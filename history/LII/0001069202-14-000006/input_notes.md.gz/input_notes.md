# LII notes — 0001069202-14-000006


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-14-000006:notes:1]
[same as prior period, unchanged from 0001069202-14-000004:notes:1]

[0001069202-14-000006:notes:2]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2014, the accompanying unaudited Consolidated

[0001069202-14-000006:notes:3]
Statements of Operations for the three and six months ended June 30, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-14-000006:notes:4]
Our fiscal year ends on December 31 and each quarter is comprised of 13 weeks. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-14-000006:notes:5]
Commitments and Contingencies:

[0001069202-14-000006:notes:6]
Product Warranties and Product Related Contingencies

[0001069202-14-000006:notes:7]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-14-000006:notes:8]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000006:notes:9]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 27.9 |  |  | $ | 28.7 |  |
| Other liabilities | 57.4 |  |  | 52.9 |  |
| Total warranty liability | $ | 85.3 |  |  | $ | 81.6 |  |

[0001069202-14-000006:notes:10]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2014 were as follows (in millions):

[0001069202-14-000006:notes:11]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (10.3 | ) |
| Changes resulting from issuance of new warranties | 16.0 |  |
| Changes in estimates associated with pre-existing liabilities | (2.2 | ) |
| Changes in foreign currency translation rates and other | 0.2 |  |
| Total warranty liability as of June 30, 2014 | $ | 85.3 |  |

[0001069202-14-000006:notes:12]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001069202-14-000006:notes:13]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the six months ended June 30, 2014 were as follows (in millions):

[0001069202-14-000006:notes:14]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.4 | ) |
| Total accrued product quality issues as of June 30, 2014 | $ | 4.3 |  |

[0001069202-14-000006:notes:15]
The expenses related to these product quality issues were classified in Cost of goods sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the Consolidated Balance Sheets.  The expenses for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated product warranty liabilities.  We may incur additional charges for these product quality issues in the future as more information becomes available.

[0001069202-14-000006:notes:16]
Litigation

[0001069202-14-000006:notes:17]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-14-000006:notes:18]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2014, and 2013, expense for asbestos-related litigation was $0.6 million, and $0.5 million, net of insurance recoveries, respectively.

[0001069202-14-000006:notes:19]
We are the defendant in an attempted class action lawsuit which alleges that evaporator coils in certain of our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks, and asserts claims for relief.  We dispute the allegations in the lawsuit.  The outcome related to this action is uncertain and we therefore cannot reasonably estimate the amount of any potential impact.

[0001069202-14-000006:notes:20]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-14-000006:notes:21]
[same as prior period, unchanged from 0001069202-14-000004:notes:20]

[0001069202-14-000006:notes:22]
The following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-14-000006:notes:23]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (2.8 | ) |  | $ | (1.6 | ) |  | $ | (3.9 | ) |  | $ | (1.2 | ) |  | Cost of goods sold |
| Income tax benefit |  | 1.0 |  |  | 0.6 |  |  | 1.4 |  |  | 0.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.8 | ) |  | $ | (1.0 | ) |  | $ | (2.5 | ) |  | $ | (0.8 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.3 | ) |  | $ | (1.9 | ) |  | $ | (2.6 | ) |  | $ | (3.9 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.5 |  |  | 0.7 |  |  | 1.0 |  |  | 1.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.8 | ) |  | $ | (1.2 | ) |  | $ | (1.6 | ) |  | $ | (2.5 | ) |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |  |  |  |  |
| Sale of foreign business (1) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 41.1 |  |  | Loss from discontinued operations |
| Total reclassifications from AOCL |  | $ | (2.6 | ) |  | $ | (2.2 | ) |  | $ | (4.1 | ) |  | $ | 37.8 |  |  |  |

[0001069202-14-000006:notes:24]
[same as prior period, unchanged from 0001069202-14-000004:notes:23]

[0001069202-14-000006:notes:25]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2014 (in millions):

[0001069202-14-000006:notes:26]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| AOCL as of December 31, 2013 |  | $ | (0.6 | ) |  | $ | 2.5 |  |  | $ | (106.0 | ) |  | $ | 43.0 |  |  | $ | (61.1 | ) |
| Other comprehensive (loss) income before reclassifications |  | (2.5 | ) |  | 1.1 |  |  | (1.4 | ) |  | 8.9 |  |  | 6.1 |  |
| Amounts reclassified from AOCL |  | 2.5 |  |  | — |  |  | 1.6 |  |  | — |  |  | 4.1 |  |
| Net other comprehensive (loss) income |  | — |  |  | 1.1 |  |  | 0.2 |  |  | 8.9 |  |  | 10.2 |  |
| AOCL as of June 30, 2014 |  | $ | (0.6 | ) |  | $ | 3.6 |  |  | $ | (105.8 | ) |  | $ | 51.9 |  |  | $ | (50.9 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-14-000006:notes:27]
[same as prior period, unchanged from 0001069202-14-000004:notes:26]

[0001069202-14-000006:notes:28]
[same as prior period, unchanged from 0001069202-14-000004:notes:27]

[0001069202-14-000006:notes:29]
[same as prior period, unchanged from 0001069202-14-000004:notes:28]

[0001069202-14-000006:notes:30]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of June 30, 2014 and December 31, 2013 and for the three and six months ended June 30, 2014 and 2013 are shown on the following pages.

[0001069202-14-000006:notes:31]
[same as prior period, unchanged from 0001069202-14-000004:notes:30]

[0001069202-14-000006:notes:32]
[same as prior period, unchanged from 0001069202-14-000004:notes:31]

[0001069202-14-000006:notes:33]
As of June 30, 2014

[0001069202-14-000006:notes:34]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.9 |  |  | $ | 19.1 |  |  | $ | 29.6 |  |  | $ | — |  |  | $ | 49.6 |  |
| Accounts and notes receivable, net | — |  |  | 19.8 |  |  | 556.7 |  |  | — |  |  | 576.5 |  |
| Inventories, net | — |  |  | 376.3 |  |  | 144.1 |  |  | (5.5 | ) |  | 514.9 |  |
| Deferred income taxes, net | (0.4 | ) |  | 21.2 |  |  | 6.0 |  |  | (3.3 | ) |  | 23.5 |  |
| Other assets | 3.5 |  |  | 46.7 |  |  | 75.6 |  |  | (67.6 | ) |  | 58.2 |  |
| Total current assets | 4.0 |  |  | 483.1 |  |  | 812.0 |  |  | (76.4 | ) |  | 1,222.7 |  |
| Property, plant and equipment, net | — |  |  | 252.6 |  |  | 97.9 |  |  | — |  |  | 350.5 |  |
| Goodwill | — |  |  | 140.4 |  |  | 79.3 |  |  | — |  |  | 219.7 |  |
| Investment in subsidiaries | 1,276.0 |  |  | 468.4 |  |  | (0.5 | ) |  | (1,743.9 | ) |  | — |  |
| Deferred income taxes | 1.0 |  |  | 73.7 |  |  | 20.3 |  |  | (8.6 | ) |  | 86.4 |  |
| Other assets, net | 3.9 |  |  | 64.6 |  |  | 23.7 |  |  | (1.4 | ) |  | 90.8 |  |
| Intercompany receivables (payables), net | (305.2 | ) |  | 299.4 |  |  | 5.8 |  |  |  |  |  | — |  |
| Total assets | $ | 979.7 |  |  | $ | 1,782.2 |  |  | $ | 1,038.5 |  |  | $ | (1,830.3 | ) |  | $ | 1,970.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 185.6 |  |  | $ | — |  |  | $ | 185.6 |  |
| Current maturities of long-term debt | — |  |  | 0.9 |  |  | 0.4 |  |  | — |  |  | 1.3 |  |
| Accounts payable | 14.6 |  |  | 300.3 |  |  | 86.0 |  |  | — |  |  | 400.9 |  |
| Accrued expenses | 3.0 |  |  | 169.1 |  |  | 64.7 |  |  | (0.2 | ) |  | 236.6 |  |
| Income taxes payable | 40.7 |  |  | 2.3 |  |  | 53.0 |  |  | (73.1 | ) |  | 22.9 |  |
| Total current liabilities | 58.3 |  |  | 472.6 |  |  | 389.7 |  |  | (73.3 | ) |  | 847.3 |  |
| Long-term debt | 403.0 |  |  | 16.5 |  |  | 0.3 |  |  | — |  |  | 419.8 |  |
| Post-retirement benefits, other than pensions | — |  |  | 3.3 |  |  | — |  |  | — |  |  | 3.3 |  |
| Pensions | — |  |  | 50.4 |  |  | 10.3 |  |  | — |  |  | 60.7 |  |
| Other liabilities | 0.4 |  |  | 120.6 |  |  | 11.8 |  |  | (11.8 | ) |  | 121.0 |  |
| Total liabilities | 461.7 |  |  | 663.4 |  |  | 412.1 |  |  | (85.1 | ) |  | 1,452.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 518.0 |  |  | 1,118.8 |  |  | 626.4 |  |  | (1,745.2 | ) |  | 518.0 |  |
| Total liabilities and stockholders' equity | $ | 979.7 |  |  | $ | 1,782.2 |  |  | $ | 1,038.5 |  |  | $ | (1,830.3 | ) |  | $ | 1,970.1 |  |

[0001069202-14-000006:notes:35]
[same as prior period, unchanged from 0001069202-14-000004:notes:34]

[0001069202-14-000006:notes:36]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.1 |  |  | $ | 10.5 |  |  | $ | 26.4 |  |  | $ | — |  |  | $ | 38.0 |  |
| Accounts and notes receivable, net | — |  |  | 12.8 |  |  | 395.3 |  |  | — |  |  | 408.1 |  |
| Inventories, net | — |  |  | 253.6 |  |  | 128.4 |  |  | (3.2 | ) |  | 378.8 |  |
| Deferred income taxes, net | 0.9 |  |  | 21.2 |  |  | 5.7 |  |  | (3.3 | ) |  | 24.5 |  |
| Other assets | 3.4 |  |  | 38.4 |  |  | 70.2 |  |  | (59.0 | ) |  | 53.0 |  |
| Total current assets | 5.4 |  |  | 336.5 |  |  | 626.0 |  |  | (65.5 | ) |  | 902.4 |  |
| Property, plant and equipment, net | — |  |  | 246.4 |  |  | 89.1 |  |  | — |  |  | 335.5 |  |
| Goodwill | — |  |  | 140.4 |  |  | 76.4 |  |  | — |  |  | 216.8 |  |
| Investment in subsidiaries | 1,138.8 |  |  | 337.5 |  |  | (0.6 | ) |  | (1,475.7 | ) |  | — |  |
| Deferred income taxes | — |  |  | 76.9 |  |  | 20.2 |  |  | (8.6 | ) |  | 88.5 |  |
| Other assets, net | 4.2 |  |  | 64.3 |  |  | 16.4 |  |  | (1.4 | ) |  | 83.5 |  |
| Intercompany receivables (payables), net | (460.6 | ) |  | 434.0 |  |  | 26.6 |  |  | — |  |  | — |  |
| Total assets | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 165.9 |  |  | $ | — |  |  | $ | 165.9 |  |
| Current maturities of long-term debt | — |  |  | 1.0 |  |  | 0.3 |  |  | — |  |  | 1.3 |  |
| Accounts payable | 11.8 |  |  | 187.8 |  |  | 83.5 |  |  | — |  |  | 283.1 |  |
| Accrued expenses | 3.3 |  |  | 168.4 |  |  | 60.4 |  |  | — |  |  | 232.1 |  |
| Income taxes payable | (30.3 | ) |  | 75.7 |  |  | 49.9 |  |  | (63.7 | ) |  | 31.6 |  |
| Total current liabilities | (15.2 | ) |  | 432.9 |  |  | 360.0 |  |  | (63.7 | ) |  | 714.0 |  |
| Long-term debt | 217.0 |  |  | 15.8 |  |  | 0.4 |  |  | — |  |  | 233.2 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| Pensions | — |  |  | 58.4 |  |  | 11.6 |  |  | — |  |  | 70.0 |  |
| Other liabilities | 0.3 |  |  | 119.4 |  |  | 11.3 |  |  | (11.8 | ) |  | 119.2 |  |
| Total liabilities | 202.1 |  |  | 631.1 |  |  | 383.3 |  |  | (75.5 | ) |  | 1,141.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 485.7 |  |  | 1,004.9 |  |  | 470.8 |  |  | (1,475.7 | ) |  | 485.7 |  |
| Total liabilities and stockholders' equity | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |

[0001069202-14-000006:notes:37]
[same as prior period, unchanged from 0001069202-14-000004:notes:36]

[0001069202-14-000006:notes:38]
For the Three Months Ended June 30, 2014

[0001069202-14-000006:notes:39]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 793.6 |  |  | $ | 210.4 |  |  | $ | (43.3 | ) |  | $ | 960.7 |  |
| Cost of goods sold | — |  |  | 583.0 |  |  | 157.0 |  |  | (41.9 | ) |  | 698.1 |  |
| Gross profit | — |  |  | 210.6 |  |  | 53.4 |  |  | (1.4 | ) |  | 262.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 131.2 |  |  | 17.7 |  |  | — |  |  | 148.9 |  |
| Losses (gains) and other expenses, net | (1.1 | ) |  | 0.3 |  |  | (0.2 | ) |  | — |  |  | (1.0 | ) |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Income from equity method investments | (75.5 | ) |  | (12.1 | ) |  | (4.0 | ) |  | 87.0 |  |  | (4.6 | ) |
| Operational income from continuing operations | 76.6 |  |  | 91.1 |  |  | 39.8 |  |  | (88.4 | ) |  | 119.1 |  |
| Interest expense, net | 3.5 |  |  | (0.9 | ) |  | 1.1 |  |  | — |  |  | 3.7 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 73.1 |  |  | 92.0 |  |  | 38.7 |  |  | (88.4 | ) |  | 115.4 |  |
| Provision for income taxes | (0.8 | ) |  | 28.1 |  |  | 13.9 |  |  | (0.4 | ) |  | 40.8 |  |
| Income from continuing operations | 73.9 |  |  | 63.9 |  |  | 24.8 |  |  | (88.0 | ) |  | 74.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.7 | ) |  | — |  |  | (0.7 | ) |
| Net income | $ | 73.9 |  |  | $ | 63.9 |  |  | $ | 24.1 |  |  | $ | (88.0 | ) |  | $ | 73.9 |  |
| Other comprehensive income, net of tax | 10.2 |  |  | 1.6 |  |  | 4.1 |  |  | (5.7 | ) |  | 10.2 |  |
| Comprehensive income | $ | 84.1 |  |  | $ | 65.5 |  |  | $ | 28.2 |  |  | $ | (93.7 | ) |  | $ | 84.1 |  |

[0001069202-14-000006:notes:40]
For the Six Months Ended June 30, 2014

[0001069202-14-000006:notes:41]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,352.8 |  |  | $ | 393.0 |  |  | $ | (89.7 | ) |  | $ | 1,656.1 |  |
| Cost of goods sold | — |  |  | 1,016.3 |  |  | 296.4 |  |  | (87.3 | ) |  | 1,225.4 |  |
| Gross profit | — |  |  | 336.5 |  |  | 96.6 |  |  | (2.4 | ) |  | 430.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 235.5 |  |  | 49.0 |  |  | — |  |  | 284.5 |  |
| Losses (gains) and other expenses, net | (0.2 | ) |  | 1.1 |  |  | 0.5 |  |  |  |  |  | 1.4 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.2 |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (97.9 | ) |  | (14.6 | ) |  | (7.1 | ) |  | 111.1 |  |  | (8.5 | ) |
| Operational income from continuing operations | 98.1 |  |  | 114.4 |  |  | 54.0 |  |  | (113.5 | ) |  | 153.0 |  |
| Interest expense, net | 6.5 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 7.0 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 91.6 |  |  | 115.9 |  |  | 52.0 |  |  | (113.5 | ) |  | 146.0 |  |
| Provision for income taxes | (2.2 | ) |  | 35.9 |  |  | 18.6 |  |  | (0.8 | ) |  | 51.5 |  |
| Income from continuing operations | 93.8 |  |  | 80.0 |  |  | 33.4 |  |  | (112.7 | ) |  | 94.5 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.7 | ) |  | — |  |  | (0.7 | ) |
| Net income | $ | 93.8 |  |  | $ | 80.0 |  |  | $ | 32.7 |  |  | $ | (112.7 | ) |  | $ | 93.8 |  |
| Other comprehensive income, net of tax | 10.2 |  |  | 4.9 |  |  | 5.4 |  |  | (10.3 | ) |  | 10.2 |  |
| Comprehensive income | $ | 104.0 |  |  | $ | 84.9 |  |  | $ | 38.1 |  |  | $ | (123.0 | ) |  | $ | 104.0 |  |

[0001069202-14-000006:notes:42]
[same as prior period, unchanged from 0001069202-14-000004:notes:39]

[0001069202-14-000006:notes:43]
For the Three Months Ended June 30, 2013

[0001069202-14-000006:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 795.4 |  |  | $ | 208.2 |  |  | $ | (90.5 | ) |  | $ | 913.1 |  |
| Cost of goods sold | 0.1 |  |  | 575.0 |  |  | 169.9 |  |  | (85.9 | ) |  | 659.1 |  |
| Gross profit | (0.1 | ) |  | 220.4 |  |  | 38.3 |  |  | (4.6 | ) |  | 254.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 117.6 |  |  | 33.7 |  |  | — |  |  | 151.3 |  |
| Losses (gains) and other expenses, net | 2.0 |  |  | (0.3 | ) |  | 0.4 |  |  | — |  |  | 2.1 |  |
| Restructuring charges | — |  |  | 1.2 |  |  | 1.2 |  |  | — |  |  | 2.4 |  |
| Income from equity method investments | (63.7 | ) |  | 6.5 |  |  | (3.4 | ) |  | 56.4 |  |  | (4.2 | ) |
| Operational income from continuing operations | 61.6 |  |  | 95.4 |  |  | 6.4 |  |  | (61.0 | ) |  | 102.4 |  |
| Interest expense, net | 3.7 |  |  | (0.6 | ) |  | 0.5 |  |  | — |  |  | 3.6 |  |
| Other expense, net | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Income from continuing operations before income taxes | 57.9 |  |  | 96.0 |  |  | 6.1 |  |  | (61.0 | ) |  | 99.0 |  |
| Provision for income taxes | (2.0 | ) |  | 35.3 |  |  | 3.1 |  |  | (1.7 | ) |  | 34.7 |  |
| Income from continuing operations | 59.9 |  |  | 60.7 |  |  | 3.0 |  |  | (59.3 | ) |  | 64.3 |  |
| Loss from discontinued operations | — |  |  | 25.4 |  |  | (25.4 | ) |  | — |  |  | — |  |
| Net income | $ | 59.9 |  |  | $ | 86.1 |  |  | $ | (22.4 | ) |  | $ | (59.3 | ) |  | $ | 64.3 |  |
| Other comprehensive income (loss), net of tax | (4.2 | ) |  | 0.3 |  |  | 38.7 |  |  | (66.3 | ) |  | (31.5 | ) |
| Comprehensive income (loss) | $ | 55.7 |  |  | $ | 86.4 |  |  | $ | 16.3 |  |  | $ | (125.6 | ) |  | $ | 32.8 |  |

[0001069202-14-000006:notes:45]
For the Six Months Ended June 30, 2013

[0001069202-14-000006:notes:46]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,316.1 |  |  | $ | 397.7 |  |  | $ | (132.3 | ) |  | $ | 1,581.5 |  |
| Cost of goods sold | 0.1 |  |  | 979.4 |  |  | 313.2 |  |  | (127.2 | ) |  | 1,165.5 |  |
| Gross profit | (0.1 | ) |  | 336.7 |  |  | 84.5 |  |  | (5.1 | ) |  | 416.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 220.3 |  |  | 66.7 |  |  | — |  |  | 287.0 |  |
| Losses and other expenses, net | 2.4 |  |  | 0.1 |  |  | 0.7 |  |  | — |  |  | 3.2 |  |
| Restructuring charges | — |  |  | 1.5 |  |  | 1.4 |  |  | — |  |  | 2.9 |  |
| Income from equity method investments | (71.6 | ) |  | 8.9 |  |  | (6.2 | ) |  | 61.5 |  |  | (7.4 | ) |
| Operational income from continuing operations | 69.1 |  |  | 105.9 |  |  | 21.9 |  |  | (66.6 | ) |  | 130.3 |  |
| Interest expense, net | 7.0 |  |  | (1.1 | ) |  | 1.1 |  |  | — |  |  | 7.0 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 62.1 |  |  | 107.0 |  |  | 20.9 |  |  | (66.6 | ) |  | 123.4 |  |
| Provision for income taxes | (3.3 | ) |  | 40.1 |  |  | 8.4 |  |  | (1.9 | ) |  | 43.3 |  |
| Income from continuing operations | 65.4 |  |  | 66.9 |  |  | 12.5 |  |  | (64.7 | ) |  | 80.1 |  |
| Loss from discontinued operations | — |  |  | 17.6 |  |  | (25.4 | ) |  | — |  |  | (7.8 | ) |
| Net income | $ | 65.4 |  |  | $ | 84.5 |  |  | $ | (12.9 | ) |  | $ | (64.7 | ) |  | $ | 72.3 |  |
| Other comprehensive income (loss), net of tax | (7.6 | ) |  | 1.1 |  |  | (7.3 | ) |  | (67.0 | ) |  | (80.8 | ) |
| Comprehensive income (loss) | $ | 57.8 |  |  | $ | 85.6 |  |  | $ | (20.2 | ) |  | $ | (131.7 | ) |  | $ | (8.5 | ) |

[0001069202-14-000006:notes:47]
[same as prior period, unchanged from 0001069202-14-000004:notes:42]

[0001069202-14-000006:notes:48]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 48.6 |  |  | $ | (92.5 | ) |  | $ | (29.5 | ) |  | $ | — |  |  | $ | (73.4 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (29.9 | ) |  | (11.3 | ) |  | — |  |  | (41.2 | ) |
| Net proceeds from sale of business | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in investing activities | — |  |  | (29.9 | ) |  | (11.3 | ) |  | — |  |  | (41.2 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.6 | ) |  | — |  |  | (0.6 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | — |  |  | (0.7 | ) |  | (0.2 | ) |  | — |  |  | (0.9 | ) |
| Borrowings from revolving credit facility | 1,018.5 |  |  | — |  |  | — |  |  | — |  |  | 1,018.5 |  |
| Payments on revolving credit facility | (832.5 | ) |  | — |  |  | — |  |  | — |  |  | (832.5 | ) |
| Proceeds from employee stock purchases | 1.0 |  |  | — |  |  | — |  |  | — |  |  | 1.0 |  |
| Repurchases of common stock | (50.0 | ) |  | — |  |  | — |  |  | — |  |  | (50.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (10.8 | ) |  | — |  |  | — |  |  | — |  |  | (10.8 | ) |
| Excess tax benefits related to share-based payments | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |
| Intercompany debt | (5.6 | ) |  | (6.3 | ) |  | 11.9 |  |  | — |  |  | — |  |
| Intercompany financing activity | (149.8 | ) |  | 141.0 |  |  | 8.8 |  |  | — |  |  | — |  |
| Intercompany investments | — |  |  | (3.0 | ) |  | 3.0 |  |  | — |  |  | — |  |
| Cash dividends paid | (23.6 | ) |  | — |  |  | — |  |  | — |  |  | (23.6 | ) |
| Net cash provided by financing activities | (48.8 | ) |  | 131.0 |  |  | 42.9 |  |  | — |  |  | 125.1 |  |
| Increase in cash and cash equivalents | (0.2 | ) |  | 8.6 |  |  | 2.1 |  |  | — |  |  | 10.5 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 1.1 |  |  | — |  |  | 1.1 |  |
| Cash and cash equivalents, beginning of period | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of period | $ | 0.9 |  |  | $ | 19.1 |  |  | $ | 29.6 |  |  | $ | — |  |  | $ | 49.6 |  |

[0001069202-14-000006:notes:49]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | (15.8 | ) |  | $ | 70.3 |  |  | $ | (142.8 | ) |  | $ | — |  |  | $ | (88.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (17.5 | ) |  | (5.9 | ) |  | — |  |  | (23.4 | ) |
| Net proceeds from sale of business | 1.5 |  |  | — |  |  | 3.3 |  |  | — |  |  | 4.8 |  |
| Net cash used in discontinued operations | — |  |  | (0.1 | ) |  | — |  |  | — |  |  | (0.1 | ) |
| Net cash used in investing activities | 1.5 |  |  | (17.6 | ) |  | (2.6 | ) |  | — |  |  | (18.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 270.0 |  |  | — |  |  | 270.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (180.0 | ) |  | — |  |  | (180.0 | ) |
| Long-term debt payments | — |  |  | (0.3 | ) |  | (0.2 | ) |  | — |  |  | (0.5 | ) |
| Borrowings from revolving credit facility | 700.5 |  |  | — |  |  | — |  |  | — |  |  | 700.5 |  |
| Payments on revolving credit facility | (640.5 | ) |  | — |  |  | — |  |  | — |  |  | (640.5 | ) |
| Proceeds from employee stock purchases | 1.0 |  |  | — |  |  | — |  |  | — |  |  | 1.0 |  |
| Repurchases of common stock | (33.0 | ) |  | — |  |  | — |  |  | — |  |  | (33.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (5.8 | ) |  | — |  |  | — |  |  | — |  |  | (5.8 | ) |
| Excess tax benefits related to share-based payments | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |
| Intercompany debt | (27.0 | ) |  | 9.7 |  |  | 17.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | 26.1 |  |  | (55.2 | ) |  | 29.1 |  |  | — |  |  | — |  |
| Cash dividends paid | (10.1 | ) |  | — |  |  | — |  |  | — |  |  | (10.1 | ) |
| Net cash provided by financing activities | 14.6 |  |  | (45.8 | ) |  | 137.8 |  |  | — |  |  | 106.6 |  |
| Decrease in cash and cash equivalents | 0.3 |  |  | 6.9 |  |  | (7.6 | ) |  | — |  |  | (0.4 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (6.1 | ) |  | — |  |  | (6.1 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of period | $ | 1.3 |  |  | $ | 20.3 |  |  | $ | 23.7 |  |  | $ | — |  |  | $ | 45.3 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-14-000006:notes:50]
Lines of Credit and Financing Arrangements:

[0001069202-14-000006:notes:51]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000006:notes:52]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 5.6 |  |  | 5.9 |  |
| Total short-term debt | $ | 185.6 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.8 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 203.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 419.8 |  |  | $ | 233.2 |  |
| Total debt | $ | 606.7 |  |  | $ | 400.4 |  |

[0001069202-14-000006:notes:53]
Short-Term Debt

[0001069202-14-000006:notes:54]
Foreign Obligations

[0001069202-14-000006:notes:55]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $5.6 million and $5.9 million of foreign obligations as of June 30, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.

[0001069202-14-000006:notes:56]
Asset Securitization Program

[0001069202-14-000006:notes:57]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-14-000006:notes:58]
The ASP provides for a maximum securitization amount ranging from $160.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-14-000006:notes:59]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 180.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 180.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

[0001069202-14-000006:notes:60]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for June 30, 2014 and December 31, 2013 was 0.77% and 0.78% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-14-000006:notes:61]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2014, we were in compliance with all covenant requirements.

[0001069202-14-000006:notes:62]
Long-Term Debt

[0001069202-14-000006:notes:63]
Domestic Revolving Credit Facility

[0001069202-14-000006:notes:64]
Under our $650.0 million Domestic Revolving Credit Facility, we had outstanding borrowings of $203.0 million as well as $27.6 million committed to standby letters of credit as of June 30, 2014. Subject to covenant limitations, $419.4 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-14-000006:notes:65]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-14-000006:notes:66]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |

[0001069202-14-000006:notes:67]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-14-000006:notes:68]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-14-000006:notes:69]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Revolving Credit Facility could occur if:

[0001069202-14-000006:notes:70]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-14-000006:notes:71]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-14-000006:notes:72]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2014, we were in compliance with all covenant requirements.

[0001069202-14-000006:notes:73]
Senior Unsecured Notes

[0001069202-14-000006:notes:74]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2014, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-14-000006:notes:75]
[same as prior period, unchanged from 0001069202-14-000004:notes:70]

[0001069202-14-000006:notes:76]
[same as prior period, unchanged from 0001069202-14-000004:notes:71]

[0001069202-14-000006:notes:77]
[same as prior period, unchanged from 0001069202-14-000004:notes:72]

[0001069202-14-000006:notes:78]
[same as prior period, unchanged from 0001069202-14-000004:notes:73]

[0001069202-14-000006:notes:79]
[same as prior period, unchanged from 0001069202-14-000004:notes:74]

[0001069202-14-000006:notes:80]
[same as prior period, unchanged from 0001069202-14-000004:notes:75]

[0001069202-14-000006:notes:81]
We have commodity futures contracts designated as cash flow hedges that are scheduled to mature through December 2015.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-14-000006:notes:82]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Unrealized losses on unsettled futures contracts | $ | 0.9 |  |  | $ | 0.8 |  |
| Income tax benefit | (0.3 | ) |  | (0.2 | ) |
| Losses included in AOCL, net of tax (1) | $ | 0.6 |  |  | $ | 0.6 |  |

[0001069202-14-000006:notes:83]
(1) Assuming commodity prices remain constant, we expect to reclassify $0.8 million of derivative losses into earnings within the next 12 months.

[0001069202-14-000006:notes:84]
[same as prior period, unchanged from 0001069202-14-000004:notes:79]

[0001069202-14-000006:notes:85]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Copper | 25.6 |  |  | 22.9 |  |

[0001069202-14-000006:notes:86]
[same as prior period, unchanged from 0001069202-14-000004:notes:81]

[0001069202-14-000006:notes:87]
[same as prior period, unchanged from 0001069202-14-000004:notes:82]

[0001069202-14-000006:notes:88]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Copper | 2.8 |  |  | 2.0 |  |
| Aluminum | 2.6 |  |  | 2.7 |  |

[0001069202-14-000006:notes:89]
[same as prior period, unchanged from 0001069202-14-000004:notes:84]

[0001069202-14-000006:notes:90]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Notional Amounts (in local currency): |  |  |  |
| Brazilian Real | 2.2 |  |  | 1.2 |  |
| Mexican Peso | 121.7 |  |  | 130.0 |  |
| Euro | 18.7 |  |  | — |  |
| British Pound | 1.8 |  |  | 3.4 |  |
| Indian Rupee | — |  |  | 28.0 |  |
| Polish Zloty | 17.1 |  |  | 32.6 |  |
| Russian Ruble | 25.8 |  |  | — |  |

[0001069202-14-000006:notes:91]
Information about the Locations and Amounts of Derivative Instruments

[0001069202-14-000006:notes:92]
[same as prior period, unchanged from 0001069202-14-000004:notes:87]

[0001069202-14-000006:notes:93]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of June 30, 2014 |  | As of December 31, 2013 |  | As of June 30, 2014 |  | As of December 31, 2013 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.4 |  |  | 0.3 |  |  | — |  |  | — |  |
| Total Assets | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |

[0001069202-14-000006:notes:94]
[same as prior period, unchanged from 0001069202-14-000004:notes:89]

[0001069202-14-000006:notes:95]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Amount of Loss reclassified from AOCL into Income (Effective Portion) (1) |  | $ | 2.8 |  |  | $ | 1.6 |  |  | $ | 3.9 |  |  | $ | 1.2 |  |
| Amount of Loss (Gain) recognized in Net income (Ineffective Portion) (2) |  | $ | (0.1 | ) |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.3 |  |

[0001069202-14-000006:notes:96]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | (0.4 | ) |  | $ | 1.0 |  |  | $ | 0.3 |  |  | $ | 1.8 |  |
| Foreign currency forward contracts (2) |  | — |  |  | 1.3 |  |  | 0.1 |  |  | 0.8 |  |
|  |  | $ | (0.4 | ) |  | $ | 2.3 |  |  | $ | 0.4 |  |  | $ | 2.6 |  |

[0001069202-14-000006:notes:97]
(1) The loss was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-14-000006:notes:98]
(2) The loss (gain) was recorded in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-14-000006:notes:99]
[same as prior period, unchanged from 0001069202-14-000004:notes:94]

[0001069202-14-000006:notes:100]
We issue various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights under the Lennox International Inc. 2010 Incentive Plan, as amended and restated.  Stock-based compensation expense related to continuing operations is included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-14-000006:notes:101]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Stock-based compensation expense (1) | $ | 6.9 |  |  | $ | 7.5 |  |  | $ | 10.7 |  |  | $ | 15.2 |  |

[0001069202-14-000006:notes:102]
[same as prior period, unchanged from 0001069202-14-000004:notes:97]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-14-000006:notes:103]
[same as prior period, unchanged from 0001069202-14-000004:notes:98]

[0001069202-14-000006:notes:104]
[same as prior period, unchanged from 0001069202-14-000004:notes:99]

[0001069202-14-000006:notes:105]
There were no assets and liabilities related to the Service Experts or Hearth businesses included in the accompanying Consolidated Balance Sheets as of June 30, 2014 or December 31, 2013, except for insurance casualty loss reserves which we retained after the respective transactions.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in discontinued operations in the accompanying Consolidated Statements of Operations.  The following table provides a summary of net trade sales, pre-tax operating income (loss) and other supplemental information related to discontinued operations (in millions):

[0001069202-14-000006:notes:106]
|  | Service Experts |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 73.5 |  |
| Pre-tax operating income (loss) (1) | 1.2 |  |  | (0.4 | ) |  | 1.1 |  |  | (15.5 | ) |
| Gain (loss) on sale of business | — |  |  | — |  |  | — |  |  | 1.7 |  |

[0001069202-14-000006:notes:107]
(1) Excludes eliminations of intercompany sales and any associated profit

[0001069202-14-000006:notes:108]
|  | Hearth |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | (2.3 | ) |  | 0.4 |  |  | (2.2 | ) |  | 0.5 |  |
| Gain (loss) on sale of business | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-14-000006:notes:109]
[same as prior period, unchanged from 0001069202-14-000004:notes:103]

[0001069202-14-000006:notes:110]
[same as prior period, unchanged from 0001069202-14-000004:notes:104]

[0001069202-14-000006:notes:111]
[same as prior period, unchanged from 0001069202-14-000004:notes:105]

[0001069202-14-000006:notes:112]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net income | $ | 73.9 |  |  | $ | 64.3 |  |  | $ | 93.8 |  |  | $ | 72.3 |  |
| Add: Loss from discontinued operations | 0.7 |  |  | — |  |  | 0.7 |  |  | 7.8 |  |
| Income from continuing operations | $ | 74.6 |  |  | $ | 64.3 |  |  | $ | 94.5 |  |  | $ | 80.1 |  |
| Weighted-average shares outstanding – basic | 48.8 |  |  | 50.2 |  |  | 48.9 |  |  | 50.2 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.8 |  |  | 0.7 |  |  | 0.8 |  |  | 0.8 |  |
| Weighted-average shares outstanding – diluted | 49.6 |  |  | 50.9 |  |  | 49.7 |  |  | 51.0 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.53 |  |  | $ | 1.28 |  |  | $ | 1.93 |  |  | $ | 1.60 |  |
| Loss from discontinued operations | (0.02 | ) |  | — |  |  | (0.01 | ) |  | (0.16 | ) |
| Net income | $ | 1.51 |  |  | $ | 1.28 |  |  | $ | 1.92 |  |  | $ | 1.44 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.50 |  |  | $ | 1.26 |  |  | $ | 1.90 |  |  | $ | 1.57 |  |
| Loss from discontinued operations | (0.01 | ) |  | — |  |  | (0.01 | ) |  | (0.15 | ) |
| Net income | $ | 1.49 |  |  | $ | 1.26 |  |  | $ | 1.89 |  |  | $ | 1.42 |  |

[0001069202-14-000006:notes:113]
[same as prior period, unchanged from 0001069202-14-000004:notes:107]

[0001069202-14-000006:notes:114]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Weighted-average number of shares | 0.3 |  |  | 0.1 |  |  | 0.3 |  |  | 0.1 |  |
| Price range per share | $81.11 - $81.14 |  |  | $ | 51.40 |  |  | $81.11 - $81.14 |  |  | $ | 51.40 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-14-000006:notes:115]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Senior unsecured notes | $ | 214.6 |  |  | $ | 214.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-14-000006:notes:116]
[same as prior period, unchanged from 0001069202-14-000004:notes:110]

[0001069202-14-000006:notes:117]
[same as prior period, unchanged from 0001069202-14-000004:notes:111]

[0001069202-14-000006:notes:118]
The methodologies used to determine the fair value of our financial assets and liabilities at June 30, 2014 were the same as those used at December 31, 2013.

[0001069202-14-000006:notes:119]
[same as prior period, unchanged from 0001069202-14-000004:notes:113]

[0001069202-14-000006:notes:120]
[same as prior period, unchanged from 0001069202-14-000004:notes:114]

[0001069202-14-000006:notes:121]
[same as prior period, unchanged from 0001069202-14-000004:notes:115]

[0001069202-14-000006:notes:122]
[same as prior period, unchanged from 0001069202-14-000004:notes:116]

[0001069202-14-000006:notes:123]
[same as prior period, unchanged from 0001069202-14-000004:notes:117]

[0001069202-14-000006:notes:124]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Investment in marketable equity securities | $ | 5.4 |  |  | $ | 4.4 |  |

[0001069202-14-000006:notes:125]
[same as prior period, unchanged from 0001069202-14-000004:notes:119]

[0001069202-14-000006:notes:126]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Revolving Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-14-000006:notes:127]
[same as prior period, unchanged from 0001069202-14-000004:notes:121]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-14-000006:notes:128]
[same as prior period, unchanged from 0001069202-14-000004:notes:122]

[0001069202-14-000006:notes:129]
The changes in the carrying amount of goodwill for the first six months of 2014, in total and by segment, are summarized in the table below (in millions):

[0001069202-14-000006:notes:130]
|  | Balance at December 31, 2013 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at June 30, 2014 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 64.6 |  |  | — |  |  | (0.2 | ) |  | 64.4 |  |
| Refrigeration | 126.1 |  |  | — |  |  | 3.1 |  |  | 129.2 |  |
| Total Goodwill | $ | 216.8 |  |  | $ | — |  |  | $ | 2.9 |  |  | $ | 219.7 |  |

[0001069202-14-000006:notes:131]
[same as prior period, unchanged from 0001069202-14-000004:notes:125]

[0001069202-14-000006:notes:132]
We performed our annual goodwill impairment test in the first quarter of 2014, and based on a qualitative assessment of impairment indicators for each of our reporting units, did not record any goodwill impairments.  We will continue to monitor our reporting units for indicators of impairment throughout the year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-14-000006:notes:133]
[same as prior period, unchanged from 0001069202-14-000004:notes:127]

[0001069202-14-000006:notes:134]
As of June 30, 2014, we had approximately $1.5 million in total gross unrecognized tax benefits. Of this amount, $1.2 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of June 30, 2014, we had approximately $0.3 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-14-000006:notes:135]
[same as prior period, unchanged from 0001069202-14-000004:notes:129]

[0001069202-14-000006:notes:136]
Since January 1, 2014, numerous states, including Indiana, New York and Rhode Island, have enacted legislation effective for tax years beginning on or after January 1, 2014, including changes to rates and unitary reporting requirements.  The impact of these changes is immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-14-000006:notes:137]
[same as prior period, unchanged from 0001069202-14-000004:notes:131]

[0001069202-14-000006:notes:138]
[same as prior period, unchanged from 0001069202-14-000004:notes:132]

[0001069202-14-000006:notes:139]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Finished goods | $ | 373.5 |  |  | $ | 251.4 |  |
| Work in process | 11.7 |  |  | 11.8 |  |
| Raw materials and parts | 202.4 |  |  | 188.9 |  |
| Subtotal | 587.6 |  |  | 452.1 |  |
| Excess of current cost over last-in, first-out cost | (72.7 | ) |  | (73.3 | ) |
| Total inventories, net | $ | 514.9 |  |  | $ | 378.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-14-000006:notes:140]
[same as prior period, unchanged from 0001069202-14-000004:notes:134]

[0001069202-14-000006:notes:141]
[same as prior period, unchanged from 0001069202-14-000004:notes:135]

[0001069202-14-000006:notes:142]
[same as prior period, unchanged from 0001069202-14-000004:notes:136]

[0001069202-14-000006:notes:143]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-14-000006:notes:144]
[same as prior period, unchanged from 0001069202-14-000004:notes:138]

[0001069202-14-000006:notes:145]
[same as prior period, unchanged from 0001069202-14-000004:notes:139]

[0001069202-14-000006:notes:146]
[same as prior period, unchanged from 0001069202-14-000004:notes:140]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-14-000006:notes:147]
[same as prior period, unchanged from 0001069202-14-000004:notes:141]

[0001069202-14-000006:notes:148]
[same as prior period, unchanged from 0001069202-14-000004:notes:142]

[0001069202-14-000006:notes:149]
|  | For the Three Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.1 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.4 |  |  | 4.2 |  |  | 0.1 |  |  | — |  |
| Expected return on plan assets | (5.7 | ) |  | (5.4 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.8 | ) |  | (0.7 | ) |
| Recognized actuarial loss | 1.6 |  |  | 2.3 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | — |  |  | 0.7 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.5 |  |  | $ | 3.1 |  |  | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0001069202-14-000006:notes:150]
|  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 2.2 |  |  | $ | 2.6 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 8.8 |  |  | 8.3 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on plan assets | (11.3 | ) |  | (10.6 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.2 |  |  | 0.2 |  |  | (1.5 | ) |  | (1.5 | ) |
| Recognized actuarial loss | 3.2 |  |  | 4.6 |  |  | 0.7 |  |  | 0.7 |  |
| Settlements and curtailments | — |  |  | 1.2 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 3.1 |  |  | $ | 6.3 |  |  | $ | (0.7 | ) |  | $ | (0.7 | ) |

[0001069202-14-000006:notes:151]
(1) All net periodic benefit cost for the three and six months ended June 30, 2014 and 2013 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-14-000006:notes:152]
[same as prior period, unchanged from 0001069202-14-000004:notes:145]

[0001069202-14-000006:notes:153]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 527.7 |  |  | $ | 476.2 |  |  | $ | 869.8 |  |  | $ | 790.7 |  |
| Commercial Heating & Cooling | 241.0 |  |  | 229.6 |  |  | 414.0 |  |  | 392.6 |  |
| Refrigeration | 192.0 |  |  | 207.3 |  |  | 372.3 |  |  | 398.2 |  |
|  | $ | 960.7 |  |  | $ | 913.1 |  |  | $ | 1,656.1 |  |  | $ | 1,581.5 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 85.0 |  |  | $ | 66.2 |  |  | $ | 109.4 |  |  | $ | 86.7 |  |
| Commercial Heating & Cooling | 39.0 |  |  | 34.6 |  |  | 49.2 |  |  | 45.7 |  |
| Refrigeration | 13.7 |  |  | 25.8 |  |  | 25.8 |  |  | 42.5 |  |
| Corporate and other | (19.2 | ) |  | (20.9 | ) |  | (30.6 | ) |  | (39.6 | ) |
| Subtotal that includes segment profit and eliminations | 118.5 |  |  | 105.7 |  |  | 153.8 |  |  | 135.3 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Special product quality adjustments | (0.4 | ) |  | 0.1 |  |  | (0.3 | ) |  | (0.1 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | (0.4 | ) |  | 0.8 |  |  | 0.8 |  |  | 2.2 |  |
| Restructuring charges | 0.2 |  |  | 2.4 |  |  | 0.3 |  |  | 2.9 |  |
| Interest expense, net | 3.7 |  |  | 3.6 |  |  | 7.0 |  |  | 7.0 |  |
| Other expense (income), net | — |  |  | (0.2 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | $ | 115.4 |  |  | $ | 99.0 |  |  | $ | 146.0 |  |  | $ | 123.4 |  |

[0001069202-14-000006:notes:154]
[same as prior period, unchanged from 0001069202-14-000004:notes:147]

[0001069202-14-000006:notes:155]
[same as prior period, unchanged from 0001069202-14-000004:notes:148]

[0001069202-14-000006:notes:156]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-14-000006:notes:157]
[same as prior period, unchanged from 0001069202-14-000004:notes:150]

[0001069202-14-000006:notes:158]
| ◦ | Special legal contingency charges, |

[0001069202-14-000006:notes:159]
| ◦ | Asbestos-related litigation, and |

[0001069202-14-000006:notes:160]
[same as prior period, unchanged from 0001069202-14-000004:notes:153]

[0001069202-14-000006:notes:161]
[same as prior period, unchanged from 0001069202-14-000004:notes:154]

[0001069202-14-000006:notes:162]
[same as prior period, unchanged from 0001069202-14-000004:notes:155]

[0001069202-14-000006:notes:163]
[same as prior period, unchanged from 0001069202-14-000004:notes:156]

[0001069202-14-000006:notes:164]
[same as prior period, unchanged from 0001069202-14-000004:notes:157]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-14-000006:notes:165]
[same as prior period, unchanged from 0001069202-14-000004:notes:158]

[0001069202-14-000006:notes:166]
[same as prior period, unchanged from 0001069202-14-000004:notes:159]

[0001069202-14-000006:notes:167]
[same as prior period, unchanged from 0001069202-14-000004:notes:160]

[0001069202-14-000006:notes:168]
[same as prior period, unchanged from 0001069202-14-000004:notes:163]

[0001069202-14-000006:notes:169]
|  | Charges Incurred in 2014 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | — |  |  | $ | 6.4 |  |  | $ | 6.4 |  |
| Asset write-offs and accelerated depreciation | 0.2 |  |  | 1.7 |  |  | 1.7 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |
| Other | 0.1 |  |  | 1.7 |  |  | 1.8 |  |
| Total restructuring charges | $ | 0.3 |  |  | $ | 9.8 |  |  | $ | 9.9 |  |

[0001069202-14-000006:notes:170]
[same as prior period, unchanged from 0001069202-14-000004:notes:165]

[0001069202-14-000006:notes:171]
|  | Charges Incurred in 2014 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 1.3 |  |  | $ | 1.3 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | 0.3 |  |  | 7.6 |  |  | 7.7 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total restructuring charges | $ | 0.3 |  |  | $ | 9.8 |  |  | $ | 9.9 |  |

[0001069202-14-000006:notes:172]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below details the activity in 2014 within the restructuring accruals (in millions):

[0001069202-14-000006:notes:173]
|  | Balance as ofDecember 31, 2013 |  | Charged to Earnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as ofJune 30, 2014 |
| Severance and related expense | $ | 1.6 |  |  | $ | — |  |  | $ | (0.2 | ) |  | $ | — |  |  | $ | 1.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.2 |  |  | — |  |  | (0.2 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Total restructuring accruals | $ | 1.6 |  |  | $ | 0.3 |  |  | $ | (0.3 | ) |  | $ | (0.2 | ) |  | $ | 1.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-14-000006:notes:174]
[same as prior period, unchanged from 0001069202-14-000004:notes:169]

[0001069202-14-000006:notes:175]
[same as prior period, unchanged from 0001069202-14-000004:notes:170]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-14-000006:notes:176]
[same as prior period, unchanged from 0001069202-14-000004:notes:171]

[0001069202-14-000006:notes:177]
[same as prior period, unchanged from 0001069202-14-000004:notes:172]

[0001069202-14-000006:notes:178]
[same as prior period, unchanged from 0001069202-14-000004:notes:173]

[0001069202-14-000006:notes:179]
[same as prior period, unchanged from 0001069202-14-000004:notes:174]

[0001069202-14-000006:notes:180]
[same as prior period, unchanged from 0001069202-14-000004:notes:175]

[0001069202-14-000006:notes:181]
[same as prior period, unchanged from 0001069202-14-000004:notes:176]

[0001069202-14-000006:notes:182]
[same as prior period, unchanged from 0001069202-14-000004:notes:177]

[0001069202-14-000006:notes:183]
[same as prior period, unchanged from 0001069202-14-000004:notes:178]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-14-000006:notes:184]
[same as prior period, unchanged from 0001069202-14-000004:notes:179]

[0001069202-14-000006:notes:185]
Our Board of Directors has authorized a total of $700.0 million towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first six months of 2014.  For the six months ended June 30, 2014, we repurchased 0.6 million shares for $50.0 million under the Share Repurchase Plans.  As of June 30, 2014, $196.2 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-14-000006:notes:186]
We also repurchased 0.1 million shares for $10.8 million for the six months ended June 30, 2014 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
