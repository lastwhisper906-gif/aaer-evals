# LII notes — 0001069202-20-000015


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-20-000015:notes:1]
[same as prior period, unchanged from 0001069202-19-000036:notes:2]

[0001069202-20-000015:notes:2]
[same as prior period, unchanged from 0001069202-19-000036:notes:3]

[0001069202-20-000015:notes:3]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2020, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2020 and 2019, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2020 and 2019, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2020 and 2019, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2020 and 2019 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2019. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-20-000015:notes:4]
[same as prior period, unchanged from 0001069202-19-000036:notes:5]

[0001069202-20-000015:notes:5]
[same as prior period, unchanged from 0001069202-19-000036:notes:6]

[0001069202-20-000015:notes:6]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-20-000015:notes:7]
[same as prior period, unchanged from 0001069202-19-000036:notes:8]

[0001069202-20-000015:notes:8]
Impact of COVID-19 Pandemic

[0001069202-20-000015:notes:9]
A novel strain of coronavirus (“COVID-19”) surfaced in late 2019 and has spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic has disrupted our business operations and caused a significant unfavorable impact on our results of operations.

[0001069202-20-000015:notes:10]
In response to the COVID-19 pandemic, various national, state, and local governments where we, our suppliers, and our customers operate have issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work.  Those decrees have resulted in supply chain disruption and higher employee absenteeism in our factories.  Additionally, certain of our manufacturing facilities have experienced a short-term suspension of operations for COVID-19 employee health concerns.

[0001069202-20-000015:notes:11]
We anticipate potential supply chain disruptions, employee absenteeism and short-term suspensions of manufacturing facilities related to the COVID-19 pandemic that could unfavorably impact our business.  Although these disruptions are expected to be temporary, there is significant uncertainty around the duration and overall impact to our business operations.  We believe it is possible that the impact of the COVID-19 pandemic could have a material adverse effect on the results of our operations, financial position and cash flows as of and for the year ended December 31, 2020.

[0001069202-20-000015:notes:12]
Recently Adopted Accounting Guidance

[0001069202-20-000015:notes:13]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to estimate credit losses. ASU 2016-13 is effective for SEC filers for interim and annual periods beginning after December 15, 2019.  We adopted ASU 2016-13 using the modified retrospective method for all financial assets measured at amortized cost.  Results for periods after January 1, 2020 are presented under ASU 2016-13 while prior period amounts continue to be reported under previously applicable accounting standards.  We recorded a $1.3 million net decrease to retained earnings as of January 1, 2020 for the cumulative effect of adopting ASU 2016-13.

[0001069202-20-000015:notes:14]
In January 2017, the FASB issued ASU No. 2017-04, Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates step two of the goodwill impairment test and specifies that goodwill impairment should be measured by comparing the fair value of a reporting unit with its carrying amount. Additionally, the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount of net assets should be disclosed. ASU 2017-04 is effective for annual or interim goodwill impairment tests performed in fiscal years beginning after December 15, 2019.  The adoption of ASU 2017-04 did not have a material impact on our consolidated results of operations, cash flow, and statement of financial position.
In August 2018, the FASB issued ASU No. 2018-15, Intangibles – Internal-Use Software (Topic 350-40): Customer’s Accounting for Implementation Costs incurred in a Cloud Computing Arrangement That is a Service Contract.  ASU 2018-15 provides guidance to determine how implementation costs associated with cloud computing arrangements that are incurred to develop or obtain internal-use software should be capitalized or expensed as incurred. ASU 2018-15 is effective for fiscal years beginning after December 15, 2019.  The adoption of ASU 2018-15 did not have a material impact on our consolidated results of operations, cash flow, and statement of financial position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-20-000015:notes:15]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-20-000015:notes:16]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, and variable refrigerant flow commercial products |  | Light Commercial |  | United StatesCanada |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, and compressorized racks |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | United StatesCanadaEurope |

[0001069202-20-000015:notes:17]
[same as prior period, unchanged from 0001069202-19-000036:notes:176]

[0001069202-20-000015:notes:18]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards

[0001069202-20-000015:notes:19]
provided to employees throughout LII. We record these share-based awards as corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-20-000015:notes:20]
[same as prior period, unchanged from 0001069202-19-000036:notes:178]

[0001069202-20-000015:notes:21]
[same as prior period, unchanged from 0001069202-19-000036:notes:179]

[0001069202-20-000015:notes:22]
[same as prior period, unchanged from 0001069202-19-000036:notes:180]

[0001069202-20-000015:notes:23]
|  |  |  |  |  | For the Three Months Ended March 31, |  |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  |  |  |  | $ | 442.1 |  |  | $ | 465.6 |  |
| Commercial Heating & Cooling |  |  |  |  | 178.4 |  |  | 173.3 |  |
| Refrigeration |  |  |  |  | 103.3 |  |  | 151.4 |  |
|  |  |  |  |  | $ | 723.8 |  |  | $ | 790.3 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  |  |  |  | $ | 32.5 |  |  | $ | 86.7 |  |
| Commercial Heating & Cooling |  |  |  |  | 18.7 |  |  | 15.1 |  |
| Refrigeration |  |  |  |  | 0.7 |  |  | 8.4 |  |
| Corporate and other |  |  |  |  | (14.3) |  |  | (12.1) |  |
| Total segment profit |  |  |  |  | 37.6 |  |  | 98.1 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Loss on sale of business |  |  |  |  | — |  |  | 8.5 |  |
| Loss (gain) from natural disaster, net of insurance recoveries |  |  |  |  | 1.6 |  |  | (6.9) |  |
| Items in (Gains) losses and other expenses, net that are excluded from segment profit (loss) (1) |  |  |  |  | (0.9) |  |  | 1.3 |  |
| Restructuring charges |  |  |  |  | 0.5 |  |  | 0.5 |  |
| Operating income |  |  |  |  | $ | 36.4 |  |  | $ | 94.7 |  |

[0001069202-20-000015:notes:24]
(1) We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-20-000015:notes:25]
•The following items in (Gains) losses and other expenses, net:

[0001069202-20-000015:notes:26]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001069202-20-000015:notes:27]
◦Special legal contingency charges,

[0001069202-20-000015:notes:28]
◦Asbestos-related litigation,

[0001069202-20-000015:notes:29]
◦Environmental liabilities,

[0001069202-20-000015:notes:30]
◦Other items, net,

[0001069202-20-000015:notes:31]
•Loss on sale of business,

[0001069202-20-000015:notes:32]
•Loss (gain) from natural disaster, net of insurance recoveries; and,

[0001069202-20-000015:notes:33]
•Restructuring charges.


## us-gaap:EarningsPerShareTextBlock

[0001069202-20-000015:notes:34]
[same as prior period, unchanged from 0001069202-19-000036:notes:166]

[0001069202-20-000015:notes:35]
[same as prior period, unchanged from 0001069202-19-000036:notes:167]

[0001069202-20-000015:notes:36]
|  |  |  |  |  | For the Three Months Ended March 31, |  |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| Net income |  |  |  |  | $ | 12.9 |  |  | $ | 69.3 |  |
| Exclude: (Income) loss from discontinued operations |  |  |  |  | (0.4) |  |  | 0.1 |  |
| Income from continuing operations |  |  |  |  | $ | 12.5 |  |  | $ | 69.4 |  |
| Weighted-average shares outstanding – basic |  |  |  |  | 38.4 |  |  | 39.7 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments |  |  |  |  | 0.3 |  |  | 0.4 |  |
| Weighted-average shares outstanding – diluted |  |  |  |  | 38.7 |  |  | 40.1 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations |  |  |  |  | $ | 0.33 |  |  | $ | 1.75 |  |
| Income from discontinued operations |  |  |  |  | 0.01 |  |  | — |  |
| Net income |  |  |  |  | $ | 0.34 |  |  | $ | 1.75 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations |  |  |  |  | $ | 0.32 |  |  | $ | 1.73 |  |
| Income from discontinued operations |  |  |  |  | 0.01 |  |  | — |  |
| Net income |  |  |  |  | $ | 0.33 |  |  | $ | 1.73 |  |

[0001069202-20-000015:notes:37]
[same as prior period, unchanged from 0001069202-19-000036:notes:169]

[0001069202-20-000015:notes:38]
|  |  |  |  |  | For the Three Months Ended March 31, |  |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| Weighted-average number of shares |  |  |  |  | 0.3 |  |  | 0.1 |  |
| Price per share |  |  |  |  | $214.63 - $270.83 |  | $ | 214.63 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-20-000015:notes:39]
4. Commitments and Contingencies:

[0001069202-20-000015:notes:40]
Leases

[0001069202-20-000015:notes:41]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component

[0001069202-20-000015:notes:42]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering

[0001069202-20-000015:notes:43]
event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

[0001069202-20-000015:notes:44]
Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-20-000015:notes:45]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-20-000015:notes:46]
We lease certain real and personal property under non-cancelable operating leases. Approximately 75% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-20-000015:notes:47]
Product Warranties and Product Related Contingencies

[0001069202-20-000015:notes:48]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-20-000015:notes:49]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000015:notes:50]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Accrued expenses | $ | 37.8 |  |  | $ | 38.2 |  |
| Other liabilities | 76.3 |  |  | 74.6 |  |
| Total warranty liability | $ | 114.1 |  |  | $ | 112.8 |  |

[0001069202-20-000015:notes:51]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2020 were as follows (in millions):

[0001069202-20-000015:notes:52]
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Warranty claims paid | (5.9) |  |
| Changes resulting from issuance of new warranties | 8.4 |  |
| Changes in estimates associated with pre-existing liabilities | (0.7) |  |
| Changes in foreign currency translation rates and other | (0.5) |  |
| Total warranty liability as of March 31, 2020 | $ | 114.1 |  |

[0001069202-20-000015:notes:53]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

[0001069202-20-000015:notes:54]
Litigation

[0001069202-20-000015:notes:55]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-20-000015:notes:56]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in (Gains) losses and other expenses, net in the Consolidated Statements of Operations.

[0001069202-20-000015:notes:57]
|  |  |  |  |  | For the Three Months Ended March 31, |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| (Gain) expense for asbestos-related litigation, net |  |  |  |  | $ | (1.7) |  |  | $ | 1.4 |  |

[0001069202-20-000015:notes:58]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.

[0001069202-20-000015:notes:59]
Marshalltown Tornado and Recovery

[0001069202-20-000015:notes:60]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covered the repair or replacement of our assets that suffered damage or loss, and business interruption costs, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Insurance proceeds for lost profits and Loss (gain) from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations.

[0001069202-20-000015:notes:61]
In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019.

[0001069202-20-000015:notes:62]
The following table summarizes the Gain from insurance recoveries, net of losses incurred:

[0001069202-20-000015:notes:63]
| (Amounts in millions) | For the Three months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Insurance recoveries received | $ | — |  |  | $ | 76.0 |  |  |  |  |  |
| Less losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | — |  |  | 17.1 |  |  |  |  |  |
| Factory inefficiencies due to lower productivity | — |  |  | 4.0 |  |  |  |  |  |
| Other | 1.6 |  |  | 8.5 |  |  |  |  |  |
| Total losses and expenses | $ | 1.6 |  |  | $ | 29.6 |  |  |  |  |  |
| Presentation in the Consolidated Statements of Operations: |  |  |  |  |  |  |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.6 |  |  | (6.9) |  |  |  |  |  |
| Insurance proceeds for lost profits | — |  |  | (39.5) |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-20-000015:notes:64]
Our Board of Directors have authorized a total of $3 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in December 2019. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of March 31, 2020, $446 million of shares may be repurchased under the Share Repurchase Plans.  
On February 13, 2020, we entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the "ASR Agreement") with Bank of America, to effect an accelerated stock buyback of the Company's common stock.  Under the ASR Agreement, we paid Bank of America $100.0 million and Bank of America delivered to us common stock representing approximately 85% of the shares expected to be purchased under the ASR Agreement.  The ASR was completed in March 2020 and Bank of America delivered a total of 0.4 million shares of common stock repurchased under this ASR Agreement.

[0001069202-20-000015:notes:65]
We also repurchased shares for $5.5 million during the three months ended March 31, 2020 from employees who tendered their shares to satisfy minimum tax withholding obligations upon the vesting and exercise of stock-based compensation awards.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-20-000015:notes:66]
During the first quarter of 2019, we obtained Board of Directors' approval and signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. The sale was completed on March 29, 2019 and the following table summarizes the net loss recognized in connection with this divestiture.  There were no gains or losses on the sale of this business for the three months ended March 31, 2020.

[0001069202-20-000015:notes:67]
| (Amounts in millions) | For the Year Ended December 31, 2019 |
| Cash received from the buyer | $ | 49.0 |  |
| Net assets sold | (52.0) |  |
| AOCI reclassification adjustments, primarily foreign currency translation | (2.1) |  |
| Direct costs to sell | (5.5) |  |
| Loss on sale of business | $ | (10.6) |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-20-000015:notes:68]
We record restructuring charges associated with management-approved restructuring plans when we reorganize or remove duplicative headcount or infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs, accelerated depreciation for impaired assets and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 2.

[0001069202-20-000015:notes:69]
Restructuring Activities in 2020

[0001069202-20-000015:notes:70]
Information regarding the restructuring charges for all ongoing activities is presented in the following table (in millions):

[0001069202-20-000015:notes:71]
|  | Incurred in 2020 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 0.1 |  |  | $ | 1.4 |  |  | $ | 1.4 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 1.7 |  |  | 1.7 |  |
| Lease termination | — |  |  | 1.1 |  |  | 1.1 |  |
| Other | 0.3 |  |  | 0.9 |  |  | 1.6 |  |
| Total restructuring charges | $ | 0.5 |  |  | $ | 5.1 |  |  | $ | 5.8 |  |

[0001069202-20-000015:notes:72]
[same as prior period, unchanged from 0001069202-19-000036:notes:145]

[0001069202-20-000015:notes:73]
|  | Incurred in 2020 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.2 |  |  | $ | 3.1 |  |  | $ | 3.1 |  |
| Commercial Heating & Cooling | 0.3 |  |  | 2.0 |  |  | 2.7 |  |
| Total restructuring charges | $ | 0.5 |  |  | $ | 5.1 |  |  | $ | 5.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-20-000015:notes:74]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue.  See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.

[0001069202-20-000015:notes:75]
|  | For the Three Months March 31, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 412.4 |  |  | $ | 161.1 |  |  | $ | 59.5 |  |  | $ | 633.0 |  |
| Canada | 29.7 |  |  | 17.1 |  |  | — |  |  | 46.8 |  |
| Other international | — |  |  | 0.2 |  |  | 43.8 |  |  | 44.0 |  |
| Total | $ | 442.1 |  |  | $ | 178.4 |  |  | $ | 103.3 |  |  | $ | 723.8 |  |

[0001069202-20-000015:notes:76]
|  | For the Three Months Ended March 31, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 433.2 |  |  | $ | 157.3 |  |  | $ | 91.6 |  |  | $ | 682.1 |  |
| Canada | 32.4 |  |  | 15.9 |  |  | 0.7 |  |  | 49.0 |  |
| Other international | — |  |  | 0.1 |  |  | 59.1 |  |  | 59.2 |  |
| Total | $ | 465.6 |  |  | $ | 173.3 |  |  | $ | 151.4 |  |  | $ | 790.3 |  |

[0001069202-20-000015:notes:77]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2020 and 2019, direct sales represented 73% and 72% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-20-000015:notes:78]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2020 and 2019, equipment sales represented 84% and 83% of revenues and the remainder of our revenue was generated from our service business.

[0001069202-20-000015:notes:79]
[same as prior period, unchanged from 0001069202-19-000036:notes:22]

[0001069202-20-000015:notes:80]
[same as prior period, unchanged from 0001069202-19-000036:notes:23]

[0001069202-20-000015:notes:81]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the

[0001069202-20-000015:notes:82]
practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001069202-20-000015:notes:83]
[same as prior period, unchanged from 0001069202-19-000036:notes:25]

[0001069202-20-000015:notes:84]
[same as prior period, unchanged from 0001069202-19-000036:notes:26]

[0001069202-20-000015:notes:85]
[same as prior period, unchanged from 0001069202-19-000036:notes:27]

[0001069202-20-000015:notes:86]
|  | March 31, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (8.5) |  |  | $ | (8.4) |  |  | $ | (0.1) |  |  | (1.2) | % |
| Contract liabilities - noncurrent | (5.8) |  |  | (5.9) |  |  | 0.1 |  |  | 1.7 | % |
| Total | $ | (14.3) |  |  | $ | (14.3) |  |  | $ | — |  |  |  |

[0001069202-20-000015:notes:87]
For the three months ended March 31, 2020 and 2019, we recognized revenue of $1.5 million and $1.1 million related to our contract liabilities at January 1, 2020 and 2019, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020 and 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-20-000015:notes:88]
[same as prior period, unchanged from 0001069202-19-000036:notes:31]

[0001069202-20-000015:notes:89]
[same as prior period, unchanged from 0001069202-19-000036:notes:32]

[0001069202-20-000015:notes:90]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Finished goods | $ | 462.1 |  |  | $ | 402.9 |  |
| Work in process | 5.7 |  |  | 6.0 |  |
| Raw materials and parts | 207.6 |  |  | 198.8 |  |
| Subtotal | 675.4 |  |  | 607.7 |  |
| Excess of current cost over last-in, first-out cost | (63.6) |  |  | (63.6) |  |
| Total inventories, net | $ | 611.8 |  |  | $ | 544.1 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-20-000015:notes:91]
Goodwill:

[0001069202-20-000015:notes:92]
The changes in the carrying amount of goodwill for the first three months of 2020, in total and by segment, are summarized in the table below (in millions):

[0001069202-20-000015:notes:93]
|  | Balance at December 31, 2019 |  |  |  | Changes in foreign currency translation rates |  | Balance at March 31, 2020 |
| Residential Heating & Cooling | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.3 |  |  |  |  | — |  |  | 99.3 |  |
| Total Goodwill | $ | 186.5 |  |  |  |  | $ | — |  |  | $ | 186.5 |  |

[0001069202-20-000015:notes:94]
[same as prior period, unchanged from 0001069202-19-000036:notes:37]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-20-000015:notes:95]
[same as prior period, unchanged from 0001069202-19-000036:notes:38]

[0001069202-20-000015:notes:96]
[same as prior period, unchanged from 0001069202-19-000036:notes:39]

[0001069202-20-000015:notes:97]
[same as prior period, unchanged from 0001069202-19-000036:notes:40]

[0001069202-20-000015:notes:98]
[same as prior period, unchanged from 0001069202-19-000036:notes:41]

[0001069202-20-000015:notes:99]
[same as prior period, unchanged from 0001069202-19-000036:notes:42]

[0001069202-20-000015:notes:100]
[same as prior period, unchanged from 0001069202-19-000036:notes:43]

[0001069202-20-000015:notes:101]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through January 2021 and August 2021, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-20-000015:notes:102]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Unrealized losses on unsettled contracts | $ | 13.7 |  |  | $ | 0.2 |  |
| Income tax benefit | (4.1) |  |  | (0.2) |  |
| Losses (gains) included in AOCL, net of tax (1) | $ | 9.6 |  |  | $ | — |  |

[0001069202-20-000015:notes:103]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $7.7 million of derivative losses into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-20-000015:notes:104]
[same as prior period, unchanged from 0001069202-19-000036:notes:127]

[0001069202-20-000015:notes:105]
We issue various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights under the Lennox International Inc. 2019 Incentive Plan, as amended and restated. Stock-based compensation expense related to continuing operations is included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-20-000015:notes:106]
|  |  |  |  |  |  | For the Three Months Ended March 31, |  |  |
|  |  |  |  |  |  | 2020 |  | 2019 |
| Stock-based compensation expense (1) |  |  |  |  |  | $ | 3.7 |  |  | $ | 5.2 |  |

[0001069202-20-000015:notes:107]
[same as prior period, unchanged from 0001069202-19-000036:notes:130]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-20-000015:notes:108]
[same as prior period, unchanged from 0001069202-19-000036:notes:124]

[0001069202-20-000015:notes:109]
|  |  | For the Three Months Ended March 31, |  |  |
|  |  | 2020 |  | 2019 |
| Service cost |  | $ | 1.4 |  |  | $ | 1.2 |  |
| Interest cost |  | 1.8 |  |  | 3.5 |  |
| Expected return on plan assets |  | (2.2) |  |  | (4.7) |  |
| Recognized actuarial loss |  | 1.5 |  |  | 2.0 |  |
| Net periodic benefit cost |  | $ | 2.5 |  |  | $ | 2.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-20-000015:notes:110]
As of March 31, 2020, we had approximately $3.1 million in total gross unrecognized tax benefits.  Of this amount $3.1 million, if recognized, would be recorded through the Consolidated Statements of Operations.

[0001069202-20-000015:notes:111]
We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2019 and are subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2012.

[0001069202-20-000015:notes:112]
In the first quarter of 2020, we recorded a $7.6 million valuation allowance on certain foreign deferred tax assets. We concluded that it was no longer more likely than not that these foreign tax loss carryforwards would be realized due to the adverse impact of the COVID-19 pandemic on our European manufacturing facilities and the resulting downturn in the related business.


## us-gaap:DebtDisclosureTextBlock

[0001069202-20-000015:notes:113]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000015:notes:114]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 215.0 |  |  | $ | 285.0 |  |
| Finance lease obligations | 8.2 |  |  | 7.8 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 252.3 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 26.2 |  |  | 25.9 |  |
| Domestic credit facility | 815.5 |  |  | 475.5 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (1.8) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,189.9 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,442.2 |  |  | $ | 1,171.2 |  |

[0001069202-20-000015:notes:115]
Short-Term Debt

[0001069202-20-000015:notes:116]
Foreign Obligations

[0001069202-20-000015:notes:117]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2020 or December 31, 2019 and there were no proceeds and repayments on these facilities for the three months ended March 31, 2020 or March 31, 2019.

[0001069202-20-000015:notes:118]
Asset Securitization Program

[0001069202-20-000015:notes:119]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001069202-20-000015:notes:120]
We renewed the ASP in November 2019, extending its term to November 2021 and increasing the maximum securitization amount to a range from$250.0 million to $400.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-20-000015:notes:121]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 215.0 |  |  | $ | 320.0 |  |
| Less: Beneficial interest transferred | (215.0) |  |  | (285.0) |  |
| Remaining amount available | $ | — |  |  | $ | 35.0 |  |

[0001069202-20-000015:notes:122]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of

[0001069202-20-000015:notes:123]
0.70%. The average rates as of March 31, 2020 and December 31, 2019 were 2.23% and 2.51%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-20-000015:notes:124]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of March 31, 2020, we believe we were in compliance with all covenant requirements.

[0001069202-20-000015:notes:125]
Long-Term Debt

[0001069202-20-000015:notes:126]
Domestic Credit Facility

[0001069202-20-000015:notes:127]
On January 22, 2019, we amended our Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $160.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $845.5 million, of which $160.0 million was the term loan balance, as well as $2.4 million committed to standby letters of credit as of March 31, 2020. Subject to covenant limitations, $312.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

[0001069202-20-000015:notes:128]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-20-000015:notes:129]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 2.13 | % |  | 2.93 | % |

[0001069202-20-000015:notes:130]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-20-000015:notes:131]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-20-000015:notes:132]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-20-000015:notes:133]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or

[0001069202-20-000015:notes:134]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-20-000015:notes:135]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-20-000015:notes:136]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2020, we believe we were in compliance with all covenant requirements.
Senior Unsecured NotesWe issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2020, we believe we were in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-20-000015:notes:137]
[same as prior period, unchanged from 0001069202-19-000036:notes:136]

[0001069202-20-000015:notes:138]
|  |  |  |  |  |  | For the Three Months Ended March 31, |  |  |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  |  |  |  |  | 2020 |  | 2019 |  |  |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  |  |  |  |  | $ | (1.2) |  |  | $ | (2.4) |  |  | Cost of goods sold and (Gains) losses and other expenses, net |
| Income tax benefit (expense) |  |  |  |  |  |  | 0.3 |  |  | 0.6 |  |  | Provision for income taxes |
| Net of tax |  |  |  |  |  |  | $ | (0.9) |  |  | $ | (1.8) |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  |  |  |  |  | $ | (1.5) |  |  | $ | (2.0) |  |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  |  |  |  |  | 0.3 |  |  | 0.5 |  |  | Provision for income taxes |
| Net of tax |  |  |  |  |  | $ | (1.2) |  |  | $ | (1.5) |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency adjustments on sale of business |  |  |  |  |  | $ | — |  |  | $ | (2.1) |  |  | Loss on sale of business |
| Net of tax |  |  |  |  |  | $ | — |  |  | $ | (2.1) |  |  |  |
| Total reclassifications from AOCL |  |  |  |  |  | $ | (2.1) |  |  | $ | (5.4) |  |  |  |

[0001069202-20-000015:notes:139]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2020 (in millions):

[0001069202-20-000015:notes:140]
|  |  | Gains (Losses) on Cash Flow Hedges |  |  |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2019 |  | $ | — |  |  |  |  | $ | (81.5) |  |  | $ | (22.3) |  |  | $ | (103.8) |  |
| Other comprehensive loss before reclassifications |  | (10.5) |  |  |  |  | (0.6) |  |  | (20.3) |  |  | (31.4) |  |
| Amounts reclassified from AOCL |  | 0.9 |  |  |  |  | 1.2 |  |  | — |  |  | 2.1 |  |
| Net other comprehensive (loss) income |  | (9.6) |  |  |  |  | 0.6 |  |  | (20.3) |  |  | (29.3) |  |
| Balance as of March 31, 2020 |  | $ | (9.6) |  |  |  |  | $ | (80.9) |  |  | $ | (42.6) |  |  | $ | (133.1) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-20-000015:notes:141]
[same as prior period, unchanged from 0001069202-19-000036:notes:200]

[0001069202-20-000015:notes:142]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2020 were the same as those used at December 31, 2019.

[0001069202-20-000015:notes:143]
[same as prior period, unchanged from 0001069202-19-000036:notes:202]

[0001069202-20-000015:notes:144]
Derivatives were classified as Level 2 and primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives. We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, however, they were insignificant to the overall value of the derivatives.  Refer to Note 9 for more information related to our derivative instruments.

[0001069202-20-000015:notes:145]
[same as prior period, unchanged from 0001069202-19-000036:notes:204]

[0001069202-20-000015:notes:146]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-20-000015:notes:147]
[same as prior period, unchanged from 0001069202-19-000036:notes:206]

[0001069202-20-000015:notes:148]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Senior unsecured notes | $ | 356.8 |  |  | $ | 356.8 |  |


## us-gaap:SubsequentEventsTextBlock

[0001069202-20-000015:notes:149]
15. Subsequent Event:Due to the economic impact of the COVID-19 pandemic on our business, we implemented cost reduction actions in April 2020 to realize SG&A savings for the balance of the year.  In connection with these cost saving actions, we expect to incur pre-tax charges of approximately $10 million in the second quarter of 2020 related to personnel severance and benefits and facility exit costs.
