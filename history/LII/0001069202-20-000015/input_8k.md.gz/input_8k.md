# LII 8-K — 0001069202-20-000013 filed 2020-04-20

## item codes, every 8-K on or before 2020-04-20

- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2020-04-20

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-20-000013:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetabl.htm
EX-99.1

[0001069202-20-000013:8k_2_02:2]
Document

[0001069202-20-000013:8k_2_02:3]
Exhibit-99.1

[0001069202-20-000013:8k_2_02:4]
Lennox International Reports First Quarter Results and Updates Outlook

[0001069202-20-000013:8k_2_02:5]
•Impacted by adverse weather and the COVID-19 pandemic, the company reports first-quarter results and updates financial outlook for the year based on current market assumptions

[0001069202-20-000013:8k_2_02:6]
•First-quarter revenue on a GAAP basis down 8%; excluding the impact from prior-year divestitures, adjusted revenue down 4%

[0001069202-20-000013:8k_2_02:7]
•GAAP EPS from continuing operations $0.32 compared to $1.73 in the prior-year quarter that included $0.87 of insurance benefit related to the tornado

[0001069202-20-000013:8k_2_02:8]
•Adjusted EPS from continuing operations $0.56 compared to $1.68 in the prior-year quarter that included $0.75 of insurance benefit related to the tornado

[0001069202-20-000013:8k_2_02:9]
•Stock repurchases of $100 million in the first quarter

[0001069202-20-000013:8k_2_02:10]
•For 2020, the company currently assumes a negative 20% impact from COVID-19 on the North America unitary HVAC and refrigeration market

[0001069202-20-000013:8k_2_02:11]
•2020 adjusted revenue expected to be down 11-17% from the prior year versus previous guidance for 4-8% growth

[0001069202-20-000013:8k_2_02:12]
•Currently estimating 2020 GAAP EPS from continuing operations of $7.07-$8.07 and adjusted EPS from continuing operations of $7.50-$8.50

[0001069202-20-000013:8k_2_02:13]
•$115 million of SG&A cost reduction actions taken for the balance of 2020; a pre-tax charge of approximately $10 million expected in the second quarter

[0001069202-20-000013:8k_2_02:14]
DALLAS, April 20, 2020 – Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2020. All comparisons are to the prior-year period. The company’s insurance references relate to the July 2018 tornado damage at a Residential manufacturing facility in Iowa. Adjusted revenue and profit exclude non-core Refrigeration businesses divested in prior periods.

[0001069202-20-000013:8k_2_02:15]
Lennox International reported first-quarter GAAP and adjusted revenue of $724 million. GAAP revenue was down 8%, including 4% of negative impact from divestitures in the prior year. Excluding the impact from divestitures, adjusted revenue was down 4%.

[0001069202-20-000013:8k_2_02:16]
GAAP operating income was $36 million, down from $95 million in the prior-year quarter that included approximately $47 million of insurance benefit. GAAP earnings per share from continuing operations was $0.32, compared to $1.73 in the prior-year quarter that included $0.87 of insurance benefit.

[0001069202-20-000013:8k_2_02:17]
Total adjusted segment profit was $38 million, compared to $99 million in the prior year quarter that included $40 million of insurance benefit. Total adjusted segment margin was 5.2% compared to 13.1% in the prior-year quarter as reported and 7.8% excluding the insurance benefit. Adjusted earnings per share from continuing operations was $0.56 compared to $1.68 in the prior-year quarter that included $0.75 of insurance benefit.

[0001069202-20-000013:8k_2_02:18]
“Weather continued to have an adverse impact on our business in the first quarter with heating degree days down significantly from last year,” said Chairman and CEO Todd Bluedorn. “In addition, we saw an increasing impact on our business in March from the COVID-19 pandemic. Operationally, HVAC is designated as an essential business in North America and Europe. On the demand side, however, we saw contractors stocking up less residential equipment ahead of the spring and summer seasons due to the economic uncertainty, and national account customers in both our Commercial and Refrigeration businesses pushing orders out.

[0001069202-20-000013:8k_2_02:19]
“Residential segment revenue was down 5% in the first quarter. Segment profit was $33 million, down from $87 million on a reported basis in the prior-year quarter that included $40 million of insurance benefit. Segment margin was 7.4% in the quarter, compared to 18.6% as reported or 10.0% excluding the $40 million of insurance benefit in the prior-year quarter.

[0001069202-20-000013:8k_2_02:20]
“In our Commercial business, revenue was up 3% in the first quarter. Segment profit rose 24%, and segment margin expanded 180 basis points to 10.5%. In Refrigeration, adjusted segment revenue was down 11% at constant currency. North America was down mid-single digits. Europe refrigeration and HVAC revenue was down high-teens as the impact from COVID-19 began to hit the already slower European market earlier than in North America. Refrigeration segment margin declined 730 basis points to 0.7%, and segment profit was down 93% to $1 million.

[0001069202-20-000013:8k_2_02:21]
“For 2020, significant challenges lie ahead in uncertain market conditions in which we currently expect a negative 20% impact from the pandemic. We have re-set our financial expectations based on that level of market impact and now expect company revenue to be down 11-17% and adjusted EPS from continuing operations in the range of $7.50-$8.50 for 2020. Lennox has a focused and seasoned team with experience managing through economic downturns. We have already taken cost reduction

[0001069202-20-000013:8k_2_02:22]
actions to realize $115 million in SG&A savings for the balance of the year. We expect cash generation this year to remain strong as working capital requirements shrink and we take action to reduce our capital expenditures. While executing on what is required in current economic conditions, we remain mindful of the future and are confident we will once again strengthen our position in the market as we emerge in the recovery.”

[0001069202-20-000013:8k_2_02:23]
FINANCIAL HIGHLIGHTS

[0001069202-20-000013:8k_2_02:24]
Revenue: On a GAAP and adjusted basis, revenue was $724 million. GAAP revenue was down 8%. Excluding the impact from divestitures in the prior year, adjusted revenue was down 4%. Foreign exchange was neutral to revenue. Volume was down, and price and mix were favorable.

[0001069202-20-000013:8k_2_02:25]
Gross Profit: On a GAAP basis, gross profit was $166 million compared to $202 million in the prior-year quarter. GAAP gross margin was 22.9% compared to 25.5% in the prior-year quarter. On an adjusted basis, gross profit was $166 million compared to $198 million in the first quarter a year ago. Adjusted gross margin was 22.9% compared to 26.2% in the prior-year quarter. Gross profit was impacted by lower volume from adverse weather and the COVID-19 pandemic, unfavorable mix, lower factory absorption, higher other product costs, and COVID-19 factory shutdown costs.

[0001069202-20-000013:8k_2_02:26]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the first quarter was $12.5 million, or $0.32 per share, compared to $69.4 million, or $1.73 per share, in the prior-year quarter.

[0001069202-20-000013:8k_2_02:27]
Adjusted income from continuing operations in the first quarter was $21.7 million, or $0.56 per share, compared to $67.2 million, or $1.68 per share, in the prior-year quarter. Adjusted income from continuing operations for the first quarter of 2020 excludes net after-tax charges of $9.2 million, consisting of: $8.3 million in total for other tax items, net, and excess tax benefits from share-based compensation; $1.3 million for loss from natural disaster, net of insurance recoveries; and a net benefit of $0.4 million for various other items.

[0001069202-20-000013:8k_2_02:28]
Cash from Operations, Free Cash Flow and Total Debt: Net cash used in operations in the first quarter was $99 million compared to $141 million in the prior-year quarter. Capital expenditures were $25 million compared to $37 million in the prior-year quarter that also included $7 million of proceeds related to divestitures and insurance. Free cash flow was approximately ($123) million compared to ($171) million in the first quarter a year ago. Total debt at the end of the first quarter was $1.44 billion. Total cash, cash equivalents and short-term investments were $43 million at the end of March. In the first quarter, the company repurchased $100 million of stock and paid $30 million in dividends.

[0001069202-20-000013:8k_2_02:29]
BUSINESS SEGMENT HIGHLIGHTS

[0001069202-20-000013:8k_2_02:30]
Residential Heating & Cooling

[0001069202-20-000013:8k_2_02:31]
Revenue in the Residential Heating & Cooling business segment was $442 million, down 5%. Foreign exchange was neutral to revenue. Segment profit was $33 million, compared to $87 million in the prior-year quarter that included $40 million of insurance benefit. Segment margin was 7.4%. In the prior-year quarter, segment margin was 18.6% as reported or 10.0% excluding the $40 million insurance benefit. Residential results were negatively impacted by the year-over-year difference in insurance benefit, unfavorable weather, the COVID-19 pandemic that led to lower volume and factory shutdown costs, higher other product costs, and unfavorable mix. Partial offsets included favorable price, lower material costs, lower tariffs, favorable warranty costs, lower freight costs, lower SG&A expenses, and favorable foreign exchange.

[0001069202-20-000013:8k_2_02:32]
Commercial Heating & Cooling

[0001069202-20-000013:8k_2_02:33]
Revenue in the Commercial Heating & Cooling business segment was $178 million, up 3%. Foreign exchange was neutral. Segment margin expanded 180 basis points to 10.5%. Segment profit rose 24% to $19 million. Commercial results were impacted by favorable mix, lower material costs, and lower SG&A expenses. Partial offsets included the COVID-19 pandemic that led to lower volume, and unfavorable warranty costs.

[0001069202-20-000013:8k_2_02:34]
Refrigeration

[0001069202-20-000013:8k_2_02:35]
Adjusted revenue in the Refrigeration business segment was $103 million, down 12%. Foreign exchange had a negative 1% impact on revenue. Adjusted segment profit was $1 million, compared to $9 million in the prior-year quarter. Segment margin was 0.7%, compared to 8.0% in the prior-year quarter. Refrigeration results were impacted by the COVID-19 pandemic that led to lower volume and factory shutdown costs, higher other product costs, and unfavorable mix. Partial offsets included favorable price and lower SG&A expenses.

[0001069202-20-000013:8k_2_02:36]
FULL-YEAR ESTIMATES

[0001069202-20-000013:8k_2_02:37]
Assuming a decline in the North America unitary HVAC and refrigeration market of approximately 20% in 2020 due to the impact from the COVID-19 pandemic, the company estimates the following financial results for the full year:

[0001069202-20-000013:8k_2_02:38]
•Adjusted revenue down 11-17% from the prior year, compared to previous guidance of 4-8% revenue growth.

[0001069202-20-000013:8k_2_02:39]
•GAAP EPS from continuing operations of $7.07-$8.07, including a pre-tax charge of approximately $10 million expected in the second quarter for restructuring actions; previous guidance was $11.30-$11.90.

[0001069202-20-000013:8k_2_02:40]
•Adjusted EPS from continuing operations of $7.50-$8.50, compared to previous guidance of $11.30-$11.90.

[0001069202-20-000013:8k_2_02:41]
•Corporate expenses of approximately $75 million, compared to previous guidance of $90 million.

[0001069202-20-000013:8k_2_02:42]
•An effective tax rate of 21-22% on an adjusted basis for the full year, unchanged from previous guidance.

[0001069202-20-000013:8k_2_02:43]
•Capital expenditures of approximately $120 million, compared to previous guidance of $153 million.

[0001069202-20-000013:8k_2_02:44]
•Free cash flow of approximately $340 million, compared to previous guidance of $410 million.

[0001069202-20-000013:8k_2_02:45]
•The company repurchased $100 million of stock in the first quarter of 2020, has placed repurchase plans for the second quarter on hold, and will review plans for the third and fourth quarters as the year progresses; previous guidance was for $400 million of stock repurchases in 2020.

[0001069202-20-000013:8k_2_02:46]
•The company’s quarterly dividend plans are unchanged, most recently $0.77 per share, or more than $115 million in total for the year.

[0001069202-20-000013:8k_2_02:47]
CONFERENCE CALL INFORMATION

[0001069202-20-000013:8k_2_02:48]
A conference call to discuss the company’s first-quarter results and outlook will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 844-291-6362 (U.S.) or 234-720-6995 (international) at least 10 minutes prior to the scheduled start time and use reservation number 4313873. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from approximately 11:00 a.m. Central time on April 20 through May 4, 2020 by dialing 866-207-1041 (U.S.) or 402-970-0847 (international) and using access code 7727432. The call also will be archived on the company’s website.

[0001069202-20-000013:8k_2_02:49]
About Lennox International

[0001069202-20-000013:8k_2_02:50]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-20-000013:8k_2_02:51]
FORWARD-LOOKING STATEMENTS

[0001069202-20-000013:8k_2_02:52]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000013:8k_2_02:53]
Consolidated Statements of Operations

[0001069202-20-000013:8k_2_02:54]
(Unaudited)

[0001069202-20-000013:8k_2_02:55]
| (Amounts in millions, except per share data) |  |  |  |  | For the Three Months Ended March 31, |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| Net sales |  |  |  |  | $ | 723.8 |  |  | $ | 790.3 |  |
| Cost of goods sold |  |  |  |  | 558.1 |  |  | 588.7 |  |
| Gross profit |  |  |  |  | 165.7 |  |  | 201.6 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  |  |  | 131.1 |  |  | 145.8 |  |
| (Gains) losses and other expenses, net |  |  |  |  | (1.0) |  |  | 1.1 |  |
| Restructuring charges |  |  |  |  | 0.5 |  |  | 0.5 |  |
| Loss on sale of business |  |  |  |  | — |  |  | 8.5 |  |
| Insurance proceeds for lost profits |  |  |  |  | — |  |  | (39.5) |  |
| Loss (gain) from natural disaster, net of insurance recoveries |  |  |  |  | 1.6 |  |  | (6.9) |  |
| Income from equity method investments |  |  |  |  | (2.9) |  |  | (2.6) |  |
| Operating income |  |  |  |  | 36.4 |  |  | 94.7 |  |
| Interest expense, net |  |  |  |  | 8.7 |  |  | 10.9 |  |
| Other expense (income), net |  |  |  |  | 1.2 |  |  | 0.8 |  |
| Income from continuing operations before income taxes |  |  |  |  | 26.5 |  |  | 83.0 |  |
| Provision for income taxes |  |  |  |  | 14.0 |  |  | 13.6 |  |
| Income from continuing operations |  |  |  |  | 12.5 |  |  | 69.4 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  |  |  | — |  |  | (0.1) |  |
| Income tax benefit |  |  |  |  | (0.4) |  |  | — |  |
| Income (loss) from discontinued operations |  |  |  |  | 0.4 |  |  | (0.1) |  |
| Net income |  |  |  |  | $ | 12.9 |  |  | $ | 69.3 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations |  |  |  |  | $ | 0.33 |  |  | $ | 1.75 |  |
| Income from discontinued operations |  |  |  |  | 0.01 |  |  | — |  |
| Net income |  |  |  |  | $ | 0.34 |  |  | $ | 1.75 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations |  |  |  |  | $ | 0.32 |  |  | $ | 1.73 |  |
| Income from discontinued operations |  |  |  |  | 0.01 |  |  | — |  |
| Net income |  |  |  |  | $ | 0.33 |  |  | $ | 1.73 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  |  |  | 38.4 |  |  | 39.7 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  |  |  | 38.7 |  |  | 40.1 |  |

[0001069202-20-000013:8k_2_02:56]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |
| Adjusted Segment Net Sales and Profit (Loss) |  |  |  |
| (Unaudited) |  |  |  |

[0001069202-20-000013:8k_2_02:57]
| (Amounts in millions) |  |  |  |  | For the Three Months Ended March 31, |  |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  |  |  |  | $ | 442.1 |  |  | $ | 465.6 |  |
| Commercial Heating & Cooling |  |  |  |  | 178.4 |  |  | 173.3 |  |
| Refrigeration (1) |  |  |  |  | $ | 103.3 |  |  | 117.1 |  |
|  |  |  |  |  | $ | 723.8 |  |  | $ | 756.0 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  |  |  |  | $ | 32.5 |  |  | $ | 86.7 |  |
| Commercial Heating & Cooling |  |  |  |  | 18.7 |  |  | 15.1 |  |
| Refrigeration (1) |  |  |  |  | 0.7 |  |  | 9.4 |  |
| Corporate and other |  |  |  |  | (14.3) |  |  | (12.1) |  |
| Total adjusted segment profit |  |  |  |  | 37.6 |  |  | 99.1 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Loss on sale of business |  |  |  |  | — |  |  | 8.5 |  |
| Loss (gain) from natural disaster, net of insurance recoveries |  |  |  |  | 1.6 |  |  | (6.9) |  |
| Items in (gains) losses and other expenses, net that are excluded from segment profit (loss) (2) |  |  |  |  | (0.9) |  |  | 1.3 |  |
| Restructuring charges |  |  |  |  | 0.5 |  |  | 0.5 |  |
| Operating loss from non-core business (1) |  |  |  |  | — |  |  | 1.0 |  |
| Operating income |  |  |  |  | $ | 36.4 |  |  | $ | 94.7 |  |

[0001069202-20-000013:8k_2_02:58]
(1) Excludes the non-core business results related to Kysor Warren, which was sold in March 2019.

[0001069202-20-000013:8k_2_02:59]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-20-000013:8k_2_02:60]
•The following items in (Gains) losses and other expenses, net:

[0001069202-20-000013:8k_2_02:61]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001069202-20-000013:8k_2_02:62]
◦Special legal contingency charges,

[0001069202-20-000013:8k_2_02:63]
◦Asbestos-related litigation,

[0001069202-20-000013:8k_2_02:64]
◦Environmental liabilities,

[0001069202-20-000013:8k_2_02:65]
◦Other items, net,

[0001069202-20-000013:8k_2_02:66]
•Loss on sale of business,

[0001069202-20-000013:8k_2_02:67]
•Loss (gain) from natural disaster, net of insurance recoveries,

[0001069202-20-000013:8k_2_02:68]
•Operating loss (income) from non-core businesses; and

[0001069202-20-000013:8k_2_02:69]
•Restructuring charges.

[0001069202-20-000013:8k_2_02:70]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000013:8k_2_02:71]
Consolidated Balance Sheets

[0001069202-20-000013:8k_2_02:72]
| (Amounts in millions, except shares and par values) | As of March 31, 2020 |  | As of December 31, 2019 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 39.1 |  |  | $ | 37.3 |  |
| Short-term investments | 3.7 |  |  | 2.9 |  |
| Accounts and notes receivable, net of allowances of $7.0 and $6.1 in 2020 and 2019, respectively | 492.7 |  |  | 477.8 |  |
| Inventories, net | 611.8 |  |  | 544.1 |  |
| Other assets | 77.8 |  |  | 58.8 |  |
| Total current assets | 1,225.1 |  |  | 1,120.9 |  |
| Property, plant and equipment, net of accumulated depreciation of $836.5 and $824.3 in 2020 and 2019, respectively | 442.1 |  |  | 445.4 |  |
| Right-of-use assets from operating leases | 183.2 |  |  | 181.6 |  |
| Goodwill | 186.5 |  |  | 186.5 |  |
| Deferred income taxes | 16.3 |  |  | 21.5 |  |
| Other assets, net | 75.2 |  |  | 79.0 |  |
| Total assets | $ | 2,128.4 |  |  | $ | 2,034.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 252.3 |  |  | 321.9 |  |
| Current operating lease liabilities | 52.2 |  |  | 52.7 |  |
| Accounts payable | 355.0 |  |  | 372.4 |  |
| Accrued expenses | 235.1 |  |  | 255.7 |  |
| Total current liabilities | 894.6 |  |  | 1,002.7 |  |
| Long-term debt | 1,189.9 |  |  | 849.3 |  |
| Long-term operating lease liabilities | 133.2 |  |  | 131.0 |  |
| Pensions | 89.8 |  |  | 87.4 |  |
| Other liabilities | 139.2 |  |  | 134.7 |  |
| Total liabilities | 2,446.7 |  |  | 2,205.1 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,095.2 |  |  | 1,093.5 |  |
| Retained earnings | 2,130.9 |  |  | 2,148.7 |  |
| Accumulated other comprehensive loss | (133.1) |  |  | (103.8) |  |
| Treasury stock, at cost, 48,918,495 shares and 48,575,901 shares for 2020 and 2019, respectively | (3,412.2) |  |  | (3,309.5) |  |
| Total stockholders' deficit | (318.3) |  |  | (170.2) |  |
| Total liabilities and stockholders' deficit | $ | 2,128.4 |  |  | $ | 2,034.9 |  |

[0001069202-20-000013:8k_2_02:73]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000013:8k_2_02:74]
Consolidated Statements of Cash Flows

[0001069202-20-000013:8k_2_02:75]
(Unaudited)

[0001069202-20-000013:8k_2_02:76]
| (Amounts in millions) | For the Three Months Ended March 31, |  |  |
|  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 12.9 |  |  | $ | 69.3 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |
| Loss on sale of business | — |  |  | 8.5 |  |
| Gain from insurance recoveries, net of losses incurred | — |  |  | (6.9) |  |
| Income from equity method investments | (2.9) |  |  | (2.6) |  |
| Restructuring charges, net of cash paid | 0.1 |  |  | 0.3 |  |
| Provision for bad debts | 1.2 |  |  | 1.6 |  |
| Unrealized losses (gains) on derivative contracts | 1.5 |  |  | (0.6) |  |
| Stock-based compensation expense | 3.7 |  |  | 5.2 |  |
| Depreciation and amortization | 19.0 |  |  | 18.2 |  |
| Deferred income taxes | 8.8 |  |  | 15.5 |  |
| Pension expense | 2.7 |  |  | 2.0 |  |
| Pension contributions | (0.6) |  |  | (2.5) |  |
| Other items, net | 0.2 |  |  | 0.2 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (18.7) |  |  | (62.7) |  |
| Inventories | (71.0) |  |  | (120.9) |  |
| Other current assets | (0.7) |  |  | 4.5 |  |
| Accounts payable | (8.7) |  |  | (1.7) |  |
| Accrued expenses | (33.0) |  |  | (35.0) |  |
| Income taxes payable / receivable | (17.3) |  |  | (34.1) |  |
| Leases, net | 0.1 |  |  | 0.5 |  |
| Other, net | 3.9 |  |  | 0.2 |  |
| Net cash used in operating activities | (98.8) |  |  | (141.0) |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.1 |  |  | 0.3 |  |
| Purchases of property, plant and equipment | (24.7) |  |  | (37.2) |  |
| Net proceeds from sale of business | — |  |  | 43.6 |  |
| Purchases of short-term investments | (1.1) |  |  | — |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 6.9 |  |
| Net cash (used in) provided by investing activities | (25.7) |  |  | 13.6 |  |
| Cash flows from financing activities: |  |  |  |
| Asset securitization payments | (70.0) |  |  | (43.5) |  |
| Long-term debt payments | (2.6) |  |  | (31.7) |  |
| Long-term debt borrowings | — |  |  | 3.3 |  |
| Borrowings from credit facility | 682.5 |  |  | 844.5 |  |
| Payments on credit facility | (342.5) |  |  | (525.5) |  |
| Proceeds from employee stock purchases | 0.8 |  |  | 0.8 |  |
| Repurchases of common stock | (100.0) |  |  | (100.0) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (5.5) |  |  | (13.5) |  |
| Cash dividends paid | (29.7) |  |  | (25.5) |  |
| Net cash provided by financing activities | 133.0 |  |  | 108.9 |  |
| Increase (decrease) in cash and cash equivalents | 8.5 |  |  | (18.5) |  |
| Effect of exchange rates on cash and cash equivalents | (6.7) |  |  | 3.9 |  |
| Cash and cash equivalents, beginning of period | 37.3 |  |  | 46.3 |  |
| Cash and cash equivalents, end of period | $ | 39.1 |  |  | $ | 31.7 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 6.8 |  |  | $ | 8.4 |  |
| Income taxes paid (net of refunds) | $ | 21.3 |  |  | $ | 32.0 |  |
| Insurance recoveries received | $ | — |  |  | $ | 76.0 |  |

[0001069202-20-000013:8k_2_02:77]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |  |  |  |  |  |  |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |  |  |  |  |  |  |  |  |  |  |  |
| (Unaudited, in millions, except per share and ratio data) |  |  |  |  |  |  |  |  |  |  |  |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. During the first quarter of 2019, the Company completed the sale of its Kysor Warren business. The results from operations for these businesses have been shown in the tables below as “Non-core business results”. |  |  |  |  |  |  |  |  |  |  |  |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |  |  |  |  |  |  |  |  |  |  |  |
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |
|  | Pre-Tax |  | Tax Impact (e) |  | After Tax |  |  | Pre-Tax |  | Tax Impact (e) |  | After Tax |  |  |  |  |  |
| Income from continuing operations, a GAAP measure | $ | 26.5 |  | $ | (14.0) |  | $ | 12.5 |  |  | $ | 83.0 |  | $ | (13.6) |  | $ | 69.4 |  |  |  |  |  |
| Restructuring charges | 0.5 |  | (0.1) |  | 0.4 |  |  | 0.5 |  | (0.1) |  | 0.4 |  |  |  |  |  |
| Special legal contingency charges (a) | — |  | — |  | — |  |  | 0.2 |  | — |  | 0.2 |  |  |  |  |  |
| Asbestos-related litigation (a) | (1.7) |  | 0.4 |  | (1.3) |  |  | 1.4 |  | (0.3) |  | 1.1 |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | 0.6 |  | (0.2) |  | 0.4 |  |  | (0.4) |  | 0.1 |  | (0.3) |  |  |  |  |  |
| Environmental liabilities (a) | 0.2 |  | (0.1) |  | 0.1 |  |  | — |  | — |  | — |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) | — |  | 0.1 |  | 0.1 |  |  | — |  | (4.4) |  | (4.4) |  |  |  |  |  |
| Other tax items, net (c) | — |  | 8.2 |  | 8.2 |  |  | — |  | — |  | — |  |  |  |  |  |
| Loss on sale of business | — |  | — |  | — |  |  | 8.5 |  | (3.5) |  | 5.0 |  |  |  |  |  |
| Loss (gain) from natural disaster, net of insurance recoveries (g) | 1.6 |  | (0.3) |  | 1.3 |  |  | (6.9) |  | 1.7 |  | (5.2) |  |  |  |  |  |
| Other items, net (a) | — |  | — |  | — |  |  | 0.1 |  | (0.1) |  | — |  |  |  |  |  |
| Non-core business results (f) | — |  | — |  | — |  |  | 1.3 |  | (0.3) |  | 1.0 |  |  |  |  |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 27.7 |  | $ | (6.0) |  | $ | 21.7 |  |  | $ | 87.7 |  | $ | (20.5) |  | $ | 67.2 |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 0.32 |  |  |  |  |  |  | $ | 1.73 |  |  |  |  |  |
| Restructuring charges |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.01 |  |  |  |  |  |
| Special legal contingency charges (a) |  |  |  |  | — |  |  |  |  |  |  | 0.01 |  |  |  |  |  |
| Asbestos-related litigation (a) |  |  |  |  | (0.03) |  |  |  |  |  |  | 0.03 |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  | 0.01 |  |  |  |  |  |  | (0.01) |  |  |  |  |  |
| Environmental liabilities (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | — |  |  |  |  |  |  | (0.11) |  |  |  |  |  |
| Other tax items, net (c) |  |  |  |  | 0.21 |  |  |  |  |  |  | — |  |  |  |  |  |
| Loss on sale of business |  |  |  |  | — |  |  |  |  |  |  | 0.13 |  |  |  |  |  |
| Loss (gain) from natural disaster, net of insurance recoveries (g) |  |  |  |  | 0.04 |  |  |  |  |  |  | (0.13) |  |  |  |  |  |
| Other items, net (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |  |  |  |  |
| Non-core business results (f) |  |  |  |  | — |  |  |  |  |  |  | 0.02 |  |  |  |  |  |
| Change in share counts from share-based compensation (d) |  |  |  |  | — |  |  |  |  |  |  | — |  |  |  |  |  |

[0001069202-20-000013:8k_2_02:78]
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 0.56 |  |  |  |  | $ | 1.68 |  |  |  |  |  |
| (a) Recorded in (Gains) losses and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount.. |  |  |  |  |  |  |  |  |  |  |  |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |  |  |  |  |  |  |  |  |  |  |  |
| (f) Non-core business results represents the Kysor Warren business, not included elsewhere in the reconciliation. |  |  |  |  |  |  |  |  |  |  |  |
| (g) Recorded in Loss (gain) from natural disaster, net of insurance recoveries in the Consolidated Statement of Operations. |  |  |  |  |  |  |  |  |  |  |  |

[0001069202-20-000013:8k_2_02:79]
|  | For the Three Months Ended December 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Components of (Gains) losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) | $ | 0.1 |  |  | $ | 0.1 |  |  |  |  |  |
| Foreign currency exchange gains (a) | (0.5) |  |  | (0.5) |  |  |  |  |  |
| Loss on disposal of fixed assets (a) | 0.1 |  |  | 0.2 |  |  |  |  |  |
| Other operating losses (a) | 0.2 |  |  | — |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) | 0.6 |  |  | (0.4) |  |  |  |  |  |
| Special legal contingency charges (b) | — |  |  | 0.2 |  |  |  |  |  |
| Asbestos-related litigation (b) | (1.7) |  |  | 1.4 |  |  |  |  |  |
| Environmental liabilities (b) | 0.2 |  |  | — |  |  |  |  |  |
| Other items, net (b) | — |  |  | 0.1 |  |  |  |  |  |
| (Gains) Losses and other expenses, net (pre-tax) | $ | (1.0) |  |  | $ | 1.1 |  |  |  |  |  |

[0001069202-20-000013:8k_2_02:80]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |  |  |  |  |  |  |  |  |  |  |  |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |  |  |  |  |  |  |  |  |  |  |  |

[0001069202-20-000013:8k_2_02:81]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |  |  |  |  |  |  |  |
|  |  |  |  |  | For the Year Ended December 31, 2020ESTIMATED |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $7.07 - $8.07 |  |  |
| Other non-core EBIT charges and other non-core tax items, net, incurred in 1Q 2020, and 2Q 2020 announced personnel and exit charges related to cost savings actions |  |  |  |  | (0.43) |  |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  |  |  |  | $7.50 - $8.50 |  |  |

[0001069202-20-000013:8k_2_02:82]
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |  |  |  |  |  |  |  |
|  |  |  |  |  | For the Three Months Ended March 31, |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| Average shares outstanding - diluted, a GAAP measure |  |  |  |  | 38.7 |  | $ | 40.1 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  |  |  |  |  | — |  |  | — |  |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure |  |  |  |  |  | 38.7 |  | 40.1 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended March 31, |  |  |  | For the Three Months Ended March 31, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales, a GAAP measure | $ | 103.3 |  |  | $ | 151.4 |  |  | $ | 723.8 |  |  | $ | 790.3 |  |
| Net sales from non-core businesses (a) | — |  |  | 34.3 |  |  | — |  |  | 34.3 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 103.3 |  |  | $ | 117.1 |  |  | $ | 723.8 |  |  | $ | 756.0 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended March 31, |  |  |  | For the Three Months Ended March 31, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit, a GAAP measure | $ | 27.5 |  |  | $ | 42.5 |  |  | $ | 165.7 |  |  | $ | 201.6 |  |
| Gross profit from non-core businesses (a) | — |  |  | 3.6 |  |  | — |  |  | 3.6 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 27.5 |  |  | $ | 38.9 |  |  | $ | 165.7 |  |  | $ | 198.0 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended March 31, |  |  |  | For the Three Months Ended March 31, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment profit, a Non-GAAP measure | $ | 0.7 |  |  | $ | 8.4 |  |  | $ | 37.6 |  |  | $ | 98.1 |  |
| (Loss) profit from non-core businesses (a) | — |  |  | (1.0) |  |  | — |  |  | (1.0) |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 0.7 |  |  | $ | 9.4 |  |  | $ | 37.6 |  |  | $ | 99.1 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |

[0001069202-20-000013:8k_2_02:83]
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended March 31, |  |  |  | For the Three Months Ended March 31, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Selling, general and administrative expenses, a GAAP measure | $ | 28.2 |  |  | $ | 36.4 |  |  | $ | 131.1 |  |  | $ | 145.8 |  |
| Selling, general and administrative expenses from non-core businesses (a) | — |  |  | 4.8 |  |  | — |  |  | 4.8 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 28.2 |  |  | $ | 31.6 |  |  | $ | 131.1 |  |  | $ | 141.0 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  |  |  |  |  | For the Three Months Ended March 31, |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| Net cash provided by operating activities, a GAAP measure |  |  |  |  |  |  | $ | (98.8) |  |  | $ | (141.0) |  |
| Purchases of property, plant and equipment |  |  |  |  |  |  | (24.7) |  |  | (37.2) |  |
| Proceeds from the disposal of property, plant and equipment |  |  |  |  |  |  | 0.1 |  |  | 0.3 |  |
| Insurance recoveries received for property damage incurred from natural disaster |  |  |  |  |  |  | — |  |  | 6.9 |  |
| Free cash flow, a Non-GAAP measure |  |  |  |  |  |  | (123.4) |  |  | (171.0) |  |

[0001069202-20-000013:8k_2_02:84]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to March 31, 2020 |
| Adjusted EBIT (a) |  |  |  |  |  |  | $ | 548.5 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  | 70.9 |  |
| EBITDA (a + b) |  |  |  |  |  |  | $ | 619.4 |  |
| Total debt at March 31, 2020 (c) |  |  |  |  |  |  | $ | 1,442.2 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  | 2.3 |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | Trailing Twelve Months to March 31, 2020 |
| Income from continuing operations before income taxes, a GAAP measure |  |  |  |  |  |  | $ | 451.4 |  |
| Items in (Gains) losses and other expenses, net that are excluded from segment profit |  |  |  |  |  |  | 9.1 |  |
| Special product quality adjustments |  |  |  |  |  |  | (0.6) |  |
| Restructuring charges |  |  |  |  |  |  | 10.3 |  |
| Interest expense, net |  |  |  |  |  |  | 45.4 |  |
| Pension settlements |  |  |  |  |  |  | 99.2 |  |
| Loss on sale of business |  |  |  |  |  |  | 2.1 |  |
| Insurance recoveries received for property damage incurred from natural disaster |  |  |  |  |  |  | (71.1) |  |
| Other expense (income), net |  |  |  |  |  |  | 2.7 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  |  |  |  |  | $ | 548.5 |  |
