# LII MD&A — 0001069202-20-000015


## mdna

[0001069202-20-000015:mdna:1]
[same as prior period, unchanged from 0001069202-19-000036:mdna:1]

[0001069202-20-000015:mdna:2]
[same as prior period, unchanged from 0001069202-19-000036:mdna:2]

[0001069202-20-000015:mdna:3]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For  additional information regarding our reportable segments, see Note 2 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000015:mdna:4]
[same as prior period, unchanged from 0001069202-19-000036:mdna:4]

[0001069202-20-000015:mdna:5]
[same as prior period, unchanged from 0001069202-19-000036:mdna:5]

[0001069202-20-000015:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated warranty costs, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components, including the impact of imposed tariffs on the import of certain of our raw materials and components, has impacted us and the HVACR industry in general.  We seek to mitigate the impact of volatility in commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-20-000015:mdna:7]
Impact of COVID-19 Pandemic and the Resulting Changes to our 2020 Financial Outlook

[0001069202-20-000015:mdna:8]
A novel strain of coronavirus (“COVID-19”) surfaced in late 2019 and has spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic has disrupted our business operations and caused a significant unfavorable impact on our results of operations.

[0001069202-20-000015:mdna:9]
In response to the COVID-19 pandemic various national, state, and local governments where we, our suppliers, and our customers operate have issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work.  Those decrees have resulted in supply chain disruption and higher employee absenteeism in our

[0001069202-20-000015:mdna:10]
factories.  Additionally, certain of our manufacturing facilities have experienced a short-term suspension of operations for COVID-19 employee health concerns.

[0001069202-20-000015:mdna:11]
During the first quarter of 2020, we incurred charges of approximately $2 million primarily related to inefficiencies at our factories caused by the COVID-19 pandemic. Additionally, due to the adverse impact of the COVID-19 pandemic on our European manufacturing facilities and the resulting downturn in the related business, we recorded an $8 million valuation allowance on certain foreign deferred tax assets as we concluded that it was no longer more likely than not that these foreign tax loss carryforwards would be realized.

[0001069202-20-000015:mdna:12]
We anticipate potential supply chain disruptions, employee absenteeism and short-term suspensions of manufacturing facilities related to the COVID-19 pandemic that could unfavorably impact our business.  We also anticipate significant challenges in the remainder of 2020 due to uncertain market conditions.  Accordingly, we have revised our financial outlook downward in 2020.

[0001069202-20-000015:mdna:13]
Currently, our view is that the North America unitary HVAC and refrigeration market will be negatively impacted about 20% this year by the pandemic.  Therefore, we have reset our financial expectations for the year based on that level of market impact and now expect revenue to be down 11%-17% from last year versus our previous guidance for growth of 4%-8%.  We expect Diluted EPS from continuing operations in the range of $7.07 to $8.07 for the year.  In April 2020, we implemented cost reduction actions to realize $115 million of SG&A savings for the balance of the year.  In connection with these cost saving actions, we expect to incur pre-tax charges of approximately $10 million in the second quarter of 2020 related to personnel severance and benefits and facility exit costs.

[0001069202-20-000015:mdna:14]
We expect our cash generation to remain strong for 2020 as our working capital requirements decline and are projecting approximately $460 million in cash flows from operations for the year. We have reduced our capital expenditure plans for 2020 from $153 million to $120 million. We are rated investment grade by both S&P and Moody’s, and we expect to remain well within our debt covenants. Our bank revolver and asset securitization line do not have to go through renewal again until the latter half of 2021, and our senior notes do not mature until November 2023.  Our quarterly dividend plans are unchanged, most recently $0.77 per share, or more than $115 million in total payments for the year.  We repurchased $100 million of stock in the first quarter of the $400 million we had planned to repurchase for the year. However, we placed repurchase plans for the second quarter on hold and we will review plans for the third and fourth quarters as the year progresses.

[0001069202-20-000015:mdna:15]
[same as prior period, unchanged from 0001069202-19-000036:mdna:12]

[0001069202-20-000015:mdna:16]
Results for the first quarter of 2020 were driven by year over year sales and profit declines in our Residential Heating & Cooling and Refrigeration segments.  The Residential Heating & Cooling segment saw a 5% decrease in net sales primarily on lower volumes and unfavorable mix.  Their segment profit was down $54 million, including a $40 million decline related to  non-recurring insurance recoveries in 2019 for lost profits from the Marshalltown tornado.  The Commercial Heating & Cooling segment had a 3% increase in net sales and a $4 million increase in segment profit driven primarily by favorable mix and sourcing and engingeering-led cost reductions. The Refrigeration segment had a 32% decline in net sales and a $6 million decline in segment profit  primarily due to the sale of our Kysor Warren business in 2019 and lower volumes.

[0001069202-20-000015:mdna:17]
[same as prior period, unchanged from 0001069202-19-000036:mdna:14]

[0001069202-20-000015:mdna:18]
•Net sales decreased $67 million to $724 million in the first quarter of 2019 driven by declines in our Residential Heating & Cooling and Refrigeration segments.  Approximately half of the decline related to the sale of our Kysor Warren business in 2019.

[0001069202-20-000015:mdna:19]
•Operating income in the first quarter of 2020 decreased $58 million to $36 million primarily due to lower volumes, unfavorable mix, and non-recurring insurance recoveries in 2019 for lost profits related to the Marshalltown tornado.

[0001069202-20-000015:mdna:20]
•Net income for the first quarter of 2020 decreased $56 million to $13 million.

[0001069202-20-000015:mdna:21]
•Diluted earnings per share from continuing operations were $0.32 per share in the first quarter of 2020 compared to $1.73 per share in the first quarter of 2019.

[0001069202-20-000015:mdna:22]
•For the three months ended March 31, 2020, we returned $30 million to shareholders through dividend payments and repurchased $100 million of common stock through our share repurchase program.

[0001069202-20-000015:mdna:23]
First Quarter of 2020 Compared to First Quarter of 2019 - Consolidated Results

[0001069202-20-000015:mdna:24]
[same as prior period, unchanged from 0001069202-19-000036:mdna:21]

[0001069202-20-000015:mdna:25]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |  |  |
|  | Dollars (in millions) |  |  |  | PercentChangeFav/(Unfav) |  | Percent of Sales |  |  |
|  | 2020 |  | 2019 |  |  |  | 2020 |  | 2019 |
| Net sales | $ | 723.8 |  |  | $ | 790.3 |  |  | (8.4) | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 558.1 |  |  | 588.7 |  |  | 5.2 |  |  | 77.1 |  |  | 74.5 |  |
| Gross profit | 165.7 |  |  | 201.6 |  |  | (17.8) |  |  | 22.9 |  |  | 25.5 |  |
| Selling, general and administrative expenses | 131.1 |  |  | 145.8 |  |  | 10.1 |  |  | 18.1 |  |  | 18.4 |  |
| (Gains) losses and other expenses, net | (1.0) |  |  | 1.1 |  |  | 190.9 |  |  | (0.1) |  |  | 0.1 |  |
| Restructuring charges | 0.5 |  |  | 0.5 |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Loss on sale of business | — |  |  | 8.5 |  |  | 100.0 |  |  | — |  |  | 1.1 |  |
| Insurance proceeds for lost profits | — |  |  | (39.5) |  |  | 100.0 |  |  | — |  |  | (5.0) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.6 |  |  | (6.9) |  |  | 123.2 |  |  | 0.2 |  |  | (0.9) |  |
| Income from equity method investments | (2.9) |  |  | (2.6) |  |  | 11.5 |  |  | (0.4) |  |  | (0.3) |  |
| Operating income | $ | 36.4 |  |  | $ | 94.7 |  |  | (61.6) | % |  | 5.0 | % |  | 12.0 | % |

[0001069202-20-000015:mdna:26]
[same as prior period, unchanged from 0001069202-19-000036:mdna:23]

[0001069202-20-000015:mdna:27]
Net sales declined 8% in the first quarter of 2020 compared to the first quarter of 2019, driven by a 4% decline related to the divestiture of our Kysor Warren business in 2019 and a 5% decline in volume, partially offset by a 1% increase in higher combined price and mix.

[0001069202-20-000015:mdna:28]
[same as prior period, unchanged from 0001069202-19-000036:mdna:25]

[0001069202-20-000015:mdna:29]
Gross profit margin in the first quarter of 2020 decreased 260 basis points ("bps") to 22.9% compared to 25.5% in the first quarter of 2019.  We saw margin decreases of 160 bps from lower volumes, 140 bps from factory inefficiencies, and 150 bps from higher other product costs. Partially offsetting these decreases were margin increases of 90 bps from lower commodity costs, 80 bps from lower tariffs and sourcing and engineering-led cost reductions, and 20 bps from the divestiture of the Kysor Warren business which had lower margins.

[0001069202-20-000015:mdna:30]
[same as prior period, unchanged from 0001069202-19-000036:mdna:27]

[0001069202-20-000015:mdna:31]
Selling, general and administrative expenses ("SG&A") declined $15 million to $131 million in the first quarter of 2020 compared to $146 million in the first quarter of 2019.  As a percentage of net sales, SG&A decreased 30 bps to 18.1% primarily due to a decline in SG&A from our divested Kysor Warren business and lower incentive compensation costs.

[0001069202-20-000015:mdna:32]
(Gains) Losses and Other Expenses, Net

[0001069202-20-000015:mdna:33]
(Gains) losses and other expenses, net for the first quarter of 2020 and 2019 included the following (in millions):

[0001069202-20-000015:mdna:34]
|  | For the Three Months Ended March 31, |  |  |
|  | 2020 |  |  | 2019 |  |
| Realized losses on settled future contracts | $ | 0.1 |  |  | $ | 0.1 |  |
| Foreign currency exchange gains | (0.5) |  |  | (0.5) |  |
| Loss on disposal of fixed assets | 0.1 |  |  | 0.2 |  |
| Other operating losses | 0.2 |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.6 |  |  | (0.4) |  |
| Special legal contingency charges | — |  |  | 0.2 |  |
| Asbestos-related litigation | (1.7) |  |  | 1.4 |  |
| Environmental liabilities | 0.2 |  |  | — |  |
| Other items, net | — |  |  | 0.1 |  |
| (Gains) losses and other expenses, net (pre-tax) | $ | (1.0) |  |  | $ | 1.1 |  |

[0001069202-20-000015:mdna:35]
The net change in unrealized losses (gains) on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 9 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.

[0001069202-20-000015:mdna:36]
[same as prior period, unchanged from 0001069202-19-000036:mdna:33]

[0001069202-20-000015:mdna:37]
Restructuring charges were approximately $1 million in the first quarter of 2020 and related to activities initiated in 2019 in our Commercial Heating & Cooling and Residential Heating & Cooling segments.  For additional information on our restructuring activities, refer to Note 7 in the Notes to the Consolidated Financial Statements. For additional information on restructuring activities planned in future periods of 2020, refer to Note 15 of the Notes to the Consolidated Financial Statements.

[0001069202-20-000015:mdna:38]
Loss on Sale of Business

[0001069202-20-000015:mdna:39]
We recognized a loss of $8.5 million in the first quarter of 2019 related to the sale of our Kysor Warren business.  There were no gains or losses related to this divestiture in the first quarter of 2020.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-20-000015:mdna:40]
Gains and Losses related to Marshalltown Tornado

[0001069202-20-000015:mdna:41]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covered the repair or replacement of our assets that suffered damage or loss and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Loss (gain) from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations. Our insurance policies also provided business interruption coverage, including lost profits, related to the losses suffered.  These insurance recoveries are shown in Insurance proceeds for lost profits in the Consolidated Statements of Operations.

[0001069202-20-000015:mdna:42]
In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019.

[0001069202-20-000015:mdna:43]
For the three months ended March 31, 2020, we incurred expenses of $2 million related to damages caused by the tornado, which included site clean up, waste disposal and other restoration costs.  See Note 4 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-20-000015:mdna:44]
[same as prior period, unchanged from 0001069202-19-000036:mdna:37]

[0001069202-20-000015:mdna:45]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $3 million in the first quarter of 2020 was comparable to the first quarter of 2019.

[0001069202-20-000015:mdna:46]
[same as prior period, unchanged from 0001069202-19-000036:mdna:39]

[0001069202-20-000015:mdna:47]
Interest expense, net of $9 million in the first quarter of 2020 was down $2 million from $11 million in the first quarter of 2019 primarily due to lower borrowing costs.

[0001069202-20-000015:mdna:48]
[same as prior period, unchanged from 0001069202-19-000036:mdna:41]

[0001069202-20-000015:mdna:49]
Our effective tax rate was 52.8% for the first quarter of 2020 compared to 16.4% for the first quarter of 2019.  The rate increased primarily due to lower excess tax benefits and the recording of an $8 million valuation allowance on certain foreign deferred tax assets.  We concluded that it was no longer more likely than not that these foreign tax loss carryforwards would be realized due to the adverse impact of the COVID-19 pandemic on our European manufacturing facilities and the resulting downturn in the related business.

[0001069202-20-000015:mdna:50]
We expect our annual effective tax rate to be between 21% and 22%, excluding the impacts of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09 and excluding the $8 million valuation allowance.

[0001069202-20-000015:mdna:51]
First Quarter of 2020 Compared to First Quarter of 2019 - Results by Segment

[0001069202-20-000015:mdna:52]
[same as prior period, unchanged from 0001069202-19-000036:mdna:44]

[0001069202-20-000015:mdna:53]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000015:mdna:54]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  |  | 2019 |  |  | Difference |  | % Change |
| Net sales | $ | 442.1 |  |  | $ | 465.6 |  |  | $ | (23.5) |  |  | (5.0) | % |
| Profit | $ | 32.5 |  |  | $ | 86.7 |  |  | $ | (54.2) |  |  | (62.5) | % |
| % of net sales | 7.4 | % |  | 18.6 | % |  |  |  |  |

[0001069202-20-000015:mdna:55]
Net sales decreased 5% in the first quarter of 2020 compared to the first quarter of 2019.  Sales volumes declined 5% and mix was 1% lower, partially offset by 1% higher price.

[0001069202-20-000015:mdna:56]
Segment profit in the first quarter of 2020 declined $54 million compared to the first quarter of 2019 due to $40 million of non-recurring insurance proceeds for lost profits in 2019 related to the Marshalltown tornado, $14 million of unfavorable mix, $9 million of higher other product costs, $8 million of factory inefficiencies, and $8 million from lower sales volume.  Partially offsetting these declines was $6 million of higher price, $6 million of lower SG&A expense, $6 million of sourcing and engineering-led cost reductions, $5 million of lower commodities, $1 million of lower tariffs on certain Chinese imports, and $1 million of favorable foreign exchange rates.

[0001069202-20-000015:mdna:57]
[same as prior period, unchanged from 0001069202-19-000036:mdna:49]

[0001069202-20-000015:mdna:58]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000015:mdna:59]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  |  | 2019 |  |  | Difference |  | % Change |
| Net sales | $ | 178.4 |  |  | $ | 173.3 |  |  | $ | 5.1 |  |  | 2.9 | % |
| Profit | $ | 18.7 |  |  | $ | 15.1 |  |  | $ | 3.6 |  |  | 23.8 | % |
| % of net sales | 10.5 | % |  | 8.7 | % |  |  |  |  |

[0001069202-20-000015:mdna:60]
Net sales increased 3% in the first quarter of 2020 compared to the first quarter of 2019.  Sales mix was favorable 4%, partially offset by 1% lower volumes.

[0001069202-20-000015:mdna:61]
Segment profit in the first quarter of 2020 increased $4 million compared to the first quarter of 2019 due to $2 million of favorable mix, $2 million of sourcing and engineering-led cost reductions,  $1 million of lower commodities, and $1 million of lower SG&A expense. Partially offsetting these increases was $1 million of lower sales volume and $1 million of higher warranty costs.

[0001069202-20-000015:mdna:62]
[same as prior period, unchanged from 0001069202-19-000036:mdna:54]

[0001069202-20-000015:mdna:63]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000015:mdna:64]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  |  | 2019 |  |  | Difference |  | % Change |
| Net sales | $ | 103.3 |  |  | $ | 151.4 |  |  | $ | (48.1) |  |  | (31.8) | % |
| Profit | $ | 0.7 |  |  | $ | 8.4 |  |  | $ | (7.7) |  |  | (91.7) | % |
| % of net sales | 0.7 | % |  | 5.5 | % |  |  |  |  |

[0001069202-20-000015:mdna:65]
Net sales decreased 32% in the first quarter of 2020 compared to the first quarter of 2019.  The loss of sales from our divested Kysor Warren business contributed 23%, sales volume was lower by 9%, and foreign currency exchange rates were unfavorable by 1%, partially offset by higher combined price and mix of 1%.

[0001069202-20-000015:mdna:66]
Segment profit in the first quarter of 2020 decreased $8 million compared to the first quarter of 2019 due to $4 million of lower volumes, $5 million of factory inefficiencies, $3 million of higher other product costs, and $2 million of lower sales of refrigerant allocations in Europe. Partially offsetting these decreases was $2 million of lower commodities, $2 million of lower SG&A, $1 million of sourcing and engineering-led cost reductions, and $1 million of higher profit due to the divestiture of the Kysor Warren business.

[0001069202-20-000015:mdna:67]
[same as prior period, unchanged from 0001069202-19-000036:mdna:59]

[0001069202-20-000015:mdna:68]
Corporate and other expenses increased $2 million in the first quarter of 2020 compared to the first quarter of 2019 primarily due to $2 million of higher information technology investments, and $1 million of unfavorable foreign currency exchange rates, partially offset by $1 million of lower discretionary expenditures.

[0001069202-20-000015:mdna:69]
[same as prior period, unchanged from 0001069202-19-000036:mdna:103]

[0001069202-20-000015:mdna:70]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement. Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-20-000015:mdna:71]
[same as prior period, unchanged from 0001069202-19-000036:mdna:105]

[0001069202-20-000015:mdna:72]
The following table summarizes our cash flow activity for the three months ended March 31, 2020 and 2019 (in millions):

[0001069202-20-000015:mdna:73]
|  | For the Three Months Ended March 31, |  |  |  |
|  | 2020 |  |  | 2019 |  |
| Net cash used in operating activities | $ | (98.8) |  |  | $ | (141.0) |  |
| Net cash (used in) provided by investing activities | (25.7) |  |  | 13.6 |  |
| Net cash provided by financing activities | 133.0 |  |  | 108.9 |  |

[0001069202-20-000015:mdna:74]
Net Cash Provided by Operating Activities - The net cash used in operating activities in the three months ended March 31,  2020 and 2019 reflects the seasonal increase in working capital requirements. The decrease in cash used in operating activities in the first quarter of 2020 compared to the same period in 2019 was primarily due to the timing of working capital payments.

[0001069202-20-000015:mdna:75]
Net Cash (Used in) Provided by Investing Activities - Capital expenditures were $25 million in the three months ended March, 2020 compared to $37 million in the same period of 2019.  Capital expenditures in 2020 were primarily related to the an expansion of manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.

[0001069202-20-000015:mdna:76]
Net Cash Provided by Financing Activities - Net cash provided by financing activities in the three months ended March 31, 2020 was $133 million compared to $109 million in the same period of 2019.  This increase is primarily due to higher net borrowings on our revolving credit facility.  We also repurchased $100 million of shares for the three months ended March 31, 2020 and returned $30 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000015:mdna:77]
[same as prior period, unchanged from 0001069202-19-000036:mdna:111]

[0001069202-20-000015:mdna:78]
The following table details our lines of credit and financing arrangements as of March 31, 2020 (in millions):

[0001069202-20-000015:mdna:79]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (2) | $ | 215.0 |  |
| Finance lease obligations | 8.2 |  |
| Domestic credit facility(1) | 30.0 |  |
| Debt issuance costs | (0.9) |  |
| Total current maturities of long-term debt | $ | 252.3 |  |
| Long-term debt: |  |
| Finance lease obligations | 26.2 |  |
| Domestic credit facility (1) | 815.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (1.8) |  |
| Total long-term debt | 1,189.9 |  |
| Total debt | $ | 1,442.2 |  |

[0001069202-20-000015:mdna:80]
(1) The available future borrowings on our domestic credit facility are $312.1 million after being reduced by the outstanding borrowings and $2.4 million in outstanding standby letters of credit.  We also had $29.6 million in outstanding standby letters of credit outside of the domestic credit facility as of March 31, 2020.

[0001069202-20-000015:mdna:81]
(2) The maximum securitization amount ranges from $250.0 million to $400.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information.

[0001069202-20-000015:mdna:82]
[same as prior period, unchanged from 0001069202-19-000036:mdna:116]

[0001069202-20-000015:mdna:83]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 128.3% at March 31, 2020 from 117.0% at December 31, 2019.

[0001069202-20-000015:mdna:84]
As of March 31, 2020, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-20-000015:mdna:85]
[same as prior period, unchanged from 0001069202-19-000036:mdna:119]

[0001069202-20-000015:mdna:86]
We believe our cash and cash equivalents of $39 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $39 million as of March 31, 2020 was $20 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-20-000015:mdna:87]
[same as prior period, unchanged from 0001069202-19-000036:mdna:123]

[0001069202-20-000015:mdna:88]
[same as prior period, unchanged from 0001069202-19-000036:mdna:124]

[0001069202-20-000015:mdna:89]
Commitments, Contingencies and Guarantees

[0001069202-20-000015:mdna:90]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000015:mdna:91]
[same as prior period, unchanged from 0001069202-19-000036:mdna:127]

[0001069202-20-000015:mdna:92]
[same as prior period, unchanged from 0001069202-19-000036:mdna:128]
