# LII MD&A — 0001069202-16-000024


## mdna

[0001069202-16-000024:mdna:1]
[same as prior period, unchanged from 0001069202-16-000020:mdna:1]

[0001069202-16-000024:mdna:2]
[same as prior period, unchanged from 0001069202-16-000020:mdna:2]

[0001069202-16-000024:mdna:3]
[same as prior period, unchanged from 0001069202-16-000020:mdna:3]

[0001069202-16-000024:mdna:4]
Our fiscal year ends on December 31 and our interim fiscal quarters are each comprised of approximately 13 weeks.  For convenience, throughout this Management’s Discussion and Analysis of Financial Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.

[0001069202-16-000024:mdna:5]
[same as prior period, unchanged from 0001069202-16-000020:mdna:5]

[0001069202-16-000024:mdna:6]
[same as prior period, unchanged from 0001069202-16-000020:mdna:6]

[0001069202-16-000024:mdna:7]
[same as prior period, unchanged from 0001069202-16-000020:mdna:7]

[0001069202-16-000024:mdna:8]
In the third quarter of 2016, the Residential Heating & Cooling segment continued to lead our overall operational performance with a 11% increase in net sales and a $23 million increase in segment profit compared to the third quarter of 2015.  The primary growth drivers for this segment were volume gains and lower material cost.  Our Commercial Heating & Cooling segment also performed well in the third quarter of 2016 with a 2% increase in net sales and $4 million in increased segment profit compared to the third quarter of 2015.  This segment's profits were up largely due to lower material cost.  While sales in our Refrigeration segment were down 2%, the segment profit increased $3 million compared to the third quarter of 2015.  For this segment, lower sales volume was offset by lower material cost.

[0001069202-16-000024:mdna:9]
[same as prior period, unchanged from 0001069202-16-000020:mdna:10]

[0001069202-16-000024:mdna:10]
[same as prior period, unchanged from 0001069202-16-000020:mdna:11]

[0001069202-16-000024:mdna:11]
| • | Net sales increased $55 million, or 6%, to $1,010 million in the third quarter of 2016 compared to $955 million in the third quarter of 2015. |

[0001069202-16-000024:mdna:12]
| • | Operating income in the third quarter of 2016 increased $30 million to $157 million from $127 million in the third quarter of 2015. |

[0001069202-16-000024:mdna:13]
| • | Net income for the third quarter of 2016 increased $22 million to $102 million from $80 million in the third quarter of 2015. |

[0001069202-16-000024:mdna:14]
| • | Diluted earnings per share from continuing operations were $2.33 per share in the third quarter of 2016 compared to $1.76 per share in the third quarter of 2015. |

[0001069202-16-000024:mdna:15]
| • | During the third quarter of 2016, we returned $19 million to shareholders through dividend payments. |

[0001069202-16-000024:mdna:16]
| • | Cash provided by operating activities was flat at $107 million in the first nine months of 2016 and 2015, although we made a discretionary $50 million pension contribution into our U.S. qualified plan in the third quarter of 2016. |

[0001069202-16-000024:mdna:17]
Third Quarter of 2016 Compared to Third Quarter of 2015 - Consolidated Results

[0001069202-16-000024:mdna:18]
[same as prior period, unchanged from 0001069202-16-000020:mdna:19]

[0001069202-16-000024:mdna:19]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales | $ | 1,010.0 |  |  | $ | 955.0 |  |  | 5.8 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 699.7 |  |  | 681.6 |  |  | (2.7 | ) |  | 69.3 |  |  | 71.4 |  |
| Gross profit | 310.3 |  |  | 273.4 |  |  | 13.5 |  |  | 30.7 |  |  | 28.6 |  |
| Selling, general and administrative expenses | 156.5 |  |  | 143.8 |  |  | (8.8 | ) |  | 15.5 |  |  | 15.1 |  |
| Losses and other expenses, net | 0.7 |  |  | 6.0 |  |  | 88.3 |  |  | 0.1 |  |  | 0.6 |  |
| Restructuring charges | 0.6 |  |  | (0.4 | ) |  | (250.0 | ) |  | 0.1 |  |  | — |  |
| Income from equity method investments | (4.4 | ) |  | (3.0 | ) |  | 46.7 |  |  | (0.4 | ) |  | (0.3 | ) |
| Operating income | $ | 156.9 |  |  | $ | 127.0 |  |  | 23.5 | % |  | 15.5 | % |  | 13.3 | % |

[0001069202-16-000024:mdna:20]
[same as prior period, unchanged from 0001069202-16-000020:mdna:21]

[0001069202-16-000024:mdna:21]
Net sales increased 6% in the third quarter of 2016 compared to the third quarter of 2015, primarily from 5% higher sales volumes and 1% from price and mix.  The Residential Heating & Cooling segment delivered higher volume by capturing additional replacement and new construction business and the Commercial Heating & Cooling segment delivered higher volume from our North American Service business.

[0001069202-16-000024:mdna:22]
[same as prior period, unchanged from 0001069202-16-000020:mdna:23]

[0001069202-16-000024:mdna:23]
Gross profit margin in the third quarter of 2016 increased 210 basis points ("bps") to 30.7% compared to the third quarter of 2015.  Our profit margin increased 270 bps from lower material costs.  Offsetting this increase were decreases of 10 bps for unfavorable mix and price, 20 bps from combined freight and distribution, and 30 bps from other product costs.

[0001069202-16-000024:mdna:24]
[same as prior period, unchanged from 0001069202-16-000020:mdna:25]

[0001069202-16-000024:mdna:25]
Selling, general and administrative expenses, or SG&A, was $157 million in the third quarter of 2016 compared to $144 million in the third quarter of 2015, and as a percentage of net sales increased 40 bps to 15.5%.  SG&A expenses increased due to higher long-term incentive compensation costs, wage inflation, and increased investment in information technology and research and development.

[0001069202-16-000024:mdna:26]
[same as prior period, unchanged from 0001069202-16-000020:mdna:28]

[0001069202-16-000024:mdna:27]
Losses and other expenses, net for the third quarter of 2016 and 2015 included the following (in millions):

[0001069202-16-000024:mdna:28]
|  | For the Three Months Ended September 30, |
|  | 2016 |  | 2015 |
| Realized losses on settled future contracts | $ | 0.3 |  |  | $ | 0.6 |  |
| Foreign currency exchange losses | 0.5 |  |  | 1.4 |  |
| Loss on disposal of fixed assets | 0.2 |  |  | 0.1 |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (1.2 | ) |  | 0.8 |  |
| Special legal contingency charges | 0.5 |  |  | 1.3 |  |
| Asbestos-related litigation | 0.4 |  |  | 0.4 |  |
| Contractor tax payments | — |  |  | 0.8 |  |
| Environmental liabilities | — |  |  | 0.3 |  |
| Other items, net | — |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) | $ | 0.7 |  |  | $ | 6.0 |  |

[0001069202-16-000024:mdna:29]
The net change in unrealized (gains) losses on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements. The change in the special legal contingency charges resulted from higher estimated liabilities related to settled claims.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000024:mdna:30]
[same as prior period, unchanged from 0001069202-16-000020:mdna:32]

[0001069202-16-000024:mdna:31]
Restructuring charges during the third quarter of 2016 relate to the demolition of a facility relating to a previous restructuring activity.  The restructuring charges in the third quarter of 2015 relate to the restructuring of our Australian operations in the Refrigeration segment.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000024:mdna:32]
[same as prior period, unchanged from 0001069202-16-000020:mdna:34]

[0001069202-16-000024:mdna:33]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $4 million in the third quarter of 2016 increased from $3 million in the third quarter of 2015.

[0001069202-16-000024:mdna:34]
[same as prior period, unchanged from 0001069202-16-000020:mdna:36]

[0001069202-16-000024:mdna:35]
Interest expense, net of $7 million in the third quarter of 2016 was up from $6 million as compared to the third quarter of 2015.

[0001069202-16-000024:mdna:36]
[same as prior period, unchanged from 0001069202-16-000020:mdna:38]

[0001069202-16-000024:mdna:37]
We expect our annual effective tax rate to be 31% in 2016 and subsequent years to be approximately 32% due to sustainable benefits from reorganization of our international subsidiaries that will enable us to utilize foreign tax credits and other benefits that drives our effective tax rate down by approximately 250 basis points.  The tax benefit resulting from a repatriation of earnings in 2016 was recognized in the second quarter.

[0001069202-16-000024:mdna:38]
The effective tax rate was 32.2% for the third quarter of 2016 compared to 34.2% for the third quarter of 2015.

[0001069202-16-000024:mdna:39]
Third Quarter of 2016 Compared to Third Quarter of 2015 - Results by Segment

[0001069202-16-000024:mdna:40]
[same as prior period, unchanged from 0001069202-16-000020:mdna:42]

[0001069202-16-000024:mdna:41]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000024:mdna:42]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 572.7 |  |  | $ | 517.9 |  |  | $ | 54.8 |  |  | 10.6 | % |
| Profit | $ | 112.7 |  |  | $ | 90.1 |  |  | $ | 22.6 |  |  | 25.1 | % |
| % of net sales | 19.7 | % |  | 17.4 | % |  |  |  |  |

[0001069202-16-000024:mdna:43]
Net sales increased by 11% in the third quarter of 2016 compared to the third quarter of 2015.  Sales volumes increased by 10% and price and mix combined increased sales by 1%.

[0001069202-16-000024:mdna:44]
Segment profit for the third quarter of 2016 increased $23 million due to $13 million in higher sales volumes, $13 million in lower material cost and $4 million from factory productivity, which includes the addition of a second factory in Mexico, and $1 million from price and mix combined.  Partially offsetting these increases was $1 million of SG&A expenses primarily for information technology and research and development investments, $4 million in distribution investments, and $3 million from increases in other product costs.

[0001069202-16-000024:mdna:45]
[same as prior period, unchanged from 0001069202-16-000020:mdna:47]

[0001069202-16-000024:mdna:46]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000024:mdna:47]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 251.4 |  |  | $ | 246.8 |  |  | $ | 4.6 |  |  | 1.9 | % |
| Profit | $ | 48.9 |  |  | $ | 44.8 |  |  | $ | 4.1 |  |  | 9.2 | % |
| % of net sales | 19.5 | % |  | 18.2 | % |  |  |  |  |

[0001069202-16-000024:mdna:48]
Net sales increased by 2% in the third quarter of 2016 compared to the third quarter of 2015.  Sales volumes increased by 2%  primarily the result of growth in our North American Service and VRF businesses.

[0001069202-16-000024:mdna:49]
Segment profit in the third quarter of 2016 increased $4 million compared to the third quarter of 2015 due to $6 million in lower material cost, $1 million from higher sales volumes, and $1 million in lower freight expenses.  Partially offsetting these increases was $2 million in SG&A expenses, $1 million in lower factory productivity, and $1 million in other product costs.

[0001069202-16-000024:mdna:50]
[same as prior period, unchanged from 0001069202-16-000020:mdna:52]

[0001069202-16-000024:mdna:51]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000024:mdna:52]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 185.9 |  |  | $ | 190.3 |  |  | $ | (4.4 | ) |  | (2.3 | )% |
| Profit | $ | 22.9 |  |  | $ | 20.3 |  |  | $ | 2.6 |  |  | 12.8 | % |
| % of net sales | 12.3 | % |  | 10.7 | % |  |  |  |  |

[0001069202-16-000024:mdna:53]
Net sales decreased 2% in the third quarter of 2016 compared to the third quarter of 2015.  Sales volume decreased by 1%  and price and mix combined decreased sales by 1%.

[0001069202-16-000024:mdna:54]
Segment profit for the third quarter of 2016 increased $3 million compared to the third quarter of 2015 due to $7 million from lower material costs and $2 million from lower depreciation and amortization due to the impairment of our Kysor Warren business recorded in the fourth quarter of 2015. Partially offsetting these increases was $4 million in higher SG&A expenses, $1 million from combined price and mix and $1 million in lower sales volumes.

[0001069202-16-000024:mdna:55]
[same as prior period, unchanged from 0001069202-16-000020:mdna:58]

[0001069202-16-000024:mdna:56]
Corporate and other expenses increased $4 million in the third quarter of 2016 compared to the third quarter of 2015 primarily due to $5 million of higher incentive compensation and general wage inflation and $2 million in investments in research and development and consulting.  Partially offsetting these increases was $3 million in lower health care expenses.

[0001069202-16-000024:mdna:57]
Year-to-Date through September 30, 2016 Compared to Year-to-Date through September 30, 2015 - Consolidated Results

[0001069202-16-000024:mdna:58]
[same as prior period, unchanged from 0001069202-16-000020:mdna:61]

[0001069202-16-000024:mdna:59]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales | $ | 2,744.4 |  |  | $ | 2,633.3 |  |  | 4.2 |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,935.5 |  |  | 1,913.5 |  |  | (1.1 | ) |  | 70.5 |  |  | 72.7 |  |
| Gross profit | 808.9 |  |  | 719.8 |  |  | 12.4 |  |  | 29.5 |  |  | 27.3 |  |
| Selling, general and administrative expenses | 456.2 |  |  | 430.0 |  |  | (6.1 | ) |  | 16.6 |  |  | 16.3 |  |
| Losses and other expenses, net | 5.5 |  |  | 14.9 |  |  | 63.1 |  |  | 0.2 |  |  | 0.6 |  |
| Restructuring charges | 1.2 |  |  | 1.8 |  |  | 33.3 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (15.3 | ) |  | (11.8 | ) |  | 29.7 |  |  | (0.6 | ) |  | (0.4 | ) |
| Operating income | $ | 361.3 |  |  | $ | 284.9 |  |  | 26.8 |  |  | 13.2 | % |  | 10.8 | % |

[0001069202-16-000024:mdna:60]
[same as prior period, unchanged from 0001069202-16-000020:mdna:63]

[0001069202-16-000024:mdna:61]
Net sales increased 4% in the first nine months of 2016 compared to the first nine months of 2015, with sales volumes up 4% and a 1% increase from price and mix combined.  The volume increases were driven by our Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments all capturing additional replacement and new construction business.  Partially offsetting these increases was a 1% decrease from unfavorable foreign currency exchange rates.

[0001069202-16-000024:mdna:62]
[same as prior period, unchanged from 0001069202-16-000020:mdna:65]

[0001069202-16-000024:mdna:63]
Gross profit margins in the first nine months of 2016 increased 220 bps to 29.5% compared to the first nine months of 2015.  Our profit margin increased 290 bps from material cost savings and 30 bps from factory productivity.   Offsetting these  increases were decreases of 40 bps for unfavorable mix and price, 20 bps from unfavorable foreign currency exchange rates, 10 bps from freight and distribution, and 30 bps from other product costs.

[0001069202-16-000024:mdna:64]
[same as prior period, unchanged from 0001069202-16-000020:mdna:67]

[0001069202-16-000024:mdna:65]
SG&A was $456 million for the first nine months of 2016 compared to $430 million for the first nine months of 2015, and as a percentage of net sales, increased 30 bps to 16.6% from 16.3%.  SG&A expenses increased due to higher long-term incentive compensation costs, wage inflation, and increased investment in information technology and research and development.

[0001069202-16-000024:mdna:66]
[same as prior period, unchanged from 0001069202-16-000020:mdna:69]

[0001069202-16-000024:mdna:67]
Losses and other expenses, net for the first nine months of 2016 and 2015 included the following (in millions):

[0001069202-16-000024:mdna:68]
|  | For the Nine Months Ended September 30, |
|  | 2016 |  | 2015 |
| Realized losses on settled future contracts | $ | 1.2 |  |  | $ | 1.3 |  |
| Foreign currency exchange losses | 1.1 |  |  | 2.7 |  |
| Loss on disposal of fixed assets | 0.3 |  |  | 0.1 |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (1.9 | ) |  | 0.9 |  |
| Special legal contingency charges | 0.5 |  |  | 5.5 |  |
| Asbestos-related litigation | 2.3 |  |  | 1.0 |  |
| Environmental liabilities | 1.1 |  |  | 0.7 |  |
| Contractor tax payments | 0.5 |  |  | 2.4 |  |
| Acquisition costs | 0.4 |  |  | — |  |
| Other items, net | — |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) | $ | 5.5 |  |  | $ | 14.9 |  |

[0001069202-16-000024:mdna:69]
The net change in unrealized gains on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.  Contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.

[0001069202-16-000024:mdna:70]
[same as prior period, unchanged from 0001069202-16-000020:mdna:73]

[0001069202-16-000024:mdna:71]
Restructuring charges during the first nine months of 2016 relate to the demolition of a facility relating to a previous restructuring activity.  The restructuring charges in the first nine months of 2015 relate to the restructuring of our Australian operations in the Refrigeration segment.    For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000024:mdna:72]
[same as prior period, unchanged from 0001069202-16-000020:mdna:75]

[0001069202-16-000024:mdna:73]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments increased to $15 million in the first nine months of 2016 as compared to $12 million in the first nine months of 2015.

[0001069202-16-000024:mdna:74]
[same as prior period, unchanged from 0001069202-16-000020:mdna:77]

[0001069202-16-000024:mdna:75]
Interest expense, net of $20 million in the first nine months of 2016 increased from $18 million in the first nine months of 2015 due to an increase in our average net borrowings.

[0001069202-16-000024:mdna:76]
[same as prior period, unchanged from 0001069202-16-000020:mdna:79]

[0001069202-16-000024:mdna:77]
We expect our annual effective tax rate to be 31% in 2016 and subsequent years to be approximately 32% due to sustainable benefits from reorganization of our international subsidiaries that will enable us to utilize foreign tax credits and other benefits that drives our effective tax rate down by approximately 250 basis points.  The tax benefit resulting from a repatriation of earnings in 2016 was recognized in the second quarter.

[0001069202-16-000024:mdna:78]
The effective tax rate was 30.4% for the first nine months of 2016 compared to 34.3% for the first nine months of 2015.

[0001069202-16-000024:mdna:79]
Year-to-Date through September 30, 2016 Compared to Year-to-Date through September 30, 2015 - Results by Segment

[0001069202-16-000024:mdna:80]
[same as prior period, unchanged from 0001069202-16-000020:mdna:83]

[0001069202-16-000024:mdna:81]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first nine months of 2016 and 2015 (dollars in millions):

[0001069202-16-000024:mdna:82]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 1,524.5 |  |  | $ | 1,435.6 |  |  | $ | 88.9 |  |  | 6.2 | % |
| Profit | $ | 266.9 |  |  | $ | 221.3 |  |  | $ | 45.6 |  |  | 20.6 | % |
| % of net sales | 17.5 | % |  | 15.4 | % |  |  |  |  |

[0001069202-16-000024:mdna:83]
Net sales increased by 6%  in the first nine months of 2016 compared to the first nine months of 2015.  Sales volumes increased net sales by 5% due to industry growth and market share gains and the benefits of favorable price and mix contributed 1%.

[0001069202-16-000024:mdna:84]
Segment profit for the first nine months of 2016 increased $46 million due to $45 million in lower material costs, $22 million from higher sales volume and $9 million from favorable factory productivity which includes the addition of a second factory in Mexico.  Partially offsetting these increases was $9 million from unfavorable price and mix combined, $4 million of unfavorable foreign currency exchange rates, $6 million in distribution investments, $7 million of SG&A expenses to support wage inflation and investments in information technology and research and development, and $4 million of other product costs.

[0001069202-16-000024:mdna:85]
[same as prior period, unchanged from 0001069202-16-000020:mdna:88]

[0001069202-16-000024:mdna:86]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first nine months of 2016 and 2015 (dollars in millions):

[0001069202-16-000024:mdna:87]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 674.7 |  |  | $ | 660.3 |  |  | $ | 14.4 |  |  | 2.2 | % |
| Profit | $ | 110.6 |  |  | $ | 95.5 |  |  | $ | 15.1 |  |  | 15.8 | % |
| % of net sales | 16.4 | % |  | 14.5 | % |  |  |  |  |

[0001069202-16-000024:mdna:88]
Commercial Heating & Cooling net sales increased by 2% in the first nine months of 2016 compared to the first nine months of 2015. Sales volumes increased net sales by 2%, price and mix increased sales by 1% and changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-16-000024:mdna:89]
Segment profit in the first nine months of 2016 increased $15 million compared to the first nine months of 2015.  The benefits of $4 million from incremental volume, $15 million from lower material costs, $4 million from price and mix and $2 million from lower freight and distribution expenses were partially offset by $5 million in lower factory productivity and other product costs, $3  million of higher SG&A expenses, $1 million for investments in infrastructure for the North American Service business and $1 million from changes in foreign currency exchange rates.

[0001069202-16-000024:mdna:90]
[same as prior period, unchanged from 0001069202-16-000020:mdna:93]

[0001069202-16-000024:mdna:91]
The following table presents our Refrigeration segment's net sales and profit for the first nine months of 2016 and 2015 (dollars in millions):

[0001069202-16-000024:mdna:92]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 545.2 |  |  | $ | 537.4 |  |  | $ | 7.8 |  |  | 1.5 | % |
| Profit | $ | 53.2 |  |  | $ | 37.5 |  |  | $ | 15.7 |  |  | 41.9 | % |
| % of net sales | 9.8 | % |  | 7.0 | % |  |  |  |  |

[0001069202-16-000024:mdna:93]
Refrigeration net sales increased 2% in the first nine months of 2016 compared to the first nine months of 2015 primarily due 4% volume growth led by our North American supermarket businesses.  This volume increase was partially offset by a 1% impact from unfavorable foreign exchange rates and a 1% impact from price reductions.

[0001069202-16-000024:mdna:94]
Segment profit for the first nine months of 2016 increased $16 million compared to the first nine months of 2015 primarily due to $6 million from increased sales volumes, $16 million in lower material costs, $5 million from lower depreciation and amortization due to the impairment of our Kysor Warren business recorded in the fourth quarter of 2015 and $3 million in factory productivity and other product costs.  Partially offsetting these increases were $7 million from unfavorable price and mix combined, $6 million from higher SG&A expenses and $1 million from changes in foreign currency exchange rates.

[0001069202-16-000024:mdna:95]
[same as prior period, unchanged from 0001069202-16-000020:mdna:98]

[0001069202-16-000024:mdna:96]
Corporate and other expenses increased $8 million in the first nine months of 2016 as compared to the first nine months of 2015 due primarily to $10 million in incentive compensation and wage inflation and $2 million of investments in research and development and consulting.  Partially offsetting these increases was $4 million from lower health care and other miscellaneous costs.

[0001069202-16-000024:mdna:97]
Pensions

[0001069202-16-000024:mdna:98]
As part of our overall strategy to de-risk our pension plans, we have offered certain vested participants in our U.S. qualified plans the opportunity to take a one-time lump sum distribution in lieu of future monthly pension payments.  These lump sum distributions will be paid from our retirement plan in the fourth quarter of 2016.  As a result of these lump sum payments, our pension benefit obligation will be reduced by approximately $50 million, and we expect to recognize a pre-tax pension settlement charge in the fourth quarter of approximately $30 million.

[0001069202-16-000024:mdna:99]
[same as prior period, unchanged from 0001069202-16-000020:mdna:100]

[0001069202-16-000024:mdna:100]
[same as prior period, unchanged from 0001069202-16-000020:mdna:101]

[0001069202-16-000024:mdna:101]
[same as prior period, unchanged from 0001069202-16-000020:mdna:102]

[0001069202-16-000024:mdna:102]
The following table summarizes our cash flow activity for the nine months ended September 30, 2016 and 2015 (in millions):

[0001069202-16-000024:mdna:103]
|  | For the Nine Months Ended September 30, |
|  | 2016 |  | 2015 |
| Net cash provided by operating activities | $ | 106.9 |  |  | $ | 106.9 |  |
| Net cash used in investing activities | (59.4 | ) |  | (47.0 | ) |
| Net cash used in financing activities | (41.8 | ) |  | (52.9 | ) |

[0001069202-16-000024:mdna:104]
Net Cash Provided by Operating Activities - The net cash provided by operating activities in the first nine months of 2016 and 2015 reflects the seasonal increase in working capital requirements and was flat year over year. Cash provided by operating activities was flat, the increase in net income in the first nine months of 2016 as compared to 2015 was offset by increases in cash  paid for taxes and the fact we made a discretionary pension contribution of $50 million into our U.S. qualified pension plan during the third quarter of 2016.

[0001069202-16-000024:mdna:105]
Net Cash Used in Investing Activities - Capital expenditures were $59 million and $47 million in the first nine months of 2016 and 2015, respectively.  Capital expenditures in 2016 were primarily related to investments in systems and software to support the overall enterprise, expansion of our manufacturing capacity, and continued investments in our distribution network.

[0001069202-16-000024:mdna:106]
Net Cash Used in Financing Activities - Net cash used in financing activities decreased to $42 million in the first nine months of 2016 primarily due to an increase in stock repurchases partially offset by increases in borrowings.   Net borrowings were higher in 2016 to support the increased stock repurchases and dividend payments.  Final settlement of the $200 million Accelerated Share Repurchase Plan executed in the first quarter of 2016 was in the third quarter of 2016. Final settlement of the $100 Million Accelerated Share Repurchase Plan executed in the third quarter of 2016 will be in the fourth quarter of 2016.

[0001069202-16-000024:mdna:107]
[same as prior period, unchanged from 0001069202-16-000020:mdna:108]

[0001069202-16-000024:mdna:108]
The following table details our lines of credit and financing arrangements as of September 30, 2016 (in millions):

[0001069202-16-000024:mdna:109]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 2.8 |  |
| Asset Securitization Program (1) | 325.0 |  |
| Total short-term debt | $ | 327.8 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 0.9 |  |
| Domestic credit facility (2) | 15.0 |  |
| Senior unsecured notes | 200.0 |  |
| Debt issuance costs | (0.3 | ) |
| Total current maturities of long-term debt | $ | 215.6 |  |
| Long-term debt: |  |
| Capital lease obligations | 15.1 |  |
| Domestic credit facility (2) | 500.0 |  |
| Debt issuance costs | (2.6 | ) |
| Total long-term debt | 512.5 |  |
| Total debt | $ | 1,055.9 |  |

[0001069202-16-000024:mdna:110]
(1) The maximum securitization amount ranges from $200.0 million to $325.0 million, depending on the period, after consideration of the July 5, 2016 amendment.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.

[0001069202-16-000024:mdna:111]
(2) The available future borrowings on our domestic credit facility are $380.6 million after being reduced by the outstanding borrowings and $4.4 million in outstanding standby letters of credit.  We also had $38.3 million in outstanding standby letters of credit outside of the domestic credit facility as of September 30, 2016.

[0001069202-16-000024:mdna:112]
[same as prior period, unchanged from 0001069202-16-000020:mdna:113]

[0001069202-16-000024:mdna:113]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 97.8% at September 30, 2016 from 87.9% at December 31, 2015.

[0001069202-16-000024:mdna:114]
As of September 30, 2016, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-16-000024:mdna:115]
[same as prior period, unchanged from 0001069202-16-000020:mdna:116]

[0001069202-16-000024:mdna:116]
We believe our cash and cash equivalents of $48 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $48 million as of September 30, 2016 was $27.4 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States. If we were to repatriate foreign earnings, we would be required to accrue and pay taxes in the United States, less foreign tax credits, for the amounts that were repatriated.  However, an additional benefit of the tax reorganization discussed previously is our ability to repatriate cash generated in prior periods in a tax efficient manner. We repatriated $42 million in cash from foreign subsidiaries and made a discretionary contribution of $50 million to our qualified pension plans in the third quarter of 2016.

[0001069202-16-000024:mdna:117]
Our expected capital expenditures for 2016 are $95 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with the completion of our $200 million accelerated share repurchase program in 2016, the initiation of another $100 million stock repurchase program in the third quarter of 2016, and a target of between $65 million and $75 million of dividend payments in 2016.

[0001069202-16-000024:mdna:118]
[same as prior period, unchanged from 0001069202-16-000020:mdna:119]

[0001069202-16-000024:mdna:119]
[same as prior period, unchanged from 0001069202-16-000020:mdna:120]

[0001069202-16-000024:mdna:120]
Commitments, Contingencies and Guarantees

[0001069202-16-000024:mdna:121]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000024:mdna:122]
[same as prior period, unchanged from 0001069202-16-000020:mdna:123]

[0001069202-16-000024:mdna:123]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our Consolidated Financial Statements and related disclosures. We will adopt the new standard using the modified retrospective approach and are still determining the effect of the standard on our ongoing financial reporting.

[0001069202-16-000024:mdna:124]
In January 2015, the FASB issued ASU No. 2015-01, Income Statement - Extraordinary and Unusual Items (Subtopic 225-20): Simplifying Income Statement Presentation by Eliminating the Concept of Extraordinary Items. ASU No. 2015-01 eliminates the concept of an extraordinary item from GAAP. As a result, an entity will no longer be required to separately present an extraordinary item on its statement of operations, net of tax, after income from continuing operations or to disclose income taxes and net income per share data applicable to an extraordinary item. However, ASU No. 2015-01 will still retain the presentation and disclosure guidance for items that are unusual in nature and occur infrequently. ASU No. 2015-01 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period, although early adoption is permitted. The adoption of this standard did not materially impact our Consolidated Financial Statements.

[0001069202-16-000024:mdna:125]
In February 2015, the FASB issued ASU 2015-02, Consolidation: Amendments to the Consolidation Analysis, or ASU 2015-02, which amends the criteria for determining which entities are considered variable interest entities (“VIEs”), amends the criteria for determining if a service provider possesses a variable interest in a VIE and ends the deferral granted to investment companies for application of the VIE consolidation model. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015 and early adoption is permitted. The adoption of this standard did not materially impact our Consolidated Financial Statements.

[0001069202-16-000024:mdna:126]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015, and early adoption is permitted. The adoption of this standard did not materially impact our Consolidated Financial Statements.

[0001069202-16-000024:mdna:127]
In November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes (Topic 740) that simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent on the

[0001069202-16-000024:mdna:128]
balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. We adopted this standard retrospectively as of December 31, 2015.

[0001069202-16-000024:mdna:129]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001069202-16-000024:mdna:130]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. The ASU includes multiple provisions intended to simplify various aspects of the accounting for share-based payments. Excess tax benefits for share-based payments will be recorded as a reduction of income taxes and reflected in operating cash flows upon the adoption of this ASU.  Excess tax benefits are currently recorded in equity and as financing activity under the current rules. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2016.
