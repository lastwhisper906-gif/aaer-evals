# LII notes — 0001069202-16-000024


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-16-000024:notes:1]
[same as prior period, unchanged from 0001069202-16-000020:notes:1]

[0001069202-16-000024:notes:2]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 325.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 325.0 |  |  | 200.0 |  |
| Remaining amount available | $ | — |  |  | $ | 20.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-16-000024:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-16-000024:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-16-000024:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-16-000024:notes:6]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.70 | % |  | 1.90 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-16-000024:notes:7]
[same as prior period, unchanged from 0001069202-16-000020:notes:7]

[0001069202-16-000024:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2016, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2016 and 2015, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine  months ended September 30, 2016 and 2015, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2016 and 2015 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2015. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-16-000024:notes:9]
Our fiscal year ends on December 31 and each quarter is comprised of approximately13 weeks. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-16-000024:notes:10]
Commitments and Contingencies:

[0001069202-16-000024:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-16-000024:notes:12]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-16-000024:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000024:notes:14]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Accrued expenses | $ | 30.3 |  |  | $ | 26.7 |  |
| Other liabilities | 69.9 |  |  | 65.6 |  |
| Total warranty liability | $ | 100.2 |  |  | $ | 92.3 |  |

[0001069202-16-000024:notes:15]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2016 were as follows (in millions):

[0001069202-16-000024:notes:16]
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |
| Warranty claims paid | (20.4 | ) |
| Changes resulting from issuance of new warranties | 31.6 |  |
| Changes in estimates associated with pre-existing liabilities | (3.9 | ) |
| Changes in foreign currency translation rates and other | 0.6 |  |
| Total warranty liability as of September 30, 2016 | $ | 100.2 |  |

[0001069202-16-000024:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a certain supplier quality issue within a range of $1.9 million and $9.1 million  with all amounts in that range equally likely.  We have accrued a $1.9 million liability in Accrued expenses on the Consolidated Balance Sheet at September 30, 2016. The supplier is reimbursing the majority of costs related to this liability.

[0001069202-16-000024:notes:18]
Litigation

[0001069202-16-000024:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-16-000024:notes:20]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and is subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2016, and 2015, expense for asbestos-related litigation was $2.3 million, and $1.0 million, net of insurance recoveries, respectively.

[0001069202-16-000024:notes:21]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-16-000024:notes:22]
[same as prior period, unchanged from 0001069202-16-000020:notes:22]

[0001069202-16-000024:notes:23]
[same as prior period, unchanged from 0001069202-16-000020:notes:23]

[0001069202-16-000024:notes:24]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (2.4 | ) |  | $ | (3.2 | ) |  | $ | (10.6 | ) |  | $ | (9.4 | ) |  | Cost of goods sold |
| Income tax benefit |  | 0.8 |  |  | 1.2 |  |  | 3.7 |  |  | 3.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.6 | ) |  | $ | (2.0 | ) |  | $ | (6.9 | ) |  | $ | (6.2 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.6 | ) |  | $ | (2.0 | ) |  | $ | (4.8 | ) |  | $ | (6.1 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.6 |  |  | 0.7 |  |  | 1.7 |  |  | 2.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.0 | ) |  | $ | (1.3 | ) |  | $ | (3.1 | ) |  | $ | (3.9 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (2.6 | ) |  | $ | (3.3 | ) |  | $ | (10.0 | ) |  | $ | (10.1 | ) |  |  |

[0001069202-16-000024:notes:25]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2016 (in millions):

[0001069202-16-000024:notes:26]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2015 |  | $ | (8.4 | ) |  | $ | 4.4 |  |  | $ | (139.3 | ) |  | $ | (61.4 | ) |  | $ | (204.7 | ) |
| Other comprehensive (loss) income before reclassifications |  | 0.8 |  |  | (1.8 | ) |  | (2.6 | ) |  | 11.3 |  |  | 7.7 |  |
| Amounts reclassified from AOCL |  | 6.9 |  |  | — |  |  | 3.1 |  |  | — |  |  | 10.0 |  |
| Net other comprehensive (loss) income |  | 7.7 |  |  | (1.8 | ) |  | 0.5 |  |  | 11.3 |  |  | 17.7 |  |
| Balance as of September 30, 2016 |  | $ | (0.7 | ) |  | $ | 2.6 |  |  | $ | (138.8 | ) |  | $ | (50.1 | ) |  | $ | (187.0 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-16-000024:notes:27]
[same as prior period, unchanged from 0001069202-16-000020:notes:27]

[0001069202-16-000024:notes:28]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor Subsidiaries”) and are not guaranteed by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001069202-16-000024:notes:29]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of September 30, 2016 and December 31, 2015 and for the three and nine months ended September 30, 2016 and 2015 are shown on the following pages.

[0001069202-16-000024:notes:30]
[same as prior period, unchanged from 0001069202-16-000020:notes:30]

[0001069202-16-000024:notes:31]
[same as prior period, unchanged from 0001069202-16-000020:notes:31]

[0001069202-16-000024:notes:32]
As of September 30, 2016

[0001069202-16-000024:notes:33]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 4.5 |  |  | $ | 15.9 |  |  | $ | 27.4 |  |  | $ | — |  |  | $ | 47.8 |  |
| Accounts and notes receivable, net | — |  |  | 42.4 |  |  | 528.0 |  |  | — |  |  | 570.4 |  |
| Inventories, net | — |  |  | 361.3 |  |  | 119.3 |  |  | (6.6 | ) |  | 474.0 |  |
| Other assets | 4.8 |  |  | 50.5 |  |  | 80.1 |  |  | (61.1 | ) |  | 74.3 |  |
| Total current assets | 9.3 |  |  | 470.1 |  |  | 754.8 |  |  | (67.7 | ) |  | 1,166.5 |  |
| Property, plant and equipment, net | — |  |  | 269.0 |  |  | 77.2 |  |  | — |  |  | 346.2 |  |
| Goodwill | — |  |  | 134.9 |  |  | 63.6 |  |  | — |  |  | 198.5 |  |
| Investment in subsidiaries | 1,137.6 |  |  | 308.6 |  |  | (0.6 | ) |  | (1,445.6 | ) |  | — |  |
| Deferred income taxes | 5.0 |  |  | 129.0 |  |  | 28.5 |  |  | (15.1 | ) |  | 147.4 |  |
| Other assets, net | 2.1 |  |  | 38.6 |  |  | 28.8 |  |  | (1.5 | ) |  | 68.0 |  |
| Intercompany receivables (payables), net | (450.8 | ) |  | 439.0 |  |  | 85.1 |  |  | (73.3 | ) |  | — |  |
| Total assets | $ | 703.2 |  |  | $ | 1,789.2 |  |  | $ | 1,037.4 |  |  | $ | (1,603.2 | ) |  | $ | 1,926.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 327.8 |  |  | $ | — |  |  | $ | 327.8 |  |
| Current maturities of long-term debt | 214.7 |  |  | 0.6 |  |  | 0.3 |  |  | — |  |  | 215.6 |  |
| Accounts payable | 18.5 |  |  | 283.0 |  |  | 70.2 |  |  | — |  |  | 371.7 |  |
| Accrued expenses | 6.1 |  |  | 208.3 |  |  | 57.8 |  |  | — |  |  | 272.2 |  |
| Income taxes payable | (58.4 | ) |  | 79.3 |  |  | 57.4 |  |  | (77.5 | ) |  | 0.8 |  |
| Total current liabilities | 180.9 |  |  | 571.2 |  |  | 513.5 |  |  | (77.5 | ) |  | 1,188.1 |  |
| Long-term debt | 497.6 |  |  | 14.6 |  |  | 0.3 |  |  | — |  |  | 512.5 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.2 |  |  | — |  |  | — |  |  | 2.2 |  |
| Pensions | — |  |  | 64.7 |  |  | 8.2 |  |  | — |  |  | 72.9 |  |
| Other liabilities | 0.5 |  |  | 120.2 |  |  | 10.7 |  |  | (4.7 | ) |  | 126.7 |  |
| Total liabilities | 679.0 |  |  | 772.9 |  |  | 532.7 |  |  | (82.2 | ) |  | 1,902.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 24.2 |  |  | 1,016.3 |  |  | 504.7 |  |  | (1,521.0 | ) |  | 24.2 |  |
| Total liabilities and stockholders' equity | $ | 703.2 |  |  | $ | 1,789.2 |  |  | $ | 1,037.4 |  |  | $ | (1,603.2 | ) |  | $ | 1,926.6 |  |

[0001069202-16-000024:notes:34]
[same as prior period, unchanged from 0001069202-16-000020:notes:34]

[0001069202-16-000024:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.5 |  |  | $ | 7.8 |  |  | $ | 30.6 |  |  | $ | — |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net | — |  |  | 25.9 |  |  | 396.9 |  |  | — |  |  | 422.8 |  |
| Inventories, net | — |  |  | 324.3 |  |  | 98.9 |  |  | (4.4 | ) |  | 418.8 |  |
| Other assets | 3.3 |  |  | 46.9 |  |  | 67.4 |  |  | (59.9 | ) |  | 57.7 |  |
| Total current assets | 3.8 |  |  | 404.9 |  |  | 593.8 |  |  | (64.3 | ) |  | 938.2 |  |
| Property, plant and equipment, net | — |  |  | 261.8 |  |  | 77.8 |  |  | — |  |  | 339.6 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 879.0 |  |  | 337.6 |  |  | (0.6 | ) |  | (1,216.0 | ) |  | — |  |
| Deferred income taxes | 5.4 |  |  | 126.6 |  |  | 28.4 |  |  | (14.7 | ) |  | 145.7 |  |
| Other assets, net | 1.5 |  |  | 38.2 |  |  | 20.6 |  |  | (1.5 | ) |  | 58.8 |  |
| Intercompany (payables) receivables, net | (278.6 | ) |  | 253.3 |  |  | 25.3 |  |  | — |  |  | — |  |
| Total assets | $ | 611.1 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,677.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 204.1 |  |  | $ | — |  |  | $ | 204.1 |  |
| Current maturities of long-term debt | 29.8 |  |  | 0.8 |  |  | 0.4 |  |  | — |  |  | 31.0 |  |
| Accounts payable | 16.1 |  |  | 237.9 |  |  | 66.1 |  |  | — |  |  | 320.1 |  |
| Accrued expenses | 15.8 |  |  | 176.7 |  |  | 50.1 |  |  | — |  |  | 242.6 |  |
| Income taxes (receivable) payable | (43.0 | ) |  | 106.6 |  |  | 37.9 |  |  | (75.5 | ) |  | 26.0 |  |
| Total current liabilities | 18.7 |  |  | 522.0 |  |  | 358.6 |  |  | (75.5 | ) |  | 823.8 |  |
| Long-term debt | 490.4 |  |  | 15.1 |  |  | 0.5 |  |  | — |  |  | 506.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.1 |  |  | — |  |  | — |  |  | 4.1 |  |
| Pensions | — |  |  | 111.9 |  |  | 8.9 |  |  | — |  |  | 120.8 |  |
| Other liabilities | 0.4 |  |  | 114.4 |  |  | 10.5 |  |  | (4.2 | ) |  | 121.1 |  |
| Total liabilities | 509.5 |  |  | 767.5 |  |  | 378.5 |  |  | (79.7 | ) |  | 1,575.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 101.6 |  |  | 789.8 |  |  | 427.0 |  |  | (1,216.8 | ) |  | 101.6 |  |
| Total liabilities and stockholders' equity | $ | 611.1 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,677.4 |  |

[0001069202-16-000024:notes:36]
[same as prior period, unchanged from 0001069202-16-000020:notes:36]

[0001069202-16-000024:notes:37]
For the Three Months Ended September 30, 2016

[0001069202-16-000024:notes:38]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 870.5 |  |  | $ | 186.9 |  |  | $ | (47.4 | ) |  | $ | 1,010.0 |  |
| Cost of goods sold | — |  |  | 603.4 |  |  | 143.7 |  |  | (47.4 | ) |  | 699.7 |  |
| Gross profit | — |  |  | 267.1 |  |  | 43.2 |  |  | — |  |  | 310.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 135.9 |  |  | 20.6 |  |  | — |  |  | 156.5 |  |
| Losses (gains) and other expenses, net | (1.1 | ) |  | 1.1 |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Restructuring charges | — |  |  | 0.5 |  |  | 0.1 |  |  | — |  |  | 0.6 |  |
| Income from equity method investments | (105.0 | ) |  | (10.0 | ) |  | (3.2 | ) |  | 113.8 |  |  | (4.4 | ) |
| Operating income | 106.1 |  |  | 139.6 |  |  | 25.0 |  |  | (113.8 | ) |  | 156.9 |  |
| Interest expense, net | 6.1 |  |  | (0.5 | ) |  | 1.4 |  |  | — |  |  | 7.0 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 100.0 |  |  | 140.1 |  |  | 23.6 |  |  | (113.8 | ) |  | 149.9 |  |
| Provision for income taxes | (1.7 | ) |  | 42.3 |  |  | 7.6 |  |  | — |  |  | 48.2 |  |
| Income from continuing operations | 101.7 |  |  | 97.8 |  |  | 16.0 |  |  | (113.8 | ) |  | 101.7 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 101.7 |  |  | $ | 97.8 |  |  | $ | 16.0 |  |  | $ | (113.8 | ) |  | $ | 101.7 |  |
| Other comprehensive income (loss), net of tax | 2.7 |  |  | (0.4 | ) |  | (2.3 | ) |  | (0.4 | ) |  | (0.4 | ) |
| Comprehensive income | $ | 104.4 |  |  | $ | 97.4 |  |  | $ | 13.7 |  |  | $ | (114.2 | ) |  | $ | 101.3 |  |

[0001069202-16-000024:notes:39]
For the Nine Months Ended September 30, 2016

[0001069202-16-000024:notes:40]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,368.8 |  |  | $ | 514.1 |  |  | $ | (138.5 | ) |  | $ | 2,744.4 |  |
| Cost of goods sold | — |  |  | 1,675.6 |  |  | 396.3 |  |  | (136.4 | ) |  | 1,935.5 |  |
| Gross profit | — |  |  | 693.2 |  |  | 117.8 |  |  | (2.1 | ) |  | 808.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 394.6 |  |  | 61.6 |  |  | — |  |  | 456.2 |  |
| Losses (gains) and other expenses, net | (1.7 | ) |  | 4.3 |  |  | 3.0 |  |  | (0.1 | ) |  | 5.5 |  |
| Restructuring charges | — |  |  | 1.5 |  |  | (0.3 | ) |  | — |  |  | 1.2 |  |
| Income from equity method investments | (248.5 | ) |  | (19.5 | ) |  | (12.4 | ) |  | 265.1 |  |  | (15.3 | ) |
| Operating income | 250.2 |  |  | 312.3 |  |  | 65.9 |  |  | (267.1 | ) |  | 361.3 |  |
| Interest expense, net | 17.7 |  |  | (1.5 | ) |  | 3.4 |  |  | — |  |  | 19.6 |  |
| Other expense, net | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Income from continuing operations before income taxes | 232.5 |  |  | 313.8 |  |  | 62.7 |  |  | (267.1 | ) |  | 341.9 |  |
| Provision for income taxes | (4.9 | ) |  | 89.1 |  |  | 20.5 |  |  | (0.7 | ) |  | 104.0 |  |
| Income from continuing operations | 237.4 |  |  | 224.7 |  |  | 42.2 |  |  | (266.4 | ) |  | 237.9 |  |
| Loss from discontinued operations | — |  |  | — |  |  | 0.6 |  |  | — |  |  | 0.6 |  |
| Net income | $ | 237.4 |  |  | $ | 224.7 |  |  | $ | 41.6 |  |  | $ | (266.4 | ) |  | $ | 237.3 |  |
| Other comprehensive income (loss), net of tax | 7.7 |  |  | 2.0 |  |  | 6.7 |  |  | 1.3 |  |  | 17.7 |  |
| Comprehensive income | $ | 245.1 |  |  | $ | 226.7 |  |  | $ | 48.3 |  |  | $ | (265.1 | ) |  | $ | 255.0 |  |

[0001069202-16-000024:notes:41]
For the Three Months Ended September 30, 2015

[0001069202-16-000024:notes:42]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 827.9 |  |  | $ | 185.2 |  |  | $ | (58.1 | ) |  | $ | 955.0 |  |
| Cost of goods sold | — |  |  | 589.9 |  |  | 150.2 |  |  | (58.5 | ) |  | 681.6 |  |
| Gross profit | — |  |  | 238.0 |  |  | 35.0 |  |  | 0.4 |  |  | 273.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 124.0 |  |  | 19.8 |  |  | — |  |  | 143.8 |  |
| Losses and other expenses, net | 0.6 |  |  | 2.7 |  |  | 2.7 |  |  | — |  |  | 6.0 |  |
| Restructuring gains | — |  |  | (0.2 | ) |  | (0.2 | ) |  | — |  |  | (0.4 | ) |
| Income from equity method investments | (84.2 | ) |  | (2.7 | ) |  | (2.1 | ) |  | 86.0 |  |  | (3.0 | ) |
| Operating income | 83.6 |  |  | 114.2 |  |  | 14.8 |  |  | (85.6 | ) |  | 127.0 |  |
| Interest expense, net | 5.4 |  |  | (0.4 | ) |  | 0.7 |  |  | — |  |  | 5.7 |  |
| Other expense, net | — |  |  | — |  |  | (0.7 | ) |  | — |  |  | (0.7 | ) |
| Income from continuing operations before income taxes | 78.2 |  |  | 114.6 |  |  | 14.8 |  |  | (85.6 | ) |  | 122.0 |  |
| Provision for income taxes | (2.1 | ) |  | 39.0 |  |  | 4.6 |  |  | 0.2 |  |  | 41.7 |  |
| Income from continuing operations | 80.3 |  |  | 75.6 |  |  | 10.2 |  |  | (85.8 | ) |  | 80.3 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 80.3 |  |  | $ | 75.6 |  |  | $ | 10.2 |  |  | $ | (85.8 | ) |  | $ | 80.3 |  |
| Other comprehensive loss, net of tax | (4.3 | ) |  | (8.6 | ) |  | (16.2 | ) |  | (1.8 | ) |  | (30.9 | ) |
| Comprehensive income (loss) | $ | 76.0 |  |  | $ | 67.0 |  |  | $ | (6.0 | ) |  | $ | (87.6 | ) |  | $ | 49.4 |  |

[0001069202-16-000024:notes:43]
For the Nine Months Ended September 30, 2015

[0001069202-16-000024:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,268.6 |  |  | $ | 520.7 |  |  | $ | (156.0 | ) |  | $ | 2,633.3 |  |
| Cost of goods sold | — |  |  | 1,650.7 |  |  | 418.2 |  |  | (155.4 | ) |  | 1,913.5 |  |
| Gross profit | — |  |  | 617.9 |  |  | 102.5 |  |  | (0.6 | ) |  | 719.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 362.0 |  |  | 68.0 |  |  | — |  |  | 430.0 |  |
| Losses and other expenses, net | 1.1 |  |  | 7.7 |  |  | 6.2 |  |  | (0.1 | ) |  | 14.9 |  |
| Restructuring charges | — |  |  | (0.5 | ) |  | 2.3 |  |  | — |  |  | 1.8 |  |
| Income from equity method investments | (187.2 | ) |  | (0.3 | ) |  | (9.3 | ) |  | 185.0 |  |  | (11.8 | ) |
| Operating income | 186.1 |  |  | 249.0 |  |  | 35.3 |  |  | (185.5 | ) |  | 284.9 |  |
| Interest expense, net | 17.1 |  |  | (1.5 | ) |  | 2.3 |  |  | — |  |  | 17.9 |  |
| Other expense, net | — |  |  | — |  |  | (0.7 | ) |  | — |  |  | (0.7 | ) |
| Income from continuing operations before income taxes | 169.0 |  |  | 250.5 |  |  | 33.7 |  |  | (185.5 | ) |  | 267.7 |  |
| Provision for income taxes | (6.3 | ) |  | 87.2 |  |  | 11.2 |  |  | (0.2 | ) |  | 91.9 |  |
| Income from continuing operations | 175.3 |  |  | 163.3 |  |  | 22.5 |  |  | (185.3 | ) |  | 175.8 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Net income | $ | 175.3 |  |  | $ | 163.3 |  |  | $ | 22.0 |  |  | $ | (185.3 | ) |  | $ | 175.3 |  |
| Other comprehensive income (loss), net of tax | (2.9 | ) |  | (13.8 | ) |  | (36.4 | ) |  | (3.2 | ) |  | (56.3 | ) |
| Comprehensive income | $ | 172.4 |  |  | $ | 149.5 |  |  | $ | (14.4 | ) |  | $ | (188.5 | ) |  | $ | 119.0 |  |

[0001069202-16-000024:notes:45]
[same as prior period, unchanged from 0001069202-16-000020:notes:45]

[0001069202-16-000024:notes:46]
For the Nine Months Ended September 30, 2016

[0001069202-16-000024:notes:47]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | (4.5 | ) |  | $ | 262.2 |  |  | $ | (150.8 | ) |  | $ | — |  |  | $ | 106.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (52.4 | ) |  | (7.0 | ) |  | — |  |  | (59.4 | ) |
| Net cash used in investing activities | — |  |  | (52.4 | ) |  | (7.0 | ) |  | — |  |  | (59.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (2.1 | ) |  | — |  |  | (2.1 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 145.0 |  |  | — |  |  | 145.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (20.0 | ) |  | — |  |  | (20.0 | ) |
| Long-term debt payments | (30.0 | ) |  | (0.6 | ) |  | (0.3 | ) |  | — |  |  | (30.9 | ) |
| Borrowings from credit facility | 1,715.0 |  |  | — |  |  | — |  |  | — |  |  | 1,715.0 |  |
| Payments on credit facility | (1,493.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,493.0 | ) |
| Proceeds from employee stock purchases | 1.9 |  |  | — |  |  | — |  |  | — |  |  | 1.9 |  |
| Payments of deferred financing costs | (0.9 | ) |  | — |  |  | — |  |  | — |  |  | (0.9 | ) |
| Repurchases of common stock | (300.0 | ) |  | — |  |  | — |  |  | — |  |  | (300.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (26.3 | ) |  | — |  |  | — |  |  | — |  |  | (26.3 | ) |
| Excess tax benefits related to share-based payments | 20.0 |  |  | — |  |  | — |  |  | — |  |  | 20.0 |  |
| Intercompany debt | (6.6 | ) |  | (5.1 | ) |  | 11.7 |  |  | — |  |  | — |  |
| Intercompany financing activity | 178.9 |  |  | (196.0 | ) |  | 17.1 |  |  | — |  |  | — |  |
| Cash dividends paid | (50.5 | ) |  | — |  |  | — |  |  | — |  |  | (50.5 | ) |
| Net cash provided by financing activities | 8.5 |  |  | (201.7 | ) |  | 151.4 |  |  | — |  |  | (41.8 | ) |
| Increase in cash and cash equivalents | 4.0 |  |  | 8.1 |  |  | (6.4 | ) |  | — |  |  | 5.7 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 3.2 |  |  | — |  |  | 3.2 |  |
| Cash and cash equivalents, beginning of period | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of period | $ | 4.5 |  |  | $ | 15.9 |  |  | $ | 27.4 |  |  | $ | — |  |  | $ | 47.8 |  |

[0001069202-16-000024:notes:48]
For the Nine Months Ended September 30, 2015

[0001069202-16-000024:notes:49]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | (27.3 | ) |  | $ | 138.2 |  |  | $ | (4.0 | ) |  | $ | — |  |  | $ | 106.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (40.3 | ) |  | (6.7 | ) |  | — |  |  | (47.0 | ) |
| Net cash used in investing activities | — |  |  | (40.3 | ) |  | (6.7 | ) |  | — |  |  | (47.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Long-term debt payments | (22.5 | ) |  | (0.8 | ) |  | (0.2 | ) |  | — |  |  | (23.5 | ) |
| Borrowings from revolving credit facility | 1,401.0 |  |  | — |  |  | — |  |  | — |  |  | 1,401.0 |  |
| Payments on revolving credit facility | (1,385.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,385.0 | ) |
| Proceeds from employee stock purchases | 1.8 |  |  | — |  |  | — |  |  | — |  |  | 1.8 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (23.5 | ) |  | — |  |  | — |  |  | — |  |  | (23.5 | ) |
| Payments of deferred financing costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Excess tax benefits related to share-based payments | 18.6 |  |  | — |  |  | — |  |  | — |  |  | 18.6 |  |
| Intercompany financing activity | (37.7 | ) |  | 10.2 |  |  | 27.5 |  |  | — |  |  | — |  |
| Intercompany investments | 118.0 |  |  | (106.3 | ) |  | (11.7 | ) |  | — |  |  | — |  |
| Cash dividends paid | (43.1 | ) |  | — |  |  | — |  |  | — |  |  | (43.1 | ) |
| Net cash provided by financing activities | 27.6 |  |  | (96.9 | ) |  | 16.4 |  |  | — |  |  | (52.9 | ) |
| Increase in cash and cash equivalents | 0.3 |  |  | 1.0 |  |  | 5.7 |  |  | — |  |  | 7.0 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (9.4 | ) |  | — |  |  | (9.4 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of period | $ | 1.3 |  |  | $ | 12.5 |  |  | $ | 21.3 |  |  | $ | — |  |  | $ | 35.1 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-16-000024:notes:50]
Lines of Credit and Financing Arrangements:

[0001069202-16-000024:notes:51]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000024:notes:52]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 325.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 2.8 |  |  | 4.1 |  |
| Total short-term debt | $ | 327.8 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.9 |  |  | $ | 1.2 |  |
| Domestic credit facility | 15.0 |  |  | 30.0 |  |
| Senior unsecured notes | 200.0 |  |  | — |  |
| Debt issuance costs | (0.3 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 215.6 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.1 |  |  | $ | 15.6 |  |
| Domestic credit facility | 500.0 |  |  | 293.0 |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (2.6 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 512.5 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,055.9 |  |  | $ | 741.1 |  |

[0001069202-16-000024:notes:53]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. We adopted this guidance in the first quarter of 2016 and have reclassified the unamortized debt issuance costs into the debt liability as shown in the table above.

[0001069202-16-000024:notes:54]
Short-Term Debt

[0001069202-16-000024:notes:55]
Foreign Obligations

[0001069202-16-000024:notes:56]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $2.8 million and $4.1 million of foreign obligations as of September 30, 2016 and December 31, 2015, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $28.2 million  and $63.6 million during the nine months ended September 30, 2016 and 2015, respectively. Repayments on the facilities were $30.3 million and $61.7 million during the nine months ended September 30, 2016 and 2015, respectively.

[0001069202-16-000024:notes:57]
Asset Securitization Program

[0001069202-16-000024:notes:58]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP matures in November 2017 and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-16-000024:notes:59]
Prior to the amendment in July 2016, the ASP provided for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The ASP was amended effective as of July 5, 2016 to increase the maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-16-000024:notes:60]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rate for September 30, 2016 and December 31, 2015 was 1.49% and 1.06% respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-16-000024:notes:61]
The ASP contains certain restrictive qualifications relating to the quality of our accounts receivable and certain cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2016, we believe we were in compliance with all covenant requirements.

[0001069202-16-000024:notes:62]
Long-Term Debt

[0001069202-16-000024:notes:63]
Domestic Credit Facility

[0001069202-16-000024:notes:64]
On August 30, 2016, we replaced an earlier $950.0 million credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $515.0 million, of which $250.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of September 30, 2016. Subject to covenant limitations, $380.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million beginning in March 2017.  The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-16-000024:notes:65]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-16-000024:notes:66]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-16-000024:notes:67]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-16-000024:notes:68]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-16-000024:notes:69]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2016, we believe we were in compliance with all covenant requirements.

[0001069202-16-000024:notes:70]
Senior Unsecured Notes

[0001069202-16-000024:notes:71]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2016, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-16-000024:notes:72]
[same as prior period, unchanged from 0001069202-16-000020:notes:72]

[0001069202-16-000024:notes:73]
[same as prior period, unchanged from 0001069202-16-000020:notes:73]

[0001069202-16-000024:notes:74]
[same as prior period, unchanged from 0001069202-16-000020:notes:74]

[0001069202-16-000024:notes:75]
[same as prior period, unchanged from 0001069202-16-000020:notes:75]

[0001069202-16-000024:notes:76]
[same as prior period, unchanged from 0001069202-16-000020:notes:76]

[0001069202-16-000024:notes:77]
[same as prior period, unchanged from 0001069202-16-000020:notes:77]

[0001069202-16-000024:notes:78]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flow hedges that are scheduled to mature through February 2018.  Unrealized gains or losses from our cash flow hedges are included in Accumulated Other Comprehensive Loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-16-000024:notes:79]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Unrealized losses on unsettled futures contracts | $ | 1.2 |  |  | $ | 13.2 |  |
| Income tax benefit | (0.4 | ) |  | (4.8 | ) |
| Losses included in AOCL, net of tax (1) | $ | 0.8 |  |  | $ | 8.4 |  |

[0001069202-16-000024:notes:80]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $1.4 million of derivative losses into earnings within the next 12 months.

[0001069202-16-000024:notes:81]
[same as prior period, unchanged from 0001069202-16-000020:notes:81]

[0001069202-16-000024:notes:82]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Copper | 31.6 |  |  | 34.7 |  |

[0001069202-16-000024:notes:83]
[same as prior period, unchanged from 0001069202-16-000020:notes:83]

[0001069202-16-000024:notes:84]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 230.6 |  |  | 201.4 |  |
| Canadian Dollar | 16.4 |  |  | — |  |

[0001069202-16-000024:notes:85]
[same as prior period, unchanged from 0001069202-16-000020:notes:85]

[0001069202-16-000024:notes:86]
[same as prior period, unchanged from 0001069202-16-000020:notes:86]

[0001069202-16-000024:notes:87]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Copper | 2.6 |  |  | 3.3 |  |
| Aluminum | 3.1 |  |  | 3.2 |  |

[0001069202-16-000024:notes:88]
[same as prior period, unchanged from 0001069202-16-000020:notes:88]

[0001069202-16-000024:notes:89]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 34.7 |  |  | 53.0 |  |
| Indian Rupee | 218.5 |  |  | 30.8 |  |
| Euro | 51.1 |  |  | 3.2 |  |
| Chinese Yuan | 14.0 |  |  | — |  |
| Polish Zloty | — |  |  | 25.4 |  |
| Great Britain Pound | 1.9 |  |  | — |  |
| New Zealand Dollar | 3.0 |  |  | — |  |
| Australian Dollar | 28.0 |  |  | — |  |

[0001069202-16-000024:notes:90]
[same as prior period, unchanged from 0001069202-16-000020:notes:90]

[0001069202-16-000024:notes:91]
[same as prior period, unchanged from 0001069202-16-000020:notes:91]

[0001069202-16-000024:notes:92]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of September 30, 2016 |  | As of December 31, 2015 |  | As of September 30, 2016 |  | As of December 31, 2015 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 1.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.4 |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.6 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total Assets | $ | 1.7 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 0.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 2.0 |  |  | $ | 12.5 |  |  | $ | 0.2 |  |  | $ | 1.5 |  |
| Foreign currency forward contracts | 0.4 |  |  | 0.4 |  |  | 0.1 |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.1 |  |  | 0.4 |  |  | — |  |  | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 2.5 |  |  | $ | 13.3 |  |  | $ | 0.3 |  |  | $ | 1.5 |  |

[0001069202-16-000024:notes:93]
[same as prior period, unchanged from 0001069202-16-000020:notes:93]

[0001069202-16-000024:notes:94]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amount of Loss reclassified from AOCL into Income (effective portion) (1) |  | $ | 2.4 |  |  | $ | 3.2 |  |  | $ | 10.6 |  |  | $ | 9.4 |  |
| Amount of Loss recognized in Net income (ineffective portion) (2) |  | $ | (0.5 | ) |  | $ | — |  |  | $ | (0.4 | ) |  | $ | — |  |

[0001069202-16-000024:notes:95]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | (0.3 | ) |  | $ | 1.4 |  |  | $ | (0.2 | ) |  | $ | 2.2 |  |
| Foreign currency forward contracts (2) |  | 0.4 |  |  | — |  |  | 0.3 |  |  | 0.2 |  |
|  |  | $ | 0.1 |  |  | $ | 1.4 |  |  | $ | 0.1 |  |  | $ | 2.4 |  |

[0001069202-16-000024:notes:96]
[same as prior period, unchanged from 0001069202-16-000020:notes:96]

[0001069202-16-000024:notes:97]
[same as prior period, unchanged from 0001069202-16-000020:notes:97]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-16-000024:notes:98]
[same as prior period, unchanged from 0001069202-16-000020:notes:98]

[0001069202-16-000024:notes:99]
[same as prior period, unchanged from 0001069202-16-000020:notes:99]

[0001069202-16-000024:notes:100]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Stock-based compensation expense (1) | $ | 9.9 |  |  | $ | 7.7 |  |  | $ | 24.8 |  |  | $ | 18.5 |  |

[0001069202-16-000024:notes:101]
[same as prior period, unchanged from 0001069202-16-000020:notes:101]


## us-gaap:EarningsPerShareTextBlock

[0001069202-16-000024:notes:102]
[same as prior period, unchanged from 0001069202-16-000020:notes:102]

[0001069202-16-000024:notes:103]
[same as prior period, unchanged from 0001069202-16-000020:notes:103]

[0001069202-16-000024:notes:104]
[same as prior period, unchanged from 0001069202-16-000020:notes:104]

[0001069202-16-000024:notes:105]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net income | $ | 101.7 |  |  | $ | 80.3 |  |  | $ | 237.3 |  |  | $ | 175.3 |  |
| Add: Loss from discontinued operations | — |  |  | — |  |  | 0.6 |  |  | 0.5 |  |
| Income from continuing operations | $ | 101.7 |  |  | $ | 80.3 |  |  | $ | 237.9 |  |  | $ | 175.8 |  |
| Weighted-average shares outstanding – basic | 43.2 |  |  | 45.0 |  |  | 43.6 |  |  | 44.9 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.5 |  |  | 0.6 |  |  | 0.6 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 43.7 |  |  | 45.6 |  |  | 44.2 |  |  | 45.6 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.35 |  |  | $ | 1.78 |  |  | $ | 5.46 |  |  | $ | 3.92 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01 | ) |  | (0.01 | ) |
| Net income | $ | 2.35 |  |  | $ | 1.78 |  |  | $ | 5.45 |  |  | $ | 3.91 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.33 |  |  | $ | 1.76 |  |  | $ | 5.39 |  |  | $ | 3.86 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01 | ) |  | (0.01 | ) |
| Net income | $ | 2.33 |  |  | $ | 1.76 |  |  | $ | 5.38 |  |  | $ | 3.85 |  |

[0001069202-16-000024:notes:106]
[same as prior period, unchanged from 0001069202-16-000020:notes:106]

[0001069202-16-000024:notes:107]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Weighted-average number of shares | — |  |  | — |  |  | 0.2 |  |  | 0.2 |  |
| Price range per share | $ | — |  |  | $ | — |  |  | $124.97-$131.94 |  |  | $ | 92.64 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-16-000024:notes:108]
[same as prior period, unchanged from 0001069202-16-000020:notes:108]

[0001069202-16-000024:notes:109]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Senior unsecured notes | $ | 207.2 |  |  | $ | 207.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-16-000024:notes:110]
[same as prior period, unchanged from 0001069202-16-000020:notes:110]

[0001069202-16-000024:notes:111]
[same as prior period, unchanged from 0001069202-16-000020:notes:111]

[0001069202-16-000024:notes:112]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2016 were the same as those used at December 31, 2015.

[0001069202-16-000024:notes:113]
[same as prior period, unchanged from 0001069202-16-000020:notes:113]

[0001069202-16-000024:notes:114]
[same as prior period, unchanged from 0001069202-16-000020:notes:114]

[0001069202-16-000024:notes:115]
[same as prior period, unchanged from 0001069202-16-000020:notes:115]

[0001069202-16-000024:notes:116]
[same as prior period, unchanged from 0001069202-16-000020:notes:116]

[0001069202-16-000024:notes:117]
[same as prior period, unchanged from 0001069202-16-000020:notes:117]

[0001069202-16-000024:notes:118]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Investment in marketable equity securities | $ | 4.6 |  |  | $ | 6.5 |  |

[0001069202-16-000024:notes:119]
[same as prior period, unchanged from 0001069202-16-000020:notes:119]

[0001069202-16-000024:notes:120]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-16-000024:notes:121]
[same as prior period, unchanged from 0001069202-16-000020:notes:121]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-16-000024:notes:122]
[same as prior period, unchanged from 0001069202-16-000020:notes:122]

[0001069202-16-000024:notes:123]
The changes in the carrying amount of goodwill for the first nine months of 2016, in total and by segment, are summarized in the table below (in millions):

[0001069202-16-000024:notes:124]
|  | Balance at December 31, 2015 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at September 30, 2016 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 60.6 |  |  | — |  |  | 0.5 |  |  | 61.1 |  |
| Refrigeration | 108.4 |  |  | — |  |  | 2.9 |  |  | 111.3 |  |
| Total Goodwill | $ | 195.1 |  |  | $ | — |  |  | $ | 3.4 |  |  | $ | 198.5 |  |

[0001069202-16-000024:notes:125]
[same as prior period, unchanged from 0001069202-16-000020:notes:125]

[0001069202-16-000024:notes:126]
We performed our annual goodwill impairment test in the fourth quarter of  2015 and recorded a $5.5 million goodwill impairment charge.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We will perform our annual goodwill assessment in the fourth quarter of 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-16-000024:notes:127]
[same as prior period, unchanged from 0001069202-16-000020:notes:127]

[0001069202-16-000024:notes:128]
As of September 30, 2016, we had approximately$0.8 million in total gross unrecognized tax benefits. Of this amount,$0.8 million, if recognized, would be recorded through the Consolidated Statement of Operations.

[0001069202-16-000024:notes:129]
[same as prior period, unchanged from 0001069202-16-000020:notes:129]

[0001069202-16-000024:notes:130]
Since January 1, 2016, numerous states, including Delaware, North Carolina and the District of Columbia, have enacted legislation effective for tax years beginning on or after January 1, 2016, including changes to apportionment methodologies and tax rates.  The impact of these changes is immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-16-000024:notes:131]
[same as prior period, unchanged from 0001069202-16-000020:notes:131]

[0001069202-16-000024:notes:132]
[same as prior period, unchanged from 0001069202-16-000020:notes:132]

[0001069202-16-000024:notes:133]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Finished goods | $ | 335.5 |  |  | $ | 300.0 |  |
| Work in process | 6.8 |  |  | 4.2 |  |
| Raw materials and parts | 193.8 |  |  | 178.3 |  |
| Subtotal | 536.1 |  |  | 482.5 |  |
| Excess of current cost over last-in, first-out cost | (62.1 | ) |  | (63.7 | ) |
| Total inventories, net | $ | 474.0 |  |  | $ | 418.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-16-000024:notes:134]
[same as prior period, unchanged from 0001069202-16-000020:notes:134]

[0001069202-16-000024:notes:135]
[same as prior period, unchanged from 0001069202-16-000020:notes:135]

[0001069202-16-000024:notes:136]
[same as prior period, unchanged from 0001069202-16-000020:notes:136]

[0001069202-16-000024:notes:137]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-16-000024:notes:138]
[same as prior period, unchanged from 0001069202-16-000020:notes:138]

[0001069202-16-000024:notes:139]
[same as prior period, unchanged from 0001069202-16-000020:notes:139]

[0001069202-16-000024:notes:140]
[same as prior period, unchanged from 0001069202-16-000020:notes:140]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-16-000024:notes:141]
[same as prior period, unchanged from 0001069202-16-000020:notes:141]

[0001069202-16-000024:notes:142]
[same as prior period, unchanged from 0001069202-16-000020:notes:142]

[0001069202-16-000024:notes:143]
|  | For the Three Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.1 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.8 |  |  | 4.3 |  |  | — |  |  | 0.1 |  |
| Expected return on plan assets | (5.4 | ) |  | (5.3 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | — |  |  | (0.8 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 1.9 |  |  | 2.4 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | 0.2 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.7 |  |  | $ | 2.6 |  |  | $ | (0.4 | ) |  | $ | (0.3 | ) |

[0001069202-16-000024:notes:144]
|  | For the Nine Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 3.3 |  |  | $ | 3.6 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 11.5 |  |  | 12.9 |  |  | 0.1 |  |  | 0.2 |  |
| Expected return on plan assets | (16.2 | ) |  | (16.0 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.2 |  |  | — |  |  | (2.3 | ) |  | (2.4 | ) |
| Recognized actuarial loss | 5.7 |  |  | 7.2 |  |  | 1.1 |  |  | 1.2 |  |
| Settlements and curtailments | 0.2 |  |  | 0.4 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 4.7 |  |  | $ | 8.1 |  |  | $ | (1.1 | ) |  | $ | (1.0 | ) |

[0001069202-16-000024:notes:145]
(1) All net periodic benefit cost for the three and nine months ended September 30, 2016 and 2015 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-16-000024:notes:146]
[same as prior period, unchanged from 0001069202-16-000020:notes:146]

[0001069202-16-000024:notes:147]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 572.7 |  |  | $ | 517.9 |  |  | $ | 1,524.5 |  |  | $ | 1,435.6 |  |
| Commercial Heating & Cooling | 251.4 |  |  | 246.8 |  |  | 674.7 |  |  | 660.3 |  |
| Refrigeration | 185.9 |  |  | 190.3 |  |  | 545.2 |  |  | 537.4 |  |
|  | $ | 1,010.0 |  |  | $ | 955.0 |  |  | $ | 2,744.4 |  |  | $ | 2,633.3 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 112.7 |  |  | $ | 90.1 |  |  | $ | 266.9 |  |  | $ | 221.3 |  |
| Commercial Heating & Cooling | 48.9 |  |  | 44.8 |  |  | 110.6 |  |  | 95.5 |  |
| Refrigeration | 22.9 |  |  | 20.3 |  |  | 53.2 |  |  | 37.5 |  |
| Corporate and other | (27.3 | ) |  | (24.0 | ) |  | (65.7 | ) |  | (57.4 | ) |
| Total segment profit | 157.2 |  |  | 131.2 |  |  | 365.0 |  |  | 296.9 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special product quality adjustments | — |  |  | 0.7 |  |  | (0.4 | ) |  | (0.6 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | (0.3 | ) |  | 3.9 |  |  | 2.9 |  |  | 10.8 |  |
| Restructuring charges (gains) | 0.6 |  |  | (0.4 | ) |  | 1.2 |  |  | 1.8 |  |
| Operating income | $ | 156.9 |  |  | $ | 127.0 |  |  | $ | 361.3 |  |  | $ | 284.9 |  |

[0001069202-16-000024:notes:148]
[same as prior period, unchanged from 0001069202-16-000020:notes:148]

[0001069202-16-000024:notes:149]
[same as prior period, unchanged from 0001069202-16-000020:notes:149]

[0001069202-16-000024:notes:150]
[same as prior period, unchanged from 0001069202-16-000020:notes:150]

[0001069202-16-000024:notes:151]
[same as prior period, unchanged from 0001069202-16-000020:notes:151]

[0001069202-16-000024:notes:152]
| ◦ | Special legal contingency charges, |

[0001069202-16-000024:notes:153]
| ◦ | Asbestos-related litigation, |

[0001069202-16-000024:notes:154]
[same as prior period, unchanged from 0001069202-16-000020:notes:154]

[0001069202-16-000024:notes:155]
[same as prior period, unchanged from 0001069202-16-000020:notes:155]

[0001069202-16-000024:notes:156]
[same as prior period, unchanged from 0001069202-16-000020:notes:156]

[0001069202-16-000024:notes:157]
[same as prior period, unchanged from 0001069202-16-000020:notes:157]

[0001069202-16-000024:notes:158]
[same as prior period, unchanged from 0001069202-16-000020:notes:158]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-16-000024:notes:159]
[same as prior period, unchanged from 0001069202-16-000020:notes:159]

[0001069202-16-000024:notes:160]
[same as prior period, unchanged from 0001069202-16-000020:notes:160]

[0001069202-16-000024:notes:161]
[same as prior period, unchanged from 0001069202-16-000020:notes:161]

[0001069202-16-000024:notes:162]
Information regarding the restructuring charges for all ongoing activities is presented in the following table (in millions):

[0001069202-16-000024:notes:163]
|  | Charges Incurred in 2016 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related (gains) expense | $ | (0.3 | ) |  | $ | 9.2 |  |  | $ | 9.2 |  |
| Asset write-offs and accelerated depreciation | 0.2 |  |  | 2.3 |  |  | 2.3 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | 0.2 |  |  | 0.2 |  |
| Other | 1.3 |  |  | 3.3 |  |  | 4.1 |  |
| Total restructuring charges | $ | 1.2 |  |  | $ | 15.0 |  |  | $ | 15.8 |  |

[0001069202-16-000024:notes:164]
[same as prior period, unchanged from 0001069202-16-000020:notes:164]

[0001069202-16-000024:notes:165]
|  | Charges Incurred in 2016 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | (0.2 | ) |  | 11.8 |  |  | 11.8 |  |
| Corporate & Other | 1.4 |  |  | 1.4 |  |  | 2.2 |  |
| Total restructuring charges | $ | 1.2 |  |  | $ | 15.0 |  |  | $ | 15.8 |  |

[0001069202-16-000024:notes:166]
[same as prior period, unchanged from 0001069202-16-000020:notes:166]

[0001069202-16-000024:notes:167]
|  | Balance as ofDecember 31, 2015 |  | Included inEarnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of September 30, 2016 |
| Severance and related expense | $ | 0.7 |  |  | $ | (0.3 | ) |  | $ | (0.4 | ) |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.2 |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | 0.2 |  |  | — |  |  | — |  |  |  |  |  | 0.2 |  |
| Other | — |  |  | 1.3 |  |  | (1.5 | ) |  | — |  |  | (0.2 | ) |
| Total restructuring accruals | $ | 0.9 |  |  | $ | 1.2 |  |  | $ | (2.0 | ) |  | $ | — |  |  | $ | 0.1 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001069202-16-000024:notes:168]
[same as prior period, unchanged from 0001069202-16-000020:notes:168]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-16-000024:notes:169]
[same as prior period, unchanged from 0001069202-16-000020:notes:169]

[0001069202-16-000024:notes:170]
[same as prior period, unchanged from 0001069202-16-000020:notes:170]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-16-000024:notes:171]
[same as prior period, unchanged from 0001069202-16-000020:notes:171]

[0001069202-16-000024:notes:172]
[same as prior period, unchanged from 0001069202-16-000020:notes:172]

[0001069202-16-000024:notes:173]
[same as prior period, unchanged from 0001069202-16-000020:notes:173]

[0001069202-16-000024:notes:174]
[same as prior period, unchanged from 0001069202-16-000020:notes:174]

[0001069202-16-000024:notes:175]
[same as prior period, unchanged from 0001069202-16-000020:notes:175]

[0001069202-16-000024:notes:176]
[same as prior period, unchanged from 0001069202-16-000020:notes:176]

[0001069202-16-000024:notes:177]
[same as prior period, unchanged from 0001069202-16-000020:notes:177]

[0001069202-16-000024:notes:178]
[same as prior period, unchanged from 0001069202-16-000020:notes:178]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-16-000024:notes:179]
[same as prior period, unchanged from 0001069202-16-000020:notes:179]

[0001069202-16-000024:notes:180]
Our Board of Directors has authorized a total of $1.4 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first nine months of 2016. As of September 30, 2016, $96.2 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-16-000024:notes:181]
On February 10, 2016, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “First ASR Agreement”) with Merrill Lynch International (“Merrill Lynch”), acting through its agent, Merrill Lynch, Pierce, Fenner and Smith Incorporated to effect an accelerated stock buyback of the Company’s common stock (the “Common Stock”).

[0001069202-16-000024:notes:182]
Under the First ASR Agreement, on February 10, 2016, the Company paid Merrill Lynch an initial purchase price of $200 million, and Merrill Lynch delivered to the Company a total of 1.3 million shares of Common Stock, representing approximately 75% of the shares expected to be purchased under the ASR Agreement. The First ASR Agreement was completed in the third quarter and Merrill Lynch delivered an additional 0.2 million shares of Common Stock to the Company.

[0001069202-16-000024:notes:183]
On August 1, 2016, the Company entered into another Fixed Dollar ASR Agreement (the "Second ASR Agreement) with Wells Fargo to effect an accelerated stock buyback of Common Stock.

[0001069202-16-000024:notes:184]
Under the Second ASR Agreement, on August 1, 2016, the Company paid Wells Fargo an initial purchase price of $100 million, and Wells Fargo delivered to the Company a total of 0.5 million shares of Common Stock, representing approximately 75% of the shares expected to be purchased under the Second ASR Agreement. The Second ASR Agreement will be completed in the fourth quarter.

[0001069202-16-000024:notes:185]
We also repurchased 0.2 million shares for $26.3 million for the nine months ended September 30, 2016 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
