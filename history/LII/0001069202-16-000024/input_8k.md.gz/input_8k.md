# LII 8-K — 0001193125-16-739148 filed 2016-10-17

## item codes, every 8-K on or before 2016-10-17

- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2016-10-17

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-739148:8k_2_02:1]
EX-99.1
2
d272359dex991.htm
EX-99.1

[0001193125-16-739148:8k_2_02:2]
EX-99.1

[0001193125-16-739148:8k_2_02:3]
Exhibit 99.1

[0001193125-16-739148:8k_2_02:4]
Lennox International Reports Record Third-Quarter Profit

[0001193125-16-739148:8k_2_02:5]
| • |  | Revenue up 6%, led by 11% growth in Residential |

[0001193125-16-739148:8k_2_02:6]
| • |  | GAAP EPS from continuing operations up 32% to third-quarter record $2.33 |

[0001193125-16-739148:8k_2_02:7]
| • |  | Adjusted EPS from continuing operations up 28% to third-quarter record $2.33 |

[0001193125-16-739148:8k_2_02:8]
| • |  | Narrowing 2016 revenue growth guidance from 3-7% to 4-6% |

[0001193125-16-739148:8k_2_02:9]
| • |  | Updating 2016 GAAP EPS from continuing operations guidance from $6.45-$6.85 to $6.25-$6.45, including the expected impact from a one-time, non-cash charge for a lump-sum pension buyout program |

[0001193125-16-739148:8k_2_02:10]
| • |  | Raising 2016 adjusted EPS from continuing operations guidance from $6.50-$6.90 to $6.75-$6.95 |

[0001193125-16-739148:8k_2_02:11]
| • |  | Previously announced $100 million stock repurchase program to be concluded in the fourth quarter for a total of $300 million of stock repurchases in 2016 |

[0001193125-16-739148:8k_2_02:12]
DALLAS, October 17, 2016 – Lennox International Inc. (NYSE: LII) today reported financial results for the third quarter of 2016. All comparisons are
against the prior-year quarter unless otherwise noted.

[0001193125-16-739148:8k_2_02:13]
Revenue for the third quarter was $1.01 billion, up 6%. Foreign exchange was neutral to revenue in
the quarter. GAAP operating income increased 24% to a third-quarter record $157 million. GAAP earnings per share from continuing operations was a third-quarter record $2.33, up 32%. Adjusted earnings per share from continuing operations was a
third-quarter record $2.33, up 28%.

[0001193125-16-739148:8k_2_02:14]
“Lennox International set new third-quarter records for operating margin and profit on strong revenue growth,
led by our Residential business,” said Chairman and CEO Todd Bluedorn. “We continued to drive significant margin expansion across all three of our businesses in the third quarter. Overall, total segment profit margin rose 190 basis points
to a third-quarter record 15.6%.

[0001193125-16-739148:8k_2_02:15]
“Our Residential business set third-quarter records for sales, margin and profit. Residential revenue was up 11% on
strength in both replacement and new construction business. Residential profit rose 25% as segment margin expanded 230 basis points to 19.7%. Our Commercial business established new highs for margin and profit on 2% revenue growth. Commercial profit
rose 9%, and segment margin expanded 130 basis points to 19.5%. In Refrigeration, profit rose 13% as segment margin expanded 160 basis points to 12.3%. Refrigeration revenue was down 2%, primarily on the timing of national account business and soft
market conditions in Europe.”

[0001193125-16-739148:8k_2_02:16]
Looking ahead for the company overall, Bluedorn said, “As part of our ongoing strategy to de-risk the
company’s pension plan obligations, we expect to complete a one-time, lump sum pension buyout in the fourth quarter for certain vested participants. This action is expected to reduce the company’s pension obligations by approximately $50
million. We expect to take a non-cash charge of approximately $20 million after-tax, and our updated 2016 guidance for GAAP EPS from continuing operations incorporates this.

[0001193125-16-739148:8k_2_02:17]
“For adjusted EPS from continuing operations, we are raising 2016 guidance based on the company’s
strong operational performance and outlook, and we continue to expect strong margin expansion and profit growth as momentum continues.”

[0001193125-16-739148:8k_2_02:18]
FINANCIAL
HIGHLIGHTS

[0001193125-16-739148:8k_2_02:19]
Revenue: Revenue for the third quarter was $1.01 billion, up 6%. Foreign exchange was neutral to revenue. Volume and price/mix were
up on a revenue basis.

[0001193125-16-739148:8k_2_02:20]
Gross Profit: Gross profit in the third quarter was $310 million, up 13%. Gross margin was 30.7%, up 210 basis points.
Gross profit was positively impacted by higher volume, higher factory productivity, and lower material costs, with partial offsets from investments in distribution expansion and other product costs.

[0001193125-16-739148:8k_2_02:21]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the third quarter was $101.7 million, or $2.33 per share,
compared to $80.3 million, or $1.76 per share, in the prior-year quarter.

[0001193125-16-739148:8k_2_02:22]
Adjusted income from continuing operations in the third quarter was $101.9
million, or $2.33 per share, compared to $83.2 million, or $1.82 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the third quarter of 2016 excludes $0.2 million in net after-tax charges: a $0.7 million gain for
the net change in unrealized gains on unsettled future contracts, a charge of $0.4 million for restructuring activities, and charges of $0.5 million for other items, net.

[0001193125-16-739148:8k_2_02:23]
Free Cash Flow and Total Debt: In the third quarter, net cash from operations was $148 million, capital expenditures totaled $18 million, and free cash
flow was $130 million. This includes a $50 million use of cash for a discretionary pension contribution. In the prior-year quarter, net cash from operations was $159 million, capital expenditures totaled $14 million, and free cash flow was $145
million. Total debt at the end of the third quarter was $1.06 billion. Total cash and cash equivalents were $48 million at the end of the quarter. The company paid $19 million in dividends in the third quarter and paid $100 million in conjunction
with an accelerated share repurchase program over the third and fourth quarters.

[0001193125-16-739148:8k_2_02:24]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-16-739148:8k_2_02:25]
Residential Heating & Cooling

[0001193125-16-739148:8k_2_02:26]
Revenue in the
Residential Heating & Cooling business segment was a third-quarter record $573 million, up 11%. Foreign exchange was neutral to revenue. Segment profit was a third-quarter record $113 million, up 25%. Segment profit margin was a
third-quarter record 19.7%, up 230 basis points. Results were impacted by higher volume, favorable price/mix, lower material costs, and higher factory productivity, with partial offsets from investments in SG&A, distribution expansion, and other
product costs.

[0001193125-16-739148:8k_2_02:27]
Commercial Heating & Cooling

[0001193125-16-739148:8k_2_02:28]
Revenue in the Commercial Heating & Cooling business segment was $251 million in the third quarter, up 2%. Foreign exchange was neutral to revenue.
Segment profit was a record $49 million, up 9%. Segment profit margin was a record 19.5%, up 130 basis points. Results were impacted by higher volume, lower material costs, and lower freight costs, with partial offsets from factory productivity and
other product costs, and investments in SG&A.

[0001193125-16-739148:8k_2_02:29]
Refrigeration

[0001193125-16-739148:8k_2_02:30]
Revenue in the Refrigeration business segment was $186 million in the third quarter, down 2%. Foreign exchange was neutral to revenue. Segment profit was $23
million, up 13%. Segment profit margin was 12.3%, up 160 basis points. Results were impacted by lower material costs, lower factory costs and higher productivity, with partial offsets from lower volume, unfavorable price/mix, unfavorable foreign
exchange, and higher SG&A.

[0001193125-16-739148:8k_2_02:31]
FULL-YEAR OUTLOOK

[0001193125-16-739148:8k_2_02:32]
For 2016, the company is updating guidance for revenue growth and EPS from continuing operations.

[0001193125-16-739148:8k_2_02:33]
|  | • |  | Narrowing guidance for 2016 revenue growth from 3-7% to 4-6%. The company still expects foreign exchange to be neutral to revenue on a full-year basis. |

[0001193125-16-739148:8k_2_02:34]
|  | • |  | Updating guidance for 2016 GAAP EPS from continuing operations from $6.45-$6.85 to a range of $6.25-$6.45, including special items to-date and the approximate $20 million after-tax ($30 million pre-tax) pension charge expected in the fourth quarter as a result of the one-time, lump-sum pension buyout program to certain vested participants. |

[0001193125-16-739148:8k_2_02:35]
|  | • |  | Raising guidance for 2016 adjusted EPS from continuing operations from $6.50-$6.90 to a range of $6.75-$6.95. |

[0001193125-16-739148:8k_2_02:36]
|  | • |  | Reiterating effective tax rate guidance of approximately 31% on a full-year basis for 2016 and 32% for future years. |

[0001193125-16-739148:8k_2_02:37]
|  | • |  | Reiterating fully diluted share count guidance of approximately 44 million shares on a full-year basis. |

[0001193125-16-739148:8k_2_02:38]
|  | • |  | Reiterating 2016 capital expenditure guidance of approximately $95 million. |

[0001193125-16-739148:8k_2_02:39]
CONFERENCE CALL INFORMATION

[0001193125-16-739148:8k_2_02:40]
A conference call to discuss the company’s third-quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call
line at 612-288-0340 at least 10 minutes prior to the scheduled start time and use reservation number 403686. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available
from 11:00 a.m. Central time on October 17 through midnight October 31, 2016 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 403686. The call also will be archived on the company’s web site.

[0001193125-16-739148:8k_2_02:41]
About Lennox International

[0001193125-16-739148:8k_2_02:42]
Lennox International Inc. is
a global leader in the heating, air conditioning, and refrigeration markets. Lennox International is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at:
www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-16-739148:8k_2_02:43]
Forward-Looking Statements

[0001193125-16-739148:8k_2_02:44]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-739148:8k_2_02:45]
Consolidated Statements of Operations

[0001193125-16-739148:8k_2_02:46]
(Unaudited)

[0001193125-16-739148:8k_2_02:47]
|  |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
| (Amounts in millions, except per share data) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 1,010.0 |  |  | $ | 955.0 |  |  | $ | 2,744.4 |  |  | $ | 2,633.3 |  |
| Cost of goods sold |  |  | 699.7 |  |  |  | 681.6 |  |  |  | 1,935.5 |  |  |  | 1,913.5 |  |
| Gross profit |  |  | 310.3 |  |  |  | 273.4 |  |  |  | 808.9 |  |  |  | 719.8 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 156.5 |  |  |  | 143.8 |  |  |  | 456.2 |  |  |  | 430.0 |  |
| Losses and other expenses, net |  |  | 0.7 |  |  |  | 6.0 |  |  |  | 5.5 |  |  |  | 14.9 |  |
| Restructuring charges (gains) |  |  | 0.6 |  |  |  | (0.4 | ) |  |  | 1.2 |  |  |  | 1.8 |  |
| Income from equity method investments |  |  | (4.4 | ) |  |  | (3.0 | ) |  |  | (15.3 | ) |  |  | (11.8 | ) |
| Operating income |  |  | 156.9 |  |  |  | 127.0 |  |  |  | 361.3 |  |  |  | 284.9 |  |
| Interest expense, net |  |  | 7.0 |  |  |  | 5.7 |  |  |  | 19.6 |  |  |  | 17.9 |  |
| Other income, net |  |  | — |  |  |  | (0.7 | ) |  |  | (0.2 | ) |  |  | (0.7 | ) |
| Income from continuing operations before income taxes |  |  | 149.9 |  |  |  | 122.0 |  |  |  | 341.9 |  |  |  | 267.7 |  |
| Provision for income taxes |  |  | 48.2 |  |  |  | 41.7 |  |  |  | 104.0 |  |  |  | 91.9 |  |
| Income from continuing operations |  |  | 101.7 |  |  |  | 80.3 |  |  |  | 237.9 |  |  |  | 175.8 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | — |  |  |  | — |  |  |  | (0.9 | ) |  |  | (0.9 | ) |
| Benefit from income taxes |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |  |  | (0.4 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | (0.6 | ) |  |  | (0.5 | ) |
| Net income |  | $ | 101.7 |  |  | $ | 80.3 |  |  | $ | 237.3 |  |  | $ | 175.3 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.35 |  |  | $ | 1.78 |  |  | $ | 5.46 |  |  | $ | 3.92 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | (0.01 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 2.35 |  |  | $ | 1.78 |  |  | $ | 5.45 |  |  | $ | 3.91 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.33 |  |  | $ | 1.76 |  |  | $ | 5.39 |  |  | $ | 3.86 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | (0.01 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 2.33 |  |  | $ | 1.76 |  |  | $ | 5.38 |  |  | $ | 3.85 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 43.2 |  |  |  | 45.0 |  |  |  | 43.6 |  |  |  | 44.9 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 43.7 |  |  |  | 45.6 |  |  |  | 44.2 |  |  |  | 45.6 |  |
| Cash dividends declared per share |  | $ | 0.43 |  |  | $ | 0.36 |  |  | $ | 1.22 |  |  | $ | 1.02 |  |

[0001193125-16-739148:8k_2_02:48]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-739148:8k_2_02:49]
Segment Net Sales and Profit (Loss)

[0001193125-16-739148:8k_2_02:50]
(Unaudited)

[0001193125-16-739148:8k_2_02:51]
|  |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
| (Amounts in millions) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 572.7 |  |  | $ | 517.9 |  |  | $ | 1,524.5 |  |  | $ | 1,435.6 |  |
| Commercial Heating & Cooling |  |  | 251.4 |  |  |  | 246.8 |  |  |  | 674.7 |  |  |  | 660.3 |  |
| Refrigeration |  |  | 185.9 |  |  |  | 190.3 |  |  |  | 545.2 |  |  |  | 537.4 |  |
|  |  | $ | 1,010.0 |  |  | $ | 955.0 |  |  | $ | 2,744.4 |  |  | $ | 2,633.3 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 112.7 |  |  | $ | 90.1 |  |  | $ | 266.9 |  |  | $ | 221.3 |  |
| Commercial Heating & Cooling |  |  | 48.9 |  |  |  | 44.8 |  |  |  | 110.6 |  |  |  | 95.5 |  |
| Refrigeration |  |  | 22.9 |  |  |  | 20.3 |  |  |  | 53.2 |  |  |  | 37.5 |  |
| Corporate and other |  |  | (27.3 | ) |  |  | (24.0 | ) |  |  | (65.7 | ) |  |  | (57.4 | ) |
| Total segment profit |  |  | 157.2 |  |  |  | 131.2 |  |  |  | 365.0 |  |  |  | 296.9 |  |
| Reconciliation to operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | — |  |  |  | 0.7 |  |  |  | (0.4 | ) |  |  | (0.6 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) |  |  | (0.3 | ) |  |  | 3.9 |  |  |  | 2.9 |  |  |  | 10.8 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | (0.4 | ) |  |  | 1.2 |  |  |  | 1.8 |  |
| Operating income |  | $ | 156.9 |  |  | $ | 127.0 |  |  | $ | 361.3 |  |  | $ | 284.9 |  |

[0001193125-16-739148:8k_2_02:52]
| (1) | The Company defines segment profit and loss as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-16-739148:8k_2_02:53]
|  | • |  | Special product quality adjustments; |

[0001193125-16-739148:8k_2_02:54]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-16-739148:8k_2_02:55]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-16-739148:8k_2_02:56]
|  | • |  | Special legal contingency charges, |

[0001193125-16-739148:8k_2_02:57]
|  | • |  | Asbestos-related litigation, |

[0001193125-16-739148:8k_2_02:58]
|  | • |  | Contractor tax payments, |

[0001193125-16-739148:8k_2_02:59]
|  | • |  | Environmental liabilities, and |

[0001193125-16-739148:8k_2_02:60]
|  | • |  | Other items, net; |

[0001193125-16-739148:8k_2_02:61]
|  | • |  | Restructuring charges; and, |

[0001193125-16-739148:8k_2_02:62]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments. |

[0001193125-16-739148:8k_2_02:63]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-739148:8k_2_02:64]
Consolidated Balance Sheets

[0001193125-16-739148:8k_2_02:65]
|  |  | As of September |  |  | As of December |  |
| (Amounts in millions, except shares and par values) |  | 30, 2016 |  |  | 31, 2015 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 47.8 |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net of allowances of $7.7 and $6.3 in 2016 and 2015, respectively |  |  | 570.4 |  |  |  | 422.8 |  |
| Inventories, net |  |  | 474.0 |  |  |  | 418.8 |  |
| Other assets |  |  | 74.3 |  |  |  | 57.7 |  |
| Total current assets |  |  | 1,166.5 |  |  |  | 938.2 |  |
| Property, plant and equipment, net of accumulated depreciation of $718 and $682.9 in 2016 and 2015, respectively |  |  | 346.2 |  |  |  | 339.6 |  |
| Goodwill |  |  | 198.5 |  |  |  | 195.1 |  |
| Deferred income taxes |  |  | 147.4 |  |  |  | 145.7 |  |
| Other assets, net |  |  | 68.0 |  |  |  | 58.8 |  |
| Total assets |  | $ | 1,926.6 |  |  | $ | 1,677.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 327.8 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt |  |  | 215.6 |  |  |  | 31.0 |  |
| Accounts payable |  |  | 371.7 |  |  |  | 320.1 |  |
| Accrued expenses |  |  | 272.2 |  |  |  | 242.6 |  |
| Income taxes payable |  |  | 0.8 |  |  |  | 26.0 |  |
| Total current liabilities |  |  | 1,188.1 |  |  |  | 823.8 |  |
| Long-term debt |  |  | 512.5 |  |  |  | 506.0 |  |
| Post-retirement benefits, other than pensions |  |  | 2.2 |  |  |  | 4.1 |  |
| Pensions |  |  | 72.9 |  |  |  | 120.8 |  |
| Other liabilities |  |  | 126.7 |  |  |  | 121.1 |  |
| Total liabilities |  |  | 1,902.4 |  |  |  | 1,575.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,017.5 |  |  |  | 1,002.4 |  |
| Retained earnings |  |  | 1,331.1 |  |  |  | 1,146.7 |  |
| Accumulated other comprehensive loss |  |  | (187.0 | ) |  |  | (204.7 | ) |
| Treasury stock, at cost, 44,126,432 shares and 42,491,910 shares as of September 30, 2016 and December 31, 2015, respectively |  |  | (2,138.7 | ) |  |  | (1,844.1 | ) |
| Noncontrolling interests |  |  | 0.4 |  |  |  | 0.4 |  |
| Total stockholders’ equity |  |  | 24.2 |  |  |  | 101.6 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,926.6 |  |  | $ | 1,677.4 |  |

[0001193125-16-739148:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-739148:8k_2_02:67]
Consolidated Statements of Cash Flows

[0001193125-16-739148:8k_2_02:68]
(Unaudited)

[0001193125-16-739148:8k_2_02:69]
|  |  | For the Nine Months Ended |  |
|  |  | September 30, |  |
| (Amounts in millions) |  | 2016 |  |  | 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 237.3 |  |  | $ | 175.3 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (15.3 | ) |  |  | (11.8 | ) |
| Dividends from affiliates |  |  | 3.9 |  |  |  | 7.4 |  |
| Restructuring (gains) expenses, net of cash paid |  |  | (0.8 | ) |  |  | (0.2 | ) |
| Provision for bad debts |  |  | 3.4 |  |  |  | 2.1 |  |
| Unrealized (gains) losses on derivative contracts |  |  | (2.2 | ) |  |  | 1.3 |  |
| Stock-based compensation expense |  |  | 24.8 |  |  |  | 18.5 |  |
| Depreciation and amortization |  |  | 43.4 |  |  |  | 46.6 |  |
| Deferred income taxes |  |  | (2.6 | ) |  |  | (0.2 | ) |
| Pension expense |  |  | 4.8 |  |  |  | 8.1 |  |
| Pension contributions |  |  | (52.6 | ) |  |  | (3.8 | ) |
| Other items, net |  |  | 0.4 |  |  |  | 0.3 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (146.2 | ) |  |  | (135.9 | ) |
| Inventories |  |  | (49.9 | ) |  |  | (41.0 | ) |
| Other current assets |  |  | (6.6 | ) |  |  | (2.8 | ) |
| Accounts payable |  |  | 56.4 |  |  |  | 23.4 |  |
| Accrued expenses |  |  | 40.7 |  |  |  | 15.1 |  |
| Income taxes payable and receivable |  |  | (35.0 | ) |  |  | (0.9 | ) |
| Other |  |  | 3.0 |  |  |  | 5.4 |  |
| Net cash provided by operating activities |  |  | 106.9 |  |  |  | 106.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (59.4 | ) |  |  | (47.0 | ) |
| Net cash used in investing activities |  |  | (59.4 | ) |  |  | (47.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (2.1 | ) |  |  | 0.8 |  |
| Asset securitization borrowings |  |  | 145.0 |  |  |  | 40.0 |  |
| Asset securitization payments |  |  | (20.0 | ) |  |  | (40.0 | ) |
| Long-term debt payments |  |  | (30.9 | ) |  |  | (23.5 | ) |
| Borrowings from credit facility |  |  | 1,715.0 |  |  |  | 1,401.0 |  |
| Payments on credit facility |  |  | (1,493.0 | ) |  |  | (1,385.0 | ) |
| Payments of deferred financing costs |  |  | (0.9 | ) |  |  | — |  |
| Proceeds from employee stock purchases |  |  | 1.9 |  |  |  | 1.8 |  |
| Repurchases of common stock |  |  | (300.0 | ) |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (26.3 | ) |  |  | (23.5 | ) |
| Excess tax benefits related to share-based payments |  |  | 20.0 |  |  |  | 18.6 |  |
| Cash dividends paid |  |  | (50.5 | ) |  |  | (43.1 | ) |
| Net cash used in financing activities |  |  | (41.8 | ) |  |  | (52.9 | ) |
| Increase in cash and cash equivalents |  |  | 5.7 |  |  |  | 7.0 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | 3.2 |  |  |  | (9.4 | ) |
| Cash and cash equivalents, beginning of period |  |  | 38.9 |  |  |  | 37.5 |  |
| Cash and cash equivalents, end of period |  | $ | 47.8 |  |  | $ | 35.1 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 17.0 |  |  | $ | 15.9 |  |
| Income taxes paid (net of refunds) |  | $ | 120.9 |  |  | $ | 73.4 |  |

[0001193125-16-739148:8k_2_02:70]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-739148:8k_2_02:71]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-16-739148:8k_2_02:72]
(Unaudited, in millions, except per share and ratio data)

[0001193125-16-739148:8k_2_02:73]
Use of Non-GAAP Financial Measures

[0001193125-16-739148:8k_2_02:74]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with
the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the
Company’s business trends and operating performance.

[0001193125-16-739148:8k_2_02:75]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from
Continuing Operations, a Non-GAAP measure

[0001193125-16-739148:8k_2_02:76]
|  |  | For the Three Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 149.9 |  |  | $ | (48.2 | ) |  | $ | 101.7 |  |  | $ | 122.0 |  |  | $ | (41.7 | ) |  | $ | 80.3 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | 0.4 |  |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |
| Special product quality adjustments (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 0.5 |  |
| Special legal contingency charges (a) |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.3 |  |  |  | 1.3 |  |  |  | (0.5 | ) |  |  | 0.8 |  |
| Asbestos-related litigation (a) |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 0.3 |  |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 0.3 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | (1.2 | ) |  |  | 0.5 |  |  |  | (0.7 | ) |  |  | 0.8 |  |  |  | (0.3 | ) |  |  | 0.5 |  |
| Environmental liabilities(a) |  |  | — |  |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | 0.3 |  |  |  | — |  |  |  | 0.3 |  |
| Contractor tax payments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.8 |  |  |  | (0.1 | ) |  |  | 0.7 |  |
| Other items, net (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.3 |  |  |  | (0.2 | ) |  |  | 0.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 150.2 |  |  | $ | (48.3 | ) |  | $ | 101.9 |  |  | $ | 126.2 |  |  | $ | (43.0 | ) |  | $ | 83.2 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.33 |  |  |  |  |  |  |  |  |  |  | $ | 1.76 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Special legal contingency charges(a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Asbestos-related litigation(a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.33 |  |  |  |  |  |  |  |  |  |  | $ | 1.82 |  |

[0001193125-16-739148:8k_2_02:77]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-16-739148:8k_2_02:78]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-16-739148:8k_2_02:79]
| (c) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-16-739148:8k_2_02:80]
|  |  | For the Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 341.9 |  |  | $ | (104.0 | ) |  | $ | 237.9 |  |  | $ | 267.7 |  |  | $ | (91.9 | ) |  | $ | 175.8 |  |
| Restructuring charges |  |  | 1.2 |  |  |  | (0.4 | ) |  |  | 0.8 |  |  |  | 1.8 |  |  |  | (0.6 | ) |  |  | 1.2 |  |
| Special product quality adjustments (b) |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |  |  | (0.6 | ) |  |  | 0.2 |  |  |  | (0.4 | ) |
| Special legal contingency charges (a) |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.3 |  |  |  | 5.5 |  |  |  | (2.1 | ) |  |  | 3.4 |  |
| Asbestos-related litigation (a) |  |  | 2.3 |  |  |  | (0.8 | ) |  |  | 1.5 |  |  |  | 1.0 |  |  |  | (0.3 | ) |  |  | 0.7 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | (1.9 | ) |  |  | 0.7 |  |  |  | (1.2 | ) |  |  | 0.9 |  |  |  | (0.4 | ) |  |  | 0.5 |  |
| Environmental liabilities (a) |  |  | 1.1 |  |  |  | (0.3 | ) |  |  | 0.8 |  |  |  | 0.7 |  |  |  | (0.1 | ) |  |  | 0.6 |  |
| Contractor tax payments (a) |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 0.4 |  |  |  | 2.4 |  |  |  | (0.6 | ) |  |  | 1.8 |  |
| Other items (a) |  |  | 0.4 |  |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | 0.3 |  |  |  | (0.2 | ) |  |  | 0.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 345.6 |  |  | $ | (105.2 | ) |  | $ | 240.4 |  |  | $ | 279.7 |  |  | $ | (96 | ) |  | $ | 183.7 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 5.39 |  |  |  |  |  |  |  |  |  |  | $ | 3.86 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.08 |  |
| Asbestos-related litigation (a) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 5.44 |  |  |  |  |  |  |  |  |  |  | $ | 4.04 |  |

[0001193125-16-739148:8k_2_02:81]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-16-739148:8k_2_02:82]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-16-739148:8k_2_02:83]
| (c) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-16-739148:8k_2_02:84]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |
| Foreign currency exchange losses (a) |  |  | 0.5 |  |  |  | 1.4 |  |  |  | 1.1 |  |  |  | 2.7 |  |
| Loss on disposal of fixed assets (a) |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.3 |  |  |  | 0.1 |  |
| Net change in unrealized (gains) losses on unsettled futures contracts (b) |  |  | (1.2 | ) |  |  | 0.8 |  |  |  | (1.9 | ) |  |  | 0.9 |  |
| Special legal contingency (gains) charges (b) |  |  | 0.5 |  |  |  | 1.3 |  |  |  | 0.5 |  |  |  | 5.5 |  |
| Asbestos-related litigation (b) |  |  | 0.4 |  |  |  | 0.4 |  |  |  | 2.3 |  |  |  | 1.0 |  |
| Environmental liabilities (benefits) (b) |  |  | — |  |  |  | 0.3 |  |  |  | 1.1 |  |  |  | 0.7 |  |
| Contractor tax payments (b) |  |  | — |  |  |  | 0.8 |  |  |  | 0.5 |  |  |  | 2.4 |  |
| Acquisition costs (b) |  |  | — |  |  |  | — |  |  |  | 0.4 |  |  |  | — |  |
| Other items, net (b) |  |  | — |  |  |  | 0.3 |  |  |  | — |  |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 0.7 |  |  | $ | 6.0 |  |  | $ | 5.5 |  |  | $ | 14.9 |  |

[0001193125-16-739148:8k_2_02:85]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-16-739148:8k_2_02:86]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-16-739148:8k_2_02:87]
Reconciliation of Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Earnings per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-16-739148:8k_2_02:88]
|  |  | For the Year |  |
|  |  | Ended |  |
|  |  | December 31, |  |
|  |  | 2016 |  |
|  |  | ESTIMATED |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 6.75 - $6.95 |  |
| Pension buyout and other items |  |  | (0.50 | ) |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $ | 6.25-$6.45 |  |

[0001193125-16-739148:8k_2_02:89]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars
in millions)

[0001193125-16-739148:8k_2_02:90]
|  |  | For the Three Months Ended September 30, |  |  | For the Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 147.9 |  |  | $ | 159.1 |  |  | $ | 106.9 |  |  | $ | 106.9 |  |
| Purchases of property, plant and equipment |  | $ | (17.7 | ) |  | $ | (13.9 | ) |  | $ | (59.4 | ) |  | $ | (47.0 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | 130.2 |  |  | $ | 145.2 |  |  | $ | 47.5 |  |  | $ | 59.9 |  |

[0001193125-16-739148:8k_2_02:91]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | September 30, |  |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | 2016 |  |
| Adjusted EBIT (a) |  | $ | 445.8 |  |
| Depreciation and amortization expense (b) |  |  | 59.5 |  |
| EBITDA (a + b) |  | $ | 505.3 |  |
| Total debt at September 30, 2016 (c) |  |  | 1,055.9 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.1 |  |

[0001193125-16-739148:8k_2_02:92]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP
measure (dollars in millions)

[0001193125-16-739148:8k_2_02:93]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | September 30, |  |
|  |  | 2016 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 445.8 |  |
| Special product quality adjustments |  |  | (1.9 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 7.7 |  |
| Restructuring charges |  |  | 2.6 |  |
| Interest expense, net |  |  | 25.3 |  |
| Special inventory write down |  |  | 5.6 |  |
| Goodwill impairment |  |  | 5.5 |  |
| Asset impairment |  |  | 44.5 |  |
| Other expenses, net |  |  | (0.4 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 356.9 |  |
