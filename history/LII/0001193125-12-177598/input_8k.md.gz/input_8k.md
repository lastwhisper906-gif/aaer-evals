# LII 8-K — 0001193125-12-177442 filed 2012-04-24

## item codes, every 8-K on or before 2012-04-24

- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2012-04-24

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-12-177442:8k_2_02:1]
EX-99.1
2
d338961dex991.htm
PRESS RELEASE DATED APRIL 24, 2012

[0001193125-12-177442:8k_2_02:2]
Press Release dated April 24, 2012

[0001193125-12-177442:8k_2_02:3]
Exhibit 99.1

[0001193125-12-177442:8k_2_02:4]
Lennox International Reports First Quarter Results

[0001193125-12-177442:8k_2_02:5]
|  | • |  | Revenue up 2%, led by 7% growth in Residential |

[0001193125-12-177442:8k_2_02:6]
|  | • |  | Adjusted earnings per share from continuing operations of $0.01 |

[0001193125-12-177442:8k_2_02:7]
|  | • |  | GAAP loss per share from continuing operations of $0.01 |

[0001193125-12-177442:8k_2_02:8]
|  | • |  | Reiterating 2012 revenue growth guidance range of 2-6% |

[0001193125-12-177442:8k_2_02:9]
|  | • |  | Reiterating 2012 adjusted EPS from continuing operations guidance range of $2.20 to $2.60 |

[0001193125-12-177442:8k_2_02:10]
DALLAS, April 24, 2012 – Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2012. Financial
results presented have been adjusted for discontinued operations related to the company’s planned sale of its Hearth business.

[0001193125-12-177442:8k_2_02:11]
Revenue
for the first quarter was $684 million, up 2% from the prior-year quarter. Adjusted earnings per share from continuing operations was $0.01, compared to a loss of $0.04 in the prior-year quarter. First quarter 2012 adjusted EPS from continuing
operations had a $0.03 benefit from the movement of the Hearth business to discontinued operations, and first quarter 2011 adjusted EPS from continuing operations had a $0.07 benefit. On a GAAP basis, loss per share from continuing operations was
$0.01, compared to a loss of $0.06 in the prior-year quarter.

[0001193125-12-177442:8k_2_02:12]
“Strong execution in our Residential business drove 7% revenue growth and
230 basis points of margin expansion in that business in the first quarter,” said Todd Bluedorn, CEO of Lennox International. “Residential realized very strong revenue growth in the new construction market and was up high single digits in
the replacement market despite the relatively warm winter weather. In our Commercial business, revenue was flat at constant currency, with margin up slightly. As previously mentioned, the timing of growth in our national account business in 2012
would be beyond the first quarter. Backlog looks good, and we continue to expect a solid year in our Commercial business. In Service Experts, commercial service saw very strong growth, while residential service remained weak. Refrigeration revenue
was up 6%, or about half that rate organically, led by double-digit growth in North America. Looking ahead for the company overall with our strongest seasonal period still in front of us, we are reiterating our revenue growth guidance of 2-6% and
adjusted EPS from continuing operations guidance of $2.20-$2.60.”

[0001193125-12-177442:8k_2_02:13]
FINANCIAL HIGHLIGHTS

[0001193125-12-177442:8k_2_02:14]
Revenue: Revenue for the first quarter was $684 million, up 2% from the prior-year quarter. At constant currency, revenue was up 3%. Volume and price/mix were up from the prior-year quarter.

[0001193125-12-177442:8k_2_02:15]
Gross Profit: Gross profit for the first quarter was $166 million, up 1% from the prior-year quarter. Gross margin was 24.3% compared
to 24.5% in the prior-year quarter. Gross margin was primarily impacted by higher raw and component commodity costs, partially offset by favorable price/mix.

[0001193125-12-177442:8k_2_02:16]
Income (Loss) from Continuing Operations: Adjusted income from continuing operations in the first quarter was $0.3 million, or $0.01 earnings per share, compared to an adjusted loss from continuing
operations of $2.1 million, or $0.04 loss per share, in the prior-year quarter. Adjusted earnings from continuing operations for the first quarter of 2012 excludes an after-tax charge of $2.0 million for restructuring activities, $1.1 million
after-tax for the net change in unrealized gains on open future contracts, and a gain of $0.1 million after-tax for other items, net.

[0001193125-12-177442:8k_2_02:17]
On a
GAAP basis, loss from continuing operations for the first quarter was $0.5 million, or $0.01 loss per share, compared to a $3.5 million loss from continuing operations, or $0.06 diluted loss per share, in the prior-year quarter.

[0001193125-12-177442:8k_2_02:18]
Loss from Discontinued Operations: The Hearth business was placed in discontinued operations in the first quarter of 2012 due to the planned sale
by the company. The loss from discontinued operations in the first quarter of 2012 was $5.6 million, or $0.11 per share, compared to a loss of $3.7 million, or $0.07 per share, in the first quarter of 2011. The loss from discontinued operations in
the first quarter of 2012 included a charge of $4.2 million after tax, or $0.08 per share, to write down the related assets to their estimated fair value. (Revised 2011 quarterly and annual earnings statements, which show the effect of the removal
of the Hearth business on the company’s 2011 results, are available at www.lennoxinternational.com.)

[0001193125-12-177442:8k_2_02:19]
Free Cash Flow and Total
Debt: Net cash used in operations in the first quarter was $34 million compared to $148 million in the prior-year quarter. The company invested $7 million in capital assets in the first quarter. Free cash flow was ($41) million, compared to
($156) million in the prior-year quarter. Total debt at the end of the first quarter was $524 million. Total cash and cash equivalents were $55 million at the end of the quarter.

[0001193125-12-177442:8k_2_02:20]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-12-177442:8k_2_02:21]
Residential Heating & Cooling

[0001193125-12-177442:8k_2_02:22]
First quarter 2012 revenue in the Residential
Heating & Cooling business segment was $273 million, up 7% from the prior-year quarter. Currency was neutral to revenue growth. Segment profit was $11 million, up 150% from the prior-year quarter. Segment profit margin was 4.0%, up 230
basis points. Results were primarily impacted by higher volume and lower SG&A expenses, partially offset by lower mix and higher raw and component commodity costs than the prior-year quarter.

[0001193125-12-177442:8k_2_02:23]
Commercial Heating & Cooling

[0001193125-12-177442:8k_2_02:24]
Revenue in the Commercial Heating & Cooling business segment was $137 million, down 1% from the prior-year quarter. At constant currency, revenue
was flat. Segment profit was $6 million, flat with the prior-year quarter. Segment profit margin was 4.4%, up 10 basis points. Results were primarily impacted by favorable price/mix and productivity initiatives, with offsets from higher raw and
component commodity costs and the timing of SG&A expenses.

[0001193125-12-177442:8k_2_02:25]
Service Experts

[0001193125-12-177442:8k_2_02:26]
Revenue in the Service Experts business segment was $102 million in the first quarter, down 13% from the prior-year quarter. Currency was neutral to
revenue. Segment loss was $12 million and segment loss margin was 11.3%, compared to segment loss of $8 million and segment loss margin of 7.0% in the prior-year quarter. Results were primarily impacted by lower volume in residential service,
partially offset by lower SG&A expenses and strong growth in commercial service.

[0001193125-12-177442:8k_2_02:27]
Refrigeration

[0001193125-12-177442:8k_2_02:28]
Revenue in the Refrigeration business segment was $185 million in the first quarter, up 6% from the prior-year quarter. Currency was neutral to revenue
growth. Segment profit was $14 million, up 5%. Segment profit margin was 7.7%, flat with the prior-year quarter. Results were primarily impacted by higher volume and favorable price/mix, with offsets from higher raw and component commodity costs,
timing of factory absorption, and selling expenses.

[0001193125-12-177442:8k_2_02:29]
FULL-YEAR OUTLOOK

[0001193125-12-177442:8k_2_02:30]
The company reiterates its revenue and adjusted EPS from continuing operations guidance ranges for 2012.

[0001193125-12-177442:8k_2_02:31]
|  | • |  | Reiterating revenue growth guidance range of 2-6%, with a neutral impact from currency. |

[0001193125-12-177442:8k_2_02:32]
|  | • |  | Reiterating adjusted EPS from continuing operations guidance range of $2.20-$2.60. |

[0001193125-12-177442:8k_2_02:33]
|  | • |  | Adjusting GAAP EPS from continuing operations guidance from a range of $2.17-$2.57 to a range of $2.15-$2.55 due to additional restructuring activities. |

[0001193125-12-177442:8k_2_02:34]
|  | • |  | Reiterating tax rate guidance of 33-34% for the full year. |

[0001193125-12-177442:8k_2_02:35]
|  | • |  | Reiterating average diluted share count of approximately 51 million shares for the full year, including a minimum $50 million stock repurchase target. |

[0001193125-12-177442:8k_2_02:36]
|  | • |  | Reiterating capital expenditure guidance of approximately $55 million in 2012. |

[0001193125-12-177442:8k_2_02:37]
CONFERENCE CALL INFORMATION

[0001193125-12-177442:8k_2_02:38]
A
conference call to discuss the company’s first quarter results will be held this morning at 8:30 a.m. Central time. To listen, please call the conference call line at 612-288-0340 at least 10 minutes prior to the scheduled start time and use
reservation number 243388. This conference call will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0001193125-12-177442:8k_2_02:39]
A replay will be available from 11:00 a.m. Central time on April 24 through May 1, 2012, by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 243388. This call
will also be archived on the company’s web site.

[0001193125-12-177442:8k_2_02:40]
Lennox International Inc. is a global leader in the heating, air conditioning, and
refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under the symbol “LII.” Additional information is available at: http://www.lennoxinternational.com or by contacting Steve Harrison, Vice President,
Investor Relations, at 972-497-6670.

[0001193125-12-177442:8k_2_02:41]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-177442:8k_2_02:42]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-12-177442:8k_2_02:43]
(Unaudited, in millions, except per share data)

[0001193125-12-177442:8k_2_02:44]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| NET SALES |  | $ | 684.2 |  |  | $ | 669.4 |  |
| COST OF GOODS SOLD |  |  | 518.1 |  |  |  | 505.1 |  |
| Gross profit |  |  | 166.1 |  |  |  | 164.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 163.0 |  |  |  | 167.3 |  |
| Gains and other expenses, net |  |  | (1.5 | ) |  |  | (0.3 | ) |
| Restructuring charges |  |  | 3.1 |  |  |  | 1.2 |  |
| Income from equity method investments |  |  | (2.4 | ) |  |  | (2.6 | ) |
| Operational income (loss) from continuing operations |  |  | 3.9 |  |  |  | (1.3 | ) |
| INTEREST EXPENSE, net |  |  | 4.7 |  |  |  | 4.1 |  |
| Loss from continuing operations before income taxes |  |  | (0.8 | ) |  |  | (5.4 | ) |
| BENEFIT FROM INCOME TAXES |  |  | (0.3 | ) |  |  | (1.9 | ) |
| Loss from continuing operations |  |  | (0.5 | ) |  |  | (3.5 | ) |
| DISCONTINUED OPERATIONS: |  |  |  |  |  |  |  |  |
| Loss from discontinued operations |  |  | (8.5 | ) |  |  | (5.7 | ) |
| Benefit from income taxes |  |  | (2.9 | ) |  |  | (2.0 | ) |
| Loss from discontinued operations |  |  | (5.6 | ) |  |  | (3.7 | ) |
| Net loss |  | $ | (6.1 | ) |  | $ | (7.2 | ) |
| LOSS PER SHARE—BASIC AND DILUTED: |  |  |  |  |  |  |  |  |
| Loss from continuing operations |  | $ | (0.01 | ) |  | $ | (0.06 | ) |
| Loss from discontinued operations |  |  | (0.11 | ) |  |  | (0.07 | ) |
| Net loss |  | $ | (0.12 | ) |  | $ | (0.13 | ) |
| AVERAGE SHARES OUTSTANDING—BASIC AND DILUTED |  |  | 50.9 |  |  |  | 53.6 |  |
| CASH DIVIDENDS DECLARED PER SHARE |  | $ | 0.18 |  |  | $ | 0.18 |  |

[0001193125-12-177442:8k_2_02:45]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-177442:8k_2_02:46]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001193125-12-177442:8k_2_02:47]
(Unaudited, in millions)

[0001193125-12-177442:8k_2_02:48]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 272.6 |  |  | $ | 253.6 |  |
| Commercial Heating & Cooling |  |  | 137.0 |  |  |  | 138.8 |  |
| Service Experts |  |  | 101.6 |  |  |  | 116.5 |  |
| Refrigeration |  |  | 185.1 |  |  |  | 175.1 |  |
| Eliminations (A) |  |  | (12.1 | ) |  |  | (14.6 | ) |
|  |  | $ | 684.2 |  |  | $ | 669.4 |  |
| Segment Profit (Loss) (B) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 11.0 |  |  | $ | 4.4 |  |
| Commercial Heating & Cooling |  |  | 6.0 |  |  |  | 5.9 |  |
| Service Experts |  |  | (11.5 | ) |  |  | (8.2 | ) |
| Refrigeration |  |  | 14.2 |  |  |  | 13.5 |  |
| Corporate and other |  |  | (14.4 | ) |  |  | (14.5 | ) |
| Eliminations (A) |  |  | (0.2 | ) |  |  | (0.3 | ) |
| Subtotal that includes segment profit (loss) and eliminations |  |  | 5.1 |  |  |  | 0.8 |  |
| Reconciliation to loss from continuing operations before income taxes: |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | (0.4 | ) |  |  | — |  |
| Items in gains and other expenses, net that are excluded from segment profit (loss) (C) |  |  | (1.5 | ) |  |  | 0.9 |  |
| Restructuring charges |  |  | 3.1 |  |  |  | 1.2 |  |
| Interest expense, net |  |  | 4.7 |  |  |  | 4.1 |  |
| Loss from continuing operations before income taxes |  | $ | (0.8 | ) |  | $ | (5.4 | ) |

[0001193125-12-177442:8k_2_02:49]
| (A) | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |

[0001193125-12-177442:8k_2_02:50]
| (B) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |

[0001193125-12-177442:8k_2_02:51]
Excluding:

[0001193125-12-177442:8k_2_02:52]
|  | • |  | Special product quality adjustment. |

[0001193125-12-177442:8k_2_02:53]
|  | • |  | Items within Gains and/or losses and other expenses, net that are noted in (C) . |

[0001193125-12-177442:8k_2_02:54]
|  | • |  | Restructuring charges. |

[0001193125-12-177442:8k_2_02:55]
|  | • |  | Goodwill and equity method investment impairments. |

[0001193125-12-177442:8k_2_02:56]
|  | • |  | Interest expense, net. |

[0001193125-12-177442:8k_2_02:57]
|  | • |  | Other expense, net. |

[0001193125-12-177442:8k_2_02:58]
| (C) | Items in Gains and/or losses and other expenses, net that are excluded from segment profit or loss are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |

[0001193125-12-177442:8k_2_02:59]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-177442:8k_2_02:60]
CONSOLIDATED BALANCE SHEETS

[0001193125-12-177442:8k_2_02:61]
(In millions, except share and per share data)

[0001193125-12-177442:8k_2_02:62]
|  |  | As ofMarch 31,2012 |  |  | As ofDecember 31,2011 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 54.7 |  |  | $ | 45.0 |  |
| Accounts and notes receivable, net of allowances of $12.9 and $12.0 in 2012 and 2011, respectively |  |  | 394.7 |  |  |  | 401.4 |  |
| Inventories, net |  |  | 401.9 |  |  |  | 324.0 |  |
| Deferred income taxes |  |  | 32.8 |  |  |  | 35.2 |  |
| Other assets |  |  | 81.8 |  |  |  | 75.4 |  |
| Assets of discontinued operations |  |  | 32.4 |  |  |  | 35.0 |  |
| Total current assets |  |  | 998.3 |  |  |  | 916.0 |  |
| PROPERTY, PLANT AND EQUIPMENT, net of accumulated depreciation of $581.3 and $571.6 in 2012 and 2011, respectively |  |  | 299.2 |  |  |  | 304.5 |  |
| GOODWILL |  |  | 310.6 |  |  |  | 305.6 |  |
| DEFERRED INCOME TAXES |  |  | 99.1 |  |  |  | 99.5 |  |
| OTHER ASSETS, net |  |  | 82.8 |  |  |  | 80.1 |  |
| TOTAL ASSETS |  | $ | 1,790.0 |  |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 11.4 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt |  |  | 0.6 |  |  |  | 0.8 |  |
| Accounts payable |  |  | 307.4 |  |  |  | 271.0 |  |
| Accrued expenses |  |  | 255.9 |  |  |  | 279.5 |  |
| Income taxes payable |  |  | 5.7 |  |  |  | 5.7 |  |
| Liabilities of discontinued operations |  |  | 15.4 |  |  |  | 11.6 |  |
| Total current liabilities |  |  | 596.4 |  |  |  | 573.3 |  |
| LONG-TERM DEBT |  |  | 511.5 |  |  |  | 459.6 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | 18.9 |  |  |  | 18.6 |  |
| PENSIONS |  |  | 121.2 |  |  |  | 124.7 |  |
| OTHER LIABILITIES |  |  | 64.2 |  |  |  | 61.7 |  |
| Total liabilities |  |  | 1,312.2 |  |  |  | 1,237.9 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,100,663 shares and 86,938,004 shares issued for 2012 and 2011, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 885.9 |  |  |  | 881.2 |  |
| Retained earnings |  |  | 677.7 |  |  |  | 692.9 |  |
| Accumulated other comprehensive income |  |  | (14.7 | ) |  |  | (37.1 | ) |
| Treasury stock, at cost, 36,139,434 shares and 36,093,966 shares for 2012 and 2011, respectively |  |  | (1,072.0 | ) |  |  | (1,070.1 | ) |
| Total stockholders’ equity |  |  | 477.8 |  |  |  | 467.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,790.0 |  |  | $ | 1,705.7 |  |

[0001193125-12-177442:8k_2_02:63]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-177442:8k_2_02:64]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-12-177442:8k_2_02:65]
(Unaudited, in millions)

[0001193125-12-177442:8k_2_02:66]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net loss |  |  | (6.1 | ) |  |  | (7.2 | ) |
| Net loss from discontinued operations |  |  | 5.6 |  |  |  | 3.7 |  |
| Adjustments to reconcile net loss to net cash used in by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (2.4 | ) |  |  | (2.6 | ) |
| Dividends from affiliates |  |  |  |  |  |  |  |  |
| Restructuring expenses, net of cash paid |  |  | 1.7 |  |  |  | (1.8 | ) |
| Provision for bad debts |  |  | 1.6 |  |  |  | 0.8 |  |
| Unrealized (gain) loss on derivative contracts |  |  | (0.5 | ) |  |  | 1.2 |  |
| Stock-based compensation expense |  |  | 3.8 |  |  |  | 4.9 |  |
| Depreciation and amortization |  |  | 14.2 |  |  |  | 14.1 |  |
| Deferred income taxes |  |  | (0.1 | ) |  |  | (0.8 | ) |
| Other items, net |  |  | 0.4 |  |  |  | 0.6 |  |
| Accounts and notes receivable |  |  | 10.3 |  |  |  | 17.1 |  |
| Inventories |  |  | (75.7 | ) |  |  | (134.6 | ) |
| Other current assets |  |  | 3.9 |  |  |  | (1.8 | ) |
| Accounts payable |  |  | 34.2 |  |  |  | 50.2 |  |
| Accrued expenses |  |  | (17.0 | ) |  |  | (58.8 | ) |
| Income taxes payable and receivable |  |  | (8.5 | ) |  |  | (25.9 | ) |
| Other |  |  | 1.9 |  |  |  | (1.5 | ) |
| Net cash used in discontinued operations |  |  | (1.6 | ) |  |  | (5.9 | ) |
| Net cash used in operating activities |  |  | (34.3 | ) |  |  | (148.3 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 0.7 |  |
| Purchases of property, plant and equipment |  |  | (6.8 | ) |  |  | (7.9 | ) |
| Acquisition of business |  |  | — |  |  |  | (144.2 | ) |
| Change in restricted cash |  |  | — |  |  |  | 1.6 |  |
| Net cash used in discontinued operations |  |  | (0.1 | ) |  |  | (0.3 | ) |
| Net cash used in investing activities |  |  | (6.8 | ) |  |  | (150.1 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 6.6 |  |  |  | 1.2 |  |
| Asset securitization borrowings |  |  | 170.0 |  |  |  | 50.0 |  |
| Asset securitization payments |  |  | (170.0 | ) |  |  | — |  |
| Long-term payments |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Borrowings from revolving credit facility |  |  | 267.5 |  |  |  | 339.0 |  |
| Payments on revolving credit facility |  |  | (215.5 | ) |  |  | (167.5 | ) |
| Proceeds from stock option exercises |  |  | 0.1 |  |  |  | 0.9 |  |
| Repurchases of common stock |  |  | (1.9 | ) |  |  | (24.7 | ) |
| Excess tax benefits related to share-based payments |  |  | 0.8 |  |  |  | 1.2 |  |
| Cash dividends paid |  |  | (9.2 | ) |  |  | (8.1 | ) |
| Net cash provided by financing activities |  |  | 48.2 |  |  |  | 191.8 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | 7.1 |  |  |  | (106.6 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | 2.6 |  |  |  | 1.8 |  |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | 45.0 |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of period |  |  | 54.7 |  |  |  | 55.2 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the period for: |  |  |  |  |  |  |  |  |
| Interest, net |  |  | 2.3 |  |  |  | 1.6 |  |
| Income taxes (net of refunds) |  |  | 5.1 |  |  |  | 21.5 |  |

[0001193125-12-177442:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-177442:8k_2_02:68]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-12-177442:8k_2_02:69]
(Unaudited, in millions, except per share, ratio, sales growth rate and margin data)

[0001193125-12-177442:8k_2_02:70]
Use of Non-GAAP Financial Measures

[0001193125-12-177442:8k_2_02:71]
To
supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes
that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP
financial measures enhance the ability of investors to analyze the Company’s business trends and operating performance.

[0001193125-12-177442:8k_2_02:72]
Reconciliation of Loss From Continuing Operations, a GAAP measure, to Adjusted Income (Loss) From Continuing Operations, a Non-GAAP measure

[0001193125-12-177442:8k_2_02:73]
|  |  | For The Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Loss from continuing operations, a GAAP measure |  | $ | (0.5 | ) |  | $ | (3.5 | ) |
| Restructuring charges, after tax |  |  | 2.0 |  |  |  | 0.8 |  |
| Net change in unrealized losses on open future contracts, after tax (a) |  |  | (1.1 | ) |  |  | 0.5 |  |
| Acquisition expenses, after-tax (a) |  |  | — |  |  |  | 0.1 |  |
| Special product quality adjustment, after-tax (b) |  |  | (0.3 | ) |  |  | — |  |
| Other items, net, after tax (a) |  |  | 0.2 |  |  |  | — |  |
| Adjusted income (loss) from continuing operations, a non-GAAP measure |  | $ | 0.3 |  |  | $ | (2.1 | ) |
| Loss per share from continuing operations—basic and diluted, a GAAP measure |  | $ | (0.01 | ) |  | $ | (0.06 | ) |
| Restructuring charges |  |  | 0.04 |  |  |  | 0.01 |  |
| Net change in unrealized losses on open future contracts (a) |  |  | (0.02 | ) |  |  | 0.01 |  |
| Adjusted earnings (loss) per share from continuing operations—basic and diluted, a non-GAAP measure |  | $ | 0.01 |  |  | $ | (0.04 | ) |

[0001193125-12-177442:8k_2_02:74]
| (a) | Recorded in Gains and other expenses, net in the Consolidated Statements of Operations |

[0001193125-12-177442:8k_2_02:75]
|  |  | For The Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Components of Gains and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |
| Realized loss (gains) on settled future contracts (a) |  | $ | 0.3 |  |  | $ | (0.6 | ) |
| Foreign currency exchange (gain) loss (a) |  |  | (0.3 | ) |  |  | 0.1 |  |
| Gain on disposal of fixed assets (a) |  |  | — |  |  |  | (0.7 | ) |
| Net change in unrealized (gains) losses on open futures contracts (b) |  |  | (1.7 | ) |  |  | 0.7 |  |
| Acquisition expenses (b) |  |  | — |  |  |  | 0.2 |  |
| Other items, net (b) |  |  | 0.2 |  |  |  | — |  |
| Gains and other expenses, net (pre-tax) |  | $ | (1.5 | ) |  | $ | (0.3 | ) |

[0001193125-12-177442:8k_2_02:76]
| (a) | Included in segment profit (loss) and adjusted income (loss) from continuing operations |

[0001193125-12-177442:8k_2_02:77]
| (b) | Excluded from segment profit (loss) and adjusted income (loss) from continuing operations |

[0001193125-12-177442:8k_2_02:78]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations—Diluted, a Non-GAAP
Measure, to Income per Share from Continuing Operations—Diluted, a GAAP Measure

[0001193125-12-177442:8k_2_02:79]
|  |  | For the |  |
|  |  | Year Ended |  |
|  |  | December 31, |  |
|  |  | 2012 |  |
|  |  | ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 2.20 - $2.60 |  |
| Restructuring charges |  |  | (0.05 | ) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 2.15 - $2.55 |  |

[0001193125-12-177442:8k_2_02:80]
Reconciliation of Net Cash Used in Operating Activities, a GAAP Measure, to Free Cash Flow, a Non-GAAP Measure

[0001193125-12-177442:8k_2_02:81]
|  |  | For the Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net cash used in operating activities, a GAAP measure |  | $ | (34.3 | ) |  | $ | (148.3 | ) |
| Purchase of property, plant and equipment |  |  | (6.8 | ) |  |  | (7.9 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | (41.1 | ) |  | $ | (156.2 | ) |

[0001193125-12-177442:8k_2_02:82]
Calculation of Debt to EBITDA Ratio:

[0001193125-12-177442:8k_2_02:83]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | March 31, |  |
|  |  | 2012 |  |
| EBIT (a) |  | $ | 195.2 |  |
| Depreciation and amortization expense (b) |  |  | 57.9 |  |
| EBITDA (a + b) |  | $ | 253.1 |  |
| Total debt at March 31, 2012 (c) |  | $ | 523.5 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 2.1 |  |

[0001193125-12-177442:8k_2_02:84]
Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income Taxes, a GAAP Measure

[0001193125-12-177442:8k_2_02:85]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | March 31, |  |
|  |  | 2012 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 195.2 |  |
| Special product quality adjustment |  |  | (4.7 | ) |
| Items in gains and other expenses, net that are excluded from segment profit |  |  | 2.5 |  |
| Restructuring charges |  |  | 17.9 |  |
| Asset Impairment |  |  | 0.3 |  |
| Other expenses, net |  |  | 0.3 |  |
| Interest expense, net |  |  | 17.4 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 161.5 |  |
