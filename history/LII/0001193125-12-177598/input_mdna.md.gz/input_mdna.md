# LII MD&A — 0001193125-12-177598


## mdna

[0001193125-12-177598:mdna:1]
| Item 2. | Management’s Discussion and Analysis of Financial Condition and Results of Operations. |

[0001193125-12-177598:mdna:2]
[same as prior period, unchanged from 0000950123-11-091697:mdna:2]

[0001193125-12-177598:mdna:3]
We operate in
four reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments consist of Residential Heating & Cooling, Commercial Heating & Cooling, Service
Experts and Refrigeration. For more detailed information regarding our reportable segments, see Note 13 in the Notes to our Consolidated Financial Statements.

[0001193125-12-177598:mdna:4]
Our products and services are sold through a combination of distributors, independent and company-owned dealer service centers, other installing contractors, wholesalers, manufacturers’
representatives, and original equipment manufacturers and to national accounts. The demand for our products and services is seasonal and dependent on the weather. Warmer than normal summer temperatures generate strong demand for replacement air
conditioning and refrigeration products and services and colder than normal winter temperatures have the same effect on heating products and services. Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR
products and services. In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment
trends, new construction, general economic conditions and consumer spending habits and confidence. A substantial portion of our business is attributable to replacement business, with the balance comprised of new construction business.

[0001193125-12-177598:mdna:5]
The principal elements of cost of goods sold in our manufacturing operations are components, raw materials, factory overhead, labor and
estimated costs of warranty expense. In our Service Experts segment, the principal components of cost of goods sold are equipment, parts and supplies and labor. The principal raw materials used in our manufacturing processes are steel, copper and
aluminum. In recent years, increased prices for these commodities and related components have challenged us and the HVACR industry in general. We seek to mitigate the impact of higher commodity prices through a combination of price increases for our
products and services, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001193125-12-177598:mdna:6]
In the first quarter of 2012, our Residential Heating & Cooling segment saw a 7.5% increase in net sales and almost
$7 million in increased profit. This segment benefitted from an increase in its new construction business as well as good comparables for its replacement business. The replacement equipment sales comparables to the first quarter of 2011 were better
since consumers accelerated their replacement of systems in the fourth quarter of 2010 before the reduction in government tax credits as well as announced price increases in the first quarter of 2011. Our Refrigeration segment also saw net sales
increase by 5.7% with an almost $1million increase in segment profit. The increase in our Refrigeration segment was driven by increased growth in our North American businesses. Our Commercial Heating & Cooling segment performance in the
first quarter of 2012 was comparable to the first quarter of 2011. However, our Service Experts segment saw a 12.8% decline in net sales and a $3 million increase in loss for the first quarter of 2012 compared to the first quarter of 2011. The
primary reason for the decline in net sales and increase in loss is due to unseasonably warm weather, particularly in January and February.

[0001193125-12-177598:mdna:7]
The Hearth business was placed in discontinued operations in the first quarter of 2012 as
management committed to a plan to sell this business. The loss from discontinued operations in the first quarter of 2012 included a charge for $6.3 million to write-down the related assets to their estimated fair value.

[0001193125-12-177598:mdna:8]
[same as prior period, unchanged from 0000950123-11-091697:mdna:11]

[0001193125-12-177598:mdna:9]
|  | • |  | Net sales for first quarter of 2012 increased to $684.2 million as compared to $669.4 million in 2011. The increase in net sales was due to our Residential Heating & Cooling and Refrigeration segments partially offset by our Service Experts segment as discussed above. |

[0001193125-12-177598:mdna:10]
|  | • |  | Operational income for first quarter of 2012 increased to $3.9 million of operational income compared to an operational loss of $1.3 million in 2011. The increase to operational income in 2012 was primarily due to the increase in sales volume from our Residential Heating & Cooling segment and increases in price and mix from our Commercial Heating & Cooling and Refrigeration segments and lower selling, general and administrative expenses in the first quarter of 2012 partially offset by higher raw material and component costs. |

[0001193125-12-177598:mdna:11]
|  | • |  | Net loss for the first quarter of 2012 was $6.1 million, including the write-down of net assets for our Hearth reporting unit included in loss from discontinued operations, compared to a net loss of $7.2 million in 2011. Basic and diluted loss per share from continuing operations were $0.01 in the first quarter of 2012 compared to $0.06 in 2011. |

[0001193125-12-177598:mdna:12]
|  | • |  | Cash of $34.3 million was used in operating activities for first quarter of 2012 compared to $148.3 million in the first quarter of 2011. Cash used in operating activities was lower than the first quarter of 2011 primarily due to a smaller increase in inventory in 2012. |

[0001193125-12-177598:mdna:13]
[same as prior period, unchanged from 0000950123-11-091697:mdna:15]

[0001193125-12-177598:mdna:14]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in
millions):

[0001193125-12-177598:mdna:15]
|  |  | Three Months Ended March 31, |  |
|  |  |  |  |  | PercentChange Fav/(Unfav) |  |  |  |  |
|  |  | Dollars |  |  |  | Percent Sales |  |
|  |  | 2012 |  |  | 2011 |  |  |  | 2012 |  |  | 2011 |  |
| Net sales |  | $ | 684.2 |  |  | $ | 669.4 |  |  |  | 2.2 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 518.1 |  |  |  | 505.1 |  |  |  | (2.6 | ) |  |  | 75.7 |  |  |  | 75.5 |  |
| Gross profit |  |  | 166.1 |  |  |  | 164.3 |  |  |  | 1.1 |  |  |  | 24.3 |  |  |  | 24.5 |  |
| Selling, general and administrative expenses |  |  | 163.0 |  |  |  | 167.3 |  |  |  | 2.6 |  |  |  | 23.8 |  |  |  | 25.0 |  |
| Gains and other expenses, net |  |  | (1.5 | ) |  |  | (0.3 | ) |  |  | 400.0 |  |  |  | (0.2 | ) |  |  | N.M |  |
| Restructuring charges |  |  | 3.1 |  |  |  | 1.2 |  |  |  | (158.3 | ) |  |  | 0.5 |  |  |  | 0.1 |  |
| Income from equity method investments |  |  | (2.4 | ) |  |  | (2.6 | ) |  |  | (7.7 | ) |  |  | (0.4 | ) |  |  | (0.4 | ) |
| Operational income (loss) |  | $ | 3.9 |  |  | $ | (1.3 | ) |  |  | 400.0 | % |  |  | 0.6 | % |  |  | (0.2 | )% |
| Net loss |  | $ | (6.1 | ) |  | $ | (7.2 | ) |  |  | 15.3 | % |  |  | (0.9 | )% |  |  | (1.1 | )% |

[0001193125-12-177598:mdna:16]
First Quarter of 2012 Compared to First Quarter of 2011 – Consolidated Results

[0001193125-12-177598:mdna:17]
[same as prior period, unchanged from 0000950123-11-091697:mdna:18]

[0001193125-12-177598:mdna:18]
Net sales
increased 2.2% in the first quarter of 2012 compared to the first quarter of 2011. Our sales volumes were up 1.8% and price and mix were up 0.9% in the comparable period. Changes in foreign currency exchange rates unfavorably impacted net sales by
0.5%.

[0001193125-12-177598:mdna:19]
[same as prior period, unchanged from 0000950123-11-091697:mdna:20]

[0001193125-12-177598:mdna:20]
Gross profit margins declined 20 basis points to 24.3% for the first quarter of 2012 when compared to gross profit margins of 24.5% in 2011. The impact from commodity costs on both raw material and
components contributed approximately 50 basis points to the decline which was partially offset by improved price and mix of 20 basis points and favorable foreign currency exchange rates of 10 basis points.

[0001193125-12-177598:mdna:21]
[same as prior period, unchanged from 0000950123-11-091697:mdna:22]

[0001193125-12-177598:mdna:22]
Selling, general and administrative (“SG&A”) expenses decreased by $4.3 million in the first quarter of 2012 compared to
2011, and, as a percentage of net sales, SG&A expenses declined to 23.8% in 2012 from 25.0% in 2011. The decline in SG&A is primarily due to general cost control initiatives. Changes in foreign currency exchange rates favorably impacted
SG&A by $0.6 million

[0001193125-12-177598:mdna:23]
Gains and Other Expenses, Net

[0001193125-12-177598:mdna:24]
Gains and other expenses, net for the first quarters of 2012 and 2011 included the following (in millions):

[0001193125-12-177598:mdna:25]
|  |  | Three Months Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Realized losses (gains) on settled futures contracts |  | $ | 0.3 |  |  | $ | (0.6) |  |
| Unrealized (gain) loss on unsettled futures contracts not designated as cash flow hedges |  |  | (1.7) |  |  |  | 0.7 |  |
| Foreign currency exchange (gains) loss |  |  | (0.3) |  |  |  | 0.1 |  |
| Gain on disposal of fixed assets |  |  | — |  |  |  | (0.7) |  |
| Acquisition expenses |  |  | — |  |  |  | 0.2 |  |
| Other items, net |  |  | 0.2 |  |  |  | — |  |
| Gains and other expenses, net |  | $ | (1.5) |  |  | $ | (0.3) |  |

[0001193125-12-177598:mdna:26]
The change in gains and losses on futures contracts was primarily due to decreases in commodity prices
relative to our futures contract prices during 2012 as compared to 2011 for the contracts that settled during the period. Conversely, the change in unrealized losses related to unsettled futures contracts not designated as cash flow hedges was
primarily due to higher commodity prices relative to the futures contract prices for those contracts. For more information, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001193125-12-177598:mdna:27]
[same as prior period, unchanged from 0000950123-11-091697:mdna:28]

[0001193125-12-177598:mdna:28]
Restructuring charges increased from $1.2 million in
the first quarter of 2011 to $3.1 million in the first quarter of 2012. The charges in the first quarter of 2012 were from open projects initiated in prior periods, as we did not initiate any new projects in the current period. The $3.1 million in
restructuring charges in the current period primarily consisted of $2.5 million in lease termination charges for our Regional Distribution Network project and $0.5 million in charges for Service Experts reorganization. The restructuring charges from
the first quarter of 2011were primarily minor charges from various open projects initiated in prior years.

[0001193125-12-177598:mdna:29]
Results from Equity Method and
Other Equity Investments

[0001193125-12-177598:mdna:30]
Investments over which we do not exercise control but have significant influence are accounted
for using the equity method of accounting. Income from equity method investments decreased slightly to $2.4 million in the first quarter of 2012 from $2.6 million in 2011.

[0001193125-12-177598:mdna:31]
[same as prior period, unchanged from 0000950123-11-091697:mdna:32]

[0001193125-12-177598:mdna:32]
Interest expense, net, increased to $4.7 million in
2012 from $4.1 million in 2011. The increase in interest expense was primarily attributable to an increase in the average amounts borrowed and an increase in the weighted average borrowing rate in the first quarter of 2012 compared to 2011.

[0001193125-12-177598:mdna:33]
Benefit from Income Taxes

[0001193125-12-177598:mdna:34]
The income tax benefits were $0.3 million in the first quarter of 2012 compared to $1.9 million in 2011. The effective tax rate was 34.0% for 2012 and 36.0% in 2011. Our effective rates differ from the
statutory federal rate of 35% for certain items, such as foreign taxes at rates other than 35% and other permanent items.

[0001193125-12-177598:mdna:35]
Loss from
Discontinued Operations

[0001193125-12-177598:mdna:36]
In the fourth quarter of 2011, we began to pursue strategic alternatives for our Hearth reporting
unit due to the

[0001193125-12-177598:mdna:37]
prolonged uncertainty of the residential new construction market and our outlook for this reporting unit. The Hearth reporting unit is heavily dependent on the residential new construction
market; more so than our other reporting units due to its product offerings: fireplaces, stoves and venting products. In the first quarter of 2012, management committed to a plan to sell the Hearth business.

[0001193125-12-177598:mdna:38]
We had a pre-tax loss of $8.5 million in discontinued operations in the first quarter of 2012 for the Hearth reporting unit compared to a
pre-tax loss of $5.7 million in the first quarter of 2011. The loss from discontinued operations in the first quarter of 2012 included a charge for $6.3 million to write-down the related assets to their estimated fair value.

[0001193125-12-177598:mdna:39]
First Quarter of 2012 Compared to First Quarter of 2011 – Results by Segment

[0001193125-12-177598:mdna:40]
Residential Heating & Cooling

[0001193125-12-177598:mdna:41]
The following table summarizes our
Residential Heating & Cooling segment’s net sales and profit for the first quarters of 2012 and 2011 (dollars in millions):

[0001193125-12-177598:mdna:42]
|  |  | Three Months EndedMarch 31, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 272.6 |  |  | $ | 253.6 |  |  | $ | 19.0 |  |  |  | 7.5 | % |
| Profit |  |  | 11.0 |  |  |  | 4.4 |  |  |  | 6.6 |  |  |  | 150.0 | % |
| % of net sales |  |  | 4.0 | % |  |  | 1.7 | % |  |  |  |  |  |  |  |  |

[0001193125-12-177598:mdna:43]
Sales volumes increased by 10% in 2012 as compared to 2011 primarily due to an increase in net sales in
our residential new construction business and good comparables for our replacement business. The first quarter of 2011 replacement equipment sales were negatively affected by consumers purchasing replacement systems in the fourth quarter of 2010 in
advance of the reduction in government tax credits in 2011 and of announced price increases by the company. Partially offsetting the increase in sales volumes was an almost 3% decline in price and mix.

[0001193125-12-177598:mdna:44]
Segment profit increased almost $7 million due to $7 million in higher sales volumes, $2 million from favorable freight and distribution
costs, and a $3 million decline in SG&A expenses. The decline in SG&A expenses was primarily from lower selling and advertising expenses and research and development expenses in the comparable period. Partially offsetting these increases in
segment profit were $2 million in unfavorable price and mix and $2 million in increased other product costs from a decline in factory absorption due to lower production levels in the first quarter of 2012 compared to the first quarter of 2011.

[0001193125-12-177598:mdna:45]
Commercial Heating & Cooling

[0001193125-12-177598:mdna:46]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit for the first quarters of 2012 and 2011 (dollars in millions):

[0001193125-12-177598:mdna:47]
|  |  | Three Months EndedMarch 31, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 137.0 |  |  | $ | 138.8 |  |  | $ | (1.8 | ) |  |  | (1.3 | )% |
| Profit |  |  | 6.0 |  |  |  | 5.9 |  |  |  | 0.1 |  |  |  | 1.7 |  |
| % of net sales |  |  | 4.4 | % |  |  | 4.3 | % |  |  |  |  |  |  |  |  |

[0001193125-12-177598:mdna:48]
Our Commercial Heating & Cooling segment experienced a slight decline in net sales in the first
quarter of 2012 compared to 2011. The decline in net sales was primarily due to unfavorable changes in foreign currency exchange rates of 2% and a 1% decline in sales volume on timing of national account deliveries. Partially offsetting these
declines in net sales was a 1% increase in price and mix.

[0001193125-12-177598:mdna:49]
Segment profit for the first quarter of 2012
was relatively flat when compared to the first quarter of 2011. Segment profit was favorably impacted by $2 million increase in price and mix and a $3 million decline in other products costs due to an increase in factory productivity in the first
quarter of 2012 compared to the first quarter of 2011. The increase in factory productivity was primarily related to factory inefficiencies in the first quarter of 2011 related to the Energence® product introduction. Almost fully offsetting these favorable items was $3 million in higher commodity costs in both raw materials and components and $2 million in
higher SG&A costs. The increase in SG&A costs was primarily from increased selling and advertising expense.

[0001193125-12-177598:mdna:50]
[same as prior period, unchanged from 0000950123-11-091697:mdna:47]

[0001193125-12-177598:mdna:51]
The following table summarizes our Service Experts segment’s net sales and loss for the first quarters of 2012 and 2011 (dollars in millions):

[0001193125-12-177598:mdna:52]
|  |  | Three Months EndedMarch 31, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 101.6 |  |  | $ | 116.5 |  |  | $ | (14.9 | ) |  |  | (12.8 | )% |
| Loss |  |  | (11.5 | ) |  |  | (8.2 | ) |  |  | (3.3 | ) |  |  | (40.2 | ) |
| % of net sales |  |  | (11.3 | )% |  |  | (7.0 | )% |  |  |  |  |  |  |  |  |

[0001193125-12-177598:mdna:53]
In total, sales volumes declined almost 19% which was partially offset by a 6% increase in price and mix.

[0001193125-12-177598:mdna:54]
In the seasonally lightest quarter, segment loss increased $3 million due to the impact of the volume decline in net sales of
almost $7 million. Partially offsetting the volume decline was a SG&A expense improvement of $3 million due to lower commissions related to the decline in net sales and an increase in productivity from restructuring activities.

[0001193125-12-177598:mdna:55]
[same as prior period, unchanged from 0000950123-11-091697:mdna:52]

[0001193125-12-177598:mdna:56]
The
following table summarizes our Refrigeration segment’s net sales and profit for the first quarters of 2012 and 2011 (dollars in millions):

[0001193125-12-177598:mdna:57]
|  |  | Three Months EndedMarch 31, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 185.1 |  |  | $ | 175.1 |  |  | $ | 10.0 |  |  |  | 5.7 | % |
| Profit |  |  | 14.2 |  |  |  | 13.5 |  |  |  | 0.7 |  |  |  | 5.2 |  |
| % of net sales |  |  | 7.7 | % |  |  | 7.7 | % |  |  |  |  |  |  |  |  |

[0001193125-12-177598:mdna:58]
Net sales increased almost 6% due to 4% in higher sales volumes and 2% in improved price and mix. Foreign
exchange rates were relatively flat in the first quarter of 2012 compared to the first quarter of 2011.

[0001193125-12-177598:mdna:59]
Segment profit
increased slightly in the first quarter of 2012 compared to the first quarter of 2011. Segment profit was favorably impacted by $1 million from the higher sales volumes and $4 million from improved price and mix. Almost fully offsetting the positive
impact to segment profit by the increases in net sales was almost $1 million from component headwinds, $2 million in increased other product costs due to a decline in factory absorption with the decline in production in the first quarter of 2012,
and $1 million in higher SG&A costs primarily due to higher commissions from the increase in net sales.

[0001193125-12-177598:mdna:60]
Corporate and
Other

[0001193125-12-177598:mdna:61]
Corporate and other expenses were relatively flat at $14.4 million in the first quarter of 2012, down from $14.5
million in 2011.

[0001193125-12-177598:mdna:62]
[same as prior period, unchanged from 0000950123-11-091697:mdna:105]

[0001193125-12-177598:mdna:63]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and a revolving period asset securitization arrangement. Working capital
needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001193125-12-177598:mdna:64]
Statement
of Cash Flows

[0001193125-12-177598:mdna:65]
The following table summarizes our cash activity for the quarters ended March 31, 2012 and 2011 (in
millions):

[0001193125-12-177598:mdna:66]
|  |  | Three Months EndedMarch 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net cash used in operating activities |  | $ | (34.3 | ) |  | $ | (148.3 | ) |
| Net cash used in investing activities |  |  | (6.8 | ) |  |  | (150.1 | ) |
| Net cash provided by financing activities |  |  | 48.2 |  |  |  | 191.8 |  |

[0001193125-12-177598:mdna:67]
Net Cash Used in Operating Activities

[0001193125-12-177598:mdna:68]
Operating activities resulted in a lower use of cash in 2012 compared to 2011. This decreased use was primarily due to a favorable change
in working capital in 2012 and a favorable change in accrued expenses. Our working capital requirements resulted in a $31.2 million use of cash in the first quarter of 2012 compared to a $67.3 million use of cash in 2011. The decrease in working
capital requirements was primarily related to inventory. As we prepare for the peak cooling season, we carry higher than average inventory balances in the first and second quarters to meet the summer demand. In addition to the higher than average
inventory balances, in the first quarter of 2011our inventory increase was greater than what we normally see in this period due to an increased effort to level load our factories. The favorable comparison for accrued expenses was primarily due to
higher payments for incentive compensation in 2011 versus 2012. Incentive compensation is accrued in the current year based on performance, but paid out in the first quarter of the subsequent year.

[0001193125-12-177598:mdna:69]
[same as prior period, unchanged from 0000950123-11-091697:mdna:112]

[0001193125-12-177598:mdna:70]
Net cash used in investing activities for the first quarter of 2012 was $143.3 million less than 2011. The primary reason for the decrease in net cash used in investing activities was the $144.2 million
cash used for the acquisition of the Kysor/Warren business from The Manitowoc Company in 2011.

[0001193125-12-177598:mdna:71]
Capital expenditures in the
first quarter of 2012 were $6.8 million, which was slightly lower than the $7.9 million in the first quarter of 2011. Capital expenditures in the quarter were primarily related to investments in our distribution network, investments for
manufacturing and sourcing excellence, and maintenance capital expenditures.

[0001193125-12-177598:mdna:72]
[same as prior period, unchanged from 0000950123-11-091697:mdna:117]

[0001193125-12-177598:mdna:73]
Net cash provided by financing activities decreased by $143.6 million in the first quarter of 2012 compared to the first quarter of 2011.
This decrease was primarily related to an increase in net borrowings in the first quarter of 2011 to fund the Kysor/Warren acquisition. Additionally, we did not repurchase any shares under the share repurchase program in the first quarter of 2012
compared to $23.7 million in share repurchases in the first quarter of 2011.

[0001193125-12-177598:mdna:74]
[same as prior period, unchanged from 0000950123-11-091697:mdna:119]

[0001193125-12-177598:mdna:75]
The following table details our lines of credit and financing arrangements as of March 31, 2012:

[0001193125-12-177598:mdna:76]
|  |  | MaximumCapacity |  |  | OutstandingBorrowings |  |  | Available forFutureBorrowings |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign Obligations |  | $ | 11.4 |  |  | $ | 11.4 |  |  | $ | — |  |
| Asset Securitization (1) |  |  | 150.0 |  |  |  | — |  |  |  | 150.0 |  |
| Total short-term debt |  | $ | 161.4 |  |  | $ | 11.4 |  |  | $ | 150.0 |  |
| Current Maturities of Long-Term Debt: |  | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | — |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital lease obligations |  | $ | 16.5 |  |  | $ | 16.5 |  |  | $ | — |  |
| Domestic revolving credit facility (2) |  |  | 650.0 |  |  |  | 295.0 |  |  |  | 276.5 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |  |  | — |  |
| Total long-term debt |  | $ | 866.5 |  |  | $ | 511.5 |  |  |  | 276.5 |  |
| Total |  | $ | 1,028.5 |  |  | $ | 523.5 |  |  | $ | 426.5 |  |

[0001193125-12-177598:mdna:77]
| (1) | The maximum capacity under the asset securitization arrangement (“ASA”) is the lesser of $150.0 million or 100% of the net pool balance defined under the ASA. |

[0001193125-12-177598:mdna:78]
| (2) | The available future borrowings on our domestic revolving credit facility exclude $78.5 million in standby letters of credit. |

[0001193125-12-177598:mdna:79]
As our peak season arrives, we typically pay down debt. We believe our available future
borrowings combined with our cash of $54.7 million and future cash from operations are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, dividends and other needs in the foreseeable
future. Our expected capital expenditures are $55 million for 2012.

[0001193125-12-177598:mdna:80]
Our debt-to-total-capital ratio increased to 52.3% at
March 31, 2012 compared to 49.9% at December 31, 2011. The increase in the ratio is due to an increase in the total debt balance at March 31, 2012 primarily related to the seasonal build in inventory to meet peak seasonal demand.

[0001193125-12-177598:mdna:81]
Covenants on our outstanding debt did not change in the first quarter of 2012 and we were in compliance with all of our debt
covenants as of March 31, 2012. For a more detailed discussion of our debt, see Note 7 in the Notes to the Consolidated Financial Statements set forth in Part I, Item I of this Quarterly Report on Form 10-Q.

[0001193125-12-177598:mdna:82]
We periodically review our capital structure, including our primary bank facility, to ensure that it has adequate liquidity. We also
periodically consider various other financing alternatives and may, from time to time, seek to take advantage of favorable interest rate environments or other market conditions, which may include accessing the capital markets.

[0001193125-12-177598:mdna:83]
On March 30, 2012, the parties involved with the asset securitization program (“ASP”) agreed to remove Lennox Hearth
Products LLC from the ASP. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. We do not believe the removal
of Lennox Hearth Products LLC from the ASP will have a significant impact on the available borrowings under the ASP. The eligible amount to borrow under the program as of March 31, 2012 was $150.0 million.

[0001193125-12-177598:mdna:84]
Dividend payments are expected to be approximately $36 million in 2012. We also continue to increase shareholder value through our share
repurchase program. We are planning a minimum of $50 million in share repurchases in 2012.

[0001193125-12-177598:mdna:85]
[same as prior period, unchanged from 0000950123-11-091697:mdna:128]

[0001193125-12-177598:mdna:86]
In addition to the credit facilities and promissory notes described above, we also lease real estate and machinery and equipment pursuant
to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.

[0001193125-12-177598:mdna:87]
Commitments, Contingencies and Guarantees

[0001193125-12-177598:mdna:88]
For a detailed discussion of
commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001193125-12-177598:mdna:89]
The estimate of
our liability for future warranty costs requires us to make significant assumptions about the amount, timing and nature of the costs we will incur in the future. We review the assumptions used to determine the liability periodically and we adjust
our assumptions based upon factors such as actual failure rates and cost experience. Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, and changes in manufacturing
techniques or locations, components or suppliers used. In recent years, changes in the warranty liability as the result of the issuance of new warranties and the payments made have remained relatively stable. Should actual warranty costs differ from
our estimates, we may be required to record adjustments to accruals and expense in the future. At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year, we perform a complete reevaluation
of our warranty liabilities.

[0001193125-12-177598:mdna:90]
We also may incur costs related to our products that may not be covered under our warranties and
are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied
components that fail to meet required specifications. We have identified a product quality issue

[0001193125-12-177598:mdna:91]
in a heating and cooling product line produced in the 2006 and 2007 time period that we believe results from a vendor-supplied materials quality issue. No material charges were recorded for this
matter in the first quarter of 2012. As of March 31, 2012, we had $6.3 million accrued for this matter. We may incur additional charges in the future as more information becomes available.

[0001193125-12-177598:mdna:92]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts known. We do not
believe that any current, pending or threatened litigation with have a material adverse effect on our financial position. Litigation, however, involves uncertainties and it is possible that the eventual outcome of litigation could adversely affect
our results of operations for a particular period.
