# LII notes — 0001193125-12-177598


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-177598:notes:1]
[same as prior period, unchanged from 0000950123-11-091697:notes:1]

[0001193125-12-177598:notes:2]
References in this Quarterly Report on Form 10-Q to “we,” “our,” “us,” “LII” or
   the “Company” refer to Lennox International Inc. and its subsidiaries, unless the context requires otherwise.

[0001193125-12-177598:notes:3]
[same as prior period, unchanged from 0000950123-11-091697:notes:3]

[0001193125-12-177598:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2012, the accompanying unaudited Consolidated Statements of
   Operations for the three months ended March 31, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2012 and 2011, and the accompanying unaudited Consolidated Statements of Cash
   Flows for the three months ended March 31, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2011. The
   accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of
   Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash
   flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures
   herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001193125-12-177598:notes:5]
Our fiscal year ends on December 31 and our quarters are each comprised of 13 weeks. For convenience, throughout these financial
   statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.

[0001193125-12-177598:notes:6]
[same as prior period, unchanged from 0000950123-11-091697:notes:6]

[0001193125-12-177598:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the
   underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable,
   inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, and pension and postretirement medical benefits, among others.
   These estimates and assumptions are based on management’s best estimates and judgment.

[0001193125-12-177598:notes:8]
We evaluate these estimates and
   assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and adjust such estimates and assumptions
   when facts and circumstances dictate.

[0001193125-12-177598:notes:9]
[same as prior period, unchanged from 0000950123-11-091697:notes:9]

[0001193125-12-177598:notes:10]
[same as prior period, unchanged from 0000950123-11-091697:notes:10]

[0001193125-12-177598:notes:11]
[same as prior period, unchanged from 0000950123-11-091697:notes:11]

[0001193125-12-177598:notes:12]
In June 2011, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”)
   No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income (“ASU 2011-05”). This ASU eliminates the option to present the components of other comprehensive income as part of the statement of
   stockholders’ equity. Rather, it gives an entity the choice to present the components of net income and other comprehensive income in either a single continuous statement or two separate but consecutive statements. The components of
   comprehensive income and timing of reclassification of an item to net income do not change with this update. ASU 2011-05 requires retrospective application and is effective for annual and interim periods beginning after December 15, 2011. We adopted this ASU in the
   first quarter of 2012 and have presented separate Consolidated Statements of Comprehensive Income.

[0001193125-12-177598:notes:13]
In September 2011, the FASB issued ASU No. 2011-08, Intangibles – Goodwill and Other (Topic 350):Testing
   Goodwill for Impairment (“ASU 2011-08”) related to goodwill impairment guidance. This ASU gives an option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that
   it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If after assessing all events and circumstances, an entity determines it is not more likely than not that the fair value of a reporting unit is less
   than its carrying amount, the performance of the two-step impairment test is unnecessary. The effective date is for fiscal years beginning after December 15, 2011. We adopted this ASU in the first quarter of 2012. See Note 3 for the results of
   our annual goodwill impairment test.

[0001193125-12-177598:notes:14]
In December 2011, the FASB issued ASU No. 2011-12, Comprehensive Income
   (Topic 220): Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update No. 2011-05. This ASU defers including the
   reclassification adjustments in the income statement but does not defer reclassification adjustments in other comprehensive income. We have included the reclassification adjustments in other comprehensive income in the Consolidated Statements of
   Comprehensive Income as allowed in this ASU.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-177598:notes:15]
[same as prior period, unchanged from 0000950123-11-091697:notes:15]

[0001193125-12-177598:notes:16]
[same as prior period, unchanged from 0000950123-11-091697:notes:16]

[0001193125-12-177598:notes:17]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Finished goods |  | $ | 288.3 |  |  | $ | 222.3 |  |
| Work in process |  |  | 14.7 |  |  |  | 13.3 |  |
| Raw materials and repair parts |  |  | 172.5 |  |  |  | 162.3 |  |
|  |  |  | 475.5 |  |  |  | 397.9 |  |
| Excess of current cost over last-in, first-out cost and other items |  |  | (73.6 | ) |  |  | (73.9 | ) |
| Total inventories, net |  | $ | 401.9 |  |  | $ | 324.0 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-12-177598:notes:18]
3. Goodwill:

[0001193125-12-177598:notes:19]
The changes in the carrying amount of goodwill for the first three months of 2012, in total and by segment, are as
   follows (in millions):

[0001193125-12-177598:notes:20]
|  |  | Balance atDecember 31,2011 |  |  |  |  |  |  |  |  | Balance atMarch 31,2012 |  |
| Segment: |  | Goodwill |  |  | Acquisitions/(Dispositions) |  |  | Other(2) |  |  | Goodwill |  |
| Residential Heating & Cooling |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling |  |  | 29.4 |  |  |  | — |  |  |  | 0.5 |  |  |  | 29.9 |  |
| Service Experts (1) |  |  | 116.5 |  |  |  | — |  |  |  | 3.1 |  |  |  | 119.6 |  |
| Refrigeration |  |  | 133.6 |  |  |  | — |  |  |  | 1.4 |  |  |  | 135.0 |  |
|  |  | $ | 305.6 |  |  | $ | — |  |  | $ | 5.0 |  |  | $ | 310.6 |  |

[0001193125-12-177598:notes:21]
| (1) | Service Experts goodwill includes accumulated impairment losses of $208.0 million from prior periods with no impairment losses in the current year. |

[0001193125-12-177598:notes:22]
| (2) | Other consists primarily of changes in foreign currency translation rates. |

[0001193125-12-177598:notes:23]
We performed our
   annual goodwill impairment test in the first quarter of 2012. We implemented ASU 2011-08 in the first quarter of 2012 which allows for an assessment of qualitative factors to determine if it is more likely than not the fair value of our reporting
   units is less than the carrying value including goodwill. Based on this qualitative assessment, as of the date of our annual impairment test, we believe it is more likely than not that our fair values exceed our carrying values; therefore, the
   traditional two step impairment test was not performed and we recognized no goodwill impairment for any of our reporting units. We will continue to monitor our reporting units throughout the year to determine if a change in facts and circumstances
   warrants a re-evaluation of our goodwill.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-12-177598:notes:24]
4. Derivatives:

[0001193125-12-177598:notes:25]
[same as prior period, unchanged from 0000950123-11-091697:notes:26]

[0001193125-12-177598:notes:26]
[same as prior period, unchanged from 0000950123-11-091697:notes:27]

[0001193125-12-177598:notes:27]
We utilize a cash flow hedging program to mitigate
   our exposure to volatility in the prices of metal commodities we use in our production processes. The hedging program includes the use of futures contracts. We enter into these contracts based on our hedging strategy, a dollar cost averaging
   strategy. As part of this strategy, a higher percentage of commodity price exposures are hedged near term with lower percentages hedged at future dates. This strategy provides us with protection against near-term price volatility while allowing us
   to adjust to market price movements over time. Upon entering into futures contracts, we lock in prices and are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.

[0001193125-12-177598:notes:28]
[same as prior period, unchanged from 0000950123-11-091697:notes:29]

[0001193125-12-177598:notes:29]
A
   portion of our debt bears interest at variable interest rates, and therefore, we are subject to variability in the cash paid for interest. In order to mitigate a portion of the risk, we use a hedging strategy to eliminate the variability of cash
   flows in the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the benchmark interest rate. This strategy allows us to fix a
   portion of our variable interest payments.

[0001193125-12-177598:notes:30]
On June 12, 2009, we entered into a $100 million pay-fixed, receive-variable
   interest rate swap with a large financial institution at a fixed interest rate of 2.66%. The variable portion of the interest rate swap is tied to the 1-Month LIBOR (the benchmark interest rate). The interest rates under both the interest rate swap
   and the underlying debt are reset, the swap is settled with the counterparty, and the interest is paid, on a monthly basis. The interest rate swap expires October 12, 2012. We account for the interest rate swap as a cash flow hedge.

[0001193125-12-177598:notes:31]
[same as prior period, unchanged from 0000950123-11-091697:notes:31]

[0001193125-12-177598:notes:32]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in
   foreign currencies. Our objective for entering into foreign currency forward contracts is to mitigate the impact of short-term currency exchange rate movements on certain short-term intercompany transactions. In order to meet that objective, we
   periodically enter into foreign currency forward contracts that act as economic hedges against changes in foreign currency exchange rates. These forward contracts are not designated as hedges and generally expire during the quarter that we enter
   into them. By entering into these forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001193125-12-177598:notes:33]
[same as prior period, unchanged from 0000950123-11-091697:notes:33]

[0001193125-12-177598:notes:34]
We include gains or losses in AOCI in connection with our commodity cash
   flow hedges. The gains or losses related to commodity price hedges are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates. Assuming that commodity prices remain
   constant, $0.1 million of derivative losses are expected to be reclassified into earnings within the next 12 months. Commodity futures contracts that are designated as cash flow hedges and are in place as of March 31, 2012 are scheduled to
   mature through August 2013.

[0001193125-12-177598:notes:35]
We also include gains or losses in AOCI from our $100 million pay-fixed, receive-variable
   interest rate swap. Assuming that the benchmark interest rate remains constant, $0.8 million of derivative losses are expected to be reclassified into earnings within the next 12 months. The interest rate swap expires October 12, 2012.

[0001193125-12-177598:notes:36]
We recorded the
   following amounts related to our cash flow hedges (in millions):

[0001193125-12-177598:notes:37]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Commodity Price Hedges: |  |  |  |  |  |  |  |  |
| (Gains) losses included in AOCI, net of tax |  | $ | (0.4 | ) |  | $ | 6.1 |  |
| Provision for (benefit from) income taxes |  |  | 0.2 |  |  |  | (3.5 | ) |
| Interest Rate Swap: |  |  |  |  |  |  |  |  |
| Losses included in AOCI, net of tax |  | $ | 0.8 |  |  | $ | 1.1 |  |
| Benefit from income taxes |  |  | (0.5 | ) |  |  | (0.6 | ) |

[0001193125-12-177598:notes:38]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions):

[0001193125-12-177598:notes:39]
|  |  | As ofMarch 31, 2012 |  |  | As ofDecember 31, 2011 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 21.2 |  |  |  |  |  | 23.3 |  |

[0001193125-12-177598:notes:40]
[same as prior period, unchanged from 0000950123-11-091697:notes:40]

[0001193125-12-177598:notes:41]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges. We elect not to designate these derivatives as cash flow
   hedges at the inception of the arrangement. We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions):

[0001193125-12-177598:notes:42]
|  |  | As ofMarch 31, 2012 |  |  | As ofDecember 31, 2011 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 2.6 |  |  |  |  |  | 2.8 |  |
| Aluminum |  |  | 2.8 |  |  |  |  |  | 3.0 |  |

[0001193125-12-177598:notes:43]
We had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001193125-12-177598:notes:44]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Notional amounts: |  |  |  |  |  |  |  |  |
| Brazilian Real |  |  | 4.4 |  |  |  | 4.5 |  |
| U.S. Dollars |  |  | 0.8 |  |  |  | 2.0 |  |
| Mexican Peso |  |  | 250.0 |  |  |  | 172.0 |  |
| Euros |  |  | — |  |  |  | 7.8 |  |
| British Pounds |  |  | 6.0 |  |  |  | 6.5 |  |
| Indian Rupees |  |  | 195.0 |  |  |  | — |  |

[0001193125-12-177598:notes:45]
[same as prior period, unchanged from 0000950123-11-091697:notes:45]

[0001193125-12-177598:notes:46]
The following table provides the location and amounts of derivative fair values in the Consolidated Balance Sheets and derivative
   gains and losses in the Consolidated Statements of Operations (in millions):

[0001193125-12-177598:notes:47]
|  |  | Fair Values of Derivative Instruments(1) |  |
|  |  | Derivatives Designated asHedging Instruments |  |  | Derivatives Not Designated asHedging Instruments |  |
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 1.2 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | 1.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | 0.5 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | — |  |
| Total Assets |  | $ | 1.7 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | 1.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 1.0 |  |  | $ | 9.4 |  |  | $ | 0.6 |  |  | $ | 1.8 |  |
| Interest rate swap |  |  | 1.3 |  |  |  | 1.8 |  |  |  | — |  |  |  | — |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | — |  |  |  | 0.3 |  |  |  | — |  |  |  | 0.2 |  |
| Interest rate swap |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total Liabilities |  | $ | 2.3 |  |  | $ | 11.5 |  |  | $ | 0.7 |  |  | $ | 2.1 |  |

[0001193125-12-177598:notes:48]
| (1) | All our derivative instruments are classified as Level 2 within the fair value hierarchy. For more information on other fair value measurements, see Note 14. |

[0001193125-12-177598:notes:49]
| Derivatives Designated as Hedging Instruments |  |
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Amount of Loss or (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |  |
| Commodity futures contracts (1) |  | $ | 1.9 |  |  | $ | (5.2 | ) |
| Interest rate swap (2) |  |  | 0.6 |  |  |  | 0.6 |  |
|  |  | $ | 2.5 |  |  | $ | (4.6 | ) |
| Amount of (Gain) or Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |  |  |  |
| Commodity futures contracts (3) |  | $ | (0.1 | ) |  | $ | — |  |

[0001193125-12-177598:notes:50]
| Derivatives Not Designated as Hedging Instruments |  |
|  |  | For the Three MonthsEnded March, |  |
|  |  | 2012 |  |  | 2011 |  |
| Amount of (Gain) or Loss Recognized in Income on Derivatives: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (3) |  | $ | (1.3 | ) |  | $ | 0.1 |  |
| Foreign currency forward contracts (3) |  |  | — |  |  |  | 0.9 |  |
|  |  | $ | (1.3 | ) |  | $ | 1.0 |  |

[0001193125-12-177598:notes:51]
| (1) | The loss (gain) is recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations. |

[0001193125-12-177598:notes:52]
| (2) | The loss (gain) is recorded in Interest expense, net in the accompanying Consolidated Statements of Operations. |

[0001193125-12-177598:notes:53]
| (3) | The loss (gain) is recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-177598:notes:54]
5. Income Taxes:

[0001193125-12-177598:notes:55]
As of March 31, 2012, we had approximately $6.0 million in total gross unrecognized tax benefits. Of this amount,
   $5.9 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations. As of March 31, 2012, we recognized $0.1 million (net of federal tax benefits) in interest and penalties in income tax expense in accordance with FASB
   Accounting Standards Codification (“ASC”) Topic 740.

[0001193125-12-177598:notes:56]
We are currently under examination for our U.S. federal income
   taxes for 2011 and 2012 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany. We are generally no longer subject to U.S. federal, state and
   local, or non-U.S. income tax examinations by taxing authorities for years before 2007.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-177598:notes:57]
6. Commitments and Contingencies:

[0001193125-12-177598:notes:58]
We are subject to contingencies that arise in the normal course of business, including product warranties and other
   product related contingencies, pending litigation, environmental matters and other guarantees or claims.

[0001193125-12-177598:notes:59]
We use a combination
   of third-party insurance and self-insurance plans (large deductible or captive) to provide protection against claims relating to contingencies such as workers’ compensation, general liability, product liability, property damage, aviation
   liability, directors’ and officers’ liability, auto liability, physical damage and other exposures. Self-insurance expense and liabilities are actuarially determined based on our historical claims information, as well as industry factors
   and trends. Because we have a captive insurance company, we are required to maintain specified levels of liquid assets from which we must pay claims. The majority of our self-insured risks (excluding auto liability and physical damage) will be paid
   over an extended period of time. There have been no material changes in our insurance liability since our latest fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our large deductible or captive insurance
   plans. The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were $65.0 million and $63.3 million as of March 31, 2012 and December 31, 2011, respectively.

[0001193125-12-177598:notes:60]
Product Warranties and Product Related Contingencies

[0001193125-12-177598:notes:61]
Total liabilities for estimated product warranty are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001193125-12-177598:notes:62]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Accrued expenses |  | $ | 28.3 |  |  | $ | 29.4 |  |
| Other liabilities |  |  | 43.4 |  |  |  | 41.8 |  |
|  |  | $ | 71.7 |  |  | $ | 71.2 |  |

[0001193125-12-177598:notes:63]
The changes in total product warranty liabilities for the first quarter of 2012 were as follows (in millions):

[0001193125-12-177598:notes:64]
| Total warranty liability as of December 31, 2011 |  | $ | 71.2 |  |
| Payments made in 2012 |  |  | (6.1 | ) |
| Changes resulting from issuance of new warranties |  |  | 6.2 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | 0.1 |  |
| Changes in foreign currency translation rates and other |  |  | 0.3 |  |
| Total warranty liability as of March 31, 2012 |  | $ | 71.7 |  |

[0001193125-12-177598:notes:65]
At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year,
   we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities.

[0001193125-12-177598:notes:66]
We incur the risk of liability claims for the installation and service of heating and air conditioning products, and we maintain
   liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an
   adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material
   changes in the circumstances that affect our product warranties since our latest fiscal year-end.

[0001193125-12-177598:notes:67]
We may also incur
   costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to
   protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001193125-12-177598:notes:68]
In addition to normal product warranty, we identified a product quality issue in a heating and cooling product line produced in 2006 and 2007 that we believe resulted from a vendor-supplied materials
   quality issue. The expense for this product quality issue, and the related liability, is not included in the above tables related to our estimated warranty liabilities. The expense related to this product quality issue was classified in Cost of
   Goods Sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in
   the accrued product quality issue for the first quarter of 2012 were as follows (in millions):

[0001193125-12-177598:notes:69]
| Total accrued product quality issue as of December 31, 2011 |  | $ | 7.5 |  |
| Product quality claims |  |  | (1.2 | ) |
| Total accrued product quality issue as of March 31, 2012 |  | $ | 6.3 |  |

[0001193125-12-177598:notes:70]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts
   known. We do not believe that any current or pending or threatened litigation will have a material adverse effect on our financial position. Litigation and arbitration, however, involve uncertainties and it is possible that the eventual
   outcome of litigation could adversely affect our results of operations for a particular period.

[0001193125-12-177598:notes:71]
Our obligations under the Lake
   Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic
   Revolving Credit Facility. We were in compliance with these financial covenants as of March 31, 2012.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-177598:notes:72]
7. Lines of Credit and Financing Arrangements:

[0001193125-12-177598:notes:73]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated
   Balance Sheets (in millions):

[0001193125-12-177598:notes:74]
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 11.4 |  |  | $ | 4.7 |  |
| Total short-term debt |  | $ | 11.4 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: |  | $ | 0.6 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.5 |  |  |  | 16.6 |  |
| Domestic revolving credit facility |  |  | 295.0 |  |  |  | 243.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 511.5 |  |  | $ | 459.6 |  |
| Total debt |  | $ | 523.5 |  |  | $ | 465.1 |  |

[0001193125-12-177598:notes:75]
Short-Term Debt

[0001193125-12-177598:notes:76]
Foreign Obligations

[0001193125-12-177598:notes:77]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs
   for our foreign locations. We had $11.4 million and $4.7 million of foreign obligations as of March 31, 2012 and December 31, 2011, respectively.

[0001193125-12-177598:notes:78]
Asset Securitization Program

[0001193125-12-177598:notes:79]
Under a Receivables Purchase Agreement (“RPA”), we are eligible to sell beneficial interests in a portion of our
   trade accounts receivable to participating financial institutions for cash. The RPA is subject to renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued
   involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the
   accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. The RPA provides for a maximum securitization amount of $150.0 million or
   100% of the net pool balance as defined by the RPA. However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The beneficial interest sold cannot exceed the
   maximum amount even if our qualifying accounts receivable is greater than the maximum amount at any point in time. On March 30, 2012, the parties involved with this securitization program agreed to remove Lennox Hearth Products LLC from the
   program. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. The eligible amounts available and beneficial
   interests sold were as follows (in millions):

[0001193125-12-177598:notes:80]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Eligible amount available under the RPA on qualified accounts receivable |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 150.0 |  |  | $ | 150.0 |  |

[0001193125-12-177598:notes:81]
Under the RPA, we pay certain discount fees to use the program and have the facility available to us. These fees relate
   to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee
   of 0.60%. The average rate for March 31, 2012 was 0.85% and the average rate at December 31, 2011 was 0.91%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed
   rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the RPA recorded was as follows (in millions):

[0001193125-12-177598:notes:82]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Interest expense (including fees) |  | $ | 0.3 |  |  | $ | 0.1 |  |

[0001193125-12-177598:notes:83]
The RPA contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default
   provisions with our Domestic Revolving Credit Facility and senior unsecured notes. The administrative agent under the RPA is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade
   credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the RPA. As of March 31, 2012, we were in compliance with all covenant requirements.

[0001193125-12-177598:notes:84]
Long-Term Debt

[0001193125-12-177598:notes:85]
Domestic
   Revolving Credit Facility

[0001193125-12-177598:notes:86]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of
   $295.0 million and $78.5 million committed to standby letters of credit as of March 31, 2012. Subject to covenant limitations, $276.5 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of
   letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of
   $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001193125-12-177598:notes:87]
Our weighted average
   borrowing rate on the facility was as follows:

[0001193125-12-177598:notes:88]
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Weighted average borrowing rate |  |  | 1.49 | % |  |  | 1.53 | % |

[0001193125-12-177598:notes:89]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants
   relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit
   Facility are detailed below:

[0001193125-12-177598:notes:90]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |

[0001193125-12-177598:notes:91]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default
   include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our revolving credit
   facility could occur if:

[0001193125-12-177598:notes:92]
|  | • |  | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001193125-12-177598:notes:93]
|  | • |  | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001193125-12-177598:notes:94]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross
   default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, or our RPA were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or
   lease commitment.

[0001193125-12-177598:notes:95]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may
   require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such
   amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2012, we were in compliance with all covenant requirements.

[0001193125-12-177598:notes:96]
Senior Unsecured Notes

[0001193125-12-177598:notes:97]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and
   November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

[0001193125-12-177598:notes:98]
The notes are
   guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other
   things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our
   assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded
   within 30 days of the notice date. As of March 31, 2012, we were in compliance with all covenant requirements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-12-177598:notes:99]
8. Pension and Postretirement Benefit Plans:

[0001193125-12-177598:notes:100]
[same as prior period, unchanged from 0000950123-11-091697:notes:105]

[0001193125-12-177598:notes:101]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
|  |  | Pension Benefits |  |  | Other Benefits |  |
| Service cost |  | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | 0.3 |  |  | $ | 0.2 |  |
| Interest cost |  |  | 4.3 |  |  |  | 4.5 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Expected return on plan assets |  |  | (4.7 | ) |  |  | (4.8 | ) |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.1 |  |  |  | 0.1 |  |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Amortization of net loss |  |  | 2.2 |  |  |  | 1.7 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Settlements or curtailments |  |  | — |  |  |  | 1.5 |  |  |  | — |  |  |  | — |  |
| Total net periodic pension cost |  | $ | 3.3 |  |  | $ | 4.4 |  |  | $ | 0.3 |  |  | $ | 0.2 |  |

[0001193125-12-177598:notes:102]
Pension expense includes pension benefits of $3.3 million and $4.0 million in Income from continuing operations for the three months
   ended March 31, 2012 and 2011, respectively, and $0.4 million in Loss from discontinued operations in the three months ended March 31, 2011. The pension expense for other benefits is included in Income from continuing operations for the
   three months ended March 31, 2012 and 2011.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-177598:notes:103]
9. Stock-Based Compensation:

[0001193125-12-177598:notes:104]
The Lennox International Inc. 2010 Incentive Plan, as amended and restated, provides for various long-term incentive
   awards, which include performance share units, restricted stock units and stock appreciation rights. Net stock-based compensation expense recognized was as follows (in millions):

[0001193125-12-177598:notes:105]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net stock-based compensation expense |  | $ | 3.8 |  |  | $ | 4.9 |  |

[0001193125-12-177598:notes:106]
Net stock-based compensation expense includes $4.3 million in Selling, General and Administrative Expenses and a $0.5
   million benefit in Loss from discontinued operations for shares that were probable of forfeiture as of March 31, 2012 due to the pending Hearth sale in the accompanying Consolidated Statements of Operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-12-177598:notes:107]
10. Restructuring Charges:

[0001193125-12-177598:notes:108]
As part of our strategic priorities of manufacturing and sourcing excellence and expense reduction, we initiated
   various manufacturing rationalization actions designed to lower our cost structure. We expanded these expense reductions across the organization by initiating a number of activities to rationalize and reorganize various support and administrative
   functions. Restructuring charges are not included in our calculation of segment profit (loss), see Note 13 for further discussion. Detailed below are the restructuring activities that we incurred additional expense in 2012.

[0001193125-12-177598:notes:109]
[same as prior period, unchanged from 0000950123-11-091697:notes:122]

[0001193125-12-177598:notes:110]
[same as prior period, unchanged from 0000950123-11-091697:notes:123]

[0001193125-12-177598:notes:111]
We began to exit certain Refrigeration manufacturing operations in Milperra, Australia in 2010, specifically our OEM coil
   manufacturing and contract coil manufacturing. The exit of our OEM coil manufacturing was substantially complete in 2010. We initiated restructuring activities related to exiting contract coil manufacturing in the third quarter of 2010. The
   remaining costs related to this restructuring activity primarily relate to plant closure costs. In the first quarter of 2012, we recognized $0.2 million in plant closure costs. We reversed $0.3 million in severance charges in the first quarter of
   2012 to adjust estimated charges for our OEM coil manufacturing restructuring to actual.

[0001193125-12-177598:notes:112]
[same as prior period, unchanged from 0000950123-11-091697:notes:125]

[0001193125-12-177598:notes:113]
We began to reorganize certain administrative functions and the management structure of our Service Experts business in 2010 and initiated
   two actions. The first action was to reorganize the administrative operations of an acquired company and was completed in 2010. The second action, initiated in the fourth quarter of 2010, was to reorganize the management structure of our Service
   Experts business. We recognized $0.4 million in severance and other costs in the first quarter of 2012. This reorganization is substantially complete.

[0001193125-12-177598:notes:114]
[same as prior period, unchanged from 0000950123-11-091697:notes:127]

[0001193125-12-177598:notes:115]
[same as prior period, unchanged from 0000950123-11-091697:notes:132]

[0001193125-12-177598:notes:116]
In the fourth quarter of 2008, we commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa
   to other locations, including our North American Distribution Center in Marshalltown, Iowa. In the first quarter of 2012, we recognized $2.6 million primarily in lease termination charges. The total expected restructuring charges for the regional
   distribution network is $6.6 million of which $6.2 million were incurred to date.

[0001193125-12-177598:notes:117]
[same as prior period, unchanged from 0000950123-11-091697:notes:134]

[0001193125-12-177598:notes:118]
[same as prior period, unchanged from 0000950123-11-091697:notes:135]

[0001193125-12-177598:notes:119]
|  |  | ChargesIncurred in 2012 |  |  | ChargesIncurred to Date |  |  | TotalCharges Expected tobe Incurred |  |
| Severance and related expense |  | $ | — |  |  | $ | 33.9 |  |  | $ | 33.9 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 11.8 |  |  |  | 11.8 |  |
| Equipment moves |  |  | 0.1 |  |  |  | 1.9 |  |  |  | 2.2 |  |
| Lease termination |  |  | 2.5 |  |  |  | 9.6 |  |  |  | 9.6 |  |
| Other |  |  | 0.5 |  |  |  | 18.3 |  |  |  | 19.3 |  |
| Total |  | $ | 3.1 |  |  | $ | 75.5 |  |  | $ | 76.8 |  |

[0001193125-12-177598:notes:120]
[same as prior period, unchanged from 0000950123-11-091697:notes:137]

[0001193125-12-177598:notes:121]
|  |  | ChargesIncurred in2012 |  |  | ChargesIncurred toDate |  |  | TotalChargesExpected tobe Incurred |  |
| Residential Heating & Cooling |  | $ | 2.7 |  |  | $ | 21.0 |  |  | $ | 22.1 |  |
| Commercial Heating & Cooling |  |  | — |  |  |  | 12.6 |  |  |  | 12.6 |  |
| Service Experts |  |  | 0.4 |  |  |  | 9.1 |  |  |  | 9.3 |  |
| Refrigeration |  |  | — |  |  |  | 27.1 |  |  |  | 27.1 |  |
| Corporate & Other |  |  | — |  |  |  | 5.7 |  |  |  | 5.7 |  |
| Total |  | $ | 3.1 |  |  | $ | 75.5 |  |  | $ | 76.8 |  |

[0001193125-12-177598:notes:122]
Restructuring reserves are included in Accrued Expenses in the accompanying Consolidated Balance Sheets. The table
   below details activity within the restructuring reserves for the first quarter of 2012 (in millions):

[0001193125-12-177598:notes:123]
| Description of Reserves |  | Balance as ofDecember 31,2011 |  |  | Chargedto Earnings |  |  | CashUtilization |  |  | Non-CashUtilizationand Other |  |  | Balance as ofMarch 31,2012 |  |
| Severance and related expense |  | $ | 2.5 |  |  | $ | — |  |  | $ | (0.7 | ) |  | $ | — |  |  | $ | 1.8 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |
| Lease termination |  |  | — |  |  |  | 2.5 |  |  |  | — |  |  |  | — |  |  |  | 2.5 |  |
| Other |  |  | 0.1 |  |  |  | 0.5 |  |  |  | (0.6 | ) |  |  | 0.1 |  |  |  | 0.1 |  |
| Total restructuring reserves |  | $ | 2.6 |  |  | $ | 3.1 |  |  | $ | (1.4 | ) |  | $ | 0.1 |  |  | $ | 4.4 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001193125-12-177598:notes:124]
11. Discontinued Operations:

[0001193125-12-177598:notes:125]
In the fourth quarter of 2011, we began to pursue strategic alternatives for our Hearth reporting unit due to the
   prolonged uncertainty of the residential new construction market and our outlook for this reporting unit. The Hearth reporting unit is heavily dependent on the residential new construction market; more so than our other reporting units due to its
   product offerings: fireplaces, stoves and venting products. In the first quarter of 2012, management committed to a plan to sell the Hearth business. This planned sale of the Hearth reporting unit qualified as a discontinued operation in the first quarter
   of 2012 and was reported as assets and liabilities held for sale for all periods presented. The Hearth reporting unit was previously included in our Residential Heating & Cooling segment. We recorded a $6.3 million pre-tax charge in
   discontinued operations in the first quarter of 2012 to write-down the net assets to their estimated fair value.

[0001193125-12-177598:notes:126]
A summary of
   net trade sales and pre-tax operating losses are detailed below (in millions):

[0001193125-12-177598:notes:127]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net trade sales |  | $ | 18.6 |  |  | $ | 18.4 |  |
| Pre-tax operating loss |  |  | (8.5 | ) |  |  | (5.7 | ) |

[0001193125-12-177598:notes:128]
The assets and liabilities of the discontinued operations are presented as follows in the accompanying Consolidated
   Balance Sheets (in millions):

[0001193125-12-177598:notes:129]
|  |  | As of March 31, |  |  | As ofDecember 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Assets of discontinued operations: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 8.5 |  |  | $ | 7.3 |  |
| Inventories, net |  |  | 13.7 |  |  |  | 12.4 |  |
| Deferred income taxes |  |  | 9.6 |  |  |  | 9.1 |  |
| Property, Plant and Equipment |  |  | — |  |  |  | 5.4 |  |
| Other assets |  |  | 0.6 |  |  |  | 0.8 |  |
| Liabilities of discontinued operations: |  |  |  |  |  |  |  |  |
| Accounts Payable |  | $ | 7.4 |  |  | $ | 6.0 |  |
| Accrued expenses |  |  | 4.1 |  |  |  | 5.2 |  |
| Pensions |  |  | 3.5 |  |  |  | — |  |
| Other Liabilities |  |  | 0.4 |  |  |  | 0.4 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-177598:notes:130]
12. Loss Per Share:

[0001193125-12-177598:notes:131]
Due to the net losses recorded in the first quarters of 2012 and 2011, basic loss per share is computed by dividing net
   loss by the weighted-average number of common shares outstanding during the period. Diluted loss per share is computed by dividing net loss by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding,
   if dilutive, under our stock-based compensation plans.

[0001193125-12-177598:notes:132]
The computations of basic and diluted loss per share for Loss from
   Continuing Operations were as follows (in millions, except per share data):

[0001193125-12-177598:notes:133]
|  |  | For theThree Months EndedMarch 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net loss |  | $ | (6.1 | ) |  | $ | (7.2 | ) |
| Add: Loss from discontinued operations |  |  | (5.6 | ) |  |  | (3.7 | ) |
| Loss from continuing operations |  | $ | (0.5 | ) |  | $ | (3.5 | ) |
| Weighted-average shares outstanding – basic and diluted |  |  | 50.9 |  |  |  | 53.6 |  |
| Loss per share from continuing operations – basic and diluted |  |  | (0.01 | ) |  |  | (0.06 | ) |
| Loss per share from discontinued operations – basic and diluted |  |  | (0.11 | ) |  |  | (0.07 | ) |
| Net loss per share |  | $ | (0.12 | ) |  | $ | (0.13 | ) |

[0001193125-12-177598:notes:134]
Not included in the
   2012 and 2011 computations of diluted loss per share were 636,860 and 1,128,847 shares, respectively, of potentially dilutive securities, including stock options, stock appreciation rights, restricted stock units and performance share units as these
   shares would be anti-dilutive. The shares were anti-dilutive due to the loss position in both periods.

[0001193125-12-177598:notes:135]
Additionally, stock
   appreciation rights were outstanding, but not included in the diluted loss per share calculation because the assumed exercise of such rights would be anti-dilutive. The details are as follows:

[0001193125-12-177598:notes:136]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Number of shares |  |  | 1,136,015 |  |  |  | 464,314 |  |
| Price ranges per share |  | $ | 34.06-46.78 |  |  | $ | 46.78 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-177598:notes:137]
13. Reportable Business Segments:

[0001193125-12-177598:notes:138]
We operate in four reportable business segments of the heating, ventilation, air conditioning and refrigeration
   (“HVACR”) industry. Our segments are organized primarily by the nature of the products and services provided. The table below details the nature of the operations for each reportable segment:

[0001193125-12-177598:notes:139]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Heating Air Conditioning |  | Residential Replacement Residential New Construction |  | United States Canada |
| Commercial Heating & Cooling |  | Rooftop Products Chillers Air Handlers |  | Light Commercial |  | United States Canada Europe |
| Service Experts |  | Equipment Sales Installation Maintenance Repair |  | Residential Light Commercial |  | United States Canada |
| Refrigeration |  | Unit Coolers Condensing Units Other Commercial Refrigeration Products Display Cases and Systems |  | Light Commercial Food Preservation and Non-Food/Industrial |  | United States Canada Europe Asia Pacific South America Mexico |

[0001193125-12-177598:notes:140]
Transactions between segments, such as products sold to Service Experts by the Residential Heating & Cooling
   segment, are recorded on an arm’s-length basis using the market price for these products. The eliminations of these intercompany sales and any associated profit are noted in the reconciliation of segment results to the income from continuing
   operations before income taxes below.

[0001193125-12-177598:notes:141]
We use segment profit or loss as the primary measure of profitability to evaluate
   operating performance and to allocate capital resources. We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations
   excluding certain items. The reconciliation below details the items excluded.

[0001193125-12-177598:notes:142]
Our corporate costs include those costs related
   to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII. We recorded
   these share-based awards as Corporate costs as they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001193125-12-177598:notes:143]
Net sales and segment profit (loss) by business segment, along with a reconciliation of segment profit (loss) to Loss from Continuing
   Operations Before Income Taxes are shown below (in millions):

[0001193125-12-177598:notes:144]
|  |  | For the Three Months EndedMarch 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 272.6 |  |  | $ | 253.6 |  |
| Commercial Heating & Cooling |  |  | 137.0 |  |  |  | 138.8 |  |
| Service Experts |  |  | 101.6 |  |  |  | 116.5 |  |
| Refrigeration |  |  | 185.1 |  |  |  | 175.1 |  |
| Eliminations (1) |  |  | (12.1 | ) |  |  | (14.6 | ) |
|  |  | $ | 684.2 |  |  | $ | 669.4 |  |
| Segment Profit (Loss)(2) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 11.0 |  |  | $ | 4.4 |  |
| Commercial Heating & Cooling |  |  | 6.0 |  |  |  | 5.9 |  |
| Service Experts |  |  | (11.5 | ) |  |  | (8.2 | ) |
| Refrigeration |  |  | 14.2 |  |  |  | 13.5 |  |
| Corporate and other |  |  | (14.4 | ) |  |  | (14.5 | ) |
| Eliminations (1) |  |  | (0.2 | ) |  |  | (0.3 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 5.1 |  |  |  | 0.8 |  |
| Reconciliation to loss from continuing operations before income taxes: |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | (0.4 | ) |  |  | — |  |
| Items in Gains and other expenses, net that are excluded from segment profit (loss) (3) |  |  | (1.5 | ) |  |  | 0.9 |  |
| Restructuring charges |  |  | 3.1 |  |  |  | 1.2 |  |
| Interest expense, net |  |  | 4.7 |  |  |  | 4.1 |  |
| Other expense, net |  |  | — |  |  |  | — |  |
| Loss from continuing operations before income taxes |  | $ | (0.8 | ) |  | $ | (5.4 | ) |

[0001193125-12-177598:notes:145]
| (1) | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |

[0001193125-12-177598:notes:146]
| (2) | We define segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-12-177598:notes:147]
|  | • |  | Special product quality adjustments. |

[0001193125-12-177598:notes:148]
|  | • |  | Items within Gains and other expenses, net that are noted in (3). |

[0001193125-12-177598:notes:149]
|  | • |  | Restructuring charges. |

[0001193125-12-177598:notes:150]
|  | • |  | Interest expense, net. |

[0001193125-12-177598:notes:151]
|  | • |  | Acquisition costs. |

[0001193125-12-177598:notes:152]
|  | • |  | Other expense, net. |

[0001193125-12-177598:notes:153]
| (3) | Items in Gains and other expenses, net that are excluded from segment profit are net change in unrealized gains and/or losses on open futures contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-177598:notes:154]
14. Fair Value Measurements:

[0001193125-12-177598:notes:155]
[same as prior period, unchanged from 0000950123-11-091697:notes:162]

[0001193125-12-177598:notes:156]
The following table presents the fair value hierarchy for those assets and liabilities measured at fair value on a recurring basis (in
   millions):

[0001193125-12-177598:notes:157]
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Assets: |  |  |  |  |  |  |  |  |
| Investment in marketable equity securities (1) |  | $ | 8.6 |  |  | $ | 8.4 |  |

[0001193125-12-177598:notes:158]
| (1) | Investment in marketable equity securities is recorded in Other Assets, net in the accompanying Consolidated Balance Sheets. |

[0001193125-12-177598:notes:159]
[same as prior period, unchanged from 0000950123-11-091697:notes:166]

[0001193125-12-177598:notes:160]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net, accounts payable, other current
   liabilities, and short-term debt approximate fair value due to the short maturities of these instruments. The fair values of each of our long-term debt instruments are based on the quoted market prices for the same issues or on the amount of future
   cash flows associated with each instrument using current market rates for debt instruments of similar maturities and credit risk. The fair values presented are estimates and are not necessarily indicative of amounts for which we could settle such
   instruments currently or indicative of our intent or ability to dispose of or liquidate them. The estimated fair value of our debt was as follows (in millions):

[0001193125-12-177598:notes:161]
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Senior unsecured notes |  | $ | 211.1 |  |  | $ | 207.0 |  |


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0001193125-12-177598:notes:162]
15. Condensed Consolidating Financial Statements:

[0001193125-12-177598:notes:163]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries
   (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). As a result of the guarantee arrangements, we are required to present the following condensed consolidating
   financial statements.

[0001193125-12-177598:notes:164]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity
   method of accounting. Intercompany account balances have been included in Accounts and notes receivable, Other assets (Current), Other assets, net, Short-term debt, Accounts payable, and Long-term debt line items of the Parent, Guarantor and
   Non-Guarantor balance sheets. The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001193125-12-177598:notes:165]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of March 31, 2012 and December 31, 2011 and for the three months ended
   March 31, 2012 and 2011 are shown below:

[0001193125-12-177598:notes:166]
Condensed
   Consolidating Balance Sheets

[0001193125-12-177598:notes:167]
As of March 31, 2012

[0001193125-12-177598:notes:168]
[same as prior period, unchanged from 0000950123-11-091697:notes:178]

[0001193125-12-177598:notes:169]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 0.9 |  |  | $ | 16.9 |  |  | $ | 36.9 |  |  | $ | — |  |  | $ | 54.7 |  |
| Accounts and notes receivable, net |  |  | (910.5 | ) |  |  | 860.2 |  |  |  | 418.6 |  |  |  | 26.4 |  |  |  | 394.7 |  |
| Inventories, net |  |  | — |  |  |  | 295.2 |  |  |  | 111.5 |  |  |  | (4.8 | ) |  |  | 401.9 |  |
| Deferred income taxes, net |  |  | 2.3 |  |  |  | 23.4 |  |  |  | 8.4 |  |  |  | (1.3 | ) |  |  | 32.8 |  |
| Other assets |  |  | 1.7 |  |  |  | 21.1 |  |  |  | 123.6 |  |  |  | (64.6 | ) |  |  | 81.8 |  |
| Assets of discontinued operations |  |  | — |  |  |  | 25.6 |  |  |  | 6.8 |  |  |  | — |  |  |  | 32.4 |  |
| Total current assets |  |  | (905.6 | ) |  |  | 1,242.4 |  |  |  | 705.8 |  |  |  | (44.3 | ) |  |  | 998.3 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 245.3 |  |  |  | 53.9 |  |  |  | — |  |  |  | 299.2 |  |
| GOODWILL |  |  | — |  |  |  | 133.9 |  |  |  | 176.7 |  |  |  | — |  |  |  | 310.6 |  |
| DEFERRED INCOME TAXES |  |  | (0.3 | ) |  |  | 89.7 |  |  |  | 19.4 |  |  |  | (9.7 | ) |  |  | 99.1 |  |
| OTHER ASSETS, net |  |  | 2,167.1 |  |  |  | 556.1 |  |  |  | 24.6 |  |  |  | (2,665.0 | ) |  |  | 82.8 |  |
| TOTAL ASSETS |  | $ | 1,261.2 |  |  | $ | 2,267.4 |  |  | $ | 980.4 |  |  | $ | (2,719.0 | ) |  | $ | 1,790.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 119.5 |  |  | $ | — |  |  | $ | (70.6 | ) |  | $ | (37.5 | ) |  | $ | 11.4 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.4 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.6 |  |
| Accounts payable |  |  | 9.2 |  |  |  | 177.7 |  |  |  | 83.4 |  |  |  | 37.1 |  |  |  | 307.4 |  |
| Accrued expenses |  |  | 7.7 |  |  |  | 170.0 |  |  |  | 78.3 |  |  |  | (0.1 | ) |  |  | 255.9 |  |
| Income taxes payable |  |  | (2.6 | ) |  |  | 4.7 |  |  |  | 31.3 |  |  |  | (27.7 | ) |  |  | 5.7 |  |
| Liabilities of discontinued operations |  |  | — |  |  |  | 12.2 |  |  |  | 3.2 |  |  |  | — |  |  |  | 15.4 |  |
| Total current liabilities |  |  | 133.8 |  |  |  | 365.0 |  |  |  | 125.8 |  |  |  | (28.2 | ) |  |  | 596.4 |  |
| LONG-TERM DEBT |  |  | 495.0 |  |  |  | 16.1 |  |  |  | 98.6 |  |  |  | (98.2 | ) |  |  | 511.5 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 18.9 |  |  |  | — |  |  |  | — |  |  |  | 18.9 |  |
| PENSIONS |  |  | — |  |  |  | 108.1 |  |  |  | 13.1 |  |  |  | — |  |  |  | 121.2 |  |
| OTHER LIABILITIES |  |  | 0.8 |  |  |  | 60.4 |  |  |  | 14.0 |  |  |  | (11.0 | ) |  |  | 64.2 |  |
| Total liabilities |  |  | 629.6 |  |  |  | 568.5 |  |  |  | 251.5 |  |  |  | (137.4 | ) |  |  | 1,312.2 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 631.6 |  |  |  | 1,698.9 |  |  |  | 728.9 |  |  |  | (2,581.6 | ) |  |  | 477.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,261.2 |  |  | $ | 2,267.4 |  |  | $ | 980.4 |  |  | $ | (2,719.0 | ) |  | $ | 1,790.0 |  |

[0001193125-12-177598:notes:170]
Condensed
   Consolidating Statements of Operations

[0001193125-12-177598:notes:171]
For the Three Months Ended March 31, 2012

[0001193125-12-177598:notes:172]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 523.2 |  |  | $ | 208.1 |  |  | $ | (47.1 | ) |  | $ | 684.2 |  |
| COST OF GOODS SOLD |  |  | — |  |  |  | 408.2 |  |  |  | 156.9 |  |  |  | (47.0 | ) |  |  | 518.1 |  |
| Gross profit |  |  | — |  |  |  | 115.0 |  |  |  | 51.2 |  |  |  | (0.1 | ) |  |  | 166.1 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 121.6 |  |  |  | 41.4 |  |  |  | — |  |  |  | 163.0 |  |
| (Gains) losses and other expenses, net |  |  | (1.6 | ) |  |  | (0.7 | ) |  |  | 0.8 |  |  |  | — |  |  |  | (1.5 | ) |
| Restructuring charges |  |  | — |  |  |  | 3.1 |  |  |  | — |  |  |  | — |  |  |  | 3.1 |  |
| Loss (income) from equity method investments |  |  | 6.8 |  |  |  | 2.1 |  |  |  | (1.9 | ) |  |  | (9.4 | ) |  |  | (2.4 | ) |
| (Loss) income from continuing operations |  |  | (5.2 | ) |  |  | (11.1 | ) |  |  | 10.9 |  |  |  | 9.3 |  |  |  | 3.9 |  |
| INTEREST EXPENSE (INCOME), net |  |  | 4.4 |  |  |  | (0.5 | ) |  |  | 0.8 |  |  |  | — |  |  |  | 4.7 |  |
| (Loss) income from continuing operations before income taxes |  |  | (9.6 | ) |  |  | (10.6 | ) |  |  | 10.1 |  |  |  | 9.3 |  |  |  | (0.8 | ) |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (1.0 | ) |  |  | (2.8 | ) |  |  | 3.6 |  |  |  | (0.1 | ) |  |  | (0.3 | ) |
| Loss income from continuing operations |  |  | (8.6 | ) |  |  | (7.8 | ) |  |  | 6.5 |  |  |  | 9.4 |  |  |  | (0.5 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | (2.2 | ) |  |  | (3.4 | ) |  |  | — |  |  |  | (5.6 | ) |
| Net (loss) income |  | $ | (8.6 | ) |  | $ | (10.0 | ) |  | $ | 3.1 |  |  | $ | 9.4 |  |  | $ | (6.1 | ) |

[0001193125-12-177598:notes:173]
As of December 31, 2011

[0001193125-12-177598:notes:174]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1.0 |  |  | $ | 9.7 |  |  | $ | 34.4 |  |  | $ | (0.1 | ) |  | $ | 45.0 |  |
| Accounts and notes receivable, net |  |  | (991.9 | ) |  |  | 950.1 |  |  |  | 422.6 |  |  |  | 20.6 |  |  |  | 401.4 |  |
| Inventories, net |  |  | — |  |  |  | 221.2 |  |  |  | 107.5 |  |  |  | (4.7 | ) |  |  | 324.0 |  |
| Deferred income taxes, net |  |  | 4.7 |  |  |  | 23.5 |  |  |  | 8.3 |  |  |  | (1.3 | ) |  |  | 35.2 |  |
| Other assets |  |  | 1.6 |  |  |  | 21.7 |  |  |  | 108.6 |  |  |  | (56.5 | ) |  |  | 75.4 |  |
| Assets of discontinued operations |  |  | — |  |  |  | 24.7 |  |  |  | 10.3 |  |  |  | — |  |  |  | 35.0 |  |
| Total current assets |  |  | (984.6 | ) |  |  | 1,250.9 |  |  |  | 691.7 |  |  |  | (42.0 | ) |  |  | 916.0 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 251.7 |  |  |  | 52.8 |  |  |  | — |  |  |  | 304.5 |  |
| GOODWILL |  |  | — |  |  |  | 133.4 |  |  |  | 172.2 |  |  |  | — |  |  |  | 305.6 |  |
| DEFERRED INCOME TAXES |  |  | 0.2 |  |  |  | 89.8 |  |  |  | 19.2 |  |  |  | (9.7 | ) |  |  | 99.5 |  |
| OTHER ASSETS, net |  |  | 2,174.6 |  |  |  | 532.8 |  |  |  | 22.2 |  |  |  | (2,649.5 | ) |  |  | 80.1 |  |
| TOTAL ASSETS |  | $ | 1,190.2 |  |  | $ | 2,258.6 |  |  | $ | 958.1 |  |  | $ | (2,701.2 | ) |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 112.1 |  |  | $ | — |  |  | $ | (67.3 | ) |  | $ | (40.1 | ) |  | $ | 4.7 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.6 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.8 |  |
| Accounts payable |  |  | 9.2 |  |  |  | 133.5 |  |  |  | 96.9 |  |  |  | 31.4 |  |  |  | 271.0 |  |
| Accrued expenses |  |  | 15.3 |  |  |  | 177.0 |  |  |  | 87.3 |  |  |  | (0.1 | ) |  |  | 279.5 |  |
| Income taxes payable |  |  | (29.9 | ) |  |  | 28.0 |  |  |  | 24.7 |  |  |  | (17.1 | ) |  |  | 5.7 |  |
| Liabilities of discontinued operations |  |  | — |  |  |  | 8.2 |  |  |  | 3.4 |  |  |  | — |  |  |  | 11.6 |  |
| Total current liabilities |  |  | 106.7 |  |  |  | 347.3 |  |  |  | 145.2 |  |  |  | (25.9 | ) |  |  | 573.3 |  |
| LONG-TERM DEBT |  |  | 443.0 |  |  |  | 16.2 |  |  |  | 97.3 |  |  |  | (96.9 | ) |  |  | 459.6 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 18.6 |  |  |  | — |  |  |  | — |  |  |  | 18.6 |  |
| PENSIONS |  |  | — |  |  |  | 111.9 |  |  |  | 12.8 |  |  |  | — |  |  |  | 124.7 |  |
| OTHER LIABILITIES |  |  | 0.8 |  |  |  | 58.6 |  |  |  | 13.3 |  |  |  | (11.0 | ) |  |  | 61.7 |  |
| Total liabilities |  |  | 550.5 |  |  |  | 552.6 |  |  |  | 268.6 |  |  |  | (133.8 | ) |  |  | 1,237.9 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 639.7 |  |  |  | 1,706.0 |  |  |  | 689.5 |  |  |  | (2,567.4 | ) |  |  | 467.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,190.2 |  |  | $ | 2,258.6 |  |  | $ | 958.1 |  |  | $ | (2,701.2 | ) |  | $ | 1,705.7 |  |

[0001193125-12-177598:notes:175]
For the Three Months Ended March 31, 2011

[0001193125-12-177598:notes:176]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 500.6 |  |  | $ | 213.3 |  |  | $ | (44.5 | ) |  | $ | 669.4 |  |
| COST OF GOODS SOLD |  |  | — |  |  |  | 388.0 |  |  |  | 162.7 |  |  |  | (45.6 | ) |  |  | 505.1 |  |
| Gross profit |  |  | — |  |  |  | 112.6 |  |  |  | 50.6 |  |  |  | 1.1 |  |  |  | 164.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 122.3 |  |  |  | 45.0 |  |  |  | — |  |  |  | 167.3 |  |
| Losses (gains) and other expenses, net |  |  | 0.9 |  |  |  | (1.2 | ) |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | (0.3 | ) |
| Restructuring charges |  |  | — |  |  |  | 0.7 |  |  |  | 0.5 |  |  |  | — |  |  |  | 1.2 |  |
| Loss (income) from equity method investments |  |  | 6.0 |  |  |  | 1.1 |  |  |  | (2.3 | ) |  |  | (7.4 | ) |  |  | (2.6 | ) |
| (Loss) income from continuing operations |  |  | (6.9 | ) |  |  | (10.3 | ) |  |  | 7.6 |  |  |  | 8.3 |  |  |  | (1.3 | ) |
| INTEREST EXPENSE (INCOME), net |  |  | 4.0 |  |  |  | (0.8 | ) |  |  | 1.0 |  |  |  | (0.1 | ) |  |  | 4.1 |  |
| (Loss) income from continuing operations before income taxes |  |  | (10.9 | ) |  |  | (9.5 | ) |  |  | 6.6 |  |  |  | 8.4 |  |  |  | (5.4 | ) |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (1.8 | ) |  |  | (3.0 | ) |  |  | 2.8 |  |  |  | 0.1 |  |  |  | (1.9 | ) |
| (Loss) income from continuing operations |  |  | (9.1 | ) |  |  | (6.5 | ) |  |  | 3.8 |  |  |  | 8.3 |  |  |  | (3.5 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | (3.4 | ) |  |  | (0.3 | ) |  |  | — |  |  |  | (3.7 | ) |
| Net (loss) income |  | $ | (9.1 | ) |  | $ | (9.9 | ) |  | $ | 3.5 |  |  | $ | 8.3 |  |  | $ | (7.2 | ) |

[0001193125-12-177598:notes:177]
Condensed
   Consolidating Statements of Cash Flows

[0001193125-12-177598:notes:178]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | 30.9 |  |  | $ | (71.5 | ) |  | $ | 6.3 |  |  | $ | — |  |  | $ | (34.3 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (5.7 | ) |  |  | (1.1 | ) |  |  | — |  |  |  | (6.8 | ) |
| Net cash used in discontinued operations |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Net cash used in investing activities |  |  | — |  |  |  | (5.7 | ) |  |  | (1.1 | ) |  |  | — |  |  |  | (6.8 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 6.6 |  |  |  | — |  |  |  | 6.6 |  |
| Asset securitization borrowings |  |  | — |  |  |  | — |  |  |  | 170.0 |  |  |  | — |  |  |  | 170.0 |  |
| Asset securitization payments |  |  | — |  |  |  | — |  |  |  | (170.0 | ) |  |  | — |  |  |  | (170.0 | ) |
| Long-term payments |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |
| Revolver long-term borrowings |  |  | 267.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 267.5 |  |
| Revolver long-term payments |  |  | (215.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (215.5 | ) |
| Proceeds from stock option exercises |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.1 |  |
| Repurchases of common stock |  |  | (1.9 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.9 | ) |
| Excess tax benefits related to share-based payments |  |  | 0.8 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.8 |  |
| Intercompany debt |  |  | 8.5 |  |  |  | (2.2 | ) |  |  | (6.3 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (81.3 | ) |  |  | 86.8 |  |  |  | (5.5 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (9.2 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (9.2 | ) |
| Net cash (used in) provided by financing activities |  |  | (31.0 | ) |  |  | 84.4 |  |  |  | (5.2 | ) |  |  | — |  |  |  | 48.2 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | (0.1 | ) |  |  | 7.2 |  |  |  | — |  |  |  | — |  |  |  | 7.1 |  |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 2.6 |  |  |  | — |  |  |  | 2.6 |  |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 1.0 |  |  |  | 9.7 |  |  |  | 34.3 |  |  |  | — |  |  |  | 45.0 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | 0.9 |  |  | $ | 16.9 |  |  | $ | 36.9 |  |  | $ | — |  |  | $ | 54.7 |  |

[0001193125-12-177598:notes:179]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | 59.7 |  |  | $ | (131.0 | ) |  | $ | (77.0 | ) |  | $ | — |  |  | $ | (148.3 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.7 |  |  |  | — |  |  |  | — |  |  |  | 0.7 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (7.1 | ) |  |  | (0.8 | ) |  |  | — |  |  |  | (7.9 | ) |
| Proceeds from sale of business |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Acquisition of business |  |  | — |  |  |  | (136.3 | ) |  |  | (7.9 | ) |  |  | — |  |  |  | (144.2 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 1.6 |  |  |  | — |  |  |  | 1.6 |  |
| Net cash used in discontinued operations |  |  | — |  |  |  | (0.3 | ) |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |
| Net cash used in investing activities |  |  | — |  |  |  | (143.0 | ) |  |  | (7.1 | ) |  |  | — |  |  |  | (150.1 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 1.2 |  |  |  | — |  |  |  | 1.2 |  |
| Asset securitization borrowings |  |  |  |  |  |  | — |  |  |  | 50.0 |  |  |  | — |  |  |  | 50.0 |  |
| Long-term payments |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |
| Revolver long-term borrowings |  |  | 339.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 339.0 |  |
| Revolver long-term payments |  |  | (167.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (167.5 | ) |
| Proceeds from stock option exercises |  |  | 0.9 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.9 |  |
| Payments of deferred financing costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Repurchases of common stock |  |  | (24.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (24.7 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.2 |  |
| Intercompany debt |  |  | 1.8 |  |  |  | (2.3 | ) |  |  | 0.5 |  |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (283.4 | ) |  |  | 275.6 |  |  |  | 7.8 |  |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (8.1 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (8.1 | ) |
| Net cash (used in) provided by financing activities |  |  | (140.8 | ) |  |  | 273.1 |  |  |  | 59.5 |  |  |  | — |  |  |  | 191.8 |  |
| (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | (81.1 | ) |  |  | (0.9 | ) |  |  | (24.6 | ) |  |  | — |  |  |  | (106.6 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 1.8 |  |  |  | — |  |  |  | 1.8 |  |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 81.1 |  |  |  | 14.7 |  |  |  | 64.2 |  |  |  | — |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | — |  |  | $ | 13.8 |  |  | $ | 41.4 |  |  | $ | — |  |  | $ | 55.2 |  |
