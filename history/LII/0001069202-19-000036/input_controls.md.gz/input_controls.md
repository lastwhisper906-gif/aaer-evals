# LII 10-Q controls and the auditor's report


## item_4_controls

[0001069202-19-000036:item_4_controls:1]
Item 4.  Controls and Procedures

[0001069202-19-000036:item_4_controls:2]
Disclosure Controls and Procedures

[0001069202-19-000036:item_4_controls:3]
As required by Rule 13a-15 under the Exchange Act, we carried out an evaluation, under the supervision and with the participation of our current management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures as of the end of the period covered by this report.  There are inherent limitations to the effectiveness of any system of disclosure controls and procedures, including the possibility of human error and circumvention or overriding of the controls and procedures. Accordingly, even effective disclosure controls and procedures can only provide reasonable assurance of achieving their control objectives. Based on that evaluation, the Chief Executive Officer and Chief Financial Officer have concluded that, as of September 30, 2019, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in the reports we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the applicable rules and forms, and that such information is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosure.

[0001069202-19-000036:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0001069202-19-000036:item_4_controls:5]
In the first quarter of 2019, we implemented new controls as part of our efforts to adopt ASU 2016-02.  We  implemented new controls related to the adoption process, a new IT system to capture, calculate, and account for leases, and gather the necessary data to properly account for leases under ASC 842.  There were no other changes in our internal control over financial reporting that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
