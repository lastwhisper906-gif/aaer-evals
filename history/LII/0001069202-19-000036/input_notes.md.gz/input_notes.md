# LII notes — 0001069202-19-000036


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-19-000036:notes:1]
[same as prior period, unchanged from 0001069202-19-000030:notes:1]

[0001069202-19-000036:notes:2]
[same as prior period, unchanged from 0001069202-19-000030:notes:2]

[0001069202-19-000036:notes:3]
[same as prior period, unchanged from 0001069202-19-000030:notes:3]

[0001069202-19-000036:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2019, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Stockholders' (Deficit) Equity for the three and nine months ended September 30, 2019 and 2018, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2019 and 2018 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2018. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-19-000036:notes:5]
[same as prior period, unchanged from 0001069202-19-000030:notes:5]

[0001069202-19-000036:notes:6]
[same as prior period, unchanged from 0001069202-19-000030:notes:6]

[0001069202-19-000036:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-19-000036:notes:8]
[same as prior period, unchanged from 0001069202-19-000030:notes:8]

[0001069202-19-000036:notes:9]
Recently Adopted Accounting Guidance

[0001069202-19-000036:notes:10]
[same as prior period, unchanged from 0001069202-19-000030:notes:12]

[0001069202-19-000036:notes:11]
We adopted other new accounting standards during the first quarter of 2019 and their impacts are discussed in their respective Notes to the Consolidated Financial Statements.

[0001069202-19-000036:notes:12]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable

[0001069202-19-000036:notes:13]
information to estimate credit losses. ASU 2016-13 is effective for SEC filers for interim and annual periods beginning after December 15, 2019.  We are currently assessing the impact ASU 2016-13, but do not expect it to have a material impact on our financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-19-000036:notes:14]
[same as prior period, unchanged from 0001069202-19-000030:notes:14]

[0001069202-19-000036:notes:15]
[same as prior period, unchanged from 0001069202-19-000030:notes:15]

[0001069202-19-000036:notes:16]
|  | For the Three Months Ended September 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 597.3 |  |  | $ | 227.0 |  |  | $ | 82.5 |  |  | $ | 906.8 |  |
| Canada | 40.3 |  |  | 26.0 |  |  | — |  |  | 66.3 |  |
| International | — |  |  | 0.3 |  |  | 59.5 |  |  | 59.8 |  |
| Total | $ | 637.6 |  |  | $ | 253.3 |  |  | $ | 142.0 |  |  | $ | 1,032.9 |  |

[0001069202-19-000036:notes:17]
|  | For the Three Months Ended September 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 553.8 |  |  | $ | 212.4 |  |  | $ | 114.0 |  |  | $ | 880.2 |  |
| Canada | 40.9 |  |  | 24.3 |  |  | 2.1 |  |  | 67.3 |  |
| International | — |  |  | 0.2 |  |  | 82.5 |  |  | 82.7 |  |
| Total | $ | 594.7 |  |  | $ | 236.9 |  |  | $ | 198.6 |  |  | $ | 1,030.2 |  |

[0001069202-19-000036:notes:18]
|  | For the Nine Months Ended September 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,677.6 |  |  | $ | 623.3 |  |  | $ | 254.1 |  |  | $ | 2,555.0 |  |
| Canada | 114.6 |  |  | 63.8 |  |  | 0.7 |  |  | 179.1 |  |
| International | — |  |  | 0.8 |  |  | 187.3 |  |  | 188.1 |  |
| Total | $ | 1,792.2 |  |  | $ | 687.9 |  |  | $ | 442.1 |  |  | $ | 2,922.2 |  |

[0001069202-19-000036:notes:19]
|  | For the Nine Months Ended September 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,640.9 |  |  | $ | 604.5 |  |  | $ | 322.4 |  |  | $ | 2,567.8 |  |
| Canada | 123.5 |  |  | 62.7 |  |  | 4.1 |  |  | 190.3 |  |
| International | — |  |  | 0.9 |  |  | 281.4 |  |  | 282.3 |  |
| Total | $ | 1,764.4 |  |  | $ | 668.1 |  |  | $ | 607.9 |  |  | $ | 3,040.4 |  |

[0001069202-19-000036:notes:20]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2019 and 2018, direct sales represented 74% and 77% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2019 and 2018, direct sales represented 74% and 76% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-19-000036:notes:21]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.    For the three months ended September 30, 2019 and 2018, equipment sales represented 86% and 86% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2019 and 2018, equipment sales represented 86% and 86% of revenues and the remainder was generated from our service business.

[0001069202-19-000036:notes:22]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Less than 1% of segment revenue relates to services for start-up and commissioning activities.

[0001069202-19-000036:notes:23]
[same as prior period, unchanged from 0001069202-19-000030:notes:23]

[0001069202-19-000036:notes:24]
[same as prior period, unchanged from 0001069202-19-000030:notes:24]

[0001069202-19-000036:notes:25]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets, net in our Consolidated Balance Sheets.

[0001069202-19-000036:notes:26]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheets.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.

[0001069202-19-000036:notes:27]
[same as prior period, unchanged from 0001069202-19-000030:notes:27]

[0001069202-19-000036:notes:28]
|  | September 30, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | $ | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (8.4 | ) |  | (13.0 | ) |  | 4.6 |  |  | (35.4 | )% |
| Contract liabilities - noncurrent | (5.9 | ) |  | (5.9 | ) |  | — |  |  | — | % |
| Total | $ | (14.3 | ) |  | $ | (16.4 | ) |  | $ | 2.1 |  |  |  |

[0001069202-19-000036:notes:29]
For the three months ended September 30, 2019 and 2018, we recognized revenue of $0.2 million and $1.3 million and for the nine months ended September 30, 2019 and 2018, we recognized revenue of $2.8 million and $4.2 million related to our contract

[0001069202-19-000036:notes:30]
liabilities at January 1, 2019 and  2018, respectively.  Impairment losses recognized in our receivables and contract assets were de minimis in 2018 and 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-19-000036:notes:31]
[same as prior period, unchanged from 0001069202-19-000030:notes:30]

[0001069202-19-000036:notes:32]
[same as prior period, unchanged from 0001069202-19-000030:notes:31]

[0001069202-19-000036:notes:33]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Finished goods | $ | 404.2 |  |  | $ | 330.5 |  |
| Work in process | 7.2 |  |  | 10.0 |  |
| Raw materials and parts | 233.5 |  |  | 229.1 |  |
| Subtotal | 644.9 |  |  | 569.6 |  |
| Excess of current cost over last-in, first-out cost | (59.6 | ) |  | (59.8 | ) |
| Total inventories, net | $ | 585.3 |  |  | $ | 509.8 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-19-000036:notes:34]
Goodwill:
The changes in the carrying amount of goodwill for the first nine months of 2019, in total and by segment, are summarized in the table below (in millions):

[0001069202-19-000036:notes:35]
|  | Balance at December 31, 2018 |  | Goodwill Reallocation (1) |  | Changes in foreign currency translation rates |  | Balance at September 30, 2019 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.4 |  |  | (0.3 | ) |  | — |  |  | 61.1 |  |
| Refrigeration | 99.1 |  |  | 0.3 |  |  | (0.2 | ) |  | 99.2 |  |
| Total Goodwill | $ | 186.6 |  |  | $ | — |  |  | $ | (0.2 | ) |  | $ | 186.4 |  |

[0001069202-19-000036:notes:36]
[same as prior period, unchanged from 0001069202-19-000030:notes:35]

[0001069202-19-000036:notes:37]
[same as prior period, unchanged from 0001069202-19-000030:notes:36]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-19-000036:notes:38]
[same as prior period, unchanged from 0001069202-19-000030:notes:37]

[0001069202-19-000036:notes:39]
[same as prior period, unchanged from 0001069202-19-000030:notes:38]

[0001069202-19-000036:notes:40]
[same as prior period, unchanged from 0001069202-19-000030:notes:39]

[0001069202-19-000036:notes:41]
[same as prior period, unchanged from 0001069202-19-000030:notes:40]

[0001069202-19-000036:notes:42]
[same as prior period, unchanged from 0001069202-19-000030:notes:41]

[0001069202-19-000036:notes:43]
[same as prior period, unchanged from 0001069202-19-000030:notes:42]

[0001069202-19-000036:notes:44]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through December 2020 and February 2021, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-19-000036:notes:45]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Unrealized losses on unsettled contracts | $ | 3.8 |  |  | $ | 8.4 |  |
| Income tax benefit | (0.9 | ) |  | (2.2 | ) |
| Losses (gains) included in AOCL, net of tax (1) | $ | 2.9 |  |  | $ | 6.2 |  |

[0001069202-19-000036:notes:46]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $2.8 million of derivative losses into earnings within the next 12 months.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-19-000036:notes:47]
[same as prior period, unchanged from 0001069202-19-000030:notes:46]

[0001069202-19-000036:notes:48]
As of September 30, 2019, we had approximately $2.7 million in total gross unrecognized tax benefits.  Of this amount $2.7 million, if recognized, would be recorded through the Consolidated Statement of Operations.

[0001069202-19-000036:notes:49]
[same as prior period, unchanged from 0001069202-19-000030:notes:48]

[0001069202-19-000036:notes:50]
[same as prior period, unchanged from 0001069202-19-000030:notes:49]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-19-000036:notes:51]
Commitments and Contingencies:

[0001069202-19-000036:notes:52]
Leases

[0001069202-19-000036:notes:53]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). We adopted ASC 842 on January 1, 2019, using the effective date method, with the cumulative-effect adjustment to the opening balance sheet of retained earnings as of the effective date. The financial results reported in periods prior to January 1, 2019 are unchanged.  Upon adoption, we recognized almost all of our leases greater than one year in duration on the balance sheet as right-of-use assets and lease liabilities. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification is based on criteria that are largely similar to those applied in current lease accounting standard, but without explicit bright lines. We have made certain assumptions in judgments when applying ASC 842.  Those judgments of most significance are as follows:

[0001069202-19-000036:notes:54]
| • | We elected the package of practical expedients available for transition which allow us to not reassess: |

[0001069202-19-000036:notes:55]
| ◦ | Whether expired or existing contracts contain leases under the new definition of a lease; |

[0001069202-19-000036:notes:56]
| ◦ | Lease classification for expired or existing leases; and |

[0001069202-19-000036:notes:57]
| ◦ | Whether previously capitalized initial direct costs would qualify for capitalization under ASC 842. |

[0001069202-19-000036:notes:58]
| • | We did not elect to use hindsight for transition when considering judgments and estimates such as assessments of lessee options to extend or terminate a lease or purchase the underlying asset. |

[0001069202-19-000036:notes:59]
| • | We did not elect to reassess whether land easements meet the definition of a lease if they were not accounted for as leases under the former rules. |

[0001069202-19-000036:notes:60]
| • | For all asset classes, we elected to not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. |

[0001069202-19-000036:notes:61]
| • | For all asset classes, we elected to not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component. |

[0001069202-19-000036:notes:62]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheet as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated

[0001069202-19-000036:notes:63]
Balance Sheet. Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

[0001069202-19-000036:notes:64]
Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-19-000036:notes:65]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-19-000036:notes:66]
We lease certain real and personal property under non-cancelable operating leases.  Approximately 73% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-19-000036:notes:67]
The components of lease expense were as follows (in millions):

[0001069202-19-000036:notes:68]
|  | For the Three Months Ended September 30, 2019 |  | For the Nine Months Ended September 30, 2019 |
| Finance lease cost: |  |  |  |
| Amortization of right-of-use assets | $ | 1.9 |  |  | $ | 5.2 |  |
| Interest on lease liabilities | 0.2 |  |  | 0.5 |  |
| Operating lease cost | 14.7 |  |  | 44.0 |  |
| Short-term lease cost | 1.1 |  |  | 3.4 |  |
| Variable lease cost | 5.0 |  |  | 15.1 |  |
| Total lease cost | $ | 22.9 |  |  | $ | 68.2 |  |
| Other information |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 15.0 |  |  | $ | 42.4 |  |
| Financing cash flows from finance leases | $ | 2.0 |  |  | $ | 5.8 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 2.5 |  |  | $ | 8.5 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 10.3 |  |  | $ | 31.9 |  |

[0001069202-19-000036:notes:69]
|  | As of September 30, 2019 |
| Finance lease right-of-use assets | $ | 24.4 |  |
| Operating lease right-of-use assets | $ | 172.9 |  |
| Finance lease liability, current | $ | 6.9 |  |
| Finance lease liability, non-current | $ | 23.7 |  |
| Operating lease liability, current | $ | 51.6 |  |
| Operating lease liability, non-current | $ | 123.0 |  |
| Weighted-average remaining lease term - finance leases | 5.2 years |  |
| Weighted-average remaining lease term - operating leases | 4.2 years |  |
| Weighted-average discount rate - finance leases | 2.10 | % |
| Weighted-average discount rate – operating leases | 3.81 | % |

[0001069202-19-000036:notes:70]
Future annual minimum lease payments and finance lease commitments as of September 30, 2019 were as follows (in millions):

[0001069202-19-000036:notes:71]
|  | Operating Leases |  | Finance Leases |
| 2019 (excluding the nine months ended September 30, 2019) | $ | 14.9 |  |  | $ | 2.0 |  |
| 2020 | 55.3 |  |  | 7.1 |  |
| 2021 | 42.9 |  |  | 5.5 |  |
| 2022 | 30.3 |  |  | 3.6 |  |
| 2023 | 23.3 |  |  | 1.6 |  |
| 2024 and thereafter | 22.5 |  |  | 11.9 |  |
| Total minimum lease payments | $ | 189.2 |  |  | $ | 31.7 |  |
| Less imputed interest | (14.6 | ) |  | (1.1 | ) |
| Lease liability | $ | 174.6 |  |  | $ | 30.6 |  |

[0001069202-19-000036:notes:72]
The Company adopted ASU 2016-02 on January 1, 2019 as noted above, and as required, the following disclosure is provided for periods prior to adoption. Future annual minimum lease payments and capital lease commitments as of December 31, 2018 were as follows (in millions):

[0001069202-19-000036:notes:73]
|  | Operating Leases |  | Capital Leases |
| 2019 | $ | 47.4 |  |  | $ | 6.6 |  |
| 2020 | 38.4 |  |  | 5.4 |  |
| 2021 | 27.2 |  |  | 3.8 |  |
| 2022 | 17.9 |  |  | 2.1 |  |
| 2023 | 12.7 |  |  | 0.9 |  |
| Thereafter | 16.1 |  |  | 12.8 |  |
| Total minimum lease payments | $ | 159.7 |  |  | $ | 31.6 |  |
| Less amount representing interest |  |  | (2.1 | ) |
| Present value of minimum payments |  |  | $ | 29.5 |  |

[0001069202-19-000036:notes:74]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024. The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, we are obligated to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance of $41.2 million, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 87% of the lease balance.  The headquarters lease is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-19-000036:notes:75]
Our obligations under the headquarters lease are secured by a pledge of our interest in the leased property.  The lease contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of September 30, 2019.

[0001069202-19-000036:notes:76]
Product Warranties and Product Related Contingencies

[0001069202-19-000036:notes:77]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-19-000036:notes:78]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000036:notes:79]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Accrued expenses | $ | 38.2 |  |  | $ | 37.9 |  |
| Other liabilities | 75.8 |  |  | 73.7 |  |
| Total warranty liability | $ | 114.0 |  |  | $ | 111.6 |  |

[0001069202-19-000036:notes:80]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2019 were as follows (in millions):

[0001069202-19-000036:notes:81]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Warranty claims paid | (28.2 | ) |
| Changes resulting from issuance of new warranties | 36.0 |  |
| Changes in estimates associated with pre-existing liabilities | (4.8 | ) |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Warranty liability from divestitures | (0.4 | ) |
| Total warranty liability as of September 30, 2019 | $ | 114.0 |  |

[0001069202-19-000036:notes:82]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

[0001069202-19-000036:notes:83]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect was isolated, the vendor is supplying corrected components, and we are manufacturing products with the corrected components. We incurred and recorded insignificant expenses associated with this product quality in 2017. In the second quarter of 2019, the vendor agreed to reimburse us for certain losses incurred due to this quality issue.  These reimbursements include cash payments in 2019 and price reductions on annual qualifying purchases from this vendor through 2024.  Reimbursements we receive from the vendor will offset the costs we have incurred related to this product quality matter.

[0001069202-19-000036:notes:84]
Litigation

[0001069202-19-000036:notes:85]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-19-000036:notes:86]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and

[0001069202-19-000036:notes:87]
judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

[0001069202-19-000036:notes:88]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Expense for asbestos-related litigation | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 3.3 |  |  | $ | 3.3 |  |

[0001069202-19-000036:notes:89]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.

[0001069202-19-000036:notes:90]
Marshalltown Tornado and Recovery

[0001069202-19-000036:notes:91]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  We have insurance for the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in (Gain) loss from insurance recoveries, net of losses incurred in the Consolidated Statements of Operations.

[0001069202-19-000036:notes:92]
The following table summarizes the Gain from insurance recoveries, net of losses incurred:

[0001069202-19-000036:notes:93]
| (Amounts in millions) | For the Three months Ended September 30, |  | For the Nine months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Insurance recoveries received | $ | 10.0 |  |  | $ | 45.0 |  |  | $ | 138.0 |  |  | $ | 45.0 |  |
| Insurance recoveries receivable | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Less losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | (3.5 | ) |  | 28.4 |  |  | 19.8 |  |  | 28.4 |  |
| Factory inefficiencies due to lower productivity | 0.8 |  |  | 4.9 |  |  | 9.3 |  |  | 4.9 |  |
| Write-off of property, plant and equipment | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Write-off of inventory | — |  |  | 5.2 |  |  | — |  |  | 5.2 |  |
| Other | 5.6 |  |  | 6.7 |  |  | 23.5 |  |  | 6.7 |  |
| Total losses and expenses | $ | 2.9 |  |  | $ | 49.4 |  |  | $ | 52.6 |  |  | $ | 49.4 |  |
| Total gain (loss) from insurance recoveries | $ | 7.1 |  |  | $ | (0.3 | ) |  | $ | 85.4 |  |  | $ | (0.3 | ) |
| Components of (Gain) loss from insurance recoveries, net of losses incurred: |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits | (8.3 | ) |  | 0.3 |  |  | (73.8 | ) |  | 0.3 |  |
| (Gain) loss from insurance recoveries, net of losses incurred | 1.2 |  |  | — |  |  | (11.6 | ) |  | — |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-19-000036:notes:94]
Lines of Credit and Financing Arrangements:

[0001069202-19-000036:notes:95]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000036:notes:96]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 365.5 |  |  | $ | 268.0 |  |
| Finance lease obligations | 6.9 |  |  | 3.5 |  |
| Domestic credit facility | 22.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 394.3 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 23.7 |  |  | 15.7 |  |
| Domestic credit facility | 685.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.4 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,056.8 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,451.1 |  |  | $ | 1,041.3 |  |

[0001069202-19-000036:notes:97]
Short-Term Debt

[0001069202-19-000036:notes:98]
Foreign Obligations

[0001069202-19-000036:notes:99]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2019 or December 31, 2018.  There were $5.3 million in proceeds and repayments on these facilities for the nine months ended September 30, 2019.  Proceeds and repayments on these facilities were $39.6 million and $41.1 million, respectively, for the nine months ended September 30, 2018.

[0001069202-19-000036:notes:100]
Asset Securitization Program

[0001069202-19-000036:notes:101]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.  The ASP will expire in November 2019 and we intend to renew the ASP prior to its expiration.

[0001069202-19-000036:notes:102]
The ASP provides for a maximum securitization amount ranging from $225.0 million to $380.0 million, depending on the period. The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-19-000036:notes:103]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 380.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (365.5 | ) |  | (268.0 | ) |
| Remaining amount available | $ | 14.5 |  |  | $ | 22.0 |  |

[0001069202-19-000036:notes:104]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2019 and December 31, 2018 were 2.79% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-19-000036:notes:105]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of September 30, 2019, we believe we were in compliance with all covenant requirements.

[0001069202-19-000036:notes:106]
Long-Term Debt

[0001069202-19-000036:notes:107]
Domestic Credit Facility

[0001069202-19-000036:notes:108]
On January 22, 2019, we amended our Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $190.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $708.0 million, of which $160.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of September 30, 2019. Subject to covenant limitations, $449.5 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

[0001069202-19-000036:notes:109]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-19-000036:notes:110]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.31 | % |  | 3.74 | % |

[0001069202-19-000036:notes:111]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-19-000036:notes:112]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-19-000036:notes:113]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-19-000036:notes:114]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-19-000036:notes:115]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-19-000036:notes:116]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-19-000036:notes:117]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due

[0001069202-19-000036:notes:118]
and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2019, we believe we were in compliance with all covenant requirements.

[0001069202-19-000036:notes:119]
Senior Unsecured Notes

[0001069202-19-000036:notes:120]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2019, we believe we were in compliance with all covenant requirements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-19-000036:notes:121]
[same as prior period, unchanged from 0001069202-19-000030:notes:118]

[0001069202-19-000036:notes:122]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other expense (income), net in the Statement of Operations. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We elected the practical expedient to use the prior year's disclosure as a basis for the retroactive adoption of the ASU.  The ASU did not have a material impact on our financial results.

[0001069202-19-000036:notes:123]
[same as prior period, unchanged from 0001069202-19-000030:notes:120]

[0001069202-19-000036:notes:124]
The components of net periodic benefit cost for pensions benefits were as follows (in millions):

[0001069202-19-000036:notes:125]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Service cost | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 3.6 |  |  | $ | 4.0 |  |
| Interest cost | 2.7 |  |  | 3.1 |  |  | 8.1 |  |  | 9.3 |  |
| Expected return on plan assets | (3.6 | ) |  | (4.7 | ) |  | (10.8 | ) |  | (14.1 | ) |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Recognized actuarial loss | 1.4 |  |  | 2.3 |  |  | 4.3 |  |  | 6.9 |  |
| Other | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Settlements and curtailments | — |  |  | — |  |  | 60.6 |  |  | — |  |
| Net periodic benefit cost | $ | 1.8 |  |  | $ | 2.4 |  |  | $ | 65.9 |  |  | $ | 6.5 |  |

[0001069202-19-000036:notes:126]
[same as prior period, unchanged from 0001069202-19-000030:notes:123]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-19-000036:notes:127]
[same as prior period, unchanged from 0001069202-19-000030:notes:124]

[0001069202-19-000036:notes:128]
We issue various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights under the Lennox International Inc. 2019 Incentive Plan, as amended and restated.  Stock-based compensation expense related to continuing operations is included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-19-000036:notes:129]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Stock-based compensation expense (1) | $ | 4.2 |  |  | $ | 7.4 |  |  | $ | 15.6 |  |  | $ | 21.0 |  |

[0001069202-19-000036:notes:130]
[same as prior period, unchanged from 0001069202-19-000030:notes:127]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-19-000036:notes:131]
[same as prior period, unchanged from 0001069202-19-000030:notes:128]

[0001069202-19-000036:notes:132]
Our Board of Directors has authorized a total of $2.5 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in  March 2018. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of September 30, 2019, $46 million of shares may be repurchased under the Share Repurchase Plans.

[0001069202-19-000036:notes:133]
We repurchased 0.4 million shares for $100.0 million during the first quarter of 2019, 0.6 million shares for $150.0 million during the second quarter of 2019 and 0.5 million shares for $150.0 million during the third quarter of 2019, respectively, from open market transactions.

[0001069202-19-000036:notes:134]
We also repurchased 0.1 million shares for $16.9 million during the nine months ended September 30, 2019 from employees who surrendered shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-19-000036:notes:135]
[same as prior period, unchanged from 0001069202-19-000030:notes:131]

[0001069202-19-000036:notes:136]
[same as prior period, unchanged from 0001069202-19-000030:notes:132]

[0001069202-19-000036:notes:137]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts/foreign exchange forward contracts |  | $ | (2.5 | ) |  | $ | 0.3 |  |  | $ | (6.9 | ) |  | $ | 7.3 |  |  | Cost of goods sold |
| Income tax benefit (expense) |  | 0.5 |  |  | (0.1 | ) |  | 1.6 |  |  | (1.7 | ) |  | Provision for income taxes |
| Net of tax |  | $ | (2.0 | ) |  | $ | 0.2 |  |  | $ | (5.3 | ) |  | $ | 5.6 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.5 | ) |  | $ | (2.4 | ) |  | $ | (4.4 | ) |  | $ | (7.0 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Pension settlement |  | — |  |  | — |  |  | (60.6 | ) |  | — |  |  | Pension settlement |
| Income tax benefit |  | 0.4 |  |  | 0.6 |  |  | 16.2 |  |  | 1.7 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.1 | ) |  | $ | (1.8 | ) |  | $ | (48.8 | ) |  | $ | (5.3 | ) |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency adjustments on sale of businesses |  | $ | — |  |  | $ | (5.0 | ) |  | $ | (2.1 | ) |  | $ | (27.9 | ) |  | Loss (gain), net on sale of businesses and related property |
| Net of tax |  | $ | — |  |  | $ | (5.0 | ) |  | $ | (2.1 | ) |  | $ | (27.9 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (3.1 | ) |  | $ | (6.6 | ) |  | $ | (56.2 | ) |  | $ | (27.6 | ) |  |  |

[0001069202-19-000036:notes:138]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2019 (in millions):

[0001069202-19-000036:notes:139]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2018 |  | $ | (6.2 | ) |  | $ | (154.5 | ) |  | $ | (28.1 | ) |  | $ | (188.8 | ) |
| Other comprehensive income (loss) before reclassifications |  | (2.0 | ) |  | 9.8 |  |  | (2.4 | ) |  | 5.4 |  |
| Amounts reclassified from AOCL |  | 5.3 |  |  | 48.8 |  |  | 2.1 |  |  | 56.2 |  |
| Net other comprehensive (loss) income |  | 3.3 |  |  | 58.6 |  |  | (0.3 | ) |  | 61.6 |  |
| Balance as of Septemer 30, 2019 |  | $ | (2.9 | ) |  | $ | (95.9 | ) |  | $ | (28.4 | ) |  | $ | (127.2 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-19-000036:notes:140]
[same as prior period, unchanged from 0001069202-19-000030:notes:136]

[0001069202-19-000036:notes:141]
We record restructuring charges associated with management-approved restructuring plans when we reorganize or remove duplicative headcount or infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs, accelerated depreciation for impaired assets and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 16.

[0001069202-19-000036:notes:142]
Restructuring Activities in 2019

[0001069202-19-000036:notes:143]
In the third quarter of 2019, the Commercial Heating & Cooling and Corporate segments incurred restructuring charges primarily related to activities to re-align resources and its product portfolio.  Information regarding the restructuring charges for all ongoing activities is presented in the following table (in millions):

[0001069202-19-000036:notes:144]
|  | Charges Incurred in 2019 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 1.5 |  |  | $ | 3.9 |  |  | $ | 4.1 |  |
| Asset write-offs and accelerated depreciation | 5.3 |  |  | 5.3 |  |  | 5.3 |  |
| Lease termination | (0.3 | ) |  | 0.4 |  |  | 0.4 |  |
| Other | — |  |  | — |  |  | 1.4 |  |
| Total restructuring charges | $ | 6.5 |  |  | $ | 9.6 |  |  | $ | 11.2 |  |

[0001069202-19-000036:notes:145]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-19-000036:notes:146]
|  | Charges Incurred in 2019 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Commercial Heating & Cooling | 0.7 |  |  | 2.4 |  |  | 4.0 |  |
| Refrigeration | 0.7 |  |  | 2.1 |  |  | 2.1 |  |
| Corporate & Other | 5.1 |  |  | 5.1 |  |  | 5.1 |  |
| Total restructuring charges | $ | 6.5 |  |  | $ | 9.6 |  |  | $ | 11.2 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-19-000036:notes:147]
[same as prior period, unchanged from 0001069202-19-000030:notes:138]

[0001069202-19-000036:notes:148]
[same as prior period, unchanged from 0001069202-19-000030:notes:139]

[0001069202-19-000036:notes:149]
During the first quarter of 2019, we obtained Board of Directors' approval and signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. The sale was completed on March 29, 2019. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-19-000036:notes:150]
| (Amounts in millions) | For the Nine Months Ended September 30, 2019 |
| Cash received from the buyer | $ | 49.0 |  |
| Net assets sold | (50.5 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (2.1 | ) |
| Direct costs to sell | (5.5 | ) |
| Loss on sale of business | $ | (9.1 | ) |

[0001069202-19-000036:notes:151]
[same as prior period, unchanged from 0001069202-19-000030:notes:142]

[0001069202-19-000036:notes:152]
[same as prior period, unchanged from 0001069202-19-000030:notes:143]

[0001069202-19-000036:notes:153]
[same as prior period, unchanged from 0001069202-19-000030:notes:144]

[0001069202-19-000036:notes:154]
[same as prior period, unchanged from 0001069202-19-000030:notes:145]

[0001069202-19-000036:notes:155]
[same as prior period, unchanged from 0001069202-19-000030:notes:146]

[0001069202-19-000036:notes:156]
[same as prior period, unchanged from 0001069202-19-000030:notes:147]

[0001069202-19-000036:notes:157]
[same as prior period, unchanged from 0001069202-19-000030:notes:148]

[0001069202-19-000036:notes:158]
[same as prior period, unchanged from 0001069202-19-000030:notes:149]

[0001069202-19-000036:notes:159]
[same as prior period, unchanged from 0001069202-19-000030:notes:150]

[0001069202-19-000036:notes:160]
(2) Includes $1.2 million of net assets that were written down during the quarter ended June 30, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our South America business.

[0001069202-19-000036:notes:161]
The total Loss (gain), net on sale of businesses and related property in our Consolidated Statements of Operations for year ended December 31, 2018 of $27.0 million is comprised of the $13.3 million loss on the sale of our Australia, New Zealand and Asia business, the $23.8 million gain on the sale of our Milperra property, and the $37.5 million loss on the sale of our South America business.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001069202-19-000036:notes:162]
[same as prior period, unchanged from 0001069202-19-000030:notes:153]

[0001069202-19-000036:notes:163]
[same as prior period, unchanged from 0001069202-19-000030:notes:154]

[0001069202-19-000036:notes:164]
(2) Includes $1.2 million of net assets that were written down during the quarter ended June 30, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our South America business.
The following table summarizes the net loss recognized in connection with this divestiture:


## us-gaap:EarningsPerShareTextBlock

[0001069202-19-000036:notes:165]
[same as prior period, unchanged from 0001069202-19-000030:notes:156]

[0001069202-19-000036:notes:166]
[same as prior period, unchanged from 0001069202-19-000030:notes:157]

[0001069202-19-000036:notes:167]
[same as prior period, unchanged from 0001069202-19-000030:notes:158]

[0001069202-19-000036:notes:168]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net income | $ | 114.7 |  |  | $ | 108.0 |  |  | $ | 294.7 |  |  | $ | 283.4 |  |
| Add: Loss from discontinued operations | — |  |  | — |  |  | 0.3 |  |  | 1.7 |  |
| Income from continuing operations | $ | 114.7 |  |  | $ | 108.0 |  |  | $ | 295.0 |  |  | $ | 285.1 |  |
| Weighted-average shares outstanding – basic | 38.6 |  |  | 40.3 |  |  | 39.1 |  |  | 40.8 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.4 |  |  | 0.4 |  |  | 0.4 |  |  | 0.5 |  |
| Weighted-average shares outstanding – diluted | 39.0 |  |  | 40.7 |  |  | 39.5 |  |  | 41.3 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.97 |  |  | $ | 2.68 |  |  | $ | 7.54 |  |  | $ | 6.98 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01 | ) |  | (0.04 | ) |
| Net income | $ | 2.97 |  |  | $ | 2.68 |  |  | $ | 7.53 |  |  | $ | 6.94 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.94 |  |  | $ | 2.65 |  |  | $ | 7.46 |  |  | $ | 6.90 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | (0.04 | ) |
| Net income | $ | 2.94 |  |  | $ | 2.65 |  |  | $ | 7.46 |  |  | $ | 6.86 |  |

[0001069202-19-000036:notes:169]
[same as prior period, unchanged from 0001069202-19-000030:notes:160]

[0001069202-19-000036:notes:170]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Weighted-average number of shares | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Price per share | $ | — |  |  | $ | 205.53 |  |  | $ | — |  |  | $ | 205.53 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-19-000036:notes:171]
[same as prior period, unchanged from 0001069202-19-000030:notes:162]

[0001069202-19-000036:notes:172]
[same as prior period, unchanged from 0001069202-19-000030:notes:163]

[0001069202-19-000036:notes:173]
[same as prior period, unchanged from 0001069202-19-000030:notes:164]

[0001069202-19-000036:notes:174]
[same as prior period, unchanged from 0001069202-19-000030:notes:165]

[0001069202-19-000036:notes:175]
[same as prior period, unchanged from 0001069202-19-000030:notes:166]

[0001069202-19-000036:notes:176]
[same as prior period, unchanged from 0001069202-19-000030:notes:167]

[0001069202-19-000036:notes:177]
[same as prior period, unchanged from 0001069202-19-000030:notes:168]

[0001069202-19-000036:notes:178]
[same as prior period, unchanged from 0001069202-19-000030:notes:169]

[0001069202-19-000036:notes:179]
[same as prior period, unchanged from 0001069202-19-000030:notes:170]

[0001069202-19-000036:notes:180]
[same as prior period, unchanged from 0001069202-19-000030:notes:171]

[0001069202-19-000036:notes:181]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 637.6 |  |  | $ | 594.7 |  |  | $ | 1,792.2 |  |  | $ | 1,764.4 |  |
| Commercial Heating & Cooling | 253.3 |  |  | 236.9 |  |  | 687.9 |  |  | 668.1 |  |
| Refrigeration | 142.0 |  |  | 198.6 |  |  | 442.1 |  |  | 607.9 |  |
|  | $ | 1,032.9 |  |  | $ | 1,030.2 |  |  | $ | 2,922.2 |  |  | $ | 3,040.4 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 126.5 |  |  | $ | 113.0 |  |  | $ | 366.6 |  |  | $ | 317.9 |  |
| Commercial Heating & Cooling | 47.1 |  |  | 44.8 |  |  | 116.0 |  |  | 117.6 |  |
| Refrigeration | 19.8 |  |  | 24.9 |  |  | 47.3 |  |  | 57.1 |  |
| Corporate and other | (18.1 | ) |  | (28.1 | ) |  | (54.3 | ) |  | (61.8 | ) |
| Total segment profit | 175.3 |  |  | 154.6 |  |  | 475.6 |  |  | 430.8 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special inventory write down | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Special product quality adjustment | (0.5 | ) |  | — |  |  | (1.0 | ) |  | — |  |
| Loss (gain), net on sale of businesses and related property | 0.2 |  |  | 6.2 |  |  | 9.1 |  |  | 25.8 |  |
| Loss (gain) from insurance recoveries, net of losses incurred | 1.2 |  |  | 0.3 |  |  | (11.6 | ) |  | 0.3 |  |
| Prior quarter partial advance of insurance recoveries related to lost profits | 8.0 |  |  | — |  |  | — |  |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 3.5 |  |  | 2.4 |  |  | 7.3 |  |  | 9.3 |  |
| Restructuring charges | 6.1 |  |  | 0.5 |  |  | 6.5 |  |  | 1.9 |  |
| Operating income | $ | 156.8 |  |  | $ | 145.2 |  |  | $ | 465.3 |  |  | $ | 393.3 |  |

[0001069202-19-000036:notes:182]
[same as prior period, unchanged from 0001069202-19-000030:notes:173]

[0001069202-19-000036:notes:183]
[same as prior period, unchanged from 0001069202-19-000030:notes:174]

[0001069202-19-000036:notes:184]
[same as prior period, unchanged from 0001069202-19-000030:notes:175]

[0001069202-19-000036:notes:185]
| ◦ | Special legal contingency charges, |

[0001069202-19-000036:notes:186]
| ◦ | Asbestos-related litigation, |

[0001069202-19-000036:notes:187]
[same as prior period, unchanged from 0001069202-19-000030:notes:178]

[0001069202-19-000036:notes:188]
[same as prior period, unchanged from 0001069202-19-000030:notes:180]

[0001069202-19-000036:notes:189]
[same as prior period, unchanged from 0001069202-19-000030:notes:181]

[0001069202-19-000036:notes:190]
[same as prior period, unchanged from 0001069202-19-000030:notes:182]

[0001069202-19-000036:notes:191]
[same as prior period, unchanged from 0001069202-19-000030:notes:183]

[0001069202-19-000036:notes:192]
| • | Prior quarter partial advance of insurance recoveries related to lost profits, |

[0001069202-19-000036:notes:193]
| • | Loss (gain) from insurance recoveries, net of losses incurred; and, |

[0001069202-19-000036:notes:194]
[same as prior period, unchanged from 0001069202-19-000030:notes:187]

[0001069202-19-000036:notes:195]
[same as prior period, unchanged from 0001069202-19-000030:notes:188]

[0001069202-19-000036:notes:196]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Total Assets: |  |  |  |
| Residential Heating & Cooling | $ | 1,165.3 |  |  | $ | 837.4 |  |
| Commercial Heating & Cooling | 423.4 |  |  | 349.5 |  |
| Refrigeration | 415.7 |  |  | 462.9 |  |
| Corporate and other | 210.4 |  |  | 167.4 |  |
| Total assets | $ | 2,214.8 |  |  | $ | 1,817.2 |  |

[0001069202-19-000036:notes:197]
[same as prior period, unchanged from 0001069202-19-000030:notes:190]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-19-000036:notes:198]
[same as prior period, unchanged from 0001069202-19-000030:notes:191]


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-19-000036:notes:199]
[same as prior period, unchanged from 0001069202-19-000030:notes:192]

[0001069202-19-000036:notes:200]
[same as prior period, unchanged from 0001069202-19-000030:notes:193]

[0001069202-19-000036:notes:201]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2019 were the same as those used at December 31, 2018.

[0001069202-19-000036:notes:202]
[same as prior period, unchanged from 0001069202-19-000030:notes:195]

[0001069202-19-000036:notes:203]
[same as prior period, unchanged from 0001069202-19-000030:notes:196]

[0001069202-19-000036:notes:204]
[same as prior period, unchanged from 0001069202-19-000030:notes:197]

[0001069202-19-000036:notes:205]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-19-000036:notes:206]
[same as prior period, unchanged from 0001069202-19-000030:notes:199]

[0001069202-19-000036:notes:207]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Senior unsecured notes | $ | 357.1 |  |  | $ | 338.4 |  |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-19-000036:notes:208]
[same as prior period, unchanged from 0001069202-19-000030:notes:201]

[0001069202-19-000036:notes:209]
[same as prior period, unchanged from 0001069202-19-000030:notes:202]

[0001069202-19-000036:notes:210]
The condensed consolidating financial statements reflect our investments in our subsidiaries using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Our condensed consolidating financial statements and our Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of September 30, 2019 and December 31, 2018, and for the three and nine months ended September 30, 2019 and 2018 are shown on the following pages.
Lennox International Inc. and Subsidiaries
Condensed Consolidating Balance Sheets

[0001069202-19-000036:notes:211]
As of September 30, 2019

[0001069202-19-000036:notes:212]
(Unaudited)

[0001069202-19-000036:notes:213]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.4 |  |  | $ | 26.0 |  |  | $ | 18.7 |  |  | $ | — |  |  | $ | 46.1 |  |
| Short-term investments | — |  |  | — |  |  | 2.4 |  |  | — |  |  | $ | 2.4 |  |
| Accounts and notes receivable, net | — |  |  | 72.0 |  |  | 550.2 |  |  | — |  |  | 622.2 |  |
| Inventories, net | — |  |  | 509.2 |  |  | 78.3 |  |  | (2.2 | ) |  | 585.3 |  |
| Other assets | 3.4 |  |  | 42.8 |  |  | 49.4 |  |  | (34.3 | ) |  | 61.3 |  |
| Total current assets | 4.8 |  |  | 650.0 |  |  | 699.0 |  |  | (36.5 | ) |  | 1,317.3 |  |
| Property, plant and equipment, net | — |  |  | 365.4 |  |  | 53.4 |  |  | — |  |  | 418.8 |  |
| Right-of-use assets from operating leases | — |  |  | 149.0 |  |  | 23.9 |  |  | — |  |  | 172.9 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.3 |  |  | — |  |  | 186.4 |  |
| Investment in subsidiaries | 1,651.7 |  |  | 422.1 |  |  | 50.2 |  |  | (2,124.0 | ) |  | — |  |
| Deferred income taxes | (12.2 | ) |  | 49.5 |  |  | 22.5 |  |  | (12.2 | ) |  | 47.6 |  |
| Other assets, net | 1.4 |  |  | 54.6 |  |  | 1.6 |  |  | 14.2 |  |  | 71.8 |  |
| Intercompany (payables) receivables, net | (872.4 | ) |  | 857.5 |  |  | 134.8 |  |  | (119.9 | ) |  | — |  |
| Total assets | $ | 773.3 |  |  | $ | 2,714.2 |  |  | $ | 1,005.7 |  |  | $ | (2,278.4 | ) |  | $ | 2,214.8 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt | 21.9 |  |  | 5.8 |  |  | 366.6 |  |  | — |  |  | 394.3 |  |
| Current operating lease liabilities | — |  |  | 44.4 |  |  | 7.2 |  |  | — |  |  | 51.6 |  |
| Accounts payable | 29.7 |  |  | 317.6 |  |  | 45.7 |  |  | — |  |  | 393.0 |  |
| Accrued expenses | 11.2 |  |  | 219.1 |  |  | 40.7 |  |  | — |  |  | 271.0 |  |
| Income taxes (receivable) payable | (45.7 | ) |  | 52.3 |  |  | 44.2 |  |  | (50.8 | ) |  | — |  |
| Total current liabilities | 17.1 |  |  | 639.2 |  |  | 504.4 |  |  | (50.8 | ) |  | 1,109.9 |  |
| Long-term debt | 1,033.2 |  |  | 21.7 |  |  | 1.9 |  |  | — |  |  | 1,056.8 |  |
| Long-term operating lease liabilities | — |  |  | 106.1 |  |  | 16.9 |  |  | — |  |  | 123.0 |  |
| Pensions | — |  |  | 64.9 |  |  | 7.6 |  |  | — |  |  | 72.5 |  |
| Other liabilities | 0.3 |  |  | 122.7 |  |  | 6.9 |  |  | — |  |  | 129.9 |  |
| Total liabilities | 1,050.6 |  |  | 954.6 |  |  | 537.7 |  |  | (50.8 | ) |  | 2,492.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' (deficit) equity | (277.3 | ) |  | 1,759.6 |  |  | 468.0 |  |  | (2,227.6 | ) |  | (277.3 | ) |
| Total liabilities and stockholders' (deficit) equity | $ | 773.3 |  |  | $ | 2,714.2 |  |  | $ | 1,005.7 |  |  | $ | (2,278.4 | ) |  | $ | 2,214.8 |  |

[0001069202-19-000036:notes:214]
[same as prior period, unchanged from 0001069202-19-000030:notes:206]

[0001069202-19-000036:notes:215]
[same as prior period, unchanged from 0001069202-19-000030:notes:207]

[0001069202-19-000036:notes:216]
[same as prior period, unchanged from 0001069202-19-000030:notes:208]

[0001069202-19-000036:notes:217]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.8 |  |  | $ | 15.4 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 46.3 |  |
| Accounts and notes receivable, net | — |  |  | 44.3 |  |  | 428.4 |  |  | — |  |  | 472.7 |  |
| Inventories, net | — |  |  | 411.4 |  |  | 103.9 |  |  | (5.5 | ) |  | 509.8 |  |
| Other assets | 3.3 |  |  | 36.2 |  |  | 54.7 |  |  | (33.6 | ) |  | 60.6 |  |
| Total current assets | 5.1 |  |  | 507.3 |  |  | 616.1 |  |  | (39.1 | ) |  | 1,089.4 |  |
| Property, plant and equipment, net | — |  |  | 293.3 |  |  | 118.6 |  |  | (3.6 | ) |  | 408.3 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.5 |  |  | — |  |  | 186.6 |  |
| Investment in subsidiaries | 1,311.9 |  |  | 357.8 |  |  | (0.5 | ) |  | (1,669.2 | ) |  | — |  |
| Deferred income taxes | 1.4 |  |  | 54.4 |  |  | 23.4 |  |  | (12.2 | ) |  | 67.0 |  |
| Other assets, net | 1.5 |  |  | 48.1 |  |  | 17.8 |  |  | (1.5 | ) |  | 65.9 |  |
| Intercompany (payables) receivables, net | (715.5 | ) |  | 675.8 |  |  | 142.6 |  |  | (102.9 | ) |  | — |  |
| Total assets | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.8 |  |  | 268.6 |  |  | — |  |  | 300.8 |  |
| Accounts payable | 25.5 |  |  | 295.7 |  |  | 112.1 |  |  | — |  |  | 433.3 |  |
| Accrued expenses | 12.1 |  |  | 213.8 |  |  | 46.4 |  |  | — |  |  | 272.3 |  |
| Income taxes (receivable) payable | (38.5 | ) |  | 40.6 |  |  | 50.8 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | 28.5 |  |  | 552.9 |  |  | 477.9 |  |  | (50.8 | ) |  | 1,008.5 |  |
| Long-term debt | 724.9 |  |  | 15.0 |  |  | 0.6 |  |  | — |  |  | 740.5 |  |
| Pensions | — |  |  | 75.1 |  |  | 7.7 |  |  | — |  |  | 82.8 |  |
| Other liabilities | 0.6 |  |  | 126.4 |  |  | 8.0 |  |  | — |  |  | 135.0 |  |
| Total liabilities | 754.0 |  |  | 769.4 |  |  | 494.2 |  |  | (50.8 | ) |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' (deficit) equity | (149.6 | ) |  | 1,333.4 |  |  | 444.3 |  |  | (1,777.7 | ) |  | (149.6 | ) |
| Total liabilities and stockholders' (deficit) equity | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |

[0001069202-19-000036:notes:218]
[same as prior period, unchanged from 0001069202-19-000030:notes:210]

[0001069202-19-000036:notes:219]
For the Three Months Ended September 30, 2019

[0001069202-19-000036:notes:220]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net sales | $ | — |  |  | $ | 950.0 |  |  | $ | 139.5 |  |  | $ | (56.6 | ) |  | $ | 1,032.9 |  |
| Cost of goods sold | — |  |  | 681.2 |  |  | 109.8 |  |  | (56.4 | ) |  | 734.6 |  |
| Gross profit | — |  |  | 268.8 |  |  | 29.7 |  |  | (0.2 | ) |  | 298.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 139.9 |  |  | 3.5 |  |  | — |  |  | 143.4 |  |
| Losses (gains) and other expenses, net | 0.2 |  |  | 1.5 |  |  | 0.6 |  |  | (0.1 | ) |  | 2.2 |  |
| Restructuring charges | — |  |  | 6.0 |  |  | 0.1 |  |  | — |  |  | 6.1 |  |
| Loss on sale of business | — |  |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Gain from insurance recoveries, net of losses incurred | — |  |  | (7.1 | ) |  | — |  |  | — |  |  | (7.1 | ) |
| Income from equity method investments | (116.4 | ) |  | (20.1 | ) |  | (2.3 | ) |  | 135.5 |  |  | (3.3 | ) |
| Operating income | 116.2 |  |  | 148.4 |  |  | 27.8 |  |  | (135.6 | ) |  | 156.8 |  |
| Interest expense, net | 2.1 |  |  | 7.7 |  |  | 2.7 |  |  | — |  |  | 12.5 |  |
| Other expense (income), net | — |  |  | 0.5 |  |  | 0.1 |  |  | — |  |  | 0.6 |  |
| Income from continuing operations before income taxes | 114.1 |  |  | 140.2 |  |  | 25.0 |  |  | (135.6 | ) |  | 143.7 |  |
| Provision for income tax (benefit) expense | (0.6 | ) |  | 23.0 |  |  | 6.6 |  |  | — |  |  | 29.0 |  |
| Income from continuing operations | 114.7 |  |  | 117.2 |  |  | 18.4 |  |  | (135.6 | ) |  | 114.7 |  |
| Net income (loss) | $ | 114.7 |  |  | $ | 117.2 |  |  | $ | 18.4 |  |  | $ | (135.6 | ) |  | $ | 114.7 |  |
| Other comprehensive (loss) income, net of tax | (0.3 | ) |  | 7.7 |  |  | (5.0 | ) |  | — |  |  | 2.4 |  |
| Comprehensive income | $ | 114.4 |  |  | $ | 124.9 |  |  | $ | 13.4 |  |  | $ | (135.6 | ) |  | $ | 117.1 |  |

[0001069202-19-000036:notes:221]
[same as prior period, unchanged from 0001069202-19-000030:notes:213]

[0001069202-19-000036:notes:222]
For the Nine Months Ended  September 30, 2019

[0001069202-19-000036:notes:223]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 21.0 |  |  | $ | 217.7 |  |  | $ | (114.2 | ) |  | $ | — |  |  | $ | 124.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.8 |  |  | 0.4 |  |  | — |  |  | 1.2 |  |
| Purchases of property, plant and equipment | — |  |  | (71.6 | ) |  | (5.4 | ) |  | — |  |  | (77.0 | ) |
| Net proceeds from sale of business | — |  |  | 42.9 |  |  | 0.6 |  |  | — |  |  | 43.5 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 11.6 |  |  | — |  |  | — |  |  | 11.6 |  |
| Purchases of short-term investments | — |  |  | — |  |  | (2.4 | ) |  | — |  |  | (2.4 | ) |
| Net cash used in investing activities | — |  |  | (16.3 | ) |  | (6.8 | ) |  | — |  |  | (23.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term debt payments | — |  |  | — |  |  | (5.3 | ) |  | — |  |  | (5.3 | ) |
| Short-term debt proceeds | — |  |  | — |  |  | 5.3 |  |  | — |  |  | 5.3 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 155.5 |  |  | — |  |  | 155.5 |  |
| Asset securitization payments | — |  |  | — |  |  | (58.0 | ) |  | — |  |  | (58.0 | ) |
| Long-term debt payments | (30.0 | ) |  | (3.0 | ) |  | (2.0 | ) |  | — |  |  | (35.0 | ) |
| Borrowings from credit facility | 1,938.5 |  |  | — |  |  | — |  |  | — |  |  | 1,938.5 |  |
| Payments on credit facility | (1,608.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,608.5 | ) |
| Proceeds from employee stock purchases | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |
| Repurchases of common stock | (400.0 | ) |  | — |  |  | — |  |  | — |  |  | (400.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (16.9 | ) |  | — |  |  | — |  |  | — |  |  | (16.9 | ) |
| Intercompany financing activity | 173.9 |  |  | (188.2 | ) |  | 14.3 |  |  | — |  |  | — |  |
| Cash dividends paid | (80.9 | ) |  | — |  |  | — |  |  | — |  |  | (80.9 | ) |
| Net cash (used in) provided by financing activities | (21.4 | ) |  | (191.2 | ) |  | 109.8 |  |  | — |  |  | (102.8 | ) |
| (Decrease) increase in cash and cash equivalents | (0.4 | ) |  | 10.2 |  |  | (11.2 | ) |  | — |  |  | (1.4 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | 0.4 |  |  | 0.8 |  |  | — |  |  | 1.2 |  |
| Cash and cash equivalents, beginning of period | 1.8 |  |  | 15.4 |  |  | 29.1 |  |  | — |  |  | 46.3 |  |
| Cash and cash equivalents, end of period | $ | 1.4 |  |  | $ | 26.0 |  |  | $ | 18.7 |  |  | $ | — |  |  | $ | 46.1 |  |

[0001069202-19-000036:notes:224]
For the Nine Months Ended  September 30, 2018

[0001069202-19-000036:notes:225]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 57.2 |  |  | $ | 362.5 |  |  | $ | (188.4 | ) |  | $ | — |  |  | $ | 231.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (46.1 | ) |  | (14.8 | ) |  | — |  |  | (60.9 | ) |
| Net proceeds from sale of businesses and related property | — |  |  | 4.0 |  |  | 111.9 |  |  | — |  |  | 115.9 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 4.2 |  |  | — |  |  | — |  |  | 4.2 |  |
| Net cash (used in) provided by investing activities | — |  |  | (37.9 | ) |  | 97.2 |  |  | — |  |  | 59.3 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term debt payments | — |  |  | — |  |  | (41.1 | ) |  | — |  |  | (41.1 | ) |
| Short-term debt proceeds | — |  |  | — |  |  | 39.6 |  |  | — |  |  | 39.6 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 155.0 |  |  | — |  |  | 155.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (53.7 | ) |  | — |  |  | (53.7 | ) |
| Long-term debt payments | (30.0 | ) |  | (2.8 | ) |  | (0.1 | ) |  | — |  |  | (32.9 | ) |
| Long-term borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Borrowings from credit facility | 1,820.0 |  |  | — |  |  | — |  |  | — |  |  | 1,820.0 |  |
| Payments on credit facility | (1,766.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,766.5 | ) |
| Proceeds from employee stock purchases | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |
| Repurchases of common stock | (350.2 | ) |  | — |  |  | — |  |  | — |  |  | (350.2 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (21.1 | ) |  | — |  |  | — |  |  | — |  |  | (21.1 | ) |
| Intercompany financing activity | 356.1 |  |  | (323.0 | ) |  | (33.1 | ) |  | — |  |  | — |  |
| Cash dividends paid | (68.2 | ) |  | — |  |  | — |  |  | — |  |  | (68.2 | ) |
| Net cash (used in) provided by financing activities | (57.4 | ) |  | (325.8 | ) |  | 66.6 |  |  | — |  |  | (316.6 | ) |
| Decrease in cash and cash equivalents | (0.2 | ) |  | (1.2 | ) |  | (24.6 | ) |  | — |  |  | (26.0 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | (2.8 | ) |  | 6.7 |  |  | — |  |  | 3.9 |  |
| Cash and cash equivalents, beginning of period | 1.6 |  |  | 28.0 |  |  | 38.6 |  |  | — |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 1.4 |  |  | $ | 24.0 |  |  | $ | 20.7 |  |  | $ | — |  |  | $ | 46.1 |  |


## us-gaap:SubsequentEventsTextBlock

[0001069202-19-000036:notes:226]
Subsequent Event:

[0001069202-19-000036:notes:227]
On October 15, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $75.0 million of our pension plan assets and $77.9 million of related benefit obligations.  This transaction requires a remeasurement of the pension plan and we expect to recognize a $38.5 million non-cash pension settlement pre-tax loss in the fourth quarter of 2019 for this remeasurement.
