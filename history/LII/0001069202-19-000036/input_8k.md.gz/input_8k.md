# LII 8-K — 0001069202-19-000034 filed 2019-10-21

## item codes, every 8-K on or before 2019-10-21

- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2019-10-21

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-19-000034:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetabl.htm
EXHIBIT 99.1

[0001069202-19-000034:8k_2_02:2]
Exhibit

[0001069202-19-000034:8k_2_02:3]
Exhibit-99.1

[0001069202-19-000034:8k_2_02:4]
Lennox International Reports Third Quarter Results

[0001069202-19-000034:8k_2_02:5]
| • | Revenue on a GAAP basis up slightly, including 7% of negative impact from the tornado and divestitures |

[0001069202-19-000034:8k_2_02:6]
| • | Excluding divestitures, adjusted revenue a third-quarter record $1.03 billion, up 6%, including 2% of negative tornado impact |

[0001069202-19-000034:8k_2_02:7]
| • | GAAP EPS from continuing operations up 11% to third-quarter record $2.94 |

[0001069202-19-000034:8k_2_02:8]
| • | Adjusted EPS from continuing operations up 26% to third-quarter record $3.34 |

[0001069202-19-000034:8k_2_02:9]
| • | Updating 2019 guidance for adjusted revenue growth from 2-5% to 2-4% |

[0001069202-19-000034:8k_2_02:10]
| • | Updating 2019 guidance for GAAP EPS from continuing operations from $11.91-$12.51 to $10.65-$10.95, including a fourth-quarter non-cash pension settlement charge |

[0001069202-19-000034:8k_2_02:11]
| • | Updating adjusted EPS from continuing operations from $11.30-$11.90 to $11.15-$11.45 |

[0001069202-19-000034:8k_2_02:12]
| • | Repurchased $150 million of stock in the third quarter and $400 million in total for 2019 |

[0001069202-19-000034:8k_2_02:13]
DALLAS, October 21, 2019 - Lennox International Inc. (NYSE: LII) today reported financial results for the third quarter of 2019. All comparisons are to the prior-year period. The company’s tornado references relate to the July 2018 tornado damage at a Residential manufacturing facility in Iowa. Adjusted revenue and profit exclude non-core Refrigeration businesses divested in 2018 and 2019.

[0001069202-19-000034:8k_2_02:14]
Lennox International reported third-quarter GAAP and adjusted revenue of $1,033 million. GAAP revenue was up slightly, including 7% of negative impact from the tornado and divestitures. Adjusted revenue, excluding the impact from divestitures, was up 6% to a new third-quarter high. GAAP and adjusted revenue included 2% of negative tornado impact.

[0001069202-19-000034:8k_2_02:15]
GAAP operating income was $157 million, up 8%. GAAP earnings per share from continuing operations was up 11% to a third-quarter record $2.94. Total adjusted segment profit rose 15% to a third-quarter record $175 million, and total adjusted segment margin expanded 140 basis points to a third-quarter record 17.0%. Adjusted earnings per share from continuing operations rose 26% to a third-quarter record $3.34.

[0001069202-19-000034:8k_2_02:16]
“Adverse weather conditions continued in the third quarter with cooler weather than last year in key swing regions and for the U.S. overall,” said Chairman and CEO Todd Bluedorn. “This was a major headwind to our Residential business following the significantly cooler and wetter weather of the second quarter. On a reported basis, Residential segment revenue was a third-quarter record $638 million, up 7% compared to the third quarter a year ago in which a tornado damaged a major manufacturing facility and disrupted our highest-end business. Residential segment margin for the third quarter of 2019 expanded 80 basis points to a third-quarter record 19.8%, and segment profit rose 12% to a third-quarter record $127 million. Residential revenue was negatively impacted $23 million or 4% from business not recovered following the tornado. Segment profit was negatively impacted $12 million, offset by $16 million of insurance recovery for lost profits. The net $4 million benefit to segment profit was $3 million below guidance. For 2019 overall, we continue to expect $99 million of negative tornado impact to Residential revenue, a negative $54 million impact to segment profit, and insurance recovery for lost profits of $94 million. The resulting $40 million of net benefit to Residential segment profit in 2019 is unchanged.

[0001069202-19-000034:8k_2_02:17]
“In our Commercial business, revenue was up 7% in the third quarter, led by double-digit growth in National Account equipment revenue, and we added 13 new National Account customers in the quarter. Segment margin was down 30 basis points to 18.6%. Segment profit rose 5%. In Refrigeration, adjusted segment revenue was flat at constant currency, with North America up mid-single digits and Europe down mid-single digits. Adjusted segment profit was down 10% as segment margin declined 130 basis points to 13.9%.

[0001069202-19-000034:8k_2_02:18]
“Overall for the company in 2019, we now expect revenue growth of 2-4% and adjusted EPS from continuing operations of $11.15-$11.45. Moving into the heating season, the fourth quarter is off to a solid start, and we look forward to finishing the year strong with continued momentum into 2020.”

[0001069202-19-000034:8k_2_02:19]
FINANCIAL HIGHLIGHTS

[0001069202-19-000034:8k_2_02:20]
Revenue: On a GAAP and adjusted basis, revenue was $1,033 million. GAAP revenue was up slightly, and adjusted revenue was up 6% to a new third-quarter high. Foreign exchange was neutral to revenue. Volume was up, and price was favorable. Mix was neutral to revenue.

[0001069202-19-000034:8k_2_02:21]
Gross Profit: On a GAAP and adjusted basis, gross profit was approximately $298 million. GAAP gross margin was 28.9%, and adjusted gross margin was 28.8%. GAAP gross profit was down 1%, and adjusted gross profit was up 2% excluding the impact from divestitures. Gross profit benefitted from higher volume, favorable price, and lower material costs. Partial offsets

[0001069202-19-000034:8k_2_02:22]
included the tornado impact, cooler third-quarter weather and factory productivity and other product costs, unfavorable mix, higher distribution and freight expenses, and unfavorable foreign exchange. On a GAAP basis, divestitures also had a negative impact on gross profit.

[0001069202-19-000034:8k_2_02:23]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the third quarter was $114.7 million, or $2.94 per share, compared to $108.0 million, or $2.65 per share, in the prior-year quarter.

[0001069202-19-000034:8k_2_02:24]
Adjusted income from continuing operations in the third quarter was $130.0 million, or $3.34 per share, compared to $108.0 million, or $2.66 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the third quarter of 2019 excludes net after-tax charges of $15.3 million: $5.9 million for the partial advance in the second quarter of 2019 of insurance recoveries related to lost profits, $4.8 million for restructuring activities, $2.7 million for other tax items, net, and a net charge of $1.9 million for various other items.

[0001069202-19-000034:8k_2_02:25]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from operations in the third quarter was $236 million compared to $266 million in the prior-year quarter. Net cash used in investing activities was $25 million compared to $9 million in the prior-year quarter. Free cash flow was $211 million compared to $253 million in the third quarter a year ago. Total debt at the end of the third quarter was $1.45 billion. Total cash and cash equivalents were $46 million at the end of September. In the third quarter, the company repurchased $150 million of stock and paid $30 million in dividends.

[0001069202-19-000034:8k_2_02:26]
BUSINESS SEGMENT HIGHLIGHTS

[0001069202-19-000034:8k_2_02:27]
Residential Heating & Cooling

[0001069202-19-000034:8k_2_02:28]
Revenue in the Residential Heating & Cooling business was up 7% to a third-quarter record $638 million. Foreign exchange was neutral. Segment margin expanded 80 basis points to a third-quarter record 19.8%. Segment profit rose 12% to a third-quarter record $127 million. Residential results were impacted by higher volume, favorable price, lower material costs, favorable warranty, tariff rebates, and insurance proceeds for lost profits. Partial offsets included cooler weather, tornado impact, lower factory efficiency and higher other product costs, unfavorable mix, and higher distribution, freight, and SG&A expenses.

[0001069202-19-000034:8k_2_02:29]
Commercial Heating & Cooling

[0001069202-19-000034:8k_2_02:30]
Revenue in the Commercial Heating & Cooling business segment was up 7% to $253 million. Foreign exchange was neutral. Segment margin contracted 30 basis points to 18.6%. Segment profit rose 5% to $47 million. Commercial results were impacted by higher volume, favorable price and mix, and sourcing and engineering-led cost reductions. Offsets included higher commodity and other product costs, tariffs, lower factory efficiency, and higher distribution, freight and SG&A expenses.

[0001069202-19-000034:8k_2_02:31]
Refrigeration

[0001069202-19-000034:8k_2_02:32]
Adjusted revenue in the Refrigeration business segment was $142 million, down 2%. Foreign exchange had a negative 2% impact on revenue. Adjusted segment profit was $20 million, down 10%, and margin contracted 130 basis points to 13.9%. Refrigeration results were impacted by lower factory efficiency, unfavorable mix, higher commodities and other product costs, tariffs, and higher SG&A expenses. Partial offsets included higher volume, favorable price, sourcing and engineering-led cost reductions, and lower freight costs.

[0001069202-19-000034:8k_2_02:33]
FULL-YEAR OUTLOOK

[0001069202-19-000034:8k_2_02:34]
| • | Updating 2019 guidance for adjusted revenue growth from 2-5% to 2-4%. |

[0001069202-19-000034:8k_2_02:35]
| • | Updating guidance for GAAP EPS from continuing operations from $11.91-$12.51 to $10.65-$10.95, including a non-cash pension settlement charge of approximately $28.9 million after-tax, or $0.73 per share, in the fourth quarter of 2019. |

[0001069202-19-000034:8k_2_02:36]
| • | Updating guidance for adjusted EPS from continuing operations from $11.30-$11.90 to $11.15-$11.45. |

[0001069202-19-000034:8k_2_02:37]
| • | Updating guidance for corporate expenses from approximately $90 million to $85 million. |

[0001069202-19-000034:8k_2_02:38]
| • | Reiterating guidance for an effective tax rate of 22-23% on an adjusted basis for the full year. |

[0001069202-19-000034:8k_2_02:39]
| • | Reiterating guidance for 2019 capital expenditures of approximately $155 million, including $55 million funded by insurance proceeds. |

[0001069202-19-000034:8k_2_02:40]
| • | Updating guidance for free cash flow from approximately $390 million to $320 million for the full year. |

[0001069202-19-000034:8k_2_02:41]
| • | $400 million of stock repurchased in 2019. |

[0001069202-19-000034:8k_2_02:42]
A chart of the company’s current view on the tornado financial impact and insurance recovery for 2018-2019 is posted on the company’s website at www.lennoxinternational.com.

[0001069202-19-000034:8k_2_02:43]
CONFERENCE CALL INFORMATION

[0001069202-19-000034:8k_2_02:44]
A conference call to discuss the company’s third-quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-288-0340 at least 10 minutes prior to the scheduled start time and use reservation number 472904. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on October 21 through November 4, 2019 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 472904. The call also will be archived on the company’s website.

[0001069202-19-000034:8k_2_02:45]
About Lennox International

[0001069202-19-000034:8k_2_02:46]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-19-000034:8k_2_02:47]
FORWARD-LOOKING STATEMENTS

[0001069202-19-000034:8k_2_02:48]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Statements of Operations(Unaudited) |
| (Amounts in millions, except per share data) | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 1,032.9 |  |  | $ | 1,030.2 |  |  | $ | 2,922.2 |  |  | $ | 3,040.4 |  |
| Cost of goods sold | 734.6 |  |  | 728.3 |  |  | 2,090.3 |  |  | 2,153.8 |  |
| Gross profit | 298.3 |  |  | 301.9 |  |  | 831.9 |  |  | 886.6 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 143.4 |  |  | 149.4 |  |  | 441.6 |  |  | 466.1 |  |
| Losses (gains) and other expenses, net | 2.2 |  |  | 2.7 |  |  | 5.3 |  |  | 10.0 |  |
| Restructuring charges | 6.1 |  |  | 0.5 |  |  | 6.5 |  |  | 1.9 |  |
| Loss (gain), net on sale of businesses and related property | 0.2 |  |  | 6.2 |  |  | 9.1 |  |  | 25.8 |  |
| (Gain) loss from insurance recoveries, net of losses incurred | (7.1 | ) |  | 0.3 |  |  | (85.4 | ) |  | 0.3 |  |
| Income from equity method investments | (3.3 | ) |  | (2.4 | ) |  | (10.5 | ) |  | (10.8 | ) |
| Operating income | 156.8 |  |  | 145.2 |  |  | 465.3 |  |  | 393.3 |  |
| Pension settlement | — |  |  | — |  |  | 60.6 |  |  | — |  |
| Interest expense, net | 12.5 |  |  | 10.3 |  |  | 36.5 |  |  | 28.5 |  |
| Other expense (income), net | 0.6 |  |  | 1.1 |  |  | 1.7 |  |  | 2.4 |  |
| Income from continuing operations before income taxes | 143.7 |  |  | 133.8 |  |  | 366.5 |  |  | 362.4 |  |
| Provision for income taxes | 29.0 |  |  | 25.8 |  |  | 71.5 |  |  | 77.3 |  |
| Income from continuing operations | 114.7 |  |  | 108.0 |  |  | 295.0 |  |  | 285.1 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| (Loss) income from discontinued operations before income taxes | — |  |  | — |  |  | (0.4 | ) |  | 0.4 |  |
| Income tax expense | — |  |  | — |  |  | (0.1 | ) |  | 2.1 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.3 | ) |  | (1.7 | ) |
| Net income | $ | 114.7 |  |  | $ | 108.0 |  |  | $ | 294.7 |  |  | $ | 283.4 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.97 |  |  | $ | 2.68 |  |  | $ | 7.54 |  |  | $ | 6.98 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01 | ) |  | (0.04 | ) |
| Net income | $ | 2.97 |  |  | $ | 2.68 |  |  | $ | 7.53 |  |  | $ | 6.94 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.94 |  |  | $ | 2.65 |  |  | $ | 7.46 |  |  | $ | 6.90 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | (0.04 | ) |
| Net income | $ | 2.94 |  |  | $ | 2.65 |  |  | $ | 7.46 |  |  | $ | 6.86 |  |
| Weighted Average Number of Shares Outstanding - Basic | 38.6 |  |  | 40.3 |  |  | 39.1 |  |  | 40.8 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 39.0 |  |  | 40.7 |  |  | 39.5 |  |  | 41.3 |  |

[0001069202-19-000034:8k_2_02:49]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Adjusted Segment Net Sales and Profit (Loss) |
| (Unaudited) |

[0001069202-19-000034:8k_2_02:50]
| (Amounts in millions) | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 637.6 |  |  | $ | 594.7 |  |  | $ | 1,792.2 |  |  | $ | 1,764.4 |  |
| Commercial Heating & Cooling | 253.3 |  |  | 236.9 |  |  | 687.9 |  |  | 668.1 |  |
| Refrigeration (1) | 142.0 |  |  | 145.0 |  |  | 407.8 |  |  | 409.8 |  |
|  | $ | 1,032.9 |  |  | $ | 976.6 |  |  | $ | 2,887.9 |  |  | $ | 2,842.3 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 126.5 |  |  | $ | 113.0 |  |  | $ | 366.6 |  |  | $ | 317.9 |  |
| Commercial Heating & Cooling | 47.1 |  |  | 44.8 |  |  | 116.0 |  |  | 117.6 |  |
| Refrigeration (1) | 19.8 |  |  | 22.1 |  |  | 48.3 |  |  | 57.4 |  |
| Corporate and other | (18.1 | ) |  | (28.1 | ) |  | (54.3 | ) |  | (61.8 | ) |
| Total adjusted segment profit | 175.3 |  |  | 151.8 |  |  | 476.6 |  |  | 431.1 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Special inventory write down | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Special product quality adjustment | (0.5 | ) |  | — |  |  | (1.0 | ) |  | — |  |
| Loss (gain), net on sale of businesses and related property | 0.2 |  |  | 6.2 |  |  | 9.1 |  |  | 25.8 |  |
| Loss (gain) from insurance recoveries, net of losses incurred | 1.2 |  |  | 0.3 |  |  | (11.6 | ) |  | 0.3 |  |
| Prior quarter partial advance of insurance recoveries related to lost profits | 8.0 |  |  | — |  |  | — |  |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 3.5 |  |  | 2.4 |  |  | 7.3 |  |  | 9.3 |  |
| Restructuring charges | 6.1 |  |  | 0.5 |  |  | 6.5 |  |  | 1.9 |  |
| Operating loss (income) from non-core businesses (1) | — |  |  | (2.8 | ) |  | 1.0 |  |  | 0.3 |  |
| Operating income | $ | 156.8 |  |  | $ | 145.2 |  |  | $ | 465.3 |  |  | $ | 393.3 |  |

[0001069202-19-000034:8k_2_02:51]
(1) Excludes the non-core business results related to Kysor Warren, which was sold in March 2019 and the Company's business operations in Australia, Asia and South America, which were sold in 2018.

[0001069202-19-000034:8k_2_02:52]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-19-000034:8k_2_02:53]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-19-000034:8k_2_02:54]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-19-000034:8k_2_02:55]
| ◦ | Special legal contingency charges, |

[0001069202-19-000034:8k_2_02:56]
| ◦ | Asbestos-related litigation, |

[0001069202-19-000034:8k_2_02:57]
| ◦ | Environmental liabilities, |

[0001069202-19-000034:8k_2_02:58]
| ◦ | Other items, net, |

[0001069202-19-000034:8k_2_02:59]
| • | Special inventory write down, |

[0001069202-19-000034:8k_2_02:60]
| • | Special product quality adjustment, |

[0001069202-19-000034:8k_2_02:61]
| • | Loss (gain), net on sale of businesses and related property, |

[0001069202-19-000034:8k_2_02:62]
| • | Prior quarter partial advance of insurance recoveries related to lost profits, |

[0001069202-19-000034:8k_2_02:63]
| • | Loss (gain) from insurance recoveries, net of losses incurred, |

[0001069202-19-000034:8k_2_02:64]
| • | Operating loss (income) from non-core businesses; and |

[0001069202-19-000034:8k_2_02:65]
| • | Restructuring charges. |

[0001069202-19-000034:8k_2_02:66]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Balance Sheets |
| (Amounts in millions, except shares and par values) | As of September 30, 2019 |  | As of December 31, 2018 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 46.1 |  |  | $ | 46.3 |  |
| Short-term investments | 2.4 |  |  | — |  |
| Accounts and notes receivable, net of allowances of $7.1 and $6.3 in 2019 and 2018, respectively | 622.2 |  |  | 472.7 |  |
| Inventories, net | 585.3 |  |  | 509.8 |  |
| Other assets | 61.3 |  |  | 60.6 |  |
| Total current assets | 1,317.3 |  |  | 1,089.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $807.0 and $778.5 in 2019 and 2018, respectively | 418.8 |  |  | 408.3 |  |
| Right-of-use assets from operating leases | 172.9 |  |  | — |  |
| Goodwill | 186.4 |  |  | 186.6 |  |
| Deferred income taxes | 47.6 |  |  | 67.0 |  |
| Other assets, net | 71.8 |  |  | 65.9 |  |
| Total assets | $ | 2,214.8 |  |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 394.3 |  |  | 300.8 |  |
| Current operating lease liabilities | 51.6 |  |  | — |  |
| Accounts payable | 393.0 |  |  | 433.3 |  |
| Accrued expenses | 271.0 |  |  | 272.3 |  |
| Income taxes payable | — |  |  | 2.1 |  |
| Total current liabilities | 1,109.9 |  |  | 1,008.5 |  |
| Long-term debt | 1,056.8 |  |  | 740.5 |  |
| Long-term operating lease liabilities | 123.0 |  |  | — |  |
| Pensions | 72.5 |  |  | 82.8 |  |
| Other liabilities | 129.9 |  |  | 135.0 |  |
| Total liabilities | 2,492.1 |  |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,090.0 |  |  | 1,078.8 |  |
| Retained earnings | 2,064.4 |  |  | 1,855.0 |  |
| Accumulated other comprehensive loss | (127.2 | ) |  | (188.8 | ) |
| Treasury stock, at cost, 48,642,428 shares and 47,312,248 shares for 2019 and 2018, respectively | (3,305.4 | ) |  | (2,895.5 | ) |
| Total stockholders' deficit | (277.3 | ) |  | (149.6 | ) |
| Total liabilities and stockholders' deficit | $ | 2,214.8 |  |  | $ | 1,817.2 |  |

[0001069202-19-000034:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-19-000034:8k_2_02:68]
Consolidated Statements of Cash Flows

[0001069202-19-000034:8k_2_02:69]
(Unaudited)

[0001069202-19-000034:8k_2_02:70]
| (Amounts in millions) | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 294.7 |  |  | $ | 283.4 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Loss (gain), net on sale of businesses and related property | 9.1 |  |  | 25.8 |  |
| Gain from insurance recoveries, net of losses incurred | (11.6 | ) |  | — |  |
| Income from equity method investments | (10.5 | ) |  | (10.8 | ) |
| Dividends from Affiliates | 9.3 |  |  | 6.6 |  |
| Restructuring charges, net of cash paid | 6.0 |  |  | 0.5 |  |
| Provision for bad debts | 4.0 |  |  | 3.8 |  |
| Unrealized losses on derivative contracts | (0.1 | ) |  | 1.4 |  |
| Stock-based compensation expense | 15.6 |  |  | 21.0 |  |
| Depreciation and amortization | 53.1 |  |  | 49.4 |  |
| Deferred income taxes | 17.0 |  |  | (5.6 | ) |
| Pension expense | 65.9 |  |  | 6.5 |  |
| Pension contributions | (1.7 | ) |  | (20.3 | ) |
| Other items, net | (0.4 | ) |  | 0.3 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (178.2 | ) |  | (114.0 | ) |
| Inventories | (107.0 | ) |  | (73.7 | ) |
| Other current assets | 1.5 |  |  | (8.6 | ) |
| Accounts payable | (24.5 | ) |  | 46.9 |  |
| Accrued expenses | 7.6 |  |  | 35.6 |  |
| Income taxes payable and receivable | (8.2 | ) |  | (1.4 | ) |
| Other | (17.1 | ) |  | (15.5 | ) |
| Net cash provided by operating activities | 124.5 |  |  | 231.3 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 1.2 |  |  | 0.1 |  |
| Purchases of property, plant and equipment | (77.0 | ) |  | (60.9 | ) |
| Net proceeds from sale of businesses | 43.5 |  |  | 115.9 |  |
| Purchases of short-term investments | (2.4 | ) |  | — |  |
| Insurance recoveries received for property damage incurred from natural disaster | 11.6 |  |  | 4.2 |  |
| Net cash (used in) provided by investing activities | (23.1 | ) |  | 59.3 |  |
| Cash flows from financing activities: |  |  |  |
| Short-term debt payments | (5.3 | ) |  | (41.1 | ) |
| Short-term debt proceeds | 5.3 |  |  | 39.6 |  |
| Asset securitization borrowings | 155.5 |  |  | 155.0 |  |
| Asset securitization payments | (58.0 | ) |  | (53.7 | ) |
| Long-term debt payments | (35.0 | ) |  | (32.9 | ) |
| Borrowings from credit facility | 1,938.5 |  |  | 1,820.0 |  |
| Payments on credit facility | (1,608.5 | ) |  | (1,766.5 | ) |
| Proceeds from employee stock purchases | 2.5 |  |  | 2.5 |  |
| Repurchases of common stock | (400.0 | ) |  | (350.2 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (16.9 | ) |  | (21.1 | ) |
| Cash dividends paid | (80.9 | ) |  | (68.2 | ) |
| Net cash used in financing activities | (102.8 | ) |  | (316.6 | ) |
| Decrease in cash and cash equivalents | (1.4 | ) |  | (26.0 | ) |
| Effect of exchange rates on cash and cash equivalents | 1.2 |  |  | 3.9 |  |
| Cash and cash equivalents, beginning of period | 46.3 |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 46.1 |  |  | $ | 46.1 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 31.5 |  |  | $ | 25.9 |  |
| Income taxes paid (net of refunds) | $ | 78.7 |  |  | $ | 87.2 |  |
| Insurance recoveries received | $ | 138.0 |  |  | $ | 45.0 |  |

[0001069202-19-000034:8k_2_02:71]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. During the first quarter of 2019, the Company completed the sale of its Kysor Warren business. In the first quarter of 2018, the Company announced the planned sales of its businesses in Australia, Asia, and South America. The sale of the Company's business in Australia and Asia and the related property was completed in the second quarter of 2018 and sale of the Company's business in South America was completed in the third quarter of 2018. The results from operations for these businesses have been shown in the tables below as “Non-core business results”. The prior period results have been updated to provide period-over-period comparability. |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |
|  | For the Three Months Ended September 30, |
|  | (Unaudited) |
|  | 2019 |  | 2018 |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |
| Income from continuing operations, a GAAP measure | $ | 143.7 |  | $ | (29.0 | ) | $ | 114.7 |  |  | $ | 133.8 |  | $ | (25.8 | ) | $ | 108.0 |  |
| Restructuring charges | 6.1 |  | (1.3 | ) | 4.8 |  |  | 0.5 |  | (0.1 | ) | 0.4 |  |
| Special product quality adjustments (b) | (0.5 | ) | 0.1 |  | (0.4 | ) |  | — |  | — |  | — |  |
| Special legal contingency charges (a) | 0.3 |  | (0.1 | ) | 0.2 |  |  | 0.1 |  | — |  | 0.1 |  |
| Asbestos-related litigation (a) | 1.5 |  | (0.3 | ) | 1.2 |  |  | 1.4 |  | (0.4 | ) | 1.0 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | 0.1 |  | (0.1 | ) | — |  |  | 0.2 |  | (0.1 | ) | 0.1 |  |
| Environmental liabilities (a) | 1.1 |  | (0.2 | ) | 0.9 |  |  | 0.2 |  | — |  | 0.2 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (1.7 | ) | (1.7 | ) |  | — |  | (1.7 | ) | (1.7 | ) |
| Other tax items, net (c) | — |  | 2.7 |  | 2.7 |  |  | — |  | (1.4 | ) | (1.4 | ) |
| Loss on sale of businesses | 0.2 |  | — |  | 0.2 |  |  | 6.2 |  | (3.8 | ) | 2.4 |  |
| Prior quarter partial advance of insurance recoveries related to lost profits (g) | 8.0 |  | (2.1 | ) | 5.9 |  |  | — |  | — |  | — |  |
| Loss (gain) from insurance recoveries, net of losses incurred | 1.2 |  | (0.2 | ) | 1.0 |  |  | 0.3 |  | (0.1 | ) | 0.2 |  |
| Other items, net (a) | 0.6 |  | (0.1 | ) | 0.5 |  |  | 0.5 |  | — |  | 0.5 |  |
| Non-core business results (f) | — |  | — |  | — |  |  | (2.3 | ) | 0.5 |  | (1.8 | ) |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 162.3 |  | $ | (32.3 | ) | $ | 130.0 |  |  | $ | 140.9 |  | $ | (32.9 | ) | $ | 108.0 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 2.94 |  |  |  |  |  |  | $ | 2.65 |  |
| Restructuring charges |  |  |  |  | 0.12 |  |  |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  | (0.01 | ) |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  | 0.01 |  |  |  |  |  |  | — |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.02 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  | 0.02 |  |  |  |  |  |  | 0.01 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.04 | ) |  |  |  |  |  | (0.04 | ) |
| Other tax items, net (c) |  |  |  |  | 0.07 |  |  |  |  |  |  | (0.03 | ) |
| Loss on sale of businesses |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.06 |  |
| Prior quarter partial advance of insurance recoveries related to lost profits (g) |  |  | 0.15 |  |  |  |  | — |  |

[0001069202-19-000034:8k_2_02:72]
| Loss (gain) from insurance recoveries, net of losses incurred |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.01 |  |
| Other items, net (a) |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.01 |  |
| Non-core business results (f) |  |  |  |  | — |  |  |  |  |  |  | (0.05 | ) |
| Change in share counts from share-based compensation (d) |  |  |  |  | — |  |  |  |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 3.34 |  |  |  |  | $ | 2.66 |  |
| (a) Recorded in Losses (Gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to the Company's business operations in South America and the Kysor Warren business, not included elsewhere in the reconciliation. |
| (g) During the second quarter of 2019, the Company received a partial advance of $8 million related to lost profits incurred in the second quarter. The Company included this amount in adjusted income in the third quarter now that the lost profits related to the second quarter are collected in full. |
|  | For the Nine Months Ended September 30, |
|  | (Unaudited) |
|  | 2019 |  | 2018 |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |
| Income from continuing operations, a GAAP measure | $ | 366.5 |  | $ | (71.5 | ) | $ | 295.0 |  |  | $ | 362.4 |  | $ | (77.3 | ) | $ | 285.1 |  |
| Restructuring charges | 6.5 |  | (1.4 | ) | 5.1 |  |  | 1.9 |  | (0.5 | ) | 1.4 |  |
| Pension settlement | 60.6 |  | (15.1 | ) | 45.5 |  |  | — |  | — |  | — |  |
| Special product quality adjustments (b) | (1.0 | ) | 0.2 |  | (0.8 | ) |  | — |  | — |  | — |  |
| Special legal contingency charges (a) | 0.5 |  | (0.1 | ) | 0.4 |  |  | 1.8 |  | (0.4 | ) | 1.4 |  |
| Asbestos-related litigation (a) | 3.3 |  | (0.7 | ) | 2.6 |  |  | 3.3 |  | (0.8 | ) | 2.5 |  |
| Net change in unrealized (gains) losses on unsettled future contracts (a) | (0.2 | ) | — |  | (0.2 | ) |  | 1.4 |  | (0.3 | ) | 1.1 |  |
| Inventory write down (b) | — |  | — |  | — |  |  | 0.2 |  | — |  | 0.2 |  |
| Environmental liabilities (a) | 2.4 |  | (0.5 | ) | 1.9 |  |  | 1.4 |  | (0.3 | ) | 1.1 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (7.0 | ) | (7.0 | ) |  | — |  | (6.6 | ) | (6.6 | ) |
| Other tax items, net (c) | — |  | 3.3 |  | 3.3 |  |  | — |  | (4.7 | ) | (4.7 | ) |
| Loss (gain), net on sale of businesses and related property | 9.1 |  | (3.5 | ) | 5.6 |  |  | 25.8 |  | 0.3 |  | 26.1 |  |
| (Gain) loss from insurance recoveries, net of losses incurred | (11.6 | ) | 2.9 |  | (8.7 | ) |  | 0.3 |  | (0.1 | ) | 0.2 |  |
| Other items, net (a) | 1.3 |  | (0.2 | ) | 1.1 |  |  | 1.4 |  | (0.7 | ) | 0.7 |  |
| Non-core business results (f) | 1.3 |  | (0.3 | ) | 1.0 |  |  | 1.7 |  | (0.3 | ) | 1.4 |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 438.7 |  | $ | (93.9 | ) | $ | 344.8 |  |  | $ | 401.6 |  | $ | (91.7 | ) | $ | 309.9 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 7.46 |  |  |  |  |  |  | $ | 6.90 |  |
| Restructuring charges |  |  |  |  | 0.13 |  |  |  |  |  |  | 0.03 |  |
| Pension settlement |  |  | 1.15 |  |  |  |  | — |  |
| Special product quality adjustments (b) |  |  |  |  | (0.02 | ) |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.03 |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.07 |  |  |  |  |  |  | 0.06 |  |
| Net change in unrealized (gains) losses on unsettled future contracts (a) |  |  |  |  | (0.01 | ) |  |  |  |  |  | 0.03 |  |
| Inventory write down (b) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  | 0.05 |  |  |  |  |  |  | 0.03 |  |

[0001069202-19-000034:8k_2_02:73]
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.18 | ) |  |  |  |  |  | (0.16 | ) |
| Other tax items, net (c) |  |  |  |  | 0.08 |  |  |  |  |  |  | (0.11 | ) |
| Loss (gain), net on sale of businesses and related property |  |  |  |  | 0.14 |  |  |  |  |  |  | 0.64 |  |
| (Gain) loss from insurance recoveries, net of losses incurred |  |  |  |  | (0.22 | ) |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.02 |  |
| Non-core business results (f) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.03 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  | 0.02 |  |  |  |  |  |  | 0.03 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  | $ | 8.74 |  |  |  |  |  |  | $ | 7.53 |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to the Company's business operations in Australia, Asia, and South America and the Kysor Warren business, not included elsewhere in the reconciliation. |

[0001069202-19-000034:8k_2_02:74]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts (a) | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | (0.6 | ) |
| Foreign currency exchange (gains) losses (a) | (0.3 | ) |  | 0.1 |  |  | (1.0 | ) |  | 1.2 |  |
| (Gain) loss on disposal of fixed assets (a) | — |  |  | — |  |  | (0.2 | ) |  | 0.1 |  |
| Other operating (gains) losses (a) | (1.2 | ) |  | — |  |  | (1.2 | ) |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) | 0.1 |  |  | 0.2 |  |  | (0.2 | ) |  | 1.4 |  |
| Special legal contingency charges (b) | 0.3 |  |  | 0.1 |  |  | 0.5 |  |  | 1.8 |  |
| Asbestos-related litigation (b) | 1.5 |  |  | 1.4 |  |  | 3.3 |  |  | 3.3 |  |
| Environmental liabilities (b) | 1.1 |  |  | 0.2 |  |  | 2.4 |  |  | 1.4 |  |
| Other items, net (b) | 0.6 |  |  | 0.5 |  |  | 1.3 |  |  | 1.4 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.2 |  |  | $ | 2.7 |  |  | $ | 5.3 |  |  | $ | 10.0 |  |

[0001069202-19-000034:8k_2_02:75]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001069202-19-000034:8k_2_02:76]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |
|  |  |  |  |  | For the Year Ended December 31, 2019ESTIMATED |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $10.65-$10.95 |
| Insurance recovery from tornado impact for damaged property, net of other non-core EBIT charges, and fourth quarter non-cash pension settlement charge |  | 0.50 |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $11.15-$11.45 |

[0001069202-19-000034:8k_2_02:77]
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Average shares outstanding - diluted, a GAAP measure | 39.0 |  |  | 40.7 |  |  | 39.5 |  |  | $ | 41.3 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | (0.1 | ) |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 38.9 |  |  | 40.6 |  |  | 39.5 |  |  | 41.2 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales, a GAAP measure | $ | 142.0 |  |  | $ | 198.6 |  |  | $ | 1,032.9 |  |  | $ | 1,030.2 |  |
| Net sales from non-core businesses (a) | — |  |  | 53.6 |  |  | — |  |  | 53.6 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 142.0 |  |  | $ | 145.0 |  |  | $ | 1,032.9 |  |  | $ | 976.6 |  |
| (a) Non-Core businesses represent the Company's business operations in South America and the Kysor Warren business. |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Nine Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales, a GAAP measure | $ | 442.1 |  |  | $ | 607.9 |  |  | $ | 2,922.2 |  |  | $ | 3,040.4 |  |
| Net sales from non-core businesses (a) | 34.3 |  |  | 198.1 |  |  | 34.3 |  |  | 198.1 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 407.8 |  |  | $ | 409.8 |  |  | $ | 2,887.9 |  |  | $ | 2,842.3 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit, a GAAP measure | $ | 47.4 |  |  | $ | 58.6 |  |  | $ | 298.3 |  |  | $ | 301.9 |  |
| Non-GAAP adjustments to gross profit | — |  |  | — |  |  | 0.5 |  |  | — |  |
| Gross profit from non-core businesses (a) | — |  |  | 9.1 |  |  | — |  |  | 9.1 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 47.4 |  |  | $ | 49.5 |  |  | $ | 297.8 |  |  | $ | 292.8 |  |
| (a) Non-Core businesses represent the Company's business operations in South America and the Kysor Warren business. |  |  |  |  |

[0001069202-19-000034:8k_2_02:78]
|  | Refrigeration Segment |  | Consolidated |
|  | For the Nine Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit, a GAAP measure | $ | 135.6 |  |  | $ | 175.0 |  |  | $ | 831.9 |  |  | $ | 886.6 |  |
| Non-GAAP adjustments to gross profit | — |  |  | (0.2 | ) |  | 1.0 |  |  | (0.2 | ) |
| Gross profit from non-core businesses (a) | 3.6 |  |  | 34.0 |  |  | 3.6 |  |  | 34.0 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 132.0 |  |  | $ | 141.2 |  |  | $ | 827.3 |  |  | $ | 852.8 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit, a GAAP measure | $ | 19.8 |  |  | $ | 24.9 |  |  | $ | 175.3 |  |  | $ | 154.6 |  |
| (Loss) profit from non-core businesses (a) | — |  |  | 2.8 |  |  | — |  |  | 2.8 |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 19.8 |  |  | $ | 22.1 |  |  | $ | 175.3 |  |  | $ | 151.8 |  |
| (a) Non-Core businesses represent the Company's business operations in South America and the Kysor Warren business. |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Nine Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit, a GAAP measure | $ | 47.3 |  |  | $ | 57.1 |  |  | $ | 475.6 |  |  | $ | 430.8 |  |
| (Loss) profit from non-core businesses (a) | (1.0 | ) |  | (0.3 | ) |  | (1.0 | ) |  | (0.3 | ) |
| Adjusted Segment profit, a Non-GAAP measure | $ | 48.3 |  |  | $ | 57.4 |  |  | $ | 476.6 |  |  | $ | 431.1 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Selling, general and administrative expenses, a GAAP measure | $ | 30.4 |  |  | $ | 37.2 |  |  | $ | 143.4 |  |  | $ | 149.4 |  |
| Selling, general and administrative expenses from non-core businesses (a) | — |  |  | 6.2 |  |  | — |  |  | 6.2 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 30.4 |  |  | $ | 31.0 |  |  | $ | 143.4 |  |  | $ | 143.2 |  |
| (a) Non-Core businesses represent the Company's business operations in South America and the Kysor Warren business. |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Nine Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Selling, general and administrative expenses, a GAAP measure | $ | 96.3 |  |  | $ | 129.1 |  |  | $ | 441.6 |  |  | $ | 466.1 |  |
| Selling, general and administrative expenses from non-core businesses (a) | 4.6 |  |  | 34.6 |  |  | 4.6 |  |  | 34.6 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 91.7 |  |  | $ | 94.5 |  |  | $ | 437.0 |  |  | $ | 431.5 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |

[0001069202-19-000034:8k_2_02:79]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net cash provided by operating activities, a GAAP measure | $ | 235.5 |  |  | $ | 266.3 |  |  | $ | 124.5 |  |  | $ | 231.3 |  |
| Purchases of property, plant and equipment | (23.5 | ) |  | (17.5 | ) |  | (77.0 | ) |  | (60.9 | ) |
| Proceeds from the disposal of property, plant and equipment | 0.4 |  |  | — |  |  | 1.2 |  |  | 0.1 |  |
| Insurance recoveries received for property damage incurred from natural disaster | (1.2 | ) |  | 4.2 |  |  | 11.6 |  |  | 4.2 |  |
| Free cash flow, a Non-GAAP measure | 211.2 |  |  | 253.0 |  |  | 60.3 |  |  | 174.7 |  |

[0001069202-19-000034:8k_2_02:80]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to September 30, 2019 |
| Adjusted EBIT (b)(a) |  |  |  |  |  |  | $ | 588.9 |  |
| Depreciation and amortization expense (c) |  |  |  |  |  |  | 68.8 |  |
| EBITDA (b + c) |  |  |  |  |  |  | $ | 657.7 |  |
| Total debt at September 30, 2019 (d) |  |  |  |  |  |  | $ | 1,451.1 |  |
| Total Debt to EBITDA ratio ((d / (b + c)) |  |  |  |  |  |  | 2.2 |  |
| (a) Excludes Non-Core business results representing the Company's business operations in Australia, Asia, and South America and the Kysor Warren business,. |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |
|  |  |  |  |  |  |  | Trailing Twelve Months to September 30, 2019 |
| Income from continuing operations before income taxes, a GAAP measure | $ | 472.0 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit | 8.9 |  |
| Special product quality adjustments | (1.0 | ) |
| Restructuring charges | 7.6 |  |
| Interest expense, net | 46.3 |  |
| Pension settlement | 61.0 |  |
| Loss (gain), net on sale of businesses and related property | 10.9 |  |
| (Gain) loss from insurance recoveries, net of losses incurred | (22.8 | ) |
| Non-core business results (a) | 3.4 |  |
| Other expense (income), net | 2.6 |  |
| Adjusted EBIT per above, a Non-GAAP measure | $ | 588.9 |  |
| (a) Non-core businesses results represent activity related to the Company's business operations in Australia, Asia, and South America and the Kysor Warren business, not included elsewhere in the reconciliation. |
