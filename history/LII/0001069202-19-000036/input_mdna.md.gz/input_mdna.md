# LII MD&A — 0001069202-19-000036


## mdna

[0001069202-19-000036:mdna:1]
[same as prior period, unchanged from 0001069202-19-000030:mdna:1]

[0001069202-19-000036:mdna:2]
[same as prior period, unchanged from 0001069202-19-000030:mdna:2]

[0001069202-19-000036:mdna:3]
[same as prior period, unchanged from 0001069202-19-000030:mdna:3]

[0001069202-19-000036:mdna:4]
[same as prior period, unchanged from 0001069202-19-000030:mdna:4]

[0001069202-19-000036:mdna:5]
[same as prior period, unchanged from 0001069202-19-000030:mdna:5]

[0001069202-19-000036:mdna:6]
[same as prior period, unchanged from 0001069202-19-000030:mdna:6]

[0001069202-19-000036:mdna:7]
Marshalltown Tornado

[0001069202-19-000036:mdna:8]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance

[0001069202-19-000036:mdna:9]
policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.

[0001069202-19-000036:mdna:10]
In the third quarter of 2019, we incurred expenses of $3 million related to damages caused by the tornado, which included site clean-up and demolition, factory inefficiencies, freight to move product to other warehouses and sales and marketing promotional costs.  We received insurance recoveries of $10 million in the third quarter of 2019 and allocated the first $2 million of these proceeds to cover our expenses and rebuilding costs incurred during the quarter and allocated the remaining $8 million for lost profits.  These amounts are included in (Gain) loss from insurance recoveries, net of losses incurred in the Consolidated Statements of Operations.

[0001069202-19-000036:mdna:11]
[same as prior period, unchanged from 0001069202-19-000030:mdna:9]

[0001069202-19-000036:mdna:12]
[same as prior period, unchanged from 0001069202-19-000030:mdna:10]

[0001069202-19-000036:mdna:13]
Results for the third quarter of 2019 were driven by year over year sales and profit growth in our Residential Heating & Cooling and Commercial Heating & Cooling segments.  The Residential Heating & Cooling segment saw a 7% increase in net sales primarily on higher volumes and their segment profit was up $14 million, including the impact of insurance proceeds received for lost profits.  The Commercial Heating & Cooling segment had a 7% increase in net sales and a $2 million increase in segment profit which were driven by higher volumes and higher price and mix.  Sales in our Refrigeration segment decreased by 28%  primarily due to the sale of our South America and Kysor Warren businesses in prior quarters, and segment profit declined $5 million.

[0001069202-19-000036:mdna:14]
[same as prior period, unchanged from 0001069202-19-000030:mdna:12]

[0001069202-19-000036:mdna:15]
| • | Net sales increased $3 million to $1,033 million in the third quarter of 2019. Growth in our Residential Heating & Cooling and Commercial Heating & Cooling segments were offset by a sales decline in our Refrigeration segment due to the sale of our South America and Kysor Warren businesses in prior quarters. |

[0001069202-19-000036:mdna:16]
| • | Operating income in the third quarter of 2019 increased $12 million to $157 million due primarily to insurance proceeds for lost profits related to the Marshalltown tornado. |

[0001069202-19-000036:mdna:17]
| • | Net income for the third quarter of 2019 increased $7 million to $115 million. |

[0001069202-19-000036:mdna:18]
| • | Diluted earnings per share from continuing operations were $2.94 per share in the third quarter of 2019 compared to $2.65 per share in the third quarter of 2018. |

[0001069202-19-000036:mdna:19]
| • | For the nine months ended September 30, 2019, we returned $81 million to shareholders through dividend payments and repurchased $400 million of common stock. |

[0001069202-19-000036:mdna:20]
Third Quarter of 2019 Compared to Third Quarter of 2018 - Consolidated Results

[0001069202-19-000036:mdna:21]
[same as prior period, unchanged from 0001069202-19-000030:mdna:19]

[0001069202-19-000036:mdna:22]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 1,032.9 |  |  | $ | 1,030.2 |  |  | 0.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 734.6 |  |  | 728.3 |  |  | (0.9 | ) |  | 71.1 |  |  | 70.7 |  |
| Gross profit | 298.3 |  |  | 301.9 |  |  | (1.2 | ) |  | 28.9 |  |  | 29.3 |  |
| Selling, general and administrative expenses | 143.4 |  |  | 149.4 |  |  | 4.0 |  |  | 13.9 |  |  | 14.5 |  |
| Losses (gains) and other expenses, net | 2.2 |  |  | 2.7 |  |  | 18.5 |  |  | 0.2 |  |  | 0.3 |  |
| Restructuring charges | 6.1 |  |  | 0.5 |  |  | (1,120.0 | ) |  | 0.6 |  |  | — |  |
| Loss (gain) on sale of businesses and related property | 0.2 |  |  | 6.2 |  |  | 96.8 |  |  | — |  |  | 0.6 |  |
| (Gain) loss from insurance recoveries, net of losses incurred | (7.1 | ) |  | 0.3 |  |  | 2,466.7 |  |  | (0.7 | ) |  | — |  |
| Income from equity method investments | (3.3 | ) |  | (2.4 | ) |  | 37.5 |  |  | (0.3 | ) |  | (0.2 | ) |
| Operating income | $ | 156.8 |  |  | $ | 145.2 |  |  | 8.0 | % |  | 15.2 | % |  | 14.1 | % |

[0001069202-19-000036:mdna:23]
[same as prior period, unchanged from 0001069202-19-000030:mdna:21]

[0001069202-19-000036:mdna:24]
Net sales were up $3 million, or flat in percentage terms, in the third quarter of 2019 compared to the third quarter of 2018.  Higher sales volume across all of our segments contributed 4% and favorable combined price and mix in our Residential Heating & Cooling and Commercial Heating & Cooing segments contributed 1%.  These were partially offset by a 5% decline related to the loss of sales related to our South America and Kysor Warren businesses.

[0001069202-19-000036:mdna:25]
[same as prior period, unchanged from 0001069202-19-000030:mdna:23]

[0001069202-19-000036:mdna:26]
Gross profit margin in the third quarter of 2019 decreased to 28.9% compared to 29.3% in the third quarter of 2018.  We saw decreases in profit margin of 150 basis points ("bps") from lower factory efficiency and higher other product costs, and 70 bps from higher freight and distribution costs.  Partially offsetting these decreases were positive margin increases of 40 bps from favorable price and mix, 40 bps from sourcing and engineering-led cost reductions, 20 bps from lower commodity costs, 10 bps from favorable product warranty costs, and 70 bps from the divested South America and Kysor Warren businesses which had lower margins.

[0001069202-19-000036:mdna:27]
[same as prior period, unchanged from 0001069202-19-000030:mdna:25]

[0001069202-19-000036:mdna:28]
Selling, general and administrative expenses, or SG&A declined $6 million to $143 million in the third quarter of 2019 compared to $149 million in the third quarter of 2018 primarily due to the sale of our South America and Kysor Warren businesses.  As a percentage of net sales, SG&A decreased 60 bps to 13.9% primarily due to a decline in SG&A from our divested business and lower short-term and long-term incentive compensation costs.

[0001069202-19-000036:mdna:29]
[same as prior period, unchanged from 0001069202-19-000030:mdna:27]

[0001069202-19-000036:mdna:30]
Losses (gains) and other expenses, net for the third quarter of 2019 and 2018 included the following (in millions):

[0001069202-19-000036:mdna:31]
|  | For the Three Months Ended September 30, |
|  | 2019 |  | 2018 |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | 0.2 |  |
| Foreign currency exchange gains | (0.3 | ) |  | 0.1 |  |
| Other operating (gains) losses | (1.2 | ) |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | 0.2 |  |
| Special legal contingency charges | 0.3 |  |  | 0.1 |  |
| Asbestos-related litigation | 1.5 |  |  | 1.4 |  |
| Environmental liabilities | 1.1 |  |  | 0.2 |  |
| Other items, net | 0.6 |  |  | 0.5 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.2 |  |  | $ | 2.7 |  |

[0001069202-19-000036:mdna:32]
The net change in unrealized losses (gains) on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 14 in the Notes to the Consolidated Financial Statements for more information on the divestiture costs.

[0001069202-19-000036:mdna:33]
[same as prior period, unchanged from 0001069202-19-000030:mdna:31]

[0001069202-19-000036:mdna:34]
Restructuring charges were $6 million in the third quarter of 2019 and primarily related to activities to re-align resources and the product portfolio in our Commercial Heating & Cooling and Corporate segments.  For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000036:mdna:35]
[same as prior period, unchanged from 0001069202-19-000030:mdna:33]

[0001069202-19-000036:mdna:36]
We recognized a loss of $0.2 million in the third quarter of 2019 related to the sale of our Kysor Warren business.  Refer to Note 14 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-19-000036:mdna:37]
[same as prior period, unchanged from 0001069202-19-000030:mdna:35]

[0001069202-19-000036:mdna:38]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $3 million in the third quarter of 2019 increased $1 million compared to the third quarter of 2018 on improved operating performance of the joint ventures.

[0001069202-19-000036:mdna:39]
[same as prior period, unchanged from 0001069202-19-000030:mdna:39]

[0001069202-19-000036:mdna:40]
Interest expense, net of $13 million in the third quarter of 2019 was up from $10 million in the third quarter of 2018 due to an increase in our average net borrowings.

[0001069202-19-000036:mdna:41]
[same as prior period, unchanged from 0001069202-19-000030:mdna:41]

[0001069202-19-000036:mdna:42]
Our effective tax rate increased to 20.2% for the third quarter of 2019 compared to 19.3% for the third quarter of 2018 primarily due to the recording of unrecognized tax benefits.  We expect our annual effective tax rate to be between 22% and 23%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001069202-19-000036:mdna:43]
Third Quarter of 2019 Compared to Third Quarter of 2018 - Results by Segment

[0001069202-19-000036:mdna:44]
[same as prior period, unchanged from 0001069202-19-000030:mdna:44]

[0001069202-19-000036:mdna:45]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000036:mdna:46]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 637.6 |  |  | $ | 594.7 |  |  | $ | 42.9 |  |  | 7.2 | % |
| Profit | $ | 126.5 |  |  | $ | 113.0 |  |  | $ | 13.5 |  |  | 11.9 | % |
| % of net sales | 19.8 | % |  | 19.0 | % |  |  |  |  |

[0001069202-19-000036:mdna:47]
Net sales increased 7% in the third quarter of 2019 compared to the third quarter of 2018.  Sales volume was higher by 6% and price and mix combined was higher by 1%.

[0001069202-19-000036:mdna:48]
Segment profit in the third quarter of 2019 increased $14 million compared to the third quarter of 2018 due to $16 million of insurance proceeds for lost profits due to the Marshalltown tornado, $9 million of higher sales volume, $3 million of higher combined price and mix, $3 million from lower commodities, $3 million from tariff rebates, and $2 million of sourcing and engineering-led cost reductions.  Partially offsetting these increases was $7 million of higher SG&A expense, $6 million from lower factory efficiency, $6 million of higher freight and distribution expense, and $3 million of higher other product costs.

[0001069202-19-000036:mdna:49]
[same as prior period, unchanged from 0001069202-19-000030:mdna:50]

[0001069202-19-000036:mdna:50]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000036:mdna:51]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 253.3 |  |  | $ | 236.9 |  |  | $ | 16.4 |  |  | 6.9 | % |
| Profit | $ | 47.1 |  |  | $ | 44.8 |  |  | $ | 2.3 |  |  | 5.1 | % |
| % of net sales | 18.6 | % |  | 18.9 | % |  |  |  |  |

[0001069202-19-000036:mdna:52]
Net sales increased 7% in the third quarter of 2019 compared to the third quarter of 2018.  Sales volume was higher 4% and price and mix combined was higher by 3%.

[0001069202-19-000036:mdna:53]
Segment profit in the third quarter of 2019 increased $2 million compared to the third quarter of 2018 due to $5 million of higher price and mix combined, $3 million of higher sales volume, $1 million of sourcing and engineering-led cost reductions, and $1 million of higher equity method income.  Partially offsetting these increases was $2 million from lower factory efficiency, $2 million of higher SG&A expense, $1 million of higher commodities, $1 million of higher tariffs on Chinese imports, $1 million of higher freight and distribution expense, and $1 million of higher other product costs.

[0001069202-19-000036:mdna:54]
[same as prior period, unchanged from 0001069202-19-000030:mdna:55]

[0001069202-19-000036:mdna:55]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000036:mdna:56]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 142.0 |  |  | $ | 198.6 |  |  | $ | (56.6 | ) |  | (28.5 | )% |
| Profit | $ | 19.8 |  |  | $ | 24.9 |  |  | $ | (5.1 | ) |  | (20.5 | )% |
| % of net sales | 13.9 | % |  | 12.5 | % |  |  |  |  |

[0001069202-19-000036:mdna:57]
Net sales decreased 28% in the third quarter of 2019 compared to the third quarter of 2018.  The loss of sales from the divested Kysor Warren and South America businesses contributed 27%, unfavorable foreign currency exchange rates contributed 1% and unfavorable mix contributed 1%, partially offset by 1% higher sales volume.

[0001069202-19-000036:mdna:58]
Segment profit in the third quarter of 2019 decreased $5 million compared to the third quarter of 2018 due to $3 million of lower profit due to the divested Kysor Warren and South America businesses, $2 million from lower factory efficiency, $1 million of higher SG&A, $1 million of higher tariffs on Chinese imports, and $1 million of lower sales of refrigerant allocations in Europe.  Partially offsetting these decreases were $1 million of sourcing and engineering-led cost reductions, $1 million of higher sales volume, and $1 million of lower freight and distribution expense.

[0001069202-19-000036:mdna:59]
[same as prior period, unchanged from 0001069202-19-000030:mdna:60]

[0001069202-19-000036:mdna:60]
Corporate and other expenses decreased $10 million in the third quarter of 2019 compared to the third quarter of 2018 primarily due to lower short-term and long-term incentive compensation and higher income from equity method investments.

[0001069202-19-000036:mdna:61]
Year-to-Date through September 30, 2019 Compared to Year-to-Date through September 30, 2018 - Consolidated Results

[0001069202-19-000036:mdna:62]
[same as prior period, unchanged from 0001069202-19-000030:mdna:63]

[0001069202-19-000036:mdna:63]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 2,922.2 |  |  | $ | 3,040.4 |  |  | (3.9 | ) |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 2,090.3 |  |  | 2,153.8 |  |  | 2.9 |  |  | 71.5 |  |  | 70.8 |  |
| Gross profit | 831.9 |  |  | 886.6 |  |  | (6.2 | ) |  | 28.5 |  |  | 29.2 |  |
| Selling, general and administrative expenses | 441.6 |  |  | 466.1 |  |  | 5.3 |  |  | 15.1 |  |  | 15.3 |  |
| Losses (gains) and other expenses, net | 5.3 |  |  | 10.0 |  |  | 47.0 |  |  | 0.2 |  |  | 0.3 |  |
| Restructuring charges | 6.5 |  |  | 1.9 |  |  | (242.1 | ) |  | 0.2 |  |  | 0.1 |  |
| Loss (gain), net sale of businesses and related property | 9.1 |  |  | 25.8 |  |  | 64.7 |  |  | 0.3 |  |  | 0.8 |  |
| (Gain) loss from insurance recoveries, net of losses incurred | (85.4 | ) |  | 0.3 |  |  | 28,566.7 |  |  | (2.9 | ) |  | — |  |
| Income from equity method investments | (10.5 | ) |  | (10.8 | ) |  | (2.8 | ) |  | (0.4 | ) |  | (0.4 | ) |
| Operating income | $ | 465.3 |  |  | $ | 393.3 |  |  | 18.3 |  |  | 15.9 | % |  | 12.9 | % |

[0001069202-19-000036:mdna:64]
[same as prior period, unchanged from 0001069202-19-000030:mdna:65]

[0001069202-19-000036:mdna:65]
Net sales decreased 4% in the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018 due to a 5% decline related to the sale of our Australia, New Zealand, Asia and South America and Kysor Warren businesses and 1% from unfavorable foreign currency exchange rates, partially offset by 2% from favorable price and mix combined.

[0001069202-19-000036:mdna:66]
[same as prior period, unchanged from 0001069202-19-000030:mdna:67]

[0001069202-19-000036:mdna:67]
Gross profit margins for the nine months ended September 30, 2019 decreased 70 bps to 28.5% compared to the nine months ended September 30, 2018.  Our profit margin decreased 50 bps from higher commodity costs, 100 bps from higher freight and distribution costs, 20 bps from tariffs on Chinese imports and 110 bps from other product costs.  These were partially offset by 100 bps from favorable price and mix combined, 50 bps from sourcing and engineering-led cost reductions, 10 bps from favorable warranty costs, and 50 bps from the divested Australia, New Zealand, Asia, South America and Kysor Warren businesses which had lower margins.

[0001069202-19-000036:mdna:68]
[same as prior period, unchanged from 0001069202-19-000030:mdna:69]

[0001069202-19-000036:mdna:69]
SG&A was $442 million for the nine months ended September 30, 2019 compared to $466 million for the nine months ended September 30, 2018, and declined primarily due to the sale of our Australia, New Zealand, Asia, South America and Kysor Warren businesses.  As a percentage of net sales, SG&A decreased 20 bps to 15.1% from 15.3%.

[0001069202-19-000036:mdna:70]
41

[0001069202-19-000036:mdna:71]
Losses (gains) and Other Expenses, Net

[0001069202-19-000036:mdna:72]
Losses (gains) and other expenses, net for the nine months ended September 30, 2019 and 2018 included the following (in millions):

[0001069202-19-000036:mdna:73]
|  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |
| Realized losses (gains) on settled future contracts | $ | 0.4 |  |  | $ | (0.6 | ) |
| Foreign currency exchange (gains) losses | (1.0 | ) |  | 1.2 |  |
| (Gain) loss on disposal of fixed assets | (0.2 | ) |  | 0.1 |  |
| Other operating (gains) losses | (1.2 | ) |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (0.2 | ) |  | 1.4 |  |
| Special legal contingency charges | 0.5 |  |  | 1.8 |  |
| Asbestos-related litigation | 3.3 |  |  | 3.3 |  |
| Environmental liabilities | 2.4 |  |  | 1.4 |  |
| Other items, net | 1.3 |  |  | 1.4 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 5.3 |  |  | $ | 10.0 |  |

[0001069202-19-000036:mdna:74]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.

[0001069202-19-000036:mdna:75]
[same as prior period, unchanged from 0001069202-19-000030:mdna:75]

[0001069202-19-000036:mdna:76]
Restructuring charges were $7 million in the nine months ended September 30, 2019 and primarily related to activities to re-align resources and the product portfolio in our Commercial Heating & Cooling and Corporate segments. For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000036:mdna:77]
[same as prior period, unchanged from 0001069202-19-000030:mdna:77]

[0001069202-19-000036:mdna:78]
Income from equity method investments of $11 million for the nine months ended September 30, 2019 was flat compared to the nine months ended September 30, 2018.

[0001069202-19-000036:mdna:79]
[same as prior period, unchanged from 0001069202-19-000030:mdna:37]

[0001069202-19-000036:mdna:80]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and $105.6 million of related pension benefit obligations.  For the nine months ended September 30, 2019, we recognized a $60.6 million pension settlement charge in the Statement of Operations and reclassified $5.6 million of pension benefit obligations to AOCL as a result of this transaction.  For additional information, refer to Note 9 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000036:mdna:81]
[same as prior period, unchanged from 0001069202-19-000030:mdna:81]

[0001069202-19-000036:mdna:82]
Interest expense, net of $37 million in the nine months ended September 30, 2019 increased from $29 million in the nine months ended September 30, 2018 primarily due to an increase in our average net borrowings.

[0001069202-19-000036:mdna:83]
[same as prior period, unchanged from 0001069202-19-000030:mdna:83]

[0001069202-19-000036:mdna:84]
Our effective tax rate declined to 19.5% for the nine months ended September 30, 2019 compared to 21.3% for the nine months ended September 30, 2018 primarily due to the mix of earnings between U.S. and foreign jurisdictions.

[0001069202-19-000036:mdna:85]
Year-to-Date through September 30, 2019 Compared to Year-to-Date through September 30, 2018 - Results by Segment

[0001069202-19-000036:mdna:86]
[same as prior period, unchanged from 0001069202-19-000030:mdna:86]

[0001069202-19-000036:mdna:87]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the nine months ended September 30, 2019 and 2018 (dollars in millions):

[0001069202-19-000036:mdna:88]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 1,792.2 |  |  | $ | 1,764.4 |  |  | $ | 27.8 |  |  | 1.6 | % |
| Profit | $ | 366.6 |  |  | $ | 317.9 |  |  | $ | 48.7 |  |  | 15.3 | % |
| % of net sales | 20.5 | % |  | 18.0 | % |  |  |  |  |

[0001069202-19-000036:mdna:89]
Net sales increased 2% in the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018 due to higher combined price and mix.

[0001069202-19-000036:mdna:90]
Segment profit increased $49 million for the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018 due to $74 million of insurance proceeds for lost profits related to the Marshalltown tornado, $33 million of favorable price and mix, $11 million of sourcing and engineering-led cost reductions, and $1 million of higher equity method income.  Partially offsetting these increases is $25 million of higher freight and distribution expenses, $11 million of higher SG&A, $9 million from lower factory efficiency, $8 million of higher commodity costs, $7 million of lower sales volume, $8 million of higher other product costs, $1 million of higher tariffs on imported Chinese components, and $1 million of unfavorable foreign exchange rates.

[0001069202-19-000036:mdna:91]
[same as prior period, unchanged from 0001069202-19-000030:mdna:92]

[0001069202-19-000036:mdna:92]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the nine months ended September 30, 2019 and 2018 (dollars in millions):

[0001069202-19-000036:mdna:93]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 687.9 |  |  | $ | 668.1 |  |  | $ | 19.8 |  |  | 3.0 | % |
| Profit | $ | 116.0 |  |  | $ | 117.6 |  |  | $ | (1.6 | ) |  | (1.4 | )% |
| % of net sales | 16.9 | % |  | 17.6 | % |  |  |  |  |

[0001069202-19-000036:mdna:94]
Net sales increased 3% in the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018 due to 4% higher combined price and mix partially offset by 1% lower sales volume.

[0001069202-19-000036:mdna:95]
Segment profit decreased $2 million in the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018 due to $7 million of higher other product costs, $5 million from lower factory efficiency, $5 million of higher commodity costs, $4 million of higher freight and distribution expense, $4 million of higher SG&A expense, $3 million of lower sales volume, and $2 million of higher tariffs on Chinese imports.  Partially offsetting these decreases was $23 million of higher price and mix combined, $4 million of sourcing and engineering-led cost reductions, and $1 million of higher equity method income.

[0001069202-19-000036:mdna:96]
[same as prior period, unchanged from 0001069202-19-000030:mdna:97]

[0001069202-19-000036:mdna:97]
The following table presents our Refrigeration segment's net sales and profit for the nine months ended September 30, 2019 and 2018 (dollars in millions):

[0001069202-19-000036:mdna:98]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 442.1 |  |  | $ | 607.9 |  |  | $ | (165.8 | ) |  | (27.3 | )% |
| Profit | $ | 47.3 |  |  | $ | 57.1 |  |  | $ | (9.8 | ) |  | (17.2 | )% |
| % of net sales | 10.7 | % |  | 9.4 | % |  |  |  |  |

[0001069202-19-000036:mdna:99]
Net sales decreased 27% in the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018.  The loss of sales from our divested Australia, New Zealand, Asia, South America and Kysor Warren businesses contributed 27% and unfavorable foreign currency exchange rates contributed 1%, partially offset by 1% favorable combined price and mix.

[0001069202-19-000036:mdna:100]
Segment profit in the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018 decreased $10 million due to $4 million of lower profit due to the divested Australia, New Zealand, Asia, South America and Kysor Warren businesses, $3 million of higher commodity costs, $3 million of lower European refrigerant allocation sales, $2 million from lower factory efficiency, $2 million of higher tariffs on Chinese imports, $2 million of higher other product costs, $1 million of higher SG&A expense, $1 million of higher freight and distribution expense, and $1 million of lower equity method income.  Partially offsetting these declines was $5 million of sourcing and engineering-led cost reductions, $3 million of higher combined price and mix, and $1 million of higher sales volume.

[0001069202-19-000036:mdna:101]
[same as prior period, unchanged from 0001069202-19-000030:mdna:102]

[0001069202-19-000036:mdna:102]
Corporate and other expenses decreased $8 million in the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018 due to lower short-term and long-term incentive compensation.

[0001069202-19-000036:mdna:103]
[same as prior period, unchanged from 0001069202-19-000030:mdna:104]

[0001069202-19-000036:mdna:104]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-19-000036:mdna:105]
[same as prior period, unchanged from 0001069202-19-000030:mdna:107]

[0001069202-19-000036:mdna:106]
The following table summarizes our cash flow activity for the nine months ended September 30, 2019 and 2018 (in millions):

[0001069202-19-000036:mdna:107]
|  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |
| Net cash provided by operating activities | $ | 124.5 |  |  | $ | 231.3 |  |
| Net cash (used in) provided by investing activities | (23.1 | ) |  | 59.3 |  |
| Net cash used in financing activities | (102.8 | ) |  | (316.6 | ) |

[0001069202-19-000036:mdna:108]
Net Cash Provided by Operating Activities - The net cash used in operating activities in the nine months ended September 30,  2019 and 2018 reflects the seasonal increase in working capital requirements. The decrease in cash provided by operating activities in the nine months ended September 30, 2019 compared to the same period in 2018 was primarily due to the timing of working capital payments and the supply disruption in 2018 caused by the tornado at our Marshalltown facility.

[0001069202-19-000036:mdna:109]
Net Cash Provided by (Used in) Investing Activities - Capital expenditures were $77 million in the nine months ended September 30, 2019 compared to $61 million in the same period of 2018.  Capital expenditures in 2019 were primarily related to the reconstruction of the Marshalltown facility as well as equipment and investments in systems and software to support the overall enterprise.  Net proceeds of $44 million in the first quarter of 2019 were provided by the sale of our Kysor Warren business. We also received $12 million in insurance proceeds to fund the reconstruction of our Marshalltown facility.

[0001069202-19-000036:mdna:110]
Net Cash Provided by (Used in) Financing Activities - Net cash used in financing activities in the nine months ended September 30, 2019 was $103 million compared to $317 million in the same period of 2018.  The decrease in cash used in financing activities is largely due to higher net borrowings on our revolving credit facility partially offset by an increase in share repurchases in 2019 compared to 2018.  We repurchased $400 million of shares for the nine months ended September 30, 2019 compared to $350 million of shares in the same period of 2018.  We also returned $81 million to shareholders through dividend payments in the nine months ended September 30, 2019. For additional information on share repurchases, refer to Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000036:mdna:111]
[same as prior period, unchanged from 0001069202-19-000030:mdna:113]

[0001069202-19-000036:mdna:112]
The following table details our lines of credit and financing arrangements as of September 30, 2019 (in millions):

[0001069202-19-000036:mdna:113]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset Securitization Program | $ | 365.5 |  |
| Capital lease obligations | $ | 6.9 |  |
| Domestic credit facility(1) | 22.5 |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 394.3 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | — |  |
| Capital lease obligations | 23.7 |  |
| Domestic credit facility(1) | 685.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (2.4 | ) |
| Total long-term debt | 1,056.8 |  |
| Total debt | $ | 1,451.1 |  |

[0001069202-19-000036:mdna:114]
(1) The available future borrowings on our domestic credit facility are $449.5 million after being reduced by the outstanding borrowings and $2.5 million in outstanding standby letters of credit.  We also had $29.6 million in outstanding standby letters of credit outside of the domestic credit facility as of September 30, 2019.

[0001069202-19-000036:mdna:115]
[same as prior period, unchanged from 0001069202-19-000030:mdna:117]

[0001069202-19-000036:mdna:116]
[same as prior period, unchanged from 0001069202-19-000030:mdna:118]

[0001069202-19-000036:mdna:117]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 123.6% at September 30, 2019 from 116.8% at December 31, 2018.

[0001069202-19-000036:mdna:118]
As of September 30, 2019, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-19-000036:mdna:119]
[same as prior period, unchanged from 0001069202-19-000030:mdna:121]

[0001069202-19-000036:mdna:120]
We believe our cash and cash equivalents of $46 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $46 million as of September 30,

[0001069202-19-000036:mdna:121]
2019 was $19 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-19-000036:mdna:122]
Our expected capital expenditures for 2019 are $100 million, excluding capital expenditures made in conjunction with repair of our Marshalltown facility as those repairs will be covered by insurance.  We also continue to increase shareholder value through the $400 million of share repurchases completed in the nine months ended September 30, 2019.

[0001069202-19-000036:mdna:123]
[same as prior period, unchanged from 0001069202-19-000030:mdna:124]

[0001069202-19-000036:mdna:124]
[same as prior period, unchanged from 0001069202-19-000030:mdna:125]

[0001069202-19-000036:mdna:125]
Commitments, Contingencies and Guarantees

[0001069202-19-000036:mdna:126]
For information regarding our commitments, contingencies and guarantees, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000036:mdna:127]
[same as prior period, unchanged from 0001069202-19-000030:mdna:128]

[0001069202-19-000036:mdna:128]
[same as prior period, unchanged from 0001069202-19-000030:mdna:129]
