# LII MD&A — 0001069202-14-000008


## mdna

[0001069202-14-000008:mdna:1]
[same as prior period, unchanged from 0001069202-14-000006:mdna:1]

[0001069202-14-000008:mdna:2]
[same as prior period, unchanged from 0001069202-14-000006:mdna:2]

[0001069202-14-000008:mdna:3]
[same as prior period, unchanged from 0001069202-14-000006:mdna:3]

[0001069202-14-000008:mdna:4]
[same as prior period, unchanged from 0001069202-14-000006:mdna:4]

[0001069202-14-000008:mdna:5]
[same as prior period, unchanged from 0001069202-14-000006:mdna:5]

[0001069202-14-000008:mdna:6]
[same as prior period, unchanged from 0001069202-14-000006:mdna:6]

[0001069202-14-000008:mdna:7]
[same as prior period, unchanged from 0001069202-14-000006:mdna:7]

[0001069202-14-000008:mdna:8]
| • | Net sales increased $30 million, or 4%, to $898 million in the third quarter of 2014 compared to $868 million in the third quarter of 2013. |

[0001069202-14-000008:mdna:9]
| • | Operational income from continuing operations in the third quarter of 2014 increased $3 million to $107 million from $104 million in the third quarter of 2013. |

[0001069202-14-000008:mdna:10]
| • | Net income for the third quarter of 2014 increased $3 million to $67 million from $64 million in the third quarter of 2013. |

[0001069202-14-000008:mdna:11]
| • | Diluted earnings per share from continuing operations were $1.38 per share in the third quarter of 2014 compared to $1.30 per share in the third quarter of 2013. |

[0001069202-14-000008:mdna:12]
| • | During the third quarter of 2014, we returned $15 million to shareholders through dividend payments and $50 million through share repurchases. |

[0001069202-14-000008:mdna:13]
| • | Cash provided by operating activities was $24 million in the first nine months of 2014 compared to $65 million in the first nine months of 2013. |

[0001069202-14-000008:mdna:14]
Third Quarter of 2014 Compared to Third Quarter of 2013 - Consolidated Results

[0001069202-14-000008:mdna:15]
[same as prior period, unchanged from 0001069202-14-000006:mdna:15]

[0001069202-14-000008:mdna:16]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | $ | 898.4 |  |  | $ | 868.0 |  |  | 3.5 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 651.3 |  |  | 630.6 |  |  | (3.3 | ) |  | 72.5 |  |  | 72.6 |  |
| Gross profit | 247.1 |  |  | 237.4 |  |  | 4.1 |  |  | 27.5 |  |  | 27.4 |  |
| Selling, general and administrative expenses | 140.9 |  |  | 136.9 |  |  | (2.9 | ) |  | 15.7 |  |  | 15.8 |  |
| Losses (gains) and other expenses, net | 2.1 |  |  | (0.3 | ) |  | (800.0 | ) |  | 0.2 |  |  | — |  |
| Restructuring charges | 1.0 |  |  | 0.3 |  |  | (233.3 | ) |  | 0.1 |  |  | — |  |
| Income from equity method investments | (3.5 | ) |  | (3.3 | ) |  | 6.1 |  |  | (0.4 | ) |  | (0.4 | ) |
| Operational income from continuing operations | $ | 106.6 |  |  | $ | 103.8 |  |  | 2.7 | % |  | 11.9 | % |  | 12.0 | % |

[0001069202-14-000008:mdna:17]
[same as prior period, unchanged from 0001069202-14-000006:mdna:17]

[0001069202-14-000008:mdna:18]
Net sales increased 4% in the third quarter of 2014 compared to the third quarter of 2013, primarily from 3% higher sales volumes and 1% favorable price and mix.  The Residential Heating & Cooling and Commercial Heating & Cooling segments delivered higher volume by capturing additional replacement and new construction business.

[0001069202-14-000008:mdna:19]
[same as prior period, unchanged from 0001069202-14-000006:mdna:19]

[0001069202-14-000008:mdna:20]
Gross profit margin in the third quarter of 2014 increased 10 basis points ("bps") to 27.5% compared to the third quarter of 2013.  Lower material costs increased our profit margin by 100 bps and volume increased our profit margin by 10 bps. Offsetting these increases were decreases due to 10 bps of unfavorable mix and price, 40 bps from lower refrigerant pricing on our Australia wholesale business when compared to the prior year quarter, 10 bps from unfavorable foreign currency exchange rate impact, and 40 bps for investments in distribution and other growth initiatives with the balance from other cost changes.

[0001069202-14-000008:mdna:21]
[same as prior period, unchanged from 0001069202-14-000006:mdna:21]

[0001069202-14-000008:mdna:22]
SG&A was $141 million in the third quarter of 2014 compared to $137 million in the third quarter of 2013, and as a percentage of net sales was relatively flat.

[0001069202-14-000008:mdna:23]
[same as prior period, unchanged from 0001069202-14-000006:mdna:23]

[0001069202-14-000008:mdna:24]
Losses (gains) and other expenses, net for the third quarter of 2014 and 2013 included the following (in millions):

[0001069202-14-000008:mdna:25]
|  | For the Three Months Ended September 30, |
|  | 2014 |  | 2013 |
| Realized losses on settled future contracts | $ | 0.1 |  |  | $ | 0.4 |  |
| Foreign currency exchange losses (gains) | 0.1 |  |  | (0.5 | ) |
| Loss on disposal of fixed assets | 0.1 |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.2 |  |  | (1.1 | ) |
| Special legal contingency charges | 0.5 |  |  | 0.8 |  |
| Asbestos-related litigation | 0.4 |  |  | — |  |
| Environmental liabilities | 0.7 |  |  | — |  |
| Other items, net | — |  |  | 0.1 |  |
| Losses (gains) and other expenses, net | $ | 2.1 |  |  | $ | (0.3 | ) |

[0001069202-14-000008:mdna:26]
The net change in unrealized losses (gains) on unsettled futures contracts was due to lower commodity prices relative to the

[0001069202-14-000008:mdna:27]
unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange losses (gains) increased in the third quarter of 2014 primarily due to the Australian and Canadian dollar exchange rates. For more information on asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000008:mdna:28]
[same as prior period, unchanged from 0001069202-14-000006:mdna:27]

[0001069202-14-000008:mdna:29]
Restructuring charges increased to $1 million in the third quarter of 2014 while minimal restructuring charges were incurred in the third quarter of 2013.  The increase was for a new project to realign accountabilities and enhance distribution capabilities.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000008:mdna:30]
[same as prior period, unchanged from 0001069202-14-000006:mdna:29]

[0001069202-14-000008:mdna:31]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $4 million in the third quarter of 2014 increased slightly over the third quarter of 2013 due to improved operating results from our joint ventures.

[0001069202-14-000008:mdna:32]
[same as prior period, unchanged from 0001069202-14-000006:mdna:31]

[0001069202-14-000008:mdna:33]
Interest expense, net was $4 million in the third quarter of 2014 and was flat compared to the third quarter of 2013.  The impact of the increase in our average net borrowings was offset by a slight decline in weighted average borrowing rates over the comparable periods.

[0001069202-14-000008:mdna:34]
[same as prior period, unchanged from 0001069202-14-000006:mdna:33]

[0001069202-14-000008:mdna:35]
The Provision for income taxes was $35 million in the third quarter of 2014 compared to $34 million in the third quarter of 2013.  The effective tax rate remained unchanged at 34.2% for the third quarter of 2014 compared to the third quarter of 2013.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-14-000008:mdna:36]
Third Quarter of 2014 Compared to Third Quarter of 2013 - Results by Segment

[0001069202-14-000008:mdna:37]
[same as prior period, unchanged from 0001069202-14-000006:mdna:36]

[0001069202-14-000008:mdna:38]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000008:mdna:39]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 462.6 |  |  | $ | 433.9 |  |  | $ | 28.7 |  |  | 6.6 | % |
| Profit | $ | 69.4 |  |  | $ | 57.0 |  |  | $ | 12.4 |  |  | 21.8 | % |
| % of net sales | 15.0 | % |  | 13.1 | % |  |  |  |  |

[0001069202-14-000008:mdna:40]
Net sales increased by 7% in the third quarter of 2014 compared to the third quarter of 2013.  Volume increased by 6% due to industry growth and market share gains and favorable price and mix increased net sales by 1%.

[0001069202-14-000008:mdna:41]
Segment profit for the third quarter of 2014 increased $12 million due to $7 million in material cost savings, $6 million in higher sales volumes, $2 million from favorable price, and $1 million from favorable other product cost changes.  Partially offsetting these increases was $1 million of unfavorable foreign currency exchange rates, $1 million of higher SG&A expenses, and $2 million from investments in distribution.

[0001069202-14-000008:mdna:42]
[same as prior period, unchanged from 0001069202-14-000006:mdna:41]

[0001069202-14-000008:mdna:43]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000008:mdna:44]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 241.6 |  |  | $ | 239.1 |  |  | $ | 2.5 |  |  | 1.0 | % |
| Profit | $ | 42.2 |  |  | $ | 39.2 |  |  | $ | 3.0 |  |  | 7.7 | % |
| % of net sales | 17.5 | % |  | 16.4 | % |  |  |  |  |

[0001069202-14-000008:mdna:45]
Net sales increased 1% in the third quarter of 2014 compared to the third quarter of 2013 due primarily to volume increases in our North American service business.

[0001069202-14-000008:mdna:46]
Segment profit in the third quarter of 2014 increased $3 million compared to the third quarter of 2013, with increases of $1 million from higher sales volumes, $2 million in material cost savings, and $1 million from favorable price and mix. Partially offsetting these increases was a total of $1 million higher SG&A expenses including start-up costs to enter the Variable Refrigerant Flow ("VRF") market.

[0001069202-14-000008:mdna:47]
[same as prior period, unchanged from 0001069202-14-000006:mdna:46]

[0001069202-14-000008:mdna:48]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000008:mdna:49]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 194.2 |  |  | $ | 195.0 |  |  | $ | (0.8 | ) |  | (0.4 | )% |
| Profit | $ | 16.5 |  |  | $ | 23.9 |  |  | $ | (7.4 | ) |  | (31.0 | )% |
| % of net sales | 8.5 | % |  | 12.3 | % |  |  |  |  |

[0001069202-14-000008:mdna:50]
Net sales were relatively flat in the third quarter of 2014 compared to the third quarter of 2013, with favorable mix and price and favorable foreign currency exchange rates, offset by a negative impact to the profitability of our refrigerant business in Australia due to the repeal of the carbon tax.

[0001069202-14-000008:mdna:51]
Segment profit for the third quarter of 2014 decreased $7 million compared to the third quarter of 2013 primarily due to $4 million from unfavorable mix, $3 million lower profitability in our Australia refrigerant business, and $1 million of costs related to investments for future growth, offset by a $1 million increase from favorable price.

[0001069202-14-000008:mdna:52]
[same as prior period, unchanged from 0001069202-14-000006:mdna:51]

[0001069202-14-000008:mdna:53]
Corporate and other expenses increased $1 million to $18 million in the third quarter of 2014 from $17 million in the third quarter of 2013 due primarily to higher wages and other administrative expenses.

[0001069202-14-000008:mdna:54]
Year-to-Date through September 30, 2014 Compared to Year-to-Date through September 30, 2013 - Consolidated Results

[0001069202-14-000008:mdna:55]
[same as prior period, unchanged from 0001069202-14-000006:mdna:54]

[0001069202-14-000008:mdna:56]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | $ | 2,554.6 |  |  | $ | 2,449.5 |  |  | 4.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,876.7 |  |  | 1,796.1 |  |  | 4.5 |  |  | 73.5 |  |  | 73.3 |  |
| Gross profit | 677.9 |  |  | 653.4 |  |  | 3.7 |  |  | 26.5 |  |  | 26.7 |  |
| Selling, general and administrative expenses | 425.5 |  |  | 424.0 |  |  | 0.4 |  |  | 16.7 |  |  | 17.3 |  |
| Losses and other expenses, net | 3.5 |  |  | 2.8 |  |  | 25.0 |  |  | 0.1 |  |  | 0.1 |  |
| Restructuring charges | 1.3 |  |  | 3.2 |  |  | (59.4 | ) |  | 0.1 |  |  | 0.1 |  |
| Income from equity method investments | (12.0 | ) |  | (10.7 | ) |  | 12.1 |  |  | (0.5 | ) |  | (0.4 | ) |
| Operational income from continuing operations | $ | 259.6 |  |  | $ | 234.1 |  |  | 10.9 |  |  | 10.2 | % |  | 9.6 | % |

[0001069202-14-000008:mdna:57]
[same as prior period, unchanged from 0001069202-14-000006:mdna:56]

[0001069202-14-000008:mdna:58]
Net sales increased 4% in the first nine months of 2014 compared to the first nine months of 2013, with sales volumes up 4% and price and mix up 1%.  The volume increases were driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  Partially offsetting these increases was a 1% decrease from unfavorable foreign currency exchange rates.

[0001069202-14-000008:mdna:59]
[same as prior period, unchanged from 0001069202-14-000006:mdna:58]

[0001069202-14-000008:mdna:60]
Gross profit margins in the first nine months of 2014 decreased 20 bps to 27% compared to the first nine months of 2013.  Improvements of 120 bps from material cost savings were offset by 10 bps from unfavorable price and mix, 20 bps from unfavorable foreign currency exchange rates, 50 bps for investments in distribution and other growth initiatives, and 60 bps from increased total other product costs.

[0001069202-14-000008:mdna:61]
[same as prior period, unchanged from 0001069202-14-000006:mdna:60]

[0001069202-14-000008:mdna:62]
SG&A was $426 million for the first nine months of 2014 compared to $424 million for the first nine months of 2013, and as a percentage of net sales, declined 60 bps from 17.3% to 16.7%.  The largest driver of the decrease in SG&A as a percentage of net sales was lower incentive compensation.

[0001069202-14-000008:mdna:63]
[same as prior period, unchanged from 0001069202-14-000006:mdna:62]

[0001069202-14-000008:mdna:64]
Losses and other expenses, net for the first nine months of 2014 and 2013 included the following (in millions):

[0001069202-14-000008:mdna:65]
|  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |
| Realized losses on settled future contracts | $ | 0.6 |  |  | $ | 0.8 |  |
| Foreign currency exchange losses (gains) | 0.1 |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | 0.7 |  |
| Special legal contingency charges | 0.7 |  |  | 1.0 |  |
| Asbestos-related litigation | 1.0 |  |  | — |  |
| Environmental liabilities | 0.7 |  |  | — |  |
| Other items, net | 0.3 |  |  | 0.3 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.5 |  |  | $ | 2.8 |  |

[0001069202-14-000008:mdna:66]
The net change in unrealized (gains) losses on unsettled futures contracts was due to higher commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.   For more information on asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000008:mdna:67]
[same as prior period, unchanged from 0001069202-14-000006:mdna:66]

[0001069202-14-000008:mdna:68]
Restructuring charges were $1 million in the first nine months of 2014 and $3 million in the first nine months of 2013.  2014 charges were for a new project to realign accountabilities and enhance distribution capabilities while the 2013 charges related primarily to our Regional Distribution Network project as well as anticipated severance charges associated with a relocation of certain Residential Heating & Cooling manufacturing operations to lower cost facilities. For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000008:mdna:69]
[same as prior period, unchanged from 0001069202-14-000006:mdna:68]

[0001069202-14-000008:mdna:70]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $12 million in the first nine months of 2014 increased $1 million over the first nine months of 2013 due to improved operating results from our joint ventures.

[0001069202-14-000008:mdna:71]
[same as prior period, unchanged from 0001069202-14-000006:mdna:70]

[0001069202-14-000008:mdna:72]
Interest expense, net was $11 million in the first nine months of 2014 and was flat compared to the first nine months of 2013.  The impact of the increase in our average net borrowings was offset by a slight decline in weighted average borrowing rates over the comparable periods.

[0001069202-14-000008:mdna:73]
[same as prior period, unchanged from 0001069202-14-000006:mdna:72]

[0001069202-14-000008:mdna:74]
The Provision for income taxes was $87 million in the first nine months of 2014 compared to $78 million in the first nine months of 2013.  The effective tax rate was 34.8% for the first nine months of 2014 compared to 34.7% for the first nine months of 2013.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-14-000008:mdna:75]
Year-to-Date through September 30, 2014 Compared to Year-to-Date through September 30, 2013 - Results by Segment

[0001069202-14-000008:mdna:76]
[same as prior period, unchanged from 0001069202-14-000006:mdna:75]

[0001069202-14-000008:mdna:77]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first nine months of 2014 and 2013 (dollars in millions):

[0001069202-14-000008:mdna:78]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 1,332.5 |  |  | $ | 1,224.5 |  |  | $ | 108 |  |  | 8.8 | % |
| Profit | $ | 178.8 |  |  | $ | 143.7 |  |  | $ | 35.1 |  |  | 24.4 | % |
| % of net sales | 13.4 | % |  | 11.7 | % |  |  |  |  |

[0001069202-14-000008:mdna:79]
Net sales increased by 9%  in the first nine months of 2014 compared to the first nine months of 2013.  Sales volumes increased net sales by 8% due to industry growth and market share gains and the benefits of favorable price and mix contributed 2%.  Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-14-000008:mdna:80]
Segment profit for the first nine months of 2014 increased $35 million due to $20 million contributed by incremental volume, $22 million from material cost savings, and $5 million from favorable price with mix contributing $1 million. Partially offsetting these increases was $7 million in distribution expenses related to continued investment in distribution expansion, and unfavorable foreign exchange rates of $6 million.

[0001069202-14-000008:mdna:81]
[same as prior period, unchanged from 0001069202-14-000006:mdna:80]

[0001069202-14-000008:mdna:82]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first nine months of 2014 and 2013 (dollars in millions):

[0001069202-14-000008:mdna:83]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 655.6 |  |  | $ | 631.8 |  |  | $ | 23.8 |  |  | 3.8 | % |
| Profit | $ | 91.3 |  |  | $ | 84.8 |  |  | $ | 6.5 |  |  | 7.7 | % |
| % of net sales | 13.9 | % |  | 13.4 | % |  |  |  |  |

[0001069202-14-000008:mdna:84]
Commercial Heating & Cooling net sales increased 4% in the first nine months of 2014 compared to the first nine months of 2013 due to broad-based volume increases in North America.

[0001069202-14-000008:mdna:85]
Segment profit in the first nine months of 2014 increased $7 million compared to the first nine months of 2013.  The benefits of $7 million from incremental volume and $5 million from material cost savings were offset by $4 million higher SG&A expenses including start-up costs to enter the VRF market, with the balance associated with other costs including investments in distribution expansion.

[0001069202-14-000008:mdna:86]
[same as prior period, unchanged from 0001069202-14-000006:mdna:85]

[0001069202-14-000008:mdna:87]
The following table presents our Refrigeration segment's net sales and profit for the first nine months of 2014 and 2013 (dollars in millions):

[0001069202-14-000008:mdna:88]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 566.5 |  |  | $ | 593.2 |  |  | $ | (26.7 | ) |  | (4.5 | )% |
| Profit | $ | 42.3 |  |  | $ | 66.5 |  |  | $ | (24.2 | ) |  | (36.4 | )% |
| % of net sales | 7.5 | % |  | 11.2 | % |  |  |  |  |

[0001069202-14-000008:mdna:89]
Refrigeration net sales declined 5% in the first nine months of 2014 compared to the first nine months of 2013 primarily due to a 3% volume decline and a 2% impact from unfavorable Australian dollar exchange rates.  The North American supermarket and Australian wholesale businesses have been soft.  We continue to expect the North American supermarket business to improve in the last quarter of the year based on national account business won in 2014.  In Australia, with the repeal of the carbon tax, we expect a negative impact to the profitability of our refrigerant business for the remainder of the year.

[0001069202-14-000008:mdna:90]
Segment profit for the first nine months of 2014 decreased $24 million compared to the first nine months of 2013 primarily due to volume related declines of $5 million, unfavorable mix of $9 million, unfavorable foreign exchange rates of $3 million, and $3 million relating to investment in growth initiatives.  These decreases were offset by a $1 million increase related to favorable price with the balance associated with other cost changes.

[0001069202-14-000008:mdna:91]
[same as prior period, unchanged from 0001069202-14-000006:mdna:90]

[0001069202-14-000008:mdna:92]
Corporate and other expenses decreased $8 million to $48 million in the first nine months of 2014 from $56 million in the first nine months of 2013 due primarily to lower incentive compensation.

[0001069202-14-000008:mdna:93]
[same as prior period, unchanged from 0001069202-14-000006:mdna:92]

[0001069202-14-000008:mdna:94]
[same as prior period, unchanged from 0001069202-14-000006:mdna:93]

[0001069202-14-000008:mdna:95]
[same as prior period, unchanged from 0001069202-14-000006:mdna:94]

[0001069202-14-000008:mdna:96]
The following table summarizes our cash flow activity for the nine months ended September 30, 2014 and 2013 (in millions):

[0001069202-14-000008:mdna:97]
|  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |
| Net cash provided by operating activities | $ | 23.5 |  |  | $ | 65.0 |  |
| Net cash used in investing activities | (59.7 | ) |  | (32.9 | ) |
| Net cash provided by (used in) financing activities | 49.7 |  |  | (42.2 | ) |

[0001069202-14-000008:mdna:98]
Net Cash Provided by Operating Activities - Net cash provided by operating activities decreased approximately $42 million in the first nine months of 2014 compared to $65 million in the first nine months of 2013.   This decrease was primarily attributable to the seasonal increase in working capital requirements and higher income tax payments in 2014 due to timing of payments, partially offset by higher net income.

[0001069202-14-000008:mdna:99]
Net Cash Used in Investing Activities - Capital expenditures were $60 million and $41 million in the first nine months of 2014 and 2013, respectively.  Capital expenditures in 2014 were primarily related to an expansion of manufacturing capacity for our Residential Heating & Cooling segment, investments in systems and software to support the overall enterprise and investments in our distribution network.  Net cash used in investing activities in the first nine months of 2013 also included net proceeds of $5 million from the sale of the Service Experts business.

[0001069202-14-000008:mdna:100]
Net Cash Provided by (Used in) Financing Activities - Net cash provided by financing activities increased to $50 million in the first nine months of 2014 primarily due to an increase in net borrowings and was partially offset by increases in stock repurchases and cash dividends paid.  Net borrowings were higher in 2014 to support the increased stock repurchases, dividend and tax payments.  Dividend payments increased because the fourth quarter 2012 dividend was paid in 2012, whereas the fourth quarter 2013 dividend was not paid until the first quarter of 2014.

[0001069202-14-000008:mdna:101]
[same as prior period, unchanged from 0001069202-14-000006:mdna:100]

[0001069202-14-000008:mdna:102]
The following table details our lines of credit and financing arrangements as of September 30, 2014 (in millions):

[0001069202-14-000008:mdna:103]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-term debt: |  |  |  |  |  |
| Foreign obligations | $ | 28.6 |  |  | $ | 9.0 |  |  | $ | 19.6 |  |
| Asset Securitization Program (1) | 220.0 |  |  | 220.0 |  |  | — |  |
| Total short-term debt | $ | 248.6 |  |  | $ | 229.0 |  |  | $ | 19.6 |  |
| Current maturities of long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | — |  |
| Long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.7 |  |  | $ | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 149.0 |  |  | 473.8 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 866.7 |  |  | 365.7 |  |  | 473.8 |  |
| Total debt | $ | 1,116.6 |  |  | $ | 596.0 |  |  | $ | 493.4 |  |

[0001069202-14-000008:mdna:104]
[same as prior period, unchanged from 0001069202-14-000006:mdna:103]

[0001069202-14-000008:mdna:105]
(2) The available future borrowings on our domestic revolving credit facility were reduced by the outstanding borrowings and $27.2 million in outstanding standby letters of credit.  We also had $26.4 million in outstanding standby letters of credit outside of the domestic revolving credit facility as of September 30, 2014.

[0001069202-14-000008:mdna:106]
[same as prior period, unchanged from 0001069202-14-000006:mdna:105]

[0001069202-14-000008:mdna:107]
[same as prior period, unchanged from 0001069202-14-000006:mdna:106]

[0001069202-14-000008:mdna:108]
market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 54.3% at September 30, 2014 from 45.2% at December 31, 2013 due to the increase in our net borrowings, as noted above.

[0001069202-14-000008:mdna:109]
As of September 30, 2014, our senior credit rating with Moody's Investors Service, Inc. ("Moody's") was Baa3 with a stable outlook, which is judged to be lowest investment grade and subject to moderate credit risk and may possess certain speculative characteristics. Our senior credit rating with Standard & Poor's Rating Group ("S&P") was upgraded in the first quarter of 2014 by one notch to BBB with a stable outlook, which is judged to be investment grade but subject to weakened ability to meet commitments upon adverse economic conditions or changing circumstances. The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency. Each rating should be evaluated independently of any other rating. Our goal is to retain investment grade ratings from Moody's and S&P to ensure adequate access to capital markets.

[0001069202-14-000008:mdna:110]
[same as prior period, unchanged from 0001069202-14-000006:mdna:108]

[0001069202-14-000008:mdna:111]
We believe our cash and cash equivalents of $48 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $48 million as of September 30, 2014 was $31.5 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and pay taxes in the United States for the amounts that were repatriated.

[0001069202-14-000008:mdna:112]
[same as prior period, unchanged from 0001069202-14-000006:mdna:110]

[0001069202-14-000008:mdna:113]
[same as prior period, unchanged from 0001069202-14-000006:mdna:111]

[0001069202-14-000008:mdna:114]
[same as prior period, unchanged from 0001069202-14-000006:mdna:112]

[0001069202-14-000008:mdna:115]
Commitments, Contingencies and Guarantees

[0001069202-14-000008:mdna:116]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000008:mdna:117]
[same as prior period, unchanged from 0001069202-14-000006:mdna:115]

[0001069202-14-000008:mdna:118]
On May 28, 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2017. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.
