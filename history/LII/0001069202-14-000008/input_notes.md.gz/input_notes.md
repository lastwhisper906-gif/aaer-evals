# LII notes — 0001069202-14-000008


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-14-000008:notes:1]
[same as prior period, unchanged from 0001069202-14-000006:notes:1]

[0001069202-14-000008:notes:2]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2014, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-14-000008:notes:3]
[same as prior period, unchanged from 0001069202-14-000006:notes:4]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-14-000008:notes:4]
Commitments and Contingencies:

[0001069202-14-000008:notes:5]
Product Warranties and Product Related Contingencies

[0001069202-14-000008:notes:6]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-14-000008:notes:7]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000008:notes:8]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 27.5 |  |  | $ | 28.7 |  |
| Other liabilities | 58.6 |  |  | 52.9 |  |
| Total warranty liability | $ | 86.1 |  |  | $ | 81.6 |  |

[0001069202-14-000008:notes:9]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2014 were as follows (in millions):

[0001069202-14-000008:notes:10]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (16.6 | ) |
| Changes resulting from issuance of new warranties | 24.1 |  |
| Changes in estimates associated with pre-existing liabilities | (2.3 | ) |
| Changes in foreign currency translation rates and other | (0.7 | ) |
| Total warranty liability as of September 30, 2014 | $ | 86.1 |  |

[0001069202-14-000008:notes:11]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001069202-14-000008:notes:12]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the nine months ended September 30, 2014 were as follows (in millions):

[0001069202-14-000008:notes:13]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.6 | ) |
| Total accrued product quality issues as of September 30, 2014 | $ | 4.1 |  |

[0001069202-14-000008:notes:14]
The expenses related to these product quality issues were classified in Cost of goods sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the Consolidated Balance Sheets.  The expenses for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated product warranty liabilities.  We may incur additional charges for these product quality issues in the future as more information becomes available.

[0001069202-14-000008:notes:15]
Litigation

[0001069202-14-000008:notes:16]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-14-000008:notes:17]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2014, and 2013, expense for asbestos-related litigation was $1.0 million, and $0.5 million, net of insurance recoveries, respectively.

[0001069202-14-000008:notes:18]
We are the defendant in an attempted class action lawsuit which alleges that evaporator coils in certain of our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks, and asserts claims for relief.  We dispute the allegations in the lawsuit.  The outcome related to this action is uncertain and we therefore cannot reasonably estimate the amount of any potential impact.

[0001069202-14-000008:notes:19]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-14-000008:notes:20]
[same as prior period, unchanged from 0001069202-14-000006:notes:21]

[0001069202-14-000008:notes:21]
[same as prior period, unchanged from 0001069202-14-000006:notes:22]

[0001069202-14-000008:notes:22]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (1.0 | ) |  | $ | (2.1 | ) |  | $ | (4.9 | ) |  | $ | (3.3 | ) |  | Cost of goods sold |
| Income tax benefit |  | 0.4 |  |  | 0.8 |  |  | 1.8 |  |  | 1.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.6 | ) |  | $ | (1.3 | ) |  | $ | (3.1 | ) |  | $ | (2.1 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.3 | ) |  | $ | (2.0 | ) |  | $ | (4.0 | ) |  | $ | (6.1 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.5 |  |  | 0.7 |  |  | 1.5 |  |  | 2.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.8 | ) |  | $ | (1.3 | ) |  | $ | (2.5 | ) |  | $ | (3.9 | ) |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |  |  |  |  |
| Sale of foreign business (1) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 41.1 |  |  | Loss from discontinued operations |
| Total reclassifications from AOCL |  | $ | (1.4 | ) |  | $ | (2.6 | ) |  | $ | (5.6 | ) |  | $ | 35.1 |  |  |  |

[0001069202-14-000008:notes:23]
[same as prior period, unchanged from 0001069202-14-000006:notes:24]

[0001069202-14-000008:notes:24]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2014 (in millions):

[0001069202-14-000008:notes:25]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| AOCL as of December 31, 2013 |  | $ | (0.6 | ) |  | $ | 2.5 |  |  | $ | (106.0 | ) |  | $ | 43.0 |  |  | $ | (61.1 | ) |
| Other comprehensive (loss) income before reclassifications |  | (4.2 | ) |  | 2.1 |  |  | (1.7 | ) |  | (17.6 | ) |  | (21.4 | ) |
| Amounts reclassified from AOCL |  | 3.1 |  |  | — |  |  | 2.5 |  |  | — |  |  | 5.6 |  |
| Net other comprehensive (loss) income |  | (1.1 | ) |  | 2.1 |  |  | 0.8 |  |  | (17.6 | ) |  | (15.8 | ) |
| AOCL as of September 30, 2014 |  | $ | (1.7 | ) |  | $ | 4.6 |  |  | $ | (105.2 | ) |  | $ | 25.4 |  |  | $ | (76.9 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-14-000008:notes:26]
[same as prior period, unchanged from 0001069202-14-000006:notes:27]

[0001069202-14-000008:notes:27]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001069202-14-000008:notes:28]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of September 30, 2014 and December 31, 2013 and for the three and nine months ended September 30, 2014 and 2013 are shown on the following pages.

[0001069202-14-000008:notes:29]
[same as prior period, unchanged from 0001069202-14-000006:notes:31]

[0001069202-14-000008:notes:30]
[same as prior period, unchanged from 0001069202-14-000006:notes:32]

[0001069202-14-000008:notes:31]
As of September 30, 2014

[0001069202-14-000008:notes:32]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.5 |  |  | $ | 15.1 |  |  | $ | 31.5 |  |  | $ | — |  |  | $ | 48.1 |  |
| Accounts and notes receivable, net | — |  |  | 11.8 |  |  | 489.7 |  |  | — |  |  | 501.5 |  |
| Inventories, net | — |  |  | 372.0 |  |  | 134.2 |  |  | (4.7 | ) |  | 501.5 |  |
| Deferred income taxes, net | 0.2 |  |  | 21.2 |  |  | 5.6 |  |  | (3.2 | ) |  | 23.8 |  |
| Other assets | 3.4 |  |  | 56.2 |  |  | 79.2 |  |  | (77.2 | ) |  | 61.6 |  |
| Total current assets | 5.1 |  |  | 476.3 |  |  | 740.2 |  |  | (85.1 | ) |  | 1,136.5 |  |
| Property, plant and equipment, net | — |  |  | 257.5 |  |  | 93.0 |  |  | — |  |  | 350.5 |  |
| Goodwill | — |  |  | 140.4 |  |  | 73.7 |  |  | — |  |  | 214.1 |  |
| Investment in subsidiaries | 1,320.7 |  |  | 344.5 |  |  | (0.5 | ) |  | (1,664.7 | ) |  | — |  |
| Deferred income taxes | 1.1 |  |  | 75.7 |  |  | 18.0 |  |  | (8.6 | ) |  | 86.2 |  |
| Other assets, net | 3.4 |  |  | 64.3 |  |  | 23.0 |  |  | (1.5 | ) |  | 89.2 |  |
| Intercompany receivables (payables), net | (459.5 | ) |  | 451.8 |  |  | 7.7 |  |  |  |  |  | — |  |
| Total assets | $ | 870.8 |  |  | $ | 1,810.5 |  |  | $ | 955.1 |  |  | $ | (1,759.9 | ) |  | $ | 1,876.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 229.0 |  |  | $ | — |  |  | $ | 229.0 |  |
| Current maturities of long-term debt | — |  |  | 1.0 |  |  | 0.3 |  |  | — |  |  | 1.3 |  |
| Accounts payable | 14.4 |  |  | 245.2 |  |  | 73.5 |  |  | — |  |  | 333.1 |  |
| Accrued expenses | 6.7 |  |  | 176.9 |  |  | 65.1 |  |  | — |  |  | 248.7 |  |
| Income taxes payable | (1.5 | ) |  | 31.9 |  |  | 64.8 |  |  | (82.4 | ) |  | 12.8 |  |
| Total current liabilities | 19.6 |  |  | 455.0 |  |  | 432.7 |  |  | (82.4 | ) |  | 824.9 |  |
| Long-term debt | 349.0 |  |  | 16.7 |  |  | — |  |  | — |  |  | 365.7 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.7 |  |  | — |  |  | — |  |  | 2.7 |  |
| Pensions | — |  |  | 51.3 |  |  | 9.3 |  |  | — |  |  | 60.6 |  |
| Other liabilities | 0.5 |  |  | 120.7 |  |  | 11.5 |  |  | (11.8 | ) |  | 120.9 |  |
| Total liabilities | 369.1 |  |  | 646.4 |  |  | 453.5 |  |  | (94.2 | ) |  | 1,374.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 501.7 |  |  | 1,164.1 |  |  | 501.6 |  |  | (1,665.7 | ) |  | 501.7 |  |
| Total liabilities and stockholders' equity | $ | 870.8 |  |  | $ | 1,810.5 |  |  | $ | 955.1 |  |  | $ | (1,759.9 | ) |  | $ | 1,876.5 |  |

[0001069202-14-000008:notes:33]
[same as prior period, unchanged from 0001069202-14-000006:notes:35]

[0001069202-14-000008:notes:34]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.1 |  |  | $ | 10.5 |  |  | $ | 26.4 |  |  | $ | — |  |  | $ | 38.0 |  |
| Accounts and notes receivable, net | — |  |  | 12.8 |  |  | 395.3 |  |  | — |  |  | 408.1 |  |
| Inventories, net | — |  |  | 253.6 |  |  | 128.4 |  |  | (3.2 | ) |  | 378.8 |  |
| Deferred income taxes, net | 0.9 |  |  | 21.2 |  |  | 5.7 |  |  | (3.3 | ) |  | 24.5 |  |
| Other assets | 3.4 |  |  | 38.4 |  |  | 70.2 |  |  | (59.0 | ) |  | 53.0 |  |
| Total current assets | 5.4 |  |  | 336.5 |  |  | 626.0 |  |  | (65.5 | ) |  | 902.4 |  |
| Property, plant and equipment, net | — |  |  | 246.4 |  |  | 89.1 |  |  | — |  |  | 335.5 |  |
| Goodwill | — |  |  | 140.4 |  |  | 76.4 |  |  | — |  |  | 216.8 |  |
| Investment in subsidiaries | 1,138.8 |  |  | 337.5 |  |  | (0.6 | ) |  | (1,475.7 | ) |  | — |  |
| Deferred income taxes | — |  |  | 76.9 |  |  | 20.2 |  |  | (8.6 | ) |  | 88.5 |  |
| Other assets, net | 4.2 |  |  | 64.3 |  |  | 16.4 |  |  | (1.4 | ) |  | 83.5 |  |
| Intercompany receivables (payables), net | (460.6 | ) |  | 434.0 |  |  | 26.6 |  |  | — |  |  | — |  |
| Total assets | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 165.9 |  |  | $ | — |  |  | $ | 165.9 |  |
| Current maturities of long-term debt | — |  |  | 1.0 |  |  | 0.3 |  |  | — |  |  | 1.3 |  |
| Accounts payable | 11.8 |  |  | 187.8 |  |  | 83.5 |  |  | — |  |  | 283.1 |  |
| Accrued expenses | 3.3 |  |  | 168.4 |  |  | 60.4 |  |  | — |  |  | 232.1 |  |
| Income taxes payable | (30.3 | ) |  | 75.7 |  |  | 49.9 |  |  | (63.7 | ) |  | 31.6 |  |
| Total current liabilities | (15.2 | ) |  | 432.9 |  |  | 360.0 |  |  | (63.7 | ) |  | 714.0 |  |
| Long-term debt | 217.0 |  |  | 15.8 |  |  | 0.4 |  |  | — |  |  | 233.2 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| Pensions | — |  |  | 58.4 |  |  | 11.6 |  |  | — |  |  | 70.0 |  |
| Other liabilities | 0.3 |  |  | 119.4 |  |  | 11.3 |  |  | (11.8 | ) |  | 119.2 |  |
| Total liabilities | 202.1 |  |  | 631.1 |  |  | 383.3 |  |  | (75.5 | ) |  | 1,141.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 485.7 |  |  | 1,004.9 |  |  | 470.8 |  |  | (1,475.7 | ) |  | 485.7 |  |
| Total liabilities and stockholders' equity | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |

[0001069202-14-000008:notes:35]
[same as prior period, unchanged from 0001069202-14-000006:notes:37]

[0001069202-14-000008:notes:36]
For the Three Months Ended September 30, 2014

[0001069202-14-000008:notes:37]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 736.2 |  |  | $ | 213.5 |  |  | $ | (51.3 | ) |  | $ | 898.4 |  |
| Cost of goods sold | — |  |  | 538.8 |  |  | 164.5 |  |  | (52.0 | ) |  | 651.3 |  |
| Gross profit | — |  |  | 197.4 |  |  | 49.0 |  |  | 0.7 |  |  | 247.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 127.4 |  |  | 13.5 |  |  | — |  |  | 140.9 |  |
| Losses (gains) and other expenses, net | (0.1 | ) |  | 1.2 |  |  | 1.0 |  |  | — |  |  | 2.1 |  |
| Restructuring charges | — |  |  | (0.1 | ) |  | 1.1 |  |  | — |  |  | 1.0 |  |
| Income from equity method investments | (69.7 | ) |  | (6.4 | ) |  | (2.7 | ) |  | 75.3 |  |  | (3.5 | ) |
| Operational income from continuing operations | 69.8 |  |  | 75.3 |  |  | 36.1 |  |  | (74.6 | ) |  | 106.6 |  |
| Interest expense, net | 3.6 |  |  | (0.7 | ) |  | 1.1 |  |  | — |  |  | 4.0 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 66.2 |  |  | 76.0 |  |  | 35.0 |  |  | (74.6 | ) |  | 102.6 |  |
| Provision for income taxes | (1.2 | ) |  | 24.1 |  |  | 11.9 |  |  | 0.3 |  |  | 35.1 |  |
| Income from continuing operations | 67.4 |  |  | 51.9 |  |  | 23.1 |  |  | (74.9 | ) |  | 67.5 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Net income | $ | 67.4 |  |  | $ | 51.9 |  |  | $ | 23.0 |  |  | $ | (74.9 | ) |  | $ | 67.4 |  |
| Other comprehensive income (loss), net of tax | (1.1 | ) |  | (6.7 | ) |  | (17.2 | ) |  | (1.0 | ) |  | (26.0 | ) |
| Comprehensive income | $ | 66.3 |  |  | $ | 45.2 |  |  | $ | 5.8 |  |  | $ | (75.9 | ) |  | $ | 41.4 |  |

[0001069202-14-000008:notes:38]
For the Nine Months Ended September 30, 2014

[0001069202-14-000008:notes:39]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,089.0 |  |  | $ | 606.5 |  |  | $ | (140.9 | ) |  | $ | 2,554.6 |  |
| Cost of goods sold | — |  |  | 1,555.1 |  |  | 460.9 |  |  | (139.3 | ) |  | 1,876.7 |  |
| Gross profit | — |  |  | 533.9 |  |  | 145.6 |  |  | (1.6 | ) |  | 677.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 362.9 |  |  | 62.6 |  |  | — |  |  | 425.5 |  |
| Losses (gains) and other expenses, net | (0.3 | ) |  | 2.3 |  |  | 1.5 |  |  |  |  |  | 3.5 |  |
| Restructuring charges | — |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Income from equity method investments | (167.6 | ) |  | (21.0 | ) |  | (9.8 | ) |  | 186.4 |  |  | (12.0 | ) |
| Operational income from continuing operations | 167.9 |  |  | 189.7 |  |  | 90.0 |  |  | (188.0 | ) |  | 259.6 |  |
| Interest expense, net | 10.1 |  |  | (2.2 | ) |  | 3.1 |  |  | — |  |  | 11.0 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 157.8 |  |  | 191.9 |  |  | 86.9 |  |  | (188.0 | ) |  | 248.6 |  |
| Provision for income taxes | (3.4 | ) |  | 60.0 |  |  | 30.5 |  |  | (0.5 | ) |  | 86.6 |  |
| Income from continuing operations | 161.2 |  |  | 131.9 |  |  | 56.4 |  |  | (187.5 | ) |  | 162.0 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Net income | $ | 161.2 |  |  | $ | 131.9 |  |  | $ | 55.6 |  |  | $ | (187.5 | ) |  | $ | 161.2 |  |
| Other comprehensive income (loss), net of tax | (1.1 | ) |  | (1.8 | ) |  | (11.8 | ) |  | (1.1 | ) |  | (15.8 | ) |
| Comprehensive income | $ | 160.1 |  |  | $ | 130.1 |  |  | $ | 43.8 |  |  | $ | (188.6 | ) |  | $ | 145.4 |  |

[0001069202-14-000008:notes:40]
For the Three Months Ended September 30, 2013

[0001069202-14-000008:notes:41]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 668.4 |  |  | $ | 221.7 |  |  | $ | (22.1 | ) |  | $ | 868.0 |  |
| Cost of goods sold | — |  |  | 494.5 |  |  | 161.7 |  |  | (25.6 | ) |  | 630.6 |  |
| Gross profit | — |  |  | 173.9 |  |  | 60.0 |  |  | 3.5 |  |  | 237.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 107.5 |  |  | 29.4 |  |  | — |  |  | 136.9 |  |
| Losses (gains) and other expenses, net | (1.7 | ) |  | 2.0 |  |  | (0.6 | ) |  | — |  |  | (0.3 | ) |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.2 |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (65.5 | ) |  | (14.9 | ) |  | (2.5 | ) |  | 79.6 |  |  | (3.3 | ) |
| Operational income from continuing operations | 67.2 |  |  | 79.2 |  |  | 33.5 |  |  | (76.1 | ) |  | 103.8 |  |
| Interest expense, net | 3.5 |  |  | (0.4 | ) |  | 0.7 |  |  | — |  |  | 3.8 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 63.7 |  |  | 79.6 |  |  | 32.8 |  |  | (76.1 | ) |  | 100.0 |  |
| Provision for income taxes | (0.6 | ) |  | 22.7 |  |  | 10.7 |  |  | 1.4 |  |  | 34.2 |  |
| Income from continuing operations | 64.3 |  |  | 56.9 |  |  | 22.1 |  |  | (77.5 | ) |  | 65.8 |  |
| Loss from discontinued operations | — |  |  | (1.5 | ) |  | — |  |  | — |  |  | (1.5 | ) |
| Net income | $ | 64.3 |  |  | $ | 55.4 |  |  | $ | 22.1 |  |  | $ | (77.5 | ) |  | $ | 64.3 |  |
| Other comprehensive income, net of tax | 4.5 |  |  | 0.8 |  |  | 3.5 |  |  | 0.4 |  |  | 9.2 |  |
| Comprehensive income | $ | 68.8 |  |  | $ | 56.2 |  |  | $ | 25.6 |  |  | $ | (77.1 | ) |  | $ | 73.5 |  |

[0001069202-14-000008:notes:42]
For the Nine Months Ended September 30, 2013

[0001069202-14-000008:notes:43]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,984.5 |  |  | $ | 619.3 |  |  | $ | (154.3 | ) |  | $ | 2,449.5 |  |
| Cost of goods sold | — |  |  | 1,473.9 |  |  | 474.9 |  |  | (152.7 | ) |  | 1,796.1 |  |
| Gross profit | — |  |  | 510.6 |  |  | 144.4 |  |  | (1.6 | ) |  | 653.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 327.8 |  |  | 96.2 |  |  | — |  |  | 424.0 |  |
| Losses and other expenses, net | 0.8 |  |  | 2.2 |  |  | — |  |  | (0.2 | ) |  | 2.8 |  |
| Restructuring charges | — |  |  | 1.6 |  |  | 1.6 |  |  | — |  |  | 3.2 |  |
| Income from equity method investments | (144.1 | ) |  | (6.0 | ) |  | (8.7 | ) |  | 148.1 |  |  | (10.7 | ) |
| Operational income from continuing operations | 143.3 |  |  | 185.0 |  |  | 55.3 |  |  | (149.5 | ) |  | 234.1 |  |
| Interest expense, net | 10.6 |  |  | (1.5 | ) |  | 1.7 |  |  | — |  |  | 10.8 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 132.7 |  |  | 186.5 |  |  | 53.7 |  |  | (149.5 | ) |  | 223.4 |  |
| Provision for income taxes | (3.9 | ) |  | 63.3 |  |  | 18.7 |  |  | (0.6 | ) |  | 77.5 |  |
| Income from continuing operations | 136.6 |  |  | 123.2 |  |  | 35.0 |  |  | (148.9 | ) |  | 145.9 |  |
| Loss from discontinued operations | — |  |  | 16.2 |  |  | (25.5 | ) |  | — |  |  | (9.3 | ) |
| Net income | $ | 136.6 |  |  | $ | 139.4 |  |  | $ | 9.5 |  |  | $ | (148.9 | ) |  | $ | 136.6 |  |
| Other comprehensive income (loss), net of tax | (3.1 | ) |  | 1.9 |  |  | (3.8 | ) |  | (66.6 | ) |  | (71.6 | ) |
| Comprehensive income | $ | 133.5 |  |  | $ | 141.3 |  |  | $ | 5.7 |  |  | $ | (215.5 | ) |  | $ | 65.0 |  |

[0001069202-14-000008:notes:44]
[same as prior period, unchanged from 0001069202-14-000006:notes:47]

[0001069202-14-000008:notes:45]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 13.4 |  |  | $ | 72.1 |  |  | $ | (62.0 | ) |  | $ | — |  |  | $ | 23.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (45.5 | ) |  | (14.4 | ) |  | — |  |  | (59.9 | ) |
| Net proceeds from sale of business | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in investing activities | — |  |  | (45.3 | ) |  | (14.4 | ) |  | — |  |  | (59.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 60.0 |  |  | — |  |  | 60.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | — |  |  | (1.4 | ) |  | (0.3 | ) |  | — |  |  | (1.7 | ) |
| Borrowings from revolving credit facility | 1,483.0 |  |  | — |  |  | — |  |  | — |  |  | 1,483.0 |  |
| Payments on revolving credit facility | (1,351.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,351.0 | ) |
| Proceeds from employee stock purchases | 1.5 |  |  | — |  |  | — |  |  | — |  |  | 1.5 |  |
| Repurchases of common stock | (100.3 | ) |  | — |  |  | — |  |  | — |  |  | (100.3 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (12.3 | ) |  | — |  |  | — |  |  | — |  |  | (12.3 | ) |
| Excess tax benefits related to share-based payments | 5.3 |  |  | — |  |  | — |  |  | — |  |  | 5.3 |  |
| Intercompany debt | (12.5 | ) |  | (0.8 | ) |  | 13.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | 11.5 |  |  | (17.0 | ) |  | 5.5 |  |  | — |  |  | — |  |
| Intercompany investments | — |  |  | (3.0 | ) |  | 3.0 |  |  | — |  |  | — |  |
| Cash dividends paid | (38.2 | ) |  | — |  |  | — |  |  | — |  |  | (38.2 | ) |
| Net cash provided by financing activities | (13.0 | ) |  | (22.2 | ) |  | 84.9 |  |  | — |  |  | 49.7 |  |
| Increase in cash and cash equivalents | 0.4 |  |  | 4.6 |  |  | 8.5 |  |  | — |  |  | 13.5 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (3.4 | ) |  | — |  |  | (3.4 | ) |
| Cash and cash equivalents, beginning of period | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of period | $ | 1.5 |  |  | $ | 15.1 |  |  | $ | 31.5 |  |  | $ | — |  |  | $ | 48.1 |  |

[0001069202-14-000008:notes:46]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | (41.6 | ) |  | $ | 267.0 |  |  | $ | (160.4 | ) |  | $ | — |  |  | $ | 65.0 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (30.3 | ) |  | (10.7 | ) |  | — |  |  | (41.0 | ) |
| Net proceeds from sale of business | 4.8 |  |  | — |  |  | 3.3 |  |  | — |  |  | 8.1 |  |
| Net cash used in discontinued operations | — |  |  | (0.1 | ) |  | — |  |  | — |  |  | (0.1 | ) |
| Net cash used in investing activities | 4.8 |  |  | (30.3 | ) |  | (7.4 | ) |  | — |  |  | (32.9 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 330.0 |  |  | — |  |  | 330.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (200.0 | ) |  | — |  |  | (200.0 | ) |
| Long-term debt payments | — |  |  | (0.5 | ) |  | (0.2 | ) |  | — |  |  | (0.7 | ) |
| Borrowings from revolving credit facility | 998.0 |  |  | — |  |  | — |  |  | — |  |  | 998.0 |  |
| Payments on revolving credit facility | (1,083.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,083.5 | ) |
| Proceeds from employee stock purchases | 1.3 |  |  | — |  |  | — |  |  | — |  |  | 1.3 |  |
| Repurchases of common stock | (66.0 | ) |  | — |  |  | — |  |  | — |  |  | (66.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (7.7 | ) |  | — |  |  | — |  |  | — |  |  | (7.7 | ) |
| Excess tax benefits related to share-based payments | 4.7 |  |  | — |  |  | — |  |  | — |  |  | 4.7 |  |
| Intercompany debt | (44.4 | ) |  | 8.4 |  |  | 36.0 |  |  | — |  |  | — |  |
| Intercompany financing activity | 257.0 |  |  | (242.7 | ) |  | (14.3 | ) |  | — |  |  | — |  |
| Cash dividends paid | (22.1 | ) |  | — |  |  | — |  |  | — |  |  | (22.1 | ) |
| Net cash used in financing activities | 37.3 |  |  | (234.8 | ) |  | 155.3 |  |  | — |  |  | (42.2 | ) |
| Decrease in cash and cash equivalents | 0.5 |  |  | 1.9 |  |  | (12.5 | ) |  | — |  |  | (10.1 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (3.9 | ) |  | — |  |  | (3.9 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of period | $ | 1.5 |  |  | $ | 15.3 |  |  | $ | 21.0 |  |  | $ | — |  |  | $ | 37.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-14-000008:notes:47]
Lines of Credit and Financing Arrangements:

[0001069202-14-000008:notes:48]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000008:notes:49]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 9.0 |  |  | 5.9 |  |
| Total short-term debt | $ | 229.0 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 149.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 365.7 |  |  | $ | 233.2 |  |
| Total debt | $ | 596.0 |  |  | $ | 400.4 |  |

[0001069202-14-000008:notes:50]
Short-Term Debt

[0001069202-14-000008:notes:51]
Foreign Obligations

[0001069202-14-000008:notes:52]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $9.0 million and $5.9 million of foreign obligations as of September 30, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.

[0001069202-14-000008:notes:53]
Asset Securitization Program

[0001069202-14-000008:notes:54]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-14-000008:notes:55]
The ASP provides for a maximum securitization amount ranging from $160.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-14-000008:notes:56]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 220.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

[0001069202-14-000008:notes:57]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for September 30, 2014 and December 31, 2013 was 0.77% and 0.78% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-14-000008:notes:58]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2014, we were in compliance with all covenant requirements.

[0001069202-14-000008:notes:59]
Long-Term Debt

[0001069202-14-000008:notes:60]
Domestic Revolving Credit Facility

[0001069202-14-000008:notes:61]
Under our $650.0 million Domestic Revolving Credit Facility, we had outstanding borrowings of $149.0 million as well as $27.2 million committed to standby letters of credit as of September 30, 2014. Subject to covenant limitations, $473.8 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-14-000008:notes:62]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-14-000008:notes:63]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.38 | % |  | 1.17 | % |

[0001069202-14-000008:notes:64]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-14-000008:notes:65]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-14-000008:notes:66]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Revolving Credit Facility could occur if:

[0001069202-14-000008:notes:67]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-14-000008:notes:68]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-14-000008:notes:69]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2014, we were in compliance with all covenant requirements.

[0001069202-14-000008:notes:70]
Senior Unsecured Notes

[0001069202-14-000008:notes:71]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2014, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-14-000008:notes:72]
[same as prior period, unchanged from 0001069202-14-000006:notes:75]

[0001069202-14-000008:notes:73]
[same as prior period, unchanged from 0001069202-14-000006:notes:76]

[0001069202-14-000008:notes:74]
[same as prior period, unchanged from 0001069202-14-000006:notes:77]

[0001069202-14-000008:notes:75]
[same as prior period, unchanged from 0001069202-14-000006:notes:78]

[0001069202-14-000008:notes:76]
[same as prior period, unchanged from 0001069202-14-000006:notes:79]

[0001069202-14-000008:notes:77]
[same as prior period, unchanged from 0001069202-14-000006:notes:80]

[0001069202-14-000008:notes:78]
We have commodity futures contracts designated as cash flow hedges that are scheduled to mature through March 2016.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-14-000008:notes:79]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Unrealized losses on unsettled futures contracts | $ | 2.7 |  |  | $ | 0.8 |  |
| Income tax benefit | (1.0 | ) |  | (0.2 | ) |
| Losses included in AOCL, net of tax (1) | $ | 1.7 |  |  | $ | 0.6 |  |

[0001069202-14-000008:notes:80]
(1) Assuming commodity prices remain constant, we expect to reclassify $2.5 million of derivative losses into earnings within the next 12 months.

[0001069202-14-000008:notes:81]
[same as prior period, unchanged from 0001069202-14-000006:notes:84]

[0001069202-14-000008:notes:82]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Copper | 25.3 |  |  | 22.9 |  |

[0001069202-14-000008:notes:83]
[same as prior period, unchanged from 0001069202-14-000006:notes:86]

[0001069202-14-000008:notes:84]
[same as prior period, unchanged from 0001069202-14-000006:notes:87]

[0001069202-14-000008:notes:85]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Copper | 2.4 |  |  | 2.0 |  |
| Aluminum | 2.7 |  |  | 2.7 |  |

[0001069202-14-000008:notes:86]
[same as prior period, unchanged from 0001069202-14-000006:notes:89]

[0001069202-14-000008:notes:87]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Notional Amounts (in local currency): |  |  |  |
| Brazilian Real | 2.3 |  |  | 1.2 |  |
| Mexican Peso | 102.9 |  |  | 130.0 |  |
| United States Dollar | 1.9 |  |  | — |  |
| British Pound | 1.4 |  |  | 3.4 |  |
| Indian Rupee | — |  |  | 28.0 |  |
| Polish Zloty | 21.6 |  |  | 32.6 |  |
| Russian Ruble | 24.3 |  |  | — |  |

[0001069202-14-000008:notes:88]
[same as prior period, unchanged from 0001069202-14-000006:notes:91]

[0001069202-14-000008:notes:89]
[same as prior period, unchanged from 0001069202-14-000006:notes:92]

[0001069202-14-000008:notes:90]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of September 30, 2014 |  | As of December 31, 2013 |  | As of September 30, 2014 |  | As of December 31, 2013 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.2 |  |  | 0.1 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Total Assets | $ | — |  |  | $ | 0.4 |  |  | $ | 0.2 |  |  | $ | 0.1 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 2.5 |  |  | $ | 1.2 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.2 |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 2.7 |  |  | $ | 1.2 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |

[0001069202-14-000008:notes:91]
[same as prior period, unchanged from 0001069202-14-000006:notes:94]

[0001069202-14-000008:notes:92]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Amount of Loss reclassified from AOCL into Income (Effective Portion) (1) |  | $ | 1.0 |  |  | $ | 2.1 |  |  | $ | 4.9 |  |  | $ | 3.3 |  |
| Amount of Loss (Gain) recognized in Net income (Ineffective Portion) (2) |  | $ | — |  |  | $ | (0.1 | ) |  | $ | 0.1 |  |  | $ | 0.2 |  |

[0001069202-14-000008:notes:93]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | 0.3 |  |  | $ | (0.6 | ) |  | $ | 0.6 |  |  | $ | 1.2 |  |
| Foreign currency forward contracts (2) |  | (0.2 | ) |  | (0.6 | ) |  | (0.1 | ) |  | 0.2 |  |
|  |  | $ | 0.1 |  |  | $ | (1.2 | ) |  | $ | 0.5 |  |  | $ | 1.4 |  |

[0001069202-14-000008:notes:94]
[same as prior period, unchanged from 0001069202-14-000006:notes:97]

[0001069202-14-000008:notes:95]
[same as prior period, unchanged from 0001069202-14-000006:notes:98]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-14-000008:notes:96]
[same as prior period, unchanged from 0001069202-14-000006:notes:99]

[0001069202-14-000008:notes:97]
[same as prior period, unchanged from 0001069202-14-000006:notes:100]

[0001069202-14-000008:notes:98]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Stock-based compensation expense (1) | $ | 6.6 |  |  | $ | 5.3 |  |  | $ | 17.3 |  |  | $ | 20.5 |  |

[0001069202-14-000008:notes:99]
[same as prior period, unchanged from 0001069202-14-000006:notes:102]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-14-000008:notes:100]
[same as prior period, unchanged from 0001069202-14-000006:notes:103]

[0001069202-14-000008:notes:101]
[same as prior period, unchanged from 0001069202-14-000006:notes:104]

[0001069202-14-000008:notes:102]
There were no assets and liabilities related to the Service Experts or Hearth businesses included in the accompanying Consolidated Balance Sheets as of September 30, 2014 or December 31, 2013, except for insurance casualty loss reserves which we retained after the respective transactions.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in discontinued operations in the accompanying Consolidated Statements of Operations.  The following table provides a summary of net trade sales, pre-tax operating income (loss) and other supplemental information related to discontinued operations (in millions):

[0001069202-14-000008:notes:103]
|  | Service Experts |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 73.5 |  |
| Pre-tax operating income (loss) (1) | — |  |  | (2.3 | ) |  | 1.1 |  |  | (17.8 | ) |
| Gain (loss) on sale of business | — |  |  | — |  |  | — |  |  | 1.7 |  |

[0001069202-14-000008:notes:104]
[same as prior period, unchanged from 0001069202-14-000006:notes:107]

[0001069202-14-000008:notes:105]
|  | Hearth |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | (0.2 | ) |  | — |  |  | (2.4 | ) |  | 0.5 |  |
| Gain (loss) on sale of business | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-14-000008:notes:106]
[same as prior period, unchanged from 0001069202-14-000006:notes:109]

[0001069202-14-000008:notes:107]
[same as prior period, unchanged from 0001069202-14-000006:notes:110]

[0001069202-14-000008:notes:108]
[same as prior period, unchanged from 0001069202-14-000006:notes:111]

[0001069202-14-000008:notes:109]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net income | $ | 67.4 |  |  | $ | 64.3 |  |  | $ | 161.2 |  |  | $ | 136.6 |  |
| Add: Loss from discontinued operations | 0.1 |  |  | 1.5 |  |  | 0.8 |  |  | 9.3 |  |
| Income from continuing operations | $ | 67.5 |  |  | $ | 65.8 |  |  | $ | 162.0 |  |  | $ | 145.9 |  |
| Weighted-average shares outstanding – basic | 48.3 |  |  | 49.7 |  |  | 48.7 |  |  | 50.0 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.7 |  |  | 0.8 |  |  | 0.8 |  |  | 0.8 |  |
| Weighted-average shares outstanding – diluted | 49.0 |  |  | 50.5 |  |  | 49.5 |  |  | 50.8 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.40 |  |  | $ | 1.32 |  |  | $ | 3.33 |  |  | $ | 2.92 |  |
| Loss from discontinued operations | — |  |  | (0.03 | ) |  | (0.02 | ) |  | (0.19 | ) |
| Net income | $ | 1.40 |  |  | $ | 1.29 |  |  | $ | 3.31 |  |  | $ | 2.73 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.38 |  |  | $ | 1.30 |  |  | $ | 3.27 |  |  | $ | 2.87 |  |
| Loss from discontinued operations | — |  |  | (0.03 | ) |  | (0.01 | ) |  | (0.18 | ) |
| Net income | $ | 1.38 |  |  | $ | 1.27 |  |  | $ | 3.26 |  |  | $ | 2.69 |  |

[0001069202-14-000008:notes:110]
[same as prior period, unchanged from 0001069202-14-000006:notes:113]

[0001069202-14-000008:notes:111]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Weighted-average number of shares | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |
| Price range per share |  | $81.11 - $81.14 |  |  | $ | — |  |  |  | $81.11 - $81.14 |  |  | $ | — |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-14-000008:notes:112]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Senior unsecured notes | $ | 213.9 |  |  | $ | 214.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-14-000008:notes:113]
[same as prior period, unchanged from 0001069202-14-000006:notes:116]

[0001069202-14-000008:notes:114]
[same as prior period, unchanged from 0001069202-14-000006:notes:117]

[0001069202-14-000008:notes:115]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2014 were the same as those used at December 31, 2013.

[0001069202-14-000008:notes:116]
[same as prior period, unchanged from 0001069202-14-000006:notes:119]

[0001069202-14-000008:notes:117]
[same as prior period, unchanged from 0001069202-14-000006:notes:120]

[0001069202-14-000008:notes:118]
[same as prior period, unchanged from 0001069202-14-000006:notes:121]

[0001069202-14-000008:notes:119]
[same as prior period, unchanged from 0001069202-14-000006:notes:122]

[0001069202-14-000008:notes:120]
[same as prior period, unchanged from 0001069202-14-000006:notes:123]

[0001069202-14-000008:notes:121]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Investment in marketable equity securities | $ | 6.7 |  |  | $ | 4.4 |  |

[0001069202-14-000008:notes:122]
[same as prior period, unchanged from 0001069202-14-000006:notes:125]

[0001069202-14-000008:notes:123]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Revolving Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-14-000008:notes:124]
[same as prior period, unchanged from 0001069202-14-000006:notes:127]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-14-000008:notes:125]
[same as prior period, unchanged from 0001069202-14-000006:notes:128]

[0001069202-14-000008:notes:126]
The changes in the carrying amount of goodwill for the first nine months of 2014, in total and by segment, are summarized in the table below (in millions):

[0001069202-14-000008:notes:127]
|  | Balance at December 31, 2013 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at September 30, 2014 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 64.6 |  |  | — |  |  | (1.4 | ) |  | 63.2 |  |
| Refrigeration | 126.1 |  |  | — |  |  | (1.3 | ) |  | 124.8 |  |
| Total Goodwill | $ | 216.8 |  |  | $ | — |  |  | $ | (2.7 | ) |  | $ | 214.1 |  |

[0001069202-14-000008:notes:128]
[same as prior period, unchanged from 0001069202-14-000006:notes:131]

[0001069202-14-000008:notes:129]
We performed our annual goodwill impairment test in the first quarter of 2014, and based on a qualitative assessment of impairment indicators for each of our reporting units, did not record any goodwill impairments.  We continue to monitor our reporting units for indicators of impairment throughout the year.  Refer to Note 1 for information about the change in our method of accounting for evaluating goodwill for impairment.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-14-000008:notes:130]
[same as prior period, unchanged from 0001069202-14-000006:notes:133]

[0001069202-14-000008:notes:131]
As of September 30, 2014, we had approximately $1.5 million in total gross unrecognized tax benefits. Of this amount, $1.2 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of September 30, 2014, we had approximately $0.4 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-14-000008:notes:132]
[same as prior period, unchanged from 0001069202-14-000006:notes:135]

[0001069202-14-000008:notes:133]
Since January 1, 2014, numerous states, including Indiana, New York and Rhode Island and the District of Columbia, have enacted legislation effective for tax years beginning on or after January 1, 2014, including changes to rates, apportionment methodologies and unitary reporting requirements.  The impact of these changes is immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-14-000008:notes:134]
[same as prior period, unchanged from 0001069202-14-000006:notes:137]

[0001069202-14-000008:notes:135]
[same as prior period, unchanged from 0001069202-14-000006:notes:138]

[0001069202-14-000008:notes:136]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Finished goods | $ | 357.4 |  |  | $ | 251.4 |  |
| Work in process | 14.4 |  |  | 11.8 |  |
| Raw materials and parts | 199.2 |  |  | 188.9 |  |
| Subtotal | 571.0 |  |  | 452.1 |  |
| Excess of current cost over last-in, first-out cost | (69.5 | ) |  | (73.3 | ) |
| Total inventories, net | $ | 501.5 |  |  | $ | 378.8 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001069202-14-000008:notes:137]
Change in method of accounting for evaluating goodwill for impairment

[0001069202-14-000008:notes:138]
The annual goodwill impairment test was performed during the first quarter of 2014, and no impairment was recognized.  During the third quarter of 2014, we changed the date of our annual goodwill impairment test from March 31st to December 31st. The change was made to more closely align the impairment testing date with the year-end results and may result in impairment charges identified in the fourth quarter.

[0001069202-14-000008:notes:139]
The change in goodwill impairment testing date is deemed a change in accounting principle. Management believes that the change in accounting principle will not delay, accelerate, or avoid a goodwill impairment charge. Management determined that the change in accounting principle is preferable under the circumstances and does not result in adjustments to our financial statements when applied retrospectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-14-000008:notes:140]
[same as prior period, unchanged from 0001069202-14-000006:notes:140]

[0001069202-14-000008:notes:141]
[same as prior period, unchanged from 0001069202-14-000006:notes:141]

[0001069202-14-000008:notes:142]
[same as prior period, unchanged from 0001069202-14-000006:notes:142]

[0001069202-14-000008:notes:143]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-14-000008:notes:144]
[same as prior period, unchanged from 0001069202-14-000006:notes:144]

[0001069202-14-000008:notes:145]
[same as prior period, unchanged from 0001069202-14-000006:notes:145]

[0001069202-14-000008:notes:146]
[same as prior period, unchanged from 0001069202-14-000006:notes:146]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-14-000008:notes:147]
[same as prior period, unchanged from 0001069202-14-000006:notes:147]

[0001069202-14-000008:notes:148]
[same as prior period, unchanged from 0001069202-14-000006:notes:148]

[0001069202-14-000008:notes:149]
|  | For the Three Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.1 |  |  | $ | 1.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.4 |  |  | 4.0 |  |  | 0.1 |  |  | — |  |
| Expected return on plan assets | (5.7 | ) |  | (5.1 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.8 | ) |  | (0.7 | ) |
| Recognized actuarial loss | 1.6 |  |  | 2.3 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.5 |  |  | $ | 2.7 |  |  | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0001069202-14-000008:notes:150]
|  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 3.2 |  |  | $ | 3.9 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 13.3 |  |  | 12.3 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on plan assets | (17.0 | ) |  | (15.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.2 |  |  | 0.3 |  |  | (2.2 | ) |  | (2.2 | ) |
| Recognized actuarial loss | 4.9 |  |  | 6.9 |  |  | 1.1 |  |  | 1.1 |  |
| Settlements and curtailments | — |  |  | 1.3 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 4.6 |  |  | $ | 9.0 |  |  | $ | (1.0 | ) |  | $ | (1.0 | ) |

[0001069202-14-000008:notes:151]
(1) All net periodic benefit cost for the three and nine months ended September 30, 2014 and 2013 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-14-000008:notes:152]
[same as prior period, unchanged from 0001069202-14-000006:notes:152]

[0001069202-14-000008:notes:153]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 462.6 |  |  | $ | 433.9 |  |  | $ | 1,332.5 |  |  | $ | 1,224.5 |  |
| Commercial Heating & Cooling | 241.6 |  |  | 239.1 |  |  | 655.6 |  |  | 631.8 |  |
| Refrigeration | 194.2 |  |  | 195.0 |  |  | 566.5 |  |  | 593.2 |  |
|  | $ | 898.4 |  |  | $ | 868.0 |  |  | $ | 2,554.6 |  |  | $ | 2,449.5 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 69.4 |  |  | $ | 57.0 |  |  | $ | 178.8 |  |  | $ | 143.7 |  |
| Commercial Heating & Cooling | 42.2 |  |  | 39.2 |  |  | 91.3 |  |  | 84.8 |  |
| Refrigeration | 16.5 |  |  | 23.9 |  |  | 42.3 |  |  | 66.5 |  |
| Corporate and other | (17.5 | ) |  | (16.6 | ) |  | (47.8 | ) |  | (56.2 | ) |
| Subtotal that includes segment profit and eliminations | 110.6 |  |  | 103.5 |  |  | 264.6 |  |  | 238.8 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Special product quality adjustments | 0.2 |  |  | (0.4 | ) |  | (0.1 | ) |  | (0.5 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 1.8 |  |  | (0.2 | ) |  | 2.8 |  |  | 2.0 |  |
| Restructuring charges | 1.0 |  |  | 0.3 |  |  | 1.3 |  |  | 3.2 |  |
| Interest expense, net | 4.0 |  |  | 3.8 |  |  | 11.0 |  |  | 10.8 |  |
| Special inventory write down | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |
| Other expense (income), net | — |  |  | — |  |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | $ | 102.6 |  |  | $ | 100.0 |  |  | $ | 248.6 |  |  | $ | 223.4 |  |

[0001069202-14-000008:notes:154]
[same as prior period, unchanged from 0001069202-14-000006:notes:154]

[0001069202-14-000008:notes:155]
[same as prior period, unchanged from 0001069202-14-000006:notes:155]

[0001069202-14-000008:notes:156]
[same as prior period, unchanged from 0001069202-14-000006:notes:156]

[0001069202-14-000008:notes:157]
[same as prior period, unchanged from 0001069202-14-000006:notes:157]

[0001069202-14-000008:notes:158]
| ◦ | Special legal contingency charges, |

[0001069202-14-000008:notes:159]
| ◦ | Asbestos-related litigation, |

[0001069202-14-000008:notes:160]
| ◦ | Environmental liabilities, and |

[0001069202-14-000008:notes:161]
[same as prior period, unchanged from 0001069202-14-000006:notes:160]

[0001069202-14-000008:notes:162]
[same as prior period, unchanged from 0001069202-14-000006:notes:161]

[0001069202-14-000008:notes:163]
[same as prior period, unchanged from 0001069202-14-000006:notes:162]

[0001069202-14-000008:notes:164]
| • | Interest expense, net; |

[0001069202-14-000008:notes:165]
| • | Special inventory write down; and |

[0001069202-14-000008:notes:166]
[same as prior period, unchanged from 0001069202-14-000006:notes:164]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-14-000008:notes:167]
[same as prior period, unchanged from 0001069202-14-000006:notes:165]

[0001069202-14-000008:notes:168]
[same as prior period, unchanged from 0001069202-14-000006:notes:166]

[0001069202-14-000008:notes:169]
[same as prior period, unchanged from 0001069202-14-000006:notes:167]

[0001069202-14-000008:notes:170]
[same as prior period, unchanged from 0001069202-14-000006:notes:168]

[0001069202-14-000008:notes:171]
|  | Charges Incurred in 2014 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 1.0 |  |  | $ | 6.6 |  |  | $ | 6.6 |  |
| Asset write-offs and accelerated depreciation | 0.2 |  |  | 1.7 |  |  | 1.7 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |
| Other | 0.1 |  |  | 1.7 |  |  | 1.8 |  |
| Total restructuring charges | $ | 1.3 |  |  | $ | 10.0 |  |  | $ | 10.1 |  |

[0001069202-14-000008:notes:172]
[same as prior period, unchanged from 0001069202-14-000006:notes:170]

[0001069202-14-000008:notes:173]
|  | Charges Incurred in 2014 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 1.3 |  |  | $ | 1.4 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | 1.4 |  |  | 7.8 |  |  | 7.8 |  |
| Corporate & Other | (0.1 | ) |  | — |  |  | — |  |
| Total restructuring charges | $ | 1.3 |  |  | $ | 10.0 |  |  | $ | 10.1 |  |

[0001069202-14-000008:notes:174]
[same as prior period, unchanged from 0001069202-14-000006:notes:172]

[0001069202-14-000008:notes:175]
|  | Balance as ofDecember 31, 2013 |  | Charged to Earnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of September 30, 2014 |
| Severance and related expense | $ | 1.6 |  |  | $ | 1.0 |  |  | $ | (1.3 | ) |  | $ | — |  |  | $ | 1.3 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.2 |  |  | — |  |  | (0.2 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Total restructuring accruals | $ | 1.6 |  |  | $ | 1.3 |  |  | $ | (1.4 | ) |  | $ | (0.2 | ) |  | $ | 1.3 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-14-000008:notes:176]
[same as prior period, unchanged from 0001069202-14-000006:notes:174]

[0001069202-14-000008:notes:177]
[same as prior period, unchanged from 0001069202-14-000006:notes:175]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-14-000008:notes:178]
[same as prior period, unchanged from 0001069202-14-000006:notes:176]

[0001069202-14-000008:notes:179]
[same as prior period, unchanged from 0001069202-14-000006:notes:177]

[0001069202-14-000008:notes:180]
[same as prior period, unchanged from 0001069202-14-000006:notes:178]

[0001069202-14-000008:notes:181]
[same as prior period, unchanged from 0001069202-14-000006:notes:179]

[0001069202-14-000008:notes:182]
[same as prior period, unchanged from 0001069202-14-000006:notes:180]

[0001069202-14-000008:notes:183]
[same as prior period, unchanged from 0001069202-14-000006:notes:181]

[0001069202-14-000008:notes:184]
[same as prior period, unchanged from 0001069202-14-000006:notes:182]

[0001069202-14-000008:notes:185]
[same as prior period, unchanged from 0001069202-14-000006:notes:183]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-14-000008:notes:186]
[same as prior period, unchanged from 0001069202-14-000006:notes:184]

[0001069202-14-000008:notes:187]
Our Board of Directors has authorized a total of $700.0 million towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first nine months of 2014.  For the nine months ended September 30, 2014, we repurchased 1.1 million shares for $100.3 million under the Share Repurchase Plans.  As of September 30, 2014, $145.9 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-14-000008:notes:188]
We also repurchased 0.1 million shares for $12.3 million for the nine months ended September 30, 2014 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.


## us-gaap:SubsequentEventsTextBlock

[0001069202-14-000008:notes:189]
17. Subsequent Events:

[0001069202-14-000008:notes:190]
On October 17, 2014, our Board of Directors authorized an additional $700.0 million towards our Share Repurchase Plans.  This is in addition to the amounts set forth in Note 10 and results in a total of $845.9 million that may be used, subject to certain conditions, under the Share Repurchase Plans.  On October 20, 2014, we announced our plans for a new $450.0 million accelerated share repurchase program in October, 2014.

[0001069202-14-000008:notes:191]
On October 20, 2014, the Company entered into a short term loan agreement (the “Short-Term Facility”) with JPMorgan Chase Bank, N.A. and Morgan Stanley Bank, N.A. to borrow, subject to the satisfaction of specified conditions, up to $250.0 million.  The Short-Term Facility is guaranteed by the same subsidiaries as our Domestic Revolving Credit Facility, and contains substantially similar financial and other covenants as described in Note 7.  The Short-Term Facility will become due on March 31, 2015, and allows for pre-payment. The Company intends to use the borrowings under the Short-Term Facility, along with borrowings under the Domestic Revolving Credit Facility, to fund the expected $450.0 million accelerated share repurchase program.
