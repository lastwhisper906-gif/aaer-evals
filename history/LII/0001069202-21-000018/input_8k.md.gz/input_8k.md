# LII 8-K — 0001069202-21-000016 filed 2021-04-26

## item codes, every 8-K on or before 2021-04-26

- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2021-04-26

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-21-000016:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetables20.htm
EX-99.1

[0001069202-21-000016:8k_2_02:2]
Document

[0001069202-21-000016:8k_2_02:3]
Exhibit-99.1

[0001069202-21-000016:8k_2_02:4]
Lennox International Reports Record First Quarter Revenue and Profit and Raises 2021 Guidance

[0001069202-21-000016:8k_2_02:5]
•    Revenue up 29% to first-quarter record $931 million, led by 37% Residential growth

[0001069202-21-000016:8k_2_02:6]
•    GAAP EPS from continuing operations up 588% to first-quarter record $2.20

[0001069202-21-000016:8k_2_02:7]
•    Adjusted EPS from continuing operations up 305% to first-quarter record $2.27

[0001069202-21-000016:8k_2_02:8]
•    Repurchased $200 million of stock and $200 million more planned for 2021

[0001069202-21-000016:8k_2_02:9]
•    Raising 2021 guidance for revenue growth from 4-8% to 7-11%

[0001069202-21-000016:8k_2_02:10]
•    Raising 2021 guidance for GAAP EPS from continuing operations from $10.55-$11.15 to $11.33-$11.93

[0001069202-21-000016:8k_2_02:11]
•    Raising 2021 guidance for adjusted EPS from continuing operations from $10.55-$11.15 to $11.40-$12.00

[0001069202-21-000016:8k_2_02:12]
DALLAS, April 26, 2021 – Lennox International Inc. (NYSE: LII), a global leader in energy-efficient climate-control solutions, today reported financial results for the first quarter of 2021. All comparisons are to the prior-year period.

[0001069202-21-000016:8k_2_02:13]
Lennox International reported record first-quarter revenue of $931 million, up 29%. Foreign exchange had a positive 1% impact to revenue growth. GAAP operating income was a first-quarter record $114 million, up 213%. GAAP earnings per share from continuing operations was a first-quarter record $2.20, up 588%.

[0001069202-21-000016:8k_2_02:14]
Total segment profit was a first-quarter record $116 million, up 208%. Total segment margin expanded 720 basis points to 12.4%. Adjusted earnings per share from continuing operations was a first-quarter record $2.27, up 305%.

[0001069202-21-000016:8k_2_02:15]
“Lennox International posted record first-quarter revenue, profit and earnings per share in the quarter with double-digit revenue growth and margin expansion in all three of our businesses,” said Chairman and CEO Todd Bluedorn. “Our Residential business set new first-quarter highs for revenue and profit. Revenue was up 37% on strong growth in both replacement and new construction business. Profit rose 197%. Segment margin expanded 850 basis points to 15.9%.

[0001069202-21-000016:8k_2_02:16]
“In Commercial, our business set new first-quarter highs for segment revenue, profit and margin. Segment revenue was up 12% led by high-teens growth in replacement business and high-single digit growth in new construction. Commercial profit rose 47%, and segment margin expanded 330 basis points to 13.8%. In Refrigeration, revenue was up 21%. North America revenue was up more than 25%, and Europe revenue was up low-double digits. Segment margin expanded 560 basis points to 6.3%, and profit rose to $8 million for the quarter.

[0001069202-21-000016:8k_2_02:17]
“Demand remained strong across all our businesses entering the second quarter, and we are capitalizing on market growth and share gain opportunities with strong operational execution. Looking ahead for 2021 overall, we are raising guidance for revenue and earnings, as well as for free cash flow – now approximately $375 million for the full year. We have repurchased $200 million of stock this year and plan to buy $200 million more in 2021.”

[0001069202-21-000016:8k_2_02:18]
FINANCIAL HIGHLIGHTS

[0001069202-21-000016:8k_2_02:19]
Revenue: Revenue was a first-quarter record $931 million, up 29% with volume, price, mix and foreign exchange favorable to revenue.

[0001069202-21-000016:8k_2_02:20]
Gross Profit: Gross profit was $257 million, up 55%, and gross margin was 27.6%, up 470 basis points. Gross profit was positively impacted by higher volume, favorable price, mix and foreign exchange, factory productivity, distribution and freight savings, and sourcing and engineering-led cost reductions. Partial offsets included higher commodity, warranty, and other product costs.

[0001069202-21-000016:8k_2_02:21]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the first quarter was $84.2 million, or $2.20 per share, compared to $12.5 million, or $0.32 per share, in the prior-year quarter.

[0001069202-21-000016:8k_2_02:22]
Adjusted income from continuing operations in the first quarter was $86.9 million, or $2.27 per share, compared to $21.7 million, or $0.56 per share, in the prior-year quarter. Adjusted income from continuing operations for the first quarter of 2021 excludes net after-tax charges of $2.7 million, consisting of: a $2.0 million charge for other tax items, net; a $1.9 million net charge in total for various other items; and a benefit of $1.2 million for excess tax benefits from share-based compensation.

[0001069202-21-000016:8k_2_02:23]
Cash from Operations, Free Cash Flow and Total Debt: Net cash used in operations in the first quarter was $18 million compared to $99 million in the prior-year quarter. Capital expenditures were approximately $24 million in the first quarter and in the prior-year quarter. Free cash flow was ($42) million compared to ($123) million in the first quarter a year ago. Total debt

[0001069202-21-000016:8k_2_02:24]
at the end of the first quarter was $1.17 billion. Total cash, cash equivalents and short-term investments were $40 million at the end of the quarter. The company paid approximately $30 million in dividends in the first quarter and repurchased $200 million of stock.

[0001069202-21-000016:8k_2_02:25]
BUSINESS SEGMENT HIGHLIGHTS

[0001069202-21-000016:8k_2_02:26]
Residential Heating & Cooling

[0001069202-21-000016:8k_2_02:27]
Revenue in the Residential Heating & Cooling business segment was up 37% to a first-quarter record $606 million. Foreign exchange was neutral to revenue. Segment profit rose 197% to a first-quarter record $96 million. Segment margin expanded 850 basis points to 15.9%. Residential results were primarily impacted by higher volume, favorable price and mix, higher factory productivity, sourcing and engineering-led cost reductions, distribution and freight savings, and favorable foreign exchange. Partial offsets included higher commodity, warranty and other product costs, and higher SG&A.

[0001069202-21-000016:8k_2_02:28]
Commercial Heating & Cooling

[0001069202-21-000016:8k_2_02:29]
Revenue in the Commercial Heating & Cooling business segment was up 12% to a first-quarter record $199 million. Foreign exchange had a 1% positive impact to revenue growth. Segment profit rose 47% to a first-quarter record $27 million. Segment margin expanded 330 basis points to a first-quarter record 13.8%. Commercial results were primarily impacted by higher volume, lower material costs, and lower SG&A. Partial offsets included unfavorable mix.

[0001069202-21-000016:8k_2_02:30]
Refrigeration

[0001069202-21-000016:8k_2_02:31]
Revenue in the Refrigeration business segment was up 21% to $125 million. Foreign exchange had a 4% positive impact to revenue growth. Segment profit rose to $8 million from $1 million in the prior-year quarter. Segment margin expanded 560 basis points to 6.3%. Refrigeration results were primarily impacted by higher volume, favorable price and mix, lower material costs, and higher factory productivity. Higher SG&A was a partial offset.

[0001069202-21-000016:8k_2_02:32]
FULL-YEAR GUIDANCE

[0001069202-21-000016:8k_2_02:33]
The company is raising 2021 guidance for revenue, EPS from continuing operations, and free cash flow.

[0001069202-21-000016:8k_2_02:34]
•    Raising guidance for revenue growth from 4-8% to 7-11%; neutral foreign exchange.

[0001069202-21-000016:8k_2_02:35]
•    Raising guidance for GAAP EPS from continuing operations from $10.55-$11.15 to $11.33-$11.93.

[0001069202-21-000016:8k_2_02:36]
•    Raising guidance for adjusted EPS from continuing operations from $10.55-$11.15 to $11.40-$12.00.

[0001069202-21-000016:8k_2_02:37]
•    Corporate expense is now expected to be approximately $95 million compared to prior guidance of $90 million.

[0001069202-21-000016:8k_2_02:38]
•    The effective tax rate is still expected to be approximately 21% on an adjusted basis for the full year.

[0001069202-21-000016:8k_2_02:39]
•    Capital expenditures are still planned to be approximately $135 million.

[0001069202-21-000016:8k_2_02:40]
•    Raising guidance for free cash flow from approximately $325 million to approximately $375 million for the full year.

[0001069202-21-000016:8k_2_02:41]
•    The company repurchased $200 million of stock in the first quarter of its planned $400 million for the year.

[0001069202-21-000016:8k_2_02:42]
CONFERENCE CALL INFORMATION

[0001069202-21-000016:8k_2_02:43]
A conference call to discuss the company’s first-quarter results and outlook will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 844-867-6169 (U.S.) or 409-207-6975 (international) at least 10 minutes prior to the scheduled start time and use participant code 5260831. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from approximately 11:00 a.m. Central time on April 26 through May 10, 2021 by dialing 866-207-1041 (U.S.) or 402-970-0847 (international) and using access code 7601253. The call also will be archived on the company’s website.

[0001069202-21-000016:8k_2_02:44]
ABOUT LENNOX INTERNATIONAL

[0001069202-21-000016:8k_2_02:45]
Lennox International Inc. is a global leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our air conditioning, heating, indoor air quality, and refrigeration systems. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol "LII". Additional information on Lennox International is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-21-000016:8k_2_02:46]
FORWARD-LOOKING STATEMENTS

[0001069202-21-000016:8k_2_02:47]
uncertainties that could cause actual results to differ materially from the results expressed or implied by the statements, and investors should not place undue reliance on them. Risks and uncertainties that could cause actual results to differ materially from such statements include risks associated with the economic impact of the COVID-19 pandemic on the company and its employees, customers and suppliers if the pandemic worsens or continues longer than anticipated; risks that the North American unitary HVAC and refrigeration markets perform worse than current assumptions. Additional statements include, but are not limited to: the impact of higher raw material prices, the impact of new or increased trade tariffs, LII’s ability to implement price increases for its products and services, economic conditions in our markets, regulatory changes, the impact of unfavorable weather, and a decline in new construction activity and related demand for products and services. For information concerning these and other risks and uncertainties, see LII’s publicly available filings with the Securities and Exchange Commission. LII disclaims any intention or obligation to update or revise any forward-looking statements, whether as a result of new information, future events or otherwise, except as required by law.

[0001069202-21-000016:8k_2_02:48]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-21-000016:8k_2_02:49]
Consolidated Statements of Operations

[0001069202-21-000016:8k_2_02:50]
(Unaudited)

[0001069202-21-000016:8k_2_02:51]
| (Amounts in millions, except per share data) | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net sales | $ | 930.5 |  |  | $ | 723.8 |  |  |  |  |  |
| Cost of goods sold | 674.0 |  |  | 558.1 |  |  |  |  |  |
| Gross profit | 256.5 |  |  | 165.7 |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 145.3 |  |  | 131.1 |  |  |  |  |  |
| Losses (gains) and other expenses, net | 0.3 |  |  | (1.0) |  |  |  |  |  |
| Restructuring charges | 0.1 |  |  | 0.5 |  |  |  |  |  |
| Loss from natural disasters, net of insurance recoveries | — |  |  | 1.6 |  |  |  |  |  |
| Income from equity method investments | (3.3) |  |  | (2.9) |  |  |  |  |  |
| Operating income | 114.1 |  |  | 36.4 |  |  |  |  |  |
| Pension settlement | 0.7 |  |  | — |  |  |  |  |  |
| Interest expense, net | 6.0 |  |  | 8.7 |  |  |  |  |  |
| Other expense (income), net | 1.0 |  |  | 1.2 |  |  |  |  |  |
| Income from continuing operations before income taxes | 106.4 |  |  | 26.5 |  |  |  |  |  |
| Provision for income taxes | 22.2 |  |  | 14.0 |  |  |  |  |  |
| Income from continuing operations | 84.2 |  |  | 12.5 |  |  |  |  |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes | — |  |  | — |  |  |  |  |  |
| Income tax benefit | — |  |  | (0.4) |  |  |  |  |  |
| Income from discontinued operations | — |  |  | 0.4 |  |  |  |  |  |
| Net income | $ | 84.2 |  |  | $ | 12.9 |  |  |  |  |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.22 |  |  | $ | 0.33 |  |  |  |  |  |
| Income from discontinued operations | — |  |  | 0.01 |  |  |  |  |  |
| Net income | $ | 2.22 |  |  | $ | 0.34 |  |  |  |  |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.20 |  |  | $ | 0.32 |  |  |  |  |  |
| Income from discontinued operations | — |  |  | 0.01 |  |  |  |  |  |
| Net income | $ | 2.20 |  |  | $ | 0.33 |  |  |  |  |  |
| Weighted Average Number of Shares Outstanding - Basic | 38.0 |  |  | 38.4 |  |  |  |  |  |
| Weighted Average Number of Shares Outstanding - Diluted | 38.2 |  |  | 38.7 |  |  |  |  |  |

[0001069202-21-000016:8k_2_02:52]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Segment Net Sales and Profit (Loss) |
| (Unaudited) |

[0001069202-21-000016:8k_2_02:53]
| (Amounts in millions) | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 606.3 |  |  | $ | 442.1 |  |  |  |  |  |
| Commercial Heating & Cooling | 199.2 |  |  | 178.4 |  |  |  |  |  |
| Refrigeration | 125.0 |  |  | 103.3 |  |  |  |  |  |
|  | $ | 930.5 |  |  | $ | 723.8 |  |  |  |  |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 96.4 |  |  | $ | 32.5 |  |  |  |  |  |
| Commercial Heating & Cooling | 27.4 |  |  | 18.7 |  |  |  |  |  |
| Refrigeration | 7.9 |  |  | 0.7 |  |  |  |  |  |
| Corporate and other | (16.0) |  |  | (14.3) |  |  |  |  |  |
| Total segment profit | 115.7 |  |  | 37.6 |  |  |  |  |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Loss from natural disasters, net of insurance recoveries | — |  |  | 1.6 |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) | 1.5 |  |  | (0.9) |  |  |  |  |  |
| Restructuring charges | 0.1 |  |  | 0.5 |  |  |  |  |  |
| Operating income | $ | 114.1 |  |  | $ | 36.4 |  |  |  |  |  |

[0001069202-21-000016:8k_2_02:54]
(1)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-21-000016:8k_2_02:55]
•The following items in Losses (gains) and other expenses, net:

[0001069202-21-000016:8k_2_02:56]
◦Net change in unrealized (gains) losses on unsettled futures contracts,

[0001069202-21-000016:8k_2_02:57]
◦Special legal contingency charges,

[0001069202-21-000016:8k_2_02:58]
◦Asbestos-related litigation,

[0001069202-21-000016:8k_2_02:59]
◦Environmental liabilities,

[0001069202-21-000016:8k_2_02:60]
◦Charges incurred related to COVID-19 pandemic; and

[0001069202-21-000016:8k_2_02:61]
◦Other items, net,

[0001069202-21-000016:8k_2_02:62]
•Loss from natural disasters, net of insurance recoveries; and

[0001069202-21-000016:8k_2_02:63]
•Restructuring charges.

[0001069202-21-000016:8k_2_02:64]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-21-000016:8k_2_02:65]
Consolidated Balance Sheets

[0001069202-21-000016:8k_2_02:66]
| (Amounts in millions, except shares and par values) | As of March 31, 2021 |  | As of December 31, 2020 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 35.5 |  |  | $ | 123.9 |  |
| Short-term investments | 4.5 |  |  | 5.1 |  |
| Accounts and notes receivable, net of allowances of $9.2 and $9.6 in 2021 and 2020, respectively | 522.6 |  |  | 448.3 |  |
| Inventories, net | 502.3 |  |  | 439.4 |  |
| Other assets | 73.3 |  |  | 70.9 |  |
| Total current assets | 1,138.2 |  |  | 1,087.6 |  |
| Property, plant and equipment, net of accumulated depreciation of $891.6 and $880.6 in 2021 and 2020, respectively | 466.4 |  |  | 464.3 |  |
| Right-of-use assets from operating leases | 190.7 |  |  | 194.4 |  |
| Goodwill | 186.7 |  |  | 186.9 |  |
| Deferred income taxes | 7.6 |  |  | 13.2 |  |
| Other assets, net | 85.4 |  |  | 86.1 |  |
| Total assets | $ | 2,075.0 |  |  | $ | 2,032.5 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 165.0 |  |  | 9.9 |  |
| Current operating lease liabilities | 54.9 |  |  | 55.0 |  |
| Accounts payable | 372.9 |  |  | 340.3 |  |
| Accrued expenses | 254.5 |  |  | 296.1 |  |
| Income taxes payable | 1.8 |  |  | — |  |
| Total current liabilities | 849.1 |  |  | 701.3 |  |
| Long-term debt | 1,007.9 |  |  | 970.7 |  |
| Long-term operating lease liabilities | 138.5 |  |  | 142.8 |  |
| Pensions | 94.8 |  |  | 92.5 |  |
| Other liabilities | 145.4 |  |  | 142.3 |  |
| Total liabilities | 2,235.7 |  |  | 2,049.6 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,090.3 |  |  | 1,113.2 |  |
| Retained earnings | 2,440.9 |  |  | 2,385.8 |  |
| Accumulated other comprehensive loss | (99.2) |  |  | (97.2) |  |
| Treasury stock, at cost, 49,396,668 shares and 48,820,969 shares for 2021 and 2020, respectively | (3,593.6) |  |  | (3,419.8) |  |
| Total stockholders' deficit | (160.7) |  |  | (17.1) |  |
| Total liabilities and stockholders' deficit | $ | 2,075.0 |  |  | $ | 2,032.5 |  |

[0001069202-21-000016:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-21-000016:8k_2_02:68]
Consolidated Statements of Cash Flows

[0001069202-21-000016:8k_2_02:69]
(Unaudited)

[0001069202-21-000016:8k_2_02:70]
| (Amounts in millions) | For the Three Months Ended March 31, |
|  | 2021 |  | 2020 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 84.2 |  |  | $ | 12.9 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |
| Income from equity method investments | (3.3) |  |  | (2.9) |  |
| Restructuring charges, net of cash paid | 0.3 |  |  | 0.1 |  |
| Provision for credit losses | 2.0 |  |  | 1.2 |  |
| Unrealized (gains) losses, net on derivative contracts | (0.2) |  |  | 1.5 |  |
| Stock-based compensation expense | 8.5 |  |  | 3.7 |  |
| Depreciation and amortization | 17.4 |  |  | 19.0 |  |
| Deferred income taxes | 1.0 |  |  | 8.8 |  |
| Pension expense | 3.0 |  |  | 2.7 |  |
| Pension contributions | (0.4) |  |  | (0.6) |  |
| Other items, net | (0.1) |  |  | 0.2 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts and notes receivable | (77.5) |  |  | (18.7) |  |
| Inventories | (62.5) |  |  | (71.0) |  |
| Other current assets | (9.5) |  |  | (0.7) |  |
| Accounts payable | 41.2 |  |  | (8.7) |  |
| Accrued expenses | (41.8) |  |  | (33.0) |  |
| Income taxes payable / receivable, net | 14.0 |  |  | (17.3) |  |
| Leases, net | (0.7) |  |  | 0.1 |  |
| Other, net | 6.9 |  |  | 3.9 |  |
| Net cash used in operating activities | (17.5) |  |  | (98.8) |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.4 |  |  | 0.1 |  |
| Purchases of property, plant and equipment | (24.7) |  |  | (24.7) |  |
| Proceeds from (purchases of) short-term investments | 0.5 |  |  | (1.1) |  |
| Net cash used in investing activities | (23.8) |  |  | (25.7) |  |
| Cash flows from financing activities: |  |  |  |
| Asset securitization borrowings | 155.0 |  |  | — |  |
| Asset securitization payments | — |  |  | (70.0) |  |
| Long-term debt payments | (2.9) |  |  | (2.6) |  |
| Borrowings from credit facility | 202.0 |  |  | 682.5 |  |
| Payments on credit facility | (165.0) |  |  | (342.5) |  |
| Proceeds from employee stock purchases | 0.9 |  |  | 0.8 |  |
| Repurchases of common stock | (200.0) |  |  | (100.0) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (6.0) |  |  | (5.5) |  |
| Cash dividends paid | (29.5) |  |  | (29.7) |  |
| Net cash (used in) provided by financing activities | (45.5) |  |  | 133.0 |  |
| (Decrease) increase in cash and cash equivalents | (86.8) |  |  | 8.5 |  |
| Effect of exchange rates on cash and cash equivalents | (1.6) |  |  | (6.7) |  |
| Cash and cash equivalents, beginning of period | 123.9 |  |  | 37.3 |  |
| Cash and cash equivalents, end of period | $ | 35.5 |  |  | $ | 39.1 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 5.5 |  |  | $ | 6.8 |  |
| Income taxes paid (net of refunds) | $ | 8.2 |  |  | $ | 21.3 |  |

[0001069202-21-000016:8k_2_02:71]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |
|  | For the Three Months Ended March 31, |  |  |
|  | (Unaudited) |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | Pre-Tax | Tax Impact (d) | After Tax |  | Pre-Tax | Tax Impact (d) | After Tax |  |  |  |  |
| Income from continuing operations, a GAAP measure | $ | 106.4 |  | $ | (22.2) |  | $ | 84.2 |  |  | $ | 26.5 |  | $ | (14.0) |  | $ | 12.5 |  |  |  |  |  |
| Restructuring charges | 0.1 |  | (0.1) |  | — |  |  | 0.5 |  | (0.1) |  | 0.4 |  |  |  |  |  |
| Pension settlement | 0.7 |  | (0.1) |  | 0.6 |  |  | — |  | — |  | — |  |  |  |  |  |
| Items in Losses (gains) and other expenses, netwhich are excluded from segment profit (loss) (a) | 1.5 |  | (0.2) |  | 1.3 |  |  | (0.9) |  | 0.1 |  | (0.8) |  |  |  |  |  |
| Excess tax benefits from share-based compensation (b) | — |  | (1.2) |  | (1.2) |  |  | — |  | 0.1 |  | 0.1 |  |  |  |  |  |
| Other tax items, net (b) | — |  | 2.0 |  | 2.0 |  |  | — |  | 8.2 |  | 8.2 |  |  |  |  |  |
| Loss from natural disasters, net of insurance recoveries (e) | — |  | — |  | — |  |  | 1.6 |  | (0.3) |  | 1.3 |  |  |  |  |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 108.7 |  | $ | (21.8) |  | $ | 86.9 |  |  | $ | 27.7 |  | $ | (6.0) |  | $ | 21.7 |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  | $ | 2.20 |  |  |  |  | $ | 0.32 |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  |  | 0.01 |  |  |  |  |  |
| Pension settlement |  |  | 0.02 |  |  |  |  | — |  |  |  |  |  |
| Items in Losses (gains) and other expenses, netwhich are excluded from segment profit (loss) (a) |  |  | 0.03 |  |  |  |  | (0.02) |  |  |  |  |  |
| Excess tax benefits from share-based compensation (b) |  |  | (0.03) |  |  |  |  | — |  |  |  |  |  |
| Other tax items, net (b) |  |  | 0.05 |  |  |  |  | 0.21 |  |  |  |  |  |
| Loss from natural disasters, net of insurance recoveries (e) |  |  | — |  |  |  |  | 0.04 |  |  |  |  |  |
| Change in share counts from share-based compensation (c) |  |  | — |  |  |  |  | — |  |  |  |  |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 2.27 |  |  |  |  | $ | 0.56 |  |  |  |  |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |
| (c) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount.. |  |  |
| (d) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |  |  |
| (e) Recorded in Loss from natural disasters, net of insurance recoveries in the Consolidated Statement of Operations. |  |  |  |  |

[0001069202-21-000016:8k_2_02:72]
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized (gains) losses on settled future contracts (a) | $ | (0.3) |  |  | $ | 0.1 |  |  |  |  |  |
| Foreign currency exchange gains (a) | (0.3) |  |  | (0.5) |  |  |  |  |  |
| (Gain) loss on disposal of fixed assets (a) | (0.3) |  |  | 0.1 |  |  |  |  |  |
| Other operating (income) loss (a) | (0.3) |  |  | 0.2 |  |  |  |  |  |
| Net change in unrealized (gains) losses on unsettled futures contracts (b) | (0.2) |  |  | 0.6 |  |  |  |  |  |
| Special legal contingency charges (b) | 0.2 |  |  | — |  |  |  |  |  |
| Asbestos-related litigation (b) | 1.1 |  |  | (1.7) |  |  |  |  |  |
| Environmental liabilities (b) | 0.6 |  |  | 0.2 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (b) | 0.6 |  |  | — |  |  |  |  |  |
| Other items, net (b) | (0.8) |  |  | — |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 0.3 |  |  | $ | (1.0) |  |  |  |  |  |

[0001069202-21-000016:8k_2_02:73]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |  |  |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |  |  |

[0001069202-21-000016:8k_2_02:74]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |
|  |  |  |  |  | For the Year Ended December 31, 2021ESTIMATED |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $11.33-$11.93 |
| Other non-core EBIT charges and other non-core tax items |  | (0.07) |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $11.40-$12.00 |

[0001069202-21-000016:8k_2_02:75]
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Average shares outstanding - diluted, a GAAP measure | 38.2 |  | 38.7 |  |  |  |  |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | — |  |  | — |  |  |  |  |  |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 38.2 |  | 38.7 |  |  |  |  |  |
| Reconciliation of Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net cash used in operating activities | $ | (17.5) |  |  | $ | (98.8) |  |  |  |  |  |
| Purchases of property, plant and equipment | (24.7) |  |  | (24.7) |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.4 |  |  | 0.1 |  |  |  |  |  |
| Free cash flow, a Non-GAAP measure | $ | (41.8) |  |  | $ | (123.4) |  |  |  |  |  |

[0001069202-21-000016:8k_2_02:76]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to March 31, 2021 |
| Adjusted EBIT (a) |  |  |  |  |  |  | $ | 584.8 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  | 69.1 |  |
| EBITDA (a + b) |  |  |  |  |  |  | $ | 653.9 |  |
| Total debt at March 31, 2021 (c) |  |  |  |  |  |  | $ | 1,172.9 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  | 1.8 |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |
|  |  |  |  |  |  |  | Trailing Twelve Months to March 31, 2021 |
| Income from continuing operations before income taxes, a GAAP measure | $ | 525.1 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit | 15.7 |  |
| Special product quality adjustments | 1.0 |  |
| Restructuring charges | 10.4 |  |
| Interest expense, net | 25.6 |  |
| Pension settlements | 1.3 |  |
| Loss from natural disasters, net of insurance recoveries | 1.5 |  |
| Other expense (income), net | 4.2 |  |
| Adjusted EBIT per above, a Non-GAAP measure | $ | 584.8 |  |
