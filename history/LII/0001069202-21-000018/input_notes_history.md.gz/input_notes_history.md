# LII note change history — 0001069202-20-000048 → 0001069202-21-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-04-26):
[0001069202-21-000018:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or
  (was, 2020-10-19, similarity 0.8584):
[0001069202-20-000048:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

- added (2021-04-26):
[0001069202-21-000018:note_history:2]
underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

- changed (2021-04-26):
[0001069202-21-000018:note_history:3]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.
  (was, 2020-10-19, similarity 0.9717):
[0001069202-20-000048:note_history:3]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

- changed (2021-04-26):
[0001069202-21-000018:note_history:4]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Accrued expenses | $ | 38.8 |  |  | $ | 37.7 |  |
| Other liabilities | 85.0 |  |  | 82.1 |  |
| Total warranty liability | $ | 123.8 |  |  | $ | 119.8 |  |
  (was, 2020-10-19, similarity 0.9716):
[0001069202-20-000048:note_history:4]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Accrued expenses | $ | 37.0 |  |  | $ | 38.2 |  |
| Other liabilities | 80.4 |  |  | 74.6 |  |
| Total warranty liability | $ | 117.4 |  |  | $ | 112.8 |  |

- changed (2021-04-26):
[0001069202-21-000018:note_history:5]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2021 were as follows (in millions):
  (was, 2020-10-19, similarity 0.9416):
[0001069202-20-000048:note_history:5]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2020 were as follows (in millions):

- changed (2021-04-26):
[0001069202-21-000018:note_history:6]
| Total warranty liability as of December 31, 2020 | $ | 119.8 |  |
| Warranty claims paid | (7.0) |  |
| Changes resulting from issuance of new warranties | 9.8 |  |
| Changes in estimates associated with pre-existing liabilities | 1.3 |  |
| Changes in foreign currency translation rates and other | (0.1) |  |
| Total warranty liability as of March 31, 2021 | $ | 123.8 |  |
  (was, 2020-10-19, similarity 0.8642):
[0001069202-20-000048:note_history:6]
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Warranty claims paid | (26.9) |  |
| Changes resulting from issuance of new warranties | 31.2 |  |
| Changes in estimates associated with pre-existing liabilities | 0.3 |  |
| Changes in foreign currency translation rates and other | — |  |
| Total warranty liability as of September 30, 2020 | $ | 117.4 |  |

- changed (2021-04-26):
[0001069202-21-000018:note_history:7]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future
  (was, 2020-10-19, similarity 0.8646):
[0001069202-20-000048:note_history:7]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):

- added (2021-04-26):
[0001069202-21-000018:note_history:8]
settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):

- added (2021-04-26):
[0001069202-21-000018:note_history:9]
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Loss (gain) for asbestos-related litigation, net | $ | 1.1 |  |  | $ | (1.7) |  |  |  |  |  |

- removed (2021-04-26):
[0001069202-20-000048:note_history:10]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Expense (gain) for asbestos-related litigation, net | $ | 2.4 |  |  | $ | 1.5 |  |  | $ | 1.9 |  |  | $ | 3.3 |  |

- removed (2021-04-26):
[0001069202-20-000048:note_history:11]
Natural Disasters and Recovery

- removed (2021-04-26):
[0001069202-20-000048:note_history:12]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  On August 10, 2020, the Marshalltown facility was partially damaged by a derecho wind storm. The costs and losses incurred as well as any insurance recoveries for both of these natural disasters are shown in Loss (gain) from natural disasters, net of insurance recoveries in the Consolidated Statements of Operations.

- removed (2021-04-26):
[0001069202-20-000048:note_history:13]
The following table summarizes the components of Loss (gain) from natural disasters, net of insurance recoveries (in millions):

- removed (2021-04-26):
[0001069202-20-000048:note_history:14]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Marshalltown tornado | $ | 0.4 |  |  | $ | (7.1) |  |  | $ | 3.1 |  |  | $ | (85.4) |  |
| Marshalltown wind storm | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |
| Loss (gain) from natural disasters, net of insurance recoveries | $ | 4.9 |  |  | $ | (7.1) |  |  | $ | 7.6 |  |  | $ | (85.4) |  |

- removed (2021-04-26):
[0001069202-20-000048:note_history:15]
Marshalltown Tornado

- removed (2021-04-26):
[0001069202-20-000048:note_history:16]
Insurance covered the repair or replacement of our assets that suffered damage or loss, and business interruption costs, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.  In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019. The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the tornado (in millions):

- removed (2021-04-26):
[0001069202-20-000048:note_history:17]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Insurance recoveries received | $ | — |  |  | $ | 10.0 |  |  | $ | — |  |  | $ | 138.0 |  |
| Losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | — |  |  | (3.5) |  |  | — |  |  | 19.8 |  |
| Factory inefficiencies due to lower productivity | — |  |  | 0.8 |  |  | — |  |  | 9.3 |  |
| Other | 0.4 |  |  | 5.6 |  |  | 3.1 |  |  | 23.5 |  |
| Total losses and expenses | $ | 0.4 |  |  | $ | 2.9 |  |  | $ | 3.1 |  |  | $ | 52.6 |  |
| Components of Marshalltown tornado in Loss (gain) from natural disasters, net of insurance recoveries: |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits | — |  |  | (8.3) |  |  | — |  |  | (73.8) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 0.4 |  |  | 1.2 |  |  | 3.1 |  |  | (11.6) |  |
|  | $ | 0.4 |  |  | $ | (7.1) |  |  | $ | 3.1 |  |  | $ | (85.4) |  |

- removed (2021-04-26):
[0001069202-20-000048:note_history:18]
Marshalltown Wind Storm

- removed (2021-04-26):
[0001069202-20-000048:note_history:19]
We have insurance for the repair and replacement of our assets that suffered damage or loss, and are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and losses we suffered.  Our insurance policies also provide business interruption coverage, including lost profits and reimbursement for other expenses and costs that have been incurred related to the damages and losses suffered. The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the wind storm (in millions):

- removed (2021-04-26):
[0001069202-20-000048:note_history:20]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Inventory write-offs | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |
| Site clean-up and remediation | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |
| Building repairs | 2.8 |  |  | — |  |  | 2.8 |  |  | — |  |
| Factory inefficiencies due to lower productivity | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |
| Other | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |
| Total losses and expenses | $ | 4.5 |  |  | $ | — |  |  | $ | 4.5 |  |  | $ | — |  |
| Components of Marshalltown wind storm in Loss (gain) from natural disasters, net of insurance recoveries: |  |  |  |  |  |  |  |
| Loss (gain) from natural disaster | $ | 4.5 |  |  | $ | — |  |  | $ | 4.5 |  |  | $ | — |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-04-26):
[0001069202-21-000018:note_history:21]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2021, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2021 and 2020, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2021 and 2020, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2021 and 2020, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2021 and 2020 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2020.
  (was, 2020-10-19, similarity 0.8524):
[0001069202-20-000048:note_history:21]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2020, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2020 and 2019, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2020 and 2019 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2019.

- changed (2021-04-26):
[0001069202-21-000018:note_history:22]
A novel strain of coronavirus (“COVID-19”) surfaced in late 2019 and has spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic has disrupted our business operations and caused a significant unfavorable impact on our results of operations in 2020. The COVID-19 pandemic has resulted in supply chain disruptions and higher employee absenteeism in our factories and distribution locations.
  (was, 2020-10-19, similarity 0.821):
[0001069202-20-000048:note_history:22]
A novel strain of coronavirus (“COVID-19”) surfaced in late 2019 and has spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic has disrupted our business operations and caused a significant unfavorable impact on our results of operations.

- added (2021-04-26):
[0001069202-21-000018:note_history:23]
As the COVID-19 pandemic continues, health concern risks remain, and we cannot predict whether any of our manufacturing, operational or distribution facilities will experience disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

- added (2021-04-26):
[0001069202-21-000018:note_history:24]
In December 2019, the FASB issued ASU No. 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.  ASU 2019-02, in an effort to reduce complexity in accounting for income taxes, removes certain exceptions for measuring intraperiod tax allocations, foreign subsidiary equity method investments and interim period tax losses.  ASU 2019-12 is effective for calendar year-end public business entities on January 1, 2021.  The adoption of ASU 2019-12 did not have a material impact on our financial statements.

- removed (2021-04-26):
[0001069202-20-000048:note_history:25]
In response to the COVID-19 pandemic, various national, state, and local governments where we, our suppliers, and our customers operate issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work.  Those decrees have resulted in supply chain disruption and higher employee absenteeism in our factories.

- removed (2021-04-26):
[0001069202-20-000048:note_history:26]
Additionally, certain of our manufacturing facilities experienced short-term suspensions of operations for COVID-19 employee health concerns.

- removed (2021-04-26):
[0001069202-20-000048:note_history:27]
The magnitude of the impact of COVID-19 remains unpredictable and we, therefore, continue to anticipate potential supply chain disruptions, employee absenteeism, short-term suspensions of manufacturing facilities and additional health and safety costs related to the COVID-19 pandemic that could unfavorably impact our business.  Although these disruptions and costs are expected to be temporary, there is significant uncertainty around the duration and overall impact to our business operations.  We believe it is possible that the impact of the COVID-19 pandemic could have a material adverse effect on the results of our operations, financial position and cash flows.

- removed (2021-04-26):
[0001069202-20-000048:note_history:28]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to estimate credit losses. ASU 2016-13 is effective for SEC filers for interim and annual periods beginning after December 15, 2019.  We adopted ASU 2016-13 using the modified retrospective method for all financial assets measured at amortized cost.  Results for periods after January 1, 2020 are presented under ASU 2016-13 while prior period amounts continue to be reported under previously applicable accounting standards.  We recorded a $1.3 million net decrease to retained earnings as of January 1, 2020 for the cumulative effect of adopting ASU 2016-13.

- removed (2021-04-26):
[0001069202-20-000048:note_history:29]
In January 2017, the FASB issued ASU No. 2017-04, Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates step two of the goodwill impairment test and specifies that goodwill impairment should be measured by comparing the fair value of a reporting unit with its carrying amount. Additionally, the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount of net assets should be disclosed. ASU 2017-04 is effective for annual or interim goodwill impairment tests performed in fiscal years beginning after December 15, 2019.  The adoption of ASU 2017-04 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.
In August 2018, the FASB issued ASU No. 2018-15, Intangibles – Internal-Use Software (Topic 350-40): Customer’s Accounting for Implementation Costs incurred in a Cloud Computing Arrangement That is a Service Contract.  ASU 2018-15 provides guidance to determine how implementation costs associated with cloud computing arrangements that are incurred to develop or obtain internal-use software should be capitalized or expensed as incurred. ASU 2018-15 is effective for fiscal years beginning after December 15, 2019.  The adoption of ASU 2018-15 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-26):
[0001069202-21-000018:note_history:30]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.63 | % |  | — | % |
  (was, 2020-10-19, similarity 0.94):
[0001069202-20-000048:note_history:30]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 1.65 | % |  | 2.93 | % |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-26):
[0001069202-21-000018:note_history:31]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 155.0 |  |  | $ | — |  |
| Finance lease obligations | 10.1 |  |  | 10.1 |  |
| Debt issuance costs | (0.1) |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 165.0 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 28.9 |  |  | 29.3 |  |
| Domestic credit facility | 37.0 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (8.0) |  |  | (8.6) |  |
| Total long-term debt | $ | 1,007.9 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,172.9 |  |  | $ | 980.6 |  |
  (was, 2020-10-19, similarity 0.9315):
[0001069202-20-000048:note_history:31]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 285.0 |  |
| Finance lease obligations | 9.6 |  |  | 7.8 |  |
| Domestic credit facility | — |  |  | 30.0 |  |
| Debt issuance costs | (2.6) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 7.0 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 28.8 |  |  | 25.9 |  |
| Domestic credit facility | 34.5 |  |  | 475.5 |  |
| Senior unsecured notes | 950.0 |  |  | 350.0 |  |
| Debt issuance costs | (6.7) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,006.6 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,013.6 |  |  | $ | 1,171.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-26):
[0001069202-21-000018:note_history:32]
|  | For the Three Months Ended March 31, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 558.8 |  |  | $ | 182.3 |  |  | $ | 75.6 |  |  | $ | 816.7 |  |
| Canada | 47.5 |  |  | 16.9 |  |  | — |  |  | 64.4 |  |
| Other international | — |  |  | — |  |  | 49.4 |  |  | 49.4 |  |
| Total | $ | 606.3 |  |  | $ | 199.2 |  |  | $ | 125.0 |  |  | $ | 930.5 |  |
  (was, 2020-10-19, similarity 0.75):
[0001069202-20-000048:note_history:32]
|  | For the Three Months Ended September 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 665.6 |  |  | $ | 184.6 |  |  | $ | 67.2 |  |  | $ | 917.4 |  |
| Canada | 56.4 |  |  | 22.7 |  |  | — |  |  | 79.1 |  |
| Other international | — |  |  | 0.6 |  |  | 57.9 |  |  | 58.5 |  |
| Total | $ | 722.0 |  |  | $ | 207.9 |  |  | $ | 125.1 |  |  | $ | 1,055.0 |  |

- changed (2021-04-26):
[0001069202-21-000018:note_history:33]
|  | For the Three Months Ended March 31, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 412.4 |  |  | $ | 161.1 |  |  | $ | 59.5 |  |  | $ | 633.0 |  |
| Canada | 29.7 |  |  | 17.1 |  |  | — |  |  | 46.8 |  |
| Other international | — |  |  | 0.2 |  |  | 43.8 |  |  | 44.0 |  |
| Total | $ | 442.1 |  |  | $ | 178.4 |  |  | $ | 103.3 |  |  | $ | 723.8 |  |
  (was, 2020-10-19, similarity 0.9444):
[0001069202-20-000048:note_history:33]
|  | For the Three Months Ended September 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 597.3 |  |  | $ | 227.0 |  |  | $ | 82.5 |  |  | $ | 906.8 |  |
| Canada | 40.3 |  |  | 26.0 |  |  | — |  |  | 66.3 |  |
| Other international | — |  |  | 0.3 |  |  | 59.5 |  |  | 59.8 |  |
| Total | $ | 637.6 |  |  | $ | 253.3 |  |  | $ | 142.0 |  |  | $ | 1,032.9 |  |

- added (2021-04-26):
[0001069202-21-000018:note_history:34]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products,

- changed (2021-04-26):
[0001069202-21-000018:note_history:35]
replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2021 and 2020, direct sales represented 67% and 73% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2020-10-19, similarity 0.6899):
[0001069202-20-000048:note_history:35]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2020 and 2019, direct sales represented 74% and 74% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2020 and 2019, direct sales represented 75% and 74% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- added (2021-04-26):
[0001069202-21-000018:note_history:36]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2021 and 2020, equipment sales represented 83% and 84% of revenues and the remainder of our revenue was generated from our service business.

- added (2021-04-26):
[0001069202-21-000018:note_history:37]
|  | March 31, 2021 |  | December 31, 2020 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (8.2) |  |  | $ | (5.5) |  |  | $ | (2.7) |  |  | 49.1 | % |
| Contract liabilities - noncurrent | (5.5) |  |  | (5.6) |  |  | 0.1 |  |  | (1.8) | % |
| Total | $ | (13.7) |  |  | $ | (11.1) |  |  | $ | (2.6) |  |  |  |

- changed (2021-04-26):
[0001069202-21-000018:note_history:38]
For the three months ended March 31, 2021 and 2020, we recognized revenue of $1.6 million and $1.5 million related to our contract liabilities at January 1, 2021 and 2020, respectively. Impairment losses recognized in our receivables and contract assets were de minimis for the three months ended March 31,  2021 and 2020.
  (was, 2020-10-19, similarity 0.745):
[0001069202-20-000048:note_history:38]
For the three months ended September 30, 2020 and 2019, we recognized revenue of $1.4 million and $0.2 million and for the nine months ended September 30, 2020 and 2019 we recognized revenue of $5.9 million and $2.8 million related to our contract liabilities at January 1, 2020 and 2019, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020 and 2019.

- removed (2021-04-26):
[0001069202-20-000048:note_history:39]
|  | For the Nine Months Ended September 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,681.8 |  |  | $ | 518.9 |  |  | $ | 188.0 |  |  | $ | 2,388.7 |  |
| Canada | 127.0 |  |  | 54.8 |  |  | — |  |  | $ | 181.8 |  |
| Other international | — |  |  | 0.9 |  |  | 148.7 |  |  | $ | 149.6 |  |
| Total | $ | 1,808.8 |  |  | $ | 574.6 |  |  | $ | 336.7 |  |  | $ | 2,720.1 |  |

- removed (2021-04-26):
[0001069202-20-000048:note_history:40]
|  | For the Nine Months Ended September 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,677.6 |  |  | $ | 623.3 |  |  | $ | 254.1 |  |  | $ | 2,555.0 |  |
| Canada | 114.6 |  |  | 63.8 |  |  | 0.7 |  |  | $ | 179.1 |  |
| International | — |  |  | 0.8 |  |  | 187.3 |  |  | $ | 188.1 |  |
| Total | $ | 1,792.2 |  |  | $ | 687.9 |  |  | $ | 442.1 |  |  | $ | 2,922.2 |  |

- removed (2021-04-26):
[0001069202-20-000048:note_history:41]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These

- removed (2021-04-26):
[0001069202-20-000048:note_history:42]
products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2020 and 2019, equipment sales represented 83% and 86% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2020 and 2019, equipment sales represented 84% and 86% of revenues, and the remainder of our revenue was generated from our service business.

- removed (2021-04-26):
[0001069202-20-000048:note_history:43]
|  | September 30, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (7.0) |  |  | $ | (8.4) |  |  | $ | 1.4 |  |  | (16.7) | % |
| Contract liabilities - noncurrent | (5.6) |  |  | (5.9) |  |  | 0.3 |  |  | (5.1) | % |
| Total | $ | (12.6) |  |  | $ | (14.3) |  |  | $ | 1.7 |  |  |  |
