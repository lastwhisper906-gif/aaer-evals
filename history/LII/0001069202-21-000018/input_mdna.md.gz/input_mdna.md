# LII MD&A — 0001069202-21-000018


## mdna

[0001069202-21-000018:mdna:1]
[same as prior period, unchanged from 0001069202-20-000048:mdna:1]

[0001069202-21-000018:mdna:2]
[same as prior period, unchanged from 0001069202-20-000048:mdna:2]

[0001069202-21-000018:mdna:3]
[same as prior period, unchanged from 0001069202-20-000048:mdna:3]

[0001069202-21-000018:mdna:4]
[same as prior period, unchanged from 0001069202-20-000048:mdna:4]

[0001069202-21-000018:mdna:5]
[same as prior period, unchanged from 0001069202-20-000048:mdna:5]

[0001069202-21-000018:mdna:6]
[same as prior period, unchanged from 0001069202-20-000048:mdna:6]

[0001069202-21-000018:mdna:7]
Impact of COVID-19 Pandemic

[0001069202-21-000018:mdna:8]
A novel strain of coronavirus (“COVID-19”) surfaced in late 2019 and has spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic has disrupted our business operations and caused a significant unfavorable impact on our results of operations in 2020. The COVID-19 pandemic has resulted in supply chain disruptions and higher employee absenteeism in our factories and distribution locations.

[0001069202-21-000018:mdna:9]
As the COVID-19 pandemic continues, health concern risks remain, and we cannot predict whether any of our manufacturing, operational or distribution facilities will experience disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

[0001069202-21-000018:mdna:10]
[same as prior period, unchanged from 0001069202-20-000048:mdna:16]

[0001069202-21-000018:mdna:11]
Results for the first quarter of 2021 were driven by year over year sales and profit increases across all of our business segments.  The Residential Heating & Cooling segment saw a 37% increase in net sales and a $64 million increase in segment profit. The Commercial Heating & Cooling segment had a 12% increase in net sales and a $9 million increase in segment profit. The Refrigeration segment had a 21% increase in net sales and a $7 million increase in segment profit.

[0001069202-21-000018:mdna:12]
[same as prior period, unchanged from 0001069202-20-000048:mdna:18]

[0001069202-21-000018:mdna:13]
•Net sales increased $207 million to $931 million in the first quarter of 2021 driven by net volume increases and favorable price and mix.

[0001069202-21-000018:mdna:14]
•Operating income in the first quarter of 2021 increased $78 million to $114 million primarily driven by higher net sales and an improved gross margin percentage partially offset by higher SG&A costs.

[0001069202-21-000018:mdna:15]
•Net income for the first quarter of 2021 increased $71 million to $84 million.

[0001069202-21-000018:mdna:16]
•Diluted earnings per share from continuing operations were $2.20 per share in the first quarter of 2021 compared to $0.32 per share in the first quarter of 2020.

[0001069202-21-000018:mdna:17]
•For the three months ended March 31, 2021, we returned $30 million to shareholders through dividend payments and repurchased $200 million of common stock through our share repurchase program.

[0001069202-21-000018:mdna:18]
First Quarter of 2021 Compared to First Quarter of 2020 - Consolidated Results

[0001069202-21-000018:mdna:19]
[same as prior period, unchanged from 0001069202-20-000048:mdna:25]

[0001069202-21-000018:mdna:20]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales | $ | 930.5 |  |  | $ | 723.8 |  |  | 28.6 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 674.0 |  |  | 558.1 |  |  | (20.8) |  |  | 72.4 |  |  | 77.1 |  |
| Gross profit | 256.5 |  |  | 165.7 |  |  | 54.8 |  |  | 27.6 |  |  | 22.9 |  |
| Selling, general and administrative expenses | 145.3 |  |  | 131.1 |  |  | (10.8) |  |  | 15.6 |  |  | 18.1 |  |
| Losses (gains) and other expenses, net | 0.3 |  |  | (1.0) |  |  | (130.0) |  |  | — |  |  | (0.1) |  |
| Restructuring charges | 0.1 |  |  | 0.5 |  |  | 80.0 |  |  | — |  |  | 0.1 |  |
| Loss from natural disasters, net of insurance recoveries | — |  |  | 1.6 |  |  | 100.0 |  |  | — |  |  | 0.2 |  |
| Income from equity method investments | (3.3) |  |  | (2.9) |  |  | 13.8 |  |  | (0.4) |  |  | (0.4) |  |
| Operating income | $ | 114.1 |  |  | $ | 36.4 |  |  | 213.5 | % |  | 12.3 | % |  | 5.0 | % |

[0001069202-21-000018:mdna:21]
[same as prior period, unchanged from 0001069202-20-000048:mdna:27]

[0001069202-21-000018:mdna:22]
Net sales increased 29% in the first quarter of 2021 compared to the first quarter of 2020 driven by higher sales volumes of 25%, favorable combined price and mix of 3% and favorable foreign currency of 1%.

[0001069202-21-000018:mdna:23]
[same as prior period, unchanged from 0001069202-20-000048:mdna:29]

[0001069202-21-000018:mdna:24]
Gross profit margin in the first quarter of 2021 increased 470 basis points ("bps") to 27.6% compared to 22.9% in the first quarter of 2020. We saw margin increases of 300 bps from favorable price and mix, 90 bps from sourcing and engineering-led cost reductions, 80 bps from lower other product costs, 40 bps from improved freight and distribution costs, and 10 bps from foreign currency which were partially offset by 30 bps due to unfavorable commodity costs and 20 bps from unfavorable product warranty costs.

[0001069202-21-000018:mdna:25]
[same as prior period, unchanged from 0001069202-20-000048:mdna:31]

[0001069202-21-000018:mdna:26]
Selling, general and administrative expenses ("SG&A") increased $14 million to $145 million in the first quarter of 2021 compared to $131 million in the first quarter of 2020 due to higher incentive compensation and other employee costs. As a percentage of net sales, SG&A decreased 250 bps to 15.6% .

[0001069202-21-000018:mdna:27]
[same as prior period, unchanged from 0001069202-20-000048:mdna:33]

[0001069202-21-000018:mdna:28]
Losses (gains) losses and other expenses, net for the first quarter of 2021 and 2020 included the following (in millions):

[0001069202-21-000018:mdna:29]
|  | For the Three Months Ended March 31, |
|  | 2021 |  | 2020 |
| Realized (gains) losses on settled futures contracts | $ | (0.3) |  |  | $ | 0.1 |  |
| Foreign currency exchange gains | (0.3) |  |  | (0.5) |  |
| (Gain) loss on disposal of fixed assets | (0.3) |  |  | 0.1 |  |
| Other operating (income) loss | (0.3) |  |  | 0.2 |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.2) |  |  | 0.6 |  |
| Special legal contingency charges | 0.2 |  |  | — |  |
| Asbestos-related litigation | 1.1 |  |  | (1.7) |  |
| Environmental liabilities | 0.6 |  |  | 0.2 |  |
| Charges incurred related to COVID-19 pandemic | 0.6 |  |  | — |  |
| Other items, net | (0.8) |  |  | — |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 0.3 |  |  | $ | (1.0) |  |

[0001069202-21-000018:mdna:30]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 7 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities related to estimated remediation costs for contamination at some of our facilities.

[0001069202-21-000018:mdna:31]
[same as prior period, unchanged from 0001069202-20-000048:mdna:37]

[0001069202-21-000018:mdna:32]
Restructuring charges were insignificant in the first quarter of 2021 and related to ongoing cost reduction actions taken in prior periods.

[0001069202-21-000018:mdna:33]
[same as prior period, unchanged from 0001069202-20-000048:mdna:39]

[0001069202-21-000018:mdna:34]
The insignificant charges recorded during 2021 and 2020 relate to continuing costs related to natural disasters that occurred in prior years.

[0001069202-21-000018:mdna:35]
[same as prior period, unchanged from 0001069202-20-000048:mdna:44]

[0001069202-21-000018:mdna:36]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $3 million in the first quarter of 2021 was up slightly compared to the first quarter of 2020.

[0001069202-21-000018:mdna:37]
[same as prior period, unchanged from 0001069202-20-000048:mdna:47]

[0001069202-21-000018:mdna:38]
Interest expense, net was down $3 million to $6 million in the first quarter of 2021 from $9 million in the first quarter of 2020 due to lower borrowing costs and less outstanding debt.

[0001069202-21-000018:mdna:39]
[same as prior period, unchanged from 0001069202-20-000048:mdna:49]

[0001069202-21-000018:mdna:40]
Our effective tax rate was 20.9% for the first quarter of 2021 compared to 52.8% for the first quarter of 2020.  The rate decreased primarily due to the recording of a valuation allowance on certain foreign deferred tax assets in 2020.   We expect our annual effective tax rate in 2021 to be between 20% and 21%, after excluding the impacts of excess tax benefits recorded under ASU No. 2016-09.

[0001069202-21-000018:mdna:41]
First Quarter of 2021 Compared to First Quarter of 2020 - Results by Segment

[0001069202-21-000018:mdna:42]
[same as prior period, unchanged from 0001069202-20-000048:mdna:52]

[0001069202-21-000018:mdna:43]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first quarter of 2021 and 2020 (dollars in millions):

[0001069202-21-000018:mdna:44]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 606.3 |  |  | $ | 442.1 |  |  | $ | 164.2 |  |  | 37.1 | % |
| Profit | $ | 96.4 |  |  | $ | 32.5 |  |  | $ | 63.9 |  |  | 196.6 | % |
| % of net sales | 15.9 | % |  | 7.4 | % |  |  |  |  |

[0001069202-21-000018:mdna:45]
Net sales increased 37% in the first quarter of 2021 compared to the first quarter of 2020.  Sales volumes increased 32% and combined price and mix increased 5%.

[0001069202-21-000018:mdna:46]
Segment profit in 2021 increased $64 million compared to 2020 due to $46 million from volume, $10 million of factory productivity, $8 million of combined price and mix, $6 million of engineering and sourcing led cost reductions, $3 million of lower freight and distribution expense, and $1 million favorable foreign currency exchange rates.  Partially offsetting these increases were higher costs from $4 million of commodities and tariffs, $3 million of other product costs, and $3 million higher SG&A.

[0001069202-21-000018:mdna:47]
[same as prior period, unchanged from 0001069202-20-000048:mdna:57]

[0001069202-21-000018:mdna:48]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2021 and 2020 (dollars in millions):

[0001069202-21-000018:mdna:49]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 199.2 |  |  | $ | 178.4 |  |  | $ | 20.8 |  |  | 11.7 | % |
| Profit | $ | 27.4 |  |  | $ | 18.7 |  |  | $ | 8.7 |  |  | 46.5 | % |
| % of net sales | 13.8 | % |  | 10.5 | % |  |  |  |  |

[0001069202-21-000018:mdna:50]
Net sales increased 12% in the first quarter of 2021 compared to the first quarter of 2020.  Sales volumes increased 15% and foreign currency was 1% favorable partially offset by unfavorable mix of 4%.

[0001069202-21-000018:mdna:51]
Segment profit in 2021 increased $9 million compared to 2020 due to $8 million from volume, $1 million of engineering and sourcing led cost reductions, and $1 million of lower SG&A.  Partially offsetting these increases was $1 million unfavorable mix.

[0001069202-21-000018:mdna:52]
[same as prior period, unchanged from 0001069202-20-000048:mdna:62]

[0001069202-21-000018:mdna:53]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2021 and 2020 (dollars in millions):

[0001069202-21-000018:mdna:54]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 125.0 |  |  | $ | 103.3 |  |  | $ | 21.7 |  |  | 21.0 | % |
| Profit | $ | 7.9 |  |  | $ | 0.7 |  |  | $ | 7.2 |  |  | 1,028.6 | % |
| % of net sales | 6.3 | % |  | 0.7 | % |  |  |  |  |

[0001069202-21-000018:mdna:55]
Net sales increased 21% in the first quarter of 2021 compared to the first quarter of 2020. Sales volumes increased 15%, foreign currency was 4% favorable, and combined price and mix were 2% higher.

[0001069202-21-000018:mdna:56]
Segment profit in 2021 increased $7 million compared to 2020 due to $5 million from volume, $3 million of combined price and mix, $2 million of engineering and sourcing led cost reductions, and $1 million of factory productivity.  Partially offsetting these increases was $3 million of SG&A and $1 million of other product costs and tariffs.

[0001069202-21-000018:mdna:57]
[same as prior period, unchanged from 0001069202-20-000048:mdna:67]

[0001069202-21-000018:mdna:58]
Corporate and other expenses increased $2 million in the first quarter of 2021 compared to the first quarter of 2020 due to $4 million related to the timing of long-term incentive compensation and other employee costs.  These increases in expense were partially offset by $1 million of favorable foreign currency and $1 million of income from equity method investments and other cost reductions.

[0001069202-21-000018:mdna:59]
[same as prior period, unchanged from 0001069202-20-000048:mdna:116]

[0001069202-21-000018:mdna:60]
[same as prior period, unchanged from 0001069202-20-000048:mdna:117]

[0001069202-21-000018:mdna:61]
[same as prior period, unchanged from 0001069202-20-000048:mdna:118]

[0001069202-21-000018:mdna:62]
The following table summarizes our cash flow activity for the three months ended March 31, 2021 and 2020 (in millions):

[0001069202-21-000018:mdna:63]
|  | For the Three Months Ended March 31, |
|  | 2021 |  | 2020 |
| Net cash used in operating activities | $ | (17.5) |  |  | $ | (98.8) |  |
| Net cash used in investing activities | (23.8) |  |  | (25.7) |  |
| Net cash (used in) provided by financing activities | (45.5) |  |  | 133.0 |  |

[0001069202-21-000018:mdna:64]
Net Cash Used in Operating Activities - The net cash used in operating activities in the three months ended March 31, 2021 and 2020 reflects the seasonal increase in working capital requirements.  The change in net cash used in operating activities for the three months ended March 31, 2021 compared to the same period in 2020 reflects an increase in operating income and changes in working capital.

[0001069202-21-000018:mdna:65]
Net Cash Used in Investing Activities - Capital expenditures were $25 million in the three months ended March 31, 2021 compared to $25 million in the same period of 2020.  Capital expenditures in 2021 were primarily related to the expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001069202-21-000018:mdna:66]
Net Cash (Used in) provided by Financing Activities - Net cash (used in) provided by financing activities in the three months ended March 31, 2021 changed to a net use of cash of $46 million compared to a net cash inflow of $133 million in the same period of 2020.  The change was primarily due to lower net borrowings and increased share repurchases in the current year compared to the prior year.  We repurchased $200 million of shares for the three months ended March 31, 2021 and returned $30 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001069202-21-000018:mdna:67]
[same as prior period, unchanged from 0001069202-20-000048:mdna:124]

[0001069202-21-000018:mdna:68]
The following table details our lines of credit and financing arrangements as of March 31, 2021 (in millions):

[0001069202-21-000018:mdna:69]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (2) | $ | 155.0 |  |
| Finance lease obligations | 10.1 |  |
| Debt issuance costs | (0.1) |  |
| Total current maturities of long-term debt | $ | 165.0 |  |
| Long-term debt: |  |
| Finance lease obligations | 28.9 |  |
| Domestic credit facility (1) | 37.0 |  |
| Senior unsecured notes | 950.0 |  |
| Debt issuance costs | (8.0) |  |
| Total long-term debt | 1,007.9 |  |
| Total debt | $ | 1,172.9 |  |

[0001069202-21-000018:mdna:70]
(1) The available future borrowings on our domestic credit facility are $710.8 million, after being reduced by the outstanding borrowings and $2.2 million in outstanding standby letters of credit.  The domestic credit facility matures in August 2022.

[0001069202-21-000018:mdna:71]
(2) The maximum securitization amount ranges from $250.0 million to $400.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information.

[0001069202-21-000018:mdna:72]
[same as prior period, unchanged from 0001069202-20-000048:mdna:129]

[0001069202-21-000018:mdna:73]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 115.9% at March 31, 2021 from 102.0% at December 31, 2020.

[0001069202-21-000018:mdna:74]
As of March 31, 2021, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-21-000018:mdna:75]
[same as prior period, unchanged from 0001069202-20-000048:mdna:132]

[0001069202-21-000018:mdna:76]
We believe our cash and cash equivalents of $36 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $36 million as of March 31, 2021 was $22 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-21-000018:mdna:77]
[same as prior period, unchanged from 0001069202-20-000048:mdna:134]

[0001069202-21-000018:mdna:78]
[same as prior period, unchanged from 0001069202-20-000048:mdna:135]

[0001069202-21-000018:mdna:79]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of March 31, 2021 and December 31, 2020 and for the three months ended March 31, 2021 and the year ended December 31, 2020 (in millions):

[0001069202-21-000018:mdna:80]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Current assets | $ | 557.7 |  |  | $ | 538.1 |  |
| Non-current assets | $ | 2,896.6 |  |  | $ | 2,975.5 |  |
| Current liabilities | $ | 578.0 |  |  | $ | 588.0 |  |
| Non-current liabilities | $ | 1,356.5 |  |  | $ | 1,318.7 |  |
| Amounts due to non-guarantor subsidiaries | $ | (334.5) |  |  | $ | (303.8) |  |

[0001069202-21-000018:mdna:81]
|  |  |  | For the Three Months EndedMarch 31, 2021 |  | For the Year Ended December 31, 2020 |
| Net sales |  |  | $ | 855.0 |  |  | $ | 3,358.0 |  |
| Gross profit |  |  | $ | 229.2 |  |  | $ | 981.5 |  |
| Income from continuing operations |  |  | $ | 187.3 |  |  | $ | 721.7 |  |
| Net income |  |  | $ | 187.3 |  |  | $ | 721.7 |  |
| Net sales to non-guarantor subsidiaries |  |  | $ | 53.1 |  |  | $ | 245.5 |  |

[0001069202-21-000018:mdna:82]
[same as prior period, unchanged from 0001069202-20-000048:mdna:139]

[0001069202-21-000018:mdna:83]
[same as prior period, unchanged from 0001069202-20-000048:mdna:140]

[0001069202-21-000018:mdna:84]
Commitments, Contingencies and Guarantees

[0001069202-21-000018:mdna:85]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-21-000018:mdna:86]
[same as prior period, unchanged from 0001069202-20-000048:mdna:143]

[0001069202-21-000018:mdna:87]
[same as prior period, unchanged from 0001069202-20-000048:mdna:144]
