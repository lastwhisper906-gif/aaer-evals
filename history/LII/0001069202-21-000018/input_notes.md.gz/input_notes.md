# LII notes — 0001069202-21-000018


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-21-000018:notes:1]
[same as prior period, unchanged from 0001069202-20-000048:notes:1]

[0001069202-21-000018:notes:2]
[same as prior period, unchanged from 0001069202-20-000048:notes:2]

[0001069202-21-000018:notes:3]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2021, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2021 and 2020, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2021 and 2020, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2021 and 2020, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2021 and 2020 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2020.

[0001069202-21-000018:notes:4]
[same as prior period, unchanged from 0001069202-20-000048:notes:4]

[0001069202-21-000018:notes:5]
[same as prior period, unchanged from 0001069202-20-000048:notes:5]

[0001069202-21-000018:notes:6]
[same as prior period, unchanged from 0001069202-20-000048:notes:6]

[0001069202-21-000018:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-21-000018:notes:8]
[same as prior period, unchanged from 0001069202-20-000048:notes:8]

[0001069202-21-000018:notes:9]
[same as prior period, unchanged from 0001069202-20-000048:notes:9]

[0001069202-21-000018:notes:10]
A novel strain of coronavirus (“COVID-19”) surfaced in late 2019 and has spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic has disrupted our business operations and caused a significant unfavorable impact on our results of operations in 2020. The COVID-19 pandemic has resulted in supply chain disruptions and higher employee absenteeism in our factories and distribution locations.

[0001069202-21-000018:notes:11]
As the COVID-19 pandemic continues, health concern risks remain, and we cannot predict whether any of our manufacturing, operational or distribution facilities will experience disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

[0001069202-21-000018:notes:12]
Recently Adopted Accounting Guidance

[0001069202-21-000018:notes:13]
In December 2019, the FASB issued ASU No. 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.  ASU 2019-02, in an effort to reduce complexity in accounting for income taxes, removes certain exceptions for measuring intraperiod tax allocations, foreign subsidiary equity method investments and interim period tax losses.  ASU 2019-12 is effective for calendar year-end public business entities on January 1, 2021.  The adoption of ASU 2019-12 did not have a material impact on our financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-21-000018:notes:14]
[same as prior period, unchanged from 0001069202-20-000048:notes:17]

[0001069202-21-000018:notes:15]
[same as prior period, unchanged from 0001069202-20-000048:notes:18]

[0001069202-21-000018:notes:16]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation in the table below details the items excluded.

[0001069202-21-000018:notes:17]
[same as prior period, unchanged from 0001069202-20-000048:notes:21]

[0001069202-21-000018:notes:18]
[same as prior period, unchanged from 0001069202-20-000048:notes:22]

[0001069202-21-000018:notes:19]
[same as prior period, unchanged from 0001069202-20-000048:notes:23]

[0001069202-21-000018:notes:20]
[same as prior period, unchanged from 0001069202-20-000048:notes:24]

[0001069202-21-000018:notes:21]
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 606.3 |  |  | $ | 442.1 |  |  |  |  |  |
| Commercial Heating & Cooling | 199.2 |  |  | 178.4 |  |  |  |  |  |
| Refrigeration | 125.0 |  |  | 103.3 |  |  |  |  |  |
|  | $ | 930.5 |  |  | $ | 723.8 |  |  |  |  |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 96.4 |  |  | $ | 32.5 |  |  |  |  |  |
| Commercial Heating & Cooling | 27.4 |  |  | 18.7 |  |  |  |  |  |
| Refrigeration | 7.9 |  |  | 0.7 |  |  |  |  |  |
| Corporate and other | (16.0) |  |  | (14.3) |  |  |  |  |  |
| Total segment profit | 115.7 |  |  | 37.6 |  |  |  |  |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Loss from natural disasters, net of insurance recoveries | — |  |  | 1.6 |  |  |  |  |  |
| Items in (Gains) losses and other expenses, net that are excluded from segment profit (loss) (1) | 1.5 |  |  | (0.9) |  |  |  |  |  |
| Restructuring charges | 0.1 |  |  | 0.5 |  |  |  |  |  |
| Operating income | $ | 114.1 |  |  | $ | 36.4 |  |  |  |  |  |

[0001069202-21-000018:notes:22]
[same as prior period, unchanged from 0001069202-20-000048:notes:26]

[0001069202-21-000018:notes:23]
◦The following items in Losses (gains) and other expenses, net:

[0001069202-21-000018:notes:24]
▪Net change in unrealized (gains) losses on unsettled futures contracts,

[0001069202-21-000018:notes:25]
▪Special legal contingency charges,

[0001069202-21-000018:notes:26]
▪Asbestos-related litigation,

[0001069202-21-000018:notes:27]
▪Environmental liabilities,

[0001069202-21-000018:notes:28]
▪Charges incurred related to COVID-19 pandemic; and

[0001069202-21-000018:notes:29]
▪Other items, net,

[0001069202-21-000018:notes:30]
◦Loss from natural disasters, net of insurance recoveries; and

[0001069202-21-000018:notes:31]
◦Restructuring charges.


## us-gaap:EarningsPerShareTextBlock

[0001069202-21-000018:notes:32]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period. Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-21-000018:notes:33]
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Net income | $ | 84.2 |  |  | $ | 12.9 |  |  |  |  |  |
| Exclude: Income from discontinued operations | — |  |  | (0.4) |  |  |  |  |  |
| Income from continuing operations | $ | 84.2 |  |  | $ | 12.5 |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 38.0 |  |  | 38.4 |  |  |  |  |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.3 |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 38.2 |  |  | 38.7 |  |  |  |  |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.22 |  |  | $ | 0.33 |  |  |  |  |  |
| Income from discontinued operations | — |  |  | 0.01 |  |  |  |  |  |
| Net income | $ | 2.22 |  |  | $ | 0.34 |  |  |  |  |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.20 |  |  | $ | 0.32 |  |  |  |  |  |
| Income from discontinued operations | — |  |  | 0.01 |  |  |  |  |  |
| Net income | $ | 2.20 |  |  | $ | 0.33 |  |  |  |  |  |

[0001069202-21-000018:notes:34]
[same as prior period, unchanged from 0001069202-20-000048:notes:42]

[0001069202-21-000018:notes:35]
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Weighted-average number of shares | 0.1 |  |  | 0.3 |  |  |  |  |  |
| Price per share | $278.00 |  | $214.63-$270.83 |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-21-000018:notes:36]
Leases

[0001069202-21-000018:notes:37]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001069202-21-000018:notes:38]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or

[0001069202-21-000018:notes:39]
underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-21-000018:notes:40]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-21-000018:notes:41]
We lease certain real and personal property under non-cancelable operating leases. Approximately 73% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-21-000018:notes:42]
Product Warranties and Product Related Contingencies

[0001069202-21-000018:notes:43]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001069202-21-000018:notes:44]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-21-000018:notes:45]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Accrued expenses | $ | 38.8 |  |  | $ | 37.7 |  |
| Other liabilities | 85.0 |  |  | 82.1 |  |
| Total warranty liability | $ | 123.8 |  |  | $ | 119.8 |  |

[0001069202-21-000018:notes:46]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2021 were as follows (in millions):

[0001069202-21-000018:notes:47]
| Total warranty liability as of December 31, 2020 | $ | 119.8 |  |
| Warranty claims paid | (7.0) |  |
| Changes resulting from issuance of new warranties | 9.8 |  |
| Changes in estimates associated with pre-existing liabilities | 1.3 |  |
| Changes in foreign currency translation rates and other | (0.1) |  |
| Total warranty liability as of March 31, 2021 | $ | 123.8 |  |

[0001069202-21-000018:notes:48]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

[0001069202-21-000018:notes:49]
Litigation

[0001069202-21-000018:notes:50]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-21-000018:notes:51]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future

[0001069202-21-000018:notes:52]
settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):

[0001069202-21-000018:notes:53]
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Loss (gain) for asbestos-related litigation, net | $ | 1.1 |  |  | $ | (1.7) |  |  |  |  |  |

[0001069202-21-000018:notes:54]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-21-000018:notes:55]
Our Board of Directors have authorized a total of $3 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in December 2019. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of March 31, 2021, $246 million of shares may be repurchased under the Share Repurchase Plans.

[0001069202-21-000018:notes:56]
On February 4, 2021, we entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the "ASR Agreement") with Wells Fargo Bank, to effect an accelerated stock buyback of the Company's common stock.  Under the ASR Agreement, we paid Wells Fargo Bank $200.0 million and Wells Fargo Bank delivered to us 0.6 million shares of common stock representing approximately 85% of the shares expected to be purchased under the ASR Agreement. The ASR was completed in April 2021 and Wells Fargo Bank delivered an additional 0.1 million shares of common stock for a total of 0.7 million shares of common stock repurchased under this ASR Agreement.

[0001069202-21-000018:notes:57]
We also repurchased shares for $6.0 million during the three months ended March 31, 2021 from employees who tendered their shares to satisfy minimum tax withholding obligations upon the vesting and exercise of stock-based compensation awards.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-21-000018:notes:58]
[same as prior period, unchanged from 0001069202-20-000048:notes:77]

[0001069202-21-000018:notes:59]
|  | For the Three Months Ended March 31, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 558.8 |  |  | $ | 182.3 |  |  | $ | 75.6 |  |  | $ | 816.7 |  |
| Canada | 47.5 |  |  | 16.9 |  |  | — |  |  | 64.4 |  |
| Other international | — |  |  | — |  |  | 49.4 |  |  | 49.4 |  |
| Total | $ | 606.3 |  |  | $ | 199.2 |  |  | $ | 125.0 |  |  | $ | 930.5 |  |

[0001069202-21-000018:notes:60]
|  | For the Three Months Ended March 31, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 412.4 |  |  | $ | 161.1 |  |  | $ | 59.5 |  |  | $ | 633.0 |  |
| Canada | 29.7 |  |  | 17.1 |  |  | — |  |  | 46.8 |  |
| Other international | — |  |  | 0.2 |  |  | 43.8 |  |  | 44.0 |  |
| Total | $ | 442.1 |  |  | $ | 178.4 |  |  | $ | 103.3 |  |  | $ | 723.8 |  |

[0001069202-21-000018:notes:61]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products,

[0001069202-21-000018:notes:62]
replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2021 and 2020, direct sales represented 67% and 73% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-21-000018:notes:63]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2021 and 2020, equipment sales represented 83% and 84% of revenues and the remainder of our revenue was generated from our service business.

[0001069202-21-000018:notes:64]
[same as prior period, unchanged from 0001069202-20-000048:notes:85]

[0001069202-21-000018:notes:65]
[same as prior period, unchanged from 0001069202-20-000048:notes:86]

[0001069202-21-000018:notes:66]
[same as prior period, unchanged from 0001069202-20-000048:notes:87]

[0001069202-21-000018:notes:67]
[same as prior period, unchanged from 0001069202-20-000048:notes:88]

[0001069202-21-000018:notes:68]
[same as prior period, unchanged from 0001069202-20-000048:notes:89]

[0001069202-21-000018:notes:69]
[same as prior period, unchanged from 0001069202-20-000048:notes:90]

[0001069202-21-000018:notes:70]
|  | March 31, 2021 |  | December 31, 2020 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (8.2) |  |  | $ | (5.5) |  |  | $ | (2.7) |  |  | 49.1 | % |
| Contract liabilities - noncurrent | (5.5) |  |  | (5.6) |  |  | 0.1 |  |  | (1.8) | % |
| Total | $ | (13.7) |  |  | $ | (11.1) |  |  | $ | (2.6) |  |  |  |

[0001069202-21-000018:notes:71]
For the three months ended March 31, 2021 and 2020, we recognized revenue of $1.6 million and $1.5 million related to our contract liabilities at January 1, 2021 and 2020, respectively. Impairment losses recognized in our receivables and contract assets were de minimis for the three months ended March 31,  2021 and 2020.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-21-000018:notes:72]
[same as prior period, unchanged from 0001069202-20-000048:notes:93]

[0001069202-21-000018:notes:73]
[same as prior period, unchanged from 0001069202-20-000048:notes:94]

[0001069202-21-000018:notes:74]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Finished goods | $ | 321.8 |  |  | $ | 280.1 |  |
| Work in process | 6.3 |  |  | 6.5 |  |
| Raw materials and parts | 228.8 |  |  | 207.8 |  |
| Subtotal | 556.9 |  |  | 494.4 |  |
| Excess of current cost over last-in, first-out cost | (54.6) |  |  | (55.0) |  |
| Total inventories, net | $ | 502.3 |  |  | $ | 439.4 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-21-000018:notes:75]
[same as prior period, unchanged from 0001069202-20-000048:notes:96]

[0001069202-21-000018:notes:76]
The changes in the carrying amount of goodwill in 2021, in total and by segment, are summarized in the table below (in millions):

[0001069202-21-000018:notes:77]
|  | Balance at December 31, 2020 |  |  |  | Changes in foreign currency translation rates |  | Balance at March 31, 2021 |
| Residential Heating & Cooling | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.7 |  |  |  |  | (0.2) |  |  | 99.5 |  |
| Total Goodwill | $ | 186.9 |  |  |  |  | $ | (0.2) |  |  | $ | 186.7 |  |

[0001069202-21-000018:notes:78]
[same as prior period, unchanged from 0001069202-20-000048:notes:99]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-21-000018:notes:79]
[same as prior period, unchanged from 0001069202-20-000048:notes:100]

[0001069202-21-000018:notes:80]
[same as prior period, unchanged from 0001069202-20-000048:notes:101]

[0001069202-21-000018:notes:81]
[same as prior period, unchanged from 0001069202-20-000048:notes:102]

[0001069202-21-000018:notes:82]
[same as prior period, unchanged from 0001069202-20-000048:notes:103]

[0001069202-21-000018:notes:83]
[same as prior period, unchanged from 0001069202-20-000048:notes:104]

[0001069202-21-000018:notes:84]
[same as prior period, unchanged from 0001069202-20-000048:notes:105]

[0001069202-21-000018:notes:85]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through August 2022.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-21-000018:notes:86]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Unrealized gains on unsettled contracts | $ | (15.7) |  |  | $ | (10.5) |  |
| Income tax expense | 3.4 |  |  | 2.3 |  |
| Gains included in AOCL, net of tax (1) | $ | (12.3) |  |  | $ | (8.2) |  |

[0001069202-21-000018:notes:87]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $11.5 million of derivative gains into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-21-000018:notes:88]
[same as prior period, unchanged from 0001069202-20-000048:notes:110]

[0001069202-21-000018:notes:89]
[same as prior period, unchanged from 0001069202-20-000048:notes:111]

[0001069202-21-000018:notes:90]
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Stock-based compensation expense (1) | $ | 8.5 |  |  | $ | 3.7 |  |  |  |  |  |

[0001069202-21-000018:notes:91]
[same as prior period, unchanged from 0001069202-20-000048:notes:113]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-21-000018:notes:92]
[same as prior period, unchanged from 0001069202-20-000048:notes:114]

[0001069202-21-000018:notes:93]
|  | For the Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Service cost | $ | 1.5 |  |  | $ | 1.4 |  |  |  |  |  |
| Interest cost | 1.5 |  |  | 1.8 |  |  |  |  |  |
| Expected return on plan assets | (2.7) |  |  | (2.2) |  |  |  |  |  |
| Amortization of prior service cost | 0.1 |  |  | — |  |  |  |  |  |
| Recognized actuarial loss | 2.1 |  |  | 1.5 |  |  |  |  |  |
| Other | (0.2) |  |  | — |  |  |  |  |  |
| Settlements and curtailments | 0.7 |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 3.0 |  |  | $ | 2.5 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-21-000018:notes:94]
, we had approximately $3.3 million in total gross unrecognized tax benefits. Of this amount $3.3 million, if recognized, would be recorded through the Consolidated Statements of Operations.We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2019 and 2020 and are subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2014.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001069202-21-000018:notes:95]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-21-000018:notes:96]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 155.0 |  |  | $ | — |  |
| Finance lease obligations | 10.1 |  |  | 10.1 |  |
| Debt issuance costs | (0.1) |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 165.0 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 28.9 |  |  | 29.3 |  |
| Domestic credit facility | 37.0 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (8.0) |  |  | (8.6) |  |
| Total long-term debt | $ | 1,007.9 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,172.9 |  |  | $ | 980.6 |  |


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-21-000018:notes:97]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 240.7 |  |  | $ | 279.1 |  |
| Less: Beneficial interest transferred | (155.0) |  |  | — |  |
| Remaining amount available | $ | 85.7 |  |  | $ | 279.1 |  |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-21-000018:notes:98]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-21-000018:notes:99]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.63 | % |  | — | % |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-21-000018:notes:100]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-21-000018:notes:101]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-21-000018:notes:102]
[same as prior period, unchanged from 0001069202-20-000048:notes:124]

[0001069202-21-000018:notes:103]
|  |  | For the Three Months Ended March 31, |  |  |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2021 |  | 2020 |  |  |  |  |  |
| (Losses) Gains on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | 4.4 |  |  | $ | (1.2) |  |  |  |  |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax benefit |  | (1.0) |  |  | 0.3 |  |  |  |  |  |  | Provision for income taxes |
| Net of tax |  | $ | 3.4 |  |  | $ | (0.9) |  |  |  |  |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (2.2) |  |  | $ | (1.5) |  |  |  |  |  |  | Cost of goods sold; Selling, general and administrative expenses |
| Pension settlement |  | (0.7) |  |  | — |  |  |  |  |  |  | Pension settlement |
| Income tax benefit |  | 0.7 |  |  | 0.3 |  |  |  |  |  |  | Provision for income taxes |
| Net of tax |  | $ | (2.2) |  |  | $ | (1.2) |  |  |  |  |  |  |  |
| Total reclassifications from AOCL |  | $ | 1.2 |  |  | $ | (2.1) |  |  |  |  |  |  |  |

[0001069202-21-000018:notes:104]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2021 (in millions):

[0001069202-21-000018:notes:105]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2020 |  | $ | 8.2 |  |  | $ | (1.2) |  |  | $ | (82.7) |  |  | $ | (21.5) |  |  | $ | (97.2) |  |
| Other comprehensive income (loss) before reclassifications |  | 7.5 |  |  | — |  |  | (5.8) |  |  | (2.5) |  |  | (0.8) |  |
| Amounts reclassified from AOCL |  | (3.4) |  |  | — |  |  | 2.2 |  |  | — |  |  | (1.2) |  |
| Net other comprehensive income (loss) |  | 4.1 |  |  | — |  |  | (3.6) |  |  | (2.5) |  |  | (2.0) |  |
| Balance as of March 31, 2021 |  | $ | 12.3 |  |  | $ | (1.2) |  |  | $ | (86.3) |  |  | $ | (24.0) |  |  | $ | (99.2) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-21-000018:notes:106]
[same as prior period, unchanged from 0001069202-20-000048:notes:128]

[0001069202-21-000018:notes:107]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2021 were the same as those used at December 31, 2020.

[0001069202-21-000018:notes:108]
[same as prior period, unchanged from 0001069202-20-000048:notes:130]

[0001069202-21-000018:notes:109]
Derivatives were classified as Level 2 and primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives. We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, however, they were insignificant to the overall value of the derivatives.  Refer to Note 7 for more information related to our derivative instruments.

[0001069202-21-000018:notes:110]
[same as prior period, unchanged from 0001069202-20-000048:notes:132]

[0001069202-21-000018:notes:111]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-21-000018:notes:112]
[same as prior period, unchanged from 0001069202-20-000048:notes:134]

[0001069202-21-000018:notes:113]
|  | As of March 31, 2021 |  | As of December 31, 2020 |
| Senior unsecured notes | $ | 959.9 |  |  | $ | 971.6 |  |
