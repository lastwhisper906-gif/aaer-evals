# LII 8-K — 0001069202-26-000005 filed 2026-01-28

## item codes, every 8-K on or before 2026-02-17

- 2026-01-28 0001069202-26-000005 — 2.02, 9.01
- 2025-12-05 0001069202-25-000062 — 5.02, 9.01
- 2025-10-22 0001069202-25-000046 — 2.02, 9.01
- 2025-07-23 0001069202-25-000029 — 2.02, 9.01
- 2025-05-27 0001069202-25-000024 — 5.02, 5.07, 9.01
- 2025-05-14 0001069202-25-000022 — 1.01, 2.03, 9.01
- 2025-04-23 0001069202-25-000015 — 2.02, 9.01
- 2025-03-13 0001069202-25-000005 — 4.01, 9.01
- 2025-01-29 0001628280-25-002910 — 2.02, 9.01
- 2024-12-06 0001628280-24-050201 — 5.02
- 2024-10-23 0001628280-24-043349 — 2.02, 5.02, 7.01, 9.01
- 2024-07-24 0001628280-24-032683 — 2.02, 9.01
- 2024-05-23 0001628280-24-024875 — 5.02, 9.01
- 2024-05-20 0001628280-24-024385 — 5.07
- 2024-04-24 0001628280-24-017515 — 2.02, 9.01
- 2024-03-18 0001628280-24-011594 — 5.02, 9.01
- 2024-01-31 0001628280-24-002634 — 2.02, 9.01
- 2023-12-11 0001628280-23-041239 — 5.02, 9.01 — amendment of 0001628280-23-035187
- 2023-12-08 0001628280-23-041128 — 5.02
- 2023-10-26 0001628280-23-035187 — 2.02, 5.02, 7.01, 9.01
- 2023-09-21 0001628280-23-032729 — 8.01, 9.01
- 2023-09-15 0001628280-23-032385 — 1.01, 2.03, 8.01, 9.01
- 2023-09-12 0001628280-23-032078 — 8.01, 9.01
- 2023-08-28 0001628280-23-030777 — 1.01, 2.03, 9.01
- 2023-08-25 0001628280-23-030602 — 8.01, 9.01
- 2023-07-27 0001628280-23-025808 — 2.02, 9.01
- 2023-05-19 0001628280-23-019040 — 5.07
- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2026-02-17

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-26-000005:8k_2_02:1]
EX-99.1
2
lii-20251231xexx991pressre.htm
EX-99.1

[0001069202-26-000005:8k_2_02:2]
Document

[0001069202-26-000005:8k_2_02:3]
Exhibit 99.1

[0001069202-26-000005:8k_2_02:4]
Lennox Reports Fourth Quarter and Full Year 2025 Results;

[0001069202-26-000005:8k_2_02:5]
Provides Full Year 2026 Guidance

[0001069202-26-000005:8k_2_02:6]
____________________________________________________________________________

[0001069202-26-000005:8k_2_02:7]
Q4 Highlights

[0001069202-26-000005:8k_2_02:8]
(All comparisons are year-over-year, unless otherwise noted)
(Reflects change in accounting method from LIFO to FIFO, effective 4Q 2025)

[0001069202-26-000005:8k_2_02:9]
•Revenue $1.2 billion, down 11%

[0001069202-26-000005:8k_2_02:10]
•GAAP Operating Income $196 million  –  Segment profit down 16% to $212 million

[0001069202-26-000005:8k_2_02:11]
•GAAP diluted EPS $4.07  –  Adjusted diluted EPS down 22% to $4.45

[0001069202-26-000005:8k_2_02:12]
__________________________________________________________________________________

[0001069202-26-000005:8k_2_02:13]
2025 Full Year Highlights

[0001069202-26-000005:8k_2_02:14]
(All comparisons are year-over-year, unless otherwise noted)

[0001069202-26-000005:8k_2_02:15]
(Reflects change in accounting method from LIFO to FIFO, effective 4Q 2025)

[0001069202-26-000005:8k_2_02:16]
•Revenue $5.2 billion, down 3%

[0001069202-26-000005:8k_2_02:17]
•GAAP Operating Income $1 billion  –  Segment profit up 2% to $1.1 billion

[0001069202-26-000005:8k_2_02:18]
•GAAP diluted EPS $22.79  –  Adjusted diluted EPS up 2% to $23.16

[0001069202-26-000005:8k_2_02:19]
__________________________________________________________________________________

[0001069202-26-000005:8k_2_02:20]
DALLAS, January 28, 2026 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported fourth quarter financial results with $1.2 billion of revenue, $196 million of operating income, and $4.07 GAAP diluted earnings per share. Accompanying financial tables reflect the change in accounting method resulting from the transition from LIFO to FIFO accounting.

[0001069202-26-000005:8k_2_02:21]
Revenue declined 11% to $1.2 billion. Segment profit decreased 16% to $212 million. Segment margin was down 110 basis points to 17.7%. Adjusted diluted earnings per share decreased 22% to $4.45.

[0001069202-26-000005:8k_2_02:22]
“We are pleased with our performance in 2025 given industry headwinds. For the first time in its history, Lennox delivered annual margins over 20%, a particularly meaningful accomplishment driven by our cost reduction actions and mix benefits,” said CEO, Alok Maskara. “This is a direct reflection of the hard work and dedication of the Lennox team, and we remain confident that our strategy and recent investments position us to grow revenue and profits in 2026 as the industry normalizes.”

[0001069202-26-000005:8k_2_02:23]
Home Comfort Solutions revenue declined 21% in the fourth quarter, driven by expected channel destocking and continued softness in new construction sales. Broader macroeconomic uncertainty continued to temper both consumer and dealer activity which has led to an increase in deferred system replacements. Segment margins were down 220 basis points, primarily due to the impact of lower sales volumes and under absorption of manufacturing costs. In response to these headwinds, we took disciplined SG&A cost control actions and delivered favorable mix and price. We have a more constructive backdrop as we enter the new year with one‑step channel’s inventory destock nearly complete and two-step inventories expected to normalize by the second quarter.

[0001069202-26-000005:8k_2_02:24]
The Building Climate Solutions segment delivered 8% revenue growth in the fourth quarter, supported by steady parts acquisition, services demand, and a favorable mix. Margins expanded on improved factory productivity and disciplined cost control. Despite end markets below historical levels, the segment continued to gain momentum in emergency replacement positioning us for growth acceleration.

[0001069202-26-000005:8k_2_02:25]
FOURTH QUARTER 2025 FINANCIAL HIGHLIGHTS

[0001069202-26-000005:8k_2_02:26]
(All comparisons are year-over-year, unless otherwise noted)

[0001069202-26-000005:8k_2_02:27]
(Reflects change in accounting method from LIFO to FIFO, effective 4Q 2025)

[0001069202-26-000005:8k_2_02:28]
Revenue: $1.2 billion was down 11% driven by unfavorable sales volumes.

[0001069202-26-000005:8k_2_02:29]
Operating Income: $196 million, down 22%, with operating profit margin of 16.4%, down 220 basis points.

[0001069202-26-000005:8k_2_02:30]
Segment Profit: $212 million, down 16%, and segment profit margin of 17.7%, down 110 basis points primarily driven by $115 million decrease in sales volumes and $31 million product cost primarily related to recent inflationary impacts and factory under absorption. This was partially offset by $84 million of mix/price benefits and a $21 million improvement in SG&A and other costs.

[0001069202-26-000005:8k_2_02:31]
Net Income: $143 million, or $4.07 per share, compared to $202 million, or $5.64 per share, in the prior-year quarter.

[0001069202-26-000005:8k_2_02:32]
Adjusted Net Income: $155.8 million, or $4.45 per share, compared to $205 million, or $5.72 per share, in the prior-year quarter.

[0001069202-26-000005:8k_2_02:33]
Cash Flow: Operating cash flow was $406 million compared to $332 million in the prior-year quarter as inventory levels normalized in the quarter. Net capital expenditures were $29 million compared to $60 million in the prior-year quarter. Share repurchases totaled $150 million.

[0001069202-26-000005:8k_2_02:34]
Home Comfort Solutions: Business segment revenue was $700 million, down 21%. Segment profit was $137 million, down 29%, and segment margin was 19.6%, down 220 basis points. Segment profit decreased $56 million compared to the prior-year quarter. The decline was driven by a $102 million contraction in sales volumes, $29 million in product cost inflation and lower factory absorption. This was partially offset by $56 million in mix/price benefits and $19 million improvement of other costs, including selling expense net of freight and distribution expense.

[0001069202-26-000005:8k_2_02:35]
Building Climate Solutions: Business segment revenue was $495 million, up 8%. Segment profit was $115 million, up $11 million or 11%, and segment margin improved 50 basis points to 23.1%. This increase was driven by $27 million in mix/price benefits and $5 million improvement in selling expenses, net of acquisition and other expenses. This was partially offset by $13 million decrease in sales volume; $5 million from higher distribution and freight costs; and $3 million in product cost inflation and lower factory absorption.

[0001069202-26-000005:8k_2_02:36]
Corporate and Other: Corporate expenses were $40 million, down $4 million from the prior-year quarter.

[0001069202-26-000005:8k_2_02:37]
FULL YEAR 2025 FINANCIAL HIGHLIGHTS

[0001069202-26-000005:8k_2_02:38]
(All comparisons are year-over-year, unless otherwise noted)

[0001069202-26-000005:8k_2_02:39]
(Reflects change in accounting method from LIFO to FIFO, effective 4Q 2025)

[0001069202-26-000005:8k_2_02:40]
Revenue: $5.2 billion was down 3% driven by unfavorable sales volumes.

[0001069202-26-000005:8k_2_02:41]
Operating Income: $1 billion, flat to prior-year, with operating profit margin of 20.0%, up 50 basis points.

[0001069202-26-000005:8k_2_02:42]
Segment Profit: $1.1 billion, up 2%, and segment profit margin of 20.4%, up 90 basis points. Profit improvement can be attributed to $356 million of mix/price benefits, driven primarily by new product mix; and $56 million improvement in other costs, including selling expense. This was partially offset by $255 million decrease in sales volumes, $80 million of product cost primarily related to inflationary impacts, and $61 million of freight and distribution expense.

[0001069202-26-000005:8k_2_02:43]
Net Income: $806 million, or $22.79 per share, compared to $811 million, or $22.66 per share, in the prior-year.

[0001069202-26-000005:8k_2_02:44]
Adjusted Net Income: $819 million, or $23.16 per share, compared to $813 million, or $22.70 per share, in the prior-year.

[0001069202-26-000005:8k_2_02:45]
Cash Flow: Operating cash flow was $757 million compared to $946 million in the prior-year, primarily driven by excess inventory associated with refrigerant transition dynamics, channel destocking, and the deployment of emergency replacement product. Net capital expenditures were $117 million compared to $161 million in the prior-year. Share repurchases totaled $482 million.

[0001069202-26-000005:8k_2_02:46]
Home Comfort Solutions: Business segment revenue was $3.3 billion, down 7%. Segment profit was $729 million, down 4%, and segment margin was 21.8%, up 50 basis points. Segment profit decreased $32 million compared to the prior-year. The decline was driven by a $224 million contraction in sales volumes; $64 million in product cost inflation and factory productivity; and $47 million in freight and distribution expense. This was partially offset by $256 million in mix/price benefits and $47 million improvement of other costs, including selling expense.

[0001069202-26-000005:8k_2_02:47]
Building Climate Solutions: Business segment revenue was $1.9 billion, up 5%. Segment profit was $434 million, up $33 million or 8%, and segment margin improved 60 basis points to 23.4%. This increase was driven by $100 million in mix/price benefits. This was partially offset by $31 million in lower sales volumes, $16 million of product cost inflation net of factory productivity and $20 million from investment in distribution and selling as well as other inflationary impacts.

[0001069202-26-000005:8k_2_02:48]
Corporate and Other: Corporate expenses were $105 million, down $15 million from the prior-year.

[0001069202-26-000005:8k_2_02:49]
FULL YEAR 2026 GUIDANCE

[0001069202-26-000005:8k_2_02:50]
For full year 2026, revenue is anticipated to increase by approximately 6% to 7%, with growth from completed acquisitions contributing approximately 4%.

[0001069202-26-000005:8k_2_02:51]
Adjusted earnings per share is expected to be within the range of $23.50 to $25.00.

[0001069202-26-000005:8k_2_02:52]
Capital expenditures are projected to be approximately $250 million, and Free Cash Flow is estimated to fall within the range of $750 million to $850 million.

[0001069202-26-000005:8k_2_02:53]
CONFERENCE CALL INFORMATION

[0001069202-26-000005:8k_2_02:54]
A conference call to discuss the company’s fourth quarter and full year results, as well as 2026 full year guidance, will be held this morning at 8:30 a.m. Central Time. To participate in the earnings conference, please call 800-267-6316 (U.S.) or +1 203-518-9783 (international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ425. The conference call also will be webcast live on the company’s investor relations web site at investor.lennox.com. A replay of the conference call will be available until February 4, 2026, by calling toll-free 800-723-0607 (U.S.) or +1 402-220-2658 (international). The call will also be archived on the company's investor relations website at investor.lennox.com.

[0001069202-26-000005:8k_2_02:55]
ABOUT LENNOX

[0001069202-26-000005:8k_2_02:56]
Lennox (NYSE: LII) is a leader in energy-efficient climate-control solutions. We are committed to sustainability and creating comfortable, healthier environments for residential and commercial customers. Our innovative portfolio includes cooling, heating, indoor air quality, and refrigeration systems, along with a comprehensive range of HVAC parts, supplies, and services that support the full lifecycle of customer needs. Additional information on Lennox is available at Lennox.com or by contacting investor@lennox.com.

[0001069202-26-000005:8k_2_02:57]
FORWARD-LOOKING STATEMENTS & NON-GAAP FINANCIAL MEASURES

[0001069202-26-000005:8k_2_02:58]
For information concerning these and other risks and uncertainties, see LII’s publicly available filings with the Securities and Exchange Commission. LII disclaims any intention or obligation to update or revise any forward-looking statements, whether as a result of new information, future events or otherwise, except as required by law.

[0001069202-26-000005:8k_2_02:59]
A reconciliation of non-GAAP financial measures appearing in this document to financial measures prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP) are included in the Annex to this document.

[0001069202-26-000005:8k_2_02:60]
This document includes forward-looking statements regarding segment profit, adjusted net income, adjusted diluted earnings per share, and free cash flow, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, changes in environmental liabilities, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on LII’s full year GAAP financial results.

[0001069202-26-000005:8k_2_02:61]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-26-000005:8k_2_02:62]
Consolidated Statements of Operations

[0001069202-26-000005:8k_2_02:63]
(Unaudited)

[0001069202-26-000005:8k_2_02:64]
| (Amounts in millions, except per share data) | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 1,195.0 |  |  | $ | 1,345.0 |  |  | $ | 5,195.3 |  |  | $ | 5,341.3 |  |
| Cost of goods sold | 805.7 |  |  | 884.1 |  |  | 3,460.5 |  |  | 3,563.8 |  |
| Gross profit | 389.3 |  |  | 460.9 |  |  | 1,734.8 |  |  | 1,777.5 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 175.2 |  |  | 207.0 |  |  | 681.4 |  |  | 730.6 |  |
| Losses and other expenses, net | 12.6 |  |  | 2.4 |  |  | 12.0 |  |  | 12.9 |  |
| Restructuring charges | 6.8 |  |  | — |  |  | 6.8 |  |  | — |  |
| (Gain) loss on sale from previous dispositions | (0.9) |  |  | 3.1 |  |  | (0.9) |  |  | 1.5 |  |
| Income from equity method investments | (0.2) |  |  | (1.8) |  |  | (6.0) |  |  | (7.9) |  |
| Operating income | 195.8 |  |  | 250.2 |  |  | 1,041.5 |  |  | 1,040.4 |  |
| Pension settlements | 0.1 |  |  | — |  |  | 0.4 |  |  | 0.4 |  |
| Interest expense, net | 15.9 |  |  | 5.5 |  |  | 40.9 |  |  | 38.7 |  |
| Other expense, net | 1.1 |  |  | 0.4 |  |  | 3.4 |  |  | 1.9 |  |
| Net income before income taxes | 178.7 |  |  | 244.3 |  |  | 996.8 |  |  | 999.4 |  |
| Provision for income taxes | 36.2 |  |  | 42.4 |  |  | 191.0 |  |  | 188.3 |  |
| Net income | $ | 142.5 |  |  | $ | 201.9 |  |  | $ | 805.8 |  |  | $ | 811.1 |  |
| Earnings per share – Basic(1): | $ | 4.08 |  |  | $ | 5.67 |  |  | $ | 22.89 |  |  | $ | 22.78 |  |
| Earnings per share – Diluted(1): | $ | 4.07 |  |  | $ | 5.64 |  |  | $ | 22.79 |  |  | $ | 22.66 |  |
| Weighted Average Number of Shares Outstanding - Basic | 34.9 |  |  | 35.6 |  |  | 35.2 |  |  | 35.6 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 35.1 |  |  | 35.8 |  |  | 35.4 |  |  | 35.8 |  |

[0001069202-26-000005:8k_2_02:65]
(1) Amounts may not recalculate due to rounding.

[0001069202-26-000005:8k_2_02:66]
Note: The 2024 amounts are adjusted to reflect the accounting method change from LIFO to FIFO.

[0001069202-26-000005:8k_2_02:67]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |
| Segment Net Sales and Profit |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |

[0001069202-26-000005:8k_2_02:68]
| (Amounts in millions) | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net Sales |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 699.8 |  |  | $ | 887.4 |  |  | $ | 3,343.4 |  |  | $ | 3,577.1 |  |
| Building Climate Solutions | 495.2 |  |  | 457.6 |  |  | 1,851.9 |  |  | 1,764.2 |  |
| Corporate and other | — |  | — |  | — |  | — |
| Total net sales | $ | 1,195.0 |  |  | $ | 1,345.0 |  |  | $ | 5,195.3 |  |  | $ | 5,341.3 |  |
| Segment Profit(1) |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 137.4 |  |  | $ | 193.4 |  |  | $ | 728.5 |  |  | $ | 760.5 |  |
| Building Climate Solutions | 114.5 |  |  | 103.6 |  |  | 434.2 |  |  | 401.7 |  |
| Corporate and other | (39.9) |  |  | (43.7) |  |  | (105.0) |  |  | (120.3) |  |
| Total segment profit | 212.0 |  |  | 253.3 |  |  | 1,057.7 |  |  | 1,041.9 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Restructuring charges | 6.8 |  |  | — |  |  | 6.8 |  |  | — |  |
| (Gain) loss on sale from previous dispositions | (0.9) |  |  | 3.1 |  |  | (0.9) |  |  | 1.5 |  |
| Acquisition costs(2) | 10.3 |  |  | — |  |  | 10.3 |  |  | — |  |
| Operating income | $ | 195.8 |  |  | $ | 250.2 |  |  | $ | 1,041.5 |  |  | $ | 1,040.4 |  |

[0001069202-26-000005:8k_2_02:69]
(1) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-26-000005:8k_2_02:70]
•Restructuring charges,

[0001069202-26-000005:8k_2_02:71]
•Gain (loss) on sale of previous dispositions, and;

[0001069202-26-000005:8k_2_02:72]
•Acquisition costs

[0001069202-26-000005:8k_2_02:73]
(2) Recorded in Losses and other expenses, net in the accompanying Consolidated Statement of Operations.

[0001069202-26-000005:8k_2_02:74]
Note: The 2024 amounts are adjusted to reflect the accounting method change from LIFO to FIFO.

[0001069202-26-000005:8k_2_02:75]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-26-000005:8k_2_02:76]
Consolidated Balance Sheets

[0001069202-26-000005:8k_2_02:77]
(Unaudited)

[0001069202-26-000005:8k_2_02:78]
| (Amounts in millions, except shares and par values) | As of December 31, 2025 |  | As of December 31, 2024 |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 34.2 |  |  | $ | 415.1 |  |
| Short-term investments | 0.5 |  |  | 7.2 |  |
| Accounts and notes receivable, net of allowances of $8.5 and $17.8 in 2025 and 2024, respectively | 578.8 |  |  | 661.1 |  |
| Inventories, net | 1,152.6 |  |  | 853.0 |  |
| Other current assets | 137.7 |  |  | 96.0 |  |
| Total current assets | 1,903.8 |  |  | 2,032.4 |  |
| Restricted cash | 18.5 |  |  | — |  |
| Property, plant and equipment, net of accumulated depreciation of $1,043.9 and $956.8 in 2025 and 2024, respectively | 887.2 |  |  | 800.1 |  |
| Right-of-use assets from operating leases | 356.3 |  |  | 327.2 |  |
| Goodwill | 497.2 |  |  | 220.0 |  |
| Deferred income taxes | 12.9 |  |  | 75.1 |  |
| Other assets, net | 405.9 |  |  | 165.2 |  |
| Total assets | $ | 4,081.8 |  |  | $ | 3,620.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current Liabilities: |  |  |  |
| Accounts payable | $ | 438.0 |  |  | $ | 490.0 |  |
| Accrued expenses | 374.2 |  |  | 435.4 |  |
| Income taxes payable | 46.4 |  |  | — |  |
| Commercial paper | 226.0 |  |  | — |  |
| Current maturities of long-term debt | 18.3 |  |  | 314.5 |  |
| Current operating lease liabilities | 88.9 |  |  | 73.4 |  |
| Total current liabilities | 1,191.8 |  |  | 1,313.3 |  |
| Long-term debt | 1,144.1 |  |  | 833.1 |  |
| Long-term operating lease liabilities | 293.4 |  |  | 267.6 |  |
| Pensions | 18.7 |  |  | 18.9 |  |
| Other liabilities | 270.7 |  |  | 225.0 |  |
| Total liabilities | 2,918.7 |  |  | 2,657.9 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' equity: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,243.0 |  |  | 1,213.3 |  |
| Retained earnings | 4,891.1 |  |  | 4,262.7 |  |
| Accumulated other comprehensive loss | (48.5) |  |  | (93.7) |  |
| Treasury stock, at cost, 52,374,147 shares and 51,573,986 shares for 2025 and 2024, respectively | (4,923.4) |  |  | (4,421.1) |  |
| Total stockholders' equity | 1,163.1 |  |  | 962.1 |  |
| Total liabilities and stockholders' equity | $ | 4,081.8 |  |  | $ | 3,620.0 |  |

[0001069202-26-000005:8k_2_02:79]
Note: The 2024 amounts are adjusted to reflect the accounting method change from LIFO to FIFO.

[0001069202-26-000005:8k_2_02:80]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-26-000005:8k_2_02:81]
Consolidated Statements of Cash Flows

[0001069202-26-000005:8k_2_02:82]
(Unaudited)

[0001069202-26-000005:8k_2_02:83]
| (Amounts in millions) | For the Years Ended December 31, |
|  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 805.8 |  |  | $ | 811.1 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| (Gain) loss on sale from previous dispositions | (0.9) |  |  | 1.5 |  |
| Income from equity method investments | (6.0) |  |  | (7.9) |  |
| Dividends from affiliates | 6.6 |  |  | 3.0 |  |
| Restructuring charges, net of cash paid | 3.3 |  |  | — |  |
| Provision for credit (gains) losses | (1.9) |  |  | 8.0 |  |
| Unrealized losses (gains), net on derivative contracts | 4.8 |  |  | (2.3) |  |
| Stock-based compensation expense | 29.1 |  |  | 28.5 |  |
| Depreciation and amortization | 112.5 |  |  | 95.1 |  |
| Deferred income taxes | 20.2 |  |  | (23.2) |  |
| Pension expense | 4.3 |  |  | 4.2 |  |
| Pension contributions | (8.0) |  |  | (9.3) |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |
| Accounts and notes receivable | 108.9 |  |  | (80.4) |  |
| Inventories | (228.2) |  |  | (15.6) |  |
| Other current assets | (27.8) |  |  | (8.3) |  |
| Accounts payable | (74.2) |  |  | 115.0 |  |
| Accrued expenses | (69.5) |  |  | 30.4 |  |
| Income taxes payable and receivable, net | 58.6 |  |  | (21.9) |  |
| Leases, net | 12.1 |  |  | 5.5 |  |
| Other, net | 7.9 |  |  | 12.3 |  |
| Net cash provided by operating activities | 757.6 |  |  | 945.7 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 1.4 |  |  | 2.5 |  |
| Purchases of property, plant and equipment | (118.8) |  |  | (163.6) |  |
| Net proceeds from previous disposition | — |  |  | (7.7) |  |
| Acquisitions, net of cash | (545.0) |  |  | 1.8 |  |
| Proceeds from (purchases of) investments and other | 6.8 |  |  | (7.4) |  |
| Net cash used in investing activities | (655.6) |  |  | (174.4) |  |
| Cash flows from financing activities: |  |  |  |
| Commercial paper borrowings | 1,368.8 |  |  | 424.1 |  |
| Commercial paper payments | (1,142.8) |  |  | (574.1) |  |
| Borrowings from debt arrangements | 300.0 |  |  | 156.7 |  |
| Payments on debt arrangements | (18.9) |  |  | (194.3) |  |
| Payment of senior unsecured notes | (300.0) |  |  | — |  |
| Borrowings from credit facility | 200.0 |  |  | — |  |
| Payments on credit facility | (200.0) |  |  | — |  |
| Payments of deferred financing costs | (2.3) |  |  | — |  |
| Proceeds from employee stock purchases | 4.0 |  |  | 4.5 |  |
| Repurchases of common stock | (482.3) |  |  | (53.6) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (19.2) |  |  | (21.6) |  |
| Cash dividends paid | (173.0) |  |  | (160.3) |  |
| Net cash used in financing activities | (465.7) |  |  | (418.6) |  |
| (Decrease) increase in cash and cash equivalents and restricted cash | (363.7) |  |  | 352.7 |  |
| Effect of exchange rates on cash and cash equivalents and restricted cash | 1.3 |  |  | 1.7 |  |
| Cash and cash equivalents and restricted cash, beginning of period | 415.1 |  |  | 60.7 |  |
| Cash and cash equivalents and restricted cash, end of period | $ | 52.7 |  |  | $ | 415.1 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 46.5 |  |  | $ | 45.2 |  |
| Income taxes paid (net of refunds) | $ | 103.8 |  |  | $ | 231.9 |  |

[0001069202-26-000005:8k_2_02:84]
Note: The 2024 amounts are adjusted to reflect the accounting method change from LIFO to FIFO.

[0001069202-26-000005:8k_2_02:85]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit (loss) presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company's business trends and operating performance. |
| Reconciliation of Net income, a GAAP measure, to Adjusted net income, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |  |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |
|  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  |  |
| Net income, a GAAP measure | $ | 142.5 |  | $ | 4.07 |  |  | $ | 201.9 |  | $ | 5.64 |  |  | $ | 805.8 |  | $ | 22.79 |  |  | $ | 811.1 |  | $ | 22.66 |  |  |  |
| Restructuring charges | 5.1 |  | 0.15 |  |  | — |  | — |  |  | 5.1 |  | 0.14 |  |  | — |  | — |  |  |  |
| (Gain) loss on sale from previous dispositions | (0.7) |  | (0.02) |  |  | 3.1 |  | 0.08 |  |  | (0.7) |  | (0.02) |  |  | 1.5 |  | 0.04 |  |  |  |
| Acquisition costs (a) | 8.9 |  | 0.25 |  |  | — |  | — |  |  | 8.9 |  | 0.25 |  |  | — |  | — |  |  |  |
| Adjusted net income, a non-GAAP measure | $ | 155.8 |  | $ | 4.45 |  |  | $ | 205.0 |  | $ | 5.72 |  |  | $ | 819.1 |  | $ | 23.16 |  |  | $ | 812.6 |  | $ | 22.70 |  |  |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |
| Note: The 2024 amounts are adjusted to reflect the accounting method change from LIFO to FIFO. |  |  |  |  |  |  |  |  |

[0001069202-26-000005:8k_2_02:86]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net cash provided by operating activities | $ | 405.9 |  |  | $ | 332.4 |  |  | $ | 757.6 |  |  | $ | 945.7 |  |
| Purchases of property, plant and equipment | (29.2) |  |  | (60.2) |  |  | (118.8) |  |  | (163.6) |  |
| Proceeds from the disposal of property, plant and equipment | 0.3 |  |  | 0.6 |  |  | 1.4 |  |  | 2.5 |  |
| Free cash flow, a Non-GAAP measure | $ | 377.0 |  |  | $ | 272.8 |  |  | $ | 640.2 |  |  | $ | 784.6 |  |
