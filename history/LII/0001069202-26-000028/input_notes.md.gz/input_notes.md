# LII notes — 0001069202-26-000028


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001069202-26-000028:notes:1]
Portions of the registrant’s 2026 Definitive Proxy Statement to be filed with the Securities and Exchange Commission in connection with the registrant’s 2026 Annual Meeting of Stockholders to be held on May 21, 2026 are incorporated by reference into Part III of this report.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001069202-26-000028:notes:2]
We manage cybersecurity risk through three core teams: cybersecurity engineering, data privacy, and a security operation center. These teams are responsible for overseeing data safety during new system and infrastructure deployments, maintaining appropriate cybersecurity controls, and monitoring, documenting and investigating any anomalies affecting employees, suppliers, and customers. Our IT security controls are designed to align with the NIST (National Institute of Standards and Technology) standards and are tested on an ongoing basis. These controls and procedures include processes that oversee and identify cybersecurity risks associated with third-party service providers that we engage, as described below. For instance, we conduct risk and compliance assessments of third-party service providers that request access to our information assets. To support our internal risk management structure, we use third-party specialists to monitor for emerging threats, conduct vulnerability scans and analysis including simulated hacker attacks, and audit our cybersecurity framework. We also maintain an information security risk insurance policy in the event of a security breach. Our internal audit function also performs independent testing on aspects of the operations of our cybersecurity program and the supporting controls based upon its risk-based internal audit plan and reports the results of these audits in its periodic reports to the Audit Committee.

[0001069202-26-000028:notes:3]
Leadership receives training on how to respond to ransomware events and participates in breach simulations at least once a year. Additionally, employees throughout the organization support LII’s risk management efforts by participating in mandatory cybersecurity training at least once a year, ongoing awareness campaigns, and quarterly simulated phishing attempts.

[0001069202-26-000028:notes:4]
To our knowledge, LII’s business strategy, results of operations and financial condition have not been materially affected by risks from cybersecurity threats within the last three years, including as a result of previously identified cybersecurity incidents. However, we cannot provide assurance that they will not be materially affected in the future by such risks or any future material incidents. For more information on our cybersecurity related risks, see Item 1A, “Risk Factors.”


## cyd:CybersecurityRiskProcessForInformingBoardCommitteeOrSubcommitteeResponsibleForOversightTextBlock

[0001069202-26-000028:notes:5]
Our Chief Technology Officer is ultimately responsible for overseeing all cybersecurity management, including the three core teams mentioned above, and reports to the Board of Directors twice a year on our cybersecurity tactical responses and strategic roadmap. The entire Board of Directors reviews significant cybersecurity risks and works with the Audit Committee to address enterprise risk management processes and policies. 
At the management level, our Data Protection & Cybersecurity Steering Committee (“DPCSC”) meets on a quarterly basis. The DPCSC includes representatives from communications, ethics and compliance, human resources, information technology, corporate audit, legal, risk, privacy, and sourcing. This committee is responsible for overseeing LII’s data protection and cybersecurity policies and procedures. These cybersecurity policies and procedures include an IT security and privacy incident response plan to notify the appropriate parties, including our Chief Technology Officer, our Disclosure Committee, and our Board of Directors, in a timely manner.


## cyd:CybersecurityRiskManagementExpertiseOfManagementResponsibleTextBlock

[0001069202-26-000028:notes:6]
Our Chief Technology Officer has served in the role since 2008, and has more than 15 years of experience in developing and executing large enterprise data privacy and cyber security roadmaps at publicly-traded companies. He holds undergraduate and graduate degrees in engineering. Our Vice President, Information Technology, has served in the role since 2003, and has more than 35 years of cybersecurity experience. He holds an undergraduate degree in computer science.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-26-000028:notes:7]
2. Summary of Significant Accounting Policies:

[0001069202-26-000028:notes:8]
Principles of Consolidation

[0001069202-26-000028:notes:9]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries. All intercompany transactions, profits and balances have been eliminated.

[0001069202-26-000028:notes:10]
Cash and Cash Equivalents

[0001069202-26-000028:notes:11]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents. Cash and cash equivalents consisted primarily of bank deposits.

[0001069202-26-000028:notes:12]
Restricted Cash Equivalents

[0001069202-26-000028:notes:13]
Restricted cash equivalents relate to amounts restricted for payment of certain indemnities and is recorded within long-term assets on the accompanying Consolidated Balance Sheets.

[0001069202-26-000028:notes:14]
Short-term Investments

[0001069202-26-000028:notes:15]
Short-term investments include all investments, exclusive of cash equivalents, with a stated maturity date of one year or less from the balance sheet date.

[0001069202-26-000028:notes:16]
Accounts and Notes Receivable

[0001069202-26-000028:notes:17]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts. The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management’s judgment on our ability to collect. Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions. We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management’s review of our ability to collect, as noted above. We have no significant concentrations of credit risk within our accounts and notes receivable.

[0001069202-26-000028:notes:18]
Inventories

[0001069202-26-000028:notes:19]
Inventory costs include material, labor, and capitalized overhead. Inventories are valued at the lower of cost or net realizable value with costs determined primarily using standard cost, which approximates costs determined on a first-in, first-out (“FIFO”) basis. See Note 9 for more information on our inventories. In the fourth quarter of 2025, we changed the method of accounting for certain of our inventories from last-in-first-out (“LIFO”) to FIFO. Refer to “Change in Accounting” below for further discussion.

[0001069202-26-000028:notes:20]
Property, Plant and Equipment

[0001069202-26-000028:notes:21]
Property, plant and equipment is stated at cost, net of accumulated depreciation. Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001069202-26-000028:notes:22]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-26-000028:notes:23]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 40 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 5 years |
| Vehicles | 3 to 10 years |

[0001069202-26-000028:notes:24]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable. To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets. If the expected future undiscounted cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value. See Note 9 for additional information on our property, plant and equipment. Based on the expected fair value of the consideration to be received from the sale of our European commercial HVAC and refrigeration businesses, net of our costs to sell, we recorded an impairment on assets held for sale during the third quarter of 2023 which included a $22.6 million impairment of property, plant and equipment.

[0001069202-26-000028:notes:25]
Goodwill and Intangible Assets

[0001069202-26-000028:notes:26]
Goodwill represents the excess of cost over fair value of assets from acquired businesses. Goodwill is not amortized, but is reviewed for impairment annually during the third quarter and whenever events or changes in circumstances indicate the asset may be impaired. See Note 9 for additional information on our goodwill.

[0001069202-26-000028:notes:27]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a quantitative goodwill impairment test. As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities as a whole and for each reporting unit.

[0001069202-26-000028:notes:28]
If a quantitative goodwill impairment test is determined to be necessary, we estimate reporting unit fair values using a combination of the discounted cash flow approach and a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. The market approach is based on objective evidence of market values. In the third quarter of 2023, we recorded a $2.3 million impairment of goodwill related to our agreement to sell our European commercial HVAC and refrigeration businesses which was included in our impairment on assets held for sale.

[0001069202-26-000028:notes:29]
Intangible assets such as customer relationships, non-compete agreements and trade names with finite lives are amortized based on the pattern in which the economic benefits of the intangible assets are utilized. If a pattern of economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, then straight-line amortization may be used.

[0001069202-26-000028:notes:30]
The range of useful lives approximates the following (in years):

[0001069202-26-000028:notes:31]
| Customer relationships | 2 to 20 years |
| Non-compete agreements | Contracted term |
| Trade names | 2 to 20 years |

[0001069202-26-000028:notes:32]
We assess the recoverability of the carrying amount of our intangible assets with finite lives whenever events or changes in circumstances indicate that the carrying value of the asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001069202-26-000028:notes:33]
Product Warranties

[0001069202-26-000028:notes:34]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from 1 to 20 years to customers for certain components such as compressors or heat exchangers. For select products, we used to provide limited lifetime warranties. A liability for estimated warranty expense is recorded in cost of goods sold on the date that revenue is recognized. Our estimates of future warranty costs are determined by product category. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. In most cases, the estimated units to be repaired under warranty are multiplied by the estimated cost of replacement parts to determine the estimated future warranty cost. We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations. Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience. Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability. See Note 5 for more information on our estimated future warranty costs.

[0001069202-26-000028:notes:35]
Pensions and Post-retirement Benefits

[0001069202-26-000028:notes:36]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees. We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheets. Changes in the funded status are recognized in the year in which the changes occur through Accumulated other comprehensive loss (“AOCL”). Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-26-000028:notes:37]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans. Should actual results differ from management’s estimates, revisions to the benefit plan assets and liabilities would be required. See Note 10 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-26-000028:notes:38]
Self-Insurance

[0001069202-26-000028:notes:39]
Self-insurance expense and liabilities are actuarially determined based primarily on our historical claims information, industry factors, and trends. The self-insurance liabilities as of December 31, 2025 represent our best estimate of the future payments to be made on reported and unreported losses for 2025 and prior years. The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims. To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change. See Note 5 for additional information on our self-insured risks and liabilities.

[0001069202-26-000028:notes:40]
Derivatives

[0001069202-26-000028:notes:41]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates. We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months. See Note 9 for more information on our derivatives.

[0001069202-26-000028:notes:42]
Leases

[0001069202-26-000028:notes:43]
We lease certain real and personal property under non-cancelable leases including real estate, IT equipment, fleet vehicles and manufacturing and distribution equipment. At inception of the lease, we determine a lease exists if the contract conveys the right to control an identified asset for a period of time in exchange for consideration. Control is considered to exist when the lessee has the right to obtain substantially all the economic benefits from the use of an identified asset as well as the right to direct the use of the asset. If a contract is considered to be a lease, we recognize a lease liability based on the present value of the future minimum lease payments and a right-of-use asset. For contracts that are 12 months or less, we do not recognize a right-of-use asset or liability. We do not separate non-lease components from the lease components to which they relate and account for the combined lease and non-lease components as a single lease component.

[0001069202-26-000028:notes:44]
Income Taxes

[0001069202-26-000028:notes:45]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date. Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 12 for more information related to income taxes.

[0001069202-26-000028:notes:46]
Revenue Recognition

[0001069202-26-000028:notes:47]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction. Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes. Certain customers in our smaller operations, primarily outside of North America, have shipping terms where control does not transfer until the product is delivered to the customer. For these transactions, revenue is recognized on the date that the product is received and accepted by such customers. We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience. Our historical rates of return are insignificant as a percentage of sales. We also recognize revenue net of sales taxes. We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers. See Note 8 for more information on our revenue recognition practices.

[0001069202-26-000028:notes:48]
Cost of Goods Sold

[0001069202-26-000028:notes:49]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense, and freight and distribution costs.

[0001069202-26-000028:notes:50]
Selling, General and Administrative Expenses

[0001069202-26-000028:notes:51]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other SG&A related costs such as insurance, travel, non-production depreciation, and rent.

[0001069202-26-000028:notes:52]
Stock-Based Compensation

[0001069202-26-000028:notes:53]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs based on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known. For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period. See Note 15 for more information.

[0001069202-26-000028:notes:54]
Translation of Foreign Currencies

[0001069202-26-000028:notes:55]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date. Revenue and expenses are translated at weighted average exchange rates during the year. Unrealized translation gains and losses are included in AOCL in the accompanying Consolidated Balance Sheets. Transaction gains and losses are included in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.

[0001069202-26-000028:notes:56]
Use of Estimates

[0001069202-26-000028:notes:57]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-26-000028:notes:58]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-26-000028:notes:59]
Change in Accounting

[0001069202-26-000028:notes:60]
In the fourth quarter of 2025, we changed the method of accounting for all inventory previously on LIFO to FIFO. Inventories valued using the LIFO method comprised approximately 75% of our consolidated inventories before deducting the LIFO reserve as of December 31, 2024. We believe the FIFO method is preferable because it more closely matches the physical flow of materials through purchasing, receiving, warehousing, production and order fulfillment, it results in a more consistent method to value inventory across the Company, and it improves comparability with industry peers. This change increased Retained Earnings by $106.6 million as of January 1, 2023. The effects of the change in accounting principle have been retrospectively applied to all periods presented.

[0001069202-26-000028:notes:61]
The effect of the changes made to our Consolidated Statements of Operations was as follows (in millions):

[0001069202-26-000028:notes:62]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |
|  | As Reported |  | Effect of Change |  | As Adjusted |  | As Reported |  | Effect of Change |  | As Adjusted |
| Net sales | $ | 5,341.3 |  |  | $ | — |  |  | $ | 5,341.3 |  |  | $ | 4,981.9 |  |  | $ | — |  |  | $ | 4,981.9 |  |
| Cost of goods sold | 3,569.4 |  |  | (5.6) |  |  | 3,563.8 |  |  | 3,434.1 |  |  | (1.4) |  |  | 3,432.7 |  |
| Gross profit | 1,771.9 |  |  | 5.6 |  |  | 1,777.5 |  |  | 1,547.8 |  |  | 1.4 |  |  | 1,549.2 |  |
| Operating income | 1,034.8 |  |  | 5.6 |  |  | 1,040.4 |  |  | 790.1 |  |  | 1.4 |  |  | 791.5 |  |
| Income before income taxes | 993.8 |  |  | 5.6 |  |  | 999.4 |  |  | 737.5 |  |  | 1.4 |  |  | 738.9 |  |
| Provision for income taxes | 186.9 |  |  | 1.4 |  |  | 188.3 |  |  | 147.4 |  |  | 0.3 |  |  | 147.7 |  |
| Net income | $ | 806.9 |  |  | $ | 4.2 |  |  | $ | 811.1 |  |  | $ | 590.1 |  |  | $ | 1.1 |  |  | $ | 591.2 |  |
| Earnings per share - Basic | $ | 22.67 |  |  | $ | 0.11 |  |  | $ | 22.78 |  |  | $ | 16.61 |  |  | $ | 0.04 |  |  | $ | 16.65 |  |
| Earnings per share - Diluted | $ | 22.54 |  |  | $ | 0.12 |  |  | $ | 22.66 |  |  | $ | 16.54 |  |  | $ | 0.04 |  |  | $ | 16.58 |  |

[0001069202-26-000028:notes:63]
The effect of the changes made to our Consolidated Balance Sheets was as follows (in millions):

[0001069202-26-000028:notes:64]
|  | As of December 31, |
|  | 2024 |  | 2023 |
|  | As Reported |  | Effect of Change |  | As Adjusted |  | As Reported |  | Effect of Change |  | As Adjusted |
| Inventories, net | $ | 704.8 |  |  | $ | 148.2 |  |  | $ | 853.0 |  |  | $ | 699.1 |  |  | $ | 142.7 |  |  | $ | 841.8 |  |
| Total current assets | $ | 1,884.2 |  |  | $ | 148.2 |  |  | $ | 2,032.4 |  |  | $ | 1,433.5 |  |  | $ | 142.7 |  |  | $ | 1,576.2 |  |
| Total assets | $ | 3,471.8 |  |  | $ | 148.2 |  |  | $ | 3,620.0 |  |  | $ | 2,798.3 |  |  | $ | 142.7 |  |  | $ | 2,941.0 |  |
| Other liabilities(1) | $ | 188.7 |  |  | $ | 36.3 |  |  | $ | 225.0 |  |  | $ | 168.2 |  |  | $ | 35.0 |  |  | $ | 203.2 |  |
| Total liabilities | $ | 2,621.6 |  |  | $ | 36.3 |  |  | $ | 2,657.9 |  |  | $ | 2,513.0 |  |  | $ | 35.0 |  |  | $ | 2,548.0 |  |
| Retained earnings | $ | 4,150.8 |  |  | $ | 111.9 |  |  | $ | 4,262.7 |  |  | $ | 3,506.2 |  |  | $ | 107.7 |  |  | $ | 3,613.9 |  |
| Total stockholders’ equity | $ | 850.2 |  |  | $ | 111.9 |  |  | $ | 962.1 |  |  | $ | 285.3 |  |  | $ | 107.7 |  |  | $ | 393.0 |  |
| Total liabilities and stockholders' equity | $ | 3,471.8 |  |  | $ | 148.2 |  |  | $ | 3,620.0 |  |  | $ | 2,798.3 |  |  | $ | 142.7 |  |  | $ | 2,941.0 |  |

[0001069202-26-000028:notes:65]
(1) The accounting change impacts Deferred tax liabilities within Other liabilities in our Consolidated Balance Sheets.

[0001069202-26-000028:notes:66]
The effect of the changes made to our Consolidated Statements of Cash Flows (in millions):

[0001069202-26-000028:notes:67]
|  | As of December 31, |
|  | 2024 |  | 2023 |
|  | As Reported |  | Effect of Change |  | As Adjusted |  | As Reported |  | Effect of Change |  | As Adjusted |
| Net Income | $ | 806.9 |  |  | $ | 4.2 |  |  | $ | 811.1 |  |  | $ | 590.1 |  |  | $ | 1.1 |  |  | $ | 591.2 |  |
| Inventories | $ | (10.1) |  |  | $ | (5.5) |  |  | $ | (15.6) |  |  | $ | 11.1 |  |  | $ | (1.4) |  |  | $ | 9.7 |  |
| Deferred income taxes | $ | (24.5) |  |  | $ | 1.3 |  |  | $ | (23.2) |  |  | $ | (26.0) |  |  | $ | 0.3 |  |  | $ | (25.7) |  |

[0001069202-26-000028:notes:68]
The following tables compare the amounts currently reported to the amounts that would have been reported under LIFO (in millions):

[0001069202-26-000028:notes:69]
|  | For the Year Ended December 31, 2025 |
|  | As Reported |  | Inventory Calculated Using LIFO |  | Effect of Change |
| Consolidated Statement of Operations |  |  |  |  |  |
| Cost of goods sold | $ | 3,460.5 |  |  | $ | 3,481.2 |  |  | $ | (20.7) |  |
| Income before income taxes | $ | 996.8 |  |  | $ | 976.1 |  |  | $ | 20.7 |  |
| Provision for income taxes | $ | 191.0 |  |  | $ | 186.0 |  |  | $ | 5.0 |  |
| Net income | $ | 805.8 |  |  | $ | 790.1 |  |  | $ | 15.7 |  |
| Earnings per share - Basic | $ | 22.89 |  |  | $ | 22.45 |  |  | $ | (0.44) |  |
| Earnings per share - Diluted | $ | 22.79 |  |  | $ | 22.32 |  |  | $ | (0.47) |  |
|  | As of December 31, 2025 |
|  | As Reported |  | Inventory Calculated Using LIFO |  | Effect of Change |
| Consolidated Balance Sheet |  |  |  |  |  |
| Inventories | $ | 1,152.6 |  |  | $ | 983.4 |  |  | $ | (169.2) |  |
| Total assets | $ | 4,081.8 |  |  | $ | 3,912.6 |  |  | $ | (169.2) |  |
| Other liabilities(1) | $ | 270.7 |  |  | $ | 229.3 |  |  | $ | (41.4) |  |
| Retained earnings | $ | 4,891.1 |  |  | $ | 4,763.3 |  |  | $ | (127.8) |  |
| Total liabilities and stockholders’ equity | $ | 4,081.8 |  |  | $ | 3,912.6 |  |  | $ | (169.2) |  |

[0001069202-26-000028:notes:70]
Changes in Accounting Standards Effective for Future Reporting Periods

[0001069202-26-000028:notes:71]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40), which will require public entities to disclose additional information about specific expense categories in the notes to the financial statements at interim and annual reporting periods. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027. We are currently evaluating the impact of this standard on our financial statements.

[0001069202-26-000028:notes:72]
Recently Adopted Accounting Pronouncements

[0001069202-26-000028:notes:73]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which updates income tax disclosure requirements, primarily through enhanced disclosures regarding income rate reconciliation and income taxes paid. This is effective for fiscal years beginning after December 15, 2024. ASU 2023-09 requires that, on an annual basis, entities disclose specific categories in the rate reconciliation and additional information for reconciling items that meet a certain quantitative threshold. The amendment also requires enhanced disclosures around taxes paid and income tax expense by federal, state and foreign jurisdictions. We adopted the standard on a prospective basis in the current period. See Note 12 for more information.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001069202-26-000028:notes:74]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-26-000028:notes:75]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Land | $ | 46.4 |  |  | $ | 30.3 |  |
| Buildings and improvements | 475.1 |  |  | 427.8 |  |
| Machinery and equipment | 1,192.2 |  |  | 1,056.6 |  |
| Finance leases | 108.4 |  |  | 84.9 |  |
| Construction in progress and equipment not yet in service | 109.0 |  |  | 157.3 |  |
| Total | 1,931.1 |  |  | 1,756.9 |  |
| Less accumulated depreciation | (1,043.9) |  |  | (956.8) |  |
| Property, plant and equipment, net | $ | 887.2 |  |  | $ | 800.1 |  |


## us-gaap:LesseeLeasesPolicyTextBlock

[0001069202-26-000028:notes:76]
We lease certain real and personal property under non-cancelable leases. Approximately 81% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-26-000028:notes:77]
3. Reportable Business Segments:

[0001069202-26-000028:notes:78]
Description of Segments

[0001069202-26-000028:notes:79]
We operate in two reportable business segments of the HVACR industry. Our segments are organized primarily by the nature of the products and services we provide. The following table describes each segment:

[0001069202-26-000028:notes:80]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Home Comfort Solutions |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Building Climate Solutions |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products, curb, curb adapters, drop box diffusers, HVAC recycling and salvage service, condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, replacement parts and supplies |  | Light Commercial; Food Preservation; Non-Food Industry |  | United StatesCanada |

[0001069202-26-000028:notes:81]
Prior to January 1, 2023, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses. We continue to invest in our Heatcraft Worldwide Refrigeration business which is included in the Building Climate Solutions segment. The consolidation of our Heatcraft business within the Building Climate Solutions segment provides the opportunity to leverage synergies and create long-term growth opportunities by integrating entities with similar products, end consumers and financial performance metrics under the same management. The change in segment reporting better aligns with how the businesses are managed and evaluated given the change in portfolio.

[0001069202-26-000028:notes:82]
In the fourth quarter of 2023, we successfully completed the divestiture of our European operations, which until that time, were presented with the Corporate and Other segment.

[0001069202-26-000028:notes:83]
Segment Data

[0001069202-26-000028:notes:84]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources. We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation in the table below details the items excluded.

[0001069202-26-000028:notes:85]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results. There were no significant intercompany eliminations for the periods presented.

[0001069202-26-000028:notes:86]
The chief operating decision maker uses segment profit or loss from operations before interest and income taxes, excluding certain items, to allocate resources (including employees, financial, or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances in segment profit or loss and its individual components on a monthly basis when evaluating segment performance and making decisions about allocating resources to the segments.

[0001069202-26-000028:notes:87]
The Company’s chief operating decision maker is Alok Maskara, Chief Executive Officer.

[0001069202-26-000028:notes:88]
Key financial information for each segment is shown below (in millions):

[0001069202-26-000028:notes:89]
|  | Home Comfort Solutions |  | Business Climate Solutions |  | Corporate and Other(1) |  | Total |
| For the Year Ended December 31, 2025 |  |  |  |  |  |  |  |
| Net Sales(2) | $ | 3,343.4 |  |  | $ | 1,851.9 |  |  | $ | — |  |  | $ | 5,195.3 |  |
| Cost of Goods Sold | 2,280.7 |  |  | 1,179.8 |  |  | — |  |  | 3,460.5 |  |
| Selling, general and administrative | 349.6 |  |  | 240.4 |  |  | 91.4 |  |  | 681.4 |  |
| Other (income) expense(4) | (15.4) |  |  | (2.5) |  |  | 13.6 |  |  | (4.3) |  |
| Segment profit (loss)(5) | $ | 728.5 |  |  | $ | 434.2 |  |  | $ | (105.0) |  |  | $ | 1,057.7 |  |
| For the Year Ended December 31, 2024 |  |  |  |  |  |  |  |
| Net Sales(2) | $ | 3,577.1 |  |  | $ | 1,764.2 |  |  | $ | — |  |  | $ | 5,341.3 |  |
| Cost of Goods Sold(3) | 2,425.3 |  |  | 1,137.8 |  |  | 0.7 |  |  | 3,563.8 |  |
| Selling, general and administrative | 393.8 |  |  | 229.9 |  |  | 107.0 |  |  | 730.6 |  |
| Other (income) expense(4) | (2.5) |  |  | (5.2) |  |  | 12.7 |  |  | 5.0 |  |
| Segment profit (loss)(3)(5) | $ | 760.5 |  |  | $ | 401.7 |  |  | $ | (120.3) |  |  | $ | 1,041.9 |  |
| For the Year Ended December 31, 2023 |  |  |  |  |  |  |  |
| Net Sales(2) | $ | 3,222.9 |  |  | $ | 1,511.4 |  |  | $ | 247.6 |  |  | $ | 4,981.9 |  |
| Cost of Goods Sold(3) | 2,275.9 |  |  | 977.9 |  |  | 178.9 |  |  | 3,432.7 |  |
| Selling, general and administrative | 350.2 |  |  | 197.5 |  |  | 157.8 |  |  | 705.5 |  |
| Other (income) expense(4) | (14.8) |  |  | (4.8) |  |  | 4.8 |  |  | (14.8) |  |
| Segment profit (loss)(3)(5) | $ | 611.6 |  |  | $ | 340.8 |  |  | $ | (93.9) |  |  | $ | 858.5 |  |

[0001069202-26-000028:notes:90]
(1) The Corporate and Other segment included our European portfolio. In the fourth quarter of 2023, we completed the divestiture of our European operations.

[0001069202-26-000028:notes:91]
(2) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-26-000028:notes:92]
(3) Amounts are adjusted to reflect the accounting method change from LIFO to FIFO. The adjustments for Home Comfort Solutions were $0.8 million and $1.4 million for the years ended December 31, 2024 and 2023, respectively. The adjustment for Business Climate Solutions was $4.8 million for the year ended December 31, 2024 and a nominal adjustment was made for the year ended December 31, 2023.

[0001069202-26-000028:notes:93]
(4) Other (income) expense is primarily comprised of income from equity method investments and losses and other expenses, net.

[0001069202-26-000028:notes:94]
(5) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-26-000028:notes:95]
•The following items in Losses and other expenses, net:

[0001069202-26-000028:notes:96]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001069202-26-000028:notes:97]
◦Environmental liabilities and special litigation charges

[0001069202-26-000028:notes:98]
◦Other items, net, and

[0001069202-26-000028:notes:99]
◦Acquisition costs

[0001069202-26-000028:notes:100]
•Restructuring charges;

[0001069202-26-000028:notes:101]
•Impairment on assets held for sale; and

[0001069202-26-000028:notes:102]
•(Gain) loss on sale from previous dispositions.

[0001069202-26-000028:notes:103]
The reconciliations of segment profit to Operating income and Net income before income taxes are presented below (in millions):

[0001069202-26-000028:notes:104]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Total segment profit(1)(2) | $ | 1,057.7 |  |  | $ | 1,041.9 |  |  | $ | 858.5 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| (Gain) loss on sale from previous dispositions | (0.9) |  |  | 1.5 |  |  | (14.1) |  |
| Impairment of assets held for sale | — |  |  | — |  |  | 63.2 |  |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) | — |  |  | — |  |  | 14.8 |  |
| Restructuring charges | 6.8 |  |  | — |  |  | 3.1 |  |
| Acquisition costs | 10.3 |  |  | — |  |  | — |  |
| Operating income | 1,041.5 |  |  | 1,040.4 |  |  | 791.5 |  |
| Reconciliation to income before income taxes: |  |  |  |  |  |
| Pension settlements | 0.4 |  |  | 0.4 |  |  | 0.8 |  |
| Interest expense, net | 40.9 |  |  | 38.7 |  |  | 51.7 |  |
| Other expense, net | 3.4 |  |  | 1.9 |  |  | 0.1 |  |
| Income before income taxes | $ | 996.8 |  |  | $ | 999.4 |  |  | $ | 738.9 |  |

[0001069202-26-000028:notes:105]
(1) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-26-000028:notes:106]
◦Environmental liabilities and special litigation charges,

[0001069202-26-000028:notes:107]
•(Gain) loss on sale of businesses.

[0001069202-26-000028:notes:108]
(2) The 2024 and 2023 amounts are adjusted to reflect the accounting method change from LIFO to FIFO.

[0001069202-26-000028:notes:109]
Total assets by segment are shown below (in millions):

[0001069202-26-000028:notes:110]
|  | As of December 31, |
|  | 2025 |  | 2024As Adjusted |  | 2023As Adjusted |
| Total Assets: |  |  |  |  |  |
| Home Comfort Solutions | $ | 1,971.0 |  |  | $ | 1,721.4 |  |  | $ | 1,549.3 |  |
| Building Climate Solutions | 1,746.4 |  |  | 1,105.5 |  |  | 1,032.1 |  |
| Corporate and Other | 364.4 |  |  | 793.1 |  |  | 359.6 |  |
| Total assets | $ | 4,081.8 |  |  | $ | 3,620.0 |  |  | $ | 2,941.0 |  |

[0001069202-26-000028:notes:111]
The assets in Corporate and Other primarily consist of cash, property, plant and equipment and short-term investments and deferred tax assets as well as the assets in the European portfolio which was disposed of in the fourth quarter of 2023. Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-26-000028:notes:112]
Total capital expenditures by segment are shown below (in millions):

[0001069202-26-000028:notes:113]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Capital Expenditures: |  |  |  |  |  |
| Home Comfort Solutions | $ | 49.0 |  |  | $ | 78.1 |  |  | $ | 59.1 |  |
| Building Climate Solutions | 37.7 |  |  | 57.8 |  |  | 119.6 |  |
| Corporate and Other | 32.1 |  |  | 27.7 |  |  | 71.5 |  |
| Total capital expenditures | $ | 118.8 |  |  | $ | 163.6 |  |  | $ | 250.2 |  |

[0001069202-26-000028:notes:114]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-26-000028:notes:115]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Depreciation and Amortization: |  |  |  |  |  |
| Home Comfort Solutions | $ | 46.9 |  |  | $ | 39.0 |  |  | $ | 35.3 |  |
| Building Climate Solutions | 36.0 |  |  | 25.6 |  |  | 19.4 |  |
| Corporate and Other | 29.6 |  |  | 30.5 |  |  | 31.3 |  |
| Total depreciation and amortization | $ | 112.5 |  |  | $ | 95.1 |  |  | $ | 86.0 |  |

[0001069202-26-000028:notes:116]
The income from equity method investments is shown below (in millions):

[0001069202-26-000028:notes:117]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Home Comfort Solutions | $ | 5.4 |  |  | $ | 4.4 |  |  | $ | 5.5 |  |
| Building Climate Solutions | 0.6 |  |  | 3.5 |  |  | 3.0 |  |
| Total income from equity method investments | $ | 6.0 |  |  | $ | 7.9 |  |  | $ | 8.5 |  |

[0001069202-26-000028:notes:118]
Geographic Information

[0001069202-26-000028:notes:119]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-26-000028:notes:120]
|  | As of December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 607.4 |  |  | $ | 537.3 |  |  | $ | 487.1 |  |
| Mexico | 269.2 |  |  | 254.0 |  |  | 228.7 |  |
| Canada | 4.2 |  |  | 2.9 |  |  | 2.2 |  |
| Other international | 6.4 |  |  | 5.9 |  |  | 2.4 |  |
| Total Property, plant and equipment, net | $ | 887.2 |  |  | $ | 800.1 |  |  | $ | 720.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-26-000028:notes:121]
The following table describes each segment:


## us-gaap:EarningsPerShareTextBlock

[0001069202-26-000028:notes:122]
4. Earnings Per Share:

[0001069202-26-000028:notes:123]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period. Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-26-000028:notes:124]
The computations of basic and diluted earnings per share were as follows (in millions, except per share data):

[0001069202-26-000028:notes:125]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024As Adjusted |  | 2023As Adjusted |
| Net income | $ | 805.8 |  |  | $ | 811.1 |  |  | $ | 591.2 |  |
| Weighted-average shares outstanding – basic | 35.2 |  |  | 35.6 |  |  | 35.5 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Weighted-average shares outstanding – diluted | $ | 35.4 |  |  | $ | 35.8 |  |  | $ | 35.7 |  |
| Earnings per share - Basic(1): | $ | 22.89 |  |  | $ | 22.78 |  |  | $ | 16.65 |  |
| Earnings per share - Diluted(1): | $ | 22.79 |  |  | $ | 22.66 |  |  | $ | 16.58 |  |

[0001069202-26-000028:notes:126]
(1) Amounts may not recalculate due to rounding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-26-000028:notes:127]
The components of lease expense were as follows (in millions):

[0001069202-26-000028:notes:128]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Finance lease cost: |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 19.3 |  |  | $ | 15.4 |  |  | $ | 14.5 |  |
| Interest on lease liabilities | 2.9 |  |  | 2.7 |  |  | 1.7 |  |
| Operating lease cost | 96.1 |  |  | 83.3 |  |  | 74.1 |  |
| Short-term lease cost | 6.4 |  |  | 5.0 |  |  | 5.3 |  |
| Variable lease cost | 31.0 |  |  | 27.6 |  |  | 26.8 |  |
| Total lease cost | $ | 155.7 |  |  | $ | 134.0 |  |  | $ | 122.4 |  |
| Other information |  |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 90.6 |  |  | $ | 76.6 |  |  | $ | 70.5 |  |
| Financing cash flows from finance leases | $ | 21.8 |  |  | $ | 17.3 |  |  | $ | 15.8 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 36.2 |  |  | $ | 26.1 |  |  | $ | 21.3 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 107.7 |  |  | $ | 177.1 |  |  | $ | 56.4 |  |

[0001069202-26-000028:notes:129]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Finance lease right-of-use assets(1) | $ | 62.1 |  |  | $ | 48.1 |  |
| Operating lease right-of-use assets | $ | 356.3 |  |  | $ | 327.2 |  |
| Finance lease liability, current(2) | $ | 18.3 |  |  | $ | 14.9 |  |
| Finance lease liability, non-current(3) | $ | 50.6 |  |  | $ | 39.5 |  |
| Operating lease liability, current | $ | 88.9 |  |  | $ | 73.4 |  |
| Operating lease liability, non-current | $ | 293.4 |  |  | $ | 267.6 |  |
| Weighted-average remaining lease term – finance leases | 3.3 years |  | 3.3 years |
| Weighted-average remaining lease term – operating leases | 5.6 years |  | 5.5 years |
| Weighted-average discount rate – finance leases | 4.70 | % |  | 4.73 | % |
| Weighted-average discount rate – operating leases | 4.76 | % |  | 4.67 | % |
| (1) Recorded in Property, plant and equipment in Consolidated Balance Sheets |
| (2) Recorded in Current maturities of long-term debt in Consolidated Balance Sheets |
| (3) Recorded in Long-term debt in Consolidated Balance Sheets |

[0001069202-26-000028:notes:130]
Future annual minimum lease payments and finance lease commitments as of December 31, 2025 were as follows (in millions).

[0001069202-26-000028:notes:131]
|  | Operating Leases |  | Finance Leases |
| 2026 | $ | 98.9 |  |  | $ | 21.1 |  |
| 2027 | 80.8 |  |  | 17.0 |  |
| 2028 | 68.7 |  |  | 13.2 |  |
| 2029 | 58.1 |  |  | 19.9 |  |
| 2030 | 40.7 |  |  | 3.1 |  |
| Thereafter | 83.0 |  |  | — |  |
| Total minimum lease payments | $ | 430.2 |  |  | $ | 74.3 |  |
| Less imputed interest | (47.9) |  |  | (5.4) |  |
| Present value of minimum payments | $ | 382.3 |  |  | $ | 68.9 |  |

[0001069202-26-000028:notes:132]
As of December 31, 2025, the Company has an additional operating lease commitment of $63.5 million for a distribution facility that has not yet commenced and is not included in the amounts in the table above.

[0001069202-26-000028:notes:133]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024. The property consists of an office building of approximately 192,000 square feet, land and related improvements. In December 2023, we purchased the property for $41.2 million.

[0001069202-26-000028:notes:134]
Environmental

[0001069202-26-000028:notes:135]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties, properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal. We are aware of contamination at some facilities; however, we do not believe that any future remediation related to those facilities will be material to our results of operations. Total environmental accruals are included in Accrued expenses and Other liabilities on the accompanying Consolidated Balance Sheets. Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-26-000028:notes:136]
Product Warranties and Product Related Contingencies

[0001069202-26-000028:notes:137]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-26-000028:notes:138]
Total product warranty liabilities are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-26-000028:notes:139]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Accrued expenses | $ | 53.1 |  |  | $ | 49.1 |  |
| Other liabilities | 114.1 |  |  | 109.4 |  |
| Total product warranty liabilities | $ | 167.2 |  |  | $ | 158.4 |  |

[0001069202-26-000028:notes:140]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2025 and 2024 were as follows (in millions):

[0001069202-26-000028:notes:141]
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Payments made in 2024 | (41.2) |  |
| Changes resulting from issuance of new warranties | 59.0 |  |
| Changes in estimates associated with pre-existing liabilities | (1.4) |  |
| Changes in foreign currency translation rates and other | (0.8) |  |
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Payments made in 2025 | (46.9) |  |
| Changes resulting from issuance of new warranties | 52.5 |  |
| Changes in estimates associated with pre-existing liabilities | 2.7 |  |
| Changes in foreign currency translation rates and other | 0.5 |  |
| Total warranty liability as of December 31, 2025 | $ | 167.2 |  |

[0001069202-26-000028:notes:142]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures. We use large deductible insurance plans, written through third-party insurance providers, for workers’ compensation/employers’ liability, general liability, product liability and auto liability. We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors’ and officers’ liability, property damage and certain other insurance programs. For directors’ and officers’ liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits. We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-26-000028:notes:143]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.

[0001069202-26-000028:notes:144]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-26-000028:notes:145]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Accrued expenses | $ | 6.7 |  |  | $ | 4.6 |  |
| Other liabilities | 15.8 |  |  | 15.6 |  |
| Total self-insurance liabilities | $ | 22.5 |  |  | $ | 20.2 |  |

[0001069202-26-000028:notes:146]
Litigation

[0001069202-26-000028:notes:147]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-26-000028:notes:148]
It is management’s opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-26-000028:notes:149]
6. Stock Repurchases:

[0001069202-26-000028:notes:150]
Our Board of Directors have authorized a total of $5 billion to repurchase shares of our common stock (collectively referred to as the “Share Repurchase Plans”), including a $1.0 billion share repurchase authorization in May 2025. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. Such repurchases may also be made in compliance with Rule 10b5-1 trading plans entered into by us, which would permit common stock to be repurchased when the Company might otherwise be precluded from doing so under insider trading laws or self-imposed trading restrictions. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of December 31, 2025, $1,009.6 million of shares are available for repurchase under the Share Repurchase Plans.

[0001069202-26-000028:notes:151]
We repurchased 0.9 million shares at an aggregate cost, inclusive of fees, of $482.3 million in 2025 and 0.1 million shares for $54.2 million in 2024. No shares were repurchased in 2023. The shares repurchased are held as treasury shares.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-26-000028:notes:152]
7. Restructuring Charges:

[0001069202-26-000028:notes:153]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses. Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period. Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 3.

[0001069202-26-000028:notes:154]
We recorded restructuring charges of $6.8 million in 2025 to realize SG&A and distribution efficiencies and $3.1 million in 2023 to reorganize or remove duplicative headcount and infrastructure. There were no restructuring charges in 2024. 
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-26-000028:notes:155]
8. Revenue Recognition:

[0001069202-26-000028:notes:156]
The following table disaggregates our revenue by business segment by geography to provide information as to the major sources of revenue. See Note 3 for additional description of our reportable business segments and the products and services being sold in each segment.

[0001069202-26-000028:notes:157]
|  | For the Year Ended December 31, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 3,097.4 |  |  | $ | 1,724.5 |  |  | $ | — |  |  | $ | 4,821.9 |  |
| Canada | 246.0 |  |  | 127.4 |  |  | — |  |  | 373.4 |  |
| Total | $ | 3,343.4 |  |  | $ | 1,851.9 |  |  | $ | — |  |  | $ | 5,195.3 |  |

[0001069202-26-000028:notes:158]
|  | For the Year Ended December 31, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 3,346.0 |  |  | $ | 1,675.8 |  |  | $ | — |  |  | $ | 5,021.8 |  |
| Canada | 231.1 |  |  | 88.4 |  |  | — |  |  | 319.5 |  |
| Total | $ | 3,577.1 |  |  | $ | 1,764.2 |  |  | $ | — |  |  | $ | 5,341.3 |  |

[0001069202-26-000028:notes:159]
|  | For the Year Ended December 31, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 3,001.3 |  |  | $ | 1,415.6 |  |  | $ | — |  |  | $ | 4,416.9 |  |
| Canada | 221.6 |  |  | 95.8 |  |  | — |  |  | 317.4 |  |
| International | — |  |  | — |  |  | 247.6 |  |  | 247.6 |  |
| Total | $ | 3,222.9 |  |  | $ | 1,511.4 |  |  | $ | 247.6 |  |  | $ | 4,981.9 |  |

[0001069202-26-000028:notes:160]
For our businesses that provide services, revenue is recognized at the time services are completed. Our Building Climate Solutions segment also provides sales, installation, maintenance and repair services under fixed-price contracts. Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided. We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty. Revenue from extended warranties is insignificant. See Note 5 for more information on product warranties.

[0001069202-26-000028:notes:161]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America. These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox Stores or to independent distributors. In the fourth quarter of 2025, we acquired Sealed Unit Parts Buyer, Inc. (“Supco”), which sells HVAC parts and supplies with HVACR applications. For the years ended December 31, 2025, 2024 and 2023, direct sales represented 76%, 74% and 75% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-26-000028:notes:162]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the U.S. and Canada. AES manufactures curb, curb adapters, drop box diffusers and also offers HVAC recycling and salvage services, as well as focusing on multi-family HVAC replacement for expired mechanical assets. In the fourth quarter of 2025, we acquired Duro Dyne Buyer, Inc. (“Duro Dyne”), which manufactures and sells HVAC parts and supplies such as air distribution accessories, switches and controls, and other engineered components and accessories with HVACR applications. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the years ended December 31, 2025, 2024 and 2023, equipment sales represented 80%, 80% and 86% of revenues, respectively, and the remainder of our revenue was generated from our service business.

[0001069202-26-000028:notes:163]
Corporate and Other - In Europe, we manufactured and marketed equipment for the global commercial refrigeration markets. We also manufactured and sold unitary heating and cooling products and applied systems. In the fourth quarter of 2023, we successfully completed the divestiture of our European operations.

[0001069202-26-000028:notes:164]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers. We record these customer discounts and incentives as a reduction of sales when the sales are recorded. For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to SG&A expenses. All other advertising, promotions and marketing costs are expensed as incurred.

[0001069202-26-000028:notes:165]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less. Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less. These costs are included in SG&A expenses. ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any

[0001069202-26-000028:notes:166]
significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception. We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18. We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001069202-26-000028:notes:167]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed. There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed. Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheets.

[0001069202-26-000028:notes:168]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue. Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheets. The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.

[0001069202-26-000028:notes:169]
Net contract assets (liabilities) consisted of the following:

[0001069202-26-000028:notes:170]
|  | December 31, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 1.7 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (10.5) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (10.3) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (19.1) |  |  | $ | (12.2) |  |  |  |  |  |

[0001069202-26-000028:notes:171]
For the years ended December 31, 2025, 2024, and 2023, we recognized revenue of $4.6 million, $7.4 million and $7.7 million related to our contract liabilities at January 1, 2025, 2024 and 2023, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025, 2024 and 2023.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-26-000028:notes:172]
The components of inventories are as follows (in millions):

[0001069202-26-000028:notes:173]
|  | As of December 31, |
|  | 2025 |  | 2024(1) |
| Finished goods | $ | 719.1 |  |  | $ | 431.3 |  |
| Work in process | 7.5 |  |  | 11.0 |  |
| Raw materials and parts | 426.0 |  |  | 410.7 |  |
| Total inventories, net | 1,152.6 |  |  | 853.0 |  |

[0001069202-26-000028:notes:174]
(1) Through our assessment of our change in method of inventory valuation, we identified immaterial errors in our 2024 and 2023 disclosures of current costs of inventory and the excess of current cost over LIFO cost. We have corrected previously reported amounts for those immaterial errors resulting in an increase in total current cost and the excess of current cost over LIFO cost of $8.6 million and $8.7 million in 2024 and 2023, respectively. Such disclosure errors had no impact on the inventory balances reflected in our Consolidated Balance Sheets.

[0001069202-26-000028:notes:175]
Obsolete and slow-moving inventories were $73.5 million and $55.8 million as of December 31, 2025 and December 31, 2024, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-26-000028:notes:176]
Goodwill

[0001069202-26-000028:notes:177]
The changes in the carrying amount of goodwill in 2025 and 2024, in total and by segment, are summarized in the table below (in millions):

[0001069202-26-000028:notes:178]
| Segment: | Balance at December 31, 2023 (1) |  | Goodwill adjustment (2) |  |  | Balance at December 31, 2024 |  |  |  |  |  | Goodwill from business acquisition (3) |  | Balance at December 31, 2025 |
| Home Comfort Solutions | $ | 26.1 |  |  | $ | — |  |  |  | $ | 26.1 |  |  |  |  |  |  | $ | 60.9 |  |  | $ | 87.0 |  |
| Building Climate Solutions | 196.0 |  |  | (2.1) |  |  |  | 193.9 |  |  |  |  |  |  | 216.3 |  |  | 410.2 |  |
| Corporate and Other | — |  |  | — |  |  |  | — |  |  |  |  |  |  | — |  |  | — |  |
|  | $ | 222.1 |  |  | $ | (2.1) |  |  |  | $ | 220.0 |  |  |  |  |  |  | $ | 277.2 |  |  | $ | 497.2 |  |

[0001069202-26-000028:notes:179]
(1) The goodwill balances in the table above are presented net of accumulated impairment charges of $37.3 million, all of which related to impairments in periods prior to 2023.

[0001069202-26-000028:notes:180]
(2) On October 25, 2023, we announced the acquisition of AES. In connection with this acquisition, $40.4 million of goodwill was recorded in 2023 and included in the Building Climate Solutions reporting unit. In the first and fourth quarters of 2024, we made adjustments to our purchase price allocation of AES that resulted in a $2.1 million reduction of goodwill.

[0001069202-26-000028:notes:181]
(3) On October 15, 2025, we announced the acquisition of Duro Dyne and Supco. In connection with this acquisition, $277.2 million of goodwill was recorded, of which $216.3 million was included in the Building Climate Solutions reporting unit and $60.9 million was included in the Home Comfort Solutions reporting unit. Duro Dyne is included in our Business Climate Solutions segment and Supco is included in our Home Comfort Solutions segment. See Note 17 for additional information on the Duro Dyne and Supco acquisition.
A qualitative review of impairment indicators was performed in 2025 for the Home Comfort Solutions and Building Climate Solutions segments. No impairment charges were recorded in 2025, 2024 or 2023, except to the extent of respective goodwill impaired in connection with the disposition of our European operations.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-26-000028:notes:182]
No impairment charges were recorded in 2025 or 2024.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-26-000028:notes:183]
Accrued Expenses

[0001069202-26-000028:notes:184]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-26-000028:notes:185]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Accrued rebates and promotions | $ | 111.9 |  |  | $ | 128.2 |  |
| Accrued compensation and benefits | 86.3 |  |  | 130.0 |  |
| Accrued warranties | 53.1 |  |  | 49.1 |  |
| Accrued sales, use, property and VAT taxes | 16.9 |  |  | 18.0 |  |
| Accrued freight | 9.4 |  |  | 12.9 |  |
| Accrued asbestos reserves | 18.6 |  |  | 15.8 |  |
| Accrued interest | 10.0 |  |  | 11.2 |  |
| Accrued pension | 1.4 |  |  | 6.4 |  |
| Derivative contracts | 1.2 |  |  | 5.7 |  |
| Deferred revenue | 10.5 |  |  | 5.0 |  |
| Self insurance reserves | 6.7 |  |  | 4.6 |  |
| Other | 48.2 |  |  | 48.5 |  |
| Total Accrued expenses | $ | 374.2 |  |  | $ | 435.4 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-26-000028:notes:186]
Objectives and Strategies for Using Derivative Instruments

[0001069202-26-000028:notes:187]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes. Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase. We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates. This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-26-000028:notes:188]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest. To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001069202-26-000028:notes:189]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001069202-26-000028:notes:190]
Cash Flow Hedges

[0001069202-26-000028:notes:191]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through June 2027 and February 2026, respectively. We currently have cash flow hedge contracts with a notional amount of 86.4 million pounds of aluminum and copper. Unrealized gains or losses from our cash flow hedges are included in AOCL and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.

[0001069202-26-000028:notes:192]
We recorded the following amounts related to our cash flow hedges in AOCL (in millions):

[0001069202-26-000028:notes:193]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Unrealized (gains) losses, net on unsettled contracts | $ | (23.3) |  |  | $ | 2.0 |  |
| Income tax expense (benefit) | 5.4 |  |  | (0.6) |  |
| Unrealized (gains) losses included in AOCL, net of tax (1) | $ | (17.9) |  |  | $ | 1.4 |  |

[0001069202-26-000028:notes:194]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $17.1 million of derivative gains into earnings within the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-26-000028:notes:195]
Expenses included in our Consolidated Statements of Operations

[0001069202-26-000028:notes:196]
Below is information about expenses included in Selling, general and administrative expenses in our Consolidated Statements of Operations (in millions):

[0001069202-26-000028:notes:197]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Research and development | $ | 103.4 |  |  | $ | 93.6 |  |  | $ | 94.0 |  |
| Advertising, promotions and marketing | 34.4 |  |  | 49.7 |  |  | 39.5 |  |
| Cooperative advertising expenditures | 21.8 |  |  | 22.5 |  |  | 28.7 |  |


## us-gaap:ScheduleOfOtherOperatingCostAndExpenseByComponentTextBlock

[0001069202-26-000028:notes:198]
Losses and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-26-000028:notes:199]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Realized losses on settled future contracts | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |
| Foreign currency exchange (gains) losses | (10.5) |  |  | 7.7 |  |  | (4.3) |  |
| Loss (gain) on disposal of fixed assets | 1.1 |  |  | (2.1) |  |  | (0.5) |  |
| Other operating (income) loss | 0.2 |  |  | 0.5 |  |  | (1.6) |  |
| Net change in unrealized gains on unsettled futures contracts | — |  |  | — |  |  | (0.1) |  |
| Environmental liabilities and special litigation charges | 10.9 |  |  | 6.8 |  |  | 15.6 |  |
| Acquisition costs | 10.3 |  |  | — |  |  | — |  |
| Other items, net | — |  |  | — |  |  | (0.7) |  |
| Losses and other expenses, net (pre-tax) | $ | 12.0 |  |  | $ | 12.9 |  |  | $ | 8.5 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001069202-26-000028:notes:200]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-26-000028:notes:201]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Interest expense, net of capitalized interest | $ | 46.4 |  |  | $ | 44.1 |  |  | $ | 56.0 |  |
| Less: Interest income | 5.5 |  |  | 5.4 |  |  | 4.3 |  |
| Interest expense, net | $ | 40.9 |  |  | $ | 38.7 |  |  | $ | 51.7 |  |

[0001069202-26-000028:notes:202]
Our provision for income taxes consisted of the following (in millions):

[0001069202-26-000028:notes:203]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024As Adjusted |  | 2023As Adjusted |
| Current: |  |  |  |  |  |
| Federal | $ | 109.0 |  |  | $ | 159.2 |  |  | $ | 132.1 |  |
| State | 34.9 |  |  | 33.7 |  |  | 26.6 |  |
| Foreign | 27.0 |  |  | 20.0 |  |  | 14.5 |  |
| Total current | 170.9 |  |  | 212.9 |  |  | 173.2 |  |
| Deferred: |  |  |  |  |  |
| Federal | 23.2 |  |  | (19.6) |  |  | (22.2) |  |
| State | (3.5) |  |  | (4.0) |  |  | (4.9) |  |
| Foreign | 0.4 |  |  | (1.0) |  |  | 1.6 |  |
| Total deferred | 20.1 |  |  | (24.6) |  |  | (25.5) |  |
| Total provision for income taxes | $ | 191.0 |  |  | $ | 188.3 |  |  | $ | 147.7 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-26-000028:notes:204]
Losses and Other Expenses, net


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-26-000028:notes:205]
10. Employee Benefit Plans: 
Many of our defined benefit pension and profit sharing plans have been frozen and replaced with defined contribution plans. We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen. We also have several active defined benefit plans that provide benefits based on years of service. Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.

[0001069202-26-000028:notes:206]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.

[0001069202-26-000028:notes:207]
Defined Contribution Plans

[0001069202-26-000028:notes:208]
We recorded the following contributions to our defined contribution plans (in millions):

[0001069202-26-000028:notes:209]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Contributions to defined contribution plans | $ | 25.8 |  |  | $ | 26.9 |  |  | $ | 22.5 |  |

[0001069202-26-000028:notes:210]
Pension and Post-retirement Benefit Plans

[0001069202-26-000028:notes:211]
Benefit Obligations, Fair Value of Plan Assets, Funded Status, and Balance Sheet Position

[0001069202-26-000028:notes:212]
The following tables set forth amounts recognized in our financial statements and the plans’ funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-26-000028:notes:213]
|  | Pension Benefits |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Accumulated benefit obligation | $ | 162.0 |  |  | $ | 161.4 |  |  |  |  |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 162.1 |  |  | $ | 179.1 |  |  |  |  |  |
| Service cost | 1.1 |  |  | 1.5 |  |  |  |  |  |
| Interest cost | 8.4 |  |  | 8.5 |  |  |  |  |  |
| Actuarial loss (gain) | 4.4 |  |  | (9.9) |  |  |  |  |  |
| Effect of exchange rates | 1.2 |  |  | (0.9) |  |  |  |  |  |
| Adjustment upon sale of businesses | — |  |  | (1.2) |  |  |  |  |  |
| Settlements | (7.5) |  |  | (9.5) |  |  |  |  |  |
| Benefits paid | (7.6) |  |  | (5.5) |  |  |  |  |  |
| Benefit obligation at end of year | $ | 162.1 |  |  | $ | 162.1 |  |  |  |  |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 145.0 |  |  | $ | 156.5 |  |  |  |  |  |
| Actual return on plan assets | 8.5 |  |  | (4.9) |  |  |  |  |  |
| Employer contributions | 7.5 |  |  | 9.3 |  |  |  |  |  |
| Effect of exchange rates | 1.4 |  |  | (0.9) |  |  |  |  |  |
| Plan settlements | (7.5) |  |  | (9.5) |  |  |  |  |  |
| Benefits paid | (7.6) |  |  | (5.5) |  |  |  |  |  |
| Fair value of plan assets at end of year | 147.3 |  |  | 145.0 |  |  |  |  |  |
| Funded status / net amount recognized | $ | (14.8) |  |  | $ | (17.1) |  |  |  |  |  |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Non-current assets | $ | 4.5 |  |  | $ | 8.2 |  |  |  |  |  |
| Current liability | (1.4) |  |  | (6.4) |  |  |  |  |  |
| Non-current liability(1) | (17.9) |  |  | (18.9) |  |  |  |  |  |
| Net amount recognized | $ | (14.8) |  |  | $ | (17.1) |  |  |  |  |  |

[0001069202-26-000028:notes:214]
(1) This amount does not include the $0.8 million in non-current pension liability assumed as part of the Duro Dyne acquisition.

[0001069202-26-000028:notes:215]
Plans with Benefit Obligations in Excess of Plan Assets

[0001069202-26-000028:notes:216]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 19.3 |  |  | $ | 25.3 |  |
| Accumulated benefit obligation | 19.2 |  |  | 24.6 |  |
| Fair value of plan assets | — |  |  | — |  |

[0001069202-26-000028:notes:217]
Net Periodic Benefit Cost

[0001069202-26-000028:notes:218]
Our U.S.-based pension plans comprised approximately 88% of the projected benefit obligation and 85% of plan assets as of December 31, 2025.

[0001069202-26-000028:notes:219]
|  | Pension Benefits |  |  |
|  | 2025 |  | 2024 |  | 2023 |  |  |  |  |  |  |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 1.1 |  |  | $ | 1.5 |  |  | $ | 2.1 |  |  |  |  |  |  |  |
| Interest cost | 8.4 |  |  | 8.5 |  |  | 8.9 |  |  |  |  |  |  |  |
| Expected return on plan assets | (7.2) |  |  | (7.6) |  |  | (9.4) |  |  |  |  |  |  |  |
| Amortization of prior service costs | — |  |  | 0.1 |  |  | 0.1 |  |  |  |  |  |  |  |
| Recognized actuarial loss | 1.4 |  |  | 1.1 |  |  | 1.1 |  |  |  |  |  |  |  |
| Settlements | 0.4 |  |  | 0.4 |  |  | 0.8 |  |  |  |  |  |  |  |
| Other | — |  |  | — |  |  | (0.4) |  |  |  |  |  |  |  |
| Net periodic benefit cost | $ | 4.1 |  |  | $ | 4.0 |  |  | $ | 3.2 |  |  |  |  |  |  |  |

[0001069202-26-000028:notes:220]
Amounts recognized in AOCL and Other Comprehensive Income (Loss)

[0001069202-26-000028:notes:221]
The following table sets forth amounts recognized in AOCL and Other comprehensive income (loss) in our financial statements for 2025 and 2024 (in millions):

[0001069202-26-000028:notes:222]
|  | Pension Benefits |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Amounts recognized in AOCL: |  |  |  |  |  |  |  |
| Prior service costs | $ | (0.1) |  |  | $ | (0.2) |  |  |  |  |  |
| Actuarial loss | (56.2) |  |  | (54.7) |  |  |  |  |  |
| Subtotal | (56.3) |  |  | (54.9) |  |  |  |  |  |
| Deferred taxes | 13.7 |  |  | 13.5 |  |  |  |  |  |
| Net amount recognized | $ | (42.6) |  |  | $ | (41.4) |  |  |  |  |  |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Current year actuarial gain | 3.1 |  |  | 2.5 |  |  |  |  |  |
| Effect of exchange rates | 0.6 |  |  | (0.5) |  |  |  |  |  |
| Amortization of prior service costs | (0.1) |  |  | (0.1) |  |  |  |  |  |
| Amortization of actuarial loss, including settlements and other | (2.0) |  |  | (1.5) |  |  |  |  |  |
| Total recognized in other comprehensive income (loss) | $ | 1.6 |  |  | $ | 0.4 |  |  |  |  |  |
| Total recognized in net periodic benefit cost and other comprehensive income | $ | 5.7 |  |  | $ | 4.4 |  |  |  |  |  |

[0001069202-26-000028:notes:223]
The estimated actuarial losses for pension benefits that will be amortized from AOCL in 2026 are $1.7 million. Estimated prior service costs that will be amortized from AOCL in 2026 are expected to be nominal.

[0001069202-26-000028:notes:224]
Assumptions

[0001069202-26-000028:notes:225]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2025 and 2024:

[0001069202-26-000028:notes:226]
|  |  | Pension Benefits |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |
| Discount rate |  | 5.47 | % |  | 5.68 | % |  |  |  |  |
| Rate of compensation increase |  | 4.00 | % |  | 3.95 | % |  |  |  |  |

[0001069202-26-000028:notes:227]
|  | Pension Benefits |  |  |
|  | 2025 |  | 2024 |  | 2023 |  |  |  |  |  |  |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate - service cost | 5.64 | % |  | 5.23 | % |  | 5.39 | % |  |  |  |  |  |  |
| Discount rate - interest cost | 5.43 | % |  | 5.15 | % |  | 5.38 | % |  |  |  |  |  |  |
| Expected long-term return on plan assets | 4.50 | % |  | 4.50 | % |  | 6.50 | % |  |  |  |  |  |  |
| Rate of compensation increase | 3.95 | % |  | 4.02 | % |  | 4.02 | % |  |  |  |  |  |  |

[0001069202-26-000028:notes:228]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the non-U.S.-based plans in 2025 and 2024:

[0001069202-26-000028:notes:229]
|  | Pension Benefits |
|  | 2025 |  | 2024 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 5.30 | % |  | 5.16 | % |
| Rate of compensation increase | 3.75 | % |  | 3.75 | % |

[0001069202-26-000028:notes:230]
|  | Pension Benefits |
|  | 2025 |  | 2024 |  | 2023 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | — | % |  | — | % |  | 3.75 | % |
| Discount rate - interest cost | 5.11 | % |  | 4.62 | % |  | 4.79 | % |
| Expected long-term return on plan assets | 5.04 | % |  | 4.53 | % |  | 4.94 | % |
| Rate of compensation increase | 3.75 | % |  | 3.07 | % |  | 3.11 | % |

[0001069202-26-000028:notes:231]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing. These results were adjusted for the payment of reasonable expenses of the plan from plan assets. This resulted in the selection of the 4.50% long-term rate of return on assets assumption. A similar process was followed for the non-U.S.-based plans.

[0001069202-26-000028:notes:232]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans were matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis to select the discount rate for each plan. The analysis was completed separately for each U.S. pension and other post-employment benefits (“OPEB”) plan. A similar process was followed for the non-U.S.-based plans with sufficient corporate bond information. In other countries, the discount rate was selected based on the approximate duration of plan obligations.

[0001069202-26-000028:notes:233]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan. The following table sets forth the healthcare trend rate assumptions used:

[0001069202-26-000028:notes:234]
|  | 2025 |  | 2024 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 8.00 | % |  | 7.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 4.50 | % |  | 4.50 | % |
| Year that the rate reaches the ultimate trend rate | 2040 |  | 2037 |

[0001069202-26-000028:notes:235]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-26-000028:notes:236]
|  | For the Years Ended December 31, |
|  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031-2035 |
| Pension benefits | $ | 8.2 |  |  | $ | 15.0 |  |  | $ | 11.2 |  |  | $ | 13.2 |  |  | $ | 9.8 |  |  | $ | 54.0 |  |

[0001069202-26-000028:notes:237]
Composition of Pension Plan Assets

[0001069202-26-000028:notes:238]
In the fourth quarter of 2023, based on the strong funded status of our U.S. pension plan, we opted to make a $12.2 million voluntary contribution to the plan to increase the funded status and fully fund the plan. With the U.S. pension plan fully funded, the asset allocation was changed from a blend of 50% equities and 50% fixed income to 100% fixed income in order to align changes in asset values with changes in liabilities, therefore reducing funded status volatility, which effectively placed the plan in hibernation status. As a result, we reduced the expected long-term rate of return for our U.S. pension plan assets to 4.5%. Our U.S. pension plan represents 85%, our Canadian pension plan 6%, and our United Kingdom (“U.K.”) pension plan 9% of the total fair value of our plan assets as of December 31, 2025.

[0001069202-26-000028:notes:239]
Our U.S. pension plans’ weighted-average asset allocation by asset category as of December 31, 2025 and 2024 were almost entirely comprised of fixed income. Our U.S. pension plans’ assets were invested according to our target of 100% in fixed income assets.

[0001069202-26-000028:notes:240]
Similarly, in 2023, based on the strong funded status of our Canadian pension plans, the asset allocation was adjusted as well, with the Salaried plan moving from 75% fixed income and 25% equity to 100% fixed income, and the Hourly plan moving from 75% fixed income and 25% equity to 87% fixed income and 13% equity. As with the U.S. pension plan, this change in asset allocation has greatly reduced funded status volatility.

[0001069202-26-000028:notes:241]
Our U.K. pension plan was invested in fixed income securities, including corporate and government bonds.

[0001069202-26-000028:notes:242]
The fair values of our pension plan assets, by asset category, were as follows (in millions):

[0001069202-26-000028:notes:243]
|  | Fair Value Measurements as of December 31, 2025 |  |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |  |
| Asset Category: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |  |  |  |
| Fixed income (1) | — |  |  | 125.5 |  |  | — |  |  | 125.5 |  |  |
| Balanced pension trust: (2) |  |  |  |  |  |  |  |  |
| International equity | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |  |
| Fixed income | — |  |  | 8.3 |  |  | — |  |  | 8.3 |  |  |
| Pension fund: |  |  |  |  |  |  |  |  |
| Fixed income (3) | — |  |  | 12.9 |  |  | — |  |  | 12.9 |  |  |
| Total | $ | 0.1 |  |  | $ | 147.2 |  |  | $ | — |  |  | $ | 147.3 |  |  |

[0001069202-26-000028:notes:244]
|  | Fair Value Measurements as of December 31, 2024 |  |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |  |
| Asset Category: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |  |  |  |
| Fixed income (1) | — |  |  | 122.7 |  |  | — |  |  | 122.7 |  |  |
| Balanced pension trust: (2) |  |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |  |
| Fixed income | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  |
| Pension fund: |  |  |  |  |  |  |  |  |
| Fixed income (3) | — |  |  | 12.5 |  |  | — |  |  | 12.5 |  |  |
| Total | $ | 0.1 |  |  | $ | 144.9 |  |  | $ | — |  |  | $ | 145.0 |  |  |

[0001069202-26-000028:notes:245]
| (1) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (2) | The investment objectives of the plan are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The plan also holds a portion of its assets in international equities, a portion of which may be invested in U.S. securities. |
| (3) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer with a derivatives overlay and investment grade corporate bonds denominated in sterling. The plan also holds a portion of its assets in international instruments, a portion of which may be invested in U.S. securities. |

[0001069202-26-000028:notes:246]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-26-000028:notes:247]
|  | As of December 31, 2025 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |
| Fixed income (1) | 125.5 |  |  | Daily |  | 5 days |
| Balanced pension trust: (2) |  |  |  |  |  |
| International equity | 0.5 |  |  | Daily |  | 3-5 days |
| Fixed income | 8.3 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (3) | 12.9 |  |  | Daily |  | 1-3 days |
| Total | $ | 147.2 |  |  |  |  |  |

[0001069202-26-000028:notes:248]
|  | As of December 31, 2024 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |
| Fixed income (1) | 122.7 |  |  | Daily |  | 5 days |
| Balanced pension trust: (2) |  |  |  |  |  |
| International equity | 4.7 |  |  | Daily |  | 3-5 days |
| Fixed income | 5.0 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (3) | 12.5 |  |  | Daily |  | 1-3 days |
| Total | $ | 144.9 |  |  |  |  |  |

[0001069202-26-000028:notes:249]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors. The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies. We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures. The fair values we report are based on the pool, trust or fund’s NAV per share. The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the number of units owned. See Note 16 for information about our fair value hierarchies and valuation techniques.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-26-000028:notes:250]
11. Joint Ventures and Other Investments:

[0001069202-26-000028:notes:251]
We participate in four joint ventures. Three are located in the U.S. and the fourth in Mexico. These four joint ventures are engaged in the manufacturing and distribution of compressors, condensing units, unit and module coolers, heat pumps, ductless heat pump mini-split, Variable Refrigerant Flow systems, and water heaters. We exert significant influence over these affiliates based upon our respective 25%, 49.9%, 49.9% and 50% ownership, but do not control them due to venture partner participation. Accordingly, our joint ventures have been accounted for under the equity method and held-to-maturity investments, and their financial position and results of operations are not consolidated.

[0001069202-26-000028:notes:252]
The combined balance of equity method and other investments included in Other assets, net totaled (in millions):

[0001069202-26-000028:notes:253]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Equity method investments | $ | 59.7 |  |  | $ | 56.4 |  |
| Held-to-maturity investment | 7.9 |  |  | 7.9 |  |
| Total investments | $ | 67.6 |  |  | $ | 64.3 |  |

[0001069202-26-000028:notes:254]
We purchase compressors from one of our U.S. joint ventures for use in certain of our products. The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-26-000028:notes:255]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Purchases of compressors from joint venture | $ | 148.8 |  |  | $ | 173.3 |  |  | $ | 148.3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-26-000028:notes:256]
12. Income Taxes:

[0001069202-26-000028:notes:257]
Income before income taxes was comprised of the following (in millions):

[0001069202-26-000028:notes:258]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024As Adjusted |  | 2023As Adjusted |
| Domestic | $ | 584.9 |  |  | $ | 625.8 |  |  | $ | 472.8 |  |
| Foreign | 411.9 |  |  | 373.6 |  |  | 266.1 |  |
| Total | $ | 996.8 |  |  | $ | 999.4 |  |  | $ | 738.9 |  |

[0001069202-26-000028:notes:259]
The difference between the income tax provision computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-26-000028:notes:260]
|  | For the Years Ended December 31, |
|  | 2024As Adjusted |  | 2023As Adjusted |
| Provision at the U.S. statutory rate of 21% | $ | 209.9 |  |  | $ | 155.2 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |
| State income tax, net of federal income tax benefit | 23.2 |  |  | 16.4 |  |
| Tax credits, net of unrecognized tax benefits | (5.3) |  |  | (3.4) |  |
| Change in unrecognized tax benefits | 0.5 |  |  | 0.4 |  |
| Change in valuation allowance | — |  |  | 0.1 |  |
| Foreign taxes at rates other than U.S. statutory rate | (61.1) |  |  | (40.3) |  |
| Deemed inclusions | 7.6 |  |  | 6.1 |  |
| Global intangible low-taxed income | 20.8 |  |  | 17.5 |  |
| Change in rates from the Tax Act & other law changes | — |  |  | 0.2 |  |
| Excess tax benefits from stock-based compensation | (8.0) |  |  | (5.2) |  |
| Miscellaneous other | 0.7 |  |  | 0.7 |  |
| Total provision for income taxes | $ | 188.3 |  |  | $ | 147.7 |  |
|  | For the Year Ended December 31, 2025 |
|  | Amount |  | Percent |
| US federal statutory tax rate | 209.3 |  |  | 21.0 | % |
| State and local income taxes, net of federal income tax effect(1) | 24.8 |  |  | 2.5 |  |
| Foreign tax effects |  |  |  |
| Mexico |  |  |  |
| Statutory tax rate difference between Mexico and United States | 15.2 |  |  | 1.5 |  |
| Nontaxable income | (42.3) |  |  | (4.1) |  |
| Other | 3.1 |  |  | 0.3 |  |
| Other foreign jurisdictions | 7.4 |  |  | 0.7 |  |
| Effects of changes in tax laws or rates enacted in the current period | — |  |  | — |  |
| Effect of cross-border tax laws |  |  |  |
| Global intangible low-taxed income | 14.0 |  |  | 1.4 |  |
| Other | 4.3 |  |  | 0.5 |  |
| Tax credits | (3.0) |  |  | (0.3) |  |
| Changes in valuation allowances | (0.6) |  |  | (0.1) |  |
| Nontaxable or nondeductible items |  |  |  |
| Nontaxable income | (41.1) |  |  | (4.1) |  |
| Other | (0.5) |  |  | (0.1) |  |
| Changes in unrecognized tax benefits | 0.4 |  |  | — |  |
| Effective tax rate | $ | 191.0 |  |  | 19.2 | % |

[0001069202-26-000028:notes:261]
(1) State taxes in California, Florida, Illinois, New Jersey, Pennsylvania, and Minnesota made up the majority (greater than 50%) of the tax effect in this category.

[0001069202-26-000028:notes:262]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax. The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-26-000028:notes:263]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-26-000028:notes:264]
|  | As of December 31, |
|  | 2025 |  | 2024 As Adjusted |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 41.6 |  |  | $ | 39.4 |  |
| Loss carryforwards (foreign, U.S. and state) | 2.4 |  |  | 2.7 |  |
| Post-retirement and pension benefits | 4.2 |  |  | 4.5 |  |
| Receivables allowance | 3.9 |  |  | 7.4 |  |
| Compensation liabilities | 7.4 |  |  | 6.6 |  |
| Legal reserves | 20.8 |  |  | 14.2 |  |
| Tax credits, net of federal effect | 13.4 |  |  | 12.3 |  |
| Research and development capitalization | 32.2 |  |  | 55.8 |  |
| Lease liabilities | 81.0 |  |  | 76.9 |  |
| Other | 6.2 |  |  | 5.4 |  |
| Total deferred tax assets | 213.1 |  |  | 225.2 |  |
| Valuation allowance | (9.9) |  |  | (10.6) |  |
| Total deferred tax assets, net of valuation allowance | 203.2 |  |  | 214.6 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (77.8) |  |  | (64.4) |  |
| Intangibles | (72.5) |  |  | (17.4) |  |
| Insurance liabilities | (4.1) |  |  | (2.0) |  |
| Inventory reserve | (13.5) |  |  | (20.1) |  |
| Hedges | (6.5) |  |  | (1.5) |  |
| Lease assets | (72.1) |  |  | (70.4) |  |
| Other | (2.3) |  |  | — |  |
| Total deferred tax liabilities | (248.8) |  |  | (175.8) |  |
| Net deferred tax assets | $ | (45.6) |  |  | $ | 38.8 |  |

[0001069202-26-000028:notes:265]
As of December 31, 2025 and 2024, we had $2.4 million and $2.7 million in tax-effected foreign net operating loss carryforwards, respectively. The deferred tax asset valuation allowance relates primarily to state tax credits. The remainder of the valuation allowance relates to loss carryforwards.

[0001069202-26-000028:notes:266]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all the deferred tax asset will not be realized. We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment. Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of December 31, 2025.

[0001069202-26-000028:notes:267]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries’ earnings. An actual repatriation in the future from our non-U.S. subsidiaries could still be subject to foreign withholding taxes and U.S. state taxes, but we expect any amounts to be immaterial.

[0001069202-26-000028:notes:268]
Income taxes paid, net of refunds, was comprised of the following (in millions):

[0001069202-26-000028:notes:269]
|  | For the Year Ended December 31, 2025 |
| Federal | $ | 57.0 |  |
| State |  |
| California | 5.5 |  |
| Other | 18.5 |  |
| Foreign |  |
| Canada | 5.8 |  |
| Mexico | 10.8 |  |
| Other | 6.2 |  |
| Total | $ | 103.8 |  |

[0001069202-26-000028:notes:270]
We and our subsidiaries file income tax returns with the U.S. federal government, various U.S. states, and various foreign jurisdictions throughout the world. We regularly engage in discussions and negotiations with tax authorities regarding tax matters, and we continue to defend any and all such claims presented. Our U.S. federal and state tax returns remain open to examination for 2018 through 2024. We are currently under a limited scope audit by the Internal Revenue Service for our 2021 and 2022 tax years. There are also ongoing U.S. state and local audits and other foreign audits covering fiscal years 2018 through 2024. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2018. We have no material uncertain tax provisions recorded as of December 31, 2025. We do not expect the results from any ongoing income tax audit to have a material impact on our consolidated financial condition, results of operations, or cash flows.


## us-gaap:DebtDisclosureTextBlock

[0001069202-26-000028:notes:271]
13. Lines of Credit and Financing Arrangements:

[0001069202-26-000028:notes:272]
The following tables summarize our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-26-000028:notes:273]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Commercial paper: | $ | 226.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 18.3 |  |  | $ | 14.9 |  |
| Senior unsecured notes | — |  |  | 300.0 |  |
| Debt issuance costs | — |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 18.3 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 50.6 |  |  | 39.5 |  |
| Term loan | 300.0 |  |  | — |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.5) |  |  | (6.4) |  |
| Total long-term debt | $ | 1,144.1 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,388.4 |  |  | $ | 1,147.6 |  |

[0001069202-26-000028:notes:274]
As of December 31, 2025, the aggregate amounts of required principal payments on total debt excluding finance lease obligations (see Note 5) were as follows (in millions):

[0001069202-26-000028:notes:275]
| 2026 | $ | — |  |
| 2027 | 600.0 |  |
| 2028 | 500.0 |  |
| Thereafter | — |  |

[0001069202-26-000028:notes:276]
Commercial Paper Program

[0001069202-26-000028:notes:277]
On October 25, 2023, we established a commercial paper program (the “Program”) pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from the issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $226 million CP Notes outstanding under the Program as of December 31, 2025.

[0001069202-26-000028:notes:278]
Below is a summary of the weighted average interest rate for CP notes as of December 31, 2025 and 2024:

[0001069202-26-000028:notes:279]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Weighted average borrowing rate | 3.98 | % |  | — | % |

[0001069202-26-000028:notes:280]
Long-Term Debt

[0001069202-26-000028:notes:281]
Term Loan

[0001069202-26-000028:notes:282]
On October 16, 2025, we entered into a Term Credit Agreement (the “Term Credit Agreement”) with Wells Fargo Bank, National Association, as administrative agent, and the other lenders party thereto. We borrowed $300.0 million pursuant to the Term Credit Agreement and used the net proceeds to repay existing borrowings under the Credit Agreement (as defined below). The Term Credit Agreement matures on October 16, 2027. Loans under the Term Credit Agreement bear interest at our election

[0001069202-26-000028:notes:283]
at a rate per annum equal to (i) a forward-looking term rate based on the secured overnight financing rate for the applicable interest period ("Term SOFR"), plus an applicable margin ranging between 0.90% and 1.025% per annum depending on our long-term unsecured debt rating, or (ii) the highest of the Wells Fargo Bank, National Association prime rate, the Federal Funds rate plus 0.50%, and Term SOFR for a one month tenor in effect on such day plus 1.00%, plus an applicable margin ranging between 0.00% and 0.025% per annum depending on our long-term unsecured debt rating.

[0001069202-26-000028:notes:284]
The Term Credit Agreement contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Credit Agreement.

[0001069202-26-000028:notes:285]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Weighted average borrowing rate | 4.90 | % |  | — | % |

[0001069202-26-000028:notes:286]
Credit Agreement

[0001069202-26-000028:notes:287]
On May 9, 2025, we entered into an Amendment and Restatement Agreement (the "Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Credit Agreement. The Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of December 31, 2025. Subject to covenant limitations, $772.3 million was available for future borrowings after taking into consideration the Program. Availability under the Credit Agreement is reduced by borrowings under the Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001069202-26-000028:notes:288]
Below is a summary of the weighted average interest rate as of December 31, 2025 and 2024:

[0001069202-26-000028:notes:289]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Weighted average borrowing rate | — | % |  | — | % |

[0001069202-26-000028:notes:290]
The Credit Agreement and the Term Credit Agreement (the “Credit Facilities”) are guaranteed by certain of our subsidiaries (the “Guarantor Subsidiaries”) and contain customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Facilities each contain a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001069202-26-000028:notes:291]
Our Credit Facilities contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our Credit Facilities could occur if:

[0001069202-26-000028:notes:292]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001069202-26-000028:notes:293]
•We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-26-000028:notes:294]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Facilities or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-26-000028:notes:295]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments, may require the administrative agent to terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Facilities (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-26-000028:notes:296]
We are currently in compliance with all covenant requirements.

[0001069202-26-000028:notes:297]
Senior Unsecured Notes

[0001069202-26-000028:notes:298]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%. In July 2020, we issued senior unsecured notes for $300.0 million, which will mature on August 1, 2027 (the "2027 Notes" and collectively with the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.70% per annum. On August 1, 2025, we repaid upon maturity $300.0 million of our 1.35% senior unsecured notes due in 2025 that were originally issued in 2020.

[0001069202-26-000028:notes:299]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-26-000028:notes:300]
14. Comprehensive Income:

[0001069202-26-000028:notes:301]
The following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-26-000028:notes:302]
|  |  | For the Years Ended December 31, |  |  |
| AOCL Component |  | 2025 |  | 2024 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| (Gains)/Losses on cash flow hedges: |  |  |  |  |  |  |
| Derivative contracts |  | $ | 21.0 |  |  | $ | (0.9) |  |  | Cost of goods sold; Losses and other expenses, net |
| Income tax benefit (expense) |  | (4.9) |  |  | 0.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | 16.1 |  |  | $ | (0.7) |  |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and post-retirement benefits costs |  | $ | (1.4) |  |  | $ | (1.4) |  |  | Cost of goods sold; Selling, general, and administrative expenses and Losses and other expenses, net |
| Pension settlements |  | (0.4) |  |  | (0.4) |  |  | Pension settlements |
| Income tax benefit (expense) |  | 0.4 |  |  | 0.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.4) |  |  | $ | (1.4) |  |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Foreign currency adjustments upon liquidation of businesses |  | $ | 1.3 |  |  | $ | — |  |  | (Gain) loss on sale of businesses |
| Income tax expense |  | — |  |  | — |  |  | Provision for income taxes |
| Net of tax |  | $ | 1.3 |  |  | $ | — |  |  |  |
| Total reclassifications from AOCL |  | $ | 16.0 |  |  | $ | (2.1) |  |  |  |

[0001069202-26-000028:notes:303]
The following tables provide information on changes in AOCL, by component (net of tax), for the years ended December 31, 2025 and 2024 (in millions):

[0001069202-26-000028:notes:304]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2024 |  | $ | (1.5) |  |  | $ | 0.4 |  |  | $ | (45.7) |  |  | $ | (46.9) |  |  | $ | (93.7) |  |
| Other comprehensive income (loss) before reclassifications |  | 35.5 |  |  | (0.2) |  |  | (2.5) |  |  | 28.4 |  |  | 61.2 |  |
| Amounts reclassified from AOCL |  | (16.1) |  |  | — |  |  | 1.4 |  |  | (1.3) |  |  | (16.0) |  |
| Net other comprehensive income (loss) |  | 19.4 |  |  | (0.2) |  |  | (1.1) |  |  | 27.1 |  |  | 45.2 |  |
| Balance as of December 31, 2025 |  | $ | 17.9 |  |  | $ | 0.2 |  |  | $ | (46.8) |  |  | $ | (19.8) |  |  | $ | (48.5) |  |

[0001069202-26-000028:notes:305]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2023 |  | $ | (2.0) |  |  | $ | 0.6 |  |  | $ | (44.2) |  |  | $ | (11.3) |  |  | $ | (56.9) |  |
| Other comprehensive loss before reclassifications |  | (0.2) |  |  | (0.2) |  |  | (2.9) |  |  | (35.6) |  |  | (38.9) |  |
| Amounts reclassified from AOCL |  | 0.7 |  |  | — |  |  | 1.4 |  |  | — |  |  | 2.1 |  |
| Net other comprehensive income |  | 0.5 |  |  | (0.2) |  |  | (1.5) |  |  | (35.6) |  |  | (36.8) |  |
| Balance as of December 31, 2024 |  | $ | (1.5) |  |  | $ | 0.4 |  |  | $ | (45.7) |  |  | $ | (46.9) |  |  | $ | (93.7) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-26-000028:notes:306]
15. Stock-Based Compensation:

[0001069202-26-000028:notes:307]
Stock-based compensation expense was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-26-000028:notes:308]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Compensation expense | $ | 28.4 |  |  | $ | 28.5 |  |  | $ | 30.1 |  |

[0001069202-26-000028:notes:309]
Incentive Plan

[0001069202-26-000028:notes:310]
Under the Lennox International Inc. 2019 Equity and Incentive Compensation Plan, we are authorized to issue awards for 1.7 million shares of common stock. The plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights. A description of these long-term incentive awards and related activity within each award category is provided below. As of December 31, 2025, there were 1.6 million shares available for future issuance.

[0001069202-26-000028:notes:311]
Historically our annual equity awards were granted in December. In 2023, we made the decision to move the annual grant for 2023 to February 2024. Thus, there were no equity grants in 2023. We also made the decision to award the Board of Directors fully vested shares on an annual basis. As a result, approximately $1.1 million and $1.3 million of compensation expense was recognized in 2025 for the 2025 director grant and in 2024 for the 2024 director grant, respectively.

[0001069202-26-000028:notes:312]
Performance Share Units

[0001069202-26-000028:notes:313]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year. Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock. Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained. To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited. Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII’s performance over the three-year performance period.

[0001069202-26-000028:notes:314]
Performance share units are classified as equity awards. Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant. The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded. Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-26-000028:notes:315]
The following table provides information on our performance share units:

[0001069202-26-000028:notes:316]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Compensation expense for performance share units (in millions) | $ | 12.8 |  |  | $ | 14.9 |  |  | $ | 15.2 |  |
| Weighted-average fair value of grants, per share | $ | 558.78 |  |  | $ | 403.68 |  |  | $ | — |  |
| Payout ratio for shares paid | 200 | % |  | 189 | % |  | 131 | % |

[0001069202-26-000028:notes:317]
A summary of the status of our undistributed performance share units as of December 31, 2025, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001069202-26-000028:notes:318]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2024 | 99.1 |  |  | $ | 305.14 |  |
| Granted | 18.1 |  |  | $ | 558.78 |  |
| Adjustment to shares paid based on payout ratio | 30.4 |  |  | $ | 245.27 |  |
| Distributed | (42.2) |  |  | $ | 289.77 |  |
| Forfeited | (7.1) |  |  | $ | 387.59 |  |
| Undistributed performance share units as of December 31, 2025 (1) | 98.3 |  |  | $ | 330.10 |  |

[0001069202-26-000028:notes:319]
(1) Undistributed performance share units include 36,590 units with a weighted-average grant date fair value of $473.11 per share that had not yet vested and 61,710 units that have vested but were not yet distributed with a fair value of $15.1 million.

[0001069202-26-000028:notes:320]
As of December 31, 2025, we had $11.4 million of total unrecognized compensation cost related to non-vested performance share units that are expected to be recognized over a weighted-average period of 1.78 years. Our weighted-average estimated forfeiture rate for these performance share units was 28.0% as of December 31, 2025.

[0001069202-26-000028:notes:321]
The total fair value of performance share units distributed and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001069202-26-000028:notes:322]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Fair value of performance share units distributed | $ | 21.2 |  |  | $ | 19.5 |  |  | $ | 13.5 |  |
| Realized tax benefits from tax deductions | $ | 5.2 |  |  | $ | 4.8 |  |  | $ | 3.3 |  |

[0001069202-26-000028:notes:323]
Restricted Stock Units

[0001069202-26-000028:notes:324]
Restricted stock units are issued to attract and retain key employees. Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant. Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings. Restricted stock units are classified as equity awards. The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-26-000028:notes:325]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-26-000028:notes:326]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Compensation expense for restricted stock units | $ | 10.5 |  |  | $ | 9.4 |  |  | $ | 10.8 |  |
| Weighted-average fair value of grants, per share | $ | 551.56 |  |  | $ | 404.91 |  |  | $ | — |  |

[0001069202-26-000028:notes:327]
A summary of our non-vested restricted stock units as of December 31, 2025 and changes during the year then ended is presented below (in thousands, except per share data):

[0001069202-26-000028:notes:328]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2024 | 70.9 |  |  | $ | 306.01 |  |
| Granted | 24.1 |  |  | $ | 551.56 |  |
| Vested | (40.6) |  |  | $ | 243.07 |  |
| Forfeited | (8.9) |  |  | $ | 388.26 |  |
| Non-vested restricted stock units as of December 31, 2025 (1) | 45.5 |  |  | $ | 474.46 |  |

[0001069202-26-000028:notes:329]
(1) As of December 31, 2025, we had $12.1 million of total unrecognized compensation cost related to non-vested restricted stock units that are expected to be recognized over a weighted-average period of 1.87 years. Our estimated forfeiture rate for restricted stock units was 20.0% as of December 31, 2025.

[0001069202-26-000028:notes:330]
The total fair value of restricted stock units vested and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001069202-26-000028:notes:331]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Fair value of restricted stock units vested | $ | 17.9 |  |  | $ | 17.3 |  |  | $ | 15.0 |  |
| Realized tax benefits from tax deductions | $ | 4.4 |  |  | $ | 4.2 |  |  | $ | 3.7 |  |

[0001069202-26-000028:notes:332]
Stock Appreciation Rights

[0001069202-26-000028:notes:333]
Stock appreciation rights are issued to certain key employees. Each recipient is given the “right” to receive compensation, paid in shares of our common stock, equal to the future appreciation of our common stock price. Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years. Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-26-000028:notes:334]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-26-000028:notes:335]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Compensation expense for stock appreciation rights | $ | 5.1 |  |  | $ | 4.2 |  |  | $ | 4.1 |  |
| Weighted-average fair value of grants, per share | $ | 161.50 |  |  | $ | 136.37 |  |  | $ | — |  |

[0001069202-26-000028:notes:336]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period. We used historical stock price data to estimate the expected volatility. We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group. The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-26-000028:notes:337]
The fair value of the stock appreciation rights granted in 2025 and 2024 were estimated on the date of grant using the following assumptions.

[0001069202-26-000028:notes:338]
|  |  | 2025 |  | 2024 |
| Expected dividend yield |  | 0.97 | % |  | 1.23 | % |
| Risk-free interest rate |  | 4.28 | % |  | 4.05 | % |
| Expected volatility |  | 29.95 | % |  | 34.89 | % |
| Expected life (in years) |  | 4.09 |  | 4.18 |

[0001069202-26-000028:notes:339]
A summary of our stock appreciation rights as of December 31, 2025, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001069202-26-000028:notes:340]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2024 | 203.7 |  |  | $ | 306.61 |  |
| Granted | 37.3 |  |  | $ | 576.28 |  |
| Exercised | (37.3) |  |  | $ | 281.41 |  |
| Forfeited | (14.1) |  |  | $ | 417.89 |  |
| Outstanding stock appreciation rights as of December 31, 2025 | 189.6 |  |  | $ | 356.37 |  |
| Exercisable stock appreciation rights as of December 31, 2025 | 153.1 |  |  | $ | 317.79 |  |

[0001069202-26-000028:notes:341]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2025 (in millions, except per share data and years; shares in thousands):

[0001069202-26-000028:notes:342]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares (1) |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $214.63 to $257.08 |  | 19.9 |  |  | 1.0 |  | $ | 4.6 |  |  | 19.9 |  |  | 1.0 |  | $ | 5.1 |  |
| $278.00 to $328.65 |  | 46.5 |  |  | 2.54 |  | $ | 8.4 |  |  | 46.5 |  |  | 2.54 |  | $ | 14.2 |  |
| $259.56 to $418.69 |  | 90.3 |  |  | 4.45 |  | $ | 14.6 |  |  | 76.8 |  |  | 4.33 |  | $ | 23.6 |  |
| $576.28 |  | 32.9 |  |  | 6.1 |  | $ | — |  |  | 9.9 |  |  | 6.1 |  | $ | 5.7 |  |

[0001069202-26-000028:notes:343]
(1) Share amounts are rounded but the balance accurately reflects the actual amount of exercisable stock appreciation rights as of December 31, 2025.

[0001069202-26-000028:notes:344]
As of December 31, 2025, we had $5.7 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 1.75 years. Our estimated forfeiture rate for stock appreciation rights was 20.0% as of December 31, 2025.

[0001069202-26-000028:notes:345]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-26-000028:notes:346]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Intrinsic value of stock appreciation rights exercised | $ | 10.7 |  |  | $ | 25.4 |  |  | $ | 19.8 |  |
| Realized tax benefits from tax deductions | $ | 2.6 |  |  | $ | 6.2 |  |  | $ | 4.8 |  |

[0001069202-26-000028:notes:347]
Employee Stock Purchase Plan

[0001069202-26-000028:notes:348]
Effective July 1, 2025, the Company amended the 2022 Employee Stock Purchase Plan (“ESPP”) to increase the discount percentage for which all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of six month offering periods. The purchase price for such shares decreased from 95% to 85% of the fair market value of the stock at the lower of the fair market value of the shares at the subscription date (first date of offering period) or the purchase date (last date of offering period) making the plan compensatory. For the year ended December 31, 2025, we recognized $0.7 million in compensation expense under the amended ESPP. A maximum of 1.0 million shares is authorized for purchase until issuance of all shares available under the plan, unless terminated earlier at the discretion of the

[0001069202-26-000028:notes:349]
Board of Directors. Employees purchased approximately 11,300 shares under the ESPP during the year ended December 31, 2025. Approximately 960,000 shares remain available for purchase under the ESPP as of December 31, 2025.


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-26-000028:notes:350]
16. Fair Value Measurements:

[0001069202-26-000028:notes:351]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities. Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001069202-26-000028:notes:352]
Level 1 -      Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-26-000028:notes:353]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001069202-26-000028:notes:354]
Level 3 -   Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001069202-26-000028:notes:355]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use. Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2025 and 2024, the measurement dates.

[0001069202-26-000028:notes:356]
The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2025 were the same as those used as of December 31, 2024.

[0001069202-26-000028:notes:357]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-26-000028:notes:358]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-26-000028:notes:359]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives. We also considered the counterparty’s creditworthiness, or our own creditworthiness, as appropriate. Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives. Refer to Note 9 for more information related to our derivative instruments. Refer to Note 10 for more information related to the fair value assumptions related to our pension assets and liabilities.

[0001069202-26-000028:notes:360]
Other Fair Value Disclosures

[0001069202-26-000028:notes:361]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments. The carrying amount of our Credit Facilities and CP Notes in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-26-000028:notes:362]
We purchased the held-to-maturity investment in 2024. The carrying value of the investment approximates fair value.

[0001069202-26-000028:notes:363]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk. The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-26-000028:notes:364]
|  | As of December 31, |
|  | 2025 |  | 2024 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 817.4 |  |  | $ | 1,093.4 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001069202-26-000028:notes:365]
17. Acquisitions:

[0001069202-26-000028:notes:366]
Duro Dyne and Supco

[0001069202-26-000028:notes:367]
In October 2025, we acquired 100% of the outstanding shares of common stock in Duro Dyne and Supco, a robust portfolio of HVAC parts and supplies that complement our existing residential and commercial offerings. Excluding cash received at the closing, the total cash consideration paid was $545.0 million, which was primarily funded by cash and borrowings under our financing arrangements.

[0001069202-26-000028:notes:368]
The purchase price was allocated to the assets acquired and liabilities assumed based on management’s estimate of their respective fair values at the date of acquisition. Goodwill was calculated as the excess of the consideration transferred over the net assets recognized and represents the estimated future economic benefits arising from other assets acquired that could not be individually identified and separately recognized. The factors contributing to the recognition of goodwill were the assembled workforce and strategic benefits that are expected to be realized from the acquisition. The purchase price allocation is preliminary and subject to revision as additional information about the fair value of assets acquired and liabilities assumed becomes available.

[0001069202-26-000028:notes:369]
Under the terms of the purchase agreement, a final working capital adjustment is due in the first quarter of 2026. The preliminary allocation of the purchase price as of the acquisition date was as follows:

[0001069202-26-000028:notes:370]
| (Amounts in millions) | Amount |  |  |  |  |
| Total consideration paid | $ | 551.3 |  |  |  |  |  |
| Cash and cash equivalents | 6.3 |  |  |  |  |  |
| Accounts receivable, net | 22.9 |  |  |  |  |  |
| Inventory, net | 67.4 |  |  |  |  |  |
| Other current assets | 0.5 |  |  |  |  |  |
| Property, plant and equipment | 18.3 |  |  |  |  |  |
| Right-of-use assets from operating leases | 29.8 |  |  |  |  |  |
| Other assets, net | 1.2 |  |  |  |  |  |
| Intangible assets acquired | 235.0 |  |  |  |  |  |
| Accounts payable | (9.7) |  |  |  |  |  |
| Accrued expenses | (9.3) |  |  |  |  |  |
| Current operating lease liabilities | (2.9) |  |  |  |  |  |
| Long-term operating lease liabilities | (26.3) |  |  |  |  |  |
| Other liabilities | (59.1) |  |  |  |  |  |
| Total net assets acquired | $ | 274.1 |  |  |  |  |  |
| Goodwill as of acquisition date | $ | 277.2 |  |  |  |  |  |

[0001069202-26-000028:notes:371]
The purchase price allocation includes $235 million of acquired identifiable intangible assets, all of which have finite lives. The fair value of the identifiable intangible assets has been estimated using the income approach through a discounted cash flow analysis. The determination of the useful lives is based upon various industry studies, historical acquisition experience, and economic factors.

[0001069202-26-000028:notes:372]
The amounts allocated to intangible assets are as follows:

[0001069202-26-000028:notes:373]
| (Amounts in millions) | Gross Carrying Amount |  | Useful Life |  | Amortization Method |
| Customer relationships | $ | 180.3 |  |  | 19 years |  | Straight-line |
| Trade names | 54.7 |  | 20 years |  | Straight-line |
| Total | $ | 235.0 |  |  |  |  |  |

[0001069202-26-000028:notes:374]
Subsequent to the purchase of Duro Dyne and Supco, we recognized net sales of approximately $42 million and the acquired businesses contributed approximately $6.4 million and $0.4 million to the Building Climate Solutions and Home Comfort Solutions segment profit, respectively, from the date of acquisition through December 31, 2025.

[0001069202-26-000028:notes:375]
AES

[0001069202-26-000028:notes:376]
In October 2023, we completed the acquisition of AES, a company dedicated to service and sustainability in the light commercial market. Under the terms of the purchase agreement, a final working capital adjustment was completed in the first quarter of 2024.  This working capital adjustment resulted in a $1.8 million reduction in the purchase price. Additionally, in the first and fourth quarters of 2024, we made certain purchase price adjustments. The following table details the purchase price adjustments that were made during the first and fourth quarters of 2024 (in millions):

[0001069202-26-000028:notes:377]
| (Amounts in millions) |  | December 31, 2023 |  | Adjustment |  | December 31, 2024 |
| Net tangible assets acquired |  | $ | 17.6 |  |  | $ | (1.7) |  |  | $ | 15.9 |  |
| Intangible assets acquired |  | 36.9 |  |  | 2.1 |  |  | 39.0 |  |
| Goodwill |  | 40.4 |  |  | (2.1) |  |  | 38.3 |  |
| Total investment |  | $ | 94.9 |  |  | $ | (1.7) |  |  | $ | 93.2 |  |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001069202-26-000028:notes:378]
The preliminary allocation of the purchase price as of the acquisition date was as follows:

[0001069202-26-000028:notes:379]
The following table details the purchase price adjustments that were made during the first and fourth quarters of 2024 (in millions):


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-26-000028:notes:380]
18. Quarterly Information (Unaudited)

[0001069202-26-000028:notes:381]
The following is a summary of the quarterly results of operations for the year ended December 31, 2025:

[0001069202-26-000028:notes:382]
|  | September 30, 2025(1) |  | June 30, 2025(1) |  | March 31, 2025(1) |
| Three months ended(In millions, except per share data) | As Reported | Immaterial Error Correction | Impact of LIFO Change | Adjusted |  | As Reported | Immaterial Error Correction | Impact of LIFO Change | Adjusted |  | As Reported | Immaterial Error Correction | Impact of LIFO Change | Adjusted |
| Net sales | $ | 1,426.8 |  | $ | — |  | $ | — |  | $ | 1,426.8 |  |  | $ | 1,500.9 |  | $ | — |  | $ | — |  | $ | 1,500.9 |  |  | $ | 1,072.6 |  | $ | — |  | $ | — |  | $ | 1,072.6 |  |
| Cost of goods sold | 958.2 |  | (5.4) |  | (13.2) |  | 939.6 |  |  | 978.4 |  | 1.5 |  | 3.5 |  | 983.4 |  |  | 744.1 |  | (5.1) |  | (7.3) |  | 731.7 |  |
| Gross profit | 468.6 |  | 5.4 |  | 13.2 |  | 487.2 |  |  | 522.5 |  | (1.5) |  | (3.5) |  | 517.5 |  |  | 328.5 |  | 5.1 |  | 7.3 |  | 340.9 |  |
| Operating income | 310.2 |  | 5.4 |  | 13.2 |  | 328.8 |  |  | 354.0 |  | (1.5) |  | (3.5) |  | 349.0 |  |  | 155.6 |  | 5.1 |  | 7.3 |  | 168.0 |  |
| Income before income taxes | 298.8 |  | 5.4 |  | 13.2 |  | 317.4 |  |  | 345.0 |  | (1.5) |  | (3.5) |  | 340.0 |  |  | 148.4 |  | 5.1 |  | 7.3 |  | 160.8 |  |
| Provision for income taxes | 53.0 |  | 1.3 |  | 3.2 |  | 57.5 |  |  | 67.4 |  | (0.4) |  | (0.9) |  | 66.1 |  |  | 28.1 |  | 1.3 |  | 1.8 |  | 31.2 |  |
| Net income | $ | 245.8 |  | $ | 4.1 |  | $ | 10.0 |  | $ | 259.9 |  |  | $ | 277.6 |  | $ | (1.1) |  | $ | (2.6) |  | $ | 273.9 |  |  | $ | 120.3 |  | $ | 3.8 |  | $ | 5.5 |  | $ | 129.6 |  |
| Earnings per share - Basic | $ | 7.01 |  | $ | 0.12 |  | $ | 0.28 |  | $ | 7.41 |  |  | $ | 7.86 |  | $ | (0.03) |  | $ | (0.08) |  | $ | 7.75 |  |  | $ | 3.39 |  | $ | 0.11 |  | $ | 0.15 |  | $ | 3.65 |  |
| Earnings per share - Diluted | $ | 6.98 |  | $ | 0.12 |  | $ | 0.28 |  | $ | 7.38 |  |  | $ | 7.82 |  | $ | (0.03) |  | $ | (0.08) |  | $ | 7.71 |  |  | $ | 3.37 |  | $ | 0.11 |  | $ | 0.15 |  | $ | 3.63 |  |

[0001069202-26-000028:notes:383]
(1) In the fourth quarter of 2025, we changed the method of accounting for our inventories from LIFO to FIFO. The effects of the change in accounting principle have been retrospectively applied. Through our assessment of our change in method of inventory valuation, we identified and corrected immaterial errors in the capitalization of inventory variances for the respective quarters. In accordance with ASC 250, Accounting Changes and Error Corrections, the quarterly information for the first three quarters of 2025, which had been previously reported, has been adjusted on a retrospective basis to reflect that change in accounting principle. See Note 2 for further information.

[0001069202-26-000028:notes:384]
We have assessed the impact of the change in accounting principle for the year ended December 31, 2024, and have

[0001069202-26-000028:notes:385]
determined the adjustments on a quarterly basis are immaterial.

[0001069202-26-000028:notes:386]
The following table compares the amounts currently reported for the fourth quarter to the amounts that would have been reported under LIFO (in millions):

[0001069202-26-000028:notes:387]
|  | For the Three Months Ended December 31, 2025 |
| Three months ended(In millions, except per share data) | As Reported Under FIFO | Impact of LIFO Change | Calculated Under LIFO |
| Net sales | $ | 1,195.0 |  | $ | — |  | $ | 1,195.0 |  |
| Cost of goods sold | 805.7 |  | 3.7 |  | 809.4 |  |
| Gross profit | 389.3 |  | (3.7) |  | 385.6 |  |
| Operating income | 195.8 |  | (3.7) |  | 192.1 |  |
| Income before income taxes | 178.7 |  | (3.7) |  | 175.0 |  |
| Provision for income taxes | 36.2 |  | (0.9) |  | 35.3 |  |
| Net income | $ | 142.5 |  | $ | (2.8) |  | $ | 139.7 |  |
| Earnings per share - Basic | $ | 4.08 |  | $ | (0.08) |  | $ | 4.00 |  |
| Earnings per share - Diluted | $ | 4.07 |  | $ | (0.08) |  | $ | 3.99 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001069202-26-000028:notes:388]
Daniel M. Sessa, Executive Vice President and Chief Human Resources Officer, adopted a prearranged stock trading plan on November 10, 2025. Mr. Sessa’s plan provides for the sale of approximately 3,685 shares of the Company's common stock and the exercise and sale of approximately 5,058 stock appreciation rights between February 13, 2026 and October 30, 2026.

[0001069202-26-000028:notes:389]
This trading plan was entered into during an open insider trading window and is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act and the Company's policies regarding transactions in the Company's securities.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-26-000028:notes:390]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-26-000028:notes:391]
For the Years Ended December 31, 2025, 2024 and 2023

[0001069202-26-000028:notes:392]
(In millions)

[0001069202-26-000028:notes:393]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other(1) |  | Balance at end of year |
| 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 15.5 |  |  | $ | 9.8 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | (10.7) |  |  | $ | 14.4 |  |
| 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 14.4 |  |  | $ | 8.0 |  |  | $ | (0.6) |  |  | $ | — |  |  | $ | (4.0) |  |  | $ | 17.8 |  |
| 2025 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 17.8 |  |  | $ | 1.2 |  |  | $ | (8.5) |  |  | $ | — |  |  | $ | (2.0) |  |  | $ | 8.5 |  |
| (1) 2023 consists of the sale of our European businesses and other miscellaneous items. |
