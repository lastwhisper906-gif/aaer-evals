# LII 10-K controls and the auditor's report


## auditors_report

[0001069202-26-000028:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001069202-26-000028:auditors_report:2]
To the Stockholders and the Board of Directors of Lennox International Inc.

[0001069202-26-000028:auditors_report:3]
Opinion on the Financial Statements

[0001069202-26-000028:auditors_report:4]
We have audited the accompanying consolidated balance sheet of Lennox International Inc. and subsidiaries (the Company) as of December 31, 2025, the related consolidated statements of operations, comprehensive income (loss), stockholders' equity (deficit) and cash flows for the year then ended, and the related notes and Schedule II – Valuation and Qualifying Accounts and Reserves listed in the Index at Item 15 for the year ended December 31, 2025 (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at December 31, 2025, and the results of its operations and its cash flows for the year then ended, in conformity with U.S. generally accepted accounting principles.

[0001069202-26-000028:auditors_report:5]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of December 31, 2025, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework), and our report dated February 17, 2026 expressed an unqualified opinion thereon.

[0001069202-26-000028:auditors_report:6]
Change in Accounting Principle

[0001069202-26-000028:auditors_report:7]
As discussed in Note 2 to the consolidated financial statements, the Company has elected to change its method of accounting for certain inventories to the first-in, first-out (“FIFO”) method effective October 1, 2025, with retrospective application to all periods presented.

[0001069202-26-000028:auditors_report:8]
Basis for Opinion

[0001069202-26-000028:auditors_report:9]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company’s financial statements based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001069202-26-000028:auditors_report:10]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0001069202-26-000028:auditors_report:11]
Critical Audit Matter

[0001069202-26-000028:auditors_report:12]
The critical audit matter communicated below is a matter arising from the current period audit of the financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective or complex judgments. The communication of the critical audit matter does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001069202-26-000028:auditors_report:13]
Product Warranty Liability

[0001069202-26-000028:auditors_report:14]
| Description of the Matter | As of December 31, 2025, the Company's product warranty liability was $167.2 million. As discussed in Note 2 to the consolidated financial statements, the Company accrues for product warranty liabilities based on the estimated future costs to repair or replace products under warranty. Auditing the product warranty liability is complex and involves subjective auditor judgment in assessing the assumptions used to estimate the product warranty liability, specifically, the estimated failure rates and estimated cost per failure. |
| How We Addressed the Matter in Our Audit | We obtained an understanding, evaluated the design and tested the operating effectiveness of controls over the Company’s process for estimating the product warranty liability. We tested the Company’s controls that address the risk of material misstatement related to the determination of the product warranty liability, including the key assumptions related to the estimates of the failure rates and the cost of failures, and the completeness and accuracy of data used in the model developed by management. |

[0001069202-26-000028:auditors_report:15]
To test the product warranty liability, our audit procedures included, among others, evaluating the key assumptions and the underlying data used by the Company in developing the liability estimate. As management utilizes historical trends in failure rates and average cost of failures relative to its product categories and warranty terms, we evaluated management’s methodology for determining the failure rate and cost of failure assumptions by comparing these key assumptions to trends observed in historical Company claims data. We also performed sensitivity analyses to determine the effect of changes in assumptions, where appropriate. We also tested completeness and accuracy of underlying claims data used in management’s estimation calculations and performed recalculations to evaluate the accuracy of the model used by management to determine the estimate.

[0001069202-26-000028:auditors_report:16]
/s/ Ernst & Young LLP

[0001069202-26-000028:auditors_report:17]
We have served as the Company’s auditor since 2025.

[0001069202-26-000028:auditors_report:18]
Dallas, Texas

[0001069202-26-000028:auditors_report:19]
February 17, 2026

[0001069202-26-000028:auditors_report:20]
36

[0001069202-26-000028:auditors_report:21]
Report of Independent Registered Public Accounting Firm

[0001069202-26-000028:auditors_report:22]
To the Stockholders and the Board of Directors of Lennox International Inc.

[0001069202-26-000028:auditors_report:23]
Opinion on Internal Control Over Financial Reporting

[0001069202-26-000028:auditors_report:24]
We have audited Lennox International Inc. and subsidiaries’ internal control over financial reporting as of December 31, 2025, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the COSO criteria). In our opinion, Lennox International Inc. and subsidiaries (the Company) maintained, in all material respects, effective internal control over financial reporting as of December 31, 2025, based on the COSO criteria.

[0001069202-26-000028:auditors_report:25]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated balance sheet of the Company as of December 31, 2025, the related consolidated statements of operations, comprehensive income (loss), stockholders' equity (deficit) and cash flows for the year then ended, and the related notes and Schedule II – Valuation and Qualifying Accounts and Reserves listed in the Index at Item 15 for the year ended December 31, 2025, and our report dated February 17, 2026, expressed an unqualified opinion thereon.

[0001069202-26-000028:auditors_report:26]
Basis for Opinion

[0001069202-26-000028:auditors_report:27]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001069202-26-000028:auditors_report:28]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.

[0001069202-26-000028:auditors_report:29]
Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001069202-26-000028:auditors_report:30]
Definition and Limitations of Internal Control Over Financial Reporting

[0001069202-26-000028:auditors_report:31]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001069202-26-000028:auditors_report:32]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001069202-26-000028:auditors_report:33]
/s/ Ernst & Young LLP

[0001069202-26-000028:auditors_report:34]
Dallas, Texas

[0001069202-26-000028:auditors_report:35]
February 17, 2026

[0001069202-26-000028:auditors_report:36]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001069202-26-000028:auditors_report:37]
To the Stockholders and Board of Directors

[0001069202-26-000028:auditors_report:38]
Lennox International Inc.:

[0001069202-26-000028:auditors_report:39]
Opinion on the Consolidated Financial Statements

[0001069202-26-000028:auditors_report:40]
We have audited the accompanying consolidated balance sheet of Lennox International Inc. and subsidiaries (the Company) as of December 31, 2024, the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity (deficit), and cash flows for each of the years in the two-year period ended December 31, 2024, and the related notes and Schedule II – Valuation and Qualifying Accounts and Reserves (collectively, the consolidated financial statements). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2024, and the results of its operations and its cash flows for each of the years in the two-year period ended December 31, 2024, in conformity with U.S. generally accepted accounting principles.

[0001069202-26-000028:auditors_report:41]
Basis for Opinion

[0001069202-26-000028:auditors_report:42]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on these consolidated financial statements based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001069202-26-000028:auditors_report:43]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001069202-26-000028:auditors_report:44]
/s/ KPMG LLP

[0001069202-26-000028:auditors_report:45]
We served as the Company’s auditor from 2002 to 2025.

[0001069202-26-000028:auditors_report:46]
Dallas, Texas

[0001069202-26-000028:auditors_report:47]
February 11, 2025, except for the effects of the change in accounting principle related to inventories described in Note 2, as to which the date is February 17, 2026

[0001069202-26-000028:auditors_report:48]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES


## item_9a

[0001069202-26-000028:item_9a:1]
Item 9A.  Controls and Procedures

[0001069202-26-000028:item_9a:2]
Disclosure Controls and Procedures

[0001069202-26-000028:item_9a:3]
As required by Rule 13a-15 under the Exchange Act, we carried out an evaluation, under the supervision and with the participation of our current management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures as of the end of the period covered by this report. There are inherent limitations to the effectiveness of any system of disclosure controls and procedures, including the possibility of human error and circumvention or overriding of the controls and procedures. Accordingly, even effective disclosure controls and procedures can only provide reasonable assurance of achieving their control objectives. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that, as of December 31, 2025, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in the reports we file or submit under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the applicable rules and forms, and that such information is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosure.

[0001069202-26-000028:item_9a:4]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001069202-26-000028:item_9a:5]
See “Management’s Report on Internal Control Over Financial Reporting” included in Item 8 “Financial Statements and Supplementary Data.”

[0001069202-26-000028:item_9a:6]
Attestation Report of the Independent Registered Public Accounting Firm

[0001069202-26-000028:item_9a:7]
See “Report of Independent Registered Public Accounting Firm” included on page 37 of Item 8 “Financial Statements and Supplementary Data.”

[0001069202-26-000028:item_9a:8]
Changes in Internal Control Over Financial Reporting

[0001069202-26-000028:item_9a:9]
There were no changes during the year ended December 31, 2025 in our internal control over financial reporting that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
