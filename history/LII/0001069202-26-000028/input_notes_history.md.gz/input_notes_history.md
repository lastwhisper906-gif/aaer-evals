# LII note change history — 0001069202-25-000032 → 0001069202-25-000048


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-22):
[0001069202-25-000048:note_history:1]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or
  (was, 2025-07-23, similarity 0.8434):
[0001069202-25-000032:note_history:1]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

- added (2025-10-22):
[0001069202-25-000048:note_history:2]
less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

- changed (2025-10-22):
[0001069202-25-000048:note_history:3]
|  | September 30, 2025 |  | December 31, 2024 |
| Accrued expenses | $ | 50.7 |  |  | $ | 49.1 |  |
| Other liabilities | 114.3 |  |  | 109.4 |  |
| Total warranty liability | $ | 165.0 |  |  | $ | 158.4 |  |
  (was, 2025-07-23, similarity 0.9664):
[0001069202-25-000032:note_history:3]
|  | June 30, 2025 |  | December 31, 2024 |
| Accrued expenses | $ | 47.4 |  |  | $ | 49.1 |  |
| Other liabilities | 116.7 |  |  | 109.4 |  |
| Total warranty liability | $ | 164.1 |  |  | $ | 158.4 |  |

- changed (2025-10-22):
[0001069202-25-000048:note_history:4]
The changes in product warranty liabilities for the nine months ended September 30, 2025 were as follows (in millions):
  (was, 2025-07-23, similarity 0.9279):
[0001069202-25-000032:note_history:4]
The changes in product warranty liabilities for the six months ended June 30, 2025 were as follows (in millions):

- changed (2025-10-22):
[0001069202-25-000048:note_history:5]
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Warranty claims paid | (36.3) |  |
| Changes resulting from issuance of new warranties | 39.9 |  |
| Changes in estimates associated with pre-existing liabilities | 2.7 |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of September 30, 2025 | $ | 165.0 |  |
  (was, 2025-07-23, similarity 0.9811):
[0001069202-25-000032:note_history:5]
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Warranty claims paid | (20.4) |  |
| Changes resulting from issuance of new warranties | 24.8 |  |
| Changes in estimates associated with pre-existing liabilities | 0.8 |  |
| Changes in foreign currency translation rates and other | 0.5 |  |
| Total warranty liability as of June 30, 2025 | $ | 164.1 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-10-22):
[0001069202-25-000048:note_history:6]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2025, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three and nine months ended September 30, 2025 and 2024, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2025 and 2024 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2024.

- removed (2025-10-22):
[0001069202-25-000032:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2025, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three and six months ended June 30, 2025 and 2024, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2025 and 2024 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2024.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-22):
[0001069202-25-000048:note_history:8]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.30 | % |  | — | % |
  (was, 2025-07-23, similarity 0.9371):
[0001069202-25-000032:note_history:8]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.57 | % |  | — | % |

- changed (2025-10-22):
[0001069202-25-000048:note_history:9]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |
  (was, 2025-07-23, similarity 0.9371):
[0001069202-25-000032:note_history:9]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-22):
[0001069202-25-000048:note_history:10]
|  | September 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 157.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.9 |  |  | $ | 14.9 |  |
| Senior unsecured notes | — |  |  | 300.0 |  |
| Debt issuance costs | — |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 16.9 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 44.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.5) |  |  | (6.4) |  |
| Total long-term debt | $ | 838.2 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,012.1 |  |  | $ | 1,147.6 |  |
  (was, 2025-07-23, similarity 0.9188):
[0001069202-25-000032:note_history:10]
|  | June 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 29.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.5 |  |  | $ | 14.9 |  |
| Senior unsecured notes | 300.0 |  |  | 300.0 |  |
| Debt issuance costs | (0.1) |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 316.4 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 42.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (7.0) |  |  | (6.4) |  |
| Total long-term debt | $ | 835.7 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,181.1 |  |  | $ | 1,147.6 |  |

- changed (2025-10-22):
[0001069202-25-000048:note_history:11]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $157.0 million CP Notes outstanding under the Program as of September 30, 2025.
  (was, 2025-07-23, similarity 0.9937):
[0001069202-25-000032:note_history:11]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $29.0 million CP Notes outstanding under the Program as of June 30, 2025.

- changed (2025-10-22):
[0001069202-25-000048:note_history:12]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.30 | % |  | — | % |
  (was, 2025-07-23, similarity 0.9371):
[0001069202-25-000032:note_history:12]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.57 | % |  | — | % |

- changed (2025-10-22):
[0001069202-25-000048:note_history:13]
On May 9, 2025, we entered into an Amendment and Restatement Agreement ("Amended Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Amended Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Amended Credit Agreement. The Amended Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of September 30, 2025. Subject to covenant limitations, $841.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Amended Credit Agreement is reduced by borrowings under the Program. The Amended Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Amended Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Amended Credit Agreement.
  (was, 2025-07-23, similarity 0.9947):
[0001069202-25-000032:note_history:13]
On May 9, 2025, we entered into an Amendment and Restatement Agreement ("Amended Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Amended Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Amended Credit Agreement. The Amended Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of June 30, 2025. Subject to covenant limitations, $969.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Amended Credit Agreement is reduced by borrowings under the Program. The Amended Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Amended Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Amended Credit Agreement.

- changed (2025-10-22):
[0001069202-25-000048:note_history:14]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |
  (was, 2025-07-23, similarity 0.9371):
[0001069202-25-000032:note_history:14]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |

- changed (2025-10-22):
[0001069202-25-000048:note_history:15]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding      $75.0 million; or
  (was, 2025-07-23, similarity 0.9962):
[0001069202-25-000032:note_history:15]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

- changed (2025-10-22):
[0001069202-25-000048:note_history:16]
•We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.
  (was, 2025-07-23, similarity 0.9983):
[0001069202-25-000032:note_history:16]
• We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

- changed (2025-10-22):
[0001069202-25-000048:note_history:17]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  In July 2020, we issued $300.0 million of senior unsecured notes, which will mature on August 1, 2027 (the "2027 Notes," and collectively with the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.70% per annum. On August 1, 2025, we repaid upon maturity $300.0 million of senior unsecured notes originally issued in 2020. 
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Amended Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.
  (was, 2025-07-23, similarity 0.9226):
[0001069202-25-000032:note_history:17]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Amended Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-22):
[0001069202-25-000048:note_history:18]
|  | September 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 157.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.9 |  |  | $ | 14.9 |  |
| Senior unsecured notes | — |  |  | 300.0 |  |
| Debt issuance costs | — |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 16.9 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 44.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.5) |  |  | (6.4) |  |
| Total long-term debt | $ | 838.2 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,012.1 |  |  | $ | 1,147.6 |  |
  (was, 2025-07-23, similarity 0.9188):
[0001069202-25-000032:note_history:18]
|  | June 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 29.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.5 |  |  | $ | 14.9 |  |
| Senior unsecured notes | 300.0 |  |  | 300.0 |  |
| Debt issuance costs | (0.1) |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 316.4 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 42.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (7.0) |  |  | (6.4) |  |
| Total long-term debt | $ | 835.7 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,181.1 |  |  | $ | 1,147.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-10-22):
[0001069202-25-000048:note_history:19]
| (Amounts in millions) | For the Three Months Ended September 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 850.1 |  |  | $ | 478.3 |  |  | $ | — |  |  | $ | 1,328.4 |  |
| Canada | 62.8 |  |  | 35.6 |  |  | — |  |  | 98.4 |  |
| Total | $ | 912.9 |  |  | $ | 513.9 |  |  | $ | — |  |  | $ | 1,426.8 |  |
  (was, 2025-07-23, similarity 0.6667):
[0001069202-25-000032:note_history:19]
|  | For the Three Months Ended June 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 941.0 |  |  | $ | 455.6 |  |  | $ | — |  |  | $ | 1,396.6 |  |
| Canada | 68.3 |  |  | 36.0 |  |  | — |  |  | 104.3 |  |
| Total | $ | 1,009.3 |  |  | $ | 491.6 |  |  | $ | — |  |  | $ | 1,500.9 |  |

- changed (2025-10-22):
[0001069202-25-000048:note_history:20]
|  | For the Three Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 971.1 |  |  | $ | 441.9 |  |  | $ | — |  |  | $ | 1,413.0 |  |
| Canada | 61.7 |  |  | 23.4 |  |  | — |  |  | 85.1 |  |
| Total | $ | 1,032.8 |  |  | $ | 465.3 |  |  | $ | — |  |  | $ | 1,498.1 |  |
  (was, 2025-07-23, similarity 0.6887):
[0001069202-25-000032:note_history:20]
|  | For the Three Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 923.5 |  |  | $ | 445.0 |  |  | $ | — |  |  | $ | 1,368.5 |  |
| Canada | 58.8 |  |  | 23.8 |  |  | — |  |  | 82.6 |  |
| Total | $ | 982.3 |  |  | $ | 468.8 |  |  | $ | — |  |  | $ | 1,451.1 |  |

- changed (2025-10-22):
[0001069202-25-000048:note_history:21]
|  | For the Nine Months Ended September 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,458.9 |  |  | $ | 1,266.6 |  |  | $ | — |  |  | $ | 3,725.5 |  |
| Canada | 184.7 |  |  | 90.1 |  |  | — |  |  | 274.8 |  |
| Total | $ | 2,643.6 |  |  | $ | 1,356.7 |  |  | $ | — |  |  | $ | 4,000.3 |  |
  (was, 2025-07-23, similarity 0.6344):
[0001069202-25-000032:note_history:21]
|  | For the Six Months Ended June 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,608.9 |  |  | $ | 788.3 |  |  | $ | — |  |  | $ | 2,397.2 |  |
| Canada | 121.8 |  |  | 54.5 |  |  | — |  |  | 176.3 |  |
| Total | $ | 1,730.7 |  |  | $ | 842.8 |  |  | $ | — |  |  | $ | 2,573.5 |  |

- changed (2025-10-22):
[0001069202-25-000048:note_history:22]
|  | For the Nine Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,520.7 |  |  | $ | 1,244.2 |  |  | $ | — |  |  | $ | 3,764.9 |  |
| Canada | 169.0 |  |  | 62.4 |  |  | — |  |  | 231.4 |  |
| Total | $ | 2,689.7 |  |  | $ | 1,306.6 |  |  | $ | — |  |  | $ | 3,996.3 |  |
  (was, 2025-07-23, similarity 0.6344):
[0001069202-25-000032:note_history:22]
|  | For the Six Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,549.6 |  |  | $ | 802.3 |  |  | $ | — |  |  | $ | 2,351.9 |  |
| Canada | 107.3 |  |  | 39.0 |  |  | — |  |  | 146.3 |  |
| Total | $ | 1,656.9 |  |  | $ | 841.3 |  |  | $ | — |  |  | $ | 2,498.2 |  |

- added (2025-10-22):
[0001069202-25-000048:note_history:23]
installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2025 and 2024, direct sales represented 75% and 73% of revenues, respectively, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2025 and 2024, direct sales represented 74% and 74% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2025-10-22):
[0001069202-25-000048:note_history:24]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada; manufacture curb, curb adapters, drop box diffusers; offer HVAC recycling and salvage services; and focus on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2025 and 2024, equipment sales represented 80% and 80% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2025 and 2024, equipment sales represented 80% and 81% of revenues and the remainder of our revenue was generated from our service business.
  (was, 2025-07-23, similarity 0.981):
[0001069202-25-000032:note_history:24]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada; manufacture curb, curb adapters, drop box diffusers; offer HVAC recycling and salvage services; and focus on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended June 30, 2025 and 2024, equipment sales represented 81% and 82% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2025 and 2024, equipment sales represented 80% and 81% of revenues and the remainder of our revenue was generated from our service business.

- added (2025-10-22):
[0001069202-25-000048:note_history:25]
|  | September 30, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 3.1 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (11.1) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (10.1) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (18.1) |  |  | $ | (12.2) |  |  |  |  |  |

- changed (2025-10-22):
[0001069202-25-000048:note_history:26]
For the three months ended September 30, 2025 and 2024, we recognized revenue of $5.4 million and $0.7 million and for the nine months ended September 30, 2025 and 2024, we recognized revenue of $8.5 million and $6.8 million related to our contract liabilities at January 1, 2025 and 2024, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025 and 2024.
  (was, 2025-07-23, similarity 0.9149):
[0001069202-25-000032:note_history:26]
For the three months ended June 30, 2025 and 2024, we recognized revenue of $0.8 million and $0.4 million and for the six months ended June 30, 2025 and 2024, we recognized revenue of $3.1 million and $6.1 million related to our contract liabilities at January 1, 2025 and 2024, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025 and 2024.

- removed (2025-10-22):
[0001069202-25-000032:note_history:27]
installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2025 and 2024, direct sales represented 74% and 76% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2025 and 2024, direct sales represented 74% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- removed (2025-10-22):
[0001069202-25-000032:note_history:28]
|  | June 30, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 1.7 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (9.7) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (9.5) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (17.5) |  |  | $ | (12.2) |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-10-22):
[0001069202-25-000048:note_history:29]
13. Subsequent Events:

- added (2025-10-22):
[0001069202-25-000048:note_history:30]
Acquisition – Duro Dyne and Supco

- added (2025-10-22):
[0001069202-25-000048:note_history:31]
On October 15, 2025, the Company completed the previously announced acquisition of Duro Dyne Buyer, Inc. and Sealed Unit Parts Buyer, Inc. (“Duro Dyne and Supco”). Duro Dyne and Supco offer a robust portfolio of HVAC parts and supplies that complement our existing residential and commercial offerings. Excluding cash received at the closing, the net purchase price for the acquisition was $546.3 million. We used cash on hand and available borrowing capacity to fund the purchase price.  The purchase price is subject to final adjustments for net working capital. The financial results of Duro Dyne and Supco will be included beginning in the fourth quarter of 2025.

- added (2025-10-22):
[0001069202-25-000048:note_history:32]
Due to the timing of this transaction, the allocation of the purchase price has not yet been finalized.

- added (2025-10-22):
[0001069202-25-000048:note_history:33]
Term Credit Agreement

- added (2025-10-22):
[0001069202-25-000048:note_history:34]
On October 16, 2025, we entered into a Term Credit Agreement (the “Term Credit Agreement”) with Wells Fargo Bank, National Association, as administrative agent, and the other lenders party thereto. We borrowed $300.0 million pursuant to the Term Credit Agreement and used the net proceeds to repay existing borrowings under the Amended Credit Agreement. The Term Credit Agreement matures on October 16, 2027. Loans under the Term Credit Agreement bear interest at our election at a rate per annum equal to (i) a forward-looking term rate based on the secured overnight financing rate for the applicable interest period ("Term SOFR"), plus an applicable margin ranging between 0.90% and 1.025% per annum depending on our long-term unsecured debt rating, or (ii) the highest of the Wells Fargo Bank, National Association prime rate, the Federal Funds rate plus 0.50%, and Term SOFR for a one month tenor in effect on such day plus 1.00%, plus an applicable margin ranging between 0.00% and 0.025% per annum depending on our long-term unsecured debt rating.

- added (2025-10-22):
[0001069202-25-000048:note_history:35]
The Term Credit Agreement is guaranteed by the Guarantor Subsidiaries and contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Amended Credit Agreement.
