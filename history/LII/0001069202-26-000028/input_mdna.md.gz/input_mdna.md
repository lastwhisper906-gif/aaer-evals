# LII MD&A — 0001069202-26-000028


## mdna

[0001069202-26-000028:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-26-000028:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the Consolidated Financial Statements and related Notes to the Consolidated Financial Statements in Item 8, “Other Financial Statement Details,” of this Annual Report on Form 10-K.

[0001069202-26-000028:mdna:3]
Forward-Looking Statements

[0001069202-26-000028:mdna:4]
The following are some of the factors that could cause actual results to differ materially from those expressed or implied in forward-looking statements:

[0001069202-26-000028:mdna:5]
•competition in the HVACR business;

[0001069202-26-000028:mdna:6]
•our ability to successfully develop and market new products or execute our business strategy, including the implementation of price increases for products and services;

[0001069202-26-000028:mdna:7]
•our ability to meet and anticipate customer demands;

[0001069202-26-000028:mdna:8]
•our ability to continue to license or enforce our intellectual property rights;

[0001069202-26-000028:mdna:9]
•our ability to attract, motivate, develop and retain our employees, as well as labor relations problems;

[0001069202-26-000028:mdna:10]
•artificial intelligence technologies;

[0001069202-26-000028:mdna:11]
•a decline in new construction activity and related demand for our products and services;

[0001069202-26-000028:mdna:12]
•the impact of weather on our business;

[0001069202-26-000028:mdna:13]
•the impact of higher raw material prices and significant supply interruptions;

[0001069202-26-000028:mdna:14]
•product liability, warranty claims, or recalls;

[0001069202-26-000028:mdna:15]
•changes in environmental and climate-related legislation or government regulations or policies;

[0001069202-26-000028:mdna:16]
•changes in tax legislation;

[0001069202-26-000028:mdna:17]
•the impact of new or increased trade tariffs;

[0001069202-26-000028:mdna:18]
•improper conduct by any of our employees, agents, or business partners;

[0001069202-26-000028:mdna:19]
•litigation risks;

[0001069202-26-000028:mdna:20]
•general economic conditions in the U.S. and abroad;

[0001069202-26-000028:mdna:21]
•extraordinary events beyond our control, such as conflicts, wars, natural disasters, public health crises, terrorist acts, or other civil or political disruptions;

[0001069202-26-000028:mdna:22]
•risks associated with our international operations;

[0001069202-26-000028:mdna:23]
•cyber attacks and other disruptions or misuse of information systems; and

[0001069202-26-000028:mdna:24]
•our ability to successfully realize, complete and integrate acquisitions.

[0001069202-26-000028:mdna:25]
Business Overview

[0001069202-26-000028:mdna:26]
We operate in two reportable business segments of the HVACR industry, Home Comfort Solutions and Building Climate Solutions. In addition to the two major business segments, Corporate and Other is also reported as a segment. For more detailed information regarding our reportable segments, see Note 3 in the Notes to the Consolidated Financial Statements.

[0001069202-26-000028:mdna:27]
In the fourth quarter of 2023, we completed the sale of our European businesses. The European businesses were presented with the Corporate and Other business segment until their divestiture.

[0001069202-26-000028:mdna:28]
In October 2025, we completed the acquisition of Duro Dyne and Supco, a robust portfolio of HVAC parts and supplies that complement our existing residential and commercial offerings. Duro Dyne is reported in our Business Climate Solutions segment, and Supco is reported in our Home Comfort Solutions segment.

[0001069202-26-000028:mdna:29]
In October 2023, we completed the acquisition of AES, which is included in our Building Climate Solutions segment. AES is a company dedicated to service and sustainability in the light commercial markets across North America.

[0001069202-26-000028:mdna:30]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and can be significantly impacted by the weather. Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services. Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services. In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence. A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-26-000028:mdna:31]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs. The principal raw materials used in our manufacturing processes are steel, aluminum and copper. In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general. We seek to mitigate the impact of certain commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-26-000028:mdna:32]
In the fourth quarter of 2025, we changed the method of accounting for our inventories from last-in-first-out (“LIFO”) to first-in-first-out (“FIFO”). We believe the FIFO method is preferable because it more closely matches the physical flow of materials through purchasing, receiving, warehousing, production and order fulfillment, it results in a more consistent method to value inventory across the Company, and it improves comparability with industry peers. This change increased Retained Earnings by $106.6 million as of January 1, 2023, and increased net income by $1.1 million and $4.2 million for the years ended December 31, 2023 and 2024, respectively. All prior amounts have been adjusted.

[0001069202-26-000028:mdna:33]
Financial Highlights

[0001069202-26-000028:mdna:34]
•Net sales decreased $146 million, or 3%, to $5,195 million in 2025 from $5,341 million in 2024.

[0001069202-26-000028:mdna:35]
•Operating income in 2025 was $1,042 million compared to $1,040 million in 2024.

[0001069202-26-000028:mdna:36]
•Net income in 2025 decreased to $806 million from $811 million in 2024.

[0001069202-26-000028:mdna:37]
•Diluted earnings per share was $22.79 per share in 2025 compared to $22.66 per share in 2024.

[0001069202-26-000028:mdna:38]
•We generated $758 million of cash flow from operating activities in 2025 compared to $946 million in 2024.

[0001069202-26-000028:mdna:39]
•We returned $173 million to shareholders through dividend payments and repurchased $482 million as part of our Share Repurchase Plans in 2025.

[0001069202-26-000028:mdna:40]
Recent Developments

[0001069202-26-000028:mdna:41]
On July 4, 2025, the One Big Beautiful Bill Act (the “OBBBA”) was enacted into law, introducing significant changes to corporate income tax rates and deductions. For fiscal year 2025, the OBBBA did not have a material impact on our effective tax rate. We continue to evaluate the future impact of the OBBBA for those provisions that are effective after fiscal year 2025.

[0001069202-26-000028:mdna:42]
Overview of Results

[0001069202-26-000028:mdna:43]
The Home Comfort Solutions segment experienced a 7% decrease in net sales and a $32 million decrease in segment profit in 2025 as compared to 2024 primarily driven by lower sales volumes. Our Building Climate Solutions segment saw an increase in net sales of 5% and a $33 million increase in segment profit in 2025 compared to 2024, primarily due to favorable price and mix.

[0001069202-26-000028:mdna:44]
Results of Operations

[0001069202-26-000028:mdna:45]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-26-000028:mdna:46]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 5,195.3 |  |  | 100.0 | % |  | $ | 5,341.3 |  |  | 100.0 | % |  | $ | 4,981.9 |  |  | 100.0 | % |
| Cost of goods sold | 3,460.5 |  |  | 66.6 | % |  | 3,563.8 |  |  | 66.7 | % |  | 3,432.7 |  |  | 68.9 | % |
| Gross profit | 1,734.8 |  |  | 33.4 | % |  | 1,777.5 |  |  | 33.3 | % |  | 1,549.2 |  |  | 31.1 | % |
| Selling, general and administrative expenses | 681.4 |  |  | 13.1 | % |  | 730.6 |  |  | 13.7 | % |  | 705.5 |  |  | 14.2 | % |
| Losses (gains) and other expenses, net | 12.0 |  |  | 0.2 | % |  | 12.9 |  |  | 0.2 | % |  | 8.5 |  |  | 0.2 | % |
| Restructuring charges | 6.8 |  |  | 0.1 | % |  | — |  |  | — | % |  | 3.1 |  | 0.1 | % |
| Impairment on assets held for sale | — |  |  | — | % |  | — |  |  | — | % |  | 63.2 |  |  | 1.3 | % |
| Loss (gain) on sale of businesses | (0.9) |  |  | — | % |  | 1.5 |  |  | — | % |  | (14.1) |  |  | (0.3) | % |
| Income from equity method investments | (6.0) |  |  | (0.1) | % |  | (7.9) |  |  | (0.1) | % |  | (8.5) |  |  | (0.2) | % |
| Operating income | $ | 1,041.5 |  |  | 20.0 | % |  | $ | 1,040.4 |  |  | 19.5 | % |  | $ | 791.5 |  |  | 15.9 | % |
| Net income | $ | 805.8 |  |  | 15.5 | % |  | $ | 811.1 |  |  | 15.2 | % |  | $ | 591.2 |  |  | 11.9 | % |

[0001069202-26-000028:mdna:47]
Year Ended December 31, 2025 Compared to Year Ended December 31, 2024 - Consolidated Results

[0001069202-26-000028:mdna:48]
Net Sales

[0001069202-26-000028:mdna:49]
Net sales decreased 3% in 2025 compared to 2024 as lower sales volumes of 13% were partially offset by favorable price and mix of 9% and a 1% increase in sales volumes due to our fourth quarter acquisition of Duro Dyne and Supco.

[0001069202-26-000028:mdna:50]
Gross Profit

[0001069202-26-000028:mdna:51]
Gross profit margins for 2025 increased 10 basis points (“bps”) to 33.4% compared to 33.3% in 2024. Gross profit margin increased 290 bps from higher price and favorable mix, which was partially offset by 160 bps from higher products costs and 120 bps from higher freight and distribution costs.

[0001069202-26-000028:mdna:52]
Selling, General and Administrative Expenses

[0001069202-26-000028:mdna:53]
SG&A expenses decreased by $49 million in 2025 compared to 2024. As a percentage of net sales, SG&A expenses decreased 60 bps from 13.7% to 13.1% in the same periods, primarily due to lower employee-related costs including reduced incentive compensation and reduced discretionary expenses.

[0001069202-26-000028:mdna:54]
Losses and Other Expenses, Net

[0001069202-26-000028:mdna:55]
Losses and other expenses, net for 2025 and 2024 included the following (in millions):

[0001069202-26-000028:mdna:56]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2024 |
| Foreign currency exchange (gains) losses | (10.5) |  |  | 7.7 |  |
| Loss (gain) on disposal of fixed assets | 1.1 |  |  | (2.1) |  |
| Acquisition costs | 10.3 |  |  | — |  |
| Other operating loss | 0.2 |  |  | 0.5 |  |
| Environmental liabilities and special litigation charges | 10.9 |  |  | 6.8 |  |
| Losses and other expenses, net (pre-tax) | $ | 12.0 |  |  | $ | 12.9 |  |

[0001069202-26-000028:mdna:57]
Foreign currency exchange gains increased in 2025 primarily due to changes in foreign exchange rates in our primary markets. Acquisition costs are related to the acquisition of Duro Dyne and Supco. The acquisition occurred in the fourth quarter

[0001069202-26-000028:mdna:58]
of 2025. The Environmental liabilities and special litigation charges in 2025 relate to estimated remediation costs at some of our facilities and outstanding legal settlements including asbestos. Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including asbestos-related litigation, and environmental liabilities.

[0001069202-26-000028:mdna:59]
Restructuring Charges

[0001069202-26-000028:mdna:60]
There were $6.8 million in restructuring charges in 2025 to realize SG&A and distribution efficiencies. There were no charges in 2024. For more information on our restructuring activities, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-26-000028:mdna:61]
Goodwill

[0001069202-26-000028:mdna:62]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2025. Refer to Note 9 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-26-000028:mdna:63]
Income from Equity Method Investments

[0001069202-26-000028:mdna:64]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments was $6 million in 2025 as compared to $8 million in 2024.

[0001069202-26-000028:mdna:65]
Interest Expense, net

[0001069202-26-000028:mdna:66]
Net interest expense of $41 million in 2025 increased slightly from $39 million in 2024 primarily due to increased borrowings as a result of decreased cash flow.

[0001069202-26-000028:mdna:67]
Income Taxes

[0001069202-26-000028:mdna:68]
The income tax provision was $191 million in 2025 compared to $188 million in 2024, and the effective tax rate was 19.2% in 2025 compared to 18.8% in 2024. The 2025 and 2024 effective tax rates differ from the statutory rate of 21% primarily due to foreign taxes. Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001069202-26-000028:mdna:69]
Year Ended December 31, 2025 Compared to Year Ended December 31, 2024 - Results by Segment

[0001069202-26-000028:mdna:70]
Home Comfort Solutions

[0001069202-26-000028:mdna:71]
The following table presents our Home Comfort Solutions segment’s net sales and profit for 2025 and 2024 (dollars in millions):

[0001069202-26-000028:mdna:72]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 3,343.4 |  |  | $ | 3,577.1 |  |  | $ | (233.7) |  |  | (7)% |
| Segment profit | $ | 728.5 |  |  | $ | 760.5 |  |  | $ | (32.0) |  |  | (4)% |
| % of net sales | 21.8 | % |  | 21.3 | % |  |  |  |  |

[0001069202-26-000028:mdna:73]
Net sales decreased 7% in 2025 compared to 2024 as a 17% decrease in sales volumes was partially offset by a 10% increase in price and mix.

[0001069202-26-000028:mdna:74]
Segment profit in 2025 decreased $32 million compared to 2024 primarily due to $224 million reduction in sales volumes, $64 million increase in product costs and factory inefficiencies, and $47 million in higher freight and distribution costs. Partially offsetting these decreases was $256 million in favorable price and mix and $47 million from improvement in other costs, including selling expenses.

[0001069202-26-000028:mdna:75]
Building Climate Solutions

[0001069202-26-000028:mdna:76]
The following table presents our Building Climate Solutions segment’s net sales and profit for 2025 and 2024 (dollars in millions):

[0001069202-26-000028:mdna:77]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 1,851.9 |  |  | $ | 1,764.2 |  |  | $ | 87.7 |  |  | 5 | % |
| Segment profit | $ | 434.2 |  |  | $ | 401.7 |  |  | $ | 32.5 |  |  | 9 | % |
| % of net sales | 23.4 | % |  | 22.8 | % |  |  |  |  |

[0001069202-26-000028:mdna:78]
Net sales increased 5% in 2025 compared to 2024 due to an 8% increase in favorable price and mix and a 2% increase in sales volumes from our Duro Dyne acquisition, which were partially offset by a 5% decrease in sales volumes.

[0001069202-26-000028:mdna:79]
Segment profit in 2025 increased $33 million compared to 2024 due to $100 million from price and mix benefit. Partially offsetting this increase was $31 million in lower sales volumes, a $16 million increase in product costs, net of factory efficiencies, and $20 million from inflation in distribution and selling as well as other discretionary spend.

[0001069202-26-000028:mdna:80]
Corporate and Other

[0001069202-26-000028:mdna:81]
The following table presents our Corporate and Other segment’s net sales and loss for 2025 and 2024 (dollars in millions):

[0001069202-26-000028:mdna:82]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | — |  | $ | — |  |  | $ | — |  |  | N/A |
| Loss | $ | (105.0) |  |  | $ | (120.3) |  |  | $ | 15.3 |  |  | (13) | % |

[0001069202-26-000028:mdna:83]
Corporate and Other costs decreased $15 million in 2025 as compared to 2024, primarily due to lower employee costs, including reduced incentive compensation, as well as improved productivity in consultant spending.

[0001069202-26-000028:mdna:84]
Year Ended December 31, 2024 Compared to Year Ended December 31, 2023 - Consolidated Results

[0001069202-26-000028:mdna:85]
Net Sales

[0001069202-26-000028:mdna:86]
Net sales increased 7% in 2024 compared to 2023 as higher sales volumes of 8%, favorable price and mix of 3% and an increase of sales volumes of 1% from our AES acquisition were partially offset by a 5% reduction in sales due to the fourth quarter 2023 sale of our European businesses.

[0001069202-26-000028:mdna:87]
Gross Profit

[0001069202-26-000028:mdna:88]
Gross profit margins for 2024 increased 220 bps to 33.3% compared to 31.1% in 2023. Gross profit margin increased 250 bps from higher price and favorable mix, which was partially offset by 30 bps from higher freight and distribution costs and product costs.

[0001069202-26-000028:mdna:89]
Selling, General and Administrative Expenses

[0001069202-26-000028:mdna:90]
SG&A expenses increased by $25 million in 2024 compared to 2023. As a percentage of net sales, SG&A expenses decreased 50 bps from 14.2% to 13.7% in the same periods, primarily due to higher employee-related costs including increased incentive compensation, which was partially offset by a $62 million reduction in SG&A expenses from our 2023 divestiture of our European businesses.

[0001069202-26-000028:mdna:91]
Losses and Other Expenses, Net

[0001069202-26-000028:mdna:92]
Losses and other expenses, net for 2024 and 2023 included the following (in millions):

[0001069202-26-000028:mdna:93]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |
| Realized losses on settled futures contracts | $ | — |  |  | $ | 0.1 |  |
| Foreign currency exchange losses (gains) | 7.7 |  |  | (4.3) |  |
| Gain on disposal of fixed assets | (2.1) |  |  | (0.5) |  |
| Other operating income (loss) | 0.5 |  |  | (1.6) |  |
| Net change in unrealized gains on unsettled futures contracts | — |  |  | (0.1) |  |
| Environmental liabilities and special litigation charges | 6.8 |  |  | 15.6 |  |
| Other items, net | — |  |  | (0.7) |  |
| Losses and other expenses, net | $ | 12.9 |  |  | $ | 8.5 |  |

[0001069202-26-000028:mdna:94]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices. For more information on our derivatives, see Note 9 in the Notes to the Consolidated Financial Statements. Foreign currency exchange losses increased in 2024 primarily due to changes in foreign exchange rates in our primary markets. Environmental liabilities and special litigation charges in 2024 relate to estimated remediation costs at some of our facilities and outstanding legal settlements including asbestos. Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including asbestos-related litigation, and environmental liabilities.

[0001069202-26-000028:mdna:95]
Restructuring Charges

[0001069202-26-000028:mdna:96]
There were no restructuring charges in 2024 compared to $3.1 million in 2023. Charges in 2023 were related to the reorganization or removal of duplicative headcount and infrastructure. For more information on our restructuring activities, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-26-000028:mdna:97]
Goodwill

[0001069202-26-000028:mdna:98]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2024. Refer to Note 9 in the Notes to the Consolidated Financial Statements for more information on goodwill. In 2023, we recorded a $2.3 million impairment of goodwill related to our agreement to sell our European commercial HVAC and refrigeration businesses.

[0001069202-26-000028:mdna:99]
Asset Impairments

[0001069202-26-000028:mdna:100]
We did not have any impairments of assets in 2024. In the third quarter of 2023, we recorded a $22.6 million impairment of property, plant and equipment related to our agreement to sell our European commercial HVAC and refrigeration businesses.

[0001069202-26-000028:mdna:101]
Income from Equity Method Investments

[0001069202-26-000028:mdna:102]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments was $8 million in 2024 consistent with 2023.

[0001069202-26-000028:mdna:103]
Interest Expense, net

[0001069202-26-000028:mdna:104]
Net interest expense of $39 million in 2024 decreased from $52 million in 2023 primarily due to decreased borrowings as a result of increased cash flow.

[0001069202-26-000028:mdna:105]
Income Taxes

[0001069202-26-000028:mdna:106]
The income tax provision was $188 million in 2024 compared to $148 million in 2023, and the effective tax rate was 18.8% in 2024 compared to 20.0% in 2023. The 2024 and 2023 effective tax rates differ from the statutory rate of 21% primarily due to foreign taxes. Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001069202-26-000028:mdna:107]
Year Ended December 31, 2024 Compared to Year Ended December 31, 2023 - Results by Segment

[0001069202-26-000028:mdna:108]
Home Comfort Solutions

[0001069202-26-000028:mdna:109]
The following table presents our Home Comfort Solutions segment’s net sales and profit for 2024 and 2023 (dollars in millions):

[0001069202-26-000028:mdna:110]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 3,577.1 |  | $ | 3,222.9 |  | $ | 354.2 |  |  | 11% |
| Segment profit | $ | 760.5 |  | $ | 611.6 |  | $ | 148.9 |  |  | 24% |
| % of net sales | 21.3 | % |  | 19.0 | % |  |  |  |  |

[0001069202-26-000028:mdna:111]
Net sales increased 11% in 2024 compared to 2023 due to a 7% increase in volume and a 4% increase in price and mix.

[0001069202-26-000028:mdna:112]
Segment profit in 2024 increased $149 million compared to 2023 primarily due to $122 million from higher price and favorable mix, $90 million from higher sales volumes and $9 million from factory productivity and favorable product costs. Partially offsetting these increases were $37 million from higher SG&A costs, $20 million from higher freight and distribution costs, $9 million from unfavorable foreign currency, and $6 million from miscellaneous other items.

[0001069202-26-000028:mdna:113]
Building Climate Solutions

[0001069202-26-000028:mdna:114]
The following table presents our Building Climate Solutions segment’s net sales and profit for 2024 and 2023 (dollars in millions):

[0001069202-26-000028:mdna:115]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 1,764.2 |  | $ | 1,511.4 |  | $ | 252.8 |  |  | 17% |
| Segment profit | $ | 401.7 |  | $ | 340.8 |  | $ | 60.9 |  |  | 18% |
| % of net sales | 22.8 | % |  | 22.5 | % |  |  |  |  |

[0001069202-26-000028:mdna:116]
Net sales increased 17% in 2024 compared to 2023 primarily due to a 9% increase in sales volumes, a 3% increase in higher price and favorable mix, and a 5% increase in sales volumes from our AES acquisition.

[0001069202-26-000028:mdna:117]
Segment profit in 2024 increased $61 million compared to 2023 primarily due to $44 million from higher sales volumes, $39 million from price and mix benefit, and $15 million from our AES acquisition. Partially offsetting these increases were $28 million in expenses from higher factory inefficiencies, which includes costs related to the ramp up of our new facility in Mexico, slightly higher product costs, and $9 million of inflationary wage impacts.

[0001069202-26-000028:mdna:118]
Corporate and Other

[0001069202-26-000028:mdna:119]
The following table presents our Corporate and Other segment’s net sales and loss for 2024 and 2023 (dollars in millions):

[0001069202-26-000028:mdna:120]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | 247.6 |  |  | $ | (247.6) |  |  | (100) | % |
| Loss | $ | (120.3) |  |  | $ | (93.9) |  |  | $ | (26.4) |  |  | 28 | % |

[0001069202-26-000028:mdna:121]
Net sales decreased $248 million and segment loss increased $26 million in 2024 as compared to 2023. Our European businesses, which were sold in 2023, generated net sales of $248 million and a profit of $7 million in 2023. Excluding our European business, Corporate and Other costs increased $19 million in 2024 as compared to 2023 primarily due to higher incentive compensation and other employee costs and wage inflation.

[0001069202-26-000028:mdna:122]
Accounting for Futures Contracts

[0001069202-26-000028:mdna:123]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date. Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations. See Note 9 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 3 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to operating income.

[0001069202-26-000028:mdna:124]
Liquidity and Capital Resources

[0001069202-26-000028:mdna:125]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and our commercial paper program. Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-26-000028:mdna:126]
Statement of Cash Flows

[0001069202-26-000028:mdna:127]
The following table summarizes our cash flow activity for the years ended December 31, 2025, 2024 and 2023 (in millions):

[0001069202-26-000028:mdna:128]
|  | 2025 |  | 2024 |  | 2023 |
| Net cash provided by operating activities | $ | 757.6 |  |  | $ | 945.7 |  |  | $ | 736.2 |  |
| Net cash used in investing activities | $ | (655.6) |  |  | $ | (174.4) |  |  | $ | (319.7) |  |
| Net cash used in financing activities | $ | (465.7) |  |  | $ | (418.6) |  |  | $ | (406.2) |  |

[0001069202-26-000028:mdna:129]
Net Cash Provided By Operating Activities - Net cash provided by operating activities decreased $188 million to $758 million in 2025 compared to $946 million in 2024. The decrease was primarily attributable to an increase in net working capital of $217 million.

[0001069202-26-000028:mdna:130]
Net Cash Used In Investing Activities - Net cash used in investing activities increased $481 million from 2024 to 2025 primarily due to $545 million related to our acquisition of Duro Dyne and Supco, which was partially offset by lower capital expenditures. Capital expenditures were $119 million, $164 million and $250 million in 2025, 2024 and 2023, respectively. Capital expenditures in 2025 were primarily related to the expansion of our manufacturing capacity equipment and investments in systems and software to support the overall enterprise.

[0001069202-26-000028:mdna:131]
Net Cash Used In Financing Activities - Net cash used in financing activities was $466 million in 2025 and $419 million in 2024. The increase was primarily due to share repurchases in 2025, offset by higher net debt borrowings. We repurchased $482 million and $54 million in 2025 and 2024, respectively, as part of our Share Repurchase Plans. There were no repurchases in 2023. We also returned $173 million to shareholders through dividend payments in 2025.

[0001069202-26-000028:mdna:132]
Debt Position

[0001069202-26-000028:mdna:133]
The following table details our lines of credit and financing arrangements as of December 31, 2025 (in millions):

[0001069202-26-000028:mdna:134]
|  | Outstanding Borrowings |
| Commercial paper: | $ | 226.0 |  |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 18.3 |  |
| Total current maturities of long-term debt | $ | 18.3 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 50.6 |  |
| Term loan | 300.0 |  |
| Senior unsecured notes | 800.0 |  |
| Debt issuance costs | (6.5) |  |
| Total long-term debt | $ | 1,144.1 |  |
| Total debt | $ | 1,388.4 |  |

[0001069202-26-000028:mdna:135]
Commercial Paper Program

[0001069202-26-000028:mdna:136]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There are $226.0 million in CP Notes outstanding under the Program as of December 31, 2025.

[0001069202-26-000028:mdna:137]
Credit Agreement

[0001069202-26-000028:mdna:138]
On May 9, 2025, we entered into an Amendment and Restatement Agreement (the “Credit Agreement”) to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. Our Credit Agreement consists of a $1.0 billion unsecured revolving credit facility with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Credit Agreement. We had no outstanding borrowings as well as $1.7 million committed to standby letters of credit as of December 31, 2025. Subject to covenant limitations, $772.3 million was available for future borrowings after taking into consideration outstanding borrowings under the Program. The Credit Agreement includes a subfacility for swingline loans of up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in May 2030, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001069202-26-000028:mdna:139]
Term Loan

[0001069202-26-000028:mdna:140]
On October 16, 2025, we entered into a Term Credit Agreement (the “Term Credit Agreement”) with Wells Fargo Bank, National Association, as administrative agent, and the other lenders party thereto. We borrowed $300.0 million pursuant to the Term Credit Agreement and used the net proceeds to repay existing borrowings under the Credit Agreement. The Term Credit Agreement matures on October 16, 2027. Loans under the Term Credit Agreement bear interest at our election at a rate per annum equal to (i) a forward-looking term rate based on the secured overnight financing rate for the applicable interest period ("Term SOFR"), plus an applicable margin ranging between 0.90% and 1.025% per annum depending on our long-term unsecured debt rating, or (ii) the highest of the Wells Fargo Bank, National Association prime rate, the Federal Funds rate plus

[0001069202-26-000028:mdna:141]
28

[0001069202-26-000028:mdna:142]
0.50%, and Term SOFR for a one month tenor in effect on such day plus 1.00%, plus an applicable margin ranging between 0.00% and 0.025% per annum depending on our long-term unsecured debt rating.

[0001069202-26-000028:mdna:143]
The Term Credit Agreement contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Credit Agreement.

[0001069202-26-000028:mdna:144]
Senior Unsecured Notes

[0001069202-26-000028:mdna:145]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%. In July 2020, we issued senior unsecured notes for $300.0 million, which will mature on August 1, 2027 (the "2027 Notes" and collectively with the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.70% per annum. On August 1, 2025, we repaid upon maturity $300.0 million of our 1.35% senior unsecured notes due in 2025 that were originally issued in 2020.

[0001069202-26-000028:mdna:146]
Financial Leverage

[0001069202-26-000028:mdna:147]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions. We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001069202-26-000028:mdna:148]
We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our Share Repurchase Plans. Our book value of debt-to-total-capital ratio decreased to 54% at December 31, 2025 compared to 57% at December 31, 2024.

[0001069202-26-000028:mdna:149]
As of December 31, 2025, our senior credit ratings were Baa1 with a stable outlook, and BBB with a stable outlook, by Moody’s Investors Service, Inc. (“Moody’s”) and Standard & Poor’s Rating Group (“S&P”), respectively. The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating. Our goal is to maintain investment grade ratings from Moody’s and S&P to help ensure the capital markets remain available to us.

[0001069202-26-000028:mdna:150]
Liquidity

[0001069202-26-000028:mdna:151]
We believe our cash and cash equivalents of $34.2 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future. Included in our cash and cash equivalents as of December 31, 2025 was $9 million of cash held in foreign locations, although that amount can fluctuate significantly depending on the timing of cash receipts and payments. Our cash and cash equivalents held in foreign locations is generally available for use in our U.S. operations and could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-26-000028:mdna:152]
No contributions are required to be made to our U.S. defined benefit plans in 2026. We made $7.6 million in total contributions to our pension plans in 2025.

[0001069202-26-000028:mdna:153]
Dividend payments were $173 million in 2025 compared to $160 million in 2024. On May 22, 2025, our Board of Directors approved a 13% increase in our quarterly dividend on common stock from $1.15 to $1.30 per share effective with the July 2025 dividend payment.

[0001069202-26-000028:mdna:154]
Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared and/or the preceding fiscal year. In addition, stock repurchases can only be made out of surplus and only if our capital would not be impaired.

[0001069202-26-000028:mdna:155]
We expect capital expenditures of approximately $250 million in 2026 for general capital improvement projects.

[0001069202-26-000028:mdna:156]
Financial Covenants related to our Debt

[0001069202-26-000028:mdna:157]
The Credit Agreement and Term Credit Agreement (the “Credit Facilities”) are guaranteed by the Guarantor Subsidiaries (as defined below) and contain customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Facilities each contain a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal

[0001069202-26-000028:mdna:158]
quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001069202-26-000028:mdna:159]
Our Credit Facilities contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our Credit Facilities could occur if:

[0001069202-26-000028:mdna:160]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001069202-26-000028:mdna:161]
•We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-26-000028:mdna:162]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Facilities or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-26-000028:mdna:163]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments, may require the administrative agent to terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Facilities (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-26-000028:mdna:164]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001069202-26-000028:mdna:165]
We are currently in compliance with all covenant requirements.

[0001069202-26-000028:mdna:166]
Leasing Commitments

[0001069202-26-000028:mdna:167]
Refer to Note 5 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001069202-26-000028:mdna:168]
Guarantees related to our Debt Obligations

[0001069202-26-000028:mdna:169]
Our senior unsecured notes were issued by Lennox International Inc. (the “Parent”) and are unconditionally guaranteed by certain of our subsidiaries (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries. The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001069202-26-000028:mdna:170]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of December 31, 2025 and for the year ended December 31, 2025 (in millions):

[0001069202-26-000028:mdna:171]
|  | December 31, 2025 |  |  |
| Current assets | $ | 1,676.4 |  |  |  |
| Non-current assets | 1,824.9 |  |  |  |
| Current liabilities | 1,000.7 |  |  |  |
| Non-current liabilities | 1,689.4 |  |  |  |
| Amounts due to non-Guarantor Subsidiaries | (463.7) |  |  |  |

[0001069202-26-000028:mdna:172]
|  | For the Year Ended December 31, 2025 |
| Net sales | $ | 5,113.8 |  |  |  |
| Gross profit | 1,324.4 |  |  |  |
| Net income | 406.3 |  |  |  |

[0001069202-26-000028:mdna:173]
Off Balance Sheet Arrangements

[0001069202-26-000028:mdna:174]
We have no off-balance sheet arrangements that we believe may have a material current or future effect on our financial condition, liquidity or results of operations.

[0001069202-26-000028:mdna:175]
Contractual Obligations

[0001069202-26-000028:mdna:176]
Contractual obligations arise in the normal course of business and include debt and related interest payments, leases, purchase obligations, pension and post-retirement benefits and warranty liabilities. For additional information regarding our contractual obligations, see Note 5 of the Notes to the Consolidated Financial Statements. See Note 10 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations. See Note 13 of the Notes to the Consolidated Financial Statements for more information on our debt obligations.

[0001069202-26-000028:mdna:177]
Fair Value Measurements

[0001069202-26-000028:mdna:178]
Fair value is the price that would be received to sell an asset or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date. Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities. Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001069202-26-000028:mdna:179]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-26-000028:mdna:180]
Level 1 -          Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-26-000028:mdna:181]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001069202-26-000028:mdna:182]
Level 3 -     Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001069202-26-000028:mdna:183]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use. Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2025 and 2024, the measurement dates. See Note 16 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001069202-26-000028:mdna:184]
Market Risk

[0001069202-26-000028:mdna:185]
Commodity Price Risk

[0001069202-26-000028:mdna:186]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production. Fluctuations in metal commodity prices impact the value of the futures contracts that we hold. When metal commodity prices rise, the fair value of our futures contracts increases. Conversely, when commodity prices fall, the fair value of our futures contracts decreases. Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001069202-26-000028:mdna:187]
| Notional amount (pounds of aluminum and copper) | 87.6 |
| Carrying amount and fair value of net asset | $ | 23.6 |  |
| Change in fair value from 10% change in forward prices | $ | 13.2 |  |

[0001069202-26-000028:mdna:188]
Refer to Note 9 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001069202-26-000028:mdna:189]
Interest Rate Risk

[0001069202-26-000028:mdna:190]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments. A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $1.1 million, $0.9 million and $2.3 million for the years ended December 31, 2025, 2024 and 2023, respectively.

[0001069202-26-000028:mdna:191]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments. This strategy, when employed, allows us to fix a portion of our interest payments when interest rates are low. As of December 31, 2025 and 2024, no interest rate swaps were in effect.

[0001069202-26-000028:mdna:192]
Foreign Currency Exchange Rate Risk

[0001069202-26-000028:mdna:193]
Our results of operations are affected by changes in foreign currency exchange rates. Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period. Our primary exposure to foreign currencies are the Canadian dollar, Mexican Peso, and the Euro. During 2025, 2024 and 2023, net sales from outside the U.S. represented 7%, 6% and 11%, respectively, of our total net sales. For the years ended December 31, 2025, 2024, and 2023, foreign currency transaction gains and losses did not have a material impact to our results of operations. A 10% change in foreign exchange rates would have had an estimated $5.8 million, $2.6 million and $5.6 million impact to net income for the years ended December 31, 2025, 2024 and 2023, respectively.

[0001069202-26-000028:mdna:194]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate. Refer to Note 9 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001069202-26-000028:mdna:195]
Critical Accounting Estimates

[0001069202-26-000028:mdna:196]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition. The following describes our critical accounting estimate related to product warranties and product-related contingencies and how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements. This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001069202-26-000028:mdna:197]
Product Warranties and Product-Related Contingencies

[0001069202-26-000028:mdna:198]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs. Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.

[0001069202-26-000028:mdna:199]
From time to time, we may also incur costs to repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand. These product-related costs may not be covered under our warranties and are not covered by insurance.

[0001069202-26-000028:mdna:200]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience. Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used. Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods. See Note 5 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001069202-26-000028:mdna:201]
Recent Accounting Pronouncements

[0001069202-26-000028:mdna:202]
See Note 2 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
