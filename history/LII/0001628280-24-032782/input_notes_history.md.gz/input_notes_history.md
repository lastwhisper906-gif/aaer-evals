# LII note change history — 0001628280-24-017634 → 0001628280-24-032782


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2024-07-24):
[0001628280-24-032782:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering

- changed (2024-07-24):
[0001628280-24-032782:note_history:2]
event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.
  (was, 2024-04-24, similarity 0.7429):
[0001628280-24-017634:note_history:2]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or

- changed (2024-07-24):
[0001628280-24-032782:note_history:3]
Liabilities for estimated product warranty costs are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:
  (was, 2024-04-24, similarity 0.9043):
[0001628280-24-017634:note_history:3]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:

- changed (2024-07-24):
[0001628280-24-032782:note_history:4]
|  | June 30, 2024 |  | December 31, 2023 |
| Accrued expenses | $ | 46.3 |  |  | $ | 45.4 |  |
| Other liabilities | 106.5 |  |  | 97.4 |  |
| Total warranty liability | $ | 152.8 |  |  | $ | 142.8 |  |
  (was, 2024-04-24, similarity 0.9721):
[0001628280-24-017634:note_history:4]
|  | March 31, 2024 |  | December 31, 2023 |
| Accrued expenses | $ | 45.4 |  |  | $ | 45.4 |  |
| Other liabilities | 102.2 |  |  | 97.4 |  |
| Total warranty liability | $ | 147.6 |  |  | $ | 142.8 |  |

- changed (2024-07-24):
[0001628280-24-032782:note_history:5]
The changes in product warranty liabilities for the six months ended June 30, 2024 were as follows (in millions):
  (was, 2024-04-24, similarity 0.8016):
[0001628280-24-017634:note_history:5]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2024 were as follows (in millions):

- changed (2024-07-24):
[0001628280-24-032782:note_history:6]
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Warranty claims paid | (18.0) |  |
| Changes resulting from issuance of new warranties | 28.5 |  |
| Changes in estimates associated with pre-existing liabilities | (0.2) |  |
| Changes in foreign currency translation rates and other | (0.3) |  |
| Total warranty liability as of June 30, 2024 | $ | 152.8 |  |
  (was, 2024-04-24, similarity 0.7931):
[0001628280-24-017634:note_history:6]
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Warranty claims paid | (7.0) |  |
| Changes resulting from issuance of new warranties | 11.6 |  |
| Changes in estimates associated with pre-existing liabilities | 0.4 |  |
| Changes in foreign currency translation rates and other | (0.2) |  |
| Total warranty liability as of March 31, 2024 | $ | 147.6 |  |

- removed (2024-07-24):
[0001628280-24-017634:note_history:7]
underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-07-24):
[0001628280-24-032782:note_history:8]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2024, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2024 and 2023, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three and six months ended June 30, 2024 and 2023, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2024 and 2023 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2023.
  (was, 2024-04-24, similarity 0.8716):
[0001628280-24-017634:note_history:8]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2024, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2024 and 2023, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2024 and 2023, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three months ended March 31, 2024 and 2023, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2024 and 2023 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2023.

- changed (2024-07-24):
[0001628280-24-032782:note_history:9]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June, and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls. For convenience, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.
  (was, 2024-04-24, similarity 0.999):
[0001628280-24-017634:note_history:9]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls. For convenience, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-24):
[0001628280-24-032782:note_history:10]
|  | June 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |
  (was, 2024-04-24, similarity 0.9474):
[0001628280-24-017634:note_history:10]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |

- changed (2024-07-24):
[0001628280-24-032782:note_history:11]
|  | June 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 6.67 | % |
  (was, 2024-04-24, similarity 0.9357):
[0001628280-24-017634:note_history:11]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 6.66 | % |  | 6.67 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-24):
[0001628280-24-032782:note_history:12]
|  | June 30, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 147.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 14.0 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 14.0 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 35.0 |  |  | $ | 32.7 |  |
| Credit agreement | — |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.2) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,126.8 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,287.8 |  |  | $ | 1,305.2 |  |
  (was, 2024-04-24, similarity 0.9895):
[0001628280-24-017634:note_history:12]
|  | March 31, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 250.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 22.5 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 22.5 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 50.5 |  |  | $ | 32.7 |  |
| Credit agreement | 12.0 |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.8) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,153.7 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,426.2 |  |  | $ | 1,305.2 |  |

- changed (2024-07-24):
[0001628280-24-032782:note_history:13]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2024 or December 31, 2023 and there were no borrowings or repayments on these facilities during the six months ended June 30, 2024.
  (was, 2024-04-24, similarity 0.9049):
[0001628280-24-017634:note_history:13]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2024 or December 31, 2023 and there were no borrowings or repayments on these facilities during the three months ended March 31, 2024.

- changed (2024-07-24):
[0001628280-24-032782:note_history:14]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. CP Notes currently outstanding under the Program totaled $147.0 million as of June 30, 2024.
  (was, 2024-04-24, similarity 0.8768):
[0001628280-24-017634:note_history:14]
paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. CP Notes currently outstanding under the Program totaled $250.0 million as of March 31, 2024.

- changed (2024-07-24):
[0001628280-24-032782:note_history:15]
|  | June 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |
  (was, 2024-04-24, similarity 0.9474):
[0001628280-24-017634:note_history:15]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |

- changed (2024-07-24):
[0001628280-24-032782:note_history:16]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had $0 outstanding borrowings and $1.7 million committed to standby letters of credit as of June 30, 2024. Subject to covenant limitations, $951.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.
  (was, 2024-04-24, similarity 0.9503):
[0001628280-24-017634:note_history:16]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had outstanding borrowings of $12.0 million as well as $1.7 million committed to standby letters of credit as of March 31, 2024. Subject to covenant limitations, $836.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

- changed (2024-07-24):
[0001628280-24-032782:note_history:17]
|  | June 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 6.67 | % |
  (was, 2024-04-24, similarity 0.9357):
[0001628280-24-017634:note_history:17]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 6.66 | % |  | 6.67 | % |

- changed (2024-07-24):
[0001628280-24-032782:note_history:18]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).
  (was, 2024-04-24, similarity 0.9991):
[0001628280-24-017634:note_history:18]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

- changed (2024-07-24):
[0001628280-24-032782:note_history:19]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our credit facility could occur if:
  (was, 2024-04-24, similarity 0.9989):
[0001628280-24-017634:note_history:19]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

- changed (2024-07-24):
[0001628280-24-032782:note_history:20]
As of June 30, 2024, we believe we were in compliance with all covenant requirements.
  (was, 2024-04-24, similarity 0.9434):
[0001628280-24-017634:note_history:20]
As of March 31, 2024, we believe we were in compliance with all covenant requirements.

- changed (2024-07-24):
[0001628280-24-032782:note_history:21]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2024, we believe we were in compliance with all covenant requirements.
  (was, 2024-04-24, similarity 0.8897):
[0001628280-24-017634:note_history:21]
(the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2024, we believe we were in compliance with all covenant requirements.

- removed (2024-07-24):
[0001628280-24-017634:note_history:22]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial

- removed (2024-07-24):
[0001628280-24-017634:note_history:23]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-24):
[0001628280-24-032782:note_history:24]
|  | June 30, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 147.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 14.0 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 14.0 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 35.0 |  |  | $ | 32.7 |  |
| Credit agreement | — |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.2) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,126.8 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,287.8 |  |  | $ | 1,305.2 |  |
  (was, 2024-04-24, similarity 0.9895):
[0001628280-24-017634:note_history:24]
|  | March 31, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 250.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 22.5 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 22.5 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 50.5 |  |  | $ | 32.7 |  |
| Credit agreement | 12.0 |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.8) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,153.7 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,426.2 |  |  | $ | 1,305.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-24):
[0001628280-24-032782:note_history:25]
|  | For the Three Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 923.5 |  |  | $ | 445.0 |  |  | $ | — |  |  | $ | 1,368.5 |  |
| Canada | 58.8 |  |  | 23.8 |  |  | — |  |  | 82.6 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 982.3 |  |  | $ | 468.8 |  |  | $ | — |  |  | $ | 1,451.1 |  |
  (was, 2024-04-24, similarity 0.9883):
[0001628280-24-017634:note_history:25]
|  | For the Three Months Ended March 31, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 626.1 |  |  | $ | 357.3 |  |  | $ | — |  |  | $ | 983.4 |  |
| Canada | 48.5 |  |  | 15.2 |  |  | — |  |  | 63.7 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 674.6 |  |  | $ | 372.5 |  |  | $ | — |  |  | $ | 1,047.1 |  |

- changed (2024-07-24):
[0001628280-24-032782:note_history:26]
|  | For the Three Months Ended June 30, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 868.5 |  |  | $ | 382.2 |  |  | $ | — |  |  | $ | 1,250.7 |  |
| Canada | 67.7 |  |  | 25.3 |  |  | — |  |  | 93.0 |  |
| Other international | — |  |  | — |  |  | 67.7 |  |  | 67.7 |  |
| Total | $ | 936.2 |  |  | $ | 407.5 |  |  | $ | 67.7 |  |  | $ | 1,411.4 |  |
  (was, 2024-04-24, similarity 0.9883):
[0001628280-24-017634:note_history:26]
|  | For the Three Months Ended March 31, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 639.3 |  |  | $ | 294.6 |  |  | $ | — |  |  | $ | 933.9 |  |
| Canada | 41.7 |  |  | 14.1 |  |  | — |  |  | 55.8 |  |
| Other international | — |  |  | — |  |  | 59.7 |  |  | 59.7 |  |
| Total | $ | 681.0 |  |  | $ | 308.7 |  |  | $ | 59.7 |  |  | $ | 1,049.4 |  |

- added (2024-07-24):
[0001628280-24-032782:note_history:27]
|  | For the Six Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,549.6 |  |  | $ | 802.3 |  |  | $ | — |  |  | $ | 2,351.9 |  |
| Canada | 107.3 |  |  | 39.0 |  |  | — |  |  | 146.3 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,656.9 |  |  | $ | 841.3 |  |  | $ | — |  |  | $ | 2,498.2 |  |

- added (2024-07-24):
[0001628280-24-032782:note_history:28]
|  | For the Six Months Ended June 30, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,507.8 |  |  | $ | 676.7 |  |  | $ | — |  |  | $ | 2,184.5 |  |
| Canada | 109.4 |  |  | 39.4 |  |  | — |  |  | 148.8 |  |
| Other international | — |  |  | — |  |  | 127.4 |  |  | 127.4 |  |
| Total | $ | 1,617.2 |  |  | $ | 716.1 |  |  | $ | 127.4 |  |  | $ | 2,460.7 |  |

- changed (2024-07-24):
[0001628280-24-032782:note_history:29]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent
  (was, 2024-04-24, similarity 0.7193):
[0001628280-24-017634:note_history:29]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2024 and 2023, direct sales represented 74% and 70% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- added (2024-07-24):
[0001628280-24-032782:note_history:30]
installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2024 and 2023, direct sales represented 76% and 76% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2024 and 2023, direct sales represented 75% and 73% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2024-07-24):
[0001628280-24-032782:note_history:31]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended June 30, 2024 and 2023, equipment sales represented 82% and 87% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2024 and 2023, equipment sales represented 81% and 86% of revenues and the remainder of our revenue was generated from our services business.
  (was, 2024-04-24, similarity 0.9439):
[0001628280-24-017634:note_history:31]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2024 and 2023, equipment sales represented 83% and 85% of revenues and the remainder of our revenue was generated from our service business.

- changed (2024-07-24):
[0001628280-24-032782:note_history:32]
|  | June 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Contract assets | $ | 2.0 |  |  | $ | 2.2 |  |  |  |  |  |
| Contract liabilities - current | (5.0) |  |  | (4.7) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.8) |  |  | (7.5) |  |  |  |  |  |
| Total | $ | (10.8) |  |  | $ | (10.0) |  |  |  |  |  |
  (was, 2024-04-24, similarity 0.9826):
[0001628280-24-017634:note_history:32]
|  | March 31, 2024 |  | December 31, 2023 |  |  |  |  |
| Contract assets | $ | 1.9 |  |  | $ | 2.2 |  |  |  |  |  |
| Contract liabilities - current | (3.6) |  |  | (4.7) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.5) |  |  | (7.5) |  |  |  |  |  |
| Total | $ | (9.2) |  |  | $ | (10.0) |  |  |  |  |  |

- changed (2024-07-24):
[0001628280-24-032782:note_history:33]
For the three months ended June 30, 2024 and 2023, we recognized revenue of $0.4 million and $1.2 million and for the six months ended June 30, 2024 and 2023, we recognized revenue of $6.1 million and $4.2 million related to our contract liabilities at January 1, 2024 and 2023, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2024 and 2023.
  (was, 2024-04-24, similarity 0.8301):
[0001628280-24-017634:note_history:33]
For the three months ended March 31, 2024 and 2023, we recognized revenue of $5.7 million and $3.0 million related to our contract liabilities at January 1, 2024 and 2023, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2024 and 2023.
