# LII 8-K — 0001628280-24-032683 filed 2024-07-24

## item codes, every 8-K on or before 2024-07-24

- 2024-07-24 0001628280-24-032683 — 2.02, 9.01
- 2024-05-23 0001628280-24-024875 — 5.02, 9.01
- 2024-05-20 0001628280-24-024385 — 5.07
- 2024-04-24 0001628280-24-017515 — 2.02, 9.01
- 2024-03-18 0001628280-24-011594 — 5.02, 9.01
- 2024-01-31 0001628280-24-002634 — 2.02, 9.01
- 2023-12-11 0001628280-23-041239 — 5.02, 9.01 — amendment of 0001628280-23-035187
- 2023-12-08 0001628280-23-041128 — 5.02
- 2023-10-26 0001628280-23-035187 — 2.02, 5.02, 7.01, 9.01
- 2023-09-21 0001628280-23-032729 — 8.01, 9.01
- 2023-09-15 0001628280-23-032385 — 1.01, 2.03, 8.01, 9.01
- 2023-09-12 0001628280-23-032078 — 8.01, 9.01
- 2023-08-28 0001628280-23-030777 — 1.01, 2.03, 9.01
- 2023-08-25 0001628280-23-030602 — 8.01, 9.01
- 2023-07-27 0001628280-23-025808 — 2.02, 9.01
- 2023-05-19 0001628280-23-019040 — 5.07
- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2024-07-24

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-032683:8k_2_02:1]
EX-99.1
2
lii-2024630xexx991pressrel.htm
EX-99.1

[0001628280-24-032683:8k_2_02:2]
Document

[0001628280-24-032683:8k_2_02:3]
Exhibit 99.1

[0001628280-24-032683:8k_2_02:4]
Lennox Reports Second Quarter Results and Raises Full Year Profit Guidance

[0001628280-24-032683:8k_2_02:5]
____________________________________________________________________________

[0001628280-24-032683:8k_2_02:6]
Q2 Highlights

[0001628280-24-032683:8k_2_02:7]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-24-032683:8k_2_02:8]
(Prior-year adjusted results and core revenue exclude European operations that were divested in the 4Q 2023)

[0001628280-24-032683:8k_2_02:9]
•       Revenue $1.45 billion  –  Core revenue up 8%, including 2% growth from acquisitions

[0001628280-24-032683:8k_2_02:10]
•       GAAP Operating Income $320 million  –  Adjusted segment profit up 13% to $319 million

[0001628280-24-032683:8k_2_02:11]
•       GAAP diluted EPS $6.87  –  Adjusted diluted EPS up 11% to $6.83

[0001628280-24-032683:8k_2_02:12]
•       Raising 2024 EPS guidance range to $19.50-$20.25 from prior range of $19.00-$20.00

[0001628280-24-032683:8k_2_02:13]
____________________________________________________________________________

[0001628280-24-032683:8k_2_02:14]
DALLAS, July 24, 2024 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported second quarter financial results with $1.45 billion of revenue, a record $320 million of operating income and $6.87 GAAP diluted earnings per share.

[0001628280-24-032683:8k_2_02:15]
Core revenue grew 8% to $1.45 billion. Adjusted segment profit rose 13% to $319 million. Adjusted segment margin was up 100 basis points to a record 21.9%. Adjusted diluted earnings per share rose 11% to $6.83.

[0001628280-24-032683:8k_2_02:16]
"Our growth strategy and disciplined execution continues to yield impressive results,” said Chief Executive Officer, Alok Maskara. “By leveraging our direct distribution network, industry-leading product portfolio, and heightened focus on customer experience, our team has successfully expanded share and margins. This strong performance gives us the confidence to raise our full-year EPS guidance.”

[0001628280-24-032683:8k_2_02:17]
“The smooth integration of AES, expanding heat pump penetration from our joint venture with Samsung, and opening our new commercial factory will continue to present long-term growth opportunities for Lennox,” Maskara continued. “These investments underscore our commitment to growth acceleration and sustained value creation for our shareholders, customers, and employees."

[0001628280-24-032683:8k_2_02:18]
The Home Comfort Solutions segment achieved revenue growth of 5%, primarily driven by continued pricing excellence. Sales volume also improved as industry destocking concluded midway through the quarter. The segment demonstrated strong margin expansion, which has been instrumental in offsetting the effects of inflation and the costs associated with ongoing investments. The team’s focus on strategic pricing, resilient margins, and targeted investments has enabled the Home Comfort Solutions segment to deliver profitable growth despite relatively neutral end markets.

[0001628280-24-032683:8k_2_02:19]
In the second quarter, the Business Climate Solutions segment extended its track record of segment profit growth with revenue growth of 15%, including 6% growth from acquisitions. Segment profit margins deteriorated slightly as we make the necessary investments to ramp up our new factory in Saltillo, Mexico. Progress on the new factory remains on track and we built our first complete pilot units in early July.

[0001628280-24-032683:8k_2_02:20]
SECOND QUARTER 2024 FINANCIAL HIGHLIGHTS

[0001628280-24-032683:8k_2_02:21]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-24-032683:8k_2_02:22]
Revenue: $1.45 billion was up 3% and up 8% for core operations, with organic revenue up 6% driven by price and favorable sales volume.

[0001628280-24-032683:8k_2_02:23]
Operating Income: $320 million, up 15%, with operating profit margin of 22.1%, up 230 basis points.

[0001628280-24-032683:8k_2_02:24]
Adjusted Segment Profit: $319 million, up 13%, and adjusted segment profit margin of 21.9%, up 100 basis points. Profit growth was driven by $44 million of price/mix benefits, and $19 million in organic and inorganic sales volume. This was partially offset by inflation and new factory expenses, SG&A, and distribution investments.

[0001628280-24-032683:8k_2_02:25]
Net Income: $246 million, or $6.87 per share, compared to $217 million, or $6.10 per share, in the prior-year quarter.

[0001628280-24-032683:8k_2_02:26]
Adjusted Net Income: $244 million, or $6.83 per share, compared to $219 million, or $6.15 per share, in the prior-year quarter.

[0001628280-24-032683:8k_2_02:27]
Cash: Operating cash flow was $184 million compared to $196 million in the prior-year quarter. Capital expenditures were $33 million compared to $50 million in the prior-year quarter. Total debt at the end of the second quarter was approximately $1.3 billion. Total cash, cash equivalents, and short-term investments were $58 million at the end of the quarter.

[0001628280-24-032683:8k_2_02:28]
Home Comfort Solutions: Business segment revenue was $982 million, up 5%. Segment profit was $229 million, up 13%, and segment margin was 23.3%, up 170 basis points. Segment profit increased $26 million compared to the prior-year quarter. The increase was attributed to $42 million in price/mix benefits and an increase of $2 million in sales volume. This was partially offset by an $18 million impact from inflation and investments in distribution and selling.

[0001628280-24-032683:8k_2_02:29]
Building Climate Solutions: Business segment revenue was $469 million, up 15%. Organic revenue was $446 million, up 10%. Segment profit was $114 million, up $11 million or 11%, and segment margin decreased 100 basis points to 24.3%. This profit improvement was driven by a $17 million increase in organic and inorganic sales volume, partially offset by $6 million in ramp-up costs at the new factory and inflationary wage impacts.

[0001628280-24-032683:8k_2_02:30]
Corporate and Other: Corporate expenses were $24 million, an improvement of $1 million versus the prior-year quarter adjusted amount.

[0001628280-24-032683:8k_2_02:31]
FULL YEAR 2024 GUIDANCE

[0001628280-24-032683:8k_2_02:32]
For full year 2024, we reaffirm revenue guidance of approximately 7%, with 2% of benefit from the AES acquisition.

[0001628280-24-032683:8k_2_02:33]
Earnings per share revised range is $19.50 to $20.25 versus the prior range of $19.00 to $20.00.

[0001628280-24-032683:8k_2_02:34]
Free Cash Flow is estimated to be within the range of $500 million to $600 million.

[0001628280-24-032683:8k_2_02:35]
CONFERENCE CALL INFORMATION

[0001628280-24-032683:8k_2_02:36]
A conference call to discuss the company’s second quarter results and 2024 outlook will be held this morning at 8:30 a.m. Central Time. To participate in the earnings conference, please call 800-225-9448 (U.S.) or +1 203-518-9708 (international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ224. The conference call also will be webcast live on the company’s investor relations web site at investor.lennox.com. A replay of the conference call will be available until July 31, 2024, by calling toll-free 800-839-5495 (U.S.) or +1 402-220-2553 (international). The call will also be archived on the company's investor relations website at investor.lennox.com.

[0001628280-24-032683:8k_2_02:37]
ABOUT LENNOX

[0001628280-24-032683:8k_2_02:38]
Lennox (NYSE: LII) is a leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our cooling, heating, indoor air quality, and refrigeration systems. Additional information on Lennox is available at Lennox.com or by contacting investor@lennox.com.

[0001628280-24-032683:8k_2_02:39]
FORWARD-LOOKING STATEMENTS & NON-GAAP FINANCIAL MEASURES

[0001628280-24-032683:8k_2_02:40]
For information concerning these and other risks and uncertainties, see LII’s publicly available filings with the Securities and Exchange Commission. LII disclaims any intention or obligation to update or revise any forward-looking statements, whether as a result of new information, future events or otherwise, except as required by law.

[0001628280-24-032683:8k_2_02:41]
A reconciliation of non-GAAP financial measures appearing in this document to financial measures prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP) are included in the Annex to this document.

[0001628280-24-032683:8k_2_02:42]
This document includes forward-looking statements regarding core revenue, segment profit, adjusted segment profit, adjusted net income, adjusted diluted earnings per share, free cash flow, and Debt to EBITDA, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, changes in environmental liabilities, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. Core revenue, adjusted segment profit, and adjusted diluted earnings per share exclude net sales and profit/(loss) from our European portfolio, which was sold in 4Q 2023. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on LII’s full year GAAP financial results.

[0001628280-24-032683:8k_2_02:43]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-24-032683:8k_2_02:44]
Consolidated Statements of Operations

[0001628280-24-032683:8k_2_02:45]
(Unaudited)

[0001628280-24-032683:8k_2_02:46]
| (Amounts in millions, except per share data) | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 1,451.1 |  |  | $ | 1,411.4 |  |  | $ | 2,498.2 |  |  | $ | 2,460.7 |  |
| Cost of goods sold | 962.9 |  |  | 953.6 |  |  | 1,670.0 |  |  | 1,696.2 |  |
| Gross profit | 488.2 |  |  | 457.8 |  |  | 828.2 |  |  | 764.5 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 168.5 |  |  | 181.3 |  |  | 339.2 |  |  | 348.8 |  |
| Losses and other expenses, net | 3.7 |  |  | 0.8 |  |  | 7.4 |  |  | 1.1 |  |
| Gain on sale from previous dispositions | (1.6) |  |  | — |  |  | (1.6) |  |  | — |  |
| Income from equity method investments | (2.5) |  |  | (3.1) |  |  | (3.7) |  |  | (3.8) |  |
| Operating income | 320.1 |  |  | 278.8 |  |  | 486.9 |  |  | 418.4 |  |
| Pension settlements | 0.3 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Interest expense, net | 12.5 |  |  | 15.0 |  |  | 24.3 |  |  | 29.2 |  |
| Other expense, net | 0.3 |  |  | — |  |  | 1.1 |  |  | — |  |
| Income before income taxes | 307.0 |  |  | 263.7 |  |  | 461.2 |  |  | 388.9 |  |
| Provision for income taxes | 61.1 |  |  | 46.5 |  |  | 91.0 |  |  | 73.7 |  |
| Net income | $ | 245.9 |  |  | $ | 217.2 |  |  | $ | 370.2 |  |  | $ | 315.2 |  |
| Earnings per share – Basic: | $ | 6.91 |  |  | $ | 6.12 |  |  | $ | 10.40 |  |  | $ | 8.88 |  |
| Earnings per share – Diluted: | $ | 6.87 |  |  | $ | 6.10 |  |  | $ | 10.34 |  |  | $ | 8.85 |  |
| Weighted Average Number of Shares Outstanding - Basic | 35.6 |  |  | 35.5 |  |  | 35.6 |  |  | 35.5 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 35.8 |  |  | 35.6 |  |  | 35.8 |  |  | 35.6 |  |

[0001628280-24-032683:8k_2_02:47]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |
| Segment Net Sales and Profit (Loss) |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |

[0001628280-24-032683:8k_2_02:48]
| (Amounts in millions) | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net Sales |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 982.3 |  |  | $ | 936.2 |  |  | $ | 1,656.9 |  |  | $ | 1,617.2 |  |
| Building Climate Solutions | 468.8 |  |  | 407.5 |  |  | 841.3 |  |  | 716.1 |  |
| Corporate and other (1) | — |  |  | 67.7 |  |  | — |  |  | 127.4 |  |
|  | $ | 1,451.1 |  |  | $ | 1,411.4 |  |  | $ | 2,498.2 |  |  | $ | 2,460.7 |  |
| Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 228.5 |  |  | $ | 202.6 |  |  | $ | 340.6 |  |  | $ | 313.7 |  |
| Building Climate Solutions | 114.0 |  |  | 103.0 |  |  | 192.2 |  |  | 153.0 |  |
| Corporate and other | (24.0) |  |  | (22.5) |  |  | (47.5) |  |  | (41.9) |  |
| Total segment profit | 318.5 |  |  | 283.1 |  |  | 485.3 |  |  | 424.8 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Gain on sale from previous dispositions | (1.6) |  |  | — |  |  | (1.6) |  |  | — |  |
| Items in Losses and other expenses, net which are excluded from segment profit (loss) (2) | — |  |  | 4.3 |  |  |  |  | 6.4 |  |
| Operating income | $ | 320.1 |  |  | $ | 278.8 |  |  | $ | 486.9 |  |  | $ | 418.4 |  |

[0001628280-24-032683:8k_2_02:49]
(1) The Corporate and Other segment included our European portfolio. In the fourth quarter of 2023 we completed the divestiture of our European operations.

[0001628280-24-032683:8k_2_02:50]
(2) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-24-032683:8k_2_02:51]
•The following items in Losses and other expenses, net:

[0001628280-24-032683:8k_2_02:52]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001628280-24-032683:8k_2_02:53]
◦Environmental liabilities and special litigation charges, and;

[0001628280-24-032683:8k_2_02:54]
◦Other items, net

[0001628280-24-032683:8k_2_02:55]
•Gain on sale from previous disposition of European entities

[0001628280-24-032683:8k_2_02:56]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-24-032683:8k_2_02:57]
Consolidated Balance Sheets

[0001628280-24-032683:8k_2_02:58]
| (Amounts in millions, except shares and par values) | As of June 30, 2024 |  | As of December 31, 2023 |
| ASSETS | (Unaudited) |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 47.6 |  |  | $ | 60.7 |  |
| Short-term investments | 10.2 |  |  | 8.4 |  |
| Accounts and notes receivable, net of allowances of $16.1 and $14.4 in 2024 and 2023, respectively | 858.6 |  |  | 594.6 |  |
| Inventories, net | 776.3 |  |  | 699.1 |  |
| Other assets | 72.6 |  |  | 70.7 |  |
| Total current assets | 1,765.3 |  |  | 1,433.5 |  |
| Property, plant and equipment, net of accumulated depreciation of $936.5 and $910.8 in 2024 and 2023, respectively | 740.8 |  |  | 720.4 |  |
| Right-of-use assets from operating leases | 271.6 |  |  | 213.6 |  |
| Goodwill | 219.9 |  |  | 222.1 |  |
| Deferred income taxes | 63.0 |  |  | 51.8 |  |
| Other assets, net | 161.3 |  |  | 156.9 |  |
| Total assets | $ | 3,221.9 |  |  | $ | 2,798.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current Liabilities: |  |  |  |
| Accounts payable | $ | 450.8 |  |  | $ | 374.7 |  |
| Accrued expenses | 393.0 |  |  | 416.1 |  |
| Income taxes payable | 33.1 |  |  | 4.2 |  |
| Commercial paper | 147.0 |  |  | 150.0 |  |
| Current maturities of long-term debt | 14.0 |  |  | 12.1 |  |
| Current operating lease liabilities | 66.6 |  |  | 57.5 |  |
| Total current liabilities | 1,104.5 |  |  | 1,014.6 |  |
| Long-term debt | 1,126.8 |  |  | 1,143.1 |  |
| Long-term operating lease liabilities | 215.2 |  |  | 164.6 |  |
| Pensions | 18.1 |  |  | 22.5 |  |
| Other liabilities | 179.9 |  |  | 168.2 |  |
| Total liabilities | 2,644.5 |  |  | 2,513.0 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' equity: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,197.9 |  |  | 1,184.6 |  |
| Retained earnings | 3,796.0 |  |  | 3,506.2 |  |
| Accumulated other comprehensive loss | (60.8) |  |  | (56.9) |  |
| Treasury stock, at cost, 51,538,343 shares and 51,588,103 shares for 2024 and 2023, respectively | (4,356.6) |  |  | (4,349.5) |  |
| Total stockholders' equity | 577.4 |  |  | 285.3 |  |
| Total liabilities and stockholders' equity | $ | 3,221.9 |  |  | $ | 2,798.3 |  |

[0001628280-24-032683:8k_2_02:59]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-24-032683:8k_2_02:60]
Consolidated Statements of Cash Flows

[0001628280-24-032683:8k_2_02:61]
(Unaudited)

[0001628280-24-032683:8k_2_02:62]
| (Amounts in millions) | For the Six Months Ended June 30, |
|  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 370.2 |  |  | $ | 315.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Gain on sale from previous dispositions | (1.6) |  |  | — |  |
| Income from equity method investments | (3.7) |  |  | (3.8) |  |
| Provision for credit losses | 3.4 |  |  | 3.8 |  |
| Unrealized losses, net on derivative contracts | 0.5 |  |  | 3.9 |  |
| Stock-based compensation expense | 13.3 |  |  | 13.8 |  |
| Depreciation and amortization | 49.2 |  |  | 40.5 |  |
| Deferred income taxes | (13.4) |  |  | (18.9) |  |
| Pension expense | 2.0 |  |  | 1.4 |  |
| Pension contributions | (5.1) |  |  | (2.0) |  |
| Other items, net | (0.1) |  |  | (1.2) |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |
| Accounts and notes receivable | (270.8) |  |  | (236.5) |  |
| Inventories | (78.9) |  |  | (100.4) |  |
| Other current assets | (2.5) |  |  | 8.7 |  |
| Accounts payable | 76.2 |  |  | 45.4 |  |
| Accrued expenses | (22.1) |  |  | 45.6 |  |
| Income taxes payable and receivable, net | 40.1 |  |  | 4.1 |  |
| Leases, net | 1.8 |  |  | 3.3 |  |
| Other, net | 2.7 |  |  | (6.2) |  |
| Net cash provided by operating activities | 161.2 |  |  | 116.7 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 1.1 |  |  | 1.5 |  |
| Purchases of property, plant and equipment | (62.2) |  |  | (85.3) |  |
| Net proceeds from previous disposition | 4.1 |  |  | — |  |
| Acquisitions, net of cash | 1.8 |  |  | — |  |
| (Purchases of) proceeds from short-term investments | (2.0) |  |  | 1.5 |  |
| Net cash used in investing activities | (57.2) |  |  | (82.3) |  |
| Cash flows from financing activities: |  |  |  |
| Commercial paper borrowings | 374.0 |  |  | — |  |
| Commercial paper payments | (377.0) |  |  | — |  |
| Asset securitization borrowings | — |  |  | 140.0 |  |
| Asset securitization payments | — |  |  | (90.0) |  |
| Long-term debt payments | (9.9) |  |  | (7.3) |  |
| Borrowings from credit facility | 156.7 |  |  | 1,182.0 |  |
| Payments on credit facility | (176.7) |  |  | (1,182.0) |  |
| Proceeds from employee stock purchases | 2.0 |  |  | 1.9 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (9.1) |  |  | (3.2) |  |
| Cash dividends paid | (78.3) |  |  | (75.2) |  |
| Net cash used in financing activities | (118.3) |  |  | (33.8) |  |
| (Decrease) increase in cash and cash equivalents | (14.3) |  |  | 0.6 |  |
| Effect of exchange rates on cash and cash equivalents | 1.2 |  |  | (1.8) |  |
| Cash and cash equivalents, beginning of period | 60.7 |  |  | 52.6 |  |
| Cash and cash equivalents, end of period | $ | 47.6 |  |  | $ | 51.4 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 25.6 |  |  | $ | 27.1 |  |
| Income taxes paid (net of refunds) | $ | 60.2 |  |  | $ | 88.4 |  |

[0001628280-24-032683:8k_2_02:63]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit (loss) presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company's business trends and operating performance. |
| Reconciliation of Net income, a GAAP measure, to Adjusted net income, a Non-GAAP measure |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |
|  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  |  |
| Net income, a GAAP measure | $ | 245.9 |  | $ | 6.87 |  |  | $ | 217.2 |  | $ | 6.10 |  |  | $ | 370.2 |  | $ | 10.34 |  |  | $ | 315.2 |  | $ | 8.85 |  |  |  |
| Gain on sale from previous dispositions | (1.6) |  | (0.04) |  |  | — |  | — |  |  | (1.6) |  | (0.04) |  |  | — |  | — |  |  |  |
| Pension settlements | — |  | — |  |  | 0.1 |  | — |  |  | — |  | — |  |  | 0.3 |  | 0.01 |  |  |  |
| Items in Losses and other expenses, net which are excluded from segment profit (loss) (a) | — |  | — |  |  | 2.9 |  | 0.09 |  |  | — |  | — |  |  | 3.5 |  | 0.10 |  |  |  |
| Excess tax benefit from share-based compensation (b) | — |  | — |  |  | (0.1) |  | — |  |  | — |  | — |  |  | (0.1) |  | — |  |  |  |
| Other tax items, net (b) |  |  |  | 0.1 |  | — |  |  | — |  | — |  |  | 0.4 |  | 0.01 |  |  |  |
| Non-core business results (c) | — |  | — |  |  | (1.4) |  | (0.04) |  |  | — |  | — |  |  | — |  | — |  |  |  |
| Adjusted net income, a non-GAAP measure | $ | 244.3 |  | $ | 6.83 |  |  | $ | 218.8 |  | $ | 6.15 |  |  | $ | 368.6 |  | $ | 10.30 |  |  | $ | 319.3 |  | $ | 8.97 |  |  |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |  |
| (c) Non-core business results represent activity related to our business operations in Europe not included elsewhere in the reconciliations. |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-24-032683:8k_2_02:64]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net cash provided by operating activities | $ | 184.0 |  |  | $ | 195.5 |  |  | $ | 161.2 |  |  | $ | 116.7 |  |
| Purchases of property, plant and equipment | (32.7) |  |  | (49.9) |  |  | (62.2) |  |  | (85.3) |  |
| Proceeds from the disposal of property, plant and equipment | 0.6 |  |  | 1.2 |  |  | 1.1 |  |  | 1.5 |  |
| Free cash flow, a Non-GAAP measure | $ | 151.9 |  |  | $ | 146.8 |  |  | $ | 100.1 |  |  | $ | 32.9 |  |

[0001628280-24-032683:8k_2_02:65]
| Reconciliation of Net sales, a GAAP measure to Core net sales, a Non-GAAP measure |
|  | For the Three Months Ended June 30, |
|  | Corporate and Other |  | Consolidated |
|  | 2023 |  | 2023 |
| Net sales, a GAAP measure | $ | 67.7 |  |  | $ | 1,411.4 |  |
| Net sales from non-core businesses (a) | (67.7) |  |  | (67.7) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | 1,343.7 |  |
| (a) Non-Core businesses represent our business operations in Europe, which were sold in the fourth quarter of 2023. |
| Reconciliation of Net sales, a GAAP measure to Core net sales, a Non-GAAP measure |
|  | For the Six Months Ended June 30, |
|  | Corporate and Other |  | Consolidated |
|  | 2023 |  | 2023 |
| Net sales, a GAAP measure | $ | 127.4 |  |  | $ | 2,460.7 |  |
| Net sales from non-core businesses (a) | (127.4) |  |  | (127.4) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | 2,333.3 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |
| Reconciliation of Segment profit (loss), a Non-GAAP measure to Adjusted Segment profit (loss), a Non-GAAP measure |
|  | For the Three Months Ended June 30, |
|  | Corporate and Other |  | Consolidated |
|  | 2023 |  | 2023 |
| Segment profit (loss), a Non-GAAP measure | $ | (22.5) |  |  | $ | 283.1 |  |
| Profit from non-core businesses (a) | 2.4 |  |  | 2.4 |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (24.9) |  |  | $ | 280.7 |  |
| (a) Non-Core businesses represent our business operations in Europe, which were sold in the fourth quarter of 2023. |
| Reconciliation of Segment profit, a Non-GAAP measure to Adjusted Segment profit, a Non-GAAP measure |
|  | For the Six Months Ended June 30, |
|  | Corporate and Other |  | Consolidated |
|  | 2023 |  | 2023 |
| Segment profit (loss), a Non-GAAP measure | $ | (41.9) |  |  | $ | 424.8 |  |
| Profit (loss) from non-core businesses (a) | 2.1 |  |  | 2.1 |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (44.0) |  |  | $ | 422.7 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |
