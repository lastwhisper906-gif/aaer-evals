# LII MD&A — 0001628280-24-032782


## mdna

[0001628280-24-032782:mdna:1]
[same as prior period, unchanged from 0001628280-24-017634:mdna:1]

[0001628280-24-032782:mdna:2]
[same as prior period, unchanged from 0001628280-24-017634:mdna:2]

[0001628280-24-032782:mdna:3]
[same as prior period, unchanged from 0001628280-24-017634:mdna:3]

[0001628280-24-032782:mdna:4]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June, and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls. For convenience, throughout this Management’s Discussion and Analysis of Financial Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.

[0001628280-24-032782:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and can be significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions, and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001628280-24-032782:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, aluminum and copper.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of certain commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency, and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001628280-24-032782:mdna:7]
[same as prior period, unchanged from 0001628280-24-017634:mdna:7]

[0001628280-24-032782:mdna:8]
Results for the second quarter of 2024 were driven by overall year-over-year sales and profit increases. Net sales increased 5% and segment profit increased $26 million for our Home Comfort Solutions segment. Net sales increased 15% and segment profit increased $11 million for our Building Climate Solutions segment. Net sales decreased $68 million and segment loss increased $2 million for our Corporate and Other segment.  Our European businesses were sold in the fourth quarter of 2023 and generated $68 million in net sales with segment profit of $2 million in the second quarter of 2023.

[0001628280-24-032782:mdna:9]
[same as prior period, unchanged from 0001628280-24-017634:mdna:9]

[0001628280-24-032782:mdna:10]
•Net sales of $1,451 million in the second quarter of 2024 reflected a 3% increase as compared to the same period in 2023.

[0001628280-24-032782:mdna:11]
•Operating income in the second quarter of 2024 increased $41 million to $320 million primarily driven by favorable price and higher sales volumes.

[0001628280-24-032782:mdna:12]
•Net income for the second quarter of 2024 was $246 million.

[0001628280-24-032782:mdna:13]
•Diluted earnings per share was $6.87 per share in the second quarter of 2024 as compared to $6.10 per share in the same period in 2023.

[0001628280-24-032782:mdna:14]
•For the six months ended June 30, 2024, we returned $78 million to shareholders through dividend payments.

[0001628280-24-032782:mdna:15]
Three Months Ended June 30, 2024 Compared to Three Months Ended June 30, 2023 - Consolidated Results

[0001628280-24-032782:mdna:16]
[same as prior period, unchanged from 0001628280-24-017634:mdna:16]

[0001628280-24-032782:mdna:17]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 1,451.1 |  |  | $ | 1,411.4 |  |  | 2.8 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 962.9 |  |  | 953.6 |  |  | (1.0) |  |  | 66.4 |  |  | 67.6 |  |
| Gross profit | 488.2 |  |  | 457.8 |  |  | 6.6 |  |  | 33.6 |  |  | 32.4 |  |
| Selling, general and administrative expenses | 168.5 |  |  | 181.3 |  |  | 7.1 |  |  | 11.6 |  |  | 12.8 |  |
| Losses and other expenses, net | 3.7 |  |  | 0.8 |  |  | (362.5) |  |  | 0.3 |  |  | 0.1 |  |
| Gain on sale from previous dispositions | (1.6) |  |  | — |  |  | 100.0 |  |  | (0.1) |  |  | — |  |
| Income from equity method investments | (2.5) |  |  | (3.1) |  |  | (19.4) |  |  | (0.2) |  |  | (0.2) |  |
| Operating income | $ | 320.1 |  |  | $ | 278.8 |  |  | 14.8 | % |  | 22.1 | % |  | 19.9 | % |

[0001628280-24-032782:mdna:18]
[same as prior period, unchanged from 0001628280-24-017634:mdna:18]

[0001628280-24-032782:mdna:19]
Net sales for the second quarter of 2024 increased 3% as compared to the same period in 2023.  This was primarily due to favorable price of 3%, higher sales volumes of 3%, and an increase in sales volumes of 2% from our AES acquisition, which were partially offset by a 5% reduction in sales due to the fourth quarter 2023 sale of our European businesses.

[0001628280-24-032782:mdna:20]
[same as prior period, unchanged from 0001628280-24-017634:mdna:20]

[0001628280-24-032782:mdna:21]
Gross profit margins in the second quarter of 2024 increased 120 basis points ("bps") to 33.6% as compared to 32.4% in the same period in 2023. Gross margins increased 240 bps from favorable price and 10 bps from miscellaneous other items, which were partially offset by 70 bps from higher freight and distribution costs and 60 bps from higher material and product costs.

[0001628280-24-032782:mdna:22]
[same as prior period, unchanged from 0001628280-24-017634:mdna:22]

[0001628280-24-032782:mdna:23]
Selling, general and administrative expenses ("SG&A") decreased $12 million to $169 million in the second quarter of 2024 as compared to $181 million in the same period in 2023 primarily due to a $16 million reduction in SG&A expenses from our fourth quarter of 2023 divestiture of our European businesses, which was partially offset by higher employee-related costs including increased incentive compensation. As a percentage of net sales, SG&A decreased 120 bps to 11.6%.

[0001628280-24-032782:mdna:24]
[same as prior period, unchanged from 0001628280-24-017634:mdna:24]

[0001628280-24-032782:mdna:25]
Losses (gains) and other expenses, net for the second quarter of 2024 and 2023 included the following (in millions):

[0001628280-24-032782:mdna:26]
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |  |  |
| Realized losses on settled future contracts | $ | — |  |  | $ | 0.1 |  |  |  |  |  |  |  |
| Foreign currency exchange losses (gains) | 1.5 |  |  | (2.4) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.5) |  |  | (1.0) |  |  |  |  |  |  |  |
| Other operating income | — |  |  | (0.2) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | 0.2 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 2.4 |  |  | 4.8 |  |  |  |  |  |  |  |
| Other items, net | 0.3 |  |  | (0.7) |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.7 |  |  | $ | 0.8 |  |  |  |  |  |  |  |

[0001628280-24-032782:mdna:27]
[same as prior period, unchanged from 0001628280-24-017634:mdna:27]

[0001628280-24-032782:mdna:28]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers, and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation. Accordingly, these joint ventures are accounted for under the equity method and their financial position and results of operations are not consolidated. We recognized income from equity method investments of $3 million in the second quarter of 2024 and in the second quarter of 2023.

[0001628280-24-032782:mdna:29]
[same as prior period, unchanged from 0001628280-24-017634:mdna:29]

[0001628280-24-032782:mdna:30]
Interest expense, net decreased to $13 million in the second quarter of 2024 from $15 million in the same period in 2023 due to lower borrowings.

[0001628280-24-032782:mdna:31]
[same as prior period, unchanged from 0001628280-24-017634:mdna:31]

[0001628280-24-032782:mdna:32]
Our effective tax rate was 19.9% for the second quarter of 2024 as compared to 17.6% in the same period in 2023.  The increase in rate was primarily due to income allocated to high-tax jurisdictions partially offset by a favorable adjustment for excess tax benefits.

[0001628280-24-032782:mdna:33]
Second Quarter of 2024 Compared to Second Quarter of 2023 - Results by Segment

[0001628280-24-032782:mdna:34]
[same as prior period, unchanged from 0001628280-24-017634:mdna:34]

[0001628280-24-032782:mdna:35]
The following table presents our Home Comfort Solutions segment's net sales and profit for the second quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-032782:mdna:36]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 982.3 |  |  | $ | 936.2 |  |  | $ | 46.1 |  |  | 5 | % |
| Profit | $ | 228.5 |  |  | $ | 202.6 |  |  | $ | 25.9 |  |  | 13 | % |
| % of net sales | 23.3 | % |  | 21.6 | % |  |  |  |  |

[0001628280-24-032782:mdna:37]
Net sales increased 5% in the second quarter of 2024 as compared to the same period in 2023 primarily due to favorable price of 4% and higher sales volumes of 1%.

[0001628280-24-032782:mdna:38]
Segment profit in the second quarter of 2024 increased by $26 million as compared to the same period in 2023, primarily due to $42 million from favorable price and mix and $2 million from higher sales volumes.  Partially offsetting these increases were $10 million from higher freight and distribution costs, $3 million from higher SG&A costs, and $5 million from miscellaneous other items.

[0001628280-24-032782:mdna:39]
[same as prior period, unchanged from 0001628280-24-017634:mdna:39]

[0001628280-24-032782:mdna:40]
The following table presents our Building Climate Solutions segment's net sales and profit for the second quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-032782:mdna:41]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 468.8 |  |  | $ | 407.5 |  |  | $ | 61.3 |  |  | 15 | % |
| Profit | $ | 114.0 |  |  | $ | 103.0 |  |  | $ | 11.0 |  |  | 11 | % |
| % of net sales | 24.3 | % |  | 25.3 | % |  |  |  |  |

[0001628280-24-032782:mdna:42]
Net sales increased 15% in the second quarter of 2024 as compared to the same period in 2023 primarily due to higher sales volumes of 9%, favorable price of 2%, and a 6% increase in sales volumes from our AES acquisition which were partially offset by unfavorable product mix of 2%.

[0001628280-24-032782:mdna:43]
Segment profit in the second quarter of 2024 increased $11 million as compared to the same period in 2023 primarily due to $12 million from higher sales volumes, $6 million from favorable price, and $5 million from our acquisition of AES.  Partially offsetting these increases was $6 million in higher factory inefficiencies, which includes costs related to the ramp up of our new factory in Mexico, $4 million in unfavorable product mix, and $2 million from miscellaneous other items.

[0001628280-24-032782:mdna:44]
[same as prior period, unchanged from 0001628280-24-017634:mdna:44]

[0001628280-24-032782:mdna:45]
The following table presents our Corporate and Other segment's net sales and loss for the second quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-032782:mdna:46]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | 67.7 |  |  | $ | (67.7) |  |  | (100) | % |
| Loss | $ | (24.0) |  |  | $ | (22.5) |  |  | $ | (1.5) |  |  | (7) | % |

[0001628280-24-032782:mdna:47]
Net sales decreased $68 million and segment loss increased $2 million in the second quarter of 2024 as compared to the same period in 2023.  Our European businesses, which were sold in the fourth quarter of 2023, generated $68 million in net sales and $2 million in segment profit in the second quarter of 2023.  Excluding our European businesses, Corporate and Other costs decreased $1 million in the second quarter of 2024 as compared to the same period in 2023 primarily due to lower incentive compensation costs which were partially offset by higher legal, professional, and other costs.

[0001628280-24-032782:mdna:48]
Year-to-Date through June 30, 2024 Compared to Year-to-Date through June 30, 2023 - Consolidated Results

[0001628280-24-032782:mdna:49]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001628280-24-032782:mdna:50]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 2,498.2 |  |  | $ | 2,460.7 |  |  | 1.5 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,670.0 |  |  | 1,696.2 |  |  | 1.5 |  |  | 66.8 |  |  | 68.9 |  |
| Gross profit | 828.2 |  |  | 764.5 |  |  | 8.3 |  |  | 33.2 |  |  | 31.1 |  |
| Selling, general and administrative expenses | 339.2 |  |  | 348.8 |  |  | 2.8 |  |  | 13.6 |  |  | 14.2 |  |
| Losses (gains) and other expenses, net | 7.4 |  |  | 1.1 |  |  | (572.7) |  |  | 0.3 |  |  | — |  |
| Gain on sale from previous dispositions | (1.6) |  |  | — |  |  | 100.0 |  |  | (0.1) |  |  | — |  |
| Income from equity method investments | (3.7) |  |  | (3.8) |  |  | (2.6) |  |  | (0.1) |  |  | (0.2) |  |
| Operating income | $ | 486.9 |  |  | $ | 418.4 |  |  | 16.4 | % |  | 19.5 | % |  | 17.0 | % |

[0001628280-24-032782:mdna:51]
Net Sales

[0001628280-24-032782:mdna:52]
Net sales increased 2% for the six months ended June 30, 2024 as compared to the same period in 2023. This was primarily due to favorable price of 3%, higher sales volumes of 2% and an increase in sales volumes of 2% from our AES acquisition which were partially offset by a 5% reduction in sales due to the fourth quarter 2023 sale of our European businesses.

[0001628280-24-032782:mdna:53]
Gross Profit

[0001628280-24-032782:mdna:54]
Gross profit margins for the six months ended June 30, 2024 increased 210 bps to 33.2% as compared to 31.1% in the same period in 2023. Gross margins increased 260 bps from higher price and 40 bps from miscellaneous other items, which were partially offset by 60 bps from higher freight and distribution costs, and 30 bps from higher material and product costs.

[0001628280-24-032782:mdna:55]
Selling, General and Administrative Expenses

[0001628280-24-032782:mdna:56]
SG&A decreased $10 million to $339 million for the six months ended June 30, 2024 as compared to $349 million in the same period in 2023 primarily due to a $32 million reduction in SG&A expenses from our fourth quarter of 2023 divestiture of our European businesses, which was partially offset by higher employee-related costs including increased incentive compensation. As a percentage of net sales, SG&A decreased 60 bps to 13.6% from 14.2%.

[0001628280-24-032782:mdna:57]
Losses (gains) and Other Expenses, Net

[0001628280-24-032782:mdna:58]
Losses (gains) and other expenses, net for the six months ended June 30, 2024 and 2023 included the following (in millions):

[0001628280-24-032782:mdna:59]
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |  |  |
| Realized losses on settled future contracts | $ | — |  |  | $ | 0.1 |  |  |  |  |  |  |  |
| Foreign currency exchange losses (gains) | 2.8 |  |  | (3.2) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (1.0) |  |  | (1.3) |  |  |  |  |  |  |  |
| Other operating loss (income) | 0.8 |  |  | (0.9) |  |  |  |  |  |  |  |
| Net change in unrealized gains (losses) on unsettled futures contracts | — |  |  | (0.1) |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 4.7 |  |  | 7.3 |  |  |  |  |  |  |  |
| Other items, net | — |  |  | (0.8) |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 7.4 |  |  | $ | 1.1 |  |  |  |  |  |  |  |

[0001628280-24-032782:mdna:60]
Income from Equity Method Investments

[0001628280-24-032782:mdna:61]
Income from equity method investments remained consistent at $4 million for the six months ended June 30, 2024 as compared to $4 million in the same period in 2023.

[0001628280-24-032782:mdna:62]
Interest Expense, net

[0001628280-24-032782:mdna:63]
Interest expense, net decreased $5 million for the six months ended June 30, 2024 to $24 million as compared to $29 million in the same period in 2023 primarily due to lower borrowings.

[0001628280-24-032782:mdna:64]
Income Taxes

[0001628280-24-032782:mdna:65]
Our effective tax rate was 19.7% for the six months ended June 30, 2024 as compared to 19.0% in the same period in 2023. The increase in rate was primarily due to income allocated to high-tax jurisdictions partially offset by a favorable adjustment for excess tax benefits.

[0001628280-24-032782:mdna:66]
Year-to-Date through June 30, 2024 Compared to Year-to-Date through June 30, 2023 - Results by Segment

[0001628280-24-032782:mdna:67]
Home Comfort Solutions

[0001628280-24-032782:mdna:68]
The following table presents our Home Comfort Solutions segment's net sales and profit for the six months ended June 30, 2024 and 2023 (dollars in millions):

[0001628280-24-032782:mdna:69]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 1,656.9 |  |  | $ | 1,617.2 |  |  | $ | 39.7 |  |  | 2 | % |
| Profit | $ | 340.6 |  |  | $ | 313.7 |  |  | $ | 26.9 |  |  | 9 | % |
| % of net sales | 20.6 | % |  | 19.4 | % |  |  |  |  |

[0001628280-24-032782:mdna:70]
Net sales increased 2% for the six months ended June 30, 2024 as compared to the same period in 2023. This was primarily due to favorable price of 4%, which was partially offset by lower sales volumes of 1% and unfavorable mix of 1%.

[0001628280-24-032782:mdna:71]
Segment profit for the first six months of 2024 increased $27 million as compared to the same period in 2023 primarily due to $61 million from favorable price, which was partially offset by $15 million from higher SG&A costs, $15 million from higher freight and distribution costs, and $4 million from miscellaneous other items.

[0001628280-24-032782:mdna:72]
Building Climate Solutions

[0001628280-24-032782:mdna:73]
The following table presents our Building Climate Solutions segment's net sales and profit for the six months ended June 30, 2024 and 2023 (dollars in millions):

[0001628280-24-032782:mdna:74]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 841.3 |  |  | $ | 716.1 |  |  | $ | 125.2 |  |  | 17 | % |
| Profit | $ | 192.2 |  |  | $ | 153.0 |  |  | $ | 39.2 |  |  | 26 | % |
| % of net sales | 22.8 | % |  | 21.4 | % |  |  |  |  |

[0001628280-24-032782:mdna:75]
Net sales increased 17% for the six months ended June 30, 2024 as compared to the same period in 2023. This was primarily due to higher sales volumes of 8%, favorable price of 3%, and a 6% increase in sales volumes from our AES acquisition.

[0001628280-24-032782:mdna:76]
Segment profit for the first six months of 2024 increased $39 million as compared to the same period in 2023 primarily due to $25 million from higher price, $20 million from higher sales volumes and $10 million from our acquisition of AES, which were partially offset by $8 million from higher factory inefficiencies, which includes costs related to the ramp up of our new facility in Mexico, $4 million from higher SG&A costs, and $4 million from miscellaneous other items.

[0001628280-24-032782:mdna:77]
Corporate and Other

[0001628280-24-032782:mdna:78]
The following table presents our Corporate and Other segment's net sales and loss for the six months ended June 30, 2024 and 2023 (dollars in millions):

[0001628280-24-032782:mdna:79]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | 127.4 |  |  | $ | (127.4) |  |  | (100) | % |
| Loss | $ | (47.5) |  |  | $ | (41.9) |  |  | $ | (5.6) |  |  | (13) | % |

[0001628280-24-032782:mdna:80]
Net sales decreased $127 million and segment loss increased $6 million during the six months ended June 30, 2024 as compared to the same period in 2023.  Our European businesses, which were sold in the fourth quarter of 2023, generated net sales of $127 million and a profit of $2 million in the six months ended June 30, 2023.  Excluding our European businesses,

[0001628280-24-032782:mdna:81]
Corporate and Other costs increased $4 million in the first six months of 2024 as compared to the same period in 2023 primarily due to higher incentive compensation costs and wage inflation.

[0001628280-24-032782:mdna:82]
[same as prior period, unchanged from 0001628280-24-017634:mdna:48]

[0001628280-24-032782:mdna:83]
[same as prior period, unchanged from 0001628280-24-017634:mdna:49]

[0001628280-24-032782:mdna:84]
[same as prior period, unchanged from 0001628280-24-017634:mdna:50]

[0001628280-24-032782:mdna:85]
The following table summarizes our cash flow activity for the six months ended June 30, 2024 and 2023 (in millions):

[0001628280-24-032782:mdna:86]
|  | For the Six Months Ended June 30, |
|  | 2024 |  | 2023 |
| Net cash provided by operating activities | $ | 161.2 |  |  | $ | 116.7 |  |
| Net cash used in investing activities | (57.2) |  |  | (82.3) |  |
| Net cash used in financing activities | (118.3) |  |  | (33.8) |  |

[0001628280-24-032782:mdna:87]
Net Cash Provided By Operating Activities - The change in net cash provided by operating activities for the six months ended June 30, 2024 compared to the net cash provided by operating activities for the same period in 2023 reflects changes in working capital and an increase in net income.

[0001628280-24-032782:mdna:88]
Net Cash Used In Investing Activities - Capital expenditures were $62 million for the six months ended June 30, 2024 compared to $85 million in the same period of 2023.  Capital expenditures in 2024 were related to our Commercial factory in Mexico, the general expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-24-032782:mdna:89]
Net Cash Used In Financing Activities - Net cash used in financing activities for the six months ended June 30, 2024 increased to $118 million as compared to $34 million in the same period of 2023.  The change was primarily due to changes in net borrowings and repayments of long-term debt.  We returned $78 million to shareholders through dividend payments for the six months ended June 30, 2024 and $75 million in the same period of 2023.

[0001628280-24-032782:mdna:90]
[same as prior period, unchanged from 0001628280-24-017634:mdna:56]

[0001628280-24-032782:mdna:91]
The following table details our lines of credit and financing arrangements as of June 30, 2024 (in millions):

[0001628280-24-032782:mdna:92]
|  | Outstanding Borrowings |
| Commercial paper: | $ | 147.0 |  |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 14.0 |  |
| Total current maturities of long-term debt | $ | 14.0 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 35.0 |  |
| Credit agreement | — |  |
| Senior unsecured notes | 1,100.0 |  |
| Debt issuance costs | (8.2) |  |
| Total long-term debt | $ | 1,126.8 |  |
| Total debt | $ | 1,287.8 |  |

[0001628280-24-032782:mdna:93]
[same as prior period, unchanged from 0001628280-24-017634:mdna:59]

[0001628280-24-032782:mdna:94]
On October 25, 2023, we established a commercial paper program, as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. CP Notes currently outstanding under the Program totaled $147.0 million as of June 30, 2024.

[0001628280-24-032782:mdna:95]
[same as prior period, unchanged from 0001628280-24-017634:mdna:61]

[0001628280-24-032782:mdna:96]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had 0 outstanding borrowings and $1.7 million committed to standby letters of credit as of June 30, 2024. Subject to covenant limitations, $951.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-24-032782:mdna:97]
[same as prior period, unchanged from 0001628280-24-017634:mdna:63]

[0001628280-24-032782:mdna:98]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.

[0001628280-24-032782:mdna:99]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2024, we believe we were in compliance with all covenant requirements.

[0001628280-24-032782:mdna:100]
[same as prior period, unchanged from 0001628280-24-017634:mdna:68]

[0001628280-24-032782:mdna:101]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 69% as of June 30, 2024 from 82% as of December 31, 2023.

[0001628280-24-032782:mdna:102]
As of June 30, 2024, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-24-032782:mdna:103]
[same as prior period, unchanged from 0001628280-24-017634:mdna:71]

[0001628280-24-032782:mdna:104]
We believe our cash and cash equivalents of $47.6 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share

[0001628280-24-032782:mdna:105]
26

[0001628280-24-032782:mdna:106]
repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $47.6 million as of June 30, 2024 was $20 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-24-032782:mdna:107]
[same as prior period, unchanged from 0001628280-24-017634:mdna:73]

[0001628280-24-032782:mdna:108]
[same as prior period, unchanged from 0001628280-24-017634:mdna:74]

[0001628280-24-032782:mdna:109]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of June 30, 2024 and December 31, 2023 and for the three and six months ended June 30, 2024 (in millions):

[0001628280-24-032782:mdna:110]
|  | June 30, 2024 |  | December 31, 2023 |
| Current assets | $ | 1,601.2 |  |  | $ | 1,291.0 |  |
| Non-current assets | 6,399.5 |  |  | 5,737.1 |  |
| Current liabilities | 905.5 |  |  | 843.3 |  |
| Non-current liabilities | 1,514.4 |  |  | 1,477.3 |  |
| Amounts due to non-guarantor subsidiaries | (533.0) |  |  | (472.3) |  |
|  | For the Three Months Ended June 30, 2024 |  | For the Six Months Ended June 30, 2024 |
| Net Sales | $ | 1,430.2 |  |  | $ | 2,465.9 |  |
| Gross Profit | 402.3 |  |  | 661.8 |  |
| Net Income | 556.0 |  |  | 845.8 |  |

[0001628280-24-032782:mdna:111]
[same as prior period, unchanged from 0001628280-24-017634:mdna:77]

[0001628280-24-032782:mdna:112]
[same as prior period, unchanged from 0001628280-24-017634:mdna:78]

[0001628280-24-032782:mdna:113]
Commitments, Contingencies, and Guarantees

[0001628280-24-032782:mdna:114]
For information regarding our commitments, contingencies, and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-24-032782:mdna:115]
[same as prior period, unchanged from 0001628280-24-017634:mdna:81]

[0001628280-24-032782:mdna:116]
[same as prior period, unchanged from 0001628280-24-017634:mdna:82]
