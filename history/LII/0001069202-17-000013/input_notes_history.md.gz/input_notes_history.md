# LII note change history — 0001069202-17-000009 → 0001069202-17-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-10-24):
[0001069202-17-000013:note_history:1]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 34.9 |  |  | $ | 30.0 |  |
| Other liabilities | 72.7 |  |  | 71.1 |  |
| Total warranty liability | $ | 107.6 |  |  | $ | 101.1 |  |
  (was, 2017-07-24, similarity 0.9687):
[0001069202-17-000009:note_history:1]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 32.5 |  |  | $ | 30.0 |  |
| Other liabilities | 73.1 |  |  | 71.1 |  |
| Total warranty liability | $ | 105.6 |  |  | $ | 101.1 |  |

- changed (2017-10-24):
[0001069202-17-000013:note_history:2]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2017 were as follows (in millions):
  (was, 2017-07-24, similarity 0.9444):
[0001069202-17-000009:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2017 were as follows (in millions):

- changed (2017-10-24):
[0001069202-17-000013:note_history:3]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (21.6 | ) |
| Changes resulting from issuance of new warranties | 32.2 |  |
| Changes in estimates associated with pre-existing liabilities | (4.7 | ) |
| Changes in foreign currency translation rates and other | 0.6 |  |
| Total warranty liability as of September 30, 2017 | $ | 107.6 |  |
  (was, 2017-07-24, similarity 0.9813):
[0001069202-17-000009:note_history:3]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (11.6 | ) |
| Changes resulting from issuance of new warranties | 19.6 |  |
| Changes in estimates associated with pre-existing liabilities | (4.2 | ) |
| Changes in foreign currency translation rates and other | 0.7 |  |
| Total warranty liability as of June 30, 2017 | $ | 105.6 |  |

- changed (2017-10-24):
[0001069202-17-000013:note_history:4]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.
  (was, 2017-07-24, similarity 0.6709):
[0001069202-17-000009:note_history:4]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. We currently estimate our probable liability for a certain supplier quality issue within a range of $0.9 million and $9.1 million with all amounts in that range equally likely. We have accrued a $0.9 million liability in Accrued expenses on the Consolidated Balance Sheet at June 30, 2017. The supplier is reimbursing us for the majority of the costs related to this liability.

- added (2017-10-24):
[0001069202-17-000013:note_history:5]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect has been isolated, the vendor is supplying corrected components, and we are manufacturing product with the corrected components.  We have also implemented a program for our dealers to install corrected components in the field. We recorded an expense of $0.5 million and $5.7 million for the three and nine months ended September 30, 2017, respectively, relating to estimated repair costs. The expense related to this product quality issue has been classified in Cost of goods sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses on the Consolidated Balance Sheet.

- changed (2017-10-24):
[0001069202-17-000013:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2017 and 2016, expense for asbestos-related litigation was $3.9 million and $2.3 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.  For the three months ended  September 30, 2017 and 2016, expense for asbestos-related litigation was $1.5 million and $0.4 million, respectively, net of probable insurance recoveries.
  (was, 2017-07-24, similarity 0.9154):
[0001069202-17-000009:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2017 and 2016, expense for asbestos-related litigation was $2.4 million and $1.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.

- changed (2017-10-24):
[0001069202-17-000013:note_history:7]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.
  (was, 2017-07-24, similarity 0.753):
[0001069202-17-000009:note_history:7]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants. The alleged payment was purportedly made to release a shipment of goods being held by Russian customs officials due to inaccurate paperwork. The value of the shipment was approximately €62,000 (approximately US $68,500). The allegations are related to our subsidiary in Russia, which had 2016 annual sales of US $4 million. The scope of the investigation was later expanded to include our operations in Poland and Ukraine. To date, the investigation has not resulted in any evidence of other potentially improper payments. However, the investigation has raised questions regarding possible irregularities with respect to possible non-compliance with customs documents and procedures related to these operations.  The investigation is ongoing. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.

- removed (2017-10-24):
[0001069202-17-000009:note_history:8]
We have identified a product quality issue in a residential heating and cooling product line in the Residential Heating & Cooling  segment that results from a defective vendor-supplied component.  This defect has been isolated, the vendor has begun supplying corrected components, and we have begun installing the corrected components.  For the quarter ended June 30, 2017, we recorded an expense of $5.2 million relating to total estimated repair costs.  The expense related to this product quality issue has been classified in Cost of goods sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses on the Consolidated Balance Sheet.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-10-24):
[0001069202-17-000013:note_history:9]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2017, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2017-07-24, similarity 0.9487):
[0001069202-17-000009:note_history:9]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2017, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2017-10-24):
[0001069202-17-000013:note_history:10]
On March 30, 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations.  This is in comparison to the prior requirement that these excess tax benefits be recognized in additional paid-in capital. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity.
  (was, 2017-07-24, similarity 0.942):
[0001069202-17-000009:note_history:10]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations.  This is in comparison to the prior requirement that these excess tax benefits be recognized in additional paid-in capital. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity.

- changed (2017-10-24):
[0001069202-17-000013:note_history:11]
| • | We recognized discrete tax benefits of $1.5 million and $9.6 million in the income taxes line item of our consolidated statements of operations for the three and nine months ended September 30, 2017 respectively, related to excess tax benefits upon vesting or settlement in that period. |
  (was, 2017-07-24, similarity 0.9149):
[0001069202-17-000009:note_history:11]
| • | We recognized discrete tax benefits of $0.7 million and $8.1 million in the income taxes line item of our consolidated statements of operations for the three and six months ended June 30, 2017 respectively, related to excess tax benefits upon vesting or settlement in that period. |

- changed (2017-10-24):
[0001069202-17-000013:note_history:12]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three and nine months ended September 30, 2017. |
  (was, 2017-07-24, similarity 0.96):
[0001069202-17-000009:note_history:12]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three and six months ended June 30, 2017. |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-10-24):
[0001069202-17-000013:note_history:13]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.47 | % |  | 2.00 | % |
  (was, 2017-07-24, similarity 0.9447):
[0001069202-17-000009:note_history:13]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.45 | % |  | 2.00 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-10-24):
[0001069202-17-000013:note_history:14]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 325.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.0 |  |  | 2.4 |  |
| Total short-term debt | $ | 326.0 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 0.8 |  |
| Domestic credit facility | 22.5 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 22.4 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.7 |  |  | $ | 15.0 |  |
| Domestic credit facility | 415.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.5 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 775.7 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,124.1 |  |  | $ | 868.2 |  |

- changed (2017-10-24):
[0001069202-17-000013:note_history:15]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.0 million and $2.4 million of foreign obligations outstanding as of September 30, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $19.1 million  and $28.2 million during the nine months ended September 30, 2017 and 2016, respectively. Repayments on the facilities were $20.5 million and $30.3 million during the nine months ended September 30, 2017 and 2016, respectively.
  (was, 2017-07-24, similarity 0.8816):
[0001069202-17-000009:note_history:15]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.3 million and $2.4 million of foreign obligations as of June 30, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.8 million  and $20.4 million during the six months ended June 30, 2017 and 2016, respectively. Repayments on the facilities were $1.8 million and $20.0 million during the six months ended June 30, 2017 and 2016, respectively.

- added (2017-10-24):
[0001069202-17-000013:note_history:16]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 325.0 |  |  | $ | 250.0 |  |
| Less: Beneficial interest sold | 325.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |

- changed (2017-10-24):
[0001069202-17-000013:note_history:17]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The rates as of September 30, 2017 and December 31, 2016 were 1.99% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2017-07-24, similarity 0.9921):
[0001069202-17-000009:note_history:17]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The rates as of June 30, 2017 and December 31, 2016 were 1.90% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2017-10-24):
[0001069202-17-000013:note_history:18]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2017, we believe we were in compliance with all covenant requirements.
  (was, 2017-07-24, similarity 0.9782):
[0001069202-17-000009:note_history:18]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2017, we believe we were in compliance with all covenant requirements.

- changed (2017-10-24):
[0001069202-17-000013:note_history:19]
On August 30, 2016, we replaced an earlier credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $438.0 million, of which $220.0 million was the term loan balance, as well as $3.0 million committed to standby letters of credit as of September 30, 2017. Subject to covenant limitations, $429.0 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.
  (was, 2017-07-24, similarity 0.9931):
[0001069202-17-000009:note_history:19]
On August 30, 2016, we replaced an earlier credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $577.5 million, of which $220.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of June 30, 2017. Subject to covenant limitations, $288.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2017-10-24):
[0001069202-17-000013:note_history:20]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.47 | % |  | 2.00 | % |
  (was, 2017-07-24, similarity 0.9447):
[0001069202-17-000009:note_history:20]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.45 | % |  | 2.00 | % |

- changed (2017-10-24):
[0001069202-17-000013:note_history:21]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2017, we believe we were in compliance with all covenant requirements.
  (was, 2017-07-24, similarity 0.946):
[0001069202-17-000009:note_history:21]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2017, we believe we were in compliance with all covenant requirements.

- changed (2017-10-24):
[0001069202-17-000013:note_history:22]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also repaid $200.0 million of senior unsecured notes issued in 2010 that matured on May 15, 2017.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2017, we believe we were in compliance with all covenant requirements.
  (was, 2017-07-24, similarity 0.9494):
[0001069202-17-000009:note_history:22]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also repaid $200.0 million of senior unsecured notes issued in 2010 that matured on May 15, 2017.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2017, we believe we were in compliance with all covenant requirements.

- removed (2017-10-24):
[0001069202-17-000009:note_history:23]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 250.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.3 |  |  | 2.4 |  |
| Total short-term debt | $ | 251.3 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.6 |  |  | $ | 0.8 |  |
| Domestic credit facility | 15.0 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 15.0 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.8 |  |  | $ | 15.0 |  |
| Domestic credit facility | 562.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.7 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 922.6 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,188.9 |  |  | $ | 868.2 |  |

- removed (2017-10-24):
[0001069202-17-000009:note_history:24]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 250.0 |  |  | $ | 250.0 |  |
| Less: Beneficial interest sold | 250.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-10-24):
[0001069202-17-000013:note_history:25]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 325.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.0 |  |  | 2.4 |  |
| Total short-term debt | $ | 326.0 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 0.8 |  |
| Domestic credit facility | 22.5 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 22.4 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.7 |  |  | $ | 15.0 |  |
| Domestic credit facility | 415.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.5 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 775.7 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,124.1 |  |  | $ | 868.2 |  |

- removed (2017-10-24):
[0001069202-17-000009:note_history:26]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 250.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.3 |  |  | 2.4 |  |
| Total short-term debt | $ | 251.3 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.6 |  |  | $ | 0.8 |  |
| Domestic credit facility | 15.0 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 15.0 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.8 |  |  | $ | 15.0 |  |
| Domestic credit facility | 562.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.7 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 922.6 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,188.9 |  |  | $ | 868.2 |  |
