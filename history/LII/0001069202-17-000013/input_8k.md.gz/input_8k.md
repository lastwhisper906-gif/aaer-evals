# LII 8-K — 0001193125-17-316060 filed 2017-10-23

## item codes, every 8-K on or before 2017-10-24

- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2017-10-24

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-316060:8k_2_02:1]
EX-99.1
2
d672158dex991.htm
EX-99.1

[0001193125-17-316060:8k_2_02:2]
EX-99.1

[0001193125-17-316060:8k_2_02:3]
Exhibit 99.1

[0001193125-17-316060:8k_2_02:4]
Lennox International Reports Record Third-Quarter Revenue and Profit

[0001193125-17-316060:8k_2_02:5]
|  | • |  | Revenue up 4% to third-quarter record $1.05 billion |

[0001193125-17-316060:8k_2_02:6]
|  | • |  | Record third-quarter GAAP EPS from continuing operations of $2.45, up 5% |

[0001193125-17-316060:8k_2_02:7]
|  | • |  | Record third-quarter adjusted EPS from continuing operations of $2.53, up 9% |

[0001193125-17-316060:8k_2_02:8]
|  | • |  | Updating 2017 revenue growth guidance from 4-7% with neutral foreign exchange to 5-7% with a 0.5% benefit from foreign exchange |

[0001193125-17-316060:8k_2_02:9]
|  | • |  | Updating 2017 GAAP EPS from continuing operations guidance from $7.73-$8.13 to $7.67-$7.97 |

[0001193125-17-316060:8k_2_02:10]
|  | • |  | Updating 2017 adjusted EPS from continuing operations guidance from $7.75-$8.15 to $7.75-$8.05 |

[0001193125-17-316060:8k_2_02:11]
|  | • |  | $250 million of stock repurchases and $58 million of dividends year-to-date |

[0001193125-17-316060:8k_2_02:12]
DALLAS, October 23,
2017 – Lennox International Inc. (NYSE: LII) today reported financial results for the third quarter of 2017. All comparisons are to the prior-year period.

[0001193125-17-316060:8k_2_02:13]
Revenue was a third-quarter record $1.052 billion, up 4%. At constant currency, revenue was up 3%. GAAP operating income was $155 million, down 1%. GAAP
earnings per share from continuing operations was a third-quarter record $2.45, up 5%.

[0001193125-17-316060:8k_2_02:14]
On an adjusted basis, total segment profit increased 2% to a
third-quarter record $161 million. Total segment margin was 15.3%, down 30 basis points from the record third-quarter level of a year ago. Adjusted EPS from continuing operations rose 9% to a third-quarter record $2.53.

[0001193125-17-316060:8k_2_02:15]
“While underlying economic conditions remain strong, the third quarter was materially impacted by significantly cooler weather than a year ago and the
near-term market disruption from the hurricanes that hit Texas and Florida,” said Chairman and CEO Todd Bluedorn. “These dynamics negatively impacted the company’s growth and margin performance in the quarter — specifically for
our residential replacement, commercial emergency replacement, and refrigeration wholesale businesses. That being said, the company posted record third-quarter revenue, total segment profit, and EPS.

[0001193125-17-316060:8k_2_02:16]
“In Residential, revenue and profit hit new third-quarter highs. Revenue rose 3% on high-single digit growth in new construction and low-single digit
growth in replacement. Segment margin was off 30 basis points to 19.4%. Residential profit rose 2% in the quarter.

[0001193125-17-316060:8k_2_02:17]
“Our Commercial business set new all-time highs for revenue and profit. Commercial revenue was up 6% at
constant currency, led by nearly 20% growth in National Accounts and mid-teen growth in National Account Services. Planned replacement revenue was up 20%, while emergency replacement revenue was relatively flat. Europe was down double digits.
Commercial margin was off 90 basis points to 18.6%. Commercial profit rose 2%.

[0001193125-17-316060:8k_2_02:18]
“In Refrigeration, revenue was up 2% at constant currency. North
America, our most profitable region, was flat, while Europe, Asia Pacific, and South America were up. Refrigeration margin was down 190 basis points to 10.4%, and segment profit was down 13%.

[0001193125-17-316060:8k_2_02:19]
“Looking ahead for the company overall with the recovery in key regions underway, we are well-positioned to close out a year of record revenue, margin
and profit in 2017 and to drive strong growth and profitability over the coming year.”

[0001193125-17-316060:8k_2_02:20]
FINANCIAL HIGHLIGHTS

[0001193125-17-316060:8k_2_02:21]
Revenue: Revenue was a third-quarter record $1.052 billion, up 4%. Foreign exchange was a 1 percentage point benefit to revenue growth. Volume and price
were up. Mix was unfavorable in the quarter.

[0001193125-17-316060:8k_2_02:22]
Gross Profit: Gross profit in the third quarter was $314 million, up 1%. Gross margin was 29.8%, down
90 basis points. Gross profit was positively impacted by higher volume, favorable price, sourcing and engineering-led cost reductions, and foreign exchange, with offsets from higher commodity and other product costs, unfavorable mix, and investments
in distribution expansion.

[0001193125-17-316060:8k_2_02:23]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the third quarter was $104.0
million, or $2.45 per share, compared to $101.7 million, or $2.33 per share, in the prior-year quarter.

[0001193125-17-316060:8k_2_02:24]
Adjusted income from continuing operations in the
third quarter was $106.9 million, or $2.53 per share, compared to $101.9 million, or $2.33 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the third quarter of 2017 excludes net after-tax charges of $2.9
million: $1.3 million of special legal contingency charges, $1.1 million of restructuring charges, $1.0 million for asbestos-related litigation, a total of $1.0 million for other items, and a benefit of $1.5 million for excess tax benefits from
share-based compensation.

[0001193125-17-316060:8k_2_02:25]
Free Cash Flow and Total Debt: Net cash from operations in the third quarter was $177 million, up from $152 million in
the prior-year quarter. Capital expenditures were $17 million compared to $18 million in the prior-year quarter. Free cash flow was $160 million, up from approximately $134 million in the third quarter a year ago. Total debt at the end of the third
quarter was $1.124 billion. Total cash and cash equivalents were $61 million at the end of September. In the third quarter, the company paid approximately $22 million in dividends and $75 million for stock repurchases.

[0001193125-17-316060:8k_2_02:26]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-17-316060:8k_2_02:27]
Residential Heating & Cooling

[0001193125-17-316060:8k_2_02:28]
Revenue in the
Residential Heating & Cooling business segment rose 3% to a third-quarter record $591 million. Foreign exchange was neutral on a revenue basis. Segment profit was a third-quarter record $115 million, up 2%. Segment profit margin was 19.4%,
down 30 basis points from the third-quarter record margin a year ago. Results were positively impacted by higher volume, favorable price, sourcing and engineering-led cost reductions, and foreign exchange, with offsets from higher commodity and
other product costs, unfavorable mix, investments in research and development, information technology and other SG&A, and investments in distribution expansion.

[0001193125-17-316060:8k_2_02:29]
Commercial Heating & Cooling

[0001193125-17-316060:8k_2_02:30]
Revenue in the
Commercial Heating & Cooling business segment was a record $269 million, up 7%. At constant currency, revenue was up 6%. Segment profit was a record $50 million, up 2%. Segment margin was 18.6%, down 90 basis points from the third-quarter
record a year ago. Results were positively impacted by higher volume, favorable price, sourcing and engineering-led cost reductions, lower SG&A expenses, and favorable foreign exchange. Offsets included unfavorable mix, higher commodity and
other product costs, and higher freight and distribution expenses.

[0001193125-17-316060:8k_2_02:31]
Refrigeration

[0001193125-17-316060:8k_2_02:32]
Revenue in the Refrigeration business segment was $192 million, up 3%. At constant currency, revenue was up 2%. Segment margin was down 190 basis points to
10.4%, and segment profit declined 13% to $20 million. Results were impacted by unfavorable mix, higher commodity costs, higher freight and distribution expenses, and investments in research and development, information technology, and other
SG&A. Sourcing and engineering-led cost reductions were a partial offset.

[0001193125-17-316060:8k_2_02:33]
FULL-YEAR OUTLOOK

[0001193125-17-316060:8k_2_02:34]
For 2017, the company is updating guidance for revenue and EPS from continuing operations.

[0001193125-17-316060:8k_2_02:35]
|  | • |  | Updating 2017 guidance for revenue growth from 4-7% with neutral foreign exchange to 5-7% with a 0.5% benefit from foreign exchange. |

[0001193125-17-316060:8k_2_02:36]
|  | • |  | Updating guidance for GAAP EPS from continuing operations from $7.73-$8.13 to $7.67-$7.97. |

[0001193125-17-316060:8k_2_02:37]
|  | • |  | Updating guidance for adjusted EPS from continuing operations from $7.75-$8.15 to $7.75-$8.05. |

[0001193125-17-316060:8k_2_02:38]
|  | • |  | Reiterating corporate expenses of approximately $85 million. |

[0001193125-17-316060:8k_2_02:39]
|  | • |  | Reiterating guidance for an effective tax rate of 31-32% on an adjusted basis for the full year. |

[0001193125-17-316060:8k_2_02:40]
|  | • |  | Reiterating capital expenditures of approximately $100 million. |

[0001193125-17-316060:8k_2_02:41]
|  | • |  | Reiterating guidance for a weighted average diluted share count of 42-43 million shares on a full-year basis. |

[0001193125-17-316060:8k_2_02:42]
CONFERENCE CALL INFORMATION

[0001193125-17-316060:8k_2_02:43]
A conference call to discuss the company’s third quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call
line at 612-288-0329 at least 10 minutes prior to the scheduled start time and use reservation number 431566. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available
from 11:00 a.m. Central time on October 23 through November 6, 2017 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 431566. The call also will be archived on the company’s website.

[0001193125-17-316060:8k_2_02:44]
About Lennox International

[0001193125-17-316060:8k_2_02:45]
Lennox International Inc. is
a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at:
www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-17-316060:8k_2_02:46]
Forward-Looking Statements

[0001193125-17-316060:8k_2_02:47]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-316060:8k_2_02:48]
Consolidated Statements of Operations

[0001193125-17-316060:8k_2_02:49]
(Unaudited)

[0001193125-17-316060:8k_2_02:50]
| (Amounts in millions, except per share data) |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net sales |  | $ | 1,052.3 |  |  | $ | 1,010.0 |  |  | $ | 2,947.9 |  |  | $ | 2,744.4 |  |
| Cost of goods sold |  |  | 738.6 |  |  |  | 699.7 |  |  |  | 2,082.4 |  |  |  | 1,935.5 |  |
| Gross profit |  |  | 313.7 |  |  |  | 310.3 |  |  |  | 865.5 |  |  |  | 808.9 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 158.7 |  |  |  | 156.5 |  |  |  | 479.6 |  |  |  | 456.2 |  |
| Losses and other expenses, net |  |  | 3.0 |  |  |  | 0.7 |  |  |  | 8.5 |  |  |  | 5.5 |  |
| Restructuring charges |  |  | 1.9 |  |  |  | 0.6 |  |  |  | 2.1 |  |  |  | 1.2 |  |
| Income from equity method investments |  |  | (4.5 | ) |  |  | (4.4 | ) |  |  | (15.5 | ) |  |  | (15.3 | ) |
| Operating income |  |  | 154.6 |  |  |  | 156.9 |  |  |  | 390.8 |  |  |  | 361.3 |  |
| Interest expense, net |  |  | 7.6 |  |  |  | 7.0 |  |  |  | 23.3 |  |  |  | 19.6 |  |
| Other income, net |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Income from continuing operations before income taxes |  |  | 147.0 |  |  |  | 149.9 |  |  |  | 367.7 |  |  |  | 341.9 |  |
| Provision for income taxes |  |  | 43.0 |  |  |  | 48.2 |  |  |  | 103.8 |  |  |  | 104.0 |  |
| Income from continuing operations |  |  | 104.0 |  |  |  | 101.7 |  |  |  | 263.9 |  |  |  | 237.9 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | (0.8 | ) |  |  | — |  |  |  | (2.3 | ) |  |  | (0.9 | ) |
| Benefit from income taxes |  |  | (0.3 | ) |  |  | — |  |  |  | (0.9 | ) |  |  | (0.3 | ) |
| Loss from discontinued operations |  |  | (0.5 | ) |  |  | — |  |  |  | (1.4 | ) |  |  | (0.6 | ) |
| Net income |  | $ | 103.5 |  |  | $ | 101.7 |  |  | $ | 262.5 |  |  | $ | 237.3 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.48 |  |  | $ | 2.35 |  |  | $ | 6.23 |  |  | $ | 5.46 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | — |  |  |  | (0.03 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 2.47 |  |  | $ | 2.35 |  |  | $ | 6.20 |  |  | $ | 5.45 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.45 |  |  | $ | 2.33 |  |  | $ | 6.15 |  |  | $ | 5.39 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | — |  |  |  | (0.03 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 2.44 |  |  | $ | 2.33 |  |  | $ | 6.12 |  |  | $ | 5.38 |  |
| Weighted Average Number of Shares Outstanding—Basic |  |  | 41.9 |  |  |  | 43.2 |  |  |  | 42.3 |  |  |  | 43.6 |  |
| Weighted Average Number of Shares Outstanding—Diluted |  |  | 42.4 |  |  |  | 43.7 |  |  |  | 42.9 |  |  |  | 44.2 |  |
| Cash dividends declared per share |  | $ | 0.51 |  |  | $ | 0.43 |  |  | $ | 1.45 |  |  | $ | 1.22 |  |

[0001193125-17-316060:8k_2_02:51]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-316060:8k_2_02:52]
Segment Net Sales and Profit (Loss)

[0001193125-17-316060:8k_2_02:53]
(Unaudited)

[0001193125-17-316060:8k_2_02:54]
| (Amounts in millions) |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 590.5 |  |  | $ | 572.7 |  |  | $ | 1,663.8 |  |  | $ | 1,524.5 |  |
| Commercial Heating & Cooling |  |  | 269.4 |  |  |  | 251.4 |  |  |  | 723.5 |  |  |  | 674.7 |  |
| Refrigeration |  |  | 192.4 |  |  |  | 185.9 |  |  |  | 560.6 |  |  |  | 545.2 |  |
|  |  | $ | 1,052.3 |  |  | $ | 1,010.0 |  |  | $ | 2,947.9 |  |  | $ | 2,744.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 114.7 |  |  | $ | 112.7 |  |  | $ | 297.6 |  |  | $ | 266.9 |  |
| Commercial Heating & Cooling |  |  | 50.0 |  |  |  | 48.9 |  |  |  | 113.8 |  |  |  | 110.6 |  |
| Refrigeration |  |  | 20.0 |  |  |  | 22.9 |  |  |  | 55.7 |  |  |  | 53.2 |  |
| Corporate and other |  |  | (23.7 | ) |  |  | (27.3 | ) |  |  | (58.5 | ) |  |  | (65.7 | ) |
| Total segment profit |  |  | 161.0 |  |  |  | 157.2 |  |  |  | 408.6 |  |  |  | 365.0 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | 0.5 |  |  |  | — |  |  |  | 5.7 |  |  |  | (0.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 4.0 |  |  |  | (0.3 | ) |  |  | 10.0 |  |  |  | 2.9 |  |
| Restructuring charges |  |  | 1.9 |  |  |  | 0.6 |  |  |  | 2.1 |  |  |  | 1.2 |  |
| Operating income |  | $ | 154.6 |  |  | $ | 156.9 |  |  | $ | 390.8 |  |  | $ | 361.3 |  |

[0001193125-17-316060:8k_2_02:55]
| (1) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-17-316060:8k_2_02:56]
|  | • |  | Special product quality adjustments; |

[0001193125-17-316060:8k_2_02:57]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-17-316060:8k_2_02:58]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-17-316060:8k_2_02:59]
|  | • |  | Special legal contingency charges, |

[0001193125-17-316060:8k_2_02:60]
|  | • |  | Asbestos-related litigation, |

[0001193125-17-316060:8k_2_02:61]
|  | • |  | Contractor tax payments, |

[0001193125-17-316060:8k_2_02:62]
|  | • |  | Environmental liabilities, |

[0001193125-17-316060:8k_2_02:63]
|  | • |  | Acquisition costs, |

[0001193125-17-316060:8k_2_02:64]
|  | • |  | Other items, net; and, |

[0001193125-17-316060:8k_2_02:65]
|  | • |  | Restructuring charges. |

[0001193125-17-316060:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-316060:8k_2_02:67]
Consolidated Balance Sheets

[0001193125-17-316060:8k_2_02:68]
| (Amounts in millions, except shares and par values) |  | As of September 30,2017 |  |  | As of December 31,2016 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 60.7 |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net of allowances of $6.9 and $6.7 in 2017 and 2016, respectively |  |  | 598.1 |  |  |  | 469.8 |  |
| Inventories, net |  |  | 530.9 |  |  |  | 418.5 |  |
| Other assets |  |  | 80.9 |  |  |  | 67.4 |  |
| Total current assets |  |  | 1,270.6 |  |  |  | 1,005.9 |  |
| Property, plant and equipment, net of accumulated depreciation of $767.8 and $717.2 in 2017 and 2016, respectively |  |  | 374.6 |  |  |  | 361.4 |  |
| Goodwill |  |  | 200.6 |  |  |  | 195.1 |  |
| Deferred income taxes |  |  | 143.3 |  |  |  | 136.7 |  |
| Other assets, net |  |  | 66.6 |  |  |  | 61.2 |  |
| Total assets |  | $ | 2,055.7 |  |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 326.0 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt |  |  | 22.4 |  |  |  | 200.1 |  |
| Accounts payable |  |  | 394.5 |  |  |  | 361.2 |  |
| Accrued expenses |  |  | 278.4 |  |  |  | 265.9 |  |
| Income taxes payable |  |  | 2.4 |  |  |  | 9.0 |  |
| Total current liabilities |  |  | 1,023.7 |  |  |  | 888.6 |  |
| Long-term debt |  |  | 775.7 |  |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions |  |  | 1.9 |  |  |  | 2.8 |  |
| Pensions |  |  | 90.2 |  |  |  | 87.5 |  |
| Other liabilities |  |  | 131.7 |  |  |  | 127.7 |  |
| Total liabilities |  |  | 2,023.2 |  |  |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,048.0 |  |  |  | 1,046.2 |  |
| Retained earnings |  |  | 1,554.4 |  |  |  | 1,353.0 |  |
| Accumulated other comprehensive loss |  |  | (157.0 | ) |  |  | (195.1 | ) |
| Treasury stock, at cost, 45,401,841 shares and 44,195,250 shares as of September 30, 2017 and December 31, 2016, respectively |  |  | (2,414.2 | ) |  |  | (2,167.4 | ) |
| Noncontrolling interests |  |  | 0.4 |  |  |  | 0.4 |  |
| Total stockholders’ equity |  |  | 32.5 |  |  |  | 38.0 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,055.7 |  |  | $ | 1,760.3 |  |

[0001193125-17-316060:8k_2_02:69]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-316060:8k_2_02:70]
Consolidated Statements of Cash Flows

[0001193125-17-316060:8k_2_02:71]
(Unaudited)

[0001193125-17-316060:8k_2_02:72]
| (Amounts in millions) |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 262.5 |  |  | $ | 237.3 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (15.5 | ) |  |  | (15.3 | ) |
| Dividends from affiliates |  |  | 7.8 |  |  |  | 3.9 |  |
| Restructuring charges (gains), net of cash paid |  |  | 1.0 |  |  |  | (0.8 | ) |
| Provision for bad debts |  |  | 3.2 |  |  |  | 3.4 |  |
| Unrealized gains on derivative contracts |  |  | (0.7 | ) |  |  | (2.2 | ) |
| Stock-based compensation expense |  |  | 18.8 |  |  |  | 24.8 |  |
| Depreciation and amortization |  |  | 48.1 |  |  |  | 43.4 |  |
| Deferred income taxes |  |  | (3.9 | ) |  |  | (2.6 | ) |
| Pension expense |  |  | 4.1 |  |  |  | 4.7 |  |
| Pension contributions |  |  | (1.4 | ) |  |  | (52.5 | ) |
| Other items, net |  |  | 1.0 |  |  |  | 0.4 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (118.3 | ) |  |  | (146.2 | ) |
| Inventories |  |  | (102.6 | ) |  |  | (49.9 | ) |
| Other current assets |  |  | (7.3 | ) |  |  | (6.6 | ) |
| Accounts payable |  |  | 31.0 |  |  |  | 56.4 |  |
| Accrued expenses |  |  | 7.6 |  |  |  | 40.7 |  |
| Income taxes payable and receivable |  |  | (9.9 | ) |  |  | (15.0 | ) |
| Other |  |  | 3.5 |  |  |  | 3.0 |  |
| Net cash provided by operating activities |  |  | 129.0 |  |  |  | 126.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.2 |  |  |  | — |  |
| Purchases of property, plant and equipment |  |  | (60.5 | ) |  |  | (59.4 | ) |
| Net cash used in investing activities |  |  | (60.3 | ) |  |  | (59.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (1.4 | ) |  |  | (2.1 | ) |
| Asset securitization borrowings |  |  | 275.0 |  |  |  | 145.0 |  |
| Asset securitization payments |  |  | — |  |  |  | (20.0 | ) |
| Long-term debt payments |  |  | (200.8 | ) |  |  | (30.9 | ) |
| Borrowings from credit facility |  |  | 1,883.0 |  |  |  | 1,715.0 |  |
| Payments on credit facility |  |  | (1,701.0 | ) |  |  | (1,493.0 | ) |
| Payments of deferred financing costs |  |  | — |  |  |  | (0.9 | ) |
| Proceeds from employee stock purchases |  |  | 2.3 |  |  |  | 1.9 |  |
| Repurchases of common stock |  |  | (250.0 | ) |  |  | (300.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (16.0 | ) |  |  | (26.3 | ) |
| Cash dividends paid |  |  | (58.4 | ) |  |  | (50.5 | ) |
| Net cash used in financing activities |  |  | (67.3 | ) |  |  | (61.8 | ) |
| Increase in cash and cash equivalents |  |  | 1.4 |  |  |  | 5.7 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | 9.1 |  |  |  | 3.2 |  |
| Cash and cash equivalents, beginning of period |  |  | 50.2 |  |  |  | 38.9 |  |
| Cash and cash equivalents, end of period |  | $ | 60.7 |  |  | $ | 47.8 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 22.5 |  |  | $ | 17.0 |  |
| Income taxes paid (net of refunds) |  | $ | 115.5 |  |  | $ | 120.9 |  |

[0001193125-17-316060:8k_2_02:73]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-316060:8k_2_02:74]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-17-316060:8k_2_02:75]
(Unaudited, in millions, except per share and ratio data)

[0001193125-17-316060:8k_2_02:76]
Use of Non-GAAP Financial Measures

[0001193125-17-316060:8k_2_02:77]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with
the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the
Company’s business trends and operating performance.

[0001193125-17-316060:8k_2_02:78]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from
Continuing Operations, a Non-GAAP measure

[0001193125-17-316060:8k_2_02:79]
|  |  | For the Three Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 147.0 |  |  | $ | (43.0) |  |  | $ | 104.0 |  |  | $ | 149.9 |  |  | $ | (48.2) |  |  | $ | 101.7 |  |
| Restructuring charges |  |  | 1.9 |  |  |  | (0.8) |  |  |  | 1.1 |  |  |  | 0.6 |  |  |  | (0.2) |  |  |  | 0.4 |  |
| Special product quality adjustments (b) |  |  | 0.5 |  |  |  | (0.2) |  |  |  | 0.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Special legal contingency charges (a) |  |  | 1.5 |  |  |  | (0.2) |  |  |  | 1.3 |  |  |  | 0.5 |  |  |  | (0.2) |  |  |  | 0.3 |  |
| Asbestos-related litigation (a) |  |  | 1.5 |  |  |  | (0.5) |  |  |  | 1.0 |  |  |  | 0.4 |  |  |  | (0.1) |  |  |  | 0.3 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 0.2 |  |  |  | (0.1) |  |  |  | 0.1 |  |  |  | (1.2) |  |  |  | 0.5 |  |  |  | (0.7) |  |
| Environmental liabilities(a) |  |  | 0.5 |  |  |  | (0.1) |  |  |  | 0.4 |  |  |  | — |  |  |  | (0.1) |  |  |  | (0.1) |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (1.5) |  |  |  | (1.5) |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractor tax payments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other items, net (a) |  |  | 0.3 |  |  |  | (0.1) |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 153.4 |  |  | $ | (46.5) |  |  | $ | 106.9 |  |  | $ | 150.2 |  |  | $ | (48.3) |  |  | $ | 101.9 |  |
| Earnings per share from continuing operations—diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.45 |  |  |  |  |  |  |  |  |  |  | $ | 2.33 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Special legal contingency charges(a) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Asbestos-related litigation(a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.02) |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | (0.01) |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.03) |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.53 |  |  |  |  |  |  |  |  |  |  | $ | 2.33 |  |

[0001193125-17-316060:8k_2_02:80]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-17-316060:8k_2_02:81]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-17-316060:8k_2_02:82]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-17-316060:8k_2_02:83]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-17-316060:8k_2_02:84]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-17-316060:8k_2_02:85]
|  |  | For the Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 367.7 |  |  | $ | (103.8) |  |  | $ | 263.9 |  |  | $ | 341.9 |  |  | $ | (104.0) |  |  | $ | 237.9 |  |
| Restructuring charges |  |  | 2.1 |  |  |  | (0.8) |  |  |  | 1.3 |  |  |  | 1.2 |  |  |  | (0.4) |  |  |  | 0.8 |  |
| Special product quality adjustments (b) |  |  | 5.7 |  |  |  | (2.0) |  |  |  | 3.7 |  |  |  | (0.4) |  |  |  | 0.1 |  |  |  | (0.3) |  |
| Special legal contingency charges (a) |  |  | 3.6 |  |  |  | (0.4) |  |  |  | 3.2 |  |  |  | 0.5 |  |  |  | (0.2) |  |  |  | 0.3 |  |
| Asbestos-related litigation (a) |  |  | 3.9 |  |  |  | (1.3) |  |  |  | 2.6 |  |  |  | 2.3 |  |  |  | (0.8) |  |  |  | 1.5 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 1.0 |  |  |  | (0.4) |  |  |  | 0.6 |  |  |  | (1.9) |  |  |  | 0.7 |  |  |  | (1.2) |  |
| Environmental liabilities (a) |  |  | 1.2 |  |  |  | (0.3) |  |  |  | 0.9 |  |  |  | 1.1 |  |  |  | (0.3) |  |  |  | 0.8 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (9.6) |  |  |  | (9.6) |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractor tax payments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.5 |  |  |  | (0.1) |  |  |  | 0.4 |  |
| Other items (a) |  |  | 0.3 |  |  |  | (0.1) |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | (0.2) |  |  |  | 0.2 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 385.5 |  |  | $ | (118.7) |  |  | $ | 266.8 |  |  | $ | 345.6 |  |  | $ | (105.2) |  |  | $ | 240.4 |  |
| Earnings per share from continuing operations—diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 6.15 |  |  |  |  |  |  |  |  |  |  | $ | 5.39 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | 0.09 |  |  |  |  |  |  |  |  |  |  |  | (0.01) |  |
| Special legal contingency charges (a) |  |  |  |  |  |  |  |  |  |  | 0.07 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Asbestos-related litigation (a) |  |  |  |  |  |  |  |  |  |  | 0.06 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | (0.03) |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.22) |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 6.23 |  |  |  |  |  |  |  |  |  |  | $ | 5.44 |  |

[0001193125-17-316060:8k_2_02:86]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-17-316060:8k_2_02:87]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-17-316060:8k_2_02:88]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-17-316060:8k_2_02:89]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-17-316060:8k_2_02:90]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-17-316060:8k_2_02:91]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized (gains) losses on settled future contracts (a) |  | $ | (0.5 | ) |  | $ | 0.3 |  |  | $ | (1.3 | ) |  | $ | 1.2 |  |
| Foreign currency exchange (gains) losses (a) |  |  | (0.6 | ) |  |  | 0.5 |  |  |  | (0.3 | ) |  |  | 1.1 |  |
| Loss on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.3 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | 0.2 |  |  |  | (1.2 | ) |  |  | 1.0 |  |  |  | (1.9 | ) |
| Special legal contingency charges (b) |  |  | 1.5 |  |  |  | 0.5 |  |  |  | 3.6 |  |  |  | 0.5 |  |
| Asbestos-related litigation (b) |  |  | 1.5 |  |  |  | 0.4 |  |  |  | 3.9 |  |  |  | 2.3 |  |
| Environmental liabilities (b) |  |  | 0.5 |  |  |  | — |  |  |  | 1.2 |  |  |  | 1.1 |  |
| Contractor tax payments (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.5 |  |
| Acquisition costs (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.4 |  |
| Other items, net (b) |  |  | 0.3 |  |  |  | — |  |  |  | 0.3 |  |  |  | — |  |
| Losses and other expenses, net (pre-tax) |  | $ | 3.0 |  |  | $ | 0.7 |  |  | $ | 8.5 |  |  | $ | 5.5 |  |

[0001193125-17-316060:8k_2_02:92]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-17-316060:8k_2_02:93]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-17-316060:8k_2_02:94]
Reconciliation of Earnings per Share from Continuing Operations—Diluted, a GAAP measure, to Estimated
Adjusted Earnings per Share from Continuing Operations—Diluted, a Non-GAAP measure

[0001193125-17-316060:8k_2_02:95]
|  |  | For the YearEndedDecember 31,2017ESTIMATED |  |
| Earnings per share from continuing operations—diluted, a GAAP measure |  | $ | 7.67 - $7.97 |  |
| Special product quality adjustments and other items partially offset by excess tax benefits from share-based compensation |  |  | 0.08 |  |
| Adjusted Earnings per share from continuing operations—diluted, a Non-GAAP measure |  | $ | 7.75 - $8.05 |  |

[0001193125-17-316060:8k_2_02:96]
Reconciliation of Average Shares Outstanding—Diluted, a GAAP measure, to Adjusted Average Shares
Outstanding—Diluted, a Non-GAAP measure (shares in millions):

[0001193125-17-316060:8k_2_02:97]
|  |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Average shares outstanding—diluted, a GAAP measure |  |  | 42.4 |  |  |  | 43.7 |  |  |  | 42.9 |  |  |  | 44.2 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |
| Adjusted average shares outstanding—diluted, a Non-GAAP measure |  |  | 42.3 |  |  |  | 43.7 |  |  |  | 42.8 |  |  |  | 44.2 |  |

[0001193125-17-316060:8k_2_02:98]
Reconciliation of Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in
millions)

[0001193125-17-316060:8k_2_02:99]
|  |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 177.3 |  |  | $ | 152.2 |  |  | $ | 129.0 |  |  | $ | 126.9 |  |
| Purchases of property, plant and equipment |  |  | (17.1 | ) |  |  | (17.7 | ) |  |  | (60.5 | ) |  |  | (59.4 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Free cash flow, a Non-GAAP measure |  | $ | 160.2 |  |  | $ | 134.5 |  |  | $ | 68.7 |  |  | $ | 67.5 |  |

[0001193125-17-316060:8k_2_02:100]
|  |  | TrailingTwelveMonths toSeptember 30,2017 |  |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |
| Adjusted EBIT (a) |  | $ | 513.3 |  |
| Depreciation and amortization expense (b) |  |  | 61.8 |  |
| EBITDA (a + b) |  | $ | 575.1 |  |
| Total debt at September 30, 2017 (c) |  | $ | 1,124.1 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.0 |  |

[0001193125-17-316060:8k_2_02:101]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes,
a GAAP measure (dollars in millions)

[0001193125-17-316060:8k_2_02:102]
|  |  | TrailingTwelveMonths toSeptember 30,2017 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 513.3 |  |
| Special product quality adjustments |  |  | 5.7 |  |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 14.5 |  |
| Restructuring charges |  |  | 2.7 |  |
| Interest expense, net |  |  | 30.7 |  |
| Pension Settlement |  |  | 31.4 |  |
| Other expenses, net |  |  | (0.2 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 428.5 |  |
