# LII MD&A — 0001069202-17-000013


## mdna

[0001069202-17-000013:mdna:1]
[same as prior period, unchanged from 0001069202-17-000009:mdna:1]

[0001069202-17-000013:mdna:2]
[same as prior period, unchanged from 0001069202-17-000009:mdna:2]

[0001069202-17-000013:mdna:3]
[same as prior period, unchanged from 0001069202-17-000009:mdna:3]

[0001069202-17-000013:mdna:4]
[same as prior period, unchanged from 0001069202-17-000009:mdna:4]

[0001069202-17-000013:mdna:5]
[same as prior period, unchanged from 0001069202-17-000009:mdna:5]

[0001069202-17-000013:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated warranty costs, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of volatility in commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-17-000013:mdna:7]
[same as prior period, unchanged from 0001069202-17-000009:mdna:7]

[0001069202-17-000013:mdna:8]
In the third quarter of 2017, the Commercial Heating & Cooling segment led our overall operational performance with a 7% increase in net sales and a $1 million increase in segment profit compared to the third quarter of 2016.  The primary growth driver for this segment was volume gains.  Our Residential Heating & Cooling segment also grew sales in the third quarter of 2017 with a 3% increase in net sales and had $2 million in increased segment profit compared to the third quarter of 2016.  This segment's profits were up largely due to lower materials costs, higher volumes and favorable price.  Sales in our Refrigeration segment increased by 3% and segment profit was down $3 million compared to the third quarter of 2016 due primarily to higher commodity prices and lower factory productivity.

[0001069202-17-000013:mdna:9]
[same as prior period, unchanged from 0001069202-17-000009:mdna:9]

[0001069202-17-000013:mdna:10]
| • | Net sales increased $42 million, or 4%, to $1,052 million in the third quarter of 2017 compared to the third quarter of 2016. |

[0001069202-17-000013:mdna:11]
| • | Operating income in the third quarter of 2017 decreased $2 million to $155 million. |

[0001069202-17-000013:mdna:12]
| • | Net income for the third quarter of 2017 increased $2 million to $104 million, including the benefit of $1.5 million of discrete tax benefits in the third quarter of 2017 related to excess tax benefits from share-based compensation. |

[0001069202-17-000013:mdna:13]
| • | Diluted earnings per share from continuing operations were $2.45 per share in the third quarter of 2017 compared to $2.33 per share in the third quarter of 2016. |

[0001069202-17-000013:mdna:14]
| • | During the nine months ended September 30, 2017, we returned $58 million to shareholders through dividend payments and entered into agreements to repurchase $250 million of common stock that will be completed in the fourth quarter of 2017. |

[0001069202-17-000013:mdna:15]
Third Quarter of 2017 Compared to Third Quarter of 2016 - Consolidated Results

[0001069202-17-000013:mdna:16]
[same as prior period, unchanged from 0001069202-17-000009:mdna:16]

[0001069202-17-000013:mdna:17]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 1,052.3 |  |  | $ | 1,010.0 |  |  | 4.2 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 738.6 |  |  | 699.7 |  |  | (5.6 | ) |  | 70.2 |  |  | 69.3 |  |
| Gross profit | 313.7 |  |  | 310.3 |  |  | 1.1 |  |  | 29.8 |  |  | 30.7 |  |
| Selling, general and administrative expenses | 158.7 |  |  | 156.5 |  |  | (1.4 | ) |  | 15.1 |  |  | 15.5 |  |
| Losses and other expenses, net | 3.0 |  |  | 0.7 |  |  | (328.6 | ) |  | 0.3 |  |  | 0.1 |  |
| Restructuring charges | 1.9 |  |  | 0.6 |  |  | (216.7 | ) |  | 0.2 |  |  | 0.1 |  |
| Income from equity method investments | (4.5 | ) |  | (4.4 | ) |  | 2.3 |  |  | (0.4 | ) |  | (0.4 | ) |
| Operating income | $ | 154.6 |  |  | $ | 156.9 |  |  | (1.5 | )% |  | 14.7 | % |  | 15.5 | % |

[0001069202-17-000013:mdna:18]
[same as prior period, unchanged from 0001069202-17-000009:mdna:18]

[0001069202-17-000013:mdna:19]
Net sales increased 4% in the third quarter of 2017 compared to the third quarter of 2016, primarily from 3% higher sales volumes and 1% from favorable foreign currency exchange rates.  The Residential Heating & Cooling segment delivered higher volume from additional new construction business.  The Commercial Heating & Cooling segment delivered higher volume from our North American equipment business.

[0001069202-17-000013:mdna:20]
[same as prior period, unchanged from 0001069202-17-000009:mdna:20]

[0001069202-17-000013:mdna:21]
Gross profit margin in the third quarter of 2017 decreased to 29.8% compared to 30.7% in the third quarter of 2016.  We saw negative margin decreases of 120 basis points ("bps") from higher commodity prices, 50 bps from other product costs, 50 bps from combined freight and distribution and 10 bps from product warranties. Partially offsetting these decreases were increases of 10 bps from favorable mix and price, 120 bps from lower material costs and 10 bps from favorable foreign currency exchange rates.

[0001069202-17-000013:mdna:22]
[same as prior period, unchanged from 0001069202-17-000009:mdna:22]

[0001069202-17-000013:mdna:23]
Selling, general and administrative expenses, or SG&A, was $159 million in the third quarter of 2017 compared to $157 million in the third quarter of 2016, and as a percentage of net sales decreased 40 bps to 15.1%.  SG&A increased due to wage inflation, increased healthcare costs and increased investment in information technology and research and development partially offset by decreases in long-term incentive compensation.

[0001069202-17-000013:mdna:24]
[same as prior period, unchanged from 0001069202-17-000009:mdna:24]

[0001069202-17-000013:mdna:25]
Losses and other expenses, net for the third quarter of 2017 and 2016 included the following (in millions):

[0001069202-17-000013:mdna:26]
|  | For the Three Months Ended September 30, |
|  | 2017 |  | 2016 |
| Realized (gains) losses on settled future contracts | $ | (0.5 | ) |  | $ | 0.3 |  |
| Foreign currency exchange (gains) losses | (0.6 | ) |  | 0.5 |  |
| Loss on disposal of fixed assets | 0.1 |  |  | 0.2 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.2 |  |  | (1.2 | ) |
| Special legal contingency charges | 1.5 |  |  | 0.5 |  |
| Asbestos-related litigation | 1.5 |  |  | 0.4 |  |
| Environmental liabilities | 0.5 |  |  | — |  |
| Other items, net | 0.3 |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 3.0 |  |  | $ | 0.7 |  |

[0001069202-17-000013:mdna:27]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.

[0001069202-17-000013:mdna:28]
[same as prior period, unchanged from 0001069202-17-000009:mdna:28]

[0001069202-17-000013:mdna:29]
Restructuring charges were $2 million in the third quarter of 2017 compared to $1 million in 2016. The charges in 2017 and 2016 were primarily for projects to realign resources and enhance distribution capabilities.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000013:mdna:30]
[same as prior period, unchanged from 0001069202-17-000009:mdna:30]

[0001069202-17-000013:mdna:31]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $5 million in the third quarter of 2017 was relatively flat when compared to the third quarter of 2016.

[0001069202-17-000013:mdna:32]
[same as prior period, unchanged from 0001069202-17-000009:mdna:32]

[0001069202-17-000013:mdna:33]
Interest expense, net of $8 million in the third quarter of 2017 was up from $7 million as compared to the third quarter of 2016 due to an increase in our average net borrowings.

[0001069202-17-000013:mdna:34]
[same as prior period, unchanged from 0001069202-17-000009:mdna:34]

[0001069202-17-000013:mdna:35]
We expect our annual effective tax rate to be between 31% and 32%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09, in 2017 and subsequent years.

[0001069202-17-000013:mdna:36]
The effective tax rate was 29% for the three months ended September 30, 2017, after the impact of excess tax benefits, compared to 32% for the three months ended September 30, 2016, which excluded the impact of excess tax benefits.  The rate for the third quarter of 2017 is lower as compared to the third quarter of 2016 primarily due to the impact of foreign operations in low tax jurisdictions.

[0001069202-17-000013:mdna:37]
Third Quarter of 2017 Compared to Third Quarter of 2016 - Results by Segment

[0001069202-17-000013:mdna:38]
[same as prior period, unchanged from 0001069202-17-000009:mdna:38]

[0001069202-17-000013:mdna:39]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000013:mdna:40]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 590.5 |  |  | $ | 572.7 |  |  | $ | 17.8 |  |  | 3.1 | % |
| Profit | $ | 114.7 |  |  | $ | 112.7 |  |  | $ | 2.0 |  |  | 1.8 | % |
| % of net sales | 19.4 | % |  | 19.7 | % |  |  |  |  |

[0001069202-17-000013:mdna:41]
Net sales increased by 3% in the third quarter of 2017 compared to the third quarter of 2016.  Sales volume increased 3%, price increased 1%, and mix was unfavorable by 1%.

[0001069202-17-000013:mdna:42]
Segment profit in the third quarter of 2017 increased $2 million compared to the third quarter of 2016 due to $8 million from sourcing and engineering-led cost reductions, $3 million in higher sales volume, $3 million from price and mix combined, $3 million for favorable foreign currency exchange rates, $1 million from factory productivity which includes the addition of a second factory in Mexico, and $1 million from higher income from equity method investments.  Partially offsetting these increases was $8 million from higher commodity costs, $3 million from increases in warranty and other product costs, $3 million in distribution investments, and $3 million of SG&A expenses related to investments in research and development, information technology, and other SG&A.

[0001069202-17-000013:mdna:43]
[same as prior period, unchanged from 0001069202-17-000009:mdna:43]

[0001069202-17-000013:mdna:44]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000013:mdna:45]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 269.4 |  |  | $ | 251.4 |  |  | $ | 18.0 |  |  | 7.2 | % |
| Profit | $ | 50.0 |  |  | $ | 48.9 |  |  | $ | 1.1 |  |  | 2.2 | % |
| % of net sales | 18.6 | % |  | 19.5 | % |  |  |  |  |

[0001069202-17-000013:mdna:46]
Net sales increased by 7% in the third quarter of 2017 compared to the third quarter of 2016.  Sales volume increased 6% and favorable foreign currency exchange rates contributed 1% growth.

[0001069202-17-000013:mdna:47]
Segment profit in the third quarter of 2017 increased $1 million compared to the third quarter of 2016 primarily due to $4 million from higher sales volume, $2 million from sourcing and engineering-led cost reductions, $1 million from lower SG&A expenses, and $1 million from favorable foreign currency exchange rates.  Partially offsetting these increases was $3 million from increases in warranty and other product costs, $2 million of higher commodity costs, $1 million in lower factory productivity, and $1 million in distribution investments.

[0001069202-17-000013:mdna:48]
[same as prior period, unchanged from 0001069202-17-000009:mdna:48]

[0001069202-17-000013:mdna:49]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000013:mdna:50]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 192.4 |  |  | $ | 185.9 |  |  | $ | 6.5 |  |  | 3.5 | % |
| Profit | $ | 20.0 |  |  | $ | 22.9 |  |  | $ | (2.9 | ) |  | (12.7 | )% |
| % of net sales | 10.4 | % |  | 12.3 | % |  |  |  |  |

[0001069202-17-000013:mdna:51]
Net sales increased 3% in the third quarter of 2017 compared to the third quarter of 2016.   Sales volume increased 2% primarily from our European Commercial Refrigeration and Australian businesses, and favorable foreign currency exchange rates contributed 1% growth.

[0001069202-17-000013:mdna:52]
Segment profit for the third quarter of 2017 decreased $3 million compared to the third quarter of 2016. The decrease was driven by $2 million of lower factory productivity, $2 million in higher SG&A expenses, $2 million of unfavorable price and mix, $1 million in higher commodity costs, and $1 million in freight and distribution investments that were partially offset by higher sourcing and engineering-led cost reductions of $3 million, higher sales volumes of $1 million and decreases in other product costs of $1 million.

[0001069202-17-000013:mdna:53]
[same as prior period, unchanged from 0001069202-17-000009:mdna:53]

[0001069202-17-000013:mdna:54]
Corporate and other expenses decreased $4 million in the third quarter of 2017 compared to the third quarter of 2016 primarily due to lower incentive compensation, partially offset by higher health care expenses and information technology investments.

[0001069202-17-000013:mdna:55]
Year-to-Date through September 30, 2017 Compared to Year-to-Date through September 30, 2016 - Consolidated Results

[0001069202-17-000013:mdna:56]
[same as prior period, unchanged from 0001069202-17-000009:mdna:56]

[0001069202-17-000013:mdna:57]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 2,947.9 |  |  | $ | 2,744.4 |  |  | 7.4 |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 2,082.4 |  |  | 1,935.5 |  |  | (7.6 | ) |  | 70.6 |  |  | 70.5 |  |
| Gross profit | 865.5 |  |  | 808.9 |  |  | 7.0 |  |  | 29.4 |  |  | 29.5 |  |
| Selling, general and administrative expenses | 479.6 |  |  | 456.2 |  |  | (5.1 | ) |  | 16.3 |  |  | 16.6 |  |
| Losses and other expenses, net | 8.5 |  |  | 5.5 |  |  | (54.5 | ) |  | 0.3 |  |  | 0.2 |  |
| Restructuring charges | 2.1 |  |  | 1.2 |  |  | (75.0 | ) |  | 0.1 |  |  | — |  |
| Income from equity method investments | (15.5 | ) |  | (15.3 | ) |  | 1.3 |  |  | (0.5 | ) |  | (0.6 | ) |
| Operating income | $ | 390.8 |  |  | $ | 361.3 |  |  | 8.2 |  |  | 13.3 | % |  | 13.2 | % |

[0001069202-17-000013:mdna:58]
[same as prior period, unchanged from 0001069202-17-000009:mdna:58]

[0001069202-17-000013:mdna:59]
Net sales increased 7% in the first nine months of 2017 compared to the first nine months of 2016 due to a 7% increase in sales volumes.  The volume increases were driven by our Residential Heating & Cooling and Commercial Heating & Cooling and Refrigeration segments all capturing additional replacement and new construction business.

[0001069202-17-000013:mdna:60]
[same as prior period, unchanged from 0001069202-17-000009:mdna:60]

[0001069202-17-000013:mdna:61]
Gross profit margins in the first nine months of 2017 decreased 10 bps to 29.4% compared to the first nine months of 2016.  Our profit margin decreased 70 bps from higher commodity costs, 50 bps from freight and distribution, 20 bps from unfavorable factory productivity and 20 bps related to a product quality issue disclosed in Note 6 in the Notes to the Consolidated Financial Statements.  Offsetting these decreases were increases of 100 bps from material cost savings and 50 bps from favorable price and mix combined.

[0001069202-17-000013:mdna:62]
[same as prior period, unchanged from 0001069202-17-000009:mdna:62]

[0001069202-17-000013:mdna:63]
SG&A was $480 million for the first nine months of 2017 compared to $456 million for the first nine months of 2016, and as a percentage of net sales, decreased 30 bps to 16.3% from 16.6%. SG&A increased due to wage inflation, increased healthcare costs and increased investments in information technology and research and development partially offset by decreases in long-term incentive compensation.

[0001069202-17-000013:mdna:64]
[same as prior period, unchanged from 0001069202-17-000009:mdna:64]

[0001069202-17-000013:mdna:65]
Losses and other expenses, net for the first nine months of 2017 and 2016 included the following (in millions):

[0001069202-17-000013:mdna:66]
|  | For the Nine Months Ended September 30, |
|  | 2017 |  | 2016 |
| Realized (gains) losses on settled future contracts | $ | (1.3 | ) |  | $ | 1.2 |  |
| Foreign currency exchange (gains) losses | (0.3 | ) |  | 1.1 |  |
| Loss on disposal of fixed assets | 0.1 |  |  | 0.3 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 1.0 |  |  | (1.9 | ) |
| Special legal contingency charges | 3.6 |  |  | 0.5 |  |
| Asbestos-related litigation | 3.9 |  |  | 2.3 |  |
| Environmental liabilities | 1.2 |  |  | 1.1 |  |
| Contractor tax payments | — |  |  | 0.5 |  |
| Acquisition costs | — |  |  | 0.4 |  |
| Other items, net | 0.3 |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 8.5 |  |  | $ | 5.5 |  |

[0001069202-17-000013:mdna:67]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities. Contractor tax payments in the first nine months of 2016 relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.

[0001069202-17-000013:mdna:68]
[same as prior period, unchanged from 0001069202-17-000009:mdna:68]

[0001069202-17-000013:mdna:69]
Restructuring charges were $2 million in the first nine months of 2017 compared to $1 million in 2016. The charges in 2017 and 2016 were primarily for projects to realign resources and enhance distribution capabilities.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000013:mdna:70]
[same as prior period, unchanged from 0001069202-17-000009:mdna:70]

[0001069202-17-000013:mdna:71]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $16 million in the first nine months of 2017 was relatively flat when compared to the first nine months of 2016.

[0001069202-17-000013:mdna:72]
[same as prior period, unchanged from 0001069202-17-000009:mdna:72]

[0001069202-17-000013:mdna:73]
Interest expense, net of $23 million in the first nine months of 2017 increased from $20 million in the first nine months of 2016 due to an increase in our average net borrowings.

[0001069202-17-000013:mdna:74]
[same as prior period, unchanged from 0001069202-17-000009:mdna:74]

[0001069202-17-000013:mdna:75]
We expect our annual effective tax rate to be between 31% and 32%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09, in 2017 and subsequent years.

[0001069202-17-000013:mdna:76]
The effective tax rate was 28% for the nine months ended September 30, 2017, after the impact of excess tax benefits, compared to 30% for the nine months ended September 30, 2016, which excluded the impact of excess tax benefits.  The rate for the nine months ended September 30, 2017 is lower as compared to the nine months ended September 30, 2016 primarily due to the impact of foreign operations in low tax jurisdictions.

[0001069202-17-000013:mdna:77]
Year-to-Date through September 30, 2017 Compared to Year-to-Date through September 30, 2016 - Results by Segment

[0001069202-17-000013:mdna:78]
[same as prior period, unchanged from 0001069202-17-000009:mdna:78]

[0001069202-17-000013:mdna:79]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first nine months of 2017 and 2016 (dollars in millions):

[0001069202-17-000013:mdna:80]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 1,663.8 |  |  | $ | 1,524.5 |  |  | $ | 139.3 |  |  | 9.1 | % |
| Profit | $ | 297.6 |  |  | $ | 266.9 |  |  | $ | 30.7 |  |  | 11.5 | % |
| % of net sales | 17.9 | % |  | 17.5 | % |  |  |  |  |

[0001069202-17-000013:mdna:81]
Net sales increased by 9%  in the first nine months of 2017 compared to the first nine months of 2016.  Sales volume increased net sales by 8% due to industry growth and market share gains, and the benefits of favorable price and mix contributed 1%.

[0001069202-17-000013:mdna:82]
Segment profit for the first nine months of 2017 increased $31 million compared to the first nine months of 2016 due to $39 million in higher sales volume, $16 million from sourcing and engineering-led cost reductions, $10 million from favorable price and mix, $3 million from favorable foreign currency exchange rates, $1 million in higher factory productivity, $1 million from lower warranty costs and $1 million from higher income from equity method investments.  Partially offsetting these increases was $15 million in SG&A expenses to support investments in technology and research and development and incremental headcount and higher personnel costs, $14 million in higher commodity costs, $9 million in freight and distribution investments, and $2 million in higher other product related costs.

[0001069202-17-000013:mdna:83]
[same as prior period, unchanged from 0001069202-17-000009:mdna:83]

[0001069202-17-000013:mdna:84]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first nine months of 2017 and 2016 (dollars in millions):

[0001069202-17-000013:mdna:85]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 723.5 |  |  | $ | 674.7 |  |  | $ | 48.8 |  |  | 7.2 | % |
| Profit | $ | 113.8 |  |  | $ | 110.6 |  |  | $ | 3.2 |  |  | 2.9 | % |
| % of net sales | 15.7 | % |  | 16.4 | % |  |  |  |  |

[0001069202-17-000013:mdna:86]
Commercial Heating & Cooling net sales increased by 7% in the first nine months of 2017 compared to the first nine months of 2016. Sales volume increased 7% primarily due to increases in our North American businesses.

[0001069202-17-000013:mdna:87]
Segment profit in the first nine months of 2017 increased $3 million compared to the first nine months of 2016 due to $14 million from higher sales volume, $5 million from sourcing and engineering-led cost reductions, and $1 million from favorable foreign currency exchange rates.  Partially offsetting these increases was $4 million in higher SG&A expenses, $4 million from increases in other product costs, $3 million in higher commodity costs, $2 million from unfavorable sales mix, $2 million from lower factory productivity, and $2 million in freight and distribution investments.

[0001069202-17-000013:mdna:88]
[same as prior period, unchanged from 0001069202-17-000009:mdna:88]

[0001069202-17-000013:mdna:89]
The following table presents our Refrigeration segment's net sales and profit for the first nine months of 2017 and 2016 (dollars in millions):

[0001069202-17-000013:mdna:90]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 560.6 |  |  | $ | 545.2 |  |  | $ | 15.4 |  |  | 2.8 | % |
| Profit | $ | 55.7 |  |  | $ | 53.2 |  |  | $ | 2.5 |  |  | 4.7 | % |
| % of net sales | 9.9 | % |  | 9.8 | % |  |  |  |  |

[0001069202-17-000013:mdna:91]
Refrigeration net sales increased 3% in the first nine months of 2017 compared to the first nine months of 2016.   Sales volume increased net sales by 2% and favorable mix contributed 1%.

[0001069202-17-000013:mdna:92]
Segment profit for the first nine months of 2017 increased $2 million compared to the first nine months of 2016 due to $8 million from sourcing and engineering-led cost reductions, $4 million from favorable price and mix, $3 million from lower other product costs, $3 million from higher sales volume, and $1 million from favorable foreign currency exchange rates.  Partially offsetting these increases was $10 million in higher SG&A expenses, $4 million in lower factory productivity, $2 million in higher freight and distribution investments, and $1 million in higher commodity costs.

[0001069202-17-000013:mdna:93]
[same as prior period, unchanged from 0001069202-17-000009:mdna:93]

[0001069202-17-000013:mdna:94]
Corporate and other expenses decreased $7 million in the first nine months of 2017 compared to the first nine months of 2016 primarily due from lower incentive compensation with a partial offset from general wage inflation and information technology investments.

[0001069202-17-000013:mdna:95]
[same as prior period, unchanged from 0001069202-17-000009:mdna:95]

[0001069202-17-000013:mdna:96]
[same as prior period, unchanged from 0001069202-17-000009:mdna:96]

[0001069202-17-000013:mdna:97]
[same as prior period, unchanged from 0001069202-17-000009:mdna:97]

[0001069202-17-000013:mdna:98]
The following table summarizes our cash flow activity for the nine months ended September 30, 2017 and 2016 (in millions):

[0001069202-17-000013:mdna:99]
|  | For the Nine Months Ended September 30, |
|  | 2017 |  | 2016 |
| Net cash provided by operating activities | $ | 129.0 |  |  | $ | 126.9 |  |
| Net cash used in investing activities | (60.3 | ) |  | (59.4 | ) |
| Net cash used in financing activities | (67.3 | ) |  | (61.8 | ) |

[0001069202-17-000013:mdna:100]
Net Cash Provided by Operating Activities - The net cash provided by operating activities in the first nine months of 2017 and 2016 reflects the seasonal increase in working capital requirements and the increase in sales in 2017 as compared to 2016. The increase in net income in the first nine months of 2017 as compared to 2016 was offset by increases in working capital used to support higher sales.

[0001069202-17-000013:mdna:101]
Net Cash Used in Investing Activities - Capital expenditures were $61 million and $59 million in the first nine months of 2017 and 2016, respectively.  Capital expenditures in 2017 were primarily related to investments in systems and software to support the overall enterprise, expansion of our manufacturing capacity and equipment, and continued investments in our distribution network.

[0001069202-17-000013:mdna:102]
Net Cash Used in Financing Activities - Net cash used in financing activities increased in the first nine months of  2017 to $67 million as compared to $62 million in the first nine months of 2016.  Cash continues to be provided by an increase in net borrowings and we continue to make share repurchases and dividend payments.  During the third quarter of 2017 we settled the $100 million Accelerated Share Repurchase Transaction executed in the second quarter and initiated another $75 million Accelerated Share Repurchase Transaction to be settled in the fourth quarter.  For additional information on share repurchases, refer to Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000013:mdna:103]
[same as prior period, unchanged from 0001069202-17-000009:mdna:103]

[0001069202-17-000013:mdna:104]
The following table details our lines of credit and financing arrangements as of September 30, 2017 (in millions):

[0001069202-17-000013:mdna:105]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 1.0 |  |
| Asset Securitization Program (1) | 325.0 |  |
| Total short-term debt | $ | 326.0 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 0.5 |  |
| Domestic credit facility (2) | 22.5 |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 22.4 |  |
| Long-term debt: |  |
| Capital lease obligations | 14.7 |  |
| Domestic credit facility (2) | 415.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (4.5 | ) |
| Total long-term debt | 775.7 |  |
| Total debt | $ | 1,124.1 |  |

[0001069202-17-000013:mdna:106]
[same as prior period, unchanged from 0001069202-17-000009:mdna:106]

[0001069202-17-000013:mdna:107]
(2) The available future borrowings on our domestic credit facility are $429.0 million after being reduced by the outstanding borrowings and $3.0 million in outstanding standby letters of credit.  We also had $34.7 million in outstanding standby letters of credit outside of the domestic credit facility as of September 30, 2017.

[0001069202-17-000013:mdna:108]
[same as prior period, unchanged from 0001069202-17-000009:mdna:108]

[0001069202-17-000013:mdna:109]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 97.2% at September 30, 2017 from 95.8% at December 31, 2016.

[0001069202-17-000013:mdna:110]
As of September 30, 2017, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-17-000013:mdna:111]
[same as prior period, unchanged from 0001069202-17-000009:mdna:111]

[0001069202-17-000013:mdna:112]
We believe our cash and cash equivalents of $61 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, potential dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $61 million as of September 30, 2017 was $37.1 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States. If we were to repatriate foreign earnings, we would be required to accrue and pay taxes in the United States, less foreign tax credits, for the amounts that were repatriated.

[0001069202-17-000013:mdna:113]
Our expected capital expenditures for 2017 are $100 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with the completion of a $250 million stock repurchase program and the declaration of $58 million of cash dividends in the first nine months of 2017.

[0001069202-17-000013:mdna:114]
[same as prior period, unchanged from 0001069202-17-000009:mdna:114]

[0001069202-17-000013:mdna:115]
[same as prior period, unchanged from 0001069202-17-000009:mdna:115]

[0001069202-17-000013:mdna:116]
Commitments, Contingencies and Guarantees

[0001069202-17-000013:mdna:117]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000013:mdna:118]
[same as prior period, unchanged from 0001069202-17-000009:mdna:118]

[0001069202-17-000013:mdna:119]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. We have substantially completed our evaluation of the effect that ASU 2014-09 will have on our Consolidated Financial Statements and related disclosures. We do not expect the ASU to have a material impact on the amount and timing of revenue recognition, but it will require us to enhance our disclosures to provide additional information relating to disaggregated revenue, contract assets and liabilities, and remaining performance obligations.  We are currently in the process of preparing these additional disclosures, including updating our internal controls related to the additional data and disclosures to be provided upon adoption of the new standard.  We will adopt the new standard using the modified retrospective approach.

[0001069202-17-000013:mdna:120]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.  As a result of the new standard, all of our leases greater than one year in duration will be recognized on our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.

[0001069202-17-000013:mdna:121]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees.  For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017.  This standard is not expected to have a material impact on our consolidated financial statements.

[0001069202-17-000013:mdna:122]
On October 24, 2016, the FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory. The new ASU eliminates the existing exception from recognition of the tax consequences of intercompany sales of assets other than inventory.  Under the new standard, when an asset (other than inventory) is sold from one consolidated entity to another, the tax consequences to the seller will be recognized currently as a component of the current tax provision.  The new guidance will be effective for public business entities in fiscal years beginning after December 15, 2017, including interim periods within those years.  In accordance with the ASU, our previously deferred tax costs and unrecognized deferred tax assets related to intra-entity asset transfers will need to be recognized at the date of transition through a cumulative effect adjustment to opening retained earnings upon adoption of the standard.

[0001069202-17-000013:mdna:123]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other Income, net. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We do not expect the ASU to have a material impact on our financial results.
