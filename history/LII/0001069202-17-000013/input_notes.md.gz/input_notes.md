# LII notes — 0001069202-17-000013


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-17-000013:notes:1]
[same as prior period, unchanged from 0001069202-17-000009:notes:1]

[0001069202-17-000013:notes:2]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 325.0 |  |  | $ | 250.0 |  |
| Less: Beneficial interest sold | 325.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-17-000013:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-17-000013:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-17-000013:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-17-000013:notes:6]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.47 | % |  | 2.00 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-17-000013:notes:7]
[same as prior period, unchanged from 0001069202-17-000009:notes:7]

[0001069202-17-000013:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2017, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-17-000013:notes:9]
[same as prior period, unchanged from 0001069202-17-000009:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-17-000013:notes:10]
Commitments and Contingencies:

[0001069202-17-000013:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-17-000013:notes:12]
We offer warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-17-000013:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000013:notes:14]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 34.9 |  |  | $ | 30.0 |  |
| Other liabilities | 72.7 |  |  | 71.1 |  |
| Total warranty liability | $ | 107.6 |  |  | $ | 101.1 |  |

[0001069202-17-000013:notes:15]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2017 were as follows (in millions):

[0001069202-17-000013:notes:16]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (21.6 | ) |
| Changes resulting from issuance of new warranties | 32.2 |  |
| Changes in estimates associated with pre-existing liabilities | (4.7 | ) |
| Changes in foreign currency translation rates and other | 0.6 |  |
| Total warranty liability as of September 30, 2017 | $ | 107.6 |  |

[0001069202-17-000013:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.

[0001069202-17-000013:notes:18]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect has been isolated, the vendor is supplying corrected components, and we are manufacturing product with the corrected components.  We have also implemented a program for our dealers to install corrected components in the field. We recorded an expense of $0.5 million and $5.7 million for the three and nine months ended September 30, 2017, respectively, relating to estimated repair costs. The expense related to this product quality issue has been classified in Cost of goods sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses on the Consolidated Balance Sheet.

[0001069202-17-000013:notes:19]
Litigation

[0001069202-17-000013:notes:20]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-17-000013:notes:21]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2017 and 2016, expense for asbestos-related litigation was $3.9 million and $2.3 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.  For the three months ended  September 30, 2017 and 2016, expense for asbestos-related litigation was $1.5 million and $0.4 million, respectively, net of probable insurance recoveries.

[0001069202-17-000013:notes:22]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.

[0001069202-17-000013:notes:23]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-17-000013:notes:24]
[same as prior period, unchanged from 0001069202-17-000009:notes:24]

[0001069202-17-000013:notes:25]
[same as prior period, unchanged from 0001069202-17-000009:notes:25]

[0001069202-17-000013:notes:26]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 3.5 |  |  | $ | (2.4 | ) |  | $ | 9.4 |  |  | $ | (10.6 | ) |  | Cost of goods sold |
| Income tax (expense)/benefit |  | (1.3 | ) |  | 0.8 |  |  | (3.4 | ) |  | 3.7 |  |  | Provision for income taxes |
| Net of tax |  | $ | 2.2 |  |  | $ | (1.6 | ) |  | $ | 6.0 |  |  | $ | (6.9 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.8 | ) |  | $ | (1.6 | ) |  | $ | (5.5 | ) |  | $ | (4.8 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.7 |  |  | 0.6 |  |  | 2.0 |  |  | 1.7 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.1 | ) |  | $ | (1.0 | ) |  | $ | (3.5 | ) |  | $ | (3.1 | ) |  |  |
| Total reclassifications from AOCL |  | $ | 1.1 |  |  | $ | (2.6 | ) |  | $ | 2.5 |  |  | $ | (10.0 | ) |  |  |

[0001069202-17-000013:notes:27]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2017 (in millions):

[0001069202-17-000013:notes:28]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2016 |  | $ | 5.6 |  |  | $ | 2.3 |  |  | $ | (130.0 | ) |  | $ | (73.0 | ) |  | $ | (195.1 | ) |
| Other comprehensive income (loss) before reclassifications |  | 6.7 |  |  | 0.2 |  |  | (5.7 | ) |  | 39.4 |  |  | 40.6 |  |
| Amounts reclassified from AOCL |  | (6.0 | ) |  | — |  |  | 3.5 |  |  | — |  |  | (2.5 | ) |
| Net other comprehensive income (loss) |  | 0.7 |  |  | 0.2 |  |  | (2.2 | ) |  | 39.4 |  |  | 38.1 |  |
| Balance as of September 30, 2017 |  | $ | 6.3 |  |  | $ | 2.5 |  |  | $ | (132.2 | ) |  | $ | (33.6 | ) |  | $ | (157.0 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-17-000013:notes:29]
[same as prior period, unchanged from 0001069202-17-000009:notes:29]

[0001069202-17-000013:notes:30]
[same as prior period, unchanged from 0001069202-17-000009:notes:30]

[0001069202-17-000013:notes:31]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of September 30, 2017 and December 31, 2016 and for the three and nine months ended September 30, 2017 and 2016 are shown on the following pages.

[0001069202-17-000013:notes:32]
[same as prior period, unchanged from 0001069202-17-000009:notes:32]

[0001069202-17-000013:notes:33]
[same as prior period, unchanged from 0001069202-17-000009:notes:33]

[0001069202-17-000013:notes:34]
As of September 30, 2017

[0001069202-17-000013:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 22.4 |  |  | $ | 37.1 |  |  | $ | — |  |  | $ | 60.7 |  |
| Accounts and notes receivable, net | — |  |  | 35.5 |  |  | 562.6 |  |  | — |  |  | 598.1 |  |
| Inventories, net | — |  |  | 392.2 |  |  | 143.5 |  |  | (4.8 | ) |  | 530.9 |  |
| Other assets | 14.2 |  |  | 34.3 |  |  | 60.7 |  |  | (28.3 | ) |  | 80.9 |  |
| Total current assets | 15.4 |  |  | 484.4 |  |  | 803.9 |  |  | (33.1 | ) |  | 1,270.6 |  |
| Property, plant and equipment, net | — |  |  | 243.7 |  |  | 135.2 |  |  | (4.3 | ) |  | 374.6 |  |
| Goodwill | — |  |  | 117.8 |  |  | 65.7 |  |  | 17.1 |  |  | 200.6 |  |
| Investment in subsidiaries | 1,212.8 |  |  | 383.7 |  |  | — |  |  | (1,596.5 | ) |  | — |  |
| Deferred income taxes | 11.0 |  |  | 112.0 |  |  | 32.5 |  |  | (12.2 | ) |  | 143.3 |  |
| Other assets, net | 1.8 |  |  | 42.1 |  |  | 24.1 |  |  | (1.4 | ) |  | 66.6 |  |
| Intercompany (payables) receivables, net | (453.9 | ) |  | 461.3 |  |  | 95.1 |  |  | (102.5 | ) |  | — |  |
| Total assets | $ | 787.1 |  |  | $ | 1,845.0 |  |  | $ | 1,156.5 |  |  | $ | (1,732.9 | ) |  | $ | 2,055.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 326.0 |  |  | $ | — |  |  | $ | 326.0 |  |
| Current maturities of long-term debt | 21.9 |  |  | 0.3 |  |  | 0.2 |  |  | — |  |  | 22.4 |  |
| Accounts payable | 21.3 |  |  | 252.7 |  |  | 120.5 |  |  | — |  |  | 394.5 |  |
| Accrued expenses | 5.7 |  |  | 216.6 |  |  | 56.1 |  |  | — |  |  | 278.4 |  |
| Income taxes (receivable) payable | (55.7 | ) |  | 60.4 |  |  | 48.5 |  |  | (50.8 | ) |  | 2.4 |  |
| Total current liabilities | (6.8 | ) |  | 530.0 |  |  | 551.3 |  |  | (50.8 | ) |  | 1,023.7 |  |
| Long-term debt | 761.1 |  |  | 14.3 |  |  | 0.3 |  |  | — |  |  | 775.7 |  |
| Post-retirement benefits, other than pensions | — |  |  | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Pensions | — |  |  | 77.1 |  |  | 13.1 |  |  | — |  |  | 90.2 |  |
| Other liabilities | 0.3 |  |  | 119.9 |  |  | 11.5 |  |  | — |  |  | 131.7 |  |
| Total liabilities | 754.6 |  |  | 743.2 |  |  | 576.2 |  |  | (50.8 | ) |  | 2,023.2 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 32.5 |  |  | 1,101.8 |  |  | 580.3 |  |  | (1,682.1 | ) |  | 32.5 |  |
| Total liabilities and stockholders' equity | $ | 787.1 |  |  | $ | 1,845.0 |  |  | $ | 1,156.5 |  |  | $ | (1,732.9 | ) |  | $ | 2,055.7 |  |

[0001069202-17-000013:notes:36]
[same as prior period, unchanged from 0001069202-17-000009:notes:36]

[0001069202-17-000013:notes:37]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 17.1 |  |  | $ | 31.9 |  |  | $ | — |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net | — |  |  | 30.6 |  |  | 439.2 |  |  | — |  |  | 469.8 |  |
| Inventories, net | — |  |  | 314.7 |  |  | 108.9 |  |  | (5.1 | ) |  | 418.5 |  |
| Other assets | 12.8 |  |  | 48.8 |  |  | 67.5 |  |  | (61.7 | ) |  | 67.4 |  |
| Total current assets | 14.0 |  |  | 411.2 |  |  | 647.5 |  |  | (66.8 | ) |  | 1,005.9 |  |
| Property, plant and equipment, net | — |  |  | 237.6 |  |  | 123.8 |  |  | — |  |  | 361.4 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 1,166.9 |  |  | 524.7 |  |  | (0.5 | ) |  | (1,691.1 | ) |  | — |  |
| Deferred income taxes | 6.8 |  |  | 113.5 |  |  | 31.1 |  |  | (14.7 | ) |  | 136.7 |  |
| Other assets, net | 3.6 |  |  | 40.0 |  |  | 19.0 |  |  | (1.4 | ) |  | 61.2 |  |
| Intercompany (payables) receivables, net | (382.4 | ) |  | 375.2 |  |  | 80.4 |  |  | (73.2 | ) |  | — |  |
| Total assets | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | — |  |  | $ | 52.4 |  |
| Current maturities of long-term debt | 199.3 |  |  | 0.4 |  |  | 0.4 |  |  | — |  |  | 200.1 |  |
| Accounts payable | 18.5 |  |  | 248.5 |  |  | 94.2 |  |  | — |  |  | 361.2 |  |
| Accrued expenses | 6.3 |  |  | 206.3 |  |  | 53.3 |  |  | — |  |  | 265.9 |  |
| Income taxes (receivable) payable | (54.0 | ) |  | 89.8 |  |  | 52.5 |  |  | (79.3 | ) |  | 9.0 |  |
| Total current liabilities | 170.1 |  |  | 545.0 |  |  | 252.8 |  |  | (79.3 | ) |  | 888.6 |  |
| Long-term debt | 600.9 |  |  | 14.5 |  |  | 0.3 |  |  | — |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.8 |  |  | — |  |  | — |  |  | 2.8 |  |
| Pensions | — |  |  | 75.5 |  |  | 12.0 |  |  | — |  |  | 87.5 |  |
| Other liabilities | — |  |  | 119.1 |  |  | 11.1 |  |  | (2.5 | ) |  | 127.7 |  |
| Total liabilities | 771.0 |  |  | 756.9 |  |  | 276.2 |  |  | (81.8 | ) |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 37.9 |  |  | 1,080.2 |  |  | 685.3 |  |  | (1,765.4 | ) |  | 38.0 |  |
| Total liabilities and stockholders' equity | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |

[0001069202-17-000013:notes:38]
[same as prior period, unchanged from 0001069202-17-000009:notes:38]

[0001069202-17-000013:notes:39]
For the Three Months Ended September 30, 2017

[0001069202-17-000013:notes:40]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 905.6 |  |  | $ | 300.0 |  |  | $ | (153.3 | ) |  | $ | 1,052.3 |  |
| Cost of goods sold | — |  |  | 644.8 |  |  | 249.0 |  |  | (155.2 | ) |  | 738.6 |  |
| Gross profit | — |  |  | 260.8 |  |  | 51.0 |  |  | 1.9 |  |  | 313.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 140.7 |  |  | 18.8 |  |  | (0.8 | ) |  | 158.7 |  |
| Losses and other expenses, net | 0.2 |  |  | 1.9 |  |  | 0.9 |  |  | — |  |  | 3.0 |  |
| Restructuring charges | — |  |  | 1.2 |  |  | 0.7 |  |  | — |  |  | 1.9 |  |
| Income from equity method investments | (108.2 | ) |  | (21.7 | ) |  | (3.5 | ) |  | 128.9 |  |  | (4.5 | ) |
| Operating income | 108.0 |  |  | 138.7 |  |  | 34.1 |  |  | (126.2 | ) |  | 154.6 |  |
| Interest expense, net | 6.2 |  |  | (0.6 | ) |  | 2.0 |  |  | — |  |  | 7.6 |  |
| Other expense, net | — |  |  | — |  |  | 0.2 |  |  | (0.2 | ) |  | — |  |
| Income from continuing operations before income taxes | 101.8 |  |  | 139.3 |  |  | 31.9 |  |  | (126.0 | ) |  | 147.0 |  |
| Provision for income tax (benefit) expense | (1.7 | ) |  | 30.5 |  |  | 13.5 |  |  | 0.7 |  |  | 43.0 |  |
| Income from continuing operations | 103.5 |  |  | 108.8 |  |  | 18.4 |  |  | (126.7 | ) |  | 104.0 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Net income | $ | 103.5 |  |  | $ | 108.8 |  |  | $ | 17.9 |  |  | $ | (126.7 | ) |  | $ | 103.5 |  |
| Other comprehensive income, net of tax | 0.4 |  |  | 2.1 |  |  | 6.9 |  |  | — |  |  | 9.4 |  |
| Comprehensive income (loss) | $ | 103.9 |  |  | $ | 110.9 |  |  | $ | 24.8 |  |  | $ | (126.7 | ) |  | $ | 112.9 |  |

[0001069202-17-000013:notes:41]
For the Nine Months Ended September 30, 2017

[0001069202-17-000013:notes:42]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,560.6 |  |  | $ | 869.7 |  |  | $ | (482.4 | ) |  | $ | 2,947.9 |  |
| Cost of goods sold | — |  |  | 1,830.8 |  |  | 731.1 |  |  | (479.5 | ) |  | 2,082.4 |  |
| Gross profit | — |  |  | 729.8 |  |  | 138.6 |  |  | (2.9 | ) |  | 865.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 419.2 |  |  | 61.6 |  |  | (1.2 | ) |  | 479.6 |  |
| Losses (gains) and other expenses, net | 1.1 |  |  | 5.8 |  |  | 1.7 |  |  | (0.1 | ) |  | 8.5 |  |
| Restructuring charges | — |  |  | 1.3 |  |  | 0.8 |  |  | — |  |  | 2.1 |  |
| Income from equity method investments | (277.5 | ) |  | (52.0 | ) |  | (12.7 | ) |  | 326.7 |  |  | (15.5 | ) |
| Operating income | 276.4 |  |  | 355.5 |  |  | 87.2 |  |  | (328.3 | ) |  | 390.8 |  |
| Interest expense, net | 20.9 |  |  | (2.3 | ) |  | 4.7 |  |  | — |  |  | 23.3 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | (0.2 | ) |  | (0.2 | ) |
| Income from continuing operations before income taxes | 255.5 |  |  | 357.8 |  |  | 82.5 |  |  | (328.1 | ) |  | 367.7 |  |
| Provision for income tax (benefit) expense | (7.0 | ) |  | 84.8 |  |  | 26.2 |  |  | (0.2 | ) |  | 103.8 |  |
| Income from continuing operations | 262.5 |  |  | 273.0 |  |  | 56.3 |  |  | (327.9 | ) |  | 263.9 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (1.4 | ) |  | — |  |  | (1.4 | ) |
| Net income | $ | 262.5 |  |  | $ | 273.0 |  |  | $ | 54.9 |  |  | $ | (327.9 | ) |  | $ | 262.5 |  |
| Other comprehensive income, net of tax | $ | 0.5 |  |  | $ | 9.7 |  |  | $ | 27.9 |  |  | $ | — |  |  | $ | 38.1 |  |
| Comprehensive income (loss) | $ | 263.0 |  |  | $ | 282.7 |  |  | $ | 82.8 |  |  | $ | (327.9 | ) |  | $ | 300.6 |  |

[0001069202-17-000013:notes:43]
For the Three Months Ended September 30, 2016

[0001069202-17-000013:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 870.5 |  |  | $ | 186.9 |  |  | $ | (47.4 | ) |  | $ | 1,010.0 |  |
| Cost of goods sold | — |  |  | 603.4 |  |  | 143.7 |  |  | (47.4 | ) |  | 699.7 |  |
| Gross profit | — |  |  | 267.1 |  |  | 43.2 |  |  | — |  |  | 310.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 135.9 |  |  | 20.6 |  |  | — |  |  | 156.5 |  |
| (Gains) losses and other expenses, net | (1.1 | ) |  | 1.1 |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Restructuring charges | — |  |  | 0.5 |  |  | 0.1 |  |  | — |  |  | 0.6 |  |
| Income from equity method investments | (105.0 | ) |  | (10.0 | ) |  | (3.2 | ) |  | 113.8 |  |  | (4.4 | ) |
| Operating income | 106.1 |  |  | 139.6 |  |  | 25.0 |  |  | (113.8 | ) |  | 156.9 |  |
| Interest expense, net | 6.1 |  |  | (0.5 | ) |  | 1.4 |  |  | — |  |  | 7.0 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 100.0 |  |  | 140.1 |  |  | 23.6 |  |  | (113.8 | ) |  | 149.9 |  |
| Provision for income tax (benefit) expense | (1.7 | ) |  | 42.3 |  |  | 7.6 |  |  | — |  |  | 48.2 |  |
| Income from continuing operations | 101.7 |  |  | 97.8 |  |  | 16.0 |  |  | (113.8 | ) |  | 101.7 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 101.7 |  |  | $ | 97.8 |  |  | $ | 16.0 |  |  | $ | (113.8 | ) |  | $ | 101.7 |  |
| Other comprehensive income (loss), net of tax | 2.7 |  |  | (0.4 | ) |  | (2.3 | ) |  | (0.4 | ) |  | (0.4 | ) |
| Comprehensive income (loss) | $ | 104.4 |  |  | $ | 97.4 |  |  | $ | 13.7 |  |  | $ | (114.2 | ) |  | $ | 101.3 |  |

[0001069202-17-000013:notes:45]
For the Nine Months Ended September 30, 2016

[0001069202-17-000013:notes:46]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,368.8 |  |  | $ | 514.1 |  |  | $ | (138.5 | ) |  | $ | 2,744.4 |  |
| Cost of goods sold | — |  |  | 1,675.6 |  |  | 396.3 |  |  | (136.4 | ) |  | 1,935.5 |  |
| Gross profit | — |  |  | 693.2 |  |  | 117.8 |  |  | (2.1 | ) |  | 808.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 394.6 |  |  | 61.6 |  |  | — |  |  | 456.2 |  |
| (Gains) losses and other expenses, net | (1.7 | ) |  | 4.3 |  |  | 3.0 |  |  | (0.1 | ) |  | 5.5 |  |
| Restructuring charges (gains) | — |  |  | 1.5 |  |  | (0.3 | ) |  | — |  |  | 1.2 |  |
| Income from equity method investments | (248.5 | ) |  | (19.5 | ) |  | (12.4 | ) |  | 265.1 |  |  | (15.3 | ) |
| Operating income | 250.2 |  |  | 312.3 |  |  | 65.9 |  |  | (267.1 | ) |  | 361.3 |  |
| Interest expense, net | 17.7 |  |  | (1.5 | ) |  | 3.4 |  |  | — |  |  | 19.6 |  |
| Other expense, net | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Income from continuing operations before income taxes | 232.5 |  |  | 313.8 |  |  | 62.7 |  |  | (267.1 | ) |  | 341.9 |  |
| Provision for income tax (benefit) expense | (4.9 | ) |  | 89.1 |  |  | 20.5 |  |  | (0.7 | ) |  | 104.0 |  |
| Income from continuing operations | 237.4 |  |  | 224.7 |  |  | 42.2 |  |  | (266.4 | ) |  | 237.9 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | 0.6 |  |  | — |  |  | 0.6 |  |
| Net income | $ | 237.4 |  |  | $ | 224.7 |  |  | $ | 41.6 |  |  | $ | (266.4 | ) |  | $ | 237.3 |  |
| Other comprehensive income, net of tax | 7.7 |  |  | 2.0 |  |  | 6.7 |  |  | 1.3 |  |  | 17.7 |  |
| Comprehensive income (loss) | $ | 245.1 |  |  | $ | 226.7 |  |  | $ | 48.3 |  |  | $ | (265.1 | ) |  | $ | 255.0 |  |

[0001069202-17-000013:notes:47]
[same as prior period, unchanged from 0001069202-17-000009:notes:47]

[0001069202-17-000013:notes:48]
For the Nine Months Ended September 30, 2017

[0001069202-17-000013:notes:49]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 411.6 |  |  | $ | (2.4 | ) |  | $ | (279.6 | ) |  | $ | (0.6 | ) |  | $ | 129.0 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (48.3 | ) |  | (12.2 | ) |  | — |  |  | (60.5 | ) |
| Net cash used in investing activities | — |  |  | (48.2 | ) |  | (12.2 | ) |  | 0.1 |  |  | (60.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.4 | ) |  | — |  |  | (1.4 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 275.0 |  |  | — |  |  | 275.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | (200.0 | ) |  | (0.2 | ) |  | (0.1 | ) |  | (0.5 | ) |  | (200.8 | ) |
| Long-term borrowings | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Borrowings from credit facility | 1,883.0 |  |  | (0.2 | ) |  | (0.2 | ) |  | 0.4 |  |  | 1,883.0 |  |
| Payments on credit facility | (1,701.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,701.0 | ) |
| Proceeds from employee stock purchases | 2.3 |  |  | — |  |  | — |  |  | — |  |  | 2.3 |  |
| Repurchases of common stock | (250.0 | ) |  | — |  |  | — |  |  | — |  |  | (250.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (16.0 | ) |  | — |  |  | — |  |  | — |  |  | (16.0 | ) |
| Intercompany debt | 102.8 |  |  | (34.8 | ) |  | (68.0 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (174.3 | ) |  | 91.0 |  |  | 82.7 |  |  | 0.6 |  |  | — |  |
| Cash dividends paid | (58.4 | ) |  | — |  |  | — |  |  | — |  |  | (58.4 | ) |
| Net cash (used in) provided by financing activities | (411.6 | ) |  | 55.9 |  |  | 287.9 |  |  | 0.5 |  |  | (67.3 | ) |
| Increase (decrease) in cash and cash equivalents | — |  |  | 5.3 |  |  | (3.9 | ) |  | — |  |  | 1.4 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 9.1 |  |  | — |  |  | 9.1 |  |
| Cash and cash equivalents, beginning of period | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of period | $ | 1.2 |  |  | $ | 22.4 |  |  | $ | 37.1 |  |  | $ | — |  |  | $ | 60.7 |  |

[0001069202-17-000013:notes:50]
For the Nine Months Ended September 30, 2016

[0001069202-17-000013:notes:51]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 15.5 |  |  | $ | 262.2 |  |  | $ | (150.8 | ) |  | $ | — |  |  | $ | 126.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (52.4 | ) |  | (7.0 | ) |  | — |  |  | (59.4 | ) |
| Net cash used in investing activities | — |  |  | (52.4 | ) |  | (7.0 | ) |  | — |  |  | (59.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (2.1 | ) |  | — |  |  | (2.1 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 145.0 |  |  | — |  |  | 145.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (20.0 | ) |  | — |  |  | (20.0 | ) |
| Long-term debt payments | (30.0 | ) |  | (0.6 | ) |  | (0.3 | ) |  | — |  |  | (30.9 | ) |
| Borrowings from credit facility | 1,715.0 |  |  | — |  |  | — |  |  | — |  |  | 1,715.0 |  |
| Payments on credit facility | (1,493.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,493.0 | ) |
| Proceeds from employee stock purchases | 1.9 |  |  | — |  |  | — |  |  | — |  |  | 1.9 |  |
| Payments of deferred financing costs | (0.9 | ) |  | — |  |  | — |  |  | — |  |  | (0.9 | ) |
| Repurchases of common stock | (300.0 | ) |  | — |  |  | — |  |  | — |  |  | (300.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (26.3 | ) |  | — |  |  | — |  |  | — |  |  | (26.3 | ) |
| Intercompany debt | (6.6 | ) |  | (5.1 | ) |  | 11.7 |  |  | — |  |  | — |  |
| Intercompany financing activity | 178.9 |  |  | (196.0 | ) |  | 17.1 |  |  | — |  |  | — |  |
| Intercompany investments | — |  | — |  | — |  |  | — |  |  | — |  |  | — |  |
| Cash dividends paid | (50.5 | ) |  | — |  |  | — |  |  | — |  |  | (50.5 | ) |
| Net cash (used in) provided by financing activities | (11.5 | ) |  | (201.7 | ) |  | 151.4 |  |  | — |  |  | (61.8 | ) |
| Increase (decrease) in cash and cash equivalents | 4.0 |  |  | 8.1 |  |  | (6.4 | ) |  | — |  |  | 5.7 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 3.2 |  |  | — |  |  | 3.2 |  |
| Cash and cash equivalents, beginning of period | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of period | $ | 4.5 |  |  | $ | 15.9 |  |  | $ | 27.4 |  |  | $ | — |  |  | $ | 47.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-17-000013:notes:52]
Lines of Credit and Financing Arrangements:

[0001069202-17-000013:notes:53]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000013:notes:54]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 325.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.0 |  |  | 2.4 |  |
| Total short-term debt | $ | 326.0 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 0.8 |  |
| Domestic credit facility | 22.5 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 22.4 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.7 |  |  | $ | 15.0 |  |
| Domestic credit facility | 415.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.5 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 775.7 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,124.1 |  |  | $ | 868.2 |  |

[0001069202-17-000013:notes:55]
Short-Term Debt

[0001069202-17-000013:notes:56]
Foreign Obligations

[0001069202-17-000013:notes:57]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.0 million and $2.4 million of foreign obligations outstanding as of September 30, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $19.1 million  and $28.2 million during the nine months ended September 30, 2017 and 2016, respectively. Repayments on the facilities were $20.5 million and $30.3 million during the nine months ended September 30, 2017 and 2016, respectively.

[0001069202-17-000013:notes:58]
Asset Securitization Program

[0001069202-17-000013:notes:59]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-17-000013:notes:60]
The ASP provides for a maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-17-000013:notes:61]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The rates as of September 30, 2017 and December 31, 2016 were 1.99% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-17-000013:notes:62]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2017, we believe we were in compliance with all covenant requirements.

[0001069202-17-000013:notes:63]
Long-Term Debt

[0001069202-17-000013:notes:64]
Domestic Credit Facility

[0001069202-17-000013:notes:65]
On August 30, 2016, we replaced an earlier credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $438.0 million, of which $220.0 million was the term loan balance, as well as $3.0 million committed to standby letters of credit as of September 30, 2017. Subject to covenant limitations, $429.0 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-17-000013:notes:66]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-17-000013:notes:67]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-17-000013:notes:68]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-17-000013:notes:69]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-17-000013:notes:70]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2017, we believe we were in compliance with all covenant requirements.

[0001069202-17-000013:notes:71]
Senior Unsecured Notes

[0001069202-17-000013:notes:72]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also repaid $200.0 million of senior unsecured notes issued in 2010 that matured on May 15, 2017.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2017, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-17-000013:notes:73]
[same as prior period, unchanged from 0001069202-17-000009:notes:73]

[0001069202-17-000013:notes:74]
[same as prior period, unchanged from 0001069202-17-000009:notes:74]

[0001069202-17-000013:notes:75]
[same as prior period, unchanged from 0001069202-17-000009:notes:75]

[0001069202-17-000013:notes:76]
[same as prior period, unchanged from 0001069202-17-000009:notes:76]

[0001069202-17-000013:notes:77]
[same as prior period, unchanged from 0001069202-17-000009:notes:77]

[0001069202-17-000013:notes:78]
[same as prior period, unchanged from 0001069202-17-000009:notes:78]

[0001069202-17-000013:notes:79]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flow hedges that are scheduled to mature through February 2019 and December 2018, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-17-000013:notes:80]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Unrealized (gains) losses on unsettled contracts | $ | (9.9 | ) |  | $ | (8.9 | ) |
| Income tax expense | 3.6 |  |  | 3.3 |  |
| Gains included in AOCL, net of tax (1) | $ | (6.3 | ) |  | $ | (5.6 | ) |

[0001069202-17-000013:notes:81]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $6.1 million of derivative gains into earnings within the next 12 months.

[0001069202-17-000013:notes:82]
[same as prior period, unchanged from 0001069202-17-000009:notes:82]

[0001069202-17-000013:notes:83]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Copper | 18.9 |  |  | 30.4 |  |

[0001069202-17-000013:notes:84]
[same as prior period, unchanged from 0001069202-17-000009:notes:84]

[0001069202-17-000013:notes:85]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 69.8 |  |  | 310.1 |  |
| Canadian Dollar | 83.1 |  |  | 24.9 |  |

[0001069202-17-000013:notes:86]
[same as prior period, unchanged from 0001069202-17-000009:notes:86]

[0001069202-17-000013:notes:87]
[same as prior period, unchanged from 0001069202-17-000009:notes:87]

[0001069202-17-000013:notes:88]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Copper | 1.8 |  |  | 2.4 |  |
| Aluminum | 1.9 |  |  | 2.6 |  |

[0001069202-17-000013:notes:89]
[same as prior period, unchanged from 0001069202-17-000009:notes:89]

[0001069202-17-000013:notes:90]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Notional Amounts (in local currency): |  |  |  |
| Chinese Yuan | 52.3 |  |  | 10.5 |  |
| Mexican Peso | 35.7 |  |  | 64.5 |  |
| Euro | 60.7 |  |  | 46.9 |  |
| Canadian Dollar | 31.0 |  |  | — |  |
| British Pound | 4.9 |  |  | 1.3 |  |
| Singapore Dollar | 6.5 |  |  | — |  |
| Australian Dollar | 40.0 |  |  | — |  |
| New Zealand Dollar | 6.5 |  |  | — |  |
| Indian Rupee | 169.4 |  |  | 584.6 |  |

[0001069202-17-000013:notes:91]
[same as prior period, unchanged from 0001069202-17-000009:notes:91]

[0001069202-17-000013:notes:92]
[same as prior period, unchanged from 0001069202-17-000009:notes:92]

[0001069202-17-000013:notes:93]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of September 30, 2017 |  | As of December 31, 2016 |  | As of September 30, 2017 |  | As of December 31, 2016 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 9.7 |  |  | $ | 8.7 |  |  | $ | 1.0 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts | 0.4 |  |  | 0.5 |  |  | 0.2 |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.3 |  |  | 1.9 |  |  | — |  |  | 0.2 |  |
| Total Assets | $ | 10.4 |  |  | $ | 11.1 |  |  | $ | 1.2 |  |  | $ | 1.1 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 1.5 |  |  | $ | 3.2 |  |
| Total Liabilities | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 1.5 |  |  | $ | 3.2 |  |

[0001069202-17-000013:notes:94]
[same as prior period, unchanged from 0001069202-17-000009:notes:94]

[0001069202-17-000013:notes:95]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amount of (Gain)/Loss reclassified from AOCL into Income (effective portion) (1) |  | $ | (3.5 | ) |  | $ | 2.4 |  |  | $ | (9.4 | ) |  | $ | 10.6 |  |
| Amount of (Gain)/Loss recognized in Net income (ineffective portion) (2) |  | $ | (0.1 | ) |  | $ | (0.5 | ) |  | $ | 1.1 |  |  | $ | (0.4 | ) |

[0001069202-17-000013:notes:96]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amount of (Gain)/Loss Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | (0.2 | ) |  | $ | (0.3 | ) |  | $ | (1.3 | ) |  | $ | (0.2 | ) |
| Foreign currency forward contracts (2) |  | (0.4 | ) |  | 0.4 |  |  | (4.3 | ) |  | 0.3 |  |
|  |  | $ | (0.6 | ) |  | $ | 0.1 |  |  | $ | (5.6 | ) |  | $ | 0.1 |  |

[0001069202-17-000013:notes:97]
[same as prior period, unchanged from 0001069202-17-000009:notes:97]

[0001069202-17-000013:notes:98]
[same as prior period, unchanged from 0001069202-17-000009:notes:98]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-17-000013:notes:99]
[same as prior period, unchanged from 0001069202-17-000009:notes:99]

[0001069202-17-000013:notes:100]
[same as prior period, unchanged from 0001069202-17-000009:notes:100]

[0001069202-17-000013:notes:101]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Stock-based compensation expense (1) | $ | 6.3 |  |  | $ | 9.9 |  |  | $ | 18.8 |  |  | $ | 24.8 |  |

[0001069202-17-000013:notes:102]
[same as prior period, unchanged from 0001069202-17-000009:notes:102]


## us-gaap:EarningsPerShareTextBlock

[0001069202-17-000013:notes:103]
[same as prior period, unchanged from 0001069202-17-000009:notes:103]

[0001069202-17-000013:notes:104]
[same as prior period, unchanged from 0001069202-17-000009:notes:104]

[0001069202-17-000013:notes:105]
[same as prior period, unchanged from 0001069202-17-000009:notes:105]

[0001069202-17-000013:notes:106]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net income | $ | 103.5 |  |  | $ | 101.7 |  |  | $ | 262.5 |  |  | $ | 237.3 |  |
| Add: Loss from discontinued operations | 0.5 |  |  | — |  |  | 1.4 |  |  | 0.6 |  |
| Income from continuing operations | $ | 104.0 |  |  | $ | 101.7 |  |  | $ | 263.9 |  |  | $ | 237.9 |  |
| Weighted-average shares outstanding – basic | 41.9 |  |  | 43.2 |  |  | 42.3 |  |  | 43.6 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.5 |  |  | 0.5 |  |  | 0.6 |  |  | 0.6 |  |
| Weighted-average shares outstanding – diluted | 42.4 |  |  | 43.7 |  |  | 42.9 |  |  | 44.2 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.48 |  |  | $ | 2.35 |  |  | $ | 6.23 |  |  | $ | 5.46 |  |
| Loss from discontinued operations | (0.01 | ) |  | — |  |  | (0.03 | ) |  | (0.01 | ) |
| Net income | $ | 2.47 |  |  | $ | 2.35 |  |  | $ | 6.20 |  |  | $ | 5.45 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.45 |  |  | $ | 2.33 |  |  | $ | 6.15 |  |  | $ | 5.39 |  |
| Loss from discontinued operations | (0.01 | ) |  | — |  |  | (0.03 | ) |  | (0.01 | ) |
| Net income | $ | 2.44 |  |  | $ | 2.33 |  |  | $ | 6.12 |  |  | $ | 5.38 |  |

[0001069202-17-000013:notes:107]
[same as prior period, unchanged from 0001069202-17-000009:notes:107]

[0001069202-17-000013:notes:108]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Weighted-average number of shares | 0.2 |  |  | — |  |  | 0.2 |  |  | 0.2 |  |
| Price range per share | $ | 156.94 |  |  | — |  |  | $ | 156.94 |  |  | $124.97-$131.94 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-17-000013:notes:109]
[same as prior period, unchanged from 0001069202-17-000009:notes:109]

[0001069202-17-000013:notes:110]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Senior unsecured notes | $ | 316.9 |  |  | $ | 499.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-17-000013:notes:111]
[same as prior period, unchanged from 0001069202-17-000009:notes:111]

[0001069202-17-000013:notes:112]
[same as prior period, unchanged from 0001069202-17-000009:notes:112]

[0001069202-17-000013:notes:113]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2017 were the same as those used at December 31, 2016.

[0001069202-17-000013:notes:114]
[same as prior period, unchanged from 0001069202-17-000009:notes:114]

[0001069202-17-000013:notes:115]
[same as prior period, unchanged from 0001069202-17-000009:notes:115]

[0001069202-17-000013:notes:116]
[same as prior period, unchanged from 0001069202-17-000009:notes:116]

[0001069202-17-000013:notes:117]
[same as prior period, unchanged from 0001069202-17-000009:notes:117]

[0001069202-17-000013:notes:118]
[same as prior period, unchanged from 0001069202-17-000009:notes:118]

[0001069202-17-000013:notes:119]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Investment in marketable equity securities | $ | 4.7 |  |  | $ | 4.4 |  |

[0001069202-17-000013:notes:120]
[same as prior period, unchanged from 0001069202-17-000009:notes:120]

[0001069202-17-000013:notes:121]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-17-000013:notes:122]
[same as prior period, unchanged from 0001069202-17-000009:notes:122]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-17-000013:notes:123]
[same as prior period, unchanged from 0001069202-17-000009:notes:123]

[0001069202-17-000013:notes:124]
The changes in the carrying amount of goodwill for the first nine months of 2017, in total and by segment, are summarized in the table below (in millions):

[0001069202-17-000013:notes:125]
|  | Balance at December 31, 2016 |  | Changes in foreign currency translation rates |  | Balance at September 30, 2017 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 60.1 |  |  | 1.8 |  |  | 61.9 |  |
| Refrigeration | 108.9 |  |  | 3.7 |  |  | 112.6 |  |
| Total Goodwill | $ | 195.1 |  |  | $ | 5.5 |  |  | $ | 200.6 |  |

[0001069202-17-000013:notes:126]
[same as prior period, unchanged from 0001069202-17-000009:notes:127]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-17-000013:notes:127]
[same as prior period, unchanged from 0001069202-17-000009:notes:128]

[0001069202-17-000013:notes:128]
As of September 30, 2017, we had no unrecognized tax benefits.

[0001069202-17-000013:notes:129]
[same as prior period, unchanged from 0001069202-17-000009:notes:130]

[0001069202-17-000013:notes:130]
[same as prior period, unchanged from 0001069202-17-000009:notes:131]

[0001069202-17-000013:notes:131]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity. We recognized discrete tax benefits of $1.5 million and $9.6 million in the income taxes line item of our Consolidated Statements of Operations for the three and nine months ended September 30, 2017, respectively, related to excess tax benefits upon vesting or settlement in those periods.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-17-000013:notes:132]
[same as prior period, unchanged from 0001069202-17-000009:notes:133]

[0001069202-17-000013:notes:133]
[same as prior period, unchanged from 0001069202-17-000009:notes:134]

[0001069202-17-000013:notes:134]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Finished goods | $ | 369.1 |  |  | $ | 287.2 |  |
| Work in process | 8.6 |  |  | 5.1 |  |
| Raw materials and parts | 209.4 |  |  | 183.4 |  |
| Subtotal | 587.1 |  |  | 475.7 |  |
| Excess of current cost over last-in, first-out cost | (56.2 | ) |  | (57.2 | ) |
| Total inventories, net | $ | 530.9 |  |  | $ | 418.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-17-000013:notes:135]
[same as prior period, unchanged from 0001069202-17-000009:notes:136]

[0001069202-17-000013:notes:136]
[same as prior period, unchanged from 0001069202-17-000009:notes:137]

[0001069202-17-000013:notes:137]
[same as prior period, unchanged from 0001069202-17-000009:notes:138]

[0001069202-17-000013:notes:138]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-17-000013:notes:139]
[same as prior period, unchanged from 0001069202-17-000009:notes:140]

[0001069202-17-000013:notes:140]
Recently Adopted Accounting Guidance

[0001069202-17-000013:notes:141]
On March 30, 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations.  This is in comparison to the prior requirement that these excess tax benefits be recognized in additional paid-in capital. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity.

[0001069202-17-000013:notes:142]
We have adopted ASU 2016-09 effective January 1, 2017 on a prospective basis where permitted by the new standard. As a result of this adoption:

[0001069202-17-000013:notes:143]
| • | We recognized discrete tax benefits of $1.5 million and $9.6 million in the income taxes line item of our consolidated statements of operations for the three and nine months ended September 30, 2017 respectively, related to excess tax benefits upon vesting or settlement in that period. |

[0001069202-17-000013:notes:144]
[same as prior period, unchanged from 0001069202-17-000009:notes:145]

[0001069202-17-000013:notes:145]
[same as prior period, unchanged from 0001069202-17-000009:notes:146]

[0001069202-17-000013:notes:146]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three and nine months ended September 30, 2017. |

[0001069202-17-000013:notes:147]
[same as prior period, unchanged from 0001069202-17-000009:notes:148]

[0001069202-17-000013:notes:148]
[same as prior period, unchanged from 0001069202-17-000009:notes:149]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-17-000013:notes:149]
[same as prior period, unchanged from 0001069202-17-000009:notes:150]

[0001069202-17-000013:notes:150]
[same as prior period, unchanged from 0001069202-17-000009:notes:151]

[0001069202-17-000013:notes:151]
|  | For the Three Months Ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.3 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.2 |  |  | 3.8 |  |  | — |  |  | — |  |
| Expected return on plan assets | (5.3 | ) |  | (5.4 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  | (0.6 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.0 |  |  | 1.9 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | — |  |  | 0.2 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.2 |  |  | $ | 1.7 |  |  | $ | (0.2 | ) |  | $ | (0.4 | ) |

[0001069202-17-000013:notes:152]
|  | For the Nine Months Ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 3.8 |  |  | $ | 3.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 9.5 |  |  | 11.5 |  |  | — |  |  | 0.1 |  |
| Expected return on plan assets | (16.0 | ) |  | (16.2 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.2 |  |  | (1.8 | ) |  | (2.3 | ) |
| Recognized actuarial loss | 6.1 |  |  | 5.7 |  |  | 1.1 |  |  | 1.1 |  |
| Settlements and curtailments | 0.6 |  |  | 0.2 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 4.1 |  |  | $ | 4.7 |  |  | $ | (0.7 | ) |  | $ | (1.1 | ) |

[0001069202-17-000013:notes:153]
(1) All net periodic benefit cost for the three and nine months ended September 30, 2017 and 2016 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-17-000013:notes:154]
[same as prior period, unchanged from 0001069202-17-000009:notes:155]

[0001069202-17-000013:notes:155]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 590.5 |  |  | $ | 572.7 |  |  | $ | 1,663.8 |  |  | $ | 1,524.5 |  |
| Commercial Heating & Cooling | 269.4 |  |  | 251.4 |  |  | 723.5 |  |  | 674.7 |  |
| Refrigeration | 192.4 |  |  | 185.9 |  |  | 560.6 |  |  | 545.2 |  |
|  | $ | 1,052.3 |  |  | $ | 1,010.0 |  |  | $ | 2,947.9 |  |  | $ | 2,744.4 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 114.7 |  |  | $ | 112.7 |  |  | $ | 297.6 |  |  | $ | 266.9 |  |
| Commercial Heating & Cooling | 50.0 |  |  | 48.9 |  |  | 113.8 |  |  | 110.6 |  |
| Refrigeration | 20.0 |  |  | 22.9 |  |  | 55.7 |  |  | 53.2 |  |
| Corporate and other | (23.7 | ) |  | (27.3 | ) |  | (58.5 | ) |  | (65.7 | ) |
| Total segment profit | 161.0 |  |  | 157.2 |  |  | 408.6 |  |  | 365.0 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special product quality adjustments | 0.5 |  |  | — |  |  | 5.7 |  |  | (0.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) | 4.0 |  |  | (0.3 | ) |  | 10.0 |  |  | 2.9 |  |
| Restructuring charges | 1.9 |  |  | 0.6 |  |  | 2.1 |  |  | 1.2 |  |
| Operating income | $ | 154.6 |  |  | $ | 156.9 |  |  | $ | 390.8 |  |  | $ | 361.3 |  |

[0001069202-17-000013:notes:156]
(1)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-17-000013:notes:157]
[same as prior period, unchanged from 0001069202-17-000009:notes:158]

[0001069202-17-000013:notes:158]
[same as prior period, unchanged from 0001069202-17-000009:notes:159]

[0001069202-17-000013:notes:159]
[same as prior period, unchanged from 0001069202-17-000009:notes:160]

[0001069202-17-000013:notes:160]
| ◦ | Special legal contingency charges, |

[0001069202-17-000013:notes:161]
| ◦ | Asbestos-related litigation, |

[0001069202-17-000013:notes:162]
[same as prior period, unchanged from 0001069202-17-000009:notes:163]

[0001069202-17-000013:notes:163]
[same as prior period, unchanged from 0001069202-17-000009:notes:164]

[0001069202-17-000013:notes:164]
[same as prior period, unchanged from 0001069202-17-000009:notes:165]

[0001069202-17-000013:notes:165]
[same as prior period, unchanged from 0001069202-17-000009:notes:166]

[0001069202-17-000013:notes:166]
| • | Restructuring charges. |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-17-000013:notes:167]
[same as prior period, unchanged from 0001069202-17-000009:notes:168]

[0001069202-17-000013:notes:168]
[same as prior period, unchanged from 0001069202-17-000009:notes:169]

[0001069202-17-000013:notes:169]
[same as prior period, unchanged from 0001069202-17-000009:notes:170]

[0001069202-17-000013:notes:170]
[same as prior period, unchanged from 0001069202-17-000009:notes:171]

[0001069202-17-000013:notes:171]
|  | Charges Incurred in 2017 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 1.3 |  |  | $ | 10.6 |  |  | $ | 11.0 |  |
| Asset write-offs and accelerated depreciation | 0.7 |  |  | 3.1 |  |  | 3.1 |  |
| Lease termination | — |  |  | 0.2 |  |  | 0.2 |  |
| Other | 0.1 |  |  | 3.8 |  |  | 4.1 |  |
| Total restructuring charges | $ | 2.1 |  |  | $ | 17.7 |  |  | $ | 18.4 |  |

[0001069202-17-000013:notes:172]
[same as prior period, unchanged from 0001069202-17-000009:notes:173]

[0001069202-17-000013:notes:173]
|  | Charges Incurred in 2017 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.5 |  |  | $ | 1.4 |  |  | $ | 1.6 |  |
| Commercial Heating & Cooling | 0.7 |  |  | 1.8 |  |  | 1.9 |  |
| Refrigeration | 0.4 |  |  | 12.3 |  |  | 12.3 |  |
| Corporate & Other | 0.5 |  |  | 2.2 |  |  | 2.6 |  |
| Total restructuring charges | $ | 2.1 |  |  | $ | 17.7 |  |  | $ | 18.4 |  |

[0001069202-17-000013:notes:174]
[same as prior period, unchanged from 0001069202-17-000009:notes:175]

[0001069202-17-000013:notes:175]
|  | Balance as ofDecember 31, 2016 |  | Included inEarnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of September 30, 2017 |
| Severance and related expense | $ | — |  |  | $ | 1.3 |  |  | $ | (0.9 | ) |  | $ | — |  |  | $ | 0.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.7 |  |  | (0.1 | ) |  | (0.6 | ) |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Total restructuring accruals | $ | — |  |  | $ | 2.1 |  |  | $ | (1.1 | ) |  | $ | (0.6 | ) |  | $ | 0.4 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001069202-17-000013:notes:176]
[same as prior period, unchanged from 0001069202-17-000009:notes:177]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-17-000013:notes:177]
[same as prior period, unchanged from 0001069202-17-000009:notes:178]

[0001069202-17-000013:notes:178]
[same as prior period, unchanged from 0001069202-17-000009:notes:179]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-17-000013:notes:179]
[same as prior period, unchanged from 0001069202-17-000009:notes:180]

[0001069202-17-000013:notes:180]
[same as prior period, unchanged from 0001069202-17-000009:notes:181]

[0001069202-17-000013:notes:181]
[same as prior period, unchanged from 0001069202-17-000009:notes:182]

[0001069202-17-000013:notes:182]
[same as prior period, unchanged from 0001069202-17-000009:notes:183]

[0001069202-17-000013:notes:183]
[same as prior period, unchanged from 0001069202-17-000009:notes:184]

[0001069202-17-000013:notes:184]
[same as prior period, unchanged from 0001069202-17-000009:notes:185]

[0001069202-17-000013:notes:185]
[same as prior period, unchanged from 0001069202-17-000009:notes:186]

[0001069202-17-000013:notes:186]
[same as prior period, unchanged from 0001069202-17-000009:notes:187]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-17-000013:notes:187]
[same as prior period, unchanged from 0001069202-17-000009:notes:188]

[0001069202-17-000013:notes:188]
Our Board of Directors has authorized a total of $2 billion  towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $550 million share repurchase authorization in 2016. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date. As of September 30, 2017, $396 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-17-000013:notes:189]
[same as prior period, unchanged from 0001069202-17-000009:notes:190]

[0001069202-17-000013:notes:190]
[same as prior period, unchanged from 0001069202-17-000009:notes:191]

[0001069202-17-000013:notes:191]
[same as prior period, unchanged from 0001069202-17-000009:notes:192]

[0001069202-17-000013:notes:192]
Under the Second ASR Agreement, on April 28, 2017, we paid J.P. Morgan Chase Bank an initial purchase price of $100 million, and J.P. Morgan Chase Bank delivered to us Common Stock, representing approximately 85% of the shares expected to be purchased under the ASR Agreement. The ASR Agreement was completed in the third quarter and J.P. Morgan Chase Bank delivered additional shares for a total of 0.6 million shares of common stock repurchased as part of this ASR Agreement.

[0001069202-17-000013:notes:193]
On July 27, 2017, we entered into another Fixed Dollar ASR Agreement (the "Third ASR Agreement") with Bank of America to effect an accelerated stock buyback of Common Stock.

[0001069202-17-000013:notes:194]
Under the Third ASR Agreement, on July 27, 2017, we paid Bank of America an initial purchase price of $75 million, and Bank of America delivered to us a total of 0.4 million shares of Common Stock, representing approximately 85% of the shares expected to be purchased under the third ASR Agreement. The third ASR Agreement will be completed in the fourth quarter.

[0001069202-17-000013:notes:195]
We also repurchased 0.1 million shares for $16.0 million during the nine months ended September 30, 2017 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
