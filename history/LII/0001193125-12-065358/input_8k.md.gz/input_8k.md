# LII 8-K — 0001188112-12-000235 filed 2012-02-02

## item codes, every 8-K on or before 2012-02-16

- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2012-02-16

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001188112-12-000235:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001188112-12-000235:8k_2_02:2]
ex99-1.htm

[0001188112-12-000235:8k_2_02:3]
Exhibit 99.1

[0001188112-12-000235:8k_2_02:4]
Lennox International Reports Fourth Quarter and Full Year Results

[0001188112-12-000235:8k_2_02:5]
| ● | 4Q11 adjusted EPS of $0.51 and GAAP EPS of $0.32 |

[0001188112-12-000235:8k_2_02:6]
| ● | 2011 adjusted EPS of $2.04 and GAAP EPS of $1.65 |

[0001188112-12-000235:8k_2_02:7]
| ● | Reiterate 2012 revenue growth guidance of 2-6% |

[0001188112-12-000235:8k_2_02:8]
| ● | Reiterate 2012 adjusted EPS from continuing operations guidance of $2.20-$2.60 |

[0001188112-12-000235:8k_2_02:9]
DALLAS, February 2, 2012 – Lennox International Inc. (NYSE: LII) today reported fourth quarter and full year 2011 results.

[0001188112-12-000235:8k_2_02:10]
For the fourth quarter, revenue was $756 million, down 1% from the prior-year quarter.  Excluding the Kysor/Warren acquisition that closed in January 2011, revenue was down 7% in the fourth quarter. Total segment profit margin for the company overall was 5.5% compared to 6.4% in the prior-year quarter. Diluted earnings per share from continuing operations on an adjusted basis was $0.51 compared to $0.55 in the prior-year quarter. Diluted earnings per share from continuing operations on a GAAP basis was $0.32 compared to $0.51 in the fourth quarter a year ago.

[0001188112-12-000235:8k_2_02:11]
For the full year, revenue was $3.3 billion, up 7% from the prior year. At constant currency, revenue was up 5%. Excluding the Kysor/Warren acquisition, revenue was flat, or down 2% at constant currency. Total segment profit margin for the company overall was 5.4% compared to 7.0% in the prior year. Diluted earnings per share from continuing operations on an adjusted basis, was $2.04 compared to $2.40 in 2010. Diluted earnings per share from continuing operations on a GAAP basis was $1.65 compared to $2.10 in the prior year.

[0001188112-12-000235:8k_2_02:12]
“In 2011, the residential HVAC market was down in dollar value compared to 2010, primarily from a lower mix of business without the $1,500 U.S. tax credit for high-efficiency equipment in place and with the re-emergence of minimum-efficiency condensing units in the industry based on the old R-22 refrigerant,” said Todd Bluedorn, CEO of Lennox International. “Our residential equipment and service businesses were down accordingly in 2011. Our commercial and refrigeration businesses, however, were up in 2011. At constant currency, Commercial revenue grew 10% and Refrigeration revenue grew 5% on an organic basis, adjusted for the Kysor/Warren acquisition and the strategic exit of the third-party coil business in Australia.

[0001188112-12-000235:8k_2_02:13]
“In the fourth quarter, our Commercial business continued to show strong, broad-based growth, with revenue up 9% at constant currency and margin up 230 basis points to a record fourth-quarter level of 11.1%. In our Refrigeration business, organic revenue was up 2% at constant currency. Margins expanded 170 basis points to a record fourth-quarter level of 11.7%.

[0001188112-12-000235:8k_2_02:14]
“Turning to our residential equipment and service businesses, revenue and profits were down on the warmer winter weather across North America in the fourth quarter and against the tough comparison to a year ago. In the fourth quarter of 2010, we saw a pull-forward of demand ahead of our announced price increases and from the approaching expiration of the federal tax credit at the $1,500 level. As discussed at the time, these effects drove volume and a strong product mix.

[0001188112-12-000235:8k_2_02:15]
“Looking at 2012 overall, we continue to expect low single-digit shipment growth across our commercial, refrigeration, and residential end markets, and expect total company revenue growth of 2-6%. We reiterate our adjusted EPS guidance range of $2.20-$2.60 for the full year.”

[0001188112-12-000235:8k_2_02:16]
FOURTH QUARTER 2011 FINANCIAL HIGHLIGHTS

[0001188112-12-000235:8k_2_02:17]
Revenue: Revenue for the fourth quarter was $756 million, down 1% from the prior year. Foreign exchange was neutral to revenue. Excluding Kysor/Warren and at constant currency, revenue was down 7%. Volume was down, and price/mix was flat against the fourth quarter a year ago.

[0001188112-12-000235:8k_2_02:18]
Gross Profit: Gross profit in the fourth quarter was $190 million compared to $220 million in the prior-year quarter. Gross margin was 25.1% versus 28.9% in the fourth quarter a year ago. Gross margin was negatively impacted by lower volume and product mix, higher commodity costs, and the Kysor/Warren acquisition, with a partial offset from favorable price.

[0001188112-12-000235:8k_2_02:19]
Income from Continuing Operations: For the fourth quarter, adjusted income from continuing operations was $26 million, or $0.51 diluted earnings per share, compared to $30 million, or $0.55 diluted earnings per share from continuing operations in the prior-year quarter. On a GAAP basis, fourth quarter 2011 income from continuing operations was $17 million, or $0.32 diluted earnings per share, compared to $28 million, or $0.51 diluted earnings per share, in the prior-year quarter.

[0001188112-12-000235:8k_2_02:20]
Adjusted income from continuing operations for the fourth quarter of 2011 excludes net after-tax charges of $9.7 million, which are derived from:

[0001188112-12-000235:8k_2_02:21]
|  | ● | $9.5 million charge for goodwill and asset impairment in the Hearth business |

[0001188112-12-000235:8k_2_02:22]
|  | ● | $1.5 million charge related to restructuring activities |

[0001188112-12-000235:8k_2_02:23]
|  | ● | $1.3 million income related to a special product quality adjustment, net |

[0001188112-12-000235:8k_2_02:24]
|  | ● | $0.6 million net change in unrealized gains on open future contracts |

[0001188112-12-000235:8k_2_02:25]
|  | ● | $0.6 million charge from other items, net |

[0001188112-12-000235:8k_2_02:26]
FULL YEAR 2011 FINANCIAL HIGHLIGHTS

[0001188112-12-000235:8k_2_02:27]
Revenue: For the full year, revenue was $3.3 billion, up 7% from the prior year. Foreign exchange had a positive 2 point impact to revenue. Excluding Kysor/Warren and at constant currency, revenue was down 2%. Volume was down, and price/mix was up for the full year.

[0001188112-12-000235:8k_2_02:28]
Gross Profit: Gross profit for the full year was $834 million compared to $892 million in the prior year. Gross margin was 25.2% versus 28.8% in 2010. Gross margin was negatively impacted by lower volume and product mix, higher commodity costs, a lower positive warranty adjustment, and the acquisition of Kysor/Warren, with a partial offset from favorable price.

[0001188112-12-000235:8k_2_02:29]
Income from Continuing Operations: Adjusted income from continuing operations for 2011 was $109 million, or $2.04 diluted earnings per share, compared to $134 million, or $2.40 diluted earnings per share in the prior year. On a GAAP basis, income from continuing operations for 2011 was $88 million, or $1.65 diluted earnings per share, compared to $117 million, or $2.10 diluted earnings per share in the prior year.

[0001188112-12-000235:8k_2_02:30]
Adjusted income from continuing operations for 2011 excludes net after-tax charges of $20.3 million, which are derived from:

[0001188112-12-000235:8k_2_02:31]
|  | ● | $10.6 million charge for restructuring activities |

[0001188112-12-000235:8k_2_02:32]
|  | ● | $9.5 million charge for goodwill and asset impairment in the Hearth business |

[0001188112-12-000235:8k_2_02:33]
|  | ● | $2.8 million income related to a special product quality adjustment, net |

[0001188112-12-000235:8k_2_02:34]
|  | ● | $2.5 million net change in unrealized losses on open future contracts |

[0001188112-12-000235:8k_2_02:35]
|  | ● | $0.8 million charge for acquisition costs, net |

[0001188112-12-000235:8k_2_02:36]
|  | ● | $0.3 million income/gain from other items, net |

[0001188112-12-000235:8k_2_02:37]
Free Cash Flow and Total Debt: Cash generated from operations for the year was $76 million. The company invested $43 million in capital assets, resulting in free cash flow of $33 million. In the second half of 2011, free cash flow was $194 million compared to $186 million in the second half of 2010. The company repurchased $120 million of stock in 2011, including $30 million in the fourth quarter. Total debt at the end of 2011 was $465 million. Total cash and cash equivalents were $45 million ending the year.

[0001188112-12-000235:8k_2_02:38]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001188112-12-000235:8k_2_02:39]
Residential Heating and Cooling

[0001188112-12-000235:8k_2_02:40]
|  | ● | 4Q11 revenue of $300 million, down 14% from $349 million in the prior-year quarter; foreign exchange was neutral |

[0001188112-12-000235:8k_2_02:41]
|  | ● | 4Q11 segment profit of $14 million, down 57% from $34 million in 4Q10 |

[0001188112-12-000235:8k_2_02:42]
|  | ● | 4Q11 segment profit margin of 4.8%, down 480 basis points from 9.6% in 4Q10 |

[0001188112-12-000235:8k_2_02:43]
|  | ● | 2011 revenue of $1,341 million, down 5% from $1,417 million in 2010; foreign exchange was neutral |

[0001188112-12-000235:8k_2_02:44]
|  | ● | 2011 segment profit of $75 million, down 43% from $132 million in 2010 |

[0001188112-12-000235:8k_2_02:45]
|  | ● | 2011 profit margin of 5.6%, down 370 basis points from 9.3% in 2010 |

[0001188112-12-000235:8k_2_02:46]
Fourth quarter and full year results were negatively impacted by lower volume, lower product mix, and higher commodity costs, with offsets from favorable price, productivity initiatives, and lower SG&A expenses. Both quarterly and full-year results were negatively impacted by losses in the Hearth business with single-family housing starts in 2011 at the lowest level on record. In the fourth quarter, the Hearth business had goodwill and asset impairments, which are not included at the segment level. The company is pursuing strategic alternatives for the Hearth business.

[0001188112-12-000235:8k_2_02:47]
Commercial Heating and Cooling

[0001188112-12-000235:8k_2_02:48]
|  | ● | 4Q11 revenue of $160 million, up 8% from $148 million in the prior-year quarter; up 9% at constant currency |

[0001188112-12-000235:8k_2_02:49]
|  | ● | 4Q11 segment profit of $18 million, up 35% from $13 million in 4Q10 |

[0001188112-12-000235:8k_2_02:50]
|  | ● | 4Q11 segment profit margin of 11.1%, up 230 basis points from 8.8% in 4Q10 |

[0001188112-12-000235:8k_2_02:51]
|  | ● | 2011 revenue of $696 million, up 12% from $620 million in 2010; up 10% at constant currency |

[0001188112-12-000235:8k_2_02:52]
|  | ● | 2011 segment profit of $79 million, up 15% from $69 million in 2010 |

[0001188112-12-000235:8k_2_02:53]
|  | ● | 2011 segment profit margin of 11.4%, up 20 basis points from 11.2% in 2010 |

[0001188112-12-000235:8k_2_02:54]
Fourth quarter and full year results were positively impacted by higher volume, favorable price/mix, productivity initiatives, and lower SG&A expenses, with an offset from higher commodity costs.

[0001188112-12-000235:8k_2_02:55]
Service Experts

[0001188112-12-000235:8k_2_02:56]
|  | ● | 4Q11 revenue of $122 million, down 16% from $145 million in the prior-year quarter; foreign exchange was neutral |

[0001188112-12-000235:8k_2_02:57]
|  | ● | 4Q11 segment profit of $1 million, down 78% from $5 million in 4Q10 |

[0001188112-12-000235:8k_2_02:58]
|  | ● | 4Q11 segment profit margin of 0.9%, down 260 basis points from 3.5% in 4Q10 |

[0001188112-12-000235:8k_2_02:59]
|  | ● | 2011 revenue of $529 million, down 10% from $590 million in 2010; down 11% at constant currency |

[0001188112-12-000235:8k_2_02:60]
|  | ● | 2011 segment profit of $2 million, down 92% from $19 million in 2010 |

[0001188112-12-000235:8k_2_02:61]
|  | ● | 2011 segment profit margin of 0.3%, down 300 basis points from 3.3% in 2010 |

[0001188112-12-000235:8k_2_02:62]
Fourth quarter and full year results were negatively impacted by lower volume, with offsets from productivity initiatives and lower SG&A expenses.

[0001188112-12-000235:8k_2_02:63]
Refrigeration

[0001188112-12-000235:8k_2_02:64]
|  | ● | 4Q11 revenue of $189 million, up 36% from $139 million in the prior-year quarter; up 2% on an organic basis; foreign exchange was neutral |

[0001188112-12-000235:8k_2_02:65]
|  | ● | 4Q11 segment profit of $22 million, up 59% from $14 million in 4Q10 |

[0001188112-12-000235:8k_2_02:66]
|  | ● | 4Q11 segment profit margin of 11.7%, up 170 basis points from 10.0% in 4Q10 |

[0001188112-12-000235:8k_2_02:67]
|  | ● | 2011 revenue of $805 million, up 46% from $551 million in 2010; up 10% on an organic basis and up 5% at constant currency |

[0001188112-12-000235:8k_2_02:68]
|  | ● | 2011 segment profit of $78 million, up 26% from $61 million in 2010 |

[0001188112-12-000235:8k_2_02:69]
|  | ● | 2011 segment profit margin of 9.6%, down 150 basis points from 11.1% in 2010 |

[0001188112-12-000235:8k_2_02:70]
Fourth quarter and full year results were positively impacted by favorable price/mix, productivity initiatives, and lower SG&A expenses, with an offset from higher commodity costs.

[0001188112-12-000235:8k_2_02:71]
2012 FULL YEAR OUTLOOK

[0001188112-12-000235:8k_2_02:72]
The company reiterates its 2012 guidance, originally provided on December 14, 2011:

[0001188112-12-000235:8k_2_02:73]
|  | ● | Revenue growth of 2-6%, with a neutral impact from foreign exchange |

[0001188112-12-000235:8k_2_02:74]
|  | ● | Adjusted EPS from continuing operations of $2.20 to $2.60 |

[0001188112-12-000235:8k_2_02:75]
|  | ● | GAAP EPS from continuing operations of $2.17 to $2.57 |

[0001188112-12-000235:8k_2_02:76]
|  | ● | Tax rate of approximately 33-34% |

[0001188112-12-000235:8k_2_02:77]
|  | ● | Average diluted share count of approximately 51 million shares for the full year |

[0001188112-12-000235:8k_2_02:78]
CONFERENCE CALL INFORMATION

[0001188112-12-000235:8k_2_02:79]
A conference call to discuss the company’s fourth quarter and full year 2011 results will be held this morning at 8:30 a.m. Central time. To listen, please call the conference call line at 612-332-0226 at least 10 minutes prior to the scheduled start time and use reservation number 232842. This conference call will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0001188112-12-000235:8k_2_02:80]
A replay will be available from 11:00 a.m. Central time on February 2 through February 9, 2012, by dialing 800-475-6701 (U.S.) or 320-365-3844 (International) and using access code 232842. This call will also be archived on the company’s web site.

[0001188112-12-000235:8k_2_02:81]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under the symbol “LII.” Additional information is available at: http://www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001188112-12-000235:8k_2_02:82]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001188112-12-000235:8k_2_02:83]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001188112-12-000235:8k_2_02:84]
(Unaudited, in millions, except per share data)

[0001188112-12-000235:8k_2_02:85]
|  |  | For the Three Months Ended December 31, |  |  | For the Twelve Months Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| NET SALES |  | $ | 755.8 |  |  | $ | 762.0 |  |  | $ | 3,303.6 |  |  | $ | 3,096.4 |  |
| COST OF GOODS SOLD |  |  | 566.1 |  |  |  | 542.0 |  |  |  | 2,470.0 |  |  |  | 2,204.6 |  |
| Gross profit |  |  | 189.7 |  |  |  | 220.0 |  |  |  | 833.6 |  |  |  | 891.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 144.5 |  |  |  | 172.7 |  |  |  | 659.9 |  |  |  | 685.7 |  |
| Losses and other expenses, net |  |  | 1.9 |  |  |  | 3.9 |  |  |  | 5.0 |  |  |  | 10.2 |  |
| Restructuring charges |  |  | 1.6 |  |  |  | 0.6 |  |  |  | 16.0 |  |  |  | 15.6 |  |
| Impairment of assets |  |  | 7.0 |  |  |  | - |  |  |  | 7.0 |  |  |  | - |  |
| Goodwill Impairment |  |  | 7.6 |  |  |  | - |  |  |  | 7.6 |  |  |  | - |  |
| Income from equity method investments |  |  | (0.6 | ) |  |  | (1.2 | ) |  |  | (9.6 | ) |  |  | (10.1 | ) |
| Operational income from continuing operations |  |  | 27.7 |  |  |  | 44.0 |  |  |  | 147.7 |  |  |  | 190.4 |  |
| INTEREST EXPENSE, net |  |  | 4.3 |  |  |  | 3.7 |  |  |  | 16.8 |  |  |  | 12.8 |  |
| OTHER EXPENSE, net |  |  | 0.2 |  |  |  | 0.9 |  |  |  | 0.3 |  |  |  | 1.0 |  |
| Income from continuing operations before income taxes |  |  | 23.2 |  |  |  | 39.4 |  |  |  | 130.6 |  |  |  | 176.6 |  |
| PROVISION FOR INCOME TAXES |  |  | 6.5 |  |  |  | 11.6 |  |  |  | 42.3 |  |  |  | 59.5 |  |
| Income from continuing operations |  |  | 16.7 |  |  |  | 27.8 |  |  |  | 88.3 |  |  |  | 117.1 |  |
| DISCONTINUED OPERATIONS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operational loss from discontinued operations |  |  | - |  |  |  | 0.2 |  |  |  | - |  |  |  | 1.1 |  |
| Income tax benefit |  |  | - |  |  |  | (0.1 | ) |  |  | - |  |  |  | (0.2 | ) |
| Loss from discontinued operations |  |  | - |  |  |  | 0.1 |  |  |  | - |  |  |  | 0.9 |  |
| Net income |  | $ | 16.7 |  |  | $ | 27.7 |  |  | $ | 88.3 |  |  | $ | 116.2 |  |
| EARNINGS PER SHARE - BASIC: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.33 |  |  | $ | 0.52 |  |  | $ | 1.68 |  |  | $ | 2.14 |  |
| Loss from discontinued operations |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.01 | ) |
| Net income |  | $ | 0.33 |  |  | $ | 0.52 |  |  | $ | 1.68 |  |  | $ | 2.13 |  |
| EARNINGS PER SHARE - DILUTED: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.32 |  |  | $ | 0.51 |  |  | $ | 1.65 |  |  | $ | 2.10 |  |
| Loss from discontinued operations |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.02 | ) |
| Net income |  | $ | 0.32 |  |  | $ | 0.51 |  |  | $ | 1.65 |  |  | $ | 2.08 |  |
| AVERAGE SHARES OUTSTANDING: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 51.2 |  |  |  | 53.5 |  |  |  | 52.5 |  |  |  | 54.6 |  |
| Diluted |  |  | 51.7 |  |  |  | 54.6 |  |  |  | 53.4 |  |  |  | 55.8 |  |
| CASH DIVIDENDS DECLARED PER SHARE |  | $ | 0.18 |  |  | $ | 0.15 |  |  | $ | 0.72 |  |  | $ | 0.60 |  |

[0001188112-12-000235:8k_2_02:86]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001188112-12-000235:8k_2_02:87]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001188112-12-000235:8k_2_02:88]
(Unaudited, in millions)

[0001188112-12-000235:8k_2_02:89]
|  | For the Three Months Ended December 31, |  |  | For the Twelve Months Ended December 31, |  |
|  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 300.3 |  |  | $ | 349.0 |  |  | $ | 1,341.0 |  |  | $ | 1,417.4 |  |
| Commercial Heating & Cooling |  |  | 159.6 |  |  |  | 148.2 |  |  |  | 696.0 |  |  |  | 620.0 |  |
| Service Experts |  |  | 122.0 |  |  |  | 144.7 |  |  |  | 528.6 |  |  |  | 590.3 |  |
| Refrigeration |  |  | 188.9 |  |  |  | 139.1 |  |  |  | 805.2 |  |  |  | 550.9 |  |
| Eliminations (A) |  |  | (15.0 | ) |  |  | (19.0 | ) |  |  | (67.2 | ) |  |  | (82.2 | ) |
|  |  | $ | 755.8 |  |  | $ | 762.0 |  |  | $ | 3,303.6 |  |  | $ | 3,096.4 |  |
| Segment Profit (Loss) (B) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 14.3 |  |  | $ | 33.6 |  |  | $ | 75.1 |  |  | $ | 132.3 |  |
| Commercial Heating & Cooling |  |  | 17.7 |  |  |  | 13.1 |  |  |  | 79.4 |  |  |  | 69.3 |  |
| Service Experts |  |  | 1.1 |  |  |  | 5.1 |  |  |  | 1.5 |  |  |  | 19.3 |  |
| Refrigeration |  |  | 22.1 |  |  |  | 13.9 |  |  |  | 77.5 |  |  |  | 61.4 |  |
| Corporate and other |  |  | (12.9 | ) |  |  | (17.3 | ) |  |  | (54.4 | ) |  |  | (65.5 | ) |
| Eliminations (A) |  |  | (0.9 | ) |  |  | 0.2 |  |  |  | (0.6 | ) |  |  | 0.2 |  |
| Subtotal that includes segment profit and eliminations |  |  | 41.4 |  |  |  | 48.6 |  |  |  | 178.5 |  |  |  | 217.0 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | (1.9 | ) |  |  | (0.2 | ) |  |  | (4.3 | ) |  |  | (0.2 | ) |
| Items in losses and other expenses, net that are excluded from segment profit (C) |  |  | (0.6 | ) |  |  | 4.2 |  |  |  | 4.5 |  |  |  | 11.2 |  |
| Restructuring charges |  |  | 1.6 |  |  |  | 0.6 |  |  |  | 16.0 |  |  |  | 15.6 |  |
| Impairment of assets |  |  | 7.0 |  |  |  | - |  |  |  | 7.0 |  |  |  | - |  |
| Goodwill impairment |  |  | 7.6 |  |  |  | - |  |  |  | 7.6 |  |  |  | - |  |
| Interest expense, net |  |  | 4.3 |  |  |  | 3.7 |  |  |  | 16.8 |  |  |  | 12.8 |  |
| Other expense, net |  |  | 0.2 |  |  |  | 0.9 |  |  |  | 0.3 |  |  |  | 1.0 |  |
| Income from continuing operations before income taxes |  | $ | 23.2 |  |  | $ | 39.4 |  |  | $ | 130.6 |  |  | $ | 176.6 |  |

[0001188112-12-000235:8k_2_02:90]
(A) Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment.

[0001188112-12-000235:8k_2_02:91]
(B) The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations:

[0001188112-12-000235:8k_2_02:92]
Excluding:

[0001188112-12-000235:8k_2_02:93]
o    Special product quality adjustment.

[0001188112-12-000235:8k_2_02:94]
o    Items within losses and other expenses, net that are noted in (C).

[0001188112-12-000235:8k_2_02:95]
o    Restructuring charges.

[0001188112-12-000235:8k_2_02:96]
o    Goodwill and equity method investment impairments.

[0001188112-12-000235:8k_2_02:97]
o    Interest expense, net.

[0001188112-12-000235:8k_2_02:98]
o    Other expense, net.

[0001188112-12-000235:8k_2_02:99]
(C) Items in losses and other expenses, net that are excluded from segment profit or loss are net change in unrealized gains and/or losses on open future contracts, realized gains and/or losses on marketable securities, special legal contingency charge, acquisition costs, among other items.

[0001188112-12-000235:8k_2_02:100]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001188112-12-000235:8k_2_02:101]
CONSOLIDATED BALANCE SHEETS

[0001188112-12-000235:8k_2_02:102]
(In millions, except share and per share data)

[0001188112-12-000235:8k_2_02:103]
|  | As of December 31, 2011 |  |  | As of December 31, 2010 |  |
|  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 45.0 |  |  | $ | 160.0 |  |
| Restricted cash |  |  | - |  |  |  | 12.2 |  |
| Accounts and notes receivable, net of allowances of $12.1 and $12.8 in 2011 and 2010, respectively |  |  | 408.7 |  |  |  | 384.8 |  |
| Inventories, net |  |  | 336.5 |  |  |  | 286.2 |  |
| Deferred income taxes, net |  |  | 36.8 |  |  |  | 36.7 |  |
| Other assets |  |  | 76.3 |  |  |  | 67.0 |  |
| Total current assets |  |  | 903.3 |  |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net of accumulated depreciation of $606.0 and $584.7 in 2011 and 2010, respectively |  |  | 309.9 |  |  |  | 324.3 |  |
| GOODWILL |  |  | 305.6 |  |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | 107.0 |  |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 79.9 |  |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 1,705.7 |  |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt |  |  | 0.8 |  |  |  | 0.6 |  |
| Accounts payable |  |  | 277.0 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 284.7 |  |  |  | 334.5 |  |
| Income taxes payable |  |  | 5.7 |  |  |  | 5.3 |  |
| Total current liabilities |  |  | 572.9 |  |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 459.6 |  |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | 18.6 |  |  |  | 15.9 |  |
| PENSIONS |  |  | 124.7 |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 62.1 |  |  |  | 65.7 |  |
| Total liabilities |  |  | 1,237.9 |  |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | - |  |  |  | - |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 86,648,631 shares and 86,480,816 shares issued for 2011 and 2010, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 881.2 |  |  |  | 863.5 |  |
| Retained earnings |  |  | 692.9 |  |  |  | 642.2 |  |
| Accumulated other comprehensive (loss)/income |  |  | (37.1 | ) |  |  | 30.2 |  |
| Treasury stock, at cost, 36,093,966 shares and 32,784,503 shares for 2011 and 2010, respectively |  |  | (1,070.1 | ) |  |  | (947.1 | ) |
| Total stockholders’ equity |  |  | 467.8 |  |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,705.7 |  |  | $ | 1,692.0 |  |

[0001188112-12-000235:8k_2_02:104]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001188112-12-000235:8k_2_02:105]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001188112-12-000235:8k_2_02:106]
(Unaudited, in millions, except per share and ratio data)

[0001188112-12-000235:8k_2_02:107]
Use of Non-GAAP Financial Measures

[0001188112-12-000235:8k_2_02:108]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables.  The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results.  The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating performance.

[0001188112-12-000235:8k_2_02:109]
Reconciliation of Income From Continuing Operations, a GAAP Measure, to Adjusted Income From Continuing Operations, a Non-GAAP Measure

[0001188112-12-000235:8k_2_02:110]
|  |  | For The Three Months |  |  | For The Twelve Months |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Income from continuing operations, a GAAP measure |  | $ | 16.7 |  |  | $ | 27.8 |  |  | $ | 88.3 |  |  | $ | 117.1 |  |
| Restructuring charges, after tax |  |  | 1.5 |  |  |  | (0.2 | ) |  |  | 10.6 |  |  |  | 10.0 |  |
| Special product quality adjustment, after-tax (b) |  |  | (1.3 | ) |  |  | - |  |  |  | (2.8 | ) |  |  | - |  |
| Acquisition costs, after-tax (a) |  |  | 0.1 |  |  |  | 2.8 |  |  |  | 0.8 |  |  |  | 3.0 |  |
| Special legal contingency charge, after-tax (a) |  |  | - |  |  |  | 0.3 |  |  |  | (0.2 | ) |  |  | 4.2 |  |
| Goodwill impairment, after-tax |  |  | 5.0 |  |  |  | - |  |  |  | 5.0 |  |  |  | - |  |
| Asset impairment, after-tax |  |  | 4.5 |  |  |  | - |  |  |  | 4.5 |  |  |  | - |  |
| Loss(Gain) on sale of entity, after-tax (a) |  |  | 0.2 |  |  |  | 0.1 |  |  |  | - |  |  |  | (0.1 | ) |
| Net change in unrealized losses on open future contracts, after tax (a) |  |  | (0.6 | ) |  |  | (0.4 | ) |  |  | 2.5 |  |  |  | (0.4 | ) |
| Other items, net, after tax (a) |  |  | 0.3 |  |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | - |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 26.4 |  |  | $ | 30.2 |  |  | $ | 108.6 |  |  | $ | 133.8 |  |
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP Measure, to Adjusted Earnings per Share From Continuing Operations - Diluted, a Non-GAAP Measure |  |  |  |  |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $ | 0.32 |  |  | $ | 0.51 |  |  | $ | 1.65 |  |  | $ | 2.10 |  |
| Restructuring charges |  |  | 0.03 |  |  |  | - |  |  |  | 0.20 |  |  |  | 0.18 |  |
| Special product quality adjustment, after-tax (b) |  |  | (0.02 | ) |  |  | - |  |  |  | (0.05 | ) |  |  | - |  |
| Acquisition costs, after-tax (a) |  |  | - |  |  |  | 0.05 |  |  |  | 0.01 |  |  |  | 0.05 |  |
| Special legal contingency charge, after-tax (a) |  |  | - |  |  |  | 0.01 |  |  |  | - |  |  |  | 0.08 |  |
| Goodwill impairment, after-tax |  |  | 0.10 |  |  |  | - |  |  |  | 0.10 |  |  |  | - |  |
| Asset impairment, after-tax |  |  | 0.08 |  |  |  | - |  |  |  | 0.08 |  |  |  | - |  |
| Net change in unrealized losses on open future contracts, after-tax (a) |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | 0.05 |  |  |  | (0.01 | ) |
| Other items, net (a) |  |  | 0.01 |  |  |  | (0.01 | ) |  |  | - |  |  |  | - |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  | $ | 0.51 |  |  | $ | 0.55 |  |  | $ | 2.04 |  |  | $ | 2.40 |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |
|  |  | For The Three Months |  |  | For The Twelve Months |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
| Components of Losses and other expenses, net (pre-tax): |  |  | 2011 |  |  |  | 2010 |  |  |  | 2011 |  |  |  | 2010 |  |
| Realized loss/(gains) on settled future contracts (a) |  |  | 0.9 |  |  |  | (0.3 | ) |  |  | (0.1 | ) |  |  | (1.5 | ) |
| Foreign currency exchange (gain) loss (a) |  |  | 1.5 |  |  |  | (0.1 | ) |  |  | 1.4 |  |  |  | 0.4 |  |
| Loss(Gain) on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | 0.1 |  |  |  | (0.8 | ) |  |  | 0.1 |  |
| Special legal contingency charge (b) |  |  | - |  |  |  | 0.5 |  |  |  | (0.4 | ) |  |  | 6.8 |  |
| Acquisition costs, net (b) |  |  | 0.1 |  |  |  | 4.4 |  |  |  | 1.0 |  |  |  | 4.8 |  |
| Net change in unrealized (gains)/losses on open futures contracts (b) |  |  | (1.2 | ) |  |  | (0.6 | ) |  |  | 3.8 |  |  |  | (0.6 | ) |
| Loss(Gain) on sale of entity (b) |  |  | 0.2 |  |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Other items, net (b) |  |  | 0.3 |  |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 1.9 |  |  | $ | 3.9 |  |  | $ | 5.0 |  |  | $ | 10.2 |  |
| (a) Included in segment profit (loss) and adjusted income from continuing operations |  |  |  |  |  |  |  |  |  |  |
| (b) Excluded from segment profit (loss) and adjusted income from continuing operations |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001188112-12-000235:8k_2_02:111]
Reconciliation of Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP Measure, to Earnings per Share from Continuing Operations - Diluted, a GAAP Measure

[0001188112-12-000235:8k_2_02:112]
|  |  | For the Year Ended |  |
|  |  | December 31, |  |
|  |  | 2012 |  |
|  |  | ESTIMATED |  |
| Adjusted earnings per share from continuing operations - diluted |  | $ | 2.20 - $2.60 |  |
| Restructuring charges |  |  | (0.03 | ) |
| GAAP earnings per share from continuing operations - diluted |  | $ | 2.17 - $2.57 |  |

[0001188112-12-000235:8k_2_02:113]
Reconciliation of Net Cash provided by Operating Activities, a GAAP Measure, to Free Cash Flow, a Non-GAAP Measure

[0001188112-12-000235:8k_2_02:114]
|  |  | For The Three Months |  |  | For The Twelve Months |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 78.4 |  |  | $ | 142.2 |  |  | $ | 76.2 |  |  | $ | 185.8 |  |
| Purchase of property, plant and equipment |  |  | (16.1 | ) |  |  | (15.8 | ) |  |  | (43.2 | ) |  |  | (45.8 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | 62.3 |  |  | $ | 126.4 |  |  | $ | 33.0 |  |  | $ | 140.0 |  |
| Calculation of Debt to EBITDA Ratio: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Trailing |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Twelve |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Months to |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | December 31, |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2011 |  |
| EBIT (a) |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 178.5 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 60.4 |  |
| EBITDA (a + b) |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 238.9 |  |
| Total debt at December 31, 2011 (c) |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 465.1 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1.9 |  |

[0001188112-12-000235:8k_2_02:115]
| Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income Taxes, a GAAP Measure |  |
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | December 31, |  |
|  |  | 2011 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 178.5 |  |
| Special product quality adjustment |  |  | (4.3 | ) |
| Items in losses and other expenses, net that are excluded from segment profit |  |  | 4.5 |  |
| Restructuring charges |  |  | 16.0 |  |
| Impairment of Assets |  |  | 7.0 |  |
| Goodwill Impairment |  |  | 7.6 |  |
| Interest expense, net |  |  | 16.8 |  |
| Other expenses, net |  |  | 0.3 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 130.6 |  |

[0001188112-12-000235:8k_2_02:116]
Reconciliation of Reported Revenue Growth, a GAAP measure, to Organic Revenue Growth, a non-GAAP Measure

[0001188112-12-000235:8k_2_02:117]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Translational |  | Net Sales |  |
|  |  | Net Sales |  |  |  |  |  |  |  |  | Currency |  | Growth % |  |
|  |  | For The Three Months |  |  | Net |  |  | Net |  |  | Impact |  |  | Excluding |  |
|  |  | Ended December 31, |  |  | Sales |  |  | Sales |  |  | Favorable |  | Currency |  |
|  |  | 2011 |  |  | 2010 |  |  | Variance |  |  | Growth % |  |  | (Unfavorable) |  | Impact |  |
| Lennox International Inc. and Subsidiaries |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported - a GAAP measure |  | $ | 755.8 |  |  | $ | 762.0 |  |  | $ | (6.2 | ) |  |  | -0.8 | % |  | $ | (3.2 | ) |  |  | -0.4 | % |
| Less: Kysor/Warren acquisition |  |  | (48.8 | ) |  |  | - |  |  |  | (48.8 | ) |  |  |  |  |  |  | 1.2 |  |  |  |  |  |
| Net Sales, excluding Kysor/Warren |  | $ | 707.0 |  |  | $ | 762.0 |  |  | $ | (55.0 | ) |  |  | -7.2 | % |  | $ | (2.0 | ) |  |  | -7.0 | % |
| Refrigeration Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported - a GAAP measure |  | $ | 188.9 |  |  | $ | 139.1 |  |  | $ | 49.8 |  |  |  | 35.8 | % |  | $ | (1.1 | ) |  |  | 36.6 | % |
| Less: Kysor/Warren acquisition |  |  | (48.8 | ) |  |  | - |  |  |  | (48.8 | ) |  |  |  |  |  |  | 1.2 |  |  |  |  |  |
| Net Sales, excluding Kysor/Warren |  | $ | 140.1 |  |  | $ | 139.1 |  |  | $ | 1.0 |  |  |  | 0.7 | % |  | $ | 0.1 |  |  |  | 0.6 | % |

[0001188112-12-000235:8k_2_02:118]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Translational |  |  | Net Sales |  |
|  |  | Net Sales |  |  |  |  |  |  |  |  | Currency |  |  | Growth % |  |
|  |  | For The Twelve Months |  |  | Net |  |  | Net |  |  | Impact |  |  | Excluding |  |
|  |  | Ended December 31, |  |  | Sales |  |  | Sales |  |  | Favorable |  |  | Currency |  |
|  |  | 2011 |  |  | 2010 |  |  | Variance |  |  | Growth % |  |  | (Unfavorable) |  |  | Impact |  |
| Lennox International Inc. and Subsidiaries |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported - a GAAP measure |  | $ | 3,303.6 |  |  | $ | 3,096.4 |  |  | $ | 207.2 |  |  |  | 6.7 | % |  | $ | 51.5 |  |  |  | 5.0 | % |
| Less: Kysor/Warren acquisition |  |  | (213.9 | ) |  |  | - |  |  |  | (213.9 | ) |  |  |  |  |  |  | (0.8 | ) |  |  |  |  |
| Net Sales, excluding Kysor/Warren |  | $ | 3,089.7 |  |  | $ | 3,096.4 |  |  | $ | (6.7 | ) |  |  | -0.2 | % |  | $ | 50.7 |  |  |  | -1.9 | % |
| Refrigeration Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported - a GAAP measure |  | $ | 805.2 |  |  | $ | 550.9 |  |  | $ | 254.3 |  |  |  | 46.2 | % |  | $ | 29.2 |  |  |  | 40.9 | % |
| Less: Kysor/Warren acquisition |  |  | (213.9 | ) |  |  | - |  |  |  | (213.9 | ) |  |  |  |  |  |  | (0.8 | ) |  |  |  |  |
| Net Sales, excluding Kysor/Warren |  | $ | 591.3 |  |  | $ | 550.9 |  |  | $ | 40.4 |  |  |  | 7.3 | % |  | $ | 28.4 |  |  |  | 2.2 | % |

[0001188112-12-000235:8k_2_02:119]
| Reconciliation of Reported Refrigeration Segment Profit Margin to Organic Segment Profit Margin |  |  |  |  |  |  |  |
|  |  | For the Three Months Ended December 31, 2011 |  |  | For the Three Months Ended December 31, 2010 |  |
|  |  |  |  |  |  |  |  | Segment |  |  |  |  |  |  |  |  | Segment |  |
|  |  | Net |  |  | Segment |  |  | Profit |  |  | Net |  |  | Segment |  | Profit |  |
|  |  | Sales |  |  | Profit |  |  | Margin |  |  | Sales |  |  | Profit |  |  | Margin |  |
| Refrigeration Segment, as reported |  | $ | 188.9 |  |  | $ | 22.1 |  |  |  | 11.7 | % |  | $ | 139.1 |  |  | $ | 13.9 |  |  |  | 10.0 | % |
| Less: Kysor/Warren acquisition |  |  | (48.8 | ) |  |  | (2.3 | ) |  |  | -4.7 | % |  |  | - |  |  |  | - |  |  |  | - |  |
| Refrigeration Segment, excluding Kysor/Warren |  | $ | 140.1 |  |  | $ | 19.8 |  |  |  | 14.1 | % |  | $ | 139.1 |  |  | $ | 13.9 |  |  |  | 10.0 | % |
|  |  | For the Twelve Months Ended December 31, 2011 |  |  | For the Twelve Months Ended December 31, 2010 |  |
|  |  |  |  |  |  |  |  |  |  | Segment |  |  |  |  |  |  |  |  |  |  | Segment |  |
|  |  | Net |  |  | Segment |  |  | Profit |  |  | Net |  |  | Segment |  | Profit |  |
|  |  | Sales |  |  | Profit |  |  | Margin |  |  | Sales |  |  | Profit |  |  | Margin |  |
| Refrigeration Segment, as reported |  | $ | 805.2 |  |  | $ | 77.5 |  |  |  | 9.6 | % |  | $ | 550.9 |  |  | $ | 61.4 |  |  |  | 11.1 | % |
| Less: Kysor/Warren acquisition |  |  | (213.9 | ) |  |  | (2.1 | ) |  |  | -1.0 | % |  |  | - |  |  |  | - |  |  |  | - |  |
| Refrigeration Segment, excluding Kysor/Warren |  | $ | 591.3 |  |  | $ | 75.4 |  |  |  | 12.8 | % |  | $ | 550.9 |  |  | $ | 61.4 |  |  |  | 11.1 | % |

[0001188112-12-000235:8k_2_02:120]
Reconciliation of Operational Working Capital, a Non-GAAP Measure, to GAAP Balance Sheet Line Items

[0001188112-12-000235:8k_2_02:121]
|  |  |  |  |  | December 31, |  |  |  |  |  | December 31, |  |
|  |  |  |  |  | 2011 |  |  |  |  |  | 2010 |  |
|  |  | December 31, |  |  | Trailing |  |  | December 31, |  |  | Trailing |  |
|  |  | 2011 (c) |  |  | 12 Mo. Avg. (c) |  |  | 2010 |  |  | 12 Mo. Avg. |  |
| Accounts and Notes Receivable, Net |  | $ | 362.4 |  |  |  |  |  | $ | 384.8 |  |  |  |  |
| Asset Securitization |  |  | - |  |  |  |  |  |  | - |  |  |  |  |
| Allowance for Doubtful Accounts |  |  | 9.7 |  |  |  |  |  |  | 12.8 |  |  |  |  |
| Accounts and Notes Receivable, Gross |  |  | 372.1 |  |  | $ | 416.8 |  |  |  | 397.6 |  |  | $ | 408.4 |  |
| Inventories |  |  | 310.9 |  |  |  |  |  |  |  | 286.2 |  |  |  |  |  |
| Excess of Current Cost Over Last-in, First-out |  |  | 73.9 |  |  |  |  |  |  |  | 70.8 |  |  |  |  |  |
| Inventories as Adjusted |  |  | 384.8 |  |  |  | 458.3 |  |  |  | 357.0 |  |  |  | 400.4 |  |
| Accounts Payable |  |  | (255.7 | ) |  |  | (289.4 | ) |  |  | (273.8 | ) |  |  | (281.5 | ) |
| Operating Working Capital (a) |  |  | 501.2 |  |  |  | 585.7 |  |  |  | 480.8 |  |  |  | 527.3 |  |
| Net Sales, Trailing Twelve Months (b) |  |  | 3,089.7 |  |  |  | 3,089.7 |  |  |  | 3,096.4 |  |  |  | 3,096.4 |  |
| Operational Working Capital Ratio (a / b) |  |  | 16.2 | % |  |  | 19.0 | % |  |  | 15.5 | % |  |  | 17.0 | % |

[0001188112-12-000235:8k_2_02:122]
| (c) | Excludes the impact of the Kysor/Warren acquisition completed in January 2011. Including the impact of the Kysor/Warren acquisition to the December 31, 2011 operational working capital items above would increase Accounts and Notes Receivable, Gross from $372.1 to $420.8, Inventories as Adjusted from $384.8 to $410.4 and Accounts Payable from $(255.7) to $(277.0). Net Sales, Trailing Twelve Months would increase $213.9 (representing approximately eleven and a half months of Net Sales) to $3,303.6 resulting in an Operational Working Capital Ratio of 16.8%. |
