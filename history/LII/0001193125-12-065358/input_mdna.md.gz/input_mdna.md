# LII MD&A — 0001193125-12-065358


## mdna

[0001193125-12-065358:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001193125-12-065358:mdna:2]
The following discussions should be read in conjunction with the other sections of this report, including the consolidated financial
statements and related notes contained in Item 8 of this Annual Report on Form 10-K.

[0001193125-12-065358:mdna:3]
Overview

[0001193125-12-065358:mdna:4]
We operate in four reportable business segments of the heating, ventilation, air conditioning and refrigeration, (“HVACR”)
industry. Our reportable segments are Residential Heating & Cooling, Commercial

[0001193125-12-065358:mdna:5]
Heating & Cooling, Service Experts and Refrigeration. For more detailed information regarding our reportable segments, see Note 21 in the Notes to Consolidated Financial Statements.

[0001193125-12-065358:mdna:6]
Our products and services are sold through a combination of distributors, independent and company-owned dealer service
centers, other installing contractors, wholesalers, manufacturers’ representatives, original equipment manufacturers and national accounts. The demand for our products and services is seasonal and dependent on the weather. Warmer than normal
summer temperatures generate strong demand for replacement air conditioning and refrigeration products and services and colder than normal winter temperatures have the same effect on heating products and services. Conversely, cooler than normal
summers and warmer than normal winters depress HVACR sales and services. In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability
of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence. A substantial portion of the sales in each of our business segments is attributable to replacement
business, with the balance comprised of new construction business.

[0001193125-12-065358:mdna:7]
The principal elements of cost of goods sold in our
manufacturing operations are components, raw materials, factory overhead, labor and estimated costs of warranty expense. In our Service Experts segment, the principal components of cost of goods sold are equipment, parts and supplies and labor. The
principal raw materials used in our manufacturing processes are steel, copper and aluminum. In recent years, the volatility of commodity prices and related components has impacted us and the HVACR industry in general. We seek to mitigate the impact
of higher commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into
futures contracts and fixed forward contracts.

[0001193125-12-065358:mdna:8]
In 2010, our residential businesses benefited from various government tax
credits, both in the United States and Canada, which motivated customers to purchase high-efficiency system replacements. In addition to the reduction of tax credits for high-efficiency heating and cooling products in 2011, overall consumer
sentiment declined, which resulted in our customers shifting from entire system replacements to replacement of components. This shift reduced sales volumes and resulted in unfavorable product mix in our Residential Heating & Cooling and
Service Experts businesses. However, we did see a positive shift in volume and mix in our Commercial Heating & Cooling segment. The increase in volume can be attributed to a stronger commercial HVAC market in the United States in 2011
compared to 2010, as well as organic growth in Europe through focused efforts to expand our share in the markets we serve. Our Refrigeration business also performed well in 2011 and grew both organically and through the Kysor/Warren acquisition. We
acquired Kysor/Warren, a leading manufacturer of refrigerated systems and display cases for supermarkets, from The Manitowoc Company in January 2011. This acquisition extended the value chain for us directly to food retail and supermarket customers.

[0001193125-12-065358:mdna:9]
Our margins were negatively affected by product mix in 2011 from our Residential Heating & Cooling and Service
Experts business discussed above. Adding to the negative effect from mix, commodity prices put a strain on raw material and component costs in all of our HVACR businesses. We are managing our pricing structure to offset a large portion of our
commodity price increases on raw materials. We believe we are managing our controllable costs well and continue to look for ways to lower this cost structure through manufacturing and sourcing excellence.

[0001193125-12-065358:mdna:10]
Company Highlights

[0001193125-12-065358:mdna:11]
|  | • | Net sales for 2011 were $3,303.6 million, compared to $3,096.4 million in 2010 and were favorably impacted by the Kysor/Warren acquisition, favorable price and mix in our Commercial Heating & Cooling and Refrigeration segments, and strong volume growth in Commercial Heating & Cooling. Partially offsetting these favorable items was unfavorable volume and mix from our Residential Heating & Cooling and Service Experts segments. |

[0001193125-12-065358:mdna:12]
|  | • | Operational income from continuing operations for 2011 was $147.7 million compared to $190.4 million for 2010. The decline in operational income was primarily due to lower volumes in our Residential Heating & Cooling and Service Experts segments and lower margins from increased commodity costs |

[0001193125-12-065358:mdna:13]
|  | from raw materials and components and lower price and mix from our Residential Heating & Cooling Segment. |

[0001193125-12-065358:mdna:14]
|  | • | Net income for 2011 was $88.3 million compared to $116.2 million in 2010. Diluted earnings per share from continuing operations was $1.65 per share in 2011 compared to $2.10 per share in 2010. |

[0001193125-12-065358:mdna:15]
|  | • | We generated $76.2 million of cash flow from operating activities in 2011 compared to $185.8 million in 2010. |

[0001193125-12-065358:mdna:16]
|  | • | During 2011, we returned $119.7 million to shareholders through share repurchases. |

[0001193125-12-065358:mdna:17]
Results of Operations

[0001193125-12-065358:mdna:18]
The following table provides a summary of our
financial results, including information presented as a percentage of net sales (dollars in millions):

[0001193125-12-065358:mdna:19]
|  |  | For the Years Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
|  |  | Dollars |  |  | Percent |  |  | Dollars |  |  | Percent |  |  | Dollars |  |  | Percent |  |
| Net sales |  | $ | 3,303.6 |  |  |  | 100.0 | % |  | $ | 3,096.4 |  |  |  | 100.0 | % |  | $ | 2,847.5 |  |  |  | 100.0 | % |
| Cost of goods sold |  |  | 2,470.0 |  |  |  | 74.8 |  |  |  | 2,204.6 |  |  |  | 71.2 |  |  |  | 2,059.4 |  |  |  | 72.3 |  |
| Gross profit |  |  | 833.6 |  |  |  | 25.2 |  |  |  | 891.8 |  |  |  | 28.8 |  |  |  | 788.1 |  |  |  | 27.7 |  |
| Selling, general and administrative expenses |  |  | 659.9 |  |  |  | 20.0 |  |  |  | 685.7 |  |  |  | 22.1 |  |  |  | 644.9 |  |  |  | 22.6 |  |
| Losses (gains) and other expenses, net |  |  | 5.0 |  |  |  | 0.1 |  |  |  | 10.2 |  |  |  | 0.3 |  |  |  | (6.6 | ) |  |  | (0.2 | ) |
| Restructuring charges |  |  | 16.0 |  |  |  | 0.5 |  |  |  | 15.6 |  |  |  | 0.5 |  |  |  | 41.5 |  |  |  | 1.5 |  |
| Impairment of assets |  |  | 7.0 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | 6.4 |  |  |  | 0.2 |  |
| Goodwill impairment |  |  | 7.6 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Income from equity method investments |  |  | (9.6 | ) |  |  | (0.3 | ) |  |  | (10.1 | ) |  |  | (0.3 | ) |  |  | (7.3 | ) |  |  | (0.2 | ) |
| Operational income from continuing operations |  | $ | 147.7 |  |  |  | 4.5 | % |  | $ | 190.4 |  |  |  | 6.2 | % |  | $ | 109.2 |  |  |  | 3.8 | % |
| Net income |  | $ | 88.3 |  |  |  | 2.7 | % |  | $ | 116.2 |  |  |  | 3.8 | % |  | $ | 51.1 |  |  |  | 1.8 | % |

[0001193125-12-065358:mdna:20]
The following table sets forth net sales by geographic market (dollars in millions):

[0001193125-12-065358:mdna:21]
|  |  | For the Years Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
|  |  | Dollars |  |  | Percent |  |  | Dollars |  |  | Percent |  |  | Dollars |  |  | Percent |  |
| Geographic Market: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 2,370.8 |  |  |  | 71.8 | % |  | $ | 2,255.4 |  |  |  | 72.8 | % |  | $ | 2,033.1 |  |  |  | 71.4 | % |
| Canada |  |  | 329.2 |  |  |  | 10.0 |  |  |  | 336.6 |  |  |  | 10.9 |  |  |  | 327.0 |  |  |  | 11.5 |  |
| International |  |  | 603.6 |  |  |  | 18.2 |  |  |  | 504.4 |  |  |  | 16.3 |  |  |  | 487.4 |  |  |  | 17.1 |  |
| Total net sales |  | $ | 3,303.6 |  |  |  | 100.0 | % |  | $ | 3,096.4 |  |  |  | 100.0 | % |  | $ | 2,847.5 |  |  |  | 100.0 | % |

[0001193125-12-065358:mdna:22]
Year Ended December 31, 2011 Compared to Year Ended December 31, 2010 —
Consolidated Results

[0001193125-12-065358:mdna:23]
Net Sales

[0001193125-12-065358:mdna:24]
Net sales increased 7% for 2011 as compared to 2010. Excluding the impact from the Kysor/Warren acquisition in January 2011, our net sales
were flat year over year. Our price and mix were up 1% while sales volume was down 3% in the comparable period. The decline in volume was predominantly in our Residential Heating & Cooling and Service Experts segments, partially offset by
volume growth in our Commercial Heating & Cooling. Changes in foreign currency exchange rates favorably impacted net sales by 2%. Excluding the favorable impact from the Kysor/Warren acquisition and foreign currency exchange rates, our net
sales for 2011 were down 2% compared to 2010.

[0001193125-12-065358:mdna:25]
Gross Profit

[0001193125-12-065358:mdna:26]
Gross profit margins declined $58 million compared to 2010, resulting in a 360 basis point decline to 25.2% for 2011, compared to gross
profit margins of 28.8% in 2010. The impact from commodity costs on both raw material and components contributed approximately 160 basis points to the decline with freight and distribution contributing 60 basis points to the decline in gross profit
margin. Price and mix were neutral to gross profit as our price increases in 2011 offset the margin declines from product mix. Additionally, the Kysor/Warren acquisition has negatively impacted our gross profit margin by approximately 110 basis
points in 2011 due to lower margins.

[0001193125-12-065358:mdna:27]
Selling, General and Administrative Expenses

[0001193125-12-065358:mdna:28]
Selling, General & Administrative (“SG&A”) expenses decreased by $26 million in 2011 compared to 2010, and as a
percentage of net sales, SG&A expenses declined to 20% in 2011 from 22% in 2010. Excluding the Kysor/Warren acquisition, the decrease in SG&A was principally due to a $37 million decline in variable compensation, as well as an additional $17
million from general cost control initiatives.

[0001193125-12-065358:mdna:29]
Losses (Gains) and Other Expenses, Net

[0001193125-12-065358:mdna:30]
Losses (gains) and other expenses, net for 2011 and 2010 included the following (in millions):

[0001193125-12-065358:mdna:31]
|  |  | For the YearsEndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Realized gains on settled futures contracts |  | $ | (0.1 | ) |  | $ | (1.5 | ) |
| Unrealized losses (gains) on unsettled futures contracts |  |  | 3.8 |  |  |  | (0.6 | ) |
| Special legal contingency charge |  |  | (0.4 | ) |  |  | 6.8 |  |
| Acquisition expenses, net |  |  | 1.0 |  |  |  | 4.8 |  |
| Foreign currency exchange losses |  |  | 1.4 |  |  |  | 0.4 |  |
| Other items, net |  |  | (0.7 | ) |  |  | 0.3 |  |
| Losses (gains) and other expenses, net |  | $ | 5.0 |  |  | $ | 10.2 |  |

[0001193125-12-065358:mdna:32]
The change in losses (gains) and other expenses, net is primarily due to the special legal contingency
charge related to the class action lawsuit that concluded in the second quarter of 2011 and the unrealized losses on unsettled future commodity contracts. Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on
the special legal contingency charge and Note 10 for more information on the unrealized losses on unsettled future commodity contracts.

[0001193125-12-065358:mdna:33]
Restructuring Charges

[0001193125-12-065358:mdna:34]
Restructuring charges were $16 million in 2011 compared to $16 million in 2010. The charges in 2011 were primarily from corporate restructuring charges that included the termination of our corporate
airplane lease, closure of our aviation department, and reorganization of certain support functions initiated in the third quarter of 2011. Additionally, we had charges related to the reorganization of the Service Experts administrative functions
and management structure initiated in the fourth quarter of 2010. The restructuring charges in 2010 were primarily related to the exit of the contract coil and OEM coil manufacturing in Australia and consolidation of our Parets, Spain manufacturing
facility into our Genas, France facility in our Refrigeration segment. Additionally, 2010 charges included the relocation of a research and development facility and administrative offices from California to Tennessee in our Residential Heating &
Cooling segment. The remaining restructuring charges from 2010 were minor charges from various open projects initiated in 2010 and prior years. Refer to Note 18 in Notes to the Consolidated Financial Statements for more information.

[0001193125-12-065358:mdna:35]
Impairment of Assets and Goodwill Impairment

[0001193125-12-065358:mdna:36]
Due to the prolonged uncertainty in the recovery of the residential new construction market, our long-term outlook for our Hearth reporting unit declined. As a result, we began to pursue strategic
alternatives for this

[0001193125-12-065358:mdna:37]
reporting unit. Our Hearth reporting unit is heavily dependent on the residential new construction market; more so than our other reporting units due to its product offerings: fireplaces, stoves
and venting products. As a result of our lowered expectations for this reporting unit, we determined that our long-lived assets and goodwill should be tested for impairment in the fourth quarter of 2011. As a result of these impairments tests, we
recorded $6.7 million in long-lived asset impairments and $7.6 million in goodwill impairment in 2011. We also recorded $0.3 million in machinery and equipment impairment for assets that are no longer in use. No impairment charges were
recorded in 2010.

[0001193125-12-065358:mdna:38]
Income from Equity Method Investments

[0001193125-12-065358:mdna:39]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.
Income from equity method investments decreased slightly to $9.6 million in 2011 as compared to $10.1 million in 2010.

[0001193125-12-065358:mdna:40]
Interest Expense, net

[0001193125-12-065358:mdna:41]
Interest expense, net increased to $17 million in 2011 compared to $13 million in 2010. The increase in interest expense was primarily attributable to the issuance of $200 million in senior unsecured
notes in May of 2010 at a higher fixed interest rate of 4.91% and higher average domestic credit facility borrowings resulting from the Kysor/Warren acquisition.

[0001193125-12-065358:mdna:42]
Income Taxes

[0001193125-12-065358:mdna:43]
The income tax provision was $42
million in 2011 as compared to $60 million in 2010. The effective tax rate was 32.4% for 2011 as compared to 33.7% for 2010. Our effective rates differ from the statutory federal rate of 35% for certain items, such as tax credits, foreign taxes at
rates other than 35%, and other permanent items.

[0001193125-12-065358:mdna:44]
Year Ended December 31, 2011 Compared to Year Ended
December 31, 2010 — Results by Segment

[0001193125-12-065358:mdna:45]
Residential Heating & Cooling

[0001193125-12-065358:mdna:46]
The following table details our Residential Heating & Cooling segment’s net sales and profit for 2011 and 2010 (dollars in
millions):

[0001193125-12-065358:mdna:47]
|  |  | Years EndedDecember 31, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 1,341.0 |  |  | $ | 1,417.4 |  |  | $ | (76.4 | ) |  |  | (5.4 | )% |
| Profit |  |  | 75.1 |  |  |  | 132.3 |  |  |  | (57.2 | ) |  |  | (43.2 | ) |
| % of net sales |  |  | 5.6 | % |  |  | 9.3 | % |  |  |  |  |  |  |  |  |

[0001193125-12-065358:mdna:48]
Residential Heating & Cooling net sales declined by 5% in 2011 compared to 2010. Sales volumes
declined by 4% and price and mix were down by 1% in 2011 as compared to 2010. Our Residential Heating & Cooling segment’s sales volumes and mix were negatively affected by consumers moving to lower efficient unit purchases from high
efficiency system replacements, driven by a significant reduction in the federal tax credits in 2011, the availability of R22 refrigerant outdoor condensing units, and consumer weakness.

[0001193125-12-065358:mdna:49]
Segment profit decreased $57 million due to $32 million in increased commodity costs from both raw materials and components with our
component cost commodity increases partially offset by material cost savings, $20 million in lower sales volumes, $15 million in higher freight and distribution charges, $11 million in unfavorable price and mix, and $4 million in unfavorable
warranty adjustment. A $26 million decline in SG&A expenses partially offset the decreases in segment profit. The decline in SG&A expenses was primarily due to lower variable compensation and general cost control.

[0001193125-12-065358:mdna:50]
Commercial Heating & Cooling

[0001193125-12-065358:mdna:51]
The following table details our Commercial Heating & Cooling segment’s net sales and profit for 2011 and 2010 (dollars in
millions):

[0001193125-12-065358:mdna:52]
|  |  | Years EndedDecember 31, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 696.0 |  |  | $ | 620.0 |  |  | $ | 76.0 |  |  |  | 12.3 | % |
| Profit |  |  | 79.4 |  |  |  | 69.3 |  |  |  | 10.1 |  |  |  | 14.6 |  |
| % of net sales |  |  | 11.4 | % |  |  | 11.2 | % |  |  |  |  |  |  |  |  |

[0001193125-12-065358:mdna:53]
Our Commercial Heating & Cooling business experienced a 12% increase in net
sales in 2011 compared to 2010 primarily due to an increase in our replacement business which resulted in a 7% increase in sales volume. Additionally, our price and mix increased 3% in 2011 compared to 2010. Mix was driven by strength in our high
efficiency premier products like Strategos® and Energence®. Changes in foreign currency exchange rates also favorably impacted net sales by 2% in 2011.

[0001193125-12-065358:mdna:54]
Segment profit in 2011 increased $10 million from 2010. Segment profit increased as a result of the impact of higher sales volume by $13 million, positive price and mix by $10 million, and $4 million from
productivity initiatives. Partially offsetting these increases to segment profit were $17 million in increased commodity costs from both raw materials and components with our component cost commodity increases partially offset by material cost
savings.

[0001193125-12-065358:mdna:55]
Service Experts

[0001193125-12-065358:mdna:56]
The following table details our Service Experts segment’s net sales and profit for 2011 and 2010 (dollars in millions):

[0001193125-12-065358:mdna:57]
|  |  | Years EndedDecember 31, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 528.6 |  |  | $ | 590.3 |  |  | $ | (61.7 | ) |  |  | (10.5 | )% |
| Profit |  |  | 1.5 |  |  |  | 19.3 |  |  |  | (17.8 | ) |  |  | (92.2 | ) |
| % of net sales |  |  | 0.3 | % |  |  | 3.3 | % |  |  |  |  |  |  |  |  |

[0001193125-12-065358:mdna:58]
Service Experts net sales declined 10% in 2011 compared to 2010. Sales volumes contributed 13% to the
decline in sales. Offsetting the decline in sales volume were 2% in favorable mix and 1% from favorable foreign currency exchange rates. The decline in this segment’s sales volume was primarily due to a decline in residential HVAC equipment
installations.

[0001193125-12-065358:mdna:59]
Segment profit decreased $18 million due to a $28 million decline in volume, partially offset by a
$10 million decline in SG&A expenses. The decline in SG&A expenses was primarily due to lower variable compensation and general cost control.

[0001193125-12-065358:mdna:60]
Refrigeration

[0001193125-12-065358:mdna:61]
The following table details our
Refrigeration segment’s net sales and profit for 2011 and 2010 (dollars in millions):

[0001193125-12-065358:mdna:62]
|  |  | Years EndedDecember 31, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 805.2 |  |  | $ | 550.9 |  |  | $ | 254.3 |  |  |  | 46.2 | % |
| Profit |  |  | 77.5 |  |  |  | 61.4 |  |  |  | 16.1 |  |  |  | 26.2 |  |
| % of net sales |  |  | 9.6 | % |  |  | 11.1 | % |  |  |  |  |  |  |  |  |

[0001193125-12-065358:mdna:63]
Net sales, excluding Kysor/Warren, increased 7% due to higher price and mix of 2% and favorable foreign
currency exchange rates of 5%. The Kysor/Warren acquisition contributed 39% to the increase in net sales.

[0001193125-12-065358:mdna:64]
Segment profit increased by $16 million, including a $15 million positive impact from price
and mix, $2 million in favorable foreign exchange rates, and a $5 million decline in SG&A expenses. Partially offsetting these increases in segment profit were declines of $4 million from increased commodity costs from both raw materials
and components with our component cost commodity increases more than offset by material cost savings, $3 million decline in volume, and $2 million in higher freight and distribution charges. The remaining segment profit increase was related to the
Kysor/Warren acquisition.

[0001193125-12-065358:mdna:65]
Corporate and Other

[0001193125-12-065358:mdna:66]
Corporate and other expenses were $54 million in 2011, down from $66 million in 2010. The decrease was primarily driven by a $12 million decline in compensation expense, primarily incentive compensation,
for 2011.

[0001193125-12-065358:mdna:67]
Year Ended December 31, 2010 Compared to Year Ended December 31, 2009 — Consolidated
Results

[0001193125-12-065358:mdna:68]
Net Sales

[0001193125-12-065358:mdna:69]
Sales increased 8.7% for 2010 as compared to 2009 due to increased sales volumes of 5%, primarily driven by growth across all four business segments. Volume improved in all four reportable business
segments, led by strength in Residential Heating & Cooling and Service Experts. Price and mix of approximately 2% also had a favorable impact on sales. Changes in foreign currency exchange rates favorably impacted net sales by 2%.

[0001193125-12-065358:mdna:70]
Gross Profit

[0001193125-12-065358:mdna:71]
Gross profit margins improved approximately 110 basis points to 28.8% for 2010, compared to gross profit margins of 27.7% in 2009. This improvement was primarily driven by lower product costs from
material savings and manufacturing efficiencies of approximately 140 basis points. Gross profit margin comparisons were also favorably impacted by 60 basis points for expenses related to a product quality issue that were recorded in 2009 with no
such expenses in 2010. Partially offsetting these positive impacts to gross profit margins were commodities headwinds of 50 basis points and increased freight and distribution expenses that decreased gross profit margins by approximately 50 basis
points, primarily in the Residential Heating & Cooling segment.

[0001193125-12-065358:mdna:72]
Selling, General and Administrative Expenses

[0001193125-12-065358:mdna:73]
SG&A expenses increased by $40.8 million in 2010 as compared to 2009, and as a percentage of sales, SG&A expenses
were down 50 basis points from 22.6% in 2009 to 22.1% in 2010. SG&A expenses increased $16 million due to increased variable incentive compensation driven by improved financial performance and $35 million related to increased variable selling,
advertising, and promotion expenses in support of our sales growth. These increases were partially offset by lower bad debt expense and pension costs.

[0001193125-12-065358:mdna:74]
Losses (Gains) and Other Expenses, Net

[0001193125-12-065358:mdna:75]
Losses (gains) and other expenses,
net for 2010 and 2009 included the following (in millions):

[0001193125-12-065358:mdna:76]
|  |  | For the YearsEndedDecember 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Realized (gains) losses on settled futures contracts |  | $ | (1.5 | ) |  | $ | 3.7 |  |
| Unrealized gains on unsettled futures contracts |  |  | (0.6 | ) |  |  | (7.1 | ) |
| Gain on the disposal of a business, net |  |  | (0.1 | ) |  |  | (4.1 | ) |
| Special legal contingency charge |  |  | 6.8 |  |  |  | — |  |
| Acquisition expenses |  |  | 4.8 |  |  |  | — |  |
| Foreign currency exchange losses |  |  | 0.4 |  |  |  | 0.7 |  |
| Other items, net |  |  | 0.4 |  |  |  | 0.2 |  |
| Losses (gains) and other expenses, net |  | $ | 10.2 |  |  | $ | (6.6 | ) |

[0001193125-12-065358:mdna:77]
The change in gains and losses on settled futures contracts was primarily due to increases
in commodity prices relative to the futures contract prices during 2010 as compared to 2009. Conversely, the change in unrealized gains related to unsettled futures contracts was primarily due to lower commodity prices relative to the futures
contract prices for those contracts. For more information, see Note 10 in the Notes to the Consolidated Financial Statements. For more information regarding the special legal contingency charge, see Note 12 in the Notes to the Consolidated Financial
Statements. Acquisition expenses relate to the Kysor/Warren acquisition. For more information, see Note 3 in the Notes to the Consolidated Financial Statements.

[0001193125-12-065358:mdna:78]
Restructuring Charges

[0001193125-12-065358:mdna:79]
Restructuring charges were $15.6 million in 2010
compared to $41.5 million in 2009. The lower restructuring charges in 2010 were primarily due to a smaller number of large projects in 2010. The restructuring charges in 2010 primarily consisted of manufacturing rationalization projects in Australia
in the Refrigeration segment which totaled $8.6 million, as well as administrative reorganizations in our Service Experts segment which totaled $2.1 million. The remaining restructuring charges in 2010 were primarily related to projects announced
prior to 2010. Restructuring charges in 2009 primarily consisted of three large manufacturing rationalization projects totaling $25.2 million and $11.3 million in various corporate and business unit administrative reorganizations. For a detailed
discussion regarding restructuring activities, see Note 18 in the Notes to Consolidated Financial Statements.

[0001193125-12-065358:mdna:80]
Income from
Equity Method Investments

[0001193125-12-065358:mdna:81]
Investments over which we do not exercise control but have significant influence are accounted
for using the equity method of accounting. Income from equity method investments increased to $10.1 million in 2010 as compared to $7.3 million in 2009 primarily due to the improved performance of our U.S. joint venture in compressor manufacturing,
which experienced increased sales and profitability.

[0001193125-12-065358:mdna:82]
Interest Expense, net

[0001193125-12-065358:mdna:83]
Interest expense, net increased to $12.8 million in 2010 as compared to $8.2 million in 2009. The increase in interest expense was
primarily attributable to higher debt levels, and the issuance in May 2010 of $200 million of our senior unsecured notes at 4.91% with a higher interest rate than our revolver.

[0001193125-12-065358:mdna:84]
Income Taxes

[0001193125-12-065358:mdna:85]
The income tax provision was $59.5 million in 2010 as compared to $39.1 million in 2009. The effective tax rate was 33.7% for 2010 as compared to 38.8% for 2009. Our effective rates differ from the
statutory federal rate of 35% for certain items, such as state and local taxes, non-deductible expenses, foreign operating losses for which no tax benefits have been recognized and foreign taxes at rates other than 35%.

[0001193125-12-065358:mdna:86]
Discontinued Operations

[0001193125-12-065358:mdna:87]
During 2009 and 2010, we sold twelve service centers. The pre-tax operating loss from discontinued operations was $1.1 million in 2010 as compared to $13.1 million in 2009. Included in the 2009 loss from
discontinued operations was an impairment charge of $2.7 million related to service centers where the estimated selling price of the assets was below the net book value of those assets, gains on disposal of assets and liabilities of $2.3 million,
and a write-off of $4.0 million of goodwill related to the sale of these service centers.

[0001193125-12-065358:mdna:88]
Year Ended December 31, 2010 Compared to Year Ended December 31,
2009 — Results by Segment

[0001193125-12-065358:mdna:89]
Residential Heating & Cooling

[0001193125-12-065358:mdna:90]
The following table details our Residential Heating & Cooling segment’s net sales and profit for 2010 and 2009 (dollars in
millions):

[0001193125-12-065358:mdna:91]
|  |  | Years EndedDecember 31, |  |  |  |  |  |  |  |
|  |  | 2010 |  |  | 2009 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 1,417.4 |  |  | $ | 1,293.5 |  |  | $ | 123.9 |  |  |  | 9.6 | % |
| Profit |  |  | 132.3 |  |  |  | 111.7 |  |  |  | 20.6 |  |  |  | 18.4 |  |
| % of net sales |  |  | 9.3 | % |  |  | 8.6 | % |  |  |  |  |  |  |  |  |

[0001193125-12-065358:mdna:92]
The increase in sales was due to the recovery of the U.S. residential end markets, primarily the
replacement market. Sales volumes increased net sales by 8% in 2010 as compared to 2009, while price and mix were relatively flat at a 1% increase. The positive impact of changes in foreign currency exchange rates also increased sales by 1%.

[0001193125-12-065358:mdna:93]
Segment profit increased $20.6 million, including $25 million due to the increase in sales and $14 million due to
material savings and manufacturing efficiencies partially offset by commodities headwinds of $9 million. These were partially offset by higher SG&A expenses of $14 million consisting primarily of increased variable selling expenses and incentive
compensation.

[0001193125-12-065358:mdna:94]
Commercial Heating & Cooling

[0001193125-12-065358:mdna:95]
The following table details our Commercial Heating & Cooling segment’s net sales and profit for 2010 and 2009 (dollars in
millions):

[0001193125-12-065358:mdna:96]
|  |  | Years EndedDecember 31, |  |  |  |  |  |  |  |
|  |  | 2010 |  |  | 2009 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 620.0 |  |  | $ | 594.6 |  |  | $ | 25.4 |  |  |  | 4.3 | % |
| Profit |  |  | 69.3 |  |  |  | 49.3 |  |  |  | 20.0 |  |  |  | 40.6 |  |
| % of net sales |  |  | 11.2 | % |  |  | 8.3 | % |  |  |  |  |  |  |  |  |

[0001193125-12-065358:mdna:97]
Our Commercial Heating & Cooling business experienced increased sales volumes of nearly 3%
during 2010 primarily due to introductions of energy efficient products and an increase in planned replacement business at national retail accounts, as well as strong growth in the schools market. Price and mix were favorable by 2%. Foreign currency
exchange rates decreased sales by 1%.

[0001193125-12-065358:mdna:98]
Segment profit increased $20.0 million, including nearly $19 million due to the increase
in net sales and $3 million due to material savings and manufacturing efficiencies. These increases were partially offset by higher SG&A expenses of $3 million consisting primarily of increased variable selling expenses and incentive
compensation.

[0001193125-12-065358:mdna:99]
Service Experts

[0001193125-12-065358:mdna:100]
The following table details our Service Experts segment’s net sales and profit for 2010 and 2009 (dollars in millions):

[0001193125-12-065358:mdna:101]
|  |  | Years EndedDecember 31, |  |  |  |  |  |  |  |
|  |  | 2010 |  |  | 2009 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 590.3 |  |  | $ | 535.4 |  |  | $ | 54.9 |  |  |  | 10.3 | % |
| Profit |  |  | 19.3 |  |  |  | 16.6 |  |  |  | 2.7 |  |  |  | 16.3 |  |
| % of net sales |  |  | 3.3 | % |  |  | 3.1 | % |  |  |  |  |  |  |  |  |

[0001193125-12-065358:mdna:102]
Net sales increased primarily due to the improvements in the residential service and replacement end
markets. In addition, we have had significant growth in our commercial service business. The sales increase was

[0001193125-12-065358:mdna:103]
primarily due to an increase in sales volumes of 5%. Price and mix increased sales by 3%. Foreign currency exchange rates increased sales by 2%.

[0001193125-12-065358:mdna:104]
Segment profit increased $2.7 million, including nearly $6 million due to the increase in sales. Higher selling expenses of $3 million
partially offset the favorable effect of higher revenues.

[0001193125-12-065358:mdna:105]
Refrigeration

[0001193125-12-065358:mdna:106]
The following table details our Refrigeration segment’s net sales and profit for 2010 and 2009 (dollars in millions):

[0001193125-12-065358:mdna:107]
|  |  | Years EndedDecember 31, |  |  |  |  |  |  |  |
|  |  | 2010 |  |  | 2009 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 550.9 |  |  | $ | 512.7 |  |  | $ | 38.2 |  |  |  | 7.5 | % |
| Profit |  |  | 61.4 |  |  |  | 48.9 |  |  |  | 12.5 |  |  |  | 25.6 |  |
| % of net sales |  |  | 11.1 | % |  |  | 9.5 | % |  |  |  |  |  |  |  |  |

[0001193125-12-065358:mdna:108]
Net sales increased due to higher sales volumes of about 1% and the favorable impact of changes in foreign
currency exchange rates of 5%. Price and mix also increased sales by approximately 1%.

[0001193125-12-065358:mdna:109]
Segment profit increased $12.5 million,
including $10 million due to the increase in sales and almost $3 million in improved material savings and manufacturing efficiencies as those factors more than offset commodity price pressures.

[0001193125-12-065358:mdna:110]
Corporate and Other

[0001193125-12-065358:mdna:111]
Corporate and other expenses were $65.5 million in 2010, up from $62.5 million in 2009. The increase was primarily driven by increases in stock-based and incentive compensation expenses of approximately
$8 million, partially offset by lower pension costs of approximately $4 million.

[0001193125-12-065358:mdna:112]
Accounting for Futures Contracts

[0001193125-12-065358:mdna:113]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on open
futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date. Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other
expenses, net in the accompanying Consolidated Statements of Operations. See Note 21 to Consolidated Financial Statements for more information and a reconciliation of segment profit to net income.

[0001193125-12-065358:mdna:114]
Liquidity and Capital Resources

[0001193125-12-065358:mdna:115]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement. Working capital needs are
generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001193125-12-065358:mdna:116]
Statement of Cash
Flows

[0001193125-12-065358:mdna:117]
The following table summarizes our cash flow activity for 2011, 2010 and 2009 (in millions):

[0001193125-12-065358:mdna:118]
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Net cash provided by operating activities |  | $ | 76.2 |  |  | $ | 185.8 |  |  | $ | 225.5 |  |
| Net cash used in investing activities |  |  | (177.8 | ) |  |  | (61.4 | ) |  |  | (14.0 | ) |
| Net cash used in financing activities |  |  | (11.9 | ) |  |  | (93.5 | ) |  |  | (211.7 | ) |

[0001193125-12-065358:mdna:119]
Net Cash Provided by Operating Activities

[0001193125-12-065358:mdna:120]
Net cash provided by operating activities was $76 million in 2011 compared to $186 million in 2010. This decrease was due to lower net
income, an unfavorable change in working capital, and an unfavorable change in

[0001193125-12-065358:mdna:121]
accrued expenses. The unfavorable comparison for accrued expenses was due to higher payments and lower accruals for incentive compensation in 2011 versus 2010. Incentive compensation is accrued
in the current year based on performance, but paid in the first quarter of the subsequent year. In addition, we had an increase in accrued expenses related to class action litigation in 2010 but a significant reduction in 2011 when substantially all
of these accrued expenses were paid.

[0001193125-12-065358:mdna:122]
Net Cash Used in Investing Activities

[0001193125-12-065358:mdna:123]
Net cash used in investing activities for 2011 included $143 million for the acquisition of the Kysor/Warren business from The Manitowoc
Company and $4 million for the acquisition of a commercial services business in our Service Experts segment. Kysor/Warren is a leading manufacturer of refrigerated systems and display cases for supermarkets throughout North America and is included
in our Refrigeration Segment. Offsetting the cash used in 2011 was a change in the security requirements for our captive insurance subsidiary. We transferred substantially all security from restricted cash to stand-by letters of credit resulting in
a release of $12 million of restricted cash. Investing activities from 2010 included a net purchase of a business for $4 million and restricted cash of $12 million for security requirements for our captive insurance subsidiary.

[0001193125-12-065358:mdna:124]
Capital expenditures were $43 million, $46 million and $59 million in 2011, 2010 and 2009, respectively. Capital expenditures in 2011 were
primarily investments in our distribution network, investments in systems and software to support the overall enterprise, and investments for manufacturing and sourcing excellence.

[0001193125-12-065358:mdna:125]
Net Cash Used in Financing Activities

[0001193125-12-065358:mdna:126]
Net borrowings of long-term debt, short-term debt and revolving long-term debt totaled approximately $146 million in 2011 compared to net borrowings of $87 million in 2010. During 2011, we used
approximately $120 million to repurchase approximately 3.2 million shares of our common stock compared to $144 million for 3.3 million shares of our common stock during 2010 under our share repurchase plans.

[0001193125-12-065358:mdna:127]
Debt Position and Financial Leverage

[0001193125-12-065358:mdna:128]
The following table details our lines of credit and financing arrangements as of December 31, 2011:

[0001193125-12-065358:mdna:129]
|  |  | MaximumCapacity |  |  | OutstandingBorrowings |  |  | Availablefor FutureBorrowings |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign Obligations |  |  |  |  |  |  |  |  |  |  |  |  |
| Committed |  | $ | 1.8 |  |  | $ | 0.3 |  |  | $ | 1.5 |  |
| Non-committed |  |  | 4.4 |  |  |  | 4.4 |  |  |  | — |  |
| Asset Securitization(1) |  |  | 150.0 |  |  |  | — |  |  |  | 150.0 |  |
| Total short-term debt |  | $ | 156.2 |  |  | $ | 4.7 |  |  | $ | 151.5 |  |
| Current Maturities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital lease obligations |  | $ | 0.8 |  |  |  | 0.8 |  |  |  | — |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital lease obligations |  | $ | 16.6 |  |  |  | 16.6 |  |  |  | — |  |
| Domestic revolving credit facility(2) |  |  | 650.0 |  |  |  | 243.0 |  |  |  | 328.5 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |  |  | — |  |
| Total long-term debt |  | $ | 866.6 |  |  | $ | 459.6 |  |  |  | 328.5 |  |
| Total |  | $ | 1,023.6 |  |  | $ | 465.1 |  |  | $ | 480.0 |  |

[0001193125-12-065358:mdna:130]
| (1) | The maximum capacity under the receivables purchase agreement (“RPA”) is the lesser of $150.0 million or 100% of the net pool balance less reserves, as defined under the RPA. |

[0001193125-12-065358:mdna:131]
| (2) | The available future borrowings on our domestic revolving credit facility exclude $78.5 million in standby letters of credit. |

[0001193125-12-065358:mdna:132]
As discussed above, we utilized our domestic revolving credit facility (“credit
facility”) to support the acquisition of the Kysor/Warren business. We believe our available future borrowings combined with our cash of $45.0 million and future cash from operations is sufficient to fund our operations, planned capital
expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs. Our expected capital expenditures are approximately $55 million for 2012. Additionally, we expect to make approximately $15 million in
contributions to our U.S. defined benefit plan in 2012.

[0001193125-12-065358:mdna:133]
Our debt-to-total-capital ratio increased to 49.9% at
December 31, 2011 compared to 35.1% at December 31, 2010. The increase in the ratio is due to the increase in debt since December 31, 2010, primarily related to the acquisition of the Kysor/Warren business in January 2011.

[0001193125-12-065358:mdna:134]
We periodically review our capital structure, including our primary bank facility, to ensure that it has adequate liquidity. We amended
our RPA on November 18, 2011 and amended and restated our credit facility on October 21, 2011. The most significant changes to the RPA were the addition of Allied Air Enterprises LLC, Heatcraft Refrigeration Products LLC, and Lennox Hearth
Products LLC, all wholly-owned subsidiaries, as sellers of trade accounts receivable under the program, an increase in the purchase limit to $150 million from $100 million, and the extension of the RPA to November 16, 2012. The amended credit
facility provides up to $650 million in unsecured borrowings and issuance of letters of credit up to the full amount of the facility. The maturity date was extended to October 21, 2016. Additionally, at our request and subject to certain
conditions, the commitments under the credit facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments. Although pricing under the amended facility is slightly higher, we
do not believe it will significantly increase our interest expense on an annual basis. We also periodically consider various other financing alternatives and may, from time to time, seek to take advantage of favorable interest rate environments or
other market conditions, which may include accessing the capital markets.

[0001193125-12-065358:mdna:135]
On March 11, 2011, we announced that our Board
of Directors approved a 20% increase in our quarterly dividend on common stock from $0.15 to $0.18 effective with the April dividend payment. Dividend payments were approximately $35 million in 2011. We also continue to increase shareholder value
through our share repurchase program. In December 2011, our Board of Directors increased the 2008 Share Repurchase Program by $100 million. Utilizing this program, we returned $120 million to our investors through share repurchases. We are targeting
approximately $50 million in share repurchases in 2012.

[0001193125-12-065358:mdna:136]
Our credit facility is guaranteed by certain of our subsidiaries and
contains financial covenants relating to leverage and interest coverage. Other covenants contained in the credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The
financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our credit facility are
detailed below:

[0001193125-12-065358:mdna:137]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than |  | 3.0 : 1.0 |

[0001193125-12-065358:mdna:138]
Our credit facility contains customary events of default. These events of default include nonpayment of
principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our credit facility could occur if:

[0001193125-12-065358:mdna:139]
|  | • |  | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001193125-12-065358:mdna:140]
|  | • |  | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001193125-12-065358:mdna:141]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross
default). If a cross default under the credit facility, our senior unsecured notes, or

[0001193125-12-065358:mdna:142]
our RPA were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001193125-12-065358:mdna:143]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative
agent to terminate our right to borrow under our credit facility and accelerate amounts due under our credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the
lenders’ commitments will automatically terminate). As of December 31, 2011, we were in compliance with all covenant requirements.

[0001193125-12-065358:mdna:144]
Upon a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the
principal amount of the notes repurchased, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our credit
facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into
certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in
principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001193125-12-065358:mdna:145]
During the
third quarter of 2008, we amended the lease agreement for our corporate headquarters. While the same party continues to be the lessor under the lease, the amendment, among other things, replaced the debt participant and moderately increased the
rent payments. The amendment also provides for financial covenants consistent with our credit agreement and we are in compliance with these financial covenants. The lease is accounted for as an operating lease.

[0001193125-12-065358:mdna:146]
During 2008, we expanded our Tifton, Georgia manufacturing facility using the proceeds from Industrial Development Bonds
(“IDBs”). We entered into a lease agreement with the owner of the property and the issuer of the IDBs, and through our lease payments fund the interest payments to investors in the IDBs. We also guaranteed the repayment of the IDBs and
entered into letters of credit totaling $14.5 million to fund a potential repurchase of the IDBs in the event investors exercised their right to tender the IDBs to the Trustee. As of December 31, 2011 and 2010, we recorded both a long-term
asset and a corresponding long-term obligation of $14.3 million related to these transactions.

[0001193125-12-065358:mdna:147]
Off Balance Sheet Arrangements

[0001193125-12-065358:mdna:148]
In addition to the credit facilities and promissory notes described above, we also lease real estate and machinery and
equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers. Rent expense for these leases was $70
million, $64 million and $64 million in 2011, 2010 and 2009, respectively.

[0001193125-12-065358:mdna:149]
Contractual Obligations

[0001193125-12-065358:mdna:150]
Summarized below are our contractual obligations as of December 31, 2011 (in millions):

[0001193125-12-065358:mdna:151]
|  |  | Payments Due by Period |  |
|  |  | Total |  |  | 1 Yearor Less |  |  | 2-3Years |  |  | 4-5Years |  |  | After5 Years |  |
| Total long-term debt obligations |  | $ | 460.4 |  |  | $ | 0.8 |  |  | $ | 1.5 |  |  | $ | 243.7 |  |  | $ | 214.4 |  |
| Operating leases |  |  | 169.2 |  |  |  | 50.5 |  |  |  | 65.3 |  |  |  | 31.1 |  |  |  | 22.3 |  |
| Uncertain tax positions |  |  | 6.0 |  |  |  | 5.7 |  |  |  | — |  |  |  | 0.3 |  |  |  | — |  |
| Purchase obligations |  |  | 21.9 |  |  |  | 21.9 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total contractual obligations |  | $ | 657.5 |  |  | $ | 78.9 |  |  | $ | 66.8 |  |  | $ | 275.1 |  |  | $ | 236.7 |  |

[0001193125-12-065358:mdna:152]
As of December 31, 2011, the liability for uncertain tax positions includes interest and penalties.
Purchase obligations consist of aluminum commitments and inventory that is part of our third party logistics program. The

[0001193125-12-065358:mdna:153]
above table does not include retirement, postretirement and warranty liabilities because it is not certain when these liabilities will be funded; however, we expect to pay approximately $15
million in contributions to our U.S. defined benefit plan in 2012. Contractual obligations related to capital leases as of December 31, 2011 were included as part of long-term debt in the table above. For additional information regarding our
contractual obligations, see Note 11, Note 12 and Note 13 of the Notes to Consolidated Financial Statements.

[0001193125-12-065358:mdna:154]
Fair Value Measurements

[0001193125-12-065358:mdna:155]
Fair Value Hierarchy

[0001193125-12-065358:mdna:156]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001193125-12-065358:mdna:157]
| Level 1 |  | — |  | Quoted prices for identical instruments in active markets at the measurement date. |
| Level 2 |  | — |  | Quoted prices for similar instruments in active markets; quoted prices for identicalor similar instruments in markets that are not active; and model-derived valuationsin which all significant inputs and significant value drivers are observable in activemarkets at the measurement date and for the anticipated term of the instrument. |
| Level 3 |  | — |  | Valuations derived from valuation techniques in which one or more significantinputs or significant value drivers are unobservable inputs that reflect the reportingentity’s own assumptions about the assumptions market participants would use inpricing the asset or liability developed based on the best information available inthe circumstances. |

[0001193125-12-065358:mdna:158]
Fair Value Techniques

[0001193125-12-065358:mdna:159]
General

[0001193125-12-065358:mdna:160]
Our valuation techniques are applied to all of the assets and
liabilities carried at fair value. Where available, the fair values are based upon quoted prices in active markets. However, if quoted prices are not available, then the fair values are based upon quoted prices for similar assets or liabilities or
independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities with a lack of observable market activity, if any,
the fair values are based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use. To ensure that financial assets and liabilities are recorded at fair
value, valuation adjustments may be required to reflect either party’s creditworthiness and ability to pay. Where appropriate, these amounts were incorporated into our valuations as of December 31, 2011 and 2010, the measurement dates.

[0001193125-12-065358:mdna:161]
Derivatives

[0001193125-12-065358:mdna:162]
Derivatives are primarily valued using estimated future cash flows that are based directly on observed prices from exchange-traded derivatives and, therefore, were classified as Level 2. We also take into
account the counterparty’s creditworthiness, or our own creditworthiness, as appropriate. An adjustment has been recorded in order to reflect the risk of credit default, but these adjustments have been insignificant to the overall value of the
derivatives.

[0001193125-12-065358:mdna:163]
Pension Plan Assets

[0001193125-12-065358:mdna:164]
The majority of our commingled pool/collective trust, mutual funds and balanced pension trusts are managed by professional investment advisors. The net asset values (“NAV”) per share are
furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies. We have assessed the classification of the inputs used to value these investments at Level 1 for mutual
funds and Level 2 for commingled pool/collective trusts and balance pension trusts through examination of their pricing policies and the related controls and procedures. The fair values we report are based on the pool or trust’s

[0001193125-12-065358:mdna:165]
NAV per share. The NAV’s per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the
number of units owned.

[0001193125-12-065358:mdna:166]
Market Risk

[0001193125-12-065358:mdna:167]
Commodity Price Risk

[0001193125-12-065358:mdna:168]
We enter into commodity
futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.

[0001193125-12-065358:mdna:169]
Fluctuations in metal commodity prices impact the value of the derivative instruments that we hold. When metal commodity
prices rise, the fair value of our futures contracts increases and conversely, when commodity prices fall, the fair value of our futures contracts decreases.

[0001193125-12-065358:mdna:170]
Information about our exposure to market risks related to metal commodity prices and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001193125-12-065358:mdna:171]
| Notional amount (pounds) |  |  | 29.1 |  |
| Carrying amount and fair value of asset |  | $ | (11.6 | ) |
| Change in fair value from 10% change in forward prices |  | $ | 1.2 |  |

[0001193125-12-065358:mdna:172]
Interest Rate Risk

[0001193125-12-065358:mdna:173]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our revolving credit
facilities, cash, cash equivalents and short-term investments.

[0001193125-12-065358:mdna:174]
In order to partially mitigate interest rate risk, we use a
hedging strategy to eliminate the variability of cash flows in the interest payments for the first $100 million of the total variable-rate debt outstanding under the credit facility that is solely due to changes in the benchmark interest rate. This
strategy allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.

[0001193125-12-065358:mdna:175]
On June 12, 2009, we entered into a $100 million pay-fixed, receive-variable interest rate swap with a large financial institution at
a fixed interest rate of 2.66%. The variable portion of the interest rate swap is tied to 1-Month LIBOR (the benchmark interest rate). The interest rates under both the interest rate swap and the underlying debt are reset, the swap is settled with
the counterparty, and interest is paid, on a monthly basis. The interest rate swap expires October 12, 2012. We account for the interest rate swap as a cash flow hedge.

[0001193125-12-065358:mdna:176]
Information about our exposure to interest rate risk and a sensitivity analysis related to our interest rate swap is presented below (in millions):

[0001193125-12-065358:mdna:177]
| Notional amount |  | $ | 100.0 |  |
| Impact of a 100 basis point change in the benchmark interest rate: |  |  |  |  |
| Carrying amount and fair value of liability |  | $ | 1.9 |  |
| Interest expense |  | $ | 1.9 |  |

[0001193125-12-065358:mdna:178]
Foreign Currency Exchange Rate Risk

[0001193125-12-065358:mdna:179]
Our results of operations can be affected by changes in exchange rates. Net sales and expenses in foreign currencies are translated into
U.S. dollars for financial reporting purposes based on the average exchange rate for the period. During 2011, 2010 and 2009, net sales from outside the U.S. represented 28.2%, 27.2% and 28.6%, respectively, of our total net sales. Historically,
foreign currency transaction gains (losses) have not had a material effect on our overall operations. As of December 31, 2011, the impact to net income of a 10% change in exchange rates is estimated to be approximately $5.3 million.

[0001193125-12-065358:mdna:180]
Critical Accounting Policies

[0001193125-12-065358:mdna:181]
The preparation of financial statements requires the use of judgments and estimates. The critical accounting policies are described below to provide a better understanding of how we develop our judgments
about future

[0001193125-12-065358:mdna:182]
events and related estimations and how such policies can impact our financial statements. A critical accounting policy is one that requires difficult, subjective or complex estimates and
assessments and is fundamental to the results of operations. We consider our most critical accounting policies to be:

[0001193125-12-065358:mdna:183]
•  goodwill and other intangible assets;

[0001193125-12-065358:mdna:184]
•  product warranties;

[0001193125-12-065358:mdna:185]
•  pension and
postretirement benefits;

[0001193125-12-065358:mdna:186]
•  self-insurance expense;

[0001193125-12-065358:mdna:187]
•  derivative accounting; and

[0001193125-12-065358:mdna:188]
•  income taxes.

[0001193125-12-065358:mdna:189]
This discussion and analysis should be read in
conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001193125-12-065358:mdna:190]
Goodwill and Other Intangible Assets

[0001193125-12-065358:mdna:191]
We assign goodwill to the reporting units that benefit from the synergies of our acquisitions, which are the reporting units that report the results of such acquisitions. If we reorganize our management
structure, the related goodwill is allocated to the affected reporting units based upon the relative fair values of those reporting units. Assets and liabilities, including deferred income taxes, are generally directly assigned to the reporting
units through our segment reporting system as part of our financial closing process. However, certain assets and liabilities, including information technology assets and pension, self-insurance, and environmental liabilities, are commonly managed
and are not allocated to the segments in the normal course of our financial reporting process, and therefore must be assigned to the reporting units based upon appropriate methods. We test goodwill for impairment by reporting unit annually in the
first quarter of each fiscal year.

[0001193125-12-065358:mdna:192]
Reporting units that we test are generally equivalent to our business segments, or in some
cases, one level below. We review our reporting unit structure each year as part of our annual goodwill impairment testing and reporting units are determined based upon a review of the periodic financial information supplied to and reviewed by our
Chief Executive Officer (the chief operating decision maker). We aggregate operating units reviewed into reporting units when those operating units share similar economic characteristics.

[0001193125-12-065358:mdna:193]
We estimate reporting unit fair values using standard business valuation techniques such as discounted cash flows and reference to
comparable business transactions. The discounted cash flow approach is the principal technique we use. We use comparable business transactions as a reasonableness test of our principal technique as we believe that the discounted cash flow approach
provides greater detail and opportunity to reflect specific facts, circumstances and economic conditions for each reporting unit. Comparable business transactions are often limited in number, the information can be dated, and may require significant
adjustments due to differences in the size of the business, markets served, product offered, and other factors. We therefore believe that in our circumstances, this makes comparisons to business transactions less reliable than the discounted cash
flows method.

[0001193125-12-065358:mdna:194]
The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting
unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is
based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections
and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions
used, such as the weighted-average cost of capital and terminal growth rates.

[0001193125-12-065358:mdna:195]
In the first quarter of 2011, we met all of the
criteria outlined in ASC 350 to carryforward the fair value of the reporting units from our previous impairment test. Our fair value determination from the first quarter

[0001193125-12-065358:mdna:196]
impairment test in 2010 exceeded the carrying amount, in the aggregate, in excess of $1.0 billion and on a reporting unit basis by approximately 850% for our Residential Heating &
Cooling reporting unit, approximately 50% for our Hearth reporting unit, approximately 500% for our Commercial Heating & Cooling reporting unit, approximately 140% for our Refrigeration reporting unit, approximately 300% for our Service
Experts residential reporting unit and 275% for our Service Experts commercial reporting unit. When we performed our first quarter goodwill impairment test, our expectations of future performance were based on the strong results of 2010, including a
positive outlook for the residential new construction market at that time. Although our results were not as strong in 2011, the outlook for most of our reporting units has not changed significantly from the first quarter of 2011. Our Hearth
reporting unit, however, is heavily dependent on the residential new construction market due to its product offerings: fireplaces, stoves and venting products. In the fourth quarter of 2011, we began to pursue strategic alternatives due to the
prolonged uncertainty in the recovery of the residential new construction market and its effect on our long-term outlook for this reporting unit. As a result of this decline in outlook and pursuit of strategic alternatives, we believed our Hearth
reporting unit should be tested for goodwill impairment.

[0001193125-12-065358:mdna:197]
We performed step one of the goodwill impairment test and determined
that the carrying value of our Hearth reporting unit exceeded its fair value. Therefore, we performed the second step of the goodwill impairment test and determined the carrying value of the Hearth reporting unit was less than its implied fair
value, based primarily on indications of market value through our pursuit of strategic alternatives. Accordingly, we impaired $7.6 million which was the entire goodwill for this reporting unit. Our Hearth reporting unit is included in our
Residential Heating & Cooling segment. See Footnote 5 in Notes to Consolidated Financial Statements.

[0001193125-12-065358:mdna:198]
The average rate
used to discount the estimated cash flows for each reporting unit was 10.1% in 2011 and 2010. Below is a sensitivity analysis regarding the aggregate fair value of our reporting units to changes in average discount rates for 2010, as we carried the
fair value for our reporting units forward in 2011 (in millions):

[0001193125-12-065358:mdna:199]
| Approximate decrease in fair value from a 100 basis point increase in discount rate |  | $ | (400 | ) |
| Approximate increase in fair value from a 100 basis point decrease in discount rate |  | $ | 600 |  |

[0001193125-12-065358:mdna:200]
We also monitor economic, legal, regulatory and other factors for LII as a whole and for each reporting
unit between annual impairment tests to ensure no indicators exist that make it more likely than not that there was a decline in the fair value of the reporting unit below its carrying value. Specifically, we monitor industry trends, our market
capitalization, recent and forecasted financial performance of our reporting units, and the timing and nature of our restructuring activities. As noted above, in the fourth quarter of 2011, we determined that goodwill for our Hearth reporting unit
should be tested for goodwill impairment.

[0001193125-12-065358:mdna:201]
Product Warranties

[0001193125-12-065358:mdna:202]
The estimate of our liability for future warranty costs requires us to make significant assumptions about the amount, timing and nature of
the costs we will incur in the future. As some of the warranties we issue extend 10 years or more in duration, a relatively small adjustment to an assumption may have a significant impact on our overall liability. We review the assumptions used to
determine the liability periodically and we adjust our assumptions based upon factors such as actual failure rates and cost experience. Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new
product introductions, changes in manufacturing techniques or locations, components or suppliers used. Should actual warranty costs differ from our estimates, we may be required to record adjustments to accruals and expense in the future. For more
information see Note 12 in Notes to the Consolidated Financial Statements.

[0001193125-12-065358:mdna:203]
Pensions and Postretirement Benefits

[0001193125-12-065358:mdna:204]
We have domestic and foreign pension plans covering most employees and we also maintain an unfunded postretirement benefit
plan, which provides certain medical and life insurance benefits to eligible employees. In order to calculate the liability and the expense for these plans, we make several assumptions including the discount rate and expected return on assets. The
assumed discount rates of 4.83% for pension benefits of our U.S. qualified pension plans and 4.64% for other benefits were used to calculate the liability as of December 31, 2011.

[0001193125-12-065358:mdna:205]
Our assumed discount rates are selected using the yield curve for high-quality corporate bonds, which is dependent upon risk-free interest rates and current credit market conditions. In 2011, we
utilized 8.00% as the assumed long-term rate of return on assets, which is the same rate as our 2010 estimate. These are long-term estimates of equity values and are not dependent on short-term variations of the equity markets. Differences between
actual experience and our assumptions are quantified as actuarial gains and losses. These actuarial gains and losses do not immediately impact our earnings as they are deferred in accumulated other comprehensive income (“AOCI”) and are
amortized into net periodic benefit cost over the estimated service period. For two of our pension plans, nearly all of the participants were considered inactive because the plan benefits were frozen by the Company. In 2011, we contributed
$13.4 million to our pension plans and we contributed $5.6 million in 2010.

[0001193125-12-065358:mdna:206]
The assumed long-term rate of return on assets and
the discount rate have significant effects on the amounts reported for our defined benefit plans. A 25 basis point decrease in the long-term rate of return on assets or discount rate would have the following effects (in millions):

[0001193125-12-065358:mdna:207]
|  |  | 25 Basis PointDecrease in Long-Term Rate ofReturn |  | 25 Basis PointDecrease inDiscount Rate |
| Effect on net periodic benefit cost |  | $0.5 |  | $ 0.6 |
| Effect on the postretirement benefit obligations |  | N/A |  | 11.7 |

[0001193125-12-065358:mdna:208]
Assumed healthcare cost trend rates have a significant effect on the amounts reported for our healthcare
plan. For 2011, our assumed healthcare cost trend rate was 8.40%. A one percentage-point change in assumed healthcare cost trend rates would have the following effects (in millions):

[0001193125-12-065358:mdna:209]
|  |  | 1-Percentage-PointIncrease |  | 1-Percentage-PointDecrease |
| Effect on total of service and interest cost |  | $0.2 |  | $(0.2) |
| Effect on the postretirement benefit obligation |  | 2.0 |  | (1.7) |

[0001193125-12-065358:mdna:210]
Should actual results differ from our estimates and assumptions, revisions to the benefit plan liabilities
and the related expenses would be required. For more information, see Note 14 in the Notes to Consolidated Financial Statements.

[0001193125-12-065358:mdna:211]
Self-Insurance Expense

[0001193125-12-065358:mdna:212]
We use a combination of third-party insurance and self-insurance plans (large deductible or captive) to provide protection against claims relating to workers’ compensation/employers’ liability,
general liability, product liability, auto liability, auto physical damage and other exposures. Prior to the third quarter of 2009, these policies were written by a third-party insurance provider, which was then reinsured by our captive insurance
subsidiary. Starting with the third quarter of 2009, we no longer use our captive insurer for new losses; instead, we use large deductible insurance plans for workers’ compensation/employers’ liability, general liability, product
liability, and auto liability. These policies are written through third-party insurance providers. We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors’ and officers’
liability, property damage and various other insurance programs. We believe the limit within our excess policy is adequate for companies of our size in our industry. We believe that the deductibles and liability limits retained by LII and the
captive are customary for companies of our size in our industry and are appropriate for our business.

[0001193125-12-065358:mdna:213]
In addition, we use
third-party insurance plans for property damage, directors’ and officers’ liability, and other exposures. Each of these policies may include per occurrence and annual aggregate limits. However, we believe these limits are customary for
companies of our size in our industry and are appropriate for our business.

[0001193125-12-065358:mdna:214]
The self-insurance expense and liabilities are
primarily determined based on our historical claims information, as well as industry factors and trends. We maintain safety and manufacturing programs designed to improve the safety and effectiveness of our business processes and, as a result,
reduce the level and severity of our various self-insurance risks. In recent years, our actual claims experience has trended favorably and

[0001193125-12-065358:mdna:215]
therefore, both self-insurance expense and the related liability have decreased. To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liability
may change. The self-insurance liabilities recorded in Accrued Expenses in the accompanying Consolidated Balance Sheets were $63 million and $65 million as of December 31, 2011 and 2010, respectively.

[0001193125-12-065358:mdna:216]
Derivative Accounting

[0001193125-12-065358:mdna:217]
We use futures contracts and fixed forward contracts to mitigate our exposure to volatility in commodity prices in the ordinary course of business. Fluctuations in metal commodity prices impact the value
of the derivative instruments that we hold. When metal commodity prices rise, the fair value of our futures contracts increases and conversely, when commodity prices fall, the fair value of our futures contracts decreases. We are required to prepare
and maintain contemporaneous documentation for futures contracts to be formally designated as cash flow hedges. Our failure to comply with the strict documentation requirements could result in the de-designation of cash flow hedges, which may
significantly impact our consolidated financial statements.

[0001193125-12-065358:mdna:218]
Income Taxes

[0001193125-12-065358:mdna:219]
In determining income for financial statement purposes, we must make certain estimates and judgments in the calculation of tax provisions
and the resultant tax liabilities and in the recoverability of deferred tax assets that arise from temporary differences between the tax and financial statement recognition of revenue and expense. In the ordinary course of global business, there may
be many transactions and calculations where the ultimate tax outcome is uncertain. The calculation of tax liabilities involves dealing with uncertainties in the application of complex tax laws. We recognize potential liabilities for anticipated tax
audit issues in the U.S. and other tax jurisdictions based on an estimate of the ultimate resolution of whether, and the extent to which, additional taxes will be due. Although we believe the estimates are reasonable, no assurance can be given that
the final outcome of these matters will not be different than what is reflected in the historical income tax provisions and accruals.

[0001193125-12-065358:mdna:220]
As part of our financial reporting process, we must assess the likelihood that our deferred tax assets can be recovered. If recovery is not likely, the provision for taxes must be increased by recording a
reserve in the form of a valuation allowance for the deferred tax assets that are estimated not to be ultimately recoverable. In this process, certain relevant criteria are evaluated, including the existence of deferred tax liabilities that can be
used to absorb deferred tax assets, the taxable income in prior carryback years that can be used to absorb net operating losses and credit carrybacks and taxable income in future years. Our judgment regarding future taxable income may change due to
future market conditions, changes in U.S. or international tax laws and other factors. These changes, if any, may require material adjustments to these deferred tax assets and an accompanying reduction or increase in net income in the period when
such determinations are made. In addition to the risks to the effective tax rate described above, the effective tax rate reflected in forward-looking statements is based on current tax law. Any significant changes in the tax laws could affect these
estimates.
