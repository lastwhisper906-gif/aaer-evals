# LII notes — 0001193125-12-065358


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-12-065358:notes:1]
2.    Summary of Significant Accounting Policies:

[0001193125-12-065358:notes:2]
Principles of Consolidation

[0001193125-12-065358:notes:3]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries. All
   intercompany transactions, profits and balances have been eliminated.

[0001193125-12-065358:notes:4]
Cash and Cash Equivalents

[0001193125-12-065358:notes:5]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents. Cash and
   cash equivalents consisted primarily of bank deposits and US Treasury money market securities.

[0001193125-12-065358:notes:6]
During the first quarter of
   2010, our captive insurance subsidiary entered into an agreement in which cash was placed into a trust for the benefit of a third-party insurance provider. The purpose of the trust is to pay workers compensation claims for policy years 2003
   – 2009 until the liabilities are satisfied. These policies were written by the third-party insurance provider, and then reinsured by our captive insurance subsidiary. This transaction was classified as restricted cash on the
   accompanying Consolidated Balance Sheets with a balance of $12.2 million as of December 31, 2010. In the second quarter of 2011, we changed how these claims were secured. All claims for the workers compensation claims for policy years 2003
   – 2009 are now secured by standby letters of credit.

[0001193125-12-065358:notes:7]
Accounts and Notes Receivable

[0001193125-12-065358:notes:8]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts. The
   allowance for doubtful accounts is generally established during the period in which receivables are recognized and is maintained at a level deemed appropriate based on historical and other factors that affect collectability. Such factors include the
   historical trends of write-offs and recovery of previously written-off accounts, the financial strength of the customer and projected economic and market conditions. We determine the delinquency status of receivables predominantly based on
   contractual terms and write-off of uncollectible receivables after management’s review of factors that affect collectability as noted above, among other considerations. We have no significant concentrations of credit risk within our accounts
   and notes receivable.

[0001193125-12-065358:notes:9]
Inventories

[0001193125-12-065358:notes:10]
Inventory costs include material, labor, depreciation and plant overhead. Inventories of $156.7 million and $123.8 million as of December 31, 2011 and 2010, respectively, were valued at the lower of
   cost or market using the last-in, first-out (“LIFO”) cost method. The remaining portion of the inventory is valued at the lower of cost or market with cost being determined either on the first-in, first-out (“FIFO”) basis or
   average cost. We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s. The types of inventory include raw
   materials, purchased components, work-in-process, repair parts and finished goods. Starting in the late 1990s, we began adopting the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with
   a previous LIFO election continue to use the LIFO cost method. We also use the FIFO cost method for all of our foreign-based manufacturing facilities as well as our Service Experts segment, whose inventory is limited to service parts and finished
   goods.

[0001193125-12-065358:notes:11]
Property, Plant and Equipment

[0001193125-12-065358:notes:12]
Property, plant and equipment is stated at cost, net of accumulated depreciation. Expenditures that increase the utility or extend the
   useful lives of fixed assets are capitalized and expenditures for maintenance and repairs are charged to expense as incurred. Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001193125-12-065358:notes:13]
| Buildings and improvements |  |  | 2 to 40 years |  |
| Machinery and equipment |  |  | 1 to 15 years |  |

[0001193125-12-065358:notes:14]
We periodically review long-lived assets for impairment as events or changes
   in circumstances indicate that the carrying amount of such assets might not be recoverable. In order to assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset
   group to the carrying amount of such assets. If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets
   over their fair value. In 2011, we recorded $5.4 million in asset impairments primarily on assets in our Hearth reporting unit. See Notes 5 and 6 for more discussion on these impairments.

[0001193125-12-065358:notes:15]
Goodwill

[0001193125-12-065358:notes:16]
Goodwill represents the excess of cost over fair value of assets from acquired businesses. Goodwill and intangible assets determined to
   have an indefinite useful life are not amortized, but are instead tested for impairment at least annually. We complete our annual goodwill impairment tests in the first quarter of each fiscal year and continuously monitor our operations for
   indicators of goodwill impairment based on current market conditions.

[0001193125-12-065358:notes:17]
We assign goodwill to the reporting units that benefit
   from the synergies of our acquisitions, which are the reporting units that report the results of such acquisitions. If we reorganize our management structure, the related goodwill is allocated to the affected reporting units based upon the relative
   fair values of those reporting units. Assets and liabilities, including deferred income taxes, are generally directly assigned to the reporting units through our segment reporting system as part of our financial closing process. However, certain
   assets and liabilities, including information technology assets and pension, self-insurance, and environmental liabilities, are commonly managed and are not allocated to the segments in the normal course of our financial reporting process and
   therefore must be assigned to the reporting units based upon appropriate methods.

[0001193125-12-065358:notes:18]
Reporting units we test are generally
   equivalent to our business segments, or in some cases, one level below. We review our reporting unit structure each year as part of our annual goodwill impairment testing and reporting units are determined based upon a review of the periodic
   financial information supplied to and reviewed by our Chief Executive Officer (the chief operating decision maker). We aggregate operating units reviewed into reporting units when those operating units share similar economic characteristics.

[0001193125-12-065358:notes:19]
We estimate reporting unit fair values using standard business valuation techniques such as discounted cash flows and
   reference to comparable business transactions and observable fair values of comparable entities. The discounted cash flow approach is the principal technique we use. We use comparable business transactions and observable fair values of comparable
   entities as a reasonableness test of our principal technique as we believe that the discounted cash flow approach provides greater detail and opportunity to reflect specific facts, circumstances and economic conditions for each reporting unit. Comparable business transactions are often limited in number, information can be dated, and may require significant adjustments due
   to differences in the size of the business, markets served, product offered, and other factors. We therefore believe that in our circumstances, this makes comparisons to comparable business transactions less reliable than the discounted cash flows
   method.

[0001193125-12-065358:notes:20]
The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s
   estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the
   risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions
   are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as
   the weighted-average cost of capital and terminal growth rates.

[0001193125-12-065358:notes:21]
We also monitor economic, legal, regulatory and other factors
   for LII as a whole and for each reporting unit between annual impairment tests to ensure there are no indicators that make it more likely than not there has been a decline in the fair value of any reporting unit below its carrying value.
   Specifically, we monitor industry trends, our market capitalization, recent and forecasted financial performance of our reporting units, and the timing and nature of our restructuring activities. Due to prolonged uncertainty in the residential new
   construction market, our long-term outlook for our Hearth reporting unit declined; therefore, in the fourth quarter of 2011, we began to pursue strategic alternatives. Our Hearth reporting unit is heavily dependent on the residential new
   construction market; more so than our other reporting units due to its product offerings: fireplaces, stoves, and venting products. As a result of this decline in expectations for this reporting unit, we determined that our goodwill should be tested
   for impairment, resulting in $7.6 million in impairment. (See Note 5 for further discussion of this impairment.) While our recent financial performance is below historical levels for some of our reporting units, we determined that no impairment of
   our goodwill existed as of December 31, 2011 for our remaining reporting units. We did not have any goodwill impairments in 2010 or 2009. If these estimates or the related assumptions change, we may be required to record non-cash impairment
   charges for these assets in the future. For additional disclosures on goodwill, see Note 7.

[0001193125-12-065358:notes:22]
Intangible and Other Assets

[0001193125-12-065358:notes:23]
We amortize intangible assets with finite lives over their respective estimated useful lives to their estimated residual values.
   Identifiable intangible and other assets that have finite lives are amortized over their estimated useful lives as follows:

[0001193125-12-065358:notes:24]
| Asset |  | Useful Life |
| Deferred financing costs |  | Effective interest method |
| Customer relationships Others |  | Straight-line method up to 12 years Straight-line method up to 10 years |

[0001193125-12-065358:notes:25]
We periodically review intangible assets with estimable useful lives for
   impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable. In order to assess recoverability, we compare the estimated expected undiscounted future cash flows identified with each
   intangible asset or related asset group to the carrying amount of such assets. If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the
   carrying amount of the impaired assets over their fair value.

[0001193125-12-065358:notes:26]
In assessing the fair value of our other intangibles, we must
   make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets. If these estimates or the related assumptions change, we may be required to record
   impairment charges for these assets in the future. For 2011, we recorded an impairment of $1.6 million in intangible assets for our Hearth reporting unit. See Note 5 for further discussion on this impairment.

[0001193125-12-065358:notes:27]
Product Warranties

[0001193125-12-065358:notes:28]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20
   years to customers for certain components such as compressors or heat exchangers. For select products, we also provide lifetime warranties for heat exchangers. A liability for estimated warranty expense is recorded on the date that revenue is
   recognized. Our estimates of future warranty costs are determined for each product line. The number of units we expect to repair or replace is determined by applying the estimated failure rate, which is generally based on historical experience, to
   the number of units that were sold and are still under warranty. The estimated units to be repaired under warranty are multiplied by the average cost to repair or replace such products to determine the estimated future warranty cost. We do not
   discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically identified warranty obligations. Estimated future warranty costs
   are subject to adjustment from time to time depending on changes in actual failure rate and cost experience. Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.

[0001193125-12-065358:notes:29]
Pensions and Postretirement Benefits

[0001193125-12-065358:notes:30]
We provide pension and postretirement medical benefits to eligible domestic and foreign employees and recognize pension and postretirement
   benefit costs over the estimated service life or average life expectancy of those employees. We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit
   obligation, in the Consolidated Balance Sheets. Changes in the funded status are recognized in the year in which the changes occur through accumulated other comprehensive income (“AOCI”). Actuarial gains or losses are amortized into net
   period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001193125-12-065358:notes:31]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans. Should actual results differ from management’s estimates, revisions to the benefit
   plan assets and liabilities would be required. For additional disclosures on pension and postretirement medical benefits, including how we determine the assumptions used, see Note 14.

[0001193125-12-065358:notes:32]
Self-Insurance

[0001193125-12-065358:notes:33]
Self-insurance expense and liabilities, calculated on an undiscounted basis, are actuarially determined based primarily on our historical
   claims information, as well as industry factors and trends. As of December 31, 2011, self-insurance and captive reserves represent the best estimate of the future payments to be made on losses reported and unreported for 2011 and prior years.
   The majority of our self-insured risks (excluding auto liability and physical damage) will be paid over an extended period of time.

[0001193125-12-065358:notes:34]
Actual payments for claims reserved as of December 31, 2011 may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims. To the extent
   actuarial assumptions change and claims experience rates differ from historical rates, our liability may change. For additional disclosures on self-insured risks and reserves, see Note 12.

[0001193125-12-065358:notes:35]
Derivatives

[0001193125-12-065358:notes:36]
We use futures contracts and fixed forward contracts to mitigate the exposure to volatility in commodity prices and foreign exchange
   rates, and we use an interest rate swap to hedge changes in the benchmark interest rate related to a portion of our revolving credit facility. We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for
   profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value. Classification of each hedging instrument is based upon whether the maturity of the instrument is less than or greater than 12 months. For more information, see
   Note 10.

[0001193125-12-065358:notes:37]
Income Taxes

[0001193125-12-065358:notes:38]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial
   statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable
   income in the years in which those temporary differences are expected to be recovered or settled. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.

[0001193125-12-065358:notes:39]
Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”)
   Accounting Standards Codification (“ASC”) Topic 740. For more information, see Note 11.

[0001193125-12-065358:notes:40]
Revenue Recognition

[0001193125-12-065358:notes:41]
Our Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments’ revenue recognition
   practices depend upon the shipping terms for each transaction. Shipping terms are primarily FOB Shipping Point and, therefore, revenues are recognized for these transactions when products are shipped to customers and title passes. However, certain
   customers in our smaller operations, primarily outside of North America, have shipping terms where title and risk of ownership do not transfer until the product is delivered to the customer. For these transactions, revenues are recognized on the
   date that the product is received and accepted by such customers. We have experienced returns for miscellaneous reasons and we record a reserve for these returns based on historical experience at the time we recognize revenue. Our historical rates
   of return are insignificant as a percentage of sales.

[0001193125-12-065358:notes:42]
Our Service Experts segment recognizes sales, installation, maintenance
   and repair revenues at the time the services are completed. The Service Experts segment also provides HVAC system design and installation services under fixed-price contracts, which may extend up to one year. Revenue for these services is recognized
   using the percentage-of-completion method, based on the percentage of incurred contract costs-to-date in relation to total estimated contract costs, after giving effect to the most recent estimates of total cost. The effect of changes to total
   estimated contract revenue or cost is recognized in the period such changes are determined. Provisions for estimated losses on individual contracts are made in the first period in which the loss becomes probable.

[0001193125-12-065358:notes:43]
We engage in cooperative advertising, customer rebate, cash discount and other miscellaneous programs that result in payments or credits
   being issued to our customers. Our policy is to record the discounts and incentives as a reduction of sales when the sales are recorded, with the exception of certain cooperative advertising expenditures that are charged to Selling, General and
   Administrative (“SG&A”) Expenses. Under these cooperative advertising programs, we receive, or will receive, an identifiable benefit (goods or services) in exchange for the consideration given.

[0001193125-12-065358:notes:44]
Cost of Goods Sold

[0001193125-12-065358:notes:45]
The principal components of cost of goods sold in our manufacturing operations are component costs, raw materials, factory overhead,
   labor, estimated costs of warranty expense, and freight and distribution costs. In our Service Experts segment, the principal components of cost of goods sold are equipment, vehicle costs, parts and supplies, and labor.

[0001193125-12-065358:notes:46]
Selling, General and Administrative Expenses

[0001193125-12-065358:notes:47]
SG&A expenses include all payroll and benefit costs, advertising, commissions, research and development,
   information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.

[0001193125-12-065358:notes:48]
Stock-Based Compensation

[0001193125-12-065358:notes:49]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We base stock-based
   compensation costs on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and adjust expected vesting rates to actual rates as additional information becomes known. We also adjust performance
   achievement rates based on our best estimates of those rates at the end of the performance period.

[0001193125-12-065358:notes:50]
Translation of Foreign Currencies

[0001193125-12-065358:notes:51]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect
   at the balance sheet date. Revenues and expenses are translated at weighted average exchange rates during the year. The unrealized translation gains and losses are included in AOCI in the accompanying Consolidated Balance Sheets. Transaction gains
   and losses are included in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.

[0001193125-12-065358:notes:52]
Use of Estimates

[0001193125-12-065358:notes:53]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the
   underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable,
   inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and postretirement medical benefits, among others. These
   estimates and assumptions are based on our best estimates and judgment.

[0001193125-12-065358:notes:54]
We evaluate our estimates and assumptions on an
   ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when facts and
   circumstances dictate. Volatile equity, foreign currency, and commodity markets combined to increase the uncertainty inherent in such estimates and assumptions. As future events and their effects cannot be determined with precision, actual results
   could differ significantly from these estimates. Changes in those estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001193125-12-065358:notes:55]
Reclassifications

[0001193125-12-065358:notes:56]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-065358:notes:57]
3.    Acquisition:

[0001193125-12-065358:notes:58]
On January 14, 2011, we acquired substantially all the assets of the Kysor/Warren business from The Manitowoc
   Company. Kysor/Warren is a leading manufacturer of refrigerated systems and display cases for supermarkets throughout North America and is included in our Refrigeration Segment. The total consideration for the acquisition was $143.3 million, which
   reflects post-closing purchase price working capital adjustments. In connection with this acquisition, we recorded goodwill of $42.0 million and intangible assets of $33.9 million. The intangible assets consisted of the following: trade names of
   $5.0 million with indefinite lives, customer relationships of $26.7 million with 11 to 12 year lives, and other intangibles of $2.2 million with lives ranging from one to eight years. We paid more than the fair value of the underlying net assets as
   a result of expected operational synergies. The entire $42.0 million of goodwill is expected to be deductible for tax purposes. The acquisition would not have had a significant impact on our historical results.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-065358:notes:59]
4.    Inventories:

[0001193125-12-065358:notes:60]
Components of inventories are as follows (in millions):

[0001193125-12-065358:notes:61]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Finished goods |  | $ | 228.3 |  |  | $ | 213.5 |  |
| Work in process |  |  | 14.4 |  |  |  | 6.5 |  |
| Raw materials and repair parts |  |  | 167.7 |  |  |  | 137.0 |  |
|  |  |  | 410.4 |  |  |  | 357.0 |  |
| Excess of current cost over last-in, first-out cost |  |  | (73.9 | ) |  |  | (70.8 | ) |
| Total inventories |  | $ | 336.5 |  |  | $ | 286.2 |  |

[0001193125-12-065358:notes:62]
Repair parts are primarily utilized in service operations and to fulfill our warranty obligations.

[0001193125-12-065358:notes:63]
The Company recorded pretax income of $0.1 million, $0.7 million, and $1.3 million from LIFO inventory liquidations during 2011, 2010, and
   2009, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-12-065358:notes:64]
6.    Property, Plant and Equipment:

[0001193125-12-065358:notes:65]
Components of property, plant and equipment are as follows (in millions):

[0001193125-12-065358:notes:66]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Land |  | $ | 27.6 |  |  | $ | 39.3 |  |
| Buildings and improvements |  |  | 216.3 |  |  |  | 226.5 |  |
| Machinery and equipment |  |  | 648.0 |  |  |  | 625.4 |  |
| Construction in progress and equipment not yet in service |  |  | 24.0 |  |  |  | 17.8 |  |
| Total |  |  | 915.9 |  |  |  | 909.0 |  |
| Less: accumulated depreciation |  |  | (606.0 | ) |  |  | (584.7 | ) |
| Property, plant and equipment, net |  | $ | 309.9 |  |  | $ | 324.3 |  |

[0001193125-12-065358:notes:67]
The balances above
   include capital lease assets composed of buildings and improvements and machinery and equipment totaling $16.6 million and $17.1 million, net of accumulated depreciation of $7.2 million and $5.6 million for the years ended December 31, 2011 and
   2010, respectively.

[0001193125-12-065358:notes:68]
In 2011, we recorded $5.1 million in impairment of long-lived assets for our Hearth Reporting Unit. See
   Note 5 for more information. We also recorded $0.3 million in machinery and equipment impairment for assets that are no longer in use. No impairment charges were recorded in 2010.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-12-065358:notes:69]
7.    Goodwill, Intangible and Other Assets:

[0001193125-12-065358:notes:70]
The changes in the carrying amount of goodwill, by segment, are as follows (in millions):

[0001193125-12-065358:notes:71]
|  |  | Balance atDecember 31,2009 |  |  |  |  |  |  |  |  | Balance atDecember 31,2010 |  |  |  |  |  |  |  |  | Balance atDecember 31,2011 |  |
| Segment: |  | Goodwill |  |  | Acquisitions/(Dispositions)(2) |  |  | Other(4) |  |  | Goodwill |  |  | Acquisitions/(Dispositions)(3) |  |  | Other(4)(5) |  |  | Goodwill |  |
| Residential Heating & Cooling |  | $ | 33.7 |  |  | $ | — |  |  | $ |  |  |  | $ | 33.7 |  |  | $ | — |  |  | $ | (7.6 | ) |  | $ | 26.1 |  |
| Commercial Heating & Cooling |  |  | 31.3 |  |  |  | — |  |  |  | (1.3 | ) |  |  | 30.0 |  |  |  | — |  |  |  | (0.6 | ) |  |  | 29.4 |  |
| Service Experts(1) |  |  | 106.9 |  |  |  | 4.0 |  |  |  | 5.7 |  |  |  | 116.6 |  |  |  | 3.0 |  |  |  | (3.1 | ) |  |  | 116.5 |  |
| Refrigeration |  |  | 85.5 |  |  |  | — |  |  |  | 6.0 |  |  |  | 91.5 |  |  |  | 42.0 |  |  |  | 0.1 |  |  |  | 133.6 |  |
|  |  | $ | 257.4 |  |  | $ | 4.0 |  |  | $ | 10.4 |  |  | $ | 271.8 |  |  | $ | 45.0 |  |  | $ | (11.2 | ) |  | $ | 305.6 |  |

[0001193125-12-065358:notes:72]
| (1) | Service Experts goodwill includes accumulated impairment losses of $208.0 million from prior periods with no impairment losses in the current year. |

[0001193125-12-065358:notes:73]
| (2) | During 2010, our Service Experts segment acquired a company which resulted in additional goodwill of $4.0 million. |

[0001193125-12-065358:notes:74]
| (3) | During the first quarter of 2011, our Refrigeration segment acquired Kysor/Warren which resulted in additional goodwill of $42.0 million. See Note 3 for more information on the Kysor/Warren acquisition. During the second quarter of 2011, our Service Experts segment acquired a company, which resulted in additional goodwill of $3.0 million. |

[0001193125-12-065358:notes:75]
| (4) | Other consists primarily of changes in foreign currency translation rates. |

[0001193125-12-065358:notes:76]
| (5) | In 2011, Other for our Residential Heating & Cooling segment also includes $7.6 million in goodwill impairment for its Hearth Reporting Unit. See Note 5 Goodwill and Other Long-Lived Asset Impairments for more information. |

[0001193125-12-065358:notes:77]
Identifiable intangible and other assets subject to amortization are recorded in Other Assets in the accompanying Consolidated Balance Sheets and were comprised of the following (in millions):

[0001193125-12-065358:notes:78]
|  |  | For the Years Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetAmount |  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetAmount |  |
| Deferred financing costs |  | $ | 11.5 |  |  | $ | (7.2 | ) |  | $ | 4.3 |  |  | $ | 9.2 |  |  | $ | (6.3 | ) |  | $ | 2.9 |  |
| Customer relationships |  |  | 47.6 |  |  |  | (20.4 | ) |  |  | 27.2 |  |  |  | 4.5 |  |  |  | (1.5 | ) |  |  | 3.0 |  |
| Other |  |  | 12.6 |  |  |  | (10.8 | ) |  |  | 1.8 |  |  |  | 23.6 |  |  |  | (22.3 | ) |  |  | 1.3 |  |
| Total |  | $ | 71.7 |  |  | $ | (38.4 | ) |  | $ | 33.3 |  |  | $ | 37.3 |  |  | $ | (30.1 | ) |  | $ | 7.2 |  |

[0001193125-12-065358:notes:79]
Amortization of
   intangible assets was as follows (in millions):

[0001193125-12-065358:notes:80]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Amortization expense |  | $ | 5.3 |  |  | $ | 2.0 |  |  | $ | 1.6 |  |

[0001193125-12-065358:notes:81]
Estimated intangible amortization expense for the next five years is as follows (in millions):

[0001193125-12-065358:notes:82]
| 2012 |  | $ | 3.7 |  |
| 2013 |  |  | 3.6 |  |
| 2014 |  |  | 3.4 |  |
| 2015 |  |  | 3.3 |  |
| 2016 |  |  | 3.2 |  |
| Thereafter |  |  | 16.1 |  |

[0001193125-12-065358:notes:83]
As of December 31, 2011 and 2010, we had $9.9 million and $4.9 million respectively of intangible assets primarily
   consisting of trademarks, which are not subject to amortization.


## lii:JointVenturesAndOtherEquityInvestmentTextBlock

[0001193125-12-065358:notes:84]
8.    Joint Ventures and Other Equity Investment:

[0001193125-12-065358:notes:85]
Joint Ventures

[0001193125-12-065358:notes:86]
We participate in two joint ventures; the largest is located in the U.S. and the other in Mexico. These joint ventures are engaged in the manufacture and sale of compressors, unit coolers and condensing
   units. Because we exert significant influence over these affiliates based upon our respective 25% and 50% ownership, but do not control them due to venture partner participation, they have been accounted for under the equity method and their
   financial position and results of operations are not consolidated. We purchase compressors from our U.S. joint venture for use in certain of our products.

[0001193125-12-065358:notes:87]
The combined balance of equity method investments included in Other Assets, net totaled (in millions):

[0001193125-12-065358:notes:88]
|  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Equity method investments |  | $ | 24.9 |  |  | $ | 28.2 |  |

[0001193125-12-065358:notes:89]
Purchases of compressors from our U.S. joint venture that were included in Cost of Goods Sold in the Consolidated
   Statements of Operations were approximately (in millions):

[0001193125-12-065358:notes:90]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Purchases of compressors |  | $ | 80.2 |  |  | $ | 86.1 |  |  | $ | 95.0 |  |

[0001193125-12-065358:notes:91]
During 2008, the Company loaned $1.6 million to its joint venture in Mexico due to that entity’s cash needs
   related to margin calls on forward commodity contracts and operating cash requirements. The joint venture partner loaned equal amounts under identical terms to the joint venture; and therefore, the investment continues to be recorded under the
   equity method. As of December 31, 2010, the outstanding loan balance was $0.9 million. The joint venture repaid the loan in 2011.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001193125-12-065358:notes:92]
9.    Accrued Expenses:

[0001193125-12-065358:notes:93]
Significant components of accrued expenses are presented below (in millions):

[0001193125-12-065358:notes:94]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Accrued compensation and benefits |  | $ | 54.8 |  |  | $ | 94.1 |  |
| Self insurance reserves |  |  | 63.3 |  |  |  | 64.6 |  |
| Deferred income |  |  | 36.8 |  |  |  | 34.9 |  |
| Accrued warranties |  |  | 30.1 |  |  |  | 31.2 |  |
| Accrued product quality issue |  |  | 7.5 |  |  |  | 16.0 |  |
| Accrued rebates and promotions |  |  | 37.6 |  |  |  | 38.2 |  |
| Derivative contracts |  |  | 13.1 |  |  |  | 2.2 |  |
| Other |  |  | 41.5 |  |  |  | 53.3 |  |
| Total Accrued expenses |  | $ | 284.7 |  |  | $ | 334.5 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-12-065358:notes:95]
10.    Derivatives:

[0001193125-12-065358:notes:96]
General

[0001193125-12-065358:notes:97]
Our earnings and cash flows are subject to fluctuations due to changes in commodity prices, interest rates, and foreign currency exchange rates, and we seek to mitigate a portion of these risks by
   entering into derivative contracts. The derivatives we use are commodity futures contracts, interest rate swaps, and currency forward contracts. We do not use derivatives for speculative purposes.

[0001193125-12-065358:notes:98]
The derivatives we enter into may be, but are not always, accounted for as hedges. To qualify for hedge accounting, the derivatives must
   be highly effective in reducing the risk exposure that they are designed to hedge, and it must be probable that the underlying transaction will occur. For instruments designated as cash flow hedges, we must formally document, at inception, the
   relationship between the derivative and the hedged item, the risk management objective, the hedging strategy for use of the hedged instrument, and how hedge effectiveness is, and will be, assessed. This documentation also includes linking the
   derivatives that are designated as cash flow hedges to forecasted transactions. We assess hedge effectiveness at inception and at least quarterly throughout the hedge designation period.

[0001193125-12-065358:notes:99]
We recognize all derivatives as either assets or liabilities at fair value in the Consolidated Balance Sheets, regardless of whether or
   not hedge accounting is applied. For more information on the fair value of these derivative instruments, see Note 22. We report cash flows arising from our hedging instruments consistent with the classification of cash flows from the underlying
   hedged items. Accordingly, cash flows associated with our derivative programs are classified as operating activities in the accompanying Consolidated Statements of Cash Flows.

[0001193125-12-065358:notes:100]
We monitor our derivative positions and credit ratings of our counterparties and do not anticipate losses due to counterparty non-performance.

[0001193125-12-065358:notes:101]
Hedge Accounting

[0001193125-12-065358:notes:102]
The derivatives that we use as hedges of commodity prices and movements in interest rates are accounted for as cash flow hedges. The effective portion of the gain or loss on the derivatives accounted for
   as hedges is recorded, net of applicable taxes, in AOCI, a component of Stockholders’ Equity in the accompanying Consolidated Balance Sheets. When earnings are affected by the variability of the underlying cash flow, the applicable offsetting amount of the gain or loss from the derivatives that is deferred
   in AOCI is reclassified into earnings in the same financial statement line item that the hedged item is recorded. Ineffectiveness, if any, is recorded in earnings each period. If the hedging relationship ceases to be highly effective, the net gain
   or loss shall remain in AOCI and will be reclassified into earnings when earnings are affected by the variability of the underlying cash flow. If it becomes probable that the forecasted transaction will not occur by the end of the originally
   specified period or within two months thereafter, the net gain or loss remaining in AOCI will be reclassified to earnings immediately.

[0001193125-12-065358:notes:103]
Accounting for Derivatives When Hedge Accounting is Not Applied

[0001193125-12-065358:notes:104]
We
   may also enter into derivatives that economically hedge certain of our risks, even though hedge accounting does not apply or we elect not to apply hedge accounting to these instruments. The changes in fair value of the derivatives act as an economic
   offset to changes in the fair value of the underlying items. Changes in the fair value of instruments not designated as cash flow hedges are recorded in earnings throughout the term of the derivative instrument and are reported in Losses (gains) and
   other expenses, net in the accompanying Consolidated Statements of Operations.

[0001193125-12-065358:notes:105]
Objectives and Strategies for Using
   Derivative Instruments

[0001193125-12-065358:notes:106]
Commodity Price Risk

[0001193125-12-065358:notes:107]
We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities we use in our production
   processes. The hedging program includes the use of futures contracts. We enter into these contracts based on our hedging strategy, a dollar cost averaging strategy. As part of this strategy, a higher percentage of commodity price exposures are
   hedged near term with lower percentages hedged at future dates. This strategy provides us with protection against near-term price volatility while allowing us to adjust to market price movements over time. Upon entering into futures contracts,
   we lock in prices and are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.

[0001193125-12-065358:notes:108]
Interest Rate Risk

[0001193125-12-065358:notes:109]
A portion of our debt bears interest at variable
   interest rates, and therefore, we are subject to variability in the cash paid for interest expense. In order to mitigate a portion of this risk, we use a hedging strategy to eliminate the variability of cash flows in the interest payments associated
   with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the benchmark interest rate. This strategy allows us to fix a portion of our interest payments.

[0001193125-12-065358:notes:110]
On June 12, 2009, we entered into a $100 million pay-fixed, receive-variable interest rate swap with a large financial institution
   at a fixed interest rate of 2.66%. The variable portion of the interest rate swap is tied to the 1-Month LIBOR (the benchmark interest rate). The interest rates under both the interest rate swap and the underlying debt are reset, the swap is settled
   with the counterparty, and interest is paid, on a monthly basis. The interest rate swap expires October 12, 2012. We account for the interest rate swap as a cash flow hedge.

[0001193125-12-065358:notes:111]
Foreign Currency Risk

[0001193125-12-065358:notes:112]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. Our objective for entering into foreign
   currency forward contracts is to mitigate the impact of short-term currency exchange rate movements on certain short-term intercompany transactions. In order to meet that objective, we periodically enter into foreign currency forward contracts that
   act as economic hedges against changes in foreign currency exchange rates. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them. By
   entering into these forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001193125-12-065358:notes:113]
Cash Flow Hedges

[0001193125-12-065358:notes:114]
We include gains or losses in AOCI in connection with our commodity cash flow hedges. The gains or losses related to commodity price hedges are expected to be reclassified into earnings within the next 18
   months based on the prices of the commodities at settlement date. Assuming that commodity prices remain constant, $6.0 million of derivative losses are expected to be reclassified into earnings within the next 12 months. Commodity futures contracts
   that are designated as cash flow hedges and are in place as of December 31, 2011 are scheduled to mature through May 2013.

[0001193125-12-065358:notes:115]
We also include gains or losses in AOCI from our $100 million pay-fixed receive variable interest rate swap. Assuming that the benchmark
   interest rate remains constant, $1.1 million of derivative losses are expected to be reclassified into earnings within the next 12 months. The interest rate swap expires on October 12, 2012.

[0001193125-12-065358:notes:116]
We recorded the following amounts related to our cash flow hedges (in millions):

[0001193125-12-065358:notes:117]
|  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Commodity Price Hedges: |  |  |  |  |  |  |  |  |
| Losses (gains) included in AOCI |  | $ | 6.1 |  |  | $ | (11.7 | ) |
| (Benefit from) provision for income taxes |  |  | (3.5 | ) |  |  | 6.7 |  |
| Interest Rate Swap: |  |  |  |  |  |  |  |  |
| Losses included in AOCI |  | $ | 1.1 |  |  | $ | 2.3 |  |
| Benefit from income taxes |  |  | (0.6 | ) |  |  | (1.3 | ) |

[0001193125-12-065358:notes:118]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions):

[0001193125-12-065358:notes:119]
|  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (Pounds) |  |  | (Pounds) |  |
| Copper |  |  | 23.3 |  |  |  | 18.5 |  |

[0001193125-12-065358:notes:120]
Derivatives not Designated as Cash Flow Hedges

[0001193125-12-065358:notes:121]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as for derivatives designated as cash
   flow hedges. We elect not to designate these derivatives as cash flow hedges at inception of the arrangement. We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions):

[0001193125-12-065358:notes:122]
|  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (Pounds) |  |  | (Pounds) |  |
| Copper |  |  | 2.8 |  |  |  | 1.4 |  |
| Aluminum |  |  | 3.0 |  |  |  | 1.4 |  |

[0001193125-12-065358:notes:123]
We had the
   following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001193125-12-065358:notes:124]
|  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Notional amounts: |  |  |  |  |  |  |  |  |
| Brazilian Reals |  |  | 4.5 |  |  |  | 5.6 |  |
| U.S. Dollars |  |  | 2.0 |  |  |  | — |  |
| Mexican Pesos |  |  | 172.0 |  |  |  | 138.0 |  |
| Euros |  |  | 7.8 |  |  |  | 15.6 |  |
| British Pounds |  |  | 6.5 |  |  |  | 2.0 |  |

[0001193125-12-065358:notes:125]
Information About the Location and Amounts of Derivative Instruments

[0001193125-12-065358:notes:126]
For information on the location and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and
   losses in the Consolidated Statements of Operations, see the tabular information presented below (in millions):

[0001193125-12-065358:notes:127]
|  |  | Fair Values of Derivative Instruments(1) |  |
|  |  | DerivativesDesignated asHedgingInstrumentsAs of December 31, |  |  | Derivatives NotDesignated asHedging InstrumentsAs of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | — |  |  | $ | 17.4 |  |  | $ | — |  |  | $ | 1.4 |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 1.2 |  |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | 0.1 |  |  |  | 1.3 |  |  |  | — |  |  |  | 0.1 |  |
| Total Assets |  | $ | 0.1 |  |  | $ | 18.7 |  |  | $ | 1.2 |  |  | $ | 1.7 |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 9.4 |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | — |  |
| Interest rate swap |  |  | 1.8 |  |  |  | 2.2 |  |  |  | — |  |  |  | — |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | 0.3 |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Interest rate swap |  |  | — |  |  |  | 1.4 |  |  |  | — |  |  |  | — |  |
| Total Liabilities |  | $ | 11.5 |  |  | $ | 3.6 |  |  |  | $2.1 |  |  |  | $— |  |

[0001193125-12-065358:notes:128]
| (1) | All our derivative instruments are classified as Level 2 within the fair value hierarchy. For more information on other fair value measurements, see Note 22. |

[0001193125-12-065358:notes:129]
Derivatives in Cash Flow Hedging
   Relationships

[0001193125-12-065358:notes:130]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Amount of Loss or (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(1) |  | $ | (12.1 | ) |  | $ | (11.2 | ) |  | $ | 19.6 |  |
| Interest rate swap(2) |  |  | 2.5 |  |  |  | 2.4 |  |  |  | 1.3 |  |
|  |  | $ | (9.6 | ) |  | $ | (8.8 | ) |  | $ | 20.9 |  |
| Amount of (Gain) or Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(3) |  | $ | 0.1 |  |  | $ | (0.4 | ) |  | $ | (0.1 | ) |

[0001193125-12-065358:notes:131]
Derivatives Not Designated as Hedging Instruments

[0001193125-12-065358:notes:132]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Amount of (Gain) or Loss Recognized in Income on Derivatives: |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(3) |  | $ | 3.5 |  |  | $ | (1.7 | ) |  | $ | (3.4 | ) |
| Foreign currency forward contracts(3) |  |  | 0.3 |  |  |  | (0.2 | ) |  |  | 3.1 |  |
|  |  | $ | 3.8 |  |  | $ | (1.9 | ) |  | $ | (0.3 | ) |

[0001193125-12-065358:notes:133]
| (1) | The loss (gain) is recorded in Cost of Goods Sold in the accompanying Consolidated Statements of Operations. |

[0001193125-12-065358:notes:134]
| (2) | The loss (gain) is recorded in Interest expense, net in the accompanying Consolidated Statements of Operations. |

[0001193125-12-065358:notes:135]
| (3) | The loss (gain) is recorded in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-065358:notes:136]
11.    Income Taxes:

[0001193125-12-065358:notes:137]
Our income tax provision (benefit) from continuing operations consisted of the following (in millions):

[0001193125-12-065358:notes:138]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 27.7 |  |  | $ | 54.7 |  |  | $ | 17.5 |  |
| State |  |  | 2.8 |  |  |  | 6.0 |  |  |  | 5.0 |  |
| Foreign |  |  | 8.8 |  |  |  | 7.3 |  |  |  | 8.1 |  |
| Total current |  |  | 39.3 |  |  |  | 68.0 |  |  |  | 30.6 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 0.9 |  |  |  | (6.9 | ) |  |  | 9.9 |  |
| State |  |  | (0.5 | ) |  |  | (1.6 | ) |  |  | 3.0 |  |
| Foreign |  |  | 2.6 |  |  |  | — |  |  |  | (4.4 | ) |
| Total deferred |  |  | 3.0 |  |  |  | (8.5 | ) |  |  | 8.5 |  |
| Total income tax provision |  | $ | 42.3 |  |  | $ | 59.5 |  |  | $ | 39.1 |  |

[0001193125-12-065358:notes:139]
Income from
   continuing operations before income taxes was comprised of the following (in millions):

[0001193125-12-065358:notes:140]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Domestic |  | $ | 91.3 |  |  | $ | 157.2 |  |  | $ | 99.7 |  |
| Foreign |  |  | 39.3 |  |  |  | 19.4 |  |  |  | 1.2 |  |
| Total |  | $ | 130.6 |  |  | $ | 176.6 |  |  | $ | 100.9 |  |

[0001193125-12-065358:notes:141]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax
   rate and the financial statement provision for taxes is summarized as follows (in millions):

[0001193125-12-065358:notes:142]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Provision at the U.S. statutory rate of 35% |  | $ | 45.7 |  |  | $ | 61.8 |  |  | $ | 35.3 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |  |  |  |  |  |  |  |
| State income tax, net of federal income tax benefit |  |  | 1.6 |  |  |  | 2.5 |  |  |  | 3.8 |  |
| Other permanent items |  |  | (3.3 | ) |  |  | (2.3 | ) |  |  | (2.8 | ) |
| Research tax credit |  |  | (0.3 | ) |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Decrease in tax audit reserves |  |  | (0.6 | ) |  |  | (0.2 | ) |  |  | (1.6 | ) |
| Change in valuation allowance |  |  | (0.5 | ) |  |  | (1.8 | ) |  |  | 4.5 |  |
| Foreign taxes at rates other than 35% and miscellaneous other |  |  | (0.3 | ) |  |  | — |  |  |  | 0.5 |  |
| Total income tax provision |  | $ | 42.3 |  |  | $ | 59.5 |  |  | $ | 39.1 |  |

[0001193125-12-065358:notes:143]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of
   assets and liabilities and their financial reporting basis and are reflected as current or non-current depending on the classification of the asset or liability generating the deferred tax. The deferred tax provision for the periods shown represents
   the effect of changes in the amounts of temporary differences during those periods.

[0001193125-12-065358:notes:144]
Deferred tax assets (liabilities) were
   comprised of the following (in millions):

[0001193125-12-065358:notes:145]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Gross deferred tax assets: |  |  |  |  |  |  |  |  |
| Warranties |  | $ | 27.5 |  |  | $ | 32.0 |  |
| Net operating losses (foreign and U.S. state) |  |  | 28.4 |  |  |  | 42.2 |  |
| Postretirement and pension benefits |  |  | 55.3 |  |  |  | 42.6 |  |
| Inventory reserves |  |  | 6.4 |  |  |  | 4.1 |  |
| Receivables allowance |  |  | 6.0 |  |  |  | 6.4 |  |
| Compensation liabilities |  |  | 18.1 |  |  |  | 17.3 |  |
| Deferred income |  |  | 7.4 |  |  |  | 7.8 |  |
| Insurance liabilities |  |  | 18.7 |  |  |  | 15.4 |  |
| Other |  |  | 12.9 |  |  |  | 10.6 |  |
| Total deferred tax assets |  |  | 180.7 |  |  |  | 178.4 |  |
| Valuation allowance |  |  | (12.8 | ) |  |  | (24.3 | ) |
| Total deferred tax assets, net of valuation allowance |  |  | 167.9 |  |  |  | 154.1 |  |

[0001193125-12-065358:notes:146]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Gross deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | (12.3 | ) |  |  | (11.1 | ) |
| Intangibles |  |  | (9.2 | ) |  |  | (6.6 | ) |
| Other |  |  | (2.6 | ) |  |  | (12.5 | ) |
| Total deferred tax liabilities |  |  | (24.1 | ) |  |  | (30.2 | ) |
| Net deferred tax assets |  | $ | 143.8 |  |  | $ | 123.9 |  |

[0001193125-12-065358:notes:147]
As of December 31, 2011 and 2010, we had $6.1 million and $6.5 million in tax effected state net operating loss
   carryforwards, respectively, and $22.2 million and $35.8 million in tax effected foreign net operating loss carryforwards, respectively. The state and foreign net operating loss carryforwards begin expiring in 2014. The deferred tax asset valuation
   allowance relates primarily to the operating loss carryforwards in various states in the U.S., European and Asian tax jurisdictions. The decrease in tax effected net operating loss carryforwards and associated valuation allowance is primarily
   related to the write-off of foreign losses, which were not previously benefited. The remaining decrease in the valuation allowance is primarily the result of foreign and state losses which were not previously benefited and currency fluctuation.

[0001193125-12-065358:notes:148]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion
   or all of the deferred tax assets will not be realized. We consider the reversal of existing taxable temporary differences, projected future taxable income, and tax planning strategies in making this assessment. Based upon the level of historical
   taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not that we will realize the benefits of these deductible differences, net of the existing
   valuation allowances, as of December 31, 2011.

[0001193125-12-065358:notes:149]
In order to realize the net deferred tax asset, we will need to generate
   future foreign taxable income of approximately $86.6 million during the periods in which those temporary differences become deductible. We also will need to generate U.S. federal income of approximately $80.8 million in addition to our carryback
   capacity to fully realize the federal deferred tax asset. U.S. taxable income for the years ended December 31, 2011 and 2010 was $55.2 million and $156.5 million, respectively.

[0001193125-12-065358:notes:150]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries’ earnings. It is not
   practicable to estimate the amount of tax that might be payable because our intent is to permanently reinvest these earnings or to repatriate earnings when it is tax effective to do so.

[0001193125-12-065358:notes:151]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001193125-12-065358:notes:152]
| Balance as of December 31, 2009 |  | $ | 1.5 |  |
| Decreases related to prior year tax positions |  |  | (0.4 | ) |
| Settlements |  |  | (0.1 | ) |
| Balance as of December 31, 2010 |  | $ | 1.0 |  |
| Decreases related to prior year tax positions |  |  | (0.7 | ) |
| Increases related to current year tax positions |  |  | 5.7 |  |
| Settlements |  |  | (0.1 | ) |
| Balance as of December 31, 2011 |  | $ | 5.9 |  |

[0001193125-12-065358:notes:153]
Included in the
   balance of unrecognized tax benefits as of December 31, 2011 are potential benefits of $5.9 million that, if recognized, would affect the effective tax rate on income from continuing operations. As of December 31, 2011, we recognized
   $0.1 million (net of federal tax benefits) in interest and penalties in income tax expense.

[0001193125-12-065358:notes:154]
The U.S. Internal Revenue Service
   (“IRS”) completed its examination of our consolidated tax returns for the years ended 2008 — 2009 and we reached a settlement with the IRS on April 7, 2011, which resulted in an immaterial impact to the Consolidated
   Statements of Operations.

[0001193125-12-065358:notes:155]
We are currently under examination for our U.S. federal income taxes for 2010 and 2011 and are
   subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax
   examinations by taxing authorities for years before 2005.

[0001193125-12-065358:notes:156]
Since January 1, 2011, numerous states including Arizona,
   Illinois, New Jersey, Indiana and Michigan have enacted legislation effective for tax years beginning on or after January 1, 2011, including changes to rates, apportionment methods and overall taxation systems. We determined the impact of these
   changes to be immaterial.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-065358:notes:157]
12.     Commitments and Contingencies:

[0001193125-12-065358:notes:158]
Leases

[0001193125-12-065358:notes:159]
The approximate minimum commitments under all non-cancelable leases outstanding as of December 31, 2011 are as follows (in millions):

[0001193125-12-065358:notes:160]
|  |  | OperatingLeases |  |  | CapitalLeases |  |
| 2012 |  | $ | 50.5 |  |  | $ | 1.2 |  |
| 2013 |  |  | 39.0 |  |  |  | 1.0 |  |
| 2014 |  |  | 26.3 |  |  |  | 0.9 |  |
| 2015 |  |  | 18.2 |  |  |  | 0.8 |  |
| 2016 |  |  | 12.9 |  |  |  | — |  |
| Thereafter |  |  | 22.3 |  |  |  | 14.6 |  |
| Total minimum lease payments |  | $ | 169.2 |  |  |  | 18.5 |  |
| Less amount representing interest |  |  |  |  |  |  | 1.1 |  |
| Present value of minimum payments |  |  |  |  |  | $ | 17.4 |  |

[0001193125-12-065358:notes:161]
On June 22, 2006, we entered into an agreement with a financial institution to lease our corporate headquarters in
   Richardson, Texas for a term of seven years (the “Lake Park Lease”). The leased property consists of an office building of approximately 192,000 square feet, land and related improvements. During the term, the Lake Park Lease requires us
   to pay base rent in quarterly installments, payable in arrears. At the end of the term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) make a final payment under the lease equal to
   approximately 82% of the lease balance and return the property to the financial institution in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms. If
   we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution. Any such payment cannot exceed 82% of the lease balance.

[0001193125-12-065358:notes:162]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and
   certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Revolving Credit Facility. We were in compliance with these financial covenants as of December 31, 2011. The Lake Park Lease is accounted
   for as an operating lease.

[0001193125-12-065358:notes:163]
Environmental

[0001193125-12-065358:notes:164]
Applicable environmental laws can potentially impose obligations to remediate hazardous substances at our properties, at properties
   formerly owned or operated by us and at facilities to which we have sent or send waste for treatment or disposal. We are aware of contamination at some facilities; however, we do not presently believe that any future remediation costs at such
   facilities will be material to our results of operations.

[0001193125-12-065358:notes:165]
The amount and timing of cash payments are reliably determinable
   and, therefore, we have recorded environmental reserves at their present values.

[0001193125-12-065358:notes:166]
The following information relates to our
   environmental reserves (in millions, except percentages):

[0001193125-12-065358:notes:167]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Discounted liabilities recorded in: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 1.3 |  |  | $ | 1.1 |  |
| Other liabilities |  |  | 3.1 |  |  |  | 3.3 |  |
|  |  | $ | 4.4 |  |  | $ | 4.4 |  |
| Undiscounted liabilities |  | $ | 4.7 |  |  | $ | 4.8 |  |
| Discount rate |  |  | 3.1%-4.7 | % |  |  | 1.3%-7.9 | % |

[0001193125-12-065358:notes:168]
Estimates of future costs are subject to change due to changing environmental remediation regulations and/or
   site-specific requirements.

[0001193125-12-065358:notes:169]
Total liabilities for estimated warranty are included in the following captions on the accompanying Consolidated Balance Sheets (in
   millions):

[0001193125-12-065358:notes:170]
|  |  | For the YearsEndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Accrued expenses |  | $ | 30.1 |  |  | $ | 31.2 |  |
| Other liabilities |  |  | 42.1 |  |  |  | 44.3 |  |
|  |  | $ | 72.2 |  |  | $ | 75.5 |  |

[0001193125-12-065358:notes:171]
The changes in the total warranty liabilities for the years ended December 31, 2011 and 2010 were as follows (in
   millions):

[0001193125-12-065358:notes:172]
| Total warranty liability as of December 31, 2009 |  | $ | 81.5 |  |
| Payments made in 2010 |  |  | (27.6 | ) |
| Changes resulting from issuance of new warranties |  |  | 27.6 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (6.2 | ) |
| Changes in foreign currency translation rates |  |  | 0.2 |  |
| Total warranty liability as of December 31, 2010 |  | $ | 75.5 |  |
| Payments made in 2011 |  |  | (27.7 | ) |
| Changes resulting from issuance of new warranties |  |  | 25.6 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (0.8 | ) |
| Changes in foreign currency translation rates |  |  | (0.4 | ) |
| Total warranty liability as of December 31, 2011 |  | $ | 72.2 |  |

[0001193125-12-065358:notes:173]
At the end of each accounting period, we evaluate our warranty liabilities across all segments. During the second
   quarter of each year, we perform a complete reevaluation of our HVAC warranty liabilities. As a result of our second quarter evaluation, we recorded a $2.5 million reduction in warranty liabilities that is the principal amount contained within the
   changes in estimates associated with pre-existing liabilities.

[0001193125-12-065358:notes:174]
We incur the risk of liability claims for the installation and
   service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if
   exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims may also not be covered by
   our product liability insurance. There have been no material changes in the circumstances since our latest fiscal year-end.

[0001193125-12-065358:notes:175]
We
   also may incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our
   customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001193125-12-065358:notes:176]
In addition to normal product warranty, we identified a product quality issue in a heating and cooling product line produced in 2006 and 2007 that we believe resulted from a vendor-supplied materials
   quality issue. The expense for this product quality issue, and the related liability, is not included in the above tables related to our estimated warranty liabilities. We did not incur any additional expense in 2011; however, we may incur
   additional charges in the future as more information becomes available. We decreased this liability by $1.4 million in the second quarter of 2011 to adjust the estimated claim cost based on historical claims paid. In the fourth quarter of 2011, we
   adjusted the estimated liability by an additional $1.4 million based on a lower expectation of remaining future claims. The expense related to this product quality issue was classified in Cost of Goods Sold in the Consolidated Statements of
   Operations and the related liability is included in Accrued expenses in the accompanying Consolidated Balance Sheets. The changes in the accrued product quality issue for the years ended December 31, 2011 and 2010 were as follows (in millions):

[0001193125-12-065358:notes:177]
| Total accrued product quality issue as of December 31, 2009 |  | $ | 21.6 |  |
| Product quality claims |  |  | (5.6 | ) |
| Total accrued product quality issue as of December 31, 2010 |  | $ | 16.0 |  |
| Product quality claims |  |  | (5.7 | ) |
| Changes in estimates associated with pre-existing liabilities |  |  | (2.8 | ) |
| Total accrued product quality issue as of December 31, 2011 |  | $ | 7.5 |  |

[0001193125-12-065358:notes:178]
Self
   Insurance

[0001193125-12-065358:notes:179]
We use a combination of third-party insurance and self-insurance plans (large deductible or captive) to
   provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures. Prior to the third quarter of 2009, these policies
   were written by a third-party insurance provider, which was then reinsured by our captive insurance subsidiary. Beginning in the third quarter of 2009, we now use large deductible insurance plans for workers’ compensation/employers’
   liability, general liability, product liability, and auto liability. These policies are written through third-party insurance providers. We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for
   directors’ and officers’ liability, property damage and various other insurance programs. We believe the limit within our excess policy is adequate for companies of our size in our industry. We believe that the deductibles and liability
   limits retained by LII and the captive are customary for companies of our size in our industry and are appropriate for our business.

[0001193125-12-065358:notes:180]
In addition, we use third-party insurance plans for property damage, aviation liability, directors’ and officers’ liability, and other exposures. Each of these policies may include per
   occurrence and annual aggregate limits. However, we believe these limits are customary for companies of our size in our industry and are appropriate for our business.

[0001193125-12-065358:notes:181]
We maintain safety and manufacturing programs that are designed to improve the safety and effectiveness of our business processes and, as a result, reduce the level and severity of our various
   self-insurance risks. In recent years, our actual claims experience has been trending favorably and therefore, both self-insurance expense and the related liability have decreased.

[0001193125-12-065358:notes:182]
Since we have a captive insurance company, we are required to maintain specified levels of liquid assets from which we must pay claims.
   The majority of our self-insured risks (excluding auto liability and physical damage) will be paid over an extended period of time. To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liability
   may change.

[0001193125-12-065358:notes:183]
The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were
   $63.3 million and $64.6 million as of December 31, 2011 and 2010, respectively.

[0001193125-12-065358:notes:184]
Litigation

[0001193125-12-065358:notes:185]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and
   estimated costs are recorded for such claims and lawsuits. It is management’s opinion that none of these claims or lawsuits will have a material adverse effect on our financial position, results of operations or cash flows. Costs related to
   such matters were not material to the periods presented.

[0001193125-12-065358:notes:186]
We estimate the costs to settle pending litigation based on
   experience involving similar claims and specific facts known. We do not believe that any current, or pending, or threatened litigation will have a material adverse effect on our financial position. Litigation and arbitration, however, involve
   uncertainties and it is possible that the eventual outcome of litigation could adversely affect our results of operations for a particular period.

[0001193125-12-065358:notes:187]
We were the defendant in a class action lawsuit seeking economic damages for the alleged diminished value of plaintiffs’ homes relative to certain hearth products we produced and sold. On
   June 10, 2011, the litigation of this matter concluded when the court issued its Order Granting Final Approval of Class Settlement; Final Judgment and Order of Dismissal. We do not expect to incur any significant additional expense and
   substantially all of the expenses incurred to date were paid.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-065358:notes:188]
13.    Lines of Credit and Financing Arrangements:

[0001193125-12-065358:notes:189]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated
   Balance Sheet (in millions):

[0001193125-12-065358:notes:190]
|  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Short-term debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 4.7 |  |  | $ | 1.4 |  |
| Total short-term debt |  | $ | 4.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt: |  | $ | 0.8 |  |  | $ | 0.6 |  |
| Long-term debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.6 |  |  |  | 17.0 |  |
| Domestic revolving credit facility |  |  | 243.0 |  |  |  | 100.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 459.6 |  |  | $ | 317.0 |  |
| Total debt |  | $ | 465.1 |  |  | $ | 319.0 |  |

[0001193125-12-065358:notes:191]
As of December 31, 2011, the aggregate amounts of required
   principal payments on long-term debt are as follows (in millions):

[0001193125-12-065358:notes:192]
| 2012 |  | $ | 0.8 |  |
| 2013 |  |  | 0.8 |  |
| 2014 |  |  | 0.7 |  |
| 2015 |  |  | 0.7 |  |
| 2016 |  |  | 243.0 |  |
| Thereafter |  |  | 214.4 |  |

[0001193125-12-065358:notes:193]
Short-Term Debt

[0001193125-12-065358:notes:194]
Foreign Obligations

[0001193125-12-065358:notes:195]
Through several of our foreign subsidiaries, we have
   $1.8 million in committed combined foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $1.5 million and $10.1 million of available capacity as of December 31, 2011 and 2010, respectively. Our
   foreign obligations of $4.7 million primarily represented borrowings under non-committed facilities.

[0001193125-12-065358:notes:196]
Asset Securitization

[0001193125-12-065358:notes:197]
On November 18, 2011, we amended the Receivables Purchase Agreement ( “RPA”). The most significant changes
   to the RPA include the addition of Allied Air Enterprises LLC, Heatcraft Refrigeration Products LLC, and Lennox Hearth Products LLC, all wholly-owned subsidiaries, as sellers of trade accounts receivable under the program, an increase in the
   purchase limit to $150.0 million from $100.0 million, and the extension of the Agreement to November 16, 2012.

[0001193125-12-065358:notes:198]
Under the
   RPA, LPAC Corp. (LPAC), a wholly-owned subsidiary, is eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The RPA is subject to renewal and contains a provision
   whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. LPAC
   is a separate corporate entity with its own separate creditors that will be entitled to be satisfied out of LPAC’s assets prior to any value becoming available to the Seller’s equity holders. All of the assets of LPAC are owned by LPAC.

[0001193125-12-065358:notes:199]
The accounts receivable sold under the RPA are high quality domestic customer accounts
   that have not aged significantly and the program takes into account an allowance for uncollectable accounts. The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the
   pool of receivables sold under the RPA. The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.

[0001193125-12-065358:notes:200]
The sale of the beneficial interests in our trade accounts receivable is included in cash flows from financing activities in the accompanying Consolidated
   Statements of Cash Flows. The RPA provides for a maximum securitization amount of the lesser of $150.0 million or the net pool balance as defined by the RPA. However, eligibility for securitization is limited based on the amount and quality of the
   qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001193125-12-065358:notes:201]
|  |  | As ofDecember 31,2011 |  |  | As ofDecember 31,2010 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 150.0 |  |  | $ | 100.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 150.0 |  |  | $ | 100.0 |  |

[0001193125-12-065358:notes:202]
Under the RPA, we pay certain discount fees to use the program and have the facility available to us. These fees relate
   to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee
   of 0.60%. The average rate for December 31, 2011 was 0.91% and the rate at December 31, 2010 was 1.06%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate
   throughout the term of the agreement. The amounts recorded were as follows (in millions):

[0001193125-12-065358:notes:203]
|  |  | For the YearsEndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Interest Expense (including fees) |  | $ | 0.7 |  |  | $ | 0.5 |  |  | $ | 0.7 |  |

[0001193125-12-065358:notes:204]
The RPA contains certain restrictive covenants relating to the quality of our accounts receivable and cross default
   provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement (“Domestic Revolving Credit Facility). The administrative agent under the RPA is also a participant in our Domestic Revolving Credit Facility. The participating
   financial institutions have investment grade credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the RPA. As of December 31, 2011, we were in compliance with all covenant
   requirements.

[0001193125-12-065358:notes:205]
Long-Term Debt

[0001193125-12-065358:notes:206]
Domestic Revolving Credit Facility

[0001193125-12-065358:notes:207]
On October 21, 2011, we amended
   the Third Amended and Restated Credit Agreement, dated October 12, 2007, by entering into the Domestic Revolving Credit Facility. This amended facility provides for up to $650 million in unsecured borrowings and issuance of letters of
   credit up to the full amount of the facility. The maturity date was extended to October 21, 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a
   maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001193125-12-065358:notes:208]
As of
   December 31, 2011, we had $243.0 million in outstanding borrowings and $78.5 million committed to standby letters of credit. Subject to covenant limitations, $328.5 million was available for future borrowings.

[0001193125-12-065358:notes:209]
Our weighted
   average borrowing rate on the facility was as follows:

[0001193125-12-065358:notes:210]
|  |  | As of December 31,2011 |  |  | As of December 31,2010 |  |
| Weighted average borrowing rate |  |  | 1.53 | % |  |  | 0.96 | % |

[0001193125-12-065358:notes:211]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants
   relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our domestic revolving credit
   facility are detailed below:

[0001193125-12-065358:notes:212]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |

[0001193125-12-065358:notes:213]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default
   include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our Domestic
   Revolving Credit Facility could occur if:

[0001193125-12-065358:notes:214]
|  | • |  | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001193125-12-065358:notes:215]
|  | • |  | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001193125-12-065358:notes:216]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross
   default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, or our RPA were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or
   lease commitment.

[0001193125-12-065358:notes:217]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may
   require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such
   amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2011, we were in compliance with all covenant requirements.

[0001193125-12-065358:notes:218]
Senior Unsecured Notes

[0001193125-12-065358:notes:219]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per
   annum. These notes mature on May 15, 2017.

[0001193125-12-065358:notes:220]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic
   subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors
   to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross
   default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of December 31, 2011, we were in
   compliance with all covenant requirements.

[0001193125-12-065358:notes:221]
Credit
   Rating

[0001193125-12-065358:notes:222]
At December 31, 2011, our senior credit ratings were Baa3, with a negative outlook, and BBB-, with a
   stable outlook by Moody’s and Standard & Poor’s Rating Group (“S&P”), respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-12-065358:notes:223]
14.    Employee Benefit Plans:

[0001193125-12-065358:notes:224]
Defined Contribution Plans

[0001193125-12-065358:notes:225]
We maintain noncontributory profit sharing plans for our eligible domestic and Canadian salaried employees. These plans are discretionary, as our contributions are determined annually by the Board of
   Directors. We also sponsor several defined contribution plans with employer contribution-matching requirements. We recorded the following (in millions):

[0001193125-12-065358:notes:226]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Contributions to defined contribution plans |  | $ | 14.3 |  |  | $ | 12.1 |  |  | $ | 12.4 |  |

[0001193125-12-065358:notes:227]
Pension and Postretirement Benefit Plans

[0001193125-12-065358:notes:228]
We provide pension and postretirement medical benefits to eligible domestic and foreign employees. In the third quarter of 2008, we
   announced that we were freezing our defined benefit pension and profit sharing plans for our domestic and Canadian salaried employees and moving to an enhanced defined contribution plan in 2009 for our domestic salaried employees and 2010 for our
   Canadian salaried employees. We also maintain an unfunded postretirement benefit plan, which provides certain medical and life insurance benefits to eligible employees. In 2006, we amended the postretirement benefit plan to (i) eliminate
   post-65 coverage for current and future nonunion retirees and (ii) gradually shift the pre-65 medical coverage cost from us to participants starting in 2007 such that by 2010, pre-65 retirees would be paying 100% of the cost. As a result of
   this amendment, the postretirement plan still existed in 2011 and eligible nonunion participants will still be able to receive group coverage rates. However, we won’t be paying any portion of the participants’ premiums.

[0001193125-12-065358:notes:229]
The following tables set forth amounts recognized in our financial statements and the plans’ funded status (dollars in millions):

[0001193125-12-065358:notes:230]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Accumulated benefit obligation |  | $ | 363.6 |  |  | $ | 333.2 |  |  | $ | N/A |  |  | $ | N/A |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year |  | $ | 336.3 |  |  | $ | 299.4 |  |  | $ | 17.0 |  |  | $ | 14.4 |  |
| Service cost |  |  | 5.4 |  |  |  | 5.0 |  |  |  | 0.8 |  |  |  | 0.6 |  |
| Interest cost |  |  | 17.8 |  |  |  | 17.6 |  |  |  | 0.9 |  |  |  | 0.8 |  |
| Plan participants’ contributions |  |  | — |  |  |  | — |  |  |  | 0.8 |  |  |  | 0.8 |  |
| Amendments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Actuarial loss |  |  | 28.9 |  |  |  | 34.0 |  |  |  | 2.3 |  |  |  | 2.4 |  |
| Effect of exchange rates |  |  | (0.7 | ) |  |  | 0.4 |  |  |  | — |  |  |  | — |  |
| Settlements and curtailments |  |  | (2.1 | ) |  |  | (2.6 | ) |  |  | — |  |  |  | — |  |
| Benefits paid |  |  | (16.8 | ) |  |  | (17.5 | ) |  |  | (1.9 | ) |  |  | (1.9 | ) |
| Benefit obligation at end of year |  | $ | 368.8 |  |  | $ | 336.3 |  |  | $ | 19.9 |  |  | $ | 17.0 |  |
| Changes in plan assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year |  | $ | 244.6 |  |  | $ | 231.1 |  |  | $ | — |  |  | $ | — |  |
| Actual gain return on plan assets |  |  | 3.8 |  |  |  | 27.6 |  |  |  | — |  |  |  | — |  |
| Employer contribution |  |  | 13.4 |  |  |  | 5.6 |  |  |  | 1.1 |  |  |  | 1.1 |  |
| Plan participants’ contributions |  |  | — |  |  |  | — |  |  |  | 0.8 |  |  |  | 0.8 |  |
| Effect of exchange rates |  |  | (0.4 | ) |  |  | 0.4 |  |  |  | — |  |  |  | — |  |
| Plan settlements |  |  | (2.1 | ) |  |  | (2.6 | ) |  |  | — |  |  |  | — |  |
| Benefits paid |  |  | (16.8 | ) |  |  | (17.5 | ) |  |  | (1.9 | ) |  |  | (1.9 | ) |
| Fair value of plan assets at end of year |  |  | 242.5 |  |  |  | 244.6 |  |  |  | — |  |  |  | — |  |
| Funded status/net amount recognized |  | $ | (126.3 | ) |  | $ | (91.7 | ) |  | $ | (19.9 | ) |  | $ | (17.0 | ) |
| Net amount recognized consists of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liability |  | $ | (1.6 | ) |  | $ | (3.6 | ) |  | $ | (1.3 | ) |  | $ | (1.1 | ) |
| Non-current liability |  |  | (124.7 | ) |  |  | (88.1 | ) |  |  | (18.6 | ) |  |  | (15.9 | ) |
| Net amount recognized |  | $ | (126.3 | ) |  | $ | (91.7 | ) |  | $ | (19.9 | ) |  | $ | (17.0 | ) |

[0001193125-12-065358:notes:231]
Included in the Non-Current Pension Liability on the Consolidated Balance Sheets were plans with an over-funded position
   of $0.1 million as of December 31, 2010 (in millions). No plans were overfunded as of December 31, 2011.

[0001193125-12-065358:notes:232]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |  |  |  |  |  |
| Projected benefit obligation |  | $ | 368.1 |  |  | $ | 335.6 |  |
| Accumulated benefit obligation |  |  | 362.9 |  |  |  | 332.5 |  |
| Fair value of plan assets |  |  | 241.8 |  |  |  | 243.8 |  |

[0001193125-12-065358:notes:233]
Our U.S.-based pension plans comprised approximately 89.2% of the projected benefit obligation and 88.8% of plan assets
   as of December 31, 2011.

[0001193125-12-065358:notes:234]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 5.4 |  |  | $ | 5.0 |  |  | $ | 5.6 |  |  | $ | 0.8 |  |  | $ | 0.6 |  |  | $ | 0.5 |  |
| Interest cost |  |  | 17.8 |  |  |  | 17.6 |  |  |  | 17.5 |  |  |  | 0.9 |  |  |  | 0.8 |  |  |  | 0.8 |  |
| Expected return on plan assets |  |  | (19.0 | ) |  |  | (19.5 | ) |  |  | (16.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.4 |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | (1.9 | ) |  |  | (1.9 | ) |  |  | (1.9 | ) |
| Recognized actuarial loss |  |  | 7.0 |  |  |  | 5.1 |  |  |  | 8.9 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Settlements and curtailments |  |  | 1.7 |  |  |  | 1.4 |  |  |  | 1.0 |  |  |  | — |  |  |  | — |  |  |  | (0.6 | ) |
| Net periodic benefit cost |  | $ | 13.3 |  |  | $ | 10.1 |  |  | $ | 16.8 |  |  | $ | 1.0 |  |  | $ | 0.7 |  |  | $ | — |  |

[0001193125-12-065358:notes:235]
The following table
   sets forth amounts recognized in AOCI in our financial statements for 2011 and 2010 (in millions):

[0001193125-12-065358:notes:236]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Amounts recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service costs |  | $ | (2.6 | ) |  | $ | (3.5 | ) |  | $ | 12.7 |  |  | $ | 14.7 |  |
| Actuarial loss |  |  | (212.0 | ) |  |  | (176.2 | ) |  |  | (20.8 | ) |  |  | (19.8 | ) |
| Subtotal |  |  | (214.6 | ) |  |  | (179.7 | ) |  |  | (8.1 | ) |  |  | (5.1 | ) |
| Deferred taxes |  |  | 78.6 |  |  |  | 66.2 |  |  |  | 3.1 |  |  |  | 1.9 |  |
| Net amount recognized |  | $ | (136.0 | ) |  | $ | (113.5 | ) |  | $ | (5.0 | ) |  | $ | (3.2 | ) |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current year prior service costs |  | $ | — |  |  | $ | — |  |  |  | — |  |  | $ | (0.1 | ) |
| Current year actuarial loss |  |  | 44.4 |  |  |  | 25.8 |  |  |  | 2.3 |  |  |  | 2.4 |  |
| Effect of exchange rates |  |  | (0.4 | ) |  |  | 0.3 |  |  |  | — |  |  |  | — |  |
| Amortization of prior service (costs) credits |  |  | (0.9 | ) |  |  | (0.5 | ) |  |  | 1.9 |  |  |  | 1.9 |  |
| Amortization of actuarial loss |  |  | (8.2 | ) |  |  | (6.5 | ) |  |  | (1.2 | ) |  |  | (1.3 | ) |
| Total recognized in other comprehensive income |  | $ | 34.9 |  |  | $ | 19.1 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) |  | $ | 48.2 |  |  | $ | 29.2 |  |  | $ | 4.0 |  |  | $ | 3.6 |  |

[0001193125-12-065358:notes:237]
The estimated prior service (costs) credits and actuarial gains (losses) that will be amortized from AOCI in 2012 are
   $(0.4) million and $(9.2) million, respectively, for pension benefits and $1.9 million and $(1.2) million, respectively, for other benefits.

[0001193125-12-065358:notes:238]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the U.S.-based plans in 2011 and 2010:

[0001193125-12-065358:notes:239]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  |  | 4.83 | % |  |  | 5.45 | % |  |  | 4.64 | % |  |  | 5.30 | % |
| Rate of compensation increase |  |  | 4.23 |  |  |  | 4.23 |  |  |  | — |  |  |  | — |  |

[0001193125-12-065358:notes:240]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  |  | 5.45 | % |  |  | 6.07 | % |  |  | 6.27 | % |  |  | 5.30 | % |  |  | 5.95 | % |  |  | 6.42 | % |
| Expected long-term return on plan assets |  |  | 8.00 |  |  |  | 8.00 |  |  |  | 8.25 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Rate of compensation increase |  |  | 4.23 |  |  |  | 4.23 |  |  |  | 4.19 |  |  |  | — |  |  |  | — |  |  |  | — |  |

[0001193125-12-065358:notes:241]
The following
   tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the non-U.S.-based plans in 2011 and 2010:

[0001193125-12-065358:notes:242]
|  |  | PensionBenefits |  |
|  |  | 2011 |  |  | 2010 |  |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |
| Discount rate |  |  | 4.93 | % |  |  | 5.43 | % |
| Rate of compensation increase |  |  | 3.68 |  |  |  | 3.94 |  |

[0001193125-12-065358:notes:243]
|  |  | Pension Benefits |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  |  | 5.43 | % |  |  | 5.98 | % |  |  | 6.57 | % |
| Expected long-term return on plan assets |  |  | 5.56 |  |  |  | 5.59 |  |  |  | 6.24 |  |
| Rate of compensation increase |  |  | 3.98 |  |  |  | 3.98 |  |  |  | 3.90 |  |

[0001193125-12-065358:notes:244]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical
   returns and the future expectations for returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic rebalancing. These results were adjusted for the payment of reasonable expenses of
   the plan from plan assets. This resulted in the selection of the 8.00% long-term rate of return on assets assumption. A similar process was followed for the non-U.S.-based plans.

[0001193125-12-065358:notes:245]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the
   duration of projected cash flows from defined benefit and retiree healthcare plans were matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis
   to select the discount rate that matched the duration and payment stream of the benefits in each plan. This resulted in the selection of the 4.85% discount rate assumption for the U.S. qualified pension plans, 4.59% for the U.S. non-qualified
   pension plans, and 4.64% for the other benefits. A similar process was followed for the non-U.S.-based plans.

[0001193125-12-065358:notes:246]
|  |  | 2011 |  |  | 2010 |  |
| Assumed health care cost trend rates as of December 31: |  |  |  |  |  |  |  |  |
| Health care cost trend rate assumed for next year |  |  | 8.40 | % |  |  | 8.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) |  |  | 5.00 | % |  |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate |  |  | 2020 |  |  |  | 2020 |  |

[0001193125-12-065358:notes:247]
Assumed health care cost trend rates have a significant effect on the amounts reported for our healthcare plan. A one
   percentage-point change in assumed healthcare cost trend rates would have the following effects (in millions):

[0001193125-12-065358:notes:248]
|  |  | 1-Percentage-Point Increase |  |  | 1-Percentage-Point Decrease |  |
| Effect on total of service and interest cost |  | $ | 0.2 |  |  | $ | (0.2 | ) |
| Effect on the postretirement benefit obligation |  |  | 2.0 |  |  |  | (1.7 | ) |

[0001193125-12-065358:notes:249]
Expected future benefit payments are shown in the table below (in millions):

[0001193125-12-065358:notes:250]
|  |  | Years Ended December 31, |  |
|  |  | 2012 |  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017- 2021 |  |
| Pension benefits |  | $ | 16.5 |  |  | $ | 18.8 |  |  | $ | 17.3 |  |  | $ | 18.5 |  |  | $ | 18.7 |  |  | $ | 109.2 |  |
| Other benefits |  |  | 1.3 |  |  |  | 1.3 |  |  |  | 1.3 |  |  |  | 1.3 |  |  |  | 1.4 |  |  |  | 7.7 |  |

[0001193125-12-065358:notes:251]
We believe that by adequately diversifying the plan assets, asset returns can be
   optimized at an acceptable level of risk. Since equity securities have historically generated higher returns than fixed income securities and the plan is not fully funded, we believe it is appropriate to allocate more assets to equities than
   fixed income securities. In addition, these categories are further diversified among various asset classes including high yield and emerging markets debt, and international and emerging markets equities in order to avoid significant
   concentrations of risk. Our U.S. pension plan represents approximately 90%, our Canadian pension plan approximately 6%, and our United Kingdom (“U.K.”) pension plan approximately 4% of the total fair value of our plan assets as of
   December 31, 2010.

[0001193125-12-065358:notes:252]
Our U.S. pension plans’ weighted-average asset allocations as of December 31, 2011 and 2010,
   by asset category, are as follows:

[0001193125-12-065358:notes:253]
|  |  | Plan Assets as ofDecember 31, |  |
| Asset Category |  | 2011 |  |  | 2010 |  |
| U.S. equity |  |  | 33.6 | % |  |  | 33.1 | % |
| International equity |  |  | 24.4 |  |  |  | 28.5 |  |
| Fixed income |  |  | 41.2 |  |  |  | 36.8 |  |
| Money market/cash/guaranteed investment contracts |  |  | 0.8 |  |  |  | 1.6 |  |
| Total |  |  | 100 | % |  |  | 100.0 | % |

[0001193125-12-065358:notes:254]
U.S. pension plan investments are invested within the following
   range targets:

[0001193125-12-065358:notes:255]
| Asset Category |  | Target |  |
| U.S. equity |  |  | 36.0 | % |
| International equity |  |  | 24.0 | % |
| Fixed income |  |  | 38.0 | % |
| Money market/cash/guaranteed investment contracts |  |  | 2.0 | % |

[0001193125-12-065358:notes:256]
Our Canadian pension plan was invested in only one asset, which is a balanced fund that maintains diversification among
   various asset classes, including Canadian common stocks, bonds and money market securities, U.S. equities, other international equities and fixed income investments. Our U.K. pension plan was invested in a broad mix of assets consisting of U.K.,
   U.S. and international equities, U.K. fixed income securities, including corporate and government bonds, and bank deposits.

[0001193125-12-065358:notes:257]
The fair values of our pension plan
   assets, by asset category, are as follows:

[0001193125-12-065358:notes:258]
|  |  | Fair Value Measurements as ofDecember 31, 2011 |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOther ObservableInputs(Level 2) |  |  | SignificantUnobservable Inputs(Level 3) |  |  | Total |  |
| Assets Category: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.7 |  |
| Commingled pools/Collective Trusts |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(1) |  |  | — |  |  |  | 33.4 |  |  |  | — |  |  |  | 33.4 |  |
| International equity(2) |  |  | — |  |  |  | 48.3 |  |  |  | — |  |  |  | 48.3 |  |
| Fixed income(3) |  |  | — |  |  |  | 81.9 |  |  |  | — |  |  |  | 81.9 |  |
| Mutual funds |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(4) |  |  | 38.8 |  |  |  | — |  |  |  | — |  |  |  | 38.8 |  |
| International equity(4) |  |  | 4.4 |  |  |  | — |  |  |  | — |  |  |  | 4.4 |  |
| Fixed income(5) |  |  | 6.9 |  |  |  | — |  |  |  | — |  |  |  | 6.9 |  |
| Balanced pension trust(6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity |  |  | — |  |  |  | 2.1 |  |  |  | — |  |  |  | 2.1 |  |
| International equity |  |  | — |  |  |  | 6.5 |  |  |  | — |  |  |  | 6.5 |  |
| Bonds |  |  | — |  |  |  | 4.4 |  |  |  | — |  |  |  | 4.4 |  |
| Pension fund |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(7) |  |  | — |  |  |  | 1.1 |  |  |  | — |  |  |  | 1.1 |  |
| International equity(7) |  |  | — |  |  |  | 5.5 |  |  |  | — |  |  |  | 5.5 |  |
| Fixed income(8) |  |  | — |  |  |  | 4.8 |  |  |  | — |  |  |  | 4.8 |  |
| Money market instruments(9) |  |  | — |  |  |  | 0.7 |  |  |  | — |  |  |  | 0.7 |  |
| Guaranteed investment contracts |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 53.8 |  |  | $ | 188.7 |  |  | $ | — |  |  | $ | 242.5 |  |

[0001193125-12-065358:notes:259]
|  |  | Fair Value Measurements as ofDecember 31, 2010 |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOther ObservableInputs(Level 2) |  |  | SignificantUnobservable Inputs(Level 3) |  |  | Total |  |
| Assets Category: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.9 |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(1) |  |  | — |  |  |  | 33.7 |  |  |  | — |  |  |  | 33.7 |  |
| International equity(2) |  |  | — |  |  |  | 53.8 |  |  |  | — |  |  |  | 53.8 |  |
| Fixed income(3) |  |  | — |  |  |  | 74.0 |  |  |  | — |  |  |  | 74.0 |  |
| Mutual funds |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(4) |  |  | 38.2 |  |  |  | — |  |  |  | — |  |  |  | 38.2 |  |
| International equity(4) |  |  | 6.5 |  |  |  | — |  |  |  | — |  |  |  | 6.5 |  |
| Fixed income(5) |  |  | 6.2 |  |  |  | — |  |  |  | — |  |  |  | 6.2 |  |
| Balanced pension trust(6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity |  |  | — |  |  |  | 2.1 |  |  |  | — |  |  |  | 2.1 |  |
| International equity |  |  | — |  |  |  | 7.4 |  |  |  | — |  |  |  | 7.4 |  |
| Bonds |  |  | — |  |  |  | 5.3 |  |  |  | — |  |  |  | 5.3 |  |
| Pension fund |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(7) |  |  | — |  |  |  | 1.1 |  |  |  | — |  |  |  | 1.1 |  |
| International equity(7) |  |  | — |  |  |  | 5.7 |  |  |  | — |  |  |  | 5.7 |  |
| Fixed income(8) |  |  | — |  |  |  | 4.1 |  |  |  | — |  |  |  | 4.1 |  |
| Money market instruments(9) |  |  | — |  |  |  | 0.8 |  |  |  | — |  |  |  | 0.8 |  |
| Guaranteed investment contracts |  |  | — |  |  |  | 1.8 |  |  |  | — |  |  |  | 1.8 |  |
| Total |  | $ | 54.8 |  |  | $ | 189.8 |  |  | $ | — |  |  | $ | 244.6 |  |

[0001193125-12-065358:notes:260]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001193125-12-065358:notes:261]
|  |  | As of December 31, 2011 |
|  |  | Fair Value |  |  | Redemption Frequency(if currently eligible) |  | Redemption NoticePeriod |
| Assets Category: |  |  |  |  |  |  |  |  |
| Commingled pools/Collective Trusts |  |  |  |  |  |  |  |  |
| U.S. equity(1) |  | $ | 33.4 |  |  | n/a |  | n/a |
| International equity(2) |  |  | 48.3 |  |  | Monthly |  | 10 —15 days |
| Fixed income(3) |  |  | 81.9 |  |  | Quarterly |  | 15 days |
| Mutual funds |  |  |  |  |  |  |  |  |
| U.S. equity(4) |  |  | 38.8 |  |  | n/a |  | n/a |
| International equity(4) |  |  | 4.4 |  |  | n/a |  | n/a |
| Fixed income(5) |  |  | 6.9 |  |  | n/a |  | n/a |
| Balanced pension trust(6) |  |  |  |  |  |  |  |  |
| U.S. equity |  |  | 2.1 |  |  | Daily |  | 5 days |
| International equity |  |  | 6.5 |  |  | Daily |  | 5 days |
| Bonds |  |  | 4.4 |  |  | Daily |  | 5 days |
| Pension fund |  |  |  |  |  |  |  |  |
| U.S. equity(7) |  |  | 1.1 |  |  | Daily |  | 7 days |
| International equity(7) |  |  | 5.5 |  |  | Daily |  | 7 days |
| Fixed income(8) |  |  | 4.8 |  |  | Daily |  | 7 days |
| Money market instruments(9) |  |  | 0.7 |  |  | Daily |  | 7 days |
| Total |  | $ | 238.8 |  |  |  |  |  |

[0001193125-12-065358:notes:262]
|  |  | As of December 31, 2010 |
|  |  | Fair Value |  |  | Redemption Frequency(ifcurrently eligible) |  | Redemption NoticePeriod |
| Assets Category: |  |  |  |  |  |  |  |  |
| Commingled pools/Collective Trusts |  |  |  |  |  |  |  |  |
| U.S. equity(1) |  | $ | 33.7 |  |  | n/a |  | n/a |
| International equity(2) |  |  | 53.8 |  |  | Monthly |  | 10 —15 days |
| Fixed income(3) |  |  | 74.0 |  |  | Quarterly |  | 15 days |
| Mutual funds |  |  |  |  |  |  |  |  |
| U.S. equity(4) |  |  | 38.2 |  |  | n/a |  | n/a |
| International equity(4) |  |  | 6.5 |  |  | n/a |  | n/a |
| Fixed income(5) |  |  | 6.2 |  |  | n/a |  | n/a |
| Balanced pension trust(6) |  |  |  |  |  |  |  |  |
| U.S. equity |  |  | 2.1 |  |  | Daily |  | 5 days |
| International equity |  |  | 7.4 |  |  | Daily |  | 5 days |
| Bonds |  |  | 5.3 |  |  | Daily |  | 5 days |
| Pension fund |  |  |  |  |  |  |  |  |
| U.S. equity(7) |  |  | 1.1 |  |  | Daily |  | 7 days |
| International equity(7) |  |  | 5.7 |  |  | Daily |  | 7 days |
| Fixed income(8) |  |  | 4.1 |  |  | Daily |  | 7 days |
| Money market instruments(9) |  |  | 0.8 |  |  | Daily |  | 7 days |
| Total |  | $ | 238.9 |  |  |  |  |  |

[0001193125-12-065358:notes:263]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |

[0001193125-12-065358:notes:264]
| (2) | This category includes investments primarily in non-U.S. equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |

[0001193125-12-065358:notes:265]
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, non-U.S. fixed income securities and emerging markets fixed income securities. |

[0001193125-12-065358:notes:266]
| (4) | These funds seek capital appreciation and generally invest in common stocks of U.S. and non-U.S. issuers. They may invest in growth stocks or value stocks. |

[0001193125-12-065358:notes:267]
| (5) | This fund seeks to provide inflation protection. It currently invests at least 80% of its assets in inflation-indexed bonds issued by the U.S. government. It may invest in bonds of any maturity, though the fund typically maintains a dollar-weighted average maturity of 7 to 20 years. |

[0001193125-12-065358:notes:268]
| (6) | The investment objectives of the fund are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The fund also holds a portion of its assets in U.S. and non-U.S. equities. |

[0001193125-12-065358:notes:269]
| (7) | This category includes investments in U.S. and non-U.S. equity securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |

[0001193125-12-065358:notes:270]
| (8) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer and investment grade corporate bonds denominated in sterling. |

[0001193125-12-065358:notes:271]
| (9) | This fund invests in U.K. money market instruments and includes cash, bank deposits and short-term fixed interest investments. |

[0001193125-12-065358:notes:272]
The majority of our commingled pool /collective trust, mutual funds and balanced pension trusts are managed by
   professional investment advisors. The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies. We have assessed the classification of the
   inputs used to value these investments at Level 1 for mutual funds and Level 2 for commingled pool / collective trusts and balanced pension trusts through examination of their pricing policies and the related controls and procedures. The fair values we report are
   based on the pool or trust’s NAV per share. The NAV’s per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the number of units
   owned.

[0001193125-12-065358:notes:273]
See Note 22 for information about our fair value hierarchies and valuation techniques.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-12-065358:notes:274]
15.     Comprehensive (Loss) Income:

[0001193125-12-065358:notes:275]
Our accumulated balances, shown net of tax for each classification of comprehensive (loss) income are as follows (in
   millions):

[0001193125-12-065358:notes:276]
|  |  | ForeignCurrencyTranslation Adjustment |  |  | Pension andPostretirementLiability |  |  | Derivativesand Other |  |  | Total |  |
| Balance as of December 31, 2008 |  |  | 33.8 |  |  | $ | (111.5 | ) |  | $ | (21.1 | ) |  | $ | (98.8 | ) |
| Net change in currency translation and pension and postretirement liability during 2009 |  |  | 59.5 |  |  |  | 8.1 |  |  |  | — |  |  |  | 67.6 |  |
| Net change associated with 2009 derivative and other transactions |  |  | — |  |  |  | — |  |  |  | 10.7 |  |  |  | 10.7 |  |
| Reclassification of derivative gains into earnings |  |  | — |  |  |  | — |  |  |  | 19.7 |  |  |  | 19.7 |  |
| Balance as of December 31, 2009 |  | $ | 93.3 |  |  | $ | (103.4 | ) |  | $ | 9.3 |  |  | $ | (0.8 | ) |
| Net change in currency translation and pension and postretirement liability during 2010 |  |  | 28.2 |  |  |  | (13.3 | ) |  |  | — |  |  |  | 14.9 |  |
| Net change associated with 2010 derivative and other transactions |  |  | — |  |  |  | — |  |  |  | 27.5 |  |  |  | 27.5 |  |
| Reclassification of derivative gains into earnings |  |  | — |  |  |  | — |  |  |  | (11.4 | ) |  |  | (11.4 | ) |
| Balance as of December 31, 2010 |  | $ | 121.5 |  |  | $ | (116.7 | ) |  | $ | 25.4 |  |  | $ | 30.2 |  |
| Net change in currency translation and pension and postretirement liability during 2011 |  |  | (17.7 | ) |  |  | (24.3 | ) |  |  | — |  |  |  | (42.0 | ) |
| Net change associated with 2011 derivative and other transactions |  |  | — |  |  |  | — |  |  |  | (12.9 | ) |  |  | (12.9 | ) |
| Reclassification of derivative gains into earnings |  |  | — |  |  |  | — |  |  |  | (12.4 | ) |  |  | (12.4 | ) |
| Balance as of December 31, 2011 |  | $ | 103.8 |  |  | $ | (141.0 | ) |  | $ | 0.1 |  |  | $ | (37.1 | ) |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-12-065358:notes:277]
16.     Share Repurchases:

[0001193125-12-065358:notes:278]
During 2008, our Board of Directors approved a $300.0 million share repurchase plan authorizing the repurchase of
   shares of our common stock through open market purchases (the “2008 Share Repurchase Plan”). In December 2011, our Board of Directors increased the 2008 Share Repurchase Plan by $100 million.

[0001193125-12-065358:notes:279]
The following table
   summarizes the share repurchase activity for years ended December 31, 2011, 2010 and 2009, by the 2008 Share Repurchase Plan and those related to share-based payments (in millions, except per share data):

[0001193125-12-065358:notes:280]
|  |  | Related toShare-BasedPayments |  |  | 2008 Plan |  |  | Total ShareRepurchaseActivity |  |
| 2011 share repurchase activity: |  |  |  |  |  |  |  |  |  |  |  |  |
| Number of shares |  |  | 0.1 |  |  |  | 3.2 |  |  |  | 3.3 |  |
| Weighted average price per share |  | $ | 39.26 |  |  | $ | 37.11 |  |  | $ | 37.16 |  |
| Amount Repurchased |  | $ | 3.3 |  |  | $ | 119.7 |  |  | $ | 123.0 |  |
| 2010 share repurchase activity: |  |  |  |  |  |  |  |  |  |  |  |  |
| Number of shares |  |  | 0.2 |  |  |  | 3.3 |  |  |  | 3.5 |  |
| Weighted average price per share |  | $ | 44.83 |  |  | $ | 43.97 |  |  | $ | 44.02 |  |
| Amount repurchased |  | $ | 9.4 |  |  | $ | 144.3 |  |  | $ | 153.7 |  |
| 2009 share repurchase activity: |  |  |  |  |  |  |  |  |  |  |  |  |
| Number of shares |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Weighted average price per share |  | $ | 30.55 |  |  | $ | — |  |  | $ | 30.55 |  |
| Amount repurchased |  | $ | 5.6 |  |  | $ | — |  |  | $ | 5.6 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-065358:notes:281]
17.     Stock-Based Compensation Plans:

[0001193125-12-065358:notes:282]
Stock-Based Compensation expense is included in Selling, General and Administrative expenses in the accompanying
   Consolidated Statements of Operations as follows (in millions):

[0001193125-12-065358:notes:283]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Compensation expense (1) |  | $ | 13.7 |  |  | $ | 15.4 |  |  | $ | 12.8 |  |

[0001193125-12-065358:notes:284]
| (1) | Stock-Based Compensation expense is recorded in our Corporate and other business segment. |

[0001193125-12-065358:notes:285]
Excess tax benefits classified as a financing cash inflow in the accompanying Consolidated Statements of Cash Flows were as follows (in
   millions):

[0001193125-12-065358:notes:286]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Excess tax benefits |  | $ | 1.4 |  |  | $ | 5.3 |  |  | $ | 4.9 |  |

[0001193125-12-065358:notes:287]
Incentive Plan

[0001193125-12-065358:notes:288]
Under the Lennox International Inc. 2010 Incentive Plan, as amended and restated (the “2010 Incentive Plan”), we are authorized to issue awards for 24,254,706 shares of common stock. As of
   December 31, 2011, awards for 21,106,551 shares of common stock had been granted, net of cancellations and repurchases. Consequently, as of December 31, 2011, there were 3,148,155 shares available for future issuance.

[0001193125-12-065358:notes:289]
The 2010 Incentive Plan provides for various long-term incentive awards, which include stock options, performance share units, restricted
   stock units and stock appreciation rights. A description of these long-term incentive awards and related activity within each award category is provided below.

[0001193125-12-065358:notes:290]
Performance
   Share Units

[0001193125-12-065358:notes:291]
Under the 2010 Incentive Plan, performance share units are granted to certain
   employees at the discretion of the Board of Directors with a three-year performance period beginning
   January 1st of each year. Upon meeting the
   performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock. Outstanding awards granted prior to 2003 vest after ten years of service at the target amount.

[0001193125-12-065358:notes:292]
Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been
   attained. To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited. Eligible participants may also earn additional units of our common stock, which would
   increase the potential payout from 101% to 200% of the units granted, depending on LII’s performance over the three-year performance period.

[0001193125-12-065358:notes:293]
Performance share units under the 2010 Incentive Plan are classified as equity awards, with the fair value of each unit equal to the average of the high and low market price of the stock on the date of
   grant for units granted prior to December 2007. The fair value of units granted after December 2007 is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.
   Units are amortized to expense ratably over the service period. The compensation expense for any additional units which may be earned is estimated each reporting period based on the fair value of the stock at the date of grant. The number of units
   expected to be earned will be adjusted, as necessary, to reflect the actual number of units awarded.

[0001193125-12-065358:notes:294]
The following table
   provides information on our performance share units (dollars in millions, except weighted-average grant date fair value):

[0001193125-12-065358:notes:295]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Performance Share Units: |  |  |  |  |  |  |  |  |  |  |  |  |
| Compensation expense |  | $ | 1.7 |  |  | $ | 4.1 |  |  | $ | 1.8 |  |
| Weighted-average grant date fair value |  |  | 31.78 |  |  |  | 44.85 |  |  |  | 35.26 |  |
| Payout levels for shares paid |  |  | 0.0 | % |  |  | 127.7 | % |  |  | 200.0 | % |

[0001193125-12-065358:notes:296]
A summary of the status of our undistributed performance share units as of December 31, 2011, and changes during
   the year then ended, is presented below (in millions, except per share data):

[0001193125-12-065358:notes:297]
|  |  | Year Ended December 31, 2011 |  |
|  |  | Shares |  |  | Weighted-AverageGrant DateFair Value per Share |  |
| Undistributed performance share units: |  |  |  |  |  |  |  |  |
| Undistributed as of December 31, 2010 |  |  | 0.8 |  |  | $ | 33.90 |  |
| Granted |  |  | 0.3 |  |  |  | 31.78 |  |
| Additional shares earned |  |  | (0.2 | ) |  |  | 32.92 |  |
| Distributed |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | 35.45 |  |
| Undistributed as of December 31, 2011(1) |  |  | 0.9 |  |  |  | 33.40 |  |

[0001193125-12-065358:notes:298]
| (1) | Undistributed performance share units as of December 31, 2011 include approximately 0.7 million units with a weighted-average grant date fair value of $36.01 per share that had not yet vested. |

[0001193125-12-065358:notes:299]
As of
   December 31, 2011, we had $13.3 million of total unrecognized compensation cost related to nonvested performance share units. Such cost is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for
   performance share units was 19.4% as of December 31, 2011.

[0001193125-12-065358:notes:300]
The total fair value of performance share units distributed
   and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001193125-12-065358:notes:301]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Fair value of performance share units distributed |  | $ | — |  |  | $ | 13.2 |  |  | $ | 9.6 |  |
| Realized tax benefits from tax deductions |  |  | — |  |  |  | 5.0 |  |  |  | 3.7 |  |

[0001193125-12-065358:notes:302]
Our practice is to issue new shares of common stock to satisfy performance share unit distributions.

[0001193125-12-065358:notes:303]
Restricted Stock Units

[0001193125-12-065358:notes:304]
Under the 2010 Incentive Plan, restricted stock units are issued to attract and retain key employees. Generally, at the end of a three-year retention period, the units will vest and be distributed in
   shares of our common stock to the participant.

[0001193125-12-065358:notes:305]
Restricted stock units under the 2010 Incentive Plan are classified as equity
   awards, with the fair value of each unit equal to the average of the high and low market price of the stock on the date of grant for units granted prior to December 2007. The fair value of units granted after December 2007 is the average of the high
   and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period. The following table provides information on our
   restricted stock units (dollars in millions, except weighted-average grant date fair value):

[0001193125-12-065358:notes:306]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Restricted Stock Units: |  |  |  |  |  |  |  |  |  |  |  |  |
| Compensation expense |  | $ | 6.6 |  |  | $ | 6.6 |  |  | $ | 6.6 |  |
| Weighted-average grant date fair value |  |  | 32.34 |  |  |  | 44.80 |  |  |  | 35.09 |  |

[0001193125-12-065358:notes:307]
A summary of the status of our nonvested restricted stock units as of December 31, 2011 and changes during the year
   then ended is presented below (in millions, except per share data):

[0001193125-12-065358:notes:308]
|  |  | Year Ended December 31, 2011 |  |
|  |  | Shares |  |  | Weighted-AverageGrant DateFair Valueper Share |  |
| Nonvested restricted stock units: |  |  |  |  |  |  |  |  |
| Nonvested as of December 31, 2010 |  |  | 0.6 |  |  | $ | 34.44 |  |
| Granted |  |  | 0.3 |  |  |  | 32.34 |  |
| Vested |  |  | (0.3 | ) |  |  | 26.91 |  |
| Forfeited |  |  | — |  |  |  | 35.80 |  |
| Nonvested as of December 31, 2011 |  |  | 0.6 |  |  |  | 36.51 |  |

[0001193125-12-065358:notes:309]
As of December 31, 2011, we had $12.7 million of total unrecognized compensation cost related to nonvested
   restricted stock units. Such cost is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for restricted stock units was 19.7% as of December 31, 2011.

[0001193125-12-065358:notes:310]
The total fair
   value of restricted stock units vested and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001193125-12-065358:notes:311]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Fair value of restricted stock units vested |  | $ | 8.8 |  |  | $ | 9.4 |  |  | $ | 8.3 |  |
| Realized tax benefits from tax deductions |  |  | 3.4 |  |  |  | 3.6 |  |  |  | 3.2 |  |

[0001193125-12-065358:notes:312]
Our practice is to issue new shares of common stock to satisfy restricted stock unit vestings.

[0001193125-12-065358:notes:313]
Stock Appreciation Rights

[0001193125-12-065358:notes:314]
In 2003, we began awarding stock appreciation rights. Each recipient is given the “right” to receive a value equal to the future appreciation of our common stock price. The value is paid in
   shares of our common stock. Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date, and expire after seven years.

[0001193125-12-065358:notes:315]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Stock Appreciation Rights: |  |  |  |  |  |  |  |  |  |  |  |  |
| Compensation expense |  | $ | 5.4 |  |  | $ | 4.7 |  |  | $ | 4.4 |  |
| Weighted-average grant date fair value |  |  | 9.39 |  |  |  | 13.75 |  |  |  | 10.96 |  |

[0001193125-12-065358:notes:316]
Compensation expense for stock appreciation rights granted is based on the fair value on the date of grant and is
   recognized over the service period. The fair value for these awards is estimated using the Black-Scholes-Merton valuation model. We use historical stock price data and other pertinent information to estimate the expected volatility and the
   outstanding period of the award for separate groups of employees that have similar historical exercise behavior to estimate expected life. The risk-free interest rate was based on zero-coupon U.S. Treasury instruments with a remaining term equal to
   the expected life of the stock appreciation right at the time of grant.

[0001193125-12-065358:notes:317]
The fair value of each stock appreciation right
   granted in 2011, 2010 and 2009 is estimated on the date of grant using the following assumptions:

[0001193125-12-065358:notes:318]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Expected dividend yield |  |  | 2.39 | % |  |  | 1.46 | % |  |  | 1.57 | % |
| Risk-free interest rate |  |  | 0.62 | % |  |  | 1.46 | % |  |  | 1.78 | % |
| Expected volatility |  |  | 41.94 | % |  |  | 39.93 | % |  |  | 39.81 | % |
| Expected life (in years) |  |  | 4.07 |  |  |  | 4.04 |  |  |  | 4.12 |  |

[0001193125-12-065358:notes:319]
A summary of stock
   appreciation rights activity is as follows (in millions, except per share data):

[0001193125-12-065358:notes:320]
|  |  | For the Years Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
|  |  | Shares |  |  | Weighted-AverageExercise Price perShare |  |  | Shares |  |  | Weighted-AverageExercise Price perShare |  |  | Shares |  |  | Weighted-AverageExercise Price perShare |  |
| Outstanding at beginning of year |  |  | 2.5 |  |  | $ | 34.89 |  |  |  |  |  | 2.9 |  |  | $ | 31.06 |  |  |  |  |  | 2.7 |  |  | $ | 29.59 |  |
| Granted |  |  | 0.7 |  |  |  | 34.06 |  |  |  |  |  | 0.5 |  |  |  | 46.78 |  |  |  |  |  | 0.6 |  |  |  | 36.94 |  |
| Exercised |  |  | (0.2 | ) |  |  | 31.67 |  |  |  |  |  | (0.7 | ) |  |  | 27.20 |  |  |  |  |  | (0.2 | ) |  |  | 28.31 |  |
| Forfeited |  |  | (0.1 | ) |  |  | 39.39 |  |  |  |  |  | (0.2 | ) |  |  | 31.97 |  |  |  |  |  | (0.2 | ) |  |  | 30.59 |  |
| Outstanding at end of year |  |  | 2.9 |  |  | $ | 34.85 |  |  |  |  |  | 2.5 |  |  | $ | 34.89 |  |  |  |  |  | 2.9 |  |  | $ | 31.06 |  |
| Exercisable at end of year |  |  | 1.8 |  |  | $ | 33.05 |  |  |  |  |  | 1.5 |  |  | $ | 31.81 |  |  |  |  |  | 1.6 |  |  | $ | 29.58 |  |

[0001193125-12-065358:notes:321]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2011 (in
   millions, except per share data and years):

[0001193125-12-065358:notes:322]
|  |  | Stock Appreciation Rights Outstanding |  |  | Stock Appreciation Rights Exercisable |  |
| Range of Exercise Prices per Share |  | Weighted-AverageRemainingContractual Term (in years) |  |  | Aggregate IntrinsicValue |  |  | Weighted-AverageRemainingContractual Life (in years) |  |  | Aggregate IntrinsicValue |  |
| $28.24 – $46.78 |  |  | 4.7 |  |  |  | 4.5 |  |  |  | 3.6 |  |  |  | 4.5 |  |

[0001193125-12-065358:notes:323]
As of December 31, 2011, we had $10.4 million of unrecognized compensation cost related to nonvested stock
   appreciation rights. Such cost is expected to be recognized over a weighted-average period of 2.4 years. Our estimated forfeiture rate for stock appreciation rights was 18.6% as of December 31, 2011.

[0001193125-12-065358:notes:324]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows
   (in millions):

[0001193125-12-065358:notes:325]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Intrinsic value of stock appreciation rights exercised |  | $ | 4.2 |  |  | $ | 10.1 |  |  | $ | 1.5 |  |
| Realized tax benefits from tax deductions |  |  | 1.6 |  |  |  | 3.9 |  |  |  | 0.6 |  |

[0001193125-12-065358:notes:326]
Our practice is to issue new shares of common stock to satisfy the exercise of stock appreciation rights.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-12-065358:notes:327]
18.     Restructuring Charges:

[0001193125-12-065358:notes:328]
As part of our strategic priorities of manufacturing and sourcing excellence and expense reduction, we initiated
   various manufacturing rationalization actions designed to lower our cost structure. We expanded these expense reductions across the organization by initiating a number of activities to rationalize and reorganize various support and administrative
   functions. Restructuring charges are not included in our calculation of segment profit (loss), see Note 21 for further discussion. Detailed below are the restructuring activities that we incurred additional expense in 2011.

[0001193125-12-065358:notes:329]
2011 Plans

[0001193125-12-065358:notes:330]
Corporate and Other

[0001193125-12-065358:notes:331]
In the third quarter of 2011, we terminated our airplane lease, closed the aviation department, and reorganized certain support functions within our organization. Substantially all of the costs related to
   these activities were recognized in the third quarter of 2011 and consisted of $4.3 million in lease termination costs, $1.1 million in severance costs and $0.4 million in accelerated depreciation and other charges.

[0001193125-12-065358:notes:332]
2010 Plans

[0001193125-12-065358:notes:333]
Refrigeration

[0001193125-12-065358:notes:334]
We began to exit certain Refrigeration manufacturing
   operations in Milperra, Australia in 2010, specifically our OEM coil manufacturing and contract coil manufacturing. In the first quarter of 2010, we began to exit OEM coil manufacturing. We reversed approximately $0.5 million in severance in 2011 to
   adjust estimated charges to actual. This activity was substantially complete in 2010. We initiated restructuring activities related to exiting contract coil manufacturing in the third quarter of 2010. In 2011, we recognized $1.9 million in other
   plant closure costs related to these restructuring activities. The total expected expenses for the OEM coil restructuring are $4.8 million and the contract coil manufacturing restructuring is $5.6 million.

[0001193125-12-065358:notes:335]
Service Experts

[0001193125-12-065358:notes:336]
We began to reorganize certain administrative functions and the management structure of our Service Experts business in 2010 and initiated two actions. The first action, started in the second quarter of
   2010, was to reorganize the administrative operations of an acquired company. This project was completed in 2010. The second action, initiated in the fourth quarter of 2010, was to reorganize the management structure of our Service Experts business.
   We expect to complete this project in the first quarter of 2012. We recognized $5.0 million in severance, lease termination and other costs in 2011. The total expected expenses related to the second action for the administrative and management
   restructuring is $6.4 million.

[0001193125-12-065358:notes:337]
2009 and Prior Plans

[0001193125-12-065358:notes:338]
Commercial Heating & Cooling

[0001193125-12-065358:notes:339]
We completed the consolidation of certain manufacturing operations from Mions, France into our Longvic, France operations in the first quarter of 2010. We reversed $0.2 million in severance charges in
   2011 to adjust estimated charges to actual. The total expected restructuring charges for this consolidation is $6.9 million.

[0001193125-12-065358:notes:340]
Residential Heating & Cooling

[0001193125-12-065358:notes:341]
We consolidated our manufacturing operations from Blackville, South Carolina into our Orangeburg, South Carolina and Saltillo, Mexico operations. We expect to complete this consolidation in the first
   quarter of 2012. We recognized $1.4 million in restructuring charges in 2011 related to other plant closure costs. The total expected expenses for this consolidation is $13.8 million.

[0001193125-12-065358:notes:342]
Regional Distribution Network

[0001193125-12-065358:notes:343]
In the fourth quarter of 2008, we commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa to other locations, including our North American Distribution
   Center in Marshalltown, Iowa. In 2011, we recognized $0.3 million primarily in other restructuring charges. The total expected restructuring charges for the regional distribution network is $5.3 million

[0001193125-12-065358:notes:344]
Total
   Restructuring

[0001193125-12-065358:notes:345]
Information regarding the restructuring charges for all plans is as follows (in millions):

[0001193125-12-065358:notes:346]
|  |  | ChargesIncurred in2011 |  |  | ChargesIncurred toDate |  |  | Total ChargesExpected to be Incurred |  |
| Severance and related expense |  | $ | 3.1 |  |  | $ | 33.9 |  |  | $ | 34.5 |  |
| Asset write-offs and accelerated depreciation |  |  | 1.0 |  |  |  | 11.8 |  |  |  | 11.8 |  |
| Equipment moves |  |  | 0.7 |  |  |  | 1.8 |  |  |  | 2.2 |  |
| Lease termination |  |  | 4.4 |  |  |  | 7.1 |  |  |  | 7.1 |  |
| Other |  |  | 6.8 |  |  |  | 17.8 |  |  |  | 20.5 |  |
| Total |  | $ | 16.0 |  |  | $ | 72.4 |  |  | $ | 76.1 |  |

[0001193125-12-065358:notes:347]
Information regarding the restructuring charges by segment is as follows (in millions):

[0001193125-12-065358:notes:348]
|  |  | ChargesIncurred in2011 |  |  | ChargesIncurred toDate |  |  | Total ChargesExpected to beIncurred |  |
| Residential Heating & Cooling |  | $ | 2.5 |  |  | $ | 18.3 |  |  | $ | 20.9 |  |
| Commercial Heating & Cooling |  |  | (0.2 | ) |  |  | 12.3 |  |  |  | 12.7 |  |
| Service Experts |  |  | 5.4 |  |  |  | 8.7 |  |  |  | 8.9 |  |
| Refrigeration |  |  | 2.5 |  |  |  | 27.3 |  |  |  | 27.8 |  |
| Corporate & Other |  |  | 5.8 |  |  |  | 5.8 |  |  |  | 5.8 |  |
| Total |  | $ | 16.0 |  |  | $ | 72.4 |  |  | $ | 76.1 |  |

[0001193125-12-065358:notes:349]
Restructuring reserves are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below
   details activity within the restructuring reserves (in millions):

[0001193125-12-065358:notes:350]
| Description of Reserves |  | Balance as ofDecember 31,2010 |  |  | Chargedto Earnings |  |  | CashUtilization |  |  | Non-CashUtilizationand Other |  |  | Balance as ofDecember 31,2011 |  |
| Severance and related expense |  | $ | 6.2 |  |  | $ | 3.1 |  |  | $ | (6.8 | ) |  | $ | — |  |  | $ | 2.5 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 1.0 |  |  |  | 0.3 |  |  |  | (1.3 | ) |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 0.7 |  |  |  | (0.7 | ) |  |  | — |  |  |  | — |  |
| Lease termination |  |  | 0.3 |  |  |  | 4.4 |  |  |  | (4.7 | ) |  |  | — |  |  |  | — |  |
| Other(1) |  |  | 0.7 |  |  |  | 6.8 |  |  |  | (7.4 | ) |  |  |  |  |  |  | 0.1 |  |
| Total restructuring reserves |  | $ | 7.2 |  |  | $ | 16.0 |  |  | $ | (19.3 | ) |  | $ | (1.3 | ) |  | $ | 2.6 |  |

[0001193125-12-065358:notes:351]
| Description of Reserves |  | Balance as ofDecember 31,2009 |  |  | Chargedto Earnings |  |  | CashUtilization |  |  | Non-CashUtilizationand Other |  |  | Balance as ofDecember 31,2010 |  |
| Severance and related expense |  | $ | 21.1 |  |  | $ | 9.0 |  |  | $ | (22.5 | ) |  | $ | (1.4 | ) |  | $ | 6.2 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 2.6 |  |  |  | — |  |  |  | (2.6 | ) |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 0.8 |  |  |  | (0.8 | ) |  |  | — |  |  |  | — |  |
| Lease termination |  |  | 0.3 |  |  |  | 0.5 |  |  |  | (0.5 | ) |  |  | — |  |  |  | 0.3 |  |
| Other(1) |  |  | 0.8 |  |  |  | 2.7 |  |  |  | (2.8 | ) |  |  | — |  |  |  | 0.7 |  |
| Total restructuring reserves |  | $ | 22.2 |  |  | $ | 15.6 |  |  | $ | (26.6 | ) |  | $ | (4.0 | ) |  | $ | 7.2 |  |

[0001193125-12-065358:notes:352]
| (1) | Charges classified as ‘Other’ include $1.0 million third-party services related to restructuring activities and $0.8 million of facilities clean-up and demolition costs. |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001193125-12-065358:notes:353]
19.   Discontinued Operations:

[0001193125-12-065358:notes:354]
Service Experts Discontinued Operations

[0001193125-12-065358:notes:355]
A summary of net trade sales and pre-tax operating losses classified as Discontinued Operations in the accompanying Consolidated
   Statements of Operations is detailed below (in millions):

[0001193125-12-065358:notes:356]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Net trade sales |  | $ | — |  |  | $ | 0.2 |  |  | $ | 26.1 |  |
| Pre-tax operating loss(1) |  |  | — |  |  |  | (1.1 | ) |  |  | (13.1 | ) |

[0001193125-12-065358:notes:357]
| (1) | Included in the pre-tax operating loss from discontinued operations are losses on the disposal of the assets and liabilities of the service centers sold of $0.2 million in 2010, and gains on disposal of the assets and liabilities of service centers sold of $2.3 million in 2009. Also, included in the 2009 pre-tax operating loss from discontinued operations is an impairment charge of $2.7 million related to service centers where the estimated selling price of the assets is below the net book value of those assets and a write-off of $4.0 million of goodwill related to the sale of these service centers. The pre-tax operating loss from discontinued operations in 2008 includes a provision of $4.4 million for an unfavorable judgment related to the sale of a service center in 2004 that was included in discontinued operations. This contingency was settled in 2009 for $6.1 million. |


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-065358:notes:358]
20.   Earnings Per Share:

[0001193125-12-065358:notes:359]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares
   outstanding during the period. Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based
   compensation plans.

[0001193125-12-065358:notes:360]
The computations of basic and diluted earnings per share for Income from Continuing Operations were as
   follows (in millions, except per share data):

[0001193125-12-065358:notes:361]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Net income |  | $ | 88.3 |  |  | $ | 116.2 |  |  | $ | 51.1 |  |
| Add: Loss from discontinued operations |  |  | — |  |  |  | 0.9 |  |  |  | 10.7 |  |
| Income from continuing operations |  | $ | 88.3 |  |  | $ | 117.1 |  |  | $ | 61.8 |  |
| Weighted-average shares outstanding — basic |  |  | 52.5 |  |  |  | 54.6 |  |  |  | 55.6 |  |
| Effect of dilutive securities |  |  | 0.9 |  |  |  | 1.2 |  |  |  | 1.0 |  |
| Weighted-average shares outstanding — diluted |  |  | 53.4 |  |  |  | 55.8 |  |  |  | 56.6 |  |
| Earnings per share from continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.68 |  |  | $ | 2.14 |  |  | $ | 1.11 |  |
| Diluted |  | $ | 1.65 |  |  | $ | 2.10 |  |  | $ | 1.09 |  |

[0001193125-12-065358:notes:362]
Stock appreciation
   rights were outstanding, but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive. The details are as follows:

[0001193125-12-065358:notes:363]
|  |  | For the Years Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Stock appreciation rights (number of shares) |  |  | 1,466,149 |  |  |  | 273,429 |  |  |  | — |  |
| Price ranges per share |  | $ | 34.06 –46.78 |  |  | $ | 46.78 |  |  | $ | N/A |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-065358:notes:364]
21.  Reportable Business Segments:

[0001193125-12-065358:notes:365]
We operate in four reportable business segments of the HVACR industry. Our segments are organized primarily by the
   nature of the products and services provided. The table below details the nature of the operations of each reportable segment:

[0001193125-12-065358:notes:366]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Heating Air Conditioning Hearth Products |  | Residential Replacement Residential New Construction |  | United States Canada |
| Commercial Heating & Cooling |  | Rooftop Products Chillers Air Handlers |  | Light Commercial |  | United States Canada Europe |
| Service Experts |  | Equipment Sales Installation Maintenance Repair |  | Residential Light Commercial |  | United States Canada |
| Refrigeration |  | Unit Coolers Condensing Units Other Commercial Refrigeration Products Display Cases and Systems |  | Light Commercial Food Preservation and Non-Food/Industrial |  | United States Canada Europe Asia Pacific South America Mexico |

[0001193125-12-065358:notes:367]
Transactions between segments, such as products sold to Service Experts by the Residential
   Heating & Cooling segment, are recorded on an arm’s-length basis using the market price for these products. The eliminations of these intercompany sales and any associated profit are noted in the reconciliation of segment results to
   the income from continuing operations before income taxes below.

[0001193125-12-065358:notes:368]
We use segment profit or loss as the primary measure of
   profitability to evaluate operating performance and to allocate capital resources. We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated
   Statements of Operations excluding certain items. See the reconciliation of segment profit to Income from Continuing Operations Before Income Taxes below for more detail on the items excluded from segment profit.

[0001193125-12-065358:notes:369]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax
   compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII. We recorded these share-based awards as Corporate costs as they are determined at the discretion of
   the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001193125-12-065358:notes:370]
Net sales and
   segment profit (loss) by business segment, along with a reconciliation of segment profit to Income from Continuing Operations Before Income Taxes are shown below (in millions):

[0001193125-12-065358:notes:371]
|  |  | For the Years Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 1,341.0 |  |  | $ | 1,417.4 |  |  | $ | 1,293.5 |  |
| Commercial Heating & Cooling |  |  | 696.0 |  |  |  | 620.0 |  |  |  | 594.6 |  |
| Service Experts |  |  | 528.6 |  |  |  | 590.3 |  |  |  | 535.4 |  |
| Refrigeration |  |  | 805.2 |  |  |  | 550.9 |  |  |  | 512.7 |  |
| Eliminations(1) |  |  | (67.2 | ) |  |  | (82.2 | ) |  |  | (88.7 | ) |
|  |  | $ | 3,303.6 |  |  | $ | 3,096.4 |  |  | $ | 2,847.5 |  |

[0001193125-12-065358:notes:372]
| Segment Profit (Loss)(2) |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 75.1 |  |  | $ | 132.3 |  |  | $ | 111.7 |  |
| Commercial Heating & Cooling |  |  | 79.4 |  |  |  | 69.3 |  |  |  | 49.3 |  |
| Service Experts |  |  | 1.5 |  |  |  | 19.3 |  |  |  | 16.6 |  |
| Refrigeration |  |  | 77.5 |  |  |  | 61.4 |  |  |  | 48.9 |  |
| Corporate and other |  |  | (54.4 | ) |  |  | (65.5 | ) |  |  | (62.5 | ) |
| Eliminations(1) |  |  | (0.6 | ) |  |  | 0.2 |  |  |  | 0.5 |  |
| Subtotal that includes segment profit and eliminations |  |  | 178.5 |  |  |  | 217.0 |  |  |  | 164.5 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (4.3 | ) |  |  | (0.2 | ) |  |  | 18.3 |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit(3) |  |  | 4.5 |  |  |  | 11.2 |  |  |  | (10.9 | ) |
| Restructuring charges |  |  | 16.0 |  |  |  | 15.6 |  |  |  | 41.5 |  |
| Impairment of assets |  |  | 7.0 |  |  |  | — |  |  |  | 6.4 |  |
| Goodwill impairment |  |  | 7.6 |  |  |  | — |  |  |  | — |  |
| Interest expense, net |  |  | 16.8 |  |  |  | 12.8 |  |  |  | 8.2 |  |
| Other expense, net |  |  | 0.3 |  |  |  | 1.0 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 130.6 |  |  | $ | 176.6 |  |  | $ | 100.9 |  |

[0001193125-12-065358:notes:373]
| (1) | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |

[0001193125-12-065358:notes:374]
| (2) | We define segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-12-065358:notes:375]
|  | o | Special product quality adjustments. |

[0001193125-12-065358:notes:376]
|  | o | Items within Losses (gains) and other expenses, net that are noted in(3). |

[0001193125-12-065358:notes:377]
|  | o | Restructuring charges. |

[0001193125-12-065358:notes:378]
|  | o | Goodwill and equity method investment impairments. |

[0001193125-12-065358:notes:379]
|  | o | Interest expense, net. |

[0001193125-12-065358:notes:380]
|  | o | Other expense, net. |

[0001193125-12-065358:notes:381]
| (3) | Items in Losses (gains) and other expenses, net that are excluded from segment profit are net change in unrealized gains and/or losses on open future contracts, realized gains and/or losses on marketable securities, special legal contingency charge, acquisition expenses and other items. For more information about Losses (gains) and other expenses, net see Note 24. |

[0001193125-12-065358:notes:382]
On a consolidated
   basis, no revenues from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001193125-12-065358:notes:383]
Total assets by business segment are shown below (in millions). The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets. Assets recorded in
   the operating segments represent those assets directly associated with those segments.

[0001193125-12-065358:notes:384]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Total Assets |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 481.2 |  |  | $ | 519.8 |  |
| Commercial Heating & Cooling |  |  | 257.3 |  |  |  | 252.7 |  |
| Service Experts |  |  | 182.0 |  |  |  | 186.2 |  |
| Refrigeration |  |  | 558.2 |  |  |  | 389.7 |  |
| Corporate and other |  |  | 234.8 |  |  |  | 354.9 |  |
| Eliminations(1) |  |  | (7.8 | ) |  |  | (11.3 | ) |
| Total assets |  |  | 1,705.7 |  |  |  | 1,692.0 |  |
| Discontinued operations (See Note 19) |  |  | — |  |  |  | — |  |
| Total assets |  | $ | 1,705.7 |  |  | $ | 1,692.0 |  |

[0001193125-12-065358:notes:385]
| (1) | Eliminations consist of net intercompany receivables and intercompany profit included in inventory from products sold between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |

[0001193125-12-065358:notes:386]
Total capital expenditures by business segment are shown below (in millions):

[0001193125-12-065358:notes:387]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Capital Expenditures |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 12.1 |  |  | $ | 19.4 |  |  | $ | 31.7 |  |
| Commercial Heating & Cooling |  |  | 6.5 |  |  |  | 6.2 |  |  |  | 6.8 |  |
| Service Experts |  |  | 0.8 |  |  |  | 0.8 |  |  |  | 0.7 |  |
| Refrigeration |  |  | 13.2 |  |  |  | 6.9 |  |  |  | 7.4 |  |
| Corporate and other |  |  | 10.6 |  |  |  | 12.5 |  |  |  | 12.2 |  |
| Total capital expenditures |  | $ | 43.2 |  |  | $ | 45.8 |  |  | $ | 58.8 |  |

[0001193125-12-065358:notes:388]
There were no significant new capital leases in 2011, 2010 and 2009.

[0001193125-12-065358:notes:389]
The depreciation and amortization expenses by business segment are shown below (in millions):

[0001193125-12-065358:notes:390]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Depreciation and Amortization |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 22.3 |  |  | $ | 21.7 |  |  | $ | 22.2 |  |
| Commercial Heating & Cooling |  |  | 7.7 |  |  |  | 8.0 |  |  |  | 8.0 |  |
| Service Experts |  |  | 2.0 |  |  |  | 2.2 |  |  |  | 1.9 |  |
| Refrigeration |  |  | 14.8 |  |  |  | 8.7 |  |  |  | 9.9 |  |
| Corporate and other |  |  | 13.6 |  |  |  | 12.9 |  |  |  | 10.9 |  |
| Total depreciation and amortization |  | $ | 60.4 |  |  | $ | 53.5 |  |  | $ | 52.9 |  |

[0001193125-12-065358:notes:391]
The equity method
   investees are shown below (in millions):

[0001193125-12-065358:notes:392]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Income from Equity Method Investments |  |  |  |  |  |  |  |  |  |  |  |  |
| Refrigeration |  | $ | 2.5 |  |  | $ | 1.3 |  |  | $ | 0.5 |  |
| Corporate and other(1) |  |  | 7.1 |  |  |  | 8.8 |  |  |  | 6.8 |  |
|  |  | $ | 9.6 |  |  | $ | 10.1 |  |  | $ | 7.3 |  |

[0001193125-12-065358:notes:393]
| (1) | A significant portion of income for equity method investments is allocated to our Residential Heating & Cooling and Commercial Heating & Cooling segments. We allocated $4.9 million, $5.6 million, and $5.9 million to those segments in 2011, 2010 and 2009, respectively. |

[0001193125-12-065358:notes:394]
The following table sets forth certain financial information relating to our operations by geographic area based on the
   domicile of our operations (in millions):

[0001193125-12-065358:notes:395]
|  |  | For the Years Ended December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Net Sales to External Customers by Point of Shipment |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 2,370.8 |  |  | $ | 2,255.4 |  |  | $ | 2,033.1 |  |
| Canada |  |  | 329.2 |  |  |  | 336.6 |  |  |  | 327.0 |  |
| International |  |  | 603.6 |  |  |  | 504.4 |  |  |  | 487.4 |  |
| Total net sales to external customers |  | $ | 3,303.6 |  |  | $ | 3,096.4 |  |  | $ | 2,847.5 |  |

[0001193125-12-065358:notes:396]
|  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Property, Plant and Equipment, net |  |  |  |  |  |  |  |  |
| United States |  | $ | 238.0 |  |  | $ | 225.5 |  |
| Mexico |  |  | 28.0 |  |  |  | 33.0 |  |
| Canada |  |  | 5.2 |  |  |  | 6.0 |  |
| International |  |  | 38.7 |  |  |  | 59.8 |  |
| Total property, plant and equipment, net |  | $ | 309.9 |  |  | $ | 324.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-065358:notes:397]
22.    Fair Value Measurements:

[0001193125-12-065358:notes:398]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly
   transaction between market participants at the measurement date. Our framework for measuring fair value is established on a three-level hierarchy for fair value measurements based upon the transparency of inputs to the valuation of an asset or
   liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.

[0001193125-12-065358:notes:399]
Fair Value Hierarchy

[0001193125-12-065358:notes:400]
The three-level fair value hierarchies for disclosure of fair value measurements are defined as follows:

[0001193125-12-065358:notes:401]
Level 1 – Quoted prices for identical instruments in active markets at the measurement date.

[0001193125-12-065358:notes:402]
Level 2 – Quoted prices for similar instruments in active markets; quoted prices for identical or similar
   instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001193125-12-065358:notes:403]
Level
   3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions
   market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001193125-12-065358:notes:404]
Fair Value Techniques

[0001193125-12-065358:notes:405]
Our fair value valuation techniques are
   applied to all of the assets and liabilities carried at fair value. Where available, the fair values are based upon quoted prices in active markets. However, if quoted prices are not available, then the fair values are based upon quoted prices for
   similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities with a lack of
   observable market activity, if any, the fair values are based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use. To ensure that financial assets and
   liabilities are recorded at fair value, valuation adjustments may be required to reflect either party’s creditworthiness and ability to pay. Where appropriate, these amounts were incorporated into our valuations as of December 31, 2011 and
   2010, the measurement dates.

[0001193125-12-065358:notes:406]
Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0001193125-12-065358:notes:407]
The following table presents the fair value hierarchy for those assets and liabilities measured at fair value on a recurring basis (in
   millions):

[0001193125-12-065358:notes:408]
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1)As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Assets: |  |  |  |  |  |  |  |  |
| Investment in marketable equity securities(1) |  | $ | 8.4 |  |  | $ | 18.0 |  |

[0001193125-12-065358:notes:409]
| (1) | Investment in marketable equity securities is recorded in Other Assets, net in the accompanying Consolidated Balance Sheets. |

[0001193125-12-065358:notes:410]
Other Fair Value Measurements

[0001193125-12-065358:notes:411]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net, accounts payable and other current liabilities
   approximate fair value due to the short maturities of these instruments. The fair values of each of our long-term debt instruments are based on the quoted market prices for the same issues or on the amount of future cash flows associated with each
   instrument using current market rates for debt instruments of similar maturities and credit risk. The fair values presented are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently or
   indicative of our intent or ability to dispose of or liquidate them. The estimated fair value of our debt was as follows (in millions):

[0001193125-12-065358:notes:412]
|  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Long-term debt(1) |  | $ | 256.3 |  |  | $ | 114.6 |  |
| Senior unsecured notes |  |  | 207.0 |  |  |  | 203.0 |  |

[0001193125-12-065358:notes:413]
| (1) | Long-term debt includes our domestic revolving credit facility, capital lease obligations, and any related current maturities. |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-12-065358:notes:414]
23.    Quarterly Financial Information (unaudited):

[0001193125-12-065358:notes:415]
Financial results

[0001193125-12-065358:notes:416]
The following tables provide information on net sales, gross profit, net income, earnings per share and dividends per share by quarter (in millions, except per share data):

[0001193125-12-065358:notes:417]
|  |  | Net Sales |  |  | Gross Profit |  |  | Net (Loss)Income |  |
|  |  | 2011(1) |  |  | 2010(2) |  |  | 2011(1) |  |  | 2010(2) |  |  | 2011(1) |  |  | 2010(2) |  |
| First Quarter |  | $ | 687.8 |  |  | $ | 644.1 |  |  | $ | 165.2 |  |  | $ | 174.3 |  |  | $ | (7.2 | ) |  | $ | (1.6 | ) |
| Second Quarter |  |  | 937.0 |  |  |  | 872.1 |  |  |  | 247.6 |  |  |  | 264.7 |  |  |  | 45.0 |  |  |  | 48.3 |  |
| Third Quarter |  |  | 923.0 |  |  |  | 818.2 |  |  |  | 231.1 |  |  |  | 232.8 |  |  |  | 33.8 |  |  |  | 41.8 |  |
| Fourth Quarter |  |  | 755.8 |  |  |  | 762.0 |  |  |  | 189.7 |  |  |  | 220.0 |  |  |  | 16.7 |  |  |  | 27.7 |  |
|  |  | Basic (Loss)Earnings perCommon Share |  |  | Diluted (Loss)Earnings perCommon Share |  |  | Dividends perCommon Share |  |
|  |  | 2011(1) |  |  | 2010(2) |  |  | 2011(1) |  |  | 2010(2) |  |  | 2011(1) |  |  | 2010(2) |  |
| First Quarter |  | $ | (0.13 | ) |  | $ | (0.02 | ) |  | $ | (0.13 | ) |  | $ | (0.02 | ) |  | $ | 0.18 |  |  | $ | 0.15 |  |
| Second Quarter |  |  | 0.85 |  |  |  | 0.88 |  |  |  | 0.83 |  |  |  | 0.86 |  |  |  | 0.18 |  |  |  | 0.15 |  |
| Third Quarter |  |  | 0.65 |  |  |  | 0.78 |  |  |  | 0.64 |  |  |  | 0.76 |  |  |  | 0.18 |  |  |  | 0.15 |  |
| Fourth Quarter |  |  | 0.33 |  |  |  | 0.52 |  |  |  | 0.32 |  |  |  | 0.51 |  |  |  | 0.18 |  |  |  | 0.15 |  |

[0001193125-12-065358:notes:418]
| (1) | The following unusual or infrequent pre-tax items were included in the 2011 quarterly results: |

[0001193125-12-065358:notes:419]
|  | • |  | We recorded asset impairments of $7.0 million and goodwill impairment of $7.6 million in the fourth quarter of 2011. See Notes 5 and 6 for additional disclosure on these impairments. |

[0001193125-12-065358:notes:420]
|  | • |  | We recorded restructuring charges through 2011 as follows: first quarter — $1.2 million, second quarter — $2.4 million, third quarter — $10.8 million and fourth quarter — $1.6 million. |

[0001193125-12-065358:notes:421]
| (2) | The following unusual or infrequent pre-tax items were included in the 2010 quarterly results: |

[0001193125-12-065358:notes:422]
|  | • |  | We recorded an adjustment to pension cost in the fourth quarter which resulted in a reduction of pension cost by $4.1 million as compared to the prior year and by $3.5 million as compared to the third quarter. |

[0001193125-12-065358:notes:423]
|  | o | We recorded restructuring charges throughout 2010 as follows: first quarter — $7.2 million, second quarter — $3.2 million, third quarter — $4.7 million and fourth quarter — $0.5 million. |


## lii:LossesGainsAndOtherExpensesNetTextBlock

[0001193125-12-065358:notes:424]
24.    Losses (Gains) and Other Expenses, net:

[0001193125-12-065358:notes:425]
Losses (gains) and other expenses, net were as follows (in millions):

[0001193125-12-065358:notes:426]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Realized losses (gains) on settled futures contracts |  | $ | (0.1 | ) |  | $ | (1.5 | ) |  | $ | 3.7 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts |  |  | 3.8 |  |  |  | (0.6 | ) |  |  | (7.1 | ) |
| Gain on disposal of a business, net |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (4.1 | ) |
| Losses (gains) on disposals of fixed assets |  |  | (0.8 | ) |  |  | 0.1 |  |  |  | (0.1 | ) |
| Special legal contingency charge(1) |  |  | (0.4 | ) |  |  | 6.8 |  |  |  | — |  |
| Acquisition expenses(2) |  |  | 1.0 |  |  |  | 4.8 |  |  |  | — |  |
| Foreign currency exchange losses |  |  | 1.4 |  |  |  | 0.4 |  |  |  | 0.7 |  |
| Other items, net |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Losses (gains) and other expenses, net |  | $ | 5.0 |  |  | $ | 10.2 |  |  | $ | (6.6 | ) |

[0001193125-12-065358:notes:427]
| (1) | For more information on the special legal contingency charge, see Note 12. |

[0001193125-12-065358:notes:428]
| (2) | Acquisition expenses primarily relate to the Kysor/Warren acquisition. For more information, see Note 3. |


## lii:SupplementalInformationTextBlock

[0001193125-12-065358:notes:429]
25.    Supplemental Information:

[0001193125-12-065358:notes:430]
Below is information about expenses included in our Statements of Operations (in millions):

[0001193125-12-065358:notes:431]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Research and development |  | $ | 50.3 |  |  | $ | 49.5 |  |  | $ | 48.9 |  |
| Advertising, promotions and marketing |  |  | 68.1 |  |  |  | 73.5 |  |  |  | 59.5 |  |
| Rent expense |  |  | 69.6 |  |  |  | 64.3 |  |  |  | 64.4 |  |

[0001193125-12-065358:notes:432]
Interest Expense, net

[0001193125-12-065358:notes:433]
The components of Interest Expense, net were as follows (in millions):

[0001193125-12-065358:notes:434]
|  |  | For the Years EndedDecember 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Interest expense, net of capitalized interest |  | $ | 18.7 |  |  | $ | 13.7 |  |  | $ | 9.4 |  |
| Interest income |  |  | 1.9 |  |  |  | 0.9 |  |  |  | 1.2 |  |


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0001193125-12-065358:notes:435]
26.    Condensed Consolidating Financial Statements

[0001193125-12-065358:notes:436]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries
   (the “Guarantor Subsidiaries”) while they are not by other subsidiaries (the “Non-Guarantor Subsidiaries”). As a result of these guarantee arrangements, we are required to present the following condensed consolidating
   financial statements. Three subsidiaries previously classified as non-guarantor subsidiaries as of December 31, 2010 were classified as guarantor subsidiaries in the first quarter of 2011. These changes are reflected in the consolidated
   financial statements for periods after December 31, 2010.

[0001193125-12-065358:notes:437]
The condensed consolidating financial statements reflect the investments in
   subsidiaries of the Company using the equity method of accounting. Intercompany account balances have been included in Accounts and Notes Receivable, Other (Current) Assets, Other Assets, net, Short-Term Debt, Accounts Payable, and Long-Term Debt
   line items of the Parent, Guarantor and Non-Guarantor balance sheets. The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001193125-12-065358:notes:438]
Condensed
   consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2011 and 2010 and for each of the fiscal years of the three-year period ended December 31, 2011 are shown
   below:

[0001193125-12-065358:notes:439]
Condensed Consolidating Balance Sheets

[0001193125-12-065358:notes:440]
As of December 31, 2011

[0001193125-12-065358:notes:441]
(In millions)

[0001193125-12-065358:notes:442]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1.0 |  |  | $ | 9.7 |  |  | $ | 34.4 |  |  | $ | (0.1 | ) |  | $ | 45.0 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Accounts and notes receivable, net |  |  | (991.9 | ) |  |  | 955.8 |  |  |  | 424.2 |  |  |  | 20.6 |  |  |  | 408.7 |  |
| Inventories, net |  |  | — |  |  |  | 230.7 |  |  |  | 110.5 |  |  |  | (4.7 | ) |  |  | 336.5 |  |
| Deferred income taxes |  |  | 4.7 |  |  |  | 25.0 |  |  |  | 8.4 |  |  |  | (1.3 | ) |  |  | 36.8 |  |
| Other assets |  |  | 1.6 |  |  |  | 22.0 |  |  |  | 109.0 |  |  |  | (56.4 | ) |  |  | 76.2 |  |
| Total current assets |  |  | (984.6 | ) |  |  | 1,243.2 |  |  |  | 686.5 |  |  |  | (41.9 | ) |  |  | 903.2 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 252.8 |  |  |  | 57.1 |  |  |  | — |  |  |  | 309.9 |  |
| GOODWILL |  |  | — |  |  |  | 105.8 |  |  |  | 199.8 |  |  |  | — |  |  |  | 305.6 |  |
| DEFERRED INCOME TAXES |  |  | 0.2 |  |  |  | 96.4 |  |  |  | 20.1 |  |  |  | (9.7 | ) |  |  | 107.0 |  |
| OTHER ASSETS, net |  |  | 2,174.6 |  |  |  | 532.8 |  |  |  | 22.2 |  |  |  | (2,649.6 | ) |  |  | 80.0 |  |
| TOTAL ASSETS |  | $ | 1,190.2 |  |  | $ | 2,231.0 |  |  | $ | 985.7 |  |  | $ | (2,701.2 | ) |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 112.1 |  |  | $ | — |  |  | $ | (67.3 | ) |  | $ | (40.1 | ) |  | $ | 4.7 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.6 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.8 |  |
| Accounts payable |  |  | 9.2 |  |  |  | 137.6 |  |  |  | 98.8 |  |  |  | 31.4 |  |  |  | 277.0 |  |
| Accrued expenses |  |  | 15.3 |  |  |  | 180.7 |  |  |  | 88.8 |  |  |  | (0.1 | ) |  |  | 284.7 |  |
| Income taxes payable |  |  | (29.9 | ) |  |  | 28.0 |  |  |  | 24.6 |  |  |  | (17.0 | ) |  |  | 5.7 |  |
| Total current liabilities |  |  | 106.7 |  |  |  | 346.9 |  |  |  | 145.1 |  |  |  | (25.8 | ) |  |  | 572.9 |  |
| LONG-TERM DEBT |  |  | 443.0 |  |  |  | 16.2 |  |  |  | 97.3 |  |  |  | (96.9 | ) |  |  | 459.6 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 18.6 |  |  |  | — |  |  |  | — |  |  |  | 18.6 |  |
| PENSIONS |  |  | — |  |  |  | 111.9 |  |  |  | 12.8 |  |  |  | — |  |  |  | 124.7 |  |
| OTHER LIABILITIES |  |  | 0.8 |  |  |  | 59.0 |  |  |  | 13.4 |  |  |  | (11.1 | ) |  |  | 62.1 |  |
| Total liabilities |  |  | 550.5 |  |  |  | 552.6 |  |  |  | 268.6 |  |  |  | (133.8 | ) |  |  | 1,237.9 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 639.7 |  |  |  | 1,678.4 |  |  |  | 717.1 |  |  |  | (2,567.4 | ) |  |  | 467.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,190.2 |  |  | $ | 2,231.0 |  |  | $ | 985.7 |  |  | $ | (2,701.2 | ) |  | $ | 1,705.7 |  |

[0001193125-12-065358:notes:443]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 81.1 |  |  | $ | 14.7 |  |  | $ | 64.2 |  |  | $ | — |  |  | $ | 160.0 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 12.2 |  |  |  | — |  |  |  | 12.2 |  |
| Accounts and notes receivable, net |  |  | (1,169.7 | ) |  |  | 933.3 |  |  |  | 613.2 |  |  |  | 8.0 |  |  |  | 384.8 |  |
| Inventories, net |  |  | — |  |  |  | 163.7 |  |  |  | 128.7 |  |  |  | (6.2 | ) |  |  | 286.2 |  |
| Deferred income taxes |  |  | — |  |  |  | 27.6 |  |  |  | 12.1 |  |  |  | (3.0 | ) |  |  | 36.7 |  |
| Other assets |  |  | 19.3 |  |  |  | 21.0 |  |  |  | 121.2 |  |  |  | (94.5 | ) |  |  | 67.0 |  |
| Total current assets |  |  | (1,069.3 | ) |  |  | 1,160.3 |  |  |  | 951.6 |  |  |  | (95.7 | ) |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 202.8 |  |  |  | 121.6 |  |  |  | (0.1 | ) |  |  | 324.3 |  |
| GOODWILL |  |  | — |  |  |  | 50.8 |  |  |  | 225.8 |  |  |  | (4.8 | ) |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | — |  |  |  | 77.3 |  |  |  | 22.6 |  |  |  | (12.7 | ) |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 2,068.3 |  |  |  | 415.6 |  |  |  | 51.8 |  |  |  | (2,473.9 | ) |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 31.1 |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | (31.5 | ) |  | $ | 1.4 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |
| Accounts payable |  |  | 8.1 |  |  |  | 133.1 |  |  |  | 131.0 |  |  |  | 1.6 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 6.6 |  |  |  | 262.0 |  |  |  | 115.5 |  |  |  | (49.6 | ) |  |  | 334.5 |  |
| Income taxes payable |  |  | (36.1 | ) |  |  | 30.6 |  |  |  | 28.3 |  |  |  | (17.5 | ) |  |  | 5.3 |  |
| Total current liabilities |  |  | 9.7 |  |  |  | 425.9 |  |  |  | 277.0 |  |  |  | (97.0 | ) |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 300.0 |  |  |  | 5.4 |  |  |  | 139.6 |  |  |  | (128.0 | ) |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 15.9 |  |  |  | — |  |  |  | — |  |  |  | 15.9 |  |
| PENSIONS |  |  | — |  |  |  | 77.4 |  |  |  | 10.7 |  |  |  | — |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 5.8 |  |  |  | 46.8 |  |  |  | 25.9 |  |  |  | (12.8 | ) |  |  | 65.7 |  |
| Total liabilities |  |  | 315.5 |  |  |  | 571.4 |  |  |  | 453.2 |  |  |  | (237.8 | ) |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 683.5 |  |  |  | 1,335.4 |  |  |  | 920.2 |  |  |  | (2,349.4 | ) |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |

[0001193125-12-065358:notes:444]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 2,542.8 |  |  | $ | 960.1 |  |  | $ | (199.3 | ) |  | $ | 3,303.6 |  |
| COST OF GOODS SOLD |  |  | 0.2 |  |  |  | 1,948.3 |  |  |  | 722.2 |  |  |  | (200.7 | ) |  |  | 2,470.0 |  |
| Gross profit |  |  | (0.2 | ) |  |  | 594.5 |  |  |  | 237.9 |  |  |  | 1.4 |  |  |  | 833.6 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 479.2 |  |  |  | 180.7 |  |  |  | — |  |  |  | 659.9 |  |
| (Gains) losses and other expenses, net. |  |  | 12.1 |  |  |  | 0.8 |  |  |  | (7.9 | ) |  |  | — |  |  |  | 5.0 |  |
| Restructuring charges |  |  | — |  |  |  | 14.3 |  |  |  | 1.7 |  |  |  | — |  |  |  | 16.0 |  |
| Goodwill impairment |  |  | — |  |  |  | 7.6 |  |  |  | — |  |  |  | — |  |  |  | 7.6 |  |
| Impairment of assets |  |  | — |  |  |  | 7.0 |  |  |  | — |  |  |  | — |  |  |  | 7.0 |  |
| (Income) loss from equity method investments |  |  | (135.3 | ) |  |  | (31.2 | ) |  |  | (7.0 | ) |  |  | 163.9 |  |  |  | (9.6 | ) |
| Operational income from continuing operations |  |  | 123.0 |  |  |  | 116.8 |  |  |  | 70.4 |  |  |  | (162.5 | ) |  |  | 147.7 |  |
| INTEREST (INCOME) EXPENSE, net |  |  | 16.8 |  |  |  | (3.5 | ) |  |  | 3.5 |  |  |  | — |  |  |  | 16.8 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.3 |  |  |  | — |  |  |  | 0.3 |  |
| Income from continuing operations before income taxes |  |  | 106.2 |  |  |  | 120.3 |  |  |  | 66.6 |  |  |  | (162.5 | ) |  |  | 130.6 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (9.8 | ) |  |  | 31.0 |  |  |  | 20.6 |  |  |  | 0.5 |  |  |  | 42.3 |  |
| Income from continuing operations |  |  | 116.0 |  |  |  | 89.3 |  |  |  | 46.0 |  |  |  | (163.0 | ) |  |  | 88.3 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income |  | $ | 116.0 |  |  | $ | 89.3 |  |  | $ | 46.0 |  |  | $ | (163.0 | ) |  | $ | 88.3 |  |

[0001193125-12-065358:notes:445]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 2,128.0 |  |  | $ | 1,220.8 |  |  | $ | (252.4 | ) |  | $ | 3,096.4 |  |
| COST OF GOODS SOLD |  |  | 0.2 |  |  |  | 1,545.8 |  |  |  | 907.8 |  |  |  | (249.2 | ) |  |  | 2,204.6 |  |
| Gross profit |  |  | (0.2 | ) |  |  | 582.2 |  |  |  | 313.0 |  |  |  | (3.2 | ) |  |  | 891.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 480.3 |  |  |  | 205.4 |  |  |  | — |  |  |  | 685.7 |  |
| (Gains) losses and other expenses, net |  |  | (0.6 | ) |  |  | 6.5 |  |  |  | 4.3 |  |  |  | — |  |  |  | 10.2 |  |
| Restructuring charges |  |  |  |  |  |  | 5.7 |  |  |  | 9.9 |  |  |  | — |  |  |  | 15.6 |  |
| (Income) loss from equity method investments |  |  | (138.8 | ) |  |  | (11.8 | ) |  |  | (10.1 | ) |  |  | 150.6 |  |  |  | (10.1 | ) |
| Operational income from continuing operations |  |  | 139.2 |  |  |  | 101.5 |  |  |  | 103.5 |  |  |  | (153.8 | ) |  |  | 190.4 |  |
| INTEREST (INCOME) EXPENSE, net |  |  | 12.4 |  |  |  | (3.0 | ) |  |  | 3.4 |  |  |  | — |  |  |  | 12.8 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 1.0 |  |  |  | — |  |  |  | 1.0 |  |
| Income from continuing operations before income taxes |  |  | 126.8 |  |  |  | 104.5 |  |  |  | 99.1 |  |  |  | (153.8 | ) |  |  | 176.6 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (4.4 | ) |  |  | 34.3 |  |  |  | 29.6 |  |  |  | — |  |  |  | 59.5 |  |
| Income from continuing operations |  |  | 131.2 |  |  |  | 70.2 |  |  |  | 69.5 |  |  |  | (153.8 | ) |  |  | 117.1 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.9 |  |  |  | — |  |  |  | 0.9 |  |
| Net income |  | $ | 131.2 |  |  | $ | 70.2 |  |  | $ | 68.6 |  |  | $ | (153.8 | ) |  | $ | 116.2 |  |

[0001193125-12-065358:notes:446]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 1,939.1 |  |  | $ | 1,147.1 |  |  | $ | (238.7 | ) |  | $ | 2,847.5 |  |
| COST OF GOODS SOLD |  |  | 0.2 |  |  |  | 1,440.8 |  |  |  | 857.2 |  |  |  | (238.8 | ) |  |  | 2,059.4 |  |
| Gross profit |  |  | (0.2 | ) |  |  | 498.3 |  |  |  | 289.9 |  |  |  | 0.1 |  |  |  | 788.1 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 453.0 |  |  |  | 191.8 |  |  |  | 0.1 |  |  |  | 644.9 |  |
| (Gains) losses and other expenses, net |  |  | (6.7 | ) |  |  | (0.7 | ) |  |  | 0.8 |  |  |  | — |  |  |  | (6.6 | ) |
| Restructuring charges |  |  | — |  |  |  | 16.2 |  |  |  | 25.3 |  |  |  | — |  |  |  | 41.5 |  |
| Impairment of assets |  |  | — |  |  |  | — |  |  |  | 6.4 |  |  |  | — |  |  |  | 6.4 |  |
| (Income) loss from equity method investments |  |  | (39.1 | ) |  |  | 5.4 |  |  |  | (7.3 | ) |  |  | 33.7 |  |  |  | (7.3 | ) |
| Operational income from continuing operations |  |  | 45.6 |  |  |  | 24.4 |  |  |  | 72.9 |  |  |  | (33.7 | ) |  |  | 109.2 |  |
| INTEREST (INCOME) EXPENSE, net |  |  | (0.8 | ) |  |  | 7.2 |  |  |  | 1.9 |  |  |  | (0.1 | ) |  |  | 8.2 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 46.4 |  |  |  | 17.2 |  |  |  | 70.9 |  |  |  | (33.6 | ) |  |  | 100.9 |  |
| PROVISION FOR INCOME TAXES |  |  | 0.2 |  |  |  | 6.3 |  |  |  | 32.2 |  |  |  | 0.4 |  |  |  | 39.1 |  |
| Income from continuing operations |  |  | 46.2 |  |  |  | 10.9 |  |  |  | 38.7 |  |  |  | (34.0 | ) |  |  | 61.8 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 10.7 |  |  |  | — |  |  |  | 10.7 |  |
| Net income |  | $ | 46.2 |  |  | $ | 10.9 |  |  | $ | 28.0 |  |  | $ | (34.0 | ) |  | $ | 51.1 |  |

[0001193125-12-065358:notes:447]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  | $ | (2.6 | ) |  | $ | 16.4 |  |  | $ | 62.4 |  |  | $ | — |  |  | $ | 76.2 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.3 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (35.8 | ) |  |  | (7.4 | ) |  |  | — |  |  |  | (43.2 | ) |
| Proceeds from sale of business |  |  | — |  |  |  | — |  |  |  | 0.6 |  |  |  | — |  |  |  | 0.6 |  |
| Acquisition of business |  |  | — |  |  |  | (147.7 | ) |  |  | — |  |  |  | — |  |  |  | (147.7 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 12.2 |  |  |  | — |  |  |  | 12.2 |  |
| Net cash used in investing activities |  |  | — |  |  |  | (183.4 | ) |  |  | 5.6 |  |  |  | — |  |  |  | (177.8 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 3.8 |  |  |  | — |  |  |  | 3.8 |  |
| Asset securitization borrowings |  |  | — |  |  |  | — |  |  |  | 345.0 |  |  |  | — |  |  |  | 345.0 |  |
| Asset securitization payments |  |  | — |  |  |  | — |  |  |  | (345.0 | ) |  |  | — |  |  |  | (345.0 | ) |
| Long-term payments |  |  | — |  |  |  | (0.8 | ) |  |  | (0.1 | ) |  |  | — |  |  |  | (0.9 | ) |
| Revolver long-term borrowings |  |  | 1,539.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,539.5 |  |
| Revolver long-term payments |  |  | (1,396.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,396.5 | ) |
| Proceeds from stock option exercises |  |  | 2.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2.5 |  |
| Payments of deferred financing costs |  |  | (2.2 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2.2 | ) |
| Repurchases of common stock |  |  | (123.0 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (123.0 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.4 |  |
| Intercompany debt |  |  | 115.1 |  |  |  | (8.1 | ) |  |  | (107.0 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (177.8 | ) |  |  | 170.9 |  |  |  | 6.9 |  |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (36.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (36.5 | ) |
| Net cash (used in) provided by financing activities |  |  | (77.5 | ) |  |  | 162.0 |  |  |  | (96.4 | ) |  |  | — |  |  |  | (11.9 | ) |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | (80.1 | ) |  |  | (5.0 | ) |  |  | (28.4 | ) |  |  | — |  |  |  | (113.5 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | (1.5 | ) |  |  | — |  |  |  | (1.5 | ) |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 81.1 |  |  |  | 14.7 |  |  |  | 64.2 |  |  |  | — |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | 1.0 |  |  | $ | 9.7 |  |  | $ | 34.3 |  |  | $ | — |  |  | $ | 45.0 |  |

[0001193125-12-065358:notes:448]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  | $ | (115.4 | ) |  |  | 315.3 |  |  | $ | (14.1 | ) |  | $ | — |  |  | $ | 185.8 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.2 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (33.7 | ) |  |  | (12.1 | ) |  |  | — |  |  |  | (45.8 | ) |
| Proceeds from sale of businesses |  |  | — |  |  |  | 0.1 |  |  |  | 3.5 |  |  |  | — |  |  |  | 3.6 |  |
| Acquisition of business |  |  | — |  |  |  | (7.2 | ) |  |  | — |  |  |  | — |  |  |  | (7.2 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | (12.2 | ) |  |  | — |  |  |  | (12.2 | ) |
| Net cash used in investing activities |  |  | — |  |  |  | (40.7 | ) |  |  | (20.7 | ) |  |  | — |  |  |  | (61.4 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term payments, net |  |  | — |  |  |  | — |  |  |  | (0.8 | ) |  |  | — |  |  |  | (0.8 | ) |
| Long-term payments |  |  | (35.0 | ) |  |  | (0.1 | ) |  |  | (0.8 | ) |  |  | — |  |  |  | (35.9 | ) |
| Issuance of senior unsecured notes |  |  | 199.8 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 199.8 |  |
| Revolver long-term borrowings |  |  | 981.5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 981.5 |  |
| Revolver long-term payments |  |  | (1,058.0 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,058.0 | ) |
| Additional investment in affiliate |  |  | — |  |  |  | — |  |  |  | (1.0 | ) |  |  | — |  |  |  | (1.0 | ) |
| Proceeds from stock option exercises |  |  | 3.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3.5 |  |
| Payments of deferred financing costs |  |  | (1.8 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.8 | ) |
| Repurchases of common stock |  |  | (153.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (153.7 | ) |
| Excess tax benefits related to share-based payments |  |  | 5.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.3 |  |
| Intercompany debt |  |  | 90.8 |  |  |  | (107.8 | ) |  |  | 17.0 |  |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | 194.6 |  |  |  | (158.6 | ) |  |  | (36.0 | ) |  |  | — |  |  |  | — |  |
| Intercompany investments |  |  | (7.9 | ) |  |  | — |  |  |  | 7.9 |  |  |  | — |  |  |  | — |  |
| Intercompany dividends |  |  | 9.0 |  |  |  | — |  |  |  | (9.0 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (32.4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (32.4 | ) |
| Net cash provided by (used in) financing activities |  |  | 195.7 |  |  |  | (266.5 | ) |  |  | (22.7 | ) |  |  | — |  |  |  | (93.5 | ) |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | 80.3 |  |  |  | 8.1 |  |  |  | (57.5 | ) |  |  | — |  |  |  | 30.9 |  |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 4.8 |  |  |  | — |  |  |  | 4.8 |  |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | 0.8 |  |  |  | 6.6 |  |  |  | 116.9 |  |  |  | — |  |  |  | 124.3 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | 81.1 |  |  | $ | 14.7 |  |  | $ | 64.2 |  |  | $ | — |  |  | $ | 160.0 |  |

[0001193125-12-065358:notes:449]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  | $ | 54.0 |  |  | $ | 87.0 |  |  | $ | 84.5 |  |  | $ | — |  |  | $ | 225.5 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (48.3 | ) |  |  | (10.5 | ) |  |  | — |  |  |  | (58.8 | ) |
| Proceeds from sale of businesses |  |  | — |  |  |  | 1.1 |  |  |  | 8.9 |  |  |  | — |  |  |  | 10.0 |  |
| Return of investment |  |  | — |  |  |  | — |  |  |  | 0.9 |  |  |  | — |  |  |  | 0.9 |  |
| Purchases of short-term investments . |  |  | — |  |  |  | — |  |  |  | (16.9 | ) |  |  | — |  |  |  | (16.9 | ) |
| Proceeds from sales and maturities of short-term investments |  |  | — |  |  |  | — |  |  |  | 50.2 |  |  |  | — |  |  |  | 50.2 |  |
| Net cash provided by (used in) investing activities |  |  | — |  |  |  | (47.0 | ) |  |  | 33.0 |  |  |  | — |  |  |  | (14.0 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term payments, net |  |  | — |  |  |  | — |  |  |  | (4.3 | ) |  |  | — |  |  |  | (4.3 | ) |
| Long-term payments |  |  | — |  |  |  | — |  |  |  | (1.7 | ) |  |  | — |  |  |  | (1.7 | ) |
| Revolver long-term borrowings |  |  | 830.5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 830.5 |  |
| Revolver long-term payments |  |  | (1,013.8 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,013.8 | ) |
| Proceeds from stock option exercises |  |  | 9.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9.4 |  |
| Repurchases of common stock |  |  | (5.6 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5.6 | ) |
| Excess tax benefits related to share-based payments |  |  | 4.9 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4.9 |  |
| Intercompany debt |  |  | 21.0 |  |  |  | (12.5 | ) |  |  | (8.5 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | 126.5 |  |  |  | (24.0 | ) |  |  | (102.5 | ) |  |  | — |  |  |  | — |  |
| Intercompany dividends |  |  | 5.0 |  |  |  | — |  |  |  | (5.0 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (31.1 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (31.1 | ) |
| Net cash used in financing activities |  |  | (53.2 | ) |  |  | (36.5 | ) |  |  | (122.0 | ) |  |  | — |  |  |  | (211.7 | ) |
| DECREASE IN CASH AND CASH EQUIVALENTS |  |  | 0.8 |  |  |  | 3.5 |  |  |  | (4.5 | ) |  |  | — |  |  |  | (0.2 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 2.4 |  |  |  | — |  |  |  | 2.4 |  |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | — |  |  |  | 3.1 |  |  |  | 119.0 |  |  |  | — |  |  |  | 122.1 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | 0.8 |  |  | $ | 6.6 |  |  | $ | 116.9 |  |  | $ | — |  |  | $ | 124.3 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-12-065358:notes:450]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001193125-12-065358:notes:451]
LENNOX INTERNATIONAL INC.

[0001193125-12-065358:notes:452]
SCHEDULE II — VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001193125-12-065358:notes:453]
For the Years Ended December 31, 2011, 2010 and 2009

[0001193125-12-065358:notes:454]
(In Millions)

[0001193125-12-065358:notes:455]
|  |  | Balance atBeginningof Year |  |  | AdditionsChargedto Cost andExpenses |  |  | Write-offs |  |  | Recoveries |  |  | Other |  |  | Balanceat end of Year |  |
| 2009: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 17.9 |  |  | $ | 12.6 |  |  | $ | (17.8 | ) |  | $ | 1.4 |  |  | $ | 1.5 |  |  | $ | 15.6 |  |
| 2010: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 15.6 |  |  | $ | 6.3 |  |  | $ | (9.9 | ) |  | $ | 1.2 |  |  | $ | (0.4 | ) |  | $ | 12.8 |  |
| 2011: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 12.8 |  |  | $ | 4.4 |  |  | $ | (9.9 | ) |  | $ | 1.9 |  |  | $ | 2.9 |  |  | $ | 12.1 |  |
