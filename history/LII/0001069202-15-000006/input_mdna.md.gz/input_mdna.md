# LII MD&A — 0001069202-15-000006


## mdna

[0001069202-15-000006:mdna:1]
[same as prior period, unchanged from 0001069202-14-000008:mdna:1]

[0001069202-15-000006:mdna:2]
[same as prior period, unchanged from 0001069202-14-000008:mdna:2]

[0001069202-15-000006:mdna:3]
[same as prior period, unchanged from 0001069202-14-000008:mdna:3]

[0001069202-15-000006:mdna:4]
[same as prior period, unchanged from 0001069202-14-000008:mdna:4]

[0001069202-15-000006:mdna:5]
[same as prior period, unchanged from 0001069202-14-000008:mdna:5]

[0001069202-15-000006:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated warranty costs, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  Pricing volatility for these commodities and related components impact us and the HVACR industry in general.  We seek to mitigate the impact of higher commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-15-000006:mdna:7]
[same as prior period, unchanged from 0001069202-14-000008:mdna:7]

[0001069202-15-000006:mdna:8]
| • | Net sales decreased $9 million, or 1%, to $686 million in the first quarter of 2015 compared to $695 million in the first quarter of 2014. |

[0001069202-15-000006:mdna:9]
| • | Operational income from continuing operations in the first quarter of 2015 declined $7 million to $27 million from $34 million in the first quarter of 2014. |

[0001069202-15-000006:mdna:10]
| • | Net income for the first quarter of 2015 was $14 million compared to $20 million in the first quarter of 2014. |

[0001069202-15-000006:mdna:11]
| • | Diluted earnings per share from continuing operations were $0.31 per share in the first quarter of 2015 compared to $0.40 per share in the first quarter of 2014. |

[0001069202-15-000006:mdna:12]
| • | During the first quarter of 2015, we returned $13 million to shareholders through dividend payments. |

[0001069202-15-000006:mdna:13]
| • | Cash used in operating activities was $122 million in the first three months of 2015 compared to $125 million in the first three months of 2014. |

[0001069202-15-000006:mdna:14]
Overview of Results

[0001069202-15-000006:mdna:15]
On a consolidated basis, net sales decreased 1% primarily due to unfavorable foreign currency exchange rates, partially offset by increased volume and improved price and mix.  Our gross profit margin decreased from 24.2%  as of March 31, 2014 to 23.8% as of March 31, 2015. Selling, general & administrative expenses (“SG&A”) as a percentage of net sales were constant quarter over quarter at 19.5%.  Operational income from continuing operations decreased $7 million quarter over quarter due primarily to investments in distribution, lower refrigerant pricing on our Australia wholesale business and unfavorable mix, partially offset by increased material cost savings.

[0001069202-15-000006:mdna:16]
The Residential Heating & Cooling segment led our overall operational performance in the first quarter of 2015, with a 6% increase in net sales and a $7 million increase in segment profit compared to the first quarter of 2014.  This segment benefited from market growth and material cost savings.  Sales in the Commercial Heating & Cooling segment decreased 8% and segment profit declined $3 million in the first quarter of 2015 compared to the first quarter of 2014. This segment's sales were down due to timing of certain National Account business which we expect to ship in the remaining quarters of 2015 as well as unfavorable foreign currency exchange rates.  Sales in the Refrigeration segment were down 9% and segment profit declined $8 million in the first quarter of 2015 compared to the first quarter of 2014.  This segment had reduced profitability due to the Australian carbon levy repeal, unfavorable foreign currency exchange rates, unfavorable mix and factory investments for future growth.  Also, Corporate and Other expenses increased by $1 million primarily due to general wage and cost inflation.

[0001069202-15-000006:mdna:17]
First Quarter of 2015 Compared to First Quarter of 2014 - Consolidated Results

[0001069202-15-000006:mdna:18]
[same as prior period, unchanged from 0001069202-14-000008:mdna:15]

[0001069202-15-000006:mdna:19]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | $ | 685.8 |  |  | $ | 695.4 |  |  | (1.4 | )% |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 522.8 |  |  | 527.3 |  |  | 0.9 |  |  | 76.2 |  |  | 75.8 |  |
| Gross profit | 163.0 |  |  | 168.1 |  |  | (3.0 | ) |  | 23.8 |  |  | 24.2 |  |
| Selling, general and administrative expenses | 133.4 |  |  | 135.6 |  |  | 1.6 |  |  | 19.5 |  |  | 19.5 |  |
| Losses (gains) and other expenses, net | 5.6 |  |  | 2.4 |  |  | 133.3 |  |  | 0.8 |  |  | 0.3 |  |
| Restructuring charges | 0.3 |  |  | 0.1 |  |  | (200.0 | ) |  | — |  |  | — |  |
| Income from equity method investments | (3.3 | ) |  | (3.9 | ) |  | (15.4 | ) |  | (0.5 | ) |  | (0.6 | ) |
| Operational income from continuing operations | $ | 27.0 |  |  | $ | 33.9 |  |  | (20.4 | )% |  | 3.9 | % |  | 4.9 | % |

[0001069202-15-000006:mdna:20]
[same as prior period, unchanged from 0001069202-14-000008:mdna:17]

[0001069202-15-000006:mdna:21]
Net sales decreased 1% in the first quarter of 2015 compared to the first quarter of 2014, primarily from a 3% decrease for unfavorable foreign currency exchange rates, partially offset by a 2% increase in volume.  The Residential Heating & Cooling segment delivered higher volume by capturing additional replacement and new construction business.

[0001069202-15-000006:mdna:22]
[same as prior period, unchanged from 0001069202-14-000008:mdna:19]

[0001069202-15-000006:mdna:23]
Gross profit margin in the first quarter of 2015 decreased 40 basis points ("bps") to 23.8% compared to the first quarter of 2014.  Lower material costs increased our profit margin by 240 bps. The decline in gross profit margin was due to 90 bps of unfavorable mix and price, 60 bps from lower refrigerant pricing on our Australia wholesale business when compared to the prior year quarter, 70 bps for investments in distribution and other growth initiatives, and 60 bps from increased total other product costs.

[0001069202-15-000006:mdna:24]
[same as prior period, unchanged from 0001069202-14-000008:mdna:21]

[0001069202-15-000006:mdna:25]
SG&A was $133 million in the first quarter of 2015 compared to $136 million in the first quarter of 2014, and as a percentage of net sales was flat.

[0001069202-15-000006:mdna:26]
[same as prior period, unchanged from 0001069202-14-000008:mdna:23]

[0001069202-15-000006:mdna:27]
Losses (gains) and other expenses, net for the first quarter of 2015 and 2014 included the following (in millions):

[0001069202-15-000006:mdna:28]
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Realized losses on settled future contracts | $ | 0.4 |  |  | $ | 0.2 |  |
| Foreign currency exchange losses (gains) | 1.1 |  |  | 0.8 |  |
| Loss on disposal of fixed assets | — |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (0.1 | ) |  | 0.6 |  |
| Special legal contingency charges | 3.4 |  |  | 0.4 |  |
| Asbestos-related litigation | 0.1 |  |  | 0.2 |  |
| Environmental liabilities | 0.7 |  |  | — |  |
| Other items, net | — |  |  | 0.1 |  |
| Losses (gains) and other expenses, net | $ | 5.6 |  |  | $ | 2.4 |  |

[0001069202-15-000006:mdna:29]
The net change in unrealized losses (gains) on unsettled futures contracts was due to higher commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange losses increased in the first quarter of 2015 primarily due to the Australian and Canadian dollar exchange rates. Special legal contingency charges increased for our estimate of costs expected to be incurred for an attempted class action lawsuit.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  For more information on these legal charges, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000006:mdna:30]
[same as prior period, unchanged from 0001069202-14-000008:mdna:28]

[0001069202-15-000006:mdna:31]
There were no significant restructuring charges incurred in the first quarter of 2015 or 2014.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000006:mdna:32]
[same as prior period, unchanged from 0001069202-14-000008:mdna:30]

[0001069202-15-000006:mdna:33]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $3 million in the first quarter of 2015 decreased slightly from the first quarter of 2014.

[0001069202-15-000006:mdna:34]
[same as prior period, unchanged from 0001069202-14-000008:mdna:32]

[0001069202-15-000006:mdna:35]
Interest expense, net of $6 million in the first quarter of 2015 increased from $3 million in the first quarter of 2014 due to an increase in our average borrowings.

[0001069202-15-000006:mdna:36]
[same as prior period, unchanged from 0001069202-14-000008:mdna:34]

[0001069202-15-000006:mdna:37]
The Provision for income taxes was $7 million in the first quarter of 2015 compared to $11 million in the first quarter of 2014.  The effective tax rate was 34.3% for the first quarter of 2015 compared to 35.0% for the first quarter of 2014.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-15-000006:mdna:38]
First Quarter of 2015 Compared to First Quarter of 2014 - Results by Segment

[0001069202-15-000006:mdna:39]
[same as prior period, unchanged from 0001069202-14-000008:mdna:37]

[0001069202-15-000006:mdna:40]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000006:mdna:41]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 362.5 |  |  | $ | 342.1 |  |  | $ | 20.4 |  |  | 6.0 | % |
| Profit | $ | 31.2 |  |  | $ | 24.4 |  |  | $ | 6.8 |  |  | 27.9 | % |
| % of net sales | 8.6 | % |  | 7.1 | % |  |  |  |  |

[0001069202-15-000006:mdna:42]
Net sales increased by 6% in the first quarter of 2015 compared to the first quarter of 2014.  Volume increased by 6% due to industry growth and favorable price and mix increased net sales by 1%, offset by a 1% reduction from unfavorable foreign currency exchange rates.

[0001069202-15-000006:mdna:43]
Segment profit for the first quarter of 2015 increased $7 million due to $11 million in material cost savings, $4 million in higher sales volumes, and $1 million from favorable price and mix.  Partially offsetting these increases was $3 million of unfavorable foreign currency exchange rates, $3 million of higher distribution expenses primarily related to continued investment in distribution initiatives, and $1 million of SG&A investments with the balance attributable to increased other product costs.

[0001069202-15-000006:mdna:44]
[same as prior period, unchanged from 0001069202-14-000008:mdna:42]

[0001069202-15-000006:mdna:45]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000006:mdna:46]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 159.9 |  |  | $ | 173.0 |  |  | $ | (13.1 | ) |  | (7.6 | )% |
| Profit | $ | 7.7 |  |  | $ | 10.2 |  |  | $ | (2.5 | ) |  | (24.5 | )% |
| % of net sales | 4.8 | % |  | 5.9 | % |  |  |  |  |

[0001069202-15-000006:mdna:47]
Net sales decreased 8% in the first quarter of 2015 compared to the first quarter of 2014. Sales volumes decreased by 3% primarily due to North American National account project timing and 5% from unfavorable foreign currency exchange rates.

[0001069202-15-000006:mdna:48]
Segment profit in the first quarter of 2015 declined $3 million compared to the first quarter of 2014.  The benefits of $3 million from material cost savings were offset by $2 million in lower North American sales volumes, $2 million for distribution growth investments and start-up costs to enter the Variable Refrigerant Flow ("VRF") market, and $2 million of higher SG&A expenses.

[0001069202-15-000006:mdna:49]
[same as prior period, unchanged from 0001069202-14-000008:mdna:47]

[0001069202-15-000006:mdna:50]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000006:mdna:51]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 163.4 |  |  | $ | 180.3 |  |  | $ | (16.9 | ) |  | (9.4 | )% |
| Profit | $ | 4.0 |  |  | $ | 12.1 |  |  | $ | (8.1 | ) |  | (66.9 | )% |
| % of net sales | 2.4 | % |  | 6.7 | % |  |  |  |  |

[0001069202-15-000006:mdna:52]
Net sales declined 9% in the first quarter of 2015 compared to the first quarter of 2014 primarily due to a 7% unfavorable impact from foreign currency exchange rates and a 3% unfavorable impact from the Australian carbon levy repeal that was effective July 1, 2014.  These decreases were partially offset by 1% volume growth led by our North American supermarket businesses.

[0001069202-15-000006:mdna:53]
Segment profit for the first quarter of 2015 decreased $8 million compared to the first quarter of 2014 primarily due to $4 million from unfavorable mix predominantly in the North American supermarket business, $6 million lower profitability in our Australia refrigerant business, $1 million of costs related to investments for future growth, and $2 million from unfavorable foreign currency exchange rates.  Partially offsetting these decreases were $2 million from material costs savings and $3 million from factory productivity and other product costs.

[0001069202-15-000006:mdna:54]
[same as prior period, unchanged from 0001069202-14-000008:mdna:52]

[0001069202-15-000006:mdna:55]
Corporate and other expenses were relatively flat in the first quarter of 2015 as compared to the first quarter of 2014.

[0001069202-15-000006:mdna:56]
[same as prior period, unchanged from 0001069202-14-000008:mdna:93]

[0001069202-15-000006:mdna:57]
[same as prior period, unchanged from 0001069202-14-000008:mdna:94]

[0001069202-15-000006:mdna:58]
[same as prior period, unchanged from 0001069202-14-000008:mdna:95]

[0001069202-15-000006:mdna:59]
The following table summarizes our cash flow activity for the three months ended March 31, 2015 and 2014 (in millions):

[0001069202-15-000006:mdna:60]
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Net cash used in operating activities | $ | (122.2 | ) |  | $ | (125.0 | ) |
| Net cash used in investing activities | (18.0 | ) |  | (17.3 | ) |
| Net cash provided by financing activities | 144.0 |  |  | 144.3 |  |

[0001069202-15-000006:mdna:61]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first three months of 2015 and 2014 reflects the seasonal increase in working capital requirements.  The $3 million decrease in net cash used in operating activities quarter over quarter is primarily attributable to the seasonal increase in working capital requirements in 2015 being smaller than the increase in 2014.  However, this favorable cash flow impact was offset by increased income tax payments in 2015 and an unfavorable impact from timing of payments in the ordinary course of business.

[0001069202-15-000006:mdna:62]
Net Cash Used in Investing Activities - Capital expenditures were $18 million and  $17 million for the first three months of 2015 and 2014, respectively.  Capital expenditures in 2015 were primarily related to investments in systems and software to support the overall enterprise and investments in our distribution network.

[0001069202-15-000006:mdna:63]
Net Cash Provided by Financing Activities - Net cash provided by financing activities of $144 million were comparable quarter over quarter and primarily relate to borrowings in excess of repayments on our domestic credit facility, offset by payments on our Asset Securitization Program and repurchases of common stock to satisfy employee withholding taxes.

[0001069202-15-000006:mdna:64]
[same as prior period, unchanged from 0001069202-14-000008:mdna:101]

[0001069202-15-000006:mdna:65]
The following table details our lines of credit and financing arrangements as of March 31, 2015 (in millions):

[0001069202-15-000006:mdna:66]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-term debt: |  |  |  |  |  |
| Foreign obligations | $ | 24.7 |  |  | $ | 5.3 |  |  | $ | 19.4 |  |
| Asset Securitization Program (1) | 180.0 |  |  | 180.0 |  |  | — |  |
| Total short-term debt | $ | 204.7 |  |  | $ | 185.3 |  |  | $ | 19.4 |  |
| Current maturities of long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 1.5 |  |  | 1.5 |  |  | $ | — |  |
| Domestic credit facility (2) | $ | 30.0 |  |  | $ | 30.0 |  |  | — |  |
| Long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 15.5 |  |  | $ | 15.5 |  |  | — |  |
| Domestic credit facility (2) | 920.0 |  |  | 653.5 |  |  | 239.3 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 1,135.5 |  |  | 869.0 |  |  | 239.3 |  |
| Total debt | $ | 1,371.7 |  |  | $ | 1,085.8 |  |  | $ | 258.7 |  |

[0001069202-15-000006:mdna:67]
(1) The maximum securitization amount ranges from $180.0 million to $220.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.

[0001069202-15-000006:mdna:68]
(2) In November 2014, we replaced our $650 million Domestic Revolving Credit Facility and our $200 million Short Term Facility with a $950 million Domestic Credit Facility, which consists of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019. Quarterly principal repayments of $7.5 million are required for the term loan beginning on June 30, 2015.  The available future borrowings on our domestic credit facility were reduced by the outstanding borrowings and $27.2 million in outstanding standby letters of credit.  We also had $26.4 million in outstanding standby letters of credit outside of the Domestic Credit Facility as of March 31, 2015.

[0001069202-15-000006:mdna:69]
[same as prior period, unchanged from 0001069202-14-000008:mdna:106]

[0001069202-15-000006:mdna:70]
Our debt-to-total-capital ratio increased to 101.5% at March 31, 2015 from 99.0% at December 31, 2014 due to the increase in our net borrowings, as noted above.  We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Due to first quarter currency translation adjustments and recent changes to our pension liability, we have a stockholders' deficit as of March 31, 2015.

[0001069202-15-000006:mdna:71]
As of March 31, 2015, our senior credit ratings were Baa3 with a negative outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to ensure the capital markets remain available to us.

[0001069202-15-000006:mdna:72]
[same as prior period, unchanged from 0001069202-14-000008:mdna:110]

[0001069202-15-000006:mdna:73]
We believe our cash and cash equivalents of $37 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $37 million as of March 31, 2015 was $24 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and pay taxes in the United States for the amounts that were repatriated.

[0001069202-15-000006:mdna:74]
Our expected capital expenditures for 2015 are $85 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with the completion of our $450 accelerated share repurchase program in 2015 and a target of between $55 million and $60 million of dividend payments in 2015.

[0001069202-15-000006:mdna:75]
[same as prior period, unchanged from 0001069202-14-000008:mdna:113]

[0001069202-15-000006:mdna:76]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Our operating lease commitments have not materially changed since December 31, 2014.

[0001069202-15-000006:mdna:77]
Commitments, Contingencies and Guarantees

[0001069202-15-000006:mdna:78]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000006:mdna:79]
[same as prior period, unchanged from 0001069202-14-000008:mdna:117]

[0001069202-15-000006:mdna:80]
On May 28, 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2017. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001069202-15-000006:mdna:81]
In January 2015, the FASB issued ASU No. 2015-01, Income Statement - Extraordinary and Unusual Items (Subtopic 225-20): Simplifying Income Statement Presentation by Eliminating the Concept of Extraordinary Items. ASU No. 2015-01 eliminates the concept of an extraordinary item from GAAP. As a result, an entity will no longer be required to separately present an extraordinary item on its statement of operations, net of tax, after income from continuing operations or to disclose income taxes and net income per share data applicable to an extraordinary item. However, ASU No. 2015-01 will still retain the presentation and disclosure guidance for items that are unusual in nature and occur infrequently. ASU No. 2015-01 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period, although early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements, absent any material transactions in future periods that would have qualified for extraordinary item presentation under the prior guidance.

[0001069202-15-000006:mdna:82]
In February 2015, the Financial Accounting Standard Board issued ASU 2015-02, Consolidation: Amendments to the Consolidation Analysis, or ASU 2015-02, which amends the criteria for determining which entities are considered variable interest entities (“VIEs”), amends the criteria for determining if a service provider possesses a variable interest in a VIE and ends the deferral granted to investment companies for application of the VIE consolidation model. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015 and early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements.

[0001069202-15-000006:mdna:83]
In April 2015, the Financial Accounting Standard Board issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015, and early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements.
