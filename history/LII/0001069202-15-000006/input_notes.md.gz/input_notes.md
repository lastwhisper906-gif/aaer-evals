# LII notes — 0001069202-15-000006


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-15-000006:notes:1]
The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-15-000006:notes:2]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 180.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 180.0 |  |  | 220.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-15-000006:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-15-000006:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-15-000006:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-15-000006:notes:6]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.66 | % |  | 1.88 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-15-000006:notes:7]
[same as prior period, unchanged from 0001069202-14-000008:notes:1]

[0001069202-15-000006:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2015, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2015 and 2014, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2015 and 2014, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2015 and 2014 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2014. The accompanying unaudited consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-15-000006:notes:9]
[same as prior period, unchanged from 0001069202-14-000008:notes:3]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-15-000006:notes:10]
Commitments and Contingencies:

[0001069202-15-000006:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-15-000006:notes:12]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-15-000006:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000006:notes:14]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Accrued expenses | $ | 26.3 |  |  | $ | 27.3 |  |
| Other liabilities | 60.3 |  |  | 59.9 |  |
| Total warranty liability | $ | 86.6 |  |  | $ | 87.2 |  |

[0001069202-15-000006:notes:15]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2015 were as follows (in millions):

[0001069202-15-000006:notes:16]
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |
| Warranty claims paid | (4.7 | ) |
| Changes resulting from issuance of new warranties | 6.4 |  |
| Changes in estimates associated with pre-existing liabilities | (1.2 | ) |
| Changes in foreign currency translation rates and other | (1.1 | ) |
| Total warranty liability as of March 31, 2015 | $ | 86.6 |  |

[0001069202-15-000006:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties.   Also, to satisfy our customers and protect our brands,  we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a supplier quality issue within a range of $2.2 million and $6 million; accordingly, we have accrued a $2.2 million liability in Accrued Expenses on the Consolidated Balance Sheet because all amounts in that range were equally likely. The supplier has agreed to reimburse our costs related to this liability; accordingly, we have also recorded a receivable of $2.2 million in Other Assets on the Consolidated Balance Sheet.  If additional costs are incurred, we expect the supplier will also reimburse those costs. The $2.2 million accrual is not included in the estimated warranty liabilities tables immediately above.

[0001069202-15-000006:notes:18]
Litigation

[0001069202-15-000006:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-15-000006:notes:20]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2015, and 2014, expense for asbestos-related litigation was $0.1 million, and $0.2 million, net of insurance recoveries, respectively.

[0001069202-15-000006:notes:21]
We are the defendant in an attempted class action lawsuit alleging evaporator coils in our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks.  We dispute the allegations in the lawsuit.  We have reached tentative settlement terms and recorded a liability of $2.4 million in Accrued Expenses on the Consolidated Balance Sheet.   Any additional liability resulting from the proposed settlement is not currently reasonably estimable, but we do not expect the proposed settlement to have a material adverse effect on our financial condition or results of operations.

[0001069202-15-000006:notes:22]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-15-000006:notes:23]
[same as prior period, unchanged from 0001069202-14-000008:notes:20]

[0001069202-15-000006:notes:24]
[same as prior period, unchanged from 0001069202-14-000008:notes:21]

[0001069202-15-000006:notes:25]
|  |  | For the Three Months Ended March 31, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2015 |  | 2014 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (3.4 | ) |  | $ | (1.1 | ) |  | Cost of goods sold |
| Income tax benefit |  | 1.2 |  |  | 0.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (2.2 | ) |  | $ | (0.7 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (2.0 | ) |  | $ | (1.2 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.7 |  |  | 0.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.3 | ) |  | $ | (0.8 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (3.5 | ) |  | $ | (1.5 | ) |  |  |

[0001069202-15-000006:notes:26]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2015 (in millions):

[0001069202-15-000006:notes:27]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| AOCL as of December 31, 2014 |  | $ | (4.6 | ) |  | $ | 3.2 |  |  | $ | (149.4 | ) |  | $ | (2.7 | ) |  | $ | (153.5 | ) |
| Other comprehensive (loss) income before reclassifications |  | (1.1 | ) |  | — |  |  | (0.3 | ) |  | (27.3 | ) |  | (28.7 | ) |
| Amounts reclassified from AOCL |  | 2.2 |  |  | — |  |  | 1.3 |  |  | — |  |  | 3.5 |  |
| Net other comprehensive (loss) income |  | 1.1 |  |  | — |  |  | 1.0 |  |  | (27.3 | ) |  | (25.2 | ) |
| AOCL as of March 31, 2015 |  | $ | (3.5 | ) |  | $ | 3.2 |  |  | $ | (148.4 | ) |  | $ | (30.0 | ) |  | $ | (178.7 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-15-000006:notes:28]
[same as prior period, unchanged from 0001069202-14-000008:notes:26]

[0001069202-15-000006:notes:29]
[same as prior period, unchanged from 0001069202-14-000008:notes:27]

[0001069202-15-000006:notes:30]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of March 31, 2015 and December 31, 2014 and for the three months ended March 31, 2015 and 2014 are shown on the following pages.

[0001069202-15-000006:notes:31]
[same as prior period, unchanged from 0001069202-14-000008:notes:29]

[0001069202-15-000006:notes:32]
[same as prior period, unchanged from 0001069202-14-000008:notes:30]

[0001069202-15-000006:notes:33]
As of March 31, 2015

[0001069202-15-000006:notes:34]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 11.9 |  |  | $ | 23.6 |  |  | $ | — |  |  | $ | 36.7 |  |
| Accounts and notes receivable, net | — |  |  | 27.5 |  |  | 421.9 |  |  | — |  |  | 449.4 |  |
| Inventories, net | — |  |  | 419.0 |  |  | 121.7 |  |  | (7.6 | ) |  | 533.1 |  |
| Deferred income taxes, net | 3.0 |  |  | 27.3 |  |  | 7.5 |  |  | (5.1 | ) |  | 32.7 |  |
| Other assets | 3.4 |  |  | 44.2 |  |  | 99.6 |  |  | (58.8 | ) |  | 88.4 |  |
| Total current assets | 7.6 |  |  | 529.9 |  |  | 674.3 |  |  | (71.5 | ) |  | 1,140.3 |  |
| Property, plant and equipment, net | — |  |  | 273.0 |  |  | 83.0 |  |  | — |  |  | 356.0 |  |
| Goodwill | — |  |  | 140.5 |  |  | 64.0 |  |  | — |  |  | 204.5 |  |
| Investment in subsidiaries | 969.7 |  |  | 389.6 |  |  | (0.6 | ) |  | (1,358.7 | ) |  | — |  |
| Deferred income taxes | 0.6 |  |  | 86.4 |  |  | 14.1 |  |  | (9.6 | ) |  | 91.5 |  |
| Other assets, net | 5.1 |  |  | 60.3 |  |  | 23.2 |  |  | (1.4 | ) |  | 87.2 |  |
| Intercompany receivables (payables), net | (92.9 | ) |  | 89.8 |  |  | 3.1 |  |  | — |  |  | — |  |
| Total assets | $ | 890.1 |  |  | $ | 1,569.5 |  |  | $ | 861.1 |  |  | $ | (1,441.2 | ) |  | $ | 1,879.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 185.3 |  |  | $ | — |  |  | $ | 185.3 |  |
| Current maturities of long-term debt | 30.0 |  |  | 1.3 |  |  | 0.2 |  |  | — |  |  | 31.5 |  |
| Accounts payable | 13.5 |  |  | 269.4 |  |  | 64.7 |  |  | — |  |  | 347.6 |  |
| Accrued expenses | 11.0 |  |  | 145.2 |  |  | 48.7 |  |  | — |  |  | 204.9 |  |
| Income taxes payable | (2.4 | ) |  | 16.1 |  |  | 54.4 |  |  | (66.9 | ) |  | 1.2 |  |
| Total current liabilities | 52.1 |  |  | 432.0 |  |  | 353.3 |  |  | (66.9 | ) |  | 770.5 |  |
| Long-term debt | 853.5 |  |  | 15.3 |  |  | 0.2 |  |  | — |  |  | 869.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.0 |  |  | — |  |  | — |  |  | 4.0 |  |
| Pensions | — |  |  | 119.6 |  |  | 11.4 |  |  | — |  |  | 131.0 |  |
| Other liabilities | 0.7 |  |  | 122.1 |  |  | 11.5 |  |  | (13.1 | ) |  | 121.2 |  |
| Total liabilities | 906.3 |  |  | 693.0 |  |  | 376.4 |  |  | (80.0 | ) |  | 1,895.7 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | (16.2 | ) |  | 876.5 |  |  | 484.7 |  |  | (1,361.2 | ) |  | (16.2 | ) |
| Total liabilities and stockholders' equity | $ | 890.1 |  |  | $ | 1,569.5 |  |  | $ | 861.1 |  |  | $ | (1,441.2 | ) |  | $ | 1,879.5 |  |

[0001069202-15-000006:notes:35]
As of December 31, 2014

[0001069202-15-000006:notes:36]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 11.5 |  |  | $ | 25.0 |  |  | $ | — |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net | — |  |  | 12.3 |  |  | 409.1 |  |  | — |  |  | 421.4 |  |
| Inventories, net | — |  |  | 350.6 |  |  | 119.7 |  |  | (7.0 | ) |  | 463.3 |  |
| Deferred income taxes, net | 2.8 |  |  | 27.3 |  |  | 7.4 |  |  | (5.0 | ) |  | 32.5 |  |
| Other assets | 3.6 |  |  | 45.7 |  |  | 67.2 |  |  | (57.2 | ) |  | 59.3 |  |
| Total current assets | 7.4 |  |  | 447.4 |  |  | 628.4 |  |  | (69.2 | ) |  | 1,014.0 |  |
| Property, plant and equipment, net | — |  |  | 269.0 |  |  | 89.6 |  |  | — |  |  | 358.6 |  |
| Goodwill | — |  |  | 140.4 |  |  | 69.0 |  |  | — |  |  | 209.4 |  |
| Investment in subsidiaries | 978.1 |  |  | 263.5 |  |  | (0.6 | ) |  | (1,241.0 | ) |  | — |  |
| Deferred income taxes | 0.5 |  |  | 90.8 |  |  | 15.8 |  |  | (9.6 | ) |  | 97.5 |  |
| Other assets, net | 5.2 |  |  | 61.0 |  |  | 20.1 |  |  | (1.5 | ) |  | 84.8 |  |
| Intercompany receivables (payables), net | (280.4 | ) |  | 302.4 |  |  | (22.0 | ) |  | — |  |  | — |  |
| Total assets | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 226.6 |  |  | $ | — |  |  | $ | 226.6 |  |
| Current maturities of long-term debt | 22.5 |  |  | 1.2 |  |  | 0.3 |  |  | — |  |  | 24.0 |  |
| Accounts payable | 13.4 |  |  | 237.8 |  |  | 73.1 |  |  | — |  |  | 324.3 |  |
| Accrued expenses | 9.0 |  |  | 175.5 |  |  | 54.5 |  |  | — |  |  | 239.0 |  |
| Income taxes payable | (3.7 | ) |  | 34.7 |  |  | 47.5 |  |  | (65.1 | ) |  | 13.4 |  |
| Total current liabilities | 41.2 |  |  | 449.2 |  |  | 402.0 |  |  | (65.1 | ) |  | 827.3 |  |
| Long-term debt | 659.5 |  |  | 15.3 |  |  | 0.2 |  |  | — |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| Pensions | — |  |  | 117.6 |  |  | 12.3 |  |  | — |  |  | 129.9 |  |
| Other liabilities | 1.1 |  |  | 118.7 |  |  | 11.7 |  |  | (12.9 | ) |  | 118.6 |  |
| Total liabilities | 701.8 |  |  | 705.3 |  |  | 426.2 |  |  | (78.0 | ) |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 9.0 |  |  | 869.2 |  |  | 374.1 |  |  | (1,243.3 | ) |  | 9.0 |  |
| Total liabilities and stockholders' equity | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |

[0001069202-15-000006:notes:37]
[same as prior period, unchanged from 0001069202-14-000008:notes:35]

[0001069202-15-000006:notes:38]
For the Three Months Ended March 31, 2015

[0001069202-15-000006:notes:39]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 576.2 |  |  | $ | 153.8 |  |  | $ | (44.2 | ) |  | $ | 685.8 |  |
| Cost of goods sold | — |  |  | 443.6 |  |  | 122.9 |  |  | (43.7 | ) |  | 522.8 |  |
| Gross profit | — |  |  | 132.6 |  |  | 30.9 |  |  | (0.5 | ) |  | 163.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 108.0 |  |  | 25.4 |  |  | — |  |  | 133.4 |  |
| Losses (gains) and other expenses, net | 0.1 |  |  | 3.8 |  |  | 1.7 |  |  | — |  |  | 5.6 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.2 |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (17.5 | ) |  | 2.3 |  |  | (2.8 | ) |  | 14.7 |  |  | (3.3 | ) |
| Operational income from continuing operations | 17.4 |  |  | 18.4 |  |  | 6.4 |  |  | (15.2 | ) |  | 27.0 |  |
| Interest expense, net | 5.5 |  |  | (0.5 | ) |  | 0.7 |  |  | — |  |  | 5.7 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 11.9 |  |  | 18.9 |  |  | 5.7 |  |  | (15.2 | ) |  | 21.3 |  |
| Provision for income taxes | (2.0 | ) |  | 7.8 |  |  | 1.6 |  |  | (0.1 | ) |  | 7.3 |  |
| Income from continuing operations | 13.9 |  |  | 11.1 |  |  | 4.1 |  |  | (15.1 | ) |  | 14.0 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Net income | $ | 13.9 |  |  | $ | 11.1 |  |  | $ | 4.0 |  |  | $ | (15.1 | ) |  | $ | 13.9 |  |
| Other comprehensive income (loss), net of tax | 1.0 |  |  | (3.9 | ) |  | (20.5 | ) |  | (1.8 | ) |  | (25.2 | ) |
| Comprehensive income | $ | 14.9 |  |  | $ | 7.2 |  |  | $ | (16.5 | ) |  | $ | (16.9 | ) |  | $ | (11.3 | ) |

[0001069202-15-000006:notes:40]
For the Three Months Ended March 31, 2014

[0001069202-15-000006:notes:41]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 559.2 |  |  | $ | 182.6 |  |  | $ | (46.4 | ) |  | $ | 695.4 |  |
| Cost of goods sold | — |  |  | 433.3 |  |  | 139.4 |  |  | (45.4 | ) |  | 527.3 |  |
| Gross profit | — |  |  | 125.9 |  |  | 43.2 |  |  | (1.0 | ) |  | 168.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 104.2 |  |  | 31.4 |  |  | — |  |  | 135.6 |  |
| Losses (gains) and other expenses, net | 0.9 |  |  | 0.8 |  |  | 0.7 |  |  | — |  |  | 2.4 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (22.4 | ) |  | (2.4 | ) |  | (3.2 | ) |  | 24.1 |  |  | (3.9 | ) |
| Operational income from continuing operations | 21.5 |  |  | 23.3 |  |  | 14.2 |  |  | (25.1 | ) |  | 33.9 |  |
| Interest expense, net | 3.0 |  |  | (0.6 | ) |  | 0.9 |  |  | — |  |  | 3.3 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 18.5 |  |  | 23.9 |  |  | 13.3 |  |  | (25.1 | ) |  | 30.6 |  |
| Provision for income taxes | (1.4 | ) |  | 7.8 |  |  | 4.7 |  |  | (0.4 | ) |  | 10.7 |  |
| Income from continuing operations | 19.9 |  |  | 16.1 |  |  | 8.6 |  |  | (24.7 | ) |  | 19.9 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 19.9 |  |  | $ | 16.1 |  |  | $ | 8.6 |  |  | $ | (24.7 | ) |  | $ | 19.9 |  |
| Other comprehensive income, net of tax | — |  |  | 3.3 |  |  | 1.3 |  |  | (4.6 | ) |  | — |  |
| Comprehensive income | $ | 19.9 |  |  | $ | 19.4 |  |  | $ | 9.9 |  |  | $ | (29.3 | ) |  | $ | 19.9 |  |

[0001069202-15-000006:notes:42]
[same as prior period, unchanged from 0001069202-14-000008:notes:44]

[0001069202-15-000006:notes:43]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 3.5 |  |  | $ | (156.4 | ) |  | $ | 30.7 |  |  | $ | — |  |  | $ | (122.2 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (14.9 | ) |  | (3.1 | ) |  | — |  |  | (18.0 | ) |
| Net proceeds from sale of business | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in investing activities | — |  |  | (14.9 | ) |  | (3.1 | ) |  | — |  |  | (18.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Long-term debt payments | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Borrowings from revolving credit facility | 580.5 |  |  | — |  |  | — |  |  | — |  |  | 580.5 |  |
| Payments on revolving credit facility | (379.0 | ) |  | — |  |  | — |  |  | — |  |  | (379.0 | ) |
| Proceeds from employee stock purchases | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |
| Repurchases of common stock | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (20.5 | ) |  | — |  |  | — |  |  | — |  |  | (20.5 | ) |
| Excess tax benefits related to share-based payments | 16.0 |  |  | — |  |  | — |  |  | — |  |  | 16.0 |  |
| Intercompany debt | (16.2 | ) |  | 2.9 |  |  | 13.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | (171.3 | ) |  | 168.7 |  |  | 2.6 |  |  | — |  |  | — |  |
| Intercompany investments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Cash dividends paid | (13.4 | ) |  | — |  |  | — |  |  | — |  |  | (13.4 | ) |
| Net cash provided by financing activities | (3.3 | ) |  | 171.7 |  |  | (24.4 | ) |  | — |  |  | 144.0 |  |
| Increase in cash and cash equivalents | 0.2 |  |  | 0.4 |  |  | 3.2 |  |  | — |  |  | 3.8 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (4.6 | ) |  | — |  |  | (4.6 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of period | $ | 1.2 |  |  | $ | 11.9 |  |  | $ | 23.6 |  |  | $ | — |  |  | $ | 36.7 |  |

[0001069202-15-000006:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 85.4 |  |  | $ | (198.8 | ) |  | $ | (11.6 | ) |  | $ | — |  |  | $ | (125.0 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (11.7 | ) |  | (5.6 | ) |  | — |  |  | (17.3 | ) |
| Net proceeds from sale of business | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in investing activities | — |  |  | (11.7 | ) |  | (5.6 | ) |  | — |  |  | (17.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |
| Asset securitization borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | — |  |  | (0.3 | ) |  | (0.1 | ) |  | — |  |  | (0.4 | ) |
| Borrowings from revolving credit facility | 479.0 |  |  | — |  |  | — |  |  | — |  |  | 479.0 |  |
| Payments on revolving credit facility | (319.0 | ) |  | — |  |  | — |  |  | — |  |  | (319.0 | ) |
| Proceeds from employee stock purchases | 0.5 |  |  | — |  |  | — |  |  | — |  |  | 0.5 |  |
| Repurchases of common stock | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (10.7 | ) |  | — |  |  | — |  |  | — |  |  | (10.7 | ) |
| Excess tax benefits related to share-based payments | 4.2 |  |  | — |  |  | — |  |  | — |  |  | 4.2 |  |
| Intercompany debt | (6.4 | ) |  | (4.1 | ) |  | 10.5 |  |  | — |  |  | — |  |
| Intercompany financing activity | (221.1 | ) |  | 215.3 |  |  | 5.8 |  |  | — |  |  | — |  |
| Cash dividends paid | (11.8 | ) |  | — |  |  | — |  |  | — |  |  | (11.8 | ) |
| Net cash used in financing activities | (85.3 | ) |  | 210.9 |  |  | 18.7 |  |  | — |  |  | 144.3 |  |
| Decrease in cash and cash equivalents | 0.1 |  |  | 0.4 |  |  | 1.5 |  |  | — |  |  | 2.0 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (1.0 | ) |  | — |  |  | (1.0 | ) |
| Cash and cash equivalents, beginning of period | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of period | $ | 1.2 |  |  | $ | 10.9 |  |  | $ | 26.9 |  |  | $ | — |  |  | $ | 39.0 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-15-000006:notes:45]
Lines of Credit and Financing Arrangements:

[0001069202-15-000006:notes:46]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000006:notes:47]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 5.3 |  |  | 6.6 |  |
| Total short-term debt | $ | 185.3 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.5 |  |  | $ | 1.5 |  |
| Domestic credit facility | $ | 30.0 |  |  | $ | 22.5 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.5 |  |  | $ | 15.5 |  |
| Domestic credit facility | 653.5 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 869.0 |  |  | $ | 675.0 |  |
| Total debt | $ | 1,085.8 |  |  | $ | 925.6 |  |

[0001069202-15-000006:notes:48]
Short-Term Debt

[0001069202-15-000006:notes:49]
Foreign Obligations

[0001069202-15-000006:notes:50]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $5.3 million and $6.6 million of foreign obligations as of March 31, 2015 and December 31, 2014, respectively, that were primarily borrowings under non-committed facilities.  Proceeds on these facilities were $11.0 million and $20.6 million during the three months ended March 31, 2015 and 2014, respectively. Repayments on the facilities were $11.2 million and $18.1 million and during the three months ended March 31, 2015 and 2014, respectively.

[0001069202-15-000006:notes:51]
Asset Securitization Program

[0001069202-15-000006:notes:52]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-15-000006:notes:53]
In November 2014, we amended the ASP, extending its term to November 13, 2015 and increasing the maximum securitization amount from a range of $160.0 million to $220.0 million to a range of $180.0 million to $220.0 million, depending on the period.   The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-15-000006:notes:54]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for both March 31, 2015 and December 31, 2014 was 0.79%. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-15-000006:notes:55]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2015, we were in compliance with all covenant requirements.

[0001069202-15-000006:notes:56]
Long-Term Debt

[0001069202-15-000006:notes:57]
Domestic Credit Facility

[0001069202-15-000006:notes:58]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consists of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our $950.0 million Domestic Credit Facility, we had outstanding borrowings of $683.5 million as well as $27.2 million committed to standby letters of credit as of March 31, 2015. Subject to covenant limitations, $239.3 million was available for future borrowings. The unsecured $300 million term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million beginning on June 30, 2015. The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-15-000006:notes:59]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net

[0001069202-15-000006:notes:60]
Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-15-000006:notes:61]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-15-000006:notes:62]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-15-000006:notes:63]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-15-000006:notes:64]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2015, we were in compliance with all covenant requirements.

[0001069202-15-000006:notes:65]
Senior Unsecured Notes

[0001069202-15-000006:notes:66]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2015, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-15-000006:notes:67]
[same as prior period, unchanged from 0001069202-14-000008:notes:72]

[0001069202-15-000006:notes:68]
[same as prior period, unchanged from 0001069202-14-000008:notes:73]

[0001069202-15-000006:notes:69]
[same as prior period, unchanged from 0001069202-14-000008:notes:74]

[0001069202-15-000006:notes:70]
[same as prior period, unchanged from 0001069202-14-000008:notes:75]

[0001069202-15-000006:notes:71]
[same as prior period, unchanged from 0001069202-14-000008:notes:76]

[0001069202-15-000006:notes:72]
[same as prior period, unchanged from 0001069202-14-000008:notes:77]

[0001069202-15-000006:notes:73]
We have commodity futures contracts designated as cash flow hedges that are scheduled to mature through September 2016.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.

[0001069202-15-000006:notes:74]
We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-15-000006:notes:75]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Unrealized losses on unsettled futures contracts | $ | 5.8 |  |  | $ | 7.2 |  |
| Income tax benefit | (2.1 | ) |  | (2.6 | ) |
| Losses included in AOCL, net of tax (1) | $ | 3.7 |  |  | $ | 4.6 |  |

[0001069202-15-000006:notes:76]
(1) Assuming commodity prices remain constant, we expect to reclassify $3.8 million of derivative losses into earnings within the next 12 months.

[0001069202-15-000006:notes:77]
[same as prior period, unchanged from 0001069202-14-000008:notes:81]

[0001069202-15-000006:notes:78]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Copper | 24.9 |  |  | 29.4 |  |

[0001069202-15-000006:notes:79]
[same as prior period, unchanged from 0001069202-14-000008:notes:83]

[0001069202-15-000006:notes:80]
[same as prior period, unchanged from 0001069202-14-000008:notes:84]

[0001069202-15-000006:notes:81]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Copper | 2.5 |  |  | 2.9 |  |
| Aluminum | 2.5 |  |  | 2.2 |  |

[0001069202-15-000006:notes:82]
[same as prior period, unchanged from 0001069202-14-000008:notes:86]

[0001069202-15-000006:notes:83]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Notional Amounts (in local currency): |  |  |  |
| Brazilian Real | 4.1 |  |  | 8.7 |  |
| Mexican Peso | 60.7 |  |  | 229.7 |  |
| United States Dollar | 9.0 |  |  | 4.5 |  |
| Euro | 3.9 |  |  | 3.6 |  |
| Polish Zloty | 20.2 |  |  | 30.6 |  |
| Russian Ruble | 69.9 |  |  | 80.8 |  |

[0001069202-15-000006:notes:84]
[same as prior period, unchanged from 0001069202-14-000008:notes:88]

[0001069202-15-000006:notes:85]
[same as prior period, unchanged from 0001069202-14-000008:notes:89]

[0001069202-15-000006:notes:86]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of March 31, 2015 |  | As of December 31, 2014 |  | As of March 31, 2015 |  | As of December 31, 2014 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.3 |  |  | 0.3 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.2 |  |  | — |  |  | — |  |  | — |  |
| Total Assets | $ | 0.2 |  |  | $ | — |  |  | $ | 0.3 |  |  | $ | 0.3 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 5.9 |  |  | $ | 6.7 |  |  | $ | 0.7 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.2 |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  |  | 0.5 |  |  | — |  |  | 0.1 |  |
| Total Liabilities | $ | 5.9 |  |  | $ | 7.2 |  |  | $ | 0.9 |  |  | $ | 0.8 |  |

[0001069202-15-000006:notes:87]
[same as prior period, unchanged from 0001069202-14-000008:notes:91]

[0001069202-15-000006:notes:88]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended March 31, |
|  |  | 2015 |  | 2014 |
| Amount of Loss reclassified from AOCL into Income (Effective Portion) (1) |  | $ | 3.4 |  |  | $ | 1.1 |  |
| Amount of Loss (Gain) recognized in Net income (Ineffective Portion) (2) |  | $ | — |  |  | $ | 0.1 |  |

[0001069202-15-000006:notes:89]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended March 31, |
|  |  | 2015 |  | 2014 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |
| Commodity futures contracts (2) |  | $ | 0.3 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts (2) |  | 0.2 |  |  | 0.1 |  |
|  |  | $ | 0.5 |  |  | $ | 0.8 |  |

[0001069202-15-000006:notes:90]
[same as prior period, unchanged from 0001069202-14-000008:notes:94]

[0001069202-15-000006:notes:91]
[same as prior period, unchanged from 0001069202-14-000008:notes:95]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-15-000006:notes:92]
[same as prior period, unchanged from 0001069202-14-000008:notes:96]

[0001069202-15-000006:notes:93]
[same as prior period, unchanged from 0001069202-14-000008:notes:97]

[0001069202-15-000006:notes:94]
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Stock-based compensation expense (1) | $ | 3.5 |  |  | $ | 3.8 |  |

[0001069202-15-000006:notes:95]
[same as prior period, unchanged from 0001069202-14-000008:notes:99]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-15-000006:notes:96]
[same as prior period, unchanged from 0001069202-14-000008:notes:100]

[0001069202-15-000006:notes:97]
[same as prior period, unchanged from 0001069202-14-000008:notes:101]

[0001069202-15-000006:notes:98]
There were no assets and liabilities related to the Service Experts or Hearth businesses included in the accompanying Consolidated Balance Sheets as of March 31, 2015 or December 31, 2014, except for insurance casualty loss reserves which we retained after the respective transactions.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in discontinued operations in the accompanying Consolidated Statements of Operations.  The following table provides a summary of net trade sales, pre-tax operating income (loss) and other supplemental information related to discontinued operations (in millions):

[0001069202-15-000006:notes:99]
|  | Service Experts |
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | (0.1 | ) |  | — |  |
| Gain (loss) on sale of business | — |  |  | (0.1 | ) |

[0001069202-15-000006:notes:100]
[same as prior period, unchanged from 0001069202-14-000008:notes:104]

[0001069202-15-000006:notes:101]
|  | Hearth |
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | (0.1 | ) |  | — |  |
| Gain (loss) on sale of business | — |  |  | 0.1 |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-15-000006:notes:102]
[same as prior period, unchanged from 0001069202-14-000008:notes:106]

[0001069202-15-000006:notes:103]
[same as prior period, unchanged from 0001069202-14-000008:notes:107]

[0001069202-15-000006:notes:104]
[same as prior period, unchanged from 0001069202-14-000008:notes:108]

[0001069202-15-000006:notes:105]
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Net income | $ | 13.9 |  |  | $ | 19.9 |  |
| Add: Loss from discontinued operations | 0.1 |  |  | — |  |
| Income from continuing operations | $ | 14.0 |  |  | $ | 19.9 |  |
| Weighted-average shares outstanding – basic | 44.7 |  |  | 49.0 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.8 |  |  | 0.9 |  |
| Weighted-average shares outstanding – diluted | 45.5 |  |  | 49.9 |  |
| Earnings per share – Basic: |  |  |  |
| Income from continuing operations | $ | 0.31 |  |  | $ | 0.41 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 0.31 |  |  | $ | 0.41 |  |
| Earnings per share – Diluted: |  |  |  |
| Income from continuing operations | $ | 0.31 |  |  | $ | 0.40 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 0.31 |  |  | $ | 0.40 |  |

[0001069202-15-000006:notes:106]
[same as prior period, unchanged from 0001069202-14-000008:notes:110]

[0001069202-15-000006:notes:107]
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Weighted-average number of shares | 0.2 |  |  | 0.3 |  |
| Price range per share | $ | 92.64 |  |  | $81.11 - $81.14 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-15-000006:notes:108]
The following table presents their fair value (in millions):

[0001069202-15-000006:notes:109]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Senior unsecured notes | $ | 214.8 |  |  | $ | 210.6 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-15-000006:notes:110]
[same as prior period, unchanged from 0001069202-14-000008:notes:113]

[0001069202-15-000006:notes:111]
[same as prior period, unchanged from 0001069202-14-000008:notes:114]

[0001069202-15-000006:notes:112]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2015 were the same as those used at December 31, 2014.

[0001069202-15-000006:notes:113]
[same as prior period, unchanged from 0001069202-14-000008:notes:116]

[0001069202-15-000006:notes:114]
[same as prior period, unchanged from 0001069202-14-000008:notes:117]

[0001069202-15-000006:notes:115]
[same as prior period, unchanged from 0001069202-14-000008:notes:118]

[0001069202-15-000006:notes:116]
[same as prior period, unchanged from 0001069202-14-000008:notes:119]

[0001069202-15-000006:notes:117]
[same as prior period, unchanged from 0001069202-14-000008:notes:120]

[0001069202-15-000006:notes:118]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Investment in marketable equity securities | $ | 5.5 |  |  | $ | 5.3 |  |

[0001069202-15-000006:notes:119]
[same as prior period, unchanged from 0001069202-14-000008:notes:122]

[0001069202-15-000006:notes:120]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-15-000006:notes:121]
[same as prior period, unchanged from 0001069202-14-000008:notes:124]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-15-000006:notes:122]
[same as prior period, unchanged from 0001069202-14-000008:notes:125]

[0001069202-15-000006:notes:123]
The changes in the carrying amount of goodwill for the first three months of 2015, in total and by segment, are summarized in the table below (in millions):

[0001069202-15-000006:notes:124]
|  | Balance at December 31, 2014 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at March 31, 2015 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 62.3 |  |  | — |  |  | (1.7 | ) |  | 60.6 |  |
| Refrigeration | 121.0 |  |  | — |  |  | (3.2 | ) |  | 117.8 |  |
| Total Goodwill | $ | 209.4 |  |  | $ | — |  |  | $ | (4.9 | ) |  | $ | 204.5 |  |

[0001069202-15-000006:notes:125]
[same as prior period, unchanged from 0001069202-14-000008:notes:128]

[0001069202-15-000006:notes:126]
We performed our annual goodwill impairment test in the fourth quarter of 2014 and did not record any goodwill impairments.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-15-000006:notes:127]
[same as prior period, unchanged from 0001069202-14-000008:notes:130]

[0001069202-15-000006:notes:128]
As of March 31, 2015, we had approximately $1.6 million in total gross unrecognized tax benefits. Of this amount, $1.2 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of March 31, 2015, we had approximately $0.2 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-15-000006:notes:129]
We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2015 and 2014 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2009.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-15-000006:notes:130]
[same as prior period, unchanged from 0001069202-14-000008:notes:134]

[0001069202-15-000006:notes:131]
[same as prior period, unchanged from 0001069202-14-000008:notes:135]

[0001069202-15-000006:notes:132]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Finished goods | $ | 399.3 |  |  | $ | 338.2 |  |
| Work in process | 9.4 |  |  | 8.1 |  |
| Raw materials and parts | 190.6 |  |  | 182.6 |  |
| Subtotal | 599.3 |  |  | 528.9 |  |
| Excess of current cost over last-in, first-out cost | (66.2 | ) |  | (65.6 | ) |
| Total inventories, net | $ | 533.1 |  |  | $ | 463.3 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-15-000006:notes:133]
[same as prior period, unchanged from 0001069202-14-000008:notes:140]

[0001069202-15-000006:notes:134]
[same as prior period, unchanged from 0001069202-14-000008:notes:141]

[0001069202-15-000006:notes:135]
[same as prior period, unchanged from 0001069202-14-000008:notes:142]

[0001069202-15-000006:notes:136]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-15-000006:notes:137]
[same as prior period, unchanged from 0001069202-14-000008:notes:144]

[0001069202-15-000006:notes:138]
[same as prior period, unchanged from 0001069202-14-000008:notes:145]

[0001069202-15-000006:notes:139]
[same as prior period, unchanged from 0001069202-14-000008:notes:146]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-15-000006:notes:140]
[same as prior period, unchanged from 0001069202-14-000008:notes:147]

[0001069202-15-000006:notes:141]
[same as prior period, unchanged from 0001069202-14-000008:notes:148]

[0001069202-15-000006:notes:142]
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.2 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.3 |  |  | 4.4 |  |  | — |  |  | — |  |
| Expected return on plan assets | (5.3 | ) |  | (5.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  | (0.8 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.4 |  |  | 1.6 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | 0.3 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 2.9 |  |  | $ | 1.5 |  |  | $ | (0.4 | ) |  | $ | (0.4 | ) |

[0001069202-15-000006:notes:143]
(1) All net periodic benefit cost for the three months ended March 31, 2015 and 2014 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-15-000006:notes:144]
[same as prior period, unchanged from 0001069202-14-000008:notes:152]

[0001069202-15-000006:notes:145]
|  | For the Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Net Sales |  |  |  |
| Residential Heating & Cooling | $ | 362.5 |  |  | $ | 342.1 |  |
| Commercial Heating & Cooling | 159.9 |  |  | 173.0 |  |
| Refrigeration | 163.4 |  |  | 180.3 |  |
|  | $ | 685.8 |  |  | $ | 695.4 |  |
| Segment Profit (Loss) (1) |  |  |  |
| Residential Heating & Cooling | $ | 31.2 |  |  | $ | 24.4 |  |
| Commercial Heating & Cooling | 7.7 |  |  | 10.2 |  |
| Refrigeration | 4.0 |  |  | 12.1 |  |
| Corporate and other | (11.7 | ) |  | (11.4 | ) |
| Subtotal that includes segment profit and eliminations | 31.2 |  |  | 35.3 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |
| Special product quality adjustments | (0.2 | ) |  | — |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 4.1 |  |  | 1.3 |  |
| Restructuring charges | 0.3 |  |  | 0.1 |  |
| Interest expense, net | 5.7 |  |  | 3.3 |  |
| Special inventory write down | — |  |  | — |  |
| Other expense (income), net | — |  |  | — |  |
| Income from continuing operations before income taxes | $ | 21.3 |  |  | $ | 30.6 |  |

[0001069202-15-000006:notes:146]
[same as prior period, unchanged from 0001069202-14-000008:notes:154]

[0001069202-15-000006:notes:147]
[same as prior period, unchanged from 0001069202-14-000008:notes:155]

[0001069202-15-000006:notes:148]
[same as prior period, unchanged from 0001069202-14-000008:notes:156]

[0001069202-15-000006:notes:149]
[same as prior period, unchanged from 0001069202-14-000008:notes:157]

[0001069202-15-000006:notes:150]
| ◦ | Special legal contingency charges, |

[0001069202-15-000006:notes:151]
| ◦ | Asbestos-related litigation, |

[0001069202-15-000006:notes:152]
[same as prior period, unchanged from 0001069202-14-000008:notes:160]

[0001069202-15-000006:notes:153]
[same as prior period, unchanged from 0001069202-14-000008:notes:161]

[0001069202-15-000006:notes:154]
[same as prior period, unchanged from 0001069202-14-000008:notes:162]

[0001069202-15-000006:notes:155]
[same as prior period, unchanged from 0001069202-14-000008:notes:163]

[0001069202-15-000006:notes:156]
[same as prior period, unchanged from 0001069202-14-000008:notes:164]

[0001069202-15-000006:notes:157]
[same as prior period, unchanged from 0001069202-14-000008:notes:165]

[0001069202-15-000006:notes:158]
[same as prior period, unchanged from 0001069202-14-000008:notes:166]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-15-000006:notes:159]
[same as prior period, unchanged from 0001069202-14-000008:notes:167]

[0001069202-15-000006:notes:160]
[same as prior period, unchanged from 0001069202-14-000008:notes:168]

[0001069202-15-000006:notes:161]
Restructuring Activities in 2015

[0001069202-15-000006:notes:162]
[same as prior period, unchanged from 0001069202-14-000008:notes:170]

[0001069202-15-000006:notes:163]
|  | Charges Incurred in 2015 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 0.1 |  |  | $ | 7.0 |  |  | $ | 7.3 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 1.9 |  |  | 1.9 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |
| Other | 0.1 |  |  | 1.9 |  |  | 2.2 |  |
| Total restructuring charges | $ | 0.3 |  |  | $ | 10.8 |  |  | $ | 11.4 |  |

[0001069202-15-000006:notes:164]
[same as prior period, unchanged from 0001069202-14-000008:notes:172]

[0001069202-15-000006:notes:165]
|  | Charges Incurred in 2015 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.1 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | 0.2 |  |  | 8.3 |  |  | 8.9 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total restructuring charges | $ | 0.3 |  |  | $ | 10.8 |  |  | $ | 11.4 |  |

[0001069202-15-000006:notes:166]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below details the activity in 2015 within the restructuring accruals (in millions):

[0001069202-15-000006:notes:167]
|  | Balance as ofDecember 31, 2014 |  | Charged to Earnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of March 31, 2015 |
| Severance and related expense | $ | 1.5 |  |  | $ | 0.1 |  |  | $ | (0.2 | ) |  |  |  |  | $ | 1.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.1 |  |  |  |  |  |  |  |  | 0.1 |  |
| Equipment moves | 0.1 |  |  |  |  |  | (0.1 | ) |  |  |  |  | — |  |
| Lease termination | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Other | — |  |  | 0.1 |  |  | (0.1 | ) |  |  |  |  | — |  |
| Total restructuring accruals | $ | 1.6 |  |  | $ | 0.3 |  |  | $ | (0.4 | ) |  | $ | — |  |  | $ | 1.5 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-15-000006:notes:168]
[same as prior period, unchanged from 0001069202-14-000008:notes:176]

[0001069202-15-000006:notes:169]
[same as prior period, unchanged from 0001069202-14-000008:notes:177]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-15-000006:notes:170]
[same as prior period, unchanged from 0001069202-14-000008:notes:178]

[0001069202-15-000006:notes:171]
[same as prior period, unchanged from 0001069202-14-000008:notes:179]

[0001069202-15-000006:notes:172]
[same as prior period, unchanged from 0001069202-14-000008:notes:180]

[0001069202-15-000006:notes:173]
[same as prior period, unchanged from 0001069202-14-000008:notes:181]

[0001069202-15-000006:notes:174]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations for the periods presented as follows.

[0001069202-15-000006:notes:175]
[same as prior period, unchanged from 0001069202-14-000008:notes:183]

[0001069202-15-000006:notes:176]
[same as prior period, unchanged from 0001069202-14-000008:notes:184]

[0001069202-15-000006:notes:177]
Except for the seasonal increase in total assets across all reportable segments, there have not been any material changes in the composition of total assets by segment since December 31, 2014.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-15-000006:notes:178]
[same as prior period, unchanged from 0001069202-14-000008:notes:186]

[0001069202-15-000006:notes:179]
Our Board of Directors has authorized a total of $1.4 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first three months of 2015. As of March 31, 2015, $395.9 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-15-000006:notes:180]
We also repurchased 0.2 million shares for $20.5 million for the three months ended March 31, 2015 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
