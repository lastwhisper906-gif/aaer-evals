# LII 8-K — 0001193125-15-137041 filed 2015-04-20

## item codes, every 8-K on or before 2015-04-20

- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2015-04-20

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-137041:8k_2_02:1]
EX-99.1
2
d908781dex991.htm
EX-99.1

[0001193125-15-137041:8k_2_02:2]
EX-99.1

[0001193125-15-137041:8k_2_02:3]
Exhibit 99.1

[0001193125-15-137041:8k_2_02:4]
Lennox International Reports First Quarter Results

[0001193125-15-137041:8k_2_02:5]
| • |  | Adjusted EPS from continuing operations of $0.37, and GAAP EPS from continuing operations of $0.31 |

[0001193125-15-137041:8k_2_02:6]
| • |  | Reiterating 2015 revenue growth guidance of 4-8% at constant currency |

[0001193125-15-137041:8k_2_02:7]
| • |  | Reiterating 2015 adjusted EPS from continuing operations guidance of $5.20-$5.60, and updating GAAP EPS from continuing operations guidance to $5.14-$5.54 |

[0001193125-15-137041:8k_2_02:8]
DALLAS, April 20, 2015 – Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2015. Financial results
reflect sold businesses in discontinued operations.

[0001193125-15-137041:8k_2_02:9]
Revenue for the first quarter was $686 million, down 1% from the prior-year quarter including the
negative impact from foreign exchange. At constant currency, revenue was up 2%, led by 7% growth in the Residential business. Adjusted earnings per share from continuing operations was $0.37 compared to $0.42 in the prior-year quarter. On a GAAP
basis, earnings per share from continuing operations was $0.31 compared to $0.40 in the prior-year quarter.

[0001193125-15-137041:8k_2_02:10]
“We continued to see strong momentum in
our Residential business in the first quarter, and our Refrigeration business was as expected,” said Chairman and CEO Todd Bluedorn. “However, our Commercial business saw the timing of specific national account equipment business shift
beyond the first quarter into the second through fourth quarters of this year. While Commercial national account business was down in the first quarter, our backlog is up double digits from a year ago, and we continue to expect solid growth for 2015
overall. Our non-national account business in North America continued to see strong momentum with high single-digit revenue growth in the first quarter. Overall for the Commercial business segment in the quarter, revenue was down 3% at constant
currency. In Refrigeration, North America revenue was up mid single-digits, led by strong double-digit growth in supermarkets. Europe and Australia revenue was down double digits, with the mid-2014 repeal of the carbon tax in Australia significantly
impacting profitability as expected and previously discussed. Overall for the Refrigeration business segment, revenue was down 2% at constant currency. In Residential, revenue was up 7% at constant currency. Residential profit rose 28% and segment
margin expanded 150 basis points to 8.6% as our strong business momentum continued.

[0001193125-15-137041:8k_2_02:11]
“Looking ahead for the company overall in 2015, we remain
well-positioned to capitalize on growth in our end markets, capture additional market share, and drive our operational initiatives for higher profitability. We continue to expect revenue growth of 4-8% at constant currency and reiterate guidance for
adjusted EPS from continuing operations of $5.20-$5.60 for the full year. The second quarter is off to a solid start, and we look forward to our strongest seasonal periods of the year.”

[0001193125-15-137041:8k_2_02:12]
FINANCIAL HIGHLIGHTS

[0001193125-15-137041:8k_2_02:13]
Revenue: Revenue for the first quarter was $686 million, down 1% from the prior-year quarter. At constant currency, revenue was up 2%. Volume and price
were up, and mix was down from the prior-year quarter.

[0001193125-15-137041:8k_2_02:14]
Gross Profit: Gross profit for the first quarter was $163 million compared to $168 million
in the prior-year quarter. Gross margin was 23.8% compared to 24.2% in the prior-year quarter. Gross profit was negatively impacted by negative mix, Australian refrigerant profitability, foreign exchange, and investments in distribution expansion,
with partial offsets from higher volume, favorable price, and lower material costs.

[0001193125-15-137041:8k_2_02:15]
Income from Continuing Operations: Adjusted income from
continuing operations in the first quarter was $16.8 million, or $0.37 per share, compared to $20.8 million, or $0.42 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the first quarter of 2015 excludes $2.8
million in after-tax charges: $2.2 million in special legal contingency charges, $0.5 million for environmental liabilities, and $0.1 million for other items, net.

[0001193125-15-137041:8k_2_02:16]
On a GAAP basis, income from continuing operations for the first quarter was $14.0 million, or $0.31 per share, compared to $19.9 million, or $0.40 per share,
in the prior-year quarter.

[0001193125-15-137041:8k_2_02:17]
Free Cash Flow and Total Debt: Net cash used in operations in the first quarter was $122 million compared to $125
million in the prior-year quarter. The company invested $18 million in capital assets in the first quarter compared to $17 million in the first quarter a year ago. Free cash flow was ($140) million compared to ($142) million in the prior-year
quarter. Total debt at the end of the first quarter was $1,086 million. Total cash and cash equivalents were $37 million at the end of the quarter. The company paid $13 million in dividends in the first quarter. The company’s previously
announced $450 million accelerated stock repurchase program continues and is still expected to be completed in the second half of 2015.

[0001193125-15-137041:8k_2_02:18]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-15-137041:8k_2_02:19]
Residential Heating & Cooling

[0001193125-15-137041:8k_2_02:20]
First quarter 2015
revenue in the Residential Heating & Cooling business segment was $363 million, up 6% from the prior-year quarter. At constant currency, revenue was up 7%. Segment profit was $31 million, up 28% from the prior-year quarter. Segment profit
margin was 8.6%, up 150 basis points from the prior-year quarter. Results were primarily impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from negative foreign exchange and investments in SG&A and
distribution expansion.

[0001193125-15-137041:8k_2_02:21]
Commercial Heating & Cooling

[0001193125-15-137041:8k_2_02:22]
Revenue in the Commercial Heating & Cooling business segment was $160 million, down 8% from the prior-year quarter. At constant currency, revenue was
down 3%. Segment profit was $8 million, down 25% from the prior-year quarter. Segment profit margin was 4.8%, down 110 basis points from the prior-year quarter. Results were primarily impacted by lower volume, negative foreign exchange, and
investments in distribution expansion and the VRF business, with partial offsets from favorable price/mix and lower material costs.

[0001193125-15-137041:8k_2_02:23]
Refrigeration

[0001193125-15-137041:8k_2_02:24]
Revenue in the Refrigeration business segment was $163 million in the first quarter, down 9%. At constant currency, revenue was down 2%. Segment
profit was $4 million, down 67% from $12 million in the prior-year quarter. Segment profit margin was 2.4%, down 430 basis points from the prior-year quarter. Results were primarily impacted by lower Australian refrigerant profitability, unfavorable
mix in North America supermarket business, and negative foreign exchange, with partial offsets from lower material costs and factory productivity.

[0001193125-15-137041:8k_2_02:25]
FULL-YEAR OUTLOOK

[0001193125-15-137041:8k_2_02:26]
For 2015, the company reiterates
revenue and adjusted EPS from continuing operations guidance.

[0001193125-15-137041:8k_2_02:27]
|  | • |  | Reiterating revenue growth guidance of 4-8% at constant currency; the company continues to expect a negative 3 point impact from foreign exchange on a full-year basis for a revenue growth range of 1-5% at actual currency. |

[0001193125-15-137041:8k_2_02:28]
|  | • |  | Reiterating adjusted EPS from continuing operations guidance of $5.20-$5.60. |

[0001193125-15-137041:8k_2_02:29]
|  | • |  | Updating GAAP EPS from continuing operations guidance from $5.20-$5.60 to $5.14-$5.54. |

[0001193125-15-137041:8k_2_02:30]
|  | • |  | Reiterating effective tax rate guidance of 34-35% on a full-year basis. |

[0001193125-15-137041:8k_2_02:31]
|  | • |  | Reiterating capital expenditure guidance of approximately $85 million. |

[0001193125-15-137041:8k_2_02:32]
|  | • |  | Reiterating guidance for the company’s previously announced $450 million accelerated share repurchase program to be completed in the second half of 2015. |

[0001193125-15-137041:8k_2_02:33]
CONFERENCE CALL INFORMATION

[0001193125-15-137041:8k_2_02:34]
A conference call to discuss the company’s first quarter results will be held this morning at 8:30 a.m. Central time. To listen, please call the
conference call line at 612-234-9960 at least 10 minutes prior to the scheduled start time and use reservation number 357376. The conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay
will be available from 11:30 a.m. Central time on April 20 through April 27, 2015 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 357376. The call will also be archived on the company’s web site.

[0001193125-15-137041:8k_2_02:35]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New
York Stock Exchange under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-15-137041:8k_2_02:36]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-137041:8k_2_02:37]
Consolidated Statements of Operations

[0001193125-15-137041:8k_2_02:38]
(Unaudited)

[0001193125-15-137041:8k_2_02:39]
| (Amounts in millions, except per share data) |  | For the Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 685.8 |  |  | $ | 695.4 |  |
| Cost of goods sold |  |  | 522.8 |  |  |  | 527.3 |  |
| Gross profit |  |  | 163.0 |  |  |  | 168.1 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 133.4 |  |  |  | 135.6 |  |
| Losses (gains) and other expenses, net |  |  | 5.6 |  |  |  | 2.4 |  |
| Restructuring charges |  |  | 0.3 |  |  |  | 0.1 |  |
| Income from equity method investments |  |  | (3.3 | ) |  |  | (3.9 | ) |
| Operational income from continuing operations |  |  | 27.0 |  |  |  | 33.9 |  |
| Interest expense, net |  |  | 5.7 |  |  |  | 3.3 |  |
| Other expense (income), net |  |  | — |  |  |  | — |  |
| Income from continuing operations before income taxes |  |  | 21.3 |  |  |  | 30.6 |  |
| Provision for income taxes |  |  | 7.3 |  |  |  | 10.7 |  |
| Income from continuing operations |  |  | 14.0 |  |  |  | 19.9 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | (0.2 | ) |  |  | — |  |
| Benefit from income taxes |  |  | (0.1 | ) |  |  | — |  |
| Loss from discontinued operations |  |  | (0.1 | ) |  |  | — |  |
| Net income |  | $ | 13.9 |  |  | $ | 19.9 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.31 |  |  | $ | 0.41 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 0.31 |  |  | $ | 0.41 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.31 |  |  | $ | 0.40 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 0.31 |  |  | $ | 0.40 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 44.7 |  |  |  | 49.0 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 45.5 |  |  |  | 49.9 |  |
| Cash dividends declared per share |  | $ | 0.30 |  |  | $ | 0.24 |  |

[0001193125-15-137041:8k_2_02:40]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-137041:8k_2_02:41]
Segment Net Sales and Profit (Loss)

[0001193125-15-137041:8k_2_02:42]
(Unaudited)

[0001193125-15-137041:8k_2_02:43]
| (Amounts in millions) |  | For the Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 362.5 |  |  | $ | 342.1 |  |
| Commercial Heating & Cooling |  |  | 159.9 |  |  |  | 173.0 |  |
| Refrigeration |  |  | 163.4 |  |  |  | 180.3 |  |
|  |  | $ | 685.8 |  |  | $ | 695.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 31.2 |  |  | $ | 24.4 |  |
| Commercial Heating & Cooling |  |  | 7.7 |  |  |  | 10.2 |  |
| Refrigeration |  |  | 4.0 |  |  |  | 12.1 |  |
| Corporate and other |  |  | (11.7 | ) |  |  | (11.4 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 31.2 |  |  |  | 35.3 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (0.2 | ) |  |  | — |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 4.1 |  |  |  | 1.3 |  |
| Restructuring charges |  |  | 0.3 |  |  |  | 0.1 |  |
| Interest expense, net |  |  | 5.7 |  |  |  | 3.3 |  |
| Special inventory write down |  |  | — |  |  |  | — |  |
| Other expense (income), net |  |  | — |  |  |  | — |  |
| Income from continuing operations before income taxes |  | $ | 21.3 |  |  | $ | 30.6 |  |

[0001193125-15-137041:8k_2_02:44]
| (1) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-15-137041:8k_2_02:45]
|  | • |  | Special product quality adjustments; |

[0001193125-15-137041:8k_2_02:46]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-15-137041:8k_2_02:47]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-15-137041:8k_2_02:48]
|  | • |  | Special legal contingency charges, |

[0001193125-15-137041:8k_2_02:49]
|  | • |  | Asbestos-related litigation, |

[0001193125-15-137041:8k_2_02:50]
|  | • |  | Environmental liabilities, and |

[0001193125-15-137041:8k_2_02:51]
|  | • |  | Other items, net; |

[0001193125-15-137041:8k_2_02:52]
|  | • |  | Restructuring charges; |

[0001193125-15-137041:8k_2_02:53]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments; |

[0001193125-15-137041:8k_2_02:54]
|  | • |  | Interest expense, net; |

[0001193125-15-137041:8k_2_02:55]
|  | • |  | Special inventory write down; and |

[0001193125-15-137041:8k_2_02:56]
|  | • |  | Other expense, net. |

[0001193125-15-137041:8k_2_02:57]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-137041:8k_2_02:58]
Consolidated Balance Sheets

[0001193125-15-137041:8k_2_02:59]
| (Amounts in millions, except shares and par values) |  | As of March 31,2015 |  |  | As of December 31,2014 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 36.7 |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net of allowances of $7.5 and $7.9 in 2015 and 2014, respectively |  |  | 449.4 |  |  |  | 421.4 |  |
| Inventories, net |  |  | 533.1 |  |  |  | 463.3 |  |
| Deferred income taxes, net |  |  | 32.7 |  |  |  | 32.5 |  |
| Other assets |  |  | 88.4 |  |  |  | 59.3 |  |
| Total current assets |  |  | 1,140.3 |  |  |  | 1,014.0 |  |
| Property, plant and equipment, net of accumulated depreciation of $655.3 and $654.1 in 2015 and 2014, respectively |  |  | 356.0 |  |  |  | 358.6 |  |
| Goodwill |  |  | 204.5 |  |  |  | 209.4 |  |
| Deferred income taxes |  |  | 91.5 |  |  |  | 97.5 |  |
| Other assets, net |  |  | 87.2 |  |  |  | 84.8 |  |
| Total assets |  | $ | 1,879.5 |  |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 185.3 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt |  |  | 31.5 |  |  |  | 24.0 |  |
| Accounts payable |  |  | 347.6 |  |  |  | 324.3 |  |
| Accrued expenses |  |  | 204.9 |  |  |  | 239.0 |  |
| Income taxes payable |  |  | 1.2 |  |  |  | 13.4 |  |
| Total current liabilities |  |  | 770.5 |  |  |  | 827.3 |  |
| Long-term debt |  |  | 869.0 |  |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions |  |  | 4.0 |  |  |  | 4.5 |  |
| Pensions |  |  | 131.0 |  |  |  | 129.9 |  |
| Other liabilities |  |  | 121.2 |  |  |  | 118.6 |  |
| Total liabilities |  |  | 1,895.7 |  |  |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ (deficit) equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 839.4 |  |  |  | 824.9 |  |
| Retained earnings |  |  | 1,022.5 |  |  |  | 1,022.1 |  |
| Accumulated other comprehensive loss |  |  | (178.7 | ) |  |  | (153.5 | ) |
| Treasury stock, at cost, 42,181,306 shares and 42,535,126 shares in 2015 and 2014, respectively |  |  | (1,700.9 | ) |  |  | (1,686.0 | ) |
| Noncontrolling interests |  |  | 0.6 |  |  |  | 0.6 |  |
| Total stockholders’ (deficit) equity |  |  | (16.2 | ) |  |  | 9.0 |  |
| Total liabilities and stockholders’ (deficit) equity |  | $ | 1,879.5 |  |  | $ | 1,764.3 |  |

[0001193125-15-137041:8k_2_02:60]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-137041:8k_2_02:61]
Consolidated Statements of Cash Flows

[0001193125-15-137041:8k_2_02:62]
(Unaudited)

[0001193125-15-137041:8k_2_02:63]
| (Amounts in millions) |  | For the Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 13.9 |  |  | $ | 19.9 |  |
| Net loss from discontinued operations |  |  | 0.1 |  |  |  | — |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (3.3 | ) |  |  | (3.9 | ) |
| Dividends from affiliates |  |  |  |  |  |  |  |  |
| Restructuring expenses, net of cash paid |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Provision for bad debts |  |  | 0.9 |  |  |  | (0.1 | ) |
| Unrealized losses on derivative contracts |  |  | 0.2 |  |  |  | 0.6 |  |
| Stock-based compensation expense |  |  | 3.5 |  |  |  | 3.8 |  |
| Depreciation and amortization |  |  | 15.5 |  |  |  | 15.0 |  |
| Deferred income taxes |  |  | (1.1 | ) |  |  | 0.5 |  |
| Other items, net |  |  | 0.1 |  |  |  | 12.8 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (40.1 | ) |  |  | (33.8 | ) |
| Inventories |  |  | (78.5 | ) |  |  | (122.9 | ) |
| Other current assets |  |  | 1.0 |  |  |  | (1.7 | ) |
| Accounts payable |  |  | 29.6 |  |  |  | 59.5 |  |
| Accrued expenses |  |  | (29.0 | ) |  |  | (33.1 | ) |
| Income taxes payable and receivable |  |  | (40.1 | ) |  |  | (29.3 | ) |
| Other |  |  | 5.3 |  |  |  | (12.2 | ) |
| Net cash used in discontinued operations |  |  | (0.1 | ) |  |  | — |  |
| Net cash used in operating activities |  |  | (122.2 | ) |  |  | (125.0 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  |  |  |  |  | — |  |
| Purchases of property, plant and equipment |  |  | (18.0 | ) |  |  | (17.3 | ) |
| Net proceeds from sale of business |  |  | — |  |  |  |  |  |
| Net cash used in discontinued operations |  |  | — |  |  |  |  |  |
| Net cash used in investing activities |  |  | (18.0 | ) |  |  | (17.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (0.2 | ) |  |  | 2.5 |  |
| Asset securitization borrowings |  |  | (40.0 | ) |  |  | — |  |
| Asset securitization payments |  |  | — |  |  |  | — |  |
| Long-term debt payments |  |  | — |  |  |  | (0.4 | ) |
| Borrowings from revolving credit facility |  |  | 580.5 |  |  |  | 479.0 |  |
| Payments on revolving credit facility |  |  | (379.0 | ) |  |  | (319.0 | ) |
| Proceeds from employee stock purchases |  |  | 0.6 |  |  |  | 0.5 |  |
| Repurchases of common stock |  |  | — |  |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (20.5 | ) |  |  | (10.7 | ) |
| Excess tax benefits related to share-based payments |  |  | 16.0 |  |  |  | 4.2 |  |
| Cash dividends paid |  |  | (13.4 | ) |  |  | (11.8 | ) |
| Net cash provided by financing activities |  |  | 144.0 |  |  |  | 144.3 |  |
| Increase in cash and cash equivalents |  |  | 3.8 |  |  |  | 2.0 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (4.6 | ) |  |  | (1.0 | ) |
| Cash and cash equivalents, beginning of period |  |  | 37.5 |  |  |  | 38.0 |  |
| Cash and cash equivalents, end of period |  | $ | 36.7 |  |  | $ | 39.0 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 3.1 |  |  | $ | 1.2 |  |
| Income taxes paid (net of refunds) |  | $ | 32.2 |  |  | $ | 35.4 |  |

[0001193125-15-137041:8k_2_02:64]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-137041:8k_2_02:65]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-15-137041:8k_2_02:66]
(Unaudited, in millions, except per share and ratio data)

[0001193125-15-137041:8k_2_02:67]
Use of Non-GAAP Financial Measures

[0001193125-15-137041:8k_2_02:68]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide
information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating
performance.

[0001193125-15-137041:8k_2_02:69]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-15-137041:8k_2_02:70]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Income from continuing operations, a GAAP measure |  | $ | 14.0 |  |  | $ | 19.9 |  |
| Restructuring charges, after tax |  |  | 0.2 |  |  |  | 0.1 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.1 | ) |  |  | — |  |
| Special legal contingency charges, after tax (a) |  |  | 2.2 |  |  |  | 0.2 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.1 |  |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax (a) |  |  | (0.1 | ) |  |  | 0.4 |  |
| Environmental liabilities, after tax (a) |  |  | 0.5 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | 0.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 16.8 |  |  | $ | 20.8 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 0.31 |  |  | $ | 0.40 |  |
| Special legal contingency charges, after tax (a) |  |  | 0.05 |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax (a) |  |  | — |  |  |  | 0.01 |  |
| Environmental liabilities, after tax (a) |  |  | 0.01 |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  | $ | 0.37 |  |  | $ | 0.42 |  |

[0001193125-15-137041:8k_2_02:71]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-15-137041:8k_2_02:72]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-15-137041:8k_2_02:73]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.4 |  |  | $ | 0.2 |  |
| Foreign currency exchange losses (gains) (a) |  |  | 1.1 |  |  |  | 0.8 |  |
| Loss on disposal of fixed assets (a) |  |  | — |  |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | (0.1 | ) |  |  | 0.6 |  |
| Special legal contingency charges (b) |  |  | 3.4 |  |  |  | 0.4 |  |
| Asbestos-related litigation (b) |  |  | 0.1 |  |  |  | 0.2 |  |
| Environmental liabilities (b) |  |  | 0.7 |  |  |  | — |  |
| Other items, net (b) |  |  | — |  |  |  | 0.1 |  |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 5.6 |  |  | $ | 2.4 |  |

[0001193125-15-137041:8k_2_02:74]
| (a) | Included in segment profit (loss) and Adjusted income from continuing operations |

[0001193125-15-137041:8k_2_02:75]
| (b) | Excluded from segment profit (loss) and Adjusted income from continuing operations |

[0001193125-15-137041:8k_2_02:76]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-15-137041:8k_2_02:77]
|  |  | For the Year EndedDecember 31, 2015ESTIMATED |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $5.20 - $5.60 |
| Special legal contingency charges and other items |  | (0.06) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $5.14 - $5.54 |

[0001193125-15-137041:8k_2_02:78]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars
in millions)

[0001193125-15-137041:8k_2_02:79]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | (122.2 | ) |  | $ | (125.0 | ) |
| Purchases of property, plant and equipment |  |  | (18.0 | ) |  |  | (17.3 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | (140.2 | ) |  | $ | (142.3 | ) |

[0001193125-15-137041:8k_2_02:80]
|  |  | TrailingTwelveMonths toMarch 31, 2015 |  |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |
| Adjusted EBIT (a) |  | $ | 336.8 |  |
| Depreciation and amortization expense (b) |  |  | 61.3 |  |
| EBITDA (a + b) |  | $ | 398.1 |  |
| Total debt at March 31, 2015 (c) |  | $ | 1,085.8 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.7 |  |

[0001193125-15-137041:8k_2_02:81]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP
measure (dollars in millions)

[0001193125-15-137041:8k_2_02:82]
|  |  | TrailingTwelveMonths toMarch 31, 2015 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  | 336.8 |  |
| Special product quality adjustments |  |  | (1.6 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 7.5 |  |
| Restructuring charges |  |  | 2.1 |  |
| Interest expense, net |  |  | 19.6 |  |
| Special inventory write down |  |  | 1.0 |  |
| Other expenses, net |  |  | (0.1 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  |  | 308.3 |  |
