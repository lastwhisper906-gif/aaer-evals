# LII note change history — 0001069202-14-000008 → 0001069202-15-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-04-20):
[0001069202-15-000006:note_history:1]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Accrued expenses | $ | 26.3 |  |  | $ | 27.3 |  |
| Other liabilities | 60.3 |  |  | 59.9 |  |
| Total warranty liability | $ | 86.6 |  |  | $ | 87.2 |  |
  (was, 2014-10-20, similarity 0.9716):
[0001069202-14-000008:note_history:1]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 27.5 |  |  | $ | 28.7 |  |
| Other liabilities | 58.6 |  |  | 52.9 |  |
| Total warranty liability | $ | 86.1 |  |  | $ | 81.6 |  |

- changed (2015-04-20):
[0001069202-15-000006:note_history:2]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2015 were as follows (in millions):
  (was, 2014-10-20, similarity 0.9416):
[0001069202-14-000008:note_history:2]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2014 were as follows (in millions):

- changed (2015-04-20):
[0001069202-15-000006:note_history:3]
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |
| Warranty claims paid | (4.7 | ) |
| Changes resulting from issuance of new warranties | 6.4 |  |
| Changes in estimates associated with pre-existing liabilities | (1.2 | ) |
| Changes in foreign currency translation rates and other | (1.1 | ) |
| Total warranty liability as of March 31, 2015 | $ | 86.6 |  |
  (was, 2014-10-20, similarity 0.9801):
[0001069202-14-000008:note_history:3]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (16.6 | ) |
| Changes resulting from issuance of new warranties | 24.1 |  |
| Changes in estimates associated with pre-existing liabilities | (2.3 | ) |
| Changes in foreign currency translation rates and other | (0.7 | ) |
| Total warranty liability as of September 30, 2014 | $ | 86.1 |  |

- added (2015-04-20):
[0001069202-15-000006:note_history:4]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties.   Also, to satisfy our customers and protect our brands,  we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a supplier quality issue within a range of $2.2 million and $6 million; accordingly, we have accrued a $2.2 million liability in Accrued Expenses on the Consolidated Balance Sheet because all amounts in that range were equally likely. The supplier has agreed to reimburse our costs related to this liability; accordingly, we have also recorded a receivable of $2.2 million in Other Assets on the Consolidated Balance Sheet.  If additional costs are incurred, we expect the supplier will also reimburse those costs. The $2.2 million accrual is not included in the estimated warranty liabilities tables immediately above.

- changed (2015-04-20):
[0001069202-15-000006:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2015, and 2014, expense for asbestos-related litigation was $0.1 million, and $0.2 million, net of insurance recoveries, respectively.
  (was, 2014-10-20, similarity 0.9758):
[0001069202-14-000008:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2014, and 2013, expense for asbestos-related litigation was $1.0 million, and $0.5 million, net of insurance recoveries, respectively.

- added (2015-04-20):
[0001069202-15-000006:note_history:6]
We are the defendant in an attempted class action lawsuit alleging evaporator coils in our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks.  We dispute the allegations in the lawsuit.  We have reached tentative settlement terms and recorded a liability of $2.4 million in Accrued Expenses on the Consolidated Balance Sheet.   Any additional liability resulting from the proposed settlement is not currently reasonably estimable, but we do not expect the proposed settlement to have a material adverse effect on our financial condition or results of operations.

- removed (2015-04-20):
[0001069202-14-000008:note_history:7]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

- removed (2015-04-20):
[0001069202-14-000008:note_history:8]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the nine months ended September 30, 2014 were as follows (in millions):

- removed (2015-04-20):
[0001069202-14-000008:note_history:9]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.6 | ) |
| Total accrued product quality issues as of September 30, 2014 | $ | 4.1 |  |

- removed (2015-04-20):
[0001069202-14-000008:note_history:10]
The expenses related to these product quality issues were classified in Cost of goods sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the Consolidated Balance Sheets.  The expenses for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated product warranty liabilities.  We may incur additional charges for these product quality issues in the future as more information becomes available.

- removed (2015-04-20):
[0001069202-14-000008:note_history:11]
We are the defendant in an attempted class action lawsuit which alleges that evaporator coils in certain of our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks, and asserts claims for relief.  We dispute the allegations in the lawsuit.  The outcome related to this action is uncertain and we therefore cannot reasonably estimate the amount of any potential impact.


## us-gaap:ProductLiabilityContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2015-04-20):
[0001069202-14-000008:note_history:12]
The changes in the accrued product quality issues for the nine months ended September 30, 2014 were as follows (in millions):

- removed (2015-04-20):
[0001069202-14-000008:note_history:13]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.6 | ) |
| Total accrued product quality issues as of September 30, 2014 | $ | 4.1 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-04-20):
[0001069202-15-000006:note_history:14]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2015, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2015 and 2014, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2015 and 2014, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2015 and 2014 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2014. The accompanying unaudited consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2014-10-20, similarity 0.945):
[0001069202-14-000008:note_history:14]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2014, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- removed (2015-04-20):
[0001069202-14-000008:note_history:15]
Change in method of accounting for evaluating goodwill for impairment

- removed (2015-04-20):
[0001069202-14-000008:note_history:16]
The annual goodwill impairment test was performed during the first quarter of 2014, and no impairment was recognized.  During the third quarter of 2014, we changed the date of our annual goodwill impairment test from March 31st to December 31st. The change was made to more closely align the impairment testing date with the year-end results and may result in impairment charges identified in the fourth quarter.

- removed (2015-04-20):
[0001069202-14-000008:note_history:17]
The change in goodwill impairment testing date is deemed a change in accounting principle. Management believes that the change in accounting principle will not delay, accelerate, or avoid a goodwill impairment charge. Management determined that the change in accounting principle is preferable under the circumstances and does not result in adjustments to our financial statements when applied retrospectively.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-04-20):
[0001069202-15-000006:note_history:18]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.66 | % |  | 1.88 | % |
  (was, 2014-10-20, similarity 0.95):
[0001069202-14-000008:note_history:18]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.38 | % |  | 1.17 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-04-20):
[0001069202-15-000006:note_history:19]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 5.3 |  |  | 6.6 |  |
| Total short-term debt | $ | 185.3 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.5 |  |  | $ | 1.5 |  |
| Domestic credit facility | $ | 30.0 |  |  | $ | 22.5 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.5 |  |  | $ | 15.5 |  |
| Domestic credit facility | 653.5 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 869.0 |  |  | $ | 675.0 |  |
| Total debt | $ | 1,085.8 |  |  | $ | 925.6 |  |

- changed (2015-04-20):
[0001069202-15-000006:note_history:20]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $5.3 million and $6.6 million of foreign obligations as of March 31, 2015 and December 31, 2014, respectively, that were primarily borrowings under non-committed facilities.  Proceeds on these facilities were $11.0 million and $20.6 million during the three months ended March 31, 2015 and 2014, respectively. Repayments on the facilities were $11.2 million and $18.1 million and during the three months ended March 31, 2015 and 2014, respectively.
  (was, 2014-10-20, similarity 0.7055):
[0001069202-14-000008:note_history:20]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $9.0 million and $5.9 million of foreign obligations as of September 30, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.

- changed (2015-04-20):
[0001069202-15-000006:note_history:21]
In November 2014, we amended the ASP, extending its term to November 13, 2015 and increasing the maximum securitization amount from a range of $160.0 million to $220.0 million to a range of $180.0 million to $220.0 million, depending on the period.   The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):
  (was, 2014-10-20, similarity 0.8032):
[0001069202-14-000008:note_history:21]
The ASP provides for a maximum securitization amount ranging from $160.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- added (2015-04-20):
[0001069202-15-000006:note_history:22]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 180.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 180.0 |  |  | 220.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

- changed (2015-04-20):
[0001069202-15-000006:note_history:23]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for both March 31, 2015 and December 31, 2014 was 0.79%. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2014-10-20, similarity 0.977):
[0001069202-14-000008:note_history:23]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for September 30, 2014 and December 31, 2013 was 0.77% and 0.78% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2015-04-20):
[0001069202-15-000006:note_history:24]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2015, we were in compliance with all covenant requirements.
  (was, 2014-10-20, similarity 0.9299):
[0001069202-14-000008:note_history:24]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2014, we were in compliance with all covenant requirements.

- changed (2015-04-20):
[0001069202-15-000006:note_history:25]
Domestic Credit Facility
  (was, 2014-10-20, similarity 0.8276):
[0001069202-14-000008:note_history:25]
Domestic Revolving Credit Facility

- added (2015-04-20):
[0001069202-15-000006:note_history:26]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consists of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our $950.0 million Domestic Credit Facility, we had outstanding borrowings of $683.5 million as well as $27.2 million committed to standby letters of credit as of March 31, 2015. Subject to covenant limitations, $239.3 million was available for future borrowings. The unsecured $300 million term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million beginning on June 30, 2015. The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2015-04-20):
[0001069202-15-000006:note_history:27]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.66 | % |  | 1.88 | % |
  (was, 2014-10-20, similarity 0.95):
[0001069202-14-000008:note_history:27]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.38 | % |  | 1.17 | % |

- changed (2015-04-20):
[0001069202-15-000006:note_history:28]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net
  (was, 2014-10-20, similarity 0.8869):
[0001069202-14-000008:note_history:28]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

- added (2015-04-20):
[0001069202-15-000006:note_history:29]
Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

- changed (2015-04-20):
[0001069202-15-000006:note_history:30]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:
  (was, 2014-10-20, similarity 0.9732):
[0001069202-14-000008:note_history:30]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Revolving Credit Facility could occur if:

- changed (2015-04-20):
[0001069202-15-000006:note_history:31]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2015, we were in compliance with all covenant requirements.
  (was, 2014-10-20, similarity 0.9149):
[0001069202-14-000008:note_history:31]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2014, we were in compliance with all covenant requirements.

- changed (2015-04-20):
[0001069202-15-000006:note_history:32]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2015, we were in compliance with all covenant requirements.
  (was, 2014-10-20, similarity 0.9886):
[0001069202-14-000008:note_history:32]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2014, we were in compliance with all covenant requirements.

- removed (2015-04-20):
[0001069202-14-000008:note_history:33]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 9.0 |  |  | 5.9 |  |
| Total short-term debt | $ | 229.0 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 149.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 365.7 |  |  | $ | 233.2 |  |
| Total debt | $ | 596.0 |  |  | $ | 400.4 |  |

- removed (2015-04-20):
[0001069202-14-000008:note_history:34]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 220.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

- removed (2015-04-20):
[0001069202-14-000008:note_history:35]
Under our $650.0 million Domestic Revolving Credit Facility, we had outstanding borrowings of $149.0 million as well as $27.2 million committed to standby letters of credit as of September 30, 2014. Subject to covenant limitations, $473.8 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-04-20):
[0001069202-15-000006:note_history:36]
|  | As of March 31, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 5.3 |  |  | 6.6 |  |
| Total short-term debt | $ | 185.3 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.5 |  |  | $ | 1.5 |  |
| Domestic credit facility | $ | 30.0 |  |  | $ | 22.5 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.5 |  |  | $ | 15.5 |  |
| Domestic credit facility | 653.5 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 869.0 |  |  | $ | 675.0 |  |
| Total debt | $ | 1,085.8 |  |  | $ | 925.6 |  |

- removed (2015-04-20):
[0001069202-14-000008:note_history:37]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 9.0 |  |  | 5.9 |  |
| Total short-term debt | $ | 229.0 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 149.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 365.7 |  |  | $ | 233.2 |  |
| Total debt | $ | 596.0 |  |  | $ | 400.4 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-04-20):
[0001069202-14-000008:note_history:38]
17. Subsequent Events:

- removed (2015-04-20):
[0001069202-14-000008:note_history:39]
On October 17, 2014, our Board of Directors authorized an additional $700.0 million towards our Share Repurchase Plans.  This is in addition to the amounts set forth in Note 10 and results in a total of $845.9 million that may be used, subject to certain conditions, under the Share Repurchase Plans.  On October 20, 2014, we announced our plans for a new $450.0 million accelerated share repurchase program in October, 2014.

- removed (2015-04-20):
[0001069202-14-000008:note_history:40]
On October 20, 2014, the Company entered into a short term loan agreement (the “Short-Term Facility”) with JPMorgan Chase Bank, N.A. and Morgan Stanley Bank, N.A. to borrow, subject to the satisfaction of specified conditions, up to $250.0 million.  The Short-Term Facility is guaranteed by the same subsidiaries as our Domestic Revolving Credit Facility, and contains substantially similar financial and other covenants as described in Note 7.  The Short-Term Facility will become due on March 31, 2015, and allows for pre-payment. The Company intends to use the borrowings under the Short-Term Facility, along with borrowings under the Domestic Revolving Credit Facility, to fund the expected $450.0 million accelerated share repurchase program.
