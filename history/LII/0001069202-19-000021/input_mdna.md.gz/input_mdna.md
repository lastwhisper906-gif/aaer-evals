# LII MD&A — 0001069202-19-000021


## mdna

[0001069202-19-000021:mdna:1]
[same as prior period, unchanged from 0001069202-18-000020:mdna:1]

[0001069202-19-000021:mdna:2]
[same as prior period, unchanged from 0001069202-18-000020:mdna:2]

[0001069202-19-000021:mdna:3]
[same as prior period, unchanged from 0001069202-18-000020:mdna:3]

[0001069202-19-000021:mdna:4]
[same as prior period, unchanged from 0001069202-18-000020:mdna:4]

[0001069202-19-000021:mdna:5]
[same as prior period, unchanged from 0001069202-18-000020:mdna:5]

[0001069202-19-000021:mdna:6]
[same as prior period, unchanged from 0001069202-18-000020:mdna:6]

[0001069202-19-000021:mdna:7]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.  In the first quarter of 2019, we incurred expenses of $30 million

[0001069202-19-000021:mdna:8]
related to damages caused by the tornado, which included site clean-up and demolition, factory inefficiencies, freight to move product to other warehouses and sales and marketing promotional costs.  We received insurance recoveries of $76 million in the first quarter of 2019 and allocated the first $36 million of these proceeds to cover our expenses and rebuilding costs incurred during the three months ended March 31, 2019, which is included in Gain from insurance recoveries, net of losses incurred in the Consolidated Statements of Operations.  The remaining $40 million of insurance recoveries represents amounts for lost profits and is shown in Insurance proceeds for lost profits in the Consolidated Statements of Operations.  For the year ended December 31, 2019, we expect to receive insurance proceeds of $80 million related to lost profits and $154 million to fund the reconstruction of the facility and as reimbursement for other losses and expenses expected to be incurred. We ultimately expect to receive a cumulative total of $107 million in insurance proceeds related to lost profits and a cumulative total of $251 million to fund the reconstruction of the facility and as reimbursement for other losses and expenses expected to be incurred.

[0001069202-19-000021:mdna:9]
[same as prior period, unchanged from 0001069202-18-000020:mdna:9]

[0001069202-19-000021:mdna:10]
The Residential Heating & Cooling segment performed well in the first quarter of 2019, with a 3% increase in net sales and a $35 million increase in segment profit, including the impact of insurance proceeds received for lost profits, compared to the first quarter of 2019.  Our Commercial Heating & Cooling segment had a 3% decrease in net sales and a $7 million decrease in segment profit compared to the first quarter of 2018.  This segment's results were driven by lower volumes and higher product costs partially offset by higher price and mix.  Sales in our Refrigeration segment decreased by 25% due to the sale of our Australia, New Zealand, Asia and South America businesses in the second and third quarters of 2018.  The Refrigeration segment profit in the current quarter was flat compared to the first quarter of 2018.

[0001069202-19-000021:mdna:11]
[same as prior period, unchanged from 0001069202-18-000020:mdna:11]

[0001069202-19-000021:mdna:12]
| • | Net sales decreased $45 million, or 5%, to $790 million in the first quarter of 2019 primarily due to the sale of our Australia, New Zealand, Asia and Brazil businesses in the second and third quarters of 2018. |

[0001069202-19-000021:mdna:13]
| • | Operating income in the first quarter of 2019 increased $42 million to $95 million, including $40 million of insurance proceeds for lost profits. |

[0001069202-19-000021:mdna:14]
| • | Net income for the first quarter of 2019 increased $31 million to $69 million. |

[0001069202-19-000021:mdna:15]
| • | Diluted earnings per share from continuing operations were $1.73 per share in the first quarter of 2019 compared to $0.90 per share in the first quarter of 2018. |

[0001069202-19-000021:mdna:16]
| • | During the three months ended March 31, 2019, we returned $26 million to shareholders through dividend payments and have repurchased $100 million of common stock. We also received $44 million in net proceeds from the sale of our Kysor Warren business. |

[0001069202-19-000021:mdna:17]
First Quarter of 2019 Compared to First Quarter of 2018 - Consolidated Results

[0001069202-19-000021:mdna:18]
[same as prior period, unchanged from 0001069202-18-000020:mdna:18]

[0001069202-19-000021:mdna:19]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 790.3 |  |  | $ | 834.8 |  |  | (5.3 | )% |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 588.7 |  |  | 611.6 |  |  | 3.7 |  |  | 74.5 |  |  | 73.3 |  |
| Gross profit | 201.6 |  |  | 223.2 |  |  | (9.7 | ) |  | 25.5 |  |  | 26.7 |  |
| Selling, general and administrative expenses | 145.8 |  |  | 155.2 |  |  | 6.1 |  |  | 18.4 |  |  | 18.6 |  |
| Losses (gains) and other expenses, net | 1.1 |  |  | 7.3 |  |  | 84.9 |  |  | 0.1 |  |  | 0.9 |  |
| Restructuring charges | 0.5 |  |  | 0.9 |  |  | 44.4 |  |  | 0.1 |  |  | 0.1 |  |
| Loss on sale of business | 8.5 |  |  | — |  |  | N/A |  | 1.1 |  |  | — |  |
| Loss on assets held for sale | — |  |  | 10.3 |  |  | N/A |  | — |  |  | 1.2 |  |
| Insurance proceeds for lost profits | (39.5 | ) |  | — |  |  | N/A |  | (5.0 | ) |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (6.9 | ) |  | — |  |  | N/A |  | (0.9 | ) |  | — |  |
| Income from equity method investments | (2.6 | ) |  | (3.5 | ) |  | (25.7 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Operating income | $ | 94.7 |  |  | $ | 53.0 |  |  | 78.7 | % |  | 12.0 | % |  | 6.3 | % |

[0001069202-19-000021:mdna:20]
31

[0001069202-19-000021:mdna:21]
[same as prior period, unchanged from 0001069202-18-000020:mdna:20]

[0001069202-19-000021:mdna:22]
Net sales decreased 5% in the first quarter of 2019 compared to the first quarter of 2018, of which 6% was related to our divested businesses in Australia, New Zealand, Asia and South America and 1% from unfavorable foreign currency exchange rates, partially offset by 2% from favorable price and mix across all of our segments.

[0001069202-19-000021:mdna:23]
[same as prior period, unchanged from 0001069202-18-000020:mdna:23]

[0001069202-19-000021:mdna:24]
Gross profit margin in the first quarter of 2019 decreased to 25.5% compared to 26.7% in the first quarter of 2018.  We saw decreases in profit margin of 120 basis points ("bps") from higher commodity prices, 140 bps from higher freight and distribution costs, and 80 bps from other product costs.  Partially offsetting these decreases were positive margin increases of 150 bps from favorable price and mix and 70 bps from sourcing and engineering-led cost reductions.

[0001069202-19-000021:mdna:25]
[same as prior period, unchanged from 0001069202-18-000020:mdna:25]

[0001069202-19-000021:mdna:26]
Selling, general and administrative expenses, or SG&A, was $146 million in the first quarter of 2019 compared to $155 million in the first quarter of 2018, and as a percentage of net sales decreased 20 bps to 18.4%.  SG&A decreased primarily due to the sale of our divested businesses in Australia, New Zealand, Asia and South America.

[0001069202-19-000021:mdna:27]
Losses (gains) and Other Expenses, Net

[0001069202-19-000021:mdna:28]
Losses (gains) and other expenses, net for the first quarter of 2019 and 2018 included the following (in millions):

[0001069202-19-000021:mdna:29]
|  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | (0.5 | ) |
| Foreign currency exchange losses (gains) | (0.5 | ) |  | 1.3 |  |
| Loss on disposal of fixed assets | 0.2 |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (0.4 | ) |  | 1.1 |  |
| Special legal contingency charges | 0.2 |  |  | 0.2 |  |
| Asbestos-related litigation | 1.4 |  |  | 2.1 |  |
| Environmental liabilities | — |  |  | 0.3 |  |
| Divestiture costs | — |  |  | 2.5 |  |
| Other items, net | 0.1 |  |  | 0.3 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 1.1 |  |  | $ | 7.3 |  |

[0001069202-19-000021:mdna:30]
The net change in unrealized losses (gains) on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 14 in the Notes to the Consolidated Financial Statements for more information on the divestiture costs.

[0001069202-19-000021:mdna:31]
[same as prior period, unchanged from 0001069202-18-000020:mdna:31]

[0001069202-19-000021:mdna:32]
Restructuring charges were $0.5 million in the first quarter of 2019 and were primarily for projects to realign resources in our Refrigeration segment.  For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000021:mdna:33]
Loss on Sale of Businesses

[0001069202-19-000021:mdna:34]
We recognized a loss of $8.5 million on the sale of our Kysor Warren business in the first quarter of 2019.  Refer to Note 14 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-19-000021:mdna:35]
[same as prior period, unchanged from 0001069202-18-000020:mdna:33]

[0001069202-19-000021:mdna:36]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $3 million in the first quarter of 2019 was down from $4 million when compared to the first quarter of 2018.  The decrease is because the joint ventures have experienced increased costs related to commodities and components and have not passed along these increased costs to customers through price increases.

[0001069202-19-000021:mdna:37]
[same as prior period, unchanged from 0001069202-18-000020:mdna:35]

[0001069202-19-000021:mdna:38]
Interest expense, net of $11 million in the first quarter of 2019 was up from $8 million in the first quarter of 2018 due to an increase in our average net borrowings.

[0001069202-19-000021:mdna:39]
[same as prior period, unchanged from 0001069202-18-000020:mdna:37]

[0001069202-19-000021:mdna:40]
Our effective tax rate was 16.4% for the three months ended March 31, 2019 compared to 13.9% for the three months ended March 31, 2018.  The rate for the three months ended March 31, 2019 is higher as compared to the three months ended March 31, 2018 primarily due to lower excess tax benefits from share-based compensation as a percentage of pre-tax income.  We expect our annual effective tax rate to be between 22% and 23%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001069202-19-000021:mdna:41]
First Quarter of 2019 Compared to First Quarter of 2018 - Results by Segment

[0001069202-19-000021:mdna:42]
[same as prior period, unchanged from 0001069202-18-000020:mdna:41]

[0001069202-19-000021:mdna:43]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000021:mdna:44]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 465.6 |  |  | $ | 453.7 |  |  | $ | 11.9 |  |  | 2.6 | % |
| Profit | $ | 86.7 |  |  | $ | 51.3 |  |  | $ | 35.4 |  |  | 69.0 | % |
| % of net sales | 18.6 | % |  | 11.3 | % |  |  |  |  |

[0001069202-19-000021:mdna:45]
Net sales increased 3% in the first quarter of 2019 compared to the first quarter of 2018 on higher combined price and mix.

[0001069202-19-000021:mdna:46]
Segment profit in the first quarter of 2019 increased $35 million compared to the first quarter of 2018 due to $40 million of insurance proceeds for lost profits due to the Marshalltown tornado, $12 million from higher price and mix combined, and $4 million from sourcing and engineering-led cost reductions.  Partially offsetting these increases were $9 million from higher freight and costs associated with distribution investments, $7 million from higher commodity costs, $3 million of higher SG&A expenses and $2 million from higher warranty costs.

[0001069202-19-000021:mdna:47]
[same as prior period, unchanged from 0001069202-18-000020:mdna:46]

[0001069202-19-000021:mdna:48]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000021:mdna:49]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 173.3 |  |  | $ | 179.1 |  |  | $ | (5.8 | ) |  | (3.2 | )% |
| Profit | $ | 15.1 |  |  | $ | 22.0 |  |  | $ | (6.9 | ) |  | (31.4 | )% |
| % of net sales | 8.7 | % |  | 12.3 | % |  |  |  |  |

[0001069202-19-000021:mdna:50]
Net sales decreased 3% in the first quarter of 2019 compared to the first quarter of 2018.  Sales volume was lower by 6%, partially offset by 3% higher price and mix combined.

[0001069202-19-000021:mdna:51]
Segment profit in the first quarter of 2019 decreased $7 million compared to the first quarter of 2018. The decrease was driven by $4 million from lower sales volume, $4 million of higher other product costs, $2 million of higher commodity costs, $2 million of lower factory productivity, $1 million of higher freight and distribution expense, and $1 million of higher SG&A expense.  Partially offsetting these decreases was $7 million of higher price and mix combined.

[0001069202-19-000021:mdna:52]
[same as prior period, unchanged from 0001069202-18-000020:mdna:52]

[0001069202-19-000021:mdna:53]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000021:mdna:54]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 151.4 |  |  | $ | 202.0 |  |  | $ | (50.6 | ) |  | (25.0 | )% |
| Profit | $ | 8.4 |  |  | $ | 8.7 |  |  | $ | (0.3 | ) |  | (3.4 | )% |
| % of net sales | 5.5 | % |  | 4.3 | % |  |  |  |  |

[0001069202-19-000021:mdna:55]
Net sales decreased 25% in the first quarter of 2019 compared to the first quarter of 2018.  The loss of sales from the divested Australia, New Zealand, Asia and South America businesses contributed 24% and unfavorable foreign currency exchange rates contributed 2%, partially offset by 1% higher price and mix combined.

[0001069202-19-000021:mdna:56]
Segment profit in the first quarter of 2019 was flat compared to the first quarter of 2018 due to $3 million of sourcing and engineering-led cost reductions, $2 million from higher price and mix combined, and $1 million of higher factory productivity, offset by $2 million lower profit due to the divested Australia, Asia and South America businesses, $2 million from higher commodity costs, $1 million of higher freight and distribution expense, and $1 million of higher SG&A expense.

[0001069202-19-000021:mdna:57]
[same as prior period, unchanged from 0001069202-18-000020:mdna:57]

[0001069202-19-000021:mdna:58]
Corporate and other expenses increased $1 million in the first quarter of 2019 compared to the first quarter of 2018 primarily due to the timing of information technology investments.

[0001069202-19-000021:mdna:59]
[same as prior period, unchanged from 0001069202-18-000020:mdna:101]

[0001069202-19-000021:mdna:60]
[same as prior period, unchanged from 0001069202-18-000020:mdna:102]

[0001069202-19-000021:mdna:61]
[same as prior period, unchanged from 0001069202-18-000020:mdna:103]

[0001069202-19-000021:mdna:62]
The following table summarizes our cash flow activity for the three months ended March 31, 2019 and 2018 (in millions):

[0001069202-19-000021:mdna:63]
|  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |
| Net cash used in operating activities | $ | (141.0 | ) |  | $ | (83.5 | ) |
| Net cash provided by (used in) investing activities | 13.6 |  |  | (22.6 | ) |
| Net cash provided by financing activities | 108.9 |  |  | 96.0 |  |

[0001069202-19-000021:mdna:64]
Net Cash Provided by Operating Activities - The net cash used in operating activities in the first three months of 2019 and 2018 reflects the seasonal increase in working capital requirements. The increase in cash used in operating activities in the first three months of 2019 as compared to 2018 was mainly due to the timing of working capital payments and due in part by the supply disruption caused by the tornado at our Marshalltown facility.

[0001069202-19-000021:mdna:65]
Net Cash Provided by (Used in) Investing Activities - Capital expenditures were $37 million in the first three months of 2019 compared to $23 million in the first three months of 2018.  Capital expenditures in 2019 were primarily related to the reconstruction of the Marshalltown facility as well as equipment and investments in systems and software to support the overall enterprise.  Net proceeds of $44 million in the first quarter of 2019 were provided by the sale of our Kysor Warren business. We also received $7 million in insurance proceeds to fund the reconstruction of our Marshalltown facility.

[0001069202-19-000021:mdna:66]
Net Cash Provided by Financing Activities - Net cash provided by financing activities in the first three months of 2019 was $109 million as compared to $96 million in the first three months of 2018.  The increase in cash provided by financing activities is largely due to a reduction in the amount of share repurchases in the first quarter of 2019 compared to the first quarter of 2018, partially offset by higher payments, net of borrowings, on our revolving credit facility.  During the first three months of 2019, we repurchased $100 million of shares as compared to $150 million of shares in the first three months of 2018.  We also we returned $26 million to shareholders through dividend payments in the first three months of 2019. For additional information on share repurchases, refer to Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000021:mdna:67]
[same as prior period, unchanged from 0001069202-18-000020:mdna:110]

[0001069202-19-000021:mdna:68]
The following table details our lines of credit and financing arrangements as of March 31, 2019 (in millions):

[0001069202-19-000021:mdna:69]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset Securitization Program | $ | 224.5 |  |
| Capital lease obligations | $ | 6.3 |  |
| Domestic credit facility(1) | 7.5 |  |
| Debt issuance costs | (0.7 | ) |
| Total current maturities of long-term debt | $ | 237.6 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | — |  |
| Capital lease obligations | 22.3 |  |
| Domestic credit facility(1) | 689.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (2.8 | ) |
| Total long-term debt | 1,059.0 |  |
| Total debt | $ | 1,296.6 |  |

[0001069202-19-000021:mdna:70]
(1) The available future borrowings on our domestic credit facility are $460.5 million after being reduced by the outstanding borrowings and $2.5 million in outstanding standby letters of credit.  We also had $30.7 million in outstanding standby letters of credit outside of the domestic credit facility as of March 31, 2019.

[0001069202-19-000021:mdna:71]
[same as prior period, unchanged from 0001069202-18-000020:mdna:114]

[0001069202-19-000021:mdna:72]
[same as prior period, unchanged from 0001069202-18-000020:mdna:115]

[0001069202-19-000021:mdna:73]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 118.7% at March 31, 2019 from 116.8% at December 31, 2018.

[0001069202-19-000021:mdna:74]
As of March 31, 2019, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-19-000021:mdna:75]
[same as prior period, unchanged from 0001069202-18-000020:mdna:118]

[0001069202-19-000021:mdna:76]
We believe our cash and cash equivalents of $32 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $32 million as of March 31, 2019 was $16.6 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-19-000021:mdna:77]
Our expected capital expenditures for 2019 are $100 million, excluding capital expenditures made in conjunction with repair of our Marshalltown facility as those repairs will be covered by insurance.  We also continue to increase shareholder value through our share repurchase programs and dividend payments, with the completion of $100 million of share repurchases in the first three months of 2019 and the declaration of $26 million of cash dividends in the first three months of 2019.

[0001069202-19-000021:mdna:78]
[same as prior period, unchanged from 0001069202-18-000020:mdna:122]

[0001069202-19-000021:mdna:79]
An off-balance sheet arrangement is any transaction, agreement or other contractual arrangement involving an unconsolidated entity under which the company has: (1) made guarantees, (2) a retained or a contingent interest in transferred assets, (3) an obligation under derivative instruments classified as equity or (4) any obligation arising out of a material variable interest in an unconsolidated entity that provides financing, liquidity, market risk or credit risk support to us, or that engages in leasing, hedging or research and development arrangements with us.  We have no off-balance sheet arrangements that we believe may have a material current or future effect on our financial condition, liquidity or results of operations.

[0001069202-19-000021:mdna:80]
Commitments, Contingencies and Guarantees

[0001069202-19-000021:mdna:81]
For information regarding our commitments, contingencies and guarantees, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000021:mdna:82]
[same as prior period, unchanged from 0001069202-18-000020:mdna:126]

[0001069202-19-000021:mdna:83]
[same as prior period, unchanged from 0001069202-18-000020:mdna:127]
