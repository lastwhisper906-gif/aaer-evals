# LII notes — 0001069202-19-000021


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-19-000021:notes:1]
[same as prior period, unchanged from 0001069202-18-000020:notes:156]

[0001069202-19-000021:notes:2]
[same as prior period, unchanged from 0001069202-18-000020:notes:157]

[0001069202-19-000021:notes:3]
Basis of Presentation

[0001069202-19-000021:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2019, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2019 and 2018, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2019 and 2018, the accompanying unaudited Consolidated Statements of Stockholders' (Deficit) Equity for the three months ended March 31, 2019 and 2018, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2019 and 2018 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2018. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-19-000021:notes:5]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls.

[0001069202-19-000021:notes:6]
[same as prior period, unchanged from 0001069202-18-000020:notes:158]

[0001069202-19-000021:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-19-000021:notes:8]
[same as prior period, unchanged from 0001069202-18-000020:notes:160]

[0001069202-19-000021:notes:9]
[same as prior period, unchanged from 0001069202-18-000020:notes:161]

[0001069202-19-000021:notes:10]
[same as prior period, unchanged from 0001069202-18-000020:notes:162]

[0001069202-19-000021:notes:11]
Recently Adopted Accounting Guidance

[0001069202-19-000021:notes:12]
In August 2018, the SEC issued Release No. 33-10532 that amends and clarifies certain financial reporting requirements.  The principal change to our financial reporting is the inclusion of the annual disclosure requirement of changes in stockholders’ equity in Rule 3-04 of Regulation S-X to interim periods.

[0001069202-19-000021:notes:13]
We also adopted other new accounting standards during the first quarter of 2019. The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-19-000021:notes:14]
[same as prior period, unchanged from 0001069202-18-000020:notes:196]

[0001069202-19-000021:notes:15]
[same as prior period, unchanged from 0001069202-18-000020:notes:203]

[0001069202-19-000021:notes:16]
|  | For the Three Months Ended March 31, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 433.2 |  |  | $ | 157.3 |  |  | $ | 91.6 |  |  | $ | 682.1 |  |
| Canada | 32.4 |  |  | 15.9 |  |  | 0.7 |  |  | 49.0 |  |
| International | — |  |  | 0.1 |  |  | 59.1 |  |  | 59.2 |  |
| Total | $ | 465.6 |  |  | 173.3 |  |  | 151.4 |  |  | 790.3 |  |

[0001069202-19-000021:notes:17]
|  | For the Three Months Ended March 31, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 423.5 |  |  | $ | 162.3 |  |  | $ | 95.7 |  |  | $ | 681.5 |  |
| Canada | 30.2 |  |  | 16.7 |  |  | 0.9 |  |  | 47.8 |  |
| International | — |  |  | 0.1 |  |  | 105.4 |  |  | 105.5 |  |
| Total | $ | 453.7 |  |  | 179.1 |  |  | 202.0 |  |  | 834.8 |  |

[0001069202-19-000021:notes:18]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the segment, for the three months ended March 31, 2019 and 2018, direct sales represent approximately $334.7 million and $339.5 million of revenues, and sales to independent distributors represent approximately $130.9 million and $114.2 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-19-000021:notes:19]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.    For the segment, for the three months ended March 31, 2019 and 2018, equipment sales represent approximately $143.5 million and $151.5 million of revenues while $29.8 million and $27.6 million of our revenue is generated from our service business, respectively.

[0001069202-19-000021:notes:20]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems.  Revenue for the products sold is $148.9 million and $200.0 million for the three months ended March 31, 2019 and 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

[0001069202-19-000021:notes:21]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or

[0001069202-19-000021:notes:22]
services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001069202-19-000021:notes:23]
[same as prior period, unchanged from 0001069202-18-000020:notes:212]

[0001069202-19-000021:notes:24]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets, net in our Consolidated Balance Sheet.

[0001069202-19-000021:notes:25]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheet.

[0001069202-19-000021:notes:26]
Net contract assets (liabilities) consisted of the following:

[0001069202-19-000021:notes:27]
|  | March 31, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (5.4 | ) |  | (13.0 | ) |  | 7.6 |  |  | (58.5 | )% |
| Contract liabilities - noncurrent | (5.7 | ) |  | (5.9 | ) |  | 0.2 |  |  | (3.4 | )% |
| Total | $ | (11.1 | ) |  | $ | (16.4 | ) |  | $ | 5.3 |  |  |  |

[0001069202-19-000021:notes:28]
For the three months ended March 31, 2019 and 2018, we recognized revenue of $1.1 million and $1.6 million related to our contract liabilities at January 1, 2019 and  2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the first quarter of 2019 and 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-19-000021:notes:29]
[same as prior period, unchanged from 0001069202-18-000020:notes:151]

[0001069202-19-000021:notes:30]
[same as prior period, unchanged from 0001069202-18-000020:notes:152]

[0001069202-19-000021:notes:31]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Finished goods | $ | 429.2 |  |  | $ | 330.5 |  |
| Work in process | 5.4 |  |  | 10.0 |  |
| Raw materials and parts | 225.3 |  |  | 229.1 |  |
| Subtotal | 659.9 |  |  | 569.6 |  |
| Excess of current cost over last-in, first-out cost | (59.8 | ) |  | (59.8 | ) |
| Total inventories, net | $ | 600.1 |  |  | $ | 509.8 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-19-000021:notes:32]
Goodwill:
The changes in the carrying amount of goodwill for the first three months of 2019, in total and by segment, are summarized in the table below (in millions):

[0001069202-19-000021:notes:33]
|  | Balance at December 31, 2018 |  | Goodwill Reallocation (1) |  | Changes in foreign currency translation rates |  | Balance at March 31, 2019 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.4 |  |  | (0.3 | ) |  | — |  |  | 61.1 |  |
| Refrigeration | 99.1 |  |  | 0.3 |  |  | (0.1 | ) |  | 99.3 |  |
| Total Goodwill | $ | 186.6 |  |  | $ | — |  |  | $ | (0.1 | ) |  | $ | 186.5 |  |

[0001069202-19-000021:notes:34]
(1) In 2019, we reorganized our external financial reporting structure by moving our European Commercial HVAC business from our Commercial segment to our Refrigeration segment as we will manage both our commercial HVAC and refrigeration operations in Europe together. See Note 16 for additional information.

[0001069202-19-000021:notes:35]
We perform our annual goodwill impairment test in the fourth quarter of each year.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-19-000021:notes:36]
[same as prior period, unchanged from 0001069202-18-000020:notes:75]

[0001069202-19-000021:notes:37]
[same as prior period, unchanged from 0001069202-18-000020:notes:76]

[0001069202-19-000021:notes:38]
Commodity Price Risk - We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term and lower percentages are hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-19-000021:notes:39]
[same as prior period, unchanged from 0001069202-18-000020:notes:78]

[0001069202-19-000021:notes:40]
[same as prior period, unchanged from 0001069202-18-000020:notes:79]

[0001069202-19-000021:notes:41]
[same as prior period, unchanged from 0001069202-18-000020:notes:81]

[0001069202-19-000021:notes:42]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through January 2020 and August 2020, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-19-000021:notes:43]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Unrealized losses on unsettled contracts | $ | — |  |  | $ | 8.4 |  |
| Income tax benefit | — |  |  | (2.2 | ) |
| Losses (gains) included in AOCL, net of tax (1) | $ | — |  |  | $ | 6.2 |  |

[0001069202-19-000021:notes:44]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $1.2 million of derivative losses into earnings within the next 12 months.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-19-000021:notes:45]
[same as prior period, unchanged from 0001069202-18-000020:notes:142]

[0001069202-19-000021:notes:46]
As of March 31, 2019, we had no unrecognized tax benefits.

[0001069202-19-000021:notes:47]
We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2018 and are subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2011.

[0001069202-19-000021:notes:48]
Since January 1, 2019, several states have enacted legislation effective for tax years beginning on or after January 1, 2019, including changes to tax rates and apportionment methods.  The impact of these changes is immaterial.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-19-000021:notes:49]
Commitments and Contingencies:

[0001069202-19-000021:notes:50]
Leases

[0001069202-19-000021:notes:51]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). We adopted ASC 842 on January 1, 2019, using the effective date method, with the cumulative-effect adjustment to the opening balance sheet of retained earnings as of the effective date. The financial results reported in periods prior to January 1, 2019 are unchanged.  Upon adoption, we recognized almost all of our leases greater than one year in duration on the balance sheet as right-of-use assets and lease liabilities. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification is based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines. We have made certain assumptions in judgments when applying ASC 842.  Those judgments of most significance are as follows:

[0001069202-19-000021:notes:52]
| • | We elected the package of practical expedients available for transition which allow us to not reassess: |

[0001069202-19-000021:notes:53]
| ◦ | Whether expired or existing contracts contain leases under the new definition of a lease; |

[0001069202-19-000021:notes:54]
| ◦ | Lease classification for expired or existing leases; and |

[0001069202-19-000021:notes:55]
| ◦ | Whether previously capitalized initial direct costs would qualify for capitalization under ASC 842. |

[0001069202-19-000021:notes:56]
| • | We did not elect to use hindsight for transition when considering judgments and estimates such as assessments of lessee options to extend or terminate a lease or purchase the underlying asset. |

[0001069202-19-000021:notes:57]
| • | We did not elect to reassess whether land easements meet the definition of a lease if they were not accounted for as leases under the former rules. |

[0001069202-19-000021:notes:58]
| • | For all asset classes, we elected to not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. |

[0001069202-19-000021:notes:59]
| • | For all asset classes, we elected to not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component. |

[0001069202-19-000021:notes:60]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheet as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheet. Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

[0001069202-19-000021:notes:61]
Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-19-000021:notes:62]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-19-000021:notes:63]
We lease certain real and personal property under non-cancelable operating leases.  Approximately 80% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-19-000021:notes:64]
The components of lease expense were as follows (in millions):

[0001069202-19-000021:notes:65]
|  | For the Three Months Ended March 31, 2019 |
| Finance lease cost: |  |
| Amortization of right-of-use assets | $ | 1.5 |  |
| Interest on lease liabilities | 0.2 |  |
| Operating lease cost | 14.8 |  |
| Short-term lease cost | 1.1 |  |
| Variable lease cost | 4.5 |  |
| Total lease cost | $ | 22.1 |  |
| Other information |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |
| Operating cash flows from finance leases | $ | 1.0 |  |
| Operating cash flows from operating leases | $ | 12.7 |  |
| Financing cash flows from finance leases | $ | 1.6 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 3.2 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 16.6 |  |

[0001069202-19-000021:notes:66]
|  | As of March 31, 2019 |
| Finance lease right-of-use assets | 22.7 |  |
| Operating lease right-of-use assets | 170.1 |  |
| Finance lease liability, current | 6.3 |  |
| Finance lease liability, non-current | 22.3 |  |
| Operating lease liability, current | 48.1 |  |
| Operating lease liability, non-current | 122.6 |  |
| Weighted-average remaining lease term - finance leases | 5.46 years |  |
| Weighted-average remaining lease term - operating leases | 4.37 years |  |
| Weighted-average discount rate - finance leases | 2.23 | % |
| Weighted-average discount rate – operating leases | 4.05 | % |

[0001069202-19-000021:notes:67]
Future annual minimum lease payments and capital lease commitments as of March 31, 2019 were as follows (in millions):

[0001069202-19-000021:notes:68]
|  | Operating Leases |  | Finance Leases |
| 2019 (excluding the three months ended March 31, 2019) | $ | 41.5 |  |  | $ | 5.5 |  |
| 2020 | 48.4 |  |  | 6.3 |  |
| 2021 | 35.7 |  |  | 4.5 |  |
| 2022 | 24.5 |  |  | 2.7 |  |
| 2023 | 18.7 |  |  | 1.3 |  |
| 2024 and thereafter | 18.6 |  |  | 12.9 |  |
| Total minimum lease payments | $ | 187.4 |  |  | $ | 33.2 |  |
| Less imputed interest | (16.7 | ) |  | (4.6 | ) |
| Lease liability | $ | 170.7 |  |  | $ | 28.6 |  |

[0001069202-19-000021:notes:69]
The Company adopted ASU 2016-02 on January 1, 2019 as noted above, and as required, the following disclosure is provided for periods prior to adoption. Future annual minimum lease payments and capital lease commitments as of December 31, 2018 were as follows (in millions):

[0001069202-19-000021:notes:70]
|  | Operating Leases |  | Capital Leases |
| 2019 | $ | 47.4 |  |  | $ | 6.6 |  |
| 2020 | 38.4 |  |  | 5.4 |  |
| 2021 | 27.2 |  |  | 3.8 |  |
| 2022 | 17.9 |  |  | 2.1 |  |
| 2023 | 12.7 |  |  | 0.9 |  |
| Thereafter | 16.1 |  |  | 12.8 |  |
| Total minimum lease payments | $ | 159.7 |  |  | $ | 31.6 |  |
| Less amount representing interest |  |  | 2.1 |  |
| Present value of minimum payments |  |  | $ | 29.5 |  |

[0001069202-19-000021:notes:71]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024. The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, we are obligated to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance of $41.2 million, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 87% of the lease balance.  The headquarters lease is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-19-000021:notes:72]
Our obligations under the headquarters lease are secured by a pledge of our interest in the leased property.  The lease contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of March 31, 2019.

[0001069202-19-000021:notes:73]
Product Warranties and Product Related Contingencies

[0001069202-19-000021:notes:74]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-19-000021:notes:75]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000021:notes:76]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Accrued expenses | $ | 37.4 |  |  | $ | 37.9 |  |
| Other liabilities | 76.4 |  |  | 73.7 |  |
| Total warranty liability | $ | 113.8 |  |  | $ | 111.6 |  |

[0001069202-19-000021:notes:77]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2019 were as follows (in millions):

[0001069202-19-000021:notes:78]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Warranty claims paid | (5.9 | ) |
| Changes resulting from issuance of new warranties | 8.7 |  |
| Warranty liability from divestitures | (0.6 | ) |
| Total warranty liability as of March 31, 2019 | $ | 113.8 |  |

[0001069202-19-000021:notes:79]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

[0001069202-19-000021:notes:80]
Litigation

[0001069202-19-000021:notes:81]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-19-000021:notes:82]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2019 and 2018, expense for asbestos-related litigation was $1.4 million and $2.1 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

[0001069202-19-000021:notes:83]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.

[0001069202-19-000021:notes:84]
Marshalltown Tornado and Recovery

[0001069202-19-000021:notes:85]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  We have insurance for the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Gain from insurance recoveries, net of losses incurred and Insurance proceeds for lost profits in the Consolidated Statements of Operations.

[0001069202-19-000021:notes:86]
The following table summarizes the Gain from insurance recoveries, net of losses incurred:

[0001069202-19-000021:notes:87]
| (Amounts in millions) | For the Three months Ended March 31, 2019 |
| Insurance recoveries received | $ | 76.0 |  |
| Less losses and expenses incurred: |  |
| Site clean-up and remediation | 17.1 |  |
| Factory inefficiencies due to lower productivity | 4.0 |  |
| Other | 8.5 |  |
| Total losses and expenses | $ | 29.6 |  |
| Total gain from insurance recoveries | $ | 46.4 |  |
| Presentation in the Consolidated Statements of Operations: |  |
| Gain from insurance recoveries, net of losses incurred | $ | (6.9 | ) |
| Insurance proceeds for lost profits | $ | (39.5 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001069202-19-000021:notes:88]
Lines of Credit and Financing Arrangements:

[0001069202-19-000021:notes:89]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000021:notes:90]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 224.5 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.3 |  |  | $ | 3.5 |  |
| Domestic credit facility | 7.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.7 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 237.6 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 22.3 |  |  | 15.7 |  |
| Domestic credit facility | 689.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.8 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,059.0 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,296.6 |  |  | $ | 1,041.3 |  |

[0001069202-19-000021:notes:91]
Short-Term Debt

[0001069202-19-000021:notes:92]
Foreign Obligations

[0001069202-19-000021:notes:93]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2019 or December 31, 2018.  There were no proceeds or repayments on these facilities for the three months ended March 31, 2019.  Proceeds and repayments on these facilities were $0.3 million and $0.4 million, respectively, for the three months ended March 31, 2018.

[0001069202-19-000021:notes:94]
Asset Securitization Program

[0001069202-19-000021:notes:95]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.  The ASP will expire in November 2019 and we intend to renew the ASP prior to its expiration.

[0001069202-19-000021:notes:96]
The ASP provides for a maximum securitization amount ranging from $225.0 million to $380.0 million, depending on the period. The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-19-000021:notes:97]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 225.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (224.5 | ) |  | (268.0 | ) |
| Remaining amount available | $ | 0.5 |  |  | $ | 22.0 |  |

[0001069202-19-000021:notes:98]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2019 and December 31, 2018 were 3.26% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-19-000021:notes:99]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of March 31, 2019, we believe we were in compliance with all covenant requirements.

[0001069202-19-000021:notes:100]
Long-Term Debt

[0001069202-19-000021:notes:101]
Domestic Credit Facility

[0001069202-19-000021:notes:102]
On January 22, 2019, we amended our credit facility with the Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $190.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $697.0 million, of which $160.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of March 31, 2019. Subject to covenant limitations, $460.5 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

[0001069202-19-000021:notes:103]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-19-000021:notes:104]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.68 | % |  | 3.74 | % |

[0001069202-19-000021:notes:105]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-19-000021:notes:106]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-19-000021:notes:107]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-19-000021:notes:108]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-19-000021:notes:109]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-19-000021:notes:110]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-19-000021:notes:111]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due

[0001069202-19-000021:notes:112]
and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2019, we believe we were in compliance with all covenant requirements.

[0001069202-19-000021:notes:113]
Senior Unsecured Notes

[0001069202-19-000021:notes:114]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2019, we believe we were in compliance with all covenant requirements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-19-000021:notes:115]
[same as prior period, unchanged from 0001069202-18-000020:notes:167]

[0001069202-19-000021:notes:116]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other expense (income), net in the Statement of Operations. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We elected the practical expedient to use the prior year's disclosure as a basis for the retroactive adoption of the ASU.  The ASU did not have a material impact on our financial results.

[0001069202-19-000021:notes:117]
[same as prior period, unchanged from 0001069202-18-000020:notes:169]

[0001069202-19-000021:notes:118]
|  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |
|  | Pension Benefits |
| Service cost | $ | 1.2 |  |  | $ | 1.4 |  |
| Interest cost | 3.5 |  |  | 3.1 |  |
| Expected return on plan assets | (4.7 | ) |  | (4.7 | ) |
| Recognized actuarial loss | 2.0 |  |  | 2.3 |  |
| Net periodic benefit cost | $ | 2.0 |  |  | $ | 2.1 |  |

[0001069202-19-000021:notes:119]
[same as prior period, unchanged from 0001069202-18-000020:notes:172]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-19-000021:notes:120]
[same as prior period, unchanged from 0001069202-18-000020:notes:103]

[0001069202-19-000021:notes:121]
[same as prior period, unchanged from 0001069202-18-000020:notes:104]

[0001069202-19-000021:notes:122]
|  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |
| Stock-based compensation expense (1) | $ | 5.2 |  |  | $ | 4.8 |  |

[0001069202-19-000021:notes:123]
[same as prior period, unchanged from 0001069202-18-000020:notes:106]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-19-000021:notes:124]
[same as prior period, unchanged from 0001069202-18-000020:notes:230]

[0001069202-19-000021:notes:125]
Our Board of Directors has authorized a total of $2.5 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in  March 2018. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of March 31, 2019, $346 million of shares may be repurchased under the Share Repurchase Plans.

[0001069202-19-000021:notes:126]
We repurchased 0.4 million shares for $100.0 million from open market transactions during the first quarter of 2019.

[0001069202-19-000021:notes:127]
We also repurchased 0.1 million shares for $13.5 million during the three months ended March 31, 2019 from employees who surrendered shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-19-000021:notes:128]
Comprehensive Income (Loss):

[0001069202-19-000021:notes:129]
[same as prior period, unchanged from 0001069202-18-000020:notes:27]

[0001069202-19-000021:notes:130]
|  |  | For the Three Months Ended March 31, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2019 |  | 2018 |  |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Commodity futures contracts/foreign exchange forward contracts |  | $ | (2.4 | ) |  | $ | 4.6 |  |  | Cost of goods sold |
| Income tax benefit (expense) |  | 0.6 |  |  | (1.1 | ) |  | Provision for income taxes |
| Net of tax |  | $ | (1.8 | ) |  | $ | 3.5 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (2.0 | ) |  | $ | (2.3 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.5 |  |  | 0.6 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.5 | ) |  | $ | (1.7 | ) |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |
| Foreign currency adjustments upon sale of business |  | $ | (2.1 | ) |  | $ | — |  |  | Loss (gain), net on sale of businesses and related property |
| Net of tax |  | $ | (2.1 | ) |  | $ | — |  |  |  |
| Total reclassifications from AOCL |  | $ | (5.4 | ) |  | $ | 1.8 |  |  |  |

[0001069202-19-000021:notes:131]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2019 (in millions):

[0001069202-19-000021:notes:132]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2018 |  | $ | (6.2 | ) |  | $ | (154.5 | ) |  | $ | (28.1 | ) |  | $ | (188.8 | ) |
| Other comprehensive income (loss) before reclassifications |  | 4.4 |  |  | (1.7 | ) |  | 0.5 |  |  | 3.2 |  |
| Amounts reclassified from AOCL |  | 1.8 |  |  | 1.5 |  |  | 2.1 |  |  | 5.4 |  |
| Net other comprehensive (loss) income |  | 6.2 |  |  | (0.2 | ) |  | 2.6 |  |  | 8.6 |  |
| Balance as of March 31, 2019 |  | $ | — |  |  | $ | (154.7 | ) |  | $ | (25.5 | ) |  | $ | (180.2 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-19-000021:notes:133]
[same as prior period, unchanged from 0001069202-18-000020:notes:187]

[0001069202-19-000021:notes:134]
[same as prior period, unchanged from 0001069202-18-000020:notes:188]

[0001069202-19-000021:notes:135]
Restructuring Activities in 2019

[0001069202-19-000021:notes:136]
[same as prior period, unchanged from 0001069202-18-000020:notes:190]

[0001069202-19-000021:notes:137]
|  | Charges Incurred in 2019 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 0.6 |  |  | $ | 13.6 |  |  | $ | 14.0 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 3.2 |  |  | 3.2 |  |
| Lease termination | (0.1 | ) |  | 0.8 |  |  | 0.8 |  |
| Other | — |  |  | 4.7 |  |  | 4.7 |  |
| Total restructuring charges | $ | 0.5 |  |  | $ | 22.3 |  |  | $ | 22.7 |  |

[0001069202-19-000021:notes:138]
[same as prior period, unchanged from 0001069202-18-000020:notes:192]

[0001069202-19-000021:notes:139]
|  | Charges Incurred in 2019 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 2.0 |  |  | $ | 2.0 |  |
| Commercial Heating & Cooling | (0.1 | ) |  | 2.5 |  |  | 2.5 |  |
| Refrigeration | 0.6 |  |  | 15.5 |  |  | 15.9 |  |
| Corporate & Other | — |  |  | 2.3 |  |  | 2.3 |  |
| Total restructuring charges | $ | 0.5 |  |  | $ | 22.3 |  |  | $ | 22.7 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-19-000021:notes:140]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Total Assets: |  |  |  |
| Residential Heating & Cooling | $ | 1,108.1 |  |  | $ | 837.4 |  |
| Commercial Heating & Cooling | 371.0 |  |  | 349.5 |  |
| Refrigeration | 386.2 |  |  | 462.9 |  |
| Corporate and other | 240.4 |  |  | 167.4 |  |
| Total assets | $ | 2,105.7 |  |  | $ | 1,817.2 |  |

[0001069202-19-000021:notes:141]
[same as prior period, unchanged from 0001069202-18-000020:notes:218]

[0001069202-19-000021:notes:142]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaCentral AmericaSouth America |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | United StatesCanadaEurope(1)Asia Pacific(2)South America(2)Central America |

[0001069202-19-000021:notes:143]
(1)Effective January 1, 2019, we realigned our segment structure. We shifted financial reporting of the European Commercial HVAC business from our Commercial Heating & Cooling segment to our Refrigeration segment as we manage both our commercial HVAC and refrigeration operations in Europe together. We have revised our historical segment results to present them on a comparable basis.

[0001069202-19-000021:notes:144]
(2)Our businesses in the Asia Pacific and South America area were sold in the second and third quarters of 2018, respectively. Refer to Note 14 for details regarding the divestiture of these businesses.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-19-000021:notes:145]
[same as prior period, unchanged from 0001069202-18-000020:notes:107]

[0001069202-19-000021:notes:146]
2019 Divestiture:

[0001069202-19-000021:notes:147]
During the first quarter of 2019, we obtained Board of Directors' approval and signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. The sale was completed on March 29, 2019. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-19-000021:notes:148]
| (Amounts in millions) | For the Three Months Ended March 31, 2019 |
| Cash received from the buyer | $ | 49.0 |  |
| Net assets sold | (50.0 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (2.1 | ) |
| Direct costs to sell | (5.4 | ) |
| Loss on sale of business | $ | (8.5 | ) |

[0001069202-19-000021:notes:149]
2018 Divestitures:

[0001069202-19-000021:notes:150]
Australia, New Zealand and Asia Divestiture

[0001069202-19-000021:notes:151]
During the first quarter of 2018, we obtained Board of Directors' approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia, New Zealand and Asia business, except for the Milperra property that was sold during the second quarter of 2018. We completed the sale to Beijer Ref AB in the second quarter of 2018 with the final post-completion adjustment being recorded in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-19-000021:notes:152]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Cash received from the buyer | $ | 82.9 |  |
| Net assets sold (1) | (87.2 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (3.2 | ) |
| Direct costs to sell | (5.8 | ) |
| Loss on sale of business | $ | (13.3 | ) |

[0001069202-19-000021:notes:153]
[same as prior period, unchanged from 0001069202-18-000020:notes:111]

[0001069202-19-000021:notes:154]
[same as prior period, unchanged from 0001069202-18-000020:notes:112]

[0001069202-19-000021:notes:155]
South America Divestiture

[0001069202-19-000021:notes:156]
During the second quarter of 2018, we obtained Board of Directors' approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale was subject to Brazilian antitrust approval.  We obtained antitrust approval and completed the sale to Elgin SA in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-19-000021:notes:157]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Cash received from the buyer | $ | 4.2 |  |
| Net assets sold (2) | (14.1 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (24.7 | ) |
| Direct costs to sell | (2.9 | ) |
| Loss on sale of business | $ | (37.5 | ) |

[0001069202-19-000021:notes:158]
(2) Includes $1.2 million of net assets that were written down during the quarter ended June 30, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Brazil business.

[0001069202-19-000021:notes:159]
The total Loss (gain), net on sale of businesses and related property in our Consolidated Statements of Operations for year ended December 31, 2018 of $27.0 million is comprised of the $13.3 million loss on the sale of our Australia, New Zealand and Asia business, the $23.8 million gain on the sale of our Milperra property, and the $37.5 million loss on the sale of our Brazil business.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001069202-19-000021:notes:160]
[same as prior period, unchanged from 0001069202-18-000020:notes:216]

[0001069202-19-000021:notes:161]
(1) Includes $10.3 million of net assets that were written down during the quarter ended March 31, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Australia, New Zealand and Asia business.The following table summarizes the net loss recognized in connection with this divestiture:


## us-gaap:EarningsPerShareTextBlock

[0001069202-19-000021:notes:162]
[same as prior period, unchanged from 0001069202-18-000020:notes:118]

[0001069202-19-000021:notes:163]
[same as prior period, unchanged from 0001069202-18-000020:notes:119]

[0001069202-19-000021:notes:164]
[same as prior period, unchanged from 0001069202-18-000020:notes:120]

[0001069202-19-000021:notes:165]
|  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |
| Net income | $ | 69.3 |  |  | $ | 37.9 |  |
| Add: Loss from discontinued operations | 0.1 |  |  | — |  |
| Income from continuing operations | $ | 69.4 |  |  | $ | 37.9 |  |
| Weighted-average shares outstanding – basic | 39.7 |  |  | 41.5 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.4 |  |  | 0.6 |  |
| Weighted-average shares outstanding – diluted | 40.1 |  |  | 42.1 |  |
| Earnings per share – Basic: |  |  |  |
| Income from continuing operations | $ | 1.75 |  |  | $ | 0.91 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 1.75 |  |  | $ | 0.91 |  |
| Earnings per share – Diluted: |  |  |  |
| Income from continuing operations | $ | 1.73 |  |  | $ | 0.90 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 1.73 |  |  | $ | 0.90 |  |

[0001069202-19-000021:notes:166]
[same as prior period, unchanged from 0001069202-18-000020:notes:122]

[0001069202-19-000021:notes:167]
|  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |
| Weighted-average number of shares | 0.1 |  |  | 0.2 |  |
| Price per share | $ | 214.63 |  |  | $ | 205.53 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-19-000021:notes:168]
[same as prior period, unchanged from 0001069202-18-000020:notes:220]

[0001069202-19-000021:notes:169]
[same as prior period, unchanged from 0001069202-18-000020:notes:221]

[0001069202-19-000021:notes:170]
[same as prior period, unchanged from 0001069202-18-000020:notes:223]

[0001069202-19-000021:notes:171]
[same as prior period, unchanged from 0001069202-18-000020:notes:224]

[0001069202-19-000021:notes:172]
[same as prior period, unchanged from 0001069202-18-000020:notes:225]

[0001069202-19-000021:notes:173]
[same as prior period, unchanged from 0001069202-18-000020:notes:226]

[0001069202-19-000021:notes:174]
Net sales and segment profit (loss) for each segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001069202-19-000021:notes:175]
|  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |
| Net sales |  |  |  |
| Residential Heating & Cooling | $ | 465.6 |  |  | $ | 453.7 |  |
| Commercial Heating & Cooling | 173.3 |  |  | 179.1 |  |
| Refrigeration | 151.4 |  |  | 202.0 |  |
|  | $ | 790.3 |  |  | $ | 834.8 |  |
| Segment profit (loss) (1) |  |  |  |
| Residential Heating & Cooling | $ | 86.7 |  |  | $ | 51.3 |  |
| Commercial Heating & Cooling | 15.1 |  |  | 22.0 |  |
| Refrigeration | 8.4 |  |  | 8.7 |  |
| Corporate and other | (12.1 | ) |  | (11.2 | ) |
| Total segment profit | 98.1 |  |  | 70.8 |  |
| Reconciliation to Operating income: |  |  |  |
| Special inventory write down | — |  |  | 0.1 |  |
| Loss on sale of business | 8.5 |  |  | — |  |
| Loss on assets held for sale | — |  |  | 10.3 |  |
| Gain from insurance recoveries, net of losses incurred | (6.9 | ) |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 1.3 |  |  | 6.5 |  |
| Restructuring charges | 0.5 |  |  | 0.9 |  |
| Operating income | $ | 94.7 |  |  | $ | 53.0 |  |

[0001069202-19-000021:notes:176]
(1)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-19-000021:notes:177]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-19-000021:notes:178]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-19-000021:notes:179]
| ◦ | Special legal contingency charges, |

[0001069202-19-000021:notes:180]
| ◦ | Asbestos-related litigation, |

[0001069202-19-000021:notes:181]
| ◦ | Environmental liabilities, |

[0001069202-19-000021:notes:182]
| ◦ | Divestiture costs, |

[0001069202-19-000021:notes:183]
| ◦ | Other items, net, |

[0001069202-19-000021:notes:184]
| • | Special inventory write down, |

[0001069202-19-000021:notes:185]
| • | Loss on sale of business, |

[0001069202-19-000021:notes:186]
| • | Loss on assets held for sale, |

[0001069202-19-000021:notes:187]
| • | Gain from insurance recoveries, net of losses incurred; and, |

[0001069202-19-000021:notes:188]
[same as prior period, unchanged from 0001069202-18-000020:notes:227]

[0001069202-19-000021:notes:189]
[same as prior period, unchanged from 0001069202-18-000020:notes:228]

[0001069202-19-000021:notes:190]
The assets in the Corporate and other segment primarily consist of cash, short-term investments, property, plant and equipment and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-19-000021:notes:191]
[same as prior period, unchanged from 0001069202-18-000020:notes:126]

[0001069202-19-000021:notes:192]
[same as prior period, unchanged from 0001069202-18-000020:notes:127]

[0001069202-19-000021:notes:193]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2019 were the same as those used at December 31, 2018.

[0001069202-19-000021:notes:194]
[same as prior period, unchanged from 0001069202-18-000020:notes:129]

[0001069202-19-000021:notes:195]
[same as prior period, unchanged from 0001069202-18-000020:notes:130]

[0001069202-19-000021:notes:196]
[same as prior period, unchanged from 0001069202-18-000020:notes:131]

[0001069202-19-000021:notes:197]
[same as prior period, unchanged from 0001069202-18-000020:notes:135]

[0001069202-19-000021:notes:198]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-19-000021:notes:199]
[same as prior period, unchanged from 0001069202-18-000020:notes:137]

[0001069202-19-000021:notes:200]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Senior unsecured notes | $ | 314.1 |  |  | $ | 302.9 |  |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-19-000021:notes:201]
[same as prior period, unchanged from 0001069202-18-000020:notes:31]

[0001069202-19-000021:notes:202]
[same as prior period, unchanged from 0001069202-18-000020:notes:32]

[0001069202-19-000021:notes:203]
The condensed consolidating financial statements reflect our investments in our subsidiaries using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Our condensed consolidating financial statements and our Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of March 31, 2019 and December 31, 2018, and for the three months ended March 31, 2019 and 2018 are shown on the following pages.Lennox International Inc. and Subsidiaries
Condensed Consolidating Balance Sheets

[0001069202-19-000021:notes:204]
As of March 31, 2019

[0001069202-19-000021:notes:205]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 2.0 |  |  | $ | 13.0 |  |  | $ | 16.7 |  |  | $ | — |  |  | $ | 31.7 |  |
| Accounts and notes receivable, net | — |  |  | 64.2 |  |  | 438.4 |  |  | — |  |  | 502.6 |  |
| Inventories, net | — |  |  | 497.5 |  |  | 104.5 |  |  | (1.9 | ) |  | 600.1 |  |
| Other assets | 4.5 |  |  | 63.2 |  |  | 52.2 |  |  | (33.4 | ) |  | 86.5 |  |
| Total current assets | 6.5 |  |  | 637.9 |  |  | 611.8 |  |  | (35.3 | ) |  | 1,220.9 |  |
| Property, plant and equipment, net | — |  |  | 295.3 |  |  | 116.4 |  |  | — |  |  | 411.7 |  |
| Right-of-use assets from operating leases | — |  |  | 146.2 |  |  | 23.9 |  |  | — |  |  | 170.1 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.4 |  |  | — |  |  | 186.5 |  |
| Investment in subsidiaries | 1,367.2 |  |  | 454.9 |  |  | 50.2 |  |  | (1,872.3 | ) |  | — |  |
| Deferred income taxes | (12.5 | ) |  | 50.7 |  |  | 22.5 |  |  | (12.2 | ) |  | 48.5 |  |
| Other assets, net | 1.7 |  |  | 49.8 |  |  | 2.3 |  |  | 14.2 |  |  | 68.0 |  |
| Intercompany (payables) receivables, net | (497.9 | ) |  | 438.2 |  |  | 179.6 |  |  | (119.9 | ) |  | — |  |
| Total assets | $ | 865.0 |  |  | $ | 2,239.1 |  |  | $ | 1,027.1 |  |  | $ | (2,025.5 | ) |  | $ | 2,105.7 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt | 6.9 |  |  | 5.6 |  |  | 225.1 |  |  | — |  |  | 237.6 |  |
| Current operating lease liabilities | — |  |  | 41.7 |  |  | 6.4 |  |  | — |  |  | 48.1 |  |
| Accounts payable | 25.6 |  |  | 276.6 |  |  | 109.7 |  |  | — |  |  | 411.9 |  |
| Accrued expenses | 7.5 |  |  | 175.0 |  |  | 37.3 |  |  | — |  |  | 219.8 |  |
| Income taxes (receivable) payable | (7.2 | ) |  | 19.8 |  |  | 38.0 |  |  | (50.6 | ) |  | — |  |
| Total current liabilities | 32.8 |  |  | 518.7 |  |  | 416.5 |  |  | (50.6 | ) |  | 917.4 |  |
| Long-term debt | 1,036.7 |  |  | 21.7 |  |  | 0.6 |  |  | — |  |  | 1,059.0 |  |
| Long-term operating lease liabilities | — |  |  | 105.0 |  |  | 17.6 |  |  | — |  |  | 122.6 |  |
| Pensions | — |  |  | 76.5 |  |  | 5.8 |  |  | — |  |  | 82.3 |  |
| Other liabilities | 0.3 |  |  | 122.0 |  |  | 6.9 |  |  | — |  |  | 129.2 |  |
| Total liabilities | 1,069.8 |  |  | 843.9 |  |  | 447.4 |  |  | (50.6 | ) |  | 2,310.5 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' (deficit) equity | (204.8 | ) |  | 1,395.2 |  |  | 579.7 |  |  | (1,974.9 | ) |  | (204.8 | ) |
| Total liabilities and stockholders' (deficit) equity | $ | 865.0 |  |  | $ | 2,239.1 |  |  | $ | 1,027.1 |  |  | $ | (2,025.5 | ) |  | $ | 2,105.7 |  |

[0001069202-19-000021:notes:206]
Lennox International Inc. and Subsidiaries
Condensed Consolidating Balance Sheets

[0001069202-19-000021:notes:207]
As of December 31, 2018

[0001069202-19-000021:notes:208]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.8 |  |  | $ | 15.4 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 46.3 |  |
| Accounts and notes receivable, net | — |  |  | 44.3 |  |  | 428.4 |  |  | — |  |  | 472.7 |  |
| Inventories, net | — |  |  | 411.4 |  |  | 103.9 |  |  | (5.5 | ) |  | 509.8 |  |
| Other assets | 3.3 |  |  | 36.2 |  |  | 54.7 |  |  | (33.6 | ) |  | 60.6 |  |
| Total current assets | 5.1 |  |  | 507.3 |  |  | 616.1 |  |  | (39.1 | ) |  | 1,089.4 |  |
| Property, plant and equipment, net | — |  |  | 293.3 |  |  | 118.6 |  |  | (3.6 | ) |  | 408.3 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.5 |  |  | — |  |  | 186.6 |  |
| Investment in subsidiaries | 1,311.9 |  |  | 357.8 |  |  | (0.5 | ) |  | (1,669.2 | ) |  | — |  |
| Deferred income taxes | 1.4 |  |  | 54.4 |  |  | 23.4 |  |  | (12.2 | ) |  | 67.0 |  |
| Other assets, net | 1.5 |  |  | 48.1 |  |  | 17.8 |  |  | (1.5 | ) |  | 65.9 |  |
| Intercompany (payables) receivables, net | (715.5 | ) |  | 675.8 |  |  | 142.6 |  |  | (102.9 | ) |  | — |  |
| Total assets | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.8 |  |  | 268.6 |  |  | — |  |  | 300.8 |  |
| Accounts payable | 25.5 |  |  | 295.7 |  |  | 112.1 |  |  | — |  |  | 433.3 |  |
| Accrued expenses | 12.1 |  |  | 213.8 |  |  | 46.4 |  |  | — |  |  | 272.3 |  |
| Income taxes (receivable) payable | (38.5 | ) |  | 40.6 |  |  | 50.8 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | 28.5 |  |  | 552.9 |  |  | 477.9 |  |  | (50.8 | ) |  | 1,008.5 |  |
| Long-term debt | 724.9 |  |  | 15.0 |  |  | 0.6 |  |  | — |  |  | 740.5 |  |
| Pensions | — |  |  | 75.1 |  |  | 7.7 |  |  | — |  |  | 82.8 |  |
| Other liabilities | 0.6 |  |  | 126.4 |  |  | 8.0 |  |  | — |  |  | 135.0 |  |
| Total liabilities | 754.0 |  |  | 769.4 |  |  | 494.2 |  |  | (50.8 | ) |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' (deficit) equity | (149.6 | ) |  | 1,333.4 |  |  | 444.3 |  |  | (1,777.7 | ) |  | (149.6 | ) |
| Total liabilities and stockholders' (deficit) equity | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |

[0001069202-19-000021:notes:209]
Lennox International Inc. and Subsidiaries
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-19-000021:notes:210]
For the Three Months Ended March 31, 2019

[0001069202-19-000021:notes:211]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 722.9 |  |  | $ | 121.2 |  |  | $ | (53.8 | ) |  | $ | 790.3 |  |
| Cost of goods sold | — |  |  | 530.8 |  |  | 51.1 |  |  | 6.8 |  |  | 588.7 |  |
| Gross profit | — |  |  | 192.1 |  |  | 70.1 |  |  | (60.6 | ) |  | 201.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 136.5 |  |  | 9.5 |  |  | (0.2 | ) |  | 145.8 |  |
| Losses (gains) and other expenses, net | (0.6 | ) |  | 1.7 |  |  | 0.1 |  |  | (0.1 | ) |  | 1.1 |  |
| Restructuring charges | — |  |  | 0.3 |  |  | 0.2 |  |  | — |  |  | 0.5 |  |
| Loss on sale of business | — |  |  | 0.8 |  |  | 7.7 |  |  | — |  |  | 8.5 |  |
| Insurance proceeds for lost profits | — |  |  | (39.5 | ) |  | — |  |  | — |  |  | (39.5 | ) |
| Gain from insurance recoveries, net of losses incurred | — |  |  | (6.9 | ) |  | — |  |  | — |  |  | (6.9 | ) |
| Income from equity method investments | (70.6 | ) |  | (41.1 | ) |  | (2.0 | ) |  | 111.1 |  |  | (2.6 | ) |
| Operating income | 71.2 |  |  | 140.3 |  |  | 54.6 |  |  | (171.4 | ) |  | 94.7 |  |
| Interest expense, net | 2.4 |  |  | 6.1 |  |  | 2.4 |  |  | — |  |  | 10.9 |  |
| Other (income) expense, net | — |  |  | (5.8 | ) |  | 6.6 |  |  | — |  |  | 0.8 |  |
| Income (loss) from continuing operations before income taxes | 68.8 |  |  | 140.0 |  |  | 45.6 |  |  | (171.4 | ) |  | 83.0 |  |
| Provision for income tax (benefit) expense | (0.5 | ) |  | 10.1 |  |  | 4.2 |  |  | (0.2 | ) |  | 13.6 |  |
| Income (loss) from continuing operations | 69.3 |  |  | 129.9 |  |  | 41.4 |  |  | (171.2 | ) |  | 69.4 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Net income (loss) | $ | 69.3 |  |  | $ | 129.9 |  |  | $ | 41.3 |  |  | $ | (171.2 | ) |  | $ | 69.3 |  |
| Other comprehensive income, net of tax | 6.4 |  |  | 0.4 |  |  | 1.8 |  |  | — |  |  | 8.6 |  |
| Comprehensive income (loss) | $ | 75.7 |  |  | $ | 130.3 |  |  | $ | 43.1 |  |  | $ | (171.2 | ) |  | $ | 77.9 |  |

[0001069202-19-000021:notes:212]
Lennox International Inc. and Subsidiaries
Condensed Consolidating Statements of Cash Flows

[0001069202-19-000021:notes:213]
For the Three Months Ended  March 31, 2019

[0001069202-19-000021:notes:214]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows provided by (used in) operating activities | $ | 49.9 |  |  | $ | (258.3 | ) |  | $ | 67.4 |  |  | $ | — |  |  | $ | (141.0 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.3 |  |  | — |  |  | — |  |  | 0.3 |  |
| Purchases of property, plant and equipment | — |  |  | (33.5 | ) |  | (3.7 | ) |  | — |  |  | (37.2 | ) |
| Net proceeds from sale of business | — |  |  | 43.0 |  |  | 0.6 |  |  | — |  |  | 43.6 |  |
| Insurance recoveries received for property damage incurred from natural disaster |  |  |  | 6.9 |  |  | — |  |  | — |  |  | 6.9 |  |
| Net cash provided by (used in) by investing activities | — |  |  | 16.7 |  |  | (3.1 | ) |  | — |  |  | 13.6 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Asset securitization payments |  |  |  |  |  |  | (43.5 | ) |  | — |  |  | (43.5 | ) |
| Long-term debt payments | (30.0 | ) |  | (0.5 | ) |  | (1.2 | ) |  | — |  |  | (31.7 | ) |
| Long-term borrowings | — |  |  | 2.7 |  |  | 0.6 |  |  | — |  |  | 3.3 |  |
| Borrowings from credit facility | 844.5 |  |  |  |  |  |  |  |  | — |  |  | 844.5 |  |
| Payments on credit facility | (525.5 | ) |  |  |  |  |  |  |  | — |  |  | (525.5 | ) |
| Proceeds from employee stock purchases | 0.8 |  |  | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Repurchases of common stock | (100.0 | ) |  | — |  |  | — |  |  | — |  |  | (100.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (13.5 | ) |  | — |  |  | — |  |  | — |  |  | (13.5 | ) |
| Intercompany debt | (7.9 | ) |  | (0.2 | ) |  | 8.1 |  |  | — |  |  | — |  |
| Intercompany financing activity | (192.6 | ) |  | 237.2 |  |  | (44.6 | ) |  | — |  |  | — |  |
| Cash dividends paid | (25.5 | ) |  | — |  |  | — |  |  | — |  |  | (25.5 | ) |
| Net cash (used in) provided by financing activities | (49.7 | ) |  | 239.2 |  |  | (80.6 | ) |  | — |  |  | 108.9 |  |
| Increase (decrease) in cash and cash equivalents | 0.2 |  |  | (2.4 | ) |  | (16.3 | ) |  | — |  |  | (18.5 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 3.9 |  |  | — |  |  | 3.9 |  |
| Cash and cash equivalents, beginning of period | 1.8 |  |  | 15.4 |  |  | 29.1 |  |  | — |  |  | 46.3 |  |
| Cash and cash equivalents, end of period | $ | 2.0 |  |  | $ | 13.0 |  |  | $ | 16.7 |  |  | $ | — |  |  | $ | 31.7 |  |

[0001069202-19-000021:notes:215]
For the Three Months Ended  March 31, 2018

[0001069202-19-000021:notes:216]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows provided by (used in) operating activities | $ | 104.4 |  |  | $ | (158.6 | ) |  | $ | (29.3 | ) |  | $ | — |  |  | $ | (83.5 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (17.3 | ) |  | (5.4 | ) |  | — |  |  | (22.7 | ) |
| Net cash used in investing activities | — |  |  | (17.3 | ) |  | (5.3 | ) |  | — |  |  | (22.6 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Asset securitization payments | — |  |  | — |  |  | (51.0 | ) |  | — |  |  | (51.0 | ) |
| Long-term debt payments | (7.5 | ) |  | (2.7 | ) |  | — |  |  | — |  |  | (10.2 | ) |
| Borrowings from credit facility | 790.0 |  |  | — |  |  | — |  |  | — |  |  | 790.0 |  |
| Payments on credit facility | (444.1 | ) |  | — |  |  | — |  |  | — |  |  | (444.1 | ) |
| Proceeds from employee stock purchases | 0.8 |  |  | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Repurchases of common stock | (150.0 | ) |  | — |  |  | — |  |  | — |  |  | (150.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (18.1 | ) |  | — |  |  | — |  |  | — |  |  | (18.1 | ) |
| Intercompany debt | (47.5 | ) |  | 37.9 |  |  | 9.6 |  |  | — |  |  | — |  |
| Intercompany financing activity | (206.9 | ) |  | 127.7 |  |  | 79.2 |  |  | — |  |  | — |  |
| Cash dividends paid | (21.3 | ) |  | — |  |  | — |  |  | — |  |  | (21.3 | ) |
| Net cash (used in) provided by financing activities | (104.6 | ) |  | 162.9 |  |  | 37.7 |  |  | — |  |  | 96.0 |  |
| (Decrease) increase in cash and cash equivalents | (0.2 | ) |  | (13.0 | ) |  | 3.1 |  |  | — |  |  | (10.1 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (1.0 | ) |  | — |  |  | (1.0 | ) |
| Cash and cash equivalents, beginning of period | 1.6 |  |  | 28.0 |  |  | 38.6 |  |  | — |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 1.4 |  |  | $ | 15.0 |  |  | $ | 40.7 |  |  | $ | — |  |  | $ | 57.1 |  |


## us-gaap:SubsequentEventsTextBlock

[0001069202-19-000021:notes:217]
Subsequent Event:

[0001069202-19-000021:notes:218]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and the related benefit obligations.  This transaction required a remeasurement of the pension plan and we expect to recognize a $61.0 million non-cash pension settlement pre-tax loss in the second quarter of 2019 for this remeasurement.
