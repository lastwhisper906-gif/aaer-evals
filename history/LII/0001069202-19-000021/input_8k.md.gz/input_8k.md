# LII 8-K — 0001069202-19-000018 filed 2019-04-22

## item codes, every 8-K on or before 2019-04-22

- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2019-04-22

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-19-000018:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetables20.htm
EXHIBIT 99.1

[0001069202-19-000018:8k_2_02:2]
Exhibit

[0001069202-19-000018:8k_2_02:3]
Exhibit-99.1

[0001069202-19-000018:8k_2_02:4]
Lennox International Reports First Quarter Results

[0001069202-19-000018:8k_2_02:5]
| • | Residential revenue up 3% to new first-quarter high as recovery from tornado impact continues to accelerate |

[0001069202-19-000018:8k_2_02:6]
| • | Residential revenue growth negatively impacted 8% from tornado |

[0001069202-19-000018:8k_2_02:7]
| • | Overall company revenue on a GAAP basis down 5%, including 10% of negative impact from the tornado and divestitures; excluding divestitures, adjusted company revenue up 1%, including 5% of negative tornado impact |

[0001069202-19-000018:8k_2_02:8]
| • | GAAP EPS from continuing operations up 92% to $1.73, and adjusted EPS from continuing operations up 38% to $1.68 |

[0001069202-19-000018:8k_2_02:9]
| • | Reiterating 2019 guidance for revenue growth of 3-7% |

[0001069202-19-000018:8k_2_02:10]
| • | Updating 2019 guidance for GAAP EPS from continuing operations from $14.30-$14.90 to $12.65-$13.25, incorporating lower estimated factory reconstruction costs and associated gain from replacement value above book value, and a second quarter non-cash pension settlement charge |

[0001069202-19-000018:8k_2_02:11]
| • | Reiterating adjusted EPS from continuing operations of $12.00-$12.60 |

[0001069202-19-000018:8k_2_02:12]
| • | Raising 2019 guidance for stock repurchases from $350 million to $400 million |

[0001069202-19-000018:8k_2_02:13]
DALLAS, April 22, 2019 - Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2019. All comparisons are to the prior-year period. The company’s tornado references relate to the July 2018 tornado damage at a Residential manufacturing facility in Iowa. Adjusted revenue and profit excludes non-core Refrigeration businesses divested in 2018 and 2019.

[0001069202-19-000018:8k_2_02:14]
For the first quarter, Lennox International reported GAAP revenue of $790 million, down 5%. At constant currency, GAAP revenue was down 4%. GAAP operating income was a first-quarter record $95 million, up 79%. GAAP earnings per share from continuing operations was a first-quarter record $1.73, up 92%.

[0001069202-19-000018:8k_2_02:15]
Adjusted revenue, excluding the impact from divestitures, was a first-quarter record $756 million, up 1%. At constant currency, adjusted revenue rose 2%. Total segment profit increased 34% to a first-quarter record $99 million. Total segment margin expanded 330 basis points to a first-quarter record 13.1%. Adjusted earnings per share from continuing operations was a first-quarter record $1.68, up 38%.

[0001069202-19-000018:8k_2_02:16]
“In the first quarter, our Residential business continued to make significant progress in the recovery from the tornado,” said Chairman and CEO Todd Bluedorn. “With full production capability in place across our three Residential factories, we are taking back business as we re-supply dealers and focus on fully re-filling our company-owned regional and local distribution network. We now expect $70 million of negative tornado impact on revenue this year, down from prior guidance of $85 million. We estimate $40 million of negative segment profit impact, down from the prior estimate of $43 million. Business interruption insurance recovery for lost profits is expected to be $80 million in 2019, compared to $83 million in prior guidance.

[0001069202-19-000018:8k_2_02:17]
“Looking at business segment results in the first quarter, Residential revenue was up 3%, including negative tornado impact of 8% or $35 million in the quarter. Revenue was up in both replacement and new construction business. Residential segment profit rose 69%, or 26% adjusted for the $22 million of net benefit resulting from $40 million in insurance proceeds against $18 million of negative tornado impact in the quarter. Segment margin expanded 730 basis points to 18.6%, or 160 basis points to 12.9% adjusted for the tornado impact and insurance. In Commercial, revenue was down 3% on a decline in new construction business, lumpy on a quarter-to-quarter basis. Segment profit declined 31%, and segment margin was down 360 basis points to 8.7%. In Refrigeration, revenue was up 2% at constant currency, led by growth in Europe. Segment profit was down 20% from a year ago, and segment margin was down 180 basis points to 8.0%. Heading into our seasonally largest quarters, we continue to expect growth and margin expansion in both our Commercial and Refrigeration businesses on a full-year basis.

[0001069202-19-000018:8k_2_02:18]
“For the company overall, the second quarter is off to a solid start, and we reiterate revenue and adjusted EPS guidance for 2019 as we look ahead to another year of strong growth and profitability. Following the sale of the Kysor Warren business in the first quarter, we are raising guidance for stock repurchases from $350 million to $400 million for the full year.”

[0001069202-19-000018:8k_2_02:19]
FINANCIAL HIGHLIGHTS

[0001069202-19-000018:8k_2_02:20]
Revenue: On a GAAP basis, first-quarter revenue was $790 million, down 5%. On an adjusted basis, revenue was a first-quarter record $756 million, up 1%. Foreign exchange was 1% unfavorable to revenue growth. Volume was down, and price and mix were favorable.

[0001069202-19-000018:8k_2_02:21]
Gross Profit: On a GAAP basis, gross profit was $202 million, down 10%. Gross margin was 25.5%, down 120 basis points. On an adjusted basis, gross profit was $198 million, down 5%. Adjusted gross margin was 26.2%, down 160 basis points. Gross profit on a GAAP and adjusted basis was impacted by the tornado, lower factory productivity, higher commodity, freight, tariffs, distribution, warranties and other product costs, as well as unfavorable foreign exchange. Partial offsets included higher price, favorable mix, and sourcing and engineering-led cost reductions.

[0001069202-19-000018:8k_2_02:22]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the first quarter was $69.4 million, or $1.73 per share, compared to $37.9 million, or $0.90 per share, in the prior-year quarter.

[0001069202-19-000018:8k_2_02:23]
Adjusted income from continuing operations in the first quarter was $67.2 million, or $1.68 per share, compared to $51.3 million, or $1.22 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the first quarter of 2019 excludes net after-tax benefits of $2.2 million: a gain of $5.2 million from insurance recoveries, net of losses incurred; a benefit of $4.4 million for excess tax benefits from share-based compensation; a loss on sale of business of $5.0 million; $1.0 million for non-core business results; and a net charge of $1.4 million total for various other items.

[0001069202-19-000018:8k_2_02:24]
Cash from Operations, Free Cash Flow and Total Debt: Net cash used in operations in the first quarter was $141 million compared to a use of $84 million in the prior-year quarter. Capital expenditures were $37 million compared to $23 million in the prior-year quarter. Proceeds from damage to property and proceeds from the disposal of property, plant and equipment totaled $7 million. Free cash flow was ($171) million compared to approximately ($106) million in the first quarter a year ago. Total debt at the end of the first quarter was $1.3 billion. Total cash and cash equivalents were $32 million at the end of March. In the first quarter, the company paid approximately $26 million in dividends.

[0001069202-19-000018:8k_2_02:25]
BUSINESS SEGMENT HIGHLIGHTS

[0001069202-19-000018:8k_2_02:26]
Residential Heating & Cooling

[0001069202-19-000018:8k_2_02:27]
Revenue in the Residential Heating & Cooling business segment rose 3% to a first-quarter record $466 million. Foreign exchange was neutral to revenue. Segment profit was $87 million, up 69%. Segment margin was 18.6%, up 730 basis points. Residential financial results were impacted by the tornado, insurance proceeds, higher volume, favorable price and mix, and sourcing and engineering-led cost reductions. Partial offsets included higher commodity, freight, tariffs, and warranty costs, lower factory productivity, distribution investments, and higher SG&A expenses.

[0001069202-19-000018:8k_2_02:28]
Commercial Heating & Cooling

[0001069202-19-000018:8k_2_02:29]
Revenue in the Commercial Heating & Cooling business segment was $173 million in the first quarter, down 3%. Foreign exchange was neutral to revenue. Commercial profit was $15 million, down 31%, and segment margin was 8.7%, down 360 basis points. Results were impacted by lower volume and factory productivity, higher commodity, freight, tariffs, warranty and other product costs, distribution investments, and higher SG&A expenses. Partial offsets included favorable price and mix, and sourcing and engineering-led cost reductions.

[0001069202-19-000018:8k_2_02:30]
Refrigeration

[0001069202-19-000018:8k_2_02:31]
Revenue in the Refrigeration business segment was $117 million in the first quarter, down 2%. Foreign exchange had a negative 4% impact on revenue. Refrigeration profit was $9 million, down 20%, and segment margin was 8.0%, down 180 basis points. Results were impacted by lower volume and factory productivity, unfavorable mix, higher commodity, tariffs, and freight costs, distribution investments, and higher SG&A expenses. Partial offsets included favorable price and sourcing and engineering-led cost reductions.

[0001069202-19-000018:8k_2_02:32]
FULL-YEAR OUTLOOK

[0001069202-19-000018:8k_2_02:33]
| • | Reiterating 2019 guidance for revenue growth of 3-7% |

[0001069202-19-000018:8k_2_02:34]
| • | Updating guidance for GAAP EPS from continuing operations from $14.30-$14.90 to a range of $12.65-$13.25, incorporating lower estimated factory reconstruction costs and associated gain of approximately $91 million (previously $109 million for 2019) from replacement value above book value, and a non-cash pension settlement charge of approximately $61 million pre-tax in the second quarter of 2019 |

[0001069202-19-000018:8k_2_02:35]
| • | Reiterating guidance for adjusted EPS from continuing operations of $12.00-$12.60 |

[0001069202-19-000018:8k_2_02:36]
| • | Reiterating guidance for corporate expenses of approximately $90 million |

[0001069202-19-000018:8k_2_02:37]
| • | Reiterating guidance for an effective tax rate of 22-23% on an adjusted basis for the full year |

[0001069202-19-000018:8k_2_02:38]
| • | Updating guidance for 2019 capital expenditures from approximately $215 million to $195 million, with approximately $95 million funded by insurance proceeds to complete the reconstruction of the Iowa manufacturing facility, down from $115 million previously due to lower expected construction costs |

[0001069202-19-000018:8k_2_02:39]
| • | Raising guidance for stock repurchases from $350 million to $400 million in 2019 |

[0001069202-19-000018:8k_2_02:40]
A chart of the company’s current view on the tornado financial impact and insurance recovery for 2018-2019 is posted on the company’s website at www.lennoxinternational.com.

[0001069202-19-000018:8k_2_02:41]
CONFERENCE CALL INFORMATION

[0001069202-19-000018:8k_2_02:42]
A conference call to discuss the company's first-quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-332-0107 at least 10 minutes prior to the scheduled start time and use reservation number 466328. The conference call also will be webcast on Lennox International's web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on April 22 through May 6, 2019 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 466328. The call also will be archived on the company's website.

[0001069202-19-000018:8k_2_02:43]
About Lennox International

[0001069202-19-000018:8k_2_02:44]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol "LII". Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-19-000018:8k_2_02:45]
FORWARD-LOOKING STATEMENTS

[0001069202-19-000018:8k_2_02:46]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Statements of Operations |
|  | (Amounts in millions, except per share data) | For the Three Months Ended March 31,(Unaudited) |
|  |  | 2019 |  | 2018 |
|  | Net sales | $ | 790.3 |  |  | $ | 834.8 |  |
|  | Cost of goods sold | 588.7 |  |  | 611.6 |  |
|  | Gross profit | 201.6 |  |  | 223.2 |  |
|  | Operating Expenses: |  |  |  |
|  | Selling, general and administrative expenses | 145.8 |  |  | 155.2 |  |
|  | Losses (gains) and other expenses, net | 1.1 |  |  | 7.3 |  |
|  | Restructuring charges | 0.5 |  |  | 0.9 |  |
|  | Loss on sale of business | 8.5 |  |  | — |  |
|  | Loss on assets held for sale | — |  |  | 10.3 |  |
|  | Insurance proceeds for lost profits | (39.5 | ) |  | — |  |
|  | Gain from insurance recoveries, net of losses incurred | (6.9 | ) |  | — |  |
|  | Income from equity method investments | (2.6 | ) |  | (3.5 | ) |
|  | Operating income | 94.7 |  |  | 53.0 |  |
|  | Interest expense, net | 10.9 |  |  | 8.4 |  |
|  | Other expense (income), net | 0.8 |  |  | 0.6 |  |
|  | Income from continuing operations before income taxes | 83.0 |  |  | 44.0 |  |
|  | Provision for income taxes | 13.6 |  |  | 6.1 |  |
|  | Income from continuing operations | 69.4 |  |  | 37.9 |  |
|  | Discontinued Operations: |  |  |  |
|  | Loss from discontinued operations before income taxes | (0.1 | ) |  | — |  |
|  | Income tax benefit | — |  |  | — |  |
|  | Loss from discontinued operations | (0.1 | ) |  | — |  |
|  | Net income | $ | 69.3 |  |  | $ | 37.9 |  |
|  | Earnings per share – Basic: |  |  |  |
|  | Income from continuing operations | $ | 1.75 |  |  | $ | 0.91 |  |
|  | Loss from discontinued operations | — |  |  | — |  |
|  | Net income | $ | 1.75 |  |  | $ | 0.91 |  |
|  | Earnings per share – Diluted: |  |  |  |
|  | Income from continuing operations | $ | 1.73 |  |  | $ | 0.90 |  |
|  | Loss from discontinued operations | — |  |  | — |  |
|  | Net income | $ | 1.73 |  |  | $ | 0.90 |  |
|  | Weighted Average Number of Shares Outstanding - Basic | 39.7 |  |  | 41.5 |  |
|  | Weighted Average Number of Shares Outstanding - Diluted | 40.1 |  |  | 42.1 |  |

[0001069202-19-000018:8k_2_02:47]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Adjusted Segment Net Sales and Profit (Loss) |

[0001069202-19-000018:8k_2_02:48]
| (Amounts in millions) | For the Three Months Ended March 31,(Unaudited) |
|  | 2019 |  | 2018 |
| Adjusted Net Sales |  |  |  |
| Residential Heating & Cooling | $ | 465.6 |  |  | $ | 453.7 |  |
| Commercial Heating & Cooling | 173.3 |  |  | 179.1 |  |
| Refrigeration (1) | 117.1 |  |  | 119.2 |  |
|  | $ | 756.0 |  |  | $ | 752.0 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |
| Residential Heating & Cooling | $ | 86.7 |  |  | $ | 51.3 |  |
| Commercial Heating & Cooling | 15.1 |  |  | 22.0 |  |
| Refrigeration (1) | 9.4 |  |  | 11.7 |  |
| Corporate and other | (12.1 | ) |  | (11.2 | ) |
| Total adjusted segment profit | 99.1 |  |  | 73.8 |  |
| Reconciliation to Operating Income: |  |  |  |
| Special inventory write down | — |  |  | 0.1 |  |
| Loss on sale of businesses | 8.5 |  |  | — |  |
| Loss on assets held for sale | — |  |  | 10.3 |  |
| Gain from insurance recoveries, net of losses incurred | (6.9 | ) |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 1.3 |  |  | 6.5 |  |
| Restructuring charges | 0.5 |  |  | 0.9 |  |
| Operating loss (income) from non-core businesses | 1.0 |  |  | 3.0 |  |
| Operating income | $ | 94.7 |  |  | $ | 53.0 |  |

[0001069202-19-000018:8k_2_02:49]
(1) Excludes the non-core business results related to Kysor Warren, which was sold in March 2019 and our business operations in Australia, Asia and South America, which were sold in 2018.

[0001069202-19-000018:8k_2_02:50]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-19-000018:8k_2_02:51]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-19-000018:8k_2_02:52]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-19-000018:8k_2_02:53]
| ◦ | Special legal contingency charges, |

[0001069202-19-000018:8k_2_02:54]
| ◦ | Asbestos-related litigation, |

[0001069202-19-000018:8k_2_02:55]
| ◦ | Environmental liabilities, |

[0001069202-19-000018:8k_2_02:56]
| ◦ | Divestiture costs, |

[0001069202-19-000018:8k_2_02:57]
| ◦ | Other items, net, |

[0001069202-19-000018:8k_2_02:58]
| • | Special inventory write down, |

[0001069202-19-000018:8k_2_02:59]
| • | Loss on sale of business, |

[0001069202-19-000018:8k_2_02:60]
| • | Loss on assets held for sale, |

[0001069202-19-000018:8k_2_02:61]
| • | Gain from insurance recoveries, net of losses incurred, |

[0001069202-19-000018:8k_2_02:62]
| • | Operating loss (income) from non-core businesses; and, |

[0001069202-19-000018:8k_2_02:63]
| • | Restructuring charges. |

[0001069202-19-000018:8k_2_02:64]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Balance Sheets |
| (Amounts in millions, except shares and par values) | As of March 31, 2019 |  | As of December 31, 2018 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 31.7 |  |  | $ | 46.3 |  |
| Accounts and notes receivable, net of allowances of $7.2 and $6.3 in 2019 and 2018, respectively | 502.6 |  |  | 472.7 |  |
| Inventories, net | 600.1 |  |  | 509.8 |  |
| Other assets | 86.5 |  |  | 60.6 |  |
| Total current assets | 1,220.9 |  |  | 1,089.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $785.1 and $778.5 in 2019 and 2018, respectively | 411.7 |  |  | 408.3 |  |
| Right-of-use assets from operating leases | 170.1 |  |  | — |  |
| Goodwill | 186.5 |  |  | 186.6 |  |
| Deferred income taxes | 48.5 |  |  | 67.0 |  |
| Other assets, net | 68.0 |  |  | 65.9 |  |
| Total assets | $ | 2,105.7 |  |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 237.6 |  |  | 300.8 |  |
| Current operating lease liabilities | 48.1 |  |  | — |  |
| Accounts payable | 411.9 |  |  | 433.3 |  |
| Accrued expenses | 219.8 |  |  | 272.3 |  |
| Income taxes payable | — |  |  | 2.1 |  |
| Total current liabilities | 917.4 |  |  | 1,008.5 |  |
| Long-term debt | 1,059.0 |  |  | 740.5 |  |
| Long-term operating lease liabilities | 122.6 |  |  | — |  |
| Pensions | 82.3 |  |  | 82.8 |  |
| Other liabilities | 129.2 |  |  | 135.0 |  |
| Total liabilities | 2,310.5 |  |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,079.4 |  |  | 1,078.8 |  |
| Retained earnings | 1,898.7 |  |  | 1,855.0 |  |
| Accumulated other comprehensive loss | (180.2 | ) |  | (188.8 | ) |
| Treasury stock, at cost, shares 47,609,360 and 47,312,248 shares for 2019 and 2018, respectively | (3,003.6 | ) |  | (2,895.5 | ) |
| Total stockholders' deficit | (204.8 | ) |  | (149.6 | ) |
| Total liabilities and stockholders' deficit | $ | 2,105.7 |  |  | $ | 1,817.2 |  |

[0001069202-19-000018:8k_2_02:65]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-19-000018:8k_2_02:66]
Consolidated Statements of Cash Flows

[0001069202-19-000018:8k_2_02:67]
(Unaudited)

[0001069202-19-000018:8k_2_02:68]
| (Amounts in millions) | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 69.3 |  |  | $ | 37.9 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |
| Loss on sale of business | 8.5 |  |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (6.9 | ) |  | — |  |
| Income from equity method investments | (2.6 | ) |  | (3.5 | ) |
| Loss on assets held for sale | — |  |  | 10.3 |  |
| Restructuring charges, net of cash paid | 0.3 |  |  | 0.6 |  |
| Provision for bad debts | 1.6 |  |  | 1.9 |  |
| Unrealized losses (gains) on derivative contracts | (0.6 | ) |  | (0.1 | ) |
| Stock-based compensation expense | 5.2 |  |  | 4.8 |  |
| Depreciation and amortization | 18.2 |  |  | 16.6 |  |
| Deferred income taxes | 15.5 |  |  | (2.1 | ) |
| Pension expense | 2.0 |  |  | 2.1 |  |
| Pension contributions | (2.5 | ) |  | (0.7 | ) |
| Other items, net | 0.2 |  |  | 0.1 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (62.7 | ) |  | (44.5 | ) |
| Inventories | (120.9 | ) |  | (124.3 | ) |
| Other current assets | 4.5 |  |  | (0.7 | ) |
| Accounts payable | (1.7 | ) |  | 77.5 |  |
| Accrued expenses | (35.0 | ) |  | (35.2 | ) |
| Income taxes payable and receivable | (34.1 | ) |  | (22.3 | ) |
| Other | 0.7 |  |  | (1.9 | ) |
| Net cash used in operating activities | (141.0 | ) |  | (83.5 | ) |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.3 |  |  | 0.1 |  |
| Purchases of property, plant and equipment | (37.2 | ) |  | (22.7 | ) |
| Net proceeds from sale of business | 43.6 |  |  | — |  |
| Insurance recoveries received for property damage incurred from natural disaster | 6.9 |  |  | — |  |
| Net cash provided by (used in) investing activities | 13.6 |  |  | (22.6 | ) |
| Cash flows from financing activities: |  |  |  |
| Short-term borrowings, net | — |  |  | (0.1 | ) |
| Asset securitization payments | (43.5 | ) |  | (51.0 | ) |
| Long-term debt borrowings | 3.3 |  |  | — |  |
| Long-term debt payments | (31.7 | ) |  | (10.2 | ) |
| Borrowings from credit facility | 844.5 |  |  | 790.0 |  |
| Payments on credit facility | (525.5 | ) |  | (444.1 | ) |
| Proceeds from employee stock purchases | 0.8 |  |  | 0.8 |  |
| Repurchases of common stock | (100.0 | ) |  | (150.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (13.5 | ) |  | (18.1 | ) |
| Cash dividends paid | (25.5 | ) |  | (21.3 | ) |
| Net cash provided by financing activities | 108.9 |  |  | 96.0 |  |
| Decrease in cash and cash equivalents | (18.5 | ) |  | (10.1 | ) |
| Effect of exchange rates on cash and cash equivalents | 3.9 |  |  | (1.0 | ) |
| Cash and cash equivalents, beginning of period | 46.3 |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 31.7 |  |  | $ | 57.1 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 8.4 |  |  | $ | 6.0 |  |
| Income taxes paid (net of refunds) | $ | 32.0 |  |  | $ | 32.7 |  |
| Insurance recoveries received | $ | 76.0 |  |  | $ | — |  |

[0001069202-19-000018:8k_2_02:69]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. During the first quarter of 2019, the Company completed the sale of its Kysor Warren business. In the first quarter of 2018, the Company announced the planned sales of its businesses in Australia, Asia, and South America. The sale of our business in Australia and Asia and the related property was completed in the second quarter of 2018 and sale of our business in South America was completed in the third quarter of 2018. The results from operations for these businesses have been shown in the tables below as “Non-core business results”. The prior period results have been updated to provide period-over-period comparability. |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |
|  | For the Three Months Ended March 31,(Unaudited) |
|  | 2019 |  | 2018 |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |
| Income from continuing operations, a GAAP measure | $ | 83.0 |  | $ | (13.6 | ) | $ | 69.4 |  |  | $ | 44.0 |  | $ | (6.1 | ) | $ | 37.9 |  |
| Restructuring charges | 0.5 |  | (0.1 | ) | 0.4 |  |  | 0.9 |  | (0.3 | ) | 0.6 |  |
| Loss on assets held for sale | — |  | — |  | — |  |  | 10.3 |  | — |  | 10.3 |  |
| Special legal contingency charges (a) | 0.2 |  | — |  | 0.2 |  |  | 0.2 |  | (0.1 | ) | 0.1 |  |
| Asbestos-related litigation (a) | 1.4 |  | (0.3 | ) | 1.1 |  |  | 2.1 |  | (0.6 | ) | 1.5 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | (0.4 | ) | 0.1 |  | (0.3 | ) |  | 1.1 |  | (0.2 | ) | 0.9 |  |
| Inventory write down (b) | — |  | — |  | — |  |  | 0.1 |  | — |  | 0.1 |  |
| Environmental liabilities (a) | — |  | — |  | — |  |  | 0.3 |  | — |  | 0.3 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (4.4 | ) | (4.4 | ) |  | — |  | (4.3 | ) | (4.3 | ) |
| Other tax items, net (c) | — |  | — |  | — |  |  | — |  | (0.9 | ) | (0.9 | ) |
| Loss on sale of business | 8.5 |  | (3.5 | ) | 5.0 |  |  | — |  | — |  | — |  |
| Divestiture costs (a) | — |  | — |  | — |  |  | 2.5 |  | (0.6 | ) | 1.9 |  |
| Gain from insurance recoveries, net of losses incurred | (6.9 | ) | 1.7 |  | (5.2 | ) |  | — |  | — |  | — |  |
| Other items, net (a) | 0.1 |  | (0.1 | ) | — |  |  | 0.3 |  | (0.1 | ) | 0.2 |  |
| Non-core business results (f) | 1.3 |  | (0.3 | ) | 1.0 |  |  | 3.4 |  | (0.7 | ) | 2.7 |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 87.7 |  | $ | (20.5 | ) | $ | 67.2 |  |  | $ | 65.2 |  | $ | (13.9 | ) | $ | 51.3 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 1.73 |  |  |  |  |  |  | $ | 0.90 |  |
| Restructuring charges |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.01 |  |
| Loss on assets held for sale |  |  | — |  |  |  |  | 0.25 |  |
| Special legal contingency charges (a) |  |  |  |  | 0.01 |  |  |  |  |  |  | — |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.04 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  | (0.01 | ) |  |  |  |  |  | 0.02 |  |
| Inventory write down (b) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  | — |  |  |  |  |  |  | 0.01 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.11 | ) |  |  |  |  |  | (0.10 | ) |
| Other tax items, net (c) |  |  |  |  | — |  |  |  |  |  |  | (0.02 | ) |
| Loss on sale of business |  |  |  |  | 0.13 |  |  |  |  |  |  | — |  |

[0001069202-19-000018:8k_2_02:70]
| Divestiture costs (a) |  |  |  |  | — |  |  |  |  |  |  | 0.05 |  |
| Gain from insurance recoveries, net of losses incurred |  |  |  |  | (0.13 | ) |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Non-core business results (f) |  |  |  |  | 0.02 |  |  |  |  |  |  | 0.06 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 1.68 |  |  |  |  | $ | 1.22 |  |
| (a) Recorded in Losses (Gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to our business operations in Australia, Asia, and South America and the Kysor Warren business, not included elsewhere in the reconciliation. |

[0001069202-19-000018:8k_2_02:71]
|  | For the Three Months Ended March 31,(Unaudited) |
|  | 2019 |  | 2018 |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |
| Realized losses (gains) on settled future contracts (a) | $ | 0.1 |  |  | $ | (0.5 | ) |
| Foreign currency exchange (gains) losses (a) | (0.5 | ) |  | 1.3 |  |
| Loss on disposal of fixed assets (a) | 0.2 |  |  | — |  |
| Net change in unrealized (gains) losses on unsettled futures contracts (b) | (0.4 | ) |  | 1.1 |  |
| Special legal contingency charges (b) | 0.2 |  |  | 0.2 |  |
| Asbestos-related litigation (b) | 1.4 |  |  | 2.1 |  |
| Environmental liabilities (b) | — |  |  | 0.3 |  |
| Divestiture costs (b) | — |  |  | 2.5 |  |
| Other items, net (b) | 0.1 |  |  | 0.3 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 1.1 |  |  | $ | 7.3 |  |

[0001069202-19-000018:8k_2_02:72]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001069202-19-000018:8k_2_02:73]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |
|  |  |  |  |  | For the Year Ended December 31, 2019ESTIMATED |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $12.65 - $13.25 |  |
| Insurance recovery, net of other non-core EBIT charges, from tornado impact to damaged property and second quarter non-cash pension settlement charge |  | 0.65 |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $12.00 - $12.60 |  |
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  |  |  | For the Three Months Ended March 31, |
|  |  |  |  |  | 2019 |  | 2018 |
| Average shares outstanding - diluted, a GAAP measure |  |  |  |  | 40.1 |  |  | $ | 42.1 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  |  |  | — |  |  | (0.2 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure |  |  |  |  | 40.1 |  |  | 41.9 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales, a GAAP measure | $ | 151.4 |  |  | $ | 202.0 |  |  | $ | 790.3 |  |  | $ | 834.8 |  |
| Net sales from non-core businesses (a) | 34.3 |  |  | 82.8 |  |  | 34.3 |  |  | 82.8 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 117.1 |  |  | $ | 119.2 |  |  | $ | 756.0 |  |  | $ | 752.0 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, South America and the Kysor Warren business. |  |  |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit, a GAAP measure | $ | 42.5 |  |  | $ | 54.7 |  |  | $ | 201.6 |  |  | $ | 223.2 |  |
| Non-GAAP adjustments to gross profit | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Gross profit from non-core businesses (a) | 3.6 |  |  | 14.5 |  |  | 3.6 |  |  | 14.5 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 38.9 |  |  | $ | 40.4 |  |  | $ | 198.0 |  |  | $ | 208.9 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, South America and the Kysor Warren business. |  |  |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit, a GAAP measure | $ | 8.4 |  |  | $ | 8.7 |  |  | $ | 98.1 |  |  | $ | 70.8 |  |
| Gross (loss) profit from non-core businesses (a) | (1.0 | ) |  | (3.0 | ) |  | (1.0 | ) |  | (3.0 | ) |
| Adjusted Segment profit, a Non-GAAP measure | $ | 9.4 |  |  | $ | 11.7 |  |  | $ | 99.1 |  |  | $ | 73.8 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, South America and the Kysor Warren business. |  |  |  |  |  |  |

[0001069202-19-000018:8k_2_02:74]
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Selling, general and administrative expenses, a GAAP measure | $ | 36.4 |  |  | $ | 49.2 |  |  | $ | 145.8 |  |  | $ | 155.2 |  |
| Selling, general and administrative expenses from non-core businesses (a) | 4.8 |  |  | 18.3 |  |  | 4.8 |  |  | 18.3 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 31.6 |  |  | $ | 30.9 |  |  | $ | 141.0 |  |  | $ | 136.9 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, South America and the Kysor Warren business. |  |  |  |  |  |  |
| Reconciliation of Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  |  |  | For the Three Months Ended March 31, |
|  |  |  |  |  | 2019 |  | 2018 |
| Net cash used in operating activities, a GAAP measure |  |  |  |  | $ | (141.0 | ) |  | $ | (83.5 | ) |
| Purchases of property, plant and equipment |  |  |  |  | (37.2 | ) |  | (22.7 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  |  |  | 0.3 |  |  | 0.1 |  |
| Insurance recoveries received for property damage incurred from natural disaster |  |  |  |  | 6.9 |  |  | — |  |
| Free cash flow, a Non-GAAP measure |  |  |  |  | (171.0 | ) |  | (106.1 | ) |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to March 31, 2019 |
| Adjusted EBIT (b)(a) |  |  |  |  |  |  | $ | 568.5 |  |
| Depreciation and amortization expense (c) |  |  |  |  |  |  | 66.3 |  |
| EBITDA (b + c) |  |  |  |  |  |  | $ | 634.8 |  |
| Total debt at March 31, 2019 (d) |  |  |  |  |  |  | $ | 1,296.6 |  |
| Total Debt to EBITDA ratio ((d / (b + c)) |  |  |  |  |  |  | 2.0 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, South America and the Kysor Warren business. |  |  |  |  |  |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |
|  |  |  |  |  |  |  | Trailing Twelve Months to March 31, 2019 |
| Income from continuing operations before income taxes, a GAAP measure | $ | 506.9 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit | 8.1 |  |
| Restructuring charges | 2.6 |  |
| Interest expense, net | 40.8 |  |
| Pension settlement | 0.4 |  |
| Loss (gain), net on sale of businesses and related property | 23.4 |  |
| Gain from insurance recoveries, net of losses incurred | (17.9 | ) |
| Non-core business results (a) | 0.7 |  |
| Other expense (income), net | 3.5 |  |
| Adjusted EBIT per above, a Non-GAAP measure | $ | 568.5 |  |
| (a) Non-core business results represent activity related to our business operations in Australia, Asia, South America and the Kysor Warren business, not included elsewhere in the reconciliation. |
