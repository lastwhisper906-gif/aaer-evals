# LII note change history — 0001069202-18-000020 → 0001069202-19-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-04-22):
[0001069202-19-000021:note_history:1]
Leases

- added (2019-04-22):
[0001069202-19-000021:note_history:2]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). We adopted ASC 842 on January 1, 2019, using the effective date method, with the cumulative-effect adjustment to the opening balance sheet of retained earnings as of the effective date. The financial results reported in periods prior to January 1, 2019 are unchanged.  Upon adoption, we recognized almost all of our leases greater than one year in duration on the balance sheet as right-of-use assets and lease liabilities. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification is based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines. We have made certain assumptions in judgments when applying ASC 842.  Those judgments of most significance are as follows:

- added (2019-04-22):
[0001069202-19-000021:note_history:3]
| • | We elected the package of practical expedients available for transition which allow us to not reassess: |

- added (2019-04-22):
[0001069202-19-000021:note_history:4]
| ◦ | Whether expired or existing contracts contain leases under the new definition of a lease; |

- added (2019-04-22):
[0001069202-19-000021:note_history:5]
| ◦ | Lease classification for expired or existing leases; and |

- added (2019-04-22):
[0001069202-19-000021:note_history:6]
| ◦ | Whether previously capitalized initial direct costs would qualify for capitalization under ASC 842. |

- added (2019-04-22):
[0001069202-19-000021:note_history:7]
| • | We did not elect to use hindsight for transition when considering judgments and estimates such as assessments of lessee options to extend or terminate a lease or purchase the underlying asset. |

- added (2019-04-22):
[0001069202-19-000021:note_history:8]
| • | We did not elect to reassess whether land easements meet the definition of a lease if they were not accounted for as leases under the former rules. |

- added (2019-04-22):
[0001069202-19-000021:note_history:9]
| • | For all asset classes, we elected to not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. |

- added (2019-04-22):
[0001069202-19-000021:note_history:10]
| • | For all asset classes, we elected to not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component. |

- added (2019-04-22):
[0001069202-19-000021:note_history:11]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheet as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheet. Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

- added (2019-04-22):
[0001069202-19-000021:note_history:12]
Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

- added (2019-04-22):
[0001069202-19-000021:note_history:13]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

- added (2019-04-22):
[0001069202-19-000021:note_history:14]
We lease certain real and personal property under non-cancelable operating leases.  Approximately 80% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

- added (2019-04-22):
[0001069202-19-000021:note_history:15]
The components of lease expense were as follows (in millions):

- added (2019-04-22):
[0001069202-19-000021:note_history:16]
|  | For the Three Months Ended March 31, 2019 |
| Finance lease cost: |  |
| Amortization of right-of-use assets | $ | 1.5 |  |
| Interest on lease liabilities | 0.2 |  |
| Operating lease cost | 14.8 |  |
| Short-term lease cost | 1.1 |  |
| Variable lease cost | 4.5 |  |
| Total lease cost | $ | 22.1 |  |
| Other information |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |
| Operating cash flows from finance leases | $ | 1.0 |  |
| Operating cash flows from operating leases | $ | 12.7 |  |
| Financing cash flows from finance leases | $ | 1.6 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 3.2 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 16.6 |  |

- added (2019-04-22):
[0001069202-19-000021:note_history:17]
|  | As of March 31, 2019 |
| Finance lease right-of-use assets | 22.7 |  |
| Operating lease right-of-use assets | 170.1 |  |
| Finance lease liability, current | 6.3 |  |
| Finance lease liability, non-current | 22.3 |  |
| Operating lease liability, current | 48.1 |  |
| Operating lease liability, non-current | 122.6 |  |
| Weighted-average remaining lease term - finance leases | 5.46 years |  |
| Weighted-average remaining lease term - operating leases | 4.37 years |  |
| Weighted-average discount rate - finance leases | 2.23 | % |
| Weighted-average discount rate – operating leases | 4.05 | % |

- added (2019-04-22):
[0001069202-19-000021:note_history:18]
Future annual minimum lease payments and capital lease commitments as of March 31, 2019 were as follows (in millions):

- added (2019-04-22):
[0001069202-19-000021:note_history:19]
|  | Operating Leases |  | Finance Leases |
| 2019 (excluding the three months ended March 31, 2019) | $ | 41.5 |  |  | $ | 5.5 |  |
| 2020 | 48.4 |  |  | 6.3 |  |
| 2021 | 35.7 |  |  | 4.5 |  |
| 2022 | 24.5 |  |  | 2.7 |  |
| 2023 | 18.7 |  |  | 1.3 |  |
| 2024 and thereafter | 18.6 |  |  | 12.9 |  |
| Total minimum lease payments | $ | 187.4 |  |  | $ | 33.2 |  |
| Less imputed interest | (16.7 | ) |  | (4.6 | ) |
| Lease liability | $ | 170.7 |  |  | $ | 28.6 |  |

- added (2019-04-22):
[0001069202-19-000021:note_history:20]
The Company adopted ASU 2016-02 on January 1, 2019 as noted above, and as required, the following disclosure is provided for periods prior to adoption. Future annual minimum lease payments and capital lease commitments as of December 31, 2018 were as follows (in millions):

- added (2019-04-22):
[0001069202-19-000021:note_history:21]
|  | Operating Leases |  | Capital Leases |
| 2019 | $ | 47.4 |  |  | $ | 6.6 |  |
| 2020 | 38.4 |  |  | 5.4 |  |
| 2021 | 27.2 |  |  | 3.8 |  |
| 2022 | 17.9 |  |  | 2.1 |  |
| 2023 | 12.7 |  |  | 0.9 |  |
| Thereafter | 16.1 |  |  | 12.8 |  |
| Total minimum lease payments | $ | 159.7 |  |  | $ | 31.6 |  |
| Less amount representing interest |  |  | 2.1 |  |
| Present value of minimum payments |  |  | $ | 29.5 |  |

- added (2019-04-22):
[0001069202-19-000021:note_history:22]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024. The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, we are obligated to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance of $41.2 million, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 87% of the lease balance.  The headquarters lease is classified as an operating lease and its future annual minimum lease payments are included in the table above.

- added (2019-04-22):
[0001069202-19-000021:note_history:23]
Our obligations under the headquarters lease are secured by a pledge of our interest in the leased property.  The lease contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of March 31, 2019.

- changed (2019-04-22):
[0001069202-19-000021:note_history:24]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Accrued expenses | $ | 37.4 |  |  | $ | 37.9 |  |
| Other liabilities | 76.4 |  |  | 73.7 |  |
| Total warranty liability | $ | 113.8 |  |  | $ | 111.6 |  |
  (was, 2018-10-22, similarity 0.9716):
[0001069202-18-000020:note_history:24]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 36.6 |  |  | $ | 34.8 |  |
| Other liabilities | 73.6 |  |  | 75.1 |  |
| Total warranty liability | $ | 110.2 |  |  | $ | 109.9 |  |

- changed (2019-04-22):
[0001069202-19-000021:note_history:25]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2019 were as follows (in millions):
  (was, 2018-10-22, similarity 0.9416):
[0001069202-18-000020:note_history:25]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2018 were as follows (in millions):

- changed (2019-04-22):
[0001069202-19-000021:note_history:26]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Warranty claims paid | (5.9 | ) |
| Changes resulting from issuance of new warranties | 8.7 |  |
| Warranty liability from divestitures | (0.6 | ) |
| Total warranty liability as of March 31, 2019 | $ | 113.8 |  |
  (was, 2018-10-22, similarity 0.6879):
[0001069202-18-000020:note_history:26]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (23.9 | ) |
| Changes resulting from issuance of new warranties | 29.0 |  |
| Changes in estimates associated with pre-existing liabilities | (3.1 | ) |
| Changes in foreign currency translation rates and other | (0.4 | ) |
| Warranty liability from Divestitures | (1.3 | ) |
| Total warranty liability as of September 30, 2018 | $ | 110.2 |  |

- changed (2019-04-22):
[0001069202-19-000021:note_history:27]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.
  (was, 2018-10-22, similarity 0.9977):
[0001069202-18-000020:note_history:27]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above.  Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities, for such quality related issues, are not material.

- changed (2019-04-22):
[0001069202-19-000021:note_history:28]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2019 and 2018, expense for asbestos-related litigation was $1.4 million and $2.1 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.
  (was, 2018-10-22, similarity 0.9115):
[0001069202-18-000020:note_history:28]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2018 and 2017, expense for asbestos-related litigation was $3.3 million and $3.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.  For the three months ended  September 30, 2018 and 2017, expense for asbestos-related litigation was $1.4 million and $1.5 million, respectively, net of probable insurance recoveries.

- changed (2019-04-22):
[0001069202-19-000021:note_history:29]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  We have insurance for the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Gain from insurance recoveries, net of losses incurred and Insurance proceeds for lost profits in the Consolidated Statements of Operations.
  (was, 2018-10-22, similarity 0.7295):
[0001069202-18-000020:note_history:29]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the full amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Loss from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations.

- changed (2019-04-22):
[0001069202-19-000021:note_history:30]
The following table summarizes the Gain from insurance recoveries, net of losses incurred:
  (was, 2018-10-22, similarity 0.6851):
[0001069202-18-000020:note_history:30]
The following table summarizes the loss from natural disaster, net of insurance recoveries:

- added (2019-04-22):
[0001069202-19-000021:note_history:31]
| (Amounts in millions) | For the Three months Ended March 31, 2019 |
| Insurance recoveries received | $ | 76.0 |  |
| Less losses and expenses incurred: |  |
| Site clean-up and remediation | 17.1 |  |
| Factory inefficiencies due to lower productivity | 4.0 |  |
| Other | 8.5 |  |
| Total losses and expenses | $ | 29.6 |  |
| Total gain from insurance recoveries | $ | 46.4 |  |
| Presentation in the Consolidated Statements of Operations: |  |
| Gain from insurance recoveries, net of losses incurred | $ | (6.9 | ) |
| Insurance proceeds for lost profits | $ | (39.5 | ) |

- removed (2019-04-22):
[0001069202-18-000020:note_history:32]
| (Amounts in millions) | For the Nine Months Ended September 30, 2018 |
| Write-off of property, plant and equipment | $ | 4.2 |  |
| Write-off of inventory | 5.2 |  |
| Site clean-up and remediation | 28.4 |  |
| Factory inefficiencies due to lower productivity | 4.9 |  |
| Other | 6.7 |  |
| Total expense | 49.4 |  |
| Insurance recoveries received | 45.0 |  |
| Insurance recoveries receivable (1) | 4.1 |  |
| Loss from natural disaster, net of insurance recoveries | $ | 0.3 |  |

- removed (2019-04-22):
[0001069202-18-000020:note_history:33]
(1) The insurance recoveries receivable is recorded in Other assets in the Consolidated Balance Sheets.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-04-22):
[0001069202-19-000021:note_history:34]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2019, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2019 and 2018, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2019 and 2018, the accompanying unaudited Consolidated Statements of Stockholders' (Deficit) Equity for the three months ended March 31, 2019 and 2018, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2019 and 2018 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2018. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2018-10-22, similarity 0.9059):
[0001069202-18-000020:note_history:34]
The accompanying unaudited Consolidated Balance Sheet as of  September 30, 2018, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2019-04-22):
[0001069202-19-000021:note_history:35]
In August 2018, the SEC issued Release No. 33-10532 that amends and clarifies certain financial reporting requirements.  The principal change to our financial reporting is the inclusion of the annual disclosure requirement of changes in stockholders’ equity in Rule 3-04 of Regulation S-X to interim periods.
  (was, 2018-10-22, similarity 0.7186):
[0001069202-18-000020:note_history:35]
In August 2018, the SEC issued Release No. 33-10532 that amends and clarifies certain financial reporting requirements.  The principal change to our financial reporting will be the inclusion of the annual disclosure requirement of changes in stockholders’ equity in Rule 3-04 of Regulation S-X to interim periods.  We will adopt this new rule beginning with our financial reporting for the quarter ended March 31, 2019.  Upon adoption, we will include our Consolidated Statements of Stockholders' Equity with each quarterly filing on Form 10-Q.

- removed (2019-04-22):
[0001069202-18-000020:note_history:36]
In August 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees. For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017. This standard did not have a material impact on our consolidated financial statements.

- removed (2019-04-22):
[0001069202-18-000020:note_history:37]
Recent Accounting Pronouncements

- removed (2019-04-22):
[0001069202-18-000020:note_history:38]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.  We will adopt the standard using the prospective approach.  We have completed a qualitative and quantitative assessment of our lease portfolio and are in the process of testing our new lease accounting system, collecting data for leases entered into during 2018 and implementing new processes and controls to account for our leases in accordance with the new standard.  Upon adoption, we expect to record right-of-use assets and operating lease liabilities between $150 million and $200 million in our Consolidated Balance Sheet.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-04-22):
[0001069202-19-000021:note_history:39]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.68 | % |  | 3.74 | % |
  (was, 2018-10-22, similarity 0.95):
[0001069202-18-000020:note_history:39]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.41 | % |  | 2.76 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-04-22):
[0001069202-19-000021:note_history:40]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 224.5 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.3 |  |  | $ | 3.5 |  |
| Domestic credit facility | 7.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.7 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 237.6 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 22.3 |  |  | 15.7 |  |
| Domestic credit facility | 689.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.8 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,059.0 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,296.6 |  |  | $ | 1,041.3 |  |

- added (2019-04-22):
[0001069202-19-000021:note_history:41]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2019 or December 31, 2018.  There were no proceeds or repayments on these facilities for the three months ended March 31, 2019.  Proceeds and repayments on these facilities were $0.3 million and $0.4 million, respectively, for the three months ended March 31, 2018.

- changed (2019-04-22):
[0001069202-19-000021:note_history:42]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.  The ASP will expire in November 2019 and we intend to renew the ASP prior to its expiration.
  (was, 2018-10-22, similarity 0.9639):
[0001069202-18-000020:note_history:42]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

- added (2019-04-22):
[0001069202-19-000021:note_history:43]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 225.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (224.5 | ) |  | (268.0 | ) |
| Remaining amount available | $ | 0.5 |  |  | $ | 22.0 |  |

- changed (2019-04-22):
[0001069202-19-000021:note_history:44]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2019 and December 31, 2018 were 3.26% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2018-10-22, similarity 0.9907):
[0001069202-18-000020:note_history:44]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2018 and December 31, 2017 were 2.98% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2019-04-22):
[0001069202-19-000021:note_history:45]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of March 31, 2019, we believe we were in compliance with all covenant requirements.
  (was, 2018-10-22, similarity 0.9873):
[0001069202-18-000020:note_history:45]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of September 30, 2018, we believe we were in compliance with all covenant requirements.

- changed (2019-04-22):
[0001069202-19-000021:note_history:46]
On January 22, 2019, we amended our credit facility with the Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $190.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $697.0 million, of which $160.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of March 31, 2019. Subject to covenant limitations, $460.5 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.
  (was, 2018-10-22, similarity 0.6145):
[0001069202-18-000020:note_history:46]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $390.5 million, of which $190.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of September 30, 2018. Subject to covenant limitations, $447.0 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2019-04-22):
[0001069202-19-000021:note_history:47]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.68 | % |  | 3.74 | % |
  (was, 2018-10-22, similarity 0.95):
[0001069202-18-000020:note_history:47]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.41 | % |  | 2.76 | % |

- changed (2019-04-22):
[0001069202-19-000021:note_history:48]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due
  (was, 2018-10-22, similarity 0.8246):
[0001069202-18-000020:note_history:48]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2018, we believe we were in compliance with all covenant requirements.

- added (2019-04-22):
[0001069202-19-000021:note_history:49]
and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2019, we believe we were in compliance with all covenant requirements.

- changed (2019-04-22):
[0001069202-19-000021:note_history:50]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2019, we believe we were in compliance with all covenant requirements.
  (was, 2018-10-22, similarity 0.9929):
[0001069202-18-000020:note_history:50]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2018, we believe we were in compliance with all covenant requirements.

- removed (2019-04-22):
[0001069202-18-000020:note_history:51]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | — |  |  | $ | 0.9 |  |
| Total short-term debt | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 22.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 22.3 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 377.3 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 368.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.6 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,103.6 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,125.9 |  |  | $ | 1,004.0 |  |

- removed (2019-04-22):
[0001069202-18-000020:note_history:52]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $0.0 million and $0.9 million of foreign obligations outstanding as of September 30, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $40.2 million  and $19.1 million during the nine months ended September 30, 2018 and 2017, respectively. Repayments on the facilities were $38.5 million and $20.5 million during the nine months ended September 30, 2018 and 2017, respectively.

- removed (2019-04-22):
[0001069202-18-000020:note_history:53]
|  | September 30, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 380.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (377.3 | ) |  | (276.0 | ) |
| Remaining amount available | $ | 2.7 |  |  | $ | 14.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-04-22):
[0001069202-19-000021:note_history:54]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 224.5 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.3 |  |  | $ | 3.5 |  |
| Domestic credit facility | 7.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.7 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 237.6 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 22.3 |  |  | 15.7 |  |
| Domestic credit facility | 689.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.8 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,059.0 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,296.6 |  |  | $ | 1,041.3 |  |

- removed (2019-04-22):
[0001069202-18-000020:note_history:55]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | — |  |  | $ | 0.9 |  |
| Total short-term debt | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 22.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 22.3 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 377.3 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 368.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.6 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,103.6 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,125.9 |  |  | $ | 1,004.0 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-04-22):
[0001069202-19-000021:note_history:56]
|  | For the Three Months Ended March 31, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 433.2 |  |  | $ | 157.3 |  |  | $ | 91.6 |  |  | $ | 682.1 |  |
| Canada | 32.4 |  |  | 15.9 |  |  | 0.7 |  |  | 49.0 |  |
| International | — |  |  | 0.1 |  |  | 59.1 |  |  | 59.2 |  |
| Total | $ | 465.6 |  |  | 173.3 |  |  | 151.4 |  |  | 790.3 |  |
  (was, 2018-10-22, similarity 0.6938):
[0001069202-18-000020:note_history:56]
|  | For the Three Months Ended September 30,2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 594.7 |  |  | $ | 236.9 |  |  | $ | 132.0 |  |  | $ | 963.6 |  |
| Europe | — |  |  | 38.9 |  |  | 27.7 |  |  | 66.6 |  |
| Total | $ | 594.7 |  |  | 275.8 |  |  | 159.7 |  |  | 1,030.2 |  |

- added (2019-04-22):
[0001069202-19-000021:note_history:57]
|  | For the Three Months Ended March 31, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 423.5 |  |  | $ | 162.3 |  |  | $ | 95.7 |  |  | $ | 681.5 |  |
| Canada | 30.2 |  |  | 16.7 |  |  | 0.9 |  |  | 47.8 |  |
| International | — |  |  | 0.1 |  |  | 105.4 |  |  | 105.5 |  |
| Total | $ | 453.7 |  |  | 179.1 |  |  | 202.0 |  |  | 834.8 |  |

- changed (2019-04-22):
[0001069202-19-000021:note_history:58]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the segment, for the three months ended March 31, 2019 and 2018, direct sales represent approximately $334.7 million and $339.5 million of revenues, and sales to independent distributors represent approximately $130.9 million and $114.2 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2018-10-22, similarity 0.966):
[0001069202-18-000020:note_history:58]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment, for the three and nine months ended September 30, 2018, direct sales represent approximately $459.9 million and $1,346.2 million of revenues and sales to independent distributors represent approximately $134.8 million and $418.2 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2019-04-22):
[0001069202-19-000021:note_history:59]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.    For the segment, for the three months ended March 31, 2019 and 2018, equipment sales represent approximately $143.5 million and $151.5 million of revenues while $29.8 million and $27.6 million of our revenue is generated from our service business, respectively.
  (was, 2018-10-22, similarity 0.9405):
[0001069202-18-000020:note_history:59]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, for the three and nine months ended September 30, 2018, equipment sales represent approximately $242.6 million and $679.2 million of revenues while $33.2 million and $94.3 million of our revenue is generated from our service business, respectively.

- changed (2019-04-22):
[0001069202-19-000021:note_history:60]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems.  Revenue for the products sold is $148.9 million and $200.0 million for the three months ended March 31, 2019 and 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.
  (was, 2018-10-22, similarity 0.9022):
[0001069202-18-000020:note_history:60]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $156.8 million and $495.8 million for the three and nine months ended September 30, 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

- changed (2019-04-22):
[0001069202-19-000021:note_history:61]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or
  (was, 2018-10-22, similarity 0.7502):
[0001069202-18-000020:note_history:61]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

- added (2019-04-22):
[0001069202-19-000021:note_history:62]
services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

- changed (2019-04-22):
[0001069202-19-000021:note_history:63]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets, net in our Consolidated Balance Sheet.
  (was, 2018-10-22, similarity 0.9948):
[0001069202-18-000020:note_history:63]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheet.

- changed (2019-04-22):
[0001069202-19-000021:note_history:64]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheet.
  (was, 2018-10-22, similarity 0.9791):
[0001069202-18-000020:note_history:64]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accounts payable in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheet.

- changed (2019-04-22):
[0001069202-19-000021:note_history:65]
|  | March 31, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (5.4 | ) |  | (13.0 | ) |  | 7.6 |  |  | (58.5 | )% |
| Contract liabilities - noncurrent | (5.7 | ) |  | (5.9 | ) |  | 0.2 |  |  | (3.4 | )% |
| Total | $ | (11.1 | ) |  | $ | (16.4 | ) |  | $ | 5.3 |  |  |  |
  (was, 2018-10-22, similarity 0.7771):
[0001069202-18-000020:note_history:65]
|  | September 30, 2018 |  | December 31, 2017 |  | $ Change |  | % Change |
| Contract assets | $ | 3.5 |  |  | $ | 2.1 |  |  | $ | 1.4 |  |  | 66.7 | % |
| Contract liabilities - current | (6.2 | ) |  | (7.3 | ) |  | 1.1 |  |  | (15.1 | )% |
| Contract liabilities - noncurrent | (6.0 | ) |  | (5.5 | ) |  | (0.5 | ) |  | 9.1 | % |
| Total | $ | (8.7 | ) |  | $ | (10.7 | ) |  | $ | 2.0 |  |  |  |

- changed (2019-04-22):
[0001069202-19-000021:note_history:66]
For the three months ended March 31, 2019 and 2018, we recognized revenue of $1.1 million and $1.6 million related to our contract liabilities at January 1, 2019 and  2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the first quarter of 2019 and 2018.
  (was, 2018-10-22, similarity 0.8108):
[0001069202-18-000020:note_history:66]
For the three and nine months ended September 30, 2018, we recognized revenue of $1.3 million and $4.2 million related to our contract liabilities at January 1, 2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the third quarter of 2018.

- removed (2019-04-22):
[0001069202-18-000020:note_history:67]
On January 1, 2018, we adopted the new accounting standard ASC 606, Revenue from Contracts with Customers and all the related amendments (“the new revenue standard”) and applied it to all contracts using the modified retrospective method.  We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings.  The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.  We expect the impact of the adoption of the new standard to be immaterial to our net income on an ongoing basis.

- removed (2019-04-22):
[0001069202-18-000020:note_history:68]
The cumulative effect of the changes made to our consolidated January 1, 2018 balance sheet for the adoption of the new revenue standard was as follows (in millions):

- removed (2019-04-22):
[0001069202-18-000020:note_history:69]
| BALANCE SHEET | Balance at December 31, 2017 |  | Adjustments Due to ASC 606 |  | Balance at January 1, 2018 |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 506.5 |  |  | $ | 8.3 |  |  | $ | 514.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 348.6 |  |  | 9.3 |  |  | 357.9 |  |
| Retained earnings | 1,575.9 |  |  | (1.0 | ) |  | 1,574.9 |  |

- removed (2019-04-22):
[0001069202-18-000020:note_history:70]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption on our Consolidated Balance Sheet and Consolidated Statement of Operations was as follows (in millions):

- removed (2019-04-22):
[0001069202-18-000020:note_history:71]
|  | September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 580.9 |  |  | $ | 572.4 |  |  | $ | 8.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 371.6 |  |  | 361.4 |  |  | 10.2 |  |
| Retained earnings | 1,805.0 |  |  | 1,806.7 |  |  | (1.7 | ) |
|  | For the Three Months Ended September 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 1,030.2 |  |  | $ | 1,030.2 |  |  | $ | — |  |
| Net income | 108.0 |  |  | 108.1 |  |  | (0.1 | ) |

- removed (2019-04-22):
[0001069202-18-000020:note_history:72]
|  | For the Nine Months Ended September 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 3,040.4 |  |  | $ | 3,040.6 |  |  | $ | (0.2 | ) |
| Net income | 283.4 |  |  | 283.5 |  |  | (0.1 | ) |

- removed (2019-04-22):
[0001069202-18-000020:note_history:73]
|  | For the Nine Months Ended September 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 1,764.4 |  |  | $ | 668.1 |  |  | $ | 369.4 |  |  | $ | 2,801.9 |  |
| Europe | — |  |  | 105.4 |  |  | 83.4 |  |  | 188.8 |  |
| Asia Pacific | — |  |  | — |  |  | 49.7 |  |  | 49.7 |  |
| Total | $ | 1,764.4 |  |  | 773.5 |  |  | 502.5 |  |  | 3,040.4 |  |

- removed (2019-04-22):
[0001069202-18-000020:note_history:74]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.

- removed (2019-04-22):
[0001069202-18-000020:note_history:75]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  See Note 7 for more information on product warranties.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-04-22):
[0001069202-19-000021:note_history:76]
Subsequent Event:

- added (2019-04-22):
[0001069202-19-000021:note_history:77]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and the related benefit obligations.  This transaction required a remeasurement of the pension plan and we expect to recognize a $61.0 million non-cash pension settlement pre-tax loss in the second quarter of 2019 for this remeasurement.
