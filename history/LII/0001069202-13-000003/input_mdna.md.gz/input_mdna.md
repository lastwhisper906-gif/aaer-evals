# LII MD&A — 0001069202-13-000003


## mdna

[0001069202-13-000003:mdna:1]
Item 7.  Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-13-000003:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the consolidated financial statements and related notes contained in Item 8 of this Annual Report on Form 10-K.

[0001069202-13-000003:mdna:3]
Overview

[0001069202-13-000003:mdna:4]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 19 in the Notes to Consolidated Financial Statements.

[0001069202-13-000003:mdna:5]
Our products and services are sold through a combination of direct sales, distributors and company-owned parts and supplies stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate strong demand for replacement air conditioning and refrigeration products and services and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-13-000003:mdna:6]
The principal elements of cost of goods sold in our manufacturing operations are components, raw materials, factory overhead, labor and estimated costs of warranty expense.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components have impacted us and the HVACR industry in general.  We seek to mitigate the impact of higher commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-13-000003:mdna:7]
In 2012, our Residential Heating & Cooling segment led our overall operational improvement with a 9% increase in net sales and $15 million in increased segment profit compared to 2011.  The primary growth drivers for this segment can be attributed to industry growth and market share gains in our new construction and replacement businesses during the year.  Our Commercial Heating & Cooling segment also performed well in 2012 with a 1% increase in net sales, or 3% increase when excluding a 2%

[0001069202-13-000003:mdna:8]
unfavorable foreign currency impact, and $12 million in increased segment profit compared to 2011.  This segment's profits were up largely due to improved product profit margins that were driven by volume increases, favorable price and mix and productivity initiatives.  Sales in our Refrigeration segment were down 2% compared to 2011, or flat when excluding a 2% unfavorable currency impact.  However, this segment's profit increased $4 million compared to 2011 from improved product profit margins that were driven primarily by favorable price and mix.

[0001069202-13-000003:mdna:9]
Overall, our product profit margins improved due to volume increases, primarily in our Residential Heating & Cooling segment, as well as favorable commodity pricing on raw materials and other material cost savings.  We continue to manage our pricing structure by utilizing a combination of commodity hedging practices and controllable cost management practices through manufacturing, sourcing and engineering initiatives designed to reduce our product costs.

[0001069202-13-000003:mdna:10]
In September 2012, the Company announced the planned sale of its Service Experts business. The Service Experts business had previously been reported within the Company’s Service Experts segment along with a commercial service business called Lennox National Account Services (NAS).  Beginning in the third quarter of 2012, the Service Experts business was included in discontinued operations,  NAS was included in the Company's Commercial Heating & Cooling segment, and the Service Experts reportable segment was eliminated. Results for all periods have been revised to conform with this new presentation.

[0001069202-13-000003:mdna:11]
In April 2012, the Company sold its Hearth business to Comvest Investment Partners IV in an all cash transaction for $10.1 million in net proceeds, which excludes the transaction costs and cash transferred with the business.  The loss on sale and the operating results for the Hearth business are presented as discontinued operations.

[0001069202-13-000003:mdna:12]
Company Highlights

[0001069202-13-000003:mdna:13]
| • | Net sales increased approximately $109 million, or 4%, from $2,841 million in 2011 to $2,949 million in 2012. Excluding the impact from unfavorable foreign currency exchange rates, net sales increased 5%. |

[0001069202-13-000003:mdna:14]
| • | Operational income from continuing operations for 2012 was $219 million compared to $184 million for 2011. The increase was primarily due to higher volumes, higher margins from material cost savings and a reduction in restructuring costs as cost saving initiatives wind down. |

[0001069202-13-000003:mdna:15]
| • | Net income for 2012 was $90 million compared to $88 million in 2011. |

[0001069202-13-000003:mdna:16]
| • | Diluted earnings per share from continuing operations were $2.63 per share in 2012 compared to $2.09 per share in 2011. |

[0001069202-13-000003:mdna:17]
| • | We generated $221 million of cash flow from operating activities in 2012 compared to $76 million in 2011. |

[0001069202-13-000003:mdna:18]
| • | In 2012, we returned $50 million to shareholders through share repurchases and $48 million through dividend payments. |

[0001069202-13-000003:mdna:19]
Results of Operations

[0001069202-13-000003:mdna:20]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-13-000003:mdna:21]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 2,949.4 |  |  | 100.0 | % |  | $ | 2,840.9 |  |  | 100.0 | % |  | $ | 2,585.2 |  |  | 100.0 | % |
| Cost of goods sold | 2,227.1 |  |  | 75.5 | % |  | 2,171.0 |  |  | 76.4 | % |  | 1,884.0 |  |  | 72.9 | % |
| Gross profit | 722.3 |  |  | 24.5 | % |  | 669.9 |  |  | 23.6 | % |  | 701.2 |  |  | 27.1 | % |
| Selling, general and administrative expenses | 507.0 |  |  | 17.2 | % |  | 476.9 |  |  | 16.8 | % |  | 492.0 |  |  | 19.0 | % |
| Losses and other expenses, net | 2.5 |  |  | 0.1 | % |  | 5.7 |  |  | 0.2 | % |  | 3.4 |  |  | 0.1 | % |
| Restructuring charges | 4.2 |  |  | 0.1 | % |  | 12.5 |  |  | 0.4 | % |  | 11.4 |  |  | 0.4 | % |
| Income from equity method investments | (10.5 | ) |  | (0.4 | )% |  | (9.6 | ) |  | (0.3 | )% |  | (10.1 | ) |  | (0.4 | )% |
| Operational income from continuing operations | $ | 219.1 |  |  | 7.4 | % |  | $ | 184.4 |  |  | 6.5 | % |  | $ | 204.5 |  |  | 7.9 | % |
| Loss from discontinued operations | (45.0 | ) |  | (1.5 | )% |  | (23.2 | ) |  | (0.8 | )% |  | (9.7 | ) |  | (0.4 | )% |
| Net income | $ | 90.0 |  |  | 3.1 | % |  | $ | 88.3 |  |  | 3.1 | % |  | $ | 116.2 |  |  | 4.5 | % |

[0001069202-13-000003:mdna:22]
The following table sets forth net sales by geographic market (dollars in millions):

[0001069202-13-000003:mdna:23]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Geographic Market: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. | $ | 2,147.2 |  |  | 72.8 | % |  | $ | 2,018.1 |  |  | 71.0 | % |  | $ | 1,866.4 |  |  | 72.2 | % |
| Canada | 226.7 |  |  | 7.7 |  |  | 219.2 |  |  | 7.8 |  |  | 214.5 |  |  | 8.3 |  |
| International | 575.5 |  |  | 19.5 |  |  | 603.6 |  |  | 21.2 |  |  | 504.3 |  |  | 19.5 |  |
| Total net sales | $ | 2,949.4 |  |  | 100.0 | % |  | $ | 2,840.9 |  |  | 100.0 | % |  | $ | 2,585.2 |  |  | 100.0 | % |

[0001069202-13-000003:mdna:24]
Year Ended December 31, 2012 Compared to Year Ended December 31, 2011 - Consolidated Results

[0001069202-13-000003:mdna:25]
Net Sales

[0001069202-13-000003:mdna:26]
Net sales increased 4% in 2012 compared to 2011, or increased by 5% when excluding the 1% unfavorable impact from changes in foreign currency exchange rates.  Our sales volume was up 5% and price and mix were flat from the comparable period.  The increase in volume was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  Increases in price and mix at our Commercial Heating & Cooling and Refrigeration segments were largely offset by a decrease in price and mix at our Residential Heating & Cooling segments.

[0001069202-13-000003:mdna:27]
Gross Profit

[0001069202-13-000003:mdna:28]
Gross profit margins improved 90 basis points to 24.5% in 2012 compared to 23.6% in 2011.  Improved price and mix contributed 50 basis points to profit margin and improved commodity and non-commodity material costs contributed a collective 90 basis points over 2011.  Partially offsetting these increases were 50 basis points of higher freight and distribution costs.

[0001069202-13-000003:mdna:29]
Selling, General and Administrative Expenses

[0001069202-13-000003:mdna:30]
Selling, General & Administrative (“SG&A”) expenses increased by $30 million in 2012 compared to 2011, and as a percentage of net sales, SG&A expenses increased 40 basis points from 16.8% in 2011 to 17.2% in 2012.  The increase in SG&A expenses was principally due to higher incentive compensation due to overall improved operating results in 2012.

[0001069202-13-000003:mdna:31]
Losses and Other Expenses, Net

[0001069202-13-000003:mdna:32]
Losses and other expenses, net for 2012 and 2011 included the following (in millions):

[0001069202-13-000003:mdna:33]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |
| Realized losses (gains) on settled futures contracts | $ | 1.5 |  |  | $ | (0.1 | ) |
| Foreign currency exchange losses | 0.8 |  |  | 1.4 |  |
| Loss (gain) on disposal of fixed assets | 0.4 |  |  | (0.8 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts | (2.2 | ) |  | 3.8 |  |
| Acquisition expenses | 0.1 |  |  | 1.0 |  |
| Special legal contingency charge | 1.2 |  |  | — |  |
| Other items, net | 0.7 |  |  | 0.4 |  |
| Losses and other expenses, net | $ | 2.5 |  |  | $ | 5.7 |  |

[0001069202-13-000003:mdna:34]
The change in realized gains and losses on settled futures contracts in 2012 was attributable to decreases in commodity prices relative to our futures contract prices.  Conversely, the change in unrealized gains on unsettled futures contracts was primarily due to higher commodity prices relative to the futures contract prices.  For more information on our derivatives, see Note 9 in the Notes to the Consolidated Financial Statements.  The special legal contingency charge in 2012 relates primarily to ongoing patent litigation.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on this litigation.

[0001069202-13-000003:mdna:35]
Restructuring Charges

[0001069202-13-000003:mdna:36]
Restructuring charges were $4 million in 2012 compared to $13 million in 2011.  We did not initiate any new large projects in 2012 and the charges during the year related primarily to our Regional Distribution Network project.  The restructuring charges in 2011 were primarily from corporate restructuring charges that included the termination of our corporate airplane lease, closure of our aviation department, and reorganization of certain support functions.  Refer to Note 16 in the Notes to the Consolidated Financial Statements for more information.

[0001069202-13-000003:mdna:37]
Income from Equity Method Investments

[0001069202-13-000003:mdna:38]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments increased slightly to $11 million in 2012 compared to $10 million in 2011 primarily due to improved operational performance from our joint ventures.

[0001069202-13-000003:mdna:39]
Interest Expense, net

[0001069202-13-000003:mdna:40]
Interest expense, net of $17 million in 2012 was flat compared to 2011.  Similarly, our weighted average interest rates and weighted average borrowings were relatively flat.

[0001069202-13-000003:mdna:41]
Income Taxes

[0001069202-13-000003:mdna:42]
The income tax provision was $67 million in 2012 compared to $56 million in 2011 and the effective tax rate was 33.1% for 2012 compared to 33.4% for 2011.  Our effective rates differ from the statutory federal rate of 35% for certain items, such as tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-13-000003:mdna:43]
Loss from Discontinued Operations

[0001069202-13-000003:mdna:44]
The loss from discontinued operations relates to the Service Experts business, which we announced plans to sell in September 2012, and the Hearth business, which we sold in April 2012.  The Service Experts business had a pre-tax loss of $51 million in 2012 compared to a pre-tax loss of $11 million in 2011.  The pre-tax loss from discontinued operations in 2012 included operating losses of $28 million, goodwill impairment of $21 million, and $2 million of restructuring and other expenses.  The pre-tax loss  in 2011 included operating losses of $7 million and restructuring expenses of $4 million.

[0001069202-13-000003:mdna:45]
The Hearth business had a pre-tax loss in discontinued operations of $14 million in 2012 compared to a pre-tax loss of $26 million in 2011.  The pre-tax loss in 2012 included $3 million of operating losses, a $6 million charge to write down the related assets to their fair value, a $6 million pension settlement charge for the realization of pension losses related to the transfer of a pension obligation to the buyer, a $1 million loss on the sale of the business, $2 million of other expenses and a $4 million gain for the realization of foreign currency translation adjustments.  The pre-tax loss in 2011 included operating losses of $12 million and goodwill and long-lived asset impairments of $7 million each.

[0001069202-13-000003:mdna:46]
Year Ended December 31, 2012 Compared to Year Ended December 31, 2011 - Results by Segment

[0001069202-13-000003:mdna:47]
Residential Heating & Cooling

[0001069202-13-000003:mdna:48]
The following table details our Residential Heating & Cooling segment's net sales and profit for 2012 and 2011 (dollars in millions):

[0001069202-13-000003:mdna:49]
|  | Years Ended December 31, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 1,375.8 |  |  | $ | 1,259.5 |  |  | $ | 116.3 |  |  | 9.2 | % |
| Profit | $ | 102.9 |  |  | $ | 87.6 |  |  | $ | 15.3 |  |  | 17.5 | % |
| % of net sales | 7.5 | % |  | 7.0 | % |  |  |  |  |

[0001069202-13-000003:mdna:50]
Residential Heating & Cooling net sales increased by 9% in 2012 compared to 2011.  Sales volumes increased by 11% in 2012 and were partially offset by lower sales mix of 2%.  The increase in sales volumes was attributable to industry growth and market share gains in our new construction and replacement businesses during the year.  Sales mix was negatively affected by the growth

[0001069202-13-000003:mdna:51]
in the new construction business, which generally trends towards lower efficiency products.

[0001069202-13-000003:mdna:52]
Segment profit for 2012 increased $15 million due to $40 million in higher sales volumes, $16 million in material cost savings and $4 million in favorable pricing.  Partially offsetting these increases were $25 million in unfavorable mix, $13 million in higher SG&A costs due primarily to higher incentive compensation from improved operating results in 2012, and higher freight and distribution expenses of $7 million due to continued investment in distribution initiatives.

[0001069202-13-000003:mdna:53]
Commercial Heating & Cooling

[0001069202-13-000003:mdna:54]
The following table details our Commercial Heating & Cooling segment's net sales and profit for 2012 and 2011 (dollars in millions):

[0001069202-13-000003:mdna:55]
|  | Years Ended December 31, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 785.4 |  |  | $ | 776.2 |  |  | $ | 9.2 |  |  | 1.2 | % |
| Profit | $ | 99.5 |  |  | $ | 87.6 |  |  | $ | 11.9 |  |  | 13.6 | % |
| % of net sales | 12.7 | % |  | 11.3 | % |  |  |  |  |

[0001069202-13-000003:mdna:56]
Commercial Heating & Cooling net sales increased 1% in 2012 compared to 2011, or increased 3% when excluding the 2% unfavorable impact from foreign currency exchange rates.  Sales volumes increased 2% and price and mix increased by 1%.  Sales volume growth was somewhat muted during the second half of 2012 as certain customers slowed order rates due to broad economic uncertainties.

[0001069202-13-000003:mdna:57]
Segment profit in 2012 increased $12 million compared to 2011, with increases of $5 million for higher sales volumes, $11 million for favorable price and mix and $5 million for productivity initiatives.  Partially offsetting these increases were $5 million in higher SG&A expenses due primarily to higher incentive compensation and higher freight and distribution expenses of $4 million.

[0001069202-13-000003:mdna:58]
Refrigeration

[0001069202-13-000003:mdna:59]
The following table details our Refrigeration segment's net sales and profit for 2012 and 2011 (dollars in millions):

[0001069202-13-000003:mdna:60]
|  | Years Ended December 31, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 788.2 |  |  | $ | 805.2 |  |  | $ | (17.0 | ) |  | (2.1 | )% |
| Profit | $ | 81.9 |  |  | $ | 77.5 |  |  | $ | 4.4 |  |  | 5.7 | % |
| % of net sales | 10.4 | % |  | 9.6 | % |  |  |  |  |

[0001069202-13-000003:mdna:61]
Net sales decreased by 2% in 2012 compared to 2011, or were flat excluding the 2% unfavorable impact from foreign currency exchange rates.  Price and mix improvements of approximately 3% were offset by volume declines of 3%.   Sales volumes were challenged in the second half of 2012 as we experienced some slowing in our European refrigeration markets as well as some customers pushing out orders due to broad economic uncertainties.

[0001069202-13-000003:mdna:62]
Segment profit for 2012 increased $4 million over 2011, with increases of $14 million from growth in our distribution business in Australia and overall favorable price and mix, and increases of approximately $5 million in material and other cost savings.  Partially offsetting these increases were volume declines of $4 million, higher freight and distribution costs of $2 million, and higher SG&A expenses of $9 million due primarily to higher incentive compensation.

[0001069202-13-000003:mdna:63]
Corporate and Other

[0001069202-13-000003:mdna:64]
Corporate and other expenses increased $5 million to $60 million in 2012 from $55 million in 2011.  The increase was driven by a $12 million increase in incentive compensation due to improved overall operating results that was partially offset by a $7 million reduction in self-insurance costs.

[0001069202-13-000003:mdna:65]
Year Ended December 31, 2011 Compared to Year Ended December 31, 2010 - Consolidated Results

[0001069202-13-000003:mdna:66]
Net Sales

[0001069202-13-000003:mdna:67]
Net sales increased 10% in 2011 as compared to 2010.  Excluding the impact of the Kysor/Warren acquisition in January 2011, our net sales were up 2%.  Our price and mix were up 1% while sales volume was down 1%.  The decline in volume was predominantly in our Residential Heating & Cooling segment, partially offset by volume growth in our Commercial Heating & Cooling segment.  Changes in foreign currency exchange rates favorably impacted net sales by 2%.  Excluding the favorable impacts of the Kysor/Warren acquisition and foreign currency exchange rates, our net sales were flat compared to 2010.

[0001069202-13-000003:mdna:68]
Gross Profit

[0001069202-13-000003:mdna:69]
Gross profit margins declined $31 million, or 350 basis points, from 27.1% in 2010 to 23.6% in 2011.  The unfavorable impact of higher commodity costs for raw material and components contributed approximately 160 basis points to the decline, and freight and distribution costs contributed another 70 basis points to the decline.  Price and mix were neutral to gross profit as our price increases in 2011 offset the margin declines in product mix.  Additionally, the Kysor/Warren acquisition has negatively impacted our gross profit margin by approximately 120 basis points in 2011 due to lower margins for this business as compared to our other Refrigeration businesses.

[0001069202-13-000003:mdna:70]
Selling, General and Administrative Expenses

[0001069202-13-000003:mdna:71]
SG&A expenses decreased by $15 million in 2011 compared to 2010.  As a percentage of sales, SG&A expenses declined from 19% in 2010 to 17% in 2011.  Excluding the Kysor/Warren acquisition, the decrease in SG&A expenses was principally due to a $24 million decline in variable compensation as well as $9 million from general cost control initiatives.

[0001069202-13-000003:mdna:72]
Losses and Other Expenses, Net

[0001069202-13-000003:mdna:73]
Losses and other expenses, net for 2011 and 2010 included the following (in millions):

[0001069202-13-000003:mdna:74]
|  | For the Years Ended December 31, |
|  | 2011 |  | 2010 |
| Realized gains on settled futures contracts | $ | (0.1 | ) |  | $ | (1.5 | ) |
| Foreign currency exchange losses | 1.4 |  |  | 0.5 |  |
| Loss (gain) on disposal of fixed assets | (0.8 | ) |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 3.8 |  |  | (0.6 | ) |
| Acquisition expenses | 1.0 |  |  | 4.9 |  |
| Special legal contingency charge | — |  |  | — |  |
| Other items, net | 0.4 |  |  | — |  |
| Losses and other expenses, net | $ | 5.7 |  |  | $ | 3.4 |  |

[0001069202-13-000003:mdna:75]
The changes in realized and unrealized gains and losses on futures contracts in 2011 were attributable to decreases in commodity prices relative to our futures contract prices.  For more information on our derivatives, see Note 9 in the Notes to the Consolidated Financial Statements.  Acquisition expenses in 2010 and 2011 primarily relate to the Kysor/Warren acquisition.  Refer to Note 3 in Notes to the Consolidated Financial Statements for more information on the acquisition.

[0001069202-13-000003:mdna:76]
Restructuring Charges

[0001069202-13-000003:mdna:77]
Restructuring charges were $13 million in 2011 compared to $11 million in 2010.  The charges in 2011 relate primarily to corporate restructuring including the termination of our corporate airplane lease, closure of our aviation department, and reorganization of certain support functions initiated in the third quarter of 2011.  The restructuring charges in 2010 were primarily related to the exit of the contract coil and OEM coil manufacturing operations in Australia and the consolidation of our Parets, Spain manufacturing facility into our Genas, France facility in the Refrigeration segment.  Additionally, 2010 charges included the relocation of a research and development facility and administrative offices from California to Tennessee in our Residential Heating & Cooling segment.  The remaining restructuring charges from 2010 were minor charges from various open projects initiated in 2010 and prior years.  Refer to Note 16 in the Notes to the Consolidated Financial Statements for more information.

[0001069202-13-000003:mdna:78]
Income from Equity Method Investments

[0001069202-13-000003:mdna:79]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments of $10 million in 2011 was flat compared to 2010.

[0001069202-13-000003:mdna:80]
Interest Expense, net

[0001069202-13-000003:mdna:81]
Interest expense, net increased to $17 million in 2011 compared to $13 million in 2010.  The increase in interest expense was primarily attributable to higher debt levels resulting from the Kysor/Warren acquisition as well as the issuance of $200 million in senior unsecured notes in May 2010 with a higher interest rate than our domestic revolving credit facility.

[0001069202-13-000003:mdna:82]
Income Taxes

[0001069202-13-000003:mdna:83]
The income tax provision was $56 million in 2011 as compared to $65 million in 2010.  The effective tax rate was 33.4% for 2011 as compared to 34.0% for 2010.  Our effective rates differ from the statutory federal rate of 35% for certain items, such as state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-13-000003:mdna:84]
Discontinued Operations

[0001069202-13-000003:mdna:85]
The loss from discontinued operations relates to the Service Experts business, which we announced plans to sell in September 2012, and the Hearth business, which we sold in April 2012.  The Service Experts business had a pre-tax loss of $11 million in 2011 compared to pre-tax income of $3 million in 2010.  The pre-tax loss in 2011 included operating losses of $7 million and restructuring expenses of $4 million.  The pre-tax income in 2010 was generated primarily from operations.

[0001069202-13-000003:mdna:86]
The Hearth business had a pre-tax loss in discontinued operations of $26 million in 2011 compared to a pre-tax loss of $25 million in 2010.  The pre-tax loss in 2011 included $12 million of operating losses, and goodwill and long-lived asset impairments of $7 million each.  The pre-tax loss in 2010 related primarily to operating losses.

[0001069202-13-000003:mdna:87]
Year Ended December 31, 2011 Compared to Year Ended December 31, 2010 - Results by Segment

[0001069202-13-000003:mdna:88]
Residential Heating & Cooling

[0001069202-13-000003:mdna:89]
The following table details our Residential Heating & Cooling segment's net sales and profit for 2011 and 2010 (dollars in millions):

[0001069202-13-000003:mdna:90]
|  | Years Ended December 31, |  |  |  |  |
|  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales | $ | 1,259.5 |  |  | $ | 1,338.5 |  |  | $ | (79.0 | ) |  | (5.9 | )% |
| Profit | $ | 87.6 |  |  | $ | 146.8 |  |  | $ | (59.2 | ) |  | (40.3 | )% |
| % of net sales | 7.0 | % |  | 11.0 | % |  |  |  |  |

[0001069202-13-000003:mdna:91]
Net sales declined by 6% in 2011 compared to 2010.  Sales volumes were down 5% and price and mix were down 1%.  This segment's volumes and mix were negatively affected by consumers moving to lower efficiency unit purchases from high efficiency system replacements, driven by a significant reduction in the federal tax credits in 2011, the availability of R22 refrigerant outdoor condensing units and overall economic and consumer weakness.

[0001069202-13-000003:mdna:92]
Segment profit decreased $59 million due to $31 million in increased commodity costs from both raw materials and components with our component cost commodity increases partially offset by material cost savings, $20 million in lower volumes, $15 million in higher freight and distribution costs, $13 million in unfavorable price and mix and $4 million in unfavorable warranty adjustment.  A $24 million decline in SG&A expenses partially offset the decreases in segment profit.  The decline in SG&A expenses was primarily due to lower variable compensation and general cost control.

[0001069202-13-000003:mdna:93]
Commercial Heating & Cooling

[0001069202-13-000003:mdna:94]
The following table details our Commercial Heating & Cooling segment's net sales and profit for 2011 and 2010 (dollars in millions):

[0001069202-13-000003:mdna:95]
|  | Years Ended December 31, |  |  |  |  |
|  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales | $ | 776.2 |  |  | $ | 695.8 |  |  | $ | 80.4 |  |  | 11.6 | % |
| Profit | $ | 87.6 |  |  | $ | 77.8 |  |  | $ | 9.8 |  |  | 12.6 | % |
| % of net sales | 11.3 | % |  | 11.2 | % |  |  |  |  |

[0001069202-13-000003:mdna:96]
Our Commercial Heating & Cooling business experienced a 12% increase in net sales in 2011 compared to 2010 primarily due to an increase in our replacement business which resulted in a 7% increase in sales volume.  Additionally, our price and mix increased 3% in 2011 compared to 2010.  Mix was driven by strength in our high efficiency premier products like Strategos® and Energence®.  Changes in foreign currency exchange rates also favorably impacted net sales by 2% in 2011.

[0001069202-13-000003:mdna:97]
Segment profit in 2011 increased $10 million from 2010 as a result of the impact of higher sales volume by $11 million, positive price and mix by $11 million, and $5 million from productivity initiatives.  Partially offsetting these increases were $17 million in increased material costs from both raw materials and components with our component cost commodity increases partially offset by material cost savings.

[0001069202-13-000003:mdna:98]
Refrigeration

[0001069202-13-000003:mdna:99]
The following table details our Refrigeration segment's net sales and profit for 2011 and 2010 (dollars in millions):

[0001069202-13-000003:mdna:100]
|  | Years Ended December 31, |  |  |  |  |
|  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales | $ | 805.2 |  |  | $ | 550.9 |  |  | $ | 254.3 |  |  | 46.2 | % |
| Profit | $ | 77.5 |  |  | $ | 61.4 |  |  | $ | 16.1 |  |  | 26.2 | % |
| % of net sales | 9.6 | % |  | 11.1 | % |  |  |  |  |

[0001069202-13-000003:mdna:101]
Net sales, excluding Kysor/Warren, increased 7% due to higher price and mix of 2% and favorable foreign currency exchange rates of 5%.  They Kysor/Warren acquisition contributed 39% to the increase in sales.

[0001069202-13-000003:mdna:102]
Segment profit increased $16 million primarily due to a $15 million positive impact from price and mix, $2 million in favorable foreign currency exchange rates and a $5 million decline in SG&A expenses.  Partially offsetting these increases were declines of $4 million from increased commodity costs from both raw materials and components with our component cost commodity increases more than offset by material cost savings, a $3 million decline in volume, and $2 million in higher freight and distribution charges.  The remaining segment profit increase was related to the Kysor/Warren acquisition.

[0001069202-13-000003:mdna:103]
Corporate and Other

[0001069202-13-000003:mdna:104]
Corporate and other expenses were $55 million in 2011, down from $66 million in 2010.  The decrease was primarily driven by a $12 million decline in compensation expense, primarily incentive compensation, for 2011.

[0001069202-13-000003:mdna:105]
Accounting for Futures Contracts

[0001069202-13-000003:mdna:106]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on open futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 9 to Consolidated Financial Statements for more information on our derivatives and Note 19 for more information on our segments and a reconciliation of segment profit to net income.

[0001069202-13-000003:mdna:107]
Liquidity and Capital Resources

[0001069202-13-000003:mdna:108]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-13-000003:mdna:109]
Statement of Cash Flows

[0001069202-13-000003:mdna:110]
The following table summarizes our cash flow activity for the years ended 2012, 2011 and 2010 (in millions):

[0001069202-13-000003:mdna:111]
|  | 2012 |  | 2011 |  | 2010 |
| Net cash provided by operating activities | $ | 221.4 |  |  | $ | 76.2 |  |  | $ | 185.8 |  |
| Net cash used in investing activities | (40.4 | ) |  | (177.8 | ) |  | (61.4 | ) |
| Net cash used in financing activities | (180.1 | ) |  | (11.9 | ) |  | (93.5 | ) |

[0001069202-13-000003:mdna:112]
Net Cash Provided by Operating Activities.  Net cash provided by operating activities increased $145 million to $221 million in 2012 compared to $76 million in 2011.  This increase was primarily attributable to higher income from continuing operations, an increase in accrued expenses and a reduction in working capital requirements.  The increase in accrued expenses was due primarily to higher incentive compensation as a result of improved overall operating results and the majority of the reduction in working capital in 2012 was related to a rise in accounts payable due to the timing of payments.  Also, contributions to pension plans in 2012 were $29 million compared to $13 million in 2011.

[0001069202-13-000003:mdna:113]
Net Cash Used in Investing Activities.  Capital expenditures were $50 million, $41 million and $43 million in 2012, 2011 and 2010, respectively.  Capital expenditures in 2012 were primarily investments in our distribution network, investments in systems and software to support the overall enterprise, and investments for manufacturing and sourcing excellence.

[0001069202-13-000003:mdna:114]
Net cash used in investing activities for 2012 also included $10 million in net proceeds from the sale of the Hearth business.  Net cash used in investing activities for 2011 included $143 million used for the acquisition of the Kysor/Warren business from The Manitowoc Company and $4 million for the acquisition of a commercial services business in our Commercial Heating & Cooling segment.

[0001069202-13-000003:mdna:115]
Net Cash Used in Financing Activities.  Net cash used in financing activities increased to $180 million in 2012 primarily due to a reduction in net borrowings.  The net borrowings were higher in 2011 to support the Kysor/Warren acquisition.  Also, we made $11 million more in dividend payments in 2012 compared to 2011.  Additionally, we used $50 million in 2012 to acquire 1.1 million shares of stock under our share repurchase plans compared to purchases of $120 million for 3.2 million shares of stock in 2011.

[0001069202-13-000003:mdna:116]
Debt Position and Financial Leverage

[0001069202-13-000003:mdna:117]
The following table details our lines of credit and financing arrangements as of December 31, 2012 (in millions):

[0001069202-13-000003:mdna:118]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-Term Debt: |  |  |  |  |  |
| Foreign Obligations | $ | 26.7 |  |  | $ | 4.9 |  |  | $ | 21.8 |  |
| Asset Securitization Program (1) | 160.0 |  |  | 30.0 |  |  | 130.0 |  |
| Total short-term debt | 186.7 |  |  | 34.9 |  |  | 151.8 |  |
| Current Maturities: |  |  |  |  |  |
| Capital lease obligations | 0.7 |  |  | 0.7 |  |  | — |  |
| Long-Term Debt: |  |  |  |  |  |
| Capital lease obligations | 16.0 |  |  | 16.0 |  |  | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 135.0 |  |  | 465.1 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 866.0 |  |  | 351.0 |  |  | 465.1 |  |
| Total debt | $ | 1,053.4 |  |  | $ | 386.6 |  |  | $ | 616.9 |  |

[0001069202-13-000003:mdna:119]
| (1) | The maximum capacity under the Asset Securitization program (“ASP”) is the lesser of $160.0 million or 100% of the net pool balance less reserves, as defined under the ASP. |

[0001069202-13-000003:mdna:120]
| (2) | The available future borrowings on our domestic revolving credit facility are reduced by $49.9 million in outstanding standby letters of credit. We had an additional $20.0 million in standby letters of credit with other banks. |

[0001069202-13-000003:mdna:121]
As our peak season arrives, we typically pay down debt.  We believe our available future borrowings combined with our cash of $52 million and future cash from operations are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Our expected capital expenditures for 2013 are $60 million.  Also, we expect to make approximately $5 million in contributions to our U.S. defined benefit plan in 2013.

[0001069202-13-000003:mdna:122]
Our debt-to-total-capital ratio decreased to 43.8% at December 31, 2012 compared to 49.9% at December 31, 2011.  The decrease in the ratio in 2012 is due to the reduction in our net borrowings, as noted above, as well as an increase in retained earnings primarily related to higher net income, partially offset by additional share repurchases.  We evaluate our debt-to-capital ratio as well as our debt-to-EBITDA ratio in order to determine the appropriate targets for share repurchases under our share repurchase programs.  Our senior credit ratings were investment grade as of December 31, 2012 and our goal is to retain these ratings.

[0001069202-13-000003:mdna:123]
Included in our cash and cash equivalents of $52 million as of December 31, 2012 was $37 million of cash held in foreign locations.  Our cash in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and to pay taxes in the United States for the amounts that were repatriated.

[0001069202-13-000003:mdna:124]
We periodically review our capital structure, including our primary bank facility, to ensure adequate liquidity.  In November 2012, we amended the Receivables Purchase Agreement, or Asset Securitization Program ("ASP"), increasing the maximum securitization amount from $150.0 million to $160.0 million and extending the term of the ASP to November 15, 2013.  Also, in March 2012, the parties involved with the ASP agreed to remove Lennox Hearth Products LLC from the program.  Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us.  We also periodically consider various other financing alternatives and may, from time to time, seek to take advantage of favorable interest rate environments or other market conditions, which may include accessing the capital markets.

[0001069202-13-000003:mdna:125]
On September 20, 2012, our Board of Directors approved an 11% increase in our quarterly dividend on common stock from $0.18 to $0.20 per share effective with the October 2012 dividend payment.  Dividend payments were $48 million in 2012 compared to $37 million in 2011, with the increase due primarily to the timing of payments of declared dividends.  Four quarterly dividends were declared in 2011 and 2012, whereas five quarterly dividends were paid in 2012 compared to four in 2011.  We also continue to increase shareholder value through our share repurchase programs.  In December 2011, our Board of Directors increased the 2008 Share Repurchase Program by $100 million.  Under the 2008 Share Repurchase Program, we returned $50 million to our investors through share repurchases with another $71 million of repurchases still available under the program.  Also, in December 2012, our Board of Directors approved a new $300 million share repurchase program.  We are targeting approximately $100 million in share repurchases in 2013 under the existing share repurchase programs.

[0001069202-13-000003:mdna:126]
26

[0001069202-13-000003:mdna:127]
Our credit facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage.  Other covenants contained in the credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio.  The required ratios under our credit facility are detailed below:

[0001069202-13-000003:mdna:128]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-13-000003:mdna:129]
Our credit facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our credit facility could occur if:

[0001069202-13-000003:mdna:130]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-13-000003:mdna:131]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-13-000003:mdna:132]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the credit facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-13-000003:mdna:133]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our credit facility and accelerate amounts due under our credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders' commitments will automatically terminate).   As of December 31, 2012, we were in compliance with all covenant requirements.

[0001069202-13-000003:mdna:134]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes repurchased, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our credit facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001069202-13-000003:mdna:135]
During the third quarter of 2008, we amended the lease agreement for our corporate headquarters.  While the same party continues to be the lessor under the lease, the amendment, among other things, replaced the debt participant and moderately increased the rent payments.  The amendment also provides for financial covenants consistent with our credit agreement and we are in compliance with these financial covenants as of December 31, 2012.  The lease is accounted for as an operating lease.

[0001069202-13-000003:mdna:136]
In 2008, we expanded our Tifton, Georgia manufacturing facility using the proceeds from Industrial Development Bonds (“IDBs”). We entered into a lease agreement with the owner of the property and the issuer of the IDBs, and through our lease payments fund the interest payments to investors in the IDBs. We also guaranteed the repayment of the IDBs and entered into letters of credit totaling $14.5 million to fund a potential repurchase of the IDBs in the event investors exercised their right to tender the IDBs to the Trustee.  As of December 31, 2012 and 2011, we recorded a long-term capital lease obligation of $14.3 million related to these transactions.

[0001069202-13-000003:mdna:137]
Off Balance Sheet Arrangements

[0001069202-13-000003:mdna:138]
In addition to the credit facilities and promissory notes described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Rent expense for these leases was $68 million, $70 million, and $64 million in 2012, 2011, and 2010, respectively.  Refer to Notes 11 and 23 of the Notes to the Consolidated Financial Statements for more information on our lease commitments and rent expense.

[0001069202-13-000003:mdna:139]
Contractual Obligations

[0001069202-13-000003:mdna:140]
Summarized below are our contractual obligations as of December 31, 2012 and their expected impact on our liquidity and cash flows in future periods (in millions):

[0001069202-13-000003:mdna:141]
|  | Payments Due by Period |
|  | Total |  | 1 Year or Less |  | 2 - 3 Years |  | 4 - 5 Years |  | After 5 Years |
| Total long-term debt obligations(1) | $ | 386.6 |  |  | $ | 35.6 |  |  | $ | 1.7 |  |  | $ | 335.0 |  |  | $ | 14.3 |  |
| Estimated interest payments on debt obligations | 51.2 |  |  | 12.0 |  |  | 23.7 |  |  | 15.0 |  |  | 0.5 |  |
| Operating leases(2) | 163.8 |  |  | 52.8 |  |  | 62.1 |  |  | 30.8 |  |  | 18.1 |  |
| Uncertain tax positions(3) | 0.7 |  |  | 0.4 |  |  | 0.3 |  |  | — |  |  | — |  |
| Purchase obligations(4) | 31.7 |  |  | 31.7 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 634.0 |  |  | $ | 132.5 |  |  | $ | 87.8 |  |  | $ | 380.8 |  |  | $ | 32.9 |  |

[0001069202-13-000003:mdna:142]
(1) Contractual obligations related to capital leases are included as part of long-term debt.

[0001069202-13-000003:mdna:143]
(2) Approximately $25.9 million of operating lease obligations relate to discontinued operations.

[0001069202-13-000003:mdna:144]
(3) The liability for uncertain tax positions includes interest and penalties.

[0001069202-13-000003:mdna:145]
(4) Purchase obligations consist of aluminum commitments and inventory that is part of our third party logistics programs.

[0001069202-13-000003:mdna:146]
The above table does not include retirement, post-retirement and warranty liabilities because it is not certain when these liabilities will be funded.  However, as noted above, we expect to pay approximately $5 million in contributions to our U.S. defined benefit plan in 2013.  For additional information regarding our contractual obligations, see Notes 10, 11 and 12 of the Notes to the Consolidated Financial Statements.  See Note 13 of the Notes to the Consolidated Financial Statements for more information  on our retirement and post-retirement liabilities.

[0001069202-13-000003:mdna:147]
Fair Value Measurements

[0001069202-13-000003:mdna:148]
Fair Value Hierarchy

[0001069202-13-000003:mdna:149]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-13-000003:mdna:150]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-13-000003:mdna:151]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-13-000003:mdna:152]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-13-000003:mdna:153]
Fair Value Techniques

[0001069202-13-000003:mdna:154]
General.  Our valuation techniques are applied to all of the assets and liabilities carried at fair value. Where available, the fair values are based upon quoted prices in active markets. However, if quoted prices are not available, then the fair values are based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities with a lack of observable market activity, if any, the fair values are based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use. To ensure that financial assets and liabilities are recorded at fair value, valuation adjustments may be required to reflect either party's creditworthiness and ability to pay. Where appropriate, these amounts were incorporated into our valuations as of December 31, 2012 and 2011, the measurement dates.

[0001069202-13-000003:mdna:155]
Derivatives.  Derivatives are primarily valued using estimated future cash flows that are based directly on observed prices from exchange-traded derivatives and, therefore, were classified as Level 2.  We also take into account the counterparty's creditworthiness, or our own creditworthiness, as appropriate. An adjustment has been recorded in order to reflect the risk of credit default, but these adjustments have been insignificant to the overall value of the derivatives.

[0001069202-13-000003:mdna:156]
Pension Plan Assets.  The majority of our commingled pool/collective trust, mutual funds and balanced pension trusts are managed by professional investment advisors. The net asset values (“NAV”) per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies. We have assessed the classification of the inputs used to value these investments at Level 1 for mutual funds and Level 2 for commingled pool/collective trusts and balance pension trusts through examination of their pricing policies and the related controls and procedures. The fair values we report are based on the pool or trust's NAV per share. The NAV's per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust's underlying assets divided by the number of units owned.

[0001069202-13-000003:mdna:157]
Market Risk

[0001069202-13-000003:mdna:158]
Commodity Price Risk

[0001069202-13-000003:mdna:159]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the derivative instruments that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases and conversely, when commodity prices fall, the fair value of our futures contracts decreases.

[0001069202-13-000003:mdna:160]
Information about our exposure to market risks related to metal commodity prices and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001069202-13-000003:mdna:161]
| Notional amount (pounds) | 27.7 |  |
| Carrying amount and fair value of asset | $ | 2.1 |  |
| Change in fair value from 10% change in forward prices | $ | 9.4 |  |

[0001069202-13-000003:mdna:162]
Interest Rate Risk

[0001069202-13-000003:mdna:163]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our revolving credit facilities, cash, cash equivalents and short-term investments.  In order to partially mitigate interest rate risk, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2012, no interest rate swaps were in effect.

[0001069202-13-000003:mdna:164]
A 10% adverse movement in the levels of interest rates across the entire yield curve, assuming no interest rate swaps were in place, would result in an increase in pre-tax interest expense of approximately $0.4 million for both of the years ended December 31, 2012 and 2011.

[0001069202-13-000003:mdna:165]
Foreign Currency Exchange Rate Risk

[0001069202-13-000003:mdna:166]
Our results of operations can be affected by changes in exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  During 2012, 2011 and 2010, net sales from outside the U.S. represented 27.2%, 29.0% and 27.8%, respectively, of our total net sales.  Historically, foreign currency transaction gains (losses) have not had a material effect on our overall operations.  For the years ended December 31, 2012 and 2011, the impact to net income of a 10% change in foreign exchange rates is estimated to be $3.9 million and $5.3 million, respectively.

[0001069202-13-000003:mdna:167]
Critical Accounting Policies

[0001069202-13-000003:mdna:168]
The preparation of financial statements requires the use of judgments and estimates.  The critical accounting policies are described below to provide a better understanding of how we develop our judgments about future events and related estimations and how such policies can impact our financial statements.  A critical accounting policy is one that requires difficult, subjective or complex estimates and assessments and is fundamental to the results of operations.  We consider our most critical accounting policies to be:

[0001069202-13-000003:mdna:169]
| • | goodwill and other intangible assets; |

[0001069202-13-000003:mdna:170]
| • | product warranties; |

[0001069202-13-000003:mdna:171]
| • | pension benefits; |

[0001069202-13-000003:mdna:172]
| • | self-insurance expense; |

[0001069202-13-000003:mdna:173]
| • | derivative accounting; and |

[0001069202-13-000003:mdna:174]
| • | income taxes. |

[0001069202-13-000003:mdna:175]
This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001069202-13-000003:mdna:176]
Goodwill and Other Intangible Assets

[0001069202-13-000003:mdna:177]
We assign goodwill to the reporting units that benefit from the synergies of our acquisitions.  If we reorganize our management structure, the related goodwill is allocated to the affected reporting units based upon the relative fair values of those reporting units.   Assets and liabilities, including deferred income taxes, are generally directly assigned to the reporting units.  However, certain assets and liabilities, including intellectual property assets, information technology assets and pension, self-insurance, and environmental liabilities, are commonly managed and are not allocated to the segments in the normal course of our financial reporting process, and therefore must be assigned to the reporting units based upon appropriate methods.  We test goodwill for impairment by reporting unit annually in the first quarter of each fiscal year.

[0001069202-13-000003:mdna:178]
Reporting units that we test are generally equivalent to our business segments, or in some cases, one level below.  We review our reporting unit structure each year as part of our annual goodwill impairment testing and reporting units are determined based upon a review of the periodic financial information supplied to and reviewed by our Chief Executive Officer (the chief operating decision maker).  We aggregate operating units reviewed into reporting units when those operating units share similar economic characteristics.

[0001069202-13-000003:mdna:179]
We review goodwill and indefinite-lived intangible assets for impairment annually and whenever events or changes in circumstances indicate the carrying value of an asset may not be recoverable.  The provisions of the accounting standard for goodwill and other intangibles allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors for LII as a whole and for each reporting unit.  Specifically, we monitor industry trends, our market capitalization, recent and forecasted financial performance of our reporting units, and the timing and nature of our restructuring activities.

[0001069202-13-000003:mdna:180]
For our annual test performed in the first quarter of 2012, we determined that it was not more likely than not the fair values of our reporting units, individually or collectively, were less than their carrying values.  Accordingly, no impairments were recognized as part of the annual test.  In the third quarter of 2012, we announced the planned sale of the Service Experts business and, as a result of the sales process, we received indications of market value of the business that were less than its carrying value.  Utilizing these indications of fair value, we recorded a $20.5 million goodwill impairment in the third quarter of 2012.  Refer to Note 17 in the Notes to the Consolidated Financial Statements for more information on the impairment.  No other indicators of impairment were identified from the date of our annual impairment test through December 31, 2012.

[0001069202-13-000003:mdna:181]
Product Warranties

[0001069202-13-000003:mdna:182]
The estimate of our liability for future warranty costs requires us to make significant assumptions about the amount, timing and nature of the costs we will incur in the future.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability. We review the assumptions used to determine the liability periodically and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual warranty costs differ from our estimates, we may be required to record adjustments to accruals and expense in the future.  For more information see Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000003:mdna:183]
Pension Benefits

[0001069202-13-000003:mdna:184]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.  We also have several active defined benefit plans that provide benefits based on years of service.

[0001069202-13-000003:mdna:185]
In order to calculate our liability and the expense for these benefit plans, we make several assumptions including the discount rate and expected return on assets.  We used the assumed discount rate of 3.97% for pension benefits of our U.S.-based plans as of December 31, 2012.  Our assumed discount rates are selected using the yield curve for high-quality corporate bonds, which is dependent upon risk-free interest rates and current credit market conditions.  In 2012 and 2011, we utilized an assumed long-term rate of return on assets of 8.00%.  These are long-term estimates of equity values and are not dependent on short-term variations of the equity markets.  Differences between actual experience and our assumptions are quantified as actuarial gains and losses.  These actuarial gains and losses do not immediately impact our earnings as they are deferred in accumulated other comprehensive income (“AOCI”) and are amortized into net periodic benefit cost over the estimated service period. In 2012 and 2011, we contributed $29 million and $13 million, respectively, to our pension plans.

[0001069202-13-000003:mdna:186]
The assumed long-term rate of return on assets and the discount rate have significant effects on the amounts reported for our defined benefit plans.  A 25 basis point decrease in the long-term rate of return on assets or discount rate would have the following effects (in millions):

[0001069202-13-000003:mdna:187]
|  | 25 Basis Point Decrease in Long-Term Rate of Return |  | 25 Basis Point Decrease in Discount Rate |
| Effect on net periodic benefit cost | $ | 0.5 |  |  | $ | 0.6 |  |
| Effect on the post-retirement benefit obligations | n/a |  |  | 13.5 |  |

[0001069202-13-000003:mdna:188]
Should actual results differ from our estimates and assumptions, revisions to the benefit plan liabilities and the related expenses would be required.  For more information, see Note 13 in the Notes to Consolidated Financial Statements.

[0001069202-13-000003:mdna:189]
Self-Insurance Expense

[0001069202-13-000003:mdna:190]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability,  auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers' compensation/employers' liability, general liability, product liability, and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors' and officers' liability, property damage and various other insurance programs.    For property damage, directors' and officers' liability and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-13-000003:mdna:191]
We maintain safety and manufacturing programs that are designed to remove risk and improve the  effectiveness of our business processes and, as a result, reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and therefore, both self-insurance expense and the related liability have decreased.

[0001069202-13-000003:mdna:192]
The self-insurance expense and liabilities are primarily determined based on our historical claims information, as well as industry factors and trends.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liability may change.  Also, the majority of our self-insured risks (excluding auto liability and physical damage) will be paid over an extended period of time. The self-insurance liabilities recorded in Accrued Expenses in the accompanying Consolidated Balance Sheets were $57 million and $63 million as of December 31, 2012 and 2011, respectively.  For more information, see Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000003:mdna:193]
Derivative Accounting

[0001069202-13-000003:mdna:194]
We use futures contracts and fixed forward contracts to mitigate our exposure to volatility in commodity prices in the ordinary course of business.  Fluctuations in metal commodity prices impact the value of the derivative instruments that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases and conversely, when commodity prices fall, the fair value of our futures contracts decreases.  We are required to prepare and maintain contemporaneous documentation for futures contracts to be formally designated as cash flow hedges.  Our failure to comply with the strict documentation requirements could result in the de-designation of cash flow hedges, which may significantly impact our consolidated financial statements.

[0001069202-13-000003:mdna:195]
Income Taxes

[0001069202-13-000003:mdna:196]
In determining income for financial statement purposes, we must make certain estimates and judgments in the calculation of tax provisions and the resultant tax liabilities and in the recoverability of deferred tax assets that arise from temporary differences between the tax and financial statement recognition of revenue and expense.  In the ordinary course of global business, there may be many transactions and calculations where the ultimate tax outcome is uncertain. The calculation of tax liabilities involves dealing with uncertainties in the application of complex tax laws. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on an estimate of the ultimate resolution of whether, and the extent to which, additional taxes will be due. Although we believe the estimates are reasonable, no assurance can be given that the final outcome of these matters will not be different than what is reflected in the historical income tax provisions and accruals.

[0001069202-13-000003:mdna:197]
As part of our financial reporting process, we must assess the likelihood that our deferred tax assets can be recovered.  If recovery is not likely, the provision for taxes must be increased by recording a reserve in the form of a valuation allowance for the deferred tax assets that are estimated not to be ultimately recoverable.  In this process, certain relevant criteria are evaluated, including the existence of deferred tax liabilities that can be used to absorb deferred tax assets, the taxable income in prior carryback years that can be used to absorb net operating losses and credit carrybacks and taxable income in future years.  Our judgment regarding future taxable income may change due to future market conditions, changes in U.S. or international tax laws and other factors.  These changes, if any, may require material adjustments to these deferred tax assets and an accompanying reduction or increase in net income in the period when such determinations are made.  In addition to the risks to the effective tax rate described above, the effective tax rate reflected in forward-looking statements is based on current tax law.  Any significant changes in the tax laws could affect these estimates.

[0001069202-13-000003:mdna:198]
Recent Accounting Pronouncements

[0001069202-13-000003:mdna:199]
In September 2011, the Financial Accounting Standards Board (“FASB”) updated its guidance on the annual testing of goodwill for impairment to allow companies to first assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step goodwill impairment test required under current accounting standards. The updated guidance was applicable to our goodwill impairment tests beginning in 2012. The adoption of this updated guidance did not have a material impact on our consolidated financial statements.

[0001069202-13-000003:mdna:200]
In June 2011 and as updated in December 2011, the FASB updated its guidance requiring companies to present the total of comprehensive income, the components of net income, and the components of other comprehensive income either in a single continuous statement of comprehensive income or in two separate but consecutive statements. The updated guidance eliminated the option to present the components of other comprehensive income as part of  the statement of changes in equity. This updated guidance was applicable beginning in 2012 and our adoption of the updated guidance did not have a material impact on our consolidated financial statements.

[0001069202-13-000003:mdna:201]
In July 2012, the FASB updated its guidance on the testing of indefinite-lived intangible assets for impairment to allow companies to first assess qualitative factors to determine whether it is more likely than not that an indefinite-lived intangible asset is impaired. If, as a result of the qualitative assessment, it is determined that it is not more likely than not that the indefinite-lived intangible assets is impaired, then the Company is not required to take further action. This guidance is applicable to impairment tests performed for fiscal years beginning after September 15, 2012.  We do not expect the adoption of this updated guidance to have a material impact on our consolidated financial statements.
