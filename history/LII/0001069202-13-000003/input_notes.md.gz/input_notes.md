# LII notes — 0001069202-13-000003


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-13-000003:notes:1]
Accrued Expenses:

[0001069202-13-000003:notes:2]
The significant components of accrued expenses are presented below (in millions):

[0001069202-13-000003:notes:3]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Accrued compensation and benefits | $ | 76.3 |  |  | $ | 46.9 |  |
| Self insurance reserves | 57.2 |  |  | 63.1 |  |
| Deferred income | 16.0 |  |  | 8.1 |  |
| Accrued warranties | 25.1 |  |  | 26.7 |  |
| Accrued product quality issue | 6.7 |  |  | 7.5 |  |
| Accrued rebates and promotions | 35.8 |  |  | 35.9 |  |
| Derivative contracts | 0.1 |  |  | 13.1 |  |
| Other | 42.4 |  |  | 38.1 |  |
| Total Accrued expenses | $ | 259.6 |  |  | $ | 239.4 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001069202-13-000003:notes:4]
Acquisition:

[0001069202-13-000003:notes:5]
On January 14, 2011, we acquired substantially all the assets of the Kysor/Warren business from The Manitowoc Company.  Kysor/Warren is a leading manufacturer of refrigerated systems and display cases for supermarkets throughout North America and is included in our Refrigeration Segment.  The total consideration for the acquisition was $143.3 million, which reflects post-closing purchase price working capital adjustments.  In connection with this acquisition, we recorded goodwill of $42.0 million and intangible assets of $33.9 million.  The intangible assets consisted of trade names of $5.0 million with indefinite lives, customer relationships of $26.7 million with 11 to 12 year lives, and other intangibles of $2.2 million with lives ranging from one to eight years.  We paid more than the fair value of the underlying net assets as a result of expected operational synergies.  The entire $42.0 million of goodwill is expected to be deductible for tax purposes.  The acquisition would not have had a significant impact on our historical results.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001069202-13-000003:notes:6]
Cash and Cash Equivalents

[0001069202-13-000003:notes:7]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-13-000003:notes:8]
Commitments and Contingencies:

[0001069202-13-000003:notes:9]
Leases

[0001069202-13-000003:notes:10]
We lease certain real and personal property under non-cancelable operating leases.  Several of the lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions.  We recognize our minimum rental expense on a straight-line basis.  We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use.

[0001069202-13-000003:notes:11]
The approximate minimum commitments under all non-cancelable leases outstanding as of December 31, 2012 were as follows (in millions):

[0001069202-13-000003:notes:12]
|  | Operating Leases |  | Capital Leases |
| 2013 | $ | 52.8 |  |  | $ | 1.1 |  |
| 2014 | 36.1 |  |  | 1.0 |  |
| 2015 | 26.0 |  |  | 0.7 |  |
| 2016 | 17.9 |  |  | 0.1 |  |
| 2017 | 12.9 |  |  | — |  |
| Thereafter | 18.1 |  |  | 14.6 |  |
| Total minimum lease payments(1) | $ | 163.8 |  |  | 17.5 |  |
| Less amount representing interest |  |  | 0.8 |  |
| Present value of minimum payments |  |  | $ | 16.7 |  |

[0001069202-13-000003:notes:13]
(1) Approximately $25.9 million of operating lease commitments relate to discontinued operations.  No capital lease obligations relate to discontinued operations.

[0001069202-13-000003:notes:14]
On June 22, 2006, we entered into an agreement with a financial institution to lease our corporate headquarters in Richardson, Texas for a term of seven years (the “Lake Park Lease”).  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the term, the Lake Park Lease requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) make a final payment under the lease equal to approximately 82% of the lease balance and return the property to the financial institution in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such payment cannot exceed 82% of the lease balance.

[0001069202-13-000003:notes:15]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic Revolving Credit Facility. We were in compliance with these financial covenants as of December 31, 2012.  The Lake Park Lease is accounted for as an operating lease.

[0001069202-13-000003:notes:16]
Environmental

[0001069202-13-000003:notes:17]
Applicable environmental laws can potentially impose obligations to remediate hazardous substances at our properties, at properties formerly owned or operated by us, and at facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities, however, we do not presently believe that any future remediation costs at such facilities will be material to our results of operations.

[0001069202-13-000003:notes:18]
The amount and timing of cash payments are reliably determinable and, therefore, we have recorded environmental reserves at their present values.  The following information relates to our environmental reserves (in millions, except percentages):

[0001069202-13-000003:notes:19]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Discounted liabilities recorded in: |  |  |  |
| Accrued expenses | $ | 1.4 |  |  | $ | 1.3 |  |
| Other liabilities | 3.7 |  |  | 3.1 |  |
|  | $ | 5.1 |  |  | $ | 4.4 |  |
| Undiscounted liabilities | $ | 5.0 |  |  | $ | 4.7 |  |
| Discount rate | 2.3% - 3.0% |  |  | 3.1% - 4.7% |  |

[0001069202-13-000003:notes:20]
Future environmental costs are estimates and are subject to change due to changes in environmental remediation regulations, site-specific requirements or discount rates.

[0001069202-13-000003:notes:21]
Product Warranties and Product Related Contingencies

[0001069202-13-000003:notes:22]
Total liabilities for estimated product warranty related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000003:notes:23]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Accrued expenses | $ | 25.1 |  |  | $ | 26.7 |  |
| Other liabilities | 46.8 |  |  | 41.6 |  |
|  | $ | 71.9 |  |  | $ | 68.3 |  |

[0001069202-13-000003:notes:24]
The changes in total product warranty liabilities related to continuing operations for the years ended December 31, 2012 and 2011 were as follows (in millions):

[0001069202-13-000003:notes:25]
| Total warranty liability as of December 31, 2010 | $ | 70.8 |  |
| Payments made in 2011 | (24.3 | ) |
| Changes resulting from issuance of new warranties | 22.6 |  |
| Changes in estimates associated with pre-existing liabilities | (0.4 | ) |
| Changes in foreign currency translation rates and other | (0.4 | ) |
| Total warranty liability as of December 31, 2011 | $ | 68.3 |  |
| Payments made in 2012 | (22.4 | ) |
| Changes resulting from issuance of new warranties | 25.1 |  |
| Changes in estimates associated with pre-existing liabilities | 0.6 |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |

[0001069202-13-000003:notes:26]
At the end of each accounting period, we evaluate our warranty liabilities and, during the second quarter of each year, we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities. As a result of the second quarter 2012 re-evaluation, we decreased our warranty liability by $0.4 million and that amount is the principal change in the estimate associated with pre-existing liabilities as shown in the table above.

[0001069202-13-000003:notes:27]
We incur the risk of liability claims for the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material changes in the circumstances that affect our product warranties since our latest fiscal year-end.

[0001069202-13-000003:notes:28]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001069202-13-000003:notes:29]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 as well as a refrigerant product quality issue. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the years ended December 31, 2012 and 2011 were as follows (in millions):

[0001069202-13-000003:notes:30]
| Total accrued product quality issue as of December 31, 2010 | $ | 16.0 |  |
| Changes in estimates associated with pre-existing liabilities | (2.8 | ) |
| Product quality claims | (5.7 | ) |
| Total accrued product quality issue as of December 31, 2011 | $ | 7.5 |  |
| Estimated expense for expected product quality claims | 2.2 |  |
| Product quality claims | (3.0 | ) |
| Total accrued product quality issues as of December 31, 2012 | $ | 6.7 |  |

[0001069202-13-000003:notes:31]
Self Insurance

[0001069202-13-000003:notes:32]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability,  auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers' compensation/employers' liability, general liability, product liability, and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors' and officers' liability, property damage and various other insurance programs.    For property damage, directors' and officers' liability and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-13-000003:notes:33]
We maintain safety and manufacturing programs that are designed to remove risk and improve the  effectiveness of our business processes and, as a result, reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and therefore, both self-insurance expense and the related liability have decreased.

[0001069202-13-000003:notes:34]
The self-insurance expense and liabilities are primarily determined based on our historical claims information, as well as industry factors and trends.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liability may change.  Also, the majority of our self-insured risks (excluding auto liability and physical damage) will be paid over an extended period of time. The self-insurance liabilities recorded in Accrued Expenses in the accompanying Consolidated Balance Sheets were $57.2 million and $63.1 million as of December 31, 2012 and 2011, respectively.

[0001069202-13-000003:notes:35]
Litigation

[0001069202-13-000003:notes:36]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-13-000003:notes:37]
Some of these claims and lawsuits allege health problems resulting from exposure to asbestos and we expect that additional claims will be brought against us in the future. However, our liability exposure from those additional claims cannot be estimated because of numerous uncertainties, including the number of such claims and lawsuits and the costs of defending and settling them, possible adverse judgments in amounts greater than previously experienced, and possible changes in the laws and process governing the compensation of asbestos claimants.

[0001069202-13-000003:notes:38]
We are also involved in patent litigation claims related to products from an acquired business.  The Company believes it has indemnification protection (with certain limitations) for these claims.

[0001069202-13-000003:notes:39]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ConsolidationPolicyTextBlock

[0001069202-13-000003:notes:40]
Principles of Consolidation

[0001069202-13-000003:notes:41]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.


## us-gaap:CostOfSalesPolicyTextBlock

[0001069202-13-000003:notes:42]
Cost of Goods Sold

[0001069202-13-000003:notes:43]
The principal components of cost of goods sold in our manufacturing operations are component costs, raw materials, factory overhead, labor, estimated costs of warranty expense, and freight and distribution costs.


## us-gaap:DebtDisclosureTextBlock

[0001069202-13-000003:notes:44]
Lines of Credit and Financing Arrangements:

[0001069202-13-000003:notes:45]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000003:notes:46]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 30.0 |  |  | $ | — |  |
| Foreign obligations | 4.9 |  |  | 4.7 |  |
| Total short-term debt | $ | 34.9 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: | $ | 0.7 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.0 |  |  | $ | 16.6 |  |
| Domestic revolving credit facility | 135.0 |  |  | 243.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 351.0 |  |  | $ | 459.6 |  |
| Total debt | $ | 386.6 |  |  | $ | 465.1 |  |

[0001069202-13-000003:notes:47]
As of December 31, 2012, the aggregate amounts of required principal payments on total debt were as follows (in millions):

[0001069202-13-000003:notes:48]
| 2013 | $ | 35.6 |  |
| 2014 | 0.8 |  |
| 2015 | 0.9 |  |
| 2016 | 135.0 |  |
| 2017 | 200.0 |  |
| Thereafter | 14.3 |  |

[0001069202-13-000003:notes:49]
Short-Term Debt

[0001069202-13-000003:notes:50]
Foreign Obligations

[0001069202-13-000003:notes:51]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $4.9 million and $4.7 million of foreign obligations as of December 31, 2012 and 2011, respectively, that are primarily borrowings under non-committed facilities.

[0001069202-13-000003:notes:52]
Asset Securitization Program

[0001069202-13-000003:notes:53]
Under the Receivables Purchase Agreement, or Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the RPA.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.

[0001069202-13-000003:notes:54]
The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-13-000003:notes:55]
On November 16, 2012, we amended the Receivables Purchase Agreement, increasing the maximum securitization amount from $150.0 million to $160.0 million and extending the term of the ASP to November 15, 2013.  Also, on March 30, 2012, the parties involved with the ASP agreed to remove Lennox Hearth Products LLC from the program. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us.

[0001069202-13-000003:notes:56]
The ASP provides for a maximum securitization amount of the lesser of $160.0 million or 100% of the net pool balance as defined by the ASP.  However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-13-000003:notes:57]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold | 30.0 |  |  | — |  |
| Remaining amount available | $ | 130.0 |  |  | $ | 150.0 |  |

[0001069202-13-000003:notes:58]
Under the ASP, we pay certain discount fees to use the program and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates for December 31, 2012 and 2011 were 0.85% and 0.91%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):

[0001069202-13-000003:notes:59]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Interest expense (including fees) | $ | 1.2 |  |  | $ | 0.7 |  |  | $ | 0.5 |  |

[0001069202-13-000003:notes:60]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility") and senior unsecured notes. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of December 31, 2012, we were in compliance with all covenant requirements.

[0001069202-13-000003:notes:61]
Long-Term Debt

[0001069202-13-000003:notes:62]
Domestic Revolving Credit Facility

[0001069202-13-000003:notes:63]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $135.0 million and $69.9 million committed to standby letters of credit as of December 31, 2012. Subject to covenant limitations, $465.1 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-13-000003:notes:64]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-13-000003:notes:65]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Weighted average borrowing rate | 1.46 | % |  | 1.53 | % |

[0001069202-13-000003:notes:66]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-13-000003:notes:67]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-13-000003:notes:68]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our revolving credit facility could occur if:

[0001069202-13-000003:notes:69]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-13-000003:notes:70]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-13-000003:notes:71]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-13-000003:notes:72]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2012, we were in compliance with all covenant requirements.

[0001069202-13-000003:notes:73]
Senior Unsecured Notes

[0001069202-13-000003:notes:74]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

[0001069202-13-000003:notes:75]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.   As of December 31, 2012, we were in compliance with all covenant requirements.

[0001069202-13-000003:notes:76]
Credit Rating

[0001069202-13-000003:notes:77]
As of December 31, 2012, our senior credit ratings were Baa3 with a negative outlook, and BBB- with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  Obligations rated Baa3 by Moody's and BBB- by S&P are both judged to be lowest investment grade and subject to moderate credit risk and may possess certain speculative characteristics. The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating. Our goal is to retain investment grade ratings from Moody's and S&P.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-13-000003:notes:78]
Derivatives:

[0001069202-13-000003:notes:79]
Objectives and Strategies for Using Derivative Instruments

[0001069202-13-000003:notes:80]
Commodity Price Risk

[0001069202-13-000003:notes:81]
We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes. The hedging program includes the use of futures contracts, which we enter into using a dollar cost average hedging strategy.  As part of this strategy, a higher percentage of commodity price exposures are hedged near term with lower percentages hedged at future dates. This strategy provides us with protection against near-term price volatility while allowing us to adjust to market price movements over time. Upon entering into futures contracts, we lock in prices and are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.

[0001069202-13-000003:notes:82]
Interest Rate Risk

[0001069202-13-000003:notes:83]
A portion of our debt bears interest at variable interest rates, and therefore, we are subject to variability in the cash paid for

[0001069202-13-000003:notes:84]
interest. In order to mitigate a portion of the risk, we used an interest rate swap hedging strategy to eliminate the variability of cash flows in the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the benchmark interest rate. This strategy allowed us to fix a portion of our variable interest payments.  Under the terms of the interest rate swap, the variable portion of the interest rate swap was tied to the 1-Month LIBOR (the benchmark interest rate). On a monthly basis, the interest rates for both the interest rate swap and the underlying debt were reset, the swap was settled with the counterparty, and the interest was paid.  The interest rate swap was accounted for as a cash flow hedge.  On October 12, 2012, our interest rate swap expired and, subsequently, we were no longer hedged against interest rate risk.

[0001069202-13-000003:notes:85]
Foreign Currency Risk

[0001069202-13-000003:notes:86]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. Our objective for entering into foreign currency forward contracts is to mitigate the impact of short-term currency exchange rate movements on certain short-term intercompany transactions. In order to meet that objective, we periodically enter into foreign currency forward contracts that act as economic hedges against changes in foreign currency exchange rates. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them. By entering into these forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-13-000003:notes:87]
Cash Flow Hedges

[0001069202-13-000003:notes:88]
We include gains or losses in accumulated other comprehensive income (“AOCI”) in connection with our commodity cash flow hedges. The gains or losses related to commodity price hedges are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates. Assuming that commodity prices remain constant, $0.9 million of derivative gains are expected to be reclassified into earnings within the next 12 months. Commodity futures contracts that are designated as cash flow hedges and that are in place as of December 31, 2012 are scheduled to mature through June 2014.

[0001069202-13-000003:notes:89]
Before our interest rate swap expired on October 12, 2012, we also included gains or losses in AOCI.  As of December 31, 2012, all previous derivative gains and losses included in AOCI had been reclassified into earnings.

[0001069202-13-000003:notes:90]
We recorded the following amounts related to our cash flow hedges (in millions):

[0001069202-13-000003:notes:91]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Commodity Price Hedges: |  |  |  |
| (Gains) losses included in AOCI, net of tax | $ | (1.1 | ) |  | $ | 6.1 |  |
| Expense for (benefit from) income taxes | 0.7 |  |  | (3.5 | ) |
| Interest Rate Swap: |  |  |  |
| Losses included in AOCI, net of tax | $ | — |  |  | $ | 1.1 |  |
| Benefit from income taxes | — |  |  | (0.6 | ) |

[0001069202-13-000003:notes:92]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions):

[0001069202-13-000003:notes:93]
|  | As of December 31, |
|  | 2012 |  | 2011 |
|  | (pounds) |  | (pounds) |
| Copper | 22.8 |  |  | 23.3 |  |

[0001069202-13-000003:notes:94]
Derivatives not Designated as Cash Flow Hedges

[0001069202-13-000003:notes:95]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges except that we elect not to designate these derivatives as cash flow hedges at the inception of the arrangement. We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions):

[0001069202-13-000003:notes:96]
|  | As of December 31, |
|  | 2012 |  | 2011 |
|  | (pounds) |  | (pounds) |
| Copper | 2.1 |  |  | 2.8 |  |
| Aluminum | 2.8 |  |  | 3.0 |  |

[0001069202-13-000003:notes:97]
We had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001069202-13-000003:notes:98]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Notional amounts: |  |  |  |
| Brazilian Real | 10.8 |  |  | 4.5 |  |
| Mexican Peso | 220.2 |  |  | 199.0 |  |
| Euro | 1.3 |  |  | 7.8 |  |
| British Pound | 5.4 |  |  | 6.5 |  |
| Indian Rupee | 19.5 |  |  | — |  |
| Polish Zloty | 12.4 |  |  | — |  |

[0001069202-13-000003:notes:99]
Information About the Locations and Amounts of Derivative Instruments

[0001069202-13-000003:notes:100]
The following table provides the locations and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of Operations (in millions):

[0001069202-13-000003:notes:101]
|  | Fair Values of Derivative Instruments(1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | As of December 31, |  | As of December 31, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 1.6 |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | 1.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.3 |  |  | 0.1 |  |  | — |  |  | — |  |
| Total Assets | $ | 1.9 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | 1.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 9.4 |  |  | $ | — |  |  | $ | 1.8 |  |
| Interest rate swap | — |  |  | 1.8 |  |  | — |  |  | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.3 |  |  | — |  |  | 0.2 |  |
| Interest rate swap | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | — |  |  | $ | 11.5 |  |  | $ | 0.1 |  |  | $ | 2.1 |  |

[0001069202-13-000003:notes:102]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 20 for more information.

[0001069202-13-000003:notes:103]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Amount of Loss (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |
| Commodity futures contracts(1) | $ | 6.0 |  |  | $ | (12.1 | ) |  | $ | (11.2 | ) |
| Interest rate swap(2) | 1.9 |  |  | 2.5 |  |  | 2.4 |  |
|  | $ | 7.9 |  |  | $ | (9.6 | ) |  | $ | (8.8 | ) |
| Amount of (Gain) Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |
| Commodity futures contracts(3) | $ | (0.1 | ) |  | $ | 0.1 |  |  | $ | (0.4 | ) |

[0001069202-13-000003:notes:104]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Amount of (Gain) Loss Recognized in Income on Derivatives: |  |  |  |  |  |
| Commodity futures contracts(3) | $ | (0.5 | ) |  | $ | 3.5 |  |  | $ | (1.7 | ) |
| Foreign currency forward contracts(3) | 0.4 |  |  | 0.3 |  |  | (0.2 | ) |
|  | $ | (0.1 | ) |  | $ | 3.8 |  |  | $ | (1.9 | ) |

[0001069202-13-000003:notes:105]
(1) The loss (gain) is recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-13-000003:notes:106]
(2) The loss is recorded in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-13-000003:notes:107]
(3) The (gain) loss is recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DerivativesPolicyTextBlock

[0001069202-13-000003:notes:108]
Derivatives

[0001069202-13-000003:notes:109]
We use futures contracts and fixed forward contracts to mitigate the exposure to volatility in commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months. For more information, see Note 9.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-13-000003:notes:110]
Stock-Based Compensation:

[0001069202-13-000003:notes:111]
Stock-Based Compensation expense related to continuing operations is included in Selling, General and Administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-13-000003:notes:112]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Compensation expense(1) | $ | 15.2 |  |  | $ | 13.7 |  |  | $ | 15.4 |  |

[0001069202-13-000003:notes:113]
(1) Stock-Based Compensation expense is recorded in our Corporate and other business segment.

[0001069202-13-000003:notes:114]
Incentive Plan

[0001069202-13-000003:notes:115]
Under the Lennox International Inc. 2010 Incentive Plan, as amended and restated (the “2010 Incentive Plan”), we are authorized to issue awards for 24.3 million shares of common stock.  As of December 31, 2012, awards for 20.6 million shares of common stock had been granted, net of cancellations and repurchases, and there were 3.7 million shares available for future issuance.

[0001069202-13-000003:notes:116]
The 2010 Incentive Plan provides for various long-term incentive awards, which include stock options, performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-13-000003:notes:117]
Performance Share Units

[0001069202-13-000003:notes:118]
Under the 2010 Incentive Plan, performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.

[0001069202-13-000003:notes:119]
Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout from 101% to 200% of the units granted, depending on LII's performance over the three-year performance period.

[0001069202-13-000003:notes:120]
Performance share units under the 2010 Incentive Plan are classified as equity awards. The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to expense ratably over the service period.  The compensation expense for any additional units which may be earned is estimated each reporting period based on the fair value of the stock at the date of grant.  The number of units expected to be earned will be adjusted, as necessary, to reflect the actual number of units awarded.

[0001069202-13-000003:notes:121]
The following table provides information on our performance share units (dollars in millions, except weighted-average fair values of grants):

[0001069202-13-000003:notes:122]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Performance Share Units: |  |  |  |  |  |
| Compensation expense | $ | 5.7 |  |  | $ | 1.7 |  |  | $ | 4.1 |  |
| Weighted-average fair value of grants, per share | $ | 48.64 |  |  | $ | 31.78 |  |  | $ | 44.85 |  |
| Payout ratio for shares paid | 52.5 | % |  | — | % |  | 127.7 | % |

[0001069202-13-000003:notes:123]
A summary of the status of our undistributed performance share units as of December 31, 2012, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-13-000003:notes:124]
|  | Shares |  | Weighted- Average Grant Date Fair Valueper Share |
| Undistributed performance share units: |  |  |  |
| Undistributed as of December 31, 2011 | 0.9 |  |  | $ | 33.40 |  |
| Granted | 0.1 |  |  | 48.64 |  |
| Adjustments to shares paid based on payout ratio | (0.1 | ) |  | 26.58 |  |
| Distributed | (0.1 | ) |  | 25.73 |  |
| Forfeited | (0.1 | ) |  | 35.96 |  |
| Undistributed as of December 31, 2012(1) | 0.7 |  |  | $ | 39.06 |  |

[0001069202-13-000003:notes:125]
(1) Undistributed performance share units include approximately 0.5 million units with a weighted-average grant date fair value of $40.31 per share that had not yet vested and 0.2 million units that have vested but were not yet distributed.

[0001069202-13-000003:notes:126]
As of December 31, 2012, we had $12.1 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for performance share units was 20.0% as of December 31, 2012.

[0001069202-13-000003:notes:127]
The total fair value of performance share units distributed and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-13-000003:notes:128]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Fair value of performance share units distributed | $ | 6.0 |  |  | $ | — |  |  | $ | 13.2 |  |
| Realized tax benefits from tax deductions | 2.3 |  |  | — |  |  | 5.0 |  |

[0001069202-13-000003:notes:129]
Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-13-000003:notes:130]
Restricted Stock Units

[0001069202-13-000003:notes:131]
Under the 2010 Incentive Plan, restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.

[0001069202-13-000003:notes:132]
Restricted stock units under the 2010 Incentive Plan are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.  The following table provides information on our restricted stock units (dollars in millions, except weighted-average fair value of grants):

[0001069202-13-000003:notes:133]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Restricted Stock Units: |  |  |  |  |  |
| Compensation expense | $ | 5.0 |  |  | $ | 6.6 |  |  | $ | 6.6 |  |
| Weighted-average fair value of grants, per share | $ | 48.45 |  |  | $ | 32.34 |  |  | $ | 44.80 |  |

[0001069202-13-000003:notes:134]
A summary of the status of our non-vested restricted stock units as of December 31, 2012 and changes during the year then ended is presented below (in millions, except per share data):

[0001069202-13-000003:notes:135]
|  | Shares |  | Weighted- Average Grant Date Fair Valueper Share |
| Non-vested restricted stock units: |  |  |  |
| Non-vested as of December 31, 2011 | 0.6 |  |  | $ | 36.51 |  |
| Granted | 0.2 |  |  | 48.45 |  |
| Distributed | (0.2 | ) |  | 35.16 |  |
| Forfeited | (0.1 | ) |  | 36.55 |  |
| Non-vested as of December 31, 2012 | 0.5 |  |  | $ | 40.50 |  |

[0001069202-13-000003:notes:136]
As of December 31, 2012, we had $11.9 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.3 years.  Our estimated forfeiture rate for restricted stock units was 20.9% as of December 31, 2012.

[0001069202-13-000003:notes:137]
The total fair value of restricted stock units vested and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-13-000003:notes:138]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Fair value of restricted stock units vested | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.4 |  |
| Realized tax benefits from tax deductions | 3.3 |  |  | 3.4 |  |  | 3.6 |  |

[0001069202-13-000003:notes:139]
Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.

[0001069202-13-000003:notes:140]
Stock Appreciation Rights

[0001069202-13-000003:notes:141]
In 2003, we began awarding stock appreciation rights to certain employees. Each recipient is given the “right” to receive a value, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date, and expire after seven years.  The following table provides information on our stock appreciation rights (dollars in millions, except weighted-average fair value of grants):

[0001069202-13-000003:notes:142]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Stock Appreciation Rights: |  |  |  |  |  |
| Compensation expense | $ | 4.5 |  |  | $ | 5.4 |  |  | $ | 4.7 |  |
| Weighted-average fair value of grants, per share | 14.34 |  |  | 9.39 |  |  | 13.75 |  |

[0001069202-13-000003:notes:143]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant and is recognized over the service period.  The fair value for these awards is estimated using the Black-Scholes-Merton valuation model. We use historical stock price data and other pertinent information to estimate the expected volatility and the outstanding period of the award for separate groups of employees that have similar historical exercise behavior to estimate expected life.  The risk-free interest rate was based on zero-coupon U.S. Treasury instruments with a remaining term equal to the expected life of the stock appreciation right at the time of grant.

[0001069202-13-000003:notes:144]
The fair value of each stock appreciation right granted in 2012, 2011 and 2010 is estimated on the date of grant using the following assumptions:

[0001069202-13-000003:notes:145]
|  | 2012 |  | 2011 |  | 2010 |
| Expected dividend yield | 1.75 | % |  | 2.39 | % |  | 1.46 | % |
| Risk-free interest rate | 0.48 | % |  | 0.62 | % |  | 1.46 | % |
| Expected volatility | 40.42 | % |  | 41.94 | % |  | 39.93 | % |
| Expected life (in years) | 4.14 |  |  | 4.07 |  |  | 4.04 |  |

[0001069202-13-000003:notes:146]
A summary of the status of our stock appreciation rights as of December 31, 2012, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-13-000003:notes:147]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Stock appreciation rights: |  |  |  |
| Outstanding as of December 31, 2011 | 2.9 |  |  | $ | 34.85 |  |
| Granted | 0.4 |  |  | 51.15 |  |
| Exercised | (1.0 | ) |  | 31.82 |  |
| Forfeited | (0.1 | ) |  | 37.81 |  |
| Outstanding as of December 31, 2012 | 2.2 |  |  | 38.93 |  |
| Exercisable as of December 31, 2012 | 1.3 |  |  | $ | 35.75 |  |

[0001069202-13-000003:notes:148]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2012 (in millions, except per share data and years):

[0001069202-13-000003:notes:149]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices per Share |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $28.24 - $51.40 |  | 4.8 |  | $30.0 |  | 3.7 |  | $21.3 |

[0001069202-13-000003:notes:150]
As of December 31, 2012, we had $9.7 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for stock appreciation rights was 19.6% as of December 31, 2012.

[0001069202-13-000003:notes:151]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-13-000003:notes:152]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Intrinsic value of stock appreciation rights exercised | $ | 14.4 |  |  | $ | 4.2 |  |  | $ | 10.1 |  |
| Realized tax benefits from tax deductions | 5.5 |  |  | 1.6 |  |  | 3.9 |  |

[0001069202-13-000003:notes:153]
Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-13-000003:notes:154]
Employee Stock Purchase Plan

[0001069202-13-000003:notes:155]
In May 2012, LII shareholders approved the 2012 Employee Stock Purchase Plan, or “2012 ESPP,” that allows effectively all employees who meet certain service requirements to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the 2012 ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.

[0001069202-13-000003:notes:156]
Employees purchased approximately 17,300 shares under the 2012 ESPP during the year ended December 31, 2012.  Approximately 2.5 million shares were available for purchase under the 2012 ESPP as of December 31, 2012.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-13-000003:notes:157]
Discontinued Operations:

[0001069202-13-000003:notes:158]
Service Experts

[0001069202-13-000003:notes:159]
In September 2012, the Company announced the planned sale of its Service Experts business, and as a result, the Service Experts business qualifies as a discontinued operation.  The Service Experts business had previously been reported within the Company’s Service Experts segment along with a commercial service business called Lennox National Account Services (NAS).  As of December 31, 2012, the Service Experts business was included in discontinued operations, NAS was included in the Company's Commercial Heating & Cooling segment, and the Service Experts reportable segment was eliminated. Results for all periods have been revised to conform with this new presentation.

[0001069202-13-000003:notes:160]
A summary of net trade sales, pre-tax operating income (losses) and other supplemental information for our Service Experts business is detailed below (in millions):

[0001069202-13-000003:notes:161]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Net trade sales(1) | $ | 385.1 |  |  | $ | 448.4 |  |  | $ | 514.8 |  |
| Pre-tax operating (loss) income(1)(2) | (50.8 | ) |  | (10.5 | ) |  | 2.6 |  |

[0001069202-13-000003:notes:162]
(1) Excludes eliminations of intercompany sales and any associated profit.

[0001069202-13-000003:notes:163]
(2) Pre-tax operating loss for the year ended December 31, 2012 includes a $20.5 million goodwill impairment loss (see impairment discussion below).

[0001069202-13-000003:notes:164]
The assets and liabilities of the Service Experts business are classified as held for sale as of December 31, 2012 and are carried at their fair values less costs to sell, based on indications of market value through our pursuit of strategic alternatives for the business.  The assets and liabilities of the Service Experts business include the following in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000003:notes:165]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Assets of discontinued operations: |  |  |  |
| Accounts receivable, net | $ | 11.2 |  |  | $ | 14.4 |  |
| Inventories, net | 4.8 |  |  | 6.3 |  |
| Property, plant and equipment, net | 3.6 |  |  | 3.8 |  |
| Goodwill and intangible assets, net | 66.2 |  |  | 83.2 |  |
| Deferred income taxes | 5.5 |  |  | 10.1 |  |
| Other assets | 7.3 |  |  | 7.7 |  |
| Liabilities of discontinued operations: |  |  |  |
| Accounts payable | $ | 16.7 |  |  | $ | 16.0 |  |
| Accrued expenses | 38.5 |  |  | 40.1 |  |
| Deferred income taxes | — |  |  | 3.7 |  |
| Other liabilities | — |  |  | 0.2 |  |

[0001069202-13-000003:notes:166]
Goodwill

[0001069202-13-000003:notes:167]
Goodwill of $66.0 million and $82.4 million is included in Assets of discontinued operations as of December 31, 2012 and 2011, respectively.  The Goodwill balance included in Assets of discontinued operations as of December 31, 2012 includes accumulated impairment charges of $228.5 million, of which $208.0 million is from prior periods and $20.5 million is from 2012.

[0001069202-13-000003:notes:168]
Goodwill and Long-lived Asset Impairment Considerations

[0001069202-13-000003:notes:169]
In the third quarter of 2012, we announced the planned sale of the Service Experts business and, as a result of the sales process, we received indications of market value of the business that were less than its carrying value.  Utilizing these indications of fair value, we determined that the carrying values of our long-lived assets were fully recoverable.  We also recorded a goodwill impairment of $20.5 million in the results from Discontinued operations. This goodwill impairment is an estimate that will be finalized once we complete our analysis of strategic alternatives for the business.  Adjustments to the estimate will be made in future periods as necessary.  We will continue to monitor our reporting units in future periods to determine if a change in facts and circumstances warrants a re-evaluation of our long-lived assets or goodwill.

[0001069202-13-000003:notes:170]
Hearth

[0001069202-13-000003:notes:171]
In April 2012, the Company announced the sale of its Hearth business to Comvest Investment Partners IV in an all cash transaction. The Hearth business had historically been included in the Company’s Residential Heating & Cooling Segment. We sold the Hearth business for net proceeds of $10.1 million, which excludes the transaction costs and cash transferred with the business.

[0001069202-13-000003:notes:172]
A summary of net trade sales and pre-tax operating losses for our Hearth business is detailed below (in millions):

[0001069202-13-000003:notes:173]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Net trade sales | $ | 23.5 |  |  | $ | 81.5 |  |  | $ | 78.9 |  |
| Pre-tax operating loss (1) | (13.7 | ) |  | (26.3 | ) |  | (25.2 | ) |
| Gain (loss) on sale of business | (0.9 | ) |  | — |  |  | — |  |

[0001069202-13-000003:notes:174]
| (1) | Pre-tax operating loss includes a $6.3 million first quarter 2012 pre-tax charge for the write-down of net assets to their estimated fair value and a $6.3 million settlement charge in the second quarter of 2012 related to actuarial losses recognized upon transition of a pension obligation to the acquirer of the Hearth business. Offsetting these charges was a $3.5 million gain in the second quarter of 2012 related to realized foreign currency translation adjustments. |

[0001069202-13-000003:notes:175]
The assets and liabilities of the Hearth business include the following in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000003:notes:176]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Assets of discontinued operations: |  |  |  |
| Accounts receivable, net | $ | — |  |  | $ | 7.3 |  |
| Inventories, net | — |  |  | 12.4 |  |
| Property, plant and equipment, net | — |  |  | 5.4 |  |
| Deferred income taxes | — |  |  | 9.1 |  |
| Other assets | — |  |  | 0.8 |  |
| Liabilities of discontinued operations: |  |  |  |
| Accounts payable | $ | — |  |  | $ | 6.0 |  |
| Accrued expenses | — |  |  | 5.2 |  |
| Other liabilities | — |  |  | 0.4 |  |

[0001069202-13-000003:notes:177]
Due to the prolonged uncertainty in the recovery of the residential new construction market, our long-term outlook for our Hearth reporting unit declined, and in the fourth quarter of 2011, we began to pursue strategic alternatives for the business.  Our Hearth reporting unit was heavily dependent on the residential new construction market; more so than our other reporting units due to its product offerings:  fireplaces, stoves and venting products.  As a result of this decline in expectations for this reporting unit, we tested our long-lived assets and goodwill for impairment in the fourth quarter of 2011 and again in the first quarter of 2012.

[0001069202-13-000003:notes:178]
For our long-lived assets, we determined that certain assets' carrying values were not recoverable, and accordingly, wrote them to their net realizable value.  This resulted in impairments of $5.1 million and $1.6 million for property, plant and equipment and amortizable customer relationships, respectively, in 2011, and an additional impairment of $6.3 million for property, plant and equipment in 2012.  For goodwill, we performed a goodwill impairment test and determined that the carrying value of our Hearth reporting unit exceeded its fair value.  The fair value of the reporting unit was based primarily on indications of market value through our pursuit of strategic alternatives.  Accordingly, an impairment loss of $7.6 million, representing the entire goodwill for this reporting unit, was recorded in 2011.


## us-gaap:EarningsPerShareTextBlock

[0001069202-13-000003:notes:179]
Earnings Per Share:

[0001069202-13-000003:notes:180]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period. Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-13-000003:notes:181]
The computations of basic and diluted earnings per share for Income from Continuing Operations were as follows (in millions, except per share data):

[0001069202-13-000003:notes:182]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Net income | $ | 90.0 |  |  | $ | 88.3 |  |  | $ | 116.2 |  |
| Add: Loss from discontinued operations | 45.0 |  |  | 23.2 |  |  | 9.7 |  |
| Income from continuing operations | $ | 135.0 |  |  | $ | 111.5 |  |  | $ | 125.9 |  |
| Weighted-average shares outstanding – basic | 50.7 |  |  | 52.5 |  |  | 54.6 |  |
| Effect of diluted securities attributable to stock-based payments | 0.7 |  |  | 0.9 |  |  | 1.2 |  |
| Weighted-average shares outstanding – diluted | 51.4 |  |  | 53.4 |  |  | 55.8 |  |
| Earnings per share from continuing operations: |  |  |  |  |  |
| Basic | $ | 2.66 |  |  | $ | 2.12 |  |  | $ | 2.31 |  |
| Diluted | $ | 2.63 |  |  | $ | 2.09 |  |  | $ | 2.26 |  |

[0001069202-13-000003:notes:183]
Certain stock appreciation rights were outstanding, but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive. The details are as follows (in millions, except per share data):

[0001069202-13-000003:notes:184]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Weighted-average number of shares | 0.1 |  |  | 1.5 |  |  | 0.3 |  |
| Price ranges per share | $51.11 - $51.40 |  |  | $34.06 - $46.78 |  |  | $46.78 |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-13-000003:notes:185]
Joint Ventures and Other Equity Investments:

[0001069202-13-000003:notes:186]
We participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownership, but do not control them due to venture partner participation.  Accordingly, they have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001069202-13-000003:notes:187]
The combined balance of equity method investments included in Other Assets, net totaled (in millions):

[0001069202-13-000003:notes:188]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Equity method investments | $ | 26.4 |  |  | $ | 24.9 |  |

[0001069202-13-000003:notes:189]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of Goods Sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-13-000003:notes:190]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Purchases of compressors | $ | 90.4 |  |  | $ | 80.2 |  |  | $ | 86.1 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-13-000003:notes:191]
The estimated fair value of our debt was as follows (in millions):

[0001069202-13-000003:notes:192]
|  | Quoted Prices in Active Markets forSimilar Instruments (Level 2) |
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Senior unsecured notes | $ | 212.3 |  |  | $ | 207.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-13-000003:notes:193]
Fair Value Measurements:

[0001069202-13-000003:notes:194]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Our framework for measuring fair value is established on a three-level hierarchy for fair value measurements.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.

[0001069202-13-000003:notes:195]
Fair Value Hierarchy

[0001069202-13-000003:notes:196]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-13-000003:notes:197]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-13-000003:notes:198]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-13-000003:notes:199]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-13-000003:notes:200]
Fair Value Techniques

[0001069202-13-000003:notes:201]
Our valuation techniques are applied to all of the assets and liabilities carried at fair value. Where available, the fair values are based upon quoted prices in active markets. However, if quoted prices are not available, then the fair values are based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities with a lack of observable market activity, if any, the fair values are based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use. To ensure that financial assets and liabilities are recorded at fair value, valuation adjustments may be required to reflect either party's creditworthiness and ability to pay. Where appropriate, these amounts were incorporated into our valuations as of December 31, 2012 and 2011, the measurement dates.

[0001069202-13-000003:notes:202]
Assets Measured at Fair Value on a Recurring Basis

[0001069202-13-000003:notes:203]
The following table presents the fair value hierarchy for those assets measured at fair value on a recurring basis (in millions):

[0001069202-13-000003:notes:204]
|  | Quoted Prices in Active Markets forIdentical Assets (Level 1) |
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Investment in marketable equity securities (1) | $ | 10.6 |  |  | $ | 8.4 |  |

[0001069202-13-000003:notes:205]
| (1) | Investment in marketable equity securities is recorded in Other assets, net in the accompanying Consolidated Balance Sheets. |

[0001069202-13-000003:notes:206]
Other Fair Value Measurements

[0001069202-13-000003:notes:207]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net, accounts payable, other current liabilities, and short-term debt approximate fair value due to the short maturities of these instruments. The fair values of each of our long-term debt instruments are based on the quoted market prices for the same issues or on the amount of future cash flows associated with each instrument using current market rates for debt instruments of similar maturities and credit risk. The fair values presented are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently or indicative of our intent or ability to dispose of or liquidate them. The estimated fair value of our debt was as follows (in millions):


## us-gaap:FairValueInvestmentsEntitiesThatCalculateNetAssetValuePerShareTableTextBlock

[0001069202-13-000003:notes:208]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-13-000003:notes:209]
|  | As of December 31, 2012 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |
| U.S. equity (1) | $ | 36.7 |  |  | n/a |  | n/a |
| International equity (2) | 60.3 |  |  | Monthly |  | 10 - 15 days |
| Fixed income (3) | 85.3 |  |  | Quarterly |  | 15 days |
| Mutual funds |  |  |  |  |  |
| U.S. equity (4) | 47.3 |  |  | n/a |  | n/a |
| International equity (4) | 3.9 |  |  | n/a |  | n/a |
| Fixed income (5) | 7.8 |  |  | n/a |  | n/a |
| Balanced pension trust (6) |  |  |  |  |  |
| U.S. equity | 2.4 |  |  | Daily |  | 5 days |
| International equity | 7.9 |  |  | Daily |  | 5 days |
| Fixed income | 6.6 |  |  | Daily |  | 5 days |
| Pension fund |  |  |  |  |  |
| U.S. equity (7) | 1.3 |  |  | Daily |  | 7 days |
| International equity (7) | 6.7 |  |  | Daily |  | 7 days |
| Fixed income (8) | 6.1 |  |  | Daily |  | 7 days |
| Total | $ | 272.3 |  |  |  |  |  |

[0001069202-13-000003:notes:210]
|  | As of December 31, 2011 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |
| U.S. equity (1) | $ | 33.4 |  |  | n/a |  | n/a |
| International equity (2) | 48.3 |  |  | Monthly |  | 10 - 15 days |
| Fixed income (3) | 81.9 |  |  | Quarterly |  | 15 days |
| Mutual funds |  |  |  |  |  |
| U.S. equity (4) | 38.8 |  |  | n/a |  | n/a |
| International equity (4) | 4.4 |  |  | n/a |  | n/a |
| Fixed income (5) | 8.4 |  |  | n/a |  | n/a |
| Balanced pension trust (6) |  |  |  |  |  |
| U.S. equity | 2.1 |  |  | Daily |  | 5 days |
| International equity | 6.5 |  |  | Daily |  | 5 days |
| Fixed income | 6.5 |  |  | Daily |  | 5 days |
| Pension fund |  |  |  |  |  |
| U.S. equity (7) | 1.1 |  |  | Daily |  | 7 days |
| International equity (7) | 5.5 |  |  | Daily |  | 7 days |
| Fixed income (8) | 4.8 |  |  | Daily |  | 7 days |
| Money market instruments (9) | 0.7 |  |  | Daily |  | 7 days |
| Total | $ | 242.4 |  |  |  |  |  |

[0001069202-13-000003:notes:211]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in non-U.S. equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, non-U.S. fixed income securities and emerging markets fixed income securities. |
| (4) | These funds seek capital appreciation and generally invest in common stocks of U.S. and non-U.S. issuers. They may invest in growth stocks or value stocks. |
| (5) | This fund seeks to provide inflation protection. It currently invests at least 80% of its assets in inflation-indexed bonds issued by the U.S. government. It may invest in bonds of any maturity, though the fund typically maintains a dollar-weighted average maturity of 7 to 20 years. |
| (6) | The investment objectives of the fund are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The fund also holds a portion of its assets in U.S. and non-U.S. equities. |
| (7) | This category includes investments in U.S. and non-U.S. equity securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (8) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer and investment grade corporate bonds denominated in sterling. |
| (9) | This fund invests in U.K. money market instruments and includes cash, bank deposits and short-term fixed interest investments. |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001069202-13-000003:notes:212]
Translation of Foreign Currencies

[0001069202-13-000003:notes:213]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenues and expenses are translated at weighted average exchange rates during the year.  The unrealized translation gains and losses are included in AOCI in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-13-000003:notes:214]
Goodwill, Intangible and Other Assets:

[0001069202-13-000003:notes:215]
The changes in the carrying amount of goodwill in 2011 and 2012, in total and by segment, are summarized in the table below (in millions):

[0001069202-13-000003:notes:216]
|  | Balance at December 31, 2010 |  |  |  |  |  | Balance at December 31, 2011 |  |  |  |  |  | Balance at December 31, 2012 |
| Segment: | Goodwill |  | Acquisitions / (Dispositions) (1) |  | Other(2) |  | Goodwill |  | Acquisitions / (Dispositions) |  | Other(2) |  |  |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.7 |  |  | 3.0 |  |  | (1.2 | ) |  | 63.5 |  |  | — |  |  | 0.3 |  |  | 63.8 |  |
| Refrigeration | 91.5 |  |  | 42.0 |  |  | 0.1 |  |  | 133.6 |  |  | — |  |  | 0.3 |  |  | 133.9 |  |
|  | $ | 179.3 |  |  | $ | 45.0 |  |  | $ | (1.1 | ) |  | $ | 223.2 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 223.8 |  |

[0001069202-13-000003:notes:217]
(1)  In the first quarter of 2011, our Refrigeration segment recorded $42.0 million of goodwill associated with the Kysor/Warren acquisition.  See Note 3 for more information on this acquisition.  In the second quarter of 2011, our Commercial segment acquired a company, resulting in additional goodwill of $3.0 million.

[0001069202-13-000003:notes:218]
(2)  Other consists primarily of changes in foreign currency translation rates.

[0001069202-13-000003:notes:219]
The Goodwill balances presented in the table above are presented net of accumulated impairment charges of $17.0 million, all of which relate to impairments in periods prior to 2011.

[0001069202-13-000003:notes:220]
Refer to Note 17 for information on goodwill related to discontinued operations.

[0001069202-13-000003:notes:221]
Intangible and Other Assets

[0001069202-13-000003:notes:222]
As of December 31, 2012 and 2011, there were $9.4 million of intangible assets not subject to amortization, primarily consisting of trademarks, recorded in Other assets, net in the accompanying Consolidated Balance Sheets.

[0001069202-13-000003:notes:223]
Identifiable intangible and other assets subject to amortization are recorded in Other Assets in the accompanying Consolidated Balance Sheets and were comprised of the following (in millions):

[0001069202-13-000003:notes:224]
|  | As of December 31, |
|  | 2012 |  | 2011 |
|  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Deferred financing costs | $ | 11.5 |  |  | $ | (8.0 | ) |  | $ | 3.5 |  |  | $ | 11.5 |  |  | $ | (7.2 | ) |  | $ | 4.3 |  |
| Customer relationships | 42.7 |  |  | (18.3 | ) |  | 24.4 |  |  | 42.7 |  |  | (15.8 | ) |  | 26.9 |  |
| Patents and others | 12.8 |  |  | (11.3 | ) |  | 1.5 |  |  | 12.6 |  |  | (10.7 | ) |  | 1.9 |  |
| Total | $ | 67.0 |  |  | $ | (37.6 | ) |  | $ | 29.4 |  |  | $ | 66.8 |  |  | $ | (33.7 | ) |  | $ | 33.1 |  |

[0001069202-13-000003:notes:225]
Amortization of intangible assets was as follows (in millions):

[0001069202-13-000003:notes:226]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Amortization expense | $ | 3.8 |  |  | $ | 4.7 |  |  | $ | 1.3 |  |

[0001069202-13-000003:notes:227]
Estimated intangible amortization expense for the next five years is as follows (in millions):

[0001069202-13-000003:notes:228]
| 2013 | $ | 3.8 |  |
| 2014 | 3.6 |  |
| 2015 | 3.5 |  |
| 2016 | 3.3 |  |
| 2017 | 2.8 |  |
| Thereafter | 12.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-13-000003:notes:229]
Income Taxes:

[0001069202-13-000003:notes:230]
Our income tax provision (benefit) from continuing operations consisted of the following (in millions):

[0001069202-13-000003:notes:231]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Current: |  |  |  |  |  |
| Federal | $ | 47.5 |  |  | $ | 41.4 |  |  | $ | 59.7 |  |
| State | 7.3 |  |  | 5.3 |  |  | 8.6 |  |
| Foreign | 13.4 |  |  | 7.3 |  |  | 5.6 |  |
| Total current | 68.2 |  |  | 54.0 |  |  | 73.9 |  |
| Deferred: |  |  |  |  |  |
| Federal | 0.7 |  |  | 0.4 |  |  | (4.5 | ) |
| State | (0.2 | ) |  | (1.0 | ) |  | (3.2 | ) |
| Foreign | (2.0 | ) |  | 2.4 |  |  | (1.4 | ) |
| Total deferred | (1.5 | ) |  | 1.8 |  |  | (9.1 | ) |
| Total income tax provision | $ | 66.7 |  |  | $ | 55.8 |  |  | $ | 64.8 |  |

[0001069202-13-000003:notes:232]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-13-000003:notes:233]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Domestic | $ | 169.9 |  |  | $ | 134.9 |  |  | $ | 181.7 |  |
| Foreign | 31.8 |  |  | 32.4 |  |  | 9.0 |  |
| Total | $ | 201.7 |  |  | $ | 167.3 |  |  | $ | 190.7 |  |

[0001069202-13-000003:notes:234]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement provision for taxes is summarized as follows (in millions):

[0001069202-13-000003:notes:235]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Provision at the U.S. statutory rate of 35% | $ | 70.6 |  |  | $ | 58.6 |  |  | $ | 67.1 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 5.9 |  |  | 2.9 |  |  | 3.2 |  |
| Other permanent items | (3.1 | ) |  | (3.5 | ) |  | (2.3 | ) |
| Research tax credit | — |  |  | (0.3 | ) |  | (0.5 | ) |
| Change in unrecognized tax benefits | (5.1 | ) |  | (0.6 | ) |  | (0.2 | ) |
| Change in valuation allowance | 2.3 |  |  | (0.7 | ) |  | (1.8 | ) |
| Foreign taxes at rates other than 35% and miscellaneous other | (3.9 | ) |  | (0.6 | ) |  | (0.7 | ) |
| Total income tax provision | $ | 66.7 |  |  | $ | 55.8 |  |  | $ | 64.8 |  |

[0001069202-13-000003:notes:236]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and are reflected as current or non-current depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.  Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-13-000003:notes:237]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 26.4 |  |  | $ | 26.1 |  |
| Net operating losses (foreign and U.S. state) | 20.1 |  |  | 21.8 |  |
| Post-retirement and pension benefits | 52.9 |  |  | 55.3 |  |
| Inventory reserves | 8.2 |  |  | 5.4 |  |
| Receivables allowance | 5.0 |  |  | 6.0 |  |
| Compensation liabilities | 17.2 |  |  | 17.9 |  |
| Deferred income | 0.8 |  |  | 0.7 |  |
| Insurance liabilities | 22.9 |  |  | 18.1 |  |
| Other | 9.5 |  |  | 12.5 |  |
| Total deferred tax assets | 163.0 |  |  | 163.8 |  |
| Valuation allowance | (10.9 | ) |  | (12.7 | ) |
| Total deferred tax assets, net of valuation allowance | 152.1 |  |  | 151.1 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (13.3 | ) |  | (15.2 | ) |
| Intangibles | (6.9 | ) |  | (5.1 | ) |
| Other | (1.6 | ) |  | (2.7 | ) |
| Total deferred tax liabilities | (21.8 | ) |  | (23.0 | ) |
| Net deferred tax assets | $ | 130.3 |  |  | $ | 128.1 |  |

[0001069202-13-000003:notes:238]
As of December 31, 2012 and 2011, we had $0.7 million and $0.7 million in tax effected state net operating loss carryforwards, respectively, and $19.4 million and $21.1 million in tax effected foreign net operating loss carryforwards, respectively.  The state and foreign net operating loss carryforwards begin expiring in 2014.  The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards in various states in the U.S., European and Asian tax jurisdictions.  The decrease in tax effected net operating loss carryforwards and associated valuation allowance is primarily related to the write-off of foreign losses, which were not previously benefited.

[0001069202-13-000003:notes:239]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income, and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not that we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of December 31, 2012.

[0001069202-13-000003:notes:240]
In order to realize the net deferred tax asset, we will need to generate future foreign taxable income of approximately $87.4 million during the periods in which those temporary differences become deductible.  We also will need to generate U.S. federal income of approximately $136.2 million in addition to our carryback capacity to fully realize the federal deferred tax asset.  U.S. taxable income for the years ended December 31, 2012 and 2011 was $70.0 million and $60.0 million, respectively.

[0001069202-13-000003:notes:241]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries' earnings.  It is not practicable to estimate the amount of tax that might be payable because our intent is to permanently reinvest these earnings or to repatriate earnings when it is tax effective to do so.

[0001069202-13-000003:notes:242]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001069202-13-000003:notes:243]
| Balance as of December 31, 2010 | $ | 1.0 |  |
| Decreases related to prior year tax positions | (0.7 | ) |
| Increases related to current year tax positions | 5.7 |  |
| Settlements | (0.1 | ) |
| Balance as of December 31, 2011 | 5.9 |  |
| Increases related to prior year tax positions | 0.8 |  |
| Decreases related to prior year tax positions | (5.8 | ) |
| Increases related to current year tax positions | 0.1 |  |
| Balance as of December 31, 2012 | $ | 1.0 |  |

[0001069202-13-000003:notes:244]
Included in the balance of unrecognized tax benefits as of December 31, 2012 are potential benefits of $0.7 million that, if recognized, would affect the effective tax rate on income from continuing operations.  As of December 31, 2012, we recognized $0.1 million (net of federal tax benefits) in interest and penalties in income tax expense.

[0001069202-13-000003:notes:245]
We are currently under examination for our U.S. federal income taxes for 2011 and 2012 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years before 2007.

[0001069202-13-000003:notes:246]
Since January 1, 2012, numerous states, including Pennsylvania, Idaho, West Virginia and California, enacted legislation effective for tax years beginning on or after January 1, 2012, including changes to rates and apportionment methods.  The impact of these changes is immaterial.

[0001069202-13-000003:notes:247]
On January 2, 2013, the American Taxpayer Relief Act of 2012 was enacted which retroactively reinstated and extended the Federal Research and Development Tax Credit (Federal R&D Tax Credit) from January 1, 2012 to December 31, 2013, in addition to other extenders.  As a result, the Company expects its income tax provision for the first quarter of calendar year 2013 will include a discrete tax benefit that will reduce the annual effective income tax rate.  On a full year basis, the impact to the annual effective income tax rate is not expected to be material.


## us-gaap:IncomeTaxPolicyTextBlock

[0001069202-13-000003:notes:248]
Income Taxes

[0001069202-13-000003:notes:249]
Income taxes are accounted for under the asset and liability method.  Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. For more information, see Note 10.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-13-000003:notes:250]
Inventories:

[0001069202-13-000003:notes:251]
The components of inventories are as follows (in millions):

[0001069202-13-000003:notes:252]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Finished goods | $ | 258.0 |  |  | $ | 222.3 |  |
| Work in process | 12.0 |  |  | 13.2 |  |
| Raw materials and parts | 180.1 |  |  | 156.3 |  |
|  | 450.1 |  |  | 391.8 |  |
| Excess of current cost over last-in, first-out cost | (75.3 | ) |  | (73.9 | ) |
| Total inventories, net | $ | 374.8 |  |  | $ | 317.9 |  |

[0001069202-13-000003:notes:253]
The Company recorded pretax loss of $0.1 million during 2012 and pretax income of $0.1 million and $0.7 million during 2011 and 2010, respectively, from LIFO inventory liquidations.


## us-gaap:InventoryPolicyTextBlock

[0001069202-13-000003:notes:254]
Inventories

[0001069202-13-000003:notes:255]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $176.2 million and $156.7 million as of December 31, 2012 and 2011, respectively, were valued at the lower of cost or market using the last-in, first-out (“LIFO”) cost method.  The remaining portion of the inventory is valued at the lower of cost or market with cost being determined primarily using either the first-in, first-out (“FIFO”) basis or average cost methods.

[0001069202-13-000003:notes:256]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory include raw materials, purchased components, work-in-process, repair parts and finished goods.  Starting in the late 1990s, we began adopting the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We also use the FIFO cost method for all of our foreign-based manufacturing facilities.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-13-000003:notes:257]
Employee Benefit Plans:

[0001069202-13-000003:notes:258]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.  We also have several active defined benefit plans that provide benefits based on years of service.

[0001069202-13-000003:notes:259]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.  In 2012, we amended the post-retirement benefit plan to shift pre-65 medical coverage for the employees of our largest manufacturing plant so that by 2015, retirees would pay 100% of the cost of post-retirement medical coverage.  This change resulted in a significant reduction in the projected benefit obligation for post-retirement medical benefits in 2012.

[0001069202-13-000003:notes:260]
Defined Contribution Plans

[0001069202-13-000003:notes:261]
As noted above, we sponsor several defined contribution plans, and we recorded the following expenses related to our contributions to these plans (in millions):

[0001069202-13-000003:notes:262]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Contributions to defined contribution plans(1) | $ | 13.2 |  |  | $ | 14.3 |  |  | $ | 13.6 |  |

[0001069202-13-000003:notes:263]
(1)  Contributions of $2.0 million, $2.7 million and $3.3 million are included in Loss for discontinued operations for the years ended December 31, 2012, 2011 and 2010 respectively.

[0001069202-13-000003:notes:264]
Pension and Post-retirement Benefit Plans

[0001069202-13-000003:notes:265]
As noted above, we have recorded a liability and expenses for our pension and post-retirement plans.  The following tables set forth amounts recognized in our financial statements and the plans' funded status (dollars in millions):

[0001069202-13-000003:notes:266]
|  | Pension Benefits |  | Other Benefits |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Accumulated benefit obligation | $ | 406.3 |  |  | $ | 363.6 |  |  | N/A |  |  | N/A |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 368.8 |  |  | $ | 336.3 |  |  | $ | 19.9 |  |  | $ | 17.0 |  |
| Service cost | 5.8 |  |  | 5.4 |  |  | 0.2 |  |  | 0.8 |  |
| Interest cost | 17.5 |  |  | 17.8 |  |  | 0.4 |  |  | 0.9 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.8 |  |  | 0.8 |  |
| Amendments | — |  |  | — |  |  | (14.2 | ) |  | — |  |
| Other | 4.5 |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 47.0 |  |  | 28.9 |  |  | 2.8 |  |  | 2.3 |  |
| Effect of exchange rates | 1.6 |  |  | (0.7 | ) |  | — |  |  | — |  |
| Divestiture | (10.4 | ) |  | — |  |  | — |  |  | — |  |
| Settlements and curtailments | (1.7 | ) |  | (2.1 | ) |  | — |  |  | — |  |
| Benefits paid | (19.2 | ) |  | (16.8 | ) |  | (2.3 | ) |  | (1.9 | ) |
| Benefit obligation at end of year | $ | 413.9 |  |  | $ | 368.8 |  |  | $ | 7.6 |  |  | $ | 19.9 |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 242.5 |  |  | $ | 244.6 |  |  | $ | — |  |  | $ | — |  |
| Actual gain return on plan assets | 32.1 |  |  | 3.8 |  |  | — |  |  | — |  |
| Employer contribution | 29.4 |  |  | 13.4 |  |  | 1.5 |  |  | 1.1 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.8 |  |  | 0.8 |  |
| Effect of exchange rates | 1.0 |  |  | (0.4 | ) |  | — |  |  | — |  |
| Divestiture | (7.3 | ) |  | — |  |  | — |  |  | — |  |
| Plan settlements | (1.7 | ) |  | (2.1 | ) |  | — |  |  | — |  |
| Benefits paid | (19.2 | ) |  | (16.8 | ) |  | (2.3 | ) |  | (1.9 | ) |
| Fair value of plan assets at end of year | 276.8 |  |  | 242.5 |  |  | — |  |  | — |  |
| Funded status / net amount recognized | $ | (137.1 | ) |  | $ | (126.3 | ) |  | $ | (7.6 | ) |  | $ | (19.9 | ) |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Current liability | $ | (2.7 | ) |  | $ | (1.6 | ) |  | $ | (1.5 | ) |  | $ | (1.3 | ) |
| Non-current liability | (134.4 | ) |  | (124.7 | ) |  | (6.1 | ) |  | (18.6 | ) |
| Net amount recognized | $ | (137.1 | ) |  | $ | (126.3 | ) |  | $ | (7.6 | ) |  | $ | (19.9 | ) |

[0001069202-13-000003:notes:267]
No pension plans were over-funded as of December 31, 2012 or 2011.

[0001069202-13-000003:notes:268]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 413.2 |  |  | $ | 368.1 |  |
| Accumulated benefit obligation | 405.5 |  |  | 362.9 |  |
| Fair value of plan assets | 276.1 |  |  | 241.8 |  |

[0001069202-13-000003:notes:269]
Our U.S.-based pension plans comprised approximately 88% of the projected benefit obligation and 89% of plan assets as of December 31, 2012.

[0001069202-13-000003:notes:270]
|  | Pension Benefits |  | Other Benefits |
|  | 2012 |  | 2011 |  | 2010 |  | 2012 |  | 2011 |  | 2010 |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 5.8 |  |  | $ | 5.4 |  |  | $ | 5.0 |  |  | $ | 0.2 |  |  | $ | 0.8 |  |  | $ | 0.6 |  |
| Interest cost | 17.5 |  |  | 17.8 |  |  | 17.6 |  |  | 0.4 |  |  | 0.9 |  |  | 0.8 |  |
| Expected return on plan assets | (19.0 | ) |  | (19.0 | ) |  | (19.5 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.4 |  |  | 0.4 |  |  | 0.5 |  |  | (2.7 | ) |  | (1.9 | ) |  | (1.9 | ) |
| Recognized actuarial loss | 8.7 |  |  | 7.0 |  |  | 5.1 |  |  | 1.4 |  |  | 1.2 |  |  | 1.2 |  |
| Settlements and curtailments | 7.1 |  |  | 1.7 |  |  | 1.4 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost(1) | $ | 20.5 |  |  | $ | 13.3 |  |  | $ | 10.1 |  |  | $ | (0.7 | ) |  | $ | 1.0 |  |  | $ | 0.7 |  |

[0001069202-13-000003:notes:271]
(1) Pension expense of $6.9 million, $0.8 million and $0.8 million is included in Loss for discontinued operations for the years ended December 31, 2012, 2011 and 2010 respectively.

[0001069202-13-000003:notes:272]
The following table sets forth amounts recognized in AOCI in our financial statements for 2012 and 2011 (in millions):

[0001069202-13-000003:notes:273]
|  | Pension Benefits |  | Other Benefits |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Amounts recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Prior service costs | $ | (2.8 | ) |  | $ | (2.6 | ) |  | $ | 24.2 |  |  | $ | 12.7 |  |
| Actuarial loss | (231.2 | ) |  | (212.0 | ) |  | (22.2 | ) |  | (20.8 | ) |
| Subtotal | (234.0 | ) |  | (214.6 | ) |  | 2.0 |  |  | (8.1 | ) |
| Deferred taxes | 85.2 |  |  | 78.6 |  |  | (0.8 | ) |  | 3.1 |  |
| Net amount recognized | $ | (148.8 | ) |  | $ | (136.0 | ) |  | $ | 1.2 |  |  | $ | (5.0 | ) |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Adjustment to OCI due to reclassification | $ | 0.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Current year prior service costs | — |  |  | — |  |  | (14.2 | ) |  | — |  |
| Current year actuarial loss | 34.0 |  |  | 44.4 |  |  | 2.8 |  |  | 2.3 |  |
| Effect of exchange rates | 0.7 |  |  | (0.4 | ) |  | — |  |  | — |  |
| Amortization of prior service (costs) credits | (0.4 | ) |  | (0.9 | ) |  | 2.7 |  |  | 1.9 |  |
| Amortization of actuarial loss | (15.8 | ) |  | (8.2 | ) |  | (1.4 | ) |  | (1.2 | ) |
| Total recognized in other comprehensive income | $ | 19.3 |  |  | $ | 34.9 |  |  | $ | (10.1 | ) |  | $ | 3.0 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) | $ | 39.8 |  |  | $ | 48.2 |  |  | $ | (10.8 | ) |  | $ | 4.0 |  |

[0001069202-13-000003:notes:274]
The estimated prior service (costs) credits and actuarial gains (losses) that will be amortized from AOCI in 2013 are $(0.5) million and $(10.5) million, respectively, for pension benefits and $3.1 million and $(1.5) million, respectively, for other benefits.

[0001069202-13-000003:notes:275]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the U.S.-based plans in 2012 and 2011:

[0001069202-13-000003:notes:276]
|  | Pension Benefits |  | Other Benefits |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |
| Discount rate | 3.97 | % |  | 4.83 | % |  | 2.72 | % |  | 4.64 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |

[0001069202-13-000003:notes:277]
|  | Pension Benefits |  | Other Benefits |
|  | 2012 |  | 2011 |  | 2010 |  | 2012 |  | 2011 |  | 2010 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 4.83 | % |  | 5.45 | % |  | 6.07 | % |  | 4.64 | % |  | 5.30 | % |  | 5.95 | % |
| Expected long-term return on plan assets | 8.00 | % |  | 8.00 | % |  | 8.00 | % |  | — |  |  | — |  |  | — |  |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |  | — |  |

[0001069202-13-000003:notes:278]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the non-U.S.-based plans in 2012 and 2011:

[0001069202-13-000003:notes:279]
|  | Pension Benefits |
|  | 2012 |  | 2011 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 4.12 | % |  | 4.93 | % |
| Rate of compensation increase | 3.48 | % |  | 3.68 | % |

[0001069202-13-000003:notes:280]
|  | Pension Benefits |
|  | 2012 |  | 2011 |  | 2010 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate | 4.93 | % |  | 5.43 | % |  | 5.98 | % |
| Expected long-term return on plan assets | 6.26 | % |  | 5.56 | % |  | 5.59 | % |
| Rate of compensation increase | 3.68 | % |  | 3.98 | % |  | 3.98 | % |

[0001069202-13-000003:notes:281]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns and the future expectations for returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 8.0% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-13-000003:notes:282]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the duration of projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available.  We used the results of the yield curve analysis to select the discount rate that matched the duration and payment stream of the benefits in each plan.  This resulted in the selection of the 4.02% discount rate assumption for the U.S. qualified pension plans, 3.46% for the U.S. non-qualified pension plans, and 2.72% for the other benefits.  A similar process was followed for the non-U.S.-based plans.

[0001069202-13-000003:notes:283]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-13-000003:notes:284]
|  | 2012 |  | 2011 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 8.40 | % |  | 8.40 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2020 |  |  | 2020 |  |

[0001069202-13-000003:notes:285]
A one percentage-point change in assumed healthcare cost trend rates would have the following effects (in millions):

[0001069202-13-000003:notes:286]
|  | 1-Percentage-Point Increase |  | 1-Percentage-Point Decrease |
| Effect on total of service and interest cost | $ | 0.1 |  |  | $ | (0.1 | ) |
| Effect on the post-retirement benefit obligation | 0.3 |  |  | (0.3 | ) |

[0001069202-13-000003:notes:287]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-13-000003:notes:288]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018-2022 |
| Pension benefits | $ | 18.2 |  |  | $ | 17.3 |  |  | $ | 18.0 |  |  | $ | 18.7 |  |  | $ | 19.1 |  |  | $ | 111.0 |  |
| Other benefits | 1.5 |  |  | 1.4 |  |  | 0.9 |  |  | 0.7 |  |  | 0.6 |  |  | 1.9 |  |

[0001069202-13-000003:notes:289]
We believe that by adequately diversifying the plan assets, asset returns can be optimized at an acceptable level of risk.  Since equity securities have historically generated higher returns than fixed income securities and the plan is not fully funded, we believe it is appropriate to allocate more assets to equities than fixed income securities. In addition, these categories are further diversified among various asset classes including high yield and emerging markets debt, and international and emerging markets equities in order to avoid significant concentrations of risk. Our U.S. pension plan represents 89%, our Canadian pension plan 6%, and our United Kingdom (“U.K.”) pension plan 5% of the total fair value of our plan assets as of December 31, 2012.

[0001069202-13-000003:notes:290]
Our U.S. pension plans' weighted-average asset allocations as of December 31, 2012 and 2011, by asset category, are as follows:

[0001069202-13-000003:notes:291]
|  | Plan Assets as of December 31, |
| Asset Category | 2012 |  | 2011 |
| U.S. equity | 34.2 | % |  | 33.6 | % |
| International equity | 26.1 |  |  | 24.4 |  |
| Fixed income | 37.8 |  |  | 41.9 |  |
| Money market/cash | 1.9 |  |  | 0.1 |  |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-13-000003:notes:292]
U.S. pension plan investments are invested within the following range targets:

[0001069202-13-000003:notes:293]
| Asset Category | Target |
| U.S. equity | 36.0 | % |
| International equity | 24.0 | % |
| Fixed income | 38.0 | % |
| Money market/cash/guaranteed investment contracts | 2.0 | % |

[0001069202-13-000003:notes:294]
Our Canadian pension plan was invested solely in a balanced fund that maintains diversification among various asset classes, including Canadian common stocks, bonds and money market securities, U.S. equities, other international equities and fixed income investments. Our U.K. pension plan was invested in a broad mix of assets consisting of U.K., U.S. and international equities, and U.K. fixed income securities, including corporate and government bonds.

[0001069202-13-000003:notes:295]
The fair values of our pension plan assets, by asset category, are as follows (in millions):

[0001069202-13-000003:notes:296]
|  | Fair Value Measurements as of December 31, 2012 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |  |  |
| U.S. equity(1) | — |  |  | 36.7 |  |  | — |  |  | 36.7 |  |
| International equity (2) | — |  |  | 60.3 |  |  | — |  |  | 60.3 |  |
| Fixed income (3) | — |  |  | 85.3 |  |  | — |  |  | 85.3 |  |
| Mutual funds |  |  |  |  |  |  |  |
| U.S. equity (4) | 47.3 |  |  | — |  |  | — |  |  | 47.3 |  |
| International equity (4) | 3.9 |  |  | — |  |  | — |  |  | 3.9 |  |
| Fixed income (5) | 7.8 |  |  | — |  |  | — |  |  | 7.8 |  |
| Balanced pension trust (6) |  |  |  |  |  |  |  |
| U.S. equity | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| International equity | — |  |  | 7.9 |  |  | — |  |  | 7.9 |  |
| Fixed income | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| Pension fund |  |  |  |  |  |  |  |
| U.S. equity (7) | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| International equity (7) | — |  |  | 6.7 |  |  | — |  |  | 6.7 |  |
| Fixed income (8) | — |  |  | 6.1 |  |  | — |  |  | 6.1 |  |
| Total | 63.5 |  |  | 213.3 |  |  | — |  |  | 276.8 |  |

[0001069202-13-000003:notes:297]
|  | Fair Value Measurements as of December 31, 2011 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |  |  |
| U.S. equity(1) | — |  |  | 33.4 |  |  | — |  |  | 33.4 |  |
| International equity (2) | — |  |  | 48.3 |  |  | — |  |  | 48.3 |  |
| Fixed income (3) | — |  |  | 81.9 |  |  | — |  |  | 81.9 |  |
| Mutual funds |  |  |  |  |  |  |  |
| U.S. equity (4) | 38.8 |  |  | — |  |  | — |  |  | 38.8 |  |
| International equity (4) | 4.4 |  |  | — |  |  | — |  |  | 4.4 |  |
| Fixed income (5) | 8.4 |  |  | — |  |  | — |  |  | 8.4 |  |
| Balanced pension trust (6) |  |  |  |  |  |  |  |
| U.S. equity | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |
| International equity | — |  |  | 6.5 |  |  | — |  |  | 6.5 |  |
| Fixed income | — |  |  | 6.5 |  |  | — |  |  | 6.5 |  |
| Pension fund |  |  |  |  |  |  |  |
| U.S. equity (7) | — |  |  | 1.1 |  |  | — |  |  | 1.1 |  |
| International equity (7) | — |  |  | 5.5 |  |  | — |  |  | 5.5 |  |
| Fixed income (8) | — |  |  | 4.8 |  |  | — |  |  | 4.8 |  |
| Money market instruments (9) | — |  |  | 0.7 |  |  | — |  |  | 0.7 |  |
| Total | 51.8 |  |  | 190.8 |  |  | — |  |  | 242.6 |  |

[0001069202-13-000003:notes:298]
The majority of our commingled pool /collective trusts, mutual funds and balanced pension trusts are managed by professional investment advisors. The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies. We have assessed the classification of the inputs used to value these investments at Level 1 for mutual funds and Level 2 for commingled pool / collective trusts and balanced pension trusts through examination of their pricing policies and the related controls and procedures. The fair values we report are based on the pool or trust's NAV per share. The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust's underlying assets divided by the number of units owned.  See Note 20 for information about our fair value hierarchies and valuation techniques.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-13-000003:notes:299]
Property, Plant and Equipment:

[0001069202-13-000003:notes:300]
Components of property, plant and equipment were as follows (in millions):

[0001069202-13-000003:notes:301]
|  | As of December 31, |
|  | 2012 |  | 2011 |
| Land | $ | 29.4 |  |  | $ | 26.1 |  |
| Buildings and improvements | 208.6 |  |  | 201.4 |  |
| Machinery and equipment | 612.9 |  |  | 603.2 |  |
| Construction in progress and equipment not yet in service | 32.1 |  |  | 24.0 |  |
| Total | 883.0 |  |  | 854.7 |  |
| Less accumulated depreciation | (584.8 | ) |  | (554.0 | ) |
| Property, plant and equipment, net | $ | 298.2 |  |  | $ | 300.7 |  |

[0001069202-13-000003:notes:302]
The balances above include capital lease assets comprised of buildings and improvements and machinery and equipment totaling $14.4 million and $16.6 million, net of accumulated depreciation of $8.9 million and $7.2 million for the years ended December 31, 2012 and 2011, respectively.

[0001069202-13-000003:notes:303]
We recorded $0.2 million in machinery and equipment impairment for assets that are no longer in use for the year ended December 31, 2011.  No impairment charges were recorded in 2012 or 2010.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001069202-13-000003:notes:304]
Property, Plant and Equipment

[0001069202-13-000003:notes:305]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized and expenditures for maintenance and repairs are charged to expense as incurred.  Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-13-000003:notes:306]
| Buildings and improvements | 2 to 40 years |
| Machinery and equipment: |  |
| Computer software and equipment | 1 to 5 years |
| Other machinery and equipment | 3 to 10 years |

[0001069202-13-000003:notes:307]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  In order to assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 6 for additional information on our property, plant and equipment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-13-000003:notes:308]
Quarterly Financial Information (unaudited):

[0001069202-13-000003:notes:309]
The following tables provide information on net sales, gross profit, net income, earnings per share and dividends declared per share by quarter (in millions, except per share data):

[0001069202-13-000003:notes:310]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (Loss) (1) |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| First Quarter | $ | 614.4 |  |  | $ | 582.6 |  |  | $ | 140.9 |  |  | $ | 130.9 |  |  | $ | (6.1 | ) |  | $ | (7.2 | ) |
| Second Quarter | 840.4 |  |  | 808.6 |  |  | 208.1 |  |  | 199.0 |  |  | 44.7 |  |  | 45.0 |  |
| Third Quarter | 809.7 |  |  | 801.2 |  |  | 204.9 |  |  | 186.6 |  |  | 29.4 |  |  | 33.8 |  |
| Fourth Quarter | 684.9 |  |  | 648.5 |  |  | 168.4 |  |  | 153.4 |  |  | 21.9 |  |  | 16.7 |  |

[0001069202-13-000003:notes:311]
|  | Basic Earnings (Loss) per Share (2) |  | Diluted Earnings (Loss) per Share (2) |  | Dividends per Common Share (2) |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| First Quarter | $ | (0.12 | ) |  | $ | (0.13 | ) |  | $ | (0.12 | ) |  | $ | (0.13 | ) |  | $ | 0.18 |  |  | $ | 0.18 |  |
| Second Quarter | 0.88 |  |  | 0.85 |  |  | 0.87 |  |  | 0.83 |  |  | 0.18 |  |  | 0.18 |  |
| Third Quarter | 0.58 |  |  | 0.65 |  |  | 0.57 |  |  | 0.64 |  |  | 0.20 |  |  | 0.18 |  |
| Fourth Quarter | 0.44 |  |  | 0.32 |  |  | 0.43 |  |  | 0.32 |  |  | 0.20 |  |  | 0.18 |  |

[0001069202-13-000003:notes:312]
(1)   The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-13-000003:notes:313]
(2)   EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.

[0001069202-13-000003:notes:314]
Summary of 2012 Quarterly Results

[0001069202-13-000003:notes:315]
The following unusual or infrequent pre-tax items were included in the 2012 quarterly results:

[0001069202-13-000003:notes:316]
1st Quarter.  We recorded a $6.3 million charge for the write-down of net assets to their estimated fair value related to our Hearth business.  Refer to Note 17 for more information.  We also recognized $2.6 million primarily in lease termination charges related to the Regional Distribution Network restructuring plan.  Refer to Note 16 for more details on this restructuring plan.

[0001069202-13-000003:notes:317]
2nd Quarter.  Related to the sale of our Hearth business, we recorded a $6.3 million settlement charge as a result of actuarial losses recognized upon transition of a pension obligation to the acquirer of the business.  Partially offsetting this charge was a $3.5 million gain in the second quarter of 2012 related to realized foreign currency translation adjustments.  Refer to Note 17 for more information.

[0001069202-13-000003:notes:318]
3rd Quarter.  We recorded a goodwill impairment of $20.5 million related to the Service Experts business.  Partially offsetting this charge was a $2.9 million gain for a working capital adjustment to the net proceeds associated with the sale of the Hearth business.  Refer to Note 17 for more information on these charges.

[0001069202-13-000003:notes:319]
4th Quarter.  No significant unusual or infrequent items.

[0001069202-13-000003:notes:320]
Summary of 2011 Quarterly Results

[0001069202-13-000003:notes:321]
The following unusual or infrequent pre-tax items were included in the 2011 quarterly results:

[0001069202-13-000003:notes:322]
Impairments.  In the fourth quarter of 2011, we recorded asset impairments of $6.7 million and goodwill impairment of $7.6 million related to our Hearth business.  Refer to Note 17 for more information.

[0001069202-13-000003:notes:323]
Restructuring Expenses. We recorded restructuring charges as follows: First quarter - $2.3 million, Second quarter - $1.0 million, Third quarter - $8.0 million and Fourth quarter - $1.2 million.  Refer to Note 16 for more information on our restructuring activities.


## us-gaap:ReceivablesPolicyTextBlock

[0001069202-13-000003:notes:324]
Accounts and Notes Receivable

[0001069202-13-000003:notes:325]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts. The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is maintained at a level deemed appropriate based on historical and other factors that affect collectability.  Such factors include the historical trends of write-offs and recovery of previously written-off accounts, the financial strength of the customer and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and write-off of uncollectible receivables after management's review of factors that affect collectability as noted above, among other considerations.  We have no significant concentrations of credit risk within our accounts and notes receivable.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-13-000003:notes:326]
Restructuring Charges:

[0001069202-13-000003:notes:327]
As part of the effort to achieve our strategic priorities of manufacturing and sourcing excellence and expense reduction, we initiated various rationalization actions designed to lower our cost structure.  As more fully explained in Note 19, restructuring charges are not included in our calculation of segment profit (loss).

[0001069202-13-000003:notes:328]
Detailed below are descriptions of the ongoing restructuring actions and their related activity in 2012.

[0001069202-13-000003:notes:329]
Refrigeration

[0001069202-13-000003:notes:330]
We began to exit OEM coil manufacturing and contract coil manufacturing in our Refrigeration operations in Milperra, Australia in 2010.  The exit of our OEM coil manufacturing was substantially complete in 2010.  We initiated restructuring activities related to the exit of contract coil manufacturing in the third quarter of 2010, and in 2012, we recognized the remaining $0.6 million in plant closure costs.  Also, in 2012, we reversed $0.3 million in estimated severance expenses based on actual costs incurred.  We do not expect to incur any future costs related to the exit of OEM coil manufacturing or contract coil manufacturing in Milperra, Australia.

[0001069202-13-000003:notes:331]
Corporate and Other

[0001069202-13-000003:notes:332]
In the third quarter of 2011, we terminated our airplane lease, closed the aviation department, and reorganized certain support functions within our organization.  Substantially all of the costs related to these activities were recognized in the third quarter of 2011 and consisted of $4.3 million in lease termination costs, $1.1 million in severance costs and $0.4 million in accelerated depreciation and other charges.  We do not expect to incur any future costs related to this restructuring activity.

[0001069202-13-000003:notes:333]
Regional Distribution Network

[0001069202-13-000003:notes:334]
In the fourth quarter of 2008, we commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa to other locations, including our North American Distribution Center in Marshalltown, Iowa. In 2012, we recorded expense of $2.7 million primarily related to lease termination charges.  We do not expect to incur any future costs related to this restructuring activity.

[0001069202-13-000003:notes:335]
Total Restructuring

[0001069202-13-000003:notes:336]
Information regarding the restructuring charges for all plans related to continuing operations is as follows (in millions):

[0001069202-13-000003:notes:337]
|  | ChargesIncurred in2012 |  | ChargesIncurred toDate |  | TotalChargesExpected tobe Incurred |
| Severance and related expense | $ | 1.2 |  |  | $ | 27.3 |  |  | $ | 27.3 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 10.0 |  |  | 10.0 |  |
| Equipment moves | 0.1 |  |  | 1.5 |  |  | 1.5 |  |
| Lease termination | 2.4 |  |  | 7.2 |  |  | 7.2 |  |
| Other | 0.5 |  |  | 12.2 |  |  | 12.2 |  |
| Total | $ | 4.2 |  |  | $ | 58.2 |  |  | $ | 58.2 |  |

[0001069202-13-000003:notes:338]
Information regarding the restructuring charges by segment is as follows (in millions):

[0001069202-13-000003:notes:339]
|  | ChargesIncurred in2012 |  | ChargesIncurred toDate |  | TotalChargesExpected tobe Incurred |
| Residential Heating & Cooling | $ | 2.7 |  |  | $ | 20.4 |  |  | $ | 20.4 |  |
| Commercial Heating & Cooling | — |  |  | 7.8 |  |  | 7.8 |  |
| Refrigeration | 1.6 |  |  | 24.3 |  |  | 24.3 |  |
| Corporate & Other | (0.1 | ) |  | 5.7 |  |  | 5.7 |  |
| Total | $ | 4.2 |  |  | $ | 58.2 |  |  | $ | 58.2 |  |

[0001069202-13-000003:notes:340]
Restructuring reserves related to continuing operations are included in Accrued Expenses in the accompanying Consolidated Balance Sheets. The table below details activity within the restructuring reserves (in millions):

[0001069202-13-000003:notes:341]
| Description of Reserves | Balance as ofDecember 31, 2011 |  | ChargedtoEarnings |  | CashUtilization |  | Non-CashUtilizationand Other |  | Balance as ofDecember 31, 2012 |
| Severance and related expense | $ | 2.3 |  |  | $ | 1.2 |  |  | $ | (2.8 | ) |  | $ | — |  |  | $ | 0.7 |  |
| Asset write-offs and accelerated depreciation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Equipment moves | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Lease termination | — |  |  | 2.4 |  |  | (1.2 | ) |  | — |  |  | 1.2 |  |
| Other | 0.1 |  |  | 0.5 |  |  | — |  |  | (0.1 | ) |  | 0.5 |  |
| Total restructuring reserves | $ | 2.4 |  |  | $ | 4.2 |  |  | $ | (4.1 | ) |  | $ | (0.1 | ) |  | $ | 2.4 |  |

[0001069202-13-000003:notes:342]
| Description of Reserves | Balance as of December 31, 2010 |  | ChargedtoEarnings |  | CashUtilization |  | Non-CashUtilizationand Other |  | Balance as of December 31, 2011 |
| Severance and related expense | $ | 3.7 |  |  | $ | 3.8 |  |  | $ | (5.2 | ) |  | $ | — |  |  | $ | 2.3 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 1.0 |  |  | 0.3 |  |  | (1.3 | ) |  | — |  |
| Equipment moves | — |  |  | 0.5 |  |  | (0.5 | ) |  | — |  |  | — |  |
| Lease termination | 0.2 |  |  | 4.1 |  |  | (4.3 | ) |  | — |  |  | — |  |
| Other | 0.2 |  |  | 3.1 |  |  | (3.2 | ) |  | — |  |  | 0.1 |  |
| Total restructuring reserves | $ | 4.1 |  |  | $ | 12.5 |  |  | $ | (12.9 | ) |  | $ | (1.3 | ) |  | $ | 2.4 |  |

[0001069202-13-000003:notes:343]
Plans related to Discontinued Operations

[0001069202-13-000003:notes:344]
We began to reorganize certain administrative functions and the management structure of our Service Experts business in the

[0001069202-13-000003:notes:345]
fourth quarter of 2010.  In 2012, we recognized $1.1 million of severance and other costs in Loss from discontinued operations.  Restructuring reserves of $0.2 million are included in Liabilities of discontinued operations as of December 31, 2012.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001069202-13-000003:notes:346]
Revenue Recognition

[0001069202-13-000003:notes:347]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenues are recognized for these transactions when products are shipped to customers and title passes.  However, certain customers in our smaller operations, primarily outside of North America, have shipping terms where title and risk of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenues are recognized on the date that the product is received and accepted by such customers.  We have experienced returns for miscellaneous reasons and we record a reserve for these returns based on historical experience at the time we recognize revenue.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.

[0001069202-13-000003:notes:348]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for these services is recognized ratably over the life of the contract.

[0001069202-13-000003:notes:349]
We engage in cooperative advertising, customer rebate, cash discount and other miscellaneous programs that result in payments or credits being issued to our customers.  Our policy is to record the discounts and incentives as a reduction of sales when the sales are recorded, with the exception of certain cooperative advertising expenditures that are charged to Selling, General and Administrative (“SG&A”) Expenses.   Under these cooperative advertising programs, we receive, or will receive, an identifiable benefit (goods or services) in exchange for the consideration given.  All other advertising, promotions and marketing costs are expensed as incurred.  Refer to Note 23 for more information on these costs.


## us-gaap:ScheduleOfOtherOperatingCostAndExpenseByComponentTextBlock

[0001069202-13-000003:notes:350]
Below is information about expenses included in our Consolidated Statements of Operations (in millions):

[0001069202-13-000003:notes:351]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Research and development(1) | $ | 50.7 |  |  | $ | 50.3 |  |  | $ | 49.5 |  |
| Advertising, promotions and marketing(2) | 59.4 |  |  | 58.4 |  |  | 63.3 |  |
| Cooperative advertising expenditures(3) | 9.5 |  |  | 9.7 |  |  | 10.2 |  |
| Rent expense(4) | 67.8 |  |  | 69.6 |  |  | 64.3 |  |

[0001069202-13-000003:notes:352]
(1) Includes research and development costs related to discontinued operations of $1.2 million, $3.3 million and $3.1 million for the years ended December 31, 2012, 2011 and 2010, respectively.

[0001069202-13-000003:notes:353]
(2) Includes advertising, promotions and marketing costs related to discontinued operations of $20.1 million, $22.2 million and $20.3 million for the years ended December 31, 2012, 2011 and 2010, respectively.  Cooperative advertising expenditures are not included in these amounts.

[0001069202-13-000003:notes:354]
(3) Cooperative advertising expenditures are included in Selling, general and administrative expenses in the Consolidated Statements of Operations.

[0001069202-13-000003:notes:355]
(4) Includes rent expense related to discontinued operations of $20.1 million, $20.7 million and $22.0 million for the years ended December 31, 2012, 2011 and 2010, respectively.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-13-000003:notes:356]
Net sales and segment profit (loss) by business segment, along with a reconciliation of segment profit (loss) to Income from continuing operations before income taxes are shown below (in millions):

[0001069202-13-000003:notes:357]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 1,375.8 |  |  | $ | 1,259.5 |  |  | $ | 1,338.5 |  |
| Commercial Heating & Cooling | 785.4 |  |  | 776.2 |  |  | 695.8 |  |
| Refrigeration | 788.2 |  |  | 805.2 |  |  | 550.9 |  |
|  | $ | 2,949.4 |  |  | $ | 2,840.9 |  |  | $ | 2,585.2 |  |
| Segment Profit (Loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 102.9 |  |  | $ | 87.6 |  |  | $ | 146.8 |  |
| Commercial Heating & Cooling | 99.5 |  |  | 87.6 |  |  | 77.8 |  |
| Refrigeration | 81.9 |  |  | 77.5 |  |  | 61.4 |  |
| Corporate and other | (60.1 | ) |  | (54.9 | ) |  | (66.0 | ) |
| Subtotal that includes segment profit and eliminations | 224.2 |  |  | 197.8 |  |  | 220.0 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |
| Special product quality adjustment | 1.1 |  |  | (4.3 | ) |  | (0.2 | ) |
| Items in (Gains) losses and other expenses, net that are excluded from segment profit (3) | (0.2 | ) |  | 5.2 |  |  | 4.3 |  |
| Restructuring charges | 4.2 |  |  | 12.5 |  |  | 11.4 |  |
| Interest expense, net | 17.1 |  |  | 16.8 |  |  | 12.8 |  |
| Other expense, net | 0.3 |  |  | 0.3 |  |  | 1.0 |  |
| Income from continuing operations before income taxes | $ | 201.7 |  |  | $ | 167.3 |  |  | $ | 190.7 |  |

[0001069202-13-000003:notes:358]
(1) On a consolidated basis, no revenues from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-13-000003:notes:359]
(2) We define segment profit and loss as a segment's income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding the following:

[0001069202-13-000003:notes:360]
| • | Special product quality adjustments; |

[0001069202-13-000003:notes:361]
| • | Items in (Gains) losses and other expenses, net (see table note 3 below); |

[0001069202-13-000003:notes:362]
| • | Restructuring charges; |

[0001069202-13-000003:notes:363]
| • | Goodwill, long-lived asset, and equity method investment impairments; |

[0001069202-13-000003:notes:364]
| • | Interest expense, net; |

[0001069202-13-000003:notes:365]
| • | Other expense, net. |

[0001069202-13-000003:notes:366]
(3) Items in (Gains) losses and other expenses, net that are excluded from segment profit include the following:  asset impairment, net change in unrealized gains and/or losses on open futures contracts, special legal contingency charge, and other items.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-13-000003:notes:367]
Reportable Business Segments:

[0001069202-13-000003:notes:368]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our segments are organized primarily by the nature of the products and services provided.

[0001069202-13-000003:notes:369]
In September 2012, we announced the planned sale of our Service Experts business. The Service Experts business had previously been reported within our Service Experts segment along with a commercial service business called Lennox National Account Services (NAS).  Beginning in the third quarter of 2012, the Service Experts business was included in discontinued operations, NAS was included in our Commercial Heating & Cooling segment, and the Service Experts reportable segment was eliminated. Segment results for all periods have been revised to conform to this new presentation.

[0001069202-13-000003:notes:370]
The table below details the nature of the operations for each reportable segment:

[0001069202-13-000003:notes:371]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |

[0001069202-13-000003:notes:372]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources. We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation below details the items excluded.

[0001069202-13-000003:notes:373]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII. We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-13-000003:notes:374]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results. There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-13-000003:notes:375]
Total assets by business segment are shown below (in millions).  The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-13-000003:notes:376]
|  | As of December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Total Assets |  |  |  |  |  |
| Residential Heating & Cooling | $ | 457.5 |  |  | $ | 453.2 |  |  | $ | 474.6 |  |
| Commercial Heating & Cooling | 321.9 |  |  | 306.4 |  |  | 299.1 |  |
| Refrigeration | 585.3 |  |  | 558.2 |  |  | 389.7 |  |
| Corporate and other | 228.6 |  |  | 227.4 |  |  | 349.7 |  |
| Total assets | 1,593.3 |  |  | 1,545.2 |  |  | 1,513.1 |  |
| Discontinued operations (See Note 17) | 98.6 |  |  | 160.5 |  |  | 178.9 |  |
| Total assets | $ | 1,691.9 |  |  | $ | 1,705.7 |  |  | $ | 1,692.0 |  |

[0001069202-13-000003:notes:377]
Total capital expenditures by business segment are shown below (in millions):

[0001069202-13-000003:notes:378]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Capital Expenditures |  |  |  |  |  |
| Residential Heating & Cooling | $ | 13.7 |  |  | $ | 10.9 |  |  | $ | 17.2 |  |
| Commercial Heating & Cooling | 8.7 |  |  | 6.7 |  |  | 6.5 |  |
| Refrigeration | 15.6 |  |  | 13.2 |  |  | 6.9 |  |
| Corporate and other | 12.2 |  |  | 10.6 |  |  | 12.5 |  |
| Total capital expenditures | $ | 50.2 |  |  | $ | 41.4 |  |  | $ | 43.1 |  |

[0001069202-13-000003:notes:379]
There were no significant new capital leases in 2012, 2011 or 2010.

[0001069202-13-000003:notes:380]
The depreciation and amortization expenses by business segment are shown below (in millions):

[0001069202-13-000003:notes:381]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Depreciation and Amortization |  |  |  |  |  |
| Residential Heating & Cooling | $ | 19.9 |  |  | $ | 19.6 |  |  | $ | 18.8 |  |
| Commercial Heating & Cooling | 8.5 |  |  | 8.6 |  |  | 8.5 |  |
| Refrigeration | 13.0 |  |  | 14.8 |  |  | 8.7 |  |
| Corporate and other | 14.0 |  |  | 13.6 |  |  | 12.9 |  |
| Total depreciation and amortization | $ | 55.4 |  |  | $ | 56.6 |  |  | $ | 48.9 |  |

[0001069202-13-000003:notes:382]
The equity method investments are shown below (in millions):

[0001069202-13-000003:notes:383]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Income from Equity Method Investments |  |  |  |  |  |
| Refrigeration | $ | 2.6 |  |  | $ | 2.5 |  |  | $ | 1.3 |  |
| Corporate and other(1) | 7.9 |  |  | 7.1 |  |  | 8.8 |  |
| Total income from equity method investments | $ | 10.5 |  |  | $ | 9.6 |  |  | $ | 10.1 |  |

[0001069202-13-000003:notes:384]
(1) A significant portion of income for equity method investments is allocated to our Residential Heating & Cooling and Commercial Heating & Cooling segments.  We allocated $5.0 million, $4.9 million and $5.6 million to those segments in 2012, 2011 and 2010 respectively.

[0001069202-13-000003:notes:385]
The following tables set forth certain financial information relating to our operations by geographic area based on the domicile of our operations (in millions):

[0001069202-13-000003:notes:386]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Net Sales to External Customers by Point of Shipment |  |  |  |  |  |
| United States | $ | 2,147.2 |  |  | $ | 2,018.1 |  |  | $ | 1,866.4 |  |
| Canada | 226.7 |  |  | 219.2 |  |  | 214.5 |  |
| International | 575.5 |  |  | 603.6 |  |  | 504.3 |  |
| Total net sales to external customers | $ | 2,949.4 |  |  | $ | 2,840.9 |  |  | $ | 2,585.2 |  |

[0001069202-13-000003:notes:387]
|  | As of December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Property, Plant and Equipment, net |  |  |  |  |  |
| United States | $ | 227.9 |  |  | $ | 233.4 |  |  | $ | 215.0 |  |
| Mexico | 28.0 |  |  | 28.0 |  |  | 33.0 |  |
| Canada | 0.6 |  |  | 0.6 |  |  | 0.7 |  |
| International | 41.7 |  |  | 38.7 |  |  | 59.8 |  |
| Total property, plant and equipment, net | $ | 298.2 |  |  | $ | 300.7 |  |  | $ | 308.5 |  |


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001069202-13-000003:notes:388]
Selling, General and Administrative Expenses

[0001069202-13-000003:notes:389]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-13-000003:notes:390]
Summary of Significant Accounting Policies:

[0001069202-13-000003:notes:391]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  We review goodwill and indefinite-lived intangible assets for impairment in the first quarter of each year and whenever events or changes in circumstances indicate the carrying value of an asset may not be recoverable.  The provisions of the accounting standard for goodwill and other intangibles allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors for LII as a whole and for each reporting unit.  Specifically, we monitor industry trends, our market capitalization, recent and forecasted financial performance of our reporting units, and the timing and nature of our restructuring activities.

[0001069202-13-000003:notes:392]
We assign goodwill to the reporting units that benefit from the synergies of our acquisitions.  If we reorganize our management structure, the related goodwill is allocated to the affected reporting units based upon the relative fair values of those reporting units.   Assets and liabilities, including deferred income taxes, are generally directly assigned to the reporting units.  However, certain assets and liabilities, including intellectual property assets, information technology assets and pension, self-insurance, and environmental liabilities, are commonly managed and are not allocated to the segments in the normal course of our financial reporting process, and therefore must be assigned to the reporting units based upon appropriate methods.  We test goodwill for impairment by reporting unit.

[0001069202-13-000003:notes:393]
Reporting units that we test are generally equivalent to our business segments, or in some cases, one level below.  We review our reporting unit structure each year as part of our annual goodwill impairment testing and reporting units are determined based upon a review of the periodic financial information supplied to and reviewed by our Chief Executive Officer (the chief operating decision maker).  We aggregate operating units reviewed into reporting units when those operating units share similar economic characteristics.

[0001069202-13-000003:notes:394]
We did not have any impairments of goodwill related to continuing operations in 2011 or 2012.  See Note 17 for information on impairments of goodwill related to discontinued operations.

[0001069202-13-000003:notes:395]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-13-000003:notes:396]
| Asset | Useful Life |
| Deferred financing costs | Effective interest method |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |

[0001069202-13-000003:notes:397]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  In order to assess recoverability, we compare the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets. If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of our other intangibles, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-13-000003:notes:398]
We did not have any impairments of intangible assets related to continuing operations in 2011 or 2012.  See Note 17 for information on impairments of intangible assets related to discontinued operations.

[0001069202-13-000003:notes:399]
Product Warranties

[0001069202-13-000003:notes:400]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties for heat exchangers.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined for each product line. The number of units we expect to repair or replace is determined by applying the estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. The estimated units to be repaired under warranty are multiplied by the average cost to repair or replace such products to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically identified warranty obligations.  Estimated future warranty costs are subject to adjustment from time to time depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 11 for more information on our estimated future warranty costs.

[0001069202-13-000003:notes:401]
Pensions and Post-retirement Benefits

[0001069202-13-000003:notes:402]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheets.  Changes in the funded status are recognized in the year in which the changes occur through accumulated other comprehensive income (“AOCI”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-13-000003:notes:403]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management's estimates, revisions to the benefit plan assets and liabilities would be required.  For additional disclosures on pension and post-retirement medical benefits, including how we determine the assumptions used, see Note 13.

[0001069202-13-000003:notes:404]
Self-Insurance

[0001069202-13-000003:notes:405]
Self-insurance expense and liabilities, calculated on an undiscounted basis, are actuarially determined based primarily on our historical claims information, as well as industry factors and trends.  As of December 31, 2012, self-insurance reserves represent the best estimate of the future payments to be made on reported and unreported losses for 2012 and prior years.  The majority of our self-insured risks (excluding auto liability and physical damage) will be paid over an extended period of time.

[0001069202-13-000003:notes:406]
Actual payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liability may change.  For additional disclosures on self-insured risks and reserves, see Note 11.

[0001069202-13-000003:notes:407]
Stock-Based Compensation

[0001069202-13-000003:notes:408]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We base stock-based compensation costs on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and adjust expected vesting rates to actual rates as additional information becomes known.  We also adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  For more information, see Note 14.

[0001069202-13-000003:notes:409]
Use of Estimates

[0001069202-13-000003:notes:410]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-13-000003:notes:411]
We evaluate our estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency, and commodity markets combined to increase the uncertainty inherent in such estimates and assumptions.  As future events and their effects cannot be determined with precision, actual results could differ significantly from these estimates.  Changes in those estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-13-000003:notes:412]
Reclassifications

[0001069202-13-000003:notes:413]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-13-000003:notes:414]
Stock Repurchases:

[0001069202-13-000003:notes:415]
In 2008, our Board of Directors approved a $300 million share repurchase plan, with no stated expiration date, authorizing the repurchase of shares of our common stock through open market purchases (the “2008 Share Repurchase Plan”).  In December 2011, our Board of Directors increased the authorized amount of shares that could be repurchased under the 2008 Share Repurchase Plan by $100 million to $400 million.  In 2012, we used $50.1 million to acquire 1.1 million shares of stock under this share repurchase plan, and as of December 31, 2012, $71.2 million of shares may yet be purchased.

[0001069202-13-000003:notes:416]
In December 2012, our Board of Directors approved a $300 million share repurchase plan, with no stated expiration date,  authorizing the repurchase of shares of our common stock through open market purchases (the "2012 Share Repurchase Plan").  As of December 31, 2012, no shares were repurchased under this plan.


## lii:CondensedConsolidatingFinancialStatementsTableTextBlock

[0001069202-13-000003:notes:417]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2012 and December 31, 2011 and for the years ended December 31, 2012, 2011 and 2010 are shown on the following pages:

[0001069202-13-000003:notes:418]
Condensed Consolidating Balance Sheets

[0001069202-13-000003:notes:419]
As of December 31, 2012

[0001069202-13-000003:notes:420]
(In millions)

[0001069202-13-000003:notes:421]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 13.4 |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net | (1,178.0 | ) |  | 1,076.0 |  |  | 427.2 |  |  | 48.2 |  |  | 373.4 |  |
| Inventories, net | — |  |  | 257.3 |  |  | 121.5 |  |  | (4.0 | ) |  | 374.8 |  |
| Deferred income taxes, net | — |  |  | 22.9 |  |  | 6.3 |  |  | (1.7 | ) |  | 27.5 |  |
| Other assets | (0.6 | ) |  | 23.8 |  |  | 97.5 |  |  | (59.7 | ) |  | 61.0 |  |
| Assets of discontinued operations | — |  |  | 21.2 |  |  | 77.4 |  |  | — |  |  | 98.6 |  |
| Total current assets | (1,177.6 | ) |  | 1,414.6 |  |  | 767.3 |  |  | (17.2 | ) |  | 987.1 |  |
| Property, plant and equipment, net | — |  |  | 239.7 |  |  | 58.5 |  |  | — |  |  | 298.2 |  |
| Goodwill | — |  |  | 131.8 |  |  | 92.0 |  |  | — |  |  | 223.8 |  |
| Deferred income taxes | — |  |  | 87.8 |  |  | 20.8 |  |  | (5.8 | ) |  | 102.8 |  |
| Other assets, net(1) | 2,176.3 |  |  | 488.5 |  |  | 30.3 |  |  | (2,615.1 | ) |  | 80.0 |  |
| Total assets | $ | 998.7 |  |  | $ | 2,362.4 |  |  | $ | 968.9 |  |  | $ | (2,638.1 | ) |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 101.9 |  |  | $ | — |  |  | $ | (51.0 | ) |  | $ | (16.0 | ) |  | $ | 34.9 |  |
| Current maturities of long-term debt | — |  |  | 0.5 |  |  | 0.2 |  |  | — |  |  | 0.7 |  |
| Accounts payable | — |  |  | 133.7 |  |  | 92.0 |  |  | 59.0 |  |  | 284.7 |  |
| Accrued expenses | 2.5 |  |  | 196.6 |  |  | 60.8 |  |  | (0.3 | ) |  | 259.6 |  |
| Income taxes payable | (27.3 | ) |  | 35.1 |  |  | 38.5 |  |  | (41.8 | ) |  | 4.5 |  |
| Liabilities of discontinued operations | — |  |  | 42.3 |  |  | 12.9 |  |  | — |  |  | 55.2 |  |
| Total current liabilities | 77.1 |  |  | 408.2 |  |  | 153.4 |  |  | 0.9 |  |  | 639.6 |  |
| Long-term debt | 335.0 |  |  | 15.6 |  |  | 98.7 |  |  | (98.3 | ) |  | 351.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 6.1 |  |  | — |  |  | — |  |  | 6.1 |  |
| Pensions | — |  |  | 114.7 |  |  | 19.7 |  |  | — |  |  | 134.4 |  |
| Other liabilities | 0.5 |  |  | 60.1 |  |  | 10.6 |  |  | (7.2 | ) |  | 64.0 |  |
| Total liabilities | 412.6 |  |  | 604.7 |  |  | 282.4 |  |  | (104.6 | ) |  | 1,195.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 586.1 |  |  | 1,757.7 |  |  | 686.5 |  |  | (2,533.5 | ) |  | 496.8 |  |
| Total liabilities and stockholders' equity | $ | 998.7 |  |  | $ | 2,362.4 |  |  | $ | 968.9 |  |  | $ | (2,638.1 | ) |  | $ | 1,691.9 |  |

[0001069202-13-000003:notes:422]
| (1) | Other assets, net consists primarily of Investments in subsidiaries which eliminate upon consolidation. |

[0001069202-13-000003:notes:423]
Condensed Consolidating Statements of Operations

[0001069202-13-000003:notes:424]
For the Year Ended December 31, 2012

[0001069202-13-000003:notes:425]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,327.7 |  |  | $ | 824.0 |  |  | $ | (202.3 | ) |  | $ | 2,949.4 |  |
| Cost of goods sold | 0.2 |  |  | 1,799.6 |  |  | 629.2 |  |  | (201.9 | ) |  | 2,227.1 |  |
| Gross profit | (0.2 | ) |  | 528.1 |  |  | 194.8 |  |  | (0.4 | ) |  | 722.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 374.3 |  |  | 132.7 |  |  | — |  |  | 507.0 |  |
| Losses and other expenses, net | (1.7 | ) |  | 1.1 |  |  | 3.2 |  |  | (0.1 | ) |  | 2.5 |  |
| Restructuring charges | — |  |  | 2.8 |  |  | 1.4 |  |  | — |  |  | 4.2 |  |
| Income from equity method investments | (116.3 | ) |  | (17.0 | ) |  | (7.8 | ) |  | 130.6 |  |  | (10.5 | ) |
| Operational income from continuing operations | 117.8 |  |  | 166.9 |  |  | 65.3 |  |  | (130.9 | ) |  | 219.1 |  |
| Interest expense, net | 16.6 |  |  | (2.4 | ) |  | 2.9 |  |  | — |  |  | 17.1 |  |
| Other expense, net | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Income from continuing operations before income taxes | 101.2 |  |  | 169.3 |  |  | 62.1 |  |  | (130.9 | ) |  | 201.7 |  |
| Provision for income taxes | (4.9 | ) |  | 50.5 |  |  | 21.2 |  |  | (0.1 | ) |  | 66.7 |  |
| Income from continuing operations | 106.1 |  |  | 118.8 |  |  | 40.9 |  |  | (130.8 | ) |  | 135.0 |  |
| Loss from discontinued operations | — |  |  | (18.5 | ) |  | (26.5 | ) |  | — |  |  | (45.0 | ) |
| Net income | $ | 106.1 |  |  | $ | 100.3 |  |  | $ | 14.4 |  |  | $ | (130.8 | ) |  | $ | 90.0 |  |
| Other comprehensive income | $ | 6.7 |  |  | $ | (2.8 | ) |  | $ | 5.2 |  |  | $ | 5.7 |  |  | $ | 14.8 |  |

[0001069202-13-000003:notes:426]
As of December 31, 2011

[0001069202-13-000003:notes:427]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 9.7 |  |  | $ | 34.3 |  |  | $ | — |  |  | $ | 45.0 |  |
| Accounts and notes receivable, net | (991.9 | ) |  | 944.5 |  |  | 413.8 |  |  | 20.6 |  |  | 387.0 |  |
| Inventories, net | — |  |  | 217.1 |  |  | 105.5 |  |  | (4.7 | ) |  | 317.9 |  |
| Deferred income taxes, net | 4.7 |  |  | 22.0 |  |  | 8.4 |  |  | (1.3 | ) |  | 33.8 |  |
| Other assets | 1.6 |  |  | 16.6 |  |  | 111.0 |  |  | (60.7 | ) |  | 68.5 |  |
| Assets of discontinued operations | — |  |  | 29.1 |  |  | 131.4 |  |  | — |  |  | 160.5 |  |
| Total current assets | (984.6 | ) |  | 1,239.0 |  |  | 804.4 |  |  | (46.1 | ) |  | 1,012.7 |  |
| Property, plant and equipment, net | — |  |  | 248.2 |  |  | 52.5 |  |  | — |  |  | 300.7 |  |
| Goodwill | — |  |  | 131.7 |  |  | 91.5 |  |  | — |  |  | 223.2 |  |
| Deferred income taxes | 0.2 |  |  | 82.0 |  |  | 18.2 |  |  | (9.7 | ) |  | 90.7 |  |
| Other assets, net(1) | 2,174.6 |  |  | 531.2 |  |  | 22.2 |  |  | (2,649.6 | ) |  | 78.4 |  |
| Total assets | $ | 1,190.2 |  |  | $ | 2,232.1 |  |  | $ | 988.8 |  |  | $ | (2,705.4 | ) |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 112.1 |  |  | $ | — |  |  | $ | (67.3 | ) |  | $ | (40.1 | ) |  | $ | 4.7 |  |
| Current maturities of long-term debt | — |  |  | 0.6 |  |  | 0.2 |  |  | — |  |  | 0.8 |  |
| Accounts payable | 9.2 |  |  | 120.9 |  |  | 93.4 |  |  | 31.4 |  |  | 254.9 |  |
| Accrued expenses | 15.3 |  |  | 146.7 |  |  | 77.4 |  |  | — |  |  | 239.4 |  |
| Income taxes payable | (29.9 | ) |  | 28.4 |  |  | 27.4 |  |  | (20.2 | ) |  | 5.7 |  |
| Liabilities of discontinued operations | — |  |  | 54.8 |  |  | 16.8 |  |  | — |  |  | 71.6 |  |
| Total current liabilities | 106.7 |  |  | 351.4 |  |  | 147.9 |  |  | (28.9 | ) |  | 577.1 |  |
| Long-term debt | 443.0 |  |  | 16.2 |  |  | 97.3 |  |  | (96.9 | ) |  | 459.6 |  |
| Post-retirement benefits, other than pensions | — |  |  | 18.6 |  |  | — |  |  | — |  |  | 18.6 |  |
| Pensions | — |  |  | 111.9 |  |  | 12.8 |  |  | — |  |  | 124.7 |  |
| Other liabilities | 0.8 |  |  | 54.8 |  |  | 13.3 |  |  | (11.0 | ) |  | 57.9 |  |
| Total liabilities | 550.5 |  |  | 552.9 |  |  | 271.3 |  |  | (136.8 | ) |  | 1,237.9 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 639.7 |  |  | 1,679.2 |  |  | 717.5 |  |  | (2,568.6 | ) |  | 467.8 |  |
| Total liabilities and stockholders' equity | $ | 1,190.2 |  |  | $ | 2,232.1 |  |  | $ | 988.8 |  |  | $ | (2,705.4 | ) |  | $ | 1,705.7 |  |

[0001069202-13-000003:notes:428]
For the Year Ended December 31, 2011

[0001069202-13-000003:notes:429]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,190.1 |  |  | $ | 850.1 |  |  | $ | (199.3 | ) |  | $ | 2,840.9 |  |
| Cost of goods sold | 0.2 |  |  | 1,721.0 |  |  | 650.6 |  |  | (200.8 | ) |  | 2,171.0 |  |
| Gross profit | (0.2 | ) |  | 469.1 |  |  | 199.5 |  |  | 1.5 |  |  | 669.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 327.0 |  |  | 149.9 |  |  | — |  |  | 476.9 |  |
| Losses and other expenses, net | 12.1 |  |  | 1.4 |  |  | (7.8 | ) |  | — |  |  | 5.7 |  |
| Restructuring charges | — |  |  | 10.8 |  |  | 1.7 |  |  | — |  |  | 12.5 |  |
| Income from equity method investments | (135.3 | ) |  | (31.2 | ) |  | (7.1 | ) |  | 164.0 |  |  | (9.6 | ) |
| Operational income from continuing operations | 123.0 |  |  | 161.1 |  |  | 62.8 |  |  | (162.5 | ) |  | 184.4 |  |
| Interest expense, net | 16.8 |  |  | (4.0 | ) |  | 4.0 |  |  | — |  |  | 16.8 |  |
| Other expense, net | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Income from continuing operations before income taxes | 106.2 |  |  | 165.1 |  |  | 58.5 |  |  | (162.5 | ) |  | 167.3 |  |
| Provision for income taxes | (9.8 | ) |  | 46.0 |  |  | 19.1 |  |  | 0.5 |  |  | 55.8 |  |
| Income from continuing operations | 116.0 |  |  | 119.1 |  |  | 39.4 |  |  | (163.0 | ) |  | 111.5 |  |
| Loss from discontinued operations | — |  |  | (29.8 | ) |  | 6.6 |  |  | — |  |  | (23.2 | ) |
| Net income | $ | 116.0 |  |  | $ | 89.3 |  |  | $ | 46.0 |  |  | $ | (163.0 | ) |  | $ | 88.3 |  |
| Other comprehensive income | $ | (16.9 | ) |  | $ | (22.4 | ) |  | $ | (27.3 | ) |  | $ | (0.7 | ) |  | $ | (67.3 | ) |

[0001069202-13-000003:notes:430]
For the Year Ended December 31, 2010

[0001069202-13-000003:notes:431]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,671.5 |  |  | $ | 1,070.2 |  |  | $ | (156.5 | ) |  | $ | 2,585.2 |  |
| Cost of goods sold | 0.2 |  |  | 1,234.9 |  |  | 799.1 |  |  | (150.2 | ) |  | 1,884.0 |  |
| Gross profit | (0.2 | ) |  | 436.6 |  |  | 271.1 |  |  | (6.3 | ) |  | 701.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 321.5 |  |  | 166.0 |  |  | 4.5 |  |  | 492.0 |  |
| Losses and other expenses, net | (0.6 | ) |  | 4.6 |  |  | 4.4 |  |  | (5.0 | ) |  | 3.4 |  |
| Restructuring charges | — |  |  | 1.5 |  |  | 9.9 |  |  | — |  |  | 11.4 |  |
| Income from equity method investments | (138.8 | ) |  | (11.8 | ) |  | (10.1 | ) |  | 150.6 |  |  | (10.1 | ) |
| Operational income from continuing operations | 139.2 |  |  | 120.8 |  |  | 100.9 |  |  | (156.4 | ) |  | 204.5 |  |
| Interest expense, net | 12.4 |  |  | (3.0 | ) |  | 3.8 |  |  | (0.4 | ) |  | 12.8 |  |
| Other expense, net | — |  |  | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| Income from continuing operations before income taxes | 126.8 |  |  | 123.8 |  |  | 96.1 |  |  | (156.0 | ) |  | 190.7 |  |
| Provision for income taxes | (4.4 | ) |  | 37.8 |  |  | 24.8 |  |  | 6.6 |  |  | 64.8 |  |
| Income from continuing operations | 131.2 |  |  | 86.0 |  |  | 71.3 |  |  | (162.6 | ) |  | 125.9 |  |
| Loss from discontinued operations | — |  |  | (15.8 | ) |  | (2.7 | ) |  | 8.8 |  |  | (9.7 | ) |
| Net income | $ | 131.2 |  |  | $ | 70.2 |  |  | $ | 68.6 |  |  | $ | (153.8 | ) |  | $ | 116.2 |  |
| Other comprehensive income | $ | 5.7 |  |  | $ | (1.5 | ) |  | $ | 25.3 |  |  | $ | 1.5 |  |  | $ | 31.0 |  |

[0001069202-13-000003:notes:432]
Condensed Consolidating Statements of Cash Flows

[0001069202-13-000003:notes:433]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 20.7 |  |  | $ | 207.3 |  |  | $ | (6.6 | ) |  | $ | — |  |  | $ | 221.4 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (37.7 | ) |  | (12.5 | ) |  | — |  |  | (50.2 | ) |
| Net proceeds from sale of businesses | — |  |  | 10.1 |  |  | — |  |  | — |  |  | 10.1 |  |
| Net cash used in discontinued operations | — |  |  | (0.5 | ) |  | 0.1 |  |  | — |  |  | (0.4 | ) |
| Net cash used in investing activities | — |  |  | (28.0 | ) |  | (12.4 | ) |  | — |  |  | (40.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 645.0 |  |  | — |  |  | 645.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (615.0 | ) |  | — |  |  | (615.0 | ) |
| Long-term debt payments | — |  |  | (0.7 | ) |  | (0.4 | ) |  | — |  |  | (1.1 | ) |
| Borrowings from revolving credit facility | 967.0 |  |  | — |  |  | — |  |  | — |  |  | 967.0 |  |
| Payments on revolving credit facility | (1,075.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,075.0 | ) |
| Proceeds from stock option exercises | 0.8 |  |  | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Repurchases of common stock | (57.9 | ) |  | — |  |  | — |  |  | — |  |  | (57.9 | ) |
| Excess tax benefits related to share-based payments | 3.5 |  |  | — |  |  | — |  |  | — |  |  | 3.5 |  |
| Intercompany debt | 2.4 |  |  | (4.0 | ) |  | 1.6 |  |  | — |  |  | — |  |
| Intercompany financing activity | 186.1 |  |  | (170.9 | ) |  | (15.2 | ) |  | — |  |  | — |  |
| Cash dividends paid | (47.6 | ) |  | — |  |  | — |  |  | — |  |  | (47.6 | ) |
| Net cash (used in) provided by financing activities | (20.7 | ) |  | (175.6 | ) |  | 16.2 |  |  | — |  |  | (180.1 | ) |
| Increase in cash and cash equivalents | — |  |  | 3.7 |  |  | (2.8 | ) |  | — |  |  | 0.9 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 9.7 |  |  | 34.3 |  |  | — |  |  | 45.0 |  |
| Cash and cash equivalents, end of year | $ | 1.0 |  |  | $ | 13.4 |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 51.8 |  |

[0001069202-13-000003:notes:434]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (2.6 | ) |  | $ | 18.0 |  |  | $ | 60.8 |  |  | $ | — |  |  | $ | 76.2 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (34.2 | ) |  | (7.2 | ) |  | — |  |  | (41.4 | ) |
| Net proceeds from sale of businesses | — |  |  | — |  |  | 0.6 |  |  | — |  |  | 0.6 |  |
| Acquisition of businesses | — |  |  | (147.7 | ) |  | — |  |  | — |  |  | (147.7 | ) |
| Change in restricted cash | — |  |  | — |  |  | 12.2 |  |  | — |  |  | 12.2 |  |
| Net cash used in discontinued operations | — |  |  | (1.5 | ) |  | (0.2 | ) |  | — |  |  | (1.7 | ) |
| Net cash used in investing activities | — |  |  | (183.3 | ) |  | 5.5 |  |  | — |  |  | (177.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 345.0 |  |  | — |  |  | 345.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (345.0 | ) |  | — |  |  | (345.0 | ) |
| Long-term debt payments | — |  |  | (0.8 | ) |  | (0.1 | ) |  | — |  |  | (0.9 | ) |
| Borrowings from revolving credit facility | 1,539.5 |  |  | — |  |  | — |  |  | — |  |  | 1,539.5 |  |
| Payments on revolving credit facility | (1,396.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,396.5 | ) |
| Proceeds from stock option exercises | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |
| Payments of deferred financing costs | (2.2 | ) |  | — |  |  | — |  |  | — |  |  | (2.2 | ) |
| Repurchases of common stock | (123.0 | ) |  | — |  |  | — |  |  | — |  |  | (123.0 | ) |
| Excess tax benefits related to share-based payments | 1.4 |  |  | — |  |  | — |  |  | — |  |  | 1.4 |  |
| Intercompany debt | 115.1 |  |  | (8.1 | ) |  | (107.0 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (177.8 | ) |  | 169.2 |  |  | 8.6 |  |  | — |  |  | — |  |
| Cash dividends paid | (36.5 | ) |  | — |  |  | — |  |  | — |  |  | (36.5 | ) |
| Net cash used in financing activities | (77.5 | ) |  | 160.3 |  |  | (94.7 | ) |  | — |  |  | (11.9 | ) |
| Decrease in cash and cash equivalents | (80.1 | ) |  | (5.0 | ) |  | (28.4 | ) |  | — |  |  | (113.5 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (1.5 | ) |  | — |  |  | (1.5 | ) |
| Cash and cash equivalents, beginning of year | 81.1 |  |  | 14.7 |  |  | 64.2 |  |  | — |  |  | 160.0 |  |
| Cash and cash equivalents, end of year | $ | 1.0 |  |  | $ | 9.7 |  |  | $ | 34.3 |  |  | $ | — |  |  | $ | 45.0 |  |


## lii:LossesGainsAndOtherExpensesNetTextBlock

[0001069202-13-000003:notes:435]
Losses and Other Expenses, net:

[0001069202-13-000003:notes:436]
Losses and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-13-000003:notes:437]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Realized losses (gains) on settled futures contracts | $ | 1.5 |  |  | $ | (0.1 | ) |  | $ | (1.5 | ) |
| Foreign currency exchange losses | 0.8 |  |  | 1.4 |  |  | 0.5 |  |
| Loss (gain) on disposal of fixed assets | 0.4 |  |  | (0.8 | ) |  | 0.1 |  |
| Asset impairments | — |  |  | 0.2 |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (2.2 | ) |  | 3.8 |  |  | (0.6 | ) |
| Gain on sale of entity | — |  |  | (0.1 | ) |  | (0.2 | ) |
| Acquisition expenses(1) | 0.1 |  |  | 1.0 |  |  | 4.9 |  |
| Special legal contingency charge(2) | 1.2 |  |  | — |  |  | — |  |
| Other items, net | 0.7 |  |  | 0.3 |  |  | 0.2 |  |
| Losses and other expenses, net | $ | 2.5 |  |  | $ | 5.7 |  |  | $ | 3.4 |  |

[0001069202-13-000003:notes:438]
(1)  Acquisition expenses in 2010 and 2011 primarily relate to the Kysor/Warren acquisition.  Note 3 provides more information on this acquisition.

[0001069202-13-000003:notes:439]
(2)  Special legal contingency charge in 2012 relates to patent litigation claims involving products from an acquired business.  For more information, see Note 11.


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0001069202-13-000003:notes:440]
Condensed Consolidating Financial Statements:

[0001069202-13-000003:notes:441]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-13-000003:notes:442]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001069202-13-000003:notes:443]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  Intercompany account balances have been included in Accounts and notes receivable, Other assets (Current), Other assets, net, Short-term debt, Accounts payable, and Long-term debt line items of the Parent, Guarantor and Non-Guarantor balance sheets. The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001069202-13-000003:notes:444]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (115.4 | ) |  | $ | 345.4 |  |  | $ | (44.2 | ) |  | $ | — |  |  | $ | 185.8 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (36.4 | ) |  | (6.7 | ) |  | — |  |  | (43.1 | ) |
| Net proceeds from sale of businesses | — |  |  | 0.1 |  |  | 3.5 |  |  | — |  |  | 3.6 |  |
| Acquisition of businesses | — |  |  | (7.2 | ) |  | — |  |  | — |  |  | (7.2 | ) |
| Change in restricted cash | — |  |  | — |  |  | (12.2 | ) |  | — |  |  | (12.2 | ) |
| Net cash used in discontinued operations | — |  |  | (1.8 | ) |  | (0.8 | ) |  | — |  |  | (2.6 | ) |
| Net cash used in investing activities | — |  |  | (45.2 | ) |  | (16.2 | ) |  | — |  |  | (61.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term debt payments | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Long-term debt payments | (35.0 | ) |  | (0.5 | ) |  | (0.4 | ) |  | — |  |  | (35.9 | ) |
| Issuance of senior unsecured notes | 199.8 |  |  | — |  |  | — |  |  | — |  |  | 199.8 |  |
| Borrowings from revolving credit facility | 981.5 |  |  | — |  |  | — |  |  | — |  |  | 981.5 |  |
| Payments on revolving credit facility | (1,058.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,058.0 | ) |
| Proceeds from stock option exercises | 3.5 |  |  | — |  |  | — |  |  | — |  |  | 3.5 |  |
| Additional investment in affiliates | — |  |  | — |  |  | (1.0 | ) |  | — |  |  | (1.0 | ) |
| Payments of deferred financing costs | (1.8 | ) |  | — |  |  | — |  |  | — |  |  | (1.8 | ) |
| Repurchases of common stock | (153.7 | ) |  | — |  |  | — |  |  | — |  |  | (153.7 | ) |
| Excess tax benefits related to share-based payments | 5.3 |  |  | — |  |  | — |  |  | — |  |  | 5.3 |  |
| Intercompany debt | 90.8 |  |  | (107.8 | ) |  | 17.0 |  |  | — |  |  | — |  |
| Intercompany financing activity | 194.6 |  |  | (183.8 | ) |  | (10.8 | ) |  | — |  |  | — |  |
| Intercompany investments | (7.9 | ) |  | — |  |  | 7.9 |  |  | — |  |  | — |  |
| Intercompany dividends | 9.0 |  |  | — |  |  | (9.0 | ) |  | — |  |  | — |  |
| Cash dividends paid | (32.4 | ) |  | — |  |  | — |  |  | — |  |  | (32.4 | ) |
| Net cash used in financing activities | 195.7 |  |  | (292.1 | ) |  | 2.9 |  |  | — |  |  | (93.5 | ) |
| Increase in cash and cash equivalents | 80.3 |  |  | 8.1 |  |  | (57.5 | ) |  | — |  |  | 30.9 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 4.8 |  |  | — |  |  | 4.8 |  |
| Cash and cash equivalents, beginning of year | 0.8 |  |  | 6.6 |  |  | 116.9 |  |  | — |  |  | 124.3 |  |
| Cash and cash equivalents, end of year | $ | 81.1 |  |  | $ | 14.7 |  |  | $ | 64.2 |  |  | $ | — |  |  | $ | 160.0 |  |


## lii:ScheduleOfInterestIncomeExpenseTableTextBlock

[0001069202-13-000003:notes:445]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-13-000003:notes:446]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Interest expense, net of capitalized interest | $ | 18.9 |  |  | $ | 18.7 |  |  | $ | 13.7 |  |
| Interest income | 1.8 |  |  | 1.9 |  |  | 0.9 |  |
| Interest expense, net | $ | 17.1 |  |  | $ | 16.8 |  |  | $ | 12.8 |  |


## lii:SupplementalInformationTextBlock

[0001069202-13-000003:notes:447]
Supplemental Information:

[0001069202-13-000003:notes:448]
Interest Expense, net
