# LII 8-K — 0001193125-13-037706 filed 2013-02-05

## item codes, every 8-K on or before 2013-02-15

- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2013-02-15

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-13-037706:8k_2_02:1]
EX-99.1
2
d477630dex991.htm
PRESS RELEASE DATED FEBRUARY 5, 2013

[0001193125-13-037706:8k_2_02:2]
Press Release dated February 5, 2013

[0001193125-13-037706:8k_2_02:3]
Exhibit 99.1

[0001193125-13-037706:8k_2_02:4]
Lennox International Reports Fourth Quarter and Full Year 2012 Results

[0001193125-13-037706:8k_2_02:5]
|  | • |  | 4Q12 revenue up 6% with growth in all business segments, led by 9% Residential growth |

[0001193125-13-037706:8k_2_02:6]
|  | • |  | 4Q12 adjusted EPS from continuing operations of $0.56 and GAAP EPS from continuing operations of $0.52 |

[0001193125-13-037706:8k_2_02:7]
|  | • |  | 2012 revenue up 4%, with adjusted EPS from continuing operations of $2.70 up 20% and GAAP EPS from continuing operations of $2.63 up 26% |

[0001193125-13-037706:8k_2_02:8]
|  | • |  | Reiterate 2013 revenue growth guidance of 2-6% |

[0001193125-13-037706:8k_2_02:9]
|  | • |  | Reiterate 2013 EPS from continuing operations guidance of $3.15-$3.55 |

[0001193125-13-037706:8k_2_02:10]
DALLAS, February 5, 2013 – Lennox International Inc. (NYSE: LII) today reported fourth quarter and full year 2012 results. Financial results presented have been adjusted for discontinued
operations related to the company’s previously announced plans to divest the Service Experts business.

[0001193125-13-037706:8k_2_02:11]
For the fourth quarter, revenue
was $685 million, up 6% from the prior-year quarter. Total segment profit margin was 6.2% compared to 7.0% in the prior-year quarter. Diluted earnings per share from continuing operations on an adjusted basis was $0.56 compared to $0.55 in the
prior-year quarter. Diluted earnings per share from continuing operations on a GAAP basis was $0.52 compared to $0.56 in the fourth quarter a year ago.

[0001193125-13-037706:8k_2_02:12]
For the full year, revenue was $2.9 billion, up 4% from the prior year. At constant currency, revenue was up 5%. Total segment profit margin was 7.6% compared to 7.0% in the prior year. Diluted earnings
per share from continuing operations on an adjusted basis was $2.70, up 20% from $2.25 in 2011. Diluted earnings per share from continuing operations on a GAAP basis was $2.63, up 26% from $2.09 in the prior year.

[0001193125-13-037706:8k_2_02:13]
“The company’s performance in 2012 was led by our Residential business, which significantly outperformed the market on gains in replacement
business and strong growth in new construction,” said Chairman & CEO Todd Bluedorn. “Residential revenue was up 9% with profit up 17% for the year. In the face of flat commercial markets in 2012, our Refrigeration and Commercial
businesses had strong operational performance. Refrigeration revenue was flat at constant currency with profit up 6%. Commercial revenue was up 3% at constant currency with profit up 14%. For the company overall, free cash flow was strong for the
year at 190% of GAAP net income. The company paid $48 million in dividends and repurchased $50 million of stock in 2012.

[0001193125-13-037706:8k_2_02:14]
“In the fourth quarter, momentum continued with revenue growth and strong operational performance
across all our businesses. Margins were impacted by higher incentive compensation, as planned and previously discussed, as performance targets were achieved or exceeded in 2012, compared to 2011 when incentive compensation was significantly lower.
Residential revenue was up 9% and Refrigeration revenue was up 2% in the quarter at constant currency, with margins down on the higher incentive compensation. Residential margin was also impacted by lower mix and a step-up in the quarter for
strategic investments in distribution expansion. In Commercial, revenue was up 5% at constant currency, primarily on the strength of non-national account business, and margin expanded 220 basis points to 13.5% to drive Commercial profit up 25%.

[0001193125-13-037706:8k_2_02:15]
“Looking ahead at 2013 overall, we reiterate our guidance for revenue growth of 2-6% and EPS from continuing operations of $3.15-$3.55.
The company is competitively well-positioned for continued market outperformance for the year. With our solid balance sheet and strong cash generation, we will continue to invest in the business and maintain a competitive dividend, and we plan to
repurchase $100 million of stock in 2013.”

[0001193125-13-037706:8k_2_02:16]
FOURTH QUARTER 2012 FINANCIAL HIGHLIGHTS

[0001193125-13-037706:8k_2_02:17]
Revenue: Revenue for the fourth quarter was $685 million, up 6% from the prior-year quarter. Foreign exchange was neutral to revenue. Volume and
price/mix were up from the fourth quarter a year ago.

[0001193125-13-037706:8k_2_02:18]
Gross Profit: Gross profit in the fourth quarter was $168 million, up 10% from
$153 million in the prior-year quarter. Gross margin was 24.6%, up 90 basis points from 23.7% in the fourth quarter a year ago. Gross profit was positively impacted by higher volume, favorable price/mix, and lower material costs, with a partial
offset from strategic investments in distribution.

[0001193125-13-037706:8k_2_02:19]
Income from Continuing Operations: For the fourth quarter, adjusted income from
continuing operations was $29 million, or $0.56 diluted earnings per share, compared to $29 million, or $0.55 diluted earnings per share from continuing operations in the prior-year quarter. On a GAAP basis, fourth quarter 2012 income from
continuing operations was $27 million, or $0.52 diluted earnings per share, compared to $29 million, or $0.56 diluted earnings per share from continuing operations in the prior-year quarter.

[0001193125-13-037706:8k_2_02:20]
Adjusted income from continuing operations for the fourth quarter of 2012 excludes net after-tax charges of $2.0 million, which are derived from:

[0001193125-13-037706:8k_2_02:21]
|  | • | $0.8 million for a special legal contingency charge |

[0001193125-13-037706:8k_2_02:22]
|  | • | $0.7 million charge related to restructuring activities |

[0001193125-13-037706:8k_2_02:23]
|  | • | $0.3 million net change in unrealized losses on open future contracts |

[0001193125-13-037706:8k_2_02:24]
|  | • | $0.2 million charge from other items, net |

[0001193125-13-037706:8k_2_02:25]
FULL YEAR 2012 FINANCIAL HIGHLIGHTS

[0001193125-13-037706:8k_2_02:26]
Revenue: For the full year, revenue was $2.9 billion, up 4%. At constant currency, revenue was up 5%. Volume was up, and price/mix was flat for the full year.

[0001193125-13-037706:8k_2_02:27]
Gross Profit: Gross profit for the full year was $722 million, up 8% from $670 million in the prior year. Gross margin was 24.5%, up 90 basis
points from 23.6% in the prior year. Gross profit was positively impacted by higher volume and lower material costs, with a partial offset from strategic investments in distribution.

[0001193125-13-037706:8k_2_02:28]
Income from Continuing Operations: Adjusted income from continuing operations for 2012 was $139 million, or $2.70 diluted earnings per share, compared to $120 million, or $2.25 diluted earnings per
share from continuing operations in the prior year. On a GAAP basis, income from continuing operations for 2012 was $135 million, or $2.63 diluted earnings per share, compared to $112 million, or $2.09 diluted earnings per share from continuing
operations in the prior year.

[0001193125-13-037706:8k_2_02:29]
Adjusted income from continuing operations for 2012 excludes after-tax charges of $3.6 million, net, which are
derived from:

[0001193125-13-037706:8k_2_02:30]
|  | • | $2.7 million charge for restructuring activities |

[0001193125-13-037706:8k_2_02:31]
|  | • | $1.4 million net change in unrealized gains on open future contracts |

[0001193125-13-037706:8k_2_02:32]
|  | • | $0.9 million charge related to special product quality adjustments |

[0001193125-13-037706:8k_2_02:33]
|  | • | $0.8 million for a special legal contingency charge |

[0001193125-13-037706:8k_2_02:34]
|  | • | $0.6 million charge for other items, net |

[0001193125-13-037706:8k_2_02:35]
Free Cash Flow and Total Debt: Cash from operations for the fourth quarter was $157 million, up from $78 million in the prior-year quarter.
Capital expenditures were $22 million in the fourth quarter compared to $16 million in the prior-year quarter. Free cash flow was $135 million, up from $63 million in the prior-year quarter. For the full year, cash from operations was approximately
$221 million, up from $76 million in 2011. Capital expenditures were $50 million in 2012 compared to $41 million in 2011. Free cash flow was $171 million for the full year, up from $35 million in the prior year. The company repurchased $50 million
of stock and paid $48 million of dividends in 2012. Total debt at the end of 2012 was $387 million, down $94 million from the third quarter and down $79 million from a year ago. Total cash and cash equivalents were $52 million ending 2012.

[0001193125-13-037706:8k_2_02:36]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001193125-13-037706:8k_2_02:37]
Residential Heating and Cooling

[0001193125-13-037706:8k_2_02:38]
|  | • |  | 4Q12 revenue of $305 million, up 9% from $280 million in the prior-year quarter; foreign exchange was neutral |

[0001193125-13-037706:8k_2_02:39]
|  | • |  | 4Q12 segment profit of $12 million, down 27% from $17 million in 4Q11 |

[0001193125-13-037706:8k_2_02:40]
|  | • |  | 4Q12 segment profit margin of 4.0%, down 200 basis points from 6.0% in 4Q11 |

[0001193125-13-037706:8k_2_02:41]
|  | • |  | 2012 revenue of $1,376 million, up 9% from $1,260 million in the prior year; foreign exchange was neutral |

[0001193125-13-037706:8k_2_02:42]
|  | • |  | 2012 segment profit of $103 million, up 17% from $88 million in 2011 |

[0001193125-13-037706:8k_2_02:43]
|  | • |  | 2012 profit margin of 7.5%, up 50 basis points from 7.0% in 2011 |

[0001193125-13-037706:8k_2_02:44]
Fourth quarter results were negatively impacted by higher incentive compensation, lower mix, and strategic investments in distribution expansion, with offsets from higher volume and lower material costs.
Full-year results were positively impacted by higher volume, favorable price, and lower material costs, with offsets from higher incentive compensation, lower mix, and strategic investments in distribution expansion.

[0001193125-13-037706:8k_2_02:45]
Commercial Heating and Cooling

[0001193125-13-037706:8k_2_02:46]
|  | • |  | 4Q12 revenue of $188 million, up 4% from $180 million in the prior-year quarter; up 5% at constant currency |

[0001193125-13-037706:8k_2_02:47]
|  | • |  | 4Q12 segment profit of $25 million, up 25% from $20 million in 4Q11 |

[0001193125-13-037706:8k_2_02:48]
|  | • |  | 4Q12 segment profit margin of 13.5%, up 220 basis points from 11.3% in 4Q11 |

[0001193125-13-037706:8k_2_02:49]
|  | • |  | 2012 revenue of $785 million, up 1% from $776 million in 2011; up 3% at constant currency |

[0001193125-13-037706:8k_2_02:50]
|  | • |  | 2012 segment profit of $100 million, up 14% from $88 million in 2011 |

[0001193125-13-037706:8k_2_02:51]
|  | • |  | 2012 segment profit margin of 12.7%, up 140 basis points from 11.3% in 2011 |

[0001193125-13-037706:8k_2_02:52]
Fourth quarter and full year results were positively impacted by higher volume, favorable price/mix, and lower material costs, with an offset from higher incentive compensation.

[0001193125-13-037706:8k_2_02:53]
Refrigeration

[0001193125-13-037706:8k_2_02:54]
|  | • |  | 4Q12 revenue of $192 million, up 2% from $189 million in the prior-year quarter; foreign exchange was neutral |

[0001193125-13-037706:8k_2_02:55]
|  | • |  | 4Q12 segment profit of $21 million, down 4% from $22 million in 4Q11 |

[0001193125-13-037706:8k_2_02:56]
|  | • |  | 4Q12 segment profit margin of 11.1%, down 60 basis points from 11.7% in 4Q11 |

[0001193125-13-037706:8k_2_02:57]
|  | • |  | 2012 revenue of $788 million, down 2% from $805 million in 2011; flat at constant currency |

[0001193125-13-037706:8k_2_02:58]
|  | • |  | 2012 segment profit of $82 million, up 6% from $78 million in 2011 |

[0001193125-13-037706:8k_2_02:59]
|  | • |  | 2012 segment profit margin of 10.4%, up 80 basis points from 9.6% in 2011 |

[0001193125-13-037706:8k_2_02:60]
Fourth quarter results were negatively impacted by higher incentive compensation, with offsets from higher volume, favorable price/mix, and lower material costs. Full-year results were positively impacted
by favorable price/mix and lower material costs, with offsets from lower volume, higher incentive compensation, and foreign exchange.

[0001193125-13-037706:8k_2_02:61]
2013 FULL YEAR OUTLOOK

[0001193125-13-037706:8k_2_02:62]
The company reiterates its 2013 guidance, originally provided on December 12, 2012:

[0001193125-13-037706:8k_2_02:63]
|  | • |  | Revenue growth of 2-6%, with a neutral impact from foreign exchange |

[0001193125-13-037706:8k_2_02:64]
|  | • |  | EPS from continuing operations of $3.15 to $3.55 |

[0001193125-13-037706:8k_2_02:65]
|  | • |  | Tax rate of 34-35% |

[0001193125-13-037706:8k_2_02:66]
|  | • |  | Capital expenditures of approximately $60 million |

[0001193125-13-037706:8k_2_02:67]
|  | • |  | Stock repurchases of $100 million |

[0001193125-13-037706:8k_2_02:68]
CONFERENCE CALL INFORMATION

[0001193125-13-037706:8k_2_02:69]
A conference call to discuss the company’s fourth quarter
and full year 2012 results will be held this morning at 8:30 a.m. Central time. To listen, please call the conference call line at 612-288-0337 at least 10 minutes prior to the scheduled start time and use reservation number 278932. This conference
call will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0001193125-13-037706:8k_2_02:70]
A replay will be available from
11:00 a.m. Central time on February 5 through February 12, 2013, by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 278932. This call will also be archived on the company’s web site.

[0001193125-13-037706:8k_2_02:71]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New
York Stock Exchange under the symbol “LII.” Additional information is available at http://www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-13-037706:8k_2_02:72]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-037706:8k_2_02:73]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-13-037706:8k_2_02:74]
(Unaudited, in millions, except per share data)

[0001193125-13-037706:8k_2_02:75]
|  |  | For the Three MonthsEnded December 31, |  |  | For the YearsEnded December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net sales |  | $ | 684.9 |  |  | $ | 648.5 |  |  | $ | 2,949.4 |  |  | $ | 2,840.9 |  |
| Cost of goods sold |  |  | 516.5 |  |  |  | 495.1 |  |  |  | 2,227.1 |  |  |  | 2,171.0 |  |
| Gross profit |  |  | 168.4 |  |  |  | 153.4 |  |  |  | 722.3 |  |  |  | 669.9 |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 127.2 |  |  |  | 104.0 |  |  |  | 507.0 |  |  |  | 476.9 |  |
| Losses and other expenses, net |  |  | 2.3 |  |  |  | 2.1 |  |  |  | 2.5 |  |  |  | 5.7 |  |
| Restructuring charges |  |  | 1.1 |  |  |  | 1.2 |  |  |  | 4.2 |  |  |  | 12.5 |  |
| Income from equity method investments |  |  | (1.6 | ) |  |  | (0.6 | ) |  |  | (10.5 | ) |  |  | (9.6 | ) |
| Operational income from continuing operations |  |  | 39.4 |  |  |  | 46.7 |  |  |  | 219.1 |  |  |  | 184.4 |  |
| Interest expense, net |  |  | 3.6 |  |  |  | 4.3 |  |  |  | 17.1 |  |  |  | 16.8 |  |
| Other expense |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Income from continuing operations before income taxes |  |  | 35.6 |  |  |  | 42.2 |  |  |  | 201.7 |  |  |  | 167.3 |  |
| Provision for income taxes |  |  | 9.1 |  |  |  | 13.4 |  |  |  | 66.7 |  |  |  | 55.8 |  |
| Income from continuing operations |  |  | 26.5 |  |  |  | 28.8 |  |  |  | 135.0 |  |  |  | 111.5 |  |
| Discontinued operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations |  |  | (7.7 | ) |  |  | (19.0 | ) |  |  | (64.9 | ) |  |  | (36.7 | ) |
| Benefit from income taxes |  |  | (3.1 | ) |  |  | (6.9 | ) |  |  | (19.9 | ) |  |  | (13.5 | ) |
| Loss from discontinued operations |  |  | (4.6 | ) |  |  | (12.1 | ) |  |  | (45.0 | ) |  |  | (23.2 | ) |
| Net income |  | $ | 21.9 |  |  | $ | 16.7 |  |  | $ | 90.0 |  |  | $ | 88.3 |  |
| Earnings per share—Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.53 |  |  | $ | 0.56 |  |  | $ | 2.66 |  |  | $ | 2.12 |  |
| Loss from discontinued operations |  |  | (0.09 | ) |  |  | (0.24 | ) |  |  | (0.89 | ) |  |  | (0.44 | ) |
| Net income |  | $ | 0.44 |  |  | $ | 0.32 |  |  | $ | 1.77 |  |  | $ | 1.68 |  |
| Earnings per share—Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 2.63 |  |  | $ | 2.09 |  |
| Loss from discontinued operations |  |  | (0.09 | ) |  |  | (0.24 | ) |  |  | (0.88 | ) |  |  | (0.44 | ) |
| Net income |  | $ | 0.43 |  |  | $ | 0.32 |  |  | $ | 1.75 |  |  | $ | 1.65 |  |
| Average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 50.3 |  |  |  | 51.2 |  |  |  | 50.7 |  |  |  | 52.5 |  |
| Diluted |  |  | 51.1 |  |  |  | 51.7 |  |  |  | 51.4 |  |  |  | 53.4 |  |
| Cash dividends declared per share |  | $ | 0.20 |  |  | $ | 0.18 |  |  | $ | 0.76 |  |  | $ | 0.72 |  |

[0001193125-13-037706:8k_2_02:76]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-037706:8k_2_02:77]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001193125-13-037706:8k_2_02:78]
(Unaudited, in millions)

[0001193125-13-037706:8k_2_02:79]
|  |  | For the Three MonthsEnded December 31, |  |  | For the Years Ended December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 305.0 |  |  | $ | 279.8 |  |  | $ | 1,375.8 |  |  | $ | 1,259.5 |  |
| Commercial Heating & Cooling |  |  | 187.5 |  |  |  | 179.8 |  |  |  | 785.4 |  |  |  | 776.2 |  |
| Refrigeration |  |  | 192.4 |  |  |  | 188.9 |  |  |  | 788.2 |  |  |  | 805.2 |  |
|  |  | $ | 684.9 |  |  | $ | 648.5 |  |  | $ | 2,949.4 |  |  | $ | 2,840.9 |  |
| Segment Profit (Loss) (A) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 12.2 |  |  | $ | 16.7 |  |  | $ | 102.9 |  |  | $ | 87.6 |  |
| Commercial Heating & Cooling |  |  | 25.4 |  |  |  | 20.4 |  |  |  | 99.5 |  |  |  | 87.6 |  |
| Refrigeration |  |  | 21.3 |  |  |  | 22.1 |  |  |  | 81.9 |  |  |  | 77.5 |  |
| Corporate and other |  |  | (16.4 | ) |  |  | (13.5 | ) |  |  | (60.1 | ) |  |  | (54.9 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 42.5 |  |  |  | 45.7 |  |  |  | 224.2 |  |  |  | 197.8 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | 0.1 |  |  |  | (1.9 | ) |  |  | 1.1 |  |  |  | (4.3 | ) |
| Items in losses and other expenses, net that are excluded from segment profit (loss) (B) |  |  | 1.9 |  |  |  | (0.3 | ) |  |  | (0.2 | ) |  |  | 5.2 |  |
| Restructuring charges |  |  | 1.1 |  |  |  | 1.2 |  |  |  | 4.2 |  |  |  | 12.5 |  |
| Interest expense, net |  |  | 3.6 |  |  |  | 4.3 |  |  |  | 17.1 |  |  |  | 16.8 |  |
| Other Expense, net |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Income from continuing operations before income taxes |  | $ | 35.6 |  |  | $ | 42.2 |  |  | $ | 201.7 |  |  | $ | 167.3 |  |

[0001193125-13-037706:8k_2_02:80]
| (A) | The Company defines segment profit and loss as a segment’s Income or Loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |

[0001193125-13-037706:8k_2_02:81]
Excluding:

[0001193125-13-037706:8k_2_02:82]
|  | • |  | Special product quality adjustments; |

[0001193125-13-037706:8k_2_02:83]
|  | • |  | Items within Gains and/or losses and other expenses, net that are noted in (B); |

[0001193125-13-037706:8k_2_02:84]
|  | • |  | Restructuring charges; |

[0001193125-13-037706:8k_2_02:85]
|  | • |  | Goodwill, long-lived assets and and equity method investment impairments; |

[0001193125-13-037706:8k_2_02:86]
|  | • |  | Interest expense, net; |

[0001193125-13-037706:8k_2_02:87]
|  | • |  | Other expense, net; |

[0001193125-13-037706:8k_2_02:88]
| (B) | Items in losses and other expenses, net that are excluded from segment profit or loss are asset impairments, net change in unrealized gains and/or losses on open future contracts, special legal contingency charges, and other items. |

[0001193125-13-037706:8k_2_02:89]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-037706:8k_2_02:90]
CONSOLIDATED BALANCE SHEETS

[0001193125-13-037706:8k_2_02:91]
(In millions, except share and per share data)

[0001193125-13-037706:8k_2_02:92]
|  |  | As of December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| ASSETS |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 51.8 |  |  | $ | 45.0 |  |
| Accounts and notes receivable, net of allowances of $9.5 and $11.3 in 2012 and 2011, respectively |  |  | 373.4 |  |  |  | 387.0 |  |
| Inventories, net |  |  | 374.8 |  |  |  | 317.9 |  |
| Deferred income taxes |  |  | 27.5 |  |  |  | 33.8 |  |
| Other assets |  |  | 61.0 |  |  |  | 68.5 |  |
| Assets of discontinued operations |  |  | 98.6 |  |  |  | 160.5 |  |
| Total current assets |  |  | 987.1 |  |  |  | 1,012.7 |  |
| Property, plant and equipment, net of accumulated depreciation of $584.8 and $554.0 in 2012 and 2011, respectively |  |  | 298.2 |  |  |  | 300.7 |  |
| Goodwill |  |  | 223.8 |  |  |  | 223.2 |  |
| Deferred income taxes |  |  | 102.8 |  |  |  | 90.7 |  |
| Other assets, net |  |  | 80.0 |  |  |  | 78.4 |  |
| Total assets |  | $ | 1,691.9 |  |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 34.9 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt |  |  | 0.7 |  |  |  | 0.8 |  |
| Accounts payable |  |  | 284.7 |  |  |  | 254.9 |  |
| Accrued expenses |  |  | 259.6 |  |  |  | 239.4 |  |
| Income taxes payable |  |  | 4.5 |  |  |  | 5.7 |  |
| Liabilities of discontinued operations |  |  | 55.2 |  |  |  | 71.6 |  |
| Total current liabilities |  |  | 639.6 |  |  |  | 577.1 |  |
| Long-term debt |  |  | 351.0 |  |  |  | 459.6 |  |
| Postretirement benefits, other than pensions |  |  | 6.1 |  |  |  | 18.6 |  |
| Pensions |  |  | 134.4 |  |  |  | 124.7 |  |
| Other liabilities |  |  | 64.0 |  |  |  | 57.9 |  |
| Total liabilities |  |  | 1,195.1 |  |  |  | 1,237.9 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares and 86,938,004 shares issued for 2012 and 2011, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 898.3 |  |  |  | 881.2 |  |
| Retained earnings |  |  | 744.4 |  |  |  | 692.9 |  |
| Accumulated other comprehensive income |  |  | (22.3 | ) |  |  | (37.1 | ) |
| Treasury stock, at cost, 36,937,632 shares and 36,093,966 shares for 2012 and 2011, respectively |  |  | (1,124.5 | ) |  |  | (1,070.1 | ) |
| Total stockholders’ equity |  |  | 496.8 |  |  |  | 467.8 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,691.9 |  |  | $ | 1,705.7 |  |

[0001193125-13-037706:8k_2_02:93]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-037706:8k_2_02:94]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-13-037706:8k_2_02:95]
(Unaudited, in millions)

[0001193125-13-037706:8k_2_02:96]
|  |  | For the YearsEnded December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 90.0 |  |  | $ | 88.3 |  |
| Net loss from discontinued operations |  |  | 45.0 |  |  |  | 23.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (10.5 | ) |  |  | (9.6 | ) |
| Dividends from affiliates |  |  | 9.3 |  |  |  | 11.0 |  |
| Restructuring expenses, net of cash paid |  |  | 0.1 |  |  |  | (0.4 | ) |
| Impairment of assets |  |  | — |  |  |  | 0.2 |  |
| Provision for bad debts |  |  | 3.9 |  |  |  | 4.3 |  |
| Unrealized (gain) loss on derivative contracts |  |  | (1.0 | ) |  |  | 2.9 |  |
| Stock-based compensation expense |  |  | 15.2 |  |  |  | 13.7 |  |
| Depreciation and amortization |  |  | 55.4 |  |  |  | 56.6 |  |
| Deferred income taxes |  |  | (2.7 | ) |  |  | — |  |
| Pension costs less than contributions |  |  | (15.1 | ) |  |  | (0.1 | ) |
| Other items, net |  |  | 2.1 |  |  |  | 2.6 |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | 13.3 |  |  |  | (3.0 | ) |
| Inventories |  |  | (55.8 | ) |  |  | (29.6 | ) |
| Other current assets |  |  | (1.5 | ) |  |  | 1.4 |  |
| Accounts payable |  |  | 37.1 |  |  |  | (3.9 | ) |
| Accrued expenses |  |  | 32.9 |  |  |  | (43.3 | ) |
| Income taxes payable and receivable |  |  | 18.2 |  |  |  | (11.4 | ) |
| Other |  |  | 0.7 |  |  |  | (0.6 | ) |
| Net cash used in discontinued operations |  |  | (15.2 | ) |  |  | (26.1 | ) |
| Net cash provided by operating activities |  |  | 221.4 |  |  |  | 76.2 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 0.2 |  |
| Purchases of property, plant and equipment |  |  | (50.2 | ) |  |  | (41.4 | ) |
| Net proceeds from sale of businesses |  |  | 10.1 |  |  |  | 0.6 |  |
| Acquisition of business |  |  | — |  |  |  | (147.7 | ) |
| Change in restricted cash |  |  | — |  |  |  | 12.2 |  |
| Net cash used in discontinued operations |  |  | (0.4 | ) |  |  | (1.7 | ) |
| Net cash used in investing activities |  |  | (40.4 | ) |  |  | (177.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 0.2 |  |  |  | 3.8 |  |
| Asset securitization borrowings |  |  | 645.0 |  |  |  | 345.0 |  |
| Asset securitization payments |  |  | (615.0 | ) |  |  | (345.0 | ) |
| Long-term debt payments |  |  | (1.1 | ) |  |  | (0.9 | ) |
| Borrowings from revolving credit facility |  |  | 967.0 |  |  |  | 1,539.5 |  |
| Payments on revolving credit facility |  |  | (1,075.0 | ) |  |  | (1,396.5 | ) |
| Proceeds from stock option exercises |  |  | 0.8 |  |  |  | 2.5 |  |
| Payments of deferred financing costs |  |  | — |  |  |  | (2.2 | ) |
| Repurchases of common stock |  |  | (57.9 | ) |  |  | (123.0 | ) |
| Excess tax benefits related to share-based payments |  |  | 3.5 |  |  |  | 1.4 |  |
| Cash dividends paid |  |  | (47.6 | ) |  |  | (36.5 | ) |
| Net cash used in financing activities |  |  | (180.1 | ) |  |  | (11.9 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 0.9 |  |  |  | (113.5 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | 5.9 |  |  |  | (1.5 | ) |
| Cash and cash equivalents, beginning of year |  |  | 45.0 |  |  |  | 160.0 |  |
| Cash and cash equivalents, end of year |  | $ | 51.8 |  |  | $ | 45.0 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the period for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 18.2 |  |  | $ | 17.8 |  |
| Income taxes (net of refunds) |  | $ | 30.1 |  |  | $ | 49.5 |  |

[0001193125-13-037706:8k_2_02:97]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-037706:8k_2_02:98]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-13-037706:8k_2_02:99]
(Unaudited, In millions, except per share and ratio data)

[0001193125-13-037706:8k_2_02:100]
Use of Non-GAAP Financial Measures

[0001193125-13-037706:8k_2_02:101]
To supplement the Company’s consolidated financial
statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when
considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors
to analyze the Company’s business trends and operating performance.

[0001193125-13-037706:8k_2_02:102]
Reconciliation of Income From Continuing Operations, a GAAP
measure, to Adjusted Income From Continuing Operations, a Non-GAAP measure

[0001193125-13-037706:8k_2_02:103]
|  |  | For The Three Months |  |  | For The Years |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Income from continuing operations, a GAAP measure |  | $ | 26.5 |  |  | $ | 28.8 |  |  | $ | 135.0 |  |  | $ | 111.5 |  |
| Restructuring charges, after tax |  |  | 0.7 |  |  |  | 1.0 |  |  |  | 2.7 |  |  |  | 8.2 |  |
| Special product quality adjustments, after-tax (b) |  |  | — |  |  |  | (1.3 | ) |  |  | 0.9 |  |  |  | (2.8 | ) |
| Special legal contingency charges, after-tax (a) |  |  | 0.8 |  |  |  | — |  |  |  | 0.8 |  |  |  | — |  |
| Net change in unrealized losses (gains) on open future contracts, after tax (a) |  |  | 0.3 |  |  |  | 0.6 |  |  |  | (1.4 | ) |  |  | 3.7 |  |
| Other items, net, after tax (a) |  |  | 0.2 |  |  |  | (0.5 | ) |  |  | 0.6 |  |  |  | (0.4 | ) |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 28.5 |  |  | $ | 28.6 |  |  | $ | 138.6 |  |  | $ | 120.2 |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 2.63 |  |  | $ | 2.09 |  |
| Restructuring charges, after-tax |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.05 |  |  |  | 0.15 |  |
| Special product quality adjustments, after-tax (b) |  |  | — |  |  |  | (0.02 | ) |  |  | 0.02 |  |  |  | (0.05 | ) |
| Special legal contingency charges, after-tax (a) |  |  | 0.02 |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Net change in unrealized losses (gains) on open future contracts and other items, net, after-tax (a) |  |  | 0.01 |  |  |  | — |  |  |  | (0.02 | ) |  |  | 0.06 |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  | $ | 0.56 |  |  | $ | 0.55 |  |  | $ | 2.70 |  |  | $ | 2.25 |  |

[0001193125-13-037706:8k_2_02:104]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-13-037706:8k_2_02:105]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-13-037706:8k_2_02:106]
|  |  | For The Three Months |  |  | For The Years |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized loss (gains) on settled future contracts (a) |  | $ | 0.1 |  |  | $ | 0.9 |  |  | $ | 1.5 |  |  | $ | (0.1 | ) |
| Foreign currency exchange loss (gain) (a) |  |  | — |  |  |  | 1.4 |  |  |  | 0.8 |  |  |  | 1.4 |  |
| Loss (gain) on disposal of fixed assets (a) |  |  | 0.3 |  |  |  | 0.1 |  |  |  | 0.4 |  |  |  | (0.8 | ) |
| Asset impairment (b) |  |  | — |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Net change in unrealized losses (gains) on open futures contracts (b) |  |  | 0.3 |  |  |  | (1.2 | ) |  |  | (2.2 | ) |  |  | 3.8 |  |
| Gain on sale of entity (b) |  |  | — |  |  |  | 0.2 |  |  |  | — |  |  |  | (0.1 | ) |
| Special legal contingency charge (b) |  |  | 1.2 |  |  |  | — |  |  |  | 1.2 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.4 |  |  |  | 0.5 |  |  |  | 0.8 |  |  |  | 1.3 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 2.3 |  |  | $ | 2.1 |  |  | $ | 2.5 |  |  | $ | 5.7 |  |

[0001193125-13-037706:8k_2_02:107]
| (a) | Included in segment profit (loss) and adjusted income from continuing operations |

[0001193125-13-037706:8k_2_02:108]
| (b) | Excluded from segment profit (loss) and adjusted income from continuing operations |

[0001193125-13-037706:8k_2_02:109]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations—Diluted, a Non-GAAP
Measure, to Income per Share from Continuing Operations—Diluted, a GAAP Measure

[0001193125-13-037706:8k_2_02:110]
|  |  | For theYear EndedDecember 31,2013ESTIMATED |  |
| Adjusted income per share from continuing operations—diluted, a Non-GAAP measure |  | $ | 3.15 – $3.55 |  |
| Restructuring charges |  |  | — |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 3.15 – $3.55 |  |

[0001193125-13-037706:8k_2_02:111]
Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP Measure, to Free Cash Flow, a Non-GAAP
Measure

[0001193125-13-037706:8k_2_02:112]
|  |  | For the Three Months |  |  | For The Years |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 157.0 |  |  | $ | 78.4 |  |  | $ | 221.4 |  |  | $ | 76.2 |  |
| Purchases of property, plant and equipment |  |  | (22.2 | ) |  |  | (15.6 | ) |  |  | (50.2 | ) |  |  | (41.4 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | 134.8 |  |  | $ | 62.8 |  |  | $ | 171.2 |  |  | $ | 34.8 |  |

[0001193125-13-037706:8k_2_02:113]
Calculation of Debt to EBITDA Ratio:

[0001193125-13-037706:8k_2_02:114]
|  |  | Trailing TwelveMonths toDecember 31,2012 |  |
| EBIT (a) |  | $ | 224.2 |  |
| Depreciation and amortization expense (b) |  |  | 55.4 |  |
| EBITDA (a + b) |  | $ | 279.6 |  |
| Total debt at December 31, 2012 (c) |  | $ | 386.6 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 1.4 |  |

[0001193125-13-037706:8k_2_02:115]
Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure

[0001193125-13-037706:8k_2_02:116]
|  |  | Trailing TwelveMonths toDecember 31,2012 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 224.2 |  |
| Special product quality adjustments |  |  | 1.1 |  |
| Items in gains and other expenses, net that are excluded from segment profit |  |  | (0.2 | ) |
| Restructuring charges |  |  | 4.2 |  |
| Other expenses, net |  |  | 0.3 |  |
| Interest expense, net |  |  | 17.1 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 201.7 |  |
