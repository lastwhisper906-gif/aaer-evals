# LII note change history — 0001069202-21-000028 → 0001628280-21-020422


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-10-25):
[0001628280-21-020422:note_history:1]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Accrued expenses | $ | 38.4 |  |  | $ | 37.7 |  |
| Other liabilities | 94.7 |  |  | 82.1 |  |
| Total warranty liability | $ | 133.1 |  |  | $ | 119.8 |  |
  (was, 2021-07-26, similarity 0.9687):
[0001069202-21-000028:note_history:1]
|  | As of June 30, 2021 |  | As of December 31, 2020 |
| Accrued expenses | $ | 38.8 |  |  | $ | 37.7 |  |
| Other liabilities | 93.0 |  |  | 82.1 |  |
| Total warranty liability | $ | 131.8 |  |  | $ | 119.8 |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:2]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2021 were as follows (in millions):
  (was, 2021-07-26, similarity 0.9444):
[0001069202-21-000028:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2021 were as follows (in millions):

- changed (2021-10-25):
[0001628280-21-020422:note_history:3]
| Total warranty liability as of December 31, 2020 | $ | 119.8 |  |
| Warranty claims paid | (28.1) |  |
| Changes resulting from issuance of new warranties | 37.2 |  |
| Changes in estimates associated with pre-existing liabilities | 4.2 |  |
| Changes in foreign currency translation rates and other | — |  |
| Total warranty liability as of September 30, 2021 | $ | 133.1 |  |
  (was, 2021-07-26, similarity 0.9811):
[0001069202-21-000028:note_history:3]
| Total warranty liability as of December 31, 2020 | $ | 119.8 |  |
| Warranty claims paid | (15.5) |  |
| Changes resulting from issuance of new warranties | 24.0 |  |
| Changes in estimates associated with pre-existing liabilities | 3.5 |  |
| Changes in foreign currency translation rates and other | — |  |
| Total warranty liability as of June 30, 2021 | $ | 131.8 |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:4]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Loss (gain) for asbestos-related litigation, net | $ | 1.8 |  |  | $ | 2.4 |  |  | $ | 4.5 |  |  | $ | 1.9 |  |
  (was, 2021-07-26, similarity 0.7554):
[0001069202-21-000028:note_history:4]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Loss (gain) for asbestos-related litigation, net | $ | 1.7 |  |  | $ | 1.2 |  |  | $ | 2.8 |  |  | $ | (0.5) |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-10-25):
[0001628280-21-020422:note_history:5]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2021, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2021 and 2020, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2021 and 2020, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2021 and 2020, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2021 and 2020 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2020.

- changed (2021-10-25):
[0001628280-21-020422:note_history:6]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also
  (was, 2021-07-26, similarity 0.9607):
[0001069202-21-000028:note_history:6]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience disruptions, or how long such disruptions would last.  It also remains

- changed (2021-10-25):
[0001628280-21-020422:note_history:7]
remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.
  (was, 2021-07-26, similarity 0.9887):
[0001069202-21-000028:note_history:7]
unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

- removed (2021-10-25):
[0001069202-21-000028:note_history:8]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2021, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2021 and 2020, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2021 and 2020, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and six months ended June 30, 2021 and 2020, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2021 and 2020 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2020.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-10-25):
[0001628280-21-020422:note_history:9]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.38 | % |  | — | % |
  (was, 2021-07-26, similarity 0.9447):
[0001069202-21-000028:note_history:9]
|  | As of June 30, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.63 | % |  | — | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-10-25):
[0001628280-21-020422:note_history:10]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 290.0 |  |  | $ | — |  |
| Finance lease obligations | 10.6 |  |  | 10.1 |  |
| Debt issuance costs | — |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 300.6 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 29.3 |  |
| Domestic credit facility | 9.0 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (9.2) |  |  | (8.6) |  |
| Total long-term debt | $ | 977.6 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,278.2 |  |  | $ | 980.6 |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:11]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2021 or December 31, 2020 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2021.
  (was, 2021-07-26, similarity 0.9378):
[0001069202-21-000028:note_history:11]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2021 or December 31, 2020 and there were no borrowings or repayments on these facilities during the six months ended June 30, 2021.

- added (2021-10-25):
[0001628280-21-020422:note_history:12]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 369.8 |  |  | $ | 279.1 |  |
| Less: Beneficial interest transferred | (290.0) |  |  | — |  |
| Remaining amount available | $ | 79.8 |  |  | $ | 279.1 |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:13]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2021 and December 31, 2020 were 0.78% and zero%, respectively. The unused
  (was, 2021-07-26, similarity 0.9793):
[0001069202-21-000028:note_history:13]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2021 and December 31, 2020 were 0.80% and zero%, respectively. The unused fee is

- changed (2021-10-25):
[0001628280-21-020422:note_history:14]
fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2021-07-26, similarity 0.9893):
[0001069202-21-000028:note_history:14]
based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2021-10-25):
[0001628280-21-020422:note_history:15]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our existing credit facility, senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our existing credit facility. The participating financial institutions have investment grade credit ratings.  As of September 30, 2021, we believe we were in compliance with all covenant requirements.
  (was, 2021-07-26, similarity 0.9707):
[0001069202-21-000028:note_history:15]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our existing credit facility, senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our existing credit facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2021, we believe we were in compliance with all covenant requirements.

- changed (2021-10-25):
[0001628280-21-020422:note_history:16]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility, among the Company, JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.
  (was, 2021-07-26, similarity 0.6017):
[0001069202-21-000028:note_history:16]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Prior Credit Agreement, among the Company, JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.

- added (2021-10-25):
[0001628280-21-020422:note_history:17]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $9.0 million as well as $2.0 million committed to standby letters of credit as of September 30, 2021. Subject to covenant limitations, $739.0 million was available for future borrowings.

- changed (2021-10-25):
[0001628280-21-020422:note_history:18]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.38 | % |  | — | % |
  (was, 2021-07-26, similarity 0.9447):
[0001069202-21-000028:note_history:18]
|  | As of June 30, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.63 | % |  | — | % |

- changed (2021-10-25):
[0001628280-21-020422:note_history:19]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control.  As of September 30, 2021, we believe we were in compliance with all covenant requirements.
  (was, 2021-07-26, similarity 0.9511):
[0001069202-21-000028:note_history:19]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control.  As of June 30, 2021, we believe we were in compliance with all covenant requirements.

- changed (2021-10-25):
[0001628280-21-020422:note_history:20]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2021, we believe we were in compliance with all covenant requirements.
  (was, 2021-07-26, similarity 0.9583):
[0001069202-21-000028:note_history:20]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2021, we believe we were in compliance with all covenant requirements.

- removed (2021-10-25):
[0001069202-21-000028:note_history:21]
|  | As of June 30, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 255.0 |  |  | $ | — |  |
| Finance lease obligations | 11.0 |  |  | 10.1 |  |
| Debt issuance costs | (0.1) |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 265.9 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 30.3 |  |  | 29.3 |  |
| Domestic credit facility | 4.5 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.4) |  |  | (8.6) |  |
| Total long-term debt | $ | 977.4 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,243.3 |  |  | $ | 980.6 |  |

- removed (2021-10-25):
[0001069202-21-000028:note_history:22]
|  | As of June 30, 2021 |  | As of December 31, 2020 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 320.0 |  |  | $ | 279.1 |  |
| Less: Beneficial interest transferred | (255.0) |  |  | — |  |
| Remaining amount available | $ | 65.0 |  |  | $ | 279.1 |  |

- removed (2021-10-25):
[0001069202-21-000028:note_history:23]
The Seventh Amended and Restated Credit Facility (the "Prior Credit Agreement") consisted of a $750.0 million unsecured revolving credit facility and was set to mature in August 2022.  We had outstanding borrowings of $4.5 million as well as $2.2 million committed to standby letters of credit as of June 30, 2021. Subject to covenant limitations, $743.3 million was available for future borrowings. The Prior Credit Agreement included a subfacility for swingline loans of up to $65.0 million.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-10-25):
[0001628280-21-020422:note_history:24]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 290.0 |  |  | $ | — |  |
| Finance lease obligations | 10.6 |  |  | 10.1 |  |
| Debt issuance costs | — |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 300.6 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 29.3 |  |
| Domestic credit facility | 9.0 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (9.2) |  |  | (8.6) |  |
| Total long-term debt | $ | 977.6 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,278.2 |  |  | $ | 980.6 |  |

- removed (2021-10-25):
[0001069202-21-000028:note_history:25]
|  | As of June 30, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 255.0 |  |  | $ | — |  |
| Finance lease obligations | 11.0 |  |  | 10.1 |  |
| Debt issuance costs | (0.1) |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 265.9 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 30.3 |  |  | 29.3 |  |
| Domestic credit facility | 4.5 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.4) |  |  | (8.6) |  |
| Total long-term debt | $ | 977.4 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,243.3 |  |  | $ | 980.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-10-25):
[0001628280-21-020422:note_history:26]
|  | For the Three Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 655.0 |  |  | $ | 194.0 |  |  | $ | 81.2 |  |  | $ | 930.2 |  |
| Canada | 56.0 |  |  | 16.8 |  |  | — |  |  | 72.8 |  |
| Other international | — |  |  | 0.7 |  |  | 56.2 |  |  | 56.9 |  |
| Total | $ | 711.0 |  |  | $ | 211.5 |  |  | $ | 137.4 |  |  | $ | 1,059.9 |  |
  (was, 2021-07-26, similarity 0.9268):
[0001069202-21-000028:note_history:26]
|  | For the Three Months Ended June 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 763.0 |  |  | $ | 228.7 |  |  | $ | 82.2 |  |  | $ | 1,073.9 |  |
| Canada | 75.0 |  |  | 23.9 |  |  | — |  |  | 98.9 |  |
| Other international | — |  |  | 0.2 |  |  | 66.0 |  |  | 66.2 |  |
| Total | $ | 838.0 |  |  | $ | 252.8 |  |  | $ | 148.2 |  |  | $ | 1,239.0 |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:27]
|  | For the Three Months Ended September 30, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 665.6 |  |  | $ | 184.6 |  |  | $ | 67.2 |  |  | $ | 917.4 |  |
| Canada | 56.4 |  |  | 22.7 |  |  | — |  |  | 79.1 |  |
| Other international | — |  |  | 0.6 |  |  | 57.9 |  |  | 58.5 |  |
| Total | $ | 722.0 |  |  | $ | 207.9 |  |  | $ | 125.1 |  |  | $ | 1,055.0 |  |
  (was, 2021-07-26, similarity 0.9268):
[0001069202-21-000028:note_history:27]
|  | For the Three Months Ended June 30, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 603.8 |  |  | $ | 173.1 |  |  | $ | 61.3 |  |  | $ | 838.2 |  |
| Canada | 41.0 |  |  | 15.0 |  |  | — |  |  | 56.0 |  |
| Other international | — |  |  | 0.2 |  |  | 46.9 |  |  | 47.1 |  |
| Total | $ | 644.8 |  |  | $ | 188.3 |  |  | $ | 108.2 |  |  | $ | 941.3 |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:28]
|  | For the Nine Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,976.8 |  |  | $ | 605.0 |  |  | $ | 239.1 |  |  | $ | 2,820.9 |  |
| Canada | 178.5 |  |  | 57.6 |  |  | — |  |  | 236.1 |  |
| Other international | — |  |  | 0.8 |  |  | 171.5 |  |  | 172.3 |  |
| Total | $ | 2,155.3 |  |  | $ | 663.4 |  |  | $ | 410.6 |  |  | $ | 3,229.3 |  |
  (was, 2021-07-26, similarity 0.8814):
[0001069202-21-000028:note_history:28]
|  | For the Six Months Ended June 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,321.8 |  |  | $ | 411.0 |  |  | $ | 157.9 |  |  | $ | 1,890.7 |  |
| Canada | 122.4 |  |  | 40.8 |  |  | — |  |  | 163.2 |  |
| Other international | — |  |  | 0.2 |  |  | 115.3 |  |  | 115.5 |  |
| Total | $ | 1,444.2 |  |  | $ | 452.0 |  |  | $ | 273.2 |  |  | $ | 2,169.4 |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:29]
|  | For the Nine Months Ended September 30, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,681.8 |  |  | $ | 518.9 |  |  | $ | 188.0 |  |  | $ | 2,388.7 |  |
| Canada | 127.0 |  |  | 54.8 |  |  | — |  |  | 181.8 |  |
| Other international | — |  |  | 0.9 |  |  | 148.7 |  |  | 149.6 |  |
| Total | $ | 1,808.8 |  |  | $ | 574.6 |  |  | $ | 336.7 |  |  | $ | 2,720.1 |  |
  (was, 2021-07-26, similarity 0.8814):
[0001069202-21-000028:note_history:29]
|  | For the Six Months Ended June 30, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,016.2 |  |  | $ | 334.3 |  |  | $ | 120.8 |  |  | $ | 1,471.3 |  |
| Canada | 70.7 |  |  | 32.0 |  |  | — |  |  | 102.7 |  |
| Other international | — |  |  | 0.4 |  |  | 90.7 |  |  | 91.1 |  |
| Total | $ | 1,086.9 |  |  | $ | 366.7 |  |  | $ | 211.5 |  |  | $ | 1,665.1 |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:30]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2021 and 2020, direct sales represented 73% and 74% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2021 and 2020, direct sales represented 72% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2021-07-26, similarity 0.9702):
[0001069202-21-000028:note_history:30]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2021 and 2020, direct sales represented 76% and 76% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2021 and 2020, direct sales represented 72% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2021-10-25):
[0001628280-21-020422:note_history:31]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2021 and 2020, equipment sales represented 81% and 83% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2021 and 2020, equipment sales represented 83% and 84% of revenues and the remainder of our revenue was generated from our service business.
  (was, 2021-07-26, similarity 0.9752):
[0001069202-21-000028:note_history:31]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended June 30, 2021 and 2020, equipment sales represented 85% and 86% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2021 and 2020, equipment sales represented 84% and 85% of revenues and the remainder of our revenue was generated from our service business.

- added (2021-10-25):
[0001628280-21-020422:note_history:32]
|  | September 30, 2021 |  | December 31, 2020 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (8.3) |  |  | $ | (5.5) |  |  | $ | (2.8) |  |  | 50.9 | % |
| Contract liabilities - noncurrent | (5.2) |  |  | (5.6) |  |  | 0.4 |  |  | (7.1) | % |
| Total | $ | (13.5) |  |  | $ | (11.1) |  |  | $ | (2.4) |  |  |  |

- changed (2021-10-25):
[0001628280-21-020422:note_history:33]
For the three months ended September 30, 2021 and 2020, we recognized revenue of $0.6 million and $1.4 million and for the nine months ended September 30, 2021 and 2020 we recognized revenue of $2.9 million and $5.9 million related to our contract liabilities at January 1, 2021 and 2020, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2021 and 2020.
  (was, 2021-07-26, similarity 0.9149):
[0001069202-21-000028:note_history:33]
For the three months ended June 30, 2021 and 2020, we recognized revenue of $0.8 million and $2.9 million and for the six months ended June 30, 2021 and 2020 we recognized revenue of $2.4 million and $4.5 million related to our contract liabilities at January 1, 2021 and 2020, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2021 and 2020.

- removed (2021-10-25):
[0001069202-21-000028:note_history:34]
|  | June 30, 2021 |  | December 31, 2020 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (6.5) |  |  | $ | (5.5) |  |  | $ | (1.0) |  |  | 18.2 | % |
| Contract liabilities - noncurrent | (5.7) |  |  | (5.6) |  |  | (0.1) |  |  | 1.8 | % |
| Total | $ | (12.2) |  |  | $ | (11.1) |  |  | $ | (1.1) |  |  |  |
