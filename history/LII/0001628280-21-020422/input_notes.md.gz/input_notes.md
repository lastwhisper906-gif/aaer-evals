# LII notes — 0001628280-21-020422


## us-gaap:SubsequentEventsTextBlock

[0001628280-21-020422:notes:1]
On July 8, 2021, Todd M. Bluedorn, our Chairman of the Board and Chief Executive Officer advised our Board of Directors that he intended to resign as Chief Executive Officer and as Chairman and a member of our Board of Directors in mid-2022.

[0001628280-21-020422:notes:2]
The Board of Directors has commenced a search for our next chief executive officer.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-21-020422:notes:3]
[same as prior period, unchanged from 0001069202-21-000028:notes:1]

[0001628280-21-020422:notes:4]
[same as prior period, unchanged from 0001069202-21-000028:notes:2]

[0001628280-21-020422:notes:5]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2021, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2021 and 2020, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2021 and 2020, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2021 and 2020, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2021 and 2020 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2020.

[0001628280-21-020422:notes:6]
[same as prior period, unchanged from 0001069202-21-000028:notes:4]

[0001628280-21-020422:notes:7]
[same as prior period, unchanged from 0001069202-21-000028:notes:5]

[0001628280-21-020422:notes:8]
[same as prior period, unchanged from 0001069202-21-000028:notes:6]

[0001628280-21-020422:notes:9]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001628280-21-020422:notes:10]
[same as prior period, unchanged from 0001069202-21-000028:notes:8]

[0001628280-21-020422:notes:11]
[same as prior period, unchanged from 0001069202-21-000028:notes:9]

[0001628280-21-020422:notes:12]
[same as prior period, unchanged from 0001069202-21-000028:notes:10]

[0001628280-21-020422:notes:13]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also

[0001628280-21-020422:notes:14]
remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

[0001628280-21-020422:notes:15]
Recently Adopted Accounting Guidance

[0001628280-21-020422:notes:16]
In December 2019, the FASB issued ASU No. 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.  ASU 2019-02, in an effort to reduce complexity in accounting for income taxes, removes certain exceptions for measuring intraperiod tax allocations, foreign subsidiary equity method investments and interim period tax losses.  ASU 2019-12 is effective for calendar year-end public business entities on January 1, 2021.  The adoption of ASU 2019-12 did not have a material impact on our financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-21-020422:notes:17]
[same as prior period, unchanged from 0001069202-21-000028:notes:15]

[0001628280-21-020422:notes:18]
[same as prior period, unchanged from 0001069202-21-000028:notes:16]

[0001628280-21-020422:notes:19]
[same as prior period, unchanged from 0001069202-21-000028:notes:17]

[0001628280-21-020422:notes:20]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term stock-based incentive awards provided to employees throughout LII. We record these stock-based awards as corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001628280-21-020422:notes:21]
[same as prior period, unchanged from 0001069202-21-000028:notes:19]

[0001628280-21-020422:notes:22]
[same as prior period, unchanged from 0001069202-21-000028:notes:20]

[0001628280-21-020422:notes:23]
[same as prior period, unchanged from 0001069202-21-000028:notes:21]

[0001628280-21-020422:notes:24]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 711.0 |  |  | $ | 722.0 |  |  | $ | 2,155.3 |  |  | $ | 1,808.8 |  |
| Commercial Heating & Cooling | 211.5 |  |  | 207.9 |  |  | 663.4 |  |  | 574.6 |  |
| Refrigeration | 137.4 |  |  | 125.1 |  |  | 410.6 |  |  | 336.7 |  |
|  | $ | 1,059.9 |  |  | $ | 1,055.0 |  |  | $ | 3,229.3 |  |  | $ | 2,720.1 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 144.0 |  |  | $ | 153.0 |  |  | $ | 430.1 |  |  | $ | 312.8 |  |
| Commercial Heating & Cooling | 22.6 |  |  | 38.8 |  |  | 95.3 |  |  | 93.1 |  |
| Refrigeration | 14.5 |  |  | 13.0 |  |  | 35.8 |  |  | 22.6 |  |
| Corporate and other | (16.3) |  |  | (28.3) |  |  | (59.2) |  |  | (61.3) |  |
| Total segment profit | 164.8 |  |  | 176.5 |  |  | 502.0 |  |  | 367.2 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special product quality adjustments | (1.1) |  |  | — |  |  | (1.0) |  |  | (1.0) |  |
| Loss from natural disasters, net of insurance recoveries | — |  |  | 4.9 |  |  | — |  |  | 7.6 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 2.9 |  |  | 4.4 |  |  | 8.7 |  |  | 10.5 |  |
| Restructuring charges | 0.3 |  |  | 0.1 |  |  | 1.6 |  |  | 10.6 |  |
| Operating income | $ | 162.7 |  |  | $ | 167.1 |  |  | $ | 492.7 |  |  | $ | 339.5 |  |

[0001628280-21-020422:notes:25]
[same as prior period, unchanged from 0001069202-21-000028:notes:23]

[0001628280-21-020422:notes:26]
[same as prior period, unchanged from 0001069202-21-000028:notes:24]

[0001628280-21-020422:notes:27]
[same as prior period, unchanged from 0001069202-21-000028:notes:25]

[0001628280-21-020422:notes:28]
▪Special legal contingency charges,

[0001628280-21-020422:notes:29]
▪Asbestos-related litigation,

[0001628280-21-020422:notes:30]
[same as prior period, unchanged from 0001069202-21-000028:notes:28]

[0001628280-21-020422:notes:31]
[same as prior period, unchanged from 0001069202-21-000028:notes:29]

[0001628280-21-020422:notes:32]
[same as prior period, unchanged from 0001069202-21-000028:notes:30]

[0001628280-21-020422:notes:33]
[same as prior period, unchanged from 0001069202-21-000028:notes:31]

[0001628280-21-020422:notes:34]
[same as prior period, unchanged from 0001069202-21-000028:notes:32]

[0001628280-21-020422:notes:35]
[same as prior period, unchanged from 0001069202-21-000028:notes:33]


## us-gaap:EarningsPerShareTextBlock

[0001628280-21-020422:notes:36]
[same as prior period, unchanged from 0001069202-21-000028:notes:34]

[0001628280-21-020422:notes:37]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income | $ | 126.3 |  |  | $ | 131.7 |  |  | $ | 380.4 |  |  | $ | 244.6 |  |
| Exclude: Income from discontinued operations | — |  |  | — |  |  | 0.1 |  |  | 0.3 |  |
| Income from continuing operations | $ | 126.3 |  |  | $ | 131.7 |  |  | $ | 380.5 |  |  | $ | 244.9 |  |
| Weighted-average shares outstanding – basic | 36.8 |  |  | 38.3 |  |  | 37.4 |  |  | 38.3 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Weighted-average shares outstanding – diluted | 37.0 |  |  | 38.6 |  |  | 37.7 |  |  | 38.6 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.43 |  |  | $ | 3.44 |  |  | $ | 10.17 |  |  | $ | 6.39 |  |
| Income from discontinued operations | — |  |  | — |  |  | — |  |  | (0.01) |  |
| Net income | $ | 3.43 |  |  | $ | 3.44 |  |  | $ | 10.17 |  |  | $ | 6.38 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.41 |  |  | $ | 3.42 |  |  | $ | 10.10 |  |  | $ | 6.35 |  |
| Income from discontinued operations | — |  |  | — |  |  | — |  |  | (0.01) |  |
| Net income | $ | 3.41 |  |  | $ | 3.42 |  |  | $ | 10.10 |  |  | $ | 6.34 |  |

[0001628280-21-020422:notes:38]
[same as prior period, unchanged from 0001069202-21-000028:notes:36]

[0001628280-21-020422:notes:39]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Weighted-average number of shares | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Price per share | $— |  | $257.08 |  | $— |  | $257.08 |


## us-gaap:LesseeLeasesPolicyTextBlock

[0001628280-21-020422:notes:40]
[same as prior period, unchanged from 0001069202-21-000028:notes:38]

[0001628280-21-020422:notes:41]
[same as prior period, unchanged from 0001069202-21-000028:notes:39]

[0001628280-21-020422:notes:42]
[same as prior period, unchanged from 0001069202-21-000028:notes:40]

[0001628280-21-020422:notes:43]
[same as prior period, unchanged from 0001069202-21-000028:notes:41]

[0001628280-21-020422:notes:44]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.
We lease certain real and personal property under non-cancelable operating leases. Approximately 75% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-21-020422:notes:45]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001628280-21-020422:notes:46]
We lease certain real and personal property under non-cancelable operating leases. Approximately 75% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001628280-21-020422:notes:47]
Product Warranties and Product Related Contingencies

[0001628280-21-020422:notes:48]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001628280-21-020422:notes:49]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-21-020422:notes:50]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Accrued expenses | $ | 38.4 |  |  | $ | 37.7 |  |
| Other liabilities | 94.7 |  |  | 82.1 |  |
| Total warranty liability | $ | 133.1 |  |  | $ | 119.8 |  |

[0001628280-21-020422:notes:51]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2021 were as follows (in millions):

[0001628280-21-020422:notes:52]
| Total warranty liability as of December 31, 2020 | $ | 119.8 |  |
| Warranty claims paid | (28.1) |  |
| Changes resulting from issuance of new warranties | 37.2 |  |
| Changes in estimates associated with pre-existing liabilities | 4.2 |  |
| Changes in foreign currency translation rates and other | — |  |
| Total warranty liability as of September 30, 2021 | $ | 133.1 |  |

[0001628280-21-020422:notes:53]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

[0001628280-21-020422:notes:54]
Litigation

[0001628280-21-020422:notes:55]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-21-020422:notes:56]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future

[0001628280-21-020422:notes:57]
settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):

[0001628280-21-020422:notes:58]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Loss (gain) for asbestos-related litigation, net | $ | 1.8 |  |  | $ | 2.4 |  |  | $ | 4.5 |  |  | $ | 1.9 |  |

[0001628280-21-020422:notes:59]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-21-020422:notes:60]
Our Board of Directors has authorized a total of $4.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in July 2021. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of September 30, 2021, $846 million was available for repurchase under the Share Repurchase Plans.

[0001628280-21-020422:notes:61]
On February 4, 2021, we entered into a fixed dollar accelerated share repurchase transaction (the "ASR Agreement") with Wells Fargo Bank, to effect an accelerated stock buyback of our common stock.  Under the ASR Agreement, we paid Wells Fargo Bank $200.0 million and Wells Fargo Bank delivered to us common stock representing approximately 85% of the shares expected to be purchased under this ASR Agreement. The ASR was completed in April 2021 and Wells Fargo Bank delivered a total of 0.7 million shares of common stock repurchased under this ASR Agreement.

[0001628280-21-020422:notes:62]
On May 3, 2021, we entered into an ASR Agreement with Bank of America, to effect an accelerated stock buyback of our common stock.  Under the ASR Agreement, we paid Bank of America $200.0 million and Bank of America delivered to us common stock representing approximately 85% of the shares expected to be purchased under this ASR Agreement. The ASR was completed in June 2021 and Bank of America delivered a total of 0.6 million shares of common stock repurchased under this ASR Agreement.

[0001628280-21-020422:notes:63]
On August 2, 2021, we entered into an ASR Agreement with Bank of America, to effect an accelerated stock buyback of our common stock.  Under the ASR Agreement, we paid Bank of America $200.0 million and Bank of America delivered to us common stock representing approximately 85% of the shares expected to be purchased under this ASR Agreement. The ASR was completed in September 2021 and Bank of America delivered a total of 0.6 million shares of common stock repurchased under this ASR Agreement.

[0001628280-21-020422:notes:64]
We also repurchased shares for $16.1 million during the nine months ended September 30, 2021 from employees who tendered their shares to satisfy minimum tax withholding obligations upon the vesting and exercise of stock-based compensation awards.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001628280-21-020422:notes:65]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.

[0001628280-21-020422:notes:66]
|  | For the Three Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 655.0 |  |  | $ | 194.0 |  |  | $ | 81.2 |  |  | $ | 930.2 |  |
| Canada | 56.0 |  |  | 16.8 |  |  | — |  |  | 72.8 |  |
| Other international | — |  |  | 0.7 |  |  | 56.2 |  |  | 56.9 |  |
| Total | $ | 711.0 |  |  | $ | 211.5 |  |  | $ | 137.4 |  |  | $ | 1,059.9 |  |

[0001628280-21-020422:notes:67]
|  | For the Three Months Ended September 30, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 665.6 |  |  | $ | 184.6 |  |  | $ | 67.2 |  |  | $ | 917.4 |  |
| Canada | 56.4 |  |  | 22.7 |  |  | — |  |  | 79.1 |  |
| Other international | — |  |  | 0.6 |  |  | 57.9 |  |  | 58.5 |  |
| Total | $ | 722.0 |  |  | $ | 207.9 |  |  | $ | 125.1 |  |  | $ | 1,055.0 |  |

[0001628280-21-020422:notes:68]
|  | For the Nine Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,976.8 |  |  | $ | 605.0 |  |  | $ | 239.1 |  |  | $ | 2,820.9 |  |
| Canada | 178.5 |  |  | 57.6 |  |  | — |  |  | 236.1 |  |
| Other international | — |  |  | 0.8 |  |  | 171.5 |  |  | 172.3 |  |
| Total | $ | 2,155.3 |  |  | $ | 663.4 |  |  | $ | 410.6 |  |  | $ | 3,229.3 |  |

[0001628280-21-020422:notes:69]
|  | For the Nine Months Ended September 30, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,681.8 |  |  | $ | 518.9 |  |  | $ | 188.0 |  |  | $ | 2,388.7 |  |
| Canada | 127.0 |  |  | 54.8 |  |  | — |  |  | 181.8 |  |
| Other international | — |  |  | 0.9 |  |  | 148.7 |  |  | 149.6 |  |
| Total | $ | 1,808.8 |  |  | $ | 574.6 |  |  | $ | 336.7 |  |  | $ | 2,720.1 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-21-020422:notes:70]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2021 and 2020, direct sales represented 73% and 74% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2021 and 2020, direct sales represented 72% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001628280-21-020422:notes:71]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2021 and 2020, equipment sales represented 81% and 83% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2021 and 2020, equipment sales represented 83% and 84% of revenues and the remainder of our revenue was generated from our service business.

[0001628280-21-020422:notes:72]
[same as prior period, unchanged from 0001069202-21-000028:notes:70]

[0001628280-21-020422:notes:73]
[same as prior period, unchanged from 0001069202-21-000028:notes:71]

[0001628280-21-020422:notes:74]
[same as prior period, unchanged from 0001069202-21-000028:notes:72]

[0001628280-21-020422:notes:75]
[same as prior period, unchanged from 0001069202-21-000028:notes:73]

[0001628280-21-020422:notes:76]
[same as prior period, unchanged from 0001069202-21-000028:notes:74]

[0001628280-21-020422:notes:77]
[same as prior period, unchanged from 0001069202-21-000028:notes:75]

[0001628280-21-020422:notes:78]
[same as prior period, unchanged from 0001069202-21-000028:notes:76]

[0001628280-21-020422:notes:79]
|  | September 30, 2021 |  | December 31, 2020 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (8.3) |  |  | $ | (5.5) |  |  | $ | (2.8) |  |  | 50.9 | % |
| Contract liabilities - noncurrent | (5.2) |  |  | (5.6) |  |  | 0.4 |  |  | (7.1) | % |
| Total | $ | (13.5) |  |  | $ | (11.1) |  |  | $ | (2.4) |  |  |  |

[0001628280-21-020422:notes:80]
For the three months ended September 30, 2021 and 2020, we recognized revenue of $0.6 million and $1.4 million and for the nine months ended September 30, 2021 and 2020 we recognized revenue of $2.9 million and $5.9 million related to our contract liabilities at January 1, 2021 and 2020, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2021 and 2020.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-21-020422:notes:81]
[same as prior period, unchanged from 0001069202-21-000028:notes:79]

[0001628280-21-020422:notes:82]
[same as prior period, unchanged from 0001069202-21-000028:notes:80]

[0001628280-21-020422:notes:83]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Finished goods | $ | 264.1 |  |  | $ | 280.1 |  |
| Work in process | 9.6 |  |  | 6.5 |  |
| Raw materials and parts | 254.7 |  |  | 207.8 |  |
| Subtotal | 528.4 |  |  | 494.4 |  |
| Excess of current cost over last-in, first-out cost | (67.4) |  |  | (55.0) |  |
| Total inventories, net | $ | 461.0 |  |  | $ | 439.4 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-21-020422:notes:84]
[same as prior period, unchanged from 0001069202-21-000028:notes:82]

[0001628280-21-020422:notes:85]
[same as prior period, unchanged from 0001069202-21-000028:notes:83]

[0001628280-21-020422:notes:86]
|  | Balance at December 31, 2020 |  |  |  | Changes in foreign currency translation rates |  | Balance at September 30, 2021 |
| Residential Heating & Cooling | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.7 |  |  |  |  | (0.2) |  |  | 99.5 |  |
| Total Goodwill | $ | 186.9 |  |  |  |  | $ | (0.2) |  |  | $ | 186.7 |  |

[0001628280-21-020422:notes:87]
[same as prior period, unchanged from 0001069202-21-000028:notes:85]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-21-020422:notes:88]
[same as prior period, unchanged from 0001069202-21-000028:notes:86]

[0001628280-21-020422:notes:89]
[same as prior period, unchanged from 0001069202-21-000028:notes:87]

[0001628280-21-020422:notes:90]
[same as prior period, unchanged from 0001069202-21-000028:notes:88]

[0001628280-21-020422:notes:91]
[same as prior period, unchanged from 0001069202-21-000028:notes:89]

[0001628280-21-020422:notes:92]
[same as prior period, unchanged from 0001069202-21-000028:notes:90]

[0001628280-21-020422:notes:93]
[same as prior period, unchanged from 0001069202-21-000028:notes:91]

[0001628280-21-020422:notes:94]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through February 2023.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months

[0001628280-21-020422:notes:95]
[same as prior period, unchanged from 0001069202-21-000028:notes:93]

[0001628280-21-020422:notes:96]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Unrealized gains on unsettled contracts | $ | (16.1) |  |  | $ | (10.5) |  |
| Income tax expense | 3.2 |  |  | 2.3 |  |
| Gains included in AOCL, net of tax (1) | $ | (12.9) |  |  | $ | (8.2) |  |

[0001628280-21-020422:notes:97]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $12.6 million of derivative gains as of September 30, 2021 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-21-020422:notes:98]
[same as prior period, unchanged from 0001069202-21-000028:notes:96]

[0001628280-21-020422:notes:99]
[same as prior period, unchanged from 0001069202-21-000028:notes:97]

[0001628280-21-020422:notes:100]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Stock-based compensation expense (1) | $ | (0.6) |  |  | $ | 8.0 |  |  | $ | 16.8 |  |  | $ | 18.4 |  |

[0001628280-21-020422:notes:101]
[same as prior period, unchanged from 0001069202-21-000028:notes:99]


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001628280-21-020422:notes:102]
[same as prior period, unchanged from 0001069202-21-000028:notes:100]

[0001628280-21-020422:notes:103]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Service cost | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 4.6 |  |  | $ | 4.2 |  |
| Interest cost | 1.0 |  |  | 1.6 |  |  | 4.1 |  |  | 5.0 |  |
| Expected return on plan assets | (1.7) |  |  | (2.0) |  |  | (7.1) |  |  | (6.2) |  |
| Amortization of prior service cost | 0.1 |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Recognized actuarial loss | 1.8 |  |  | 1.4 |  |  | 6.0 |  |  | 4.3 |  |
| Other | — |  |  | 0.1 |  |  | (0.4) |  |  | — |  |
| Settlements and curtailments | 0.3 |  |  | 0.3 |  |  | 1.1 |  |  | 0.3 |  |
| Net periodic benefit cost | $ | 3.0 |  |  | $ | 2.8 |  |  | $ | 8.4 |  |  | $ | 7.7 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-21-020422:notes:104]
[same as prior period, unchanged from 0001069202-21-000028:notes:102]


## us-gaap:DebtDisclosureTextBlock

[0001628280-21-020422:notes:105]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001628280-21-020422:notes:106]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 290.0 |  |  | $ | — |  |
| Finance lease obligations | 10.6 |  |  | 10.1 |  |
| Debt issuance costs | — |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 300.6 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 29.3 |  |
| Domestic credit facility | 9.0 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (9.2) |  |  | (8.6) |  |
| Total long-term debt | $ | 977.6 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,278.2 |  |  | $ | 980.6 |  |

[0001628280-21-020422:notes:107]
Short-Term Debt

[0001628280-21-020422:notes:108]
Foreign Obligations

[0001628280-21-020422:notes:109]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2021 or December 31, 2020 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2021.

[0001628280-21-020422:notes:110]
Asset Securitization Program

[0001628280-21-020422:notes:111]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale. Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001628280-21-020422:notes:112]
We renewed the ASP in November 2019, extending its term to November 2021 and increasing the maximum securitization amount to a range from $250.0 million to $400.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001628280-21-020422:notes:113]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 369.8 |  |  | $ | 279.1 |  |
| Less: Beneficial interest transferred | (290.0) |  |  | — |  |
| Remaining amount available | $ | 79.8 |  |  | $ | 279.1 |  |

[0001628280-21-020422:notes:114]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2021 and December 31, 2020 were 0.78% and zero%, respectively. The unused

[0001628280-21-020422:notes:115]
fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001628280-21-020422:notes:116]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our existing credit facility, senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our existing credit facility. The participating financial institutions have investment grade credit ratings.  As of September 30, 2021, we believe we were in compliance with all covenant requirements.

[0001628280-21-020422:notes:117]
Long-Term Debt

[0001628280-21-020422:notes:118]
Domestic Credit Facility

[0001628280-21-020422:notes:119]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility, among the Company, JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.

[0001628280-21-020422:notes:120]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $9.0 million as well as $2.0 million committed to standby letters of credit as of September 30, 2021. Subject to covenant limitations, $739.0 million was available for future borrowings.

[0001628280-21-020422:notes:121]
Our weighted average borrowing rate on the facility was as follows:

[0001628280-21-020422:notes:122]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.38 | % |  | — | % |

[0001628280-21-020422:notes:123]
The Credit Agreement provides for revolving credit commitments of $750 million with sublimits for swingline loans of up to $65 million, letters of credit up to $100 million and revolving loans in certain non-U.S. currencies up to the U.S. dollar equivalent of $40 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement. At our request and subject to certain conditions, the revolving credit commitments under the Credit Agreement may be increased by up to a total of $350 million to the extent that existing or new lenders agree to provide additional commitments.

[0001628280-21-020422:notes:124]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control.  As of September 30, 2021, we believe we were in compliance with all covenant requirements.

[0001628280-21-020422:notes:125]
Senior Unsecured Notes

[0001628280-21-020422:notes:126]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2021, we believe we were in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-21-020422:notes:127]
[same as prior period, unchanged from 0001069202-21-000028:notes:125]

[0001628280-21-020422:notes:128]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |
| (Losses) Gains on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | 7.8 |  |  | $ | (0.4) |  |  | $ | 21.3 |  |  | $ | (5.5) |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax (expense) benefit |  | (1.8) |  |  | 0.1 |  |  | (4.9) |  |  | 1.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | 6.0 |  |  | $ | (0.3) |  |  | $ | 16.4 |  |  | $ | (4.1) |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.8) |  |  | $ | (1.4) |  |  | $ | (6.0) |  |  | $ | (4.4) |  |  | Cost of goods sold; Selling, general and administrative expenses |
| Pension settlements |  | (0.3) |  |  | (0.3) |  |  | (1.1) |  |  | (0.3) |  |  | Pension settlements |
| Income tax benefit |  | 0.6 |  |  | 0.4 |  |  | 1.8 |  |  | 1.1 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.5) |  |  | $ | (1.3) |  |  | $ | (5.3) |  |  | $ | (3.6) |  |  |  |
| Total reclassifications from AOCL |  | $ | 4.5 |  |  | $ | (1.6) |  |  | $ | 11.1 |  |  | $ | (7.7) |  |  |  |

[0001628280-21-020422:notes:129]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2021 (in millions):

[0001628280-21-020422:notes:130]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2020 |  | $ | 8.2 |  |  | $ | (1.2) |  |  | $ | (82.7) |  |  | $ | (21.5) |  |  | $ | (97.2) |  |
| Other comprehensive income (loss) before reclassifications |  | 21.1 |  |  | — |  |  | (9.1) |  |  | (5.1) |  |  | 6.9 |  |
| Amounts reclassified from AOCL |  | (16.4) |  |  | — |  |  | 5.3 |  |  | — |  |  | (11.1) |  |
| Net other comprehensive income (loss) |  | 4.7 |  |  | — |  |  | (3.8) |  |  | (5.1) |  |  | (4.2) |  |
| Balance as of September 30, 2021 |  | $ | 12.9 |  |  | $ | (1.2) |  |  | $ | (86.5) |  |  | $ | (26.6) |  |  | $ | (101.4) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-21-020422:notes:131]
[same as prior period, unchanged from 0001069202-21-000028:notes:129]

[0001628280-21-020422:notes:132]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2021 were the same as those used at December 31, 2020.

[0001628280-21-020422:notes:133]
[same as prior period, unchanged from 0001069202-21-000028:notes:131]

[0001628280-21-020422:notes:134]
[same as prior period, unchanged from 0001069202-21-000028:notes:132]

[0001628280-21-020422:notes:135]
[same as prior period, unchanged from 0001069202-21-000028:notes:133]

[0001628280-21-020422:notes:136]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001628280-21-020422:notes:137]
[same as prior period, unchanged from 0001069202-21-000028:notes:135]

[0001628280-21-020422:notes:138]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Senior unsecured notes | $ | 974.8 |  |  | $ | 971.6 |  |
