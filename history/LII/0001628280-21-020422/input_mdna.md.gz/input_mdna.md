# LII MD&A — 0001628280-21-020422


## mdna

[0001628280-21-020422:mdna:1]
[same as prior period, unchanged from 0001069202-21-000028:mdna:1]

[0001628280-21-020422:mdna:2]
[same as prior period, unchanged from 0001069202-21-000028:mdna:2]

[0001628280-21-020422:mdna:3]
[same as prior period, unchanged from 0001069202-21-000028:mdna:3]

[0001628280-21-020422:mdna:4]
[same as prior period, unchanged from 0001069202-21-000028:mdna:4]

[0001628280-21-020422:mdna:5]
[same as prior period, unchanged from 0001069202-21-000028:mdna:5]

[0001628280-21-020422:mdna:6]
[same as prior period, unchanged from 0001069202-21-000028:mdna:6]

[0001628280-21-020422:mdna:7]
[same as prior period, unchanged from 0001069202-21-000028:mdna:7]

[0001628280-21-020422:mdna:8]
[same as prior period, unchanged from 0001069202-21-000028:mdna:8]

[0001628280-21-020422:mdna:9]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also

[0001628280-21-020422:mdna:10]
remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

[0001628280-21-020422:mdna:11]
[same as prior period, unchanged from 0001069202-21-000028:mdna:11]

[0001628280-21-020422:mdna:12]
Results for the third quarter of 2021 were driven by overall year over year sales increases while profit decreased.  Net sales decreased 2% and segment profit decreased $9 million for the Residential Heating & Cooling segment. Net sales increased 2% and segment profit decreased $16 million for the Commercial Heating & Cooling segment. Net sales increased 10% and segment profit increased $2 million for the Refrigeration segment.

[0001628280-21-020422:mdna:13]
[same as prior period, unchanged from 0001069202-21-000028:mdna:13]

[0001628280-21-020422:mdna:14]
•Net sales increased $5 million to $1,060 million in the third quarter of 2021 driven by favorable price and mix partially offset by lower sales volume.

[0001628280-21-020422:mdna:15]
•Operating income in the third quarter of 2021 decreased $4 million to $163 million primarily driven by rising costs partially offset by higher net sales.

[0001628280-21-020422:mdna:16]
•Net income for the third quarter of 2021 decreased $6 million to $126 million.

[0001628280-21-020422:mdna:17]
•Diluted earnings per share from continuing operations were $3.41 per share in the third quarter of 2021 compared to $3.42 per share in the third quarter of 2020.

[0001628280-21-020422:mdna:18]
•For the nine months ended September 30, 2021, we returned $93 million to shareholders through dividend payments and repurchased $600 million of common stock through our share repurchase program.

[0001628280-21-020422:mdna:19]
Third Quarter of 2021 Compared to Third Quarter of 2020 - Consolidated Results

[0001628280-21-020422:mdna:20]
[same as prior period, unchanged from 0001069202-21-000028:mdna:20]

[0001628280-21-020422:mdna:21]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales | $ | 1,059.9 |  |  | $ | 1,055.0 |  |  | 0.5 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 764.7 |  |  | 731.7 |  |  | (4.5) |  |  | 72.1 |  |  | 69.4 |  |
| Gross profit | 295.2 |  |  | 323.3 |  |  | (8.7) |  |  | 27.9 |  |  | 30.6 |  |
| Selling, general and administrative expenses | 134.2 |  |  | 151.8 |  |  | 11.6 |  |  | 12.7 |  |  | 14.4 |  |
| Losses (gains) and other expenses, net | 2.1 |  |  | 3.4 |  |  | 38.2 |  |  | 0.2 |  |  | 0.3 |  |
| Restructuring charges | 0.3 |  |  | 0.1 |  |  | (200.0) |  |  | — |  |  | — |  |
| Loss from natural disasters, net of insurance recoveries | — |  |  | 4.9 |  |  | 100.0 |  |  | — |  |  | 0.5 |  |
| Income from equity method investments | (4.1) |  |  | (4.0) |  |  | 2.5 |  |  | (0.4) |  |  | (0.4) |  |
| Operating income | $ | 162.7 |  |  | $ | 167.1 |  |  | (2.6) | % |  | 15.4 | % |  | 15.8 | % |

[0001628280-21-020422:mdna:22]
[same as prior period, unchanged from 0001069202-21-000028:mdna:22]

[0001628280-21-020422:mdna:23]
Net sales for the third quarter of 2021 compared to the third quarter of 2020 were impacted by favorable combined price and mix of 4%, which was partially offset by lower sales volume of 4%.

[0001628280-21-020422:mdna:24]
[same as prior period, unchanged from 0001069202-21-000028:mdna:24]

[0001628280-21-020422:mdna:25]
Gross profit margins in the third quarter of 2021 decreased 270 basis points ("bps") to 27.9% compared to 30.6% in the third quarter of 2020. Gross margin decreased 220 bps from higher commodity costs, 90 bps from higher freight and distribution costs, 90 bps from factory inefficiencies, 90 bps from higher other product costs, 40 bps from sourcing and engineering-led cost increases, and 20 bps from unfavorable mix.  Partially offsetting these decreases was 280 bps from favorable price.

[0001628280-21-020422:mdna:26]
[same as prior period, unchanged from 0001069202-21-000028:mdna:26]

[0001628280-21-020422:mdna:27]
Selling, general and administrative expenses ("SG&A") decreased $18 million to $134 million in the third quarter of 2021 compared to $152 million in the third quarter of 2020 due to lower incentive compensation and other employee costs. As a percentage of net sales, SG&A decreased 170 bps to 12.7%.

[0001628280-21-020422:mdna:28]
[same as prior period, unchanged from 0001069202-21-000028:mdna:28]

[0001628280-21-020422:mdna:29]
Losses (gains) losses and other expenses, net for the third quarter of 2021 and 2020 included the following (in millions):

[0001628280-21-020422:mdna:30]
|  | For the Three Months Ended September 30, |
|  | 2021 |  | 2020 |
| Realized (gains) losses on settled futures contracts | $ | (0.2) |  |  | $ | — |  |
| Foreign currency exchange gains | — |  |  | (0.4) |  |
| Gain on disposal of fixed assets | (0.1) |  |  | (0.2) |  |
| Other operating income | (0.5) |  |  | (0.4) |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.2 |  |  | (1.4) |  |
| Special legal contingency charges | 0.1 |  |  | 0.2 |  |
| Asbestos-related litigation | 1.8 |  |  | 2.4 |  |
| Environmental liabilities | 0.3 |  |  | 0.3 |  |
| Charges incurred related to COVID-19 pandemic | 0.8 |  |  | 3.0 |  |
| Other items, net | (0.3) |  |  | (0.1) |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.1 |  |  | $ | 3.4 |  |

[0001628280-21-020422:mdna:31]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 7 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities related to estimated remediation costs for contamination at some of our facilities.

[0001628280-21-020422:mdna:32]
[same as prior period, unchanged from 0001069202-21-000028:mdna:32]

[0001628280-21-020422:mdna:33]
Restructuring charges were immaterial in the third quarter of 2021 and 2020.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-21-020422:mdna:34]
[same as prior period, unchanged from 0001069202-21-000028:mdna:34]

[0001628280-21-020422:mdna:35]
The charges recorded during 2020 were for costs incurred related to natural disasters that occurred in prior years.

[0001628280-21-020422:mdna:36]
[same as prior period, unchanged from 0001069202-21-000028:mdna:36]

[0001628280-21-020422:mdna:37]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $4 million in the third quarter of 2021 was up slightly compared to the third quarter of 2020.

[0001628280-21-020422:mdna:38]
[same as prior period, unchanged from 0001069202-21-000028:mdna:38]

[0001628280-21-020422:mdna:39]
Interest expense, net was $7 million in the third quarter of 2021 and 2020, respectively.

[0001628280-21-020422:mdna:40]
[same as prior period, unchanged from 0001069202-21-000028:mdna:40]

[0001628280-21-020422:mdna:41]
Our effective tax rate was 18.4% for the third quarter of 2021 compared to 17.3% for the third quarter of 2020. The rate increased primarily due to the tax impact of discrete losses recorded in the third quarter of 2020.

[0001628280-21-020422:mdna:42]
We expect our annual effective tax rate in 2021 to be approximately 20%, after excluding the impact of excess tax benefits recorded under ASU No. 2016-09.

[0001628280-21-020422:mdna:43]
Third Quarter of 2021 Compared to Third Quarter of 2020 - Results by Segment

[0001628280-21-020422:mdna:44]
[same as prior period, unchanged from 0001069202-21-000028:mdna:44]

[0001628280-21-020422:mdna:45]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2021 and 2020 (dollars in millions):

[0001628280-21-020422:mdna:46]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 711.0 |  |  | $ | 722.0 |  |  | $ | (11.0) |  |  | (1.5) | % |
| Profit | $ | 144.0 |  |  | $ | 153.0 |  |  | $ | (9.0) |  |  | (5.9) | % |
| % of net sales | 20.3 | % |  | 21.2 | % |  |  |  |  |

[0001628280-21-020422:mdna:47]
Net sales decreased 2% in the third quarter of 2021 compared to 2020.  Sales volume decreased 6%, which was partially offset by favorable price and mix combined of 4%.

[0001628280-21-020422:mdna:48]
Segment profit in the third quarter of 2021 compared to 2020 decreased $9 million due to $18 million from higher commodity costs, $14 million from lower sales volume, $6 million from unfavorable freight and distribution costs, $4 million from factory inefficiencies, $3 million from sourcing and engineering-led cost increases, and $3 million from higher other product costs.  Partially offsetting these declines were $33 million from higher combined price and mix, $5 million from lower SG&A, and $1 million from favorable foreign currency.

[0001628280-21-020422:mdna:49]
[same as prior period, unchanged from 0001069202-21-000028:mdna:49]

[0001628280-21-020422:mdna:50]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2021 and 2020 (dollars in millions):

[0001628280-21-020422:mdna:51]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 211.5 |  |  | $ | 207.9 |  |  | $ | 3.6 |  |  | 1.7 | % |
| Profit | $ | 22.6 |  |  | $ | 38.8 |  |  | $ | (16.2) |  |  | (41.8) | % |
| % of net sales | 10.7 | % |  | 18.7 | % |  |  |  |  |

[0001628280-21-020422:mdna:52]
Net sales increased 2% in the third quarter of 2021 compared to the third quarter of 2020.  Price and mix combine increased 7% and foreign currency improved 1%, which was partially offset by 6% lower sales volume.

[0001628280-21-020422:mdna:53]
Segment profit in the third quarter of 2021 compared to 2020 decreased $16 million due to $7 million from higher other product costs, $5 million from higher factory inefficiencies, $3 million from lower sales volume, $3 million from higher freight and distribution costs, $2 million from higher commodity costs, $1 million from sourcing and engineering-led cost increases, and $1 million from unfavorable foreign currency.  Partially offsetting these declines were $6 million from higher combined price and mix.

[0001628280-21-020422:mdna:54]
[same as prior period, unchanged from 0001069202-21-000028:mdna:54]

[0001628280-21-020422:mdna:55]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2021 and 2020 (dollars in millions):

[0001628280-21-020422:mdna:56]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 137.4 |  |  | $ | 125.1 |  |  | $ | 12.3 |  |  | 9.8 | % |
| Profit | $ | 14.5 |  |  | $ | 13.0 |  |  | $ | 1.5 |  |  | 11.5 | % |
| % of net sales | 10.6 | % |  | 10.4 | % |  |  |  |  |

[0001628280-21-020422:mdna:57]
Net sales increased 10% in the third quarter of 2021 compared to the third quarter of 2020. Sales volume was 9% higher and combined price and mix improved 1%.

[0001628280-21-020422:mdna:58]
Segment profit in the third quarter of 2021 compared to 2020 increased $2 million compared to 2020 due to $5 million from higher sales volume, $3 million from favorable price and mix combined, and $1 million from higher income from equity method investments.  Partially offsetting these increases was $4 million from higher commodity costs, $2 million from higher SG&A, and $1 million from higher freight and distribution costs.

[0001628280-21-020422:mdna:59]
[same as prior period, unchanged from 0001069202-21-000028:mdna:59]

[0001628280-21-020422:mdna:60]
Corporate and other expenses decreased $12 million to $16 million in the third quarter of 2021 compared to 2020 primarily due to the timing of variable incentive compensation costs.

[0001628280-21-020422:mdna:61]
Year-to-Date through September 30, 2021 Compared to Year-to-Date through September 30, 2020 - Consolidated Results

[0001628280-21-020422:mdna:62]
[same as prior period, unchanged from 0001069202-21-000028:mdna:62]

[0001628280-21-020422:mdna:63]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales | $ | 3,229.3 |  |  | $ | 2,720.1 |  |  | 18.7 |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 2,294.5 |  |  | 1,955.3 |  |  | (17.3) |  |  | 71.1 |  |  | 71.9 |  |
| Gross profit | 934.8 |  |  | 764.8 |  |  | 22.2 |  |  | 28.9 |  |  | 28.1 |  |
| Selling, general and administrative expenses | 447.4 |  |  | 412.7 |  |  | (8.4) |  |  | 13.9 |  |  | 15.2 |  |
| Losses (gains) and other expenses, net | 4.7 |  |  | 5.6 |  |  | 16.1 |  |  | 0.1 |  |  | 0.2 |  |
| Restructuring charges | 1.6 |  |  | 10.6 |  |  | 84.9 |  |  | — |  |  | 0.4 |  |
| Loss (gain) from natural disasters, net of insurance recoveries | — |  |  | 7.6 |  |  | (100.0) |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (11.6) |  |  | (11.2) |  |  | 3.6 |  |  | (0.4) |  |  | (0.4) |  |
| Operating income | $ | 492.7 |  |  | $ | 339.5 |  |  | 45.1 |  |  | 15.3 | % |  | 12.5 | % |

[0001628280-21-020422:mdna:64]
[same as prior period, unchanged from 0001069202-21-000028:mdna:64]

[0001628280-21-020422:mdna:65]
Net sales increased 19% for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020 due to higher sales volumes of 15%, favorable combined price and mix of 3%, and a 1% increase from to foreign currency.

[0001628280-21-020422:mdna:66]
[same as prior period, unchanged from 0001069202-21-000028:mdna:66]

[0001628280-21-020422:mdna:67]
Gross profit margins for the nine months ended September 30, 2021 increased 80 bps to 28.9% compared to 28.1% for the nine months ended September 30, 2020. Gross margin increased 160 bps from favorable price, 90 bps from favorable mix, and

[0001628280-21-020422:mdna:68]
40 bps from factory productivity which were partially offset by 130 bps from higher commodity costs, 50 bps from higher other product costs, 20 bps from higher freight and distribution costs, and 10 bps from higher warranty costs.

[0001628280-21-020422:mdna:69]
[same as prior period, unchanged from 0001069202-21-000028:mdna:69]

[0001628280-21-020422:mdna:70]
SG&A increased $34 million to $447 million for the nine months ended September 30, 2021 compared to $413 million for the nine months ended September 30, 2020 primarily due to higher incentive compensation costs and higher other employee related costs.  As a percentage of net sales, SG&A decreased 130 bps to 13.9% from 15.2%.

[0001628280-21-020422:mdna:71]
[same as prior period, unchanged from 0001069202-21-000028:mdna:71]

[0001628280-21-020422:mdna:72]
Losses (gains) and other expenses, net for the nine months ended September 30, 2021 and 2020 included the following (in millions):

[0001628280-21-020422:mdna:73]
|  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |
| Realized (gains) losses on settled futures contracts | $ | (0.9) |  |  | $ | 0.2 |  |
| Foreign currency exchange gains | (1.6) |  |  | (3.0) |  |
| Gain on disposal of fixed assets | (0.6) |  |  | (0.4) |  |
| Other operating income | (0.9) |  |  | (1.7) |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | 0.1 |  |  | — |  |
| Special legal contingency charges | 1.0 |  |  | 0.9 |  |
| Asbestos-related litigation | 4.5 |  |  | 1.9 |  |
| Environmental liabilities | 1.8 |  |  | 1.5 |  |
| Charges incurred related to COVID-19 pandemic | 1.9 |  |  | 6.4 |  |
| Other items, net | (0.6) |  |  | (0.2) |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 4.7 |  |  | $ | 5.6 |  |

[0001628280-21-020422:mdna:74]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 7 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities related to estimated remediation costs for contamination at some of our facilities.

[0001628280-21-020422:mdna:75]
[same as prior period, unchanged from 0001069202-21-000028:mdna:75]

[0001628280-21-020422:mdna:76]
Restructuring charges were $2 million for the first nine months of 2021 and $11 million for the nine months ended September 30, 2020.  Charges primarily relate to several cost reduction actions taken in response to the economic impact of the COVID-19 pandemic on our business.

[0001628280-21-020422:mdna:77]
[same as prior period, unchanged from 0001069202-21-000028:mdna:77]

[0001628280-21-020422:mdna:78]
The activity in this account for 2020 related to costs occured for natural disasters in our manufacturing facility in Iowa.  There was no activity in 2021.

[0001628280-21-020422:mdna:79]
[same as prior period, unchanged from 0001069202-21-000028:mdna:79]

[0001628280-21-020422:mdna:80]
Income from equity method investments of $12 million for the nine months ended September 30, 2021 was materially consistent with the amount for the nine months ended September 30, 2020.

[0001628280-21-020422:mdna:81]
[same as prior period, unchanged from 0001069202-21-000028:mdna:81]

[0001628280-21-020422:mdna:82]
Interest expense, net was down $3 million for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020 primarily due to lower borrowing costs.

[0001628280-21-020422:mdna:83]
[same as prior period, unchanged from 0001069202-21-000028:mdna:83]

[0001628280-21-020422:mdna:84]
Our effective tax rate decreased to 19.0% for the nine months ended September 30, 2021 compared to 22.0% for the nine months ended September 30, 2020 primarily due to higher excess tax benefits from stock-based compensation and the recording of a valuation allowance on certain foreign deferred tax assets recorded in the first quarter of 2020.

[0001628280-21-020422:mdna:85]
Year-to-Date through September 30, 2021 Compared to Year-to-Date through September 30, 2020 - Results by Segment

[0001628280-21-020422:mdna:86]
[same as prior period, unchanged from 0001069202-21-000028:mdna:86]

[0001628280-21-020422:mdna:87]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the nine months ended September 30, 2021 and 2020 (dollars in millions):

[0001628280-21-020422:mdna:88]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 2,155.3 |  |  | $ | 1,808.8 |  |  | $ | 346.5 |  |  | 19.2 | % |
| Profit | $ | 430.1 |  |  | $ | 312.8 |  |  | $ | 117.3 |  |  | 37.5 | % |
| % of net sales | 20.0 | % |  | 17.3 | % |  |  |  |  |

[0001628280-21-020422:mdna:89]
Net sales increased 19% for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020. Sales volume was 15% higher, price and mix combined improved 3%, and foreign currency improved 1%.

[0001628280-21-020422:mdna:90]
Segment profit for the first nine months of 2021 compared to 2020 increased $117 million primarily due to $86 million from higher sales volume, $62 million from favorable price, $19 million from higher factory productivity, $6 million from favorable currency exchange, and $5 million from sourcing and engineering-led cost reductions. Partially offsetting these increases were $35 million from higher commodity costs and tariffs, $11 million from higher SG&A, $9 million from higher warranty and other product costs, $4 million from unfavorable mix, and $2 million from freight and distribution.

[0001628280-21-020422:mdna:91]
[same as prior period, unchanged from 0001069202-21-000028:mdna:91]

[0001628280-21-020422:mdna:92]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the nine months ended September 30, 2021 and 2020 (dollars in millions):

[0001628280-21-020422:mdna:93]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 663.4 |  |  | $ | 574.6 |  |  | $ | 88.8 |  |  | 15.5 | % |
| Profit | $ | 95.3 |  |  | $ | 93.1 |  |  | $ | 2.2 |  |  | 2.4 | % |
| % of net sales | 14.4 | % |  | 16.2 | % |  |  |  |  |

[0001628280-21-020422:mdna:94]
Net sales increased 16% for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020.  Sales volume was 12% higher, price and mix combined improved 3%, and foreign currency improved 1%.

[0001628280-21-020422:mdna:95]
Segment profit for the first nine months of 2021 compared to 2020 increased $2 million primarily due to $24 million from higher sales volume and $9 million from favorable price and mix. Partially offsetting these improvements were $11 million from higher other product costs, $8 million from factory inefficiencies, $4 million from higher freight and distribution costs, $3 million of higher SG&A costs, $3 million from higher commodity costs and tariffs, and $2 million from sourcing and engineering-led cost increases.

[0001628280-21-020422:mdna:96]
[same as prior period, unchanged from 0001069202-21-000028:mdna:96]

[0001628280-21-020422:mdna:97]
The following table presents our Refrigeration segment's net sales and profit for the nine months ended September 30, 2021 and 2020 (dollars in millions):

[0001628280-21-020422:mdna:98]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 410.6 |  |  | $ | 336.7 |  |  | $ | 73.9 |  |  | 21.9 | % |
| Profit | $ | 35.8 |  |  | $ | 22.6 |  |  | $ | 13.2 |  |  | 58.4 | % |
| % of net sales | 8.7 | % |  | 6.7 | % |  |  |  |  |

[0001628280-21-020422:mdna:99]
Net sales increased 22% for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020. Sales volume was 17% higher, foreign currency improved 3% and combined price and mix was 2% higher.

[0001628280-21-020422:mdna:100]
Segment profit for the first nine months of 2021 compared to 2020 increased $13 million primarily due to $21 million from higher volume, $7 million from favorable price and mix combined, $2 million from sourcing and engineering-led cost reductions, and $1 million from favorable foreign currency exchange. Partially offsetting these increases were $10 million from higher SG&A, $5 million from higher commodity costs, $2 million from higher other product costs, and $1 million from higher freight and distribution expense.

[0001628280-21-020422:mdna:101]
[same as prior period, unchanged from 0001069202-21-000028:mdna:101]

[0001628280-21-020422:mdna:102]
Corporate and other expenses decreased $2 million in the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020 primarily due to changes in incentive compensation costs.

[0001628280-21-020422:mdna:103]
[same as prior period, unchanged from 0001069202-21-000028:mdna:103]

[0001628280-21-020422:mdna:104]
[same as prior period, unchanged from 0001069202-21-000028:mdna:104]

[0001628280-21-020422:mdna:105]
[same as prior period, unchanged from 0001069202-21-000028:mdna:105]

[0001628280-21-020422:mdna:106]
The following table summarizes our cash flow activity for the nine months ended September 30, 2021 and 2020 (in millions):

[0001628280-21-020422:mdna:107]
|  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |
| Net cash provided by operating activities | $ | 396.3 |  |  | $ | 446.2 |  |
| Net cash used in investing activities | (67.6) |  |  | (56.5) |  |
| Net cash used in financing activities | (410.5) |  |  | (365.0) |  |

[0001628280-21-020422:mdna:108]
Net Cash Provided by Operating Activities -  The change in net cash provided by operating activities for the nine months ended September, 30 2021 compared to the same period in 2020 reflects less favorable changes in working capital partially offset by an increase in operating income.

[0001628280-21-020422:mdna:109]
Net Cash Used in Investing Activities - Capital expenditures were $69 million for the nine months ended September 30, 2021 compared to $56 million in the same period of 2020.  Capital expenditures in 2021 were primarily related to the expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-21-020422:mdna:110]
Net Cash Used in Financing Activities - Net cash used in financing activities for the nine months ended September 30, 2021 increased to $411 million compared to $365 million in the same period of 2020.  The change was primarily due to increased share repurchases in the current year compared to the prior year, which was partially offset by increased net borrowings.  We repurchased $600 million of shares for the nine months ended September 30, 2021 and returned $93 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated

[0001628280-21-020422:mdna:111]
Financial Statements.

[0001628280-21-020422:mdna:112]
[same as prior period, unchanged from 0001069202-21-000028:mdna:111]

[0001628280-21-020422:mdna:113]
The following table details our lines of credit and financing arrangements as of September 30, 2021 (in millions):

[0001628280-21-020422:mdna:114]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (2) | $ | 290.0 |  |
| Finance lease obligations | 10.6 |  |
| Debt issuance costs | — |  |
| Total current maturities of long-term debt | $ | 300.6 |  |
| Long-term debt: |  |
| Finance lease obligations | 27.8 |  |
| Domestic credit facility (1) | 9.0 |  |
| Senior unsecured notes | 950.0 |  |
| Debt issuance costs | (9.2) |  |
| Total long-term debt | 977.6 |  |
| Total debt | $ | 1,278.2 |  |

[0001628280-21-020422:mdna:115]
(1)   The available future borrowings on our domestic credit facility are $739.0 million, after being reduced by the outstanding borrowings and $2.0 million in outstanding standby letters of credit.  Refer to Note 10 in the Notes to the Consolidated Financial Statements related to the terms of the Domestic Credit Facility.

[0001628280-21-020422:mdna:116]
(2)     The maximum securitization amount ranges from $250.0 million to $400.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-21-020422:mdna:117]
[same as prior period, unchanged from 0001069202-21-000028:mdna:116]

[0001628280-21-020422:mdna:118]
[same as prior period, unchanged from 0001069202-21-000028:mdna:117]

[0001628280-21-020422:mdna:119]
[same as prior period, unchanged from 0001069202-21-000028:mdna:118]

[0001628280-21-020422:mdna:120]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and its subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of its assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control.

[0001628280-21-020422:mdna:121]
[same as prior period, unchanged from 0001069202-21-000028:mdna:120]

[0001628280-21-020422:mdna:122]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations,

[0001628280-21-020422:mdna:123]
the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 135% at September 30, 2021 from 102% at December 31, 2020.

[0001628280-21-020422:mdna:124]
As of September 30, 2021, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-21-020422:mdna:125]
[same as prior period, unchanged from 0001069202-21-000028:mdna:123]

[0001628280-21-020422:mdna:126]
We believe our cash and cash equivalents of $39 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $39 million as of September 30, 2021 was $18 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-21-020422:mdna:127]
[same as prior period, unchanged from 0001069202-21-000028:mdna:125]

[0001628280-21-020422:mdna:128]
[same as prior period, unchanged from 0001069202-21-000028:mdna:126]

[0001628280-21-020422:mdna:129]
[same as prior period, unchanged from 0001069202-21-000028:mdna:127]

[0001628280-21-020422:mdna:130]
[same as prior period, unchanged from 0001069202-21-000028:mdna:128]

[0001628280-21-020422:mdna:131]
[same as prior period, unchanged from 0001069202-21-000028:mdna:129]

[0001628280-21-020422:mdna:132]
Commitments, Contingencies and Guarantees

[0001628280-21-020422:mdna:133]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-21-020422:mdna:134]
[same as prior period, unchanged from 0001069202-21-000028:mdna:132]

[0001628280-21-020422:mdna:135]
[same as prior period, unchanged from 0001069202-21-000028:mdna:133]
