# LII 8-K — 0001069202-19-000027 filed 2019-07-22

## item codes, every 8-K on or before 2019-07-22

- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2019-07-22

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-19-000027:8k_2_02:1]
EX-99..1
2
ex-991pressreleasetables20.htm
EXHIBIT 99..1

[0001069202-19-000027:8k_2_02:2]
Exhibit

[0001069202-19-000027:8k_2_02:3]
Exhibit-99.1

[0001069202-19-000027:8k_2_02:4]
Lennox International Reports Second Quarter Results

[0001069202-19-000027:8k_2_02:5]
| • | Revenue on a GAAP basis down 6%, including 8% of negative impact from the tornado, divestitures and foreign exchange |

[0001069202-19-000027:8k_2_02:6]
| • | Excluding divestitures, adjusted revenue down 1%, including 3% of negative tornado impact and 1% of negative foreign exchange |

[0001069202-19-000027:8k_2_02:7]
| • | GAAP EPS from continuing operations down 17% to $2.81, including a previously announced non-cash pension settlement charge of $1.14 |

[0001069202-19-000027:8k_2_02:8]
| • | Adjusted EPS from continuing operations up 2% to $3.74 |

[0001069202-19-000027:8k_2_02:9]
| • | Updating 2019 guidance following the adverse weather conditions of the second quarter and a reduced outlook on commercial and refrigeration end markets |

[0001069202-19-000027:8k_2_02:10]
| • | Updating 2019 guidance for adjusted revenue growth from 3-7% to 2-5% |

[0001069202-19-000027:8k_2_02:11]
| • | Updating 2019 guidance for GAAP EPS from continuing operations from $12.65-$13.25 to $11.91-$12.51 |

[0001069202-19-000027:8k_2_02:12]
| • | Updating adjusted EPS from continuing operations from $12.00-$12.60 to $11.30-$11.90 |

[0001069202-19-000027:8k_2_02:13]
| • | Reiterating 2019 guidance for $400 million of stock repurchases |

[0001069202-19-000027:8k_2_02:14]
DALLAS, July 22, 2019 - Lennox International Inc. (NYSE: LII) today reported financial results for the second quarter of 2019. All comparisons are to the prior-year period. The company’s tornado references relate to the July 2018 tornado damage at a Residential manufacturing facility in Iowa. Adjusted revenue and profit exclude non-core Refrigeration businesses divested in 2018 and 2019.

[0001069202-19-000027:8k_2_02:15]
For the second quarter, Lennox International reported GAAP and adjusted revenue of $1,099 million. GAAP revenue was down 6%. At constant currency, GAAP revenue was down 5%. Adjusted revenue, excluding the impact from divestitures, was down 1%. At constant currency, adjusted revenue was flat, including 3% of negative tornado impact.

[0001069202-19-000027:8k_2_02:16]
GAAP operating income was $214 million, up 10%. GAAP earnings per share from continuing operations was $2.81, down 17%, including a non-cash pension settlement charge of $1.14. Total adjusted segment profit declined 2% to $202 million in the second quarter, and total segment margin was relatively flat at 18.4%. Adjusted earnings per share from continuing operations was up 2% to $3.74.

[0001069202-19-000027:8k_2_02:17]
“Significantly cooler temperatures and higher precipitation across the United States adversely impacted the HVAC market in the second quarter, and especially in key Central regions where cooling degree days were down over 30% and precipitation was up over 60% ,” said Chairman and CEO Todd Bluedorn. “Residential segment revenue was down 3% at constant currency and down 4% on a reported basis in the quarter, profit was flat, and margin expanded 80 basis points to 22.3%. Residential price yield was 3.6% in the quarter. Our Residential business had negative tornado impact of $28 million to revenue in the second quarter and $16 million to segment profit offset by $18 million of insurance recovery. Adjusting for the net impact from the tornado and insurance proceeds, Residential revenue was flat, profit was down 1%, and margin was down 40 basis points to 21.1%.

[0001069202-19-000027:8k_2_02:18]
“Slower moving shipments in the industry due to adverse weather has slowed regaining market share following the tornado and extends our recovery timeline to include the fourth quarter,” Bluedorn added. “For 2019 overall, we now expect $99 million of negative tornado impact to Residential revenue, up from $70 million previously; a negative $54 million impact to segment profit, up from $40 million previously; and insurance recovery for lost profits of $94 million, up from $80 million previously. The resulting $40 million of net benefit to Residential segment profit in 2019 is unchanged.

[0001069202-19-000027:8k_2_02:19]
“Our Commercial business hit a new second-quarter high for revenue and set new records for segment profit and margin. Commercial revenue was up 4%, led by high-single digit growth in National Account equipment business. Segment profit rose 6% to a record $54 million, and segment margin expanded 50 basis points to a record 20.6%. In Refrigeration, adjusted segment revenue rose 5% at constant currency with volume up in Europe and down in North America. Adjusted segment profit was down 19%, and adjusted segment margin declined 340 basis points to 12.8%, due in part to lower mix and the timing of the sale of refrigerant allocations in Europe compared to the prior-year quarter. We continue to expect revenue growth for both of these businesses in the second half but have reduced the outlook on commercial and refrigeration end markets.

[0001069202-19-000027:8k_2_02:20]
“For the company overall, we are updating 2019 guidance to adjusted revenue growth of 2-5% and adjusted EPS from continuing operations of $11.30-$11.90 and reiterate stock repurchases of $400 million for the full year.”

[0001069202-19-000027:8k_2_02:21]
FINANCIAL HIGHLIGHTS

[0001069202-19-000027:8k_2_02:22]
Revenue: On a GAAP and adjusted basis, second-quarter revenue was $1,099 million. GAAP revenue was down 6%, and adjusted revenue was down 1%. Foreign exchange was unfavorable to revenue growth by 1%. Volume was down, and price and mix were favorable.

[0001069202-19-000027:8k_2_02:23]
Gross Profit: On a GAAP and adjusted basis, gross profit was $332 million and gross margin was 30.2%. Gross profit was down 8% on a GAAP basis and down 6% on an adjusted basis. Gross margin was down 60 basis points on a GAAP basis and down 140 basis points on an adjusted basis. Gross profit was impacted by the tornado, cooler and wetter weather and factory productivity, unfavorable mix, higher commodity, freight, tariff and other product costs, distribution investments, and unfavorable foreign exchange. On a GAAP basis, divestitures also had a negative impact on gross profit. Partial offsets to gross profit included favorable price and warranty, and sourcing and engineering-led cost reductions.

[0001069202-19-000027:8k_2_02:24]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the second quarter was $111.0 million, or $2.81 per share, compared to $139.2 million, or $3.39 per share, in the prior-year quarter.

[0001069202-19-000027:8k_2_02:25]
Adjusted income from continuing operations in the second quarter was $147.6 million, or $3.74 per share, compared to $150.6 million, or $3.67 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the second quarter of 2019 excludes net after-tax charges of $36.6 million: a charge of $45.5 million for pension settlement, a net charge of $1.5 million for various other items, and a gain of  $10.4 million from insurance recoveries, net of losses incurred.

[0001069202-19-000027:8k_2_02:26]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from operations in the second quarter was $30 million compared to $49 million in the prior-year quarter. Capital expenditures and purchases of short-term investments were $18 million compared to $21 million in the prior-year quarter. Insurance recoveries for damage to property and proceeds from the disposal of property, plant and equipment were approximately $6 million in the second quarter of 2019. Free cash flow was $20 million compared to $28 million in the second quarter a year ago. Total debt at the end of the second quarter was $1.47 billion. Total cash and cash equivalents were $36 million at the end of June. In the second quarter, the company repurchased $150 million of stock and paid $25 million in dividends.

[0001069202-19-000027:8k_2_02:27]
BUSINESS SEGMENT HIGHLIGHTS

[0001069202-19-000027:8k_2_02:28]
Residential Heating & Cooling

[0001069202-19-000027:8k_2_02:29]
Revenue in the Residential Heating & Cooling business segment declined 4% to $689 million. Foreign exchange had a negative 1% impact on revenue. Segment profit was flat at $153 million. Segment margin expanded 80 basis points to 22.3%. Residential results were impacted by favorable price, sourcing and engineering-led cost reductions, favorable warranty, and insurance proceeds. Offsets included cooler and wetter weather, tornado impact, factory productivity, unfavorable mix, higher commodity, freight, tariff and other product costs, distribution and SG&A investments, and unfavorable foreign exchange.

[0001069202-19-000027:8k_2_02:30]
Commercial Heating & Cooling

[0001069202-19-000027:8k_2_02:31]
Revenue in the Commercial Heating & Cooling business segment was a second-quarter record $261 million, up 4%. Foreign exchange was neutral to revenue. Segment profit was a record $54 million, up 6%, and segment margin was a record 20.6%, up 50 basis points. Results were impacted by favorable price, favorable mix, and sourcing and engineering-led cost reductions. Partial offsets included lower volume, higher commodity and other product costs, tariffs, freight, and distribution and SG&A investments.

[0001069202-19-000027:8k_2_02:32]
Refrigeration

[0001069202-19-000027:8k_2_02:33]
Adjusted revenue in the Refrigeration business segment was $149 million in the second quarter, up 2%. Foreign exchange had a negative 3% impact on revenue. Refrigeration adjusted profit was $19 million, down 19%, and adjusted segment margin was 12.8%, down 340 basis points. Results were impacted by lower mix and the timing on the sale of refrigerant allocations in Europe compared to the prior-year quarter, higher commodity, freight, distribution, tariffs and other product costs, and unfavorable foreign exchange. Partial offsets included higher volume, favorable price, sourcing and engineering-led cost reductions, and lower SG&A expenses.

[0001069202-19-000027:8k_2_02:34]
FULL-YEAR OUTLOOK

[0001069202-19-000027:8k_2_02:35]
| • | Updating 2019 guidance for adjusted revenue growth from 3-7% to 2-5%. |

[0001069202-19-000027:8k_2_02:36]
| • | Updating guidance for GAAP EPS from continuing operations from $12.65-$13.25 to $11.91-$12.51. |

[0001069202-19-000027:8k_2_02:37]
| • | Updating guidance for adjusted EPS from continuing operations from $12.00-$12.60 to $11.30-$11.90. |

[0001069202-19-000027:8k_2_02:38]
| • | Reiterating guidance for corporate expenses of approximately $90 million. |

[0001069202-19-000027:8k_2_02:39]
| • | Reiterating guidance for an effective tax rate of 22-23% on an adjusted basis for the full year. |

[0001069202-19-000027:8k_2_02:40]
| • | Updating guidance for 2019 capital expenditures from approximately $195 million to $155 million as $40 million of capital to fully reconstruct the Iowa manufacturing facility damaged by the tornado moved from 2019 to 2020. |

[0001069202-19-000027:8k_2_02:41]
| • | Updating guidance for free cash flow from approximately $420 million to $390 million for the full year. |

[0001069202-19-000027:8k_2_02:42]
| • | Reiterating guidance for stock repurchases of $400 million in 2019. |

[0001069202-19-000027:8k_2_02:43]
A chart of the company’s current view on the tornado financial impact and insurance recovery for 2018-2019 is posted on the company’s website at www.lennoxinternational.com.

[0001069202-19-000027:8k_2_02:44]
CONFERENCE CALL INFORMATION

[0001069202-19-000027:8k_2_02:45]
A conference call to discuss the company's second-quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-288-0337 at least 10 minutes prior to the scheduled start time and use reservation number 469736. The conference call also will be webcast on Lennox International's web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on July 22 through August 5, 2019 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 469736. The call also will be archived on the company's website.

[0001069202-19-000027:8k_2_02:46]
About Lennox International

[0001069202-19-000027:8k_2_02:47]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol "LII". Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-19-000027:8k_2_02:48]
FORWARD-LOOKING STATEMENTS

[0001069202-19-000027:8k_2_02:49]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Statements of Operations(Unaudited) |
| (Amounts in millions, except per share data) | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 1,099.1 |  |  | $ | 1,175.4 |  |  | $ | 1,889.4 |  |  | $ | 2,010.2 |  |
| Cost of goods sold | 767.0 |  |  | 813.8 |  |  | 1,355.8 |  |  | 1,425.5 |  |
| Gross profit | 332.1 |  |  | 361.6 |  |  | 533.6 |  |  | 584.7 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 152.4 |  |  | 161.4 |  |  | 298.2 |  |  | 316.6 |  |
| Losses (gains) and other expenses, net | 2.1 |  |  | 0.2 |  |  | 3.2 |  |  | 7.5 |  |
| Restructuring charges | (0.1 | ) |  | 0.5 |  |  | 0.4 |  |  | 1.3 |  |
| Loss (gain) on sale of businesses and related property | 0.4 |  |  | (22.1 | ) |  | 8.8 |  |  | (11.8 | ) |
| Loss on assets held for sale | — |  |  | 31.4 |  |  | — |  |  | 31.4 |  |
| Insurance proceeds for lost profits | (26.0 | ) |  | — |  |  | (65.5 | ) |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (5.9 | ) |  | — |  |  | (12.8 | ) |  | — |  |
| Income from equity method investments | (4.6 | ) |  | (4.9 | ) |  | (7.2 | ) |  | (8.4 | ) |
| Operating income | 213.8 |  |  | 195.1 |  |  | 308.5 |  |  | 248.1 |  |
| Pension settlement | 60.6 |  |  | — |  |  | 60.6 |  |  | — |  |
| Interest expense, net | 13.1 |  |  | 9.8 |  |  | 23.9 |  |  | 18.2 |  |
| Other expense (income), net | 0.3 |  |  | 0.8 |  |  | 1.2 |  |  | 1.4 |  |
| Income from continuing operations before income taxes | 139.8 |  |  | 184.5 |  |  | 222.8 |  |  | 228.5 |  |
| Provision for income taxes | 28.8 |  |  | 45.3 |  |  | 42.4 |  |  | 51.4 |  |
| Income from continuing operations | 111.0 |  |  | 139.2 |  |  | 180.4 |  |  | 177.1 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| (Loss) income from discontinued operations before income taxes | (0.3 | ) |  | 0.4 |  |  | (0.4 | ) |  | 0.4 |  |
| Income tax expense | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |
| Loss from discontinued operations | (0.3 | ) |  | (1.6 | ) |  | (0.4 | ) |  | (1.6 | ) |
| Net income | $ | 110.7 |  |  | $ | 137.6 |  |  | $ | 180.0 |  |  | $ | 175.5 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.84 |  |  | $ | 3.42 |  |  | $ | 4.58 |  |  | $ | 4.31 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.04 | ) |  | (0.01 | ) |  | (0.04 | ) |
| Net income | $ | 2.83 |  |  | $ | 3.38 |  |  | $ | 4.57 |  |  | $ | 4.27 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.81 |  |  | $ | 3.39 |  |  | $ | 4.53 |  |  | $ | 4.26 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.04 | ) |  | (0.01 | ) |  | (0.04 | ) |
| Net income | $ | 2.80 |  |  | $ | 3.35 |  |  | $ | 4.52 |  |  | $ | 4.22 |  |
| Weighted Average Number of Shares Outstanding - Basic | 39.1 |  |  | 40.7 |  |  | 39.4 |  |  | 41.1 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 39.5 |  |  | 41.1 |  |  | 39.8 |  |  | 41.6 |  |

[0001069202-19-000027:8k_2_02:50]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Adjusted Segment Net Sales and Profit (Loss) |
| (Unaudited) |

[0001069202-19-000027:8k_2_02:51]
| (Amounts in millions) | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 689.1 |  |  | $ | 716.0 |  |  | $ | 1,154.6 |  |  | $ | 1,169.7 |  |
| Commercial Heating & Cooling | 261.3 |  |  | 252.1 |  |  | 434.7 |  |  | 431.2 |  |
| Refrigeration (1) | 148.7 |  |  | 145.5 |  |  | 265.8 |  |  | 264.7 |  |
|  | $ | 1,099.1 |  |  | $ | 1,113.6 |  |  | $ | 1,855.1 |  |  | $ | 1,865.6 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 153.4 |  |  | $ | 153.6 |  |  | $ | 240.1 |  |  | $ | 204.9 |  |
| Commercial Heating & Cooling | 53.9 |  |  | 50.8 |  |  | 68.9 |  |  | 72.8 |  |
| Refrigeration (1) | 19.1 |  |  | 23.6 |  |  | 28.5 |  |  | 35.2 |  |
| Corporate and other | (24.1 | ) |  | (22.5 | ) |  | (36.2 | ) |  | (33.7 | ) |
| Total adjusted segment profit | 202.3 |  |  | 205.5 |  |  | 301.3 |  |  | 279.2 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Special inventory write down | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Special product quality adjustment | (0.5 | ) |  | — |  |  | (0.5 | ) |  | — |  |
| Loss (gain) on sale of businesses | 0.4 |  |  | (22.1 | ) |  | 8.8 |  |  | (11.8 | ) |
| Loss on assets held for sale | — |  |  | 31.4 |  |  | — |  |  | 31.4 |  |
| Gain from insurance recoveries, net of losses incurred | (5.9 | ) |  | — |  |  | (12.8 | ) |  | — |  |
| Partial advance of insurance recoveries related to lost profits | (8.0 | ) |  | — |  |  | (8.0 | ) |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 2.6 |  |  | 0.4 |  |  | 3.9 |  |  | 6.9 |  |
| Restructuring charges | (0.1 | ) |  | 0.5 |  |  | 0.4 |  |  | 1.3 |  |
| Operating loss from non-core businesses (1) | — |  |  | 0.2 |  |  | 1.0 |  |  | 3.1 |  |
| Operating income | $ | 213.8 |  |  | $ | 195.1 |  |  | $ | 308.5 |  |  | $ | 248.1 |  |

[0001069202-19-000027:8k_2_02:52]
(1) Excludes the non-core business results related to Kysor Warren, which was sold in March 2019 and the Company's business operations in Australia, Asia and South America, which were sold in 2018.

[0001069202-19-000027:8k_2_02:53]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-19-000027:8k_2_02:54]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-19-000027:8k_2_02:55]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-19-000027:8k_2_02:56]
| ◦ | Special legal contingency charges, |

[0001069202-19-000027:8k_2_02:57]
| ◦ | Asbestos-related litigation, |

[0001069202-19-000027:8k_2_02:58]
| ◦ | Environmental liabilities, |

[0001069202-19-000027:8k_2_02:59]
| ◦ | Divestiture costs, |

[0001069202-19-000027:8k_2_02:60]
| ◦ | Other items, net, |

[0001069202-19-000027:8k_2_02:61]
| • | Special inventory write down, |

[0001069202-19-000027:8k_2_02:62]
| • | Special product quality adjustment, |

[0001069202-19-000027:8k_2_02:63]
| • | Loss on sale of business, |

[0001069202-19-000027:8k_2_02:64]
| • | Loss on assets held for sale, |

[0001069202-19-000027:8k_2_02:65]
| • | Gain from insurance recoveries, net of losses incurred, |

[0001069202-19-000027:8k_2_02:66]
| • | Partial advance of insurance recoveries related to lost profits; and, |

[0001069202-19-000027:8k_2_02:67]
| • | Restructuring charges. |

[0001069202-19-000027:8k_2_02:68]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Balance Sheets |
| (Amounts in millions, except shares and par values) | As of June 30, 2019 |  | As of December 31, 2018 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 36.4 |  |  | $ | 46.3 |  |
| Short-term investments | 1.8 |  |  | — |  |
| Accounts and notes receivable, net of allowances of $6.1 and $6.3 in 2019 and 2018, respectively | 718.8 |  |  | 472.7 |  |
| Inventories, net | 630.2 |  |  | 509.8 |  |
| Other assets | 56.7 |  |  | 60.6 |  |
| Total current assets | 1,443.9 |  |  | 1,089.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $795.8 and $778.5 in 2019 and 2018, respectively | 418.0 |  |  | 408.3 |  |
| Right-of-use assets from operating leases | 166.2 |  |  | — |  |
| Goodwill | 186.6 |  |  | 186.6 |  |
| Deferred income taxes | 49.2 |  |  | 67.0 |  |
| Other assets, net | 76.5 |  |  | 65.9 |  |
| Total assets | $ | 2,340.4 |  |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 311.0 |  |  | 300.8 |  |
| Current operating lease liabilities | 49.6 |  |  | — |  |
| Accounts payable | 473.6 |  |  | 433.3 |  |
| Accrued expenses | 240.8 |  |  | 272.3 |  |
| Income taxes payable | — |  |  | 2.1 |  |
| Total current liabilities | 1,075.0 |  |  | 1,008.5 |  |
| Long-term debt | 1,155.8 |  |  | 740.5 |  |
| Long-term operating lease liabilities | 117.6 |  |  | — |  |
| Pensions | 79.6 |  |  | 82.8 |  |
| Other liabilities | 129.9 |  |  | 135.0 |  |
| Total liabilities | 2,557.9 |  |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,085.8 |  |  | 1,078.8 |  |
| Retained earnings | 1,979.4 |  |  | 1,855.0 |  |
| Accumulated other comprehensive loss | (129.6 | ) |  | (188.8 | ) |
| Treasury stock, at cost, 48,144,394 shares and 47,312,248 shares for 2019 and 2018, respectively | (3,154.0 | ) |  | (2,895.5 | ) |
| Total stockholders' deficit | (217.5 | ) |  | (149.6 | ) |
| Total liabilities and stockholders' deficit | $ | 2,340.4 |  |  | $ | 1,817.2 |  |

[0001069202-19-000027:8k_2_02:69]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-19-000027:8k_2_02:70]
Consolidated Statements of Cash Flows

[0001069202-19-000027:8k_2_02:71]
(Unaudited)

[0001069202-19-000027:8k_2_02:72]
| (Amounts in millions) | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 180.0 |  |  | $ | 175.5 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |
| Loss on sale of businesses | 8.8 |  |  | 12.0 |  |
| Gain on sale of Australian Property | — |  |  | (23.8 | ) |
| Loss on Brazil assets held for sale | — |  |  | 31.4 |  |
| Gain from insurance recoveries, net of losses incurred | (12.8 | ) |  | — |  |
| Income from equity method investments | (7.2 | ) |  | (8.4 | ) |
| Dividend from Affiliates | 2.0 |  |  | 2.2 |  |
| Restructuring charges, net of cash paid | (0.2 | ) |  | 0.6 |  |
| Provision for bad debts | 2.2 |  |  | 3.3 |  |
| Unrealized losses on derivative contracts | (0.2 | ) |  | 1.3 |  |
| Stock-based compensation expense | 11.4 |  |  | 13.6 |  |
| Depreciation and amortization | 34.9 |  |  | 32.8 |  |
| Deferred income taxes | 15.7 |  |  | (6.2 | ) |
| Pension expense | 64.2 |  |  | 4.2 |  |
| Pension contributions | (1.0 | ) |  | (2.2 | ) |
| Other items, net | (0.1 | ) |  | 0.2 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (270.0 | ) |  | (272.1 | ) |
| Inventories | (149.9 | ) |  | (115.5 | ) |
| Other current assets | 10.2 |  |  | (2.2 | ) |
| Accounts payable | 52.6 |  |  | 109.2 |  |
| Accrued expenses | (21.0 | ) |  | 3.2 |  |
| Income taxes payable and receivable | (11.5 | ) |  | 15.1 |  |
| Other | (19.1 | ) |  | (9.2 | ) |
| Net cash used in operating activities | (111.0 | ) |  | (35.0 | ) |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.8 |  |  | 0.1 |  |
| Purchases of property, plant and equipment | (53.5 | ) |  | (43.4 | ) |
| Net proceeds from sale of businesses | 43.6 |  |  | 111.8 |  |
| Purchases of short-term investments | (1.8 | ) |  | — |  |
| Insurance recoveries received for property damage incurred from natural disaster | 12.8 |  |  | — |  |
| Net cash provided by investing activities | 1.9 |  |  | 68.5 |  |
| Cash flows from financing activities: |  |  |  |
| Short-term debt payments | (2.1 | ) |  | (18.4 | ) |
| Short-term debt proceeds | 2.1 |  |  | 21.3 |  |
| Asset securitization borrowings | 65.5 |  |  | 65.0 |  |
| Asset securitization payments | (43.5 | ) |  | (51.0 | ) |
| Long-term debt payments | (33.3 | ) |  | (17.8 | ) |
| Borrowings from credit facility | 1,459.5 |  |  | 1,391.0 |  |
| Payments on credit facility | (1,037.5 | ) |  | (1,042.0 | ) |
| Proceeds from employee stock purchases | 1.6 |  |  | 1.2 |  |
| Repurchases of common stock | (250.0 | ) |  | (350.2 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (14.5 | ) |  | (18.6 | ) |
| Cash dividends paid | (50.8 | ) |  | (42.4 | ) |
| Net cash provided by (used in) financing activities | 97.0 |  |  | (61.9 | ) |
| Decrease in cash and cash equivalents | (12.1 | ) |  | (28.4 | ) |
| Effect of exchange rates on cash and cash equivalents | 2.2 |  |  | (0.4 | ) |
| Cash and cash equivalents, beginning of period | 46.3 |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 36.4 |  |  | $ | 39.4 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 23.5 |  |  | $ | 18.3 |  |
| Income taxes paid (net of refunds) | $ | 54.2 |  |  | $ | 45.0 |  |
| Insurance recoveries received | $ | 128.0 |  |  | $ | — |  |

[0001069202-19-000027:8k_2_02:73]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. During the first quarter of 2019, the Company completed the sale of its Kysor Warren business. In the first quarter of 2018, the Company announced the planned sales of its businesses in Australia, Asia, and South America. The sale of the Company's business in Australia and Asia and the related property was completed in the second quarter of 2018 and sale of the Company's business in South America was completed in the third quarter of 2018. The results from operations for these businesses have been shown in the tables below as “Non-core business results”. The prior period results have been updated to provide period-over-period comparability. |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |
|  | For the Three Months Ended June 30, |
|  | (Unaudited) |
|  | 2019 |  | 2018 |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |
| Income from continuing operations, a GAAP measure | $ | 139.8 |  | $ | (28.8 | ) | $ | 111.0 |  |  | $ | 184.5 |  | $ | (45.3 | ) | $ | 139.2 |  |
| Restructuring charges | (0.1 | ) | — |  | (0.1 | ) |  | 0.5 |  | (0.1 | ) | 0.4 |  |
| Loss on assets held for sale | — |  | — |  | — |  |  | 31.4 |  | — |  | 31.4 |  |
| Pension settlement | 60.6 |  | (15.1 | ) | 45.5 |  |  | — |  | — |  | — |  |
| Special product quality adjustments (b) | (0.5 | ) | 0.1 |  | (0.4 | ) |  | — |  | — |  | — |  |
| Special legal contingency charges (a) | (0.1 | ) | — |  | (0.1 | ) |  | 1.5 |  | (0.3 | ) | 1.2 |  |
| Asbestos-related litigation (a) | 0.4 |  | (0.1 | ) | 0.3 |  |  | (0.2 | ) | 0.2 |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | 0.1 |  | — |  | 0.1 |  |  | 0.1 |  | — |  | 0.1 |  |
| Environmental liabilities (a) | 1.3 |  | (0.3 | ) | 1.0 |  |  | 0.9 |  | (0.3 | ) | 0.6 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (1.0 | ) | (1.0 | ) |  | — |  | (0.6 | ) | (0.6 | ) |
| Other tax items, net (c) | — |  | 0.6 |  | 0.6 |  |  | — |  | (2.3 | ) | (2.3 | ) |
| (Gain) loss, net on sale of business and related property | 0.4 |  | (0.1 | ) | 0.3 |  |  | (22.1 | ) | 4.1 |  | (18.0 | ) |
| Divestiture costs (a) (g) | — |  | — |  | — |  |  | (2.5 | ) | 0.6 |  | (1.9 | ) |
| Partial advance of insurance recoveries related to lost profits (h) | (8.0 | ) | 2.3 |  | (5.7 | ) |  | — |  | — |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (5.9 | ) | 1.2 |  | (4.7 | ) |  | — |  | — |  | — |  |
| Other items, net (a) | 0.9 |  | (0.1 | ) | 0.8 |  |  | 0.6 |  | (0.6 | ) | — |  |
| Non-core business results (f) | — |  | — |  | — |  |  | 0.7 |  | (0.2 | ) | 0.5 |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 188.9 |  | $ | (41.3 | ) | $ | 147.6 |  |  | $ | 195.4 |  | $ | (44.8 | ) | $ | 150.6 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 2.81 |  |  |  |  |  |  | $ | 3.39 |  |
| Restructuring charges |  |  |  |  | — |  |  |  |  |  |  | 0.01 |  |
| Loss on assets held for sale |  |  | — |  |  |  |  | 0.77 |  |
| Pension settlement |  |  | 1.14 |  |  |  |  | — |  |
| Special product quality adjustments (b) |  |  |  |  | (0.01 | ) |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  | — |  |  |  |  |  |  | 0.03 |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.01 |  |  |  |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.01 |  |

[0001069202-19-000027:8k_2_02:74]
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.03 | ) |  |  |  |  |  | (0.01 | ) |
| Other tax items, net (c) |  |  |  |  | 0.02 |  |  |  |  |  |  | (0.05 | ) |
| (Gain) loss, net on sale of business and related property |  |  |  |  | 0.01 |  |  |  |  |  |  | (0.44 | ) |
| Divestiture costs (a) (g) |  |  |  |  | — |  |  |  |  |  |  | (0.05 | ) |
| Partial advance of insurance recoveries related to lost profits (h) |  |  | (0.14 | ) |  |  |  | — |  |
| Gain from insurance recoveries, net of losses incurred |  |  |  |  | (0.13 | ) |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  | 0.02 |  |  |  |  |  |  | — |  |
| Non-core business results (f) |  |  |  |  | — |  |  |  |  |  |  | 0.01 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  | 0.01 |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 3.74 |  |  |  |  | $ | 3.67 |  |
| (a) Recorded in Losses (Gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to the Company's business operations in Australia, Asia, and South America and the Kysor Warren business, not included elsewhere in the reconciliation. |
| (g) Divestiture costs incurred in Q1 2018 related to the sales of the Australia and Asia business and the related property were reclassified to (Gain) loss, net on sale of business and related property in Q2 2018. |
| (h) During the second quarter of 2019, the Company received a partial advance of $8 million related to lost profits incurred in the second quarter. The Company will include the full recovery of the second quarter lost profits in adjusted income in the period in which the second quarter lost profits are collected in full. |
|  | For the Six Months Ended June 30, |
|  | (Unaudited) |
|  | 2019 |  | 2018 |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |
| Income from continuing operations, a GAAP measure | $ | 222.8 |  | $ | (42.4 | ) | $ | 180.4 |  |  | $ | 228.5 |  | $ | (51.4 | ) | $ | 177.1 |  |
| Restructuring charges | 0.4 |  | (0.1 | ) | 0.3 |  |  | 1.3 |  | (0.3 | ) | 1.0 |  |
| Loss on assets held for sale | — |  | — |  | — |  |  | 31.4 |  | — |  | 31.4 |  |
| Pension settlement | 60.6 |  | (15.1 | ) | 45.5 |  |  | — |  | — |  | — |  |
| Special product quality adjustments (b) | (0.5 | ) | 0.1 |  | (0.4 | ) |  | — |  | — |  | — |  |
| Special legal contingency charges (a) | 0.2 |  | (0.1 | ) | 0.1 |  |  | 1.7 |  | (0.4 | ) | 1.3 |  |
| Asbestos-related litigation (a) | 1.8 |  | (0.4 | ) | 1.4 |  |  | 1.9 |  | (0.4 | ) | 1.5 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | (0.3 | ) | 0.1 |  | (0.2 | ) |  | 1.3 |  | (0.3 | ) | 1.0 |  |
| Inventory write down (b) | — |  | — |  | — |  |  | 0.2 |  | — |  | 0.2 |  |
| Environmental liabilities (a) | 1.3 |  | (0.3 | ) | 1.0 |  |  | 1.2 |  | (0.3 | ) | 0.9 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (5.3 | ) | (5.3 | ) |  | — |  | (4.9 | ) | (4.9 | ) |
| Other tax items, net (c) | — |  | 0.6 |  | 0.6 |  |  | — |  | (3.2 | ) | (3.2 | ) |
| (Gain) loss, net on sale of business and related property | 8.8 |  | (3.5 | ) | 5.3 |  |  | (11.8 | ) | 4.1 |  | (7.7 | ) |
| Partial advance of insurance recoveries related to lost profits (g) | (8.0 | ) | 2.3 |  | (5.7 | ) |  | — |  | — |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (12.8 | ) | 2.9 |  | (9.9 | ) |  | — |  | — |  | — |  |
| Other items, net (a) | 0.9 |  | (0.2 | ) | 0.7 |  |  | 0.8 |  | (0.6 | ) | 0.2 |  |
| Non-core business results (f) | 1.3 |  | (0.3 | ) | 1.0 |  |  | 4.0 |  | (0.9 | ) | 3.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 276.5 |  | $ | (61.7 | ) | $ | 214.8 |  |  | $ | 260.5 |  | $ | (58.6 | ) | $ | 201.9 |  |

[0001069202-19-000027:8k_2_02:75]
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 4.53 |  |  |  |  |  |  | $ | 4.26 |  |
| Restructuring charges |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.03 |  |
| Loss on assets held for sale |  |  | — |  |  |  |  | 0.76 |  |
| Pension settlement |  |  | 1.14 |  |  |  |  | — |  |
| Special product quality adjustments (b) |  |  |  |  | (0.01 | ) |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  | — |  |  |  |  |  |  | 0.03 |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.04 |  |  |  |  |  |  | 0.04 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  | (0.01 | ) |  |  |  |  |  | 0.02 |  |
| Inventory write down (b) |  |  |  |  | — |  |  |  |  |  |  | 0.01 |  |
| Environmental liabilities (a) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.02 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.13 | ) |  |  |  |  |  | (0.12 | ) |
| Other tax items, net (c) |  |  |  |  | 0.02 |  |  |  |  |  |  | (0.07 | ) |
| (Gain) loss, net on sale of business and related property |  |  |  |  | 0.13 |  |  |  |  |  |  | (0.19 | ) |
| Partial advance of insurance recoveries related to lost profits (g) |  |  | (0.14 | ) |  |  |  | — |  |
| Gain from insurance recoveries, net of losses incurred |  |  |  |  | (0.26 | ) |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  | 0.02 |  |  |  |  |  |  | — |  |
| Non-core business results (f) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.07 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  | $ | 5.41 |  |  |  |  |  |  | $ | 4.87 |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to the Company's business operations in Australia, Asia, and South America and the Kysor Warren business, not included elsewhere in the reconciliation. |
| (g) During the second quarter of 2019, the Company received a partial advance of $8 million related to lost profits incurred in the second quarter. The Company will include the full recovery of the second quarter lost profits in adjusted income in the period in which the second quarter lost profits are collected in full. |

[0001069202-19-000027:8k_2_02:76]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts (a) | $ | 0.1 |  |  | $ | (0.2 | ) |  | $ | 0.2 |  |  | $ | (0.7 | ) |
| Foreign currency exchange (gains) losses (a) | (0.2 | ) |  | (0.1 | ) |  | (0.7 | ) |  | 1.2 |  |
| (Gain) loss on disposal of fixed assets (a) | (0.4 | ) |  | 0.1 |  |  | (0.2 | ) |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) | 0.1 |  |  | 0.1 |  |  | (0.3 | ) |  | 1.3 |  |
| Special legal contingency charges (b) | (0.1 | ) |  | 1.5 |  |  | 0.2 |  |  | 1.7 |  |
| Asbestos-related litigation (b) | 0.4 |  |  | (0.2 | ) |  | 1.8 |  |  | 1.9 |  |
| Environmental liabilities (b) | 1.3 |  |  | 0.9 |  |  | 1.3 |  |  | 1.2 |  |
| Divestiture costs (b) (c) | — |  |  | (2.5 | ) |  | — |  |  | — |  |
| Other items, net (b) | 0.9 |  |  | 0.6 |  |  | 0.9 |  |  | 0.8 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.1 |  |  | $ | 0.2 |  |  | $ | 3.2 |  |  | $ | 7.5 |  |

[0001069202-19-000027:8k_2_02:77]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |
| (c) Divestiture costs incurred in Q1 2018 related to the sales of the Australia and Asia business and the related property were reclassified to (Gain) loss, net on sale of business and related property in Q2 2018. |

[0001069202-19-000027:8k_2_02:78]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |
|  |  |  |  |  | For the Year Ended December 31, 2019ESTIMATED |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $11.91-$12.51 |  |
| Insurance recovery, net of other non-core EBIT charges, from tornado impact to damaged property and second quarter non-cash pension settlement charge |  | 0.61 |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $11.30-$11.90 |  |
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Average shares outstanding - diluted, a GAAP measure | 39.5 |  |  | 41.1 |  |  | 39.8 |  |  | $ | 41.6 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |  | (0.2 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 39.4 |  |  | 41.0 |  |  | 39.7 |  |  | 41.4 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales, a GAAP measure | $ | 148.7 |  |  | $ | 207.3 |  |  | $ | 1,099.1 |  |  | $ | 1,175.4 |  |
| Net sales from non-core businesses (a) | — |  |  | 61.8 |  |  | — |  |  | 61.8 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 148.7 |  |  | $ | 145.5 |  |  | $ | 1,099.1 |  |  | $ | 1,113.6 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Six Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales, a GAAP measure | $ | 300.1 |  |  | $ | 409.3 |  |  | $ | 1,889.4 |  |  | $ | 2,010.2 |  |
| Net sales from non-core businesses (a) | 34.3 |  |  | 144.6 |  |  | 34.3 |  |  | 144.6 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 265.8 |  |  | $ | 264.7 |  |  | $ | 1,855.1 |  |  | $ | 1,865.6 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit, a GAAP measure | $ | 45.7 |  |  | $ | 61.7 |  |  | $ | 332.1 |  |  | $ | 361.6 |  |
| Non-GAAP adjustments to gross profit | — |  |  | — |  |  | 0.5 |  |  | — |  |
| Gross profit from non-core businesses (a) | — |  |  | 10.3 |  |  | — |  |  | 10.3 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 45.7 |  |  | $ | 51.4 |  |  | $ | 331.6 |  |  | $ | 351.3 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |

[0001069202-19-000027:8k_2_02:79]
|  | Refrigeration Segment |  | Consolidated |
|  | For the Six Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit, a GAAP measure | $ | 88.3 |  |  | $ | 116.4 |  |  | $ | 533.6 |  |  | $ | 584.7 |  |
| Non-GAAP adjustments to gross profit | — |  |  | (0.2 | ) |  | 0.5 |  |  | (0.2 | ) |
| Gross profit from non-core businesses (a) | 3.6 |  |  | 24.9 |  |  | 3.6 |  |  | 24.9 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 84.7 |  |  | $ | 91.7 |  |  | $ | 529.5 |  |  | $ | 560.0 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit, a GAAP measure | $ | 19.1 |  |  | $ | 23.4 |  |  | $ | 202.3 |  |  | $ | 205.3 |  |
| Gross (loss) profit from non-core businesses (a) | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Adjusted Segment profit, a Non-GAAP measure | $ | 19.1 |  |  | $ | 23.6 |  |  | $ | 202.3 |  |  | $ | 205.5 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Six Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit, a GAAP measure | $ | 27.5 |  |  | $ | 32.1 |  |  | $ | 300.3 |  |  | $ | 276.1 |  |
| Gross profit from non-core businesses (a) | (1.0 | ) |  | (3.1 | ) |  | (1.0 | ) |  | (3.1 | ) |
| Adjusted Segment profit, a Non-GAAP measure | $ | 28.5 |  |  | $ | 35.2 |  |  | $ | 301.3 |  |  | $ | 279.2 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Selling, general and administrative expenses, a GAAP measure | $ | 29.5 |  |  | $ | 42.8 |  |  | $ | 152.4 |  |  | $ | 161.4 |  |
| Selling, general and administrative expenses from non-core businesses (a) | — |  |  | 10.9 |  |  | — |  |  | 10.9 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 29.5 |  |  | $ | 31.9 |  |  | $ | 152.4 |  |  | $ | 150.5 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Six Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Selling, general and administrative expenses, a GAAP measure | $ | 65.9 |  |  | $ | 92.0 |  |  | $ | 298.2 |  |  | $ | 316.6 |  |
| Selling, general and administrative expenses from non-core businesses (a) | 4.6 |  |  | 28.4 |  |  | 4.6 |  |  | 28.4 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 61.3 |  |  | $ | 63.6 |  |  | $ | 293.6 |  |  | $ | 288.2 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |

[0001069202-19-000027:8k_2_02:80]
| Reconciliation of Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net cash used in operating activities, a GAAP measure | $ | 30.0 |  |  | $ | 48.5 |  |  | $ | (111.0 | ) |  | $ | (35.0 | ) |
| Purchases of property, plant and equipment | (16.3 | ) |  | (20.7 | ) |  | (53.5 | ) |  | (43.4 | ) |
| Proceeds from the disposal of property, plant and equipment | 0.5 |  |  | — |  |  | 0.8 |  |  | 0.1 |  |
| Insurance recoveries received for property damage incurred from natural disaster | 5.9 |  |  | — |  |  | 12.8 |  |  | — |  |
| Free cash flow, a Non-GAAP measure | 20.1 |  |  | 27.8 |  |  | (150.9 | ) |  | (78.3 | ) |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to June 30, 2019 |
| Adjusted EBIT (b)(a) |  |  |  |  |  |  | $ | 565.4 |  |
| Depreciation and amortization expense (c) |  |  |  |  |  |  | 69.8 |  |
| EBITDA (b + c) |  |  |  |  |  |  | $ | 635.2 |  |
| Total debt at June 30, 2019 (d) |  |  |  |  |  |  | $ | 1,466.8 |  |
| Total Debt to EBITDA ratio ((d / (b + c)) |  |  |  |  |  |  | 2.3 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |  |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |
|  |  |  |  |  |  |  | Trailing Twelve Months to June 30, 2019 |
| Income from continuing operations before income taxes, a GAAP measure | $ | 462.2 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit | 7.8 |  |
| Special product quality adjustments | (0.5 | ) |
| Restructuring charges | 2.0 |  |
| Interest expense, net | 44.1 |  |
| Pension settlement | 61.0 |  |
| Loss (gain), net on sale of businesses and related property | 17.0 |  |
| Gain from insurance recoveries, net of losses incurred | (23.8 | ) |
| Partial advance of insurance recoveries related to lost profits | (8.0 | ) |
| Non-core business results (a) | 0.5 |  |
| Other expense (income), net | 3.1 |  |
| Adjusted EBIT per above, a Non-GAAP measure | $ | 565.4 |  |
| (a) Non-core businesses results represent activity related to the Company's business operations in Australia, Asia, and South America and the Kysor Warren business, not included elsewhere in the reconciliation. |
