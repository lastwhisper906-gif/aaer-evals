# LII MD&A — 0001069202-19-000030


## mdna

[0001069202-19-000030:mdna:1]
[same as prior period, unchanged from 0001069202-19-000021:mdna:1]

[0001069202-19-000030:mdna:2]
[same as prior period, unchanged from 0001069202-19-000021:mdna:2]

[0001069202-19-000030:mdna:3]
[same as prior period, unchanged from 0001069202-19-000021:mdna:3]

[0001069202-19-000030:mdna:4]
[same as prior period, unchanged from 0001069202-19-000021:mdna:4]

[0001069202-19-000030:mdna:5]
[same as prior period, unchanged from 0001069202-19-000021:mdna:5]

[0001069202-19-000030:mdna:6]
[same as prior period, unchanged from 0001069202-19-000021:mdna:6]

[0001069202-19-000030:mdna:7]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.

[0001069202-19-000030:mdna:8]
In the second quarter of 2019, we incurred expenses of $20 million related to damages caused by the tornado, which included site clean-up and demolition, factory inefficiencies, freight to move product to other warehouses and sales and marketing promotional costs.  We received insurance recoveries of $52 million in the second quarter of 2019 and allocated the first $26 million of these proceeds to cover our expenses and rebuilding costs incurred during the three months ended June 30, 2019, which is included in Gain from insurance recoveries, net of losses incurred in the Consolidated Statements of Operations.  The remaining $26 million of insurance recoveries represents amounts for lost profits and is shown in Insurance proceeds for lost profits in the Consolidated Statements of Operations.

[0001069202-19-000030:mdna:9]
For the year ended December 31, 2019, we expect to receive insurance proceeds of $94 million related to lost profits and $154 million to fund the reconstruction of the facility and as reimbursement for other losses and expenses expected to be incurred. We expect to receive a cumulative total of $121 million in insurance proceeds related to lost profits and a cumulative total of $251 million to fund the reconstruction of the facility and as reimbursement for other losses and expenses expected to be incurred.

[0001069202-19-000030:mdna:10]
[same as prior period, unchanged from 0001069202-19-000021:mdna:9]

[0001069202-19-000030:mdna:11]
Results for the second quarter of 2019, most notably in our Residential Heating & Cooling segment, were impacted by unfavorable weather conditions in North America when compared to the second quarter of 2018.  The Residential Heating & Cooling segment saw a 4% decrease in net sales primarily on unfavorable weather and their segment profit was flat, including the impact of insurance proceeds received for lost profits.  The Commercial Heating & Cooling segment had a 4% increase in net sales and a $3 million increase in segment profit which were driven by lower volumes and higher price and mix.  Sales in our Refrigeration segment decreased by 28%  primarily due to the sale of our Australia, New Zealand, Asia, Brazil and Kysor Warren businesses in prior quarters, and segment profit declined $4 million.

[0001069202-19-000030:mdna:12]
[same as prior period, unchanged from 0001069202-19-000021:mdna:11]

[0001069202-19-000030:mdna:13]
| • | Net sales decreased $76 million, or 6%, to $1,099 million in the second quarter of 2019 primarily due to the sale of our Australia, New Zealand, Asia, Brazil and Kysor Warren businesses in prior quarters. |

[0001069202-19-000030:mdna:14]
| • | Operating income in the second quarter of 2019 increased $19 million to $214 million due primarily to $26 million of insurance proceeds for lost profits. |

[0001069202-19-000030:mdna:15]
| • | Net income for the second quarter of 2019 decreased $27 million to $111 million. |

[0001069202-19-000030:mdna:16]
| • | Diluted earnings per share from continuing operations were $2.81 per share in the second quarter of 2019 compared to $3.39 per share in the second quarter of 2018. |

[0001069202-19-000030:mdna:17]
| • | For the six months ended June 30, 2019, we returned $51 million to shareholders through dividend payments and have repurchased $250 million of common stock. |

[0001069202-19-000030:mdna:18]
Second Quarter of 2019 Compared to Second Quarter of 2018 - Consolidated Results

[0001069202-19-000030:mdna:19]
[same as prior period, unchanged from 0001069202-19-000021:mdna:18]

[0001069202-19-000030:mdna:20]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 1,099.1 |  |  | $ | 1,175.4 |  |  | (6.5 | )% |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 767.0 |  |  | 813.8 |  |  | 5.8 |  |  | 69.8 |  |  | 69.2 |  |
| Gross profit | 332.1 |  |  | 361.6 |  |  | (8.2 | ) |  | 30.2 |  |  | 30.8 |  |
| Selling, general and administrative expenses | 152.4 |  |  | 161.4 |  |  | 5.6 |  |  | 13.9 |  |  | 13.7 |  |
| Losses (gains) and other expenses, net | 2.1 |  |  | 0.2 |  |  | (950.0 | ) |  | 0.2 |  |  | — |  |
| Restructuring charges | (0.1 | ) |  | 0.5 |  |  | 120.0 |  |  | — |  |  | — |  |
| Loss (gain), net on sale of businesses and related property | 0.4 |  |  | (22.1 | ) |  | N/A |  | — |  |  | (1.9 | ) |
| Loss on assets held for sale | — |  |  | 31.4 |  |  | N/A |  | — |  |  | 2.7 |  |
| Insurance proceeds for lost profits | (26.0 | ) |  | — |  |  | N/A |  | (2.4 | ) |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (5.9 | ) |  | — |  |  | N/A |  | (0.5 | ) |  | — |  |
| Income from equity method investments | (4.6 | ) |  | (4.9 | ) |  | (6.1 | ) |  | (0.4 | ) |  | (0.4 | ) |
| Operating income | $ | 213.8 |  |  | $ | 195.1 |  |  | 9.6 | % |  | 19.5 | % |  | 16.6 | % |

[0001069202-19-000030:mdna:21]
[same as prior period, unchanged from 0001069202-19-000021:mdna:21]

[0001069202-19-000030:mdna:22]
Net sales decreased 6% in the second quarter of 2019 compared to the second quarter of 2018.  The loss of sales related to our Australia, New Zealand, Asia, Brazil and Kysor Warren businesses contributed 5%, lower sales volume contributed 4% and unfavorable foreign currency exchange rates contributed 1%.  These were partially offset by favorable combined price and mix of 4% across all of our segments.

[0001069202-19-000030:mdna:23]
[same as prior period, unchanged from 0001069202-19-000021:mdna:23]

[0001069202-19-000030:mdna:24]
Gross profit margin in the second quarter of 2019 decreased to 30.2% compared to 30.8% in the second quarter of 2018.  We saw decreases in profit margin of 60 basis points ("bps") from higher commodity prices, 100 bps from higher freight and distribution costs, 30 bps from tariffs on Chinese imports and 90 bps from other product costs.  Partially offsetting these decreases were positive margin increases of 100 bps from favorable price and mix, 30 bps from favorable product warranty costs, 20 bps from sourcing and engineering-led cost reductions and 70 bps from the divested Australia, New Zealand, Asia, Brazil and Kysor Warren businesses which had lower margins.

[0001069202-19-000030:mdna:25]
[same as prior period, unchanged from 0001069202-19-000021:mdna:25]

[0001069202-19-000030:mdna:26]
Selling, general and administrative expenses, or SG&A, was $152 million in the second quarter of 2019 compared to $161 million in the second quarter of 2018 primarily due to the sale of our Australia, New Zealand, Asia, Brazil and Kysor Warren businesses.  As a percentage of net sales, SG&A increased 20 bps to 13.9% primarily due to a sales decline that was larger than the decline in SG&A from our divested business.

[0001069202-19-000030:mdna:27]
Losses (Gains) and Other Expenses, Net

[0001069202-19-000030:mdna:28]
Losses (gains) and other expenses, net for the second quarter of 2019 and 2018 included the following (in millions):

[0001069202-19-000030:mdna:29]
|  | For the Three Months Ended June 30, |
|  | 2019 |  | 2018 |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | (0.2 | ) |
| Foreign currency exchange gains | (0.2 | ) |  | (0.1 | ) |
| (Gain) loss on disposal of fixed assets | (0.4 | ) |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | 0.1 |  |
| Special legal contingency charges | (0.1 | ) |  | 1.5 |  |
| Asbestos-related litigation | 0.4 |  |  | (0.2 | ) |
| Environmental liabilities | 1.3 |  |  | 0.9 |  |
| Divestiture costs | — |  |  | (2.5 | ) |
| Other items, net | 0.9 |  |  | 0.6 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.1 |  |  | $ | 0.2 |  |

[0001069202-19-000030:mdna:30]
The net change in unrealized losses (gains) on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 14 in the Notes to the Consolidated Financial Statements for more information on the divestiture costs.

[0001069202-19-000030:mdna:31]
[same as prior period, unchanged from 0001069202-19-000021:mdna:31]

[0001069202-19-000030:mdna:32]
Restructuring charges were insigificant in the second quarter of 2019.  For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000030:mdna:33]
[same as prior period, unchanged from 0001069202-19-000021:mdna:33]

[0001069202-19-000030:mdna:34]
We recognized a loss of $0.4 million in the second quarter of 2019 on the sale of our Kysor Warren business in the first quarter of 2019.  Refer to Note 14 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-19-000030:mdna:35]
[same as prior period, unchanged from 0001069202-19-000021:mdna:35]

[0001069202-19-000030:mdna:36]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $5 million in the second quarter of 2019 was comparable to the second quarter of 2018.

[0001069202-19-000030:mdna:37]
Pension Settlement

[0001069202-19-000030:mdna:38]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and $105.6 million of related pension benefit obligations.  In the second quarter of 2019, we recognized a $60.6 million pension settlement charge in the Statement of Operations and reclassified $5.6 million of pension benefit obligations to AOCL as a result of this transaction.  For additional information, refer to Note 9 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000030:mdna:39]
[same as prior period, unchanged from 0001069202-19-000021:mdna:37]

[0001069202-19-000030:mdna:40]
Interest expense, net of $13 million in the second quarter of 2019 was up from $10 million in the second quarter of 2018 due to an increase in our average net borrowings.

[0001069202-19-000030:mdna:41]
[same as prior period, unchanged from 0001069202-19-000021:mdna:39]

[0001069202-19-000030:mdna:42]
Our effective tax rate was 20.6% for the three months ended June 30, 2019 compared to 24.6% for the three months ended June 30, 2018.  The rate for the three months ended June 30, 2019 is lower than the rate for the three months ended June 30, 2018 primarily due to a change in the mix of earnings between the U.S. and foreign jurisdictions. We expect our annual effective tax rate to be between 22% and 23%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001069202-19-000030:mdna:43]
Second Quarter of 2019 Compared to Second Quarter of 2018 - Results by Segment

[0001069202-19-000030:mdna:44]
[same as prior period, unchanged from 0001069202-19-000021:mdna:42]

[0001069202-19-000030:mdna:45]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the second quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000030:mdna:46]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 689.1 |  |  | $ | 716.0 |  |  | $ | (26.9 | ) |  | (3.8 | )% |
| Profit | $ | 153.4 |  |  | $ | 153.6 |  |  | $ | (0.2 | ) |  | (0.1 | )% |
| % of net sales | 22.3 | % |  | 21.5 | % |  |  |  |  |

[0001069202-19-000030:mdna:47]
Net sales decreased 4% in the second quarter of 2019 compared to the second quarter.  Sales volume was lower by 6% and foreign currency exchange rates were unfavorable by 1% and were partially offset by 3% higher combined price and mix.

[0001069202-19-000030:mdna:48]
Segment profit in the second quarter of 2019 was flat compared to the second quarter of 2018 due to $17 million of lower sales volume primarily from unfavorable weather, $9 million of higher freight and distribution expense, $4 million of higher commodity costs, $2 million of lower factory productivity, $2 million of tariffs on Chinese imports, $2 million of higher SG&A expense, $1 million of higher other product costs, $1 million of lower equity method income, and $1 million of unfavorable foreign currency.

[0001069202-19-000030:mdna:49]
Offsetting these were $18 million of higher combined price and mix, $18 million of insurance proceeds for lost profits due to the Marshalltown tornado and $3 million of sourcing and engineering-led cost reductions.

[0001069202-19-000030:mdna:50]
[same as prior period, unchanged from 0001069202-19-000021:mdna:47]

[0001069202-19-000030:mdna:51]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000030:mdna:52]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 261.3 |  |  | $ | 252.1 |  |  | $ | 9.2 |  |  | 3.6 | % |
| Profit | $ | 53.9 |  |  | $ | 50.8 |  |  | $ | 3.1 |  |  | 6.1 | % |
| % of net sales | 20.6 | % |  | 20.2 | % |  |  |  |  |

[0001069202-19-000030:mdna:53]
Net sales increased 4% in the second quarter of 2019 compared to the second quarter of 2018.  Price and mix combined increased sales by 6% and was partially offset by 2% lower sales volume.

[0001069202-19-000030:mdna:54]
Segment profit in the second quarter of 2019 increased $3 million compared to the second quarter of 2018 due to $12 million of higher combined price and mix, and $2 million of sourcing and engineering-led cost reductions. Partially offsetting these increases was $2 million of lower sales volume, $2 million of higher commodity costs, $2 million of higher other product costs, $2 million of higher freight and distribution costs, $1 million of lower factory productivity, $1 million of higher tariffs on Chinese imports, and $1 million of higher SG&A expense.

[0001069202-19-000030:mdna:55]
[same as prior period, unchanged from 0001069202-19-000021:mdna:52]

[0001069202-19-000030:mdna:56]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2019 and 2018 (dollars in millions):

[0001069202-19-000030:mdna:57]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 148.7 |  |  | $ | 207.3 |  |  | $ | (58.6 | ) |  | (28.3 | )% |
| Profit | $ | 19.1 |  |  | $ | 23.4 |  |  | $ | (4.3 | ) |  | (18.4 | )% |
| % of net sales | 12.8 | % |  | 11.3 | % |  |  |  |  |

[0001069202-19-000030:mdna:58]
Net sales decreased 28% in the second quarter of 2019 compared to the second quarter of 2018.  The loss of sales from the divested Australia, New Zealand, Asia, Brazil and Kysor Warren businesses contributed 30% and unfavorable foreign currency exchange rates contributed 2%, partially offset by 1% higher sales volume and 3% higher price and mix combined.

[0001069202-19-000030:mdna:59]
Segment profit in the second quarter of 2019 decreased $4 million compared to the second quarter of 2018. The decrease was driven by $2 million related to the timing of selling refrigerant allocations in Europe, $1 million of higher commodity costs, $1 million of tariffs on Chinese imports, $1 million of higher other product costs, $1 million of lower factory productivity, $1 million of higher freight and distribution costs, $1 million of lower equity method income, and $1 million of unfavorable foreign currency exchange rates. Partially offsetting these decreases was $1 million of higher sales volume, $1 million of combined price and mix, $1 million of engineering-led cost reductions, $1 million of lower SG&A expense, and $1 million of favorable foreign currency hedges.

[0001069202-19-000030:mdna:60]
[same as prior period, unchanged from 0001069202-19-000021:mdna:57]

[0001069202-19-000030:mdna:61]
Corporate and other expenses increased $2 million in the second quarter of 2019 compared to the second quarter of 2018 primarily due to the timing of information technology investments and non-recurring discretionary expenses.

[0001069202-19-000030:mdna:62]
Year-to-Date through June 30, 2019 Compared to Year-to-Date through June 30, 2018 - Consolidated Results

[0001069202-19-000030:mdna:63]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-19-000030:mdna:64]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 1,889.4 |  |  | $ | 2,010.2 |  |  | (6.0 | ) |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,355.8 |  |  | 1,425.5 |  |  | 4.9 |  |  | 71.8 |  |  | 70.9 |  |
| Gross profit | 533.6 |  |  | 584.7 |  |  | (8.7 | ) |  | 28.2 |  |  | 29.1 |  |
| Selling, general and administrative expenses | 298.2 |  |  | 316.6 |  |  | 5.8 |  |  | 15.8 |  |  | 15.7 |  |
| Losses (gains) and other expenses, net | 3.2 |  |  | 7.5 |  |  | 57.3 |  |  | 0.2 |  |  | 0.4 |  |
| Restructuring charges | 0.4 |  |  | 1.3 |  |  | 69.2 |  |  | — |  |  | 0.1 |  |
| Loss (gain), net sale of businesses and related property | 8.8 |  |  | (11.8 | ) |  | N/A |  |  | 0.5 |  |  | (0.6 | ) |
| Loss on assets held for sale | — |  |  | 31.4 |  |  | N/A |  |  | — |  |  | 1.6 |  |
| Insurance proceeds for lost profits | (65.5 | ) |  | — |  |  | N/A |  |  | (3.5 | ) |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (12.8 | ) |  | — |  |  | N/A |  |  | (0.7 | ) |  | — |  |
| Income from equity method investments | (7.2 | ) |  | (8.4 | ) |  | (14.3 | ) |  | (0.4 | ) |  | (0.4 | ) |
| Operating income | $ | 308.5 |  |  | $ | 248.1 |  |  | 24.3 |  |  | 16.3 | % |  | 12.3 | % |

[0001069202-19-000030:mdna:65]
Net Sales

[0001069202-19-000030:mdna:66]
Net sales decreased 6% in the first six months of 2019 compared to the first six months of 2018 due to a 5% decline related to the sale of our Australia, New Zealand, Asia and Brazil and Kysor Warren businesses, a 3% decline in sales volume and 1% from unfavorable foreign currency exchange rates.  These were partially offset by 3% from favorable price and mix combined.

[0001069202-19-000030:mdna:67]
Gross Profit

[0001069202-19-000030:mdna:68]
Gross profit margins in the first six months of 2019 decreased 90 bps to 28.2% compared to the first six months of 2018.  Our profit margin decreased 80 bps from higher commodity costs, 110 bps from higher freight and distribution costs, 30 bps from tariffs on Chinese imports and 90 bps from other product costs.  These were partially offset by 130 bps from favorable price and mix combined, 60 bps from sourcing and engineering-led cost reductions and 30 bps from the divested Australia, New Zealand, Asia, Brazil and Kysor Warren businesses which had lower margins.

[0001069202-19-000030:mdna:69]
Selling, General and Administrative Expenses

[0001069202-19-000030:mdna:70]
SG&A was $298 million for the first six months of 2019 compared to $317 million for the first six months of 2018, and  declined primarily due to the sale of our Australia, New Zealand, Asia, Brazil and Kysor Warren businesses.  As a percentage of net sales, SG&A increased 10 bps to 15.8% from 15.7%.

[0001069202-19-000030:mdna:71]
Losses and Other Expenses, Net

[0001069202-19-000030:mdna:72]
Losses and other expenses, net for the first six months of 2019 and 2018 included the following (in millions):

[0001069202-19-000030:mdna:73]
|  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |
| Realized losses (gains) on settled future contracts | $ | 0.2 |  |  | $ | (0.7 | ) |
| Foreign currency exchange (gains) losses | (0.7 | ) |  | 1.2 |  |
| Gain (loss) on disposal of fixed assets | (0.2 | ) |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (0.3 | ) |  | 1.3 |  |
| Special legal contingency charges | 0.2 |  |  | 1.7 |  |
| Asbestos-related litigation | 1.8 |  |  | 1.9 |  |
| Environmental liabilities | 1.3 |  |  | 1.2 |  |
| Other items, net | 0.9 |  |  | 0.8 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.2 |  |  | $ | 7.5 |  |

[0001069202-19-000030:mdna:74]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.

[0001069202-19-000030:mdna:75]
Restructuring Charges

[0001069202-19-000030:mdna:76]
Restructuring charges were less than $1 million in the first six months of 2019 and related primarily to projects to realign resources in our Refrigeration segment. For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000030:mdna:77]
Income from Equity Method Investments

[0001069202-19-000030:mdna:78]
Income from equity method investments of $7 million in the first six months of 2019 was down from $8 million when compared to the first six months of 2018.  The decrease is because the joint ventures have experienced increased costs related to commodities and components and have not passed along these increased costs to customers through price increases.

[0001069202-19-000030:mdna:79]
Pension Settlement

[0001069202-19-000030:mdna:80]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and $105.6 million of related pension benefit obligations.  For the six months ended June 30, 2019, we recognized a $60.6 million pension settlement charge in the Statement of Operations and reclassified $5.6 million of pension benefit obligations to AOCL as a result of this transaction.  For additional information, refer to Note 9 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000030:mdna:81]
Interest Expense, net

[0001069202-19-000030:mdna:82]
Interest expense, net of $24 million in the first six months of 2019 increased from $18 million in the first six months of 2018 due to an increase in our average net borrowings and higher interest rates.

[0001069202-19-000030:mdna:83]
Income Taxes

[0001069202-19-000030:mdna:84]
Our effective tax rate was 19.0% for the six months ended June 30, 2019 compared to 22.5% for the six months ended June 30, 2018.  The rate for the six months ended June 30, 2019 is lower compared to the six months ended June 30, 2018 primarily due to the mix of earnings between U.S. and foreign jurisdictions.

[0001069202-19-000030:mdna:85]
Year-to-Date through June 30, 2019 Compared to Year-to-Date through June 30, 2018 - Results by Segment

[0001069202-19-000030:mdna:86]
Residential Heating & Cooling

[0001069202-19-000030:mdna:87]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first six months of 2019 and 2018 (dollars in millions):

[0001069202-19-000030:mdna:88]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 1,154.6 |  |  | $ | 1,169.7 |  |  | $ | (15.1 | ) |  | (1.3 | )% |
| Profit | $ | 240.1 |  |  | $ | 204.9 |  |  | $ | 35.2 |  |  | 17.2 | % |
| % of net sales | 20.8 | % |  | 17.5 | % |  |  |  |  |

[0001069202-19-000030:mdna:89]
Net sales decreased 1% in the first six months of 2019 compared to the first six months of 2018.  Sales volume decreased 4% partially offset by 3% combined higher price and mix.

[0001069202-19-000030:mdna:90]
Segment profit for the first six months of 2019 increased $35 million compared to the first six months of 2018 due to $58 million of insurance proceeds for lost profits related to the Marshalltown tornado, $30 million favorable price and mix, $9 million of sourcing and engineering-led cost reductions, and $1 million of higher equity method income.  Partially offsetting these increases

[0001069202-19-000030:mdna:91]
is $18 million of higher freight and distribution expenses, $17 million of lower sales volume primarily from unfavorable weather in the second quarter of 2019, $11 million of higher commodity costs, $5 million of higher SG&A expense, $4 million of tariffs on imported Chinese components, $4 million of lower factory productivity, $3 million of higher other product costs, and $1 million of unfavorable foreign currency exchange rates.

[0001069202-19-000030:mdna:92]
Commercial Heating & Cooling

[0001069202-19-000030:mdna:93]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first six months of 2019 and 2018 (dollars in millions):

[0001069202-19-000030:mdna:94]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 434.7 |  |  | $ | 431.2 |  |  | $ | 3.5 |  |  | 0.8 | % |
| Profit | $ | 68.9 |  |  | $ | 72.8 |  |  | $ | (3.9 | ) |  | (5.4 | )% |
| % of net sales | 15.9 | % |  | 16.9 | % |  |  |  |  |

[0001069202-19-000030:mdna:95]
Net sales increased 1% in the first six months of 2019 compared to the first six months of 2018.  Favorable price and mix combined was 5% higher partially offset by 4% lower sales volume.

[0001069202-19-000030:mdna:96]
Segment profit for the first six months of 2019 decreased $4 million compared to the first six months of 2018 due to $6 million of lower sales volume, $6 million of higher other product costs, $4 million of higher commodity costs, $3 million of lower factory productivity, $3 million of higher freight and distribution expense, $2 million of tariffs on imported Chinese components, and $2 million of higher SG&A expense.  Partially offsetting these declines was $19 million of favorable combined price and mix and $3 million of sourcing and engineering-led cost reductions.

[0001069202-19-000030:mdna:97]
Refrigeration

[0001069202-19-000030:mdna:98]
The following table presents our Refrigeration segment's net sales and profit for the first six months of 2019 and 2018 (dollars in millions):

[0001069202-19-000030:mdna:99]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 300.1 |  |  | $ | 409.3 |  |  | $ | (109.2 | ) |  | (26.7 | )% |
| Profit | $ | 27.5 |  |  | $ | 32.1 |  |  | $ | (4.6 | ) |  | (14.3 | )% |
| % of net sales | 9.2 | % |  | 7.8 | % |  |  |  |  |

[0001069202-19-000030:mdna:100]
Refrigeration net sales decreased 27% in the first six months of 2019 compared to the first six months of 2018.   The loss of sales from our divested Australia, New Zealand, Asia and Brazil and Kysor Warren businesses contributed 26% and unfavorable foreign currency exchange rates contributed 2%, partially offset by 1% favorable price and mix combined.

[0001069202-19-000030:mdna:101]
Segment profit for the first six months of 2019 decreased $5 million compared to the first six months of 2018 due to $3 million of higher commodity costs, $2 million of higher freight and distribution expense, $2 million lower profit due to the divested Australia, Asia, Brazil and Kysor Warren businesses, $1 million of tariffs on imported Chinese components, $1 million of higher other product costs, $1 million of lower equity method income, and $1 million of unfavorable foreign currency exchange rates.  Partially offsetting these decreases was $3 million of favorable combined price and mix, $2 million of sourcing and engineering-led cost reductions, and $1 million of favorable foreign currency hedges.

[0001069202-19-000030:mdna:102]
Corporate and Other

[0001069202-19-000030:mdna:103]
Corporate and other expenses increased $2 million to $36 million in the first six months of 2019 from $34 million in the first six months of 2018 due primarily to the timing of information technology investments and non-recurring discretionary expenses.

[0001069202-19-000030:mdna:104]
[same as prior period, unchanged from 0001069202-19-000021:mdna:59]

[0001069202-19-000030:mdna:105]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of

[0001069202-19-000030:mdna:106]
credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-19-000030:mdna:107]
[same as prior period, unchanged from 0001069202-19-000021:mdna:61]

[0001069202-19-000030:mdna:108]
The following table summarizes our cash flow activity for the six months ended June 30, 2019 and 2018 (in millions):

[0001069202-19-000030:mdna:109]
|  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |
| Net cash used in operating activities | $ | (111.0 | ) |  | $ | (35.0 | ) |
| Net cash provided by investing activities | 1.9 |  |  | 68.5 |  |
| Net cash provided by (used in) financing activities | 97.0 |  |  | (61.9 | ) |

[0001069202-19-000030:mdna:110]
Net Cash Provided by Operating Activities - The net cash used in operating activities in the first six months of 2019 and 2018 reflects the seasonal increase in working capital requirements. The increase in cash used in operating activities in the first six months of 2019 as compared to 2018 was primarily due to the timing of working capital payments.

[0001069202-19-000030:mdna:111]
Net Cash Provided by (Used in) Investing Activities - Capital expenditures were $54 million in the first six months of 2019 compared to $43 million in the first six months of 2018.  Capital expenditures in 2019 were primarily related to the reconstruction of the Marshalltown facility as well as equipment and investments in systems and software to support the overall enterprise.  Net proceeds of $44 million in the first quarter of 2019 were provided by the sale of our Kysor Warren business. We also received $13 million in insurance proceeds to fund the reconstruction of our Marshalltown facility.

[0001069202-19-000030:mdna:112]
Net Cash Provided by (Used in) Financing Activities - Net cash provided by financing activities in the first six months of 2019 was $97 million compared to net cash used of $62 million in the first six months of 2018.  The increase in cash provided by financing activities is largely due to a reduction in the amount of share repurchases in 2019 compared to 2018 and higher net borrowings on our revolving credit facility.  During the first six months of 2019, we repurchased $250 million of shares as compared to $350 million of shares in the first six months of 2018.  We also returned $51 million to shareholders through dividend payments in the first six months of 2019. For additional information on share repurchases, refer to Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000030:mdna:113]
[same as prior period, unchanged from 0001069202-19-000021:mdna:67]

[0001069202-19-000030:mdna:114]
The following table details our lines of credit and financing arrangements as of June 30, 2019 (in millions):

[0001069202-19-000030:mdna:115]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset Securitization Program | $ | 290.0 |  |
| Capital lease obligations | $ | 6.6 |  |
| Domestic credit facility(1) | 15.0 |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 311.0 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | — |  |
| Capital lease obligations | 23.4 |  |
| Domestic credit facility(1) | 785.0 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (2.6 | ) |
| Total long-term debt | 1,155.8 |  |
| Total debt | $ | 1,466.8 |  |

[0001069202-19-000030:mdna:116]
(1) The available future borrowings on our domestic credit facility are $357.5 million after being reduced by the outstanding borrowings and $2.5 million in outstanding standby letters of credit.  We also had $29.6 million in outstanding standby letters of credit outside of the domestic credit facility as of June 30, 2019.

[0001069202-19-000030:mdna:117]
[same as prior period, unchanged from 0001069202-19-000021:mdna:71]

[0001069202-19-000030:mdna:118]
[same as prior period, unchanged from 0001069202-19-000021:mdna:72]

[0001069202-19-000030:mdna:119]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 117.4% at June 30, 2019 from 116.8% at December 31, 2018.

[0001069202-19-000030:mdna:120]
As of June 30, 2019, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-19-000030:mdna:121]
[same as prior period, unchanged from 0001069202-19-000021:mdna:75]

[0001069202-19-000030:mdna:122]
We believe our cash and cash equivalents of $36 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $36 million as of June 30, 2019 was $14.0 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-19-000030:mdna:123]
Our expected capital expenditures for 2019 are $100 million, excluding capital expenditures made in conjunction with repair of our Marshalltown facility as those repairs will be covered by insurance.  We also expect to return a total of $400 million to shareholders through share repurchases in 2019.

[0001069202-19-000030:mdna:124]
[same as prior period, unchanged from 0001069202-19-000021:mdna:78]

[0001069202-19-000030:mdna:125]
[same as prior period, unchanged from 0001069202-19-000021:mdna:79]

[0001069202-19-000030:mdna:126]
Commitments, Contingencies and Guarantees

[0001069202-19-000030:mdna:127]
For information regarding our commitments, contingencies and guarantees, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000030:mdna:128]
[same as prior period, unchanged from 0001069202-19-000021:mdna:82]

[0001069202-19-000030:mdna:129]
[same as prior period, unchanged from 0001069202-19-000021:mdna:83]
