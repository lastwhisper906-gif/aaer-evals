# LII notes — 0001069202-19-000030


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-19-000030:notes:1]
[same as prior period, unchanged from 0001069202-19-000021:notes:1]

[0001069202-19-000030:notes:2]
[same as prior period, unchanged from 0001069202-19-000021:notes:2]

[0001069202-19-000030:notes:3]
[same as prior period, unchanged from 0001069202-19-000021:notes:3]

[0001069202-19-000030:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2019, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Stockholders' (Deficit) Equity for the three and six months ended June 30, 2019 and 2018, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2019 and 2018 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2018. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-19-000030:notes:5]
[same as prior period, unchanged from 0001069202-19-000021:notes:5]

[0001069202-19-000030:notes:6]
[same as prior period, unchanged from 0001069202-19-000021:notes:6]

[0001069202-19-000030:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-19-000030:notes:8]
[same as prior period, unchanged from 0001069202-19-000021:notes:8]

[0001069202-19-000030:notes:9]
[same as prior period, unchanged from 0001069202-19-000021:notes:9]

[0001069202-19-000030:notes:10]
[same as prior period, unchanged from 0001069202-19-000021:notes:10]

[0001069202-19-000030:notes:11]
Recently Adopted Accounting Guidance

[0001069202-19-000030:notes:12]
[same as prior period, unchanged from 0001069202-19-000021:notes:12]

[0001069202-19-000030:notes:13]
We adopted other new accounting standards during the first quarter of 2019. The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-19-000030:notes:14]
[same as prior period, unchanged from 0001069202-19-000021:notes:14]

[0001069202-19-000030:notes:15]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue.  See Note 16 for additional information on our reportable business segments and the products and services sold in each segment.

[0001069202-19-000030:notes:16]
|  | For the Three Months Ended June 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 647.2 |  |  | $ | 239.1 |  |  | $ | 80.0 |  |  | $ | 966.3 |  |
| Canada | 41.9 |  |  | 21.9 |  |  | — |  |  | 63.8 |  |
| International | — |  |  | 0.3 |  |  | 68.7 |  |  | 69.0 |  |
| Total | $ | 689.1 |  |  | 261.3 |  |  | 148.7 |  |  | 1,099.1 |  |

[0001069202-19-000030:notes:17]
|  | For the Three Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 663.6 |  |  | $ | 229.8 |  |  | $ | 112.7 |  |  | $ | 1,006.1 |  |
| Canada | 52.4 |  |  | 21.6 |  |  | 1.1 |  |  | 75.1 |  |
| International | — |  |  | 0.7 |  |  | 93.5 |  |  | 94.2 |  |
| Total | $ | 716.0 |  |  | 252.1 |  |  | 207.3 |  |  | 1,175.4 |  |

[0001069202-19-000030:notes:18]
|  | For the Six Months Ended June 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,080.3 |  |  | $ | 396.4 |  |  | $ | 171.6 |  |  | $ | 1,648.3 |  |
| Canada | 74.3 |  |  | 37.8 |  |  | 0.7 |  |  | 112.8 |  |
| International | — |  |  | 0.5 |  |  | 127.8 |  |  | 128.3 |  |
| Total | $ | 1,154.6 |  |  | 434.7 |  |  | 300.1 |  |  | 1,889.4 |  |

[0001069202-19-000030:notes:19]
|  | For the Six Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,087.1 |  |  | $ | 392.1 |  |  | $ | 208.4 |  |  | $ | 1,687.6 |  |
| Canada | 82.6 |  |  | 38.3 |  |  | 2.0 |  |  | 122.9 |  |
| International | — |  |  | 0.8 |  |  | 198.9 |  |  | 199.7 |  |
| Total | $ | 1,169.7 |  |  | 431.2 |  |  | 409.3 |  |  | 2,010.2 |  |

[0001069202-19-000030:notes:20]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the segment, for the three months ended June 30, 2019 and 2018, direct sales represent approximately $515.2 million and $546.7 million of revenues, and sales to independent distributors represent approximately $173.9 million and $169.3 million of revenues, respectively. For the six months ended June 30, 2019 and 2018, direct sales represent approximately $849.8 million and $886.3 million of revenues, and sales to independent distributors represent approximately $304.8 million and $283.4 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-19-000030:notes:21]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.    For the segment, for the three months ended June 30, 2019 and 2018, equipment sales represent approximately $226.6 million and $218.7 million of revenues while $34.7 million and $33.4 million of our revenue is generated from our service business, respectively. For the six months ended June 30, 2019 and 2018, equipment sales represent approximately $370.2 million and $370.2 million of revenues while $64.5 million and $61.0 million of our revenue is generated from our service business, respectively.

[0001069202-19-000030:notes:22]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems.  Revenue for the products sold is $148.2 million and $205.5 million for the three months ended June 30, 2019 and 2018 and $297.1 million and $405.5 million for the six months ended June 30, 2019 and 2018, respectively and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

[0001069202-19-000030:notes:23]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001069202-19-000030:notes:24]
[same as prior period, unchanged from 0001069202-19-000021:notes:23]

[0001069202-19-000030:notes:25]
[same as prior period, unchanged from 0001069202-19-000021:notes:24]

[0001069202-19-000030:notes:26]
[same as prior period, unchanged from 0001069202-19-000021:notes:25]

[0001069202-19-000030:notes:27]
[same as prior period, unchanged from 0001069202-19-000021:notes:26]

[0001069202-19-000030:notes:28]
|  | June 30, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (4.9 | ) |  | (13.0 | ) |  | 8.1 |  |  | (62.2 | )% |
| Contract liabilities - noncurrent | (6.0 | ) |  | (5.9 | ) |  | (0.1 | ) |  | 1.7 | % |
| Total | $ | (10.9 | ) |  | $ | (16.4 | ) |  | $ | 5.5 |  |  |  |

[0001069202-19-000030:notes:29]
For the three months ended June 30, 2019 and 2018, we recognized revenue of $1.5 million and $1.3 million and for the six months ended June 30, 2019 and 2018, we recognized revenue of $2.6 million and $2.9 million related to our contract liabilities at January 1, 2019 and  2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the second quarter of 2019 and 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-19-000030:notes:30]
[same as prior period, unchanged from 0001069202-19-000021:notes:29]

[0001069202-19-000030:notes:31]
[same as prior period, unchanged from 0001069202-19-000021:notes:30]

[0001069202-19-000030:notes:32]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Finished goods | $ | 431.3 |  |  | $ | 330.5 |  |
| Work in process | 6.2 |  |  | 10.0 |  |
| Raw materials and parts | 252.4 |  |  | 229.1 |  |
| Subtotal | 689.9 |  |  | 569.6 |  |
| Excess of current cost over last-in, first-out cost | (59.7 | ) |  | (59.8 | ) |
| Total inventories, net | $ | 630.2 |  |  | $ | 509.8 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-19-000030:notes:33]
Goodwill:
The changes in the carrying amount of goodwill for the first six months of 2019, in total and by segment, are summarized in the table below (in millions):

[0001069202-19-000030:notes:34]
|  | Balance at December 31, 2018 |  | Goodwill Reallocation (1) |  | Changes in foreign currency translation rates |  | Balance at June 30, 2019 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.4 |  |  | (0.3 | ) |  | — |  |  | 61.1 |  |
| Refrigeration | 99.1 |  |  | 0.3 |  |  | — |  |  | 99.4 |  |
| Total Goodwill | $ | 186.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 186.6 |  |

[0001069202-19-000030:notes:35]
(1) In 2019, we reorganized our external financial reporting structure by moving our European Commercial HVAC business from our Commercial segment to our Refrigeration segment as we manage both our commercial HVAC and refrigeration operations in Europe together. See Note 16 for additional information.

[0001069202-19-000030:notes:36]
We perform our annual goodwill impairment test in the fourth quarter of each year, and we monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-19-000030:notes:37]
[same as prior period, unchanged from 0001069202-19-000021:notes:36]

[0001069202-19-000030:notes:38]
[same as prior period, unchanged from 0001069202-19-000021:notes:37]

[0001069202-19-000030:notes:39]
[same as prior period, unchanged from 0001069202-19-000021:notes:38]

[0001069202-19-000030:notes:40]
[same as prior period, unchanged from 0001069202-19-000021:notes:39]

[0001069202-19-000030:notes:41]
[same as prior period, unchanged from 0001069202-19-000021:notes:40]

[0001069202-19-000030:notes:42]
[same as prior period, unchanged from 0001069202-19-000021:notes:41]

[0001069202-19-000030:notes:43]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through January 2020 and November 2020, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-19-000030:notes:44]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Unrealized losses on unsettled contracts | $ | 3.3 |  |  | $ | 8.4 |  |
| Income tax benefit | (0.7 | ) |  | (2.2 | ) |
| Losses (gains) included in AOCL, net of tax (1) | $ | 2.6 |  |  | $ | 6.2 |  |

[0001069202-19-000030:notes:45]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $2.6 million of derivative losses into earnings within the next 12 months.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-19-000030:notes:46]
[same as prior period, unchanged from 0001069202-19-000021:notes:45]

[0001069202-19-000030:notes:47]
As of June 30, 2019, we had no unrecognized tax benefits.

[0001069202-19-000030:notes:48]
[same as prior period, unchanged from 0001069202-19-000021:notes:47]

[0001069202-19-000030:notes:49]
[same as prior period, unchanged from 0001069202-19-000021:notes:48]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-19-000030:notes:50]
Commitments and Contingencies:

[0001069202-19-000030:notes:51]
Leases

[0001069202-19-000030:notes:52]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). We adopted ASC 842 on January 1, 2019, using the effective date method, with the cumulative-effect adjustment to the opening balance sheet of retained earnings as of the effective date. The financial results reported in periods prior to January 1, 2019 are unchanged.  Upon adoption, we recognized almost all of our leases greater than one year in duration on the balance sheet as right-of-use assets and lease liabilities. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification is based on criteria that are largely similar to those applied in current lease accounting standard, but without explicit bright lines. We have made certain assumptions in judgments when applying ASC 842.  Those judgments of most significance are as follows:

[0001069202-19-000030:notes:53]
| • | We elected the package of practical expedients available for transition which allow us to not reassess: |

[0001069202-19-000030:notes:54]
| ◦ | Whether expired or existing contracts contain leases under the new definition of a lease; |

[0001069202-19-000030:notes:55]
| ◦ | Lease classification for expired or existing leases; and |

[0001069202-19-000030:notes:56]
| ◦ | Whether previously capitalized initial direct costs would qualify for capitalization under ASC 842. |

[0001069202-19-000030:notes:57]
| • | We did not elect to use hindsight for transition when considering judgments and estimates such as assessments of lessee options to extend or terminate a lease or purchase the underlying asset. |

[0001069202-19-000030:notes:58]
| • | We did not elect to reassess whether land easements meet the definition of a lease if they were not accounted for as leases under the former rules. |

[0001069202-19-000030:notes:59]
| • | For all asset classes, we elected to not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. |

[0001069202-19-000030:notes:60]
| • | For all asset classes, we elected to not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component. |

[0001069202-19-000030:notes:61]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheet as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheet. Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

[0001069202-19-000030:notes:62]
Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-19-000030:notes:63]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-19-000030:notes:64]
We lease certain real and personal property under non-cancelable operating leases.  Approximately 75% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-19-000030:notes:65]
The components of lease expense were as follows (in millions):

[0001069202-19-000030:notes:66]
|  | For the Three Months Ended June 30, 2019 |  | For the Six Months Ended June 30, 2019 |
| Finance lease cost: |  |  |  |
| Amortization of right-of-use assets | $ | 1.8 |  |  | $ | 3.3 |  |
| Interest on lease liabilities | 0.2 |  |  | 0.3 |  |
| Operating lease cost | 14.9 |  |  | 29.3 |  |
| Short-term lease cost | 1.2 |  |  | 2.3 |  |
| Variable lease cost | 5.2 |  |  | 10.1 |  |
| Total lease cost | $ | 23.3 |  |  | $ | 45.3 |  |
| Other information |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 14.7 |  |  | $ | 27.4 |  |
| Financing cash flows from finance leases | $ | 2.3 |  |  | $ | 3.8 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 2.8 |  |  | $ | 6.0 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 5.0 |  |  | $ | 21.6 |  |

[0001069202-19-000030:notes:67]
|  | As of June 30, 2019 |
| Finance lease right-of-use assets | 23.9 |  |
| Operating lease right-of-use assets | 166.2 |  |
| Finance lease liability, current | 6.6 |  |
| Finance lease liability, non-current | 23.4 |  |
| Operating lease liability, current | 49.6 |  |
| Operating lease liability, non-current | 117.6 |  |
| Weighted-average remaining lease term - finance leases | 5.31 years |  |
| Weighted-average remaining lease term - operating leases | 4.25 years |  |
| Weighted-average discount rate - finance leases | 2.18 | % |
| Weighted-average discount rate – operating leases | 3.97 | % |

[0001069202-19-000030:notes:68]
Future annual minimum lease payments and finance lease commitments as of June 30, 2019 were as follows (in millions):

[0001069202-19-000030:notes:69]
|  | Operating Leases |  | Finance Leases |
| 2019 (excluding the six months ended June 30, 2019) | $ | 28.5 |  |  | $ | 3.7 |  |
| 2020 | 50.9 |  |  | 6.5 |  |
| 2021 | 37.8 |  |  | 4.9 |  |
| 2022 | 25.8 |  |  | 3.1 |  |
| 2023 | 19.7 |  |  | 1.2 |  |
| 2024 and thereafter | 19.2 |  |  | 11.7 |  |
| Total minimum lease payments | $ | 181.9 |  |  | $ | 31.1 |  |
| Less imputed interest | (14.7 | ) |  | (1.1 | ) |
| Lease liability | $ | 167.2 |  |  | $ | 30.0 |  |

[0001069202-19-000030:notes:70]
The Company adopted ASU 2016-02 on January 1, 2019 as noted above, and as required, the following disclosure is provided for periods prior to adoption. Future annual minimum lease payments and capital lease commitments as of December 31, 2018 were as follows (in millions):

[0001069202-19-000030:notes:71]
|  | Operating Leases |  | Capital Leases |
| 2019 | $ | 47.4 |  |  | $ | 6.6 |  |
| 2020 | 38.4 |  |  | 5.4 |  |
| 2021 | 27.2 |  |  | 3.8 |  |
| 2022 | 17.9 |  |  | 2.1 |  |
| 2023 | 12.7 |  |  | 0.9 |  |
| Thereafter | 16.1 |  |  | 12.8 |  |
| Total minimum lease payments | $ | 159.7 |  |  | $ | 31.6 |  |
| Less amount representing interest |  |  | (2.1 | ) |
| Present value of minimum payments |  |  | $ | 29.5 |  |

[0001069202-19-000030:notes:72]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024. The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, we are obligated to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance of $41.2 million, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 87% of the lease balance.  The headquarters lease is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-19-000030:notes:73]
Our obligations under the headquarters lease are secured by a pledge of our interest in the leased property.  The lease contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of June 30, 2019.

[0001069202-19-000030:notes:74]
Product Warranties and Product Related Contingencies

[0001069202-19-000030:notes:75]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-19-000030:notes:76]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000030:notes:77]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Accrued expenses | $ | 37.6 |  |  | $ | 37.9 |  |
| Other liabilities | 76.3 |  |  | 73.7 |  |
| Total warranty liability | $ | 113.9 |  |  | $ | 111.6 |  |

[0001069202-19-000030:notes:78]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2019 were as follows (in millions):

[0001069202-19-000030:notes:79]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Warranty claims paid | (15.3 | ) |
| Changes resulting from issuance of new warranties | 22.2 |  |
| Changes in estimates associated with pre-existing liabilities | (4.1 | ) |
| Changes in foreign currency translation rates and other | 0.1 |  |
| Warranty liability from divestitures | (0.6 | ) |
| Total warranty liability as of June 30, 2019 | $ | 113.9 |  |

[0001069202-19-000030:notes:80]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

[0001069202-19-000030:notes:81]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect was isolated, the vendor is supplying corrected components, and we are manufacturing products with the corrected components. We incurred and recorded expenses associated with this product quality in 2017. In the second quarter of 2019, the vendor agreed to reimburse us for certain losses incurred due to this quality issue.  These reimbursements will include cash payments in 2019 and price reductions on annual qualifying purchases from this vendor through 2024. The total reimbursements we receive from the vendor should off set the cost we have incurred related to this product quality matter.

[0001069202-19-000030:notes:82]
Litigation

[0001069202-19-000030:notes:83]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-19-000030:notes:84]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and

[0001069202-19-000030:notes:85]
judgments. For the three months ended June 30, 2019 and 2018, expense for asbestos-related litigation was $0.4 million and $(0.2) million and for the six months ended June 30, 2019 and 2018, expense for asbestos-related litigation was $1.8 million and $1.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

[0001069202-19-000030:notes:86]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.

[0001069202-19-000030:notes:87]
Marshalltown Tornado and Recovery

[0001069202-19-000030:notes:88]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  We have insurance for the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Gain from insurance recoveries, net of losses incurred and Insurance proceeds for lost profits in the Consolidated Statements of Operations.

[0001069202-19-000030:notes:89]
The following table summarizes the Gain from insurance recoveries, net of losses incurred:

[0001069202-19-000030:notes:90]
| (Amounts in millions) | For the Three months Ended June 30, 2019 |  | For the Six months Ended June 30, 2019 |
| Insurance recoveries received | $ | 52.0 |  |  | $ | 128.0 |  |
| Less losses and expenses incurred: |  |  |  |
| Site clean-up and remediation | 6.2 |  |  | 23.3 |  |
| Factory inefficiencies due to lower productivity | 4.5 |  |  | 8.0 |  |
| Other | 9.4 |  |  | 18.4 |  |
| Total losses and expenses | $ | 20.1 |  |  | $ | 49.7 |  |
| Total gain from insurance recoveries | $ | 31.9 |  |  | $ | 78.3 |  |
| Presentation in the Consolidated Statements of Operations: |  |  |  |
| Insurance proceeds for lost profits | (26.0 | ) |  | (65.5 | ) |
| Gain from insurance recoveries, net of losses incurred | (5.9 | ) |  | (12.8 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001069202-19-000030:notes:91]
Lines of Credit and Financing Arrangements:

[0001069202-19-000030:notes:92]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000030:notes:93]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.6 |  |  | $ | 3.5 |  |
| Domestic credit facility | 15.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 311.0 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 23.4 |  |  | 15.7 |  |
| Domestic credit facility | 785.0 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.6 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,155.8 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,466.8 |  |  | $ | 1,041.3 |  |

[0001069202-19-000030:notes:94]
Short-Term Debt

[0001069202-19-000030:notes:95]
Foreign Obligations

[0001069202-19-000030:notes:96]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2019 or December 31, 2018.  There were no significant proceeds or repayments on these facilities for the six months ended June 30, 2019.  Proceeds and repayments on these facilities were $21.3 million and $18.4 million, respectively, for the six months ended June 30, 2018.

[0001069202-19-000030:notes:97]
Asset Securitization Program

[0001069202-19-000030:notes:98]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.  The ASP will expire in November 2019 and we intend to renew the ASP prior to its expiration.

[0001069202-19-000030:notes:99]
The ASP provides for a maximum securitization amount ranging from $225.0 million to $380.0 million, depending on the period. The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-19-000030:notes:100]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 290.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (290.0 | ) |  | (268.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 22.0 |  |

[0001069202-19-000030:notes:101]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2019 and December 31, 2018 were 3.11% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-19-000030:notes:102]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2019, we believe we were in compliance with all covenant requirements.

[0001069202-19-000030:notes:103]
Long-Term Debt

[0001069202-19-000030:notes:104]
Domestic Credit Facility

[0001069202-19-000030:notes:105]
On January 22, 2019, we amended our credit facility with the Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $190.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $800.0 million, of which $160.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of June 30, 2019. Subject to covenant limitations, $357.5 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

[0001069202-19-000030:notes:106]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-19-000030:notes:107]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.63 | % |  | 3.74 | % |

[0001069202-19-000030:notes:108]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-19-000030:notes:109]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-19-000030:notes:110]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-19-000030:notes:111]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-19-000030:notes:112]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-19-000030:notes:113]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-19-000030:notes:114]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due

[0001069202-19-000030:notes:115]
and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2019, we believe we were in compliance with all covenant requirements.

[0001069202-19-000030:notes:116]
Senior Unsecured Notes

[0001069202-19-000030:notes:117]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2019, we believe we were in compliance with all covenant requirements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-19-000030:notes:118]
[same as prior period, unchanged from 0001069202-19-000021:notes:115]

[0001069202-19-000030:notes:119]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other expense (income), net in the Statement of Operations. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We elected the practical expedient to use the prior year's disclosure as a basis for the retroactive adoption of the ASU.  The ASU did not have a material impact on our financial results.

[0001069202-19-000030:notes:120]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and $105.6 million of related pension benefit obligations.  In the second quarter of 2019, we recognized a $60.6 million pension settlement charge in the Statement of Operations and reclassified $5.6 million of pension benefit obligations to AOCL as a result of this transaction.

[0001069202-19-000030:notes:121]
[same as prior period, unchanged from 0001069202-19-000021:notes:117]

[0001069202-19-000030:notes:122]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Pension Benefits |  | Pension Benefits |
| Service cost | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 2.4 |  |  | $ | 2.7 |  |
| Interest cost | 1.9 |  |  | 3.1 |  |  | 5.4 |  |  | 6.2 |  |
| Expected return on plan assets | (2.5 | ) |  | (4.7 | ) |  | (7.2 | ) |  | (9.4 | ) |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Recognized actuarial loss | 0.9 |  |  | 2.3 |  |  | 2.9 |  |  | 4.6 |  |
| Settlements and curtailments | 60.6 |  |  | — |  |  | 60.6 |  |  | — |  |
| Net periodic benefit cost | $ | 62.2 |  |  | $ | 2.1 |  |  | $ | 64.2 |  |  | $ | 4.2 |  |

[0001069202-19-000030:notes:123]
In January 2018, we reduced our estimated long-term rate of return on plan assets for U.S. pension plans from 7.5% to 6.5%.  A 25 basis point decrease in the long-term rate of return will result in a $0.4 million increase in net periodic benefit cost for U.S. pension plans.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-19-000030:notes:124]
[same as prior period, unchanged from 0001069202-19-000021:notes:120]

[0001069202-19-000030:notes:125]
[same as prior period, unchanged from 0001069202-19-000021:notes:121]

[0001069202-19-000030:notes:126]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2018 |  | 2017 |
| Stock-based compensation expense (1) | $ | 6.1 |  |  | $ | 8.8 |  |  | $ | 11.4 |  |  | $ | 13.6 |  |

[0001069202-19-000030:notes:127]
[same as prior period, unchanged from 0001069202-19-000021:notes:123]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-19-000030:notes:128]
[same as prior period, unchanged from 0001069202-19-000021:notes:124]

[0001069202-19-000030:notes:129]
Our Board of Directors has authorized a total of $2.5 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in  March 2018. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of June 30, 2019, $196 million of shares may be repurchased under the Share Repurchase Plans.

[0001069202-19-000030:notes:130]
We repurchased 0.4 million shares for $100.0 million during the first quarter of 2019 and 0.6 million shares for $150.0 million during the second quarter of 2019, respectively, from open market transactions. We also repurchased 0.1 million shares for $14.5 million during the six months ended June 30, 2019 from employees who surrendered shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-19-000030:notes:131]
[same as prior period, unchanged from 0001069202-19-000021:notes:128]

[0001069202-19-000030:notes:132]
[same as prior period, unchanged from 0001069202-19-000021:notes:129]

[0001069202-19-000030:notes:133]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts/foreign exchange forward contracts |  | $ | (2.0 | ) |  | $ | 2.6 |  |  | $ | (4.3 | ) |  | $ | 7.2 |  |  | Cost of goods sold |
| Income tax benefit (expense) |  | 0.5 |  |  | (0.6 | ) |  | 1.0 |  |  | (1.6 | ) |  | Provision for income taxes |
| Net of tax |  | $ | (1.5 | ) |  | $ | 2.0 |  |  | $ | (3.3 | ) |  | $ | 5.6 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.0 | ) |  | $ | (2.4 | ) |  | $ | (3.0 | ) |  | $ | (4.7 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Pension settlement |  | (60.6 | ) |  | — |  |  | (60.6 | ) |  | — |  |  | Pension settlement |
| Income tax benefit |  | 15.3 |  |  | 0.6 |  |  | 15.8 |  |  | 1.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (46.3 | ) |  | $ | (1.8 | ) |  | $ | (47.8 | ) |  | $ | (3.5 | ) |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency adjustments on sale of businesses |  | $ | — |  |  | $ | (22.9 | ) |  | $ | (2.1 | ) |  | $ | (22.9 | ) |  | Loss (gain), net on sale of businesses and related property |
| Net of tax |  | $ | — |  |  | $ | (22.9 | ) |  | $ | (2.1 | ) |  | $ | (22.9 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (47.8 | ) |  | $ | (22.7 | ) |  | $ | (53.2 | ) |  | $ | (20.8 | ) |  |  |

[0001069202-19-000030:notes:134]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2019 (in millions):

[0001069202-19-000030:notes:135]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2018 |  | $ | (6.2 | ) |  | $ | (154.5 | ) |  | $ | (28.1 | ) |  | $ | (188.8 | ) |
| Other comprehensive income (loss) before reclassifications |  | 0.3 |  |  | 1.8 |  |  | 3.9 |  |  | 6.0 |  |
| Amounts reclassified from AOCL |  | 3.3 |  |  | 47.8 |  |  | 2.1 |  |  | 53.2 |  |
| Net other comprehensive (loss) income |  | 3.6 |  |  | 49.6 |  |  | 6.0 |  |  | 59.2 |  |
| Balance as of June 30, 2019 |  | $ | (2.6 | ) |  | $ | (104.9 | ) |  | $ | (22.1 | ) |  | $ | (129.6 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-19-000030:notes:136]
[same as prior period, unchanged from 0001069202-19-000021:notes:133]

[0001069202-19-000030:notes:137]
We record restructuring charges associated with management-approved restructuring plans when we reorganize or remove duplicative headcount or infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 16.  Restructuring activities in 2018 and 2019 were insignificant.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-19-000030:notes:138]
[same as prior period, unchanged from 0001069202-19-000021:notes:145]

[0001069202-19-000030:notes:139]
[same as prior period, unchanged from 0001069202-19-000021:notes:146]

[0001069202-19-000030:notes:140]
During the first quarter of 2019, we obtained Board of Directors' approval and signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. The sale was completed on March 29, 2019 with the post-completion adjustment being recorded in the second quarter of 2019. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-19-000030:notes:141]
| (Amounts in millions) | For the Six Months Ended June 30, 2019 |
| Cash received from the buyer | $ | 49.0 |  |
| Net assets sold | (50.3 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (2.1 | ) |
| Direct costs to sell | (5.4 | ) |
| Loss on sale of business | $ | (8.8 | ) |

[0001069202-19-000030:notes:142]
[same as prior period, unchanged from 0001069202-19-000021:notes:149]

[0001069202-19-000030:notes:143]
[same as prior period, unchanged from 0001069202-19-000021:notes:150]

[0001069202-19-000030:notes:144]
[same as prior period, unchanged from 0001069202-19-000021:notes:151]

[0001069202-19-000030:notes:145]
[same as prior period, unchanged from 0001069202-19-000021:notes:152]

[0001069202-19-000030:notes:146]
[same as prior period, unchanged from 0001069202-19-000021:notes:153]

[0001069202-19-000030:notes:147]
[same as prior period, unchanged from 0001069202-19-000021:notes:154]

[0001069202-19-000030:notes:148]
[same as prior period, unchanged from 0001069202-19-000021:notes:155]

[0001069202-19-000030:notes:149]
[same as prior period, unchanged from 0001069202-19-000021:notes:156]

[0001069202-19-000030:notes:150]
[same as prior period, unchanged from 0001069202-19-000021:notes:157]

[0001069202-19-000030:notes:151]
[same as prior period, unchanged from 0001069202-19-000021:notes:158]

[0001069202-19-000030:notes:152]
[same as prior period, unchanged from 0001069202-19-000021:notes:159]


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001069202-19-000030:notes:153]
[same as prior period, unchanged from 0001069202-19-000021:notes:160]

[0001069202-19-000030:notes:154]
(1) Includes $10.3 million of net assets that were written down during the quarter ended March 31, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Australia, New Zealand and Asia business.
The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-19-000030:notes:155]
(2) Includes $1.2 million of net assets that were written down during the quarter ended June 30, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Brazil business.
The following table summarizes the net loss recognized in connection with this divestiture:


## us-gaap:EarningsPerShareTextBlock

[0001069202-19-000030:notes:156]
[same as prior period, unchanged from 0001069202-19-000021:notes:162]

[0001069202-19-000030:notes:157]
[same as prior period, unchanged from 0001069202-19-000021:notes:163]

[0001069202-19-000030:notes:158]
[same as prior period, unchanged from 0001069202-19-000021:notes:164]

[0001069202-19-000030:notes:159]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net income | $ | 110.7 |  |  | $ | 137.6 |  |  | $ | 180.0 |  |  | $ | 175.5 |  |
| Add: Loss from discontinued operations | 0.3 |  |  | 1.6 |  |  | 0.4 |  |  | 1.6 |  |
| Income from continuing operations | $ | 111.0 |  |  | $ | 139.2 |  |  | $ | 180.4 |  |  | $ | 177.1 |  |
| Weighted-average shares outstanding – basic | 39.1 |  |  | 40.7 |  |  | 39.4 |  |  | 41.1 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.4 |  |  | 0.4 |  |  | 0.4 |  |  | 0.5 |  |
| Weighted-average shares outstanding – diluted | 39.5 |  |  | 41.1 |  |  | 39.8 |  |  | 41.6 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.84 |  |  | $ | 3.42 |  |  | $ | 4.58 |  |  | $ | 4.31 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.04 | ) |  | (0.01 | ) |  | (0.04 | ) |
| Net income | $ | 2.83 |  |  | $ | 3.38 |  |  | $ | 4.57 |  |  | $ | 4.27 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.81 |  |  | $ | 3.39 |  |  | $ | 4.53 |  |  | $ | 4.26 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.04 | ) |  | (0.01 | ) |  | (0.04 | ) |
| Net income | $ | 2.80 |  |  | $ | 3.35 |  |  | $ | 4.52 |  |  | $ | 4.22 |  |

[0001069202-19-000030:notes:160]
[same as prior period, unchanged from 0001069202-19-000021:notes:166]

[0001069202-19-000030:notes:161]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Weighted-average number of shares | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Price per share | $ | — |  |  | $ | 205.53 |  |  | $ | — |  |  | $ | 205.53 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-19-000030:notes:162]
[same as prior period, unchanged from 0001069202-19-000021:notes:168]

[0001069202-19-000030:notes:163]
[same as prior period, unchanged from 0001069202-19-000021:notes:169]

[0001069202-19-000030:notes:164]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaCentral AmericaSouth America |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | United StatesCanadaEurope(1)Asia Pacific(2)South America(2)Central America |

[0001069202-19-000030:notes:165]
(1)Effective January 1, 2019, we realigned our segment structure. We shifted financial reporting of the European Commercial HVAC business from our Commercial Heating & Cooling segment to our Refrigeration segment as we manage both our commercial HVAC and refrigeration operations in Europe together. We have revised our historical segment results to present them on a comparable basis.

[0001069202-19-000030:notes:166]
(2)Our businesses in the Asia Pacific and South America area were sold in the second and third quarters of 2018, respectively. Refer to Note 14 for details regarding the divestiture of these businesses.

[0001069202-19-000030:notes:167]
[same as prior period, unchanged from 0001069202-19-000021:notes:170]

[0001069202-19-000030:notes:168]
[same as prior period, unchanged from 0001069202-19-000021:notes:171]

[0001069202-19-000030:notes:169]
[same as prior period, unchanged from 0001069202-19-000021:notes:172]

[0001069202-19-000030:notes:170]
[same as prior period, unchanged from 0001069202-19-000021:notes:173]

[0001069202-19-000030:notes:171]
[same as prior period, unchanged from 0001069202-19-000021:notes:174]

[0001069202-19-000030:notes:172]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 689.1 |  |  | $ | 716.0 |  |  | $ | 1,154.6 |  |  | $ | 1,169.7 |  |
| Commercial Heating & Cooling | 261.3 |  |  | 252.1 |  |  | 434.7 |  |  | 431.2 |  |
| Refrigeration | 148.7 |  |  | 207.3 |  |  | 300.1 |  |  | 409.3 |  |
|  | $ | 1,099.1 |  |  | $ | 1,175.4 |  |  | $ | 1,889.4 |  |  | $ | 2,010.2 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 153.4 |  |  | $ | 153.6 |  |  | $ | 240.1 |  |  | $ | 204.9 |  |
| Commercial Heating & Cooling | 53.9 |  |  | 50.8 |  |  | 68.9 |  |  | 72.8 |  |
| Refrigeration | 19.1 |  |  | 23.4 |  |  | 27.5 |  |  | 32.1 |  |
| Corporate and other | (24.1 | ) |  | (22.5 | ) |  | (36.2 | ) |  | (33.7 | ) |
| Total segment profit | 202.3 |  |  | 205.3 |  |  | 300.3 |  |  | 276.1 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special inventory write down | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Special product quality adjustment | (0.5 | ) |  | — |  |  | (0.5 | ) |  | — |  |
| Loss (gain) on sale of businesses and related property | 0.4 |  |  | (22.1 | ) |  | 8.8 |  |  | (11.8 | ) |
| Loss on assets held for sale | — |  |  | 31.4 |  |  | — |  |  | 31.4 |  |
| Partial advance of insurance recoveries related to lost profits | (8.0 | ) |  | — |  |  | (8.0 | ) |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (5.9 | ) |  | — |  |  | (12.8 | ) |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 2.6 |  |  | 0.4 |  |  | 3.9 |  |  | 6.9 |  |
| Restructuring charges | (0.1 | ) |  | 0.5 |  |  | 0.4 |  |  | 1.3 |  |
| Operating income | $ | 213.8 |  |  | $ | 195.1 |  |  | $ | 308.5 |  |  | $ | 248.1 |  |

[0001069202-19-000030:notes:173]
[same as prior period, unchanged from 0001069202-19-000021:notes:176]

[0001069202-19-000030:notes:174]
The following items in Losses (gains) and other expenses, net:

[0001069202-19-000030:notes:175]
[same as prior period, unchanged from 0001069202-19-000021:notes:178]

[0001069202-19-000030:notes:176]
| ◦ | Special legal contingency charges, |

[0001069202-19-000030:notes:177]
| ◦ | Asbestos-related litigation, |

[0001069202-19-000030:notes:178]
[same as prior period, unchanged from 0001069202-19-000021:notes:181]

[0001069202-19-000030:notes:179]
[same as prior period, unchanged from 0001069202-19-000021:notes:182]

[0001069202-19-000030:notes:180]
[same as prior period, unchanged from 0001069202-19-000021:notes:183]

[0001069202-19-000030:notes:181]
[same as prior period, unchanged from 0001069202-19-000021:notes:184]

[0001069202-19-000030:notes:182]
| • | Special product quality adjustment, |

[0001069202-19-000030:notes:183]
| • | Loss (gain) on sale of businesses and related property, |

[0001069202-19-000030:notes:184]
[same as prior period, unchanged from 0001069202-19-000021:notes:186]

[0001069202-19-000030:notes:185]
| • | Partial advance of insurance recoveries related to lost profits, |

[0001069202-19-000030:notes:186]
| • | Gain from insurance recoveries, net of losses incurred, and, |

[0001069202-19-000030:notes:187]
[same as prior period, unchanged from 0001069202-19-000021:notes:188]

[0001069202-19-000030:notes:188]
[same as prior period, unchanged from 0001069202-19-000021:notes:189]

[0001069202-19-000030:notes:189]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Total Assets: |  |  |  |
| Residential Heating & Cooling | $ | 1,269.0 |  |  | $ | 837.4 |  |
| Commercial Heating & Cooling | 436.0 |  |  | 349.5 |  |
| Refrigeration | 412.6 |  |  | 462.9 |  |
| Corporate and other | 222.8 |  |  | 167.4 |  |
| Total assets | $ | 2,340.4 |  |  | $ | 1,817.2 |  |

[0001069202-19-000030:notes:190]
[same as prior period, unchanged from 0001069202-19-000021:notes:190]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-19-000030:notes:191]
[same as prior period, unchanged from 0001069202-19-000021:notes:141]


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-19-000030:notes:192]
[same as prior period, unchanged from 0001069202-19-000021:notes:191]

[0001069202-19-000030:notes:193]
[same as prior period, unchanged from 0001069202-19-000021:notes:192]

[0001069202-19-000030:notes:194]
The methodologies used to determine the fair value of our financial assets and liabilities at June 30, 2019 were the same as those used at December 31, 2018.

[0001069202-19-000030:notes:195]
[same as prior period, unchanged from 0001069202-19-000021:notes:194]

[0001069202-19-000030:notes:196]
[same as prior period, unchanged from 0001069202-19-000021:notes:196]

[0001069202-19-000030:notes:197]
[same as prior period, unchanged from 0001069202-19-000021:notes:197]

[0001069202-19-000030:notes:198]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-19-000030:notes:199]
[same as prior period, unchanged from 0001069202-19-000021:notes:199]

[0001069202-19-000030:notes:200]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Senior unsecured notes | $ | 326.7 |  |  | $ | 302.9 |  |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-19-000030:notes:201]
[same as prior period, unchanged from 0001069202-19-000021:notes:201]

[0001069202-19-000030:notes:202]
[same as prior period, unchanged from 0001069202-19-000021:notes:202]

[0001069202-19-000030:notes:203]
The condensed consolidating financial statements reflect our investments in our subsidiaries using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Our condensed consolidating financial statements and our Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of June 30, 2019 and December 31, 2018, and for the three and six months ended June 30, 2019 and 2018 are shown on the following pages.
Lennox International Inc. and Subsidiaries
Condensed Consolidating Balance Sheets

[0001069202-19-000030:notes:204]
As of June 30, 2019

[0001069202-19-000030:notes:205]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.9 |  |  | $ | 22.3 |  |  | $ | 12.2 |  |  | $ | — |  |  | $ | 36.4 |  |
| Short-term investments | — |  |  | — |  |  | 1.8 |  |  | — |  |  | $ | 1.8 |  |
| Accounts and notes receivable, net | — |  |  | 75.9 |  |  | 642.9 |  |  | — |  |  | 718.8 |  |
| Inventories, net | — |  |  | 552.3 |  |  | 80.0 |  |  | (2.1 | ) |  | 630.2 |  |
| Other assets | 3.5 |  |  | 35.7 |  |  | 51.9 |  |  | (34.4 | ) |  | 56.7 |  |
| Total current assets | 5.4 |  |  | 686.2 |  |  | 788.8 |  |  | (36.5 | ) |  | 1,443.9 |  |
| Property, plant and equipment, net | — |  |  | 362.9 |  |  | 55.1 |  |  | — |  |  | 418.0 |  |
| Right-of-use assets from operating leases | — |  |  | 142.2 |  |  | 24.0 |  |  | — |  |  | 166.2 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.5 |  |  | — |  |  | 186.6 |  |
| Investment in subsidiaries | 1,532.3 |  |  | 570.2 |  |  | 50.2 |  |  | (2,152.7 | ) |  | — |  |
| Deferred income taxes | (11.1 | ) |  | 49.5 |  |  | 23.1 |  |  | (12.3 | ) |  | 49.2 |  |
| Other assets, net | 1.7 |  |  | 54.2 |  |  | 6.4 |  |  | 14.2 |  |  | 76.5 |  |
| Intercompany (payables) receivables, net | (587.0 | ) |  | 589.0 |  |  | 118.0 |  |  | (120.0 | ) |  | — |  |
| Total assets | $ | 941.3 |  |  | $ | 2,620.3 |  |  | $ | 1,086.1 |  |  | $ | (2,307.3 | ) |  | $ | 2,340.4 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt | 14.4 |  |  | 5.7 |  |  | 290.9 |  |  | — |  |  | 311.0 |  |
| Current operating lease liabilities | — |  |  | 42.9 |  |  | 6.7 |  |  | — |  |  | 49.6 |  |
| Accounts payable | 30.0 |  |  | 393.3 |  |  | 50.3 |  |  | — |  |  | 473.6 |  |
| Accrued expenses | 6.5 |  |  | 193.7 |  |  | 40.6 |  |  | — |  |  | 240.8 |  |
| Income taxes (receivable) payable | (24.7 | ) |  | 34.1 |  |  | 41.4 |  |  | (50.8 | ) |  | — |  |
| Total current liabilities | 26.2 |  |  | 669.7 |  |  | 429.9 |  |  | (50.8 | ) |  | 1,075.0 |  |
| Long-term debt | 1,132.4 |  |  | 21.8 |  |  | 1.6 |  |  | — |  |  | 1,155.8 |  |
| Long-term operating lease liabilities | — |  |  | 100.2 |  |  | 17.4 |  |  | — |  |  | 117.6 |  |
| Pensions | — |  |  | 71.8 |  |  | 7.8 |  |  | — |  |  | 79.6 |  |
| Other liabilities | 0.2 |  |  | 122.6 |  |  | 7.1 |  |  | — |  |  | 129.9 |  |
| Total liabilities | 1,158.8 |  |  | 986.1 |  |  | 463.8 |  |  | (50.8 | ) |  | 2,557.9 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' (deficit) equity | (217.5 | ) |  | 1,634.2 |  |  | 622.3 |  |  | (2,256.5 | ) |  | (217.5 | ) |
| Total liabilities and stockholders' (deficit) equity | $ | 941.3 |  |  | $ | 2,620.3 |  |  | $ | 1,086.1 |  |  | $ | (2,307.3 | ) |  | $ | 2,340.4 |  |

[0001069202-19-000030:notes:206]
Lennox International Inc. and Subsidiaries

[0001069202-19-000030:notes:207]
Condensed Consolidating Balance Sheets

[0001069202-19-000030:notes:208]
[same as prior period, unchanged from 0001069202-19-000021:notes:207]

[0001069202-19-000030:notes:209]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.8 |  |  | $ | 15.4 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 46.3 |  |
| Accounts and notes receivable, net | — |  |  | 44.3 |  |  | 428.4 |  |  | — |  |  | 472.7 |  |
| Inventories, net | — |  |  | 411.4 |  |  | 103.9 |  |  | (5.5 | ) |  | 509.8 |  |
| Other assets | 3.3 |  |  | 36.2 |  |  | 54.7 |  |  | (33.6 | ) |  | 60.6 |  |
| Total current assets | 5.1 |  |  | 507.3 |  |  | 616.1 |  |  | (39.1 | ) |  | 1,089.4 |  |
| Property, plant and equipment, net | — |  |  | 293.3 |  |  | 118.6 |  |  | (3.6 | ) |  | 408.3 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.5 |  |  | — |  |  | 186.6 |  |
| Investment in subsidiaries | 1,311.9 |  |  | 357.8 |  |  | (0.5 | ) |  | (1,669.2 | ) |  | — |  |
| Deferred income taxes | 1.4 |  |  | 54.4 |  |  | 23.4 |  |  | (12.2 | ) |  | 67.0 |  |
| Other assets, net | 1.5 |  |  | 48.1 |  |  | 17.8 |  |  | (1.5 | ) |  | 65.9 |  |
| Intercompany (payables) receivables, net | (715.5 | ) |  | 675.8 |  |  | 142.6 |  |  | (102.9 | ) |  | — |  |
| Total assets | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.8 |  |  | 268.6 |  |  | — |  |  | 300.8 |  |
| Accounts payable | 25.5 |  |  | 295.7 |  |  | 112.1 |  |  | — |  |  | 433.3 |  |
| Accrued expenses | 12.1 |  |  | 213.8 |  |  | 46.4 |  |  | — |  |  | 272.3 |  |
| Income taxes (receivable) payable | (38.5 | ) |  | 40.6 |  |  | 50.8 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | 28.5 |  |  | 552.9 |  |  | 477.9 |  |  | (50.8 | ) |  | 1,008.5 |  |
| Long-term debt | 724.9 |  |  | 15.0 |  |  | 0.6 |  |  | — |  |  | 740.5 |  |
| Pensions | — |  |  | 75.1 |  |  | 7.7 |  |  | — |  |  | 82.8 |  |
| Other liabilities | 0.6 |  |  | 126.4 |  |  | 8.0 |  |  | — |  |  | 135.0 |  |
| Total liabilities | 754.0 |  |  | 769.4 |  |  | 494.2 |  |  | (50.8 | ) |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' (deficit) equity | (149.6 | ) |  | 1,333.4 |  |  | 444.3 |  |  | (1,777.7 | ) |  | (149.6 | ) |
| Total liabilities and stockholders' (deficit) equity | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |

[0001069202-19-000030:notes:210]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-19-000030:notes:211]
For the Three Months Ended June 30, 2019

[0001069202-19-000030:notes:212]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,019.2 |  |  | $ | 146.5 |  |  | $ | (66.6 | ) |  | $ | 1,099.1 |  |
| Cost of goods sold | — |  |  | 723.6 |  |  | 169.6 |  |  | (126.2 | ) |  | 767.0 |  |
| Gross profit | — |  |  | 295.6 |  |  | (23.1 | ) |  | 59.6 |  |  | 332.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 147.1 |  |  | 5.0 |  |  | 0.3 |  |  | 152.4 |  |
| Losses (gains) and other expenses, net | 0.2 |  |  | 1.3 |  |  | 0.8 |  |  | (0.2 | ) |  | 2.1 |  |
| Restructuring charges | — |  |  | (0.1 | ) |  | — |  |  | — |  |  | (0.1 | ) |
| Loss on sale of business | — |  |  | 0.3 |  |  | 0.1 |  |  | — |  |  | 0.4 |  |
| Insurance proceeds for lost profits | — |  |  | (26.0 | ) |  | — |  |  | — |  |  | (26.0 | ) |
| Gain from insurance recoveries, net of losses incurred | — |  |  | (5.9 | ) |  | — |  |  | — |  |  | (5.9 | ) |
| Income from equity method investments | (112.5 | ) |  | 24.0 |  |  | (3.8 | ) |  | 87.7 |  |  | (4.6 | ) |
| Operating income | 112.3 |  |  | 154.9 |  |  | (25.2 | ) |  | (28.2 | ) |  | 213.8 |  |
| Pension settlement | — |  |  | 60.6 |  |  | — |  |  | — |  |  | 60.6 |  |
| Interest expense, net | 2.2 |  |  | 9.3 |  |  | 1.6 |  |  | — |  |  | 13.1 |  |
| Other (income) expense, net | — |  |  | 6.8 |  |  | (6.5 | ) |  | — |  |  | 0.3 |  |
| Income (loss) from continuing operations before income taxes | 110.1 |  |  | 78.2 |  |  | (20.3 | ) |  | (28.2 | ) |  | 139.8 |  |
| Provision for income tax (benefit) expense | (0.6 | ) |  | 23.5 |  |  | 5.9 |  |  | — |  |  | 28.8 |  |
| Income (loss) from continuing operations | 110.7 |  |  | 54.7 |  |  | (26.2 | ) |  | (28.2 | ) |  | 111.0 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Net income (loss) | $ | 110.7 |  |  | $ | 54.7 |  |  | $ | (26.5 | ) |  | $ | (28.2 | ) |  | $ | 110.7 |  |
| Other comprehensive income, net of tax | (2.0 | ) |  | 50.0 |  |  | 2.6 |  |  | — |  |  | 50.6 |  |
| Comprehensive income (loss) | $ | 108.7 |  |  | $ | 104.7 |  |  | $ | (23.9 | ) |  | $ | (28.2 | ) |  | $ | 161.3 |  |

[0001069202-19-000030:notes:213]
Condensed Consolidating Statements of Cash Flows

[0001069202-19-000030:notes:214]
For the Six Months Ended  June 30, 2019

[0001069202-19-000030:notes:215]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows provided by (used in) operating activities | $ | 33.2 |  |  | $ | (79.1 | ) |  | $ | (65.1 | ) |  | $ | — |  |  | $ | (111.0 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.6 |  |  | 0.2 |  |  | — |  |  | 0.8 |  |
| Purchases of property, plant and equipment | — |  |  | (49.2 | ) |  | (4.3 | ) |  | — |  |  | (53.5 | ) |
| Net proceeds from sale of business | — |  |  | 43.0 |  |  | 0.6 |  |  | — |  |  | 43.6 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 12.8 |  |  | — |  |  | — |  |  | 12.8 |  |
| Purchases of short-term investments | — |  |  | — |  |  | (1.8 | ) |  | — |  |  | (1.8 | ) |
| Net cash provided by (used in) by investing activities | — |  |  | 7.2 |  |  | (5.3 | ) |  | — |  |  | 1.9 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term debt payments | — |  |  | — |  |  | (2.1 | ) |  | — |  |  | (2.1 | ) |
| Short-term debt proceeds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 65.5 |  |  | — |  |  | 65.5 |  |
| Asset securitization payments | — |  |  | — |  |  | (43.5 | ) |  | — |  |  | (43.5 | ) |
| Long-term debt payments | (30.0 | ) |  | (1.9 | ) |  | (1.4 | ) |  | — |  |  | (33.3 | ) |
| Borrowings from credit facility | 1,459.5 |  |  | — |  |  | — |  |  | — |  |  | 1,459.5 |  |
| Payments on credit facility | (1,037.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,037.5 | ) |
| Proceeds from employee stock purchases | 1.6 |  |  | — |  |  | — |  |  | — |  |  | 1.6 |  |
| Repurchases of common stock | (250.0 | ) |  | — |  |  | — |  |  | — |  |  | (250.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (14.5 | ) |  | — |  |  | — |  |  | — |  |  | (14.5 | ) |
| Intercompany financing activity | (111.4 | ) |  | 80.3 |  |  | 31.1 |  |  | — |  |  | — |  |
| Cash dividends paid | (50.8 | ) |  | — |  |  | — |  |  | — |  |  | (50.8 | ) |
| Net cash (used in) provided by financing activities | (33.1 | ) |  | 78.4 |  |  | 51.7 |  |  | — |  |  | 97.0 |  |
| Increase (decrease) in cash and cash equivalents | 0.1 |  |  | 6.5 |  |  | (18.7 | ) |  | — |  |  | (12.1 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | 0.4 |  |  | 1.8 |  |  | — |  |  | 2.2 |  |
| Cash and cash equivalents, beginning of period | 1.8 |  |  | 15.4 |  |  | 29.1 |  |  | — |  |  | 46.3 |  |
| Cash and cash equivalents, end of period | $ | 1.9 |  |  | $ | 22.3 |  |  | $ | 12.2 |  |  | $ | — |  |  | $ | 36.4 |  |

[0001069202-19-000030:notes:216]
For the Six Months Ended  June 30, 2018

[0001069202-19-000030:notes:217]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 87.2 |  |  | $ | (7.9 | ) |  | $ | (114.3 | ) |  | $ | — |  |  | $ | (35.0 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (33.0 | ) |  | (10.4 | ) |  | — |  |  | (43.4 | ) |
| Proceeds from sale of businesses | — |  |  | — |  |  | 111.8 |  |  | — |  |  | 111.8 |  |
| Net cash (used in) provided by investing activities | — |  |  | (33.0 | ) |  | 101.5 |  |  | — |  |  | 68.5 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term debt payments | — |  |  | — |  |  | (18.4 | ) |  | — |  |  | (18.4 | ) |
| Short-term debt proceeds | — |  |  | — |  |  | 21.3 |  |  | — |  |  | 21.3 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 65.0 |  |  | — |  |  | 65.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (51.0 | ) |  | — |  |  | (51.0 | ) |
| Long-term debt payments | (15.0 | ) |  | (2.7 | ) |  | (0.1 | ) |  | — |  |  | (17.8 | ) |
| Borrowings from credit facility | 1,391.0 |  |  | — |  |  | — |  |  | — |  |  | 1,391.0 |  |
| Payments on credit facility | (1,042.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,042.0 | ) |
| Proceeds from employee stock purchases | 1.2 |  |  | — |  |  | — |  |  | — |  |  | 1.2 |  |
| Repurchases of common stock | (350.2 | ) |  | — |  |  | — |  |  | — |  |  | (350.2 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (18.6 | ) |  | — |  |  | — |  |  | — |  |  | (18.6 | ) |
| Intercompany financing activity | (11.2 | ) |  | 38.2 |  |  | (27.0 | ) |  | — |  |  | — |  |
| Cash dividends paid | (42.4 | ) |  | — |  |  | — |  |  | — |  |  | (42.4 | ) |
| Net cash (used in) provided by financing activities | (87.2 | ) |  | 35.5 |  |  | (10.2 | ) |  | — |  |  | (61.9 | ) |
| Decrease in cash and cash equivalents | — |  |  | (5.4 | ) |  | (23.0 | ) |  | — |  |  | (28.4 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Cash and cash equivalents, beginning of period | 1.6 |  |  | 28.0 |  |  | 38.6 |  |  | — |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 1.6 |  |  | $ | 22.6 |  |  | $ | 15.2 |  |  | $ | — |  |  | $ | 39.4 |  |


## us-gaap:SubsequentEventsTextBlock

[0001069202-19-000030:notes:218]
Subsequent Event:

[0001069202-19-000030:notes:219]
In July 2019, we repurchased 0.5 million shares of our common stock for $150.0 million under the Share Repurchase Plans through transactions pursuant to a Rule 10b5-1 trading plan.
