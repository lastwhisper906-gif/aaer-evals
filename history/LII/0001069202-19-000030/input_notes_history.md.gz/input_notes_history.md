# LII note change history — 0001069202-19-000021 → 0001069202-19-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-07-22):
[0001069202-19-000030:note_history:1]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). We adopted ASC 842 on January 1, 2019, using the effective date method, with the cumulative-effect adjustment to the opening balance sheet of retained earnings as of the effective date. The financial results reported in periods prior to January 1, 2019 are unchanged.  Upon adoption, we recognized almost all of our leases greater than one year in duration on the balance sheet as right-of-use assets and lease liabilities. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification is based on criteria that are largely similar to those applied in current lease accounting standard, but without explicit bright lines. We have made certain assumptions in judgments when applying ASC 842.  Those judgments of most significance are as follows:
  (was, 2019-04-22, similarity 0.9948):
[0001069202-19-000021:note_history:1]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). We adopted ASC 842 on January 1, 2019, using the effective date method, with the cumulative-effect adjustment to the opening balance sheet of retained earnings as of the effective date. The financial results reported in periods prior to January 1, 2019 are unchanged.  Upon adoption, we recognized almost all of our leases greater than one year in duration on the balance sheet as right-of-use assets and lease liabilities. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification is based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines. We have made certain assumptions in judgments when applying ASC 842.  Those judgments of most significance are as follows:

- changed (2019-07-22):
[0001069202-19-000030:note_history:2]
|  | For the Three Months Ended June 30, 2019 |  | For the Six Months Ended June 30, 2019 |
| Finance lease cost: |  |  |  |
| Amortization of right-of-use assets | $ | 1.8 |  |  | $ | 3.3 |  |
| Interest on lease liabilities | 0.2 |  |  | 0.3 |  |
| Operating lease cost | 14.9 |  |  | 29.3 |  |
| Short-term lease cost | 1.2 |  |  | 2.3 |  |
| Variable lease cost | 5.2 |  |  | 10.1 |  |
| Total lease cost | $ | 23.3 |  |  | $ | 45.3 |  |
| Other information |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 14.7 |  |  | $ | 27.4 |  |
| Financing cash flows from finance leases | $ | 2.3 |  |  | $ | 3.8 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 2.8 |  |  | $ | 6.0 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 5.0 |  |  | $ | 21.6 |  |
  (was, 2019-04-22, similarity 0.6422):
[0001069202-19-000021:note_history:2]
|  | For the Three Months Ended March 31, 2019 |
| Finance lease cost: |  |
| Amortization of right-of-use assets | $ | 1.5 |  |
| Interest on lease liabilities | 0.2 |  |
| Operating lease cost | 14.8 |  |
| Short-term lease cost | 1.1 |  |
| Variable lease cost | 4.5 |  |
| Total lease cost | $ | 22.1 |  |
| Other information |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |
| Operating cash flows from finance leases | $ | 1.0 |  |
| Operating cash flows from operating leases | $ | 12.7 |  |
| Financing cash flows from finance leases | $ | 1.6 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 3.2 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 16.6 |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:3]
|  | As of June 30, 2019 |
| Finance lease right-of-use assets | 23.9 |  |
| Operating lease right-of-use assets | 166.2 |  |
| Finance lease liability, current | 6.6 |  |
| Finance lease liability, non-current | 23.4 |  |
| Operating lease liability, current | 49.6 |  |
| Operating lease liability, non-current | 117.6 |  |
| Weighted-average remaining lease term - finance leases | 5.31 years |  |
| Weighted-average remaining lease term - operating leases | 4.25 years |  |
| Weighted-average discount rate - finance leases | 2.18 | % |
| Weighted-average discount rate – operating leases | 3.97 | % |
  (was, 2019-04-22, similarity 0.992):
[0001069202-19-000021:note_history:3]
|  | As of March 31, 2019 |
| Finance lease right-of-use assets | 22.7 |  |
| Operating lease right-of-use assets | 170.1 |  |
| Finance lease liability, current | 6.3 |  |
| Finance lease liability, non-current | 22.3 |  |
| Operating lease liability, current | 48.1 |  |
| Operating lease liability, non-current | 122.6 |  |
| Weighted-average remaining lease term - finance leases | 5.46 years |  |
| Weighted-average remaining lease term - operating leases | 4.37 years |  |
| Weighted-average discount rate - finance leases | 2.23 | % |
| Weighted-average discount rate – operating leases | 4.05 | % |

- changed (2019-07-22):
[0001069202-19-000030:note_history:4]
Future annual minimum lease payments and finance lease commitments as of June 30, 2019 were as follows (in millions):
  (was, 2019-04-22, similarity 0.9156):
[0001069202-19-000021:note_history:4]
Future annual minimum lease payments and capital lease commitments as of March 31, 2019 were as follows (in millions):

- changed (2019-07-22):
[0001069202-19-000030:note_history:5]
|  | Operating Leases |  | Finance Leases |
| 2019 (excluding the six months ended June 30, 2019) | $ | 28.5 |  |  | $ | 3.7 |  |
| 2020 | 50.9 |  |  | 6.5 |  |
| 2021 | 37.8 |  |  | 4.9 |  |
| 2022 | 25.8 |  |  | 3.1 |  |
| 2023 | 19.7 |  |  | 1.2 |  |
| 2024 and thereafter | 19.2 |  |  | 11.7 |  |
| Total minimum lease payments | $ | 181.9 |  |  | $ | 31.1 |  |
| Less imputed interest | (14.7 | ) |  | (1.1 | ) |
| Lease liability | $ | 167.2 |  |  | $ | 30.0 |  |
  (was, 2019-04-22, similarity 0.9771):
[0001069202-19-000021:note_history:5]
|  | Operating Leases |  | Finance Leases |
| 2019 (excluding the three months ended March 31, 2019) | $ | 41.5 |  |  | $ | 5.5 |  |
| 2020 | 48.4 |  |  | 6.3 |  |
| 2021 | 35.7 |  |  | 4.5 |  |
| 2022 | 24.5 |  |  | 2.7 |  |
| 2023 | 18.7 |  |  | 1.3 |  |
| 2024 and thereafter | 18.6 |  |  | 12.9 |  |
| Total minimum lease payments | $ | 187.4 |  |  | $ | 33.2 |  |
| Less imputed interest | (16.7 | ) |  | (4.6 | ) |
| Lease liability | $ | 170.7 |  |  | $ | 28.6 |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:6]
|  | Operating Leases |  | Capital Leases |
| 2019 | $ | 47.4 |  |  | $ | 6.6 |  |
| 2020 | 38.4 |  |  | 5.4 |  |
| 2021 | 27.2 |  |  | 3.8 |  |
| 2022 | 17.9 |  |  | 2.1 |  |
| 2023 | 12.7 |  |  | 0.9 |  |
| Thereafter | 16.1 |  |  | 12.8 |  |
| Total minimum lease payments | $ | 159.7 |  |  | $ | 31.6 |  |
| Less amount representing interest |  |  | (2.1 | ) |
| Present value of minimum payments |  |  | $ | 29.5 |  |
  (was, 2019-04-22, similarity 0.9865):
[0001069202-19-000021:note_history:6]
|  | Operating Leases |  | Capital Leases |
| 2019 | $ | 47.4 |  |  | $ | 6.6 |  |
| 2020 | 38.4 |  |  | 5.4 |  |
| 2021 | 27.2 |  |  | 3.8 |  |
| 2022 | 17.9 |  |  | 2.1 |  |
| 2023 | 12.7 |  |  | 0.9 |  |
| Thereafter | 16.1 |  |  | 12.8 |  |
| Total minimum lease payments | $ | 159.7 |  |  | $ | 31.6 |  |
| Less amount representing interest |  |  | 2.1 |  |
| Present value of minimum payments |  |  | $ | 29.5 |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:7]
Our obligations under the headquarters lease are secured by a pledge of our interest in the leased property.  The lease contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of June 30, 2019.
  (was, 2019-04-22, similarity 0.9908):
[0001069202-19-000021:note_history:7]
Our obligations under the headquarters lease are secured by a pledge of our interest in the leased property.  The lease contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of March 31, 2019.

- changed (2019-07-22):
[0001069202-19-000030:note_history:8]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Accrued expenses | $ | 37.6 |  |  | $ | 37.9 |  |
| Other liabilities | 76.3 |  |  | 73.7 |  |
| Total warranty liability | $ | 113.9 |  |  | $ | 111.6 |  |
  (was, 2019-04-22, similarity 0.9741):
[0001069202-19-000021:note_history:8]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Accrued expenses | $ | 37.4 |  |  | $ | 37.9 |  |
| Other liabilities | 76.4 |  |  | 73.7 |  |
| Total warranty liability | $ | 113.8 |  |  | $ | 111.6 |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:9]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2019 were as follows (in millions):
  (was, 2019-04-22, similarity 0.9404):
[0001069202-19-000021:note_history:9]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2019 were as follows (in millions):

- added (2019-07-22):
[0001069202-19-000030:note_history:10]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Warranty claims paid | (15.3 | ) |
| Changes resulting from issuance of new warranties | 22.2 |  |
| Changes in estimates associated with pre-existing liabilities | (4.1 | ) |
| Changes in foreign currency translation rates and other | 0.1 |  |
| Warranty liability from divestitures | (0.6 | ) |
| Total warranty liability as of June 30, 2019 | $ | 113.9 |  |

- added (2019-07-22):
[0001069202-19-000030:note_history:11]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect was isolated, the vendor is supplying corrected components, and we are manufacturing products with the corrected components. We incurred and recorded expenses associated with this product quality in 2017. In the second quarter of 2019, the vendor agreed to reimburse us for certain losses incurred due to this quality issue.  These reimbursements will include cash payments in 2019 and price reductions on annual qualifying purchases from this vendor through 2024. The total reimbursements we receive from the vendor should off set the cost we have incurred related to this product quality matter.

- changed (2019-07-22):
[0001069202-19-000030:note_history:12]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and
  (was, 2019-04-22, similarity 0.8423):
[0001069202-19-000021:note_history:12]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2019 and 2018, expense for asbestos-related litigation was $1.4 million and $2.1 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

- added (2019-07-22):
[0001069202-19-000030:note_history:13]
judgments. For the three months ended June 30, 2019 and 2018, expense for asbestos-related litigation was $0.4 million and $(0.2) million and for the six months ended June 30, 2019 and 2018, expense for asbestos-related litigation was $1.8 million and $1.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

- added (2019-07-22):
[0001069202-19-000030:note_history:14]
| (Amounts in millions) | For the Three months Ended June 30, 2019 |  | For the Six months Ended June 30, 2019 |
| Insurance recoveries received | $ | 52.0 |  |  | $ | 128.0 |  |
| Less losses and expenses incurred: |  |  |  |
| Site clean-up and remediation | 6.2 |  |  | 23.3 |  |
| Factory inefficiencies due to lower productivity | 4.5 |  |  | 8.0 |  |
| Other | 9.4 |  |  | 18.4 |  |
| Total losses and expenses | $ | 20.1 |  |  | $ | 49.7 |  |
| Total gain from insurance recoveries | $ | 31.9 |  |  | $ | 78.3 |  |
| Presentation in the Consolidated Statements of Operations: |  |  |  |
| Insurance proceeds for lost profits | (26.0 | ) |  | (65.5 | ) |
| Gain from insurance recoveries, net of losses incurred | (5.9 | ) |  | (12.8 | ) |

- removed (2019-07-22):
[0001069202-19-000021:note_history:15]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Warranty claims paid | (5.9 | ) |
| Changes resulting from issuance of new warranties | 8.7 |  |
| Warranty liability from divestitures | (0.6 | ) |
| Total warranty liability as of March 31, 2019 | $ | 113.8 |  |

- removed (2019-07-22):
[0001069202-19-000021:note_history:16]
| (Amounts in millions) | For the Three months Ended March 31, 2019 |
| Insurance recoveries received | $ | 76.0 |  |
| Less losses and expenses incurred: |  |
| Site clean-up and remediation | 17.1 |  |
| Factory inefficiencies due to lower productivity | 4.0 |  |
| Other | 8.5 |  |
| Total losses and expenses | $ | 29.6 |  |
| Total gain from insurance recoveries | $ | 46.4 |  |
| Presentation in the Consolidated Statements of Operations: |  |
| Gain from insurance recoveries, net of losses incurred | $ | (6.9 | ) |
| Insurance proceeds for lost profits | $ | (39.5 | ) |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-07-22):
[0001069202-19-000030:note_history:17]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2019, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Stockholders' (Deficit) Equity for the three and six months ended June 30, 2019 and 2018, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2019 and 2018 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2018. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2019-04-22, similarity 0.9444):
[0001069202-19-000021:note_history:17]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2019, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2019 and 2018, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2019 and 2018, the accompanying unaudited Consolidated Statements of Stockholders' (Deficit) Equity for the three months ended March 31, 2019 and 2018, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2019 and 2018 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2018. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2019-07-22):
[0001069202-19-000030:note_history:18]
We adopted other new accounting standards during the first quarter of 2019. The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.
  (was, 2019-04-22, similarity 0.9873):
[0001069202-19-000021:note_history:18]
We also adopted other new accounting standards during the first quarter of 2019. The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-22):
[0001069202-19-000030:note_history:19]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.63 | % |  | 3.74 | % |
  (was, 2019-04-22, similarity 0.9538):
[0001069202-19-000021:note_history:19]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.68 | % |  | 3.74 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-22):
[0001069202-19-000030:note_history:20]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.6 |  |  | $ | 3.5 |  |
| Domestic credit facility | 15.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 311.0 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 23.4 |  |  | 15.7 |  |
| Domestic credit facility | 785.0 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.6 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,155.8 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,466.8 |  |  | $ | 1,041.3 |  |
  (was, 2019-04-22, similarity 0.9929):
[0001069202-19-000021:note_history:20]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 224.5 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.3 |  |  | $ | 3.5 |  |
| Domestic credit facility | 7.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.7 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 237.6 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 22.3 |  |  | 15.7 |  |
| Domestic credit facility | 689.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.8 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,059.0 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,296.6 |  |  | $ | 1,041.3 |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:21]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2019 or December 31, 2018.  There were no significant proceeds or repayments on these facilities for the six months ended June 30, 2019.  Proceeds and repayments on these facilities were $21.3 million and $18.4 million, respectively, for the six months ended June 30, 2018.
  (was, 2019-04-22, similarity 0.8664):
[0001069202-19-000021:note_history:21]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2019 or December 31, 2018.  There were no proceeds or repayments on these facilities for the three months ended March 31, 2019.  Proceeds and repayments on these facilities were $0.3 million and $0.4 million, respectively, for the three months ended March 31, 2018.

- changed (2019-07-22):
[0001069202-19-000030:note_history:22]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 290.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (290.0 | ) |  | (268.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 22.0 |  |
  (was, 2019-04-22, similarity 0.9165):
[0001069202-19-000021:note_history:22]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 225.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (224.5 | ) |  | (268.0 | ) |
| Remaining amount available | $ | 0.5 |  |  | $ | 22.0 |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:23]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2019 and December 31, 2018 were 3.11% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2019-04-22, similarity 0.994):
[0001069202-19-000021:note_history:23]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2019 and December 31, 2018 were 3.26% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2019-07-22):
[0001069202-19-000030:note_history:24]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2019, we believe we were in compliance with all covenant requirements.
  (was, 2019-04-22, similarity 0.9918):
[0001069202-19-000021:note_history:24]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of March 31, 2019, we believe we were in compliance with all covenant requirements.

- changed (2019-07-22):
[0001069202-19-000030:note_history:25]
On January 22, 2019, we amended our credit facility with the Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $190.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $800.0 million, of which $160.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of June 30, 2019. Subject to covenant limitations, $357.5 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.
  (was, 2019-04-22, similarity 0.9945):
[0001069202-19-000021:note_history:25]
On January 22, 2019, we amended our credit facility with the Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $190.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $697.0 million, of which $160.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of March 31, 2019. Subject to covenant limitations, $460.5 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

- changed (2019-07-22):
[0001069202-19-000030:note_history:26]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.63 | % |  | 3.74 | % |
  (was, 2019-04-22, similarity 0.9538):
[0001069202-19-000021:note_history:26]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.68 | % |  | 3.74 | % |

- changed (2019-07-22):
[0001069202-19-000030:note_history:27]
and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2019, we believe we were in compliance with all covenant requirements.
  (was, 2019-04-22, similarity 0.9703):
[0001069202-19-000021:note_history:27]
and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2019, we believe we were in compliance with all covenant requirements.

- changed (2019-07-22):
[0001069202-19-000030:note_history:28]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2019, we believe we were in compliance with all covenant requirements.
  (was, 2019-04-22, similarity 0.9954):
[0001069202-19-000021:note_history:28]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2019, we believe we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-22):
[0001069202-19-000030:note_history:29]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.6 |  |  | $ | 3.5 |  |
| Domestic credit facility | 15.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 311.0 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 23.4 |  |  | 15.7 |  |
| Domestic credit facility | 785.0 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.6 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,155.8 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,466.8 |  |  | $ | 1,041.3 |  |
  (was, 2019-04-22, similarity 0.9929):
[0001069202-19-000021:note_history:29]
|  | As of March 31, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 224.5 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.3 |  |  | $ | 3.5 |  |
| Domestic credit facility | 7.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.7 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 237.6 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 22.3 |  |  | 15.7 |  |
| Domestic credit facility | 689.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.8 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,059.0 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,296.6 |  |  | $ | 1,041.3 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-07-22):
[0001069202-19-000030:note_history:30]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue.  See Note 16 for additional information on our reportable business segments and the products and services sold in each segment.
  (was, 2019-04-22, similarity 0.7026):
[0001069202-19-000021:note_history:30]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue.  See Note 16 for additional description of our reportable business segments and the products and services being sold in each segment.

- added (2019-07-22):
[0001069202-19-000030:note_history:31]
|  | For the Three Months Ended June 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 647.2 |  |  | $ | 239.1 |  |  | $ | 80.0 |  |  | $ | 966.3 |  |
| Canada | 41.9 |  |  | 21.9 |  |  | — |  |  | 63.8 |  |
| International | — |  |  | 0.3 |  |  | 68.7 |  |  | 69.0 |  |
| Total | $ | 689.1 |  |  | 261.3 |  |  | 148.7 |  |  | 1,099.1 |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:32]
|  | For the Three Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 663.6 |  |  | $ | 229.8 |  |  | $ | 112.7 |  |  | $ | 1,006.1 |  |
| Canada | 52.4 |  |  | 21.6 |  |  | 1.1 |  |  | 75.1 |  |
| International | — |  |  | 0.7 |  |  | 93.5 |  |  | 94.2 |  |
| Total | $ | 716.0 |  |  | 252.1 |  |  | 207.3 |  |  | 1,175.4 |  |
  (was, 2019-04-22, similarity 0.6089):
[0001069202-19-000021:note_history:32]
|  | For the Three Months Ended March 31, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 433.2 |  |  | $ | 157.3 |  |  | $ | 91.6 |  |  | $ | 682.1 |  |
| Canada | 32.4 |  |  | 15.9 |  |  | 0.7 |  |  | 49.0 |  |
| International | — |  |  | 0.1 |  |  | 59.1 |  |  | 59.2 |  |
| Total | $ | 465.6 |  |  | 173.3 |  |  | 151.4 |  |  | 790.3 |  |

- added (2019-07-22):
[0001069202-19-000030:note_history:33]
|  | For the Six Months Ended June 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,080.3 |  |  | $ | 396.4 |  |  | $ | 171.6 |  |  | $ | 1,648.3 |  |
| Canada | 74.3 |  |  | 37.8 |  |  | 0.7 |  |  | 112.8 |  |
| International | — |  |  | 0.5 |  |  | 127.8 |  |  | 128.3 |  |
| Total | $ | 1,154.6 |  |  | 434.7 |  |  | 300.1 |  |  | 1,889.4 |  |

- added (2019-07-22):
[0001069202-19-000030:note_history:34]
|  | For the Six Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,087.1 |  |  | $ | 392.1 |  |  | $ | 208.4 |  |  | $ | 1,687.6 |  |
| Canada | 82.6 |  |  | 38.3 |  |  | 2.0 |  |  | 122.9 |  |
| International | — |  |  | 0.8 |  |  | 198.9 |  |  | 199.7 |  |
| Total | $ | 1,169.7 |  |  | 431.2 |  |  | 409.3 |  |  | 2,010.2 |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:35]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the segment, for the three months ended June 30, 2019 and 2018, direct sales represent approximately $515.2 million and $546.7 million of revenues, and sales to independent distributors represent approximately $173.9 million and $169.3 million of revenues, respectively. For the six months ended June 30, 2019 and 2018, direct sales represent approximately $849.8 million and $886.3 million of revenues, and sales to independent distributors represent approximately $304.8 million and $283.4 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2019-04-22, similarity 0.7837):
[0001069202-19-000021:note_history:35]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the segment, for the three months ended March 31, 2019 and 2018, direct sales represent approximately $334.7 million and $339.5 million of revenues, and sales to independent distributors represent approximately $130.9 million and $114.2 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2019-07-22):
[0001069202-19-000030:note_history:36]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.    For the segment, for the three months ended June 30, 2019 and 2018, equipment sales represent approximately $226.6 million and $218.7 million of revenues while $34.7 million and $33.4 million of our revenue is generated from our service business, respectively. For the six months ended June 30, 2019 and 2018, equipment sales represent approximately $370.2 million and $370.2 million of revenues while $64.5 million and $61.0 million of our revenue is generated from our service business, respectively.
  (was, 2019-04-22, similarity 0.9081):
[0001069202-19-000021:note_history:36]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.    For the segment, for the three months ended March 31, 2019 and 2018, equipment sales represent approximately $143.5 million and $151.5 million of revenues while $29.8 million and $27.6 million of our revenue is generated from our service business, respectively.

- changed (2019-07-22):
[0001069202-19-000030:note_history:37]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems.  Revenue for the products sold is $148.2 million and $205.5 million for the three months ended June 30, 2019 and 2018 and $297.1 million and $405.5 million for the six months ended June 30, 2019 and 2018, respectively and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.
  (was, 2019-04-22, similarity 0.6943):
[0001069202-19-000021:note_history:37]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems.  Revenue for the products sold is $148.9 million and $200.0 million for the three months ended March 31, 2019 and 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

- changed (2019-07-22):
[0001069202-19-000030:note_history:38]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.
  (was, 2019-04-22, similarity 0.7502):
[0001069202-19-000021:note_history:38]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or

- changed (2019-07-22):
[0001069202-19-000030:note_history:39]
|  | June 30, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (4.9 | ) |  | (13.0 | ) |  | 8.1 |  |  | (62.2 | )% |
| Contract liabilities - noncurrent | (6.0 | ) |  | (5.9 | ) |  | (0.1 | ) |  | 1.7 | % |
| Total | $ | (10.9 | ) |  | $ | (16.4 | ) |  | $ | 5.5 |  |  |  |
  (was, 2019-04-22, similarity 0.9424):
[0001069202-19-000021:note_history:39]
|  | March 31, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (5.4 | ) |  | (13.0 | ) |  | 7.6 |  |  | (58.5 | )% |
| Contract liabilities - noncurrent | (5.7 | ) |  | (5.9 | ) |  | 0.2 |  |  | (3.4 | )% |
| Total | $ | (11.1 | ) |  | $ | (16.4 | ) |  | $ | 5.3 |  |  |  |

- changed (2019-07-22):
[0001069202-19-000030:note_history:40]
For the three months ended June 30, 2019 and 2018, we recognized revenue of $1.5 million and $1.3 million and for the six months ended June 30, 2019 and 2018, we recognized revenue of $2.6 million and $2.9 million related to our contract liabilities at January 1, 2019 and  2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the second quarter of 2019 and 2018.
  (was, 2019-04-22, similarity 0.8244):
[0001069202-19-000021:note_history:40]
For the three months ended March 31, 2019 and 2018, we recognized revenue of $1.1 million and $1.6 million related to our contract liabilities at January 1, 2019 and  2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the first quarter of 2019 and 2018.

- removed (2019-07-22):
[0001069202-19-000021:note_history:41]
|  | For the Three Months Ended March 31, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 423.5 |  |  | $ | 162.3 |  |  | $ | 95.7 |  |  | $ | 681.5 |  |
| Canada | 30.2 |  |  | 16.7 |  |  | 0.9 |  |  | 47.8 |  |
| International | — |  |  | 0.1 |  |  | 105.4 |  |  | 105.5 |  |
| Total | $ | 453.7 |  |  | 179.1 |  |  | 202.0 |  |  | 834.8 |  |

- removed (2019-07-22):
[0001069202-19-000021:note_history:42]
services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-07-22):
[0001069202-19-000030:note_history:43]
In July 2019, we repurchased 0.5 million shares of our common stock for $150.0 million under the Share Repurchase Plans through transactions pursuant to a Rule 10b5-1 trading plan.

- removed (2019-07-22):
[0001069202-19-000021:note_history:44]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and the related benefit obligations.  This transaction required a remeasurement of the pension plan and we expect to recognize a $61.0 million non-cash pension settlement pre-tax loss in the second quarter of 2019 for this remeasurement.
