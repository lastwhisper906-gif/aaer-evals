# LII 8-K — 0001193125-15-346279 filed 2015-10-19

## item codes, every 8-K on or before 2015-10-19

- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2015-10-19

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-346279:8k_2_02:1]
EX-99.1
2
d55803dex991.htm
EX-99.1

[0001193125-15-346279:8k_2_02:2]
EX-99.1

[0001193125-15-346279:8k_2_02:3]
Exhibit 99.1

[0001193125-15-346279:8k_2_02:4]
Lennox International Reports Record Third-Quarter Profit

[0001193125-15-346279:8k_2_02:5]
| • |  | Revenue up 6%, and up 11% at constant currency |

[0001193125-15-346279:8k_2_02:6]
| • |  | Adjusted EPS from continuing operations up 26% to $1.82 |

[0001193125-15-346279:8k_2_02:7]
| • |  | GAAP EPS from continuing operations up 28% to $1.76 |

[0001193125-15-346279:8k_2_02:8]
| • |  | Narrowing 2015 revenue growth at constant currency guidance range from 4-7% to 5-7% |

[0001193125-15-346279:8k_2_02:9]
| • |  | Narrowing 2015 adjusted EPS from continuing operations guidance range from $5.25-$5.50 to $5.25-$5.40 |

[0001193125-15-346279:8k_2_02:10]
DALLAS, October 19, 2015 – Lennox International Inc. (NYSE: LII) today reported financial results for the third quarter of 2015. Financial results
reflect sold businesses in discontinued operations.

[0001193125-15-346279:8k_2_02:11]
Revenue for the third quarter was $955 million, up 6% from the prior-year quarter including the
negative impact from foreign exchange. At constant currency, revenue was up 11%. Adjusted earnings per share from continuing operations was a third-quarter record $1.82, up 26% from the prior-year quarter. On a GAAP basis, earnings per share from
continuing operations was a third-quarter record $1.76, up 28% from the prior-year quarter.

[0001193125-15-346279:8k_2_02:12]
“Lennox International realized strong revenue growth at
constant currency and significant margin expansion across all three of our businesses in the third quarter,” said Chairman and CEO Todd Bluedorn. “For the company overall, total segment profit set a third-quarter record, and profit margin
expanded 140 basis points from the prior-year quarter to a record level of 13.7%. Our Residential business set third-quarter records for revenue, margin and profit as strong business momentum continued. Residential revenue was up 13% at constant
currency, and margin expanded 240 basis points to 17.4%. In Commercial, segment profit and margin set new highs on 8% revenue growth at constant currency. North America and Europe both saw high single-digit revenue growth at constant currency.
Commercial segment margin expanded 70 basis points to 18.2%. In Refrigeration, revenue was up 8% at constant currency, with double-digit growth in North America and Europe. Refrigeration margin expanded 220 basis points from the prior-year quarter
to 10.7%.

[0001193125-15-346279:8k_2_02:13]
“Looking ahead for the company overall, we now expect revenue growth of 5-7% at constant currency for the full year. We are narrowing 2015
guidance for adjusted EPS from continuing operations to $5.25-$5.40. The company is well-positioned for continued momentum in the fourth quarter and as we look ahead to 2016. We remain focused on capitalizing on end market growth, capturing
additional market share, and driving operational initiatives for higher profitability.”

[0001193125-15-346279:8k_2_02:14]
FINANCIAL HIGHLIGHTS

[0001193125-15-346279:8k_2_02:15]
Revenue: Revenue for the third quarter was $955 million, up 6% from the prior-year quarter. At constant currency, revenue was up 11%. Volume and
price/mix were up on a revenue basis from the prior-year quarter.

[0001193125-15-346279:8k_2_02:16]
Gross Profit: Gross profit in the third quarter was $273 million, up 11% from
$247 million in the prior-year quarter. Gross margin was 28.6%, up 110 basis points from 27.5% in the prior-year quarter. Gross profit was positively impacted by higher volume, favorable price, lower material costs, and higher productivity, with
partial offsets from negative mix, unfavorable foreign exchange, and investments in distribution expansion.

[0001193125-15-346279:8k_2_02:17]
Income from Continuing Operations:
Adjusted income from continuing operations in the third quarter was $83.2 million, or $1.82 per share, compared to $70.3 million, or $1.44 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the third quarter of
2015 excludes $2.9 million in after-tax charges: $0.8 million for special legal contingency charges, $0.7 million related to contractor tax payments in a non-U.S. subsidiary, $0.5 million for the net change in unrealized losses on unsettled future
contracts, and $0.9 million, net, for other items.

[0001193125-15-346279:8k_2_02:18]
On a GAAP basis, income from continuing operations for the third quarter was $80.3 million, or $1.76
per share, compared to $67.5 million, or $1.38 per share, in the prior-year quarter.

[0001193125-15-346279:8k_2_02:19]
Free Cash Flow and Total Debt: Net cash from operations in
the third quarter was $159 million compared to $97 million in the prior-year quarter. Capital expenditures were $14 million in the third quarter compared to $19 million in the third quarter a year ago. Free cash flow was $145 million compared to $78
million in the prior-year quarter. Total debt at the end of the third quarter was $918 million. Total cash and cash equivalents were $35 million at the end of the quarter. The company paid $16 million in dividends in the third quarter. The
company’s previously announced $450 million accelerated stock repurchase program continues and will be completed in the fourth quarter of 2015.

[0001193125-15-346279:8k_2_02:20]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-15-346279:8k_2_02:21]
Residential Heating & Cooling

[0001193125-15-346279:8k_2_02:22]
Revenue in the
Residential Heating & Cooling business segment was a third-quarter record $518 million, up 12% from the prior-year quarter. At constant currency, revenue was up 13%. Segment profit was a third-quarter record $90 million, up 30% from the
prior-year quarter. Segment profit margin was a third-quarter record 17.4%, up 240 basis points from the prior-year quarter. Results were impacted by higher volume, favorable price/mix, lower material costs, and higher productivity, with partial
offsets from unfavorable foreign exchange and investments in SG&A and distribution expansion.

[0001193125-15-346279:8k_2_02:23]
Commercial Heating & Cooling

[0001193125-15-346279:8k_2_02:24]
Revenue in the Commercial Heating & Cooling business segment was $247 million in the third quarter, up 2% from the prior-year quarter. At constant
currency, revenue was up 8%. Segment profit was a record $45 million, up 6% from the prior-year quarter. Segment profit margin was a record 18.2%, up 70 basis points from the prior-year quarter. Results were impacted by higher volume, favorable
price, and lower material costs, with partial offsets from unfavorable mix, unfavorable foreign exchange, and investments in SG&A.

[0001193125-15-346279:8k_2_02:25]
Refrigeration

[0001193125-15-346279:8k_2_02:26]
Revenue in the Refrigeration business segment was $190 million in the third quarter, down 2%. At constant currency, revenue was up 8%. Segment profit
was $20 million, up 23% from the prior-year quarter. Segment profit margin was 10.7%, up 220 basis points from the prior-year quarter. Results were impacted by higher volume, favorable price, lower material costs, lower SG&A and higher
productivity, with partial offsets from unfavorable mix in North America supermarket business and unfavorable foreign exchange.

[0001193125-15-346279:8k_2_02:27]
FULL-YEAR OUTLOOK

[0001193125-15-346279:8k_2_02:28]
For 2015, the company is narrowing guidance for revenue and adjusted EPS from continuing operations.

[0001193125-15-346279:8k_2_02:29]
|  | • |  | Narrowing revenue growth guidance at constant currency from 4-7% to 5-7%. |

[0001193125-15-346279:8k_2_02:30]
|  | • |  | Still expecting a negative 3 point impact on revenue from foreign exchange on a full-year basis, equating to revenue growth guidance of 2-4% at actual currency versus the prior guidance range of 1-4%. |

[0001193125-15-346279:8k_2_02:31]
|  | • |  | Narrowing adjusted EPS from continuing operations guidance from $5.25-$5.50 to $5.25-$5.40. |

[0001193125-15-346279:8k_2_02:32]
|  | • |  | Updating GAAP EPS from continuing operations guidance from $5.14-$5.39 to $5.08-$5.23. |

[0001193125-15-346279:8k_2_02:33]
|  | • |  | Reiterating effective tax rate guidance of 34-35% on a full-year basis. |

[0001193125-15-346279:8k_2_02:34]
|  | • |  | Reiterating capital expenditure guidance of approximately $80 million. |

[0001193125-15-346279:8k_2_02:35]
CONFERENCE CALL INFORMATION

[0001193125-15-346279:8k_2_02:36]
A conference call to discuss the company’s third quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call
line at 612-288-0340 at least 10 minutes prior to the scheduled start time and use reservation number 370024. The conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available
from 11:00 a.m. Central time on October 19 through October 26, 2015 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 370024. The call will also be archived on the company’s web site.

[0001193125-15-346279:8k_2_02:37]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International is listed on the New York Stock
Exchange and traded under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-15-346279:8k_2_02:38]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-346279:8k_2_02:39]
Consolidated Statements of Operations

[0001193125-15-346279:8k_2_02:40]
(Unaudited)

[0001193125-15-346279:8k_2_02:41]
| (Amounts in millions, except per share data) |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 955.0 |  |  | $ | 898.4 |  |  | $ | 2,633.3 |  |  | $ | 2,554.6 |  |
| Cost of goods sold |  |  | 681.6 |  |  |  | 651.3 |  |  |  | 1,913.5 |  |  |  | 1,876.7 |  |
| Gross profit |  |  | 273.4 |  |  |  | 247.1 |  |  |  | 719.8 |  |  |  | 677.9 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 143.8 |  |  |  | 140.9 |  |  |  | 430.0 |  |  |  | 425.5 |  |
| Losses (gains) and other expenses, net |  |  | 6.0 |  |  |  | 2.1 |  |  |  | 14.9 |  |  |  | 3.5 |  |
| Restructuring charges |  |  | (0.4 | ) |  |  | 1.0 |  |  |  | 1.8 |  |  |  | 1.3 |  |
| Income from equity method investments |  |  | (3.0 | ) |  |  | (3.5 | ) |  |  | (11.8 | ) |  |  | (12.0 | ) |
| Operational income from continuing operations |  |  | 127.0 |  |  |  | 106.6 |  |  |  | 284.9 |  |  |  | 259.6 |  |
| Interest expense, net |  |  | 5.7 |  |  |  | 4.0 |  |  |  | 17.9 |  |  |  | 11.0 |  |
| Other expense (income), net |  |  | (0.7 | ) |  |  | — |  |  |  | (0.7 | ) |  |  | — |  |
| Income from continuing operations before income taxes |  |  | 122.0 |  |  |  | 102.6 |  |  |  | 267.7 |  |  |  | 248.6 |  |
| Provision for income taxes |  |  | 41.7 |  |  |  | 35.1 |  |  |  | 91.9 |  |  |  | 86.6 |  |
| Income from continuing operations |  |  | 80.3 |  |  |  | 67.5 |  |  |  | 175.8 |  |  |  | 162.0 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | — |  |  |  | (0.2 | ) |  |  | (0.9 | ) |  |  | (1.3 | ) |
| Benefit from income taxes |  |  | — |  |  |  | (0.1 | ) |  |  | (0.4 | ) |  |  | (0.5 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | (0.1 | ) |  |  | (0.5 | ) |  |  | (0.8 | ) |
| Net income |  | $ | 80.3 |  |  | $ | 67.4 |  |  | $ | 175.3 |  |  | $ | 161.2 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.78 |  |  | $ | 1.40 |  |  | $ | 3.92 |  |  | $ | 3.33 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | (0.01 | ) |  |  | (0.02 | ) |
| Net income |  | $ | 1.78 |  |  | $ | 1.40 |  |  | $ | 3.91 |  |  | $ | 3.31 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.76 |  |  | $ | 1.38 |  |  | $ | 3.86 |  |  | $ | 3.27 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | (0.01 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 1.76 |  |  | $ | 1.38 |  |  | $ | 3.85 |  |  | $ | 3.26 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 45.0 |  |  |  | 48.3 |  |  |  | 44.9 |  |  |  | 48.7 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 45.6 |  |  |  | 49.0 |  |  |  | 45.6 |  |  |  | 49.5 |  |
| Cash dividends declared per share |  | $ | 0.36 |  |  | $ | 0.30 |  |  | $ | 1.02 |  |  | $ | 0.84 |  |

[0001193125-15-346279:8k_2_02:42]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-346279:8k_2_02:43]
Segment Net Sales and Profit (Loss)

[0001193125-15-346279:8k_2_02:44]
(Unaudited)

[0001193125-15-346279:8k_2_02:45]
| (Amounts in millions) |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 517.9 |  |  | $ | 462.6 |  |  | $ | 1,435.6 |  |  | $ | 1,332.5 |  |
| Commercial Heating & Cooling |  |  | 246.8 |  |  |  | 241.6 |  |  |  | 660.3 |  |  |  | 655.6 |  |
| Refrigeration |  |  | 190.3 |  |  |  | 194.2 |  |  |  | 537.4 |  |  |  | 566.5 |  |
|  |  | $ | 955.0 |  |  | $ | 898.4 |  |  | $ | 2,633.3 |  |  | $ | 2,554.6 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 90.1 |  |  | $ | 69.4 |  |  | $ | 221.3 |  |  | $ | 178.8 |  |
| Commercial Heating & Cooling |  |  | 44.8 |  |  |  | 42.2 |  |  |  | 95.5 |  |  |  | 91.3 |  |
| Refrigeration |  |  | 20.3 |  |  |  | 16.5 |  |  |  | 37.5 |  |  |  | 42.3 |  |
| Corporate and other |  |  | (24.0 | ) |  |  | (17.5 | ) |  |  | (57.4 | ) |  |  | (47.8 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 131.2 |  |  |  | 110.6 |  |  |  | 296.9 |  |  |  | 264.6 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | 0.7 |  |  |  | 0.2 |  |  |  | (0.6 | ) |  |  | (0.1 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 3.9 |  |  |  | 1.8 |  |  |  | 10.8 |  |  |  | 2.8 |  |
| Restructuring charges |  |  | (0.4 | ) |  |  | 1.0 |  |  |  | 1.8 |  |  |  | 1.3 |  |
| Interest expense, net |  |  | 5.7 |  |  |  | 4.0 |  |  |  | 17.9 |  |  |  | 11.0 |  |
| Special inventory write down |  |  | — |  |  |  | 1.0 |  |  |  | — |  |  |  | 1.0 |  |
| Other expense (income), net |  |  | (0.7 | ) |  |  | — |  |  |  | (0.7 | ) |  |  | — |  |
| Income from continuing operations before income taxes |  | $ | 122.0 |  |  | $ | 102.6 |  |  | $ | 267.7 |  |  | $ | 248.6 |  |

[0001193125-15-346279:8k_2_02:46]
| (1) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-15-346279:8k_2_02:47]
|  | • |  | Special product quality adjustments; |

[0001193125-15-346279:8k_2_02:48]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-15-346279:8k_2_02:49]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-15-346279:8k_2_02:50]
|  | • |  | Special legal contingency charges, |

[0001193125-15-346279:8k_2_02:51]
|  | • |  | Asbestos-related litigation, |

[0001193125-15-346279:8k_2_02:52]
|  | • |  | Contractor tax payments, |

[0001193125-15-346279:8k_2_02:53]
|  | • |  | Environmental liabilities, and |

[0001193125-15-346279:8k_2_02:54]
|  | • |  | Other items, net; |

[0001193125-15-346279:8k_2_02:55]
|  | • |  | Restructuring charges; |

[0001193125-15-346279:8k_2_02:56]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments; |

[0001193125-15-346279:8k_2_02:57]
|  | • |  | Interest expense, net; and |

[0001193125-15-346279:8k_2_02:58]
|  | • |  | Other expense, net. |

[0001193125-15-346279:8k_2_02:59]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-346279:8k_2_02:60]
Consolidated Balance Sheets

[0001193125-15-346279:8k_2_02:61]
| (Amounts in millions, except shares and par values) |  | As of September 30,2015 |  |  | As of December 31,2014 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 35.1 |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net of allowances of $7.3 and $7.9 in 2015 and 2014, respectively |  |  | 537.7 |  |  |  | 421.4 |  |
| Inventories, net |  |  | 488.3 |  |  |  | 463.3 |  |
| Deferred income taxes, net |  |  | 31.9 |  |  |  | 32.5 |  |
| Other assets |  |  | 58.9 |  |  |  | 59.3 |  |
| Total current assets |  |  | 1,151.9 |  |  |  | 1,014.0 |  |
| Property, plant and equipment, net of accumulated depreciation of $677.9 and $654.1 in 2015 and 2014, respectively |  |  | 345.3 |  |  |  | 358.6 |  |
| Goodwill |  |  | 199.8 |  |  |  | 209.4 |  |
| Deferred income taxes |  |  | 97.9 |  |  |  | 97.5 |  |
| Other assets, net |  |  | 86.6 |  |  |  | 84.8 |  |
| Total assets |  | $ | 1,881.5 |  |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 226.3 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt |  |  | 23.7 |  |  |  | 24.0 |  |
| Accounts payable |  |  | 337.7 |  |  |  | 324.3 |  |
| Accrued expenses |  |  | 251.9 |  |  |  | 239.0 |  |
| Income taxes payable |  |  | 13.8 |  |  |  | 13.4 |  |
| Total current liabilities |  |  | 853.4 |  |  |  | 827.3 |  |
| Long-term debt |  |  | 668.0 |  |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions |  |  | 2.9 |  |  |  | 4.5 |  |
| Pensions |  |  | 134.2 |  |  |  | 129.9 |  |
| Other liabilities |  |  | 125.5 |  |  |  | 118.6 |  |
| Total liabilities |  |  | 1,784.0 |  |  |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 857.3 |  |  |  | 824.9 |  |
| Retained earnings |  |  | 1,151.5 |  |  |  | 1,022.1 |  |
| Accumulated other comprehensive loss |  |  | (209.8 | ) |  |  | (153.5 | ) |
| Treasury stock, at cost, 42,120,067 shares and 42,535,126 shares in 2015 and 2014, respectively |  |  | (1,702.9 | ) |  |  | (1,686.0 | ) |
| Noncontrolling interests |  |  | 0.5 |  |  |  | 0.6 |  |
| Total stockholders’ equity |  |  | 97.5 |  |  |  | 9.0 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,881.5 |  |  | $ | 1,764.3 |  |

[0001193125-15-346279:8k_2_02:62]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-346279:8k_2_02:63]
Consolidated Statements of Cash Flows

[0001193125-15-346279:8k_2_02:64]
(Unaudited)

[0001193125-15-346279:8k_2_02:65]
| (Amounts in millions) |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 175.3 |  |  | $ | 161.2 |  |
| Net loss from discontinued operations |  |  | 0.5 |  |  |  | 0.8 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (11.8 | ) |  |  | (12.0 | ) |
| Dividends from affiliates |  |  | 7.4 |  |  |  | 6.1 |  |
| Restructuring expenses, net of cash paid |  |  | (0.2 | ) |  |  | (0.1 | ) |
| Provision for bad debts |  |  | 2.1 |  |  |  | 2.8 |  |
| Unrealized losses on derivative contracts |  |  | 1.3 |  |  |  | 0.1 |  |
| Stock-based compensation expense |  |  | 18.5 |  |  |  | 17.3 |  |
| Depreciation and amortization |  |  | 46.6 |  |  |  | 45.2 |  |
| Deferred income taxes |  |  | (0.2 | ) |  |  | 1.4 |  |
| Other items, net |  |  | 0.3 |  |  |  | 0.3 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (135.9 | ) |  |  | (104.0 | ) |
| Inventories |  |  | (41.0 | ) |  |  | (127.6 | ) |
| Other current assets |  |  | (2.8 | ) |  |  | (6.2 | ) |
| Accounts payable |  |  | 23.4 |  |  |  | 51.0 |  |
| Accrued expenses |  |  | 15.1 |  |  |  | 18.2 |  |
| Income taxes payable and receivable |  |  | (0.9 | ) |  |  | (21.1 | ) |
| Other |  |  | 9.7 |  |  |  | (9.1 | ) |
| Net cash used in discontinued operations |  |  | (0.5 | ) |  |  | (0.8 | ) |
| Net cash provided by operating activities |  |  | 106.9 |  |  |  | 23.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the discount of property, plant and equipment |  |  | — |  |  |  | 0.2 |  |
| Purchases of property, plant and equipment |  |  | (47.0 | ) |  |  | (59.9 | ) |
| Net cash used in investing activities |  |  | (47.0 | ) |  |  | (59.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 0.8 |  |  |  | 3.4 |  |
| Asset securitization borrowings |  |  | 40.0 |  |  |  | 60.0 |  |
| Asset securitization payments |  |  | (40.0 | ) |  |  | — |  |
| Long-term debt payments |  |  | (23.5 | ) |  |  | (1.7 | ) |
| Borrowings from credit facility |  |  | 1,401.0 |  |  |  | 1,483.0 |  |
| Payments on credit facility |  |  | (1,385.0 | ) |  |  | (1,351.0 | ) |
| Proceeds from employee stock purchases |  |  | 1.8 |  |  |  | 1.5 |  |
| Repurchases of common stock |  |  | — |  |  |  | (100.3 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (23.5 | ) |  |  | (12.3 | ) |
| Excess tax benefits related to share-based payments |  |  | 18.6 |  |  |  | 5.3 |  |
| Cash dividends paid |  |  | (43.1 | ) |  |  | (38.2 | ) |
| Net cash (used in) provided by financing activities |  |  | (52.9 | ) |  |  | 49.7 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 7.0 |  |  |  | 13.5 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (9.4 | ) |  |  | (3.4 | ) |
| Cash and cash equivalents, beginning of period |  |  | 37.5 |  |  |  | 38.0 |  |
| Cash and cash equivalents, end of period |  | $ | 35.1 |  |  | $ | 48.1 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 15.9 |  |  | $ | 9.5 |  |
| Income taxes paid (net of refunds) |  | $ | 73.4 |  |  | $ | 100.4 |  |

[0001193125-15-346279:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-346279:8k_2_02:67]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-15-346279:8k_2_02:68]
(Unaudited, in millions, except per share and ratio data)

[0001193125-15-346279:8k_2_02:69]
Use of Non-GAAP Financial Measures

[0001193125-15-346279:8k_2_02:70]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide
information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating
performance.

[0001193125-15-346279:8k_2_02:71]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-15-346279:8k_2_02:72]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Income from continuing operations, a GAAP measure |  | $ | 80.3 |  |  | $ | 67.5 |  |  | $ | 175.8 |  |  | $ | 162.0 |  |
| Restructuring charges, after tax |  |  | (0.3 | ) |  |  | 0.8 |  |  |  | 1.2 |  |  |  | 1.4 |  |
| Special product quality adjustments, after tax (b) |  |  | 0.5 |  |  |  | 0.1 |  |  |  | (0.4 | ) |  |  | (0.1 | ) |
| Special legal contingency charges, after tax (a) |  |  | 0.8 |  |  |  | 0.3 |  |  |  | 3.4 |  |  |  | 0.4 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.7 |  |  |  | 0.6 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | 0.5 |  |  |  | 0.2 |  |  |  | 0.5 |  |  |  | 0.1 |  |
| Inventory write down, after tax (b) |  |  | — |  |  |  | 0.8 |  |  |  | — |  |  |  | 0.8 |  |
| Environmental liabilities, after tax (a) |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 0.6 |  |  |  | 0.4 |  |
| Contractor Tax Payments (a) |  |  | 0.7 |  |  |  | — |  |  |  | 1.8 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.5 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 83.2 |  |  | $ | 70.3 |  |  | $ | 183.7 |  |  | $ | 166.1 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 1.76 |  |  | $ | 1.38 |  |  | $ | 3.86 |  |  | $ | 3.27 |  |
| Restructuring charges, after tax |  |  | (0.01 | ) |  |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.03 |  |
| Special product quality adjustments, after tax (b) |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Special legal contingency charges, after tax (a) |  |  | 0.02 |  |  |  | 0.01 |  |  |  | 0.08 |  |  |  | 0.01 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.02 |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Inventory write down, after tax (b) |  |  | — |  |  |  | 0.02 |  |  |  | — |  |  |  | 0.02 |  |
| Environmental liabilities, after tax (a) |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.02 |  |
| Contractor Tax Payments (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.03 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  | $ | 1.82 |  |  | $ | 1.44 |  |  | $ | 4.04 |  |  | $ | 3.36 |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.6 |  |  | $ | 0.1 |  |  | $ | 1.3 |  |  | $ | 0.6 |  |
| Foreign currency exchange losses (gains) (a) |  |  | 1.4 |  |  |  | 0.1 |  |  |  | 2.7 |  |  |  | 0.1 |  |
| Loss on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | 0.8 |  |  |  | 0.2 |  |  |  | 0.9 |  |  |  | 0.1 |  |
| Special legal contingency charges (b) |  |  | 1.3 |  |  |  | 0.5 |  |  |  | 5.5 |  |  |  | 0.7 |  |
| Asbestos-related litigation (b) |  |  | 0.4 |  |  |  | 0.4 |  |  |  | 1.0 |  |  |  | 1.0 |  |
| Environmental liabilities (b) |  |  | 0.3 |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 0.7 |  |
| Contractor Tax Payments (b) |  |  | 0.8 |  |  |  | — |  |  |  | 2.4 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.3 |  |  |  | — |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 6.0 |  |  | $ | 2.1 |  |  | $ | 14.9 |  |  | $ | 3.5 |  |

[0001193125-15-346279:8k_2_02:73]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-15-346279:8k_2_02:74]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-15-346279:8k_2_02:75]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-15-346279:8k_2_02:76]
|  |  | For the YearEndedDecember 31,2015ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 5.25 - $5.40 |  |
| Restructuring charges and other items |  |  | (0.17 | ) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 5.08 - $5.23 |  |

[0001193125-15-346279:8k_2_02:77]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars
in millions)

[0001193125-15-346279:8k_2_02:78]
|  |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 159.1 |  |  | $ | 96.9 |  |  | $ | 106.9 |  |  | $ | 23.5 |  |
| Purchases of property, plant and equipment |  |  | (13.9 | ) |  |  | (18.7 | ) |  |  | (47.0 | ) |  |  | (59.9 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 145.2 |  |  | $ | 78.4 |  |  | $ | 59.9 |  |  | $ | (36.2 | ) |

[0001193125-15-346279:8k_2_02:79]
|  |  | Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelveMonths toSeptember 30,2015 |  |
|  | Adjusted EBIT (a) |  | $ | 373.1 |  |
|  | Depreciation and amortization expense (b) |  |  | 62.2 |  |
|  | EBITDA (a + b) |  | $ | 435.3 |  |
|  | Total debt at September 30, 2015 (c) |  |  | 918.0 |  |
|  | Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.1 |  |

[0001193125-15-346279:8k_2_02:80]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP
measure (dollars in millions)

[0001193125-15-346279:8k_2_02:81]
|  |  | TrailingTwelve Months to September 30,2015 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 373.1 |  |
| Special product quality adjustments |  |  | (1.9 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 4.9 |  |
| Restructuring charges |  |  | 2.4 |  |
| Interest expense, net |  |  | 24.0 |  |
| Special inventory write down |  |  | — |  |
| Other expenses, net |  |  | (0.2 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 343.9 |  |
