# LII notes — 0001069202-15-000011


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-15-000011:notes:1]
[same as prior period, unchanged from 0001069202-15-000008:notes:1]

[0001069202-15-000011:notes:2]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 220.0 |  |  | 220.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-15-000011:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-15-000011:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-15-000011:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-15-000011:notes:6]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.69 | % |  | 1.88 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-15-000011:notes:7]
[same as prior period, unchanged from 0001069202-15-000008:notes:7]

[0001069202-15-000011:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2015, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2015 and 2014, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2015 and 2014, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2015 and 2014 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2014. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-15-000011:notes:9]
[same as prior period, unchanged from 0001069202-15-000008:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-15-000011:notes:10]
Commitments and Contingencies:

[0001069202-15-000011:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-15-000011:notes:12]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-15-000011:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000011:notes:14]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Accrued expenses | $ | 25.6 |  |  | $ | 27.3 |  |
| Other liabilities | 66.1 |  |  | 59.9 |  |
| Total warranty liability | $ | 91.7 |  |  | $ | 87.2 |  |

[0001069202-15-000011:notes:15]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2015 were as follows (in millions):

[0001069202-15-000011:notes:16]
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |
| Warranty claims paid | (19.7 | ) |
| Changes resulting from issuance of new warranties | 27.4 |  |
| Changes in estimates associated with pre-existing liabilities | (1.6 | ) |
| Changes in foreign currency translation rates and other | (1.6 | ) |
| Total warranty liability as of September 30, 2015 | $ | 91.7 |  |

[0001069202-15-000011:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable outstanding liability for a certain supplier quality issue within a range of $0.7 million and $4 million, with all amounts in that range equally likely.  In the prior quarter, we accrued a $1.7 million liability related to this supplier quality issue as well as a receivable from the supplier of $2.3 million.  In the third quarter of 2015, we recorded a $1.2 million expense to reduce this receivable from the supplier based on the nature and timing of warranty claims.  The supplier has previously reimbursed the Company for costs associated with this supplier quality issue and we expect that the supplier will continue to do so.

[0001069202-15-000011:notes:18]
Litigation

[0001069202-15-000011:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-15-000011:notes:20]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and is subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2015, and 2014, expense for asbestos-related litigation was $1.0 million, and $1.0 million, net of insurance recoveries, respectively.

[0001069202-15-000011:notes:21]
We are the defendant in an attempted class action lawsuit alleging evaporator coils in our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks.  We dispute the allegations in the lawsuit.  We have reached tentative settlement terms, preliminarily approved by the court, and recorded a liability of $2.4 million in Accrued expenses on the Consolidated Balance Sheet. Any additional liability resulting from the proposed settlement is not currently reasonably estimable, but we do not expect the proposed settlement to have a material adverse effect on our financial condition or results of operations.

[0001069202-15-000011:notes:22]
A lawsuit related to a vendor-supplied product quality issue settled for a lower amount than expected; accordingly, the Company reversed the $1.2 million excess portion of the loss contingency reserve in the second quarter of 2015.  The Company also discovered it underpaid contractor taxes at one of its non-U.S. subsidiaries; accordingly, the Company has recorded a loss contingency charge in the amount of $2.4 million for the nine months ended September 30, 2015. These items were recorded in "Losses (gains) and other expenses, net" on the Consolidated Statements of Operations.

[0001069202-15-000011:notes:23]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-15-000011:notes:24]
[same as prior period, unchanged from 0001069202-15-000008:notes:24]

[0001069202-15-000011:notes:25]
[same as prior period, unchanged from 0001069202-15-000008:notes:25]

[0001069202-15-000011:notes:26]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (3.2 | ) |  | $ | (1.0 | ) |  | $ | (9.4 | ) |  | $ | (4.9 | ) |  | Cost of goods sold |
| Income tax benefit |  | 1.2 |  |  | 0.4 |  |  | 3.2 |  |  | 1.8 |  |  | Provision for income taxes |
| Net of tax |  | $ | (2.0 | ) |  | $ | (0.6 | ) |  | $ | (6.2 | ) |  | $ | (3.1 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (2.0 | ) |  | $ | (1.3 | ) |  | $ | (6.1 | ) |  | $ | (4.0 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.7 |  |  | 0.5 |  |  | 2.2 |  |  | 1.5 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.3 | ) |  | $ | (0.8 | ) |  | $ | (3.9 | ) |  | $ | (2.5 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (3.3 | ) |  | $ | (1.4 | ) |  | $ | (10.1 | ) |  | $ | (5.6 | ) |  |  |

[0001069202-15-000011:notes:27]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2015 (in millions):

[0001069202-15-000011:notes:28]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| AOCL as of December 31, 2014 |  | $ | (4.6 | ) |  | $ | 3.2 |  |  | $ | (149.4 | ) |  | $ | (2.7 | ) |  | $ | (153.5 | ) |
| Other comprehensive (loss) income before reclassifications |  | (9.4 | ) |  | 1.8 |  |  | (2.7 | ) |  | (56.1 | ) |  | (66.4 | ) |
| Amounts reclassified from AOCL |  | 6.2 |  |  | — |  |  | 3.9 |  |  | — |  |  | 10.1 |  |
| Net other comprehensive (loss) income |  | (3.2 | ) |  | 1.8 |  |  | 1.2 |  |  | (56.1 | ) |  | (56.3 | ) |
| AOCL as of September 30, 2015 |  | $ | (7.8 | ) |  | $ | 5.0 |  |  | $ | (148.2 | ) |  | $ | (58.8 | ) |  | $ | (209.8 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-15-000011:notes:29]
[same as prior period, unchanged from 0001069202-15-000008:notes:29]

[0001069202-15-000011:notes:30]
[same as prior period, unchanged from 0001069202-15-000008:notes:30]

[0001069202-15-000011:notes:31]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of September 30, 2015 and December 31, 2014 and for the three and nine months ended September 30, 2015 and 2014 are shown on the following pages.

[0001069202-15-000011:notes:32]
[same as prior period, unchanged from 0001069202-15-000008:notes:32]

[0001069202-15-000011:notes:33]
[same as prior period, unchanged from 0001069202-15-000008:notes:33]

[0001069202-15-000011:notes:34]
As of September 30, 2015

[0001069202-15-000011:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.3 |  |  | $ | 12.5 |  |  | $ | 21.3 |  |  | $ | — |  |  | $ | 35.1 |  |
| Accounts and notes receivable, net | — |  |  | 42.1 |  |  | 495.6 |  |  | — |  |  | 537.7 |  |
| Inventories, net | — |  |  | 376.1 |  |  | 119.6 |  |  | (7.4 | ) |  | 488.3 |  |
| Deferred income taxes, net | 3.3 |  |  | 27.4 |  |  | 6.3 |  |  | (5.1 | ) |  | 31.9 |  |
| Other assets | 3.3 |  |  | 48.7 |  |  | 65.7 |  |  | (58.8 | ) |  | 58.9 |  |
| Total current assets | 7.9 |  |  | 506.8 |  |  | 708.5 |  |  | (71.3 | ) |  | 1,151.9 |  |
| Property, plant and equipment, net | — |  |  | 268.3 |  |  | 77.0 |  |  | — |  |  | 345.3 |  |
| Goodwill | — |  |  | 140.4 |  |  | 59.4 |  |  | — |  |  | 199.8 |  |
| Investment in subsidiaries | 1,111.9 |  |  | 394.7 |  |  | (0.6 | ) |  | (1,506.0 | ) |  | — |  |
| Deferred income taxes | 2.4 |  |  | 91.4 |  |  | 13.7 |  |  | (9.6 | ) |  | 97.9 |  |
| Other assets, net | 4.5 |  |  | 59.8 |  |  | 23.8 |  |  | (1.5 | ) |  | 86.6 |  |
| Intercompany receivables (payables), net | (360.7 | ) |  | 357.6 |  |  | 3.1 |  |  | — |  |  | — |  |
| Total assets | $ | 766.0 |  |  | $ | 1,819.0 |  |  | $ | 884.9 |  |  | $ | (1,588.4 | ) |  | $ | 1,881.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 226.3 |  |  | $ | — |  |  | $ | 226.3 |  |
| Current maturities of long-term debt | 22.5 |  |  | 0.9 |  |  | 0.3 |  |  | — |  |  | 23.7 |  |
| Accounts payable | 16.2 |  |  | 255.9 |  |  | 65.6 |  |  | — |  |  | 337.7 |  |
| Accrued expenses | 15.7 |  |  | 181.8 |  |  | 54.4 |  |  | — |  |  | 251.9 |  |
| Income taxes payable | (41.3 | ) |  | 94.8 |  |  | 27.2 |  |  | (66.9 | ) |  | 13.8 |  |
| Total current liabilities | 13.1 |  |  | 533.4 |  |  | 373.8 |  |  | (66.9 | ) |  | 853.4 |  |
| Long-term debt | 653.0 |  |  | 14.8 |  |  | 0.2 |  |  | — |  |  | 668.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.9 |  |  | — |  |  | — |  |  | 2.9 |  |
| Pensions | — |  |  | 123.4 |  |  | 10.8 |  |  | — |  |  | 134.2 |  |
| Other liabilities | 2.4 |  |  | 125.6 |  |  | 10.4 |  |  | (12.9 | ) |  | 125.5 |  |
| Total liabilities | 668.5 |  |  | 800.1 |  |  | 395.2 |  |  | (79.8 | ) |  | 1,784.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 97.5 |  |  | 1,018.9 |  |  | 489.7 |  |  | (1,508.6 | ) |  | 97.5 |  |
| Total liabilities and stockholders' equity | $ | 766.0 |  |  | $ | 1,819.0 |  |  | $ | 884.9 |  |  | $ | (1,588.4 | ) |  | $ | 1,881.5 |  |

[0001069202-15-000011:notes:36]
[same as prior period, unchanged from 0001069202-15-000008:notes:36]

[0001069202-15-000011:notes:37]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 11.5 |  |  | $ | 25.0 |  |  | $ | — |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net | — |  |  | 12.3 |  |  | 409.1 |  |  | — |  |  | 421.4 |  |
| Inventories, net | — |  |  | 350.6 |  |  | 119.7 |  |  | (7.0 | ) |  | 463.3 |  |
| Deferred income taxes, net | 2.8 |  |  | 27.3 |  |  | 7.4 |  |  | (5.0 | ) |  | 32.5 |  |
| Other assets | 3.6 |  |  | 45.7 |  |  | 67.2 |  |  | (57.2 | ) |  | 59.3 |  |
| Total current assets | 7.4 |  |  | 447.4 |  |  | 628.4 |  |  | (69.2 | ) |  | 1,014.0 |  |
| Property, plant and equipment, net | — |  |  | 269.0 |  |  | 89.6 |  |  | — |  |  | 358.6 |  |
| Goodwill | — |  |  | 140.4 |  |  | 69.0 |  |  | — |  |  | 209.4 |  |
| Investment in subsidiaries | 978.1 |  |  | 263.5 |  |  | (0.6 | ) |  | (1,241.0 | ) |  | — |  |
| Deferred income taxes | 0.5 |  |  | 90.8 |  |  | 15.8 |  |  | (9.6 | ) |  | 97.5 |  |
| Other assets, net | 5.2 |  |  | 61.0 |  |  | 20.1 |  |  | (1.5 | ) |  | 84.8 |  |
| Intercompany receivables (payables), net | (280.4 | ) |  | 302.4 |  |  | (22.0 | ) |  | — |  |  | — |  |
| Total assets | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 226.6 |  |  | $ | — |  |  | $ | 226.6 |  |
| Current maturities of long-term debt | 22.5 |  |  | 1.2 |  |  | 0.3 |  |  | — |  |  | 24.0 |  |
| Accounts payable | 13.4 |  |  | 237.8 |  |  | 73.1 |  |  | — |  |  | 324.3 |  |
| Accrued expenses | 9.0 |  |  | 175.5 |  |  | 54.5 |  |  | — |  |  | 239.0 |  |
| Income taxes payable | (3.7 | ) |  | 34.7 |  |  | 47.5 |  |  | (65.1 | ) |  | 13.4 |  |
| Total current liabilities | 41.2 |  |  | 449.2 |  |  | 402.0 |  |  | (65.1 | ) |  | 827.3 |  |
| Long-term debt | 659.5 |  |  | 15.3 |  |  | 0.2 |  |  | — |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| Pensions | — |  |  | 117.6 |  |  | 12.3 |  |  | — |  |  | 129.9 |  |
| Other liabilities | 1.1 |  |  | 118.7 |  |  | 11.7 |  |  | (12.9 | ) |  | 118.6 |  |
| Total liabilities | 701.8 |  |  | 705.3 |  |  | 426.2 |  |  | (78.0 | ) |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 9.0 |  |  | 869.2 |  |  | 374.1 |  |  | (1,243.3 | ) |  | 9.0 |  |
| Total liabilities and stockholders' equity | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |

[0001069202-15-000011:notes:38]
[same as prior period, unchanged from 0001069202-15-000008:notes:38]

[0001069202-15-000011:notes:39]
For the Three Months Ended September 30, 2015

[0001069202-15-000011:notes:40]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 827.9 |  |  | $ | 185.2 |  |  | $ | (58.1 | ) |  | $ | 955.0 |  |
| Cost of goods sold | — |  |  | 589.9 |  |  | 150.2 |  |  | (58.5 | ) |  | 681.6 |  |
| Gross profit | — |  |  | 238.0 |  |  | 35.0 |  |  | 0.4 |  |  | 273.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 124.0 |  |  | 19.8 |  |  | — |  |  | 143.8 |  |
| Losses (gains) and other expenses, net | 0.6 |  |  | 2.7 |  |  | 2.7 |  |  | — |  |  | 6.0 |  |
| Restructuring charges | — |  |  | (0.2 | ) |  | (0.2 | ) |  | — |  |  | (0.4 | ) |
| Income from equity method investments | (84.2 | ) |  | (2.7 | ) |  | (2.1 | ) |  | 86.0 |  |  | (3.0 | ) |
| Operational income from continuing operations | 83.6 |  |  | 114.2 |  |  | 14.8 |  |  | (85.6 | ) |  | 127.0 |  |
| Interest expense, net | 5.4 |  |  | (0.4 | ) |  | 0.7 |  |  | — |  |  | 5.7 |  |
| Other expense, net | — |  |  | — |  |  | (0.7 | ) |  | — |  |  | (0.7 | ) |
| Income from continuing operations before income taxes | 78.2 |  |  | 114.6 |  |  | 14.8 |  |  | (85.6 | ) |  | 122.0 |  |
| Provision for income taxes | (2.1 | ) |  | 39.0 |  |  | 4.6 |  |  | 0.2 |  |  | 41.7 |  |
| Income from continuing operations | 80.3 |  |  | 75.6 |  |  | 10.2 |  |  | (85.8 | ) |  | 80.3 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  |  |  |  | — |  |
| Net income | $ | 80.3 |  |  | $ | 75.6 |  |  | $ | 10.2 |  |  | $ | (85.8 | ) |  | $ | 80.3 |  |
| Other comprehensive income (loss), net of tax | (4.3 | ) |  | (8.6 | ) |  | (16.2 | ) |  | (1.8 | ) |  | (30.9 | ) |
| Comprehensive income | $ | 76.0 |  |  | $ | 67.0 |  |  | $ | (6.0 | ) |  | $ | (87.6 | ) |  | $ | 49.4 |  |

[0001069202-15-000011:notes:41]
For the Nine Months Ended September 30, 2015

[0001069202-15-000011:notes:42]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,268.6 |  |  | $ | 520.7 |  |  | $ | (156.0 | ) |  | $ | 2,633.3 |  |
| Cost of goods sold | — |  |  | 1,650.7 |  |  | 418.2 |  |  | (155.4 | ) |  | 1,913.5 |  |
| Gross profit | — |  |  | 617.9 |  |  | 102.5 |  |  | (0.6 | ) |  | 719.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 362.0 |  |  | 68.0 |  |  | — |  |  | 430.0 |  |
| Losses (gains) and other expenses, net | 1.1 |  |  | 7.7 |  |  | 6.2 |  |  | (0.1 | ) |  | 14.9 |  |
| Restructuring charges | — |  |  | (0.5 | ) |  | 2.3 |  |  | — |  |  | 1.8 |  |
| Income from equity method investments | (187.2 | ) |  | (0.3 | ) |  | (9.3 | ) |  | 185.0 |  |  | (11.8 | ) |
| Operational income from continuing operations | 186.1 |  |  | 249.0 |  |  | 35.3 |  |  | (185.5 | ) |  | 284.9 |  |
| Interest expense, net | 17.1 |  |  | (1.5 | ) |  | 2.3 |  |  | — |  |  | 17.9 |  |
| Other expense, net | — |  |  | — |  |  | (0.7 | ) |  | — |  |  | (0.7 | ) |
| Income from continuing operations before income taxes | 169.0 |  |  | 250.5 |  |  | 33.7 |  |  | (185.5 | ) |  | 267.7 |  |
| Provision for income taxes | (6.3 | ) |  | 87.2 |  |  | 11.2 |  |  | (0.2 | ) |  | 91.9 |  |
| Income from continuing operations | 175.3 |  |  | 163.3 |  |  | 22.5 |  |  | (185.3 | ) |  | 175.8 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Net income | $ | 175.3 |  |  | $ | 163.3 |  |  | $ | 22.0 |  |  | $ | (185.3 | ) |  | $ | 175.3 |  |
| Other comprehensive income (loss), net of tax | (2.9 | ) |  | (13.8 | ) |  | (36.4 | ) |  | (3.2 | ) |  | (56.3 | ) |
| Comprehensive income | $ | 172.4 |  |  | $ | 149.5 |  |  | $ | (14.4 | ) |  | $ | (188.5 | ) |  | $ | 119.0 |  |

[0001069202-15-000011:notes:43]
For the Three Months Ended September 30, 2014

[0001069202-15-000011:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 736.2 |  |  | $ | 213.5 |  |  | $ | (51.3 | ) |  | $ | 898.4 |  |
| Cost of goods sold | — |  |  | 538.8 |  |  | 164.5 |  |  | (52.0 | ) |  | 651.3 |  |
| Gross profit | — |  |  | 197.4 |  |  | 49.0 |  |  | 0.7 |  |  | 247.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 127.4 |  |  | 13.5 |  |  | — |  |  | 140.9 |  |
| Losses (gains) and other expenses, net | (0.1 | ) |  | 1.2 |  |  | 1.0 |  |  | — |  |  | 2.1 |  |
| Restructuring charges | — |  |  | (0.1 | ) |  | 1.1 |  |  | — |  |  | 1.0 |  |
| Income from equity method investments | (69.7 | ) |  | (6.4 | ) |  | (2.7 | ) |  | 75.3 |  |  | (3.5 | ) |
| Operational income from continuing operations | 69.8 |  |  | 75.3 |  |  | 36.1 |  |  | (74.6 | ) |  | 106.6 |  |
| Interest expense, net | 3.6 |  |  | (0.7 | ) |  | 1.1 |  |  | — |  |  | 4.0 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 66.2 |  |  | 76.0 |  |  | 35.0 |  |  | (74.6 | ) |  | 102.6 |  |
| Provision for income taxes | (1.2 | ) |  | 24.1 |  |  | 11.9 |  |  | 0.3 |  |  | 35.1 |  |
| Income from continuing operations | 67.4 |  |  | 51.9 |  |  | 23.1 |  |  | (74.9 | ) |  | 67.5 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Net income | $ | 67.4 |  |  | $ | 51.9 |  |  | $ | 23.0 |  |  | $ | (74.9 | ) |  | $ | 67.4 |  |
| Other comprehensive income, net of tax | (1.1 | ) |  | (6.7 | ) |  | (17.2 | ) |  | (1.0 | ) |  | (26.0 | ) |
| Comprehensive income | $ | 66.3 |  |  | $ | 45.2 |  |  | $ | 5.8 |  |  | $ | (75.9 | ) |  | $ | 41.4 |  |

[0001069202-15-000011:notes:45]
For the Nine Months Ended September 30, 2014

[0001069202-15-000011:notes:46]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,089.0 |  |  | $ | 606.5 |  |  | $ | (140.9 | ) |  | $ | 2,554.6 |  |
| Cost of goods sold | — |  |  | 1,555.1 |  |  | 460.9 |  |  | (139.3 | ) |  | 1,876.7 |  |
| Gross profit | — |  |  | 533.9 |  |  | 145.6 |  |  | (1.6 | ) |  | 677.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 362.9 |  |  | 62.6 |  |  | — |  |  | 425.5 |  |
| Losses and other expenses, net | (0.3 | ) |  | 2.3 |  |  | 1.5 |  |  |  |  |  | 3.5 |  |
| Restructuring charges | — |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Income from equity method investments | (167.6 | ) |  | (21.0 | ) |  | (9.8 | ) |  | 186.4 |  |  | (12.0 | ) |
| Operational income from continuing operations | 167.9 |  |  | 189.7 |  |  | 90.0 |  |  | (188.0 | ) |  | 259.6 |  |
| Interest expense, net | 10.1 |  |  | (2.2 | ) |  | 3.1 |  |  | — |  |  | 11.0 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 157.8 |  |  | 191.9 |  |  | 86.9 |  |  | (188.0 | ) |  | 248.6 |  |
| Provision for income taxes | (3.4 | ) |  | 60.0 |  |  | 30.5 |  |  | (0.5 | ) |  | 86.6 |  |
| Income from continuing operations | 161.2 |  |  | 131.9 |  |  | 56.4 |  |  | (187.5 | ) |  | 162.0 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Net income | $ | 161.2 |  |  | $ | 131.9 |  |  | $ | 55.6 |  |  | $ | (187.5 | ) |  | $ | 161.2 |  |
| Other comprehensive income (loss), net of tax | (1.1 | ) |  | (1.8 | ) |  | (11.8 | ) |  | (1.1 | ) |  | (15.8 | ) |
| Comprehensive income | $ | 160.1 |  |  | $ | 130.1 |  |  | $ | 43.8 |  |  | $ | (188.6 | ) |  | $ | 145.4 |  |

[0001069202-15-000011:notes:47]
[same as prior period, unchanged from 0001069202-15-000008:notes:47]

[0001069202-15-000011:notes:48]
For the Nine Months Ended September 30, 2015

[0001069202-15-000011:notes:49]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | (27.3 | ) |  | $ | 138.2 |  |  | $ | (4.0 | ) |  | $ | — |  |  | $ | 106.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (40.3 | ) |  | (6.7 | ) |  | — |  |  | (47.0 | ) |
| Net cash used in investing activities | — |  |  | (40.3 | ) |  | (6.7 | ) |  | — |  |  | (47.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Long-term debt payments | (22.5 | ) |  | (0.8 | ) |  | (0.2 | ) |  | — |  |  | (23.5 | ) |
| Borrowings from credit facility | 1,401.0 |  |  | — |  |  | — |  |  | — |  |  | 1,401.0 |  |
| Payments on credit facility | (1,385.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,385.0 | ) |
| Proceeds from employee stock purchases | 1.8 |  |  | — |  |  | — |  |  | — |  |  | 1.8 |  |
| Repurchases of common stock | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (23.5 | ) |  | — |  |  | — |  |  | — |  |  | (23.5 | ) |
| Excess tax benefits related to share-based payments | 18.6 |  |  | — |  |  | — |  |  | — |  |  | 18.6 |  |
| Intercompany financing activity | (37.7 | ) |  | 10.2 |  |  | 27.5 |  |  | — |  |  | — |  |
| Intercompany investments | 118.0 |  |  | (106.3 | ) |  | (11.7 | ) |  | — |  |  | — |  |
| Cash dividends paid | (43.1 | ) |  | — |  |  | — |  |  | — |  |  | (43.1 | ) |
| Net cash provided by financing activities | 27.6 |  |  | (96.9 | ) |  | 16.4 |  |  | — |  |  | (52.9 | ) |
| Increase in cash and cash equivalents | 0.3 |  |  | 1.0 |  |  | 5.7 |  |  | — |  |  | 7.0 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (9.4 | ) |  | — |  |  | (9.4 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of period | $ | 1.3 |  |  | $ | 12.5 |  |  | $ | 21.3 |  |  | $ | — |  |  | $ | 35.1 |  |

[0001069202-15-000011:notes:50]
For the Nine Months Ended September 30, 2014

[0001069202-15-000011:notes:51]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 13.4 |  |  | $ | 72.1 |  |  | $ | (62.0 | ) |  | $ | — |  |  | $ | 23.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (45.5 | ) |  | (14.4 | ) |  | — |  |  | (59.9 | ) |
| Net cash used in investing activities | — |  |  | (45.3 | ) |  | (14.4 | ) |  | — |  |  | (59.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 60.0 |  |  | — |  |  | 60.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | — |  |  | (1.4 | ) |  | (0.3 | ) |  | — |  |  | (1.7 | ) |
| Borrowings from credit facility | 1,483.0 |  |  | — |  |  | — |  |  | — |  |  | 1,483.0 |  |
| Payments on credit facility | (1,351.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,351.0 | ) |
| Proceeds from employee stock purchases | 1.5 |  |  | — |  |  | — |  |  | — |  |  | 1.5 |  |
| Repurchases of common stock | (100.3 | ) |  | — |  |  | — |  |  | — |  |  | (100.3 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (12.3 | ) |  | — |  |  | — |  |  | — |  |  | (12.3 | ) |
| Excess tax benefits related to share-based payments | 5.3 |  |  | — |  |  | — |  |  | — |  |  | 5.3 |  |
| Intercompany debt | (12.5 | ) |  | (0.8 | ) |  | 13.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | 11.5 |  |  | (17.0 | ) |  | 5.5 |  |  | — |  |  | — |  |
| Intercompany investments | — |  |  | (3.0 | ) |  | 3.0 |  |  | — |  |  | — |  |
| Cash dividends paid | (38.2 | ) |  | — |  |  | — |  |  | — |  |  | (38.2 | ) |
| Net cash used in financing activities | (13.0 | ) |  | (22.2 | ) |  | 84.9 |  |  | — |  |  | 49.7 |  |
| Decrease in cash and cash equivalents | 0.4 |  |  | 4.6 |  |  | 8.5 |  |  | — |  |  | 13.5 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (3.4 | ) |  | — |  |  | (3.4 | ) |
| Cash and cash equivalents, beginning of period | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of period | $ | 1.5 |  |  | $ | 15.1 |  |  | $ | 31.5 |  |  | $ | — |  |  | $ | 48.1 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-15-000011:notes:52]
Lines of Credit and Financing Arrangements:

[0001069202-15-000011:notes:53]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000011:notes:54]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 6.3 |  |  | 6.6 |  |
| Total short-term debt | $ | 226.3 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.2 |  |  | $ | 1.5 |  |
| Domestic credit facility | 22.5 |  |  | 22.5 |  |
| Total current maturities of long-term debt | $ | 23.7 |  |  | $ | 24.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.0 |  |  | $ | 15.5 |  |
| Domestic credit facility | 453.0 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 668.0 |  |  | $ | 675.0 |  |
| Total debt | $ | 918.0 |  |  | $ | 925.6 |  |

[0001069202-15-000011:notes:55]
Short-Term Debt

[0001069202-15-000011:notes:56]
Foreign Obligations

[0001069202-15-000011:notes:57]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $6.3 million and $6.6 million of foreign obligations as of September 30, 2015 and December 31, 2014, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $63.6 million and $73.1 million during the nine months ended September 30, 2015 and 2014, respectively. Repayments on the facilities were $61.7 million and $65.6 million and during the nine months ended September 30, 2015 and 2014, respectively.

[0001069202-15-000011:notes:58]
Asset Securitization Program

[0001069202-15-000011:notes:59]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-15-000011:notes:60]
The ASP provides for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-15-000011:notes:61]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for September 30, 2015 and December 31, 2014 was 0.82% and 0.79% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-15-000011:notes:62]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2015, we were in compliance with all covenant requirements.

[0001069202-15-000011:notes:63]
Long-Term Debt

[0001069202-15-000011:notes:64]
Domestic Credit Facility

[0001069202-15-000011:notes:65]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consisted of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $475.5 million, of which $277.5 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of September 30, 2015. Subject to covenant limitations, $447.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. We paid $22.5 million in principal payments in June 2015 for the term loan, which represents the required principal payments for the remainder of 2015.  The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-15-000011:notes:66]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-15-000011:notes:67]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-15-000011:notes:68]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-15-000011:notes:69]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-15-000011:notes:70]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2015, we were in compliance with all covenant requirements.

[0001069202-15-000011:notes:71]
Senior Unsecured Notes

[0001069202-15-000011:notes:72]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2015, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-15-000011:notes:73]
[same as prior period, unchanged from 0001069202-15-000008:notes:73]

[0001069202-15-000011:notes:74]
[same as prior period, unchanged from 0001069202-15-000008:notes:74]

[0001069202-15-000011:notes:75]
[same as prior period, unchanged from 0001069202-15-000008:notes:75]

[0001069202-15-000011:notes:76]
[same as prior period, unchanged from 0001069202-15-000008:notes:76]

[0001069202-15-000011:notes:77]
Foreign Currency Risk - Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. Our forward contracts are primarily not designated as hedges, but on occasion we have entered into forward contracts that are designated as cash flow hedges. By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-15-000011:notes:78]
[same as prior period, unchanged from 0001069202-15-000008:notes:78]

[0001069202-15-000011:notes:79]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flow hedges that are scheduled to mature through February 2017.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-15-000011:notes:80]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Unrealized losses on unsettled futures contracts | $ | 12.3 |  |  | $ | 7.2 |  |
| Income tax benefit | (4.5 | ) |  | (2.6 | ) |
| Losses included in AOCL, net of tax (1) | $ | 7.8 |  |  | $ | 4.6 |  |

[0001069202-15-000011:notes:81]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $6.8 million of derivative losses into earnings within the next 12 months.

[0001069202-15-000011:notes:82]
[same as prior period, unchanged from 0001069202-15-000008:notes:82]

[0001069202-15-000011:notes:83]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Copper | 29.0 |  |  | 29.4 |  |

[0001069202-15-000011:notes:84]
We had the following outstanding foreign exchange forward contracts designated as cash flow hedges (in millions):

[0001069202-15-000011:notes:85]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 250.9 |  |  | — |  |

[0001069202-15-000011:notes:86]
[same as prior period, unchanged from 0001069202-15-000008:notes:84]

[0001069202-15-000011:notes:87]
[same as prior period, unchanged from 0001069202-15-000008:notes:85]

[0001069202-15-000011:notes:88]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Copper | 3.3 |  |  | 2.9 |  |
| Aluminum | 2.5 |  |  | 2.2 |  |

[0001069202-15-000011:notes:89]
[same as prior period, unchanged from 0001069202-15-000008:notes:87]

[0001069202-15-000011:notes:90]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Notional Amounts (in local currency): |  |  |  |
| Brazilian Real | — |  |  | 8.7 |  |
| Mexican Peso | — |  |  | 229.7 |  |
| United States Dollar | 7.1 |  |  | 4.5 |  |
| Euro | 6.0 |  |  | 3.6 |  |
| Polish Zloty | 29.9 |  |  | 30.6 |  |
| Russian Ruble | 94.4 |  |  | 80.8 |  |

[0001069202-15-000011:notes:91]
[same as prior period, unchanged from 0001069202-15-000008:notes:89]

[0001069202-15-000011:notes:92]
[same as prior period, unchanged from 0001069202-15-000008:notes:90]

[0001069202-15-000011:notes:93]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of September 30, 2015 |  | As of December 31, 2014 |  | As of September 30, 2015 |  | As of December 31, 2014 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | 0.3 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Assets | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.3 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 10.4 |  |  | $ | 6.7 |  |  | $ | 1.4 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts | 0.4 |  |  | — |  |  | 0.1 |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 1.5 |  |  | 0.5 |  |  | 0.3 |  |  | 0.1 |  |
| Foreign currency forward contracts | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 12.4 |  |  | $ | 7.2 |  |  | $ | 1.8 |  |  | $ | 0.8 |  |

[0001069202-15-000011:notes:94]
[same as prior period, unchanged from 0001069202-15-000008:notes:92]

[0001069202-15-000011:notes:95]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Amount of Loss reclassified from AOCL into Income (Effective Portion) (1) |  | $ | 3.2 |  |  | $ | 1.0 |  |  | $ | 9.4 |  |  | $ | 4.9 |  |
| Amount of Loss (Gain) recognized in Net income (Ineffective Portion) (2) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |

[0001069202-15-000011:notes:96]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | 1.4 |  |  | $ | 0.3 |  |  | $ | 2.2 |  |  | $ | 0.6 |  |
| Foreign currency forward contracts (2) |  | — |  |  | (0.2 | ) |  | 0.2 |  |  | (0.1 | ) |
|  |  | $ | 1.4 |  |  | $ | 0.1 |  |  | $ | 2.4 |  |  | $ | 0.5 |  |

[0001069202-15-000011:notes:97]
[same as prior period, unchanged from 0001069202-15-000008:notes:95]

[0001069202-15-000011:notes:98]
[same as prior period, unchanged from 0001069202-15-000008:notes:96]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-15-000011:notes:99]
[same as prior period, unchanged from 0001069202-15-000008:notes:97]

[0001069202-15-000011:notes:100]
[same as prior period, unchanged from 0001069202-15-000008:notes:98]

[0001069202-15-000011:notes:101]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Stock-based compensation expense (1) | $ | 7.7 |  |  | $ | 6.6 |  |  | $ | 18.5 |  |  | $ | 17.3 |  |

[0001069202-15-000011:notes:102]
[same as prior period, unchanged from 0001069202-15-000008:notes:100]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-15-000011:notes:103]
[same as prior period, unchanged from 0001069202-15-000008:notes:101]

[0001069202-15-000011:notes:104]
[same as prior period, unchanged from 0001069202-15-000008:notes:102]

[0001069202-15-000011:notes:105]
There were no assets and liabilities related to the Service Experts or Hearth businesses included in the accompanying Consolidated Balance Sheets as of September 30, 2015 or December 31, 2014, except for insurance casualty loss reserves which we retained after the respective transactions.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in Discontinued Operations in the accompanying Consolidated Statements of Operations.  The following table provides a summary of net trade sales, pre-tax operating income (loss) and other supplemental information related to discontinued operations (in millions):

[0001069202-15-000011:notes:106]
|  | Service Experts |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | — |  |  | — |  |  | (0.9 | ) |  | 1.1 |  |
| Gain (loss) on sale of business | — |  |  | — |  |  | — |  |  | — |  |

[0001069202-15-000011:notes:107]
[same as prior period, unchanged from 0001069202-15-000008:notes:105]

[0001069202-15-000011:notes:108]
|  | Hearth |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | — |  |  | (0.2 | ) |  | — |  |  | (2.4 | ) |
| Gain (loss) on sale of business | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-15-000011:notes:109]
[same as prior period, unchanged from 0001069202-15-000008:notes:107]

[0001069202-15-000011:notes:110]
[same as prior period, unchanged from 0001069202-15-000008:notes:108]

[0001069202-15-000011:notes:111]
[same as prior period, unchanged from 0001069202-15-000008:notes:109]

[0001069202-15-000011:notes:112]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net income | $ | 80.3 |  |  | $ | 67.4 |  |  | $ | 175.3 |  |  | $ | 161.2 |  |
| Add: Loss from discontinued operations | — |  |  | 0.1 |  |  | 0.5 |  |  | 0.8 |  |
| Income from continuing operations | $ | 80.3 |  |  | $ | 67.5 |  |  | $ | 175.8 |  |  | $ | 162.0 |  |
| Weighted-average shares outstanding – basic | 45.0 |  |  | 48.3 |  |  | 44.9 |  |  | 48.7 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.6 |  |  | 0.7 |  |  | 0.7 |  |  | 0.8 |  |
| Weighted-average shares outstanding – diluted | 45.6 |  |  | 49.0 |  |  | 45.6 |  |  | 49.5 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.78 |  |  | $ | 1.40 |  |  | $ | 3.92 |  |  | $ | 3.33 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01 | ) |  | (0.02 | ) |
| Net income | $ | 1.78 |  |  | $ | 1.40 |  |  | $ | 3.91 |  |  | $ | 3.31 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.76 |  |  | $ | 1.38 |  |  | $ | 3.86 |  |  | $ | 3.27 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01 | ) |  | (0.01 | ) |
| Net income | $ | 1.76 |  |  | $ | 1.38 |  |  | $ | 3.85 |  |  | $ | 3.26 |  |

[0001069202-15-000011:notes:113]
[same as prior period, unchanged from 0001069202-15-000008:notes:111]

[0001069202-15-000011:notes:114]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Weighted-average number of shares | — |  |  | 0.3 |  |  | 0.2 |  |  | 0.3 |  |
| Price range per share | $ | — |  |  | $81.11 - $81.14 |  |  | $ | 92.64 |  |  | $81.11 - $81.14 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-15-000011:notes:115]
[same as prior period, unchanged from 0001069202-15-000008:notes:113]

[0001069202-15-000011:notes:116]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Senior unsecured notes | $ | 210.3 |  |  | $ | 210.6 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-15-000011:notes:117]
[same as prior period, unchanged from 0001069202-15-000008:notes:115]

[0001069202-15-000011:notes:118]
[same as prior period, unchanged from 0001069202-15-000008:notes:116]

[0001069202-15-000011:notes:119]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2015 were the same as those used at December 31, 2014.

[0001069202-15-000011:notes:120]
[same as prior period, unchanged from 0001069202-15-000008:notes:118]

[0001069202-15-000011:notes:121]
[same as prior period, unchanged from 0001069202-15-000008:notes:119]

[0001069202-15-000011:notes:122]
[same as prior period, unchanged from 0001069202-15-000008:notes:120]

[0001069202-15-000011:notes:123]
[same as prior period, unchanged from 0001069202-15-000008:notes:121]

[0001069202-15-000011:notes:124]
[same as prior period, unchanged from 0001069202-15-000008:notes:122]

[0001069202-15-000011:notes:125]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Investment in marketable equity securities | $ | 7.1 |  |  | $ | 5.3 |  |

[0001069202-15-000011:notes:126]
[same as prior period, unchanged from 0001069202-15-000008:notes:124]

[0001069202-15-000011:notes:127]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-15-000011:notes:128]
[same as prior period, unchanged from 0001069202-15-000008:notes:126]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-15-000011:notes:129]
[same as prior period, unchanged from 0001069202-15-000008:notes:127]

[0001069202-15-000011:notes:130]
The changes in the carrying amount of goodwill for the first nine months of 2015, in total and by segment, are summarized in the table below (in millions):

[0001069202-15-000011:notes:131]
|  | Balance at December 31, 2014 |  | Acquisitions / (Dispositions) |  | Other (1) |  | September 30, 2015 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 62.3 |  |  | — |  |  | (1.2 | ) |  | 61.1 |  |
| Refrigeration | 121.0 |  |  | — |  |  | (8.4 | ) |  | 112.6 |  |
| Total Goodwill | $ | 209.4 |  |  | $ | — |  |  | $ | (9.6 | ) |  | $ | 199.8 |  |

[0001069202-15-000011:notes:132]
[same as prior period, unchanged from 0001069202-15-000008:notes:130]

[0001069202-15-000011:notes:133]
[same as prior period, unchanged from 0001069202-15-000008:notes:131]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-15-000011:notes:134]
[same as prior period, unchanged from 0001069202-15-000008:notes:132]

[0001069202-15-000011:notes:135]
As of September 30, 2015, we had approximately $1.6 million in total gross unrecognized tax benefits. Of this amount, $1.2 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of September 30, 2015, we had approximately $0.3 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-15-000011:notes:136]
[same as prior period, unchanged from 0001069202-15-000008:notes:134]

[0001069202-15-000011:notes:137]
Since January 1, 2015, numerous states, including Alabama, Connecticut, New Hampshire, North Dakota, Tennessee and Texas, have enacted legislation effective for tax years beginning on or after January 1, 2015, including changes to rates, apportionment methodologies and unitary reporting requirements.  The impact of these changes is immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-15-000011:notes:138]
[same as prior period, unchanged from 0001069202-15-000008:notes:136]

[0001069202-15-000011:notes:139]
[same as prior period, unchanged from 0001069202-15-000008:notes:137]

[0001069202-15-000011:notes:140]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Finished goods | $ | 353.5 |  |  | $ | 338.2 |  |
| Work in process | 8.9 |  |  | 8.1 |  |
| Raw materials and parts | 188.8 |  |  | 182.6 |  |
| Subtotal | 551.2 |  |  | 528.9 |  |
| Excess of current cost over last-in, first-out cost | (62.9 | ) |  | (65.6 | ) |
| Total inventories, net | $ | 488.3 |  |  | $ | 463.3 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-15-000011:notes:141]
[same as prior period, unchanged from 0001069202-15-000008:notes:139]

[0001069202-15-000011:notes:142]
[same as prior period, unchanged from 0001069202-15-000008:notes:140]

[0001069202-15-000011:notes:143]
[same as prior period, unchanged from 0001069202-15-000008:notes:141]

[0001069202-15-000011:notes:144]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-15-000011:notes:145]
[same as prior period, unchanged from 0001069202-15-000008:notes:143]

[0001069202-15-000011:notes:146]
[same as prior period, unchanged from 0001069202-15-000008:notes:144]

[0001069202-15-000011:notes:147]
[same as prior period, unchanged from 0001069202-15-000008:notes:145]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-15-000011:notes:148]
[same as prior period, unchanged from 0001069202-15-000008:notes:146]

[0001069202-15-000011:notes:149]
[same as prior period, unchanged from 0001069202-15-000008:notes:147]

[0001069202-15-000011:notes:150]
|  | For the Three Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.2 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.3 |  |  | 4.4 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on plan assets | (5.3 | ) |  | (5.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  | (0.8 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.4 |  |  | 1.6 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 2.6 |  |  | $ | 1.5 |  |  | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0001069202-15-000011:notes:151]
|  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 3.6 |  |  | $ | 3.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 12.9 |  |  | 13.3 |  |  | 0.2 |  |  | 0.1 |  |
| Expected return on plan assets | (16.0 | ) |  | (17.0 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | 0.2 |  |  | (2.4 | ) |  | (2.2 | ) |
| Recognized actuarial loss | 7.2 |  |  | 4.9 |  |  | 1.2 |  |  | 1.1 |  |
| Settlements and curtailments | 0.4 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 8.1 |  |  | $ | 4.6 |  |  | $ | (1.0 | ) |  | $ | (1.0 | ) |

[0001069202-15-000011:notes:152]
(1) All net periodic benefit cost for the three and nine months ended September 30, 2015 and 2014 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-15-000011:notes:153]
[same as prior period, unchanged from 0001069202-15-000008:notes:151]

[0001069202-15-000011:notes:154]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 517.9 |  |  | $ | 462.6 |  |  | $ | 1,435.6 |  |  | $ | 1,332.5 |  |
| Commercial Heating & Cooling | 246.8 |  |  | 241.6 |  |  | 660.3 |  |  | 655.6 |  |
| Refrigeration | 190.3 |  |  | 194.2 |  |  | 537.4 |  |  | 566.5 |  |
|  | $ | 955.0 |  |  | $ | 898.4 |  |  | $ | 2,633.3 |  |  | $ | 2,554.6 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 90.1 |  |  | $ | 69.4 |  |  | $ | 221.3 |  |  | $ | 178.8 |  |
| Commercial Heating & Cooling | 44.8 |  |  | 42.2 |  |  | 95.5 |  |  | 91.3 |  |
| Refrigeration | 20.3 |  |  | 16.5 |  |  | 37.5 |  |  | 42.3 |  |
| Corporate and other | (24.0 | ) |  | (17.5 | ) |  | (57.4 | ) |  | (47.8 | ) |
| Subtotal that includes segment profit and eliminations | 131.2 |  |  | 110.6 |  |  | 296.9 |  |  | 264.6 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Special product quality adjustments | 0.7 |  |  | 0.2 |  |  | (0.6 | ) |  | (0.1 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 3.9 |  |  | 1.8 |  |  | 10.8 |  |  | 2.8 |  |
| Restructuring charges | (0.4 | ) |  | 1.0 |  |  | 1.8 |  |  | 1.3 |  |
| Interest expense, net | 5.7 |  |  | 4.0 |  |  | 17.9 |  |  | 11.0 |  |
| Special inventory write down | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| Other expense (income), net | (0.7 | ) |  | — |  |  | (0.7 | ) |  | — |  |
| Income from continuing operations before income taxes | $ | 122.0 |  |  | $ | 102.6 |  |  | $ | 267.7 |  |  | $ | 248.6 |  |

[0001069202-15-000011:notes:155]
[same as prior period, unchanged from 0001069202-15-000008:notes:153]

[0001069202-15-000011:notes:156]
[same as prior period, unchanged from 0001069202-15-000008:notes:154]

[0001069202-15-000011:notes:157]
[same as prior period, unchanged from 0001069202-15-000008:notes:155]

[0001069202-15-000011:notes:158]
[same as prior period, unchanged from 0001069202-15-000008:notes:156]

[0001069202-15-000011:notes:159]
| ◦ | Special legal contingency charges, |

[0001069202-15-000011:notes:160]
| ◦ | Asbestos-related litigation, |

[0001069202-15-000011:notes:161]
[same as prior period, unchanged from 0001069202-15-000008:notes:159]

[0001069202-15-000011:notes:162]
[same as prior period, unchanged from 0001069202-15-000008:notes:160]

[0001069202-15-000011:notes:163]
[same as prior period, unchanged from 0001069202-15-000008:notes:161]

[0001069202-15-000011:notes:164]
[same as prior period, unchanged from 0001069202-15-000008:notes:162]

[0001069202-15-000011:notes:165]
[same as prior period, unchanged from 0001069202-15-000008:notes:163]

[0001069202-15-000011:notes:166]
[same as prior period, unchanged from 0001069202-15-000008:notes:164]

[0001069202-15-000011:notes:167]
[same as prior period, unchanged from 0001069202-15-000008:notes:165]

[0001069202-15-000011:notes:168]
[same as prior period, unchanged from 0001069202-15-000008:notes:166]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-15-000011:notes:169]
[same as prior period, unchanged from 0001069202-15-000008:notes:167]

[0001069202-15-000011:notes:170]
[same as prior period, unchanged from 0001069202-15-000008:notes:168]

[0001069202-15-000011:notes:171]
[same as prior period, unchanged from 0001069202-15-000008:notes:169]

[0001069202-15-000011:notes:172]
[same as prior period, unchanged from 0001069202-15-000008:notes:170]

[0001069202-15-000011:notes:173]
|  | Charges Incurred in 2015 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 1.2 |  |  | $ | 8.1 |  |  | $ | 8.1 |  |
| Asset write-offs and accelerated depreciation | 0.2 |  |  | 2.0 |  |  | 2.0 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |
| Other | 0.4 |  |  | 2.3 |  |  | 2.3 |  |
| Total restructuring charges | $ | 1.8 |  |  | $ | 12.4 |  |  | $ | 12.4 |  |

[0001069202-15-000011:notes:174]
[same as prior period, unchanged from 0001069202-15-000008:notes:172]

[0001069202-15-000011:notes:175]
|  | Charges Incurred in 2015 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | (0.1 | ) |  | $ | 1.4 |  |  | $ | 1.4 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | 1.9 |  |  | 10.1 |  |  | 10.1 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total restructuring charges | $ | 1.8 |  |  | $ | 12.4 |  |  | $ | 12.4 |  |

[0001069202-15-000011:notes:176]
[same as prior period, unchanged from 0001069202-15-000008:notes:174]

[0001069202-15-000011:notes:177]
|  | Balance as ofDecember 31, 2014 |  | Charged to Earnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of September 30, 2015 |
| Severance and related expense | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | (1.7 | ) |  | $ | (0.2 | ) |  | $ | 0.8 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.2 |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Equipment moves | 0.1 |  |  | — |  |  |  |  |  |  |  |  | 0.1 |  |
| Lease termination | — |  |  | — |  |  |  |  |  |  |  |  | — |  |
| Other | — |  |  | 0.4 |  |  | (0.2 | ) |  | (0.2 | ) |  | — |  |
| Total restructuring accruals | $ | 1.6 |  |  | $ | 1.8 |  |  | $ | (2.0 | ) |  | $ | (0.5 | ) |  | $ | 0.9 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-15-000011:notes:178]
[same as prior period, unchanged from 0001069202-15-000008:notes:176]

[0001069202-15-000011:notes:179]
[same as prior period, unchanged from 0001069202-15-000008:notes:177]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-15-000011:notes:180]
[same as prior period, unchanged from 0001069202-15-000008:notes:178]

[0001069202-15-000011:notes:181]
[same as prior period, unchanged from 0001069202-15-000008:notes:179]

[0001069202-15-000011:notes:182]
[same as prior period, unchanged from 0001069202-15-000008:notes:180]

[0001069202-15-000011:notes:183]
[same as prior period, unchanged from 0001069202-15-000008:notes:181]

[0001069202-15-000011:notes:184]
[same as prior period, unchanged from 0001069202-15-000008:notes:182]

[0001069202-15-000011:notes:185]
[same as prior period, unchanged from 0001069202-15-000008:notes:183]

[0001069202-15-000011:notes:186]
[same as prior period, unchanged from 0001069202-15-000008:notes:184]

[0001069202-15-000011:notes:187]
[same as prior period, unchanged from 0001069202-15-000008:notes:185]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-15-000011:notes:188]
[same as prior period, unchanged from 0001069202-15-000008:notes:186]

[0001069202-15-000011:notes:189]
Our Board of Directors has authorized a total of $1.4 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first nine months of 2015. As of September 30, 2015, $396.0 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-15-000011:notes:190]
We also repurchased 0.2 million shares for $23.5 million for the nine months ended September 30, 2015 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
