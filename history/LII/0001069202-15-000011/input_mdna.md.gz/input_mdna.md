# LII MD&A — 0001069202-15-000011


## mdna

[0001069202-15-000011:mdna:1]
[same as prior period, unchanged from 0001069202-15-000008:mdna:1]

[0001069202-15-000011:mdna:2]
[same as prior period, unchanged from 0001069202-15-000008:mdna:2]

[0001069202-15-000011:mdna:3]
[same as prior period, unchanged from 0001069202-15-000008:mdna:3]

[0001069202-15-000011:mdna:4]
[same as prior period, unchanged from 0001069202-15-000008:mdna:4]

[0001069202-15-000011:mdna:5]
[same as prior period, unchanged from 0001069202-15-000008:mdna:5]

[0001069202-15-000011:mdna:6]
[same as prior period, unchanged from 0001069202-15-000008:mdna:6]

[0001069202-15-000011:mdna:7]
[same as prior period, unchanged from 0001069202-15-000008:mdna:7]

[0001069202-15-000011:mdna:8]
In the third quarter of 2015, the Residential Heating & Cooling segment continued to lead our overall operational performance with a 12% increase in net sales and a $21 million increase in segment profit compared to the third quarter of 2014.  The primary growth drivers for this segment were increases in both price and mix as well as volume gains.  Our Commercial Heating & Cooling segment also performed well in the third quarter of 2015 with a 2% increase in net sales and $3 million in increased segment profit compared to the third quarter of 2014.  This segment's profits were up largely due to volume increases and material cost savings partially offset by unfavorable mix and unfavorable foreign currency exchange rates.  Sales in our Refrigeration segment decreased by 2% while segment profit increased $4 million compared to the third quarter of 2014.  Higher sales volume, higher productivity, and lower material costs were partially offset by lower mix and unfavorable foreign currency exchange rates.

[0001069202-15-000011:mdna:9]
On a consolidated basis, our product profit margins improved quarter over quarter primarily due to lower material costs and higher productivity.  We continue to manage our cost structure by utilizing a combination of commodity hedging and controllable product cost management initiatives.

[0001069202-15-000011:mdna:10]
[same as prior period, unchanged from 0001069202-15-000008:mdna:10]

[0001069202-15-000011:mdna:11]
| • | Net sales increased $57 million, or 6%, to $955 million in the third quarter of 2015 compared to $898 million in the third quarter of 2014. |

[0001069202-15-000011:mdna:12]
| • | Operational income from continuing operations in the third quarter of 2015 increased $20 million to $127 million from $107 million in the third quarter of 2014. |

[0001069202-15-000011:mdna:13]
| • | Net income for the third quarter of 2015 increased $13 million to $80 million from $67 million in the third quarter of 2014. |

[0001069202-15-000011:mdna:14]
| • | Diluted earnings per share from continuing operations were $1.76 per share in the third quarter of 2015 compared to $1.38 per share in the third quarter of 2014. |

[0001069202-15-000011:mdna:15]
| • | During the third quarter of 2015, we returned $16 million to shareholders through dividend payments. |

[0001069202-15-000011:mdna:16]
| • | Cash provided by operating activities was $107 million in the first nine months of 2015 compared to $24 million in the first nine months of 2014. |

[0001069202-15-000011:mdna:17]
Third Quarter of 2015 Compared to Third Quarter of 2014 - Consolidated Results

[0001069202-15-000011:mdna:18]
[same as prior period, unchanged from 0001069202-15-000008:mdna:18]

[0001069202-15-000011:mdna:19]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | $ | 955.0 |  |  | $ | 898.4 |  |  | 6.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 681.6 |  |  | 651.3 |  |  | (4.7 | ) |  | 71.4 |  |  | 72.5 |  |
| Gross profit | 273.4 |  |  | 247.1 |  |  | 10.6 |  |  | 28.6 |  |  | 27.5 |  |
| Selling, general and administrative expenses | 143.8 |  |  | 140.9 |  |  | (2.1 | ) |  | 15.1 |  |  | 15.7 |  |
| Losses (gains) and other expenses, net | 6.0 |  |  | 2.1 |  |  | 185.7 |  |  | 0.6 |  |  | 0.2 |  |
| Restructuring charges | (0.4 | ) |  | 1.0 |  |  | 140.0 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (3.0 | ) |  | (3.5 | ) |  | (14.3 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Operational income from continuing operations | $ | 127.0 |  |  | $ | 106.6 |  |  | 19.1 | % |  | 13.3 | % |  | 11.9 | % |

[0001069202-15-000011:mdna:20]
[same as prior period, unchanged from 0001069202-15-000008:mdna:20]

[0001069202-15-000011:mdna:21]
Net sales increased 6% in the third quarter of 2015 compared to the third quarter of 2014, primarily from 9% higher sales volumes and 2% favorable price and mix.  The Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments all delivered higher volume and pricing by capturing additional replacement and new construction business.  These increases were partially offset by a 5% unfavorable impact from foreign currency exchanges rates.

[0001069202-15-000011:mdna:22]
[same as prior period, unchanged from 0001069202-15-000008:mdna:22]

[0001069202-15-000011:mdna:23]
Gross profit margin in the third quarter of 2015 increased 110 basis points ("bps") to 28.6% compared to the third quarter of 2014.  Our profit margin increased 190 bps from lower material costs, 40 bps from price, and 30 bps from foreign currency translation. Offsetting this increase were decreases of 130 bps for unfavorable mix and 20 bps investments in distribution and other growth initiatives with the balance from other cost changes.

[0001069202-15-000011:mdna:24]
[same as prior period, unchanged from 0001069202-15-000008:mdna:24]

[0001069202-15-000011:mdna:25]
SG&A was $144 million in the third quarter of 2015 compared to $141 million in the third quarter of 2014, and as a percentage of net sales declined 60 bps to 15.1%.  SG&A expenses have increased at a slower pace than the increase in net sales.

[0001069202-15-000011:mdna:26]
[same as prior period, unchanged from 0001069202-15-000008:mdna:26]

[0001069202-15-000011:mdna:27]
Losses (gains) and other expenses, net for the third quarter of 2015 and 2014 included the following (in millions):

[0001069202-15-000011:mdna:28]
|  | For the Three Months Ended September 30, |
|  | 2015 |  | 2014 |
| Realized losses on settled future contracts | $ | 0.6 |  |  | $ | 0.1 |  |
| Foreign currency exchange losses (gains) | 1.4 |  |  | 0.1 |  |
| Gain on disposal of fixed assets | 0.1 |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.8 |  |  | 0.2 |  |
| Special legal contingency charges | 1.3 |  |  | 0.5 |  |
| Asbestos-related litigation | 0.4 |  |  | 0.4 |  |
| Contractor tax payments | 0.8 |  |  | — |  |
| Environmental liabilities | 0.3 |  |  | 0.7 |  |
| Other items, net | 0.3 |  |  | — |  |
| Losses (gains) and other expenses, net | $ | 6.0 |  |  | $ | 2.1 |  |

[0001069202-15-000011:mdna:29]
The net change in unrealized losses (gains) on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange losses increased in the third quarter of 2015 primarily due to the Australian and Canadian dollar exchange rates.  Contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  For more information on special legal contingency charges, asbestos-related litigation and contractor tax payments, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000011:mdna:30]
[same as prior period, unchanged from 0001069202-15-000008:mdna:30]

[0001069202-15-000011:mdna:31]
There was a minimal benefit from restructuring charges in the third quarter of 2015 while $1.0 million of restructuring charges were incurred in the third quarter of 2014.  The benefit in the current quarter is due to actual restructuring charges being less than planned restructuring charges.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000011:mdna:32]
[same as prior period, unchanged from 0001069202-15-000008:mdna:32]

[0001069202-15-000011:mdna:33]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $3 million in the third quarter of 2015 decreased slightly from the third quarter of 2014.

[0001069202-15-000011:mdna:34]
[same as prior period, unchanged from 0001069202-15-000008:mdna:34]

[0001069202-15-000011:mdna:35]
Interest expense, net of $6 million in the third quarter of 2015 increased from $4 million in the third quarter of 2014 due primarily to an increase in our average borrowings.

[0001069202-15-000011:mdna:36]
[same as prior period, unchanged from 0001069202-15-000008:mdna:36]

[0001069202-15-000011:mdna:37]
The Provision for income taxes was $42 million in the third quarter of 2015 compared to $35 million in the third quarter of 2014.  The effective tax rate was 34.2% for the third quarter of 2015 and the third quarter of 2014.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-15-000011:mdna:38]
Third Quarter of 2015 Compared to Third Quarter of 2014 - Results by Segment

[0001069202-15-000011:mdna:39]
[same as prior period, unchanged from 0001069202-15-000008:mdna:39]

[0001069202-15-000011:mdna:40]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000011:mdna:41]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 517.9 |  |  | $ | 462.6 |  |  | $ | 55.3 |  |  | 12.0 | % |
| Profit | $ | 90.1 |  |  | $ | 69.4 |  |  | $ | 20.7 |  |  | 29.8 | % |
| % of net sales | 17.4 | % |  | 15.0 | % |  |  |  |  |

[0001069202-15-000011:mdna:42]
Net sales increased by 12% in the third quarter of 2015 compared to the third quarter of 2014.  Volume increased by 10% due to industry growth and market share gains, and favorable price and mix increased net sales by 3%, with a 1% decrease from unfavorable foreign currency exchange rates.

[0001069202-15-000011:mdna:43]
Segment profit for the third quarter of 2015 increased $21 million due to $13 million in higher sales volumes, $10 million in material cost savings, $5 million from favorable price and mix, and $2 million from favorable factory productivity and other product costs.  Partially offsetting these increases was $3 million of unfavorable foreign currency exchange rates, $3 million of higher SG&A expenses due to increased wages and higher information technology investments, $2 million from investments in distribution, and $1 million in higher warranty expenses.

[0001069202-15-000011:mdna:44]
[same as prior period, unchanged from 0001069202-15-000008:mdna:44]

[0001069202-15-000011:mdna:45]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000011:mdna:46]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 246.8 |  |  | $ | 241.6 |  |  | $ | 5.2 |  |  | 2.2 | % |
| Profit | $ | 44.8 |  |  | $ | 42.2 |  |  | $ | 2.6 |  |  | 6.2 | % |
| % of net sales | 18.2 | % |  | 17.5 | % |  |  |  |  |

[0001069202-15-000011:mdna:47]
Net sales increased 2% in the third quarter of 2015 compared to the third quarter of 2014.  Sales volume increased by 7% primarily due to high single digit growth in North American service and mid single digit growth in North American equipment. Price and mix combined had a favorable 1% impact compared to the third quarter of 2014 and unfavorable foreign currency exchange rates had a negative 6% impact.

[0001069202-15-000011:mdna:48]
Segment profit in the third quarter of 2015 increased $3 million compared to the third quarter of 2014, primarily due to $5 million in higher sales volumes and $3 million from material cost savings, $1 million from price, $1 million from lower warranty expense and $1 million from lower other product costs. Partially offsetting these increases was $5 million in unfavorable mix, $2 million of unfavorable foreign currency exchange rates net of specific price increases, and $1 million of higher SG&A expenses.

[0001069202-15-000011:mdna:49]
[same as prior period, unchanged from 0001069202-15-000008:mdna:49]

[0001069202-15-000011:mdna:50]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000011:mdna:51]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 190.3 |  |  | $ | 194.2 |  |  | $ | (3.9 | ) |  | (2.0 | )% |
| Profit | $ | 20.3 |  |  | $ | 16.5 |  |  | $ | 3.8 |  |  | 23.0 | % |
| % of net sales | 10.7 | % |  | 8.5 | % |  |  |  |  |

[0001069202-15-000011:mdna:52]
Net sales decreased 2% in the third quarter of 2015 compared to the third quarter of 2014 primarily due to an 10% unfavorable impact from foreign currency exchange rates.  These decreases were partially offset by 7% volume growth led by our North

[0001069202-15-000011:mdna:53]
American supermarket businesses and by 1% from combined price and mix.

[0001069202-15-000011:mdna:54]
Segment profit for the third quarter of 2015 increased $4 million compared to the third quarter of 2014.  Higher sales volumes of $1 million, $4 million from lower material costs, $3 million of lower SG&A expenses from the results of North America and Australia restructuring activities, and $2 million from factory productivity and other product costs.  These increases were partially offset by $5 million of unfavorable mix, predominantly in the North American supermarket business and $1 million from unfavorable foreign currency exchanges rates.

[0001069202-15-000011:mdna:55]
[same as prior period, unchanged from 0001069202-15-000008:mdna:55]

[0001069202-15-000011:mdna:56]
Corporate and other expenses increased $6 million to $24 million in the third quarter of 2015 from $18 million in the third quarter of 2014 due primarily to incentive compensation expense, general wage inflation and higher health care costs.

[0001069202-15-000011:mdna:57]
Year-to-Date through September 30, 2015 Compared to Year-to-Date through September 30, 2014 - Consolidated Results

[0001069202-15-000011:mdna:58]
[same as prior period, unchanged from 0001069202-15-000008:mdna:58]

[0001069202-15-000011:mdna:59]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | $ | 2,633.3 |  |  | $ | 2,554.6 |  |  | 3.1 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,913.5 |  |  | 1,876.7 |  |  | 2.0 |  |  | 72.7 |  |  | 73.5 |  |
| Gross profit | 719.8 |  |  | 677.9 |  |  | 6.2 |  |  | 27.3 |  |  | 26.5 |  |
| Selling, general and administrative expenses | 430.0 |  |  | 425.5 |  |  | 1.1 |  |  | 16.3 |  |  | 16.7 |  |
| Losses and other expenses, net | 14.9 |  |  | 3.5 |  |  | 325.7 |  |  | 0.6 |  |  | 0.1 |  |
| Restructuring charges | 1.8 |  |  | 1.3 |  |  | 38.5 |  |  | 0.1 |  |  | 0.1 |  |
| Income from equity method investments | (11.8 | ) |  | (12.0 | ) |  | (1.7 | ) |  | (0.4 | ) |  | (0.5 | ) |
| Operational income from continuing operations | $ | 284.9 |  |  | $ | 259.6 |  |  | 9.7 |  |  | 10.8 | % |  | 10.2 | % |

[0001069202-15-000011:mdna:60]
[same as prior period, unchanged from 0001069202-15-000008:mdna:60]

[0001069202-15-000011:mdna:61]
Net sales increased 3% in the first nine months of 2015 compared to the first nine months of 2014, with sales volumes up 5% and price and mix up 2%.  The volume increases were driven by our Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments all capturing additional replacement and new construction business.  Partially offsetting these increases was a 4% decrease from unfavorable foreign currency exchange rates.

[0001069202-15-000011:mdna:62]
[same as prior period, unchanged from 0001069202-15-000008:mdna:62]

[0001069202-15-000011:mdna:63]
Gross profit margins in the first nine months of 2015 increased 80 bps to 27% compared to the first nine months of 2014.  Improvements of 210 bps from material cost savings were offset by 70 bps from unfavorable price and mix, 30 bps for investments in distribution and other growth initiatives, 20 bps from lower refrigerant pricing on our Australia wholesale business when compared to the prior year quarter with the balance attributable to increased other product costs.

[0001069202-15-000011:mdna:64]
[same as prior period, unchanged from 0001069202-15-000008:mdna:64]

[0001069202-15-000011:mdna:65]
SG&A was $430 million for the first nine months of 2015 compared to $426 million for the first nine months of 2014, and as a percentage of net sales, declined 40 bps from 16.7% to 16.3%.  SG&A expenses have increased at a slower pace than the increase in net sales.

[0001069202-15-000011:mdna:66]
[same as prior period, unchanged from 0001069202-15-000008:mdna:66]

[0001069202-15-000011:mdna:67]
Losses and other expenses, net for the first nine months of 2015 and 2014 included the following (in millions):

[0001069202-15-000011:mdna:68]
|  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |
| Realized losses on settled future contracts | $ | 1.3 |  |  | $ | 0.6 |  |
| Foreign currency exchange losses (gains) | 2.7 |  |  | 0.1 |  |
| Gain on disposal of fixed assets | 0.1 |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.9 |  |  | 0.1 |  |
| Special legal contingency charges | 5.5 |  |  | 0.7 |  |
| Asbestos-related litigation | 1.0 |  |  | 1.0 |  |
| Environmental liabilities | 0.7 |  |  | 0.7 |  |
| Contractor tax payments | 2.4 |  |  | — |  |
| Other items, net | 0.3 |  |  | 0.3 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 14.9 |  |  | $ | 3.5 |  |

[0001069202-15-000011:mdna:69]
Foreign currency exchange losses increased in the third quarter of 2015 primarily due to the Australian and Canadian dollar exchange rates. Special legal contingency charges increased for our estimate of costs expected to be incurred for an attempted class action lawsuit.  Contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  For more information on special legal contingency charges, asbestos-related litigation and contractor tax payments, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000011:mdna:70]
[same as prior period, unchanged from 0001069202-15-000008:mdna:70]

[0001069202-15-000011:mdna:71]
Restructuring charges increased to $2 million in the first nine months of 2015 as compared to $1 million in the first nine months of 2014.  The increase was primarily due to the restructuring of our Australian operations in the Refrigeration segment.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000011:mdna:72]
[same as prior period, unchanged from 0001069202-15-000008:mdna:72]

[0001069202-15-000011:mdna:73]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $12 million in the first nine months of 2015 was relatively flat as compared to the first nine months of 2014.

[0001069202-15-000011:mdna:74]
[same as prior period, unchanged from 0001069202-15-000008:mdna:74]

[0001069202-15-000011:mdna:75]
Interest expense, net of $18 million in the first nine months of 2015 increased from $11 million in the first nine months of 2014 due to an increase in our average net borrowings and an increase in our weighted average borrowing rates over the comparable periods.

[0001069202-15-000011:mdna:76]
[same as prior period, unchanged from 0001069202-15-000008:mdna:76]

[0001069202-15-000011:mdna:77]
The Provision for income taxes was $92 million in the first nine months of 2015 compared to $87 million in the first nine months of 2014.  The effective tax rate was 34.3% for the first nine months of 2015 compared to 34.8% for the first nine months of 2014.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-15-000011:mdna:78]
Year-to-Date through September 30, 2015 Compared to Year-to-Date through September 30, 2014 - Results by Segment

[0001069202-15-000011:mdna:79]
[same as prior period, unchanged from 0001069202-15-000008:mdna:79]

[0001069202-15-000011:mdna:80]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first nine months of 2015 and 2014 (dollars in millions):

[0001069202-15-000011:mdna:81]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 1,435.6 |  |  | $ | 1,332.5 |  |  | $ | 103.1 |  |  | 7.7 | % |
| Profit | $ | 221.3 |  |  | $ | 178.8 |  |  | $ | 42.5 |  |  | 23.8 | % |
| % of net sales | 15.4 | % |  | 13.4 | % |  |  |  |  |

[0001069202-15-000011:mdna:82]
Net sales increased by 8%  in the first nine months of 2015 compared to the first nine months of 2014.  Sales volumes increased net sales by 6% due to industry growth and market share gains and the benefits of favorable price and mix contributed 3%.  Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-15-000011:mdna:83]
Segment profit for the first nine months of 2015 increased $43 million due to $34 million from material cost savings, $20 million from higher sales volume, and $14 million from favorable price and mix. Partially offsetting these increases was $8 million of unfavorable foreign exchange rates, $7 million in distribution expenses related to continued investment in distribution expansion, and $10 million of SG&A inflation.

[0001069202-15-000011:mdna:84]
[same as prior period, unchanged from 0001069202-15-000008:mdna:84]

[0001069202-15-000011:mdna:85]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first nine months of 2015 and 2014 (dollars in millions):

[0001069202-15-000011:mdna:86]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 660.3 |  |  | $ | 655.6 |  |  | $ | 4.7 |  |  | 0.7 | % |
| Profit | $ | 95.5 |  |  | $ | 91.3 |  |  | $ | 4.2 |  |  | 4.6 | % |
| % of net sales | 14.5 | % |  | 13.9 | % |  |  |  |  |

[0001069202-15-000011:mdna:87]
Commercial Heating & Cooling net sales increased by 1% in the first nine months of 2015 compared to the first nine months of 2014. Sales volumes increased net sales by 5% and changes in foreign currency exchange rates unfavorably impacted net sales by 4%.

[0001069202-15-000011:mdna:88]
Segment profit in the first nine months of 2015 increased $4 million compared to the first nine months of 2014.  The benefits of $11 million from incremental volume, $10 million from material cost savings, $1 million lower warranty and other product costs, and $1 million from price were partially offset by $9 million in unfavorable mix, $4 million for information technology, distribution investments and start-up costs to enter the VRF market, $2M for unfavorable foreign exchange rates and $4 million of higher SG&A expenses.

[0001069202-15-000011:mdna:89]
[same as prior period, unchanged from 0001069202-15-000008:mdna:89]

[0001069202-15-000011:mdna:90]
The following table presents our Refrigeration segment's net sales and profit for the first nine months of 2015 and 2014 (dollars in millions):

[0001069202-15-000011:mdna:91]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 537.4 |  |  | $ | 566.5 |  |  | $ | (29.1 | ) |  | (5.1 | )% |
| Profit | $ | 37.5 |  |  | $ | 42.3 |  |  | $ | (4.8 | ) |  | (11.3 | )% |
| % of net sales | 7.0 | % |  | 7.5 | % |  |  |  |  |

[0001069202-15-000011:mdna:92]
Refrigeration net sales declined 5% in the first nine months of 2015 compared to the first nine months of 2014 primarily due to an 8% impact from unfavorable foreign exchange rates and a 2% impact from the Australian carbon levy repeal that was effective July 1, 2014.  These decreases were partially offset by 5% volume growth, led by our North America supermarket businesses.

[0001069202-15-000011:mdna:93]
Segment profit for the first nine    months of 2015 decreased $5 million compared to the first nine months of 2014 primarily due to $12 million from unfavorable mix predominantly in the North American supermarket business, $9 million lower profitability

[0001069202-15-000011:mdna:94]
in our Australia refrigerant business, $1 million of costs related to investments for future growth, and $4 million from unfavorable foreign currency exchange rates.  Partially offsetting these decreases were $10 million from material cost savings, $2 million from higher sales volumes, $1 million from lower SG&A due to North American and Australia restructuring activities, and $8 million from factory productivity and other product costs.

[0001069202-15-000011:mdna:95]
[same as prior period, unchanged from 0001069202-15-000008:mdna:95]

[0001069202-15-000011:mdna:96]
Corporate and other expenses increased $10 million to $58 million in the first nine months of 2015 from $48 million in the first nine months of 2014 due primarily to higher incentive compensation, general wage inflation, health care costs and currency losses.

[0001069202-15-000011:mdna:97]
[same as prior period, unchanged from 0001069202-15-000008:mdna:97]

[0001069202-15-000011:mdna:98]
[same as prior period, unchanged from 0001069202-15-000008:mdna:98]

[0001069202-15-000011:mdna:99]
[same as prior period, unchanged from 0001069202-15-000008:mdna:99]

[0001069202-15-000011:mdna:100]
The following table summarizes our cash flow activity for the nine months ended September 30, 2015 and 2014 (in millions):

[0001069202-15-000011:mdna:101]
|  | For the Nine Months Ended September 30, |
|  | 2015 |  | 2014 |
| Net cash provided by operating activities | $ | 106.9 |  |  | $ | 23.5 |  |
| Net cash used in investing activities | (47.0 | ) |  | (59.7 | ) |
| Net cash (used in) provided by financing activities | (52.9 | ) |  | 49.7 |  |

[0001069202-15-000011:mdna:102]
Net Cash Provided by Operating Activities - Net cash provided by operating activities increased approximately $83 million in the first nine months of 2015 compared to $24 million in the first nine months of 2014.   This increase was primarily attributable to the seasonal decrease in working capital requirements in 2015 being smaller than the decrease in 2014.

[0001069202-15-000011:mdna:103]
Net Cash Used in Investing Activities - Capital expenditures were $47 million and $60 million in the first nine months of 2015 and 2014, respectively.  Capital expenditures in 2015 were primarily related to investments in systems and software to support the overall enterprise and continued investments in our distribution network.

[0001069202-15-000011:mdna:104]
Net Cash (Used in) Provided by Financing Activities - Net cash used in financing activities increased to $53 million in the first nine months of 2015 primarily due to an increase in payments on borrowings and partially offset by decreases in stock repurchases.   Net borrowings were higher in 2015 to support the increased stock repurchases and dividend payments.  Final settlement of the $450 million Accelerated Share Repurchase Plan (ASR) executed in the fourth quarter of 2014 is expected in the fourth quarter of 2015.

[0001069202-15-000011:mdna:105]
[same as prior period, unchanged from 0001069202-15-000008:mdna:105]

[0001069202-15-000011:mdna:106]
The following table details our lines of credit and financing arrangements as of September 30, 2015 (in millions):

[0001069202-15-000011:mdna:107]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 6.3 |  |
| Asset Securitization Program (1) | 220.0 |  |
| Total short-term debt | $ | 226.3 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 1.2 |  |
| Domestic credit facility (2) | 22.5 |  |
| Total current maturities of long-term debt | $ | 23.7 |  |
| Long-term debt: |  |
| Capital lease obligations | 15.0 |  |
| Domestic credit facility (2) | 453.0 |  |
| Senior unsecured notes | 200.0 |  |
| Total long-term debt | 668.0 |  |
| Total debt | $ | 918.0 |  |

[0001069202-15-000011:mdna:108]
[same as prior period, unchanged from 0001069202-15-000008:mdna:108]

[0001069202-15-000011:mdna:109]
(2) The available future borrowings on our domestic credit facility are $447.6 million after being reduced by the outstanding borrowings and $4.4 million in outstanding standby letters of credit.  We also had $40.8 million in outstanding standby letters of credit outside of the domestic credit facility as of September 30, 2015.

[0001069202-15-000011:mdna:110]
[same as prior period, unchanged from 0001069202-15-000008:mdna:110]

[0001069202-15-000011:mdna:111]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 90.4% at September 30, 2015 from 99.0% at December 31, 2014.

[0001069202-15-000011:mdna:112]
As of September 30, 2015, our senior credit ratings were Baa3 with a negative outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to ensure the capital markets remain available to us.

[0001069202-15-000011:mdna:113]
[same as prior period, unchanged from 0001069202-15-000008:mdna:113]

[0001069202-15-000011:mdna:114]
We believe our cash and cash equivalents of $35 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $35 million as of September 30, 2015 was $21.3 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States. If we were to repatriate foreign earnings, we would be required to accrue and pay taxes in the United States, less foreign tax credits, for the amounts that were repatriated.

[0001069202-15-000011:mdna:115]
[same as prior period, unchanged from 0001069202-15-000008:mdna:115]

[0001069202-15-000011:mdna:116]
[same as prior period, unchanged from 0001069202-15-000008:mdna:116]

[0001069202-15-000011:mdna:117]
[same as prior period, unchanged from 0001069202-15-000008:mdna:117]

[0001069202-15-000011:mdna:118]
Commitments, Contingencies and Guarantees

[0001069202-15-000011:mdna:119]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000011:mdna:120]
[same as prior period, unchanged from 0001069202-15-000008:mdna:120]

[0001069202-15-000011:mdna:121]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001069202-15-000011:mdna:122]
In January 2015, the FASB issued ASU No. 2015-01, Income Statement - Extraordinary and Unusual Items (Subtopic 225-20): Simplifying Income Statement Presentation by Eliminating the Concept of Extraordinary Items. ASU No. 2015-01 eliminates the concept of an extraordinary item from GAAP. As a result, an entity will no longer be required to separately present an extraordinary item on its statement of operations, net of tax, after income from continuing operations or to disclose income taxes and net income per share data applicable to an extraordinary item. However, ASU No. 2015-01 will still retain the presentation and disclosure guidance for items that are unusual in nature and occur infrequently. ASU No. 2015-01 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period, although early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements, absent any material transactions in future periods that would have qualified for extraordinary item presentation under the prior guidance.

[0001069202-15-000011:mdna:123]
In February 2015, the FASB issued ASU 2015-02, Consolidation: Amendments to the Consolidation Analysis, or ASU 2015-02, which amends the criteria for determining which entities are considered variable interest entities (“VIEs”), amends the criteria for determining if a service provider possesses a variable interest in a VIE and ends the deferral granted to investment companies for application of the VIE consolidation model. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015 and early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements.

[0001069202-15-000011:mdna:124]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015, and early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements.
