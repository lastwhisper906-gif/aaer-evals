# LII note change history — 0001069202-15-000008 → 0001069202-15-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-10-19):
[0001069202-15-000011:note_history:1]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Accrued expenses | $ | 25.6 |  |  | $ | 27.3 |  |
| Other liabilities | 66.1 |  |  | 59.9 |  |
| Total warranty liability | $ | 91.7 |  |  | $ | 87.2 |  |
  (was, 2015-07-20, similarity 0.9687):
[0001069202-15-000008:note_history:1]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Accrued expenses | $ | 26.6 |  |  | $ | 27.3 |  |
| Other liabilities | 63.3 |  |  | 59.9 |  |
| Total warranty liability | $ | 89.9 |  |  | $ | 87.2 |  |

- changed (2015-10-19):
[0001069202-15-000011:note_history:2]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2015 were as follows (in millions):
  (was, 2015-07-20, similarity 0.9444):
[0001069202-15-000008:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2015 were as follows (in millions):

- changed (2015-10-19):
[0001069202-15-000011:note_history:3]
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |
| Warranty claims paid | (19.7 | ) |
| Changes resulting from issuance of new warranties | 27.4 |  |
| Changes in estimates associated with pre-existing liabilities | (1.6 | ) |
| Changes in foreign currency translation rates and other | (1.6 | ) |
| Total warranty liability as of September 30, 2015 | $ | 91.7 |  |
  (was, 2015-07-20, similarity 0.9815):
[0001069202-15-000008:note_history:3]
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |
| Warranty claims paid | (11.0 | ) |
| Changes resulting from issuance of new warranties | 16.9 |  |
| Changes in estimates associated with pre-existing liabilities | (2.3 | ) |
| Changes in foreign currency translation rates and other | (0.9 | ) |
| Total warranty liability as of June 30, 2015 | $ | 89.9 |  |

- added (2015-10-19):
[0001069202-15-000011:note_history:4]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable outstanding liability for a certain supplier quality issue within a range of $0.7 million and $4 million, with all amounts in that range equally likely.  In the prior quarter, we accrued a $1.7 million liability related to this supplier quality issue as well as a receivable from the supplier of $2.3 million.  In the third quarter of 2015, we recorded a $1.2 million expense to reduce this receivable from the supplier based on the nature and timing of warranty claims.  The supplier has previously reimbursed the Company for costs associated with this supplier quality issue and we expect that the supplier will continue to do so.

- changed (2015-10-19):
[0001069202-15-000011:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and is subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2015, and 2014, expense for asbestos-related litigation was $1.0 million, and $1.0 million, net of insurance recoveries, respectively.
  (was, 2015-07-20, similarity 0.9406):
[0001069202-15-000008:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2015, and 2014, expense for asbestos-related litigation was $0.4 million, and $0.6 million, net of insurance recoveries, respectively.

- changed (2015-10-19):
[0001069202-15-000011:note_history:6]
A lawsuit related to a vendor-supplied product quality issue settled for a lower amount than expected; accordingly, the Company reversed the $1.2 million excess portion of the loss contingency reserve in the second quarter of 2015.  The Company also discovered it underpaid contractor taxes at one of its non-U.S. subsidiaries; accordingly, the Company has recorded a loss contingency charge in the amount of $2.4 million for the nine months ended September 30, 2015. These items were recorded in "Losses (gains) and other expenses, net" on the Consolidated Statements of Operations.
  (was, 2015-07-20, similarity 0.6222):
[0001069202-15-000008:note_history:6]
A lawsuit related to a vendor-supplied product quality issue settled for a lower amount than expected; accordingly, the Company reversed the $1.2 million excess portion of the loss contingency reserve.  The Company also discovered it underpaid contractor taxes at one of its non-U.S. subsidiaries; accordingly, the Company recorded a loss contingency reserve in the amount of $1.6 million which represents the current estimate of the amount owed. These items were recorded in "Losses (gains) and other expenses, net" on the Consolidated Statements of Operations.

- removed (2015-10-19):
[0001069202-15-000008:note_history:7]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable remaining liability for a supplier quality issue within a range of $1.7 million and $5 million; accordingly, we have accrued a $1.7 million liability in Accrued expenses on the Consolidated Balance Sheet because all amounts in that range were equally likely. The supplier has agreed to reimburse our costs related to this liability; accordingly, we have also recorded a receivable of $2.3 million in Other assets on the Consolidated Balance Sheet, which includes amounts incurred by the Company but not yet reimbursed by the supplier.  If additional costs are incurred, we expect the supplier will also reimburse those costs. The$1.7 million accrual is not included in the estimated warranty liabilities tables immediately above.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-10-19):
[0001069202-15-000011:note_history:8]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2015, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2015 and 2014, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2015 and 2014, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2015 and 2014 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2014. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2015-07-20, similarity 0.9487):
[0001069202-15-000008:note_history:8]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2015, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2015 and 2014, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2015 and 2014, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2015 and 2014 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2014. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2015-10-19):
[0001069202-15-000011:note_history:9]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.
  (was, 2015-07-20, similarity 0.9993):
[0001069202-15-000008:note_history:9]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-10-19):
[0001069202-15-000011:note_history:10]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.69 | % |  | 1.88 | % |
  (was, 2015-07-20, similarity 0.9447):
[0001069202-15-000008:note_history:10]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.92 | % |  | 1.88 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-10-19):
[0001069202-15-000011:note_history:11]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 6.3 |  |  | 6.6 |  |
| Total short-term debt | $ | 226.3 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.2 |  |  | $ | 1.5 |  |
| Domestic credit facility | 22.5 |  |  | 22.5 |  |
| Total current maturities of long-term debt | $ | 23.7 |  |  | $ | 24.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.0 |  |  | $ | 15.5 |  |
| Domestic credit facility | 453.0 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 668.0 |  |  | $ | 675.0 |  |
| Total debt | $ | 918.0 |  |  | $ | 925.6 |  |

- changed (2015-10-19):
[0001069202-15-000011:note_history:12]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $6.3 million and $6.6 million of foreign obligations as of September 30, 2015 and December 31, 2014, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $63.6 million and $73.1 million during the nine months ended September 30, 2015 and 2014, respectively. Repayments on the facilities were $61.7 million and $65.6 million and during the nine months ended September 30, 2015 and 2014, respectively.
  (was, 2015-07-20, similarity 0.9026):
[0001069202-15-000008:note_history:12]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $6.1 million and $6.6 million of foreign obligations as of June 30, 2015 and December 31, 2014, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $32.4 million and $23.6 million during the six months ended June 30, 2015 and 2014, respectively. Repayments on the facilities were $32.1 million and $24.2 million and during the six months ended June 30, 2015 and 2014, respectively.

- added (2015-10-19):
[0001069202-15-000011:note_history:13]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 220.0 |  |  | 220.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

- changed (2015-10-19):
[0001069202-15-000011:note_history:14]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for September 30, 2015 and December 31, 2014 was 0.82% and 0.79% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2015-07-20, similarity 0.9924):
[0001069202-15-000008:note_history:14]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for June 30, 2015 and December 31, 2014 was 0.80% and 0.79% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2015-10-19):
[0001069202-15-000011:note_history:15]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2015, we were in compliance with all covenant requirements.
  (was, 2015-07-20, similarity 0.9902):
[0001069202-15-000008:note_history:15]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2015, we were in compliance with all covenant requirements.

- changed (2015-10-19):
[0001069202-15-000011:note_history:16]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consisted of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $475.5 million, of which $277.5 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of September 30, 2015. Subject to covenant limitations, $447.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. We paid $22.5 million in principal payments in June 2015 for the term loan, which represents the required principal payments for the remainder of 2015.  The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.
  (was, 2015-07-20, similarity 0.9946):
[0001069202-15-000008:note_history:16]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consisted of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $613.0 million, of which $277.5 million was the term loan balance, as well as $24.7 million committed to standby letters of credit as of June 30, 2015. Subject to covenant limitations, $289.8 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. We paid $22.5 million in principal payments in June 2015 for the term loan, which represents the required principal payments for the remainder of 2015.  The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2015-10-19):
[0001069202-15-000011:note_history:17]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.69 | % |  | 1.88 | % |
  (was, 2015-07-20, similarity 0.9447):
[0001069202-15-000008:note_history:17]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.92 | % |  | 1.88 | % |

- changed (2015-10-19):
[0001069202-15-000011:note_history:18]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2015, we were in compliance with all covenant requirements.
  (was, 2015-07-20, similarity 0.9734):
[0001069202-15-000008:note_history:18]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2015, we were in compliance with all covenant requirements.

- changed (2015-10-19):
[0001069202-15-000011:note_history:19]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2015, we were in compliance with all covenant requirements.
  (was, 2015-07-20, similarity 0.97):
[0001069202-15-000008:note_history:19]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2015, we were in compliance with all covenant requirements.

- removed (2015-10-19):
[0001069202-15-000008:note_history:20]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 6.1 |  |  | 6.6 |  |
| Total short-term debt | $ | 226.1 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.5 |  |
| Domestic credit facility | 15.0 |  |  | 22.5 |  |
| Total current maturities of long-term debt | $ | 16.3 |  |  | $ | 24.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.2 |  |  | $ | 15.5 |  |
| Domestic credit facility | 598.0 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 813.2 |  |  | $ | 675.0 |  |
| Total debt | $ | 1,055.6 |  |  | $ | 925.6 |  |

- removed (2015-10-19):
[0001069202-15-000008:note_history:21]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 220.0 |  |  | 220.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-10-19):
[0001069202-15-000011:note_history:22]
|  | As of September 30, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 6.3 |  |  | 6.6 |  |
| Total short-term debt | $ | 226.3 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.2 |  |  | $ | 1.5 |  |
| Domestic credit facility | 22.5 |  |  | 22.5 |  |
| Total current maturities of long-term debt | $ | 23.7 |  |  | $ | 24.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.0 |  |  | $ | 15.5 |  |
| Domestic credit facility | 453.0 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 668.0 |  |  | $ | 675.0 |  |
| Total debt | $ | 918.0 |  |  | $ | 925.6 |  |

- removed (2015-10-19):
[0001069202-15-000008:note_history:23]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 6.1 |  |  | 6.6 |  |
| Total short-term debt | $ | 226.1 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.5 |  |
| Domestic credit facility | 15.0 |  |  | 22.5 |  |
| Total current maturities of long-term debt | $ | 16.3 |  |  | $ | 24.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.2 |  |  | $ | 15.5 |  |
| Domestic credit facility | 598.0 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 813.2 |  |  | $ | 675.0 |  |
| Total debt | $ | 1,055.6 |  |  | $ | 925.6 |  |
