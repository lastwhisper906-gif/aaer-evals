# LII note change history — 0000950134-10-000015 → 0000950123-10-096054


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2010-10-26):
[0000950123-10-096054:note_history:1]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to
   provide protection against claims relating to contingencies such as workers’ compensation,
   general liability, product liability, property damage, aviation liability, directors’ and officers’
   liability, auto liability, physical damage and other exposures. Self-insurance expense and
   liabilities are actuarially determined based on our
   historical claims information, as well as
   industry factors and trends and because we have a captive insurance company, we are required to
   maintain specified levels of liquid assets from which we must pay claims. The majority of our
   self-insured risks (excluding auto liability and physical damage) will be paid over an extended
   period of time. There have been no material changes since our latest fiscal year-end. We also
   maintain third-party insurance coverage for risks not retained within our large deductible or
   captive insurance plans. The self-insurance liabilities recorded in Accrued Expenses in the
   accompanying Consolidated Balance Sheets were $63.3 million and $60.4 million as of September 30,
   2010 and December 31, 2009, respectively.
  (was, 2010-07-27, similarity 0.9944):
[0000950134-10-000015:note_history:1]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to provide protection against claims relating to contingencies such as workers’
   compensation, general liability, product liability, property damage, aviation liability, directors’
   and officers’ liability, auto liability, physical damage and other exposures. Self-insurance
   expense and liabilities are actuarially determined based on our
   historical claims information, as
   well as industry factors and trends and because we have a captive insurance company, we are
   required to maintain specified levels of liquid assets from which we must pay claims. The majority
   of our self-insured risks (excluding auto liability and physical damage) will be paid over an
   extended period of time. There have been no material changes since our latest fiscal year-end. We
   also maintain third-party insurance coverage for risks not retained within our large deductible or
   captive insurance plans. The self-insurance liabilities recorded in Accrued Expenses in the
   accompanying Consolidated Balance Sheets were $64.2 million and $60.4 million as of June 30, 2010
   and December 31, 2009, respectively.

- added (2010-10-26):
[0000950123-10-096054:note_history:2]
Product Warranties and Product Related Contingencies

- changed (2010-10-26):
[0000950123-10-096054:note_history:3]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued Expenses |  | $ | 31.5 |  |  | $ | 31.5 |  |
| Other Liabilities |  |  | 44.6 |  |  |  | 50.0 |  |
|  |  | $ | 76.1 |  |  | $ | 81.5 |  |
  (was, 2010-07-27, similarity 0.9723):
[0000950134-10-000015:note_history:3]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued Expenses |  | $ | 29.6 |  |  | $ | 31.5 |  |
| Other Liabilities |  |  | 46.3 |  |  |  | 50.0 |  |
|  |  | $ | 75.9 |  |  | $ | 81.5 |  |

- changed (2010-10-26):
[0000950123-10-096054:note_history:4]
The changes in the total warranty liabilities for the first nine months of 2010 were as
   follows (in millions):
  (was, 2010-07-27, similarity 0.9765):
[0000950134-10-000015:note_history:4]
The changes in the total warranty liabilities for the first six months of 2010 were as follows
   (in millions):

- changed (2010-10-26):
[0000950123-10-096054:note_history:5]
| Total warranty liability as of December 31, 2009 |  | $ | 81.5 |  |
| Payments made in 2010 |  |  | (21.2 | ) |
| Changes resulting from issuance of new warranties |  |  | 20.9 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (5.3 | ) |
| Changes in foreign currency exchange rates |  |  | 0.2 |  |
| Total warranty liability as of September 30, 2010 |  | $ | 76.1 |  |
  (was, 2010-07-27, similarity 0.969):
[0000950134-10-000015:note_history:5]
| Total warranty liability as of December 31, 2009 |  | $ | 81.5 |  |
| Payments made in 2010 |  |  | (12.9 | ) |
| Changes resulting from issuance of new warranties |  |  | 14.2 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (6.1 | ) |
| Changes in foreign currency exchange rates |  |  | (0.8 | ) |
| Total warranty liability as of June 30, 2010 |  | $ | 75.9 |  |

- changed (2010-10-26):
[0000950123-10-096054:note_history:6]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued product quality issue (not covered under warranty) |  | $ | 17.5 |  |  | $ | 21.6 |  |
  (was, 2010-07-27, similarity 0.9677):
[0000950134-10-000015:note_history:6]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued product quality issue (not covered under warranty) |  | $ | 18.9 |  |  | $ | 21.6 |  |

- added (2010-10-26):
[0000950123-10-096054:note_history:7]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete reevaluation of our heating, ventilation and air
   conditioning (“HVAC”) warranty liabilities. As a result of our annual evaluation, we have recorded
   a reduction of $6.3 million in warranty liabilities that is the principal amount contained within
   the changes in estimates associated with pre-existing liabilities.

- added (2010-10-26):
[0000950123-10-096054:note_history:8]
We have identified a product quality issue in a heating and cooling product line produced in
   2006 and 2007 that we believe results from a vendor-supplied materials quality issue. We have
   recorded an expense of $24.6 million in 2009 for the portion of the issue that is probable and can
   be reasonably estimated. There were no additional charges recorded in 2010. We may incur
   additional charges in the future as more information becomes available. The expense for this
   product quality issue, and the related liability, is not included in the tables related to our
   estimated warranty liabilities. The expense related to this product quality issue was classified
   in Cost of Goods Sold in the Consolidated Statements of Operations and the related liability is
   included in Accrued Expenses in the accompanying Consolidated Balance Sheets.

- added (2010-10-26):
[0000950123-10-096054:note_history:9]
We estimate the costs to settle pending litigation based on experience involving similar
   claims and specific facts known. We do not believe that any current or pending or threatened
   litigation will have a material adverse effect on our financial position. Litigation and
   arbitration, however, involve uncertainties and it is possible that the eventual outcome of
   litigation could adversely affect our results of operations for a particular period. We are the
   defendant in a class action lawsuit related to certain hearth products we produced and sold that
   claims such products are hazardous and that consumers were not adequately warned. On August 23,
   2010, the Company and the plaintiffs entered into a binding Memorandum of Understanding (“MOU”) and
   have reached tentative terms for settlement of the case. At the parties’ request, the court has
   stayed the litigation. If the terms of the MOU are fulfilled, as is expected, the parties will
   file a motion for preliminary approval of the settlement with the court by December 1, 2010. Total
   charges related to this matter recorded in the first nine months of 2010 were $8.2 million. We
   recorded charges totaling $2.6 million related to this matter during the third quarter of 2010 and
   we may incur additional charges in the future. These charges are included in Selling, General and
   Administrative Expenses and Losses (Gains) and Other Expenses, Net in the accompanying Consolidated
   Statement of Operations.

- changed (2010-10-26):
[0000950123-10-096054:note_history:10]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We are in compliance with these financial covenants as of September 30, 2010.
  (was, 2010-07-27, similarity 0.9826):
[0000950134-10-000015:note_history:10]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We are in compliance with these financial covenants as of June 30, 2010.

- removed (2010-10-26):
[0000950134-10-000015:note_history:11]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete reevaluation of our warranty liabilities. As a
   result of our annual evaluation, we have recorded a reduction in warranty liabilities that is the
   principal amount contained within the changes in estimates associated with pre-existing liabilities
   of $6.1 million above.

- removed (2010-10-26):
[0000950134-10-000015:note_history:12]
We have identified a product quality issue in a heating and cooling product line produced in
   2006 and 2007 that we believe results from a vendor-supplied materials quality issue. We have
   recorded an expense of $24.6 million in 2009 for the portion of the issue that is probable and can
   be reasonably estimated based upon the current data available and $18.9 million remained accrued as
   of June 30, 2010. There were no provisions to 2010. We may incur additional charges in the future
   as more information becomes available. The expense for this product quality issue, and the related
   liability, is not included in the tables related to our estimated warranty
   liabilities. The
   expense related to this product quality issue was classified in Cost of Goods Sold in the
   Consolidated Statements of Operations and the related liability is included in Accrued Expenses in
   the accompanying Consolidated Balance Sheets.

- removed (2010-10-26):
[0000950134-10-000015:note_history:13]
We estimate the costs to settle pending litigation based on experience involving similar claims and
   specific facts known. We do not believe that any current or pending or threatened litigation with
   have a material adverse effect on our financial position. Litigation and arbitration, however,
   involve uncertainties and it is possible that the eventual outcome of litigation could adversely
   affect our results of operations for a particular period. We are the defendant in a class action
   lawsuit related to certain hearth products we produced and sold that claims such products are
   hazardous and that consumers were not adequately warned. We recorded charges totaling $5.6 million
   related to this matter during the second quarter of 2010 and we may incur additional charges in the
   future. These charges are included in Selling, General and Administrative Expenses and Losses
   (Gains) and Other Expenses, Net in the accompanying Consolidated Statement of Operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2010-10-26):
[0000950123-10-096054:note_history:14]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2010, the
   accompanying unaudited Consolidated Statements of Operations for the three and nine months ended
   September 30, 2010 and 2009, the accompanying unaudited Consolidated Statement of Stockholders’
   Equity for the nine months ended September 30, 2010 and the accompanying unaudited Consolidated
   Statements of Cash Flows for the nine months ended September 30, 2010 and 2009 should be read in
   conjunction with our audited consolidated financial statements and footnotes included in our Annual
   Report on Form 10-K for the year ended December 31, 2009. The accompanying unaudited consolidated
   financial statements have been prepared in accordance with generally accepted accounting principles
   (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of
   Regulation S-X. The accompanying consolidated financial statements contain all material
   adjustments, consisting principally of normal recurring adjustments, necessary for a fair
   presentation of our financial position, results of operations and cash flows. Certain information
   and footnote disclosures normally included in financial statements prepared in accordance with
   generally accepted accounting principles have been condensed or omitted pursuant to applicable
   rules and regulations, although we believe that the disclosures herein are adequate to make the
   information presented not misleading. The operating results for the interim periods are not
   necessarily indicative of the results that may be expected for the full year.
  (was, 2010-07-27, similarity 0.9494):
[0000950134-10-000015:note_history:14]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2010, the accompanying
   unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2010
   and 2009, the accompanying unaudited Consolidated Statement of Stockholders’ Equity for the six
   months ended June 30, 2010 and the accompanying unaudited Consolidated Statements of Cash Flows for
   the six months ended June 30, 2010 and 2009 should be read in conjunction with our audited
   consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the
   year ended December 31, 2009. The accompanying unaudited consolidated financial statements have
   been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim
   financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The
   accompanying consolidated financial statements contain all material adjustments, consisting
   principally of normal recurring adjustments, necessary for a fair presentation of our financial
   position, results of operations and cash flows. Certain information and footnote disclosures
   normally included in financial statements prepared in accordance with generally accepted accounting
   principles have been condensed or omitted pursuant to applicable rules and regulations, although we
   believe that the disclosures herein are adequate to make the information presented not misleading.
   The operating results for the interim periods are not necessarily indicative of the results that
   may be expected for the full year.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2010-10-26):
[0000950123-10-096054:note_history:15]
Long –Term Debt and Lines of Credit
  (was, 2010-07-27, similarity 0.9714):
[0000950134-10-000015:note_history:15]
Long —Term Debt and Lines of Credit

- added (2010-10-26):
[0000950123-10-096054:note_history:16]
| Description of Obligations |  | Short-Term |  |  | Current |  |  | Long-Term |  |  |  |  |
| As of September 30, 2010 |  | Debt |  |  | Maturities |  |  | Maturities |  |  | Total |  |
| Domestic revolving credit facility |  | $ | — |  |  | $ | — |  |  | $ | 145.0 |  |  | $ | 145.0 |  |
| Senior unsecured notes |  |  | — |  |  |  | — |  |  |  | 200.0 |  |  |  | 200.0 |  |
| Capital lease obligations |  |  | — |  |  |  | 0.8 |  |  |  | 17.1 |  |  |  | 17.9 |  |
| Foreign obligations |  |  | 8.2 |  |  |  | — |  |  |  | — |  |  |  | 8.2 |  |
| Total debt |  | $ | 8.2 |  |  | $ | 0.8 |  |  | $ | 362.1 |  |  | $ | 371.1 |  |

- added (2010-10-26):
[0000950123-10-096054:note_history:17]
| Description of Obligations |  | Short-Term |  |  | Current |  |  | Long-Term |  |  |  |  |
| As of December 31, 2009 |  | Debt |  |  | Maturities |  |  | Maturities |  |  | Total |  |
| Domestic promissory notes (1) |  | $ | — |  |  | $ | 35.0 |  |  | $ | — |  |  | $ | 35.0 |  |
| Domestic revolving credit facility |  |  | — |  |  |  | — |  |  |  | 176.5 |  |  |  | 176.5 |  |
| Capital lease obligations |  |  | — |  |  |  | 0.4 |  |  |  | 17.1 |  |  |  | 17.5 |  |
| Foreign obligations |  |  | 2.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 2.5 |  |
| Total debt |  | $ | 2.2 |  |  | $ | 35.5 |  |  | $ | 193.8 |  |  | $ | 231.5 |  |

- added (2010-10-26):
[0000950123-10-096054:note_history:18]
As of September 30, 2010, we had outstanding borrowings of $145.0 million under the $650
   million domestic revolving credit facility and $69.5 million was committed to standby letters of
   credit. All of the remaining $435.5 million was available for future borrowings after
   consideration of covenant limitations. The facility matures in October 2012. As of September 30,
   2010, we were in compliance with all covenant requirements.

- changed (2010-10-26):
[0000950123-10-096054:note_history:19]
We have additional borrowing capacity through several of our foreign subsidiaries used
   primarily to finance seasonal borrowing needs. We had $8.2 million and $2.5 million of obligations
   outstanding through our foreign subsidiaries as of September 30, 2010 and December 31, 2009,
   respectively. Available borrowing capacity at September 30, 2010 and December 31, 2009, under
   foreign facilities was $10.0 million and $12.6 million, respectively.
  (was, 2010-07-27, similarity 0.9679):
[0000950134-10-000015:note_history:19]
We have additional borrowing capacity through several of our foreign subsidiaries used
   primarily to finance seasonal borrowing needs. We had $6.1 million and $2.5 million of obligations
   outstanding through our foreign subsidiaries as of June 30, 2010 and December 31, 2009,
   respectively. Available borrowing capacity at June 30, 2010 and December 31, 2009, under foreign
   facilities was $11.9 million and $12.6 million, respectively.

- changed (2010-10-26):
[0000950123-10-096054:note_history:20]
The domestic revolving credit facility includes a subfacility for swingline loans of up to $50
   million and provides for the issuance of letters of credit for the full amount of the credit
   facility. Our weighted average borrowing rate on the facility was 0.96% and 0.84% as of September
   30, 2010 and December 31, 2009, respectively.
  (was, 2010-07-27, similarity 0.9404):
[0000950134-10-000015:note_history:20]
The domestic revolving credit facility includes a subfacility for swingline loans of up to $50
   million and provides for the issuance of letters of credit for the full amount of the credit
   facility. Our weighted average borrowing rate on the facility was 0.95% and 0.84% as of June 30,
   2010 and December 31, 2009, respectively.

- changed (2010-10-26):
[0000950123-10-096054:note_history:21]
Our domestic revolving credit facility contains financial covenants relating to leverage and
   interest coverage. Other covenants contained in the domestic revolving credit facility restrict,
   among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain defined levels of Consolidated Indebtedness to Adjusted EBITDA
   Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio.
   The required ratios under our domestic revolving credit facility as of September 30, 2010 are
   detailed below:
  (was, 2010-07-27, similarity 0.8983):
[0000950134-10-000015:note_history:21]
Other covenants contained in the domestic revolving credit facility restrict,
   among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain defined levels of Consolidated Indebtedness to Adjusted EBITDA
   Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio.
   The required ratios under our domestic revolving credit facility as of June 30, 2010 are detailed
   below:

- changed (2010-10-26):
[0000950123-10-096054:note_history:22]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |
  (was, 2010-07-27, similarity 0.9735):
[0000950134-10-000015:note_history:22]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than |  | 3.0 : 1.0 |

- changed (2010-10-26):
[0000950123-10-096054:note_history:23]
|  | • |  | we fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $40.0 million; or |
|  | • |  | we are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $40.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |
  (was, 2010-07-27, similarity 0.999):
[0000950134-10-000015:note_history:23]
|  | • |  | we fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $40.0 million; or |
|  | • |  | we are in default in the performance of, or compliance with, any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $40.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

- changed (2010-10-26):
[0000950123-10-096054:note_history:24]
Each of our major debt agreements contains provisions by which a default under one agreement
   causes a default in the others (a cross default). If a cross default under the revolving credit
   facility, our senior unsecured notes, or our revolving period asset securitization program were to
   occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a
   single debt instrument or lease commitment.
  (was, 2010-07-27, similarity 0.9514):
[0000950134-10-000015:note_history:24]
Each of our major debt agreements contains agreements by which
   a default under one agreement causes a default in the others. If a cross default under the revolving credit facility, our senior unsecured notes, or our revolving
   period asset securitization program was to occur, it could have a wider impact on our liquidity than might
   otherwise occur from a default of a single debt instrument or lease commitment.

- changed (2010-10-26):
[0000950123-10-096054:note_history:25]
During the first quarter of 2010, our captive insurance subsidiary entered into an agreement
   in which cash was placed into a trust for the benefit of a third-party insurance provider. The
   purpose of the trust is to pay Workers Compensation claims for policy years 2003 – 2009 until the
   liabilities are fully extinguished. These policies were written by the third-party insurance
   provider, and then reinsured by our captive insurance subsidiary. This transaction was classified
   as restricted cash on the accompanying Consolidated Balance Sheets. The balance at September 30,
   2010 was $13.1 million.
  (was, 2010-07-27, similarity 0.987):
[0000950134-10-000015:note_history:25]
During the first quarter of 2010, our captive insurance subsidiary entered into an agreement
   in which cash was placed into a trust for the benefit of a third-party insurance provider. The
   purpose of the trust is to pay Workers Compensation claims for policy years 2003 — 2009 until the
   liabilities are fully extinguished. These policies were written by the third-party insurance
   provider, and then reinsured by our captive insurance subsidiary. This transaction was classified
   as restricted cash on the accompanying Consolidated Balance Sheets. The balance at June 30, 2010
   was $23.8 million.

- changed (2010-10-26):
[0000950123-10-096054:note_history:26]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our Credit Agreement. The administrative
   agent under the ASA is also a participant in our Credit Agreement. The administrative agent has an
   investment grade credit rating. We continue to evaluate its creditworthiness and have no reason to
   believe it will not perform under the ASA. As of September 30, 2010, we were in compliance with all
   covenant requirements.
  (was, 2010-07-27, similarity 0.9474):
[0000950134-10-000015:note_history:26]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our Credit Agreement. The administrative
   agent under the ASA is also a participant in our Credit Agreement. The administrative agent has an
   investment grade credit rating. We continue to evaluate its creditworthiness and have no reason to
   believe it will not perform under the ASA. As of June 30, 2010, we were in compliance with all
   covenant requirements.

- changed (2010-10-26):
[0000950123-10-096054:note_history:27]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 93.9 |  |  | $ | 72.5 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 93.9 |  |  | $ | 72.5 |  |
  (was, 2010-07-27, similarity 0.9775):
[0000950134-10-000015:note_history:27]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 100.0 |  |  | $ | 72.5 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 100.0 |  |  | $ | 72.5 |  |

- changed (2010-10-26):
[0000950123-10-096054:note_history:28]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 1.15%. The rate
   was 1.45% and 1.38% as of September 30, 2010 and December 31, 2009, respectively. The unused fee is
   based on 102% of the maximum available amount less the beneficial interest sold and calculated at
   0.5% fixed rate throughout the term of the agreement. We recorded these fees in Selling, General
   and Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):
  (was, 2010-07-27, similarity 0.9918):
[0000950134-10-000015:note_history:28]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 1.15%. The rate
   was 1.58% and 1.38% as of June 30, 2010 and December 31, 2009, respectively. The unused fee is
   based on 102% of the maximum available amount less the beneficial interest sold and calculated at
   0.5% fixed rate throughout the term of the agreement. We recorded these fees in Selling, General
   and Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):

- changed (2010-10-26):
[0000950123-10-096054:note_history:29]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2010 |  | 2009 |  | 2010 |  | 2009 |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |
  (was, 2010-07-27, similarity 0.9284):
[0000950134-10-000015:note_history:29]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2010 |  | 2009 |  | 2010 |  | 2009 |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |

- removed (2010-10-26):
[0000950134-10-000015:note_history:30]
| Description of Obligations |  | Short-Term |  |  | Current |  |  | Long-Term |  |  |  |  |
| As of June 30, 2010 |  | Debt |  |  | Maturities |  |  | Maturities |  |  | Total |  |
| Domestic revolving credit facility |  | $ | — |  |  | $ | — |  |  | $ | 132.0 |  |  | $ | 132.0 |  |
| Senior unsecured notes |  |  | — |  |  |  | — |  |  |  | 200.0 |  |  |  | 200.0 |  |
| Capital lease obligations |  |  | — |  |  |  | 0.5 |  |  |  | 17.6 |  |  |  | 18.1 |  |
| Foreign obligations |  |  | 6.1 |  |  |  | — |  |  |  | — |  |  |  | 6.1 |  |
| Total debt |  | $ | 6.1 |  |  | $ | 0.5 |  |  | $ | 349.6 |  |  | $ | 356.2 |  |

- removed (2010-10-26):
[0000950134-10-000015:note_history:31]
| Description of Obligations |  | Short-Term |  |  | Current |  |  | Long-Term |  |  |  |  |
| As of June 31, 2009 |  | Debt |  |  | Maturities |  |  | Maturities |  |  | Total |  |
| Domestic promissory notes (1) |  | $ | — |  |  | $ | 35.0 |  |  | $ | — |  |  | $ | 35.0 |  |
| Domestic revolving credit facility |  |  | — |  |  |  | — |  |  |  | 176.5 |  |  |  | 176.5 |  |
| Capital lease obligations |  |  | — |  |  |  | 0.4 |  |  |  | 17.1 |  |  |  | 17.5 |  |
| Foreign obligations |  |  | 2.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 2.5 |  |
| Total debt |  | $ | 2.2 |  |  | $ | 35.5 |  |  | $ | 193.8 |  |  | $ | 231.5 |  |

- removed (2010-10-26):
[0000950134-10-000015:note_history:32]
As of June 30, 2010, we had outstanding borrowings of $132.0 million under the $650 million
   domestic revolving credit facility and $72.0 million was committed to standby letters of credit.
   All of the remaining $446.0 million was available for future borrowings after consideration of
   covenant limitations. The facility matures in October 2012. As of June 30, 2010, we were in
   compliance with all covenant requirements.

- removed (2010-10-26):
[0000950134-10-000015:note_history:33]
Our domestic revolving credit facility contains financial covenants relating to leverage and
   interest coverage.
