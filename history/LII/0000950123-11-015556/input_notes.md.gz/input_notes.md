# LII notes — 0000950123-11-015556


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950123-11-015556:notes:1]
| 2. | Summary of Significant Accounting Policies: |

[0000950123-11-015556:notes:2]
Principles
       of Consolidation

[0000950123-11-015556:notes:3]
The consolidated financial statements include the accounts of
       Lennox International Inc. and the accounts of our majority-owned
       subsidiaries. All intercompany transactions, profits and
       balances have been eliminated.

[0000950123-11-015556:notes:4]
Cash
       and Cash Equivalents

[0000950123-11-015556:notes:5]
We consider all highly liquid temporary investments with
       original maturity dates of three months or less to be cash
       equivalents. Cash and cash equivalents consisted primarily of
       bank deposits and US Treasury money market securities.

[0000950123-11-015556:notes:6]
During the first quarter of 2010, our captive insurance
       subsidiary entered into an agreement in which cash was placed
       into a trust for the benefit of a third-party insurance
       provider. The purpose of the trust is to pay workers
       compensation claims for policy years 2003 — 2009 until
       the liabilities are fully extinguished. These policies were
       written by the third-party insurance provider, and then
       reinsured by our captive insurance subsidiary. This transaction
       was classified as restricted cash on the accompanying
       Consolidated Balance Sheets. The balance at December 31,
       2010 was $12.2 million.

[0000950123-11-015556:notes:7]
Accounts
       and Notes Receivable

[0000950123-11-015556:notes:8]
Accounts and notes receivable are shown in the accompanying
       Consolidated Balance Sheets, net of allowance for doubtful
       accounts. The allowance for doubtful accounts is generally
       established during the period in which receivables are
       recognized and is maintained at a level deemed appropriate based
       on historical and other factors that affect collectability. Such
       factors include the historical trends of write-offs and recovery
       of previously written-off accounts, the financial strength of
       the customer and projected economic and market conditions. We
       determine the delinquency status of receivables predominantly
       based on contractual terms and write off uncollectible
       receivables after management’s review of factors that
       affect collectability as noted above, among other
       considerations. We have no significant concentrations of credit
       risk within our accounts and notes receivable.

[0000950123-11-015556:notes:9]
Inventories

[0000950123-11-015556:notes:10]
Inventory costs include material, labor, depreciation and plant
       overhead. Inventories of $123.8 million and
       $100.8 million as of December 31, 2010 and 2009,
       respectively, were valued at the lower of cost or market using
       the last-in,
       first-out (“LIFO”) cost method. The remaining portion
       of the inventory is valued at the lower of cost or market with
       cost being determined either on the
       first-in,
       first-out (“FIFO”) basis or average cost. We elected
       to use the LIFO cost method for our domestic manufacturing
       companies in 1974 and continued to elect the LIFO cost method
       for new operations through the late 1980s. The types of
       inventory include raw materials, purchased
   components,
       work-in-process,
       repair parts and finished goods. Starting in the late 1990s, we
       began adopting the FIFO cost method for all new domestic
       manufacturing operations (primarily acquisitions). Our operating
       entities with a previous LIFO election continue to use the LIFO
       cost method. We also use the FIFO cost method for all of our
       foreign-based manufacturing facilities as well as our Service
       Experts segment, whose inventory is limited to service parts and
       finished goods.

[0000950123-11-015556:notes:11]
Property,
       Plant and Equipment

[0000950123-11-015556:notes:12]
Property, plant and equipment is stated at cost, net of
       accumulated depreciation. Expenditures that increase the utility
       or extend the useful lives of fixed assets are capitalized and
       expenditures for maintenance and repairs are charged to expense
       as incurred. Depreciation is computed using the straight-line
       method over the following estimated useful lives:

[0000950123-11-015556:notes:13]
| Buildings and improvements |  |  | 2 to 40 years |  |
| Machinery and equipment |  |  | 1 to 15 years |  |

[0000950123-11-015556:notes:14]
We periodically review long-lived assets for impairment as
       events or changes in circumstances indicate that the carrying
       amount of such assets might not be recoverable. In order to
       assess recoverability, we compare the estimated expected future
       undiscounted cash flows identified with each long-lived asset or
       related asset group to the carrying amount of such assets. If
       the expected future cash flows do not exceed the carrying value
       of the asset or assets being reviewed, an impairment loss is
       recognized based on the excess of the carrying amount of the
       impaired assets over their fair value.

[0000950123-11-015556:notes:15]
Goodwill

[0000950123-11-015556:notes:16]
Goodwill represents the excess of cost over fair value of assets
       of acquired businesses. Goodwill and intangible assets
       determined to have an indefinite useful life are not amortized,
       but are instead tested for impairment at least annually. We
       complete our annual goodwill impairment tests in the first
       quarter of each fiscal year and continuously monitor our
       operations for indicators of goodwill impairment based on
       current market conditions.

[0000950123-11-015556:notes:17]
We assign goodwill to the reporting units that benefit from the
       synergies of our acquisitions, which are the reporting units
       that report the results of such acquisitions. If we reorganize
       our management structure, the related goodwill is allocated to
       the affected reporting units based upon the relative fair values
       of those reporting units. Assets and liabilities, including
       deferred income taxes, are generally directly assigned to the
       reporting units through our segment reporting system as part of
       our financial closing process. However, certain assets and
       liabilities, including information technology assets and
       pension, self-insurance, and environmental liabilities, are
       commonly managed and are not allocated to the segments in the
       normal course of our financial reporting process and therefore
       must be assigned to the reporting units based upon appropriate
       methods.

[0000950123-11-015556:notes:18]
Reporting units that we test are generally equivalent to our
       business segments, or in some cases, one level below. We review
       our reporting unit structure each year as part of our annual
       goodwill impairment testing and reporting units are determined
       based upon a review of the periodic financial information
       supplied to and reviewed by our Chief Executive Officer (the
       chief operating decision maker). We aggregate operating units
       reviewed into reporting units when those operating units share
       similar economic characteristics.

[0000950123-11-015556:notes:19]
We estimate reporting unit fair values using standard business
       valuation techniques such as discounted cash flows and reference
       to comparable business transactions and observable fair values
       of comparable entities. The discounted cash flow approach is the
       principal technique we use. We use comparable business
       transactions and observable fair values of comparable entities
       as a reasonableness test of our principal technique as we
       believe that the discounted cash flow approach provides greater
       detail and opportunity to reflect specific facts, circumstances
       and economic conditions for each reporting unit. Comparable
       business transactions are often limited in number, the
       information can be dated, and may require significant
       adjustments due to differences in the size of the business,
   markets served, product offered, and other factors. We therefore
       believe that in our circumstances, this makes comparisons to
       comparable business transactions less reliable than the
       discounted cash flows method.

[0000950123-11-015556:notes:20]
The discounted cash flows used to estimate fair value are based
       on assumptions regarding each reporting unit’s estimated
       projected future cash flows and the estimated weighted-average
       cost of capital that a market participant would use in
       evaluating the reporting unit in a purchase transaction. The
       estimated weighted-average cost of capital is based on the
       risk-free interest rate and other factors such as equity risk
       premiums and the ratio of total debt to equity capital. In
       performing these impairment tests, we take steps to ensure that
       appropriate and reasonable cash flow projections and assumptions
       are used. We reconcile our estimated enterprise value to our
       market capitalization and determine the reasonableness of the
       cost of capital used by comparing to market data. We also
       perform sensitivity analyses on the key assumptions used, such
       as the weighted-average cost of capital and terminal growth
       rates.

[0000950123-11-015556:notes:21]
We also monitor economic, legal, regulatory and other factors
       for LII as a whole and for each reporting unit between annual
       impairment tests to ensure that there are no indicators that
       make it more likely than not that there has been a decline in
       the fair value of any reporting unit below its carrying value.
       Specifically, we monitor industry trends, our market
       capitalization, recent and forecasted financial performance of
       our reporting units, and the timing and nature of our
       restructuring activities. While our recent financial performance
       is below historical levels, we determined that no impairment of
       our goodwill existed as of December 31, 2010, 2009 or 2008.
       If these estimates or the related assumptions change, we may be
       required to record non-cash impairment charges for these assets
       in the future. For additional disclosures on goodwill, see
       Note 5.

[0000950123-11-015556:notes:22]
Intangible
       and Other Assets

[0000950123-11-015556:notes:23]
We amortize intangible assets with finite lives over their
       respective estimated useful lives to their estimated residual
       values.

[0000950123-11-015556:notes:24]
Identifiable intangible and other assets that have finite lives
       are amortized over their estimated useful lives as follows:

[0000950123-11-015556:notes:25]
| Asset |  | Useful Life |
| Deferred financing costs |  | Effective interest method |
| Customer relationships |  | Straight-line method up to 10 years |

[0000950123-11-015556:notes:26]
We periodically review intangible assets with estimable useful
       lives for impairment as events or changes in circumstances
       indicate that the carrying amount of such assets might not be
       recoverable. In order to assess recoverability, we compare the
       estimated expected undiscounted future cash flows identified
       with each intangible asset or related asset group to the
       carrying amount of such assets. If the expected future cash
       flows do not exceed the carrying value of the asset or assets
       being reviewed, an impairment loss is recognized based on the
       excess of the carrying amount of the impaired assets over their
       fair value.

[0000950123-11-015556:notes:27]
In assessing the fair value of our other intangibles, we must
       make assumptions that a market participant would make regarding
       estimated future cash flows and other factors to determine the
       fair value of the respective assets. If these estimates or the
       related assumptions change, we may be required to record
       impairment charges for these assets in the future.

[0000950123-11-015556:notes:28]
Product
       Warranties

[0000950123-11-015556:notes:29]
For some of our heating, ventilation and air conditioning
       (“HVAC”) products, we provide warranty terms ranging
       from one to 20 years to customers for certain components
       such as compressors or heat exchangers. For select products, we
       also provide lifetime warranties for heat exchangers. A
       liability for estimated warranty expense is recorded on the date
       that revenue is recognized. Our estimates of future warranty
       costs are determined for each product line. The number of units
       that we expect to repair or replace is determined by applying
       the estimated failure
   rate, which is generally based on historical experience, to the
       number of units that have been sold and are still under
       warranty. The estimated units to be repaired under warranty are
       multiplied by the average cost to repair or replace such
       products to determine the estimated future warranty cost. We do
       not discount product warranty liabilities as the amounts are not
       fixed and the timing of future cash payments is neither fixed
       nor reliably determinable. We also provide for specifically
       identified warranty obligations. Estimated future warranty costs
       are subject to adjustment from time to time depending on changes
       in actual failure rate and cost experience. Subsequent costs
       incurred for warranty claims serve to reduce the accrued product
       warranty liability.

[0000950123-11-015556:notes:30]
Pensions
       and Postretirement Benefits

[0000950123-11-015556:notes:31]
We provide pension and postretirement medical benefits to
       eligible domestic and foreign employees and recognize pension
       and postretirement benefit costs over the estimated service life
       or average life expectancy of those employees. We also recognize
       the funded status of our benefit plans, as measured at year-end
       by the difference between plan assets at fair value and the
       benefit obligation, in the Consolidated Balance Sheets. Changes
       in the funded status are recognized in the year in which the
       changes occur through accumulated other comprehensive income
       (“AOCI”). Actuarial gains or losses are amortized into
       net period benefit cost over the estimated service life of
       covered employees or average life expectancy of participants
       depending on the plan.

[0000950123-11-015556:notes:32]
The benefit plan assets and liabilities reflect assumptions
       about the long-range performance of our benefit plans. Should
       actual results differ from management’s estimates,
       revisions to the benefit plan assets and liabilities would be
       required. For additional disclosures on pension and
       postretirement medical benefits, including how we determine the
       assumptions used, see Note 12.

[0000950123-11-015556:notes:33]
Self-Insurance

[0000950123-11-015556:notes:34]
Self-insurance expense and liabilities, calculated on an
       undiscounted basis, are actuarially determined based primarily
       on our historical claims information, as well as industry
       factors and trends. As of December 31, 2010, self-insurance
       and captive reserves represent the best estimate of the future
       payments to be made on losses reported and unreported for 2010
       and prior years. The majority of our self-insured risks
       (excluding auto liability and physical damage) will be paid over
       an extended period of time.

[0000950123-11-015556:notes:35]
Actual payments for claims reserved as of December 31,
       2010 may vary depending on various factors, including the
       development and ultimate settlement of reported and unreported
       claims. To the extent actuarial assumptions change and claims
       experience rates differ from historical rates, our liability may
       change. For additional disclosures on self-insured risks and
       reserves, see Note 10.

[0000950123-11-015556:notes:36]
Derivatives

[0000950123-11-015556:notes:37]
We use futures contracts and fixed forward contracts to mitigate
       the exposure to volatility in commodity prices and foreign
       exchange rates, and we use an interest rate swap to hedge
       changes in the benchmark interest rate related to our revolving
       credit facility. We hedge only exposures in the ordinary course
       of business and do not hold or trade derivatives for profit. All
       derivatives are recognized in the Consolidated Balance Sheets at
       fair value. Classification of each hedging instrument is based
       upon whether the maturity of the instrument is less than or
       greater than 12 months. For more information, see
       Note 8.

[0000950123-11-015556:notes:38]
Income
       Taxes

[0000950123-11-015556:notes:39]
Income taxes are accounted for under the asset and liability
       method. Deferred tax assets and liabilities are recognized for
       the future tax consequences attributable to differences between
       the financial statement carrying amounts of existing assets and
       liabilities and their respective tax bases and operating loss
       and tax credit carry forwards. Deferred tax assets and
       liabilities are measured using enacted tax rates expected to
       apply to taxable income in the years in which those temporary
       differences are expected to be recovered or settled. The effect
       of a
   change in tax rates on deferred tax assets and liabilities is
       recognized in income in the period that includes the enactment
       date.

[0000950123-11-015556:notes:40]
Unrecognized tax benefits are accounted for as required by the
       Financial Accounting Standards Board (“FASB”)
       Accounting Standards Codification (“ASC”) Topic 740.
       For more information, see Note 9.

[0000950123-11-015556:notes:41]
Revenue
       Recognition

[0000950123-11-015556:notes:42]
Our Residential Heating & Cooling, Commercial
       Heating & Cooling and Refrigeration segments’
       revenue recognition practices depend upon the shipping terms for
       each transaction. Shipping terms are primarily FOB Shipping
       Point and, therefore, revenues are recognized for these
       transactions when products are shipped to customers and title
       passes. However, certain customers in our smaller operations,
       primarily outside of North America, have shipping terms where
       title and risk of ownership do not transfer until the product is
       delivered to the customer. For these transactions, revenues are
       recognized on the date that the product is received and accepted
       by such customers. We have experienced returns for miscellaneous
       reasons and we record a reserve for these returns based on
       historical experience at the time we recognize revenue. Our
       historical rate of returns are insignificant as a percentage of
       sales.

[0000950123-11-015556:notes:43]
Our Service Experts segment recognizes sales, installation,
       maintenance and repair revenues at the time the services are
       completed. The Service Experts segment also provides HVAC system
       design and installation services under fixed-price contracts,
       which may extend up to one year. Revenue for these services is
       recognized using the
       percentage-of-completion
       method, based on the percentage of incurred contract
       costs-to-date
       in relation to total estimated contract costs, after giving
       effect to the most recent estimates of total cost. The effect of
       changes to total estimated contract revenue or cost is
       recognized in the period such changes are determined. Provisions
       for estimated losses on individual contracts are made in the
       first period in which the loss becomes probable.

[0000950123-11-015556:notes:44]
We engage in cooperative advertising, customer rebate, cash
       discount and other miscellaneous programs that result in
       payments or credits being issued to our customers. Our policy is
       to record the discounts and incentives as a reduction of sales
       when the sales are recorded, with the exception of certain
       cooperative advertising expenditures that are charged to
       Selling, General and Administrative (“SG&A”)
       Expenses. Under these cooperative advertising programs, we
       receive, or will receive, an identifiable benefit (goods or
       services) in exchange for the consideration given.

[0000950123-11-015556:notes:45]
Cost
       of Goods Sold

[0000950123-11-015556:notes:46]
The principal components of cost of goods sold in our
       manufacturing operations are component costs, raw materials,
       factory overhead, labor, estimated costs of warranty expense,
       and freight and distribution costs. In our Service Experts
       segment, the principal components of cost of goods sold are
       equipment, vehicle costs, parts and supplies, and labor.

[0000950123-11-015556:notes:47]
Selling,
       General and Administrative Expenses

[0000950123-11-015556:notes:48]
SG&A expenses include all other payroll and benefit costs,
       advertising, commissions, research and development, information
       technology costs, and other selling, general and administrative
       related costs such as insurance, travel, non-production
       depreciation and rent.

[0000950123-11-015556:notes:49]
Stock-Based
       Compensation

[0000950123-11-015556:notes:50]
We recognize compensation expense for stock-based arrangements
       over the required employee service periods. We base stock-based
       compensation costs on the estimated grant-date fair value of the
       stock-based awards that are expected to ultimately vest and
       adjust expected vesting rates to actual rates as additional
       information becomes known. We also adjust performance
       achievement rates based on our best estimates of those rates at
       the end of the performance period.

[0000950123-11-015556:notes:51]
Translation
       of Foreign Currencies

[0000950123-11-015556:notes:52]
All assets and liabilities of foreign subsidiaries and joint
       ventures are translated into U.S. dollars using rates of
       exchange in effect at the balance sheet date. Revenues and
       expenses are translated at weighted average exchange rates
       during the year. The unrealized translation gains and losses are
       included in AOCI in the accompanying Consolidated Balance
       Sheets. Transaction gains and losses are included in Losses
       (Gains) and Other Expenses, net in the accompanying Consolidated
       Statements of Operations.

[0000950123-11-015556:notes:53]
Use of
       Estimates

[0000950123-11-015556:notes:54]
The preparation of financial statements requires us to make
       estimates and assumptions about future events. These estimates
       and the underlying assumptions affect the amounts of assets and
       liabilities reported, disclosures about contingent assets and
       liabilities, and reported amounts of revenues and expenses. Such
       estimates include the valuation of accounts receivable,
       inventories, goodwill, intangible assets, and other long-lived
       assets, contingencies, guarantee obligations, indemnifications,
       and assumptions used in the calculation of income taxes, pension
       and postretirement medical benefits, among others. These
       estimates and assumptions are based on our best estimates and
       judgment.

[0000950123-11-015556:notes:55]
We evaluate our estimates and assumptions on an ongoing basis
       using historical experience and other factors, including the
       current economic environment. We believe these estimates and
       assumptions to be reasonable under the circumstances and adjust
       such estimates and assumptions when facts and circumstances
       dictate. Volatile equity, foreign currency, and commodity
       markets, have combined to increase the uncertainty inherent in
       such estimates and assumptions. As future events and their
       effects cannot be determined with precision, actual results
       could differ significantly from these estimates. Changes in
       those estimates resulting from continuing changes in the
       economic environment will be reflected in the financial
       statements in future periods.

[0000950123-11-015556:notes:56]
Reclassifications

[0000950123-11-015556:notes:57]
Certain amounts have been reclassified from the prior year
       presentation to conform to the current year presentation.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-015556:notes:58]
| 3. | Inventories: |

[0000950123-11-015556:notes:59]
Components of inventories are as follows (in millions):

[0000950123-11-015556:notes:60]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Finished goods |  | $ | 213.7 |  |  | $ | 182.3 |  |
| Work in process |  |  | 6.5 |  |  |  | 7.2 |  |
| Raw materials and repair parts |  |  | 137.0 |  |  |  | 132.7 |  |
|  |  |  | 357.2 |  |  |  | 322.2 |  |
| Excess of current cost over last-in, first-out cost |  |  | (71.0 | ) |  |  | (72.0 | ) |
| Total inventories |  | $ | 286.2 |  |  | $ | 250.2 |  |

[0000950123-11-015556:notes:61]
Repair parts are primarily utilized in service operations and to
       fulfill our warranty obligations.

[0000950123-11-015556:notes:62]
The Company recorded income of $0.7 million and
       $1.3 million from LIFO inventory liquidations during 2010
       and 2009, respectively.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000950123-11-015556:notes:63]
| 4. | Property, Plant and Equipment: |

[0000950123-11-015556:notes:64]
Components of property, plant and equipment are as follows (in
       millions):

[0000950123-11-015556:notes:65]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Land |  | $ | 39.3 |  |  | $ | 37.7 |  |
| Buildings and improvements |  |  | 226.5 |  |  |  | 220.2 |  |
| Machinery and equipment |  |  | 625.4 |  |  |  | 583.0 |  |
| Construction in progress and equipment not yet in service |  |  | 17.8 |  |  |  | 39.7 |  |
| Total |  |  | 909.0 |  |  |  | 880.6 |  |
| Less-accumulated depreciation |  |  | (584.7 | ) |  |  | (551.0 | ) |
| Property, plant and equipment, net |  | $ | 324.3 |  |  | $ | 329.6 |  |

[0000950123-11-015556:notes:66]
The balances above include capital lease assets composed of
       buildings and improvements and machinery and equipment totaling
       $17.1 million and $17.6 million, net of accumulated
       depreciation of $5.6 million and $4.5 million for the
       years ended December 31, 2010 and 2009, respectively.

[0000950123-11-015556:notes:67]
During 2009, the Company recorded $6.0 million in
       impairment charges related to the abandonment of information
       technology assets that had not yet been placed in service. There
       were no impairment charges during 2010.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950123-11-015556:notes:68]
| 5. | Goodwill, Intangible and Other Assets: |

[0000950123-11-015556:notes:69]
The changes in the carrying amount of goodwill related to
       continuing operations, by segment, are as follows (in millions):

[0000950123-11-015556:notes:70]
|  |  | Segment |  |  |  |  |
|  |  | Residential |  |  | Commercial |  |  |  |  |  |  |  |  |  |  |
|  |  | Heating |  |  | Heating |  |  | Service |  |  |  |  |  |  |  |
|  |  | & Cooling |  |  | & Cooling |  |  | Experts |  |  | Refrigeration |  |  | Total |  |
| Balance as of January 1, 2009: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 33.7 |  |  | $ | 31.2 |  |  | $ | 301.8 |  |  | $ | 73.6 |  |  | $ | 440.3 |  |
| Accumulated impairment loss |  |  | — |  |  |  | — |  |  |  | (208.0 | ) |  |  | — |  |  |  | (208.0 | ) |
|  |  |  | 33.7 |  |  |  | 31.2 |  |  |  | 93.8 |  |  |  | 73.6 |  |  |  | 232.3 |  |
| Changes(1) |  |  | — |  |  |  | 0.1 |  |  |  | 13.1 |  |  |  | 11.9 |  |  |  | 25.1 |  |
| Balance as of December 31, 2009: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 33.7 |  |  | $ | 31.3 |  |  | $ | 314.9 |  |  | $ | 85.5 |  |  | $ | 465.4 |  |
| Accumulated impairment loss |  |  | — |  |  |  | — |  |  |  | (208.0 | ) |  |  | — |  |  |  | (208.0 | ) |
|  |  |  | 33.7 |  |  |  | 31.3 |  |  |  | 106.9 |  |  |  | 85.5 |  |  |  | 257.4 |  |
| Changes(2) |  |  | — |  |  |  | (1.3 | ) |  |  | 9.7 |  |  |  | 6.0 |  |  |  | 14.4 |  |
| Balance as of December 31, 2010: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 33.7 |  |  |  | 30.0 |  |  |  | 324.6 |  |  |  | 91.5 |  |  |  | 479.8 |  |
| Accumulated impairment loss |  |  | — |  |  |  | — |  |  |  | (208.0 | ) |  |  | — |  |  |  | (208.0 | ) |
|  |  | $ | 33.7 |  |  | $ | 30.0 |  |  | $ | 116.6 |  |  | $ | 91.5 |  |  | $ | 271.8 |  |

[0000950123-11-015556:notes:71]
| (1) |  | Changes in 2009 primarily relate to changes in foreign currency translation rates, offset by the write-off of $4.4 million of goodwill related to the sale of businesses, primarily in the Service Experts segment. |
| (2) |  | During 2010, our Service Experts segment acquired a company which resulted in additional goodwill of $4.0 million. The other changes are related to fluctuations in foreign currency translation rates. |

[0000950123-11-015556:notes:72]
Identifiable intangible and other assets subject to amortization
       are recorded in Other Assets in the accompanying Consolidated
       Balance Sheets and were comprised of the following (in millions):

[0000950123-11-015556:notes:73]
|  |  | For the Years Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Amount |  |  | Amortization |  |  | Amount |  |  | Amount |  |  | Amortization |  |  | Amount |  |
| Deferred financing costs |  | $ | 9.2 |  |  | $ | (6.3 | ) |  | $ | 2.9 |  |  | $ | 7.3 |  |  | $ | (5.5 | ) |  | $ | 1.8 |  |
| Customer relationships |  |  | 4.5 |  |  |  | (1.5 | ) |  |  | 3.0 |  |  |  | 3.3 |  |  |  | (1.1 | ) |  |  | 2.2 |  |
| Other |  |  | 4.5 |  |  |  | (3.2 | ) |  |  | 1.3 |  |  |  | 3.4 |  |  |  | (2.3 | ) |  |  | 1.1 |  |
| Total |  | $ | 18.2 |  |  | $ | (11.0 | ) |  | $ | 7.2 |  |  | $ | 14.0 |  |  | $ | (8.9 | ) |  | $ | 5.1 |  |

[0000950123-11-015556:notes:74]
Amortization of intangible assets was as follows (in millions):

[0000950123-11-015556:notes:75]
|  |  | For the Years Ended December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Amortization expense |  | $ | 2.0 |  |  | $ | 1.6 |  |  | $ | 1.5 |  |

[0000950123-11-015556:notes:76]
Estimated intangible amortization expense for the next five
       years is as follows (in millions):

[0000950123-11-015556:notes:77]
| 2011 |  | $ | 1.9 |  |
| 2012 |  |  | 1.5 |  |
| 2013 |  |  | 0.9 |  |
| 2014 |  |  | 0.9 |  |
| 2015 |  |  | 0.9 |  |
| Thereafter |  |  | 1.1 |  |

[0000950123-11-015556:notes:78]
As of December 31, 2010 and 2009, we had $4.9 million
       and $4.8 million respectively of intangible assets
       primarily consisting of trademarks, which are not subject to
       amortization.


## lii:JointVenturesAndOtherEquityInvestmentTextBlock

[0000950123-11-015556:notes:79]
| 6. | Joint Ventures and Other Equity Investment: |

[0000950123-11-015556:notes:80]
Joint
       Ventures

[0000950123-11-015556:notes:81]
We participate in two joint ventures; the largest is located in
       the U.S. and the other in Mexico. These joint ventures are
       engaged in the manufacture and sale of compressors, unit coolers
       and condensing units. Because we exert significant influence
       over these affiliates based upon our respective 25% and 50%
       ownership, but do not control them due to venture partner
       participation, they have been accounted for under the equity
       method and their financial position and results of operations
       are not consolidated. We purchase compressors from our
       U.S. joint venture for use in certain of our products.

[0000950123-11-015556:notes:82]
The combined balance of equity method investments included in
       Other Assets, net totaled (in millions):

[0000950123-11-015556:notes:83]
|  |  | As of December 31, |
|  |  | 2010 |  | 2009 |
| Other Assets, net |  | $ | 28.2 |  |  | $ | 30.0 |  |

[0000950123-11-015556:notes:84]
Purchases of compressors from our U.S. joint venture that
       were included in Cost of Goods Sold in the Consolidated
       Statements of Operations were approximately (in millions):

[0000950123-11-015556:notes:85]
|  |  | For the Years Ended December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Purchases of compressors |  | $ | 86.1 |  |  | $ | 95.0 |  |  | $ | 123.2 |  |

[0000950123-11-015556:notes:86]
During 2008, the Company loaned $1.6 million to its joint
       venture in Mexico due to that entity’s cash needs related
       to margin calls on forward commodity contracts and operating
       cash requirements. The joint venture partner loaned equal
       amounts under identical terms to the joint venture; and
       therefore, the investment continues to be recorded under the
       equity method. As of December 31, 2010 and 2009, the
       outstanding loan balance was $0.9 million and
       $1.6 million, respectively.

[0000950123-11-015556:notes:87]
Other
       Investment

[0000950123-11-015556:notes:88]
LII also has an investment in a compressor manufacturer located
       in Thailand. During 2008, under the equity method we recorded
       investment losses of $0.3 million and dividends of
       $1.1 million as reductions to the investment balance. We
       also recorded $9.1 million of impairment charges related to
       this investment in 2008.

[0000950123-11-015556:notes:89]
Also, as a result of a rights offering in 2008, our percentage
       of equity ownership declined from 13% to 9%. While formerly
       accounted for under the equity method, the investment of
       $18.0 million in 2010 and $5.4 million in 2009 was
       accounted for as an
       available-for-sale
       marketable equity security. A net gain of $12.5 million in
       2010 was recorded in AOCI. The fair value of the investment was
       measured based upon the quoted market price of the
       investee’s common stock as listed on the Stock Exchange of
       Thailand, multiplied by the number of shares owned. For more
       information on the valuation of this investment, see
       Note 20.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0000950123-11-015556:notes:90]
| 7. | Current Accrued Expenses: |

[0000950123-11-015556:notes:91]
Significant components of current accrued expenses are presented
       below (in millions):

[0000950123-11-015556:notes:92]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued compensation and benefits |  | $ | 87.6 |  |  | $ | 66.4 |  |
| Self insurance reserves |  |  | 61.3 |  |  |  | 60.4 |  |
| Deferred income |  |  | 34.9 |  |  |  | 32.7 |  |
| Accrued warranties |  |  | 31.2 |  |  |  | 31.5 |  |
| Accrued product quality issue |  |  | 16.0 |  |  |  | 21.6 |  |
| Accrued rebates and promotions |  |  | 38.2 |  |  |  | 36.7 |  |
| Derivative contracts |  |  | 2.2 |  |  |  | 2.0 |  |
| Other |  |  | 63.1 |  |  |  | 65.3 |  |
| Total continuing operations accrued expenses |  | $ | 334.5 |  |  | $ | 316.6 |  |
| Discontinued operations accrued expenses |  |  | — |  |  |  | 1.3 |  |
| Total current accrued expenses |  | $ | 334.5 |  |  | $ | 317.9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950123-11-015556:notes:93]
| 8. | Derivatives: |

[0000950123-11-015556:notes:94]
General

[0000950123-11-015556:notes:95]
Our earnings and cash flows are subject to fluctuations due to
       changes in commodity prices, interest rates, and foreign
       currency exchange rates, and we seek to mitigate a portion of
       these risks by entering into derivative contracts. The
       derivatives we use are commodity futures contracts, interest
       rate swaps, and currency forward contracts. We do not use
       derivatives for speculative purposes.

[0000950123-11-015556:notes:96]
The derivatives we enter into may be, but are not always,
       accounted for as hedges. To qualify for hedge accounting, the
       derivatives must be highly effective in reducing the risk
       exposure that they are designed to hedge, and it must be
       probable that the underlying transaction will occur. For
       instruments designated as cash flow hedges, we must formally
       document, at inception, the relationship between the derivative
       and the hedged item, the risk management objective, the hedging
       strategy for use of the hedged instrument, and how hedge
       effectiveness is, and will be, assessed. This documentation also
       includes linking the derivatives that are designated as cash
       flow hedges to forecasted transactions. We assess hedge
       effectiveness at inception and at least quarterly throughout the
       hedge designation period.

[0000950123-11-015556:notes:97]
We recognize all derivatives as either assets or liabilities at
       fair value in the Consolidated Balance Sheets, regardless of
       whether or not hedge accounting is applied. For more information
       on the fair value of these derivative instruments, see
       Note 20. We report cash flows arising from our hedging
       instruments consistent with the classification of cash flows
       from the underlying hedged items. Accordingly, cash flows
       associated with our derivative programs are classified as
       operating activities in the accompanying Consolidated Statements
       of Cash Flows.

[0000950123-11-015556:notes:98]
We monitor our derivative positions and credit ratings of our
       counterparties and do not anticipate losses due to counterparty
       non-performance.

[0000950123-11-015556:notes:99]
Hedge
       Accounting

[0000950123-11-015556:notes:100]
The derivatives that we use as hedges of commodity prices and
       movements in interest rates are accounted for as cash flow
       hedges. The effective portion of the gain or loss on the
       derivatives accounted for as hedges is recorded, net of
       applicable taxes, in AOCI, a component of Stockholders’
       Equity in the accompanying Consolidated Balance Sheets. When
       earnings are affected by the variability of the underlying cash
       flow, the applicable offsetting amount of the gain or loss from
       the derivatives that is deferred in AOCI is reclassified into
       earnings in the same financial statement line item that the
       hedged item is recorded in. Ineffectiveness, if any, is recorded
       in earnings each period. If the hedging relationship ceases to
       be highly effective, the net gain or loss shall remain in AOCI
       and will be reclassified into earnings when earnings are
       affected by the variability of the underlying cash flow. If it
       becomes probable that the forecasted transaction will not occur
       by the end of the originally specified period or within two
       months thereafter, the net gain or loss remaining in AOCI will
       be reclassified to earnings immediately.

[0000950123-11-015556:notes:101]
Accounting
       for Derivatives When Hedge Accounting is Not
       Applied

[0000950123-11-015556:notes:102]
We may also enter into derivatives that economically hedge
       certain of our risks, even though hedge accounting does not
       apply or we elect not to apply hedge accounting to these
       instruments. The changes in fair value of the derivatives act as
       an economic offset to changes in the fair value of the
       underlying items. Changes in the fair value of instruments not
       designated as cash flow hedges are recorded in earnings
       throughout the term of the derivative instrument and are
       reported in Losses (Gains) and Other Expenses, net in the
       accompanying Consolidated Statements of Operations.

[0000950123-11-015556:notes:103]
Objectives
       and Strategies for Using Derivative Instruments

[0000950123-11-015556:notes:104]
Commodity Price Risk

[0000950123-11-015556:notes:105]
We utilize a cash flow hedging program to mitigate our exposure
       to volatility in the prices of metal commodities we use in our
       production processes. The hedging program includes the use of
       futures contracts, and we enter into these contracts based on
       our hedging strategy. We use a dollar cost averaging strategy
       for our hedge program. As part of this strategy, a higher
       percentage of commodity price exposures are hedged near term
       with lower percentages hedged at future dates. This strategy
       provides us with protection against near-term price volatility
       caused by market speculators and market forces, such as supply
       variation, while allowing us to adjust to market price movements
       over time. Upon entering into futures contracts, we lock in
       prices and are subject to derivative losses should the metal
       commodity prices decrease and gains should the prices increase.

[0000950123-11-015556:notes:106]
Interest Rate Risk

[0000950123-11-015556:notes:107]
A portion of our debt bears interest at variable interest rates
       and therefore, we are subject to variability in the cash paid
       for interest expense. In order to mitigate a portion of this
       risk, we use a hedging strategy to eliminate the variability of
       cash flows in the interest payments associated with the first
       $100 million of the total variable-rate debt outstanding
       under our revolving credit facility that is solely due to
       changes in the benchmark interest rate. This strategy allows us
       to fix a portion of our interest payments.

[0000950123-11-015556:notes:108]
On June 12, 2009, we entered into a $100 million
       pay-fixed, receive-variable interest rate swap with a large
       financial institution at a fixed interest rate of 2.66%. The
       variable portion of the interest rate swap is tied to the
       1-Month
       LIBOR (the benchmark interest rate). The interest rates under
       both the interest rate swap and the underlying debt are reset,
       the swap is settled with the counterparty, and interest is paid,
       on a monthly basis. The interest rate swap expires
       October 12, 2012. We account for the interest rate swap as
       a cash flow hedge.

[0000950123-11-015556:notes:109]
Foreign Currency Risk

[0000950123-11-015556:notes:110]
Foreign currency exchange rate movements create a degree of risk
       by affecting the U.S. dollar value of assets and
       liabilities arising in foreign currencies. Our objective for
       entering into foreign currency forward contracts is to mitigate
       the impact of short-term currency exchange rate movements on
       certain short-term intercompany transactions. In order to meet
       that objective, we periodically enter into foreign currency
       forward contracts that act as economic hedges against changes in
       foreign currency exchange rates. These forward contracts are not
       designated as hedges and generally expire during the quarter
       that we entered into them.

[0000950123-11-015556:notes:111]
Cash
       Flow Hedges

[0000950123-11-015556:notes:112]
We include (gains) losses in AOCI in connection with our
       commodity cash flow hedges. The (gains) losses related to
       commodity price hedges are expected to be reclassified into
       earnings within the next 18 months based on the prices of
       the commodities at settlement date. Assuming that commodity
       prices remain constant, $10.9 million of derivative gains
       are expected to be reclassified into earnings within the next
       12 months. Commodity futures contracts that are designated
       as cash flow hedges and are in place as of December 31,
       2010 are scheduled to mature through May 2012.

[0000950123-11-015556:notes:113]
The (gains) losses related to our interest rate swap are
       expected to be reclassified into earnings within the next
       22 months based on the term of the swap. Assuming that the
       benchmark interest rate remains constant, $1.4 million of
       derivative losses are expected to be reclassified into earnings
       within the next 12 months.

[0000950123-11-015556:notes:114]
We recorded the following amounts related to our cash flow
       hedges (in millions):

[0000950123-11-015556:notes:115]
|  |  | As of December 31, |
|  |  | 2010 |  | 2009 |
| Commodity Price Hedges: |  |  |  |  |  |  |  |  |
| Gains included in AOCI, net of tax |  | $ | (11.7 | ) |  | $ | (7.2 | ) |
| Provision for income taxes |  |  | 6.7 |  |  |  | 4.1 |  |
| Interest Rate Swap: |  |  |  |  |  |  |  |  |
| Losses included in AOCI, net of tax |  | $ | 2.3 |  |  | $ | 1.4 |  |
| Benefit from income taxes |  |  | (1.3 | ) |  |  | (0.8 | ) |

[0000950123-11-015556:notes:116]
We had the following outstanding commodity futures contracts
       designated as cash flow hedges (in millions):

[0000950123-11-015556:notes:117]
|  |  | As of December 31, |
|  |  | 2010 |  | 2009 |
|  |  | (Pounds) |  | (Pounds) |
| Copper |  |  | 18.5 |  |  |  | 12.6 |  |

[0000950123-11-015556:notes:118]
Derivatives
       not Designated as Cash Flow Hedges

[0000950123-11-015556:notes:119]
For commodity derivatives not designated as cash flow hedges, we
       follow the same hedging strategy as for derivatives designated
       as cash flow hedges. We elect not to designate these derivatives
       as cash flow hedges at inception of the arrangement. We had the
       following outstanding commodity futures contracts not designated
       as cash flow hedges (in millions):

[0000950123-11-015556:notes:120]
|  |  | As of December 31, |
|  |  | 2010 |  | 2009 |
|  |  | (Pounds) |  | (Pounds) |
| Copper |  |  | 1.4 |  |  |  | 0.9 |  |
| Aluminum |  |  | 1.4 |  |  |  | 0.9 |  |

[0000950123-11-015556:notes:121]
During 2010, we entered into foreign currency forward contracts
       with notional amounts of $217.0 million and
       £16.5 million, of which $35.0 million and
       £2.0 million were outstanding at December 31,
       2010. During 2009, we entered into foreign currency forward
       contracts with notional amounts of $123.6 million, of which
       $12.2 million were outstanding at December 31, 2009.

[0000950123-11-015556:notes:122]
Information
       About the Location and Amounts of Derivative
       Instruments

[0000950123-11-015556:notes:123]
For information on the location and amounts of derivative fair
       values in the Consolidated Balance Sheets and derivative gains
       and losses in the Consolidated Statements of Operations, see the
       tabular information presented below (in millions):

[0000950123-11-015556:notes:124]
Fair
       Values of Derivative Instruments

[0000950123-11-015556:notes:125]
|  |  | As of December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
|  |  | Balance Sheet |  |  |  |  | Balance Sheet |  |  |  |
| Asset Derivatives |  | Location |  | Fair Value |  |  | Location |  | Fair Value |  |
| Derivatives designated as hedging instruments under FASB ASC Topic 815 |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | Other Assets (Current) |  | $ | 17.4 |  |  | Other Assets (Current) |  | $ | 11.1 |  |
| Commodity futures contracts |  | Other Assets (Non-current) |  |  | 1.3 |  |  | Other Assets (Non-current) |  |  | 0.3 |  |
|  |  |  |  |  | 18.7 |  |  |  |  |  | 11.4 |  |
| Derivatives not designated as hedging instruments under FASB ASC Topic 815 |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | Other Assets (Current) |  |  | 1.4 |  |  | Other Assets (Current) |  |  | 1.1 |  |
| Commodity futures contracts |  | Other Assets (Non-Current) |  |  | 0.1 |  |  | Other Assets (Non-Current) |  |  | — |  |
| Foreign currency forward contracts |  | Other Assets (Current) |  |  | 0.2 |  |  | Other Assets (Current) |  |  | — |  |
|  |  |  |  |  | 1.7 |  |  |  |  |  | 1.1 |  |
| Total Asset for Derivatives |  |  |  | $ | 20.4 |  |  |  |  | $ | 12.5 |  |
| Liability Derivatives |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivatives designated as hedging instruments under FASB ASC Topic 815 |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Accrued Expenses |  |  | 2.2 |  |  | Accrued Expenses |  |  | 2.0 |  |
| Interest rate swap |  | Other Liabilities |  |  | 1.4 |  |  | Other Liabilities |  |  | 0.3 |  |
| Total Liability for Derivatives |  |  |  | $ | 3.6 |  |  |  |  | $ | 2.3 |  |

[0000950123-11-015556:notes:126]
The
       Effect of Derivative Instruments on the Consolidated Statements
       of Operations

[0000950123-11-015556:notes:127]
|  |  |  |  | Amount of Loss or (Gain) Reclassified |  |
|  |  |  |  | from AOCI into Income |  |
| Derivatives in FASB ASC |  | Location of Loss or (Gain) |  | (Effective Portion) |  |
| Topic 815 Cash Flow |  | Reclassified from AOCI into Income |  | For the Years Ended December 31, |  |
| Hedging Relationships |  | (Effective Portion) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Commodity futures contracts |  | Cost of Goods Sold |  | $ | (11.2 | ) |  | $ | 19.6 |  |  | $ | (7.0 | ) |
| Interest rate swap |  | Interest Expense, net |  |  | 2.4 |  |  |  | 1.3 |  |  |  | — |  |
|  |  |  |  | $ | (8.8 | ) |  | $ | 20.9 |  |  | $ | (7.0 | ) |

[0000950123-11-015556:notes:128]
|  |  |  |  | Amount of Loss or |
|  |  |  |  | (Gain) Recognized |
|  |  | Location of Loss or (Gain) |  | in Income on Derivatives |
| Derivatives in FASB ASC |  | Recognized in Income on |  | (Ineffective Portion) |
| Topic 815 Cash Flow |  | Derivatives |  | For the Years Ended December 31, |
| Hedging Relationships |  | (Ineffective Portion) |  | 2010 |  | 2009 |  | 2008 |
| Commodity futures contracts |  | Losses (Gains) and Other Expenses, net |  | $ | (0.4 | ) |  | $ | (0.1 | ) |  | $ | 0.3 |  |

[0000950123-11-015556:notes:129]
|  |  |  |  | Amount of Loss or (Gain) |  |
|  |  |  |  | Recognized in Income on |  |
| Derivatives Not Designated |  | Location of (Gain) or Loss |  | Derivatives |  |
| as Hedging Instruments under |  | Recognized in Income on |  | For the Years Ended December 31, |  |
| FASB ASC Topic 815 |  | Derivatives |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Commodity futures contracts |  | Losses (Gains) and Other Expenses, net |  | $ | (1.7 | ) |  | $ | (3.4 | ) |  | $ | 5.7 |  |
| Foreign currency forward contracts |  | Losses (Gains) and Other Expenses, net |  |  | (0.2 | ) |  |  | 3.1 |  |  |  | — |  |
|  |  |  |  | $ | (1.9 | ) |  | $ | (0.3 | ) |  | $ | 5.7 |  |

[0000950123-11-015556:notes:130]
For more information on the valuation of these derivative
       instruments, see Note 20.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-015556:notes:131]
| 9. | Income Taxes: |

[0000950123-11-015556:notes:132]
Our income tax provision (benefits) from continuing operations
       consisted of the following (in millions):

[0000950123-11-015556:notes:133]
|  |  | For the Years Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 54.7 |  |  | $ | 17.5 |  |  | $ | 32.4 |  |
| State |  |  | 6.0 |  |  |  | 5.0 |  |  |  | 5.8 |  |
| Foreign |  |  | 7.3 |  |  |  | 8.1 |  |  |  | 11.0 |  |
| Total current |  |  | 68.0 |  |  |  | 30.6 |  |  |  | 49.2 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (6.9 | ) |  |  | 9.9 |  |  |  | 27.1 |  |
| State |  |  | (1.6 | ) |  |  | 3.0 |  |  |  | 4.2 |  |
| Foreign |  |  | — |  |  |  | (4.4 | ) |  |  | — |  |
| Total deferred |  |  | (8.5 | ) |  |  | 8.5 |  |  |  | 31.3 |  |
| Total income tax provision |  | $ | 59.5 |  |  | $ | 39.1 |  |  | $ | 80.5 |  |

[0000950123-11-015556:notes:134]
Income from continuing operations before income taxes was
       comprised of the following (in millions):

[0000950123-11-015556:notes:135]
|  |  | For the Years Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Domestic |  | $ | 157.2 |  |  | $ | 99.7 |  |  | $ | 186.9 |  |
| Foreign |  |  | 19.4 |  |  |  | 1.2 |  |  |  | 17.4 |  |
| Total |  | $ | 176.6 |  |  | $ | 100.9 |  |  | $ | 204.3 |  |

[0000950123-11-015556:notes:136]
The difference between the income tax provision from continuing
       operations computed at the statutory federal income tax rate and
       the financial statement provision for taxes is summarized as
       follows (in millions):

[0000950123-11-015556:notes:137]
|  |  | For the Years Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Provision at the U.S. statutory rate of 35% |  | $ | 61.8 |  |  | $ | 35.3 |  |  | $ | 71.5 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |  |  |  |  |  |  |  |
| State income tax, net of federal income tax benefit |  |  | 2.5 |  |  |  | 3.8 |  |  |  | 7.7 |  |
| Other permanent items |  |  | (2.3 | ) |  |  | (2.8 | ) |  |  | (1.2 | ) |
| Research tax credit |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | — |  |
| Decrease in tax audit reserves |  |  | (0.2 | ) |  |  | (1.6 | ) |  |  | — |  |
| Change in valuation allowance |  |  | (1.8 | ) |  |  | 4.5 |  |  |  | 1.1 |  |
| Foreign taxes at rates other than 35% and miscellaneous other |  |  | — |  |  |  | 0.5 |  |  |  | 1.4 |  |
| Total income tax provision |  | $ | 59.5 |  |  | $ | 39.1 |  |  | $ | 80.5 |  |

[0000950123-11-015556:notes:138]
Deferred income taxes reflect the tax consequences on future
       years of temporary differences between the tax basis of assets
       and liabilities and their financial reporting basis and are
       reflected as current or non-current depending on the
       classification of the asset or liability generating the deferred
       tax. The deferred tax provision for the periods shown represents
       the effect of changes in the amounts of temporary differences
       during those periods.

[0000950123-11-015556:notes:139]
Deferred tax assets (liabilities) were comprised of the
       following (in millions):

[0000950123-11-015556:notes:140]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Gross deferred tax assets: |  |  |  |  |  |  |  |  |
| Warranties |  | $ | 32.0 |  |  | $ | 36.0 |  |
| Net operating losses (foreign and U.S. state) |  |  | 42.2 |  |  |  | 48.3 |  |
| Postretirement and pension benefits |  |  | 42.6 |  |  |  | 30.2 |  |
| Inventory reserves |  |  | 4.1 |  |  |  | 6.3 |  |
| Receivables allowance |  |  | 6.4 |  |  |  | 4.3 |  |
| Compensation liabilities |  |  | 17.3 |  |  |  | 20.3 |  |
| Deferred income |  |  | 7.8 |  |  |  | 8.0 |  |
| Insurance liabilities |  |  | 15.4 |  |  |  | 2.4 |  |
| Other |  |  | 10.6 |  |  |  | 10.5 |  |
| Total deferred tax assets |  |  | 178.4 |  |  |  | 166.3 |  |
| Valuation allowance |  |  | (24.3 | ) |  |  | (30.9 | ) |
| Total deferred tax assets, net of valuation allowance |  |  | 154.1 |  |  |  | 135.4 |  |
| Gross deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | (11.1 | ) |  |  | (14.6 | ) |
| Intangibles |  |  | (6.6 | ) |  |  | (4.1 | ) |
| Other |  |  | (12.5 | ) |  |  | (7.2 | ) |
| Total deferred tax liabilities |  |  | (30.2 | ) |  |  | (25.9 | ) |
| Net deferred tax assets |  | $ | 123.9 |  |  | $ | 109.5 |  |

[0000950123-11-015556:notes:141]
As of December 31, 2010 and 2009, we had $6.5 million
       and $9.6 million in tax effected state net operating loss
       carryforwards, respectively, and $35.8 million and
       $38.7 million in tax effected foreign net operating loss
       carryforwards, respectively. The state and foreign net operating
       loss carryforwards begin expiring in 2011. The deferred tax
       asset valuation allowance relates primarily to the operating
       loss carryforwards in various states in the U.S., European and
       Asian tax jurisdictions. The decrease in the valuation allowance
       is primarily the result of foreign and state losses which were
       not previously benefited and currency fluctuation.

[0000950123-11-015556:notes:142]
In assessing the realizability of deferred tax assets, we
       consider whether it is more likely than not that some portion or
       all of the deferred tax assets will not be realized. We consider
       the reversal of existing taxable temporary differences,
       projected future taxable income, and tax planning strategies in
       making this assessment. Based upon the level of historical
       taxable income and projections for future taxable income over
       the periods in which the deferred tax assets are deductible, we
       believe it is more likely than not that we will realize the
       benefits of these deductible differences, net of the existing
       valuation allowances, as of December 31, 2010.

[0000950123-11-015556:notes:143]
In order to realize the net deferred tax asset, we will need to
       generate future foreign taxable income of approximately
       $98.5 million during the periods in which those temporary
       differences become deductible. We also will need to generate
       U.S. federal income of approximately $46.8 million in
       addition to our carryback capacity to fully realize the federal
       deferred tax asset. U.S. taxable income for the years ended
       December 31, 2010 and 2009 was $150.5 million and
       $36.7 million, respectively.

[0000950123-11-015556:notes:144]
A limited provision has been made for income taxes which may
       become payable upon distribution of our foreign
       subsidiaries’ earnings related to the Czech Republic. It is
       not practicable to estimate the amount of tax that
   might be payable with regard to any other distribution of
       foreign subsidiary earnings because our intent is to permanently
       reinvest these earnings or to repatriate earnings when it is tax
       effective to do so.

[0000950123-11-015556:notes:145]
A reconciliation of the beginning and ending amount of
       unrecognized tax benefits is as follows (in millions):

[0000950123-11-015556:notes:146]
| Balance as of December 31, 2008 |  | $ | 14.9 |  |
| Increases related to prior year tax positions |  |  | 0.1 |  |
| Decreases related to prior year tax positions |  |  | (7.2 | ) |
| Increases related to current year tax positions |  |  | 0.1 |  |
| Settlements |  |  | (6.4 | ) |
| Balance as of December 31, 2009 |  | $ | 1.5 |  |
| Decreases related to prior year tax positions |  |  | (0.4 | ) |
| Settlements |  |  | (0.1 | ) |
| Balance as of December 31, 2010 |  | $ | 1.0 |  |

[0000950123-11-015556:notes:147]
Included in the balance of unrecognized tax benefits as of
       December 31, 2010 are potential benefits of
       $0.7 million that, if recognized, would affect the
       effective tax rate on income from continuing operations. As of
       December 31, 2010, we had recognized $0.1 million (net
       of federal tax benefits) in interest and penalties in income tax
       expense.

[0000950123-11-015556:notes:148]
The Internal Revenue Service (“IRS”) completed its
       examination of our consolidated tax returns for the years
       1999 — 2003 and issued a Revenue Agent’s
       Report (“RAR”) on April 6, 2006. We reached a
       settlement with the IRS in December 2008 that resulted in an
       immaterial impact to the Consolidated Statements of Operations.

[0000950123-11-015556:notes:149]
The IRS completed its examination of our consolidated tax
       returns for the years
       2004-2005
       and issued an RAR on July 31, 2008. We reached a settlement
       with the IRS in the fourth quarter of 2009 that resulted in an
       immaterial impact to the Consolidated Statements of Operations.

[0000950123-11-015556:notes:150]
The IRS completed its examination of our consolidated tax
       returns for the years
       2006-2007
       and issued an RAR on June 1, 2009. We reached a settlement
       with the IRS in the third quarter of 2009 that resulted in an
       immaterial impact to the Consolidated Statements of Operations.

[0000950123-11-015556:notes:151]
We are currently under examination for our U.S. federal
       income taxes for 2008, 2009 and 2010. We are subject to
       examination by numerous other taxing authorities in
       jurisdictions such as Australia, Belgium, France, Canada, and
       Germany. We are generally no longer subject to
       U.S. federal, state and local, or
       non-U.S. income
       tax examinations by taxing authorities for years before 2004.

[0000950123-11-015556:notes:152]
During 2010, numerous states, including Colorado, Maine, Utah,
       the District of Columbia, California and Connecticut,
       enacted legislation effective for tax years beginning on or
       after January 1, 2010, including requirements for combined
       reporting, changes to apportionment methods and changes to nexus
       requirements. We determined the impact of these changes to be
       immaterial.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-015556:notes:153]
| 10. | Commitments and Contingencies: |

[0000950123-11-015556:notes:154]
Leases

[0000950123-11-015556:notes:155]
The approximate minimum commitments under all non-cancelable
       leases outstanding as of December 31, 2010 are as follows
       (in millions):

[0000950123-11-015556:notes:156]
|  |  | Operating |  |  | Capital |  |
|  |  | Leases |  |  | Leases |  |
| 2011 |  | $ | 54.2 |  |  | $ | 1.1 |  |
| 2012 |  |  | 40.4 |  |  |  | 1.0 |  |
| 2013 |  |  | 27.7 |  |  |  | 0.9 |  |
| 2014 |  |  | 17.4 |  |  |  | 0.7 |  |
| 2015 |  |  | 11.9 |  |  |  | 0.6 |  |
| Thereafter |  |  | 19.8 |  |  |  | 14.8 |  |
| Total minimum lease payments |  | $ | 171.4 |  |  |  | 19.1 |  |
| Less amount representing interest |  |  |  |  |  |  | 1.5 |  |
| Present value of minimum payments |  |  |  |  |  | $ | 17.6 |  |

[0000950123-11-015556:notes:157]
On June 22, 2006, we entered into an agreement with a
       financial institution to lease our corporate headquarters in
       Richardson, Texas for a term of seven years (the “Lake Park
       Lease”). The leased property consists of an office building
       of approximately 192,000 square feet, land and related
       improvements. During the term, the Lake Park Lease requires us
       to pay base rent in quarterly installments, payable in arrears.
       At the end of the term, we must do one of the following:
       (i) purchase the property for approximately
       $41.2 million; (ii) make a final payment under the
       lease equal to approximately 82% of the Lease Balance and return
       the property to the financial institution in good condition;
       (iii) arrange for the sale of the leased property to a
       third party; or (iv) renew the lease under mutually
       agreeable terms. If we elect to sell the property to a third
       party and the sales proceeds are less than the Lease Balance, we
       must pay any such deficit to the financial institution. Any such
       payment cannot exceed 82% of the Lease Balance.

[0000950123-11-015556:notes:158]
Our obligations under the Lake Park Lease are secured by a
       pledge of our interest in the leased property and are also
       guaranteed by us and certain of our subsidiaries. The Lake Park
       Lease, as amended, contains restrictive covenants that are
       consistent with those of our revolving credit facility. We were
       in compliance with these financial covenants as of
       December 31, 2010. The Lake Park Lease is accounted for as
       an operating lease.

[0000950123-11-015556:notes:159]
Environmental

[0000950123-11-015556:notes:160]
Applicable environmental laws can potentially impose obligations
       to remediate hazardous substances at our properties, at
       properties formerly owned or operated by us and at facilities to
       which we have sent or send waste for treatment or disposal. We
       are aware of contamination at some facilities; however, we do
       not presently believe that any future remediation costs at such
       facilities will be material to our results of operations.

[0000950123-11-015556:notes:161]
The amount and timing of cash payments are reliably determinable
       and, therefore, we have recorded environmental reserves at their
       present values.

[0000950123-11-015556:notes:162]
The following information relates to our environmental reserve
       (in millions except percentages):

[0000950123-11-015556:notes:163]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Discounted liabilities recorded in: |  |  |  |  |  |  |  |  |
| Accrued Expenses |  | $ | 1.1 |  |  | $ | 1.3 |  |
| Other Long-Term Liabilities |  |  | 3.3 |  |  |  | 3.0 |  |
|  |  | $ | 4.4 |  |  | $ | 4.3 |  |
| Undiscounted liabilities |  | $ | 4.8 |  |  | $ | 5.8 |  |
| Discount rate |  |  | 1.3%-7.9 | % |  |  | 3.3%-9.9 | % |

[0000950123-11-015556:notes:164]
Estimates of future costs are subject to change due to changing
       environmental remediation regulations
       and/or
       site-specific requirements.

[0000950123-11-015556:notes:165]
Total liabilities for estimated warranty are included in the
       following captions on the accompanying Consolidated Balance
       Sheets (in millions):

[0000950123-11-015556:notes:166]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued Expenses |  | $ | 31.2 |  |  | $ | 31.5 |  |
| Other Liabilities |  |  | 44.3 |  |  |  | 50.0 |  |
|  |  | $ | 75.5 |  |  | $ | 81.5 |  |

[0000950123-11-015556:notes:167]
The changes in the total warranty liabilities for the years
       ended December 31, 2010 and 2009 were as follows (in
       millions):

[0000950123-11-015556:notes:168]
| Total warranty liability as of December 31, 2008 |  | $ | 94.1 |  |
| Payments made in 2009 |  |  | (27.3 | ) |
| Changes resulting from issuance of new warranties |  |  | 25.7 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (12.7 | ) |
| Changes in foreign currency translation rates |  |  | 1.7 |  |
| Total warranty liability as of December 31, 2009 |  | $ | 81.5 |  |
| Payments made in 2010 |  |  | (27.6 | ) |
| Changes resulting from issuance of new warranties |  |  | 27.6 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (6.2 | ) |
| Changes in foreign currency translation rates |  |  | 0.2 |  |
| Total warranty liability as of December 31, 2010 |  | $ | 75.5 |  |

[0000950123-11-015556:notes:169]
|  |  | As of December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued product quality issue (not covered under warranty) |  | $ | 16.0 |  |  | $ | 21.6 |  |

[0000950123-11-015556:notes:170]
At the end of each accounting period, we evaluate our warranty
       liabilities and during the second quarter of each year, we
       perform a complete reevaluation of our HVAC warranty
       liabilities. As a result of our annual evaluation, we recorded a
       reduction in warranty liabilities in the second quarter of 2010
       that is the principal amount contained within the changes in
       estimates associated with pre-existing liabilities of
       $6.2 million above.

[0000950123-11-015556:notes:171]
We incur the risk of liability claims for the installation and
       service of heating and air conditioning products, and we
       maintain liabilities for those claims that we self-insure. We
       are involved in various claims and lawsuits related to our
       products. Our product liability insurance policies have limits
       that, if exceeded, may result in substantial costs that could
       have an adverse effect on our results of operations. In
       addition, warranty claims are not covered by our product
       liability insurance and certain product liability claims may
       also not be covered by our product liability insurance. There
       have been no material changes in the circumstances since our
       latest fiscal year-end.

[0000950123-11-015556:notes:172]
We also may incur costs related to our products that may not be
       covered under our warranties and are not covered by insurance,
       and we may, from time to time, repair or replace installed
       products experiencing quality issues in order to satisfy our
       customers and to protect our brand. These product quality issues
       may be caused by vendor-supplied components that fail to meet
       required specifications.

[0000950123-11-015556:notes:173]
We have identified a product quality issue in a heating and
       cooling product line produced in 2006 and 2007 that we believe
       results from a vendor-supplied materials quality issue. We have
       recorded an expense of $24.4 million in 2009 for the
       portion of the issue that was probable and reasonably estimable.
       There were no material charges recorded in 2010. As of
       December 31, 2010 and 2009, $16.0 million and
       $21.6 million, respectively, was accrued for this matter.
       We may incur additional charges in the future as more
       information becomes available. The expense for this product
       quality issue, and the related liability, has not been included
       in the tables related to our estimated warranty liabilities. The
       expense related to this product quality issue was classified in
       Cost of Goods Sold in the Consolidated Statements of Operations
       and the related liability is included in Accrued Expenses in the
       accompanying Consolidated Balance Sheets.

[0000950123-11-015556:notes:174]
Self
       Insurance

[0000950123-11-015556:notes:175]
We use a combination of third-party insurance and self-insurance
       plans (large deductible or captive) to provide protection
       against claims relating to workers’
       compensation/employers’ liability, general liability,
       product liability, auto liability, auto physical damage and
       other exposures. Prior to the third quarter of 2009, these
       policies were written by a third-party insurance provider, which
       was then reinsured by our captive insurance subsidiary. Starting
       with the third quarter of 2009, we use large deductible
       insurance plans for workers’ compensation/employers’
       liability, general liability, product liability, and auto
       liability. These policies are written through third-party
       insurance providers. We also carry umbrella or excess liability
       insurance for all third-party and self-insurance plans, except
       for directors’ and officers’ liability, property
       damage and various other insurance programs. We believe the
       limit within our excess policy is adequate for companies of our
       size in our industry. We believe that the deductibles and
       liability limits retained by LII and the captive are customary
       for companies of our size in our industry and are appropriate
       for our business.

[0000950123-11-015556:notes:176]
In addition, we use third-party insurance plans for property
       damage, aviation liability, directors’ and officers’
       liability, and other exposures. Each of these policies may
       include per occurrence and annual aggregate limits. However, we
       believe these limits are customary for companies of our size in
       our industry and are appropriate for our business.

[0000950123-11-015556:notes:177]
We maintain safety and manufacturing programs that are designed
       to improve the safety and effectiveness of our business
       processes and, as a result, reduce the level and severity of our
       various self-insurance risks. In recent years, our actual claims
       experience has been trending favorably and therefore, both
       self-insurance expense and the related liability have decreased.

[0000950123-11-015556:notes:178]
Since we have a captive insurance company, we are required to
       maintain specified levels of liquid assets from which we must
       pay claims. The majority of our self-insured risks (excluding
       auto liability and physical damage) will be paid over an
       extended period of time. To the extent actuarial assumptions
       change and claims experience rates differ from historical rates,
       our liability may change.

[0000950123-11-015556:notes:179]
The self-insurance liabilities recorded in Accrued Expenses in
       the accompanying Consolidated Balance Sheets were
       $61.3 million and $60.4 million as of
       December 31, 2010 and 2009, respectively.

[0000950123-11-015556:notes:180]
Litigation

[0000950123-11-015556:notes:181]
We are involved in a number of claims and lawsuits incident to
       the operation of our businesses. Insurance coverages are
       maintained and estimated costs are recorded for such claims and
       lawsuits. It is management’s opinion that none of these
       claims or lawsuits will have a material adverse effect on our
       financial position, results of operations or cash flows. Costs
       related to such matters were not material to the periods
       presented.

[0000950123-11-015556:notes:182]
We estimate the costs to settle pending litigation based on
       experience involving similar claims and specific facts known. We
       do not believe that any current or pending or threatened
       litigation will have a material adverse effect on our financial
       position. Litigation and arbitration, however, involve
       uncertainties and it is possible that the eventual outcome of
       litigation could adversely affect our results of operations for
       a particular period.

[0000950123-11-015556:notes:183]
We estimate the costs to settle pending litigation based on
       experience involving similar claims and specific facts known. We
       do not believe that any current or pending or threatened
       litigation with have a material adverse effect on our financial
       position. Litigation and arbitration, however, involve
       uncertainties and it is possible that the eventual outcome of
       litigation could adversely affect our results of operations for
       a particular period. We are the defendant in a class action
       lawsuit related to certain hearth products we produced and sold
       that claims such products are hazardous and that consumers were
       not adequately warned. On August 23, 2010, the Company and
       the plaintiffs entered into a binding Memorandum of
       Understanding (“MOU”) and have reached tentative terms
       for settlement of the case. At the parties’ request, the
       court stayed the lawsuit shortly after the MOU was signed. On
       January 11, 2011, the court granted preliminary approval of
       the settlement. The court set June 2, 2011 as the date for
       the final approval hearing. Total charges related to this matter
       recorded in 2010 were $9.3 million. These charges are
       included in Selling, General and Administrative Expenses and
       Losses (Gains) and Other Expenses, Net in the accompanying
       Consolidated Statement of Operations.


## us-gaap:DebtDisclosureTextBlock

[0000950123-11-015556:notes:184]
| 11. | Long-Term Debt, Lines of Credit and Asset Securitization: |

[0000950123-11-015556:notes:185]
Long-Term
       Debt and Lines of Credit

[0000950123-11-015556:notes:186]
The following tables summarize our outstanding debt obligations
       and the classification in the accompanying Consolidated Balance
       Sheet (in millions):

[0000950123-11-015556:notes:187]
| Description of Obligation |  |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2010 |  | Short-Term Debt |  |  | Current Maturities |  |  | Long-Term Maturities |  |  | Total |  |
| Domestic revolving credit facility |  | $ | — |  |  | $ | — |  |  | $ | 100.0 |  |  | $ | 100.0 |  |
| Senior unsecured notes |  |  | — |  |  |  | — |  |  |  | 200.0 |  |  |  | 200.0 |  |
| Capital lease obligations |  |  | — |  |  |  | 0.6 |  |  |  | 17.0 |  |  |  | 17.6 |  |
| Other obligations |  |  | 1.4 |  |  |  | — |  |  |  | — |  |  |  | 1.4 |  |
| Total debt |  | $ | 1.4 |  |  | $ | 0.6 |  |  | $ | 317.0 |  |  | $ | 319.0 |  |

[0000950123-11-015556:notes:188]
| Description of Obligation |  |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2009 |  | Short-Term Debt |  |  | Current Maturities |  |  | Long-Term Maturities |  |  | Total |  |
| Domestic promissory notes(1) |  | $ | — |  |  | $ | 35.0 |  |  | $ | — |  |  | $ | 35.0 |  |
| Domestic revolving credit facility |  |  | — |  |  |  | — |  |  |  | 176.5 |  |  |  | 176.5 |  |
| Capital lease obligations |  |  | — |  |  |  | 0.4 |  |  |  | 17.1 |  |  |  | 17.5 |  |
| Other obligations |  |  | 2.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 2.5 |  |
| Total debt |  | $ | 2.2 |  |  | $ | 35.5 |  |  | $ | 193.8 |  |  | $ | 231.5 |  |

[0000950123-11-015556:notes:189]
| (1) |  | The domestic promissory notes matured on June 1, 2010 and were prepaid during the first quarter of 2010. |

[0000950123-11-015556:notes:190]
As of December 31, 2010, the aggregate amounts of required
       principal payments on long-term debt are as follows (in
       millions):

[0000950123-11-015556:notes:191]
| 2011 |  | $ | 0.6 |  |
| 2012 |  |  | 100.7 |  |
| 2013 |  |  | 0.7 |  |
| 2014 |  |  | 0.6 |  |
| 2015 |  |  | 0.6 |  |
| Thereafter |  |  | 214.4 |  |

[0000950123-11-015556:notes:192]
As of December 31, 2010, we had outstanding borrowings of
       $100.0 million under our $650.0 million domestic
       revolving credit facility and $69.5 million was committed
       to standby letters of credit. The remaining $480.5 million
       was available for future borrowings subject to covenant
       limitations. The facility matures in October 2012. As of
       December 31, 2010, we were in compliance with all covenant
       requirements.

[0000950123-11-015556:notes:193]
We have additional borrowing capacity through several of our
       foreign subsidiaries used primarily to finance seasonal
       borrowing needs. We had $1.4 million and $2.5 million
       of obligations outstanding through our foreign subsidiaries as
       of December 31, 2010 and 2009, respectively. Available
       borrowing capacity at December 31, 2010 and 2009, under
       foreign facilities was $10.1 million and
       $12.6 million, respectively.

[0000950123-11-015556:notes:194]
Our domestic revolving credit facility includes a subfacility
       for swingline loans of up to $50.0 million and provides for
       the issuance of letters of credit for the full amount available
       under the domestic revolving credit facility. Our weighted
       average borrowing rate on the domestic revolving credit facility
       was 0.96% and 0.84% as of December 31, 2010 and 2009,
       respectively.

[0000950123-11-015556:notes:195]
Our domestic revolving credit facility contains financial
       covenants relating to leverage and interest coverage. Other
       covenants contained in our domestic revolving credit facility
       restrict, among other things, mergers, asset dispositions,
       guarantees, debt, liens, acquisitions, investments, affiliate
       transactions and our ability to make restricted payments. The
       financial covenants require us to maintain defined levels of
       Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash
       Flow (defined as EBITDA minus capital expenditures) to Net
       Interest Expense Ratio. The required ratios as of
       December 31, 2010 are detailed below:

[0000950123-11-015556:notes:196]
| Consolidated Indebtedness to Adjusted EBITDA Ratio not greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |

[0000950123-11-015556:notes:197]
Our domestic revolving credit facility contains customary events
       of default. These events of default include nonpayment of
       principal or interest, breach of covenants or other restrictions
       or requirements, default on any other
   indebtedness or receivables securitizations (cross default), and
       bankruptcy. A cross default under our revolving credit facility
       could occur if:

[0000950123-11-015556:notes:198]
|  | • | we fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $40.0 million; or |
|  | • | we are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $40.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0000950123-11-015556:notes:199]
Each of our major debt agreements contains provisions by which a
       default under one agreement causes a default in the others (a
       cross default). If a cross default under the revolving credit
       facility, our senior unsecured notes, or our revolving period
       asset securitization program were to occur, it could have a
       wider impact on our liquidity than might otherwise occur from a
       default of a single debt instrument or lease commitment.

[0000950123-11-015556:notes:200]
If any event of default occurs and is continuing, lenders with a
       majority of the aggregate commitments may require the
       administrative agent to terminate our right to borrow under our
       domestic revolving credit facility and accelerate amounts due
       under our domestic revolving credit facility (except for a
       bankruptcy event of default, in which case such amounts will
       automatically become due and payable and the lenders’
       commitments will automatically terminate).

[0000950123-11-015556:notes:201]
On May 6, 2010, we issued $200.0 million of senior
       unsecured notes due May 15, 2017 bearing fixed interest at
       4.90% as a result of a public offering of securities. We
       received proceeds of $199.8 million from the offering for a
       yield of 4.91%. We also paid and capitalized $1.9 million
       of debt issue costs related to the issuance. We pay interest on
       the notes semiannually on May 15 and November 15.

[0000950123-11-015556:notes:202]
The notes are guaranteed, on a senior unsecured basis, by each
       of our domestic subsidiaries that guarantee payment by us of any
       indebtedness under our domestic revolving credit facility. The
       indenture governing the notes contains covenants that, among
       other things, limit our ability and the ability of the
       subsidiary guarantors to: create or incur certain liens; enter
       into certain sale and leaseback transactions; enter into certain
       mergers, consolidations and transfers of substantially all of
       our assets; and transfer certain properties. The indenture also
       contains a cross default provision which is triggered if we
       default on other debt of at least $75 million in principal
       which is then accelerated, and such acceleration is not
       rescinded within 30 days of the notice date.

[0000950123-11-015556:notes:203]
During 2008, we expanded our Tifton, Georgia manufacturing
       facility using the proceeds from Industrial Development Bonds
       (“IDBs”). We entered into a lease agreement with the
       owner of the property and the issuer of the IDBs, and through
       our lease payments fund the interest payments to investors in
       the IDBs. We also guaranteed the repayment of the IDBs and
       entered into letters of credit totaling $15.5 million to
       fund a potential repurchase of the IDBs in the event that
       investors exercised their right to tender the IDBs to the
       Trustee. As of December 31, 2010 and 2009, we recorded both
       a capital lease asset and a corresponding long-term obligation
       of $14.3 million related to these transactions.

[0000950123-11-015556:notes:204]
Credit
       Rating

[0000950123-11-015556:notes:205]
At December 31, 2010, our senior credit rating was Baa3,
       with a stable outlook, by Moody’s and BBB-, with a stable
       outlook, by Standard & Poor’s Rating Group
       (“S&P”).

[0000950123-11-015556:notes:206]
Asset
       Securitization

[0000950123-11-015556:notes:207]
Under a revolving period asset securitization arrangement
       (“ASA”), we are eligible to sell beneficial interests
       in a portion of our trade accounts receivable to participating
       financial institutions for cash. The current arrangement expires
       November 18, 2011 and is subject to renewal and contains a
       provision whereby we retain the right to repurchase all of the
       outstanding beneficial interests transferred. Our continued
       involvement in the transferred assets includes servicing,
       collection and administration of the transferred beneficial
       interests.

[0000950123-11-015556:notes:208]
The accounts receivable sold under the ASA are high quality
       domestic customer accounts that have not aged significantly and
       the program takes into account an allowance for uncollectable
       accounts. The receivables represented by the retained interest
       that we service are exposed to the risk of loss for any
       uncollectible amounts in the pool of receivables sold under the
       ASA. The fair values assigned to the retained and transferred
       interests are based on the sold accounts receivable carrying
       value given the short term to maturity and low credit risk.

[0000950123-11-015556:notes:209]
The ASA contains certain restrictive covenants relating to the
       quality of our accounts receivable and cross-default provisions
       with our Credit Agreement. The administrative agent under the
       ASA is also a participant in our Credit Agreement. The
       participating financial institution has an investment grade
       credit rating. We continue to evaluate its credit rating and
       have no reason to believe it will not perform under the ASA. As
       of December 31, 2010, we were in compliance with all
       covenant requirements.

[0000950123-11-015556:notes:210]
The ASA provides for a maximum securitization amount of
       $100.0 million or 100% of the net pool balance as defined
       by the ASA. However, eligibility for securitization is limited
       based on the amount and quality of the qualifying accounts
       receivable and is calculated monthly. The beneficial interest
       sold cannot exceed the maximum amount even if our qualifying
       accounts receivable is greater than the maximum amount at any
       point in time. The eligible amounts available were as follows
       (in millions):

[0000950123-11-015556:notes:211]
|  |  | For the Years Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 100.0 |  |  | $ | 72.5 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 100.0 |  |  | $ | 72.5 |  |

[0000950123-11-015556:notes:212]
Under the ASA, we pay certain discount fees to use the program
       and have the facility available to us. These fees relate to both
       the used and unused portions of the securitization. The used fee
       is based on the beneficial interest sold and calculated on the
       average floating commercial paper rate determined by the
       purchaser of the beneficial interest, plus a program fee of
       0.75%. The rate as of December 31, 2010 and 2009 was 1.06%
       and 1.38%, respectively. The unused fee is based on 102% of the
       maximum available amount less the beneficial interest sold and
       calculated at 0.375% fixed rate throughout the term of the
       agreement. We recorded these fees in Selling, General and
       Administrative Expenses in the accompanying Consolidated
       Statements of Operations. The amounts recorded were as follows
       (in millions):

[0000950123-11-015556:notes:213]
|  |  | For the Years Ended December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Discount fees |  | $ | 0.5 |  |  | $ | 0.7 |  |  | $ | 0.2 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950123-11-015556:notes:214]
| 12. | Employee Benefit Plans: |

[0000950123-11-015556:notes:215]
Defined
       Contribution Plans

[0000950123-11-015556:notes:216]
We maintain noncontributory profit sharing plans for our
       eligible domestic and Canadian salaried employees. These plans
       are discretionary, as our contributions are determined annually
       by the Board of Directors. We also sponsor several defined
       contribution plans with employer contribution-matching
       requirements. We recorded the following (in millions):

[0000950123-11-015556:notes:217]
|  |  | For the Years Ended December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Provisions for profit sharing contributions |  | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |
| Contributions to defined contribution plans |  | $ | 12.1 |  |  | $ | 12.4 |  |  | $ | 1.6 |  |

[0000950123-11-015556:notes:218]
Pension
       and Postretirement Benefit Plans

[0000950123-11-015556:notes:219]
We provide pension and postretirement medical benefits to
       eligible domestic and foreign employees. In the third quarter of
       2008, we announced that we were freezing our defined benefit
       pension and profit sharing plans for our domestic and Canadian
       salaried employees and moving to an enhanced defined
       contribution plan in 2009 for our domestic salaried employees
       and 2010 for our Canadian salaried employees. We also maintain
       an unfunded postretirement benefit plan, which provides certain
       medical and life insurance benefits to eligible employees. In
       2006, we amended the postretirement benefit plan to
       (i) eliminate post-65 coverage for current and future
       nonunion retirees and (ii) gradually shift the pre-65
       medical coverage cost from us to participants starting in 2007
       such that by 2010, pre-65 retirees would be paying 100% of the
       cost. As a result of this amendment, the postretirement plan
       will still exist in 2010 and eligible nonunion participants will
       still be able to receive group coverage rates. However, we will
       no longer be paying any portion of the participants’
       premiums.

[0000950123-11-015556:notes:220]
The following tables set forth amounts recognized in our
       financial statements and the plans’ funded status (dollars
       in millions):

[0000950123-11-015556:notes:221]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |  |
| Accumulated benefit obligation |  | $ | 333.2 |  |  | $ | 296.1 |  |  | $ | N/A |  |  | $ | N/A |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year |  | $ | 299.4 |  |  | $ | 284.6 |  |  | $ | 14.4 |  |  | $ | 14.1 |  |
| Service cost |  |  | 5.0 |  |  |  | 5.6 |  |  |  | 0.6 |  |  |  | 0.5 |  |
| Interest cost |  |  | 17.6 |  |  |  | 17.5 |  |  |  | 0.8 |  |  |  | 0.8 |  |
| Plan participants’ contributions |  |  | — |  |  |  | — |  |  |  | 0.8 |  |  |  | 1.0 |  |
| Amendments |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |
| Actuarial loss |  |  | 34.0 |  |  |  | 9.1 |  |  |  | 2.4 |  |  |  | 1.3 |  |
| Effect of exchange rates |  |  | 0.4 |  |  |  | 3.9 |  |  |  | — |  |  |  | — |  |
| Settlements and curtailments |  |  | (2.6 | ) |  |  | (2.6 | ) |  |  | — |  |  |  | (0.9 | ) |
| Benefits paid |  |  | (17.5 | ) |  |  | (18.7 | ) |  |  | (1.9 | ) |  |  | (2.4 | ) |
| Benefit obligation at end of year |  | $ | 336.3 |  |  | $ | 299.4 |  |  | $ | 17.0 |  |  | $ | 14.4 |  |
| Changes in plan assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year |  | $ | 231.1 |  |  | $ | 174.0 |  |  | $ | — |  |  | $ | — |  |
| Actual gain return on plan assets |  |  | 27.6 |  |  |  | 33.0 |  |  |  | — |  |  |  | — |  |
| Employer contribution |  |  | 5.6 |  |  |  | 42.2 |  |  |  | 1.1 |  |  |  | 1.4 |  |
| Plan participants’ contributions |  |  | — |  |  |  | — |  |  |  | 0.8 |  |  |  | 1.0 |  |
| Effect of exchange rates |  |  | 0.4 |  |  |  | 3.0 |  |  |  | — |  |  |  | — |  |
| Plan settlements |  |  | (2.6 | ) |  |  | (2.4 | ) |  |  | — |  |  |  | — |  |
| Benefits paid |  |  | (17.5 | ) |  |  | (18.7 | ) |  |  | (1.9 | ) |  |  | (2.4 | ) |
| Fair value of plan assets at end of year |  |  | 244.6 |  |  |  | 231.1 |  |  |  | — |  |  |  | — |  |
| Funded status / net amount recognized |  | $ | (91.7 | ) |  | $ | (68.3 | ) |  | $ | (17.0 | ) |  | $ | (14.4 | ) |
| Net amount recognized consists of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liability |  | $ | (3.6 | ) |  | $ | (1.6 | ) |  | $ | (1.1 | ) |  | $ | (1.0 | ) |
| Non-current liability |  |  | (88.1 | ) |  |  | (66.7 | ) |  |  | (15.9 | ) |  |  | (13.4 | ) |
| Net amount recognized |  | $ | (91.7 | ) |  | $ | (68.3 | ) |  | $ | (17.0 | ) |  | $ | (14.4 | ) |

[0000950123-11-015556:notes:222]
Included in the Non-Current Pension Liability on the
       Consolidated Balance Sheets were plans with an over-funded
       position of $0.1 million as of December 31, 2010 and
       2009 (in millions).

[0000950123-11-015556:notes:223]
|  |  | For the Years Ended |
|  |  | December 31, |
|  |  | 2010 |  | 2009 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |  |  |  |  |  |
| Projected benefit obligation |  | $ | 335.6 |  |  | $ | 298.7 |  |
| Accumulated benefit obligation |  |  | 332.5 |  |  |  | 295.4 |  |
| Fair value of plan assets |  |  | 243.8 |  |  |  | 230.3 |  |

[0000950123-11-015556:notes:224]
Our
       U.S.-based
       pension plans comprised approximately 88.7% of the projected
       benefit obligation and 88.9% of plan assets as of
       December 31, 2010.

[0000950123-11-015556:notes:225]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 5.0 |  |  | $ | 5.6 |  |  | $ | 6.8 |  |  | $ | 0.6 |  |  | $ | 0.5 |  |  | $ | 0.8 |  |
| Interest cost |  |  | 17.6 |  |  |  | 17.5 |  |  |  | 16.4 |  |  |  | 0.8 |  |  |  | 0.8 |  |  |  | 0.8 |  |
| Expected return on plan assets |  |  | (19.5 | ) |  |  | (16.7 | ) |  |  | (17.6 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.5 |  |  |  | 0.5 |  |  |  | 0.6 |  |  |  | (1.9 | ) |  |  | (1.9 | ) |  |  | (1.9 | ) |
| Recognized actuarial loss |  |  | 5.1 |  |  |  | 8.9 |  |  |  | 4.6 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.1 |  |
| Settlements and curtailments |  |  | 1.4 |  |  |  | 1.0 |  |  |  | 3.1 |  |  |  | — |  |  |  | (0.6 | ) |  |  | — |  |
| Net periodic benefit cost |  | $ | 10.1 |  |  | $ | 16.8 |  |  | $ | 13.9 |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | 0.8 |  |

[0000950123-11-015556:notes:226]
The following table sets forth amounts recognized in AOCI in our
       financial statements for 2010 and 2009 (in millions):

[0000950123-11-015556:notes:227]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |  |
| Amounts recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service costs |  | $ | (3.5 | ) |  | $ | (4.0 | ) |  | $ | 14.7 |  |  | $ | 16.5 |  |
| Actuarial loss |  |  | (176.2 | ) |  |  | (156.6 | ) |  |  | (19.8 | ) |  |  | (18.7 | ) |
| Subtotal |  |  | (179.7 | ) |  |  | (160.6 | ) |  |  | (5.1 | ) |  |  | (2.2 | ) |
| Deferred taxes |  |  | 66.2 |  |  |  | 58.6 |  |  |  | 1.9 |  |  |  | 0.8 |  |
| Net amount recognized |  | $ | (113.5 | ) |  | $ | (102.0 | ) |  | $ | (3.2 | ) |  | $ | (1.4 | ) |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current year prior service costs |  | $ | — |  |  | $ | — |  |  |  | (0.1 | ) |  | $ | — |  |
| Current year actuarial loss (gain) |  |  | 25.8 |  |  |  | (7.5 | ) |  |  | 2.4 |  |  |  | 0.5 |  |
| Effect of exchange rates |  |  | 0.3 |  |  |  | 1.5 |  |  |  | — |  |  |  | — |  |
| Amortization of prior service (costs) credits |  |  | (0.5 | ) |  |  | (0.5 | ) |  |  | 1.9 |  |  |  | 2.5 |  |
| Amortization of actuarial loss |  |  | (6.5 | ) |  |  | (9.9 | ) |  |  | (1.3 | ) |  |  | (1.3 | ) |
| Total recognized in other comprehensive income |  | $ | 19.1 |  |  | $ | (16.4 | ) |  | $ | 2.9 |  |  | $ | 1.7 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) |  | $ | 29.2 |  |  | $ | 0.4 |  |  | $ | 3.6 |  |  | $ | 1.7 |  |

[0000950123-11-015556:notes:228]
The estimated prior service (costs) credits and actuarial gains
       (losses) that will be amortized from AOCI in 2011 are
       $(0.5) million and $(9.5) million, respectively, for
       pension benefits and $1.9 million and $(1.2) million,
       respectively, for other benefits.

[0000950123-11-015556:notes:229]
The following tables set forth the weighted-average assumptions
       used to determine Benefit Obligations and Net Periodic Benefit
       Cost for the
       U.S.-based
       plans in 2010 and 2009:

[0000950123-11-015556:notes:230]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |  |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  |  | 5.45 | % |  |  | 6.07 | % |  |  | 5.30 | % |  |  | 5.95 | % |
| Rate of compensation increase |  |  | 4.23 |  |  |  | 4.23 |  |  |  | — |  |  |  | — |  |

[0000950123-11-015556:notes:231]
|  |  | Pension Benefits |  |  | Other Benefits |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  |  | 6.07 | % |  |  | 6.27 | % |  |  | 6.48 | % |  |  | 5.95 | % |  |  | 6.42 | % |  |  | 6.36 | % |
| Expected long-term return on plan assets |  |  | 8.00 |  |  |  | 8.25 |  |  |  | 8.25 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Rate of compensation increase |  |  | 4.23 |  |  |  | 4.19 |  |  |  | 4.34 |  |  |  | — |  |  |  | — |  |  |  | — |  |

[0000950123-11-015556:notes:232]
The following tables set forth the weighted-average assumptions
       used to determine Benefit Obligations and Net Periodic Benefit
       Cost for the
       non-U.S.-based
       plans in 2010 and 2009:

[0000950123-11-015556:notes:233]
|  |  | Pension Benefits |
|  |  | 2010 |  | 2009 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |
| Discount rate |  |  | 5.43 | % |  |  | 5.98 | % |
| Rate of compensation increase |  |  | 3.94 |  |  |  | 3.98 |  |

[0000950123-11-015556:notes:234]
|  |  | Pension Benefits |
|  |  | 2010 |  | 2009 |  | 2008 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  |  | 5.98 | % |  |  | 6.57 | % |  |  | 5.60 | % |
| Expected long-term return on plan assets |  |  | 5.59 |  |  |  | 6.24 |  |  |  | 6.61 |  |
| Rate of compensation increase |  |  | 3.98 |  |  |  | 3.90 |  |  |  | 4.22 |  |

[0000950123-11-015556:notes:235]
To develop the expected long-term rate of return on assets
       assumption for the U.S. plans, we considered the historical
       returns and the future expectations for returns for each asset
       category, as well as the target asset allocation of the pension
       portfolio and the effect of periodic rebalancing. These results
       were adjusted for the payment of reasonable expenses of the plan
       from plan assets. This resulted in the selection of the 8.00%
       long-term rate of return on assets assumption. A similar process
       was followed for the
       non-U.S.-based
       plans.

[0000950123-11-015556:notes:236]
To select a discount rate for the purpose of valuing the plan
       obligations for the U.S. plans, we performed an analysis in
       which the duration of projected cash flows from defined benefit
       and retiree healthcare plans were matched with a yield curve
       based on the appropriate universe of high-quality corporate
       bonds that were available. We used the results of the yield
       curve analysis to select the discount rate that matched the
       duration and payment stream of the benefits in each plan. This
       resulted in the selection of the 5.47% discount rate assumption
       for the U.S. qualified pension plans, 5.28% for the
       U.S. non-qualified pension plans, and 5.30% for the other
       benefits. A similar process was followed for the
       non-U.S.-based
       plans.

[0000950123-11-015556:notes:237]
|  |  | 2010 |  | 2009 |
| Assumed health care cost trend rates as of December 31: |  |  |  |  |  |  |  |  |
| Health care cost trend rate assumed for next year |  |  | 8.50 | % |  |  | 8.75 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) |  |  | 5.00 | % |  |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate |  |  | 2020 |  |  |  | 2017 |  |

[0000950123-11-015556:notes:238]
Assumed health care cost trend rates have a significant effect
       on the amounts reported for our healthcare plan. A one
       percentage-point change in assumed healthcare cost trend rates
       would have the following effects (in millions):

[0000950123-11-015556:notes:239]
|  |  | 1-Percentage- |  | 1-Percentage- |
|  |  | Point Increase |  | Point Decrease |
| Effect on total of service and interest cost |  | $ | 0.2 |  |  | $ | (0.2 | ) |
| Effect on the postretirement benefit obligation |  |  | 1.6 |  |  |  | (1.4 | ) |

[0000950123-11-015556:notes:240]
Expected future benefit payments are shown in the table below
       (in millions):

[0000950123-11-015556:notes:241]
|  |  | Years Ended December 31, |
|  |  | 2011 |  | 2012 |  | 2013 |  | 2014 |  | 2015 |  | 2016- 2020 |
| Pension benefits |  | $ | 18.4 |  |  | $ | 16.9 |  |  | $ | 18.7 |  |  | $ | 17.9 |  |  | $ | 19.0 |  |  | $ | 103.6 |  |
| Other benefits |  |  | 1.1 |  |  |  | 1.1 |  |  |  | 1.1 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 7.1 |  |

[0000950123-11-015556:notes:242]
We believe that by adequately diversifying the plan assets,
       asset returns can be optimized at an acceptable level of risk.
       Since equity securities have historically generated higher
       returns than fixed income securities and the plan is not fully
       funded, we believe it is appropriate to allocate more assets to
       equities than fixed income securities. In addition, these
       categories are further diversified among various asset classes
       including high yield and emerging markets debt, and
       international and emerging markets equities in order to avoid
       significant concentrations of risk. Our U.S. pension plan
       represents approximately 90%, our Canadian pension plan
       approximately 6%, and our United Kingdom (“U.K.”)
       pension plan approximately 4% of the total fair value of our
       plan assets as of December 31, 2010.

[0000950123-11-015556:notes:243]
Our U.S. pension plans’ weighted-average asset
       allocations as of December 31, 2010 and 2009, by asset
       category, are as follows:

[0000950123-11-015556:notes:244]
|  |  | Plan Assets as of December 31, |  |
| Asset Category |  | 2010 |  |  | 2009 |  |
| U.S. equity |  |  | 33.1 | % |  |  | 33.2 | % |
| International equity |  |  | 28.5 |  |  |  | 25.8 |  |
| Fixed income |  |  | 36.8 |  |  |  | 36.8 |  |
| Money market/cash/guaranteed investment contracts |  |  | 1.6 |  |  |  | 4.2 |  |
| Total |  |  | 100.0 | % |  |  | 100.0 | % |

[0000950123-11-015556:notes:245]
U.S. pension plan investments are invested within the
       following range targets:

[0000950123-11-015556:notes:246]
| Asset Category |  | Target |
| U.S. equity |  |  | 36.0 | % |
| International equity |  |  | 24.0 | % |
| Fixed income |  |  | 38.0 | % |
| Money market/cash/guaranteed investment contracts |  |  | 2.0 | % |

[0000950123-11-015556:notes:247]
Our Canadian pension plan is invested in only one asset, which
       is a balanced fund that maintains diversification among various
       asset classes, including Canadian common stocks, bonds and money
       market securities, U.S. equities, other international
       equities and fixed income investments. Our U.K. pension plan was
       invested in a broad mix of assets consisting of U.K.,
       U.S. and international equities, U.K. fixed income
       securities, including corporate and government bonds, and bank
       deposits.

[0000950123-11-015556:notes:248]
The fair values of our pension plan assets, by asset category,
       are as follows:

[0000950123-11-015556:notes:249]
|  |  | Fair Value Measurements as of |  |
|  |  | December 31, 2010 |  |
|  |  |  |  |  | Significant |  |  |  |  |  |  |  |
|  |  | Quoted Prices in |  |  | Other |  |  | Significant |  |  |  |  |
|  |  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  |  |  |
|  |  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  |  |  |
|  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | Total |  |
| Assets Category: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.9 |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(1) |  |  | — |  |  |  | 33.7 |  |  |  | — |  |  |  | 33.7 |  |
| International equity(2) |  |  | — |  |  |  | 53.8 |  |  |  | — |  |  |  | 53.8 |  |
| Fixed income(3) |  |  | — |  |  |  | 74.0 |  |  |  | — |  |  |  | 74.0 |  |
| Mutual funds |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(4) |  |  | 38.2 |  |  |  | — |  |  |  | — |  |  |  | 38.2 |  |
| International equity(4) |  |  | 6.5 |  |  |  | — |  |  |  | — |  |  |  | 6.5 |  |
| Fixed income(5) |  |  | 6.2 |  |  |  | — |  |  |  | — |  |  |  | 6.2 |  |
| Balanced pension trust(6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity |  |  | — |  |  |  | 2.1 |  |  |  | — |  |  |  | 2.1 |  |
| International equity |  |  | — |  |  |  | 7.4 |  |  |  | — |  |  |  | 7.4 |  |
| Bonds |  |  | — |  |  |  | 5.3 |  |  |  | — |  |  |  | 5.3 |  |
| Pension fund |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(7) |  |  | — |  |  |  | 1.1 |  |  |  | — |  |  |  | 1.1 |  |
| International equity(7) |  |  | — |  |  |  | 5.7 |  |  |  | — |  |  |  | 5.7 |  |
| Fixed income(8) |  |  | — |  |  |  | 4.1 |  |  |  | — |  |  |  | 4.1 |  |
| Money market instruments(9) |  |  | — |  |  |  | 0.8 |  |  |  | — |  |  |  | 0.8 |  |
| Guaranteed investment contracts |  |  | — |  |  |  | 1.8 |  |  |  | — |  |  |  | 1.8 |  |
| Total |  | $ | 54.8 |  |  | $ | 189.8 |  |  | $ | — |  |  | $ | 244.6 |  |

[0000950123-11-015556:notes:250]
|  |  | Fair Value Measurements as of |  |
|  |  | December 31, 2009 |  |
|  |  |  |  |  | Significant |  |  |  |  |  |  |  |
|  |  | Quoted Prices in |  |  | Other |  |  | Significant |  |  |  |  |
|  |  | Active Markets for |  |  | Observable |  |  | Unobservable |  |  |  |  |
|  |  | Identical Assets |  |  | Inputs |  |  | Inputs |  |  |  |  |
|  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |  | Total |  |
| Assets Category: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 8.9 |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(1) |  |  | — |  |  |  | 45.5 |  |  |  | — |  |  |  | 45.5 |  |
| International equity(2) |  |  | — |  |  |  | 47.2 |  |  |  | — |  |  |  | 47.2 |  |
| Fixed income(3) |  |  | — |  |  |  | 69.7 |  |  |  | — |  |  |  | 69.7 |  |
| Mutual funds |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(4) |  |  | 23.0 |  |  |  | — |  |  |  | — |  |  |  | 23.0 |  |
| International equity(4) |  |  | 6.0 |  |  |  | — |  |  |  | — |  |  |  | 6.0 |  |
| Fixed income(5) |  |  | 6.0 |  |  |  | — |  |  |  | — |  |  |  | 6.0 |  |
| Balanced pension trust(6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity |  |  | — |  |  |  | 2.0 |  |  |  | — |  |  |  | 2.0 |  |
| International equity |  |  | — |  |  |  | 7.0 |  |  |  | — |  |  |  | 7.0 |  |
| Bonds |  |  | — |  |  |  | 5.1 |  |  |  | — |  |  |  | 5.1 |  |
| Guaranteed investment contracts |  |  | — |  |  |  | 10.7 |  |  |  | — |  |  |  | 10.7 |  |
| Total |  | $ | 43.9 |  |  | $ | 187.2 |  |  | $ | — |  |  | $ | 231.1 |  |

[0000950123-11-015556:notes:251]
Additional information about assets measured at Net Asset Value
       (“NAV”) per share (in millions):

[0000950123-11-015556:notes:252]
|  |  | As of December 31, 2010 |
|  |  |  |  |  | Redemption Frequency |  | Redemption Notice |
|  |  | Fair Value |  |  | (if currently eligible) |  | Period |
| Assets Category: |  |  |  |  |  |  |  |  |  |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(1) |  | $ | 33.7 |  |  | n/a |  |  | n/a |  |
| International equity(2) |  |  | 53.8 |  |  | Monthly |  |  | 10 — 15 days |  |
| Fixed income(3) |  |  | 74.0 |  |  | Quarterly |  |  | 15 days |  |
| Mutual funds |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(4) |  |  | 38.2 |  |  | n/a |  |  | n/a |  |
| International equity(4) |  |  | 6.5 |  |  | n/a |  |  | n/a |  |
| Fixed income(5) |  |  | 6.2 |  |  | n/a |  |  | n/a |  |
| Balanced pension trust(6) |  |  |  |  |  |  |  |  |  |  |
| U.S. equity |  |  | 2.1 |  |  | Daily |  |  | 5 days |  |
| International equity |  |  | 7.4 |  |  | Daily |  |  | 5 days |  |
| Bonds |  |  | 5.3 |  |  | Daily |  |  | 5 days |  |
| Pension fund |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(7) |  |  | 1.1 |  |  | Daily |  |  | 7 days |  |
| International equity(7) |  |  | 5.7 |  |  | Daily |  |  | 7 days |  |
| Fixed income(8) |  |  | 4.1 |  |  | Daily |  |  | 7 days |  |
| Money market instruments(9) |  |  | 0.8 |  |  | Daily |  |  | 7 days |  |
| Total |  | $ | 238.9 |  |  |  |  |  |  |  |

[0000950123-11-015556:notes:253]
|  |  | As of December 31, 2009 |  |
|  |  |  |  |  | Redemption Frequency |  |  | Redemption Notice |  |
|  |  | Fair Value |  |  | (if currently eligible) |  |  | Period |  |
| Assets Category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Commingled pools / Collective Trusts |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(1) |  | $ | 45.5 |  |  |  | Daily |  |  |  | 4 days |  |
| International equity(2) |  |  | 47.2 |  |  |  | Daily, Monthly |  |  |  | 4 — 15 days |  |
| Fixed income(3) |  |  | 69.7 |  |  |  | Quarterly |  |  |  | 15 days |  |
| Mutual funds |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity(4) |  |  | 23.0 |  |  |  | n/a |  |  |  | n/a |  |
| International equity(4) |  |  | 6.0 |  |  |  | n/a |  |  |  | n/a |  |
| Fixed income(5) |  |  | 6.0 |  |  |  | n/a |  |  |  | n/a |  |
| Balanced pension trust(6) |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. equity |  |  | 2.0 |  |  |  | Daily |  |  |  | 5 days |  |
| International equity |  |  | 7.0 |  |  |  | Daily |  |  |  | 5 days |  |
| Bonds |  |  | 5.1 |  |  |  | Daily |  |  |  | 5 days |  |
| Total |  | $ | 211.5 |  |  |  |  |  |  |  |  |  |

[0000950123-11-015556:notes:254]
| (1) |  | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) |  | This category includes investments primarily in Non-U.S. equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) |  | This category includes investments in U.S. investment grade and high yield fixed income securities, non-U.S. fixed income securities and emerging markets fixed income securities. |
| (4) |  | These funds seek capital appreciation and generally invest in common stocks of U.S. and Non-U.S. issuers. They may invest in growth stocks or value stocks. |
| (5) |  | This fund seeks to provide inflation protection. It currently invests at least 80% of its assets in inflation-indexed bonds issued by the U.S. government. It may invest in bonds of any maturity, though the fund typically maintains a dollar-weighted average maturity of 7 to 20 years. |
| (6) |  | The investment objectives of the fund are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The fund also holds a portion of its assets in U.S. and non-U.S. equities. |
| (7) |  | This category includes investments in U.S. and Non-U.S. equity securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (8) |  | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer and investment grade corporate bonds denominated in sterling. |
| (9) |  | This fund invests in U.K. money market instruments and includes cash, bank deposits and short-term fixed interest investments. |

[0000950123-11-015556:notes:255]
The majority of our commingled pool /collective trust, mutual
       funds and balanced pension trusts are managed by professional
       investment advisors. The NAVs per share are furnished in monthly
       and/or
       quarterly statements received from the investment advisors and
       reflect valuations based upon their pricing policies. We have
       assessed the classification of the inputs used to value these
       investments at Level 1 for mutual funds and Level 2
       for commingled pool / collective trusts and balance
       pension trusts through examination of their pricing policies and
       the related controls and procedures. The fair values we report
       are based on the pool or trust’s NAV per share. The
       NAV’s per share are calculated periodically (daily or no
       less than one time per month) as the aggregate value of each
       pool or trust’s underlying assets divided by the number of
       units owned.

[0000950123-11-015556:notes:256]
See Note 20 for information about our fair value
       hierarchies and valuation techniques.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950123-11-015556:notes:257]
| 13. | Comprehensive Income (Loss): |

[0000950123-11-015556:notes:258]
Our accumulated balances, shown net of tax for each
       classification of comprehensive income (loss) are as follows (in
       millions):

[0000950123-11-015556:notes:259]
|  |  | Foreign |  |  | Pension and |  |  |  |  |  |  |  |
|  |  | Currency |  |  | Postretirement |  |  | Derivatives |  |  |  |  |
|  |  | Translation Adjustment |  |  | Liability |  |  | and Other |  |  | Total |  |
| Balance as of December 31, 2007 |  | $ | 118.7 |  |  |  | (55.6 | ) |  |  | 0.5 |  |  |  | 63.6 |  |
| Net change in currency translation and pension and postretirement liability during 2008 |  |  | (84.9 | ) |  |  | (55.9 | ) |  |  | — |  |  |  | (140.8 | ) |
| Net change associated with 2008 derivative and other transactions |  |  | — |  |  |  | — |  |  |  | (14.9 | ) |  |  | (14.9 | ) |
| Reclassification of derivative gains into earnings |  |  | — |  |  |  | — |  |  |  | (6.7 | ) |  |  | (6.7 | ) |
| Balance as of December 31, 2008 |  |  | 33.8 |  |  | $ | (111.5 | ) |  | $ | (21.1 | ) |  | $ | (98.8 | ) |
| Net change in currency translation and pension and postretirement liability during 2009 |  |  | 59.5 |  |  |  | 8.1 |  |  |  | — |  |  |  | 67.6 |  |
| Net change associated with 2009 derivative and other transactions |  |  | — |  |  |  | — |  |  |  | 10.7 |  |  |  | 10.7 |  |
| Reclassification of derivative gains into earnings |  |  | — |  |  |  | — |  |  |  | 19.7 |  |  |  | 19.7 |  |
| Balance as of December 31, 2009 |  | $ | 93.3 |  |  | $ | (103.4 | ) |  | $ | 9.3 |  |  | $ | (0.8 | ) |
| Net change in currency translation and pension and postretirement liability during 2010 |  |  | 28.2 |  |  |  | (13.3 | ) |  |  |  |  |  |  | 14.9 |  |
| Net change associated with 2010 derivative and other transactions |  |  | — |  |  |  | — |  |  |  | 27.5 |  |  |  | 27.5 |  |
| Reclassification of derivative gains into earnings |  |  | — |  |  |  | — |  |  |  | (11.4 | ) |  |  | (11.4 | ) |
| Balance as of December 31, 2010 |  | $ | 121.5 |  |  | $ | (116.7 | ) |  | $ | 25.4 |  |  | $ | 30.2 |  |


## us-gaap:ScheduleOfTreasuryStockByClassTextBlock

[0000950123-11-015556:notes:260]
| 14. | Share Repurchases: |

[0000950123-11-015556:notes:261]
During 2008, our Board of Directors approved a
       $300.0 million share repurchase plan authorizing the
       repurchase of shares of our common stock through open market
       purchases (the “2008 Plan”). Also, during 2007, our
       Board of Directors approved a $500.0 million share
       repurchase plan authorizing the repurchase of shares of our
       common stock through open market purchases (the “2007
       Plan”).

[0000950123-11-015556:notes:262]
The following table summarizes the share repurchase activity for
       years ended December 31, 2010, 2009 and 2008, by share
       repurchase plan and those related to share-based payments (in
       millions, except per share data):

[0000950123-11-015556:notes:263]
|  |  | Related to |  |  |  |  |  |  |  |  | Total Share |  |
|  |  | Share-Based |  |  |  |  |  |  |  |  | Repurchase |  |
|  |  | Payments |  |  | 2008 Plan |  |  | 2007 Plan |  |  | Activity |  |
| 2010 share repurchase activity: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Number of shares |  |  | 0.2 |  |  |  | 3.3 |  |  |  | — |  |  |  | 3.5 |  |
| Weighted average price per share |  | $ | 44.83 |  |  | $ | 43.97 |  |  | $ | — |  |  | $ | 44.02 |  |
| Amount Repurchased |  | $ | 9.4 |  |  | $ | 144.3 |  |  | $ | — |  |  | $ | 153.7 |  |
| 2009 share repurchase activity: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Number of shares |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | 0.2 |  |
| Weighted average price per share |  | $ | 30.55 |  |  | $ | — |  |  | $ | — |  |  | $ | 30.55 |  |
| Amount repurchased |  | $ | 5.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.6 |  |
| 2008 share repurchase activity: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Number of shares |  |  | 0.4 |  |  |  | 0.6 |  |  |  | 8.3 |  |  |  | 9.3 |  |
| Weighted average price per share |  | $ | 35.10 |  |  | $ | 24.32 |  |  | $ | 35.72 |  |  | $ | 34.95 |  |
| Amount repurchased |  | $ | 12.5 |  |  | $ | 14.7 |  |  | $ | 296.6 |  |  | $ | 323.8 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-015556:notes:264]
| 15. | Stock-Based Compensation Plans: |

[0000950123-11-015556:notes:265]
Stock-Based Compensation expense is included in SG&A
       Expenses in the accompanying Consolidated Statements of
       Operations as follows (in millions):

[0000950123-11-015556:notes:266]
|  |  | For the Years Ended December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Compensation expense(1) |  | $ | 15.4 |  |  | $ | 12.8 |  |  | $ | 11.8 |  |

[0000950123-11-015556:notes:267]
| (1) |  | Stock-Based Compensation expense is recorded in our Corporate and other business segment. |

[0000950123-11-015556:notes:268]
Excess tax benefits classified as a financing cash inflow in the
       accompanying Consolidated Statements of Cash Flows were as
       follows (in millions):

[0000950123-11-015556:notes:269]
|  |  | For the Years Ended December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Excess tax benefits |  | $ | 5.3 |  |  | $ | 4.9 |  |  | $ | 11.0 |  |

[0000950123-11-015556:notes:270]
Incentive
       Plan

[0000950123-11-015556:notes:271]
Under the Lennox International Inc. 2010 Incentive Plan, as
       amended and restated (the “2010 Incentive Plan”), we
       are authorized to issue awards for 24,254,706 shares of
       common stock. As of December 31, 2010, awards for
       20,478,607 shares of common stock had been granted, net of
       cancellations and repurchases. Consequently, as of
       December 31, 2010, there were 3,776,099 shares
       available for future issuance.

[0000950123-11-015556:notes:272]
The 2010 Incentive Plan provides for various long-term incentive
       awards, which include stock options, performance share units,
       restricted stock units and stock appreciation rights. A
       description of these long-term incentive awards and related
       activity within each award category is provided below.

[0000950123-11-015556:notes:273]
Performance
       Share Units

[0000950123-11-015556:notes:274]
Total compensation expense for performance share units was
       $4.1 million, $1.8 million and $3.4 million for
       the years ended December 31, 2010, 2009 and 2008,
       respectively. The weighted-average fair value of performance
       share units granted during the years ended December 31,
       2010, 2009 and 2008 was $44.85, $35.26 and $26.83 per share,
       respectively.

[0000950123-11-015556:notes:275]
Under the 2010 Incentive Plan, performance share units are
       granted to certain employees at the discretion of the Board of
       Directors with a three-year performance period beginning
       January 1st of each year. Upon meeting the performance
       and vesting criteria, performance share units are converted to
       an equal number of shares of our common stock. Outstanding
       awards granted prior to 2003 vest after ten years of service at
       the target amount.

[0000950123-11-015556:notes:276]
Performance share units vest if, at the end of the three-year
       performance period, at least the threshold performance level has
       been attained. To the extent that the payout level attained is
       less than 100%, the difference between 100% and the units earned
       and distributed will be forfeited. Eligible participants may
       also earn additional units of our common stock, which would
       increase the potential payout from 101% to 200% of the units
       granted, depending on LII’s performance over the three-year
       performance period. The payout level for shares paid during
       years ended December 31, 2010, 2009 and 2008 was 127.68%,
       200% and 200%, respectively.

[0000950123-11-015556:notes:277]
Performance share units under the 2010 Incentive Plan are
       classified as equity awards, with the fair value of each unit
       equal to the average of the high and low market price of the
       stock on the date of grant for units granted prior to December
       2007. The fair value of units granted after December 2007 is the
       average of the high and low market price of the stock on the
       date of grant discounted by the expected dividend rate over the
       service period. Units are amortized to expense ratably over the
       service period. The compensation expense for any additional
       units which may be earned is estimated each reporting period
       based on the fair value of the stock at the date of grant. The
       number of units expected to be earned will be adjusted, as
       necessary, to reflect the actual number of units awarded.

[0000950123-11-015556:notes:278]
A summary of the status of our undistributed performance share
       units as of December 31, 2010, and changes during the year
       then ended, is presented below (in millions, except per share
       data):

[0000950123-11-015556:notes:279]
|  |  | Year Ended December 31, 2010 |  |
|  |  |  |  |  | Weighted-Average |  |
|  |  |  |  |  | Grant Date |  |
|  |  | Shares |  |  | Fair Value per Share |  |
| Undistributed performance share units: |  |  |  |  |  |  |  |  |
| Undistributed as of December 31, 2009 |  |  | 1.0 |  |  | $ | 28.68 |  |
| Granted |  |  | 0.2 |  |  |  | 44.85 |  |
| Additional shares earned |  |  | — |  |  |  | 30.85 |  |
| Distributed |  |  | (0.3 | ) |  |  | 27.07 |  |
| Forfeited |  |  | (0.1 | ) |  |  | 22.52 |  |
| Undistributed as of December 31, 2010(1) |  |  | 0.8 |  |  |  | 33.90 |  |

[0000950123-11-015556:notes:280]
| (1) |  | Undistributed performance share units as of December 31, 2010 include approximately 0.8 million units with a weighted-average grant date fair value of $33.90 per share that had not yet vested. |

[0000950123-11-015556:notes:281]
As of December 31, 2010, we had $12.6 million of total
       unrecognized compensation cost related to nonvested performance
       share units. Such cost is expected to be recognized over a
       weighted-average period of 2.4 years. Our estimated
       forfeiture rate for performance share units was 20.5% as of
       December 31, 2010.

[0000950123-11-015556:notes:282]
The total fair value of performance share units distributed and
       the resulting tax deductions to realize tax benefits were as
       follows (in millions):

[0000950123-11-015556:notes:283]
|  |  | For the Years Ended |
|  |  | December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Fair value of performance share units distributed |  | $ | 13.2 |  |  | $ | 9.6 |  |  | $ | 28.2 |  |
| Realized tax benefits from tax deductions |  |  | 5.0 |  |  |  | 3.7 |  |  |  | 10.7 |  |

[0000950123-11-015556:notes:284]
Our practice is to issue new shares of common stock to satisfy
       performance share unit distributions.

[0000950123-11-015556:notes:285]
Restricted
       Stock Units

[0000950123-11-015556:notes:286]
Total compensation expense for restricted stock units was
       $6.6 million, $6.6 million and $4.6 million for
       the years ended December 31, 2010, 2009 and 2008,
       respectively. The weighted-average fair value of restricted
       stock units granted during the years ended December 31,
       2010, 2009 and 2008 was $44.80, $35.09 and $27.48 per share,
       respectively.

[0000950123-11-015556:notes:287]
Under the 2010 Incentive Plan, restricted stock units are issued
       to attract and retain key employees. Generally, at the end of a
       three-year retention period, the units will vest and be
       distributed in shares of our common stock to the participant.

[0000950123-11-015556:notes:288]
Restricted stock units under the 2010 Incentive Plan are
       classified as equity awards, with the fair value of each unit
       equal to the average of the high and low market price of the
       stock on the date of grant for units granted prior to December
       2007. The fair value of units granted after December 2007 is the
       average of the high and low market price of the stock on the
       date of grant discounted by the expected dividend rate over the
       service period. Units are amortized to compensation expense
       ratably over the service period.

[0000950123-11-015556:notes:289]
A summary of the status of our nonvested restricted stock units
       as of December 31, 2010 and changes during the year then
       ended is presented below (in millions, except per share data):

[0000950123-11-015556:notes:290]
|  |  | Year Ended December 31, 2010 |  |
|  |  |  |  |  | Weighted-Average |  |
|  |  |  |  |  | Grant Date |  |
|  |  | Shares |  |  | Fair Value per Share |  |
| Nonvested restricted stock units: |  |  |  |  |  |  |  |  |
| Nonvested as of December 31, 2009 |  |  | 0.7 |  |  | $ | 31.14 |  |
| Granted |  |  | 0.2 |  |  |  | 44.80 |  |
| Vested |  |  | (0.2 | ) |  |  | 32.96 |  |
| Forfeited |  |  | (0.1 | ) |  |  | 30.90 |  |
| Nonvested as of December 31, 2010 |  |  | 0.6 |  |  |  | 34.44 |  |

[0000950123-11-015556:notes:291]
As of December 31, 2010, we had $13.0 million of total
       unrecognized compensation cost related to nonvested restricted
       stock units. Such cost is expected to be recognized over a
       weighted-average period of 2.4 years. Our estimated
       forfeiture rate for restricted stock units was 16.7% as of
       December 31, 2010.

[0000950123-11-015556:notes:292]
The total fair value of restricted stock units vested and the
       resulting tax deductions to realize tax benefits were as follows
       (in millions):

[0000950123-11-015556:notes:293]
|  |  | For the Years Ended December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Fair value of restricted stock units vested |  | $ | 9.4 |  |  | $ | 8.3 |  |  | $ | 6.4 |  |
| Realized tax benefits from tax deductions |  |  | 3.6 |  |  |  | 3.2 |  |  |  | 2.4 |  |

[0000950123-11-015556:notes:294]
Our practice is to issue new shares of common stock to satisfy
       restricted stock unit vestings.

[0000950123-11-015556:notes:295]
Stock
       Appreciation Rights

[0000950123-11-015556:notes:296]
Total compensation expense for stock appreciation rights was
       $4.7 million, $4.4 million and $3.8 million for
       the years ended December 31, 2010, 2009 and 2008,
       respectively. The weighted-average fair value of stock
       appreciation rights granted during the years ended
       December 31, 2010, 2009 and 2008 was $13.75, $10.96 and
       $6.84 per share, respectively.

[0000950123-11-015556:notes:297]
In 2003, we began awarding stock appreciation rights. Each
       recipient is given the “right” to receive a value
       equal to the future appreciation of our common stock price. The
       value is paid in shares of our common stock. Stock appreciation
       rights generally vest in one-third increments beginning on the
       first anniversary date after the grant date, and expire after
       seven years.

[0000950123-11-015556:notes:298]
Compensation expense for stock appreciation rights granted is
       based on the fair value on the date of grant and is recognized
       over the service period. The fair value for these awards is
       estimated using the Black-Scholes-Merton valuation model. We use
       historical stock price data and other pertinent information to
       estimate the expected volatility and the outstanding period of
       the award for separate groups of employees that have similar
       historical exercise behavior to estimate expected life. The
       risk-free interest rate was based on zero-coupon
       U.S. Treasury instruments with a remaining term equal to
       the expected life of the stock appreciation right at the time of
       grant.

[0000950123-11-015556:notes:299]
The fair value of each stock appreciation right granted in 2010,
       2009 and 2008 is estimated on the date of grant using the
       following assumptions:

[0000950123-11-015556:notes:300]
|  |  | For the Years Ended |
|  |  | December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Expected dividend yield |  |  | 1.46 | % |  |  | 1.57 | % |  |  | 2.05 | % |
| Risk-free interest rate |  |  | 1.46 | % |  |  | 1.78 | % |  |  | 1.40 | % |
| Expected volatility |  |  | 39.93 | % |  |  | 39.81 | % |  |  | 34.08 | % |
| Expected life (in years) |  |  | 4.04 |  |  |  | 4.12 |  |  |  | 4.18 |  |

[0000950123-11-015556:notes:301]
A summary of stock appreciation rights activity are as follows
       (in millions, except per share data):

[0000950123-11-015556:notes:302]
|  |  | Years Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
|  |  |  |  |  | Weighted- |  |  |  |  |  | Weighted- |  |  |  |  |  | Weighted- |  |
|  |  |  |  |  | Average |  |  |  |  |  | Average |  |  |  |  |  | Average |  |
|  |  |  |  |  | Exercise |  |  |  |  |  | Exercise |  |  |  |  |  | Exercise |  |
|  |  |  |  |  | Price per |  |  |  |  |  | Price per |  |  |  |  |  | Price per |  |
|  |  | Shares |  |  | Share |  |  | Shares |  |  | Share |  |  | Shares |  |  | Share |  |
| Outstanding at beginning of year |  |  | 2.9 |  |  | $ | 31.06 |  |  |  | 2.7 |  |  | $ | 29.59 |  |  |  | 2.2 |  |  | $ | 29.14 |  |
| Granted |  |  | 0.5 |  |  |  | 46.78 |  |  |  | 0.6 |  |  |  | 36.94 |  |  |  | 1.0 |  |  |  | 28.36 |  |
| Exercised |  |  | (0.7 | ) |  |  | 27.20 |  |  |  | (0.2 | ) |  |  | 28.31 |  |  |  | (0.3 | ) |  |  | 21.68 |  |
| Forfeited |  |  | (0.2 | ) |  |  | 31.97 |  |  |  | (0.2 | ) |  |  | 30.59 |  |  |  | (0.2 | ) |  |  | 32.68 |  |
| Outstanding at end of year |  |  | 2.5 |  |  | $ | 34.89 |  |  |  | 2.9 |  |  | $ | 31.06 |  |  |  | 2.7 |  |  | $ | 29.59 |  |
| Exercisable at end of year |  |  | 1.5 |  |  | $ | 31.81 |  |  |  | 1.6 |  |  | $ | 29.58 |  |  |  | 1.1 |  |  | $ | 28.65 |  |

[0000950123-11-015556:notes:303]
The following table summarizes information about stock
       appreciation rights outstanding as of December 31, 2010 (in
       millions, except per share data and years):

[0000950123-11-015556:notes:304]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
|  |  | Weighted-Average |  |  |  | Weighted-Average |  |  |
|  |  | Remaining |  |  |  | Remaining |  |  |
| Range of Exercise |  | Contractual Term |  | Aggregate Intrinsic |  | Contractual Life |  | Aggregate Intrinsic |
| Prices per Share |  | (in years) |  | Value |  | (in years) |  | Value |
| $16.76-$46.78 |  |  | 4 |  |  |  | 31.3 |  |  |  | 4 |  |  |  | 22.6 |  |

[0000950123-11-015556:notes:305]
As of December 31, 2010, we had $10.2 million of
       unrecognized compensation cost related to nonvested stock
       appreciation rights. Such cost is expected to be recognized over
       a weighted-average period of 2.3 years. Our estimated
       forfeiture rate for stock appreciation rights was 18% as of
       December 31, 2010.

[0000950123-11-015556:notes:306]
The total intrinsic value of stock appreciation rights exercised
       and the resulting tax deductions to realize tax benefits were as
       follows (in millions):

[0000950123-11-015556:notes:307]
|  |  | For the Years Ended |
|  |  | December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Intrinsic value of stock appreciation rights exercised |  | $ | 10.1 |  |  | $ | 1.5 |  |  | $ | 5.5 |  |
| Realized tax benefits from tax deductions |  |  | 3.9 |  |  |  | 0.6 |  |  |  | 2.1 |  |

[0000950123-11-015556:notes:308]
Our practice is to issue new shares of common stock to satisfy
       the exercise of stock appreciation rights.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950123-11-015556:notes:309]
| 16. | Restructuring Charges: |

[0000950123-11-015556:notes:310]
As part of our strategic priorities of manufacturing and
       sourcing excellence and expense reduction, we have initiated
       various manufacturing rationalization actions designed to lower
       our cost structure. We also continue to reorganize our North
       American distribution network in order to better serve our
       customers’ needs by deploying parts and equipment inventory
       closer to them. We have also initiated a number of activities
       that rationalize and reorganize various support and
       administrative functions to reduce ongoing selling and
       administrative expenses.

[0000950123-11-015556:notes:311]
Information
       on Total Restructuring Charges and Related
       Reserves

[0000950123-11-015556:notes:312]
Restructuring charges incurred include the following amounts (in
       millions):

[0000950123-11-015556:notes:313]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008(1) |  |
| Manufacturing rationalizations |  | $ | 11.1 |  |  | $ | 30.1 |  |  | $ | 19.7 |  |
| Reorganization of distribution network |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 2.9 |  |
| Reorganizations of corporate and business unit administrative functions |  |  | 4.4 |  |  |  | 11.3 |  |  |  | 7.8 |  |
| Total |  | $ | 15.6 |  |  | $ | 41.5 |  |  | $ | 30.4 |  |

[0000950123-11-015556:notes:314]
| (1) |  | Restructuring charges for manufacturing rationalizations included pension curtailment charges of $0.9 million for 2008 have not been reflected in restructuring reserves as these items relate to our pension obligation. These amounts also include pension settlement charges of $0.2 million in 2008. |

[0000950123-11-015556:notes:315]
The components of the $15.6 million of restructuring
       charges recorded in 2010 are discussed in greater detail in
       later sections of this footnote.

[0000950123-11-015556:notes:316]
In 2009, restructuring charges for manufacturing
       rationalizations included $9.7 million related to the
       consolidation of Residential Heating & Cooling
       manufacturing operations from Blackville, South Carolina into
       our operations in Orangeburg, South Carolina and Saltillo,
       Mexico. Manufacturing rationalizations recorded in
   2009 also included $7.8 million of charges related to the
       consolidation of certain Refrigeration manufacturing operations
       located in Parets, Spain into our existing operations in Genas,
       France. Restructuring charges for manufacturing rationalizations
       recorded in 2009 also included $7.7 million related to the
       consolidation of certain Commercial Heating & Cooling
       manufacturing operations located in Mions, France into our
       existing manufacturing operations in Longvic, France.
       Restructuring charges for manufacturing rationalizations
       recorded in 2009 also included $2.1 million related to the
       closure of our Refrigeration operations in Danville, Illinois
       and consolidate Danville manufacturing, support, and warehouse
       functions into our Tifton, Georgia and Stone Mountain, Georgia
       operations and $1.1 million related to the transition of
       production of selected Refrigeration products currently
       manufactured in Milperra, Australia to its sister facility in
       Wuxi, China.

[0000950123-11-015556:notes:317]
In 2009, restructuring charges related to reorganizations of
       corporate and business unit selling and administrative functions
       included $3.9 million related to reorganization of
       Commercial Heating & Cooling’s selling and
       administrative functions in Northern Europe through a series of
       restructuring actions. Reorganizations of corporate and business
       unit selling and administrative functions in 2009 also included
       charges of $1.9 million related to the relocation of
       Residential Heating & Cooling factory-built fireplace
       headquarters from Orange, California to Nashville, Tennessee and
       the consolidation of customer and technical service departments
       into our existing hearth products plant in Union City,
       Tennessee. Restructuring charges in 2009 for corporate and
       business unit selling and administrative functions also included
       $1.9 million related to the reorganization of the
       management structure of our Refrigeration administrative and
       support functions across the globe. Restructuring charges
       recorded in 2009 also included $1.8 million related to the
       centralization of certain Service Experts administrative and
       support functions and $1.1 million related to the
       reorganization of our Commercial Heating & Cooling
       selling and administrative organization in the United States and
       Canada.

[0000950123-11-015556:notes:318]
In 2008, restructuring charges for manufacturing
       rationalizations included $9.8 million related to the
       closure of our Refrigeration operations in Danville, Illinois
       and consolidation of manufacturing, support and warehouse
       functions in our Tifton, Georgia and Stone Mountain, Georgia
       operations. Manufacturing rationalizations also included charges
       of $3.4 million related to the transition of production of
       certain Residential Heating & Cooling products from
       our Marshalltown, Iowa manufacturing facility to our new
       manufacturing operations in Saltillo, Mexico and
       $3.1 million related to the transition of production of
       selected Refrigeration products manufactured in Milperra,
       Australia to its sister facility in Wuxi, China. We also
       recorded $1.6 million in restructuring charges related to
       the closure of Lennox Hearth Products Inc.’s operations in
       Lynwood, California, part of our Residential Heating &
       Cooling operations, and the consolidation of our
       U.S. factory-built fireplace manufacturing operations into
       our facility in Union City, Tennessee.

[0000950123-11-015556:notes:319]
In 2008, restructuring charges for reorganizations of corporate
       and business unit administrative functions included
       $4.1 million related to the reorganization of the Northern
       European sales support and administrative functions of the
       Commercial business unit and $1.1 million in charges
       related to the rationalization of our corporate administrative
       functions, primarily in the human resources and information
       technology areas.

[0000950123-11-015556:notes:320]
Restructuring reserves are included in Accrued Expenses in the
       accompanying Consolidated Balance Sheets. The table below
       details activity within the restructuring reserves for the years
       ended December 31, 2010 and 2009 (in millions):

[0000950123-11-015556:notes:321]
|  |  | Balance as of |  |  | Charged |  |  |  |  |  |  |  |  | Balance as of |  |
|  |  | December 31, |  |  | to |  |  | Cash |  |  | Non-Cash |  |  | December 31, |  |
| Description of Reserves |  | 2009 |  |  | Earnings |  |  | Utilization |  |  | Utilization and Other |  |  | 2010 |  |
| Severance and related expense |  | $ | 21.1 |  |  | $ | 9.0 |  |  | $ | (22.5 | ) |  | $ | (1.4 | ) |  | $ | 6.2 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 2.6 |  |  |  | — |  |  |  | (2.6 | ) |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 0.8 |  |  |  | (0.8 | ) |  |  | — |  |  |  | — |  |
| Lease termination |  |  | 0.3 |  |  |  | 0.5 |  |  |  | (0.5 | ) |  |  | — |  |  |  | 0.3 |  |
| Other(1) |  |  | 0.8 |  |  |  | 2.7 |  |  |  | (2.8 | ) |  |  | — |  |  |  | 0.7 |  |
| Total restructuring reserves |  | $ | 22.2 |  |  | $ | 15.6 |  |  | $ | (26.6 | ) |  | $ | (4.0 | ) |  | $ | 7.2 |  |

[0000950123-11-015556:notes:322]
| (1) |  | Charges classified as ‘Other’ include $1.0 million third-party services related to restructuring activities and $0.8 million of facilities clean-up and demolition costs. |

[0000950123-11-015556:notes:323]
|  |  | Balance as of |  |  | Charged |  |  |  |  |  | Non-Cash |  |  | Balance as of |  |
|  |  | December 31, |  |  | to |  |  | Cash |  |  | Utilization and |  |  | December 31, |  |
| Description of Reserves |  | 2008 |  |  | Earnings |  |  | Utilization |  |  | Other |  |  | 2009 |  |
| Severance and related expense |  | $ | 9.3 |  |  | $ | 27.8 |  |  | $ | (16.0 | ) |  | $ | — |  |  | $ | 21.1 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 7.7 |  |  |  | — |  |  |  | (7.7 | ) |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 1.5 |  |  |  | (1.4 | ) |  |  | (0.1 | ) |  |  | — |  |
| Lease termination |  |  | 0.6 |  |  |  | 0.8 |  |  |  | (1.1 | ) |  |  | — |  |  |  | 0.3 |  |
| Other(1) |  |  | 1.0 |  |  |  | 3.7 |  |  |  | (4.4 | ) |  |  | 0.5 |  |  |  | 0.8 |  |
| Total restructuring reserves |  | $ | 10.9 |  |  | $ | 41.5 |  |  | $ | (22.9 | ) |  | $ | (7.3 | ) |  | $ | 22.2 |  |

[0000950123-11-015556:notes:324]
| (1) |  | Charges classified as ‘Other’ include $1.7 million of manufacturing inefficiencies, $0.8 million third-party services related to restructuring activities and $0.7 million of facilities clean-up and demolition costs. |

[0000950123-11-015556:notes:325]
Manufacturing
       Rationalization Activities

[0000950123-11-015556:notes:326]
Information regarding the restructuring charges related to
       manufacturing rationalizations is as follows (in millions):

[0000950123-11-015556:notes:327]
|  |  | Charges |  |  | Charges |  |  | Total Charges |  |
|  |  | Incurred in |  |  | Incurred to |  |  | Expected to be |  |
|  |  | 2010 |  |  | Date |  |  | Incurred |  |
| Severance and related expense |  | $ | 6.0 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |
| Asset write-offs and accelerated depreciation |  |  | 2.1 |  |  |  | 10.5 |  |  |  | 10.5 |  |
| Equipment moves |  |  | 0.6 |  |  |  | 2.7 |  |  |  | 3.6 |  |
| Other |  |  | 2.4 |  |  |  | 6.2 |  |  |  | 8.4 |  |
| Total |  | $ | 11.1 |  |  | $ | 50.6 |  |  | $ | 53.7 |  |

[0000950123-11-015556:notes:328]
Restructuring expense for significant manufacturing
       rationalization activities related to the following:

[0000950123-11-015556:notes:329]
|  | • | In the third quarter of 2010, we began to exit contract coil manufacturing in our Refrigeration operations in Milperra, Australia. Total restructuring charges related to this action recorded in 2010 were $3.3 million, which was composed of severance of $2.8 million and other charges of $0.5 million. This action was primarily completed during 2010. |

[0000950123-11-015556:notes:330]
|  | • | In the first quarter of 2010, we began to exit OEM coil manufacturing in our Refrigeration operations in Milperra, Australia. Total restructuring charges related to this action recorded in 2010 were $5.3 million, which was composed of severance of $4.0 million, asset write-offs of $1.1 million and other charges of $0.2 million. This action was completed during 2010. |
|  | • | In the fourth quarter of 2009, we began the consolidation of certain Refrigeration manufacturing operations located in Parets, Spain into our existing operations in Genas, France. During 2010 we recorded restructuring charges totaling $1.4 million, primarily composed of equipment move costs, severance and other plant closure costs. This action was completed during 2010. |
|  | • | In the first quarter of 2009, we began the consolidation of Residential Heating & Cooling manufacturing operations from Blackville, South Carolina into our operations in Orangeburg, South Carolina and Saltillo, Mexico. Total restructuring charges recorded related to this action in 2010 were $1.4 million, primarily composed of equipment move costs, accelerated depreciation, severance and other plant closure costs. The consolidation is expected to be completed during the fourth quarter of 2011. |
|  | • | Additionally, during 2010, we reversed $0.8 million of restructuring severance charges related to the consolidation of certain Commercial Heating & Cooling manufacturing operations located in Mions, France into our existing manufacturing operations in Longvic, France to adjust estimated amounts to actual. |

[0000950123-11-015556:notes:331]
Reorganization
       of Distribution Network

[0000950123-11-015556:notes:332]
In the fourth quarter of 2008, we commenced the transition of
       activities currently performed at our North American Parts
       Center in Des Moines, Iowa to other locations, including our
       North American Distribution Center in Marshalltown, Iowa. We
       incurred $0.1 million of restructuring charges, which was
       composed of severance, during 2010 related to this transition.
       To date, we have incurred $3.2 million, which was composed
       primarily of severance, and we expect the total cost to be
       $3.6 million related to this restructuring activity. The
       total cost of this restructuring activity will be composed of
       severance of $2.6 million, equipment moving costs of
       $0.3 million and other costs of $0.7 million. The
       transition is expected to be completed in the fourth quarter of
       2011.

[0000950123-11-015556:notes:333]
Reorganizations
       of Corporate and Business Unit Administrative
       Functions

[0000950123-11-015556:notes:334]
Information regarding the restructuring charges related to the
       reorganization of the support and administrative functions is as
       follows (in millions):

[0000950123-11-015556:notes:335]
|  |  | Charges |  |  | Charges |  |  | Total Charges |  |
|  |  | Incurred in |  |  | Incurred to |  |  | Expected to be |  |
|  |  | 2010 |  |  | Date |  |  | Incurred |  |
| Severance and related expense |  | $ | 2.8 |  |  | $ | 23.4 |  |  | $ | 23.4 |  |
| Asset write-offs and accelerated depreciation |  |  | 0.6 |  |  |  | 1.4 |  |  |  | 1.4 |  |
| Lease termination |  |  | 0.7 |  |  |  | 2.4 |  |  |  | 2.4 |  |
| Other |  |  | 0.3 |  |  |  | 0.9 |  |  |  | 0.9 |  |
| Total |  | $ | 4.4 |  |  | $ | 28.1 |  |  | $ | 28.1 |  |

[0000950123-11-015556:notes:336]
We incurred costs related to the following significant
       restructuring actions in our support and administrative
       activities:

[0000950123-11-015556:notes:337]
|  | • | In the fourth quarter of 2010, we began to reorganize the management structure of our Service Experts business. Restructuring charges recorded in 2010 related to his action, totaled $1.1 million and was primarily composed of severance. Total anticipated restructuring charges related to this action are expected to total $1.1 million and consist principally of severance. We anticipate that this action will be completed in the third quarter of 2011. |

[0000950123-11-015556:notes:338]
|  | • | During the second quarter of 2010, we reorganized certain administrative operations of an acquired company within our Service Experts segment. Restructuring charges recorded in 2010 related to his action, totaled $1.0 million and was primarily composed of asset write-offs and lease termination costs. This action was completed during 2010. |
|  | • | In the third quarter of 2009, we initiated the relocation of Residential Heating & Cooling factory-built fireplace headquarters from Orange, California to Nashville, Tennessee and the consolidation of customer and technical service departments into our existing hearth products plant in Union City, Tennessee. As a result of this action, we recorded restructuring charges of $1.8 million during 2010, which primarily consisted of employee relocation and lease termination costs. Total restructuring charges related to this action totaled $3.8 million and consisted principally of severance, recruiting, relocation costs and lease termination costs. We completed this action during 2010. |
|  | • | During 2009 and 2008, we reorganized various administrative functions in our Commercial Heating & Cooling and Refrigeration segments. As a result of these actions, we recorded restructuring severance charges of $0.4 million during 2010. These actions were completed during 2010. |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000950123-11-015556:notes:339]
| 17. | Discontinued Operations: |

[0000950123-11-015556:notes:340]
Service
       Experts Discontinued Operations

[0000950123-11-015556:notes:341]
A summary of net trade sales and pre-tax operating losses
       classified as Discontinued Operations in the accompanying
       Consolidated Statements of Operations are detailed below (in
       millions):

[0000950123-11-015556:notes:342]
|  |  | For the Years Ended |
|  |  | December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Net trade sales |  | $ | 0.2 |  |  | $ | 26.1 |  |  | $ | 52.5 |  |
| Pre-tax operating loss(1) |  |  | (1.1 | ) |  |  | (13.1 | ) |  |  | (1.8 | ) |

[0000950123-11-015556:notes:343]
| (1) |  | Included in the pre-tax operating loss from discontinued operations are losses on the disposal of the assets and liabilities of the service centers sold of $0.2 million in 2010, and gains on disposal of the assets and liabilities of service centers sold of $2.3 million in 2009. Also, included in the 2009 pre-tax operating loss from discontinued operations is an impairment charge of $2.7 million related to service centers where the estimated selling price of the assets is below the net book value of those assets and a write-off of $4.0 million of goodwill related to the sale of these service centers. The pre-tax operating loss from discontinued operations in 2008 includes a provision of $4.4 million for an unfavorable judgment related to the sale of a service center in 2004 that was included in discontinued operations. This contingency was settled in 2009 for $6.1 million. |

[0000950123-11-015556:notes:344]
The assets and liabilities of the discontinued operations are
       presented as follows in the accompanying Consolidated Balance
       Sheets (in millions):

[0000950123-11-015556:notes:345]
|  |  | For the Years |
|  |  | Ended |
|  |  | December 31, |
|  |  | 2010 |  | 2009 |
| Assets of discontinued operations: |  |  |  |  |  |  |  |  |
| Other assets |  | $ | — |  |  | $ | 3.6 |  |
| Liabilities of discontinued operations: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 1.3 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-015556:notes:346]
| 18. | Earnings Per Share: |

[0000950123-11-015556:notes:347]
Basic earnings per share are computed by dividing net income by
       the weighted-average number of common shares outstanding during
       the period. Diluted earnings per share are computed by dividing
       net income by the sum of the weighted-average number of shares
       and the number of equivalent shares assumed outstanding, if
       dilutive, under our stock-based compensation plans.

[0000950123-11-015556:notes:348]
The computations of basic and diluted earnings per share for
       Income from Continuing Operations were as follows (in millions,
       except per share data):

[0000950123-11-015556:notes:349]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Net income |  | $ | 116.2 |  |  | $ | 51.1 |  |  | $ | 122.8 |  |
| Add: Loss (income) from discontinued operations |  |  | 0.9 |  |  |  | 10.7 |  |  |  | 1.0 |  |
| Income from continuing operations |  | $ | 117.1 |  |  | $ | 61.8 |  |  | $ | 123.8 |  |
| Weighted-average shares outstanding — basic |  |  | 54.6 |  |  |  | 55.6 |  |  |  | 56.7 |  |
| Effect of dilutive securities |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 1.6 |  |
| Weighted-average shares outstanding — diluted |  |  | 55.8 |  |  |  | 56.6 |  |  |  | 58.3 |  |
| Earnings per share from continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.14 |  |  | $ | 1.11 |  |  | $ | 2.18 |  |
| Diluted |  | $ | 2.10 |  |  | $ | 1.09 |  |  | $ | 2.12 |  |

[0000950123-11-015556:notes:350]
Stock appreciation rights were outstanding, but not included in
       the diluted earnings per share calculation because the assumed
       exercise of such rights would have been anti-dilutive. The
       details are as follows:

[0000950123-11-015556:notes:351]
|  |  | For the Years Ended December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Options to purchase common stock (number of shares) |  |  | 273,429 |  |  |  | — |  |  |  | 668,451 |  |
| Price ranges per share |  | $ | 46.78 |  |  | $ | N/A |  |  | $ | 34.52 to $37.11 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-015556:notes:352]
| 19. | Reportable Business Segments: |

[0000950123-11-015556:notes:353]
We operate in four reportable business segments of the HVACR
       industry. Our segments are organized primarily by the nature of
       the products and services provided. The table below details the
       nature of the operations of each reportable segment:

[0000950123-11-015556:notes:354]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Heating Air Conditioning Hearth Products |  | Residential Replacement Residential New Construction |  | United States Canada |
| Commercial Heating & Cooling |  | Rooftop Products Chillers Air Handlers |  | Light Commercial |  | United States Canada Europe |
| Service Experts |  | Equipment Sales Installation Maintenance Repair |  | Residential Light Commercial |  | United States Canada |
| Refrigeration |  | Unit Coolers Condensing Units Other Commercial Refrigeration Products |  | Light Commercial Food Preservation and Non-Food/Industrial |  | United States Canada Europe Asia Pacific South America |

[0000950123-11-015556:notes:355]
Transactions between segments, such as products sold to Service
       Experts by the Residential Heating & Cooling segment,
       are recorded on an arm’s-length basis using the market
       price for these products. The eliminations of these intercompany
       sales and any associated profit are noted in the reconciliation
       of segment results to the income from continuing operations
       before income taxes below.

[0000950123-11-015556:notes:356]
We use segment profit or loss as the primary measure of
       profitability to evaluate operating performance and to allocate
       capital resources. We define segment profit or loss as a
       segment’s income or loss from continuing operations before
       income taxes included in the accompanying Consolidated
       Statements of Operations excluding certain items. See the
       reconciliation of segment profit to Income from Continuing
       Operations Before Income Taxes below for more detail on the
       items excluded from segment profit.

[0000950123-11-015556:notes:357]
Our corporate costs include those costs related to corporate
       functions such as legal, internal audit, treasury, human
       resources, tax compliance and senior executive staff. Corporate
       costs also include the long-term share-based incentive awards
       provided to employees throughout LII. We recorded these
       share-based awards as Corporate costs as they are determined at
       the discretion of the Board of Directors and based on the
       historical practice of doing so for internal reporting purposes.

[0000950123-11-015556:notes:358]
Net sales and segment profit (loss) by business segment, along
       with a reconciliation of segment profit to Income from
       Continuing Operations Before Income Taxes are shown below (in
       millions):

[0000950123-11-015556:notes:359]
|  |  | For the Years Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 1,417.4 |  |  | $ | 1,293.5 |  |  | $ | 1,493.4 |  |
| Commercial Heating & Cooling |  |  | 620.0 |  |  |  | 594.6 |  |  |  | 835.3 |  |
| Service Experts |  |  | 590.3 |  |  |  | 535.4 |  |  |  | 586.3 |  |
| Refrigeration |  |  | 550.9 |  |  |  | 512.7 |  |  |  | 618.2 |  |
| Eliminations(1) |  |  | (82.2 | ) |  |  | (88.7 | ) |  |  | (92.1 | ) |
|  |  | $ | 3,096.4 |  |  | $ | 2,847.5 |  |  | $ | 3,441.1 |  |
| Segment Profit (Loss)(2) |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 132.3 |  |  | $ | 111.7 |  |  | $ | 145.8 |  |
| Commercial Heating & Cooling |  |  | 69.3 |  |  |  | 49.3 |  |  |  | 93.3 |  |
| Service Experts |  |  | 19.3 |  |  |  | 16.6 |  |  |  | 18.5 |  |
| Refrigeration |  |  | 61.4 |  |  |  | 48.9 |  |  |  | 60.2 |  |
| Corporate and other |  |  | (65.5 | ) |  |  | (62.5 | ) |  |  | (53.8 | ) |
| Eliminations(1) |  |  | 0.2 |  |  |  | 0.5 |  |  |  | (0.7 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 217.0 |  |  |  | 164.5 |  |  |  | 263.3 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (0.2 | ) |  |  | 18.3 |  |  |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit(3) |  |  | 11.2 |  |  |  | (10.9 | ) |  |  | 5.2 |  |
| Restructuring charges |  |  | 15.6 |  |  |  | 41.5 |  |  |  | 30.4 |  |
| Impairment of assets |  |  | — |  |  |  | 6.4 |  |  |  | 9.1 |  |
| Interest expense, net |  |  | 12.8 |  |  |  | 8.2 |  |  |  | 14.2 |  |
| Other expense, net |  |  | 1.0 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 176.6 |  |  | $ | 100.9 |  |  | $ | 204.3 |  |

[0000950123-11-015556:notes:360]
| (1) |  | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |
| (2) |  | We define segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: Excluding: |
| • |  | Special product quality adjustments. |
| • |  | Items within Losses (Gains) and Other Expenses, net that are noted in(3). |
| • |  | Restructuring charges. |
| • |  | Goodwill and equity method investment impairments. |
| • |  | Interest expense, net. |
| • |  | Other expense, net. |
| (3) |  | Items in Losses (Gains) and Other Expenses, net that are excluded from segment profit are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. For more information about Losses (Gains) and Other Expenses, net see Note 22. |

[0000950123-11-015556:notes:361]
Included in our Residential Heating & Cooling business
       segment profit for 2008 is a gain on the sale of fixed assets of
       $4.1 million. The gains or losses in our other business
       segments were immaterial for 2010, 2009 and 2008.

[0000950123-11-015556:notes:362]
On a consolidated basis, no revenues from transactions with a
       single customer were 10% or greater of our consolidated net
       sales for any of the periods presented.

[0000950123-11-015556:notes:363]
Total assets by business segment are shown below (in millions).
       The assets in the Corporate and other segment are primarily
       comprised of cash, short-term investments and deferred tax
       assets. Assets recorded in the operating segments represent
       those assets directly associated with those segments.

[0000950123-11-015556:notes:364]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Total Assets |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 519.8 |  |  | $ | 484.2 |  |
| Commercial Heating & Cooling |  |  | 252.7 |  |  |  | 238.5 |  |
| Service Experts |  |  | 186.2 |  |  |  | 173.1 |  |
| Refrigeration |  |  | 389.7 |  |  |  | 357.5 |  |
| Corporate and other |  |  | 354.9 |  |  |  | 297.3 |  |
| Eliminations(1) |  |  | (11.3 | ) |  |  | (10.3 | ) |
| Total assets |  |  | 1,692.0 |  |  |  | 1,540.3 |  |
| Discontinued operations (See Note 17) |  |  | — |  |  |  | 3.6 |  |
| Total assets |  | $ | 1,692.0 |  |  | $ | 1,543.9 |  |

[0000950123-11-015556:notes:365]
| (1) |  | Eliminations consist of net intercompany receivables and intercompany profit included in inventory from products sold between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |

[0000950123-11-015556:notes:366]
Total capital expenditures by business segment are shown below
       (in millions):

[0000950123-11-015556:notes:367]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Capital Expenditures |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 19.4 |  |  | $ | 31.7 |  |  | $ | 33.2 |  |
| Commercial Heating & Cooling |  |  | 6.2 |  |  |  | 6.8 |  |  |  | 7.0 |  |
| Service Experts |  |  | 0.8 |  |  |  | 0.7 |  |  |  | 0.3 |  |
| Refrigeration |  |  | 6.9 |  |  |  | 7.4 |  |  |  | 7.6 |  |
| Corporate and other |  |  | 12.5 |  |  |  | 12.2 |  |  |  | 14.0 |  |
| Total capital expenditures |  | $ | 45.8 |  |  | $ | 58.8 |  |  | $ | 62.1 |  |

[0000950123-11-015556:notes:368]
Excluded from capital expenditures for 2008 are capital leases
       of $7.4 million relating to our Residential
       Heating & Cooling and $14.6 million relating to
       our Refrigeration business segment. There were no capital leases
       in 2010 and 2009.

[0000950123-11-015556:notes:369]
The depreciation and amortization expense by business segment
       are shown below (in millions):

[0000950123-11-015556:notes:370]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Depreciation and Amortization |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 21.7 |  |  | $ | 22.2 |  |  | $ | 22.2 |  |
| Commercial Heating & Cooling |  |  | 8.0 |  |  |  | 8.0 |  |  |  | 8.2 |  |
| Service Experts |  |  | 2.2 |  |  |  | 1.9 |  |  |  | 1.9 |  |
| Refrigeration |  |  | 8.7 |  |  |  | 9.9 |  |  |  | 9.2 |  |
| Corporate and other |  |  | 12.9 |  |  |  | 10.9 |  |  |  | 9.1 |  |
| Total depreciation and amortization |  | $ | 53.5 |  |  | $ | 52.9 |  |  | $ | 50.6 |  |

[0000950123-11-015556:notes:371]
The equity method investees are shown below (in millions):

[0000950123-11-015556:notes:372]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Income from Equity Method Investments |  |  |  |  |  |  |  |  |  |  |  |  |
| Refrigeration |  | $ | 1.3 |  |  | $ | 0.5 |  |  | $ | 1.3 |  |
| Corporate and other(1) |  |  | 8.8 |  |  |  | 6.8 |  |  |  | 7.3 |  |
|  |  | $ | 10.1 |  |  | $ | 7.3 |  |  | $ | 8.6 |  |

[0000950123-11-015556:notes:373]
| (1) |  | A significant portion of income for equity method investments is allocated to our Residential Heating & Cooling and Commercial Heating & Cooling segments. We allocated $5.6 million, $5.9 million, and $4.5 million to those segments in 2010, 2009 and 2008, respectively. |

[0000950123-11-015556:notes:374]
The following table sets forth certain financial information
       relating to our operations by geographic area based on the
       domicile of our operations (in millions):

[0000950123-11-015556:notes:375]
|  |  | For the Years Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Net Sales to External Customers by Point of Shipment |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 2,255.4 |  |  | $ | 2,033.1 |  |  | $ | 2,429.2 |  |
| Canada |  |  | 336.6 |  |  |  | 327.0 |  |  |  | 363.9 |  |
| International |  |  | 504.4 |  |  |  | 487.4 |  |  |  | 648.0 |  |
| Total net sales to external customers |  | $ | 3,096.4 |  |  | $ | 2,847.5 |  |  | $ | 3,441.1 |  |

[0000950123-11-015556:notes:376]
|  |  | As of December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Property, Plant and Equipment, net |  |  |  |  |  |  |  |  |
| United States |  | $ | 225.5 |  |  | $ | 232.7 |  |
| Mexico |  |  | 33.0 |  |  |  | 30.3 |  |
| Canada |  |  | 6.0 |  |  |  | 6.0 |  |
| International |  |  | 59.8 |  |  |  | 60.6 |  |
| Total property, plant and equipment, net |  | $ | 324.3 |  |  | $ | 329.6 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000950123-11-015556:notes:377]
| 20. | Fair Value Measurements: |

[0000950123-11-015556:notes:378]
Fair value is the price that would be received to sell an asset
       or paid to transfer a liability in an orderly transaction
       between market participants at the measurement date. Our
       framework for measuring fair value is established on a
       three-level hierarchy for fair value measurements based upon the
       transparency of inputs to the valuation of an asset or liability
       as of the measurement date and requires consideration of our
       creditworthiness when valuing certain liabilities.

[0000950123-11-015556:notes:379]
Fair
       Value Hierarchy

[0000950123-11-015556:notes:380]
The three-level fair value hierarchies for disclosure of fair
       value measurements are defined as follows:

[0000950123-11-015556:notes:381]
Level 1 — Quoted prices for identical
       instruments in active markets at the measurement date.

[0000950123-11-015556:notes:382]
Level 2 — Quoted prices for similar
       instruments in active markets; quoted prices for identical
       or similar instruments in markets that are not active; and
       model-derived valuations in which all significant inputs and
       significant value drivers are observable in active
       markets at the measurement date and for the anticipated term of
       the instrument.

[0000950123-11-015556:notes:383]
Level 3 — Valuations derived from
       valuation techniques in which one or more significant inputs or
       significant value drivers are unobservable inputs that
       reflect the reporting entity’s own assumptions about the
       assumptions market participants would use in pricing the asset
       or liability developed based on the best information available
       in the circumstances.

[0000950123-11-015556:notes:384]
Fair
       Value Techniques

[0000950123-11-015556:notes:385]
Our fair value valuation techniques are applied to all of the
       assets and liabilities carried at fair value. Where available,
       the fair values are based upon quoted prices in active markets.
       However, if quoted prices are not available, then the fair
       values are based upon quoted prices for similar assets or
       liabilities or independently sourced market parameters, such as
       credit default swap spreads, yield curves, reported trades,
       broker/dealer quotes, interest rates and benchmark securities.
       For assets and liabilities with a lack of observable market
       activity, if any, the fair values are based upon discounted cash
       flow methodologies incorporating assumptions that, in our
       judgment, reflect the assumptions a marketplace participant
       would use. To ensure that financial assets and liabilities are
       recorded at fair value, valuation adjustments may be required to
       reflect either party’s creditworthiness and ability to pay.
       Where appropriate, these amounts were incorporated into our
       valuations as of December 31, 2010 and 2009, the
       measurement dates.

[0000950123-11-015556:notes:386]
Assets
       and Liabilities Measured at Fair Value on a Recurring
       Basis

[0000950123-11-015556:notes:387]
The following table presents the fair value hierarchy for those
       assets and liabilities measured at fair value on a recurring
       basis (in millions):

[0000950123-11-015556:notes:388]
|  |  | Fair Value Measurements on a Recurring Basis as of |
|  |  | December 31, 2010 |
|  |  | Quoted Prices in |  | Significant |  |  |  |  |
|  |  | Active Markets |  | Other |  | Significant |  |  |
|  |  | for |  | Observable |  | Unobservable |  |  |
|  |  | Identical Assets |  | Inputs |  | Inputs |  |  |
|  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  | Total |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment in marketable equity securities(1) |  | $ | 18.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 18.0 |  |
| Derivatives, net(2) |  |  | — |  |  |  | 16.8 |  |  |  | — |  |  |  | 16.8 |  |

[0000950123-11-015556:notes:389]
|  |  | Fair Value Measurements on a Recurring Basis as of |
|  |  | December 31, 2009 |
|  |  | Quoted Prices in |  | Significant |  |  |  |  |
|  |  | Active Markets |  | Other |  | Significant |  |  |
|  |  | for |  | Observable |  | Unobservable |  |  |
|  |  | Identical Assets |  | Inputs |  | Inputs |  |  |
|  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  | Total |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment in marketable equity securities(1) |  | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |
| Derivatives, net(2) |  |  | — |  |  |  | 10.2 |  |  |  | — |  |  |  | 10.2 |  |

[0000950123-11-015556:notes:390]
| (1) |  | Investment in marketable equity securities is recorded in Other Long-Term Assets in the accompanying Consolidated Balance Sheets. See Note 6 for more information. |
| (2) |  | For more information on the recording of derivatives in the accompanying Consolidated Balance Sheets, see Note 8. |

[0000950123-11-015556:notes:391]
Derivatives are primarily valued using estimated future cash
       flows that are based directly on observed prices from
       exchange-traded derivatives and, therefore, have been classified
       as Level 2. We also take into account the
       counterparty’s creditworthiness, or our own
       creditworthiness, as appropriate.

[0000950123-11-015556:notes:392]
Other
       Fair Value Measurements

[0000950123-11-015556:notes:393]
The carrying amounts of cash and cash equivalents, accounts and
       notes receivable, net, accounts payable and other current
       liabilities approximate fair value due to the short maturities
       of these instruments. The fair values of each of our long-term
       debt instruments are based on the quoted market prices for the
       same issues or on the amount of future cash flows associated
       with each instrument using current market rates for debt
       instruments of similar maturities and credit risk. The estimated
       fair value of long-term debt (including our domestic revolving
       credit facility, capital lease obligations, foreign obligations
       and any related current maturities) was $114.6 million and
       $242.5 million as of December 31, 2010 and 2009,
       respectively. The estimated fair value of our senior unsecured
       notes was $203.0 million as of December 31, 2010. The
       fair values presented are estimates and are not necessarily
       indicative of amounts for which we could settle such instruments
       currently or indicative of our intent or ability to dispose of
       or liquidate them.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000950123-11-015556:notes:394]
| 21. | Quarterly Financial Information (unaudited): |

[0000950123-11-015556:notes:395]
Financial
       results

[0000950123-11-015556:notes:396]
The following tables provide information on net sales, gross
       profit, net income, earnings per share and dividends per share
       by quarter (in millions, except per share data):

[0000950123-11-015556:notes:397]
|  |  | Net Sales |  | Gross Profit |  | Net (Loss) Income |
|  |  | 2010(1) |  | 2009(2) |  | 2010(1) |  | 2009(2) |  | 2010(1) |  | 2009(2) |
| First Quarter |  | $ | 644.1 |  |  | $ | 580.5 |  |  | $ | 174.3 |  |  | $ | 136.4 |  |  | $ | (1.6 | ) |  | $ | (18.1 | ) |
| Second Quarter |  |  | 872.1 |  |  |  | 784.0 |  |  |  | 264.7 |  |  |  | 226.2 |  |  |  | 48.3 |  |  |  | 31.7 |  |
| Third Quarter |  |  | 818.2 |  |  |  | 749.5 |  |  |  | 232.8 |  |  |  | 221.7 |  |  |  | 41.8 |  |  |  | 31.0 |  |
| Fourth Quarter |  |  | 762.0 |  |  |  | 733.5 |  |  |  | 220.0 |  |  |  | 203.8 |  |  |  | 27.7 |  |  |  | 6.5 |  |

[0000950123-11-015556:notes:398]
|  |  | Basic |  | Diluted |  |  |
|  |  | (Loss) Earnings |  | (Loss) Earnings |  |  |
|  |  | per Common |  | per |  | Dividends per |
|  |  | Share |  | Common Share |  | Common Share |
|  |  | 2010 |  | 2009 |  | 2010 |  | 2009 |  | 2010 |  | 2009 |
| First Quarter |  | $ | (0.02 | ) |  | $ | (0.33 | ) |  | $ | (0.02 | ) |  | $ | (0.33 | ) |  | $ | 0.15 |  |  | $ | 0.14 |  |
| Second Quarter |  |  | 0.88 |  |  |  | 0.57 |  |  |  | 0.86 |  |  |  | 0.56 |  |  |  | 0.15 |  |  |  | 0.14 |  |
| Third Quarter |  |  | 0.78 |  |  |  | 0.56 |  |  |  | 0.76 |  |  |  | 0.54 |  |  |  | 0.15 |  |  |  | 0.14 |  |
| Fourth Quarter |  |  | 0.52 |  |  |  | 0.12 |  |  |  | 0.51 |  |  |  | 0.11 |  |  |  | 0.15 |  |  |  | 0.14 |  |

[0000950123-11-015556:notes:399]
| (1) |  | The following unusual or infrequent pre-tax items were included in the 2010 quarterly results: |
|  |  | We recorded an adjustment to pension cost in the fourth quarter resulted in a reduction of pension cost by $4.1 million as compared to the prior year and by $3.5 million as compared to the third quarter. |
|  |  | We recorded LIFO related adjustments in the fourth quarter that increased gross profit by $2.5 million |
|  |  | We recorded restructuring charges throughout 2010 as follows: first quarter — $7.2 million, second quarter — $3.2 million, third quarter — $4.7 million and fourth quarter — $0.5 million. |
| (2) |  | The following unusual or infrequent pre-tax items were included in the 2009 quarterly results: |
|  |  | We recorded restructuring charges throughout 2009 as follows: first quarter — $11.2 million, second quarter — $4.7 million, third quarter — $11.5 million and fourth quarter — $14.1 million. |
|  |  | We recorded a $6.0 million impairment charge related to the abandonment of information technology assets in the fourth quarter. |
|  |  | We recorded expenses related to a specific product quality issue as follows: first quarter — $ —, second quarter — $4.2 million, third quarter — $0.9 million, and fourth quarter — $19.3 million. |
|  |  | We recorded a net gain of $3.8 million related to the sale and liquidation of a foreign business in the fourth quarter. |


## lii:LossesGainsAndOtherExpensesNetTextBlock

[0000950123-11-015556:notes:400]
| 22. | Losses (Gains) and Other Expenses, net: |

[0000950123-11-015556:notes:401]
Losses (Gains) and Other Expenses, net were as follows (in
       millions):

[0000950123-11-015556:notes:402]
|  |  | For the Years Ended |  |
|  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Realized losses (gains) on settled futures contracts |  | $ | (1.5 | ) |  | $ | 3.7 |  |  | $ | 0.9 |  |
| Net change in unrealized (gains) losses on unsettled futures contracts |  |  | (0.6 | ) |  |  | (7.1 | ) |  |  | 5.1 |  |
| Gain on disposal of a business, net |  |  | (0.1 | ) |  |  | (4.1 | ) |  |  | — |  |
| Losses (gains) on disposals of fixed assets |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | (4.8 | ) |
| Special legal contingency charge(1) |  |  | 6.8 |  |  |  | — |  |  |  | — |  |
| Acquisition expenses(2) |  |  | 4.8 |  |  |  | — |  |  |  | — |  |
| Foreign currency exchange losses (gains) |  |  | 0.4 |  |  |  | 0.7 |  |  |  | (3.2 | ) |
| Other items, net |  |  | 0.3 |  |  |  | 0.3 |  |  |  | 0.1 |  |
| Losses (Gains) and Other Expenses, net |  | $ | 10.2 |  |  | $ | (6.6 | ) |  | $ | (1.9 | ) |

[0000950123-11-015556:notes:403]
| (1) |  | For more information on the special legal contingency charge, see Note 10. |
| (2) |  | Acquisition expenses relate to an acquisition consummated subsequent to year end. For more information, see Note 24. |


## lii:SupplementalInformationTextBlock

[0000950123-11-015556:notes:404]
| 23. | Supplemental Information: |

[0000950123-11-015556:notes:405]
Below is information about expenses included in our Statements
       of Operations (in millions):

[0000950123-11-015556:notes:406]
|  |  | For the Years Ended |
|  |  | December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Research and development |  | $ | 49.5 |  |  | $ | 48.9 |  |  | $ | 46.0 |  |
| Advertising, promotions and marketing |  |  | 73.5 |  |  |  | 59.5 |  |  |  | 71.1 |  |
| Rent expense |  |  | 64.3 |  |  |  | 64.4 |  |  |  | 64.2 |  |

[0000950123-11-015556:notes:407]
Interest
       Expense, net

[0000950123-11-015556:notes:408]
The components of Interest Expense, net were as follows (in
       millions):

[0000950123-11-015556:notes:409]
|  |  | For the Years Ended |
|  |  | December 31, |
|  |  | 2010 |  | 2009 |  | 2008 |
| Interest expense, net of capitalized interest |  | $ | 13.7 |  |  | $ | 9.4 |  |  | $ | 18.0 |  |
| Interest income |  |  | 0.9 |  |  |  | 1.2 |  |  |  | 3.8 |  |


## us-gaap:ScheduleOfSubsequentEventsTextBlock

[0000950123-11-015556:notes:410]
| 24. | Subsequent Events (unaudited): |

[0000950123-11-015556:notes:411]
On January 14, 2011, we completed a transaction with The
       Manitowoc Company, Inc. by which we to acquired substantially
       all the assets of its Kysor/Warren business. Kysor/Warren is a
       leading manufacturer of refrigerated systems and display cases
       for supermarkets throughout North America. Under the terms of
       the agreement, the total consideration for the acquisition is
       $138 million, subject to a post-closing purchase price
       working capital adjustment.


## us-gaap:ScheduleOfCondensedFinancialStatementsTextBlock

[0000950123-11-015556:notes:412]
| 25. | Condensed Consolidating Financial Statements |

[0000950123-11-015556:notes:413]
The Company’s senior unsecured notes are unconditionally
       guaranteed by certain of the Company’s subsidiaries (the
       “Guarantor Subsidiaries”) while they are not by other
       subsidiaries (the “Non-Guarantor Subsidiaries”). As
       results of these guarantee arrangements, we are required to
       present the following condensed consolidating financial
       statements.

[0000950123-11-015556:notes:414]
The condensed consolidating financial statements reflect the
       investments in subsidiaries of the Company using the equity
       method of accounting. Intercompany account balances have been
       included in Accounts and Notes Receivable, Other (Current)
       Assets, Other Assets, net, Short-Term Debt, Accounts Payable,
       and Long-Term Debt line items of the Parent, Guarantor and
       Non-Guarantor balance sheets. The principal elimination entries
       eliminate investments in subsidiaries and intercompany balances
       and transactions.

[0000950123-11-015556:notes:415]
Condensed consolidating financial statements of the Company, its
       Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of
       December 31, 2010 and 2009 and for the for each of the
       fiscal years of the three-year period ended December 31,
       2010 are shown below:

[0000950123-11-015556:notes:416]
Condensed
       Consolidating Balance Sheets

[0000950123-11-015556:notes:417]
As of December 31, 2010

[0000950123-11-015556:notes:418]
(In millions)

[0000950123-11-015556:notes:419]
|  |  |  |  |  | Guarantor |  |  | Non-Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 81.1 |  |  | $ | 14.7 |  |  | $ | 64.2 |  |  | $ | — |  |  | $ | 160.0 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 12.2 |  |  |  | — |  |  |  | 12.2 |  |
| Accounts and notes receivable, net |  |  | (1,169.7 | ) |  |  | 933.3 |  |  |  | 613.2 |  |  |  | 8.0 |  |  |  | 384.8 |  |
| Inventories, net |  |  | — |  |  |  | 163.7 |  |  |  | 128.7 |  |  |  | (6.2 | ) |  |  | 286.2 |  |
| Deferred income taxes |  |  | — |  |  |  | 27.6 |  |  |  | 12.1 |  |  |  | (3.0 | ) |  |  | 36.7 |  |
| Other assets |  |  | 19.3 |  |  |  | 21.0 |  |  |  | 121.2 |  |  |  | (94.5 | ) |  |  | 67.0 |  |
| Total current assets |  |  | (1,069.3 | ) |  |  | 1,160.3 |  |  |  | 951.6 |  |  |  | (95.7 | ) |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 202.8 |  |  |  | 121.6 |  |  |  | (0.1 | ) |  |  | 324.3 |  |
| GOODWILL |  |  | — |  |  |  | 50.8 |  |  |  | 225.8 |  |  |  | (4.8 | ) |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | — |  |  |  | 77.3 |  |  |  | 22.6 |  |  |  | (12.7 | ) |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 2,068.3 |  |  |  | 415.6 |  |  |  | 51.8 |  |  |  | (2,473.9 | ) |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 31.1 |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | (31.5 | ) |  | $ | 1.4 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |
| Accounts payable |  |  | 8.1 |  |  |  | 133.1 |  |  |  | 131.0 |  |  |  | 1.6 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 6.6 |  |  |  | 262.0 |  |  |  | 115.5 |  |  |  | (49.6 | ) |  |  | 334.5 |  |
| Income taxes payable |  |  | (36.1 | ) |  |  | 30.6 |  |  |  | 28.3 |  |  |  | (17.5 | ) |  |  | 5.3 |  |
| Total current liabilities |  |  | 9.7 |  |  |  | 425.9 |  |  |  | 277.0 |  |  |  | (97.0 | ) |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 300.0 |  |  |  | 5.4 |  |  |  | 139.6 |  |  |  | (128.0 | ) |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 15.9 |  |  |  | — |  |  |  | — |  |  |  | 15.9 |  |
| PENSIONS |  |  | — |  |  |  | 77.4 |  |  |  | 10.7 |  |  |  | — |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 5.8 |  |  |  | 46.8 |  |  |  | 25.9 |  |  |  | (12.8 | ) |  |  | 65.7 |  |
| Total liabilities |  |  | 315.5 |  |  |  | 571.4 |  |  |  | 453.2 |  |  |  | (237.8 | ) |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 683.5 |  |  |  | 1,335.4 |  |  |  | 920.2 |  |  |  | (2,349.4 | ) |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |

[0000950123-11-015556:notes:420]
As of December 31, 2009

[0000950123-11-015556:notes:421]
|  |  |  |  |  | Guarantor |  |  | Non-Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 0.8 |  |  | $ | 6.6 |  |  | $ | 116.9 |  |  | $ | — |  |  | $ | 124.3 |  |
| Accounts and notes receivable, net |  |  | (975.0 | ) |  |  | 775.1 |  |  |  | 558.3 |  |  |  | (1.4 | ) |  |  | 357.0 |  |
| Inventories, net |  |  | — |  |  |  | 139.4 |  |  |  | 113.7 |  |  |  | (2.9 | ) |  |  | 250.2 |  |
| Deferred income taxes |  |  | — |  |  |  | 25.4 |  |  |  | 15.8 |  |  |  | (6.3 | ) |  |  | 34.9 |  |
| Other assets |  |  | 12.2 |  |  |  | 19.1 |  |  |  | 93.0 |  |  |  | (56.8 | ) |  |  | 67.5 |  |
| Total current assets |  |  | (962.0 | ) |  |  | 965.6 |  |  |  | 897.7 |  |  |  | (67.4 | ) |  |  | 833.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 207.8 |  |  |  | 121.8 |  |  |  | — |  |  |  | 329.6 |  |
| GOODWILL |  |  | — |  |  |  | 46.7 |  |  |  | 215.4 |  |  |  | (4.7 | ) |  |  | 257.4 |  |
| DEFERRED INCOME TAXES |  |  | — |  |  |  | 67.3 |  |  |  | 21.2 |  |  |  | (13.9 | ) |  |  | 74.6 |  |
| OTHER ASSETS, net |  |  | 1,905.1 |  |  |  | 371.4 |  |  |  | 41.5 |  |  |  | (2,269.6 | ) |  |  | 48.4 |  |
| TOTAL ASSETS |  | $ | 943.1 |  |  | $ | 1,658.8 |  |  | $ | 1,297.6 |  |  | $ | (2,355.6 | ) |  | $ | 1,543.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 25.1 |  |  | $ | — |  |  | $ | 2.5 |  |  | $ | (25.4 | ) |  | $ | 2.2 |  |
| Current maturities of long-term debt |  |  | 35.0 |  |  |  | — |  |  |  | 0.5 |  |  |  | — |  |  |  | 35.5 |  |
| Accounts payable |  |  | 7.9 |  |  |  | 115.4 |  |  |  | 122.7 |  |  |  | (7.8 | ) |  |  | 238.2 |  |
| Accrued expenses |  |  | 5.1 |  |  |  | 192.5 |  |  |  | 154.3 |  |  |  | (34.0 | ) |  |  | 317.9 |  |
| Income taxes payable |  |  | (17.5 | ) |  |  | (21.6 | ) |  |  | 43.2 |  |  |  | (4.1 | ) |  |  | — |  |
| Total current liabilities |  |  | 55.6 |  |  |  | 286.3 |  |  |  | 323.2 |  |  |  | (71.3 | ) |  |  | 593.8 |  |
| LONG-TERM DEBT |  |  | 176.5 |  |  |  | 98.8 |  |  |  | 117.4 |  |  |  | (198.9 | ) |  |  | 193.8 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 13.4 |  |  |  | — |  |  |  | — |  |  |  | 13.4 |  |
| PENSIONS |  |  | — |  |  |  | 56.3 |  |  |  | 10.5 |  |  |  | (0.1 | ) |  |  | 66.7 |  |
| OTHER LIABILITIES |  |  | 2.6 |  |  |  | 50.9 |  |  |  | 32.9 |  |  |  | (14.6 | ) |  |  | 71.8 |  |
| Total liabilities |  |  | 234.7 |  |  |  | 505.7 |  |  |  | 484.0 |  |  |  | (284.9 | ) |  |  | 939.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 708.4 |  |  |  | 1,153.1 |  |  |  | 813.6 |  |  |  | (2,070.7 | ) |  |  | 604.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 943.1 |  |  | $ | 1,658.8 |  |  | $ | 1,297.6 |  |  | $ | (2,355.6 | ) |  | $ | 1,543.9 |  |

[0000950123-11-015556:notes:422]
Condensed
       Consolidating Statements of Operations

[0000950123-11-015556:notes:423]
For the Year Ended December 31, 2010

[0000950123-11-015556:notes:424]
|  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 2,128.0 |  |  | $ | 1,220.8 |  |  | $ | (252.4 | ) |  | $ | 3,096.4 |  |
| COST OF GOODS SOLD |  |  | 0.2 |  |  |  | 1,545.8 |  |  |  | 907.8 |  |  |  | (249.2 | ) |  |  | 2,204.6 |  |
| Gross profit |  |  | (0.2 | ) |  |  | 582.2 |  |  |  | 313.0 |  |  |  | (3.2 | ) |  |  | 891.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 480.3 |  |  |  | 205.4 |  |  |  | — |  |  |  | 685.7 |  |
| (Gains) losses and other expenses, net |  |  | (0.6 | ) |  |  | 6.5 |  |  |  | 4.3 |  |  |  | — |  |  |  | 10.2 |  |
| Restructuring charges |  |  |  |  |  |  | 5.7 |  |  |  | 9.9 |  |  |  | — |  |  |  | 15.6 |  |
| (Income) loss from equity method investments |  |  | (138.8 | ) |  |  | (11.8 | ) |  |  | (10.1 | ) |  |  | 150.6 |  |  |  | (10.1 | ) |
| Operational income from continuing operations |  |  | 139.2 |  |  |  | 101.5 |  |  |  | 103.5 |  |  |  | (153.8 | ) |  |  | 190.4 |  |
| INTEREST (INCOME) EXPENSE, net |  |  | 12.4 |  |  |  | (3.0 | ) |  |  | 3.4 |  |  |  | — |  |  |  | 12.8 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 1.0 |  |  |  | — |  |  |  | 1.0 |  |
| Income from continuing operations before income taxes |  |  | 126.8 |  |  |  | 104.5 |  |  |  | 99.1 |  |  |  | (153.8 | ) |  |  | 176.6 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (4.4 | ) |  |  | 34.3 |  |  |  | 29.6 |  |  |  | — |  |  |  | 59.5 |  |
| Income from continuing operations |  |  | 131.2 |  |  |  | 70.2 |  |  |  | 69.5 |  |  |  | (153.8 | ) |  |  | 117.1 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.9 |  |  |  | — |  |  |  | 0.9 |  |
| Net income |  | $ | 131.2 |  |  | $ | 70.2 |  |  | $ | 68.6 |  |  | $ | (153.8 | ) |  | $ | 116.2 |  |

[0000950123-11-015556:notes:425]
CONDENSED
       CONSOLIDATING STATEMENTS OF OPERATIONS

[0000950123-11-015556:notes:426]
For the Year Ended December 31, 2009

[0000950123-11-015556:notes:427]
|  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 1,939.1 |  |  | $ | 1,147.1 |  |  | $ | (238.7 | ) |  | $ | 2,847.5 |  |
| COST OF GOODS SOLD |  |  | 0.2 |  |  |  | 1,440.8 |  |  |  | 857.2 |  |  |  | (238.8 | ) |  |  | 2,059.4 |  |
| Gross profit |  |  | (0.2 | ) |  |  | 498.3 |  |  |  | 289.9 |  |  |  | 0.1 |  |  |  | 788.1 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 453.0 |  |  |  | 191.8 |  |  |  | 0.1 |  |  |  | 644.9 |  |
| (Gains) losses and other expenses, net |  |  | (6.7 | ) |  |  | (0.7 | ) |  |  | 0.8 |  |  |  | — |  |  |  | (6.6 | ) |
| Restructuring charges |  |  | — |  |  |  | 16.2 |  |  |  | 25.3 |  |  |  | — |  |  |  | 41.5 |  |
| Impairment of assets |  |  | — |  |  |  | — |  |  |  | 6.4 |  |  |  | — |  |  |  | 6.4 |  |
| (Income) loss from equity method investments |  |  | (39.1 | ) |  |  | 5.4 |  |  |  | (7.3 | ) |  |  | 33.7 |  |  |  | (7.3 | ) |
| Operational income from continuing operations |  |  | 45.6 |  |  |  | 24.4 |  |  |  | 72.9 |  |  |  | (33.7 | ) |  |  | 109.2 |  |
| INTEREST (INCOME) EXPENSE, net |  |  | (0.8 | ) |  |  | 7.2 |  |  |  | 1.9 |  |  |  | (0.1 | ) |  |  | 8.2 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 46.4 |  |  |  | 17.2 |  |  |  | 70.9 |  |  |  | (33.6 | ) |  |  | 100.9 |  |
| PROVISION FOR INCOME TAXES |  |  | 0.2 |  |  |  | 6.3 |  |  |  | 32.2 |  |  |  | 0.4 |  |  |  | 39.1 |  |
| Income from continuing operations |  |  | 46.2 |  |  |  | 10.9 |  |  |  | 38.7 |  |  |  | (34.0 | ) |  |  | 61.8 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 10.7 |  |  |  | — |  |  |  | 10.7 |  |
| Net income |  | $ | 46.2 |  |  | $ | 10.9 |  |  | $ | 28.0 |  |  | $ | (34.0 | ) |  | $ | 51.1 |  |

[0000950123-11-015556:notes:428]
For the Year Ended December 31, 2008

[0000950123-11-015556:notes:429]
|  |  |  |  |  | Guarantor |  |  | Non-Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 2,193.6 |  |  | $ | 1,396.9 |  |  | $ | (149.4 | ) |  | $ | 3,441.1 |  |
| COST OF GOODS SOLD |  |  | 0.2 |  |  |  | 1,589.2 |  |  |  | 1,067.0 |  |  |  | (149.8 | ) |  |  | 2,506.6 |  |
| Gross profit |  |  | (0.2 | ) |  |  | 604.4 |  |  |  | 329.9 |  |  |  | 0.4 |  |  |  | 934.5 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 477.0 |  |  |  | 209.9 |  |  |  | — |  |  |  | 686.9 |  |
| Losses (gains) and other expenses, net |  |  | 5.1 |  |  |  | (5.9 | ) |  |  | (1.0 | ) |  |  | (0.1 | ) |  |  | (1.9 | ) |
| Restructuring charges |  |  | — |  |  |  | 10.7 |  |  |  | 19.7 |  |  |  | — |  |  |  | 30.4 |  |
| Impairment of assets |  |  | — |  |  |  | — |  |  |  | 9.1 |  |  |  | — |  |  |  | 9.1 |  |
| Income from equity method investments |  |  | (139.2 | ) |  |  | (6.6 | ) |  |  | (8.6 | ) |  |  | 145.8 |  |  |  | (8.6 | ) |
| Operational income from continuing operations |  |  | 133.9 |  |  |  | 129.2 |  |  |  | 100.8 |  |  |  | (145.3 | ) |  |  | 218.6 |  |
| INTEREST EXPENSE, net |  |  | 7.7 |  |  |  | 6.3 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 14.2 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 126.2 |  |  |  | 122.9 |  |  |  | 100.6 |  |  |  | (145.4 | ) |  |  | 204.3 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (2.9 | ) |  |  | 43.6 |  |  |  | 39.6 |  |  |  | 0.2 |  |  |  | 80.5 |  |
| Income from continuing operations |  |  | 129.1 |  |  |  | 79.3 |  |  |  | 61.0 |  |  |  | (145.6 | ) |  |  | 123.8 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 1.0 |  |  |  | — |  |  |  | 1.0 |  |
| Net income |  | $ | 129.1 |  |  | $ | 79.3 |  |  | $ | 60.0 |  |  | $ | (145.6 | ) |  | $ | 122.8 |  |

[0000950123-11-015556:notes:430]
CONDENSED
       CONSOLIDATING STATEMENT OF CASH FLOWS

[0000950123-11-015556:notes:431]
|  |  |  |  |  | Guarantor |  |  | Non-Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  | $ | (115.4 | ) |  |  | 315.3 |  |  | $ | (14.1 | ) |  | $ | — |  |  | $ | 185.8 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.2 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (33.7 | ) |  |  | (12.1 | ) |  |  | — |  |  |  | (45.8 | ) |
| Proceeds from sale of businesses |  |  | — |  |  |  | 0.1 |  |  |  | 3.5 |  |  |  | — |  |  |  | 3.6 |  |
| Acquisition of business |  |  | — |  |  |  | (7.2 | ) |  |  | — |  |  |  | — |  |  |  | (7.2 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | (12.2 | ) |  |  | — |  |  |  | (12.2 | ) |
| Net cash used in investing activities |  |  | — |  |  |  | (40.7 | ) |  |  | (20.7 | ) |  |  | — |  |  |  | (61.4 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term payments, net |  |  | — |  |  |  | — |  |  |  | (0.8 | ) |  |  | — |  |  |  | (0.8 | ) |
| Long-term payments |  |  | (35.0 | ) |  |  | (0.1 | ) |  |  | (0.8 | ) |  |  | — |  |  |  | (35.9 | ) |
| Issuance of senior unsecured notes |  |  | 199.8 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 199.8 |  |
| Revolver long-term borrowings, net |  |  | (76.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (76.5 | ) |
| Additional investment in affiliate |  |  | — |  |  |  | — |  |  |  | (1.0 | ) |  |  | — |  |  |  | (1.0 | ) |
| Proceeds from stock option exercises |  |  | 3.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3.5 |  |
| Payments of deferred financing costs |  |  | (1.8 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.8 | ) |
| Repurchases of common stock |  |  | (153.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (153.7 | ) |
| Excess tax benefits related to share-based payments |  |  | 5.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.3 |  |
| Intercompany debt |  |  | 90.8 |  |  |  | (107.8 | ) |  |  | 17.0 |  |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | 194.6 |  |  |  | (158.6 | ) |  |  | (36.0 | ) |  |  | — |  |  |  | — |  |
| Intercompany investments |  |  | (7.9 | ) |  |  | — |  |  |  | 7.9 |  |  |  | — |  |  |  | — |  |
| Intercompany dividends |  |  | 9.0 |  |  |  | — |  |  |  | (9.0 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (32.4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (32.4 | ) |
| Net cash provided by (used in) financing activities |  |  | 195.7 |  |  |  | (266.5 | ) |  |  | (22.7 | ) |  |  | — |  |  |  | (93.5 | ) |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | 80.3 |  |  |  | 8.1 |  |  |  | (57.5 | ) |  |  | — |  |  |  | 30.9 |  |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 4.8 |  |  |  | — |  |  |  | 4.8 |  |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | 0.8 |  |  |  | 6.6 |  |  |  | 116.9 |  |  |  | — |  |  |  | 124.3 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | 81.1 |  |  | $ | 14.7 |  |  | $ | 64.2 |  |  | $ | — |  |  | $ | 160.0 |  |

[0000950123-11-015556:notes:432]
|  |  |  |  |  | Guarantor |  |  | Non-Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  | $ | 54.0 |  |  | $ | 87.0 |  |  | $ | 84.5 |  |  | $ | — |  |  | $ | 225.5 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (48.3 | ) |  |  | (10.5 | ) |  |  | — |  |  |  | (58.8 | ) |
| Proceeds from sale of businesses |  |  | — |  |  |  | 1.1 |  |  |  | 8.9 |  |  |  | — |  |  |  | 10.0 |  |
| Return of investment |  |  | — |  |  |  | — |  |  |  | 0.9 |  |  |  | — |  |  |  | 0.9 |  |
| Purchases of short-term investments |  |  | — |  |  |  | — |  |  |  | (16.9 | ) |  |  | — |  |  |  | (16.9 | ) |
| Proceeds from sales and maturities of short-term investments |  |  | — |  |  |  | — |  |  |  | 50.2 |  |  |  | — |  |  |  | 50.2 |  |
| Net cash provided by (used in) investing activities |  |  | — |  |  |  | (47.0 | ) |  |  | 33.0 |  |  |  | — |  |  |  | (14.0 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term payments, net |  |  | — |  |  |  | — |  |  |  | (4.3 | ) |  |  | — |  |  |  | (4.3 | ) |
| Long-term payments |  |  | — |  |  |  | — |  |  |  | (1.7 | ) |  |  | — |  |  |  | (1.7 | ) |
| Revolver long-term payments, net |  |  | (183.3 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (183.3 | ) |
| Proceeds from stock option exercises |  |  | 9.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9.4 |  |
| Repurchases of common stock |  |  | (5.6 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5.6 | ) |
| Excess tax benefits related to share-based payments |  |  | 4.9 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4.9 |  |
| Intercompany debt |  |  | 21.0 |  |  |  | (12.5 | ) |  |  | (8.5 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | 126.5 |  |  |  | (24.0 | ) |  |  | (102.5 | ) |  |  | — |  |  |  | — |  |
| Intercompany dividends |  |  | 5.0 |  |  |  | — |  |  |  | (5.0 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (31.1 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (31.1 | ) |
| Net cash used in financing activities |  |  | (53.2 | ) |  |  | (36.5 | ) |  |  | (122.0 | ) |  |  | — |  |  |  | (211.7 | ) |
| DECREASE IN CASH AND CASH EQUIVALENTS |  |  | 0.8 |  |  |  | 3.5 |  |  |  | (4.5 | ) |  |  | — |  |  |  | (0.2 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 2.4 |  |  |  | — |  |  |  | 2.4 |  |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | — |  |  |  | 3.1 |  |  |  | 119.0 |  |  |  | — |  |  |  | 122.1 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | 0.8 |  |  | $ | 6.6 |  |  | $ | 116.9 |  |  | $ | — |  |  | $ | 124.3 |  |

[0000950123-11-015556:notes:433]
|  |  |  |  |  | Guarantor |  |  | Non-Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  | $ | 5.5 |  |  | $ | 136.4 |  |  | $ | 41.3 |  |  | $ | — |  |  | $ | 183.2 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 1.1 |  |  |  | 4.7 |  |  |  | — |  |  |  | 5.8 |  |
| Purchases of property, plant and equipment |  |  | (1.2 | ) |  |  | (49.3 | ) |  |  | (11.6 | ) |  |  | — |  |  |  | (62.1 | ) |
| Additional investments in affiliates |  |  | — |  |  |  | (3.1 | ) |  |  | (1.6 | ) |  |  | — |  |  |  | (4.7 | ) |
| Purchases of short-term investments |  |  | — |  |  |  | — |  |  |  | (64.2 | ) |  |  | — |  |  |  | (64.2 | ) |
| Proceeds from sales and maturities of short-term investments |  |  | — |  |  |  | — |  |  |  | 58.7 |  |  |  | — |  |  |  | 58.7 |  |
| Net cash used in investing activities |  |  | (1.2 | ) |  |  | (51.3 | ) |  |  | (14.0 | ) |  |  | — |  |  |  | (66.5 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 1.4 |  |  |  | — |  |  |  | 1.4 |  |
| Proceeds from capital lease |  |  | — |  |  |  | — |  |  |  | 15.3 |  |  |  | — |  |  |  | 15.3 |  |
| Long-term payments |  |  | (36.3 | ) |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | (36.4 | ) |
| Revolver long-term (payments) borrowings, net |  |  | 213.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 213.5 |  |
| Proceeds from stock option exercises |  |  | 19.7 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 19.7 |  |
| Payments of deferred financing costs |  |  | (0.3 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |
| Repurchases of common stock |  |  | (323.8 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (323.8 | ) |
| Excess tax benefits related to share-based payments |  |  | 11.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11.0 |  |
| Intercompany debt |  |  | (5.8 | ) |  |  | 9.8 |  |  |  | (4.0 | ) |  |  | — |  |  |  | — |  |
| Intercompany activity |  |  | 150.0 |  |  |  | (145.5 | ) |  |  | (4.5 | ) |  |  | — |  |  |  | — |  |
| Intercompany dividends |  |  | — |  |  |  | 41.5 |  |  |  | (41.5 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (32.4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (32.4 | ) |
| Net cash used in financing activities |  |  | (4.4 | ) |  |  | (94.2 | ) |  |  | (33.4 | ) |  |  | — |  |  |  | (132.0 | ) |
| DECREASE IN CASH AND CASH EQUIVALENTS |  |  | (0.1 | ) |  |  | (9.1 | ) |  |  | (6.1 | ) |  |  | — |  |  |  | (15.3 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | (8.1 | ) |  |  | — |  |  |  | (8.1 | ) |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | 0.1 |  |  |  | 12.2 |  |  |  | 133.2 |  |  |  | — |  |  |  | 145.5 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | — |  |  | $ | 3.1 |  |  | $ | 119.0 |  |  | $ | — |  |  | $ | 122.1 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000950123-11-015556:notes:434]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0000950123-11-015556:notes:435]
LENNOX
       INTERNATIONAL INC.

[0000950123-11-015556:notes:436]
SCHEDULE II — VALUATION AND
       QUALIFYING ACCOUNTS AND RESERVES

[0000950123-11-015556:notes:437]
For the Years Ended December 31, 2010, 2009 and 2008

[0000950123-11-015556:notes:438]
(In Millions)

[0000950123-11-015556:notes:439]
|  |  |  |  | Additions |  |  |  |  |  |  |  |  |
|  |  | Balance at |  | Charged |  |  |  |  |  |  |  | Balance |
|  |  | Beginning |  | to Cost and |  |  |  |  |  |  |  | at end |
|  |  | of Year |  | Expenses |  | Write-offs |  | Recoveries |  | Other |  | of Year |
| 2008: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 16.5 |  |  | $ | 17.0 |  |  | $ | (15.2 | ) |  | $ | 0.6 |  |  | $ | (1.0 | ) |  | $ | 17.9 |  |
| 2009: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 17.9 |  |  | $ | 12.6 |  |  | $ | (17.8 | ) |  | $ | 1.4 |  |  | $ | 1.5 |  |  | $ | 15.6 |  |
| 2010: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 15.6 |  |  | $ | 6.3 |  |  | $ | (9.9 | ) |  | $ | 1.2 |  |  | $ | (0.4 | ) |  | $ | 12.8 |  |
