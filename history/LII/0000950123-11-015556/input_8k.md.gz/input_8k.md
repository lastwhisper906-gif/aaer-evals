# LII 8-K — 0000950123-11-008535 filed 2011-02-03

## item codes, every 8-K on or before 2011-02-18

- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2011-02-18

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000950123-11-008535:8k_2_02:1]
EX-99.1
2
c11789exv99w1.htm
EXHIBIT 99.1

[0000950123-11-008535:8k_2_02:2]
Exhibit 99.1

[0000950123-11-008535:8k_2_02:3]
Exhibit 99.1

[0000950123-11-008535:8k_2_02:4]
Lennox International Reports Fourth Quarter and Full Year Results

[0000950123-11-008535:8k_2_02:5]
| • |  | 4Q10 adjusted EPS from continuing operations of $0.55 vs. $0.58 in 4Q09 |

[0000950123-11-008535:8k_2_02:6]
| • |  | 4Q10 GAAP EPS from continuing operations of $0.51 vs. $0.17 in 4Q09 |

[0000950123-11-008535:8k_2_02:7]
| • |  | 2010 adjusted EPS from continuing operations of $2.40, up 36% |

[0000950123-11-008535:8k_2_02:8]
| • |  | 2010 GAAP EPS from continuing operations of $2.10, up 93% |

[0000950123-11-008535:8k_2_02:9]
| • |  | Reiterate 2011 adjusted EPS from continuing operations guidance of $2.80-$3.10 |

[0000950123-11-008535:8k_2_02:10]
DALLAS, February 3, 2011 — Lennox International Inc. (NYSE: LII) today reported fourth quarter and
full year 2010 results.

[0000950123-11-008535:8k_2_02:11]
For the fourth quarter, revenue was $762 million, up 4% from the prior-year quarter. Foreign
exchange was neutral to revenue. Total segment profit margin was 6.4%, down from 7.1% in the
prior-year quarter primarily due to higher commodity costs. Diluted earnings per share from
continuing operations on an adjusted basis was $0.55 compared to $0.58 in the prior-year quarter.
Diluted earnings per share from continuing operations on a GAAP basis was $0.51 compared to $0.17
in the fourth quarter a year ago.

[0000950123-11-008535:8k_2_02:12]
For the full year, revenue was $3.1 billion, up 9% from the prior year, including a positive 2
point impact from foreign exchange. Total segment profit margin was up 120 basis points to 7.0%.
Diluted earnings per share from continuing operations on an adjusted basis, was $2.40, up 36% from
$1.77 in the prior year. Diluted earnings per share from continuing operations on a GAAP basis was
$2.10, up 93% from $1.09 in the prior year.

[0000950123-11-008535:8k_2_02:13]
“Each of our businesses returned to growth in 2010, and overall company revenue was up 9% for the
full year,” said Todd Bluedorn, CEO of Lennox International. “Our strong focus on profitability led
to a 120 basis point expansion of total segment margin for the year and 36% growth in adjusted EPS.
In the fourth quarter, revenue growth was led by our Residential business, up 9% despite the
tougher comparison against the fourth quarter a year ago. As expected overall for the company,
fourth quarter results were impacted by higher commodity costs. For 2011, we now expect $40-45
million of commodity headwind, with the year-over-year comparison more difficult in the first half.
As previously announced, we have taken pricing actions for 2011 and remain confident in offsetting
commodity headwind on a full-year basis. Looking at 2011 overall, we expect end market conditions
to continue to show improvement, and we reiterate our guidance range for organic revenue growth of
5-8% and adjusted EPS growth of 17-29% for the full year.”

[0000950123-11-008535:8k_2_02:14]
FOURTH QUARTER 2010 FINANCIAL HIGHLIGHTS

[0000950123-11-008535:8k_2_02:15]
Revenue: Revenue for the fourth quarter was $762 million, up 4% from the prior year. Foreign
exchange was neutral to revenue.

[0000950123-11-008535:8k_2_02:16]
Gross Profit: On a GAAP basis, gross profit in the fourth quarter increased 8% to $220 million, and
gross margin increased 110 basis points from 27.8% to 28.9%. On an adjusted basis, excluding an $18
million special charge in the fourth quarter of 2009, gross profit declined 1%, and gross margin
declined 140 basis points from 30.3% to 28.9%, primarily due to increased commodity costs.

[0000950123-11-008535:8k_2_02:17]
Income from Continuing Operations: For the fourth quarter, adjusted income from continuing
operations was $30 million, or $0.55 diluted earnings per share, compared to $33 million, or $0.58
diluted earnings per share from continuing operations in the prior-year quarter. On a GAAP basis,
fourth quarter 2010 income from continuing operations was $28 million, or $0.51 diluted earnings
per share, compared to $10 million, or $0.17 diluted earnings per share, in the prior-year quarter.

[0000950123-11-008535:8k_2_02:18]
Adjusted income from continuing operations for the fourth quarter of 2010 excludes net after-tax
charges of $2.4 million, which are derived from:

[0000950123-11-008535:8k_2_02:19]
|  | • |  | $2.8 million charge for acquisition expenses |

[0000950123-11-008535:8k_2_02:20]
|  | • |  | $0.2 million income related to restructuring activities |

[0000950123-11-008535:8k_2_02:21]
|  | • |  | $0.2 million net gain for the net change in unrealized gains on open future contracts, and other items |

[0000950123-11-008535:8k_2_02:22]
FULL YEAR 2010 FINANCIAL HIGHLIGHTS

[0000950123-11-008535:8k_2_02:23]
Revenue: For the full year, revenue was $3.1 billion, up 9% from the prior year. At constant
currency, revenue was up 7%.

[0000950123-11-008535:8k_2_02:24]
Gross Profit: On a GAAP basis, gross profit for the full year increased 13% to $892 million, and
gross margin increased 110 basis points from 27.7% to 28.8%. On an adjusted basis, excluding an $18
million special charge in the fourth quarter of 2009, gross profit increased 11%, and gross margin
increased 50 basis points from 28.3% to 28.8%. Gross margin increased primarily due to improved
price/mix, productivity initiatives, and sourcing savings, with offsets from higher commodity costs
and freight and distribution expenses.

[0000950123-11-008535:8k_2_02:25]
Income from Continuing Operations: Adjusted income from continuing operations for 2010 was $134
million, or $2.40 diluted earnings per share, compared to $100 million, or $1.77 diluted earnings
per share in the prior year. On a GAAP basis, income from continuing operations for 2010 was $117
million, or $2.10 diluted earnings per share, compared to $62 million, or $1.09 diluted earnings
per share in the prior year.

[0000950123-11-008535:8k_2_02:26]
Adjusted income from continuing operations for 2010 excludes net after-tax charges of $16.7
million, which are derived from:

[0000950123-11-008535:8k_2_02:27]
|  | • |  | $10.0 million charge for restructuring activities |

[0000950123-11-008535:8k_2_02:28]
|  | • |  | $4.2 million special legal contingency charge |

[0000950123-11-008535:8k_2_02:29]
|  | • |  | $3.0 million charge for acquisition expenses |

[0000950123-11-008535:8k_2_02:30]
|  | • |  | $0.5 million net gain for the net change in unrealized gains on open future contracts, and other items |

[0000950123-11-008535:8k_2_02:31]
Free Cash Flow and Total Debt: Cash generated from operations for the year was $186 million. The
company invested $46 million in capital assets, resulting in free cash flow of $140 million. Total
debt as of December 31, 2010 was $319 million. Total cash and cash equivalents were $160 million
ending the year.

[0000950123-11-008535:8k_2_02:32]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0000950123-11-008535:8k_2_02:33]
Residential Heating and Cooling

[0000950123-11-008535:8k_2_02:34]
|  | • |  | 4Q10 revenue of $349 million, up 9% from $321 million in the prior-year quarter; up 8% at constant currency |

[0000950123-11-008535:8k_2_02:35]
|  | • |  | 4Q10 segment profit of $34 million, down 12% from $38 million in 4Q09 |

[0000950123-11-008535:8k_2_02:36]
|  | • |  | 4Q10 segment profit margin of 9.6%, down 230 basis points from 11.9% in 4Q09 |

[0000950123-11-008535:8k_2_02:37]
|  | • |  | 2010 revenue of $1,417 million, up 10% from $1,293 million in 2009; up 9% at constant currency |

[0000950123-11-008535:8k_2_02:38]
|  | • |  | 2010 segment profit of $132 million, up 18% from $112 million in 2009 |

[0000950123-11-008535:8k_2_02:39]
|  | • |  | 2010 profit margin of 9.3%, up 70 basis points from 8.6% in 2009 |

[0000950123-11-008535:8k_2_02:40]
Fourth quarter results were positively impacted by higher volume and favorable price/mix, with
offsets from higher commodity costs and selling expenses. Full year results were positively
impacted by higher volume, sourcing savings, and productivity initiatives, with offsets from higher
commodity costs and selling expenses.

[0000950123-11-008535:8k_2_02:41]
Commercial Heating and Cooling

[0000950123-11-008535:8k_2_02:42]
|  | • |  | 4Q10 revenue of $148 million, up 2% from $146 million in the prior-year quarter; up 4% at constant currency |

[0000950123-11-008535:8k_2_02:43]
|  | • |  | 4Q10 segment profit of $13 million, up 20% from $11 million in 4Q09 |

[0000950123-11-008535:8k_2_02:44]
|  | • |  | 4Q10 segment profit margin of 8.8%, up 130 basis points from 7.5% in 4Q09 |

[0000950123-11-008535:8k_2_02:45]
|  | • |  | 2010 revenue of $620 million, up 4% from $595 million in 2009; up 5% at constant currency |

[0000950123-11-008535:8k_2_02:46]
|  | • |  | 2010 segment profit of $69 million, up 41% from $49 million in 2009 |

[0000950123-11-008535:8k_2_02:47]
|  | • |  | 2010 segment profit margin of 11.2%, up 290 basis points from 8.3% in 2009 |

[0000950123-11-008535:8k_2_02:48]
Fourth quarter results were positively impacted by favorable price/mix, sourcing savings, and
productivity initiatives, with offsets from higher commodity costs and selling expenses. Full year
results were positively impacted by volume, favorable price/mix, sourcing savings, and productivity
initiatives, with offsets from higher commodity costs, selling expenses, and freight and
distribution.

[0000950123-11-008535:8k_2_02:49]
Service Experts

[0000950123-11-008535:8k_2_02:50]
|  | • |  | 4Q10 revenue of $145 million, down 1% from $146 million in the prior-year quarter; down 2% at constant currency |

[0000950123-11-008535:8k_2_02:51]
|  | • |  | 4Q10 segment profit of $5 million, down 28% from $7 million in 4Q09 |

[0000950123-11-008535:8k_2_02:52]
|  | • |  | 4Q10 segment profit margin of 3.5%, down 130 basis points from 4.8% in 4Q09 |

[0000950123-11-008535:8k_2_02:53]
|  | • |  | 2010 revenue of $590 million, up 10% from $535 million in 2009; up 8% at constant currency |

[0000950123-11-008535:8k_2_02:54]
|  | • |  | 2010 segment profit of $19 million, up 16% from $17 million in 2009 |

[0000950123-11-008535:8k_2_02:55]
|  | • |  | 2010 segment profit margin of 3.3%, up 20 basis points from 3.1% in 2009 |

[0000950123-11-008535:8k_2_02:56]
Fourth quarter results were negatively impacted by volume with an offset from lower SG&A expenses.
Full year results were positively impacted by volume, with an offset from higher SG&A expenses.

[0000950123-11-008535:8k_2_02:57]
Refrigeration

[0000950123-11-008535:8k_2_02:58]
|  | • |  | 4Q10 revenue of $139 million, down 3% from $143 million in the prior-year quarter; down 5% at constant currency |

[0000950123-11-008535:8k_2_02:59]
|  | • |  | 4Q10 segment profit of $14 million, down 13% from $16 million in 4Q09 |

[0000950123-11-008535:8k_2_02:60]
|  | • |  | 4Q10 segment profit margin of 10.0%, down 120 basis points from 11.2% in 4Q09 |

[0000950123-11-008535:8k_2_02:61]
|  | • |  | 2010 revenue of $551 million, up 7% from $513 million in 2009; up 2% at constant currency |

[0000950123-11-008535:8k_2_02:62]
|  | • |  | 2010 segment profit of $61 million, up 26% from $49 million in 2009 |

[0000950123-11-008535:8k_2_02:63]
|  | • |  | 2010 segment profit margin of 11.1%, up 160 basis points from 9.5% in 2009 |

[0000950123-11-008535:8k_2_02:64]
Fourth quarter results were negatively impacted by lower volume and higher commodity costs, with
offsets from favorable price/mix, sourcing savings, and productivity initiatives. Adjusting for the
strategic exit of the third party coil business in Australia, fourth quarter revenue was up
slightly. Full year results for Refrigeration were positively impacted by volume, favorable
price/mix, sourcing savings, and productivity initiatives, with offsets from higher commodity
costs, selling expenses, and the strategic exit of the third party coil business in Australia.

[0000950123-11-008535:8k_2_02:65]
2011 FULL YEAR OUTLOOK

[0000950123-11-008535:8k_2_02:66]
The company reiterates its 2011 revenue and EPS guidance originally provided on December 15, 2010:

[0000950123-11-008535:8k_2_02:67]
|  | • |  | Organic revenue growth of 5-8%, including 1 point of positive foreign exchange impact; an additional 6 points of growth from the acquisition of Kysor/Warren, closed on January 14, 2011, resulting in total revenue growth guidance of 11-14% for 2011. |

[0000950123-11-008535:8k_2_02:68]
|  | • |  | Adjusted EPS from continuing operations of $2.80 to $3.10, up 17-29% |

[0000950123-11-008535:8k_2_02:69]
|  | • |  | GAAP EPS from continuing operations of $2.75 to $3.05, up 31-45% |

[0000950123-11-008535:8k_2_02:70]
|  | • |  | Tax rate of approximately 35% |

[0000950123-11-008535:8k_2_02:71]
CONFERENCE CALL INFORMATION

[0000950123-11-008535:8k_2_02:72]
A conference call to discuss the company’s fourth quarter and full year 2010 results will be held
this morning at 8:30 a.m. Central time. To listen, please call the conference call line at
612-288-0340 at least 10 minutes prior to the scheduled start time and use reservation number
187891. This conference call will also be webcast on Lennox International’s web site at
http://www.lennoxinternational.com.

[0000950123-11-008535:8k_2_02:73]
A replay will be available from 11:00 a.m. Central time on February 3 through February 10, 2011, by
dialing 800-475-6701 (U.S.) or 320-365-3844 (International) and using access code 187891. This call
will also be archived on the company’s web site.

[0000950123-11-008535:8k_2_02:74]
Lennox International Inc. is a global leader in the heating, air conditioning, and
refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under
the symbol “LII.” Additional information is available at: http://www.lennoxinternational.com or by
contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0000950123-11-008535:8k_2_02:75]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-008535:8k_2_02:76]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950123-11-008535:8k_2_02:77]
(Unaudited, in millions, except per share data)

[0000950123-11-008535:8k_2_02:78]
|  |  | For the Three Months |  |  | For the Twelve Months |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |  |
| NET SALES |  | $ | 762.0 |  |  | $ | 733.5 |  |  | $ | 3,096.4 |  |  | $ | 2,847.5 |  |
| COST OF GOODS SOLD |  |  | 542.0 |  |  |  | 529.7 |  |  |  | 2,204.6 |  |  |  | 2,059.4 |  |
| Gross profit |  |  | 220.0 |  |  |  | 203.8 |  |  |  | 891.8 |  |  |  | 788.1 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 172.7 |  |  |  | 171.1 |  |  |  | 685.7 |  |  |  | 644.9 |  |
| Losses (gains) and other expenses, net |  |  | 3.9 |  |  |  | (4.4 | ) |  |  | 10.2 |  |  |  | (6.6 | ) |
| Restructuring charges |  |  | 0.6 |  |  |  | 14.1 |  |  |  | 15.6 |  |  |  | 41.5 |  |
| Impairment of assets |  |  | — |  |  |  | 6.4 |  |  |  | — |  |  |  | 6.4 |  |
| Income from equity method investments |  |  | (1.2 | ) |  |  | (1.7 | ) |  |  | (10.1 | ) |  |  | (7.3 | ) |
| Operational income from continuing operations |  |  | 44.0 |  |  |  | 18.3 |  |  |  | 190.4 |  |  |  | 109.2 |  |
| INTEREST EXPENSE, net |  |  | 3.7 |  |  |  | 2.1 |  |  |  | 12.8 |  |  |  | 8.2 |  |
| OTHER EXPENSE, net |  |  | 0.9 |  |  |  | — |  |  |  | 1.0 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 39.4 |  |  |  | 16.2 |  |  |  | 176.6 |  |  |  | 100.9 |  |
| PROVISION FOR INCOME TAXES |  |  | 11.6 |  |  |  | 6.3 |  |  |  | 59.5 |  |  |  | 39.1 |  |
| Income from continuing operations |  | $ | 27.8 |  |  | $ | 9.9 |  |  | $ | 117.1 |  |  | $ | 61.8 |  |
| DISCONTINUED OPERATIONS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations |  |  | 0.2 |  |  |  | 2.9 |  |  |  | 1.1 |  |  |  | 13.1 |  |
| Income tax expense (benefit) |  |  | (0.1 | ) |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | (2.4 | ) |
| Loss from discontinued operations |  |  | 0.1 |  |  |  | 3.4 |  |  |  | 0.9 |  |  |  | 10.7 |  |
| Net income |  | $ | 27.7 |  |  | $ | 6.5 |  |  | $ | 116.2 |  |  | $ | 51.1 |  |
| EARNINGS PER SHARE — BASIC: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.52 |  |  | $ | 0.18 |  |  | $ | 2.14 |  |  | $ | 1.11 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.06 | ) |  |  | (0.01 | ) |  |  | (0.19 | ) |
| Net income |  | $ | 0.52 |  |  | $ | 0.12 |  |  | $ | 2.13 |  |  | $ | 0.92 |  |
| EARNINGS PER SHARE — DILUTED: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.51 |  |  | $ | 0.17 |  |  | $ | 2.10 |  |  | $ | 1.09 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.06 | ) |  |  | (0.02 | ) |  |  | (0.19 | ) |
| Net income |  | $ | 0.51 |  |  | $ | 0.11 |  |  | $ | 2.08 |  |  | $ | 0.90 |  |
| AVERAGE SHARES OUTSTANDING: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 53.5 |  |  |  | 56.1 |  |  |  | 54.6 |  |  |  | 55.6 |  |
| Diluted |  |  | 54.6 |  |  |  | 57.3 |  |  |  | 55.8 |  |  |  | 56.6 |  |
| CASH DIVIDENDS DECLARED PER SHARE |  | $ | 0.15 |  |  | $ | 0.14 |  |  | $ | 0.60 |  |  | $ | 0.56 |  |

[0000950123-11-008535:8k_2_02:79]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-008535:8k_2_02:80]
SEGMENT NET SALES AND PROFIT

[0000950123-11-008535:8k_2_02:81]
(Unaudited, in millions)

[0000950123-11-008535:8k_2_02:82]
|  |  | For the Three Months |  |  | For the Twelve Months |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 349.0 |  |  | $ | 320.7 |  |  | $ | 1,417.4 |  |  | $ | 1,293.5 |  |
| Commercial Heating & Cooling |  |  | 148.2 |  |  |  | 146.0 |  |  |  | 620.0 |  |  |  | 594.6 |  |
| Service Experts |  |  | 144.7 |  |  |  | 146.5 |  |  |  | 590.3 |  |  |  | 535.4 |  |
| Refrigeration |  |  | 139.1 |  |  |  | 143.3 |  |  |  | 550.9 |  |  |  | 512.7 |  |
| Eliminations (A) |  |  | (19.0 | ) |  |  | (23.0 | ) |  |  | (82.2 | ) |  |  | (88.7 | ) |
|  |  | $ | 762.0 |  |  | $ | 733.5 |  |  | $ | 3,096.4 |  |  | $ | 2,847.5 |  |
| Segment Profit (Loss) (B) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 33.6 |  |  | $ | 38.2 |  |  | $ | 132.3 |  |  | $ | 111.7 |  |
| Commercial Heating & Cooling |  |  | 13.1 |  |  |  | 10.9 |  |  |  | 69.3 |  |  |  | 49.3 |  |
| Service Experts |  |  | 5.1 |  |  |  | 7.1 |  |  |  | 19.3 |  |  |  | 16.6 |  |
| Refrigeration |  |  | 13.9 |  |  |  | 16.0 |  |  |  | 61.4 |  |  |  | 48.9 |  |
| Corporate and other |  |  | (17.3 | ) |  |  | (20.5 | ) |  |  | (65.5 | ) |  |  | (62.5 | ) |
| Eliminations (A) |  |  | 0.2 |  |  |  | 0.7 |  |  |  | 0.2 |  |  |  | 0.5 |  |
| Subtotal that includes segment profit and eliminations |  |  | 48.6 |  |  |  | 52.4 |  |  |  | 217.0 |  |  |  | 164.5 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | (0.2 | ) |  |  | 18.3 |  |  |  | (0.2 | ) |  |  | 18.3 |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (C) |  |  | 4.2 |  |  |  | (4.7 | ) |  |  | 11.2 |  |  |  | (10.9 | ) |
| Restructuring charges |  |  | 0.6 |  |  |  | 14.1 |  |  |  | 15.6 |  |  |  | 41.5 |  |
| Impairment of assets |  |  | — |  |  |  | 6.4 |  |  |  | — |  |  |  | 6.4 |  |
| Interest expense, net |  |  | 3.7 |  |  |  | 2.1 |  |  |  | 12.8 |  |  |  | 8.2 |  |
| Other expense, net |  |  | 0.9 |  |  |  | — |  |  |  | 1.0 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 39.4 |  |  | $ | 16.2 |  |  | $ | 176.6 |  |  | $ | 100.9 |  |

[0000950123-11-008535:8k_2_02:83]
| (A) |  | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |
| (B) |  | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |
|  |  | Excluding: |

[0000950123-11-008535:8k_2_02:84]
|  | • |  | Special product quality adjustment. |
|  | • |  | Items within Gains and/or losses and other expenses, net that are noted in (C). |
|  | • |  | Restructuring charges. |
|  | • |  | Goodwill and equity method investment impairments. |
|  | • |  | Interest expense, net. |
|  | • |  | Other expense, net. |

[0000950123-11-008535:8k_2_02:85]
| (C) |  | Items in Gains and/or losses and other expenses, net that are excluded from segment profit are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |

[0000950123-11-008535:8k_2_02:86]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-008535:8k_2_02:87]
CONSOLIDATED BALANCE SHEETS

[0000950123-11-008535:8k_2_02:88]
(In millions, except share and per share data)

[0000950123-11-008535:8k_2_02:89]
|  |  | As of December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 160.0 |  |  | $ | 124.3 |  |
| Restricted cash |  |  | 12.2 |  |  |  | — |  |
| Accounts and notes receivable, net of allowances of $12.8 and $15.6 in 2010 and 2009, respectively |  |  | 384.8 |  |  |  | 357.0 |  |
| Inventories, net |  |  | 286.2 |  |  |  | 250.2 |  |
| Deferred income taxes |  |  | 36.7 |  |  |  | 34.9 |  |
| Other assets |  |  | 67.0 |  |  |  | 67.5 |  |
| Total current assets |  |  | 946.9 |  |  |  | 833.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | 324.3 |  |  |  | 329.6 |  |
| GOODWILL |  |  | 271.8 |  |  |  | 257.4 |  |
| DEFERRED INCOME TAXES |  |  | 87.2 |  |  |  | 74.6 |  |
| OTHER ASSETS, net |  |  | 61.8 |  |  |  | 48.4 |  |
| TOTAL ASSETS |  | $ | 1,692.0 |  |  | $ | 1,543.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 1.4 |  |  | $ | 2.2 |  |
| Current maturities of long-term debt |  |  | 0.6 |  |  |  | 35.5 |  |
| Accounts payable |  |  | 273.8 |  |  |  | 238.2 |  |
| Accrued expenses |  |  | 334.5 |  |  |  | 317.9 |  |
| Income taxes payable |  |  | 5.3 |  |  |  | — |  |
| Total current liabilities |  |  | 615.6 |  |  |  | 593.8 |  |
| LONG-TERM DEBT |  |  | 317.0 |  |  |  | 193.8 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | 15.9 |  |  |  | 13.4 |  |
| PENSIONS |  |  | 88.1 |  |  |  | 66.7 |  |
| OTHER LIABILITIES |  |  | 65.7 |  |  |  | 71.8 |  |
| Total liabilities |  |  | 1,102.3 |  |  |  | 939.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 86,480,816 shares and 85,567,485 shares issued for 2010 and 2009, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 863.5 |  |  |  | 839.1 |  |
| Retained earnings |  |  | 642.2 |  |  |  | 558.6 |  |
| Accumulated other comprehensive income (loss) |  |  | 30.2 |  |  |  | (0.8 | ) |
| Treasury stock, at cost, 32,784,503 shares and 29,292,512 shares for 2010 and 2009, respectively |  |  | (947.1 | ) |  |  | (793.4 | ) |
| Total stockholders’ equity |  |  | 589.7 |  |  |  | 604.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,692.0 |  |  | $ | 1,543.9 |  |

[0000950123-11-008535:8k_2_02:90]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-008535:8k_2_02:91]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0000950123-11-008535:8k_2_02:92]
(Unaudited, in millions, except per share and ratio data)

[0000950123-11-008535:8k_2_02:93]
Reconciliation of Income From Continuing Operations to Adjusted Income From Continuing Operations

[0000950123-11-008535:8k_2_02:94]
|  |  | For The Three Months |  |  | For The Twelve Months |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |  |
| Income from continuing operations, a GAAP measure |  | $ | 27.8 |  |  | $ | 9.9 |  |  | $ | 117.1 |  |  | $ | 61.8 |  |
| Restructuring charges, after tax |  |  | (0.2 | ) |  |  | 10.9 |  |  |  | 10.0 |  |  |  | 30.0 |  |
| Special legal contingency charge, after-tax (a) |  |  | 0.3 |  |  |  | — |  |  |  | 4.2 |  |  |  | — |  |
| Net change in unrealized gains on open future contracts, after tax (a) |  |  | (0.4 | ) |  |  | (0.5 | ) |  |  | (0.4 | ) |  |  | (4.5 | ) |
| Acquisition expenses, after-tax (a) |  |  | 2.8 |  |  |  | — |  |  |  | 3.0 |  |  |  | — |  |
| Loss (gain) on sale of entity, after-tax (a) |  |  | 0.1 |  |  |  | (3.0 | ) |  |  | (0.1 | ) |  |  | (3.0 | ) |
| Impairment of assets, after-tax |  |  | — |  |  |  | 4.3 |  |  |  | — |  |  |  | 4.3 |  |
| Special product quality adjustment, after-tax (b) |  |  | — |  |  |  | 11.3 |  |  |  | — |  |  |  | 11.3 |  |
| Other items, net, after tax (a) |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | — |  |  |  | 0.4 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 30.2 |  |  | $ | 33.1 |  |  | $ | 133.8 |  |  | $ | 100.3 |  |
| Income per share from continuing operations — diluted, a GAAP measure |  | $ | 0.51 |  |  | $ | 0.17 |  |  | $ | 2.10 |  |  | $ | 1.09 |  |
| Restructuring charges |  |  | — |  |  |  | 0.19 |  |  |  | 0.18 |  |  |  | 0.53 |  |
| Special legal contingency charge (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.08 |  |  |  | — |  |
| Net change in unrealized gains on open future contracts (a) |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | (0.08 | ) |
| Acquisition expenses (a) |  |  | 0.05 |  |  |  | — |  |  |  | 0.05 |  |  |  | — |  |
| Loss (gain) on sale of entity (a) |  |  | — |  |  |  | (0.05 | ) |  |  | — |  |  |  | (0.05 | ) |
| Impairment of assets |  |  | — |  |  |  | 0.08 |  |  |  | — |  |  |  | 0.08 |  |
| Special product quality adjustment (b) |  |  | — |  |  |  | 0.20 |  |  |  | — |  |  |  | 0.20 |  |
| Other items, net (a) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Adjusted earnings per share from continuing operations — diluted, a non-GAAP measure |  | $ | 0.55 |  |  | $ | 0.58 |  |  | $ | 2.40 |  |  | $ | 1.77 |  |

[0000950123-11-008535:8k_2_02:95]
| (a) |  | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) |  | Recorded in Cost of Goods Sold in the Consolidated Statements of Operations |

[0000950123-11-008535:8k_2_02:96]
|  |  | For The Three Months |  |  | For The Twelve Months |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |  |
| Realized (gains) losses on settled future contracts (a) |  |  | (0.3 | ) |  |  | — |  |  |  | (1.5 | ) |  |  | 3.7 |  |
| Special legal contingency charge (c) |  |  | 0.5 |  |  |  | — |  |  |  | 6.8 |  |  |  | — |  |
| Foreign currency exchange (gain) loss (a) |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | 0.4 |  |  |  | 0.7 |  |
| Loss (gain) on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | 0.5 |  |  |  | 0.1 |  |  |  | (0.1 | ) |
| Discount fee on accounts sold (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.3 |  |
| Realized gain on marketable securities (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |
| Net change in unrealized gains on open futures contracts (c) |  |  | (0.6 | ) |  |  | (0.7 | ) |  |  | (0.6 | ) |  |  | (7.1 | ) |
| Acquisition expenses (c) |  |  | 4.4 |  |  |  | — |  |  |  | 4.8 |  |  |  | — |  |
| Loss (gain) on sale of entity (c) |  |  | 0.1 |  |  |  | (4.1 | ) |  |  | (0.1 | ) |  |  | (4.1 | ) |
| Other items, net (c) |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 3.9 |  |  | $ | (4.4 | ) |  | $ | 10.2 |  |  | $ | (6.6 | ) |

[0000950123-11-008535:8k_2_02:97]
| (a) |  | Included in segment profit and adjusted income from continuing operations |
| (b) |  | Included in adjusted income from continuing operations but excluded from segment profit |
| (c) |  | Excluded from segment profit and adjusted income from continuing operations |

[0000950123-11-008535:8k_2_02:98]
Reconciliation of Estimated Adjusted to GAAP Income per Share from Continuing Operations — Diluted

[0000950123-11-008535:8k_2_02:99]
|  |  | For the |
|  |  | Year Ended |
|  |  | December 31, |
|  |  | 2011 |
|  |  | ESTIMATED |
| Adjusted income per share from continuing operations — diluted |  | $2.80 – $3.10 |
| Restructuring charges |  | (0.05) |
| GAAP income per share from continuing operations — diluted |  | $2.75 – $3.05 |

[0000950123-11-008535:8k_2_02:100]
Free Cash Flow

[0000950123-11-008535:8k_2_02:101]
|  |  | For the Three Months |  |  | For the Twelve Months |  |
|  |  | Ended December 31, |  |  | Ended December 31, |  |
|  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |  |
| Net cash provided by operating activities |  | $ | 142.2 |  |  | $ | 12.2 |  |  | $ | 185.8 |  |  | $ | 225.5 |  |
| Purchase of property, plant and equipment |  |  | (15.8 | ) |  |  | (24.9 | ) |  |  | (45.8 | ) |  |  | (58.8 | ) |
| Free cash flow |  | $ | 126.4 |  |  | $ | (12.7 | ) |  | $ | 140.0 |  |  | $ | 166.7 |  |

[0000950123-11-008535:8k_2_02:102]
Operational Working Capital

[0000950123-11-008535:8k_2_02:103]
|  |  |  |  |  |  | December 31, |  |  |  |  |  |  | December 31, |  |
|  |  |  |  |  |  | 2010 |  |  |  |  |  |  | 2009 |  |
|  |  | December 31, |  |  | Trailing |  |  | December 31, |  |  | Trailing |  |
|  |  | 2010 |  |  | 12 Mo. Avg. |  |  | 2009 |  |  | 12 Mo. Avg. |  |
| Accounts and Notes Receivable, Net |  | $ | 384.8 |  |  |  |  |  |  | $ | 357.0 |  |  |  |  |  |
| Allowance for Doubtful Accounts |  |  | 12.8 |  |  |  |  |  |  |  | 15.6 |  |  |  |  |  |
| Accounts and Notes Receivable, Gross |  |  | 397.6 |  |  | $ | 408.4 |  |  |  | 372.6 |  |  | $ | 409.3 |  |
| Inventories |  |  | 286.2 |  |  |  |  |  |  |  | 250.2 |  |  |  |  |  |
| Excess of Current Cost Over Last-in, First-out |  |  | 70.8 |  |  |  |  |  |  |  | 71.7 |  |  |  |  |  |
| Inventories as Adjusted |  |  | 357.0 |  |  |  | 400.4 |  |  |  | 321.9 |  |  |  | 363.8 |  |
| Accounts Payable |  |  | (273.8 | ) |  |  | (281.5 | ) |  |  | (238.2 | ) |  |  | (254.0 | ) |
| Operating Working Capital (a) |  |  | 480.8 |  |  |  | 527.3 |  |  |  | 456.3 |  |  |  | 519.1 |  |
| Net Sales, Trailing Twelve Months (b) |  |  | 3,096.4 |  |  |  | 3,096.4 |  |  |  | 2,847.5 |  |  |  | 2,847.5 |  |
| Operational Working Capital Ratio (a / b) |  |  | 15.5 | % |  |  | 17.0 | % |  |  | 16.0 | % |  |  | 18.2 | % |

[0000950123-11-008535:8k_2_02:104]
| Note: |  | Management uses free cash flow and operational working capital, which are not defined by U.S. GAAP, to measure the Company’s operating performance. Free cash flow and operational working capital are also two of several measures used to determine incentive compensation for certain employees. |

[0000950123-11-008535:8k_2_02:105]
Debt to Earnings Before Interest, Taxes, Depreciation and Amortization Expense (“EBITDA”) Ratio

[0000950123-11-008535:8k_2_02:106]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | December 31, |  |
|  |  | 2010 |  |
| Earnings before interest and taxes (“EBIT”) (a) |  | $ | 217.0 |  |
| Depreciation and amortization expense (“DA”) (b) |  |  | 53.5 |  |
| EBITDA (EBIT excluding DA) (a + b) |  | $ | 270.5 |  |
| Total debt at December 31, 2010 (c) |  | $ | 319.0 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 1.2 |  |
| Reconciliation of EBIT to income from continuing operations before income taxes: |  |  |  |  |
| EBIT per above (non-GAAP) |  | $ | 217.0 |  |
| Special product quality adjustment |  |  | (0.2 | ) |
| Items in losses (gains) and other expenses, net that are excluded from segment profit |  |  | 11.2 |  |
| Restructuring charges |  |  | 15.6 |  |
| Other expenses, net |  |  | 1.0 |  |
| Interest expense, net |  |  | 12.8 |  |
| Income from continuing operations before income taxes (GAAP) |  | $ | 176.6 |  |
