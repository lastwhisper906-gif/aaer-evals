# LII note change history — 0001628280-22-010108 → 0001628280-22-019665


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001628280-22-019665:note_history:1]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Accrued expenses | $ | 39.5 |  |  | $ | 37.2 |  |
| Other liabilities | 109.4 |  |  | 97.0 |  |
| Total warranty liability | $ | 148.9 |  |  | $ | 134.2 |  |
  (was, 2022-04-25, similarity 0.9741):
[0001628280-22-010108:note_history:1]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Accrued expenses | $ | 38.5 |  |  | $ | 37.2 |  |
| Other liabilities | 104.7 |  |  | 97.0 |  |
| Total warranty liability | $ | 143.2 |  |  | $ | 134.2 |  |

- changed (2022-07-28):
[0001628280-22-019665:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2022 were as follows (in millions):
  (was, 2022-04-25, similarity 0.9404):
[0001628280-22-010108:note_history:2]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2022 were as follows (in millions):

- changed (2022-07-28):
[0001628280-22-019665:note_history:3]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Warranty claims paid | (16.5) |  |
| Changes resulting from issuance of new warranties | 27.6 |  |
| Changes in estimates associated with pre-existing liabilities | 4.3 |  |
| Changes in foreign currency translation rates and other | (0.7) |  |
| Total warranty liability as of June 30, 2022 | $ | 148.9 |  |
  (was, 2022-04-25, similarity 0.9869):
[0001628280-22-010108:note_history:3]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Warranty claims paid | (7.1) |  |
| Changes resulting from issuance of new warranties | 12.7 |  |
| Changes in estimates associated with pre-existing liabilities | 3.5 |  |
| Changes in foreign currency translation rates and other | (0.1) |  |
| Total warranty liability as of March 31, 2022 | $ | 143.2 |  |

- removed (2022-07-28):
[0001628280-22-010108:note_history:4]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):

- removed (2022-07-28):
[0001628280-22-010108:note_history:5]
|  | For the Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Loss for asbestos-related litigation, net | $ | 1.7 |  |  | $ | 1.1 |  |  |  |  |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001628280-22-019665:note_history:6]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2022, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and six months ended June 30, 2022 and 2021, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2022 and 2021 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2021.
  (was, 2022-04-25, similarity 0.8699):
[0001628280-22-010108:note_history:6]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2022, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2022 and 2021, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2022 and 2021, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2022 and 2021 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2021.

- added (2022-07-28):
[0001628280-22-019665:note_history:7]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations. As the pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows. 
Executive Leadership TransitionOn March 23, 2022, the Board of Directors appointed Alok Maskara as Chief Executive Officer ("CEO") effective May 9, 2022.  Mr. Maskara succeeded Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and served as interim CEO until Mr. Maskara assumed the role on May 9, 2022.

- removed (2022-07-28):
[0001628280-22-010108:note_history:8]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations.

- removed (2022-07-28):
[0001628280-22-010108:note_history:9]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus become more

- removed (2022-07-28):
[0001628280-22-010108:note_history:10]
dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

- removed (2022-07-28):
[0001628280-22-010108:note_history:11]
Executive Leadership Transition
On March 23, 2022, the Board of Directors appointed Alok Maskara as CEO effective May 9, 2022.  Mr. Maskara succeeds Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and will serve as interim CEO until Mr. Maskara assumes the role as CEO.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001628280-22-019665:note_history:12]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 2.53 | % |  | 1.38 | % |
  (was, 2022-04-25, similarity 0.9538):
[0001628280-22-010108:note_history:12]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 1.62 | % |  | 1.38 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001628280-22-019665:note_history:13]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 30.8 |  |  | 29.0 |  |
| Credit Agreement | 308.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.8) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,681.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,693.3 |  |  | $ | 1,237.8 |  |
  (was, 2022-04-25, similarity 0.9502):
[0001628280-22-010108:note_history:13]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 279.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 31.4 |  |  | 29.0 |  |
| Domestic credit facility | 347.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (8.4) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,599.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,611.3 |  |  | $ | 1,237.8 |  |

- changed (2022-07-28):
[0001628280-22-019665:note_history:14]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2022 or December 31, 2021 and there were no borrowings or repayments on these facilities during the six months ended June 30, 2022.
  (was, 2022-04-25, similarity 0.9049):
[0001628280-22-010108:note_history:14]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2022 or December 31, 2021 and there were no borrowings or repayments on these facilities during the three months ended March 31, 2022.

- changed (2022-07-28):
[0001628280-22-019665:note_history:15]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 400.0 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (400.0) |  |  | (250.0) |  |
| Remaining amount available | $ | — |  |  | $ | 85.6 |  |
  (was, 2022-04-25, similarity 0.9159):
[0001628280-22-010108:note_history:15]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 279.4 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (279.0) |  |  | (250.0) |  |
| Remaining amount available | $ | 0.4 |  |  | $ | 85.6 |  |

- changed (2022-07-28):
[0001628280-22-019665:note_history:16]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2022 and December 31, 2021 were 2.37% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2022-04-25, similarity 0.8492):
[0001628280-22-010108:note_history:16]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2022 and December 31, 2021 were 1.19% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging

- changed (2022-07-28):
[0001628280-22-019665:note_history:17]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of June 30, 2022, we believe we were in compliance with all covenant requirements.
  (was, 2022-04-25, similarity 0.6122):
[0001628280-22-010108:note_history:17]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of March 31, 2022, we believe we were in compliance with all covenant requirements.

- changed (2022-07-28):
[0001628280-22-019665:note_history:18]
In July 2021, we entered into a new domestic credit facility (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.
  (was, 2022-04-25, similarity 0.9203):
[0001628280-22-010108:note_history:18]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

- changed (2022-07-28):
[0001628280-22-019665:note_history:19]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $308.5 million as well as $2.0 million committed to standby letters of credit as of June 30, 2022. Subject to covenant limitations, $439.5 million was available for future borrowings.  The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.
  (was, 2022-04-25, similarity 0.6809):
[0001628280-22-010108:note_history:19]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $347.5 million as well as $2.0 million committed to standby letters of credit as of March 31, 2022. Subject to covenant limitations, $400.5 million was available for future borrowings.

- changed (2022-07-28):
[0001628280-22-019665:note_history:20]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 2.53 | % |  | 1.38 | % |
  (was, 2022-04-25, similarity 0.9538):
[0001628280-22-010108:note_history:20]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 1.62 | % |  | 1.38 | % |

- changed (2022-07-28):
[0001628280-22-019665:note_history:21]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitization (cross default), and bankruptcy. A cross default under our Credit Agreement could occur if:
  (was, 2022-04-25, similarity 0.9415):
[0001628280-22-010108:note_history:21]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our Domestic Credit Facility could occur if:

- changed (2022-07-28):
[0001628280-22-019665:note_history:22]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Credit Agreement, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.
  (was, 2022-04-25, similarity 0.9584):
[0001628280-22-010108:note_history:22]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

- changed (2022-07-28):
[0001628280-22-019665:note_history:23]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of June 30, 2022, we believe we were in compliance with all covenant requirements.
  (was, 2022-04-25, similarity 0.8482):
[0001628280-22-010108:note_history:23]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2022, we believe we were in compliance with all covenant requirements.

- changed (2022-07-28):
[0001628280-22-019665:note_history:24]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2022, we believe we were in compliance with all covenant requirements.
  (was, 2022-04-25, similarity 0.9965):
[0001628280-22-010108:note_history:24]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2022, we believe we were in compliance with all covenant requirements.

- removed (2022-07-28):
[0001628280-22-010108:note_history:25]
between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001628280-22-019665:note_history:26]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 30.8 |  |  | 29.0 |  |
| Credit Agreement | 308.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.8) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,681.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,693.3 |  |  | $ | 1,237.8 |  |
  (was, 2022-04-25, similarity 0.9502):
[0001628280-22-010108:note_history:26]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 279.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 31.4 |  |  | 29.0 |  |
| Domestic credit facility | 347.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (8.4) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,599.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,611.3 |  |  | $ | 1,237.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001628280-22-019665:note_history:27]
|  | For the Three Months Ended June 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 901.8 |  |  | $ | 207.2 |  |  | $ | 107.7 |  |  | $ | 1,216.7 |  |
| Canada | 75.7 |  |  | 12.4 |  |  | — |  |  | 88.1 |  |
| Other international | — |  |  | — |  |  | 61.5 |  |  | 61.5 |  |
| Total | $ | 977.5 |  |  | $ | 219.6 |  |  | $ | 169.2 |  |  | $ | 1,366.3 |  |
  (was, 2022-04-25, similarity 0.6271):
[0001628280-22-010108:note_history:27]
|  | For the Three Months Ended March 31, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 558.8 |  |  | $ | 182.3 |  |  | $ | 75.6 |  |  | $ | 816.7 |  |
| Canada | 47.5 |  |  | 16.9 |  |  | — |  |  | 64.4 |  |
| Other international | — |  |  | — |  |  | 49.4 |  |  | 49.4 |  |
| Total | $ | 606.3 |  |  | $ | 199.2 |  |  | $ | 125.0 |  |  | $ | 930.5 |  |

- changed (2022-07-28):
[0001628280-22-019665:note_history:28]
|  | For the Three Months Ended June 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 763.0 |  |  | $ | 228.7 |  |  | $ | 82.2 |  |  | $ | 1,073.9 |  |
| Canada | 75.0 |  |  | 23.9 |  |  | — |  |  | 98.9 |  |
| Other international | — |  |  | 0.2 |  |  | 66.0 |  |  | 66.2 |  |
| Total | $ | 838.0 |  |  | $ | 252.8 |  |  | $ | 148.2 |  |  | $ | 1,239.0 |  |
  (was, 2022-04-25, similarity 0.6271):
[0001628280-22-010108:note_history:28]
|  | For the Three Months Ended March 31, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 629.7 |  |  | $ | 176.8 |  |  | $ | 91.8 |  |  | $ | 898.3 |  |
| Canada | 52.5 |  |  | 10.4 |  |  | — |  |  | 62.9 |  |
| Other international | — |  |  | 0.5 |  |  | 51.7 |  |  | 52.2 |  |
| Total | $ | 682.2 |  |  | $ | 187.7 |  |  | $ | 143.5 |  |  | $ | 1,013.4 |  |

- added (2022-07-28):
[0001628280-22-019665:note_history:29]
|  | For the Six Months Ended June 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,531.4 |  |  | $ | 384.0 |  |  | $ | 199.6 |  |  | $ | 2,115.0 |  |
| Canada | 128.2 |  |  | 22.8 |  |  | — |  |  | 151.0 |  |
| Other international | — |  |  | 0.5 |  |  | 113.2 |  |  | 113.7 |  |
| Total | $ | 1,659.6 |  |  | $ | 407.3 |  |  | $ | 312.8 |  |  | $ | 2,379.7 |  |

- added (2022-07-28):
[0001628280-22-019665:note_history:30]
|  | For the Six Months Ended June 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,321.8 |  |  | $ | 411.0 |  |  | $ | 157.9 |  |  | $ | 1,890.7 |  |
| Canada | 122.4 |  |  | 40.8 |  |  | — |  |  | 163.2 |  |
| Other international | — |  |  | 0.2 |  |  | 115.3 |  |  | 115.5 |  |
| Total | $ | 1,444.2 |  |  | $ | 452.0 |  |  | $ | 273.2 |  |  | $ | 2,169.4 |  |

- changed (2022-07-28):
[0001628280-22-019665:note_history:31]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2022 and 2021, direct sales represented 70% and 76% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2022 and 2021, direct sales represented 69% and 72% of revenues, and sales to independent distributors represented the remainder.
  (was, 2022-04-25, similarity 0.8481):
[0001628280-22-010108:note_history:31]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2022 and 2021, direct sales represented 66% and 67% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2022-07-28):
[0001628280-22-019665:note_history:32]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.   Lennox National Account Services provides installation,
  (was, 2022-04-25, similarity 0.8871):
[0001628280-22-010108:note_history:32]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in

- added (2022-07-28):
[0001628280-22-019665:note_history:33]
service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended June 30, 2022 and 2021, equipment sales represented 81% and 85% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2022 and 2021, equipment sales represented 81% and 84% of revenues and the remainder of our revenue was generated from our service business.

- changed (2022-07-28):
[0001628280-22-019665:note_history:34]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems.   Less than 1% of segment revenue relates to services for start-up and commissioning activities.
  (was, 2022-04-25, similarity 0.8536):
[0001628280-22-010108:note_history:34]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Less than 1% of segment revenue relates to services for start-up and commissioning activities.

- added (2022-07-28):
[0001628280-22-019665:note_history:35]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Net contract liabilities consisted of the following:

- changed (2022-07-28):
[0001628280-22-019665:note_history:36]
|  | June 30, 2022 |  | December 31, 2021 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (11.6) |  |  | $ | (10.2) |  |  | $ | (1.4) |  |  | 13.9 | % |
| Contract liabilities - noncurrent | (5.8) |  |  | (5.5) |  |  | (0.3) |  |  | 6.0 | % |
| Total | $ | (17.4) |  |  | $ | (15.7) |  |  | $ | (1.7) |  |  |  |
  (was, 2022-04-25, similarity 0.9431):
[0001628280-22-010108:note_history:36]
|  | March 31, 2022 |  | December 31, 2021 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (14.0) |  |  | $ | (10.2) |  |  | $ | (3.8) |  |  | 36.9 | % |
| Contract liabilities - noncurrent | (5.4) |  |  | (5.5) |  |  | 0.1 |  |  | (1.2) | % |
| Total | $ | (19.4) |  |  | $ | (15.7) |  |  | $ | (3.7) |  |  |  |

- changed (2022-07-28):
[0001628280-22-019665:note_history:37]
For the three months ended June 30, 2022 and 2021, we recognized revenue of $2.1 million and $0.8 million and for the six months ended June 30, 2022 and 2021 we recognized revenue of $5.9 million and $2.4 million related to our contract liabilities at January 1, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2022 and 2021.
  (was, 2022-04-25, similarity 0.8301):
[0001628280-22-010108:note_history:37]
For the three months ended March 31, 2022 and 2021, we recognized revenue of $3.7 million and $1.6 million related to our contract liabilities at January 1, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2022 and 2021.

- removed (2022-07-28):
[0001628280-22-010108:note_history:38]
time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2022 and 2021, equipment sales represented 80% and 83% of revenues and the remainder of our revenue was generated from our service business.

- removed (2022-07-28):
[0001628280-22-010108:note_history:39]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

- removed (2022-07-28):
[0001628280-22-010108:note_history:40]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

- removed (2022-07-28):
[0001628280-22-010108:note_history:41]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets, net in our Consolidated Balance Sheets.

- removed (2022-07-28):
[0001628280-22-010108:note_history:42]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheets.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.

- removed (2022-07-28):
[0001628280-22-010108:note_history:43]
Net contract liabilities consisted of the following:
