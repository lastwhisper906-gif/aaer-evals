# LII 8-K — 0001193125-22-204168 filed 2022-07-28

## item codes, every 8-K on or before 2022-07-28

- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2022-07-28

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-204168:8k_2_02:1]
EX-99.1
2
d387591dex991.htm
EX-99.1

[0001193125-22-204168:8k_2_02:2]
EX-99.1

[0001193125-22-204168:8k_2_02:3]
Exhibit 99.1

[0001193125-22-204168:8k_2_02:4]
Lennox International Reports Record Revenue and Profit in Second Quarter

[0001193125-22-204168:8k_2_02:5]
|  | • |  | Revenue up 10% to record $1.37 billion |

[0001193125-22-204168:8k_2_02:6]
|  | • |  | GAAP EPS up 10% to record $4.96; Adjusted EPS up 9% to record $5.00 |

[0001193125-22-204168:8k_2_02:7]
|  | • |  | Repurchased $100 million of stock and paid $33 million in dividends |

[0001193125-22-204168:8k_2_02:8]
|  | • |  | Raising low end of 2022 EPS guidance from $13.50-$14.50 to $13.80-$14.50 |

[0001193125-22-204168:8k_2_02:9]
DALLAS, July 28, 2022 – Lennox International Inc. (NYSE: LII), a leader
in energy-efficient climate-control solutions, today reported financial results for the second quarter of 2022. All comparisons are to the prior-year period.

[0001193125-22-204168:8k_2_02:10]
Lennox International reported record revenue of $1.37 billion in the second quarter, up 10%. At constant currency, revenue was up 11%. GAAP operating
income was a record $227 million, up 5%. GAAP earnings per share was a record $4.96, up 10%.

[0001193125-22-204168:8k_2_02:11]
Total segment profit rose 4% to a record
$230 million. Total segment margin was 16.8%, down 110 basis points. Adjusted earnings per share rose 9% to a record $5.00.

[0001193125-22-204168:8k_2_02:12]
“Lennox
International posted new highs for revenue, profit and EPS, led by strong growth in our Residential and Refrigeration businesses as price continued to offset material inflation,” said CEO Alok Maskara. “In Commercial, we are encouraged by
the sequential improvement in quarterly margins even though our ability to satisfy strong demand remained constrained by supply chain shortfall and factory inefficiencies.”

[0001193125-22-204168:8k_2_02:13]
In Residential, revenue and profit set new highs. Residential revenue was up 17%, led by double-digit growth in both replacement and new construction sales.
Segment profit rose 14%. Segment margin was 22.1%, down 50 basis points. Refrigeration set new records for second-quarter revenue and profit. Refrigeration revenue was up 14% as reported and up 20% at constant currency, led by more than 30% growth
in North America. Refrigeration profit rose 73%, and segment margin expanded 470 basis points to 13.8%. Commercial revenue was down 13%, profit was down 62%, and segment margin contracted 1,010 basis points to 7.8%.

[0001193125-22-204168:8k_2_02:14]
Maskara added, “Looking ahead for the company overall, the macroeconomic environment is challenging, but customer demand remains strong. Residential and
Refrigeration businesses are performing well and capitalizing on growth opportunities while Commercial segment performance is improving. We are adjusting 2022 revenue growth guidance from 7-11% to 10-15%. We are also raising the low end of EPS guidance from $13.50-$14.50 to a range of $13.80-$14.50. And we reiterate plans for
$400 million of total stock repurchases for the full year.”

[0001193125-22-204168:8k_2_02:15]
FINANCIAL HIGHLIGHTS

[0001193125-22-204168:8k_2_02:16]
Revenue: Revenue was a record $1.37 billion, up 10%. Volume was flat, price was up and mix was down. Foreign exchange had a 1% negative impact on
revenue.

[0001193125-22-204168:8k_2_02:17]
Gross Profit: Gross profit was $397 million, up 4%. Gross margin was 29.1%, down 180 basis points, impacted by inflationary
pressures, factory inefficiencies and global supply chain disruptions.

[0001193125-22-204168:8k_2_02:18]
Net Income: On a GAAP basis, net income for the second quarter was
$177.2 million, or $4.96 per share, compared to $170.0 million, or $4.51 per share, in the prior-year quarter.

[0001193125-22-204168:8k_2_02:19]
Adjusted net income in the
second quarter was $178.4 million, or $5.00 per share, compared to $172.0 million, or $4.57 per share, in the prior-year quarter. Adjusted net income for the second quarter of 2022 excludes net
after-tax charges of $1.2 million.

[0001193125-22-204168:8k_2_02:20]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from
operations in the second quarter was $97 million compared to $192 million in the prior-year quarter as inventory returns back to normal seasonality post the Covid impact in recent years. Capital expenditures were approximately
$21 million in the second quarter, the same as in the prior-year quarter. Free cash flow was $76 million compared to $171 million in the second quarter a year ago. Total debt at the end of the second quarter was $1.69 billion.
Total cash, cash equivalents and short-term investments were $63 million at the end of the quarter. The company paid $33 million in dividends and repurchased $100 million of stock in the second quarter.

[0001193125-22-204168:8k_2_02:21]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-22-204168:8k_2_02:22]
Revenue in the Residential
Heating & Cooling business segment was a record $978 million, up 17%. Foreign exchange was neutral to revenue. Segment profit was a record $216 million, up 14%. Segment margin was 22.1%, down 50 basis points as favorable price was
partially offset by higher material costs.

[0001193125-22-204168:8k_2_02:23]
Revenue in the Commercial Heating & Cooling business segment was $220 million, down 13%. Foreign
exchange was neutral to revenue. Segment profit was $17 million, down 62%, and segment margin was 7.8%, down 1,010 basis points, impacted by lower volume and manufacturing inefficiencies.

[0001193125-22-204168:8k_2_02:24]
Revenue in the Refrigeration business segment was a record $169 million, up 14%. Foreign exchange had a 6% negative impact to revenue growth. Segment
profit rose 73% to a second-quarter record $23 million. Segment margin expanded 470 basis points to 13.8%, driven by favorable price and higher volume.

[0001193125-22-204168:8k_2_02:25]
FULL-YEAR GUIDANCE

[0001193125-22-204168:8k_2_02:26]
|  | • |  | Raising 2022 guidance for revenue growth from 7-11% to 10-15%. |

[0001193125-22-204168:8k_2_02:27]
|  | • |  | Raising the low end of 2022 guidance for GAAP and adjusted EPS from $13.50-$14.50 to $13.80-$14.50. |

[0001193125-22-204168:8k_2_02:28]
CONFERENCE CALL INFORMATION

[0001193125-22-204168:8k_2_02:29]
A conference call to discuss the company’s second-quarter results and outlook will be held this morning at 8:30 a.m. Central time. To listen, call the
conference call line at 877-226-8216 (U.S.) or 409-207-6983 (international) at least 10
minutes prior to the scheduled start time and use participant code 3408699. The conference call also will be webcast and supplemental presentation materials available on Lennox International’s web site at www.lennoxinternational.com. A replay
will be available from approximately 11:00 a.m. Central time on July 28 through August 11, 2022 by dialing 866-207-1041 (U.S.) or 402-970-0847 (international) and using access code 9000057. The call and supplemental presentation materials will be archived on the company’s website.

[0001193125-22-204168:8k_2_02:30]
ABOUT LENNOX INTERNATIONAL

[0001193125-22-204168:8k_2_02:31]
Lennox International Inc. is
a leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in
innovation with our air conditioning, heating, indoor air quality, and refrigeration systems. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol LII. Additional information on Lennox International is
available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-22-204168:8k_2_02:32]
FORWARD-LOOKING STATEMENTS

[0001193125-22-204168:8k_2_02:33]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-204168:8k_2_02:34]
Consolidated Statements of Operations

[0001193125-22-204168:8k_2_02:35]
(Unaudited)

[0001193125-22-204168:8k_2_02:36]
| (Amounts in millions, except per share data) |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net sales |  | $ | 1,366.3 |  |  | $ | 1,239.0 |  |  | $ | 2,379.7 |  |  | $ | 2,169.4 |  |
| Cost of goods sold |  |  | 969.2 |  |  |  | 855.8 |  |  |  | 1,714.4 |  |  |  | 1,529.7 |  |
| Gross profit |  |  | 397.1 |  |  |  | 383.2 |  |  |  | 665.3 |  |  |  | 639.7 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 169.6 |  |  |  | 167.8 |  |  |  | 324.9 |  |  |  | 313.2 |  |
| Losses (gains) and other expenses, net |  |  | 1.6 |  |  |  | 2.3 |  |  |  | 2.0 |  |  |  | 2.6 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 1.3 |  |
| Income from equity method investments |  |  | (1.5 | ) |  |  | (4.1 | ) |  |  | (1.4 | ) |  |  | (7.4 | ) |
| Operating income |  |  | 226.9 |  |  |  | 216.0 |  |  |  | 338.8 |  |  |  | 330.0 |  |
| Pension settlements |  |  | 0.2 |  |  |  | — |  |  |  | 0.3 |  |  |  | 0.7 |  |
| Interest expense, net |  |  | 8.7 |  |  |  | 6.4 |  |  |  | 15.6 |  |  |  | 12.3 |  |
| Other expense (income), net |  |  | 0.7 |  |  |  | 0.9 |  |  |  | 1.2 |  |  |  | 1.9 |  |
| Net income before income taxes |  |  | 217.3 |  |  |  | 208.7 |  |  |  | 321.7 |  |  |  | 315.1 |  |
| Provision for income taxes |  |  | 40.1 |  |  |  | 38.7 |  |  |  | 60.9 |  |  |  | 60.9 |  |
| Net income |  | $ | 177.2 |  |  | $ | 170.0 |  |  | $ | 260.8 |  |  | $ | 254.2 |  |
| Earnings per share – Basic: |  | $ | 4.97 |  |  | $ | 4.55 |  |  | $ | 7.25 |  |  | $ | 6.74 |  |
| Earnings per share – Diluted: |  | $ | 4.96 |  |  | $ | 4.51 |  |  | $ | 7.23 |  |  | $ | 6.70 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 35.6 |  |  |  | 37.4 |  |  |  | 36.0 |  |  |  | 37.7 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 35.7 |  |  |  | 37.7 |  |  |  | 36.1 |  |  |  | 38.0 |  |

[0001193125-22-204168:8k_2_02:37]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-204168:8k_2_02:38]
Segment Net Sales and Profit (Loss)

[0001193125-22-204168:8k_2_02:39]
(Unaudited)

[0001193125-22-204168:8k_2_02:40]
| (Amounts in millions) |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 977.5 |  |  | $ | 838.0 |  |  | $ | 1,659.6 |  |  | $ | 1,444.2 |  |
| Commercial Heating & Cooling |  |  | 219.6 |  |  |  | 252.8 |  |  |  | 407.3 |  |  |  | 452.0 |  |
| Refrigeration |  |  | 169.2 |  |  |  | 148.2 |  |  |  | 312.8 |  |  |  | 273.2 |  |
|  |  | $ | 1,366.3 |  |  | $ | 1,239.0 |  |  | $ | 2,379.7 |  |  | $ | 2,169.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 216.3 |  |  | $ | 189.7 |  |  | $ | 324.0 |  |  | $ | 286.1 |  |
| Commercial Heating & Cooling |  |  | 17.2 |  |  |  | 45.3 |  |  |  | 23.5 |  |  |  | 72.6 |  |
| Refrigeration |  |  | 23.4 |  |  |  | 13.5 |  |  |  | 37.5 |  |  |  | 21.4 |  |
| Corporate and other |  |  | (27.1 | ) |  |  | (26.9 | ) |  |  | (40.6 | ) |  |  | (42.9 | ) |
| Total segment profit |  |  | 229.8 |  |  |  | 221.6 |  |  |  | 344.4 |  |  |  | 337.2 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) |  |  | 2.4 |  |  |  | 4.4 |  |  |  | 4.6 |  |  |  | 5.9 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 1.3 |  |
| Operating income |  | $ | 226.9 |  |  | $ | 216.0 |  |  | $ | 338.8 |  |  | $ | 330.0 |  |

[0001193125-22-204168:8k_2_02:41]
| (1) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-22-204168:8k_2_02:42]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-22-204168:8k_2_02:43]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-22-204168:8k_2_02:44]
|  | • |  | Environmental liabilities and special litigation charges, |

[0001193125-22-204168:8k_2_02:45]
|  | • |  | Charges incurred related to COVID-19 pandemic; |

[0001193125-22-204168:8k_2_02:46]
|  | • |  | Other items, net, |

[0001193125-22-204168:8k_2_02:47]
|  | • |  | Special product quality adjustments; and |

[0001193125-22-204168:8k_2_02:48]
|  | • |  | Restructuring charges. |

[0001193125-22-204168:8k_2_02:49]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-204168:8k_2_02:50]
Consolidated Balance Sheets

[0001193125-22-204168:8k_2_02:51]
| (Amounts in millions, except shares and par values) |  | As of June 30, 2022 |  |  | As of December 31, 2021 |  |
|  |  | (Unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 57.4 |  |  | $ | 31.0 |  |
| Short-term investments |  |  | 5.3 |  |  |  | 5.5 |  |
| Accounts and notes receivable, net of allowances of $12.2 and $10.7 in 2022 and 2021, respectively |  |  | 782.6 |  |  |  | 508.3 |  |
| Inventories, net |  |  | 692.8 |  |  |  | 510.9 |  |
| Other assets |  |  | 91.0 |  |  |  | 119.7 |  |
| Total current assets |  |  | 1,629.1 |  |  |  | 1,175.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $906.6 and $888.8 in 2022 and 2021, respectively |  |  | 519.5 |  |  |  | 515.1 |  |
| Right-of-use assets from operating leases |  |  | 204.7 |  |  |  | 196.1 |  |
| Goodwill |  |  | 186.2 |  |  |  | 186.6 |  |
| Deferred income taxes |  |  | 29.0 |  |  |  | 11.3 |  |
| Other assets, net |  |  | 90.5 |  |  |  | 87.4 |  |
| Total assets |  | $ | 2,659.0 |  |  | $ | 2,171.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 11.8 |  |  | $ | 11.3 |  |
| Current operating lease liabilities |  |  | 59.5 |  |  |  | 54.8 |  |
| Accounts payable |  |  | 485.6 |  |  |  | 402.1 |  |
| Accrued expenses |  |  | 384.8 |  |  |  | 358.9 |  |
| Income taxes payable |  |  | 26.0 |  |  |  | — |  |
| Total current liabilities |  |  | 967.7 |  |  |  | 827.1 |  |
| Long-term debt |  |  | 1,681.5 |  |  |  | 1,226.5 |  |
| Long-term operating lease liabilities |  |  | 149.7 |  |  |  | 145.0 |  |
| Pensions |  |  | 85.6 |  |  |  | 83.3 |  |
| Other liabilities |  |  | 175.8 |  |  |  | 159.0 |  |
| Total liabilities |  |  | 3,060.3 |  |  |  | 2,440.9 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ deficit: |  |  |  |  |  |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,144.0 |  |  |  | 1,133.7 |  |
| Retained earnings |  |  | 2,909.5 |  |  |  | 2,719.3 |  |
| Accumulated other comprehensive loss |  |  | (117.9 | ) |  |  | (88.1 | ) |
| Treasury stock, at cost, 51,743,384 shares and 50,536,125 shares for 2022 and 2021, respectively |  |  | (4,337.8 | ) |  |  | (4,034.8 | ) |
| Total stockholders’ deficit |  |  | (401.3 | ) |  |  | (269.0 | ) |
| Total liabilities and stockholders’ deficit |  | $ | 2,659.0 |  |  | $ | 2,171.9 |  |

[0001193125-22-204168:8k_2_02:52]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-204168:8k_2_02:53]
Consolidated Statements of Cash Flows

[0001193125-22-204168:8k_2_02:54]
(Unaudited)

[0001193125-22-204168:8k_2_02:55]
| (Amounts in millions) |  | For the Six MonthsEnded June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 260.8 |  |  | $ | 254.2 |  |
| Adjustments to reconcile net income to net cash (used in) provided by operating activities |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (1.4 | ) |  |  | (7.4 | ) |
| Dividends from affiliates |  |  | — |  |  |  | 3.7 |  |
| Restructuring charges, net of cash paid |  |  | 0.5 |  |  |  | 1.4 |  |
| Provision for credit losses |  |  | 2.7 |  |  |  | 3.5 |  |
| Unrealized losses, net on derivative contracts |  |  | 2.0 |  |  |  | 0.3 |  |
| Stock-based compensation expense |  |  | 10.6 |  |  |  | 17.5 |  |
| Depreciation and amortization |  |  | 37.8 |  |  |  | 35.6 |  |
| Deferred income taxes |  |  | (11.6 | ) |  |  | (3.6 | ) |
| Pension expense |  |  | 3.5 |  |  |  | 5.4 |  |
| Pension contributions |  |  | (0.5 | ) |  |  | (0.8 | ) |
| Other items, net |  |  | (0.9 | ) |  |  | (0.3 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (281.6 | ) |  |  | (248.2 | ) |
| Inventories |  |  | (187.3 | ) |  |  | 7.0 |  |
| Other current assets |  |  | 1.2 |  |  |  | (9.7 | ) |
| Accounts payable |  |  | 93.7 |  |  |  | 67.4 |  |
| Accrued expenses |  |  | 14.8 |  |  |  | 33.7 |  |
| Income taxes payable and receivable, net |  |  | 39.4 |  |  |  | 1.6 |  |
| Leases, net |  |  | 0.9 |  |  |  | (0.6 | ) |
| Other, net |  |  | 14.6 |  |  |  | 13.8 |  |
| Net cash (used in) provided by operating activities |  |  | (0.8 | ) |  |  | 174.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.5 |  |  |  | 0.6 |  |
| Purchases of property, plant and equipment |  |  | (46.7 | ) |  |  | (45.5 | ) |
| Proceeds from short-term investments, net |  |  | — |  |  |  | 2.3 |  |
| Net cash used in investing activities |  |  | (46.2 | ) |  |  | (42.6 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Asset securitization borrowings |  |  | 211.0 |  |  |  | 299.0 |  |
| Asset securitization payments |  |  | (61.0 | ) |  |  | (44.0 | ) |
| Long-term debt payments |  |  | (6.4 | ) |  |  | (3.1 | ) |
| Borrowings from credit facility |  |  | 1,331.0 |  |  |  | 753.0 |  |
| Payments on credit facility |  |  | (1,029.0 | ) |  |  | (748.5 | ) |
| Proceeds from employee stock purchases |  |  | 1.8 |  |  |  | 1.6 |  |
| Repurchases of common stock |  |  | (300.0 | ) |  |  | (400.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (5.1 | ) |  |  | (10.2 | ) |
| Cash dividends paid |  |  | (66.9 | ) |  |  | (58.6 | ) |
| Net cash provided by (used in) financing activities |  |  | 75.4 |  |  |  | (210.8 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 28.4 |  |  |  | (78.9 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (2.0 | ) |  |  | (0.5 | ) |
| Cash and cash equivalents, beginning of period |  |  | 31.0 |  |  |  | 123.9 |  |
| Cash and cash equivalents, end of period |  | $ | 57.4 |  |  | $ | 44.5 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 14.2 |  |  | $ | 11.8 |  |
| Income taxes paid (net of refunds) |  | $ | 32.9 |  |  | $ | 62.6 |  |

[0001193125-22-204168:8k_2_02:56]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-204168:8k_2_02:57]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-22-204168:8k_2_02:58]
(Unaudited, in millions, except per share and ratio data)

[0001193125-22-204168:8k_2_02:59]
Use of Non-GAAP Financial Measures

[0001193125-22-204168:8k_2_02:60]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance.

[0001193125-22-204168:8k_2_02:61]
Reconciliation of Net Income, a GAAP measure, to Adjusted Net Income, a Non-GAAP measure

[0001193125-22-204168:8k_2_02:62]
|  |  | For the Three Months Ended June 30, |  |
|  |  | (Unaudited) |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | Pre-Tax |  |  | TaxImpact (d) |  |  | AfterTax |  |  | Pre-Tax |  |  | TaxImpact (d) |  |  | AfterTax |  |
| Net income, a GAAP measure |  | $ | 217.3 |  |  | $ | (40.1 | ) |  | $ | 177.2 |  |  | $ | 208.7 |  |  | $ | (38.7 | ) |  | $ | 170.0 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 0.4 |  |  |  | 1.2 |  |  |  | (0.2 | ) |  |  | 1.0 |  |
| Pension settlements |  |  | 0.2 |  |  |  | (0.1 | ) |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  | 2.4 |  |  |  | (0.4 | ) |  |  | 2.0 |  |  |  | 4.4 |  |  |  | (1.0 | ) |  |  | 3.4 |  |
| Excess tax expense (benefits) from share-based compensation (b) |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | — |  |  |  | (2.5 | ) |  |  | (2.5 | ) |
| Other tax items, net (b) |  |  | — |  |  |  | (1.4 | ) |  |  | (1.4 | ) |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Adjusted net income, a non-GAAP measure |  | $ | 220.4 |  |  | $ | (42.0 | ) |  | $ | 178.4 |  |  | $ | 214.3 |  |  | $ | (42.3 | ) |  | $ | 172.0 |  |
| Earnings per share - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 4.96 |  |  |  |  |  |  |  |  |  |  | $ | 4.51 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  |  |  |  |  |  |  |  |  | 0.06 |  |  |  |  |  |  |  |  |  |  |  | 0.09 |  |
| Excess tax expense (benefits) from share-based compensation (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.07 | ) |
| Other tax items, net (b) |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Change in share counts from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Adjusted earnings per share - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 5.00 |  |  |  |  |  |  |  |  |  |  | $ | 4.57 |  |

[0001193125-22-204168:8k_2_02:63]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-22-204168:8k_2_02:64]
| (b) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-22-204168:8k_2_02:65]
| (c) | The impact of excess tax expense (benefits) from the change in share-based compensation also impacts the Company’s diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount. |

[0001193125-22-204168:8k_2_02:66]
| (d) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-22-204168:8k_2_02:67]
|  |  | For the Six Months Ended June 30, |  |
|  |  | (Unaudited) |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | Pre-Tax |  |  | TaxImpact (d) |  |  | AfterTax |  |  | Pre-Tax |  |  | TaxImpact (d) |  |  | After Tax |  |
| Net income, a GAAP measure |  | $ | 321.7 |  |  | $ | (60.9 | ) |  | $ | 260.8 |  |  | $ | 315.1 |  |  | $ | (60.9 | ) |  | $ | 254.2 |  |
| Restructuring charges |  |  | 1.0 |  |  |  | (0.2 | ) |  |  | 0.8 |  |  |  | 1.3 |  |  |  | (0.3 | ) |  |  | 1.0 |  |
| Pension settlements |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |  |  | 0.7 |  |  |  | (0.1 | ) |  |  | 0.6 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  | 4.6 |  |  |  | (0.9 | ) |  |  | 3.7 |  |  |  | 5.9 |  |  |  | (1.1 | ) |  |  | 4.8 |  |
| Excess tax expense (benefits) from share-based compensation (b) |  |  | — |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  |  |  |  |  | (3.8 | ) |  |  | (3.8 | ) |
| Other tax items, net (b) |  |  | — |  |  |  | (1.4 | ) |  |  | (1.4 | ) |  |  | — |  |  |  | 2.1 |  |  |  | 2.1 |  |
| Adjusted net income, a non-GAAP measure |  | $ | 327.6 |  |  | $ | (63.0 | ) |  | $ | 264.6 |  |  | $ | 323.0 |  |  | $ | (64.1 | ) |  | $ | 258.9 |  |
| Earnings per share from net income - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 7.23 |  |  |  |  |  |  |  |  |  |  | $ | 6.70 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  |  |  |  |  |  |  |  |  | 0.10 |  |  |  |  |  |  |  |  |  |  |  | 0.13 |  |
| Excess tax expense (benefits) from share-based compensation (b) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | (0.10 | ) |
| Other tax items, net (b) |  |  |  |  |  |  |  |  |  |  | (0.04 | ) |  |  |  |  |  |  |  |  |  |  | 0.05 |  |
| Change in share counts from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from net income - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 7.33 |  |  |  |  |  |  |  |  |  |  | $ | 6.83 |  |

[0001193125-22-204168:8k_2_02:68]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-22-204168:8k_2_02:69]
| (b) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-22-204168:8k_2_02:70]
| (c) | The impact of excess tax expense (benefits) from the change in share-based compensation also impacts the Company’s diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount. |

[0001193125-22-204168:8k_2_02:71]
| (d) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-22-204168:8k_2_02:72]
|  |  | For the ThreeMonthsEnded June 30, |  |  | For the SixMonthsEnded June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
|  |  | (Unaudited) |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized gains on settled future contracts (a) |  | $ | (0.1 | ) |  | $ | (0.4 | ) |  | $ | (0.4 | ) |  | $ | (0.6 | ) |
| Foreign currency exchange gains (a) |  |  | (0.5 | ) |  |  | (1.3 | ) |  |  | (0.8 | ) |  |  | (1.6 | ) |
| Gain on disposal of fixed assets (a) |  |  | — |  |  |  | (0.2 | ) |  |  | (0.9 | ) |  |  | (0.5 | ) |
| Other operating income (a) |  |  | (0.2 | ) |  |  | (0.2 | ) |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | 1.9 |  |  |  | 0.1 |  |  |  | 1.2 |  |  |  | (0.2 | ) |
| Environmental liabilities and special litigation charges (b) |  |  | 1.0 |  |  |  | 3.2 |  |  |  | 3.1 |  |  |  | 5.2 |  |
| Charges incurred related to COVID-19 pandemic (b) |  |  | 0.2 |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | 1.1 |  |
| Other items, net (b) |  |  | (0.7 | ) |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 1.6 |  |  | $ | 2.3 |  |  | $ | 2.0 |  |  | $ | 2.6 |  |

[0001193125-22-204168:8k_2_02:73]
| (a) | Included in both segment profit (loss) and Adjusted net income |

[0001193125-22-204168:8k_2_02:74]
| (b) | Excluded from both segment profit (loss) and Adjusted net income |

[0001193125-22-204168:8k_2_02:75]
Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares
Outstanding - Diluted, a Non-GAAP measure (shares in millions):

[0001193125-22-204168:8k_2_02:76]
|  |  | For the ThreeMonthsEnded June 30, |  |  | For the SixMonthsEnded June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Average shares outstanding - diluted, a GAAP measure |  |  | 35.7 |  |  |  | 37.7 |  |  |  | 36.1 |  |  |  | 38.0 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure |  |  | 35.7 |  |  |  | 37.6 |  |  |  | 36.1 |  |  |  | 37.9 |  |

[0001193125-22-204168:8k_2_02:77]
Reconciliation of Net Cash Provided By (Used In) Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-22-204168:8k_2_02:78]
|  |  | For the ThreeMonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net cash provided by (used in) operating activities |  | $ | 97.1 |  |  | $ | 192.0 |  |  | $ | (0.8 | ) |  | $ | 174.5 |  |
| Purchases of property, plant and equipment |  |  | (20.9 | ) |  |  | (20.8 | ) |  |  | (46.7 | ) |  |  | (45.5 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.5 |  |  |  | 0.6 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 76.4 |  |  | $ | 171.4 |  |  | $ | (47.0 | ) |  | $ | 129.6 |  |

[0001193125-22-204168:8k_2_02:79]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | Trailing TwelveMonths toJune 30, 2022 |  |
| Adjusted EBIT (a) |  | $ | 610.8 |  |
| Depreciation and amortization expense (b) |  |  | 72.3 |  |
| EBITDA (a + b) |  | $ | 683.1 |  |
| Total debt at June 30, 2022 (c) |  | $ | 1,693.3 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.5 |  |

[0001193125-22-204168:8k_2_02:80]
Reconciliation of Net Income Before Income Taxes, a GAAP measure to Adjusted EBIT, a
Non-GAAP measure

[0001193125-22-204168:8k_2_02:81]
|  |  | Trailing TwelveMonths toJune 30, 2022 |  |
| Net income before income taxes, a GAAP measure |  |  | 566.6 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit |  |  | 12.9 |  |
| Special product quality adjustments |  |  | (2.5 | ) |
| Restructuring charges |  |  | 1.5 |  |
| Interest expense, net |  |  | 28.3 |  |
| Pension settlements |  |  | 0.7 |  |
| Other expense (income), net |  |  | 3.3 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  | 610.8 |  |
