# LII MD&A — 0001628280-22-019665


## mdna

[0001628280-22-019665:mdna:1]
[same as prior period, unchanged from 0001628280-22-010108:mdna:1]

[0001628280-22-019665:mdna:2]
[same as prior period, unchanged from 0001628280-22-010108:mdna:2]

[0001628280-22-019665:mdna:3]
[same as prior period, unchanged from 0001628280-22-010108:mdna:3]

[0001628280-22-019665:mdna:4]
[same as prior period, unchanged from 0001628280-22-010108:mdna:4]

[0001628280-22-019665:mdna:5]
[same as prior period, unchanged from 0001628280-22-010108:mdna:5]

[0001628280-22-019665:mdna:6]
[same as prior period, unchanged from 0001628280-22-010108:mdna:6]

[0001628280-22-019665:mdna:7]
[same as prior period, unchanged from 0001628280-22-010108:mdna:7]

[0001628280-22-019665:mdna:8]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations. As the pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows.

[0001628280-22-019665:mdna:9]
[same as prior period, unchanged from 0001628280-22-010108:mdna:11]

[0001628280-22-019665:mdna:10]
On March 23, 2022, the Board of Directors appointed Alok Maskara as CEO effective May 9, 2022.  Mr. Maskara succeeds Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and served as interim CEO until Mr. Maskara assumed the role as CEO on May 9, 2022.

[0001628280-22-019665:mdna:11]
[same as prior period, unchanged from 0001628280-22-010108:mdna:13]

[0001628280-22-019665:mdna:12]
Results for the second quarter of 2022 were driven by overall year-over-year sales and profit increases.  Net sales increased 17% and segment profit increased $27 million for the Residential Heating & Cooling segment. Net sales decreased 13% and segment profit decreased $28 million for the Commercial Heating & Cooling segment. Net sales increased 14% and segment profit increased $10 million for the Refrigeration segment.

[0001628280-22-019665:mdna:13]
[same as prior period, unchanged from 0001628280-22-010108:mdna:15]

[0001628280-22-019665:mdna:14]
•Net sales increased $127 million to $1,366 million in the second quarter of 2022 driven by favorable price partially offset by unfavorable foreign currency.

[0001628280-22-019665:mdna:15]
•Operating income in the second quarter of 2022 increased $11 million to $227 million primarily driven by higher net sales partially offset by rising costs.

[0001628280-22-019665:mdna:16]
•Net income for the second quarter of 2022 was $177 million.

[0001628280-22-019665:mdna:17]
•Diluted earnings per share was $4.96 per share in the second quarter of 2022 compared to $4.51 per share in the second quarter of 2021.

[0001628280-22-019665:mdna:18]
•For the six months ended June 30, 2022, we returned $67 million to shareholders through dividend payments and repurchased $300 million of common stock through our share repurchase program.

[0001628280-22-019665:mdna:19]
Three Months Ended June 30, 2022 Compared to Three Months Ended June 30, 2021 - Consolidated Results

[0001628280-22-019665:mdna:20]
[same as prior period, unchanged from 0001628280-22-010108:mdna:22]

[0001628280-22-019665:mdna:21]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | $ | 1,366.3 |  |  | $ | 1,239.0 |  |  | 10.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 969.2 |  |  | 855.8 |  |  | (13.3) |  |  | 70.9 |  |  | 69.1 |  |
| Gross profit | 397.1 |  |  | 383.2 |  |  | 3.6 |  |  | 29.1 |  |  | 30.9 |  |
| Selling, general and administrative expenses | 169.6 |  |  | 167.8 |  |  | (1.1) |  |  | 12.4 |  |  | 13.5 |  |
| Losses (gains) and other expenses, net | 1.6 |  |  | 2.3 |  |  | 30.4 |  |  | 0.1 |  |  | 0.2 |  |
| Restructuring charges | 0.5 |  |  | 1.2 |  |  | 58.3 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (1.5) |  |  | (4.1) |  |  | (63.4) |  |  | (0.1) |  |  | (0.3) |  |
| Operating income | $ | 226.9 |  |  | $ | 216.0 |  |  | 5.0 | % |  | 16.6 | % |  | 17.4 | % |

[0001628280-22-019665:mdna:22]
[same as prior period, unchanged from 0001628280-22-010108:mdna:24]

[0001628280-22-019665:mdna:23]
Net sales for the second quarter of 2022 compared to the second quarter of 2021 were impacted by favorable price of 11% which was partially offset by unfavorable foreign currency of 1%.  Sales volume and product mix were neutral for the quarter.

[0001628280-22-019665:mdna:24]
[same as prior period, unchanged from 0001628280-22-010108:mdna:26]

[0001628280-22-019665:mdna:25]
Gross profit margins in the second quarter of 2022 decreased 180 basis points ("bps") to 29.1% compared to 30.9% in the second quarter of 2021. Gross margins decreased 250 bps from higher commodity costs, 200 bps from other product costs, 150 bps from higher component costs, 130 bps from unfavorable product mix, 100 bps from higher freight and distribution costs, and 80 bps from factory inefficiencies.  Partially offsetting these decreases were 710 bps from favorable price and 20 bps from lower product warranty costs.

[0001628280-22-019665:mdna:26]
[same as prior period, unchanged from 0001628280-22-010108:mdna:29]

[0001628280-22-019665:mdna:27]
Selling, general and administrative expenses ("SG&A") increased $2 million to $170 million in the second quarter of 2022 compared to $168 million in the second quarter of 2021 due to higher employee costs. As a percentage of net sales, SG&A decreased 110 bps to 12.4%.

[0001628280-22-019665:mdna:28]
[same as prior period, unchanged from 0001628280-22-010108:mdna:31]

[0001628280-22-019665:mdna:29]
Losses (gains) and other expenses, net for the second quarter of 2022 and 2021 included the following (in millions):

[0001628280-22-019665:mdna:30]
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |  |  |
| Realized gains on settled future contracts | $ | (0.1) |  |  | $ | (0.4) |  |  |  |  |  |  |  |
| Foreign currency exchange gains | (0.5) |  |  | (1.3) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | — |  |  | (0.2) |  |  |  |  |  |  |  |
| Other operating income | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |
| Net change in unrealized losses on unsettled futures contracts | 1.9 |  |  | 0.1 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 1.0 |  |  | 3.2 |  |  |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic | 0.2 |  |  | 0.5 |  |  |  |  |  |  |  |
| Other items, net | (0.7) |  |  | 0.6 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 1.6 |  |  | $ | 2.3 |  |  |  |  |  |  |  |

[0001628280-22-019665:mdna:31]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001628280-22-019665:mdna:32]
[same as prior period, unchanged from 0001628280-22-010108:mdna:35]

[0001628280-22-019665:mdna:33]
Restructuring charges were immaterial in the second quarter of 2022 and 2021.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-22-019665:mdna:34]
Income from Equity Method Investments

[0001628280-22-019665:mdna:35]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  We recognized income from equity method investments of $1 million in the second quarter of 2022 and $4 million in the second quarter of 2021.  The change was due to rising costs at our equity method investments.

[0001628280-22-019665:mdna:36]
[same as prior period, unchanged from 0001628280-22-010108:mdna:39]

[0001628280-22-019665:mdna:37]
Interest expense, net increased to $9 million in the second quarter of 2022 from $6 million in the second quarter of 2021 due to higher borrowings and higher borrowing costs during the period.

[0001628280-22-019665:mdna:38]
[same as prior period, unchanged from 0001628280-22-010108:mdna:41]

[0001628280-22-019665:mdna:39]
Our effective tax rate was 18.4% for the second quarter of 2022 compared to 18.6% for the second quarter of 2021.  The rate decreased primarily due to a favorable mix of income in lower tax jurisdictions.   We expect our annual effective tax rate in 2022 to be 18-20%.

[0001628280-22-019665:mdna:40]
Second Quarter of 2022 Compared to Second Quarter of 2021 - Results by Segment

[0001628280-22-019665:mdna:41]
[same as prior period, unchanged from 0001628280-22-010108:mdna:45]

[0001628280-22-019665:mdna:42]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the second quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-019665:mdna:43]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 977.5 |  |  | $ | 838.0 |  |  | $ | 139.5 |  |  | 16.6 | % |
| Profit | $ | 216.3 |  |  | $ | 189.7 |  |  | $ | 26.6 |  |  | 14.0 | % |
| % of net sales | 22.1 | % |  | 22.6 | % |  |  |  |  |

[0001628280-22-019665:mdna:44]
Net sales increased 17% in the second quarter of 2022 compared to 2021, as price increased 13% and sales volume increased by 5%. Partially offsetting these increases was 1% from unfavorable mix.

[0001628280-22-019665:mdna:45]
Segment profit in the second quarter of 2022 compared to 2021 increased by $27 million, driven by $111 million from higher price, $15 million from higher sales volume, $4 million from lower SG&A, and $2 million from lower product warranty costs.  Partially offsetting these increases were $27 million from higher commodity costs, $22 million from unfavorable product mix, $18 million from higher other product costs, $16 million from higher component costs, $10 million from higher distribution and freight charges, $5 million from unfavorable foreign currency, $4 million from unfavorable factory productivity, and $3 million from lower earnings from our equity method investments.

[0001628280-22-019665:mdna:46]
[same as prior period, unchanged from 0001628280-22-010108:mdna:50]

[0001628280-22-019665:mdna:47]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-019665:mdna:48]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 219.6 |  |  | $ | 252.8 |  |  | $ | (33.2) |  |  | (13.1) | % |
| Profit | $ | 17.2 |  |  | $ | 45.3 |  |  | $ | (28.1) |  |  | (62.0) | % |
| % of net sales | 7.8 | % |  | 17.9 | % |  |  |  |  |

[0001628280-22-019665:mdna:49]
Net sales decreased 13% in the second quarter of 2022 compared to 2021.  Sales volume was lower by 22% which was partially offset by favorable mix of 5% and price increases of 4%.

[0001628280-22-019665:mdna:50]
Segment profit in the second quarter of 2022 compared to 2021 decreased $28 million due to $23 million from lower sales volume from supply chain constraints, $7 million from higher other product costs, $4 million from higher component costs, $4 million from unfavorable factory productivity, $4 million in higher SG&A costs, $3 million from higher commodity costs, and $2 million from higher freight and distribution costs. These decreases were partially offset by $11 million in favorable price, $7 million from favorable mix, and $1 million for lower product warranty costs.

[0001628280-22-019665:mdna:51]
[same as prior period, unchanged from 0001628280-22-010108:mdna:55]

[0001628280-22-019665:mdna:52]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-019665:mdna:53]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 169.2 |  |  | $ | 148.2 |  |  | $ | 21.0 |  |  | 14.2 | % |
| Profit | $ | 23.4 |  |  | $ | 13.5 |  |  | $ | 9.9 |  |  | 73.3 | % |
| % of net sales | 13.8 | % |  | 9.1 | % |  |  |  |  |

[0001628280-22-019665:mdna:54]
Net sales increased 14% in the second quarter of 2022 compared to 2021, as price increased 12% and sales volume increased by 9%. Partially offsetting these increases were unfavorable foreign currency of 6% and 1% from unfavorable mix.

[0001628280-22-019665:mdna:55]
Segment profit in the second quarter of 2022 compared to 2021 increased by $10 million driven by $18 million from higher price and $5 million from higher sales volume. Partially offsetting these increases were $5 million from commodity costs, $3 million from higher SG&A costs, $2 million from higher other product costs, $2 million from unfavorable factory productivity, and $1 million from higher freight and distribution costs.

[0001628280-22-019665:mdna:56]
[same as prior period, unchanged from 0001628280-22-010108:mdna:60]

[0001628280-22-019665:mdna:57]
There were no material changes in Corporate and Other costs during the second quarter of 2022 as compared to the second quarter of 2021.

[0001628280-22-019665:mdna:58]
Year-to-Date through June 30, 2022 Compared to Year-to-Date through June 30, 2021 - Consolidated Results

[0001628280-22-019665:mdna:59]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001628280-22-019665:mdna:60]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | $ | 2,379.7 |  |  | $ | 2,169.4 |  |  | 9.7 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,714.4 |  |  | 1,529.7 |  |  | (12.1) |  |  | 72.0 |  |  | 70.5 |  |
| Gross profit | 665.3 |  |  | 639.7 |  |  | 4.0 |  |  | 28.0 |  |  | 29.5 |  |
| Selling, general and administrative expenses | 324.9 |  |  | 313.2 |  |  | (3.7) |  |  | 13.7 |  |  | 14.4 |  |
| Losses (gains) and other expenses, net | 2.0 |  |  | 2.6 |  |  | 23.1 |  |  | 0.1 |  |  | 0.1 |  |
| Restructuring charges | 1.0 |  |  | 1.3 |  |  | 23.1 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (1.4) |  |  | (7.4) |  |  | (81.1) |  |  | (0.1) |  |  | (0.3) |  |
| Operating income | $ | 338.8 |  |  | $ | 330.0 |  |  | 2.7 | % |  | 14.2 | % |  | 15.2 | % |

[0001628280-22-019665:mdna:61]
Net Sales

[0001628280-22-019665:mdna:62]
Net sales increased 10% for the six months ended June 30, 2022 compared to the six months ended June 30, 2021 due to higher price of 10% and favorable mix of 1%.  Partially offsetting these increases was a sales volume decline of 1%.

[0001628280-22-019665:mdna:63]
Gross Profit

[0001628280-22-019665:mdna:64]
Gross profit margins for the six months ended June 30, 2022 decreased 150 bps to 28.0% compared to 29.5% for the six months ended June 30, 2021. Gross margins decreased 270 bps from higher commodity costs, 170 bps from higher component costs, 120 bps from higher other product costs, 110 from higher freight and distribution costs, 80 bps from unfavorable factory productivity, 60 bps from unfavorable mix, and 20 bps from unfavorable foreign currency.  Partially offsetting these decreases were 670 bps from higher price and 10 bps from lower tariff costs.

[0001628280-22-019665:mdna:65]
Selling, General and Administrative Expenses

[0001628280-22-019665:mdna:66]
SG&A increased $12 million to $325 million for the six months ended June 30, 2022 compared to $313 million for the six months ended June 30, 2021 primarily due to higher employee related costs.  As a percentage of net sales, SG&A decreased 70 bps to 13.7% from 14.4%.

[0001628280-22-019665:mdna:67]
Losses (gains) and Other Expenses, Net

[0001628280-22-019665:mdna:68]
Losses (gains) and other expenses, net for the six months ended June 30, 2022 and 2021 included the following (in millions):

[0001628280-22-019665:mdna:69]
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |  |  |
| Realized gains on settled future contracts | $ | (0.4) |  |  | $ | (0.6) |  |  |  |  |  |  |  |
| Foreign currency exchange gains | (0.8) |  |  | (1.6) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.9) |  |  | (0.5) |  |  |  |  |  |  |  |
| Other operating income | (0.5) |  |  | (0.6) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 1.2 |  |  | (0.2) |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 3.1 |  |  | 5.2 |  |  |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic | 0.5 |  |  | 1.1 |  |  |  |  |  |  |  |
| Other items, net | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.0 |  |  | $ | 2.6 |  |  |  |  |  |  |  |

[0001628280-22-019665:mdna:70]
The net change in unrealized losses (gains) on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001628280-22-019665:mdna:71]
Restructuring Charges

[0001628280-22-019665:mdna:72]
Restructuring charges were $1 million for the six months ended June 30, 2022 and $1 million for the six months ended June 30, 2021.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-22-019665:mdna:73]
Income from Equity Method Investments

[0001628280-22-019665:mdna:74]
Income from equity method investments decreased $6 million to $1 million for the six months ended June 30, 2022 as compared to $7 million for the six months ended June 30, 2021.  The decline is due to higher costs at the equity method investments.

[0001628280-22-019665:mdna:75]
Interest Expense, net

[0001628280-22-019665:mdna:76]
Interest expense, net increased $3 million for the six months ended June 30, 2022 compared to the six months ended June 30, 2021 primarily due to higher borrowings and higher borrowing costs.

[0001628280-22-019665:mdna:77]
Income Taxes

[0001628280-22-019665:mdna:78]
Our effective tax rate decreased to 18.9% for the six months ended June 30, 2022 compared to 19.3% for the six months ended June 30, 2021 primarily due to a favorable mix of income in lower tax jurisdictions.

[0001628280-22-019665:mdna:79]
Year-to-Date through June 30, 2022 Compared to Year-to-Date through June 30, 2021 - Results by Segment

[0001628280-22-019665:mdna:80]
Residential Heating & Cooling

[0001628280-22-019665:mdna:81]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the six months ended June 30, 2022 and 2021 (dollars in millions):

[0001628280-22-019665:mdna:82]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 1,659.6 |  |  | $ | 1,444.2 |  |  | $ | 215.4 |  |  | 14.9 | % |
| Profit | $ | 324.0 |  |  | $ | 286.1 |  |  | $ | 37.9 |  |  | 13.2 | % |
| % of net sales | 19.5 | % |  | 19.8 | % |  |  |  |  |

[0001628280-22-019665:mdna:83]
Net sales increased 15% for the six months ended June 30, 2022 compared to the six months ended June 30, 2021 as price increased by 12% and sales volume increased by 3%.

[0001628280-22-019665:mdna:84]
Segment profit for the first six months of 2022 compared to 2021 increased $38 million primarily due to $179 million from favorable price and $15 million from higher sales volume. Partially offsetting the increase were $50 million from higher commodity costs, $26 million from increased component costs, $19 million from unfavorable mix, $18 million from higher other product costs, $18 million from freight and distribution costs, $9 million for unfavorable factory productivity, $6 million from higher SG&A costs, $5 million from unfavorable foreign currency, and $5 million from lower income from equity method investments.

[0001628280-22-019665:mdna:85]
Commercial Heating & Cooling

[0001628280-22-019665:mdna:86]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the six months ended June 30, 2022 and 2021 (dollars in millions):

[0001628280-22-019665:mdna:87]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 407.3 |  |  | $ | 452.0 |  |  | $ | (44.7) |  |  | (9.9) | % |
| Profit | $ | 23.5 |  |  | $ | 72.6 |  |  | $ | (49.1) |  |  | (67.6) | % |
| % of net sales | 5.8 | % |  | 16.1 | % |  |  |  |  |

[0001628280-22-019665:mdna:88]
Net sales decreased 10% for the six months ended June 30, 2022 compared to the six months ended June 30, 2021 as sales volume decreased by 19%. Partially offsetting the decrease was favorable mix of 5% and favorable price of 4%.

[0001628280-22-019665:mdna:89]
Segment profit for the first six months of 2022 compared to 2021 decreased $49 million primarily due to $32 million from decreased volume from supply chain constraints, $12 million from higher component costs, $10 million from unfavorable factory productivity, $9 million from higher other product costs, $6 million from increased SG&A costs, $5 million from higher commodity costs, and $5 million from higher freight and distribution costs.  Partially offsetting these decreases were $17 million from higher price and $13 million from favorable product mix.

[0001628280-22-019665:mdna:90]
Refrigeration

[0001628280-22-019665:mdna:91]
The following table presents our Refrigeration segment's net sales and profit for the six months ended June 30, 2022 and 2021 (dollars in millions):

[0001628280-22-019665:mdna:92]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 312.8 |  |  | $ | 273.2 |  |  | $ | 39.6 |  |  | 14.5 | % |
| Profit | $ | 37.5 |  |  | $ | 21.4 |  |  | $ | 16.1 |  |  | 75.2 | % |
| % of net sales | 12.0 | % |  | 7.8 | % |  |  |  |  |

[0001628280-22-019665:mdna:93]
Net sales increased 15% for the six months ended June 30, 2022 compared to the six months ended June 30, 2021 as price increased by 10% and sales volume increased by 10%. Partially offsetting the decrease was unfavorable foreign currency of 4% and unfavorable mix of 1%.

[0001628280-22-019665:mdna:94]
Segment profit for the first six months of 2022 compared to 2021 increased $16 million primarily due to $28 million from favorable price and $10 million from higher sales volume. Partially offsetting the increase were $10 million from higher commodity costs, $5 million from higher SG&A costs, $4 million from higher component costs, and $3 million from higher freight and distribution costs.

[0001628280-22-019665:mdna:95]
Corporate and Other

[0001628280-22-019665:mdna:96]
Corporate and other expenses decreased $2 million in the six months ended June 30, 2022 compared to the six months ended June 30, 2021 primarily due to lower employee related costs.

[0001628280-22-019665:mdna:97]
[same as prior period, unchanged from 0001628280-22-010108:mdna:62]

[0001628280-22-019665:mdna:98]
[same as prior period, unchanged from 0001628280-22-010108:mdna:63]

[0001628280-22-019665:mdna:99]
[same as prior period, unchanged from 0001628280-22-010108:mdna:64]

[0001628280-22-019665:mdna:100]
The following table summarizes our cash flow activity for the six months ended June 30, 2022 and 2021 (in millions):

[0001628280-22-019665:mdna:101]
|  | For the Six Months Ended June 30, |
|  | 2022 |  | 2021 |
| Net cash (used in) provided by operating activities | $ | (0.8) |  |  | $ | 174.5 |  |
| Net cash used in investing activities | (46.2) |  |  | (42.6) |  |
| Net cash provided by (used in) financing activities | 75.4 |  |  | (210.8) |  |

[0001628280-22-019665:mdna:102]
Net Cash (Used In) Provided By Operating Activities -  The change in net cash used in operating activities for the six months ended June 30, 2022 compared to the cash provided by operating activities for the period in 2021 reflects less favorable changes in working capital.

[0001628280-22-019665:mdna:103]
Net Cash Used In Investing Activities - Capital expenditures were $47 million for the six months ended June 30, 2022 compared to $46 million in the same period of 2021.  Capital expenditures in 2022 were primarily related to the expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-22-019665:mdna:104]
Net Cash Provided By (Used In) Financing Activities - Net cash provided by financing activities for the six months ended June 30, 2022 increased to $75 million compared to $211 million used in financing activity in the same period of 2021.  The change was primarily due to increased net borrowings in the current year compared to the prior year and less spent on repurchase of common stock.  We repurchased $300 million of shares for the six months ended June 30, 2022 and returned $67 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001628280-22-019665:mdna:105]
[same as prior period, unchanged from 0001628280-22-010108:mdna:70]

[0001628280-22-019665:mdna:106]
The following table details our lines of credit and financing arrangements as of June 30, 2022 (in millions):

[0001628280-22-019665:mdna:107]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 11.8 |  |
| Total current maturities of long-term debt | $ | 11.8 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | 400.0 |  |
| Finance lease obligations | 30.8 |  |
| Credit Agreement (1) | 308.5 |  |
| Senior unsecured notes | 950.0 |  |
| Debt issuance costs | (7.8) |  |
| Total long-term debt | 1,681.5 |  |
| Total debt | $ | 1,693.3 |  |

[0001628280-22-019665:mdna:108]
(1)   The available future borrowings on our Credit Agreement (as defined below) are $439.5 million, after being reduced by the outstanding borrowings and $2.0 million in outstanding standby letters of credit.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-22-019665:mdna:109]
[same as prior period, unchanged from 0001628280-22-010108:mdna:74]

[0001628280-22-019665:mdna:110]
[same as prior period, unchanged from 0001628280-22-010108:mdna:75]

[0001628280-22-019665:mdna:111]
In July 2021, we entered into a domestic credit facility (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-22-019665:mdna:112]
[same as prior period, unchanged from 0001628280-22-010108:mdna:77]

[0001628280-22-019665:mdna:113]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control. As of June 30, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-22-019665:mdna:114]
[same as prior period, unchanged from 0001628280-22-010108:mdna:79]

[0001628280-22-019665:mdna:115]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 131% at June 30, 2022 from 128% at December 31, 2021.

[0001628280-22-019665:mdna:116]
As of June 30, 2022, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-22-019665:mdna:117]
[same as prior period, unchanged from 0001628280-22-010108:mdna:83]

[0001628280-22-019665:mdna:118]
We believe our cash and cash equivalents of $57 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $57 million as of June 30, 2022 was $20 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-22-019665:mdna:119]
[same as prior period, unchanged from 0001628280-22-010108:mdna:85]

[0001628280-22-019665:mdna:120]
Our senior unsecured notes were issued by Lennox International Inc. (the "Parent") and are unconditionally guaranteed by certain of our subsidiaries (the "Guarantor Subsidiaries").  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001628280-22-019665:mdna:121]
[same as prior period, unchanged from 0001628280-22-010108:mdna:88]

[0001628280-22-019665:mdna:122]
[same as prior period, unchanged from 0001628280-22-010108:mdna:89]

[0001628280-22-019665:mdna:123]
Commitments, Contingencies and Guarantees

[0001628280-22-019665:mdna:124]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-22-019665:mdna:125]
[same as prior period, unchanged from 0001628280-22-010108:mdna:92]

[0001628280-22-019665:mdna:126]
[same as prior period, unchanged from 0001628280-22-010108:mdna:93]
