# LII notes — 0001069202-13-000011


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-13-000011:notes:1]
[same as prior period, unchanged from 0001069202-13-000008:notes:1]

[0001069202-13-000011:notes:2]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2013, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2013 and 2012, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2013 and 2012, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2013 and 2012 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2012. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-13-000011:notes:3]
[same as prior period, unchanged from 0001069202-13-000008:notes:3]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-13-000011:notes:4]
Commitments and Contingencies:

[0001069202-13-000011:notes:5]
Leases

[0001069202-13-000011:notes:6]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas (the "Lake Park Renewal") for a term of approximately six years through March 1, 2019.  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease.

[0001069202-13-000011:notes:7]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Domestic Credit Facility.  We were in compliance with those covenants as of September 30, 2013.

[0001069202-13-000011:notes:8]
Product Warranties and Product Related Contingencies

[0001069202-13-000011:notes:9]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000011:notes:10]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Accrued expenses | $ | 23.7 |  |  | $ | 25.1 |  |
| Other liabilities | 52.0 |  |  | 46.8 |  |
|  | $ | 75.7 |  |  | $ | 71.9 |  |

[0001069202-13-000011:notes:11]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2013 were as follows (in millions):

[0001069202-13-000011:notes:12]
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (15.3 | ) |
| Changes resulting from issuance of new warranties | 22.5 |  |
| Changes in estimates associated with pre-existing liabilities | (3.2 | ) |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Total warranty liability as of September 30, 2013 | $ | 75.7 |  |

[0001069202-13-000011:notes:13]
We evaluate our heating, ventilation and air conditioning ("HVAC") warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.  As a result of the second quarter 2013 re-evaluation, we decreased our warranty liability by $3.2 million and recorded the related adjustment in Cost of Goods Sold in the Consolidated Statements of Operations.

[0001069202-13-000011:notes:14]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material changes in the circumstances that affect our product warranties since our latest fiscal year-end.

[0001069202-13-000011:notes:15]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001069202-13-000011:notes:16]
We have non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the nine months ended September 30, 2013 were as follows (in millions):

[0001069202-13-000011:notes:17]
| Total accrued product quality issues as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | 0.3 |  |
| Product quality claims paid in 2013 | (1.1 | ) |
| Total accrued product quality issues as of September 30, 2013 | $ | 5.9 |  |

[0001069202-13-000011:notes:18]
Litigation

[0001069202-13-000011:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-13-000011:notes:20]
Some of these claims and lawsuits allege health problems resulting from exposure to asbestos.  For the three months ended September 30, 2013, no expense was recorded and for the nine months ended September 30, 2013, $0.5 million of expense, net of insurance recoveries, was recorded for asbestos matters.  These charges were included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations.  We also expect that additional asbestos-related claims will be brought against us in the future.  However, the Company believes our liability exposure related to those additional future claims cannot currently be estimated because of numerous uncertainties, including the number of such claims and lawsuits and the costs of defending and settling them, possible adverse judgments in amounts greater than previously experienced, and possible changes in the laws and process governing the compensation of asbestos claimants.

[0001069202-13-000011:notes:21]
We are also involved in patent litigation claims related to products from an acquired business.  The Company  has indemnification protection (with certain limitations) for these claims.

[0001069202-13-000011:notes:22]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-13-000011:notes:23]
[same as prior period, unchanged from 0001069202-13-000008:notes:23]

[0001069202-13-000011:notes:24]
[same as prior period, unchanged from 0001069202-13-000008:notes:24]

[0001069202-13-000011:notes:25]
| AOCI Component |  | For the Three Months Ended September 30, 2013 |  | For the Nine Months Ended September 30, 2013 |  | Affected Line Item in the Consolidated Statements of Operations |
| Losses on cash flow hedges: |  |  |  |  |  |  |
| Commodity derivative contracts |  | $ | (2.1 | ) |  | $ | (3.3 | ) |  | Cost of goods sold |
| Income tax benefit (expense) |  | 0.8 |  |  | 1.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.3 | ) |  | $ | (2.1 | ) |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Sale of foreign business (1) |  | $ | — |  |  | $ | 41.1 |  |  | Loss from discontinued operations |
| Total reclassifications from AOCI |  | $ | (1.3 | ) |  | $ | 39.0 |  |  |  |

[0001069202-13-000011:notes:26]
[same as prior period, unchanged from 0001069202-13-000008:notes:26]

[0001069202-13-000011:notes:27]
The following table provides information on changes in AOCI by component (net of tax) for the nine months ended September 30, 2013 (in millions):

[0001069202-13-000011:notes:28]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2012 |  | $ | 1.1 |  |  | $ | 9.3 |  |  | $ | (147.5 | ) |  | $ | 114.8 |  |  | $ | (22.3 | ) |
| Other comprehensive (loss) income before reclassifications |  | (5.2 | ) |  | (6.2 | ) |  | 0.4 |  |  | (21.6 | ) |  | (32.6 | ) |
| Amounts reclassified from AOCI |  | 2.1 |  |  | — |  |  | — |  |  | (41.1 | ) |  | (39.0 | ) |
| Net other comprehensive (loss) income |  | (3.1 | ) |  | (6.2 | ) |  | 0.4 |  |  | (62.7 | ) |  | (71.6 | ) |
| Balance as of September 30, 2013 |  | $ | (2.0 | ) |  | $ | 3.1 |  |  | $ | (147.1 | ) |  | $ | 52.1 |  |  | $ | (93.9 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001069202-13-000011:notes:29]
Lines of Credit and Financing Arrangements:

[0001069202-13-000011:notes:30]
The following table summarizes our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000011:notes:31]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 7.9 |  |  | 4.9 |  |
| Total short-term debt | $ | 167.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.8 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 49.5 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 266.2 |  |  | $ | 351.0 |  |
| Total debt | $ | 434.9 |  |  | $ | 386.6 |  |

[0001069202-13-000011:notes:32]
Short-Term Debt

[0001069202-13-000011:notes:33]
Foreign Obligations

[0001069202-13-000011:notes:34]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $7.9 million and $4.9 million of foreign obligations as of September 30, 2013 and December 31, 2012, respectively, that are primarily borrowings under non-committed facilities.

[0001069202-13-000011:notes:35]
Asset Securitization Program

[0001069202-13-000011:notes:36]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.

[0001069202-13-000011:notes:37]
The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-13-000011:notes:38]
The ASP provides for a maximum securitization amount of the lesser of $160.0 million or 100% of the net pool balance as defined by the ASP.  However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-13-000011:notes:39]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 160.0 |  |  | 30.0 |  |
| Remaining amount available | $ | — |  |  | $ | 130.0 |  |

[0001069202-13-000011:notes:40]
Under the ASP, we pay certain discount fees to use the program and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates for September 30, 2013 and December 31, 2012 were 0.81% and 0.85%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):

[0001069202-13-000011:notes:41]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |

[0001069202-13-000011:notes:42]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2013, we were in compliance with all covenant requirements.

[0001069202-13-000011:notes:43]
Long-Term Debt

[0001069202-13-000011:notes:44]
Domestic Revolving Credit Facility

[0001069202-13-000011:notes:45]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $49.5 million as well as $33.5 million committed to standby letters of credit as of September 30, 2013. Subject to covenant limitations, $567.0 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-13-000011:notes:46]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-13-000011:notes:47]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.41 | % |  | 1.46 | % |

[0001069202-13-000011:notes:48]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-13-000011:notes:49]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-13-000011:notes:50]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our revolving credit facility could occur if:

[0001069202-13-000011:notes:51]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-13-000011:notes:52]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-13-000011:notes:53]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-13-000011:notes:54]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2013, we were in compliance with all covenant requirements.

[0001069202-13-000011:notes:55]
Senior Unsecured Notes

[0001069202-13-000011:notes:56]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

[0001069202-13-000011:notes:57]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2013, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-13-000011:notes:58]
[same as prior period, unchanged from 0001069202-13-000008:notes:58]

[0001069202-13-000011:notes:59]
[same as prior period, unchanged from 0001069202-13-000008:notes:59]

[0001069202-13-000011:notes:60]
[same as prior period, unchanged from 0001069202-13-000008:notes:60]

[0001069202-13-000011:notes:61]
We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-13-000011:notes:62]
[same as prior period, unchanged from 0001069202-13-000008:notes:62]

[0001069202-13-000011:notes:63]
A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest. In order to mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows.

[0001069202-13-000011:notes:64]
Prior to 2013, we used an interest rate swap hedge to fix the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the benchmark interest rate.  The variable portion of the interest rate swap was tied to the 1-Month LIBOR (the benchmark interest rate). On a monthly basis, the interest rates for both the interest rate swap and the underlying debt were reset, the swap was settled with the counterparty, and the interest was paid.  That interest rate swap was classified as a cash flow hedge and it expired on October 12, 2012.  Subsequently, we have not hedged against interest rate risk.

[0001069202-13-000011:notes:65]
[same as prior period, unchanged from 0001069202-13-000008:notes:65]

[0001069202-13-000011:notes:66]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them. By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-13-000011:notes:67]
[same as prior period, unchanged from 0001069202-13-000008:notes:67]

[0001069202-13-000011:notes:68]
We have commodity futures contracts designated as cash flows hedges that are scheduled to mature through March 2015.  Unrealized gains or losses from our commodity cash flow hedges are included in accumulated other comprehensive income (“AOCI”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.  Assuming commodity prices remain constant, we expect to reclassify $2.1 million of derivative losses into earnings within the next 12 months.

[0001069202-13-000011:notes:69]
[same as prior period, unchanged from 0001069202-13-000008:notes:69]

[0001069202-13-000011:notes:70]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Commodity Hedges: |  |  |  |
| Losses (gains) included in AOCI, net of tax | $ | 2.0 |  |  | $ | (1.1 | ) |
| Income tax expense (benefit) | (1.1 | ) |  | 0.7 |  |

[0001069202-13-000011:notes:71]
[same as prior period, unchanged from 0001069202-13-000008:notes:71]

[0001069202-13-000011:notes:72]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
|  | (pounds) |  | (pounds) |
| Copper | 20.0 |  |  | 22.8 |  |

[0001069202-13-000011:notes:73]
[same as prior period, unchanged from 0001069202-13-000008:notes:73]

[0001069202-13-000011:notes:74]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges, except that we elect not to designate them as cash flow hedges at the inception of the arrangement. We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions):

[0001069202-13-000011:notes:75]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
|  | (pounds) |  | (pounds) |
| Copper | 2.1 |  |  | 2.1 |  |
| Aluminum | 2.5 |  |  | 2.8 |  |

[0001069202-13-000011:notes:76]
[same as prior period, unchanged from 0001069202-13-000008:notes:76]

[0001069202-13-000011:notes:77]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Notional Amounts: |  |  |  |
| Brazilian Real | 5.2 |  |  | 10.8 |  |
| Mexican Peso | 248.5 |  |  | 220.2 |  |
| Euro | 2.0 |  |  | 1.3 |  |
| British Pound | 3.4 |  |  | 5.4 |  |
| Indian Rupee | 112.0 |  |  | 19.5 |  |
| Polish Zloty | 30.5 |  |  | 12.4 |  |

[0001069202-13-000011:notes:78]
[same as prior period, unchanged from 0001069202-13-000008:notes:78]

[0001069202-13-000011:notes:79]
[same as prior period, unchanged from 0001069202-13-000008:notes:79]

[0001069202-13-000011:notes:80]
|  | Fair Values of Derivative Instruments(1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | As of September 30, 2013 |  | As of December 31, 2012 |  | As of September 30, 2013 |  | As of December 31, 2012 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 1.6 |  |  | $ | — |  |  | $ | 0.2 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.1 |  |  | 0.3 |  |  | — |  |  | — |  |
| Total Assets | $ | 0.1 |  |  | $ | 1.9 |  |  | $ | — |  |  | $ | 0.3 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 3.3 |  |  | $ | — |  |  | $ | 0.4 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.2 |  |  | 0.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 3.3 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 0.1 |  |

[0001069202-13-000011:notes:81]
[same as prior period, unchanged from 0001069202-13-000008:notes:81]

[0001069202-13-000011:notes:82]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Amount of Loss Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |
| Commodity futures contracts(1) | $ | 2.1 |  |  | $ | 2.2 |  |  | $ | 3.3 |  |  | $ | 5.8 |  |
| Interest rate swap(2) | — |  |  | 0.6 |  |  | — |  |  | 1.8 |  |
|  | $ | 2.1 |  |  | $ | 2.8 |  |  | $ | 3.3 |  |  | $ | 7.6 |  |
| Amount of Loss (Gain) Recognized in Income (Ineffective Portion): |  |  |  |  |  |  |  |
| Commodity futures contracts(3) | $ | (0.1 | ) |  | $ | (0.1 | ) |  | $ | 0.2 |  |  | $ | (0.2 | ) |

[0001069202-13-000011:notes:83]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Amount of Loss (Gain) Recognized in Income: |  |  |  |  |  |  |  |
| Commodity futures contracts(3) | $ | (0.6 | ) |  | $ | (0.8 | ) |  | $ | 1.2 |  |  | $ | (0.9 | ) |
| Foreign currency forward contracts(3) | (0.6 | ) |  | 0.6 |  |  | 0.2 |  |  | 0.3 |  |
|  | $ | (1.2 | ) |  | $ | (0.2 | ) |  | $ | 1.4 |  |  | $ | (0.6 | ) |

[0001069202-13-000011:notes:84]
[same as prior period, unchanged from 0001069202-13-000008:notes:84]

[0001069202-13-000011:notes:85]
[same as prior period, unchanged from 0001069202-13-000008:notes:85]

[0001069202-13-000011:notes:86]
(3) The loss (gain) was recorded in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-13-000011:notes:87]
[same as prior period, unchanged from 0001069202-13-000008:notes:87]

[0001069202-13-000011:notes:88]
[same as prior period, unchanged from 0001069202-13-000008:notes:88]

[0001069202-13-000011:notes:89]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Compensation expense(1) | $ | 5.3 |  |  | $ | 2.7 |  |  | $ | 20.5 |  |  | $ | 10.5 |  |

[0001069202-13-000011:notes:90]
[same as prior period, unchanged from 0001069202-13-000008:notes:90]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-13-000011:notes:91]
[same as prior period, unchanged from 0001069202-13-000008:notes:91]

[0001069202-13-000011:notes:92]
[same as prior period, unchanged from 0001069202-13-000008:notes:92]

[0001069202-13-000011:notes:93]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd. in an all cash transaction for proceeds, excluding transaction costs, of $10.4 million.  The proceeds included a determinable working capital adjustment of $3.8 million.

[0001069202-13-000011:notes:94]
[same as prior period, unchanged from 0001069202-13-000008:notes:94]

[0001069202-13-000011:notes:95]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net trade sales(1) | $ | — |  |  | $ | 98.3 |  |  | $ | 73.5 |  |  | $ | 292.6 |  |
| Pre-tax operating loss (1)(2) | (2.3 | ) |  | (26.8 | ) |  | (17.8 | ) |  | (42.7 | ) |
| Gain on sale of business | — |  |  | — |  |  | 1.7 |  |  | — |  |

[0001069202-13-000011:notes:96]
[same as prior period, unchanged from 0001069202-13-000008:notes:96]

[0001069202-13-000011:notes:97]
(2) Pre-tax operating loss for the nine months ended September 30, 2013 included $2.3 million in retention bonus and severance costs and $0.2 million in stock-based compensation expense.

[0001069202-13-000011:notes:98]
[same as prior period, unchanged from 0001069202-13-000008:notes:98]

[0001069202-13-000011:notes:99]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Assets of discontinued operations: |  |  |  |
| Accounts receivable, net | $ | — |  |  | $ | 11.2 |  |
| Inventories, net | — |  |  | 4.8 |  |
| Property, plant and equipment, net | — |  |  | 3.6 |  |
| Goodwill and intangible assets, net (1) | — |  |  | 66.2 |  |
| Deferred income taxes | — |  |  | 5.5 |  |
| Other assets | — |  |  | 7.3 |  |
| Liabilities of discontinued operations: |  |  |  |
| Accounts payable | $ | — |  |  | $ | 16.7 |  |
| Accrued expenses | — |  |  | 38.5 |  |

[0001069202-13-000011:notes:100]
[same as prior period, unchanged from 0001069202-13-000008:notes:100]

[0001069202-13-000011:notes:101]
[same as prior period, unchanged from 0001069202-13-000008:notes:101]

[0001069202-13-000011:notes:102]
[same as prior period, unchanged from 0001069202-13-000008:notes:102]

[0001069202-13-000011:notes:103]
[same as prior period, unchanged from 0001069202-13-000008:notes:103]

[0001069202-13-000011:notes:104]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net trade sales(1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Pre-tax operating income (loss)(1) | — |  |  | (1.2 | ) |  | 0.5 |  |  | (13.1 | ) |
| Loss on sale of business | — |  |  | 2.9 |  |  | — |  |  | (0.9 | ) |

[0001069202-13-000011:notes:105]
[same as prior period, unchanged from 0001069202-13-000008:notes:105]

[0001069202-13-000011:notes:106]
There were no assets and liabilities related to the Hearth business included in the accompanying Consolidated Balance Sheets as of September 30, 2013 or December 31, 2012.


## us-gaap:EarningsPerShareTextBlock

[0001069202-13-000011:notes:107]
[same as prior period, unchanged from 0001069202-13-000008:notes:107]

[0001069202-13-000011:notes:108]
[same as prior period, unchanged from 0001069202-13-000008:notes:108]

[0001069202-13-000011:notes:109]
[same as prior period, unchanged from 0001069202-13-000008:notes:109]

[0001069202-13-000011:notes:110]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net income | $ | 64.3 |  |  | $ | 29.4 |  |  | $ | 136.6 |  |  | $ | 68.0 |  |
| Add: Loss from discontinued operations | 1.5 |  |  | 20.3 |  |  | 9.3 |  |  | 40.5 |  |
| Income from continuing operations | $ | 65.8 |  |  | $ | 49.7 |  |  | $ | 145.9 |  |  | $ | 108.5 |  |
| Weighted-average shares outstanding – basic | 49.7 |  |  | 50.6 |  |  | 50.0 |  |  | 50.8 |  |
| Effect of diluted securities attributable to stock-based payments | 0.8 |  |  | 0.7 |  |  | 0.8 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 50.5 |  |  | 51.3 |  |  | 50.8 |  |  | 51.5 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.32 |  |  | $ | 0.98 |  |  | $ | 2.92 |  |  | $ | 2.13 |  |
| Loss from discontinued operations | (0.03 | ) |  | (0.40 | ) |  | (0.19 | ) |  | (0.79 | ) |
| Net income | $ | 1.29 |  |  | $ | 0.58 |  |  | $ | 2.73 |  |  | $ | 1.34 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.30 |  |  | $ | 0.97 |  |  | $ | 2.87 |  |  | $ | 2.11 |  |
| Loss from discontinued operations | (0.03 | ) |  | (0.40 | ) |  | (0.18 | ) |  | (0.79 | ) |
| Net income | $ | 1.27 |  |  | $ | 0.57 |  |  | $ | 2.69 |  |  | $ | 1.32 |  |

[0001069202-13-000011:notes:111]
[same as prior period, unchanged from 0001069202-13-000008:notes:111]

[0001069202-13-000011:notes:112]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Weighted-average number of shares | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |
| Price per share | $ | — |  |  | $ | 46.78 |  |  | $ | — |  |  | $ | 46.78 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-13-000011:notes:113]
[same as prior period, unchanged from 0001069202-13-000008:notes:113]

[0001069202-13-000011:notes:114]
|  | Quoted Prices in Active Markets forSimilar Instruments (Level 2) |
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Senior unsecured notes | $ | 212.1 |  |  | $ | 212.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-13-000011:notes:115]
[same as prior period, unchanged from 0001069202-13-000008:notes:115]

[0001069202-13-000011:notes:116]
[same as prior period, unchanged from 0001069202-13-000008:notes:116]

[0001069202-13-000011:notes:117]
[same as prior period, unchanged from 0001069202-13-000008:notes:117]

[0001069202-13-000011:notes:118]
|  | Quoted Prices in Active Markets forIdentical Assets (Level 1) |
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Investment in marketable equity securities (1) | $ | 5.1 |  |  | $ | 10.6 |  |

[0001069202-13-000011:notes:119]
[same as prior period, unchanged from 0001069202-13-000008:notes:119]

[0001069202-13-000011:notes:120]
[same as prior period, unchanged from 0001069202-13-000008:notes:120]

[0001069202-13-000011:notes:121]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net, accounts payable, other current liabilities, and short-term debt approximate fair value due to the short maturities of these instruments. The carrying amount of our Domestic Revolving Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-13-000011:notes:122]
[same as prior period, unchanged from 0001069202-13-000008:notes:122]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-13-000011:notes:123]
[same as prior period, unchanged from 0001069202-13-000008:notes:123]

[0001069202-13-000011:notes:124]
The changes in the carrying amount of goodwill for the first nine months of 2013, in total and by segment, are summarized in the table below (in millions):

[0001069202-13-000011:notes:125]
|  | Balance at December 31, 2012 |  | Acquisitions / (Dispositions) |  | Other(1) |  | Balance at September 30, 2013 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 63.8 |  |  | — |  |  | 0.4 |  |  | 64.2 |  |
| Refrigeration | 133.9 |  |  | — |  |  | (5.4 | ) |  | 128.5 |  |
|  | $ | 223.8 |  |  | $ | — |  |  | $ | (5.0 | ) |  | $ | 218.8 |  |

[0001069202-13-000011:notes:126]
[same as prior period, unchanged from 0001069202-13-000008:notes:126]

[0001069202-13-000011:notes:127]
[same as prior period, unchanged from 0001069202-13-000008:notes:127]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-13-000011:notes:128]
[same as prior period, unchanged from 0001069202-13-000008:notes:128]

[0001069202-13-000011:notes:129]
As of September 30, 2013, we had approximately $1.9 million in total gross unrecognized tax benefits. Of this amount, $1.5 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of September 30, 2013, we had approximately $0.2 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-13-000011:notes:130]
We are currently under examination for our U.S. federal income taxes for 2012 and 2013 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2007.

[0001069202-13-000011:notes:131]
Since January 1, 2013, numerous states, including New Mexico, North Dakota, Minnesota, Texas, West Virginia and North Carolina, enacted legislation effective for tax years beginning on or after January 1, 2013, including changes to rates and apportionment methods.  The impact of these changes is immaterial.

[0001069202-13-000011:notes:132]
On January 2, 2013, the American Taxpayer Relief Act of 2012 was enacted which retroactively reinstated and extended the Federal Research and Development Tax Credit (Federal R&D Tax Credit) from January 1, 2012 to December 31, 2013, in addition to other extenders.  As a result, the Company's income tax provision for the first nine months of calendar year 2013 includes a discrete tax benefit that will reduce the annual effective income tax rate.  On a full year basis, the impact to the annual effective income tax rate is not expected to be material.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-13-000011:notes:133]
[same as prior period, unchanged from 0001069202-13-000008:notes:133]

[0001069202-13-000011:notes:134]
[same as prior period, unchanged from 0001069202-13-000008:notes:134]

[0001069202-13-000011:notes:135]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Finished goods | $ | 292.9 |  |  | $ | 258.0 |  |
| Work in process | 12.7 |  |  | 12.0 |  |
| Raw materials and parts | 199.7 |  |  | 180.1 |  |
|  | 505.3 |  |  | 450.1 |  |
| Excess of current cost over last-in, first-out cost | (75.3 | ) |  | (75.3 | ) |
| Total inventories, net | $ | 430.0 |  |  | $ | 374.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-13-000011:notes:136]
[same as prior period, unchanged from 0001069202-13-000008:notes:136]

[0001069202-13-000011:notes:137]
[same as prior period, unchanged from 0001069202-13-000008:notes:137]

[0001069202-13-000011:notes:138]
[same as prior period, unchanged from 0001069202-13-000008:notes:138]

[0001069202-13-000011:notes:139]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-13-000011:notes:140]
[same as prior period, unchanged from 0001069202-13-000008:notes:140]

[0001069202-13-000011:notes:141]
[same as prior period, unchanged from 0001069202-13-000008:notes:141]

[0001069202-13-000011:notes:142]
[same as prior period, unchanged from 0001069202-13-000008:notes:142]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-13-000011:notes:143]
[same as prior period, unchanged from 0001069202-13-000008:notes:143]

[0001069202-13-000011:notes:144]
[same as prior period, unchanged from 0001069202-13-000008:notes:144]

[0001069202-13-000011:notes:145]
|  | For the Three Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.0 |  |  | 4.3 |  |  | — |  |  | 0.1 |  |
| Expected return on plan assets | (5.1 | ) |  | (4.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.7 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.3 |  |  | 2.1 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | 0.1 |  |  | 1.0 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 2.7 |  |  | $ | 4.2 |  |  | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0001069202-13-000011:notes:146]
|  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 3.9 |  |  | $ | 4.1 |  |  | $ | — |  |  | $ | 0.2 |  |
| Interest cost | 12.3 |  |  | 12.9 |  |  | 0.1 |  |  | 0.4 |  |
| Expected return on plan assets | (15.7 | ) |  | (14.1 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.3 |  |  | 0.3 |  |  | (2.2 | ) |  | (2.0 | ) |
| Recognized actuarial loss | 6.9 |  |  | 6.5 |  |  | 1.1 |  |  | 1.0 |  |
| Settlements and curtailments (2) | 1.3 |  |  | 7.3 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 9.0 |  |  | $ | 17.0 |  |  | $ | (1.0 | ) |  | $ | (0.4 | ) |

[0001069202-13-000011:notes:147]
(1) Pension Expense of $0.1 million and $0.2 million was included in Loss from discontinued operations for the three and nine months ended September 30,  2013, respectively.  Pension expense of $0.6 million and $7.0 million was included in Loss from discontinued operations for the three and nine months ended September 30, 2012, respectively.

[0001069202-13-000011:notes:148]
(2) Settlements and curtailments for the nine months ended September 30, 2012 included a $6.3 million settlement charge related to actuarial losses recognized upon transition of a pension obligation to the acquirer of the Lennox Hearth Products business.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-13-000011:notes:149]
[same as prior period, unchanged from 0001069202-13-000008:notes:148]

[0001069202-13-000011:notes:150]
As part of the efforts to achieve our strategic priorities of manufacturing and sourcing excellence and expense reduction, we initiated various rationalization actions in prior periods designed to lower our cost structure.  There were several ongoing restructuring activities as of September 30, 2013, however, none were significant.

[0001069202-13-000011:notes:151]
In the third quarter of 2013, we substantially completed the Regional Distribution Network restructuring activities and below are details of those activities in 2013.

[0001069202-13-000011:notes:152]
[same as prior period, unchanged from 0001069202-13-000008:notes:150]

[0001069202-13-000011:notes:153]
In 2008, our Residential Heating & Cooling segment commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa to other locations, including our North American Distribution Center in Marshalltown, Iowa.  In the first nine months of 2013, we recorded expense of $1.4 million with no expected future costs remaining for this restructuring activity.  As of September 30, 2013, we have incurred $7.7 million in costs related to this restructuring activity.

[0001069202-13-000011:notes:154]
[same as prior period, unchanged from 0001069202-13-000008:notes:152]

[0001069202-13-000011:notes:155]
Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, lease termination costs and other related costs. Restructuring charges are generally recorded based on planned employee termination dates and site closure and consolidation plans. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.

[0001069202-13-000011:notes:156]
Information regarding the charges for all ongoing restructuring actions related to continuing operations is as follows (in millions):

[0001069202-13-000011:notes:157]
|  | Incurred in 2013 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 0.8 |  |  | $ | 11.9 |  |  | $ | 12.5 |  |
| Asset write-offs and accelerated depreciation | 0.8 |  |  | 1.8 |  |  | 1.8 |  |
| Equipment moves | 0.1 |  |  | 0.4 |  |  | 0.4 |  |
| Lease termination | — |  |  | 2.6 |  |  | 2.6 |  |
| Other | 1.5 |  |  | 7.1 |  |  | 7.2 |  |
| Total restructuring charges | $ | 3.2 |  |  | $ | 23.8 |  |  | $ | 24.5 |  |

[0001069202-13-000011:notes:158]
While restructuring charges are excluded from our calculation of segment profit (loss), as more fully explained in Note 15, the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-13-000011:notes:159]
|  | Incurred in 2013 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 1.4 |  |  | $ | 7.7 |  |  | $ | 7.7 |  |
| Commercial Heating & Cooling | 0.9 |  |  | 7.8 |  |  | 8.4 |  |
| Refrigeration | 0.9 |  |  | 8.3 |  |  | 8.4 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total restructuring charges | $ | 3.2 |  |  | $ | 23.8 |  |  | $ | 24.5 |  |

[0001069202-13-000011:notes:160]
Restructuring reserves related to continuing operations are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below details the activity in 2013 within the restructuring reserves (in millions):

[0001069202-13-000011:notes:161]
| Description of Reserves | Balance as ofDecember 31, 2012 |  | ChargedtoEarnings |  | CashUtilization |  | Non-CashUtilizationand Other |  | Balance as ofSeptember 30, 2013 |
| Severance and related expense | $ | 0.7 |  |  | $ | 0.8 |  |  | $ | (1.1 | ) |  | $ | — |  |  | $ | 0.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.8 |  |  | (0.2 | ) |  | (0.6 | ) |  | — |  |
| Equipment moves | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Lease termination | 1.2 |  |  | — |  |  | (1.2 | ) |  | — |  |  | — |  |
| Other | 0.5 |  |  | 1.5 |  |  | (1.8 | ) |  | — |  |  | 0.2 |  |
| Total restructuring reserves | $ | 2.4 |  |  | $ | 3.2 |  |  | $ | (4.4 | ) |  | $ | (0.6 | ) |  | $ | 0.6 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-13-000011:notes:162]
Net sales and segment profit (loss) for each segment, along with a reconciliation of segment profit (loss) to Income from continuing operations before income taxes are shown below (in millions):

[0001069202-13-000011:notes:163]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 433.9 |  |  | $ | 386.3 |  |  | $ | 1,224.5 |  |  | $ | 1,070.7 |  |
| Commercial Heating & Cooling | 239.1 |  |  | 219.7 |  |  | 631.8 |  |  | 597.9 |  |
| Refrigeration | 195.0 |  |  | 203.7 |  |  | 593.2 |  |  | 595.9 |  |
|  | $ | 868.0 |  |  | $ | 809.7 |  |  | $ | 2,449.5 |  |  | $ | 2,264.5 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 57.0 |  |  | $ | 37.7 |  |  | $ | 143.7 |  |  | $ | 90.7 |  |
| Commercial Heating & Cooling | 39.2 |  |  | 32.5 |  |  | 84.8 |  |  | 74.1 |  |
| Refrigeration | 23.9 |  |  | 25.1 |  |  | 66.5 |  |  | 60.6 |  |
| Corporate and other | (16.6 | ) |  | (14.3 | ) |  | (56.2 | ) |  | (43.7 | ) |
| Subtotal that includes segment profit and eliminations | 103.5 |  |  | 81.0 |  |  | 238.8 |  |  | 181.7 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Special product quality adjustment | (0.4 | ) |  | 0.9 |  |  | (0.5 | ) |  | 1.0 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | (0.2 | ) |  | (1.2 | ) |  | 2.0 |  |  | (2.0 | ) |
| Restructuring charges | 0.3 |  |  | 0.4 |  |  | 3.2 |  |  | 3.1 |  |
| Interest expense, net | 3.8 |  |  | 4.4 |  |  | 10.8 |  |  | 13.4 |  |
| Other expense (income), net | — |  |  | — |  |  | (0.1 | ) |  | 0.1 |  |
| Income from continuing operations before income taxes | $ | 100.0 |  |  | $ | 76.5 |  |  | $ | 223.4 |  |  | $ | 166.1 |  |

[0001069202-13-000011:notes:164]
(1) We define segment profit and loss as a segment's income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-13-000011:notes:165]
[same as prior period, unchanged from 0001069202-13-000008:notes:163]

[0001069202-13-000011:notes:166]
| • | Items in Losses (gains) and other expenses, net (see table note 2 below); |

[0001069202-13-000011:notes:167]
[same as prior period, unchanged from 0001069202-13-000008:notes:165]

[0001069202-13-000011:notes:168]
[same as prior period, unchanged from 0001069202-13-000008:notes:166]

[0001069202-13-000011:notes:169]
[same as prior period, unchanged from 0001069202-13-000008:notes:167]

[0001069202-13-000011:notes:170]
[same as prior period, unchanged from 0001069202-13-000008:notes:168]

[0001069202-13-000011:notes:171]
(2) Items in Losses (gains) and other expenses, net that are excluded from segment profit are the net change in unrealized gains and/or losses on unsettled futures contracts, special legal contingency charges, and other items


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-13-000011:notes:172]
[same as prior period, unchanged from 0001069202-13-000008:notes:170]

[0001069202-13-000011:notes:173]
[same as prior period, unchanged from 0001069202-13-000008:notes:171]

[0001069202-13-000011:notes:174]
[same as prior period, unchanged from 0001069202-13-000008:notes:172]

[0001069202-13-000011:notes:175]
[same as prior period, unchanged from 0001069202-13-000008:notes:173]

[0001069202-13-000011:notes:176]
[same as prior period, unchanged from 0001069202-13-000008:notes:174]

[0001069202-13-000011:notes:177]
[same as prior period, unchanged from 0001069202-13-000008:notes:175]

[0001069202-13-000011:notes:178]
[same as prior period, unchanged from 0001069202-13-000008:notes:176]

[0001069202-13-000011:notes:179]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-13-000011:notes:180]
[same as prior period, unchanged from 0001069202-13-000008:notes:178]

[0001069202-13-000011:notes:181]
Our Board of Directors has authorized a total of $700.0 million towards the repurchase of shares of our common stock (the "Share Repurchase Plans"), including a $300.0 million share repurchase authorization approved in December 2012.  The Share Repurchase Plans do not have an expiration date.  For the nine months ended September 30, 2013, we repurchased 0.9 million shares for $66.0 million under the Share Repurchase Plans.  As of September 30, 2013, $305.2 million of share repurchases remain authorized.

[0001069202-13-000011:notes:182]
We also repurchased 0.1 million shares for $7.7 million for the nine months ended September 30, 2013 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the vesting of stock-based compensation awards.


## lii:CondensedConsolidatingFinancialStatementsTableTextBlock

[0001069202-13-000011:notes:183]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of September 30, 2013 and December 31, 2012 and for the three and nine months ended September 30, 2013 and 2012 are shown on the following pages.

[0001069202-13-000011:notes:184]
[same as prior period, unchanged from 0001069202-13-000008:notes:182]

[0001069202-13-000011:notes:185]
[same as prior period, unchanged from 0001069202-13-000008:notes:183]

[0001069202-13-000011:notes:186]
As of September 30, 2013

[0001069202-13-000011:notes:187]
[same as prior period, unchanged from 0001069202-13-000008:notes:185]

[0001069202-13-000011:notes:188]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.5 |  |  | $ | 15.3 |  |  | $ | 21.0 |  |  | $ | — |  |  | $ | 37.8 |  |
| Accounts and notes receivable, net | — |  |  | 30.7 |  |  | 458.5 |  |  | — |  |  | 489.2 |  |
| Inventories, net | — |  |  | 290.3 |  |  | 140.2 |  |  | (0.5 | ) |  | 430.0 |  |
| Deferred income taxes, net | 2.5 |  |  | 23.0 |  |  | 5.8 |  |  | (1.8 | ) |  | 29.5 |  |
| Other assets | 31.8 |  |  | 55.4 |  |  | 76.6 |  |  | (113.0 | ) |  | 50.8 |  |
| Assets of discontinued operations | — |  |  | — |  |  | 0.3 |  |  | (0.3 | ) |  | — |  |
| Total current assets | 35.8 |  |  | 414.7 |  |  | 702.4 |  |  | (115.6 | ) |  | 1,037.3 |  |
| Property, plant and equipment, net | — |  |  | 234.1 |  |  | 80.7 |  |  | — |  |  | 314.8 |  |
| Goodwill | — |  |  | 140.4 |  |  | 78.4 |  |  | — |  |  | 218.8 |  |
| Investment in subsidiaries | 2,358.7 |  |  | 305.8 |  |  | (0.5 | ) |  | (2,664.0 | ) |  | — |  |
| Deferred income taxes | 0.2 |  |  | 98.7 |  |  | 18.7 |  |  | (5.8 | ) |  | 111.8 |  |
| Other assets, net | 4.3 |  |  | 52.6 |  |  | 17.5 |  |  | (1.4 | ) |  | 73.0 |  |
| Intercompany receivables (payables), net | (1,503.8 | ) |  | 1,424.4 |  |  | 79.4 |  |  | — |  |  | — |  |
| Total assets | $ | 895.2 |  |  | $ | 2,670.7 |  |  | $ | 976.6 |  |  | $ | (2,786.8 | ) |  | $ | 1,755.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 167.9 |  |  | $ | — |  |  | $ | 167.9 |  |
| Current maturities of long-term debt | — |  |  | 0.6 |  |  | 0.2 |  |  | — |  |  | 0.8 |  |
| Accounts payable | 11.9 |  |  | 229.1 |  |  | 83.1 |  |  | — |  |  | 324.1 |  |
| Accrued expenses | 8.5 |  |  | 207.9 |  |  | 65.3 |  |  | (0.3 | ) |  | 281.4 |  |
| Income taxes payable | — |  |  | 76.9 |  |  | 56.4 |  |  | (111.7 | ) |  | 21.6 |  |
| Liabilities of discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total current liabilities | 20.4 |  |  | 514.5 |  |  | 372.9 |  |  | (112.0 | ) |  | 795.8 |  |
| Long-term debt | 249.5 |  |  | 16.5 |  |  | 0.2 |  |  | — |  |  | 266.2 |  |
| Post-retirement benefits, other than pensions | — |  |  | 3.8 |  |  | — |  |  | — |  |  | 3.8 |  |
| Pensions | — |  |  | 119.3 |  |  | 18.8 |  |  | — |  |  | 138.1 |  |
| Other liabilities | 0.4 |  |  | 66.7 |  |  | 9.6 |  |  | (7.1 | ) |  | 69.6 |  |
| Total liabilities | 270.3 |  |  | 720.8 |  |  | 401.5 |  |  | (119.1 | ) |  | 1,273.5 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 624.9 |  |  | 1,949.9 |  |  | 575.1 |  |  | (2,667.7 | ) |  | 482.2 |  |
| Total liabilities and stockholders' equity | $ | 895.2 |  |  | $ | 2,670.7 |  |  | $ | 976.6 |  |  | $ | (2,786.8 | ) |  | $ | 1,755.7 |  |

[0001069202-13-000011:notes:189]
[same as prior period, unchanged from 0001069202-13-000008:notes:188]

[0001069202-13-000011:notes:190]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 13.4 |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net | — |  |  | 225.8 |  |  | 344.7 |  |  | (197.1 | ) |  | 373.4 |  |
| Inventories, net | — |  |  | 257.3 |  |  | 121.5 |  |  | (4.0 | ) |  | 374.8 |  |
| Deferred income taxes, net | — |  |  | 22.9 |  |  | 6.3 |  |  | (1.7 | ) |  | 27.5 |  |
| Other assets | 2.0 |  |  | 19.7 |  |  | 78.1 |  |  | (38.8 | ) |  | 61.0 |  |
| Assets of discontinued operations | — |  |  | 25.2 |  |  | 78.4 |  |  | (5.0 | ) |  | 98.6 |  |
| Total current assets | 3.0 |  |  | 564.3 |  |  | 666.4 |  |  | (246.6 | ) |  | 987.1 |  |
| Property, plant and equipment, net | — |  |  | 239.7 |  |  | 58.5 |  |  | — |  |  | 298.2 |  |
| Goodwill | — |  |  | 131.8 |  |  | 92.0 |  |  | — |  |  | 223.8 |  |
| Investment in subsidiaries | 2,179.9 |  |  | 337.0 |  |  | (0.2 | ) |  | (2,516.7 | ) |  | — |  |
| Deferred income taxes | — |  |  | 87.8 |  |  | 20.8 |  |  | (5.8 | ) |  | 102.8 |  |
| Other assets, net | 3.7 |  |  | 53.0 |  |  | 23.3 |  |  | — |  |  | 80.0 |  |
| Intercompany receivables (payables), net | (1,289.8 | ) |  | 1,013.6 |  |  | 89.8 |  |  | 186.4 |  |  | — |  |
| Total assets | $ | 896.8 |  |  | $ | 2,427.2 |  |  | $ | 950.6 |  |  | $ | (2,582.7 | ) |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 34.9 |  |  | $ | — |  |  | $ | 34.9 |  |
| Current maturities of long-term debt | — |  |  | 0.5 |  |  | 0.2 |  |  | — |  |  | 0.7 |  |
| Accounts payable | — |  |  | 198.6 |  |  | 86.1 |  |  | — |  |  | 284.7 |  |
| Accrued expenses | 2.5 |  |  | 196.6 |  |  | 60.8 |  |  | (0.3 | ) |  | 259.6 |  |
| Income taxes payable | (27.3 | ) |  | 35.0 |  |  | 38.5 |  |  | (41.7 | ) |  | 4.5 |  |
| Liabilities of discontinued operations | — |  |  | 42.3 |  |  | 12.9 |  |  | — |  |  | 55.2 |  |
| Total current liabilities | (24.8 | ) |  | 473.0 |  |  | 233.4 |  |  | (42.0 | ) |  | 639.6 |  |
| Long-term debt | 335.0 |  |  | 15.6 |  |  | 0.4 |  |  | — |  |  | 351.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 6.1 |  |  | — |  |  | — |  |  | 6.1 |  |
| Pensions | — |  |  | 114.7 |  |  | 19.7 |  |  | — |  |  | 134.4 |  |
| Other liabilities | 0.5 |  |  | 60.1 |  |  | 9.2 |  |  | (7.3 | ) |  | 62.5 |  |
| Total liabilities | 310.7 |  |  | 669.5 |  |  | 262.7 |  |  | (49.3 | ) |  | 1,193.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 586.1 |  |  | 1,757.7 |  |  | 687.9 |  |  | (2,533.4 | ) |  | 498.3 |  |
| Total liabilities and stockholders' equity | $ | 896.8 |  |  | $ | 2,427.2 |  |  | $ | 950.6 |  |  | $ | (2,582.7 | ) |  | $ | 1,691.9 |  |

[0001069202-13-000011:notes:191]
[same as prior period, unchanged from 0001069202-13-000008:notes:190]

[0001069202-13-000011:notes:192]
For the Three Months Ended September 30, 2013

[0001069202-13-000011:notes:193]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 668.4 |  |  | $ | 221.7 |  |  | $ | (22.1 | ) |  | $ | 868.0 |  |
| Cost of goods sold | — |  |  | 494.5 |  |  | 161.7 |  |  | (25.6 | ) |  | 630.6 |  |
| Gross profit | — |  |  | 173.9 |  |  | 60.0 |  |  | 3.5 |  |  | 237.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 107.5 |  |  | 29.4 |  |  | — |  |  | 136.9 |  |
| Losses and other expenses, net | (1.7 | ) |  | 2.0 |  |  | (0.6 | ) |  | — |  |  | (0.3 | ) |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.2 |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (65.5 | ) |  | (14.9 | ) |  | (2.5 | ) |  | 79.6 |  |  | (3.3 | ) |
| Operational income from continuing operations | 67.2 |  |  | 79.2 |  |  | 33.5 |  |  | (76.1 | ) |  | 103.8 |  |
| Interest expense, net | 3.5 |  |  | (0.4 | ) |  | 0.7 |  |  | — |  |  | 3.8 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 63.7 |  |  | 79.6 |  |  | 32.8 |  |  | (76.1 | ) |  | 100.0 |  |
| Provision for income taxes | (0.6 | ) |  | 22.7 |  |  | 10.7 |  |  | 1.4 |  |  | 34.2 |  |
| Income from continuing operations | 64.3 |  |  | 56.9 |  |  | 22.1 |  |  | (77.5 | ) |  | 65.8 |  |
| Loss from discontinued operations | — |  |  | (1.5 | ) |  | — |  |  | — |  |  | (1.5 | ) |
| Net income | $ | 64.3 |  |  | $ | 55.4 |  |  | $ | 22.1 |  |  | $ | (77.5 | ) |  | $ | 64.3 |  |
| Other comprehensive income | $ | 4.5 |  |  | $ | 0.8 |  |  | $ | 3.5 |  |  | $ | 0.4 |  |  | $ | 9.2 |  |

[0001069202-13-000011:notes:194]
For the Nine Months Ended September 30, 2013

[0001069202-13-000011:notes:195]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,984.5 |  |  | $ | 619.3 |  |  | $ | (154.3 | ) |  | $ | 2,449.5 |  |
| Cost of goods sold | — |  |  | 1,473.9 |  |  | 474.9 |  |  | (152.7 | ) |  | 1,796.1 |  |
| Gross profit | — |  |  | 510.6 |  |  | 144.4 |  |  | (1.6 | ) |  | 653.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 327.8 |  |  | 96.2 |  |  | — |  |  | 424.0 |  |
| Losses and other expenses, net | 0.8 |  |  | 2.2 |  |  | — |  |  | (0.2 | ) |  | 2.8 |  |
| Restructuring charges | — |  |  | 1.6 |  |  | 1.6 |  |  | — |  |  | 3.2 |  |
| Income from equity method investments | (144.1 | ) |  | (6.0 | ) |  | (8.7 | ) |  | 148.1 |  |  | (10.7 | ) |
| Operational income from continuing operations | 143.3 |  |  | 185.0 |  |  | 55.3 |  |  | (149.5 | ) |  | 234.1 |  |
| Interest expense, net | 10.6 |  |  | (1.5 | ) |  | 1.7 |  |  | — |  |  | 10.8 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 132.7 |  |  | 186.5 |  |  | 53.7 |  |  | (149.5 | ) |  | 223.4 |  |
| Provision for income taxes | (3.9 | ) |  | 63.3 |  |  | 18.7 |  |  | (0.6 | ) |  | 77.5 |  |
| Income from continuing operations | 136.6 |  |  | 123.2 |  |  | 35.0 |  |  | (148.9 | ) |  | 145.9 |  |
| Loss from discontinued operations | — |  |  | 16.2 |  |  | (25.5 | ) |  | — |  |  | (9.3 | ) |
| Net income | $ | 136.6 |  |  | $ | 139.4 |  |  | $ | 9.5 |  |  | $ | (148.9 | ) |  | $ | 136.6 |  |
| Other comprehensive income (loss) | $ | (3.1 | ) |  | $ | 1.9 |  |  | $ | (3.8 | ) |  | $ | (66.6 | ) |  | $ | (71.6 | ) |

[0001069202-13-000011:notes:196]
For the Three Months Ended September 30, 2012

[0001069202-13-000011:notes:197]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 654.5 |  |  | $ | 214.3 |  |  | $ | (59.1 | ) |  | $ | 809.7 |  |
| Cost of goods sold | — |  |  | 499.7 |  |  | 163.9 |  |  | (58.8 | ) |  | 604.8 |  |
| Gross profit | — |  |  | 154.8 |  |  | 50.4 |  |  | (0.3 | ) |  | 204.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 99.2 |  |  | 26.8 |  |  | (0.1 | ) |  | 125.9 |  |
| Losses and other expenses, net | 0.1 |  |  | (1.0 | ) |  | 1.2 |  |  | — |  |  | 0.3 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.3 |  |  | — |  |  | 0.4 |  |
| Income from equity method investments | (38.4 | ) |  | (6.5 | ) |  | (1.9 | ) |  | 44.2 |  |  | (2.6 | ) |
| Operational income from continuing operations | 38.3 |  |  | 63.0 |  |  | 24.0 |  |  | (44.4 | ) |  | 80.9 |  |
| Interest expense, net | 4.3 |  |  | (0.6 | ) |  | 0.7 |  |  | — |  |  | 4.4 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 34.0 |  |  | 63.6 |  |  | 23.3 |  |  | (44.4 | ) |  | 76.5 |  |
| Provision for income taxes | (1.6 | ) |  | 20.1 |  |  | 10.0 |  |  | (1.7 | ) |  | 26.8 |  |
| Income from continuing operations | 35.6 |  |  | 43.5 |  |  | 13.3 |  |  | (42.7 | ) |  | 49.7 |  |
| Loss from discontinued operations | — |  |  | (12.6 | ) |  | (7.7 | ) |  | — |  |  | (20.3 | ) |
| Net income | $ | 35.6 |  |  | $ | 30.9 |  |  | $ | 5.6 |  |  | $ | (42.7 | ) |  | $ | 29.4 |  |
| Other comprehensive income | $ | 5.6 |  |  | $ | 4.6 |  |  | $ | 17.4 |  |  | $ | 1.9 |  |  | $ | 29.5 |  |

[0001069202-13-000011:notes:198]
For the Nine Months Ended September 30, 2012

[0001069202-13-000011:notes:199]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,814.5 |  |  | $ | 610.2 |  |  | $ | (160.2 | ) |  | $ | 2,264.5 |  |
| Cost of goods sold | 0.1 |  |  | 1,401.7 |  |  | 468.4 |  |  | (159.6 | ) |  | 1,710.6 |  |
| Gross profit | (0.1 | ) |  | 412.8 |  |  | 141.8 |  |  | (0.6 | ) |  | 553.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 286.5 |  |  | 93.3 |  |  | — |  |  | 379.8 |  |
| Losses and other expenses, net | (2.1 | ) |  | (0.4 | ) |  | 2.7 |  |  | — |  |  | 0.2 |  |
| Restructuring charges | — |  |  | 2.6 |  |  | 0.5 |  |  | — |  |  | 3.1 |  |
| Income from equity method investments | (81.9 | ) |  | (8.1 | ) |  | (6.9 | ) |  | 88.1 |  |  | (8.8 | ) |
| Operational income from continuing operations | 83.9 |  |  | 132.2 |  |  | 52.2 |  |  | (88.7 | ) |  | 179.6 |  |
| Interest expense, net | 13.1 |  |  | (1.8 | ) |  | 2.1 |  |  | — |  |  | 13.4 |  |
| Other expense, net | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from continuing operations before income taxes | 70.8 |  |  | 134.0 |  |  | 50.0 |  |  | (88.7 | ) |  | 166.1 |  |
| Provision for income taxes | (4.0 | ) |  | 45.1 |  |  | 16.7 |  |  | (0.2 | ) |  | 57.6 |  |
| Income from continuing operations | 74.8 |  |  | 88.9 |  |  | 33.3 |  |  | (88.5 | ) |  | 108.5 |  |
| Loss from discontinued operations | — |  |  | (27.9 | ) |  | (12.6 | ) |  | — |  |  | (40.5 | ) |
| Net income | $ | 74.8 |  |  | $ | 61.0 |  |  | $ | 20.7 |  |  | $ | (88.5 | ) |  | $ | 68.0 |  |
| Other comprehensive income | $ | 7.9 |  |  | $ | 4.4 |  |  | $ | 8.4 |  |  | $ | 6.2 |  |  | $ | 26.9 |  |

[0001069202-13-000011:notes:200]
[same as prior period, unchanged from 0001069202-13-000008:notes:199]

[0001069202-13-000011:notes:201]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (41.6 | ) |  | $ | 267.0 |  |  | $ | (160.4 | ) |  | $ | — |  |  | $ | 65.0 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (30.3 | ) |  | (10.7 | ) |  | — |  |  | (41.0 | ) |
| Net proceeds from sale of businesses | 4.8 |  |  | — |  |  | 3.3 |  |  | — |  |  | 8.1 |  |
| Net cash used in discontinued operations | — |  |  | (0.1 | ) |  | — |  |  | — |  |  | (0.1 | ) |
| Net cash used in investing activities | 4.8 |  |  | (30.3 | ) |  | (7.4 | ) |  | — |  |  | (32.9 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 330.0 |  |  | — |  |  | 330.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (200.0 | ) |  | — |  |  | (200.0 | ) |
| Long-term debt payments | — |  |  | (0.5 | ) |  | (0.2 | ) |  | — |  |  | (0.7 | ) |
| Borrowings from revolving credit facility | 998.0 |  |  | — |  |  | — |  |  | — |  |  | 998.0 |  |
| Payments on revolving credit facility | (1,083.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,083.5 | ) |
| Proceeds from employee stock purchases | 1.3 |  |  | — |  |  | — |  |  | — |  |  | 1.3 |  |
| Repurchases of common stock | (66.0 | ) |  | — |  |  | — |  |  | — |  |  | (66.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (7.7 | ) |  | — |  |  | — |  |  | — |  |  | (7.7 | ) |
| Excess tax benefits related to share-based payments | 4.7 |  |  | — |  |  | — |  |  | — |  |  | 4.7 |  |
| Intercompany debt | (44.4 | ) |  | 8.4 |  |  | 36.0 |  |  | — |  |  | — |  |
| Intercompany financing activity | 257.0 |  |  | (242.7 | ) |  | (14.3 | ) |  | — |  |  | — |  |
| Cash dividends paid | (22.1 | ) |  | — |  |  | — |  |  | — |  |  | (22.1 | ) |
| Net cash used in financing activities | 37.3 |  |  | (234.8 | ) |  | 155.3 |  |  | — |  |  | (42.2 | ) |
| Decrease in cash and cash equivalents | 0.5 |  |  | 1.9 |  |  | (12.5 | ) |  | — |  |  | (10.1 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (3.9 | ) |  | — |  |  | (3.9 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of period | $ | 1.5 |  |  | $ | 15.3 |  |  | $ | 21.0 |  |  | $ | — |  |  | $ | 37.8 |  |

[0001069202-13-000011:notes:202]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 21.4 |  |  | $ | 83.4 |  |  | $ | (40.4 | ) |  | $ | — |  |  | $ | 64.4 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (21.5 | ) |  | (6.5 | ) |  | — |  |  | (28.0 | ) |
| Net proceeds from sale of businesses | — |  |  | 10.1 |  |  | — |  |  | — |  |  | 10.1 |  |
| Net cash used in discontinued operations | — |  |  | (0.4 | ) |  | 0.1 |  |  | — |  |  | (0.3 | ) |
| Net cash used in investing activities | — |  |  | (11.7 | ) |  | (6.4 | ) |  | — |  |  | (18.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 480.0 |  |  | — |  |  | 480.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (455.0 | ) |  | — |  |  | (455.0 | ) |
| Long-term debt payments | — |  |  | (0.6 | ) |  | (0.3 | ) |  | — |  |  | (0.9 | ) |
| Borrowings from revolving credit facility | 696.0 |  |  | — |  |  | — |  |  | — |  |  | 696.0 |  |
| Payments on revolving credit facility | (706.0 | ) |  | — |  |  | — |  |  | — |  |  | (706.0 | ) |
| Proceeds from employee stock purchases | 0.3 |  |  | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Repurchases of common stock | (35.0 | ) |  | — |  |  | — |  |  | — |  |  | (35.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (3.4 | ) |  | — |  |  | — |  |  | — |  |  | (3.4 | ) |
| Excess tax benefits related to share-based payments | 1.7 |  |  | — |  |  | — |  |  | — |  |  | 1.7 |  |
| Intercompany debt | (5.3 | ) |  | (3.9 | ) |  | 9.2 |  |  | — |  |  | — |  |
| Intercompany financing activity | 57.8 |  |  | (55.3 | ) |  | (2.5 | ) |  | — |  |  | — |  |
| Cash dividends paid | (27.5 | ) |  | — |  |  | — |  |  | — |  |  | (27.5 | ) |
| Net cash used in financing activities | (21.4 | ) |  | (59.8 | ) |  | 32.7 |  |  | — |  |  | (48.5 | ) |
| Decrease in cash and cash equivalents | — |  |  | 11.9 |  |  | (14.1 | ) |  | — |  |  | (2.2 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 6.0 |  |  | — |  |  | 6.0 |  |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 9.7 |  |  | 34.3 |  |  | — |  |  | 45.0 |  |
| Cash and cash equivalents, end of period | $ | 1.0 |  |  | $ | 21.6 |  |  | $ | 26.2 |  |  | $ | — |  |  | $ | 48.8 |  |


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0001069202-13-000011:notes:203]
[same as prior period, unchanged from 0001069202-13-000008:notes:202]

[0001069202-13-000011:notes:204]
[same as prior period, unchanged from 0001069202-13-000008:notes:203]

[0001069202-13-000011:notes:205]
[same as prior period, unchanged from 0001069202-13-000008:notes:204]

[0001069202-13-000011:notes:206]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd.  The primary subsidiary for the U.S. Service Experts business had previously been included as a "Guarantor Subsidiary" and the Canada Service Experts subsidiary had previously been included as a "Non-Guarantor Subsidiary."  As of September 30, 2013, the U.S. and Canada Service Experts businesses were included in discontinued operations of the condensed consolidating financial statements.

[0001069202-13-000011:notes:207]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.
