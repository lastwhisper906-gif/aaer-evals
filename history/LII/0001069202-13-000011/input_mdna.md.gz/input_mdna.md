# LII MD&A — 0001069202-13-000011


## mdna

[0001069202-13-000011:mdna:1]
[same as prior period, unchanged from 0001069202-13-000008:mdna:1]

[0001069202-13-000011:mdna:2]
[same as prior period, unchanged from 0001069202-13-000008:mdna:2]

[0001069202-13-000011:mdna:3]
[same as prior period, unchanged from 0001069202-13-000008:mdna:3]

[0001069202-13-000011:mdna:4]
[same as prior period, unchanged from 0001069202-13-000008:mdna:4]

[0001069202-13-000011:mdna:5]
[same as prior period, unchanged from 0001069202-13-000008:mdna:5]

[0001069202-13-000011:mdna:6]
[same as prior period, unchanged from 0001069202-13-000008:mdna:6]

[0001069202-13-000011:mdna:7]
[same as prior period, unchanged from 0001069202-13-000008:mdna:7]

[0001069202-13-000011:mdna:8]
The Residential Heating & Cooling segment continued to lead our overall operational performance in the third quarter of 2013, with a 12% increase in net sales and a $19 million increase in segment profit compared to the third quarter of 2012.  The primary growth drivers for this segment were industry growth in replacement and new construction markets.  Our Commercial Heating & Cooling segment also performed well in the third quarter of 2013 with a 9% increase in net sales and $7 million in increased segment profit compared to the third quarter of 2012.  This segment's profits were up largely due to volume increases and material cost savings.  Sales in our Refrigeration segment were down 4% and segment profit decreased $1 million compared to the third quarter of 2012.  This segment's profit decreased primarily due to volume declines partially offset by material cost savings.

[0001069202-13-000011:mdna:9]
On a consolidated basis, our product profit margin improved quarter over quarter due to volume increases primarily in our Residential Heating & Cooling and Commercial Heating & Cooling segments, favorable price and mix in our Residential Heating & Cooling segment and favorable commodity and non-commodity material cost savings across all of our segments.  The third

[0001069202-13-000011:mdna:10]
quarter results reflect the continued management of our cost structure through the utilization of commodity hedging and controllable product cost management initiatives.

[0001069202-13-000011:mdna:11]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer") in an all cash transaction for proceeds, excluding transaction costs, of $10.4 million.  The proceeds included a determinable working capital adjustment of $3.8 million.  The gain on sale of the business and the operating results for the business through March 22, 2013 are presented in discontinued operations.  The Company also entered into a two-year equipment and parts supply agreement with the Buyer.

[0001069202-13-000011:mdna:12]
[same as prior period, unchanged from 0001069202-13-000008:mdna:11]

[0001069202-13-000011:mdna:13]
| • | Net sales increased $58 million, or 7%, from $810 million in the third quarter of 2012 to $868 million in the third quarter of 2013. Net sales increased 8% when excluding a 1% unfavorable foreign currency exchange rate impact. |

[0001069202-13-000011:mdna:14]
| • | Operational income from continuing operations for the third quarter of 2013 was $104 million compared to $81 million for the third quarter of 2012. The increase was primarily due to higher volumes, higher gross profit margins from favorable price and mix and product cost savings, partially offset by higher freight and distribution costs and higher incentive compensation due to overall improved operating results in 2013. |

[0001069202-13-000011:mdna:15]
| • | Net income for the third quarter of 2013 was $64 million compared to $29 million in the third quarter of 2012. |

[0001069202-13-000011:mdna:16]
| • | Diluted earnings per share from continuing operations were $1.30 per share in the third quarter of 2013 compared to $0.97 per share in the third quarter of 2012. |

[0001069202-13-000011:mdna:17]
| • | Cash provided by operating activities was $65 million in the first nine months of 2013 compared to $64 million in the first nine months of 2012. |

[0001069202-13-000011:mdna:18]
Third Quarter of 2013 Compared to Third Quarter of 2012 - Consolidated Results

[0001069202-13-000011:mdna:19]
[same as prior period, unchanged from 0001069202-13-000008:mdna:18]

[0001069202-13-000011:mdna:20]
|  | For the Three Months Ended September 30, |
|  | Dollars |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net sales | $ | 868.0 |  |  | $ | 809.7 |  |  | 7.2 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 630.6 |  |  | 604.8 |  |  | (4.3 | ) |  | 72.6 |  |  | 74.7 |  |
| Gross profit | 237.4 |  |  | 204.9 |  |  | 15.9 |  |  | 27.4 |  |  | 25.3 |  |
| Selling, general and administrative expenses | 136.9 |  |  | 125.9 |  |  | (8.7 | ) |  | 15.8 |  |  | 15.5 |  |
| Losses and other expenses, net | (0.3 | ) |  | 0.3 |  |  | (200.0 | ) |  | — |  |  | — |  |
| Restructuring charges | 0.3 |  |  | 0.4 |  |  | 25.0 |  |  | — |  |  | — |  |
| Income from equity method investments | (3.3 | ) |  | (2.6 | ) |  | 26.9 |  |  | (0.4 | ) |  | (0.3 | ) |
| Operational income from continuing operations | $ | 103.8 |  |  | $ | 80.9 |  |  | 28.3 | % |  | 12.0 | % |  | 10.0 | % |

[0001069202-13-000011:mdna:21]
[same as prior period, unchanged from 0001069202-13-000008:mdna:20]

[0001069202-13-000011:mdna:22]
Net sales increased 7% in the third quarter of 2013 compared to the third quarter of 2012.  Our sales volume was up 6% and price and mix were up 2% from the comparable period.  The increase in volume was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-13-000011:mdna:23]
[same as prior period, unchanged from 0001069202-13-000008:mdna:22]

[0001069202-13-000011:mdna:24]
Gross profit margins improved 210 basis points to 27.4% in the third quarter of 2013 compared to 25.3% in the third quarter of 2012.  Improved price and mix contributed 130 basis points to profit margin and improved commodity and non-commodity product costs contributed a collective 160 basis points.  Partially offsetting these increases were 60 basis points of higher freight and distribution costs and 20 basis points of unfavorable warranty accrual adjustments.

[0001069202-13-000011:mdna:25]
[same as prior period, unchanged from 0001069202-13-000008:mdna:24]

[0001069202-13-000011:mdna:26]
Selling, General & Administrative (“SG&A”) expenses increased $11 million in the third quarter of 2013 compared to the third quarter of 2012.  As a percentage of net sales, SG&A expenses increased 30 basis points from 15.5% to 15.8% in the same periods.  The largest driver of the increase in SG&A expenses was higher incentive compensation due to overall improved operating results in 2013.

[0001069202-13-000011:mdna:27]
Losses (gains) and Other Expenses, Net

[0001069202-13-000011:mdna:28]
Losses (gains) and other expenses, net for third quarters of 2013 and 2012 included the following (in millions):

[0001069202-13-000011:mdna:29]
|  | For the Three Months Ended September 30, |
|  | 2013 |  | 2012 |
| Realized losses on settled futures contracts | $ | 0.4 |  |  | $ | 0.5 |  |
| Foreign currency exchange loss (gain) | (0.5 | ) |  | 1.0 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (1.1 | ) |  | (1.4 | ) |
| Special legal contingency charge | 0.8 |  |  | — |  |
| Other items, net | 0.1 |  |  | 0.2 |  |
| Losses (gains) and other expenses, net | $ | (0.3 | ) |  | $ | 0.3 |  |

[0001069202-13-000011:mdna:30]
The decrease in realized losses on settled futures contracts in the third quarter of 2013 was attributable to increases in commodity prices relative to our settled futures contract prices.  Conversely, the decrease in unrealized gains on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000011:mdna:31]
[same as prior period, unchanged from 0001069202-13-000008:mdna:31]

[0001069202-13-000011:mdna:32]
We incurred minimal restructuring charges in the third quarter of 2013 or 2012.  We have not initiated any significant new projects in 2013 and our significant ongoing projects were substantially completed as of September 30, 2013.  For more information on our restructuring activity, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000011:mdna:33]
[same as prior period, unchanged from 0001069202-13-000008:mdna:33]

[0001069202-13-000011:mdna:34]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments of $3 million in the third quarter of 2013 was comparable to the third quarter of 2012.

[0001069202-13-000011:mdna:35]
[same as prior period, unchanged from 0001069202-13-000008:mdna:35]

[0001069202-13-000011:mdna:36]
Interest expense, net of $4 million in the third quarter of 2013 declined slightly compared to the third quarter of 2012.  Our weighted average borrowings declined slightly and interest rates were relatively flat over the comparable periods.

[0001069202-13-000011:mdna:37]
[same as prior period, unchanged from 0001069202-13-000008:mdna:37]

[0001069202-13-000011:mdna:38]
The income tax provision was $34 million in the third quarter of 2013 compared to $27 million in the third quarter of 2012.  The effective tax rate was 34.2% for the third quarter of 2013 compared to 35.0% for the third quarter of 2012.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, such as tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-13-000011:mdna:39]
[same as prior period, unchanged from 0001069202-13-000008:mdna:39]

[0001069202-13-000011:mdna:40]
The Loss from discontinued operations related to the Service Experts business sold in March 2013 and the Hearth business sold in April 2012.  In the third quarter of 2013, there were $2 million of pre-tax losses from discontinued operations consisting of various divestiture-related expenses for the Service Experts business.  The Hearth business had no significant gains, losses or other activity in the third quarter of 2013.

[0001069202-13-000011:mdna:41]
In the third quarter of 2012, there were pre-tax losses of $25 million consisting of $27 million of losses related to the Service Experts business and $2 million of income related to the Hearth business.  The $27 million loss related to the Service Experts business included operating losses of $6 million and a goodwill impairment charge of $21 million.  The $2 million of income related to the Hearth business included a $3 million gain related to a working capital adjustment offset by $1 million of other divestiture-related expenses.

[0001069202-13-000011:mdna:42]
Third Quarter of 2013 Compared to Third Quarter of 2012 - Results by Segment

[0001069202-13-000011:mdna:43]
[same as prior period, unchanged from 0001069202-13-000008:mdna:43]

[0001069202-13-000011:mdna:44]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2013 and 2012 (dollars in millions):

[0001069202-13-000011:mdna:45]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 433.9 |  |  | $ | 386.3 |  |  | $ | 47.6 |  |  | 12.3 | % |
| Profit | $ | 57.0 |  |  | $ | 37.7 |  |  | $ | 19.3 |  |  | 51.2 | % |
| % of net sales | 13.1 | % |  | 9.8 | % |  |  |  |  |

[0001069202-13-000011:mdna:46]
Residential Heating & Cooling net sales increased by 12% in the third quarter of 2013 compared to the third quarter of 2012.  Sales volumes increased by 9%, primarily attributable to industry growth in replacement and new construction markets, and sales price and mix improved a collective 4% due to price increases and a moderation of downward mix pressures from lower efficiency product sales.  Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-13-000011:mdna:47]
Segment profit for the third quarter of 2013 increased $19 million due to $9 million in higher sales volumes, $8 million in commodity and non-commodity product cost savings and $10 million in favorable price and mix.  Partially offsetting these increases were $4 million in higher SG&A costs due primarily to higher employee compensation costs and $4 million of higher freight and distribution expenses due to continued investment in distribution initiatives.

[0001069202-13-000011:mdna:48]
[same as prior period, unchanged from 0001069202-13-000008:mdna:48]

[0001069202-13-000011:mdna:49]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2013 and 2012 (dollars in millions):

[0001069202-13-000011:mdna:50]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 239.1 |  |  | $ | 219.7 |  |  | $ | 19.4 |  |  | 8.8 | % |
| Profit | $ | 39.2 |  |  | $ | 32.5 |  |  | $ | 6.7 |  |  | 20.6 | % |
| % of net sales | 16.4 | % |  | 14.8 | % |  |  |  |  |

[0001069202-13-000011:mdna:51]
Commercial Heating & Cooling net sales increased 9% in the third quarter of 2013 compared to the third quarter of 2012 due  to increased sales volumes of 8% attributable to broad-based volume increases in North America partially offset by continued weakness in European markets.  Also, changes in foreign currency exchange rates favorably impacted net sales by 1%.

[0001069202-13-000011:mdna:52]
Segment profit in the third quarter of 2013 increased $7 million compared to the third quarter of 2012 due to $6 million in higher sales volumes, $3 million in commodity and non-commodity material cost savings and $1 million in other product cost savings.  Partially offsetting these increases were $2 million of higher SG&A costs and $1 million in higher freight and distribution expenses.

[0001069202-13-000011:mdna:53]
[same as prior period, unchanged from 0001069202-13-000008:mdna:53]

[0001069202-13-000011:mdna:54]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2013 and 2012 (dollars in millions):

[0001069202-13-000011:mdna:55]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 195.0 |  |  | $ | 203.7 |  |  | $ | (8.7 | ) |  | (4.3 | )% |
| Profit | $ | 23.9 |  |  | $ | 25.1 |  |  | $ | (1.2 | ) |  | (4.8 | )% |
| % of net sales | 12.3 | % |  | 12.3 | % |  |  |  |  |

[0001069202-13-000011:mdna:56]
Refrigeration net sales declined 4% in the third quarter of 2013 compared to the third quarter of 2012 due primarily to unfavorable foreign currency exchange rates and volume declines.  Foreign currency exchange rates had a 2% unfavorable impact and volumes declined 2% because of continued weakness with certain supermarket customers and soft market conditions in Europe and Australia.  In Australia, we have seen the economy slow further, and after the latest national election and government changeover, lawmakers have drafted legislation to repeal the carbon tax in that country.  We have experienced a slowdown in our Australian refrigeration wholesale business, including our refrigerant operations.

[0001069202-13-000011:mdna:57]
Segment profit for the third quarter of 2013 decreased $1 million over the third quarter of 2012.  In the third quarter of 2013 segment profit increased $1 million for favorable price and mix, $5 million from commodity and non-commodity material cost savings, and $1 million from growth in the Australia wholesale refrigerant business which continued to benefit from one-time purchases of lower cost inventory and investments in related operations.  These improvements were offset by $3 million from higher SG&A expenses and $5 million from volume-related declines.

[0001069202-13-000011:mdna:58]
[same as prior period, unchanged from 0001069202-13-000008:mdna:58]

[0001069202-13-000011:mdna:59]
Corporate and other expenses increased approximately $3 million to $17 million in the third quarter of 2013 from $14 million in the third quarter of 2012.  The increase was primarily driven by an increase in incentive compensation due to improved overall operating results.

[0001069202-13-000011:mdna:60]
Year-to-Date through September 30, 2013 Compared to Year-to-Date through September 30, 2012 - Consolidated Results

[0001069202-13-000011:mdna:61]
[same as prior period, unchanged from 0001069202-13-000008:mdna:61]

[0001069202-13-000011:mdna:62]
|  | For the Nine Months Ended September 30, |
|  | Dollars |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net sales | $ | 2,449.5 |  |  | $ | 2,264.5 |  |  | 8.2 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,796.1 |  |  | 1,710.6 |  |  | (5.0 | ) |  | 73.3 |  |  | 75.5 |  |
| Gross profit | 653.4 |  |  | 553.9 |  |  | 18.0 |  |  | 26.7 |  |  | 24.5 |  |
| Selling, general and administrative expenses | 424.0 |  |  | 379.8 |  |  | (11.6 | ) |  | 17.3 |  |  | 16.8 |  |
| Losses and other expenses, net | 2.8 |  |  | 0.2 |  |  | (1,300.0 | ) |  | 0.1 |  |  | — |  |
| Restructuring charges | 3.2 |  |  | 3.1 |  |  | (3.2 | ) |  | 0.1 |  |  | 0.1 |  |
| Income from equity method investments | (10.7 | ) |  | (8.8 | ) |  | 21.6 |  |  | (0.4 | ) |  | (0.4 | ) |
| Operational income from continuing operations | $ | 234.1 |  |  | $ | 179.6 |  |  | 30.3 | % |  | 9.6 | % |  | 7.9 | % |

[0001069202-13-000011:mdna:63]
[same as prior period, unchanged from 0001069202-13-000008:mdna:63]

[0001069202-13-000011:mdna:64]
Net sales increased 8% in the first nine months of 2013 compared to the first nine months of 2012.  Sales volumes were up 6% and price and mix were up 2% from the comparable period.  The increase in volumes was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  The increase in price and mix was driven by a combination of price increases and a moderation of downward mix pressures from lower efficiency product sales in our Residential Heating & Cooling segment as well as improvements in the Refrigeration segment's Australia refrigerant distribution business.

[0001069202-13-000011:mdna:65]
[same as prior period, unchanged from 0001069202-13-000008:mdna:65]

[0001069202-13-000011:mdna:66]
Gross profit margins improved 220 basis points to 26.7% in the first nine months of 2013 compared to 24.5% in the first nine months of 2012.  Improved price and mix contributed 170 basis points to profit margin and improved commodity and non-commodity product costs contributed a collective 140 basis points.  Partially offsetting these increases were 90 basis points of higher freight and distribution costs.

[0001069202-13-000011:mdna:67]
[same as prior period, unchanged from 0001069202-13-000008:mdna:68]

[0001069202-13-000011:mdna:68]
Selling, General & Administrative (“SG&A”) expenses increased by $44 million in the first nine months of 2013 compared to the first nine months of 2012.  As a percentage of net sales, SG&A expenses increased 50 basis points from 16.8% to 17.3% in the same periods.  The increase in SG&A expenses was principally due to higher employee compensation due to overall improved operating results in 2013.

[0001069202-13-000011:mdna:69]
Losses (gains) and Other Expenses, Net

[0001069202-13-000011:mdna:70]
Losses (gains) and other expenses, net for first nine months of 2013 and 2012 included the following (in millions):

[0001069202-13-000011:mdna:71]
|  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |
| Realized losses on settled futures contracts | $ | 0.8 |  |  | $ | 1.4 |  |
| Foreign currency exchange loss | — |  |  | 0.7 |  |
| Loss on disposal of fixed assets | — |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.7 |  |  | (2.5 | ) |
| Special legal contingency charge | 1.0 |  |  | — |  |
| Other items, net | 0.3 |  |  | 0.5 |  |
| Losses (gains) and other expenses, net | $ | 2.8 |  |  | $ | 0.2 |  |

[0001069202-13-000011:mdna:72]
The decline in realized losses on settled futures contracts in the first nine months of 2013 was attributable to increases in commodity prices relative to our settled futures contract prices.  Conversely, the change in unrealized losses (gains) on unsettled futures contracts was primarily due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000011:mdna:73]
The special legal contingency charge in 2013 relates to ongoing patent litigation.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for more information on this litigation.

[0001069202-13-000011:mdna:74]
[same as prior period, unchanged from 0001069202-13-000008:mdna:75]

[0001069202-13-000011:mdna:75]
Restructuring charges were $3 million in the first nine months of 2013 and $3 million in the first nine months of 2012.  We have not initiated any significant new projects in 2013 and the charges in both years related primarily to our Regional Distribution Network project.  For more information on our restructuring activities, see Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000011:mdna:76]
[same as prior period, unchanged from 0001069202-13-000008:mdna:77]

[0001069202-13-000011:mdna:77]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments increased slightly to $11 million in the first nine months of 2013 compared to $9 million in the first nine months of 2012 primarily due to improved operational performance from our joint ventures.

[0001069202-13-000011:mdna:78]
[same as prior period, unchanged from 0001069202-13-000008:mdna:79]

[0001069202-13-000011:mdna:79]
Interest expense, net of $11 million in the first nine months of 2013 declined from $13 million in the first nine months of 2012 due to a decrease in our weighted average borrowings in the comparable periods.  Our weighted average interest rates were relatively flat.

[0001069202-13-000011:mdna:80]
[same as prior period, unchanged from 0001069202-13-000008:mdna:81]

[0001069202-13-000011:mdna:81]
The income tax provision was $78 million in the first nine months of 2013 compared to $58 million in the first nine months of 2012.  The effective tax rate remained unchanged at 34.7% for the first nine months of 2013 compared to the first nine months of 2012.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, such as tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-13-000011:mdna:82]
[same as prior period, unchanged from 0001069202-13-000008:mdna:83]

[0001069202-13-000011:mdna:83]
The Loss from discontinued operations related to the Service Experts business sold in March 2013 and the Hearth business sold in April 2012.  In the first nine months of 2013, there were $16 million of pre-tax losses from discontinued operations consisting primarily of operating losses in the Service Experts business.  The Hearth business had no significant gains, losses or other activity in the first nine months of 2013.

[0001069202-13-000011:mdna:84]
In the first nine months of 2012, there were pre-tax losses of $57 million consisting of $43 million of operating losses related to the Service Experts business and $14 million of losses related to the Hearth business.  The $14 million of losses related to the Hearth business included operating losses of $2 million, a $6 million charge to write down certain long-lived assets to their fair value and a $6 million pension settlement charge for the realization of pension losses related to the transfer of a pension to the buyer of the business.

[0001069202-13-000011:mdna:85]
Year-to-Date through September 30, 2013 Compared to Year-to-Date through September 30, 2012 - Results by Segment

[0001069202-13-000011:mdna:86]
[same as prior period, unchanged from 0001069202-13-000008:mdna:88]

[0001069202-13-000011:mdna:87]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first nine months of 2013 and 2012 (dollars in millions):

[0001069202-13-000011:mdna:88]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 1,224.5 |  |  | $ | 1,070.7 |  |  | $ | 153.8 |  |  | 14.4 | % |
| Profit | $ | 143.7 |  |  | $ | 90.7 |  |  | $ | 53.0 |  |  | 58.4 | % |
| % of net sales | 11.7 | % |  | 8.5 | % |  |  |  |  |

[0001069202-13-000011:mdna:89]
Residential Heating & Cooling net sales increased by 14% in the first nine months of 2013 compared to the first nine months of 2012.  Sales volume increases contributed 12% and were attributable primarily to industry growth in new construction and replacement markets.  Sales price and mix improvements also contributed 2% due to price increases and a moderation of downward mix pressures from lower efficiency product sales.

[0001069202-13-000011:mdna:90]
Segment profit for the first nine months of 2013 increased $53 million due to $36 million in higher sales volumes, $17 million from favorable price and mix, $28 million in commodity and non-commodity product cost savings and $1 million from a favorable warranty accrual adjustment.  Partially offsetting these increases were $14 million in higher SG&A costs due primarily to higher advertising and employee compensation costs and $15 million of higher freight and distribution expenses due to continued investment in distribution initiatives.

[0001069202-13-000011:mdna:91]
[same as prior period, unchanged from 0001069202-13-000008:mdna:93]

[0001069202-13-000011:mdna:92]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first nine months of 2013 and 2012 (dollars in millions):

[0001069202-13-000011:mdna:93]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 631.8 |  |  | $ | 597.9 |  |  | $ | 33.9 |  |  | 5.7 | % |
| Profit | $ | 84.8 |  |  | $ | 74.1 |  |  | $ | 10.7 |  |  | 14.4 | % |
| % of net sales | 13.4 | % |  | 12.4 | % |  |  |  |  |

[0001069202-13-000011:mdna:94]
Commercial Heating & Cooling net sales increased 6% in the first nine months of 2013 compared to the first nine months of 2012.  The increase was due to broad-based volume increases in North America, partially offset by continued weakness in European markets.

[0001069202-13-000011:mdna:95]
Segment profit in the first nine months of 2013 increased $11 million compared to the first nine months of 2012 due to increases of $11 million for higher sales volumes, $5 million for favorable commodity and non-commodity product costs and $3 million for favorable price and mix.  Partially offsetting these increases were $3 million of higher freight and distribution expenses due to continued investment in distribution initiatives and $5 million of higher SG&A costs.

[0001069202-13-000011:mdna:96]
[same as prior period, unchanged from 0001069202-13-000008:mdna:98]

[0001069202-13-000011:mdna:97]
The following table presents our Refrigeration segment's net sales and profit for the first nine months of 2013 and 2012 (dollars in millions):

[0001069202-13-000011:mdna:98]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 593.2 |  |  | $ | 595.9 |  |  | $ | (2.7 | ) |  | (0.5 | )% |
| Profit | $ | 66.5 |  |  | $ | 60.6 |  |  | $ | 5.9 |  |  | 9.7 | % |
| % of net sales | 11.2 | % |  | 10.2 | % |  |  |  |  |

[0001069202-13-000011:mdna:99]
Refrigeration net sales were down approximately 1% in the first nine months of 2013 compared to the first nine months of 2012.  Foreign currency exchange rates had a 1% unfavorable impact and volumes declined 2% over the same periods.  Sales volumes declined because of continued weakness with certain supermarket customers and soft market conditions in Europe.  These declines were partially offset by growth of 2% in the Australia wholesale refrigerant business.

[0001069202-13-000011:mdna:100]
Segment profit for the first nine months of 2013 increased $6 million over the first nine months of 2012, with increases of $10 million from growth in the Australia wholesale refrigerant business which benefited from one-time purchases of lower cost inventory and investments in related operations, increases of $6 million from favorable price and mix and increases of $7 million from favorable commodity and non-commodity material costs.  Partially offsetting these increases were $9 million of higher SG&A expenses related to investments in cost savings initiatives, $7 million of volume-related declines and $1 million of higher freight and distribution expenses.

[0001069202-13-000011:mdna:101]
[same as prior period, unchanged from 0001069202-13-000008:mdna:103]

[0001069202-13-000011:mdna:102]
Corporate and other expenses increased to $56 million in the first nine months of 2013 from $44 million in the first nine months of 2012 driven by an increase of $12 million in incentive compensation due to improved overall operating results in 2013.

[0001069202-13-000011:mdna:103]
[same as prior period, unchanged from 0001069202-13-000008:mdna:105]

[0001069202-13-000011:mdna:104]
[same as prior period, unchanged from 0001069202-13-000008:mdna:106]

[0001069202-13-000011:mdna:105]
[same as prior period, unchanged from 0001069202-13-000008:mdna:107]

[0001069202-13-000011:mdna:106]
The following table summarizes our cash flow activity for the nine months ended September 30, 2013 and 2012 (in millions):

[0001069202-13-000011:mdna:107]
|  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |
| Net cash provided by operating activities | $ | 65.0 |  |  | $ | 64.4 |  |
| Net cash used in investing activities | (32.9 | ) |  | (18.1 | ) |
| Net cash used in financing activities | (42.2 | ) |  | (48.5 | ) |

[0001069202-13-000011:mdna:108]
Net Cash Provided by Operating Activities.  Net cash provided by operating activities increased approximately $1 million to $65 million in the first nine months of 2013 compared to $64 million in the first nine months of 2012.  This increase was primarily attributable to higher net income partially offset by increased working capital requirements.  Working capital was higher in the first nine months of 2013 primarily because of increases in accounts receivable due to higher sales volumes period over period.

[0001069202-13-000011:mdna:109]
Net Cash Used in Investing Activities.  Capital expenditures were $41 million and $28 million in the first nine months of 2013 and 2012, respectively.  Capital expenditures in 2013 were primarily investments in our distribution network, investments in systems and software to support the overall enterprise and an expansion of manufacturing capacity.  Net cash used in investing activities also included net proceeds of $8 million from the sale of the Service Experts business in the first quarter of 2013.

[0001069202-13-000011:mdna:110]
Net Cash Used in Financing Activities.  Net cash used in financing activities decreased to $42 million in the first nine months of 2013 primarily due to an increase in net borrowings partially offset by an increase in stock repurchases.  The net borrowings were higher in 2013 to support the increasing sales and the rise in working capital requirements.

[0001069202-13-000011:mdna:111]
[same as prior period, unchanged from 0001069202-13-000008:mdna:114]

[0001069202-13-000011:mdna:112]
[same as prior period, unchanged from 0001069202-13-000008:mdna:119]

[0001069202-13-000011:mdna:113]
The following table details our lines of credit and financing arrangements as of September 30, 2013 (in millions):

[0001069202-13-000011:mdna:114]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-Term Debt: |  |  |  |  |  |
| Foreign obligations | $ | 27.2 |  |  | $ | 7.9 |  |  | $ | 19.3 |  |
| Asset Securitization Program (1) | 160.0 |  |  | 160.0 |  |  | — |  |
| Total short-term debt | $ | 187.2 |  |  | $ | 167.9 |  |  | $ | 19.3 |  |
| Current Maturities: |  |  |  |  |  |
| Capital lease obligations | $ | 0.8 |  |  | $ | 0.8 |  |  | $ | — |  |
| Long-Term Debt: |  |  |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.7 |  |  | $ | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 49.5 |  |  | 567.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 866.7 |  |  | 266.2 |  |  | 567.0 |  |
| Total debt | $ | 1,054.7 |  |  | $ | 434.9 |  |  | $ | 586.3 |  |

[0001069202-13-000011:mdna:115]
[same as prior period, unchanged from 0001069202-13-000008:mdna:117]

[0001069202-13-000011:mdna:116]
(2) The available future borrowings on our domestic revolving credit facility were reduced by $33.5 million in outstanding standby letters of credit.  We had an additional $26.0 million in outstanding standby letters of credit with other banks.

[0001069202-13-000011:mdna:117]
[same as prior period, unchanged from 0001069202-13-000008:mdna:120]

[0001069202-13-000011:mdna:118]
Our debt-to-total-capital ratio increased to 47.4% at September 30, 2013 compared to 43.7% at December 31, 2012.  The increase in the ratio in the first nine months of 2013 is due to the increase in our net borrowings, as noted above, as well as a decrease in equity primarily related to changes in foreign currency translation adjustments within accumulated other comprehensive income into net income.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on these changes in foreign currency translation adjustments.  We evaluate our debt-to-capital ratio as well as our debt-to-EBITDA ratio in order to determine the appropriate targets for share repurchases under our share repurchase programs.  Our senior credit ratings were investment grade as of September 30, 2013 and our goal is to maintain investment grade ratings.

[0001069202-13-000011:mdna:119]
[same as prior period, unchanged from 0001069202-13-000008:mdna:122]

[0001069202-13-000011:mdna:120]
We believe our available future borrowings, our cash of $38 million and future cash generated from operations are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $38 million as of September 30, 2013 was $21 million of cash held in foreign locations.  Our cash in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and to pay taxes in the United States for the amounts that were repatriated.

[0001069202-13-000011:mdna:121]
Our expected capital expenditures for 2013 are $60 million including investments in additional manufacturing capacity.  We also continue to increase shareholder value through dividend payments and our share repurchase programs.  In 2013, we are targeting approximately $125 million in share repurchases under the existing share repurchase programs and over $30 million of dividend payments.

[0001069202-13-000011:mdna:122]
[same as prior period, unchanged from 0001069202-13-000008:mdna:125]

[0001069202-13-000011:mdna:123]
[same as prior period, unchanged from 0001069202-13-000008:mdna:126]

[0001069202-13-000011:mdna:124]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019.  The agreement provides for financial covenants consistent with our credit agreement and we were in compliance with those covenants as of September 30, 2013.  The lease is classified as an operating lease and we expect to realize annual savings of approximately $2 million in net rent costs from this renewal compared to our previous leasing arrangement.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for more details.

[0001069202-13-000011:mdna:125]
Commitments, Contingencies and Guarantees

[0001069202-13-000011:mdna:126]
For more information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000011:mdna:127]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts known and do not believe that any current, pending or threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Litigation, however, involves uncertainties and it is possible that the eventual outcome of litigation could adversely affect our results of operations for a particular period.

[0001069202-13-000011:mdna:128]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we

[0001069202-13-000011:mdna:129]
maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. We also have product liability insurance policies with limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance.

[0001069202-13-000011:mdna:130]
The estimate of our liability for future warranty costs requires us to make significant assumptions about the amount, timing and nature of the costs we will incur in the future. We periodically review the assumptions used to determine the liability and adjust our assumptions based upon factors such as actual failure rates and cost experience. Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, and changes in manufacturing techniques or locations, components or suppliers used. In recent years, changes in the warranty liability as the result of the issuance of new warranties and the payments made have remained relatively stable. Should actual warranty costs differ from our estimates, we may be required to record adjustments to accruals and expense in the future.  We evaluate our heating, ventilation and air conditioning warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.

[0001069202-13-000011:mdna:131]
We also may incur costs related to our products that are not covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products with quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications. We have product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue.  As of September 30, 2013, we have $5.9 million accrued for these matters. We may incur additional charges in the future as more information becomes available.

[0001069202-13-000011:mdna:132]
[same as prior period, unchanged from 0001069202-13-000008:mdna:133]

[0001069202-13-000011:mdna:133]
[same as prior period, unchanged from 0001069202-13-000008:mdna:134]
