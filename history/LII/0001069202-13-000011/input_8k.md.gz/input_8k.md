# LII 8-K — 0001193125-13-404683 filed 2013-10-21

## item codes, every 8-K on or before 2013-10-21

- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2013-10-21

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-13-404683:8k_2_02:1]
EX-99.1
2
d613030dex991.htm
EX-99.1

[0001193125-13-404683:8k_2_02:2]
EX-99.1

[0001193125-13-404683:8k_2_02:3]
Exhibit 99.1

[0001193125-13-404683:8k_2_02:4]
Lennox International Reports Third Quarter EPS from Continuing Operations Up 34%

[0001193125-13-404683:8k_2_02:5]
| • |  | Revenue up 8% at constant currency, led by 13% Residential growth |

[0001193125-13-404683:8k_2_02:6]
| • |  | Total segment profit margin up 190 basis points to record 11.9% |

[0001193125-13-404683:8k_2_02:7]
| • |  | Adjusted and GAAP EPS from continuing operations of $1.30, up 34% |

[0001193125-13-404683:8k_2_02:8]
| • |  | Repurchased $33 million of stock in the quarter and raising repurchase guidance from $100 million to $125 million for 2013 |

[0001193125-13-404683:8k_2_02:9]
| • |  | Raising low end of 2013 adjusted EPS from continuing operations guidance, from $3.45-$3.75 to a range of $3.50-$3.75 |

[0001193125-13-404683:8k_2_02:10]
DALLAS, October 21, 2013 – Lennox International Inc. (NYSE: LII) today reported financial results for the third quarter of 2013. Financial results
in prior periods have been revised to reflect sold businesses in discontinued operations.

[0001193125-13-404683:8k_2_02:11]
Revenue for the third quarter was $868 million, up 8% at
constant currency from the prior-year quarter and up 7% including the negative impact of foreign exchange. Both adjusted and GAAP earnings per share from continuing operations were $1.30, compared to $0.97 in the prior-year quarter, up 34% to a
record GAAP EPS.

[0001193125-13-404683:8k_2_02:12]
“Lennox International’s strong business momentum continued in the third quarter, with revenue up 8% from the prior-year
quarter at constant currency and total segment profit margin up 190 basis points to a record level of 11.9%,” said Chairman and CEO Todd Bluedorn. “In our Residential business, revenue was up 13% at constant currency, led by strong
double-digit growth in replacement business with favorable price and mix. Residential margin expanded 330 basis points to 13.1%. Residential profit grew 51%. In our Commercial business, revenue was up 8% at constant currency, led by strong growth in
national account equipment and services, as well as continued momentum in the emergency replacement market. Commercial profit grew 21% as segment margin expanded 160 basis points to a record 16.4%. In Refrigeration, global market conditions remained
choppy. Revenue was down 2% at constant currency on soft market conditions in Australia and Europe. North America was up slightly, and China and South America saw strong growth. Refrigeration profit was down 5%. Refrigeration margin was flat at
12.3%. For the company overall in 2013, given our strong performance year-to-date and current outlook, we are reiterating our revenue growth guidance of 6-8% and raising the low end of adjusted EPS from continuing operations guidance to $3.50-$3.75.
Looking ahead, the company remains strategically well-positioned to capitalize on growth in our major end markets and drive increased profitability through our key operational initiatives.”

[0001193125-13-404683:8k_2_02:13]
FINANCIAL HIGHLIGHTS

[0001193125-13-404683:8k_2_02:14]
Revenue: Revenue for the third quarter was $868 million, up 7% from the prior-year quarter. Foreign exchange had a negative 1 point impact. Volume and
price/mix were up from the prior-year quarter.

[0001193125-13-404683:8k_2_02:15]
Gross Profit: Gross profit for the third quarter was $237 million, up 16% from the prior-year
quarter. Gross margin was 27.4%, up 210 basis points from 25.3% in the prior-year quarter. Gross profit was primarily impacted by higher volume, favorable price/mix and lower material costs, partially offset by investments in distribution.

[0001193125-13-404683:8k_2_02:16]
Income from Continuing Operations: Adjusted income from continuing operations in the third quarter was $65.5 million, or $1.30 per share, compared to
$49.7 million, or $0.97 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the third quarter of 2013 excludes a special legal contingency charge of $0.5 million after-tax, $0.7 million after-tax for the net change
in unrealized gains on unsettled futures contracts, and a $0.1 million gain after-tax for other items, net.

[0001193125-13-404683:8k_2_02:17]
On a GAAP basis, income from continuing
operations for the third quarter was $65.8 million, or $1.30 per share, compared to $49.7 million, or $0.97 per share, in the prior-year quarter.

[0001193125-13-404683:8k_2_02:18]
Free
Cash Flow and Total Debt: Net cash from operations in the third quarter was $153 million, compared to $75 million in the prior-year quarter. The company invested $18 million in capital assets in the third quarter. Free cash flow was
approximately $136 million, compared to $63 million in the prior-year quarter. Total debt at the end of the third quarter was $435 million, and total cash and cash equivalents were $38 million. The company paid $12 million in dividends and
repurchased $33 million of stock in the third quarter.

[0001193125-13-404683:8k_2_02:19]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-13-404683:8k_2_02:20]
Residential Heating & Cooling

[0001193125-13-404683:8k_2_02:21]
Third quarter 2013
revenue in the Residential Heating & Cooling business segment was $434 million, up 12% from the prior-year quarter. Foreign exchange had a negative 1 point impact on revenue growth. Segment profit was $57 million, up 51% from the prior-year
quarter. Segment profit margin was 13.1%, up 330 basis points. Results were primarily impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from higher SG&A and investments in distribution expansion.

[0001193125-13-404683:8k_2_02:22]
Commercial Heating & Cooling

[0001193125-13-404683:8k_2_02:23]
Revenue in the
Commercial Heating & Cooling business segment was $239 million in the third quarter, up 9% from the prior-year quarter. Foreign exchange had a positive 1 point impact on revenue growth. Segment profit was $39 million, up 21% from the
prior-year quarter. Segment profit margin was 16.4%, up 160 basis points. Results were primarily impacted by higher volume and lower material costs, with partial offsets from higher SG&A and investments in distribution expansion.

[0001193125-13-404683:8k_2_02:24]
Refrigeration

[0001193125-13-404683:8k_2_02:25]
Revenue in the Refrigeration business
segment was $195 million in the third quarter, down 4% from the prior-year quarter. Foreign exchange had a negative 2 point impact on revenue. Segment profit was $24 million, down 5% from the prior-year quarter. Segment profit margin was flat at
12.3%. Results were primarily impacted by lower volume and SG&A investments, with a partial offset from lower material costs.

[0001193125-13-404683:8k_2_02:26]
FULL-YEAR OUTLOOK

[0001193125-13-404683:8k_2_02:27]
The company is reiterating its revenue growth guidance and raising the low end of its EPS from continuing operations guidance for 2013.

[0001193125-13-404683:8k_2_02:28]
|  | • |  | Reiterating revenue growth guidance of 6-8%; foreign exchange is still expected to have a neutral impact on revenue on a full-year basis. |

[0001193125-13-404683:8k_2_02:29]
|  | • |  | Raising the low end of adjusted EPS from continuing operations guidance from $3.45-$3.75 to a range of $3.50-$3.75. |

[0001193125-13-404683:8k_2_02:30]
|  | • |  | Raising the low end of GAAP EPS from continuing operations guidance from $3.38-$3.68 to a range of $3.43-$3.68. |

[0001193125-13-404683:8k_2_02:31]
|  | • |  | Reiterating tax rate guidance of 34-35% on a full-year basis. |

[0001193125-13-404683:8k_2_02:32]
|  | • |  | Reiterating capital expenditure guidance of approximately $60 million in 2013. |

[0001193125-13-404683:8k_2_02:33]
|  | • |  | Raising stock repurchase guidance from $100 million to $125 million for 2013, including plans to repurchase $59 million in the fourth quarter. |

[0001193125-13-404683:8k_2_02:34]
|  | • |  | Reiterating average diluted share count guidance of approximately 51 million shares for the full year. |

[0001193125-13-404683:8k_2_02:35]
CONFERENCE CALL INFORMATION

[0001193125-13-404683:8k_2_02:36]
A conference call to discuss the company’s third quarter results will be held this morning at 8:30 a.m. Central time. To listen, dial the conference call
line at 612-332-0630 at least 10 minutes prior to the scheduled start time and use reservation number 303703. The conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com.

[0001193125-13-404683:8k_2_02:37]
A replay will be available from 11:00 a.m. Central time on October 21 through October 28, 2013 by dialing 800-475-6701 (U.S.) or 320-365-3844
(international) and using access code 303703. The call will also be archived on the company’s web site.

[0001193125-13-404683:8k_2_02:38]
Lennox International Inc. is a global leader
in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under the symbol “LII.” Additional information is available at: http://www.lennoxinternational.com or by
contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-13-404683:8k_2_02:39]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-404683:8k_2_02:40]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-13-404683:8k_2_02:41]
(Unaudited)

[0001193125-13-404683:8k_2_02:42]
(In millions, except per share data)

[0001193125-13-404683:8k_2_02:43]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net sales |  | $ | 868.0 |  |  | $ | 809.7 |  |  | $ | 2,449.5 |  |  | $ | 2,264.5 |  |
| Cost of goods sold |  |  | 630.6 |  |  |  | 604.8 |  |  |  | 1,796.1 |  |  |  | 1,710.6 |  |
| Gross profit |  |  | 237.4 |  |  |  | 204.9 |  |  |  | 653.4 |  |  |  | 553.9 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 136.9 |  |  |  | 125.9 |  |  |  | 424.0 |  |  |  | 379.8 |  |
| Losses (gains) and other expenses, net |  |  | (0.3 | ) |  |  | 0.3 |  |  |  | 2.8 |  |  |  | 0.2 |  |
| Restructuring charges |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 3.2 |  |  |  | 3.1 |  |
| Income from equity method investments |  |  | (3.3 | ) |  |  | (2.6 | ) |  |  | (10.7 | ) |  |  | (8.8 | ) |
| Operational income from continuing operations |  |  | 103.8 |  |  |  | 80.9 |  |  |  | 234.1 |  |  |  | 179.6 |  |
| Interest expense, net |  |  | 3.8 |  |  |  | 4.4 |  |  |  | 10.8 |  |  |  | 13.4 |  |
| Other expense (income), net |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 100.0 |  |  |  | 76.5 |  |  |  | 223.4 |  |  |  | 166.1 |  |
| Provision for income taxes |  |  | 34.2 |  |  |  | 26.8 |  |  |  | 77.5 |  |  |  | 57.6 |  |
| Income from continuing operations |  |  | 65.8 |  |  |  | 49.7 |  |  |  | 145.9 |  |  |  | 108.5 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | (2.3 | ) |  |  | (24.6 | ) |  |  | (15.7 | ) |  |  | (57.2 | ) |
| Benefit from income taxes |  |  | (0.8 | ) |  |  | (4.3 | ) |  |  | (6.4 | ) |  |  | (16.7 | ) |
| Loss from discontinued operations |  |  | (1.5 | ) |  |  | (20.3 | ) |  |  | (9.3 | ) |  |  | (40.5 | ) |
| Net income |  | $ | 64.3 |  |  | $ | 29.4 |  |  | $ | 136.6 |  |  | $ | 68.0 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.32 |  |  | $ | 0.98 |  |  | $ | 2.92 |  |  | $ | 2.13 |  |
| Loss from discontinued operations |  |  | (0.03 | ) |  |  | (0.40 | ) |  |  | (0.19 | ) |  |  | (0.79 | ) |
| Net income |  | $ | 1.29 |  |  | $ | 0.58 |  |  | $ | 2.73 |  |  | $ | 1.34 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.30 |  |  | $ | 0.97 |  |  | $ | 2.87 |  |  | $ | 2.11 |  |
| Loss from discontinued operations |  |  | (0.03 | ) |  |  | (0.40 | ) |  |  | (0.18 | ) |  |  | (0.79 | ) |
| Net income |  | $ | 1.27 |  |  | $ | 0.57 |  |  | $ | 2.69 |  |  | $ | 1.32 |  |
| Average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 49.7 |  |  |  | 50.6 |  |  |  | 50.0 |  |  |  | 50.8 |  |
| Diluted |  |  | 50.5 |  |  |  | 51.3 |  |  |  | 50.8 |  |  |  | 51.5 |  |
| Cash dividends declared per share |  | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 0.68 |  |  | $ | 0.56 |  |

[0001193125-13-404683:8k_2_02:44]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-404683:8k_2_02:45]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001193125-13-404683:8k_2_02:46]
(Unaudited)

[0001193125-13-404683:8k_2_02:47]
(In
millions)

[0001193125-13-404683:8k_2_02:48]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 433.9 |  |  | $ | 386.3 |  |  | $ | 1,224.5 |  |  | $ | 1,070.7 |  |
| Commercial Heating & Cooling |  |  | 239.1 |  |  |  | 219.7 |  |  |  | 631.8 |  |  |  | 597.9 |  |
| Refrigeration |  |  | 195.0 |  |  |  | 203.7 |  |  |  | 593.2 |  |  |  | 595.9 |  |
|  |  | $ | 868.0 |  |  | $ | 809.7 |  |  | $ | 2,449.5 |  |  | $ | 2,264.5 |  |
| Segment Profit (Loss) (A) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 57.0 |  |  | $ | 37.7 |  |  | $ | 143.7 |  |  | $ | 90.7 |  |
| Commercial Heating & Cooling |  |  | 39.2 |  |  |  | 32.5 |  |  |  | 84.8 |  |  |  | 74.1 |  |
| Refrigeration |  |  | 23.9 |  |  |  | 25.1 |  |  |  | 66.5 |  |  |  | 60.6 |  |
| Corporate and other |  |  | (16.6 | ) |  |  | (14.3 | ) |  |  | (56.2 | ) |  |  | (43.7 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 103.5 |  |  |  | 81.0 |  |  |  | 238.8 |  |  |  | 181.7 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (0.4 | ) |  |  | 0.9 |  |  |  | (0.5 | ) |  |  | 1.0 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (B) |  |  | (0.2 | ) |  |  | (1.2 | ) |  |  | 2.0 |  |  |  | (2.0 | ) |
| Restructuring charges |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 3.2 |  |  |  | 3.1 |  |
| Interest expense, net |  |  | 3.8 |  |  |  | 4.4 |  |  |  | 10.8 |  |  |  | 13.4 |  |
| Other expense (income), net |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 100.0 |  |  | $ | 76.5 |  |  | $ | 223.4 |  |  | $ | 166.1 |  |

[0001193125-13-404683:8k_2_02:49]
| (A) | The Company defines segment profit and loss as a segment’s Income or Loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-13-404683:8k_2_02:50]
|  | ¡ |  | Special product quality adjustments; |

[0001193125-13-404683:8k_2_02:51]
|  | ¡ |  | Items in Losses (gains) and other expenses, net that are noted in (B); |

[0001193125-13-404683:8k_2_02:52]
|  | ¡ |  | Restructuring charges; |

[0001193125-13-404683:8k_2_02:53]
|  | ¡ |  | Goodwill, long-lived asset and equity method investment impairments; |

[0001193125-13-404683:8k_2_02:54]
|  | ¡ |  | Interest expense, net; |

[0001193125-13-404683:8k_2_02:55]
|  | ¡ |  | Other expense (income), net. |

[0001193125-13-404683:8k_2_02:56]
| (B) | Items in Losses (gains) and other expenses, net that are excluded from segment profit or loss are the net change in unrealized gains and/or losses on unsettled future contracts, special legal contingency charges and other items. |

[0001193125-13-404683:8k_2_02:57]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-404683:8k_2_02:58]
CONSOLIDATED BALANCE SHEETS

[0001193125-13-404683:8k_2_02:59]
(In millions, except shares and par value)

[0001193125-13-404683:8k_2_02:60]
|  |  | As ofSeptember 30,2013 |  |  | As ofDecember 31,2012 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 37.8 |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net of allowances of $9.3 and $9.5 in 2013 and 2012, respectively |  |  | 489.2 |  |  |  | 373.4 |  |
| Inventories, net |  |  | 430.0 |  |  |  | 374.8 |  |
| Deferred income taxes, net |  |  | 29.5 |  |  |  | 27.5 |  |
| Other assets |  |  | 50.8 |  |  |  | 61.0 |  |
| Assets of discontinued operations |  |  | — |  |  |  | 98.6 |  |
| Total current assets |  |  | 1,037.3 |  |  |  | 987.1 |  |
| Property, plant and equipment, net of accumulated depreciation of $615.8 and $584.8 in 2013 and 2012, respectively |  |  | 314.8 |  |  |  | 298.2 |  |
| Goodwill |  |  | 218.8 |  |  |  | 223.8 |  |
| Deferred income taxes |  |  | 111.8 |  |  |  | 102.8 |  |
| Other assets, net |  |  | 73.0 |  |  |  | 80.0 |  |
| Total assets |  | $ | 1,755.7 |  |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 167.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt |  |  | 0.8 |  |  |  | 0.7 |  |
| Accounts payable |  |  | 324.1 |  |  |  | 284.7 |  |
| Accrued expenses |  |  | 281.4 |  |  |  | 259.6 |  |
| Income taxes payable |  |  | 21.6 |  |  |  | 4.5 |  |
| Liabilities of discontinued operations |  |  | — |  |  |  | 55.2 |  |
| Total current liabilities |  |  | 795.8 |  |  |  | 639.6 |  |
| Long-term debt |  |  | 266.2 |  |  |  | 351.0 |  |
| Post-retirement benefits, other than pensions |  |  | 3.8 |  |  |  | 6.1 |  |
| Pensions |  |  | 138.1 |  |  |  | 134.4 |  |
| Other liabilities |  |  | 69.6 |  |  |  | 62.5 |  |
| Total liabilities |  |  | 1,273.5 |  |  |  | 1,193.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 916.2 |  |  |  | 898.3 |  |
| Retained earnings |  |  | 847.1 |  |  |  | 744.4 |  |
| Accumulated other comprehensive loss |  |  | (93.9 | ) |  |  | (22.3 | ) |
| Treasury stock, at cost, 37,593,995 shares and 36,937,632 shares in 2013 and 2012, respectively |  |  | (1,189.4 | ) |  |  | (1,124.5 | ) |
| Noncontrolling interests |  |  | 1.3 |  |  |  | 1.5 |  |
| Total stockholders’ equity |  |  | 482.2 |  |  |  | 498.3 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,755.7 |  |  | $ | 1,691.9 |  |

[0001193125-13-404683:8k_2_02:61]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-404683:8k_2_02:62]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-13-404683:8k_2_02:63]
For the Nine Months Ended September 30, 2013 and 2012

[0001193125-13-404683:8k_2_02:64]
(Unaudited)

[0001193125-13-404683:8k_2_02:65]
(In
millions)

[0001193125-13-404683:8k_2_02:66]
|  |  | 2013 |  |  | 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 136.6 |  |  | $ | 68.0 |  |
| Net loss from discontinued operations |  |  | 9.3 |  |  |  | 40.5 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (10.7 | ) |  |  | (8.8 | ) |
| Dividends from affiliates |  |  | 9.1 |  |  |  | 6.9 |  |
| Restructuring expenses, net of cash paid |  |  | (1.2 | ) |  |  | — |  |
| Provision for bad debts |  |  | 2.7 |  |  |  | 2.0 |  |
| Unrealized losses (gains) on derivative contracts |  |  | 0.7 |  |  |  | (1.4 | ) |
| Stock-based compensation expense |  |  | 20.5 |  |  |  | 10.5 |  |
| Depreciation and amortization |  |  | 43.1 |  |  |  | 41.1 |  |
| Deferred income taxes |  |  | 0.1 |  |  |  | 0.5 |  |
| Other items, net |  |  | 13.5 |  |  |  | 3.3 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (125.3 | ) |  |  | (62.4 | ) |
| Inventories |  |  | (76.4 | ) |  |  | (81.3 | ) |
| Other current assets |  |  | (13.7 | ) |  |  | (5.0 | ) |
| Accounts payable |  |  | 29.4 |  |  |  | 20.8 |  |
| Accrued expenses |  |  | 18.3 |  |  |  | 32.1 |  |
| Income taxes payable and receivable |  |  | 12.9 |  |  |  | 13.7 |  |
| Other |  |  | 9.3 |  |  |  | (3.6 | ) |
| Net cash used in discontinued operations |  |  | (13.2 | ) |  |  | (12.5 | ) |
| Net cash provided by operating activities |  |  | 65.0 |  |  |  | 64.4 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | (41.0 | ) |  |  | (28.0 | ) |
| Net proceeds from sale of businesses |  |  | 8.1 |  |  |  | 10.1 |  |
| Net cash used in discontinued operations |  |  | (0.1 | ) |  |  | (0.3 | ) |
| Net cash used in investing activities |  |  | (32.9 | ) |  |  | (18.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 3.8 |  |  |  | 1.3 |  |
| Asset securitization borrowings |  |  | 330.0 |  |  |  | 480.0 |  |
| Asset securitization payments |  |  | (200.0 | ) |  |  | (455.0 | ) |
| Long-term debt payments |  |  | (0.7 | ) |  |  | (0.9 | ) |
| Borrowings from revolving credit facility |  |  | 998.0 |  |  |  | 696.0 |  |
| Payments on revolving credit facility |  |  | (1,083.5 | ) |  |  | (706.0 | ) |
| Proceeds from employee stock purchases |  |  | 1.3 |  |  |  | 0.3 |  |
| Repurchases of common stock |  |  | (66.0 | ) |  |  | (35.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (7.7 | ) |  |  | (3.4 | ) |
| Excess tax benefits related to share-based payments |  |  | 4.7 |  |  |  | 1.7 |  |
| Cash dividends paid |  |  | (22.1 | ) |  |  | (27.5 | ) |
| Net cash used in financing activities |  |  | (42.2 | ) |  |  | (48.5 | ) |
| Decrease in cash and cash equivalents |  |  | (10.1 | ) |  |  | (2.2 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (3.9 | ) |  |  | 6.0 |  |
| Cash and cash equivalents, beginning of period |  |  | 51.8 |  |  |  | 45.0 |  |
| Cash and cash equivalents, end of period |  | $ | 37.8 |  |  | $ | 48.8 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the period for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 9.4 |  |  | $ | 11.8 |  |
| Income taxes (net of refunds) |  | $ | 53.6 |  |  | $ | 27.8 |  |

[0001193125-13-404683:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-404683:8k_2_02:68]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-13-404683:8k_2_02:69]
(Unaudited)

[0001193125-13-404683:8k_2_02:70]
(In
millions, except per share and ratio data)

[0001193125-13-404683:8k_2_02:71]
Use of Non-GAAP Financial Measures

[0001193125-13-404683:8k_2_02:72]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP
financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in
understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating performance.

[0001193125-13-404683:8k_2_02:73]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-13-404683:8k_2_02:74]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Income from continuing operations, a GAAP measure |  | $ | 65.8 |  |  | $ | 49.7 |  |  | $ | 145.9 |  |  | $ | 108.5 |  |
| Restructuring charges, after tax |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 2.1 |  |  |  | 2.1 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.3 | ) |  |  | 0.6 |  |  |  | (0.4 | ) |  |  | 0.9 |  |
| Special legal contingency charges, after tax (a) |  |  | 0.5 |  |  |  | — |  |  |  | 0.7 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax (a) |  |  | (0.7 | ) |  |  | (0.9 | ) |  |  | 0.4 |  |  |  | (1.7 | ) |
| Other items, net, after tax (a) |  |  | — |  |  |  | — |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 65.5 |  |  | $ | 49.7 |  |  | $ | 149.0 |  |  | $ | 110.1 |  |
| Income per share from continuing operations – diluted, a GAAP measure |  | $ | 1.30 |  |  | $ | 0.97 |  |  | $ | 2.87 |  |  | $ | 2.11 |  |
| Restructuring charges, after tax |  |  | — |  |  |  | 0.01 |  |  |  | 0.04 |  |  |  | 0.04 |  |
| Special product quality adjustments, after tax (b) |  |  | — |  |  |  | 0.01 |  |  |  | (0.01 | ) |  |  | 0.02 |  |
| Special legal contingency charges, after tax (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax (a) |  |  | (0.01 | ) |  |  | (0.02 | ) |  |  | 0.01 |  |  |  | (0.03 | ) |
| Other items, net, after tax (a) |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Adjusted earnings per share from continuing operations – diluted, a non-GAAP measure |  | $ | 1.30 |  |  | $ | 0.97 |  |  | $ | 2.93 |  |  | $ | 2.14 |  |

[0001193125-13-404683:8k_2_02:75]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-13-404683:8k_2_02:76]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-13-404683:8k_2_02:77]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 0.8 |  |  | $ | 1.4 |  |
| Foreign currency exchange loss (gain) (a) |  |  | (0.5 | ) |  |  | 1.0 |  |  |  | — |  |  |  | 0.7 |  |
| Loss on disposal of fixed assets (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | (1.1 | ) |  |  | (1.4 | ) |  |  | 0.7 |  |  |  | (2.5 | ) |
| Special legal contingency charge (b) |  |  | 0.8 |  |  |  | — |  |  |  | 1.0 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.5 |  |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | (0.3 | ) |  | $ | 0.3 |  |  | $ | 2.8 |  |  | $ | 0.2 |  |

[0001193125-13-404683:8k_2_02:78]
| (a) | Included in segment profit (loss) and adjusted income from continuing operations |

[0001193125-13-404683:8k_2_02:79]
| (b) | Excluded from segment profit (loss) and adjusted income from continuing operations |

[0001193125-13-404683:8k_2_02:80]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations – Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations – Diluted, a GAAP measure

[0001193125-13-404683:8k_2_02:81]
|  |  | For the YearEnded December 31, 2013ESTIMATED |  |
| Adjusted income per share from continuing operations – diluted, a Non-GAAP measure |  | $ | 3.50 - $3.75 |  |
| Restructuring charges and other items |  |  | (0.07 | ) |
| Income per share from continuing operations – diluted, a GAAP measure |  | $ | 3.43 - $3.68 |  |

[0001193125-13-404683:8k_2_02:82]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to
Free Cash Flow, a Non-GAAP measure

[0001193125-13-404683:8k_2_02:83]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 153.3 |  |  | $ | 75.0 |  |  | $ | 65.0 |  |  | $ | 64.4 |  |
| Purchases of property, plant and equipment |  |  | (17.6 | ) |  |  | (11.6 | ) |  |  | (41.0 | ) |  |  | (28.0 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 135.8 |  |  | $ | 63.4 |  |  | $ | 24.1 |  |  | $ | 36.5 |  |

[0001193125-13-404683:8k_2_02:84]
Calculation of Debt to EBITDA Ratio:

[0001193125-13-404683:8k_2_02:85]
|  |  | TrailingTwelve Months toSeptember 30, 2013 |  |
| EBIT (a) |  | $ | 281.3 |  |
| Depreciation and amortization expense (b) |  | $ | 57.4 |  |
| EBITDA (a + b) |  | $ | 338.7 |  |
| Total debt at September 30, 2013 (c) |  | $ | 434.9 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 1.3 |  |

[0001193125-13-404683:8k_2_02:86]
Reconciliation of EBIT, a Non-GAAP measure, to Income From Continuing Operations
Before Income Taxes, a GAAP measure

[0001193125-13-404683:8k_2_02:87]
|  |  | TrailingTwelve Months toSeptember 30, 2013 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 281.3 |  |
| Special product quality adjustments |  |  | (0.4 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 3.8 |  |
| Restructuring charges |  |  | 4.3 |  |
| Interest expense, net |  |  | 14.4 |  |
| Other expenses, net |  |  | 0.1 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 259.1 |  |
