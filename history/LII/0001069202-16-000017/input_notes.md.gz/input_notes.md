# LII notes — 0001069202-16-000017


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-16-000017:notes:1]
[same as prior period, unchanged from 0001069202-15-000011:notes:1]

[0001069202-16-000017:notes:2]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 180.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 180.0 |  |  | 200.0 |  |
| Remaining amount available | $ | — |  |  | $ | 20.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-16-000017:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-16-000017:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-16-000017:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-16-000017:notes:6]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.67 | % |  | 1.90 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-16-000017:notes:7]
[same as prior period, unchanged from 0001069202-15-000011:notes:7]

[0001069202-16-000017:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2016, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2016 and 2015, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2016 and 2015, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2016 and 2015 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2015. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-16-000017:notes:9]
[same as prior period, unchanged from 0001069202-15-000011:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-16-000017:notes:10]
Commitments and Contingencies:

[0001069202-16-000017:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-16-000017:notes:12]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-16-000017:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000017:notes:14]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Accrued expenses | $ | 27.6 |  |  | $ | 26.7 |  |
| Other liabilities | 65.8 |  |  | 65.6 |  |
| Total warranty liability | $ | 93.4 |  |  | $ | 92.3 |  |

[0001069202-16-000017:notes:15]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2016 were as follows (in millions):

[0001069202-16-000017:notes:16]
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |
| Warranty claims paid | (5.6 | ) |
| Changes resulting from issuance of new warranties | 8.1 |  |
| Changes in estimates associated with pre-existing liabilities | (1.9 | ) |
| Changes in foreign currency translation rates and other | 0.5 |  |
| Total warranty liability as of March 31, 2016 | $ | 93.4 |  |

[0001069202-16-000017:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a certain supplier quality issue within a range of $2.0 million and $9.5 million with all amounts in that range equally likely.  We have accrued a $2.0 million liability in Accrued expenses on the Consolidated Balance Sheet at March 31, 2016. The supplier is reimbursing the majority of costs related to this liability.

[0001069202-16-000017:notes:18]
Litigation

[0001069202-16-000017:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known. We increased our reserves by $1.0 million during the quarter for claims administration costs in a settled class action lawsuit which alleged that evaporator coils in our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks.  We also incurred an additional $0.7 million of legal charges related to other matters.

[0001069202-16-000017:notes:20]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and is subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2016, and 2015, expense for asbestos-related litigation was $0.8 million, and $0.1 million, net of insurance recoveries, respectively.

[0001069202-16-000017:notes:21]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-16-000017:notes:22]
[same as prior period, unchanged from 0001069202-15-000011:notes:24]

[0001069202-16-000017:notes:23]
[same as prior period, unchanged from 0001069202-15-000011:notes:25]

[0001069202-16-000017:notes:24]
|  |  | For the Three Months Ended March 31, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2016 |  | 2015 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (4.8 | ) |  | $ | (3.4 | ) |  | Cost of goods sold |
| Income tax benefit |  | 1.7 |  |  | 1.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (3.1 | ) |  | $ | (2.2 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.8 | ) |  | $ | (2.0 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.6 |  |  | 0.7 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.2 | ) |  | $ | (1.3 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (4.3 | ) |  | $ | (3.5 | ) |  |  |

[0001069202-16-000017:notes:25]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2016 (in millions):

[0001069202-16-000017:notes:26]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2015 |  | $ | (8.4 | ) |  | $ | 4.4 |  |  | $ | (139.3 | ) |  | $ | (61.4 | ) |  | $ | (204.7 | ) |
| Other comprehensive (loss) income before reclassifications |  | 1.5 |  |  | (0.1 | ) |  | (1.2 | ) |  | 9.5 |  |  | 9.7 |  |
| Amounts reclassified from AOCI |  | 3.1 |  |  | — |  |  | 1.2 |  |  | — |  |  | 4.3 |  |
| Net other comprehensive (loss) income |  | 4.6 |  |  | (0.1 | ) |  | — |  |  | 9.5 |  |  | 14.0 |  |
| Balance as of March 31, 2016 |  | $ | (3.8 | ) |  | $ | 4.3 |  |  | $ | (139.3 | ) |  | $ | (51.9 | ) |  | $ | (190.7 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-16-000017:notes:27]
[same as prior period, unchanged from 0001069202-15-000011:notes:29]

[0001069202-16-000017:notes:28]
[same as prior period, unchanged from 0001069202-15-000011:notes:30]

[0001069202-16-000017:notes:29]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of March 31, 2016 and December 31, 2015 and for the three and three months ended March 31, 2016 and 2015 are shown on the following pages.


## us-gaap:DebtDisclosureTextBlock

[0001069202-16-000017:notes:30]
Lines of Credit and Financing Arrangements:

[0001069202-16-000017:notes:31]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000017:notes:32]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 4.0 |  |  | 4.1 |  |
| Total short-term debt | $ | 184.0 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.1 |  |  | $ | 1.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.2 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 30.9 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.4 |  |  | $ | 15.6 |  |
| Domestic credit facility | 671.5 |  |  | 293.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Debt issuance costs | (2.4 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 884.5 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,099.4 |  |  | $ | 741.1 |  |

[0001069202-16-000017:notes:33]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. We are adopting this guidance in the current quarter and have reclassified the unamortized debt issuance costs into the debt liability as shown in the table above.

[0001069202-16-000017:notes:34]
Short-Term Debt

[0001069202-16-000017:notes:35]
Foreign Obligations

[0001069202-16-000017:notes:36]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $4.0 million and $4.1 million of foreign obligations as of March 31, 2016 and December 31, 2015, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $1.2 million  and $11.0 million during the three months ended March 31, 2016 and 2015, respectively. Repayments on the facilities were $1.6 million and $11.2 million during the three months ended three months ended March 31, 2016 and 2015, respectively.

[0001069202-16-000017:notes:37]
Asset Securitization Program

[0001069202-16-000017:notes:38]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-16-000017:notes:39]
The ASP provides for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-16-000017:notes:40]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rate for March 31, 2016 and December 31, 2015 was 1.20% and 1.06% respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-16-000017:notes:41]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2016, we were in compliance with all covenant requirements.

[0001069202-16-000017:notes:42]
Long-Term Debt

[0001069202-16-000017:notes:43]
Domestic Credit Facility

[0001069202-16-000017:notes:44]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consisted of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $701.5 million, of which $277.5 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of March 31, 2016. Subject to covenant limitations, $221.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million.  The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-16-000017:notes:45]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-16-000017:notes:46]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-16-000017:notes:47]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-16-000017:notes:48]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-16-000017:notes:49]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2016, we were in compliance with all covenant requirements.

[0001069202-16-000017:notes:50]
Senior Unsecured Notes

[0001069202-16-000017:notes:51]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2016, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-16-000017:notes:52]
[same as prior period, unchanged from 0001069202-15-000011:notes:73]

[0001069202-16-000017:notes:53]
[same as prior period, unchanged from 0001069202-15-000011:notes:74]

[0001069202-16-000017:notes:54]
[same as prior period, unchanged from 0001069202-15-000011:notes:75]

[0001069202-16-000017:notes:55]
[same as prior period, unchanged from 0001069202-15-000011:notes:76]

[0001069202-16-000017:notes:56]
Foreign Currency Risk - Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. Our forward contracts are generally  not designated as hedges, but on occasion we have entered into forward contracts that are designated as cash flow hedges. By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-16-000017:notes:57]
[same as prior period, unchanged from 0001069202-15-000011:notes:78]

[0001069202-16-000017:notes:58]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flow hedges that are scheduled to mature through September 2017.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-16-000017:notes:59]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Unrealized losses on unsettled futures contracts | $ | 6.0 |  |  | $ | 13.2 |  |
| Income tax benefit | (2.2 | ) |  | (4.8 | ) |
| Losses included in AOCL, net of tax (1) | $ | 3.8 |  |  | $ | 8.4 |  |

[0001069202-16-000017:notes:60]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $4.4 million of derivative losses into earnings within the next 12 months.

[0001069202-16-000017:notes:61]
[same as prior period, unchanged from 0001069202-15-000011:notes:82]

[0001069202-16-000017:notes:62]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Copper | 32.4 |  |  | 34.7 |  |

[0001069202-16-000017:notes:63]
[same as prior period, unchanged from 0001069202-15-000011:notes:84]

[0001069202-16-000017:notes:64]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 151.6 |  |  | 201.4 |  |

[0001069202-16-000017:notes:65]
[same as prior period, unchanged from 0001069202-15-000011:notes:86]

[0001069202-16-000017:notes:66]
[same as prior period, unchanged from 0001069202-15-000011:notes:87]

[0001069202-16-000017:notes:67]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Copper | 3.1 |  |  | 3.3 |  |
| Aluminum | 2.9 |  |  | 3.2 |  |

[0001069202-16-000017:notes:68]
[same as prior period, unchanged from 0001069202-15-000011:notes:89]

[0001069202-16-000017:notes:69]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 48.5 |  |  | 53.0 |  |
| Indian Rupee | 504.2 |  |  | 30.8 |  |
| Euro | 2.7 |  |  | 3.2 |  |
| Russian Ruble | 215.9 |  |  | — |  |
| Polish Zloty | 24.2 |  |  | 25.4 |  |

[0001069202-16-000017:notes:70]
[same as prior period, unchanged from 0001069202-15-000011:notes:91]

[0001069202-16-000017:notes:71]
[same as prior period, unchanged from 0001069202-15-000011:notes:92]

[0001069202-16-000017:notes:72]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of March 31, 2016 |  | As of December 31, 2015 |  | As of March 31, 2016 |  | As of December 31, 2015 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.3 |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.7 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total Assets | $ | 0.8 |  |  | $ | — |  |  | $ | 0.4 |  |  | $ | 0.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 6.5 |  |  | $ | 12.5 |  |  | $ | 0.9 |  |  | $ | 1.5 |  |
| Foreign currency forward contracts | 0.5 |  |  | 0.4 |  |  | 0.3 |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.4 |  |  | — |  |  | — |  |
| Foreign currency forward contracts |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 7.0 |  |  | $ | 13.3 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |

[0001069202-16-000017:notes:73]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 15 for more information.

[0001069202-16-000017:notes:74]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended March 31, |
|  |  | 2016 |  | 2015 |
| Amount of Loss reclassified from AOCL into Income (effective portion) (1) |  | $ | 4.8 |  |  | $ | 3.4 |  |
| Amount of Loss recognized in Net income (ineffective portion) (2) |  | $ | 0.1 |  |  | $ | — |  |

[0001069202-16-000017:notes:75]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended March 31, |
|  |  | 2016 |  | 2015 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |
| Commodity futures contracts (2) |  | $ | — |  |  | $ | 0.3 |  |
| Foreign currency forward contracts (2) |  | 0.3 |  |  | 0.2 |  |
|  |  | $ | 0.3 |  |  | $ | 0.5 |  |

[0001069202-16-000017:notes:76]
[same as prior period, unchanged from 0001069202-15-000011:notes:97]

[0001069202-16-000017:notes:77]
(2) The loss was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-16-000017:notes:78]
[same as prior period, unchanged from 0001069202-15-000011:notes:99]

[0001069202-16-000017:notes:79]
[same as prior period, unchanged from 0001069202-15-000011:notes:100]

[0001069202-16-000017:notes:80]
|  | For the Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Stock-based compensation expense (1) | $ | 6.3 |  |  | $ | 3.5 |  |

[0001069202-16-000017:notes:81]
[same as prior period, unchanged from 0001069202-15-000011:notes:102]


## us-gaap:EarningsPerShareTextBlock

[0001069202-16-000017:notes:82]
[same as prior period, unchanged from 0001069202-15-000011:notes:109]

[0001069202-16-000017:notes:83]
[same as prior period, unchanged from 0001069202-15-000011:notes:110]

[0001069202-16-000017:notes:84]
[same as prior period, unchanged from 0001069202-15-000011:notes:111]

[0001069202-16-000017:notes:85]
|  | For the Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Net income | $ | 24.9 |  |  | $ | 13.9 |  |
| Add: Loss from discontinued operations | — |  |  | 0.1 |  |
| Income from continuing operations | $ | 24.9 |  |  | $ | 14.0 |  |
| Weighted-average shares outstanding – basic | 44.0 |  |  | 44.7 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.7 |  |  | 0.8 |  |
| Weighted-average shares outstanding – diluted | 44.7 |  |  | 45.5 |  |
| Earnings per share – Basic: |  |  |  |
| Income from continuing operations | $ | 0.57 |  |  | $ | 0.31 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 0.57 |  |  | $ | 0.31 |  |
| Earnings per share – Diluted: |  |  |  |
| Income from continuing operations | $ | 0.56 |  |  | $ | 0.31 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 0.56 |  |  | $ | 0.31 |  |

[0001069202-16-000017:notes:86]
The following stock appreciation rights and restricted stock units were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive (in millions, except for per share data):

[0001069202-16-000017:notes:87]
|  | For the Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Weighted-average number of shares | 0.3 |  |  | 0.2 |  |
| Price range per share | $124.97-$131.94 |  |  | $ | 92.64 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-16-000017:notes:88]
[same as prior period, unchanged from 0001069202-15-000011:notes:115]

[0001069202-16-000017:notes:89]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Senior unsecured notes | $ | 208.8 |  |  | $ | 207.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-16-000017:notes:90]
[same as prior period, unchanged from 0001069202-15-000011:notes:117]

[0001069202-16-000017:notes:91]
[same as prior period, unchanged from 0001069202-15-000011:notes:118]

[0001069202-16-000017:notes:92]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2016 were the same as those used at December 31, 2015.

[0001069202-16-000017:notes:93]
[same as prior period, unchanged from 0001069202-15-000011:notes:120]

[0001069202-16-000017:notes:94]
[same as prior period, unchanged from 0001069202-15-000011:notes:121]

[0001069202-16-000017:notes:95]
[same as prior period, unchanged from 0001069202-15-000011:notes:122]

[0001069202-16-000017:notes:96]
[same as prior period, unchanged from 0001069202-15-000011:notes:123]

[0001069202-16-000017:notes:97]
[same as prior period, unchanged from 0001069202-15-000011:notes:124]

[0001069202-16-000017:notes:98]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Investment in marketable equity securities | $ | 6.2 |  |  | $ | 6.5 |  |

[0001069202-16-000017:notes:99]
[same as prior period, unchanged from 0001069202-15-000011:notes:126]

[0001069202-16-000017:notes:100]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-16-000017:notes:101]
[same as prior period, unchanged from 0001069202-15-000011:notes:128]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-16-000017:notes:102]
[same as prior period, unchanged from 0001069202-15-000011:notes:129]

[0001069202-16-000017:notes:103]
The changes in the carrying amount of goodwill for the first three months of 2016, in total and by segment, are summarized in the table below (in millions):

[0001069202-16-000017:notes:104]
|  | Balance at December 31, 2015 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at March 31, 2016 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 60.6 |  |  | — |  |  | 0.4 |  |  | 61.0 |  |
| Refrigeration | 108.4 |  |  | — |  |  | 1.5 |  |  | 109.9 |  |
| Total Goodwill | $ | 195.1 |  |  | $ | — |  |  | $ | 1.9 |  |  | $ | 197.0 |  |

[0001069202-16-000017:notes:105]
[same as prior period, unchanged from 0001069202-15-000011:notes:132]

[0001069202-16-000017:notes:106]
We performed our annual goodwill impairment test in the fourth quarter of 2015 and recorded a $5.5 million goodwill impairment charge.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-16-000017:notes:107]
[same as prior period, unchanged from 0001069202-15-000011:notes:134]

[0001069202-16-000017:notes:108]
As of March 31, 2016, we had approximately $0.5 million in total gross unrecognized tax benefits. Of this amount, $0.3 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of March 31, 2016, we had approximately $0.1 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-16-000017:notes:109]
We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2016 and 2015 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2010.

[0001069202-16-000017:notes:110]
Since January 1, 2016, numerous states, including Delaware, have enacted legislation effective for tax years beginning on or after January 1, 2016, including changes to apportionment methodologies.  The impact of these changes is immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-16-000017:notes:111]
[same as prior period, unchanged from 0001069202-15-000011:notes:138]

[0001069202-16-000017:notes:112]
[same as prior period, unchanged from 0001069202-15-000011:notes:139]

[0001069202-16-000017:notes:113]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Finished goods | $ | 371.4 |  |  | $ | 300.0 |  |
| Work in process | 5.3 |  |  | 4.2 |  |
| Raw materials and parts | 204.8 |  |  | 178.3 |  |
| Subtotal | 581.5 |  |  | 482.5 |  |
| Excess of current cost over last-in, first-out cost | (63.4 | ) |  | (63.7 | ) |
| Total inventories, net | $ | 518.1 |  |  | $ | 418.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-16-000017:notes:114]
[same as prior period, unchanged from 0001069202-15-000011:notes:141]

[0001069202-16-000017:notes:115]
[same as prior period, unchanged from 0001069202-15-000011:notes:142]

[0001069202-16-000017:notes:116]
[same as prior period, unchanged from 0001069202-15-000011:notes:143]

[0001069202-16-000017:notes:117]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-16-000017:notes:118]
[same as prior period, unchanged from 0001069202-15-000011:notes:145]

[0001069202-16-000017:notes:119]
[same as prior period, unchanged from 0001069202-15-000011:notes:146]

[0001069202-16-000017:notes:120]
[same as prior period, unchanged from 0001069202-15-000011:notes:147]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-16-000017:notes:121]
[same as prior period, unchanged from 0001069202-15-000011:notes:148]

[0001069202-16-000017:notes:122]
[same as prior period, unchanged from 0001069202-15-000011:notes:149]

[0001069202-16-000017:notes:123]
|  | For the Three Months Ended March 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.1 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.7 |  |  | 4.3 |  |  | — |  |  | — |  |
| Expected return on plan assets | (5.1 | ) |  | (5.3 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | — |  |  | (0.8 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.1 |  |  | 2.4 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.9 |  |  | $ | 2.9 |  |  | $ | (0.4 | ) |  | $ | (0.4 | ) |

[0001069202-16-000017:notes:124]
(1) All net periodic benefit cost for the three months ended March 31, 2016 and 2015 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-16-000017:notes:125]
[same as prior period, unchanged from 0001069202-15-000011:notes:153]

[0001069202-16-000017:notes:126]
|  | For the Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Net sales |  |  |  |
| Residential Heating & Cooling | $ | 377.3 |  |  | $ | 362.5 |  |
| Commercial Heating & Cooling | 170.3 |  |  | 159.9 |  |
| Refrigeration | 167.6 |  |  | 163.4 |  |
|  | $ | 715.2 |  |  | $ | 685.8 |  |
| Segment profit (loss) (1) |  |  |  |
| Residential Heating & Cooling | $ | 38.3 |  |  | $ | 31.2 |  |
| Commercial Heating & Cooling | 14.2 |  |  | 7.7 |  |
| Refrigeration | 9.0 |  |  | 4.0 |  |
| Corporate and other | (14.8 | ) |  | (11.7 | ) |
| Total segment profit | 46.7 |  |  | 31.2 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |
| Special product quality adjustments | (0.4 | ) |  | (0.2 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 3.6 |  |  | 4.1 |  |
| Restructuring charges | (0.2 | ) |  | 0.3 |  |
| Interest expense, net | 5.8 |  |  | 5.7 |  |
| Income from continuing operations before income taxes | $ | 37.9 |  |  | $ | 21.3 |  |

[0001069202-16-000017:notes:127]
[same as prior period, unchanged from 0001069202-15-000011:notes:155]

[0001069202-16-000017:notes:128]
[same as prior period, unchanged from 0001069202-15-000011:notes:156]

[0001069202-16-000017:notes:129]
[same as prior period, unchanged from 0001069202-15-000011:notes:157]

[0001069202-16-000017:notes:130]
[same as prior period, unchanged from 0001069202-15-000011:notes:158]

[0001069202-16-000017:notes:131]
| ◦ | Special legal contingency charges, |

[0001069202-16-000017:notes:132]
| ◦ | Asbestos-related litigation, |

[0001069202-16-000017:notes:133]
[same as prior period, unchanged from 0001069202-15-000011:notes:161]

[0001069202-16-000017:notes:134]
[same as prior period, unchanged from 0001069202-15-000011:notes:162]

[0001069202-16-000017:notes:135]
[same as prior period, unchanged from 0001069202-15-000011:notes:163]

[0001069202-16-000017:notes:136]
[same as prior period, unchanged from 0001069202-15-000011:notes:164]

[0001069202-16-000017:notes:137]
[same as prior period, unchanged from 0001069202-15-000011:notes:165]

[0001069202-16-000017:notes:138]
[same as prior period, unchanged from 0001069202-15-000011:notes:166]

[0001069202-16-000017:notes:139]
[same as prior period, unchanged from 0001069202-15-000011:notes:167]

[0001069202-16-000017:notes:140]
[same as prior period, unchanged from 0001069202-15-000011:notes:168]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-16-000017:notes:141]
[same as prior period, unchanged from 0001069202-15-000011:notes:169]

[0001069202-16-000017:notes:142]
We record restructuring charges associated with management-approved restructuring plans when we reorganize or remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 14.

[0001069202-16-000017:notes:143]
Restructuring Activities in 2016

[0001069202-16-000017:notes:144]
[same as prior period, unchanged from 0001069202-15-000011:notes:172]

[0001069202-16-000017:notes:145]
|  | Charges Incurred in 2016 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | (0.3 | ) |  | $ | 9.2 |  |  | $ | 9.2 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 2.2 |  |  | 2.2 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | 0.2 |  |  | 0.2 |  |
| Other | — |  |  | 2.0 |  |  | 4.2 |  |
| Total restructuring charges | $ | (0.2 | ) |  | $ | 13.6 |  |  | $ | 15.8 |  |

[0001069202-16-000017:notes:146]
[same as prior period, unchanged from 0001069202-15-000011:notes:174]

[0001069202-16-000017:notes:147]
|  | Charges Incurred in 2016 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | (0.2 | ) |  | 11.8 |  |  | 14.0 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total restructuring charges | $ | (0.2 | ) |  | $ | 13.6 |  |  | $ | 15.8 |  |

[0001069202-16-000017:notes:148]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below details the activity in 2016 within the restructuring accruals (in millions):

[0001069202-16-000017:notes:149]
|  | Balance as ofDecember 31, 2015 |  | Charged to Earnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of March 31, 2016 |
| Severance and related expense | $ | 0.7 |  |  | $ | (0.3 | ) |  | $ | (0.2 | ) |  | $ | 0.3 |  |  | $ | 0.5 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.1 |  |  | — |  |  | (0.1 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | 0.2 |  |  | — |  |  | (0.1 | ) |  | — |  |  | 0.1 |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total restructuring accruals | $ | 0.9 |  |  | $ | (0.2 | ) |  | $ | (0.3 | ) |  | $ | 0.2 |  |  | $ | 0.6 |  |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0001069202-16-000017:notes:150]
Lennox International Inc. and Subsidiaries

[0001069202-16-000017:notes:151]
Condensed Consolidating Balance Sheets

[0001069202-16-000017:notes:152]
As of March 31, 2016

[0001069202-16-000017:notes:153]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 15.2 |  |  | $ | 24.4 |  |  | $ | — |  |  | $ | 40.6 |  |
| Accounts and notes receivable, net | — |  |  | 38.1 |  |  | 431.7 |  |  | — |  |  | 469.8 |  |
| Inventories, net | — |  |  | 409.9 |  |  | 114.7 |  |  | (6.5 | ) |  | 518.1 |  |
| Other assets | 3.6 |  |  | 52.2 |  |  | 98.4 |  |  | (61.1 | ) |  | 93.1 |  |
| Total current assets | 4.6 |  |  | 515.4 |  |  | 669.2 |  |  | (67.6 | ) |  | 1,121.6 |  |
| Property, plant and equipment, net | — |  |  | 259.5 |  |  | 79.0 |  |  | — |  |  | 338.5 |  |
| Goodwill | — |  |  | 134.9 |  |  | 62.1 |  |  | — |  |  | 197.0 |  |
| Investment in subsidiaries | 916.4 |  |  | 380.2 |  |  | (0.6 | ) |  | (1,296.0 | ) |  | — |  |
| Deferred income taxes | 3.7 |  |  | 122.9 |  |  | 28.8 |  |  | (14.9 | ) |  | 140.5 |  |
| Other assets, net | 2.3 |  |  | 38.0 |  |  | 24.6 |  |  | (1.5 | ) |  | 63.4 |  |
| Intercompany receivables (payables), net | (73.8 | ) |  | 61.7 |  |  | 12.1 |  |  | — |  |  | — |  |
| Total assets | $ | 853.2 |  |  | $ | 1,512.6 |  |  | $ | 875.2 |  |  | $ | (1,380.0 | ) |  | $ | 1,861.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 184.0 |  |  | $ | — |  |  | $ | 184.0 |  |
| Current maturities of long-term debt | 29.8 |  |  | 0.8 |  |  | 0.3 |  |  | — |  |  | 30.9 |  |
| Accounts payable | 15.6 |  |  | 297.6 |  |  | 65.1 |  |  | — |  |  | 378.3 |  |
| Accrued expenses | 11.8 |  |  | 145.5 |  |  | 52.1 |  |  | — |  |  | 209.4 |  |
| Income taxes payable | (0.1 | ) |  | 10.5 |  |  | 67.7 |  |  | (77.5 | ) |  | 0.6 |  |
| Total current liabilities | 57.1 |  |  | 454.4 |  |  | 369.2 |  |  | (77.5 | ) |  | 803.2 |  |
| Long-term debt | 869.1 |  |  | 15.0 |  |  | 0.4 |  |  | — |  |  | 884.5 |  |
| Post-retirement benefits, other than pensions | — |  |  | 3.4 |  |  | — |  |  | — |  |  | 3.4 |  |
| Pensions | — |  |  | 113.2 |  |  | 8.7 |  |  | — |  |  | 121.9 |  |
| Other liabilities | 0.3 |  |  | 114.5 |  |  | 11.0 |  |  | (4.5 | ) |  | 121.3 |  |
| Total liabilities | 926.5 |  |  | 700.5 |  |  | 389.3 |  |  | (82.0 | ) |  | 1,934.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | (73.3 | ) |  | 812.1 |  |  | 485.9 |  |  | (1,298.0 | ) |  | (73.3 | ) |
| Total liabilities and stockholders' equity | $ | 853.2 |  |  | $ | 1,512.6 |  |  | $ | 875.2 |  |  | $ | (1,380.0 | ) |  | $ | 1,861.0 |  |

[0001069202-16-000017:notes:154]
As of December 31, 2015

[0001069202-16-000017:notes:155]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.5 |  |  | $ | 7.8 |  |  | $ | 30.6 |  |  | $ | — |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net | — |  |  | 25.9 |  |  | 396.9 |  |  | — |  |  | 422.8 |  |
| Inventories, net | — |  |  | 324.3 |  |  | 98.9 |  |  | (4.4 | ) |  | 418.8 |  |
| Other assets | 3.3 |  |  | 46.9 |  |  | 67.4 |  |  | (59.9 | ) |  | 57.7 |  |
| Total current assets | 3.8 |  |  | 404.9 |  |  | 593.8 |  |  | (64.3 | ) |  | 938.2 |  |
| Property, plant and equipment, net | — |  |  | 261.8 |  |  | 77.8 |  |  | — |  |  | 339.6 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 879.0 |  |  | 337.6 |  |  | (0.6 | ) |  | (1,216.0 | ) |  | — |  |
| Deferred income taxes | 5.4 |  |  | 126.6 |  |  | 28.4 |  |  | (14.7 | ) |  | 145.7 |  |
| Other assets, net | 1.5 |  |  | 38.2 |  |  | 20.6 |  |  | (1.5 | ) |  | 58.8 |  |
| Intercompany receivables (payables), net | (278.6 | ) |  | 253.3 |  |  | 25.3 |  |  | — |  |  | — |  |
| Total assets | $ | 611.1 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,677.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 204.1 |  |  | $ | — |  |  | $ | 204.1 |  |
| Current maturities of long-term debt | 29.8 |  |  | 0.8 |  |  | 0.4 |  |  | — |  |  | 31.0 |  |
| Accounts payable | 16.1 |  |  | 237.9 |  |  | 66.1 |  |  | — |  |  | 320.1 |  |
| Accrued expenses | 15.8 |  |  | 176.7 |  |  | 50.1 |  |  | — |  |  | 242.6 |  |
| Income taxes payable | (43.0 | ) |  | 106.6 |  |  | 37.9 |  |  | (75.5 | ) |  | 26.0 |  |
| Total current liabilities | 18.7 |  |  | 522.0 |  |  | 358.6 |  |  | (75.5 | ) |  | 823.8 |  |
| Long-term debt | 490.4 |  |  | 15.1 |  |  | 0.5 |  |  | — |  |  | 506.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.1 |  |  | — |  |  | — |  |  | 4.1 |  |
| Pensions | — |  |  | 111.9 |  |  | 8.9 |  |  | — |  |  | 120.8 |  |
| Other liabilities | 0.4 |  |  | 114.4 |  |  | 10.5 |  |  | (4.2 | ) |  | 121.1 |  |
| Total liabilities | 509.5 |  |  | 767.5 |  |  | 378.5 |  |  | (79.7 | ) |  | 1,575.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 101.6 |  |  | 789.8 |  |  | 427.0 |  |  | (1,216.8 | ) |  | 101.6 |  |
| Total liabilities and stockholders' equity | $ | 611.1 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,677.4 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0001069202-16-000017:notes:156]
Condensed Consolidating Statements of Cash Flows

[0001069202-16-000017:notes:157]
For the Three Months Ended March 31, 2016

[0001069202-16-000017:notes:158]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 47.2 |  |  | $ | (163.1 | ) |  | $ | 2.5 |  |  | $ | — |  |  | $ | (113.4 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (20.9 | ) |  | (2.9 | ) |  | — |  |  | (23.8 | ) |
| Net cash used in investing activities | — |  |  | (20.9 | ) |  | (2.9 | ) |  | — |  |  | (23.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset securitization payments | — |  |  | — |  |  | (20.0 | ) |  | — |  |  | (20.0 | ) |
| Long-term debt payments | — |  |  | (0.2 | ) |  | (0.1 | ) |  | — |  |  | (0.3 | ) |
| Borrowings from credit facility | 770.5 |  |  | — |  |  | — |  |  | — |  |  | 770.5 |  |
| Payments on credit facility | (392.0 | ) |  | — |  |  | — |  |  | — |  |  | (392.0 | ) |
| Proceeds from employee stock purchases | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |
| Repurchases of common stock | (200.0 | ) |  | — |  |  | — |  |  | — |  |  | (200.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (16.8 | ) |  | — |  |  | — |  |  | — |  |  | (16.8 | ) |
| Excess tax benefits related to share-based payments | 11.8 |  |  | — |  |  | — |  |  | — |  |  | 11.8 |  |
| Intercompany financing activity | (8.6 | ) |  | (2.9 | ) |  | 11.5 |  |  | — |  |  | — |  |
| Intercompany investments | (196.1 | ) |  | 194.5 |  |  | 1.6 |  |  | — |  |  | — |  |
| Cash dividends paid | (16.1 | ) |  | — |  |  | — |  |  | — |  |  | (16.1 | ) |
| Net cash provided by financing activities | (46.7 | ) |  | 191.4 |  |  | (7.4 | ) |  | — |  |  | 137.3 |  |
| Increase in cash and cash equivalents | 0.5 |  |  | 7.4 |  |  | (7.8 | ) |  | — |  |  | 0.1 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Cash and cash equivalents, beginning of period | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of period | $ | 1.0 |  |  | $ | 15.2 |  |  | $ | 24.4 |  |  | $ | — |  |  | $ | 40.6 |  |

[0001069202-16-000017:notes:159]
For the Three Months Ended March 31, 2015

[0001069202-16-000017:notes:160]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 3.5 |  |  | $ | (156.4 | ) |  | $ | 30.7 |  |  | $ | — |  |  | $ | (122.2 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (14.9 | ) |  | (3.1 | ) |  | — |  |  | (18.0 | ) |
| Net proceeds from sale of business | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in investing activities | — |  |  | (14.9 | ) |  | (3.1 | ) |  | — |  |  | (18.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Long-term debt payments | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Borrowings from revolving credit facility | 580.5 |  |  | — |  |  | — |  |  | — |  |  | 580.5 |  |
| Payments on revolving credit facility | (379.0 | ) |  | — |  |  | — |  |  | — |  |  | (379.0 | ) |
| Proceeds from employee stock purchases | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |
| Repurchases of common stock | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (20.5 | ) |  | — |  |  | — |  |  | — |  |  | (20.5 | ) |
| Excess tax benefits related to share-based payments | 16.0 |  |  | — |  |  | — |  |  | — |  |  | 16.0 |  |
| Intercompany debt | (16.2 | ) |  | 2.9 |  |  | 13.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | (171.3 | ) |  | 168.7 |  |  | 2.6 |  |  | — |  |  | — |  |
| Intercompany investments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Cash dividends paid | (13.4 | ) |  | — |  |  | — |  |  | — |  |  | (13.4 | ) |
| Net cash provided by financing activities | (3.3 | ) |  | 171.7 |  |  | (24.4 | ) |  | — |  |  | 144.0 |  |
| Increase in cash and cash equivalents | 0.2 |  |  | 0.4 |  |  | 3.2 |  |  | — |  |  | 3.8 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (4.6 | ) |  | — |  |  | (4.6 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of period | $ | 1.2 |  |  | $ | 11.9 |  |  | $ | 23.6 |  |  | $ | — |  |  | $ | 36.7 |  |


## us-gaap:ScheduleOfCondensedIncomeStatementTableTextBlock

[0001069202-16-000017:notes:161]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-16-000017:notes:162]
For the Three Months Ended March 31, 2016

[0001069202-16-000017:notes:163]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 613.8 |  |  | $ | 143.8 |  |  | $ | (42.4 | ) |  | $ | 715.2 |  |
| Cost of goods sold | — |  |  | 460.7 |  |  | 111.3 |  |  | (40.4 | ) |  | 531.6 |  |
| Gross profit | — |  |  | 153.1 |  |  | 32.5 |  |  | (2.0 | ) |  | 183.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 118.9 |  |  | 21.5 |  |  | — |  |  | 140.4 |  |
| Losses (gains) and other expenses, net | (0.6 | ) |  | 2.5 |  |  | 2.4 |  |  | — |  |  | 4.3 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | (0.3 | ) |  | — |  |  | (0.2 | ) |
| Income from equity method investments | (28.1 | ) |  | — |  |  | (4.0 | ) |  | 27.5 |  |  | (4.6 | ) |
| Operational income from continuing operations | 28.7 |  |  | 31.6 |  |  | 12.9 |  |  | (29.5 | ) |  | 43.7 |  |
| Interest expense, net | 5.3 |  |  | (0.5 | ) |  | 1.0 |  |  | — |  |  | 5.8 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 23.4 |  |  | 32.1 |  |  | 11.9 |  |  | (29.5 | ) |  | 37.9 |  |
| Provision for income taxes | (1.5 | ) |  | 11.9 |  |  | 3.5 |  |  | (0.9 | ) |  | 13.0 |  |
| Income from continuing operations | 24.9 |  |  | 20.2 |  |  | 8.4 |  |  | (28.6 | ) |  | 24.9 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 24.9 |  |  | $ | 20.2 |  |  | $ | 8.4 |  |  | $ | (28.6 | ) |  | $ | 24.9 |  |
| Other comprehensive income (loss), net of tax | 4.6 |  |  | 2.1 |  |  | 6.3 |  |  | 1.0 |  |  | 14.0 |  |
| Comprehensive income | $ | 29.5 |  |  | $ | 22.3 |  |  | $ | 14.7 |  |  | $ | (27.6 | ) |  | $ | 38.9 |  |

[0001069202-16-000017:notes:164]
For the Three Months Ended March 31, 2015

[0001069202-16-000017:notes:165]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 576.2 |  |  | $ | 153.8 |  |  | $ | (44.2 | ) |  | $ | 685.8 |  |
| Cost of goods sold | — |  |  | 443.6 |  |  | 122.9 |  |  | (43.7 | ) |  | 522.8 |  |
| Gross profit | — |  |  | 132.6 |  |  | 30.9 |  |  | (0.5 | ) |  | 163.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 108.0 |  |  | 25.4 |  |  | — |  |  | 133.4 |  |
| Losses (gains) and other expenses, net | 0.1 |  |  | 3.8 |  |  | 1.7 |  |  | — |  |  | 5.6 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.2 |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (17.5 | ) |  | 2.3 |  |  | (2.8 | ) |  | 14.7 |  |  | (3.3 | ) |
| Operational income from continuing operations | 17.4 |  |  | 18.4 |  |  | 6.4 |  |  | (15.2 | ) |  | 27.0 |  |
| Interest expense, net | 5.5 |  |  | (0.5 | ) |  | 0.7 |  |  | — |  |  | 5.7 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 11.9 |  |  | 18.9 |  |  | 5.7 |  |  | (15.2 | ) |  | 21.3 |  |
| Provision for income taxes | (2.0 | ) |  | 7.8 |  |  | 1.6 |  |  | (0.1 | ) |  | 7.3 |  |
| Income from continuing operations | 13.9 |  |  | 11.1 |  |  | 4.1 |  |  | (15.1 | ) |  | 14.0 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Net income | $ | 13.9 |  |  | $ | 11.1 |  |  | $ | 4.0 |  |  | $ | (15.1 | ) |  | $ | 13.9 |  |
| Other comprehensive income, net of tax | 1.0 |  |  | (3.9 | ) |  | (20.5 | ) |  | (1.8 | ) |  | (25.2 | ) |
| Comprehensive income | $ | 14.9 |  |  | $ | 7.2 |  |  | $ | (16.5 | ) |  | $ | (16.9 | ) |  | $ | (11.3 | ) |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-16-000017:notes:166]
[same as prior period, unchanged from 0001069202-15-000011:notes:178]

[0001069202-16-000017:notes:167]
[same as prior period, unchanged from 0001069202-15-000011:notes:179]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-16-000017:notes:168]
[same as prior period, unchanged from 0001069202-15-000011:notes:180]

[0001069202-16-000017:notes:169]
[same as prior period, unchanged from 0001069202-15-000011:notes:181]

[0001069202-16-000017:notes:170]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation in the table below details the items excluded.

[0001069202-16-000017:notes:171]
[same as prior period, unchanged from 0001069202-15-000011:notes:183]

[0001069202-16-000017:notes:172]
[same as prior period, unchanged from 0001069202-15-000011:notes:184]

[0001069202-16-000017:notes:173]
[same as prior period, unchanged from 0001069202-15-000011:notes:185]

[0001069202-16-000017:notes:174]
[same as prior period, unchanged from 0001069202-15-000011:notes:186]

[0001069202-16-000017:notes:175]
Except for the seasonal increase in total assets across all reportable segments, there have not been any material changes in the composition of total assets by segment since December 31, 2015.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-16-000017:notes:176]
[same as prior period, unchanged from 0001069202-15-000011:notes:188]

[0001069202-16-000017:notes:177]
Our Board of Directors has authorized a total of $1.4 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first three months of 2016. As of March 31, 2016, $196.2 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-16-000017:notes:178]
On February 10, 2016, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “ASR Agreement”) with Merrill Lynch International (“Merrill Lynch”), acting through its agent, Merrill Lynch, Pierce, Fenner and Smith Incorporated to effect an accelerated stock buyback of the Company’s common stock (the “Common Stock”).

[0001069202-16-000017:notes:179]
Under the ASR Agreement, on February 10, 2016, the Company paid Merrill Lynch an initial purchase price of $200 million, and Merrill Lynch delivered to the Company a total of 1.3 million shares of Common Stock, representing approximately 75% of the shares expected to be purchased under the ASR Agreement.

[0001069202-16-000017:notes:180]
We also repurchased 0.1 million shares for $16.8 million for the three months ended March 31, 2016 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
