# LII MD&A — 0001069202-16-000017


## mdna

[0001069202-16-000017:mdna:1]
[same as prior period, unchanged from 0001069202-15-000011:mdna:1]

[0001069202-16-000017:mdna:2]
[same as prior period, unchanged from 0001069202-15-000011:mdna:2]

[0001069202-16-000017:mdna:3]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For  additional information regarding our reportable segments, see Note 14 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000017:mdna:4]
[same as prior period, unchanged from 0001069202-15-000011:mdna:4]

[0001069202-16-000017:mdna:5]
[same as prior period, unchanged from 0001069202-15-000011:mdna:5]

[0001069202-16-000017:mdna:6]
[same as prior period, unchanged from 0001069202-15-000011:mdna:6]

[0001069202-16-000017:mdna:7]
[same as prior period, unchanged from 0001069202-15-000011:mdna:7]

[0001069202-16-000017:mdna:8]
In the first quarter of 2016, the Residential Heating & Cooling segment continued to lead our overall operational performance with a 4% increase in net sales and a $7 million increase in segment profit compared to the first quarter of 2015.  The primary growth drivers for this segment were volume gains.  Our Commercial Heating & Cooling segment also performed well in the first quarter of 2016 with a 7% increase in net sales and $7 million in increased segment profit compared to the first quarter of 2015.  This segment's profits were up largely due to volume increases partially offset by unfavorable foreign currency exchange rates.  Sales in our Refrigeration segment increased by 3% and segment profit increased $5 million compared to the first quarter of 2015.  Higher sales volume was partially offset by lower price and unfavorable foreign currency exchange rates.

[0001069202-16-000017:mdna:9]
[same as prior period, unchanged from 0001069202-15-000011:mdna:9]

[0001069202-16-000017:mdna:10]
[same as prior period, unchanged from 0001069202-15-000011:mdna:10]

[0001069202-16-000017:mdna:11]
| • | Net sales increased $29 million, or 4%, to $715 million in the first quarter of 2016 compared to $686 million in the first quarter of 2015. |

[0001069202-16-000017:mdna:12]
| • | Operational income from continuing operations in the first quarter of 2016 increased $17 million to $44 million from $27 million in the first quarter of 2015. |

[0001069202-16-000017:mdna:13]
| • | Net income for the first quarter of 2016 increased $11 million to $25 million from $14 million in the first quarter of 2015. |

[0001069202-16-000017:mdna:14]
| • | Diluted earnings per share from continuing operations were $0.56 per share in the first quarter of 2016 compared to $0.31 per share in the first quarter of 2015. |

[0001069202-16-000017:mdna:15]
| • | During the first quarter of 2016, we returned $16 million to shareholders through dividend payments. |

[0001069202-16-000017:mdna:16]
| • | Cash used in operating activities was $113 million in the first three months of 2016 compared to $122 million in the first three months of 2015. |

[0001069202-16-000017:mdna:17]
First Quarter of 2016 Compared to First Quarter of 2015 - Consolidated Results

[0001069202-16-000017:mdna:18]
[same as prior period, unchanged from 0001069202-15-000011:mdna:18]

[0001069202-16-000017:mdna:19]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales | $ | 715.2 |  |  | $ | 685.8 |  |  | 4.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 531.6 |  |  | 522.8 |  |  | (1.7 | ) |  | 74.3 |  |  | 76.2 |  |
| Gross profit | 183.6 |  |  | 163.0 |  |  | 12.6 |  |  | 25.7 |  |  | 23.8 |  |
| Selling, general and administrative expenses | 140.4 |  |  | 133.4 |  |  | (5.2 | ) |  | 19.6 |  |  | 19.5 |  |
| Losses (gains) and other expenses, net | 4.3 |  |  | 5.6 |  |  | 23.2 |  |  | 0.6 |  |  | 0.8 |  |
| Restructuring charges | (0.2 | ) |  | 0.3 |  |  | 166.7 |  |  | — |  |  | — |  |
| Income from equity method investments | (4.6 | ) |  | (3.3 | ) |  | 39.4 |  |  | (0.6 | ) |  | (0.5 | ) |
| Operational income from continuing operations | $ | 43.7 |  |  | $ | 27.0 |  |  | 61.9 | % |  | 6.1 | % |  | 3.9 | % |

[0001069202-16-000017:mdna:20]
[same as prior period, unchanged from 0001069202-15-000011:mdna:20]

[0001069202-16-000017:mdna:21]
Net sales increased 4% in the first quarter of 2016 compared to the first quarter of 2015, primarily from 6% higher sales volumes.  The Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments all delivered higher volume by capturing additional replacement and new construction business.  These increases were partially offset by a 2% unfavorable impact from foreign currency exchanges rates.

[0001069202-16-000017:mdna:22]
[same as prior period, unchanged from 0001069202-15-000011:mdna:22]

[0001069202-16-000017:mdna:23]
Gross profit margin in the first quarter of 2016 increased 190 basis points ("bps") to 25.7% compared to the first quarter of 2015.  Our profit margin increased 280 bps from lower material costs, 40 bps from factory productivity, 30 bps from combined freight and distribution, and 10 bps from other savings.  Offsetting this increase were decreases of 120 bps for unfavorable mix and price and 50 bps from unfavorable foreign currency exchange rates.

[0001069202-16-000017:mdna:24]
[same as prior period, unchanged from 0001069202-15-000011:mdna:24]

[0001069202-16-000017:mdna:25]
SG&A was $140 million in the first quarter of 2016 compared to $133 million in the first quarter of 2015, and as a percentage of net sales increased 10 bps to 19.6%.  SG&A expenses have increased due to higher long-term incentive compensation and higher advertising and promotional costs.

[0001069202-16-000017:mdna:26]
[same as prior period, unchanged from 0001069202-15-000011:mdna:66]

[0001069202-16-000017:mdna:27]
Losses and other expenses, net for the first quarter of 2016 and 2015 included the following (in millions):

[0001069202-16-000017:mdna:28]
|  | For the Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Realized losses on settled future contracts | $ | 0.5 |  |  | $ | 0.4 |  |
| Foreign currency exchange losses (gains) | 0.2 |  |  | 1.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (0.5 | ) |  | (0.1 | ) |
| Special legal contingency charges | 1.7 |  |  | 3.4 |  |
| Asbestos-related litigation | 0.8 |  |  | 0.1 |  |
| Contractor tax payments | 0.5 |  |  | — |  |
| Environmental liabilities | 0.7 |  |  | 0.7 |  |
| Acquisition costs | 0.4 |  |  | — |  |
| Losses and other expenses, net | $ | 4.3 |  |  | $ | 5.6 |  |

[0001069202-16-000017:mdna:29]
The net change in unrealized losses (gains) on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange losses decreased in the first quarter of 2016 primarily due to the Australian and Canadian dollar and Brazilian real exchange rates.  Contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  For more information on special legal contingency charges, asbestos-related litigation and contractor tax payments, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000017:mdna:30]
[same as prior period, unchanged from 0001069202-15-000011:mdna:30]

[0001069202-16-000017:mdna:31]
There was a minimal benefit from restructuring charges in the first quarter of 2016 while $0.3 million of restructuring charges were incurred in the first quarter of 2015.  The benefit in the current quarter is due to actual restructuring charges being less than planned restructuring charges.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000017:mdna:32]
[same as prior period, unchanged from 0001069202-15-000011:mdna:32]

[0001069202-16-000017:mdna:33]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $5 million in the first quarter of 2016 increased slightly from the first quarter of 2015.

[0001069202-16-000017:mdna:34]
[same as prior period, unchanged from 0001069202-15-000011:mdna:34]

[0001069202-16-000017:mdna:35]
Interest expense, net of $6 million in the first quarter of 2016 was flat as compared to the first quarter of 2015.

[0001069202-16-000017:mdna:36]
[same as prior period, unchanged from 0001069202-15-000011:mdna:36]

[0001069202-16-000017:mdna:37]
We expect our annual effective tax rate in 2016 and subsequent years to be approximately 32% due to sustainable benefits from restructuring of our international subsidiaries that will enable us to utilize foreign tax credits and other benefits that drives our effective tax rate down by approximately 250 basis points.

[0001069202-16-000017:mdna:38]
First Quarter of 2016 Compared to First Quarter of 2015 - Results by Segment

[0001069202-16-000017:mdna:39]
[same as prior period, unchanged from 0001069202-15-000011:mdna:39]

[0001069202-16-000017:mdna:40]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000017:mdna:41]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 377.3 |  |  | $ | 362.5 |  |  | $ | 14.8 |  |  | 4.1 | % |
| Profit | $ | 38.3 |  |  | $ | 31.2 |  |  | $ | 7.1 |  |  | 22.8 | % |
| % of net sales | 10.2 | % |  | 8.6 | % |  |  |  |  |

[0001069202-16-000017:mdna:42]
Net sales increased by 4% in the first quarter of 2016 compared to the first quarter of 2015.  Sales volumes increased by 5% and were partially offset by a 1% reduction from unfavorable foreign currency exchange rates.

[0001069202-16-000017:mdna:43]
Segment profit for the first quarter of 2016 increased $7 million due to $5 million in higher sales volumes, $14 million in lower commodities and material cost, $2 million from factory productivity, $1 million from lower freight expense and $1 million from other product costs.  Partially offsetting these increases was $10 million unfavorable price and mix combined, $3 million of SG&A expenses primarily for information technology and research and development investments, $2 million from unfavorable foreign currency exchange rates and $1 million in distribution investments.

[0001069202-16-000017:mdna:44]
[same as prior period, unchanged from 0001069202-15-000011:mdna:44]

[0001069202-16-000017:mdna:45]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000017:mdna:46]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 170.3 |  |  | $ | 159.9 |  |  | $ | 10.4 |  |  | 6.5 | % |
| Profit | $ | 14.2 |  |  | $ | 7.7 |  |  | $ | 6.5 |  |  | 84.4 | % |
| % of net sales | 8.3 | % |  | 4.8 | % |  |  |  |  |

[0001069202-16-000017:mdna:47]
Net sales increased 7% in the first quarter of 2016 compared to the first quarter of 2015.  Sales volumes increased by 8% primarily due to North American market growth and share gains partially offset by a 1% reduction from unfavorable foreign currency exchange rates.

[0001069202-16-000017:mdna:48]
Segment profit in the first quarter of 2016 increased $7 million compared to the first quarter of 2015 due to $4 million in higher sales volumes, $3 million in lower commodities and material cost, $1 million from combined price and mix, and $1 million from lower freight and distribution expenses.  Partially offsetting these increases was $1 million of SG&A inflation and $1 million from increases in other product costs.

[0001069202-16-000017:mdna:49]
[same as prior period, unchanged from 0001069202-15-000011:mdna:49]

[0001069202-16-000017:mdna:50]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000017:mdna:51]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 167.6 |  |  | $ | 163.4 |  |  | $ | 4.2 |  |  | 2.6 | % |
| Profit | $ | 9.0 |  |  | $ | 4.0 |  |  | $ | 5.0 |  |  | 125.0 | % |
| % of net sales | 5.4 | % |  | 2.4 | % |  |  |  |  |

[0001069202-16-000017:mdna:52]
Net sales increased 3% in the first quarter of 2016 compared to the first quarter of 2015.  Volume increased by 7% primarily due to strong performance in North America industry growth.  Partially offsetting this volume growth was a 1% decline from price and 3% reduction from unfavorable foreign currency exchange rates.

[0001069202-16-000017:mdna:53]
Segment profit for the first quarter of 2016 increased $5 million compared to the first quarter of 2015 due to $3 million in higher sales volumes, $3 million from lower commodities and material costs, $1 million from lower depreciation and amortization due to the impairment of our Kysor Warren business recorded in 2015 and $2 million in factory productivity and lower other product costs.  Partially offsetting these increases was $3 million of unfavorable combined price and mix and $1 million in higher SG&A expenses.

[0001069202-16-000017:mdna:54]
[same as prior period, unchanged from 0001069202-15-000011:mdna:55]

[0001069202-16-000017:mdna:55]
Corporate and other expenses increased $3 million to $15 million in the first quarter of 2016 from $12 million in the first quarter of 2015 primarily due to long term incentive compensation, health care costs and general wage inflation.

[0001069202-16-000017:mdna:56]
[same as prior period, unchanged from 0001069202-15-000011:mdna:97]

[0001069202-16-000017:mdna:57]
[same as prior period, unchanged from 0001069202-15-000011:mdna:98]

[0001069202-16-000017:mdna:58]
[same as prior period, unchanged from 0001069202-15-000011:mdna:99]

[0001069202-16-000017:mdna:59]
The following table summarizes our cash flow activity for the three months ended March 31, 2016 and 2015 (in millions):

[0001069202-16-000017:mdna:60]
|  | For the Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Net cash used in operating activities | $ | (113.4 | ) |  | $ | (122.2 | ) |
| Net cash used in investing activities | (23.8 | ) |  | (18.0 | ) |
| Net cash provided by financing activities | 137.3 |  |  | 144.0 |  |

[0001069202-16-000017:mdna:61]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first three months of 2016 and 2015 reflects the seasonal increase in working capital requirements.  The $9 million decrease in net cash used in operating activities quarter over quarter is primarily attributable to the seasonal increase in working capital requirements in 2016 being smaller than the increase in 2015.

[0001069202-16-000017:mdna:62]
Net Cash Used in Investing Activities - Capital expenditures were $24 million and $18 million in the first three months of 2016 and 2015, respectively.  Capital expenditures in 2016 were primarily related to investments in systems and software to support the overall enterprise and continued investments in our distribution network.

[0001069202-16-000017:mdna:63]
Net Cash Provided by Financing Activities - Net cash provided by financing activities decreased to $137 million in the first three months of 2016 primarily due to an increase in stock repurchases partially offset by increases in borrowings.   Net borrowings were higher in 2016 to support the increased stock repurchases and dividend payments.  Final settlement of the $200 million Accelerated Share Repurchase Plan (ASR) executed in the first quarter of 2016 will be in the second quarter of 2016.

[0001069202-16-000017:mdna:64]
[same as prior period, unchanged from 0001069202-15-000011:mdna:105]

[0001069202-16-000017:mdna:65]
The following table details our lines of credit and financing arrangements as of March 31, 2016 (in millions):

[0001069202-16-000017:mdna:66]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 4.0 |  |
| Asset Securitization Program (1) | 180.0 |  |
| Total short-term debt | $ | 184.0 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 1.1 |  |
| Domestic credit facility (2) | 30.0 |  |
| Debt issuance costs | (0.2 | ) |
| Total current maturities of long-term debt | $ | 30.9 |  |
| Long-term debt: |  |
| Capital lease obligations | 15.4 |  |
| Domestic credit facility (2) | 671.5 |  |
| Senior unsecured notes | 200.0 |  |
| Debt issuance costs | (2.4 | ) |
| Total long-term debt | 884.5 |  |
| Total debt | $ | 1,099.4 |  |

[0001069202-16-000017:mdna:67]
[same as prior period, unchanged from 0001069202-15-000011:mdna:108]

[0001069202-16-000017:mdna:68]
(2) The available future borrowings on our domestic credit facility are $221.6 million after being reduced by the outstanding borrowings and $4.4 million in outstanding standby letters of credit.  We also had $40.8 million in outstanding standby letters of credit outside of the domestic credit facility as of March 31, 2016.

[0001069202-16-000017:mdna:69]
[same as prior period, unchanged from 0001069202-15-000011:mdna:110]

[0001069202-16-000017:mdna:70]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 107.1% at March 31, 2016 from 87.9% at December 31, 2015.

[0001069202-16-000017:mdna:71]
As of March 31, 2016, our senior credit ratings were Baa3 with a negative outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to ensure the capital markets remain available to us.

[0001069202-16-000017:mdna:72]
[same as prior period, unchanged from 0001069202-15-000011:mdna:113]

[0001069202-16-000017:mdna:73]
We believe our cash and cash equivalents of $41 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $41 million as of March 31, 2016 was $24.4 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States. If we were to repatriate foreign earnings, we would be required to accrue and pay taxes in the United States, less foreign tax credits, for the amounts that were repatriated.

[0001069202-16-000017:mdna:74]
Our expected capital expenditures for 2016 are $95 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with the completion of our $200 million accelerated share repurchase program in 2016 and a target of between $65 million and $75 million of dividend payments in 2016.

[0001069202-16-000017:mdna:75]
[same as prior period, unchanged from 0001069202-15-000011:mdna:116]

[0001069202-16-000017:mdna:76]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Our operating lease commitments have not materially changed since December 31, 2015.

[0001069202-16-000017:mdna:77]
Commitments, Contingencies and Guarantees

[0001069202-16-000017:mdna:78]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000017:mdna:79]
[same as prior period, unchanged from 0001069202-15-000011:mdna:120]

[0001069202-16-000017:mdna:80]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We will adopt the new standard using the modified retrospective approach and are still determining the effect of the standard on our ongoing financial reporting.

[0001069202-16-000017:mdna:81]
In January 2015, the FASB issued ASU No. 2015-01, Income Statement - Extraordinary and Unusual Items (Subtopic 225-20): Simplifying Income Statement Presentation by Eliminating the Concept of Extraordinary Items. ASU No. 2015-01 eliminates the concept of an extraordinary item from GAAP. As a result, an entity will no longer be required to separately present an extraordinary item on its statement of operations, net of tax, after income from continuing operations or to disclose income taxes and net income per share data applicable to an extraordinary item. However, ASU No. 2015-01 will still retain the presentation and disclosure guidance for items that are unusual in nature and occur infrequently. ASU No. 2015-01 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period, although early adoption is permitted. The adoption of this standard did not materially impact our consolidated financial statements.

[0001069202-16-000017:mdna:82]
In February 2015, the FASB issued ASU 2015-02, Consolidation: Amendments to the Consolidation Analysis, or ASU 2015-02, which amends the criteria for determining which entities are considered variable interest entities (“VIEs”), amends the criteria for determining if a service provider possesses a variable interest in a VIE and ends the deferral granted to investment companies for application of the VIE consolidation model. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015 and early adoption is permitted. The adoption of this standard did not materially impact our consolidated financial statements.

[0001069202-16-000017:mdna:83]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015, and early adoption is permitted. The adoption of this standard did not materially impact our consolidated financial statements.

[0001069202-16-000017:mdna:84]
In November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes (Topic 740) that simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. We adopted this standard retrospectively as of December 31, 2015.

[0001069202-16-000017:mdna:85]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001069202-16-000017:mdna:86]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. The ASU includes multiple provisions intended to simplify various aspects of the

[0001069202-16-000017:mdna:87]
accounting for share-based payments. Excess tax benefits for share-based payments will be recorded as a reduction of income taxes and reflected in operating cash flows upon the adoption of this ASU.  Excess tax benefits are currently recorded in equity and as financing activity under the current rules. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2016.
