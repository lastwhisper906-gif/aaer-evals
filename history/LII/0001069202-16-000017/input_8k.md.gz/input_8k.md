# LII 8-K — 0001193125-16-543967 filed 2016-04-18

## item codes, every 8-K on or before 2016-04-18

- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2016-04-18

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-543967:8k_2_02:1]
EX-99.1
2
d181528dex991.htm
EX-99.1

[0001193125-16-543967:8k_2_02:2]
EX-99.1

[0001193125-16-543967:8k_2_02:3]
Exhibit 99.1

[0001193125-16-543967:8k_2_02:4]
Lennox International Reports Record First-Quarter Profit

[0001193125-16-543967:8k_2_02:5]
|  | • |  | Revenue up 4% and up 6% at constant currency |

[0001193125-16-543967:8k_2_02:6]
|  | • |  | Adjusted EPS from continuing operations of $0.60, up 62% |

[0001193125-16-543967:8k_2_02:7]
|  | • |  | GAAP EPS from continuing operations of $0.56, up 81% |

[0001193125-16-543967:8k_2_02:8]
|  | • |  | Reiterating 2016 revenue growth guidance of 4-8% at constant currency |

[0001193125-16-543967:8k_2_02:9]
|  | • |  | Raising 2016 adjusted EPS from continuing operations guidance from $6.10-$6.60 to $6.30-$6.80 |

[0001193125-16-543967:8k_2_02:10]
|  | • |  | Raising 2016 GAAP EPS from continuing operations guidance from $6.10-$6.60 to $6.26-$6.76 |

[0001193125-16-543967:8k_2_02:11]
DALLAS, April 18, 2016 – Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2016.

[0001193125-16-543967:8k_2_02:12]
Revenue for the first quarter was $715 million, up 4% from the prior-year quarter including the negative impact from foreign exchange. At constant currency,
revenue was up 6%. Adjusted earnings per share from continuing operations was a first-quarter record $0.60, up 62% from the prior-year quarter. On a GAAP basis, earnings per share from continuing operations was a first-quarter record $0.56, up 81%
from the prior-year quarter.

[0001193125-16-543967:8k_2_02:13]
“Lennox International realized strong revenue growth and margin expansion across all three of our businesses in the
first quarter,” said Chairman and CEO Todd Bluedorn. “For the company overall, total segment profit rose 50% from the prior-year quarter to a new first-quarter high, and profit margin expanded 200 basis points to a first-quarter record of
6.5%. In our Residential business, segment profit was up 23% on 5% revenue growth at constant currency. Residential margin rose 160 basis points to a first-quarter record of 10.2%. In our Commercial business, segment profit rose 84% to a new
first-quarter high. Commercial revenue was up 8% at constant currency, and segment margin expanded 350 basis points to a new first-quarter high of 8.3%. In Refrigeration, revenue was up 6% at constant currency, led by double-digit growth in North
America. Refrigeration profit rose 125% as segment margin expanded 300 basis points to 5.4%.

[0001193125-16-543967:8k_2_02:14]
“Looking ahead for the company overall, it is early in
the year and the largest seasonal quarters are still in front of us, but 2016 is off to a strong start, and we continue to expect another record year. While our underlying business expectations for the full year remain consistent with previous
adjusted EPS from continuing operations guidance of $6.10-$6.60, we are raising guidance to $6.30-$6.80 to reflect a new full-year effective tax rate of approximately 32% versus prior guidance of 34-35%. We are reiterating guidance for revenue
growth of 4-8% at constant currency for the year. The company is well-positioned for continued momentum in 2016, and we remain focused on capitalizing on end market growth, capturing additional market share, and driving operational initiatives for
higher profitability.”

[0001193125-16-543967:8k_2_02:15]
FINANCIAL HIGHLIGHTS

[0001193125-16-543967:8k_2_02:16]
Revenue: Revenue for the first quarter was $715 million, up 4% from the prior-year quarter. At constant currency, revenue was up 6%. Volume was up, and
price/mix was flat on a revenue basis from the prior-year quarter.

[0001193125-16-543967:8k_2_02:17]
Gross Profit: Gross profit in the first quarter was $184 million, up 13% from
$163 million in the prior-year quarter. Gross margin was 25.7%, up 190 basis points from 23.8% in the prior-year quarter. Gross profit was positively impacted by higher volume, lower material costs, and higher productivity, with partial offsets from
negative price/mix and unfavorable foreign exchange.

[0001193125-16-543967:8k_2_02:18]
Income from Continuing Operations: Adjusted income from continuing operations in the first
quarter was $27.0 million, or $0.60 per share, compared to $16.8 million, or $0.37 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the first quarter of 2016 excludes $2.1 million in after-tax charges: $1.2
million for special legal contingency charges and $0.9 million, net, for other items.

[0001193125-16-543967:8k_2_02:19]
On a GAAP basis, income from continuing operations for the first
quarter was $24.9 million, or $0.56 per share, compared to $14.0 million, or $0.31 per share, in the prior-year quarter.

[0001193125-16-543967:8k_2_02:20]
Free Cash Flow and Total
Debt: Net cash from operations in the first quarter was ($113) million compared to ($122) million in the prior-year quarter. Capital expenditures were $24 million in the first quarter compared to $18 million in the first quarter a year ago. Free
cash flow was ($137) million compared to ($140) million in the prior-year quarter. Total debt at the end of the first quarter was $1,099 million. Total cash and cash equivalents were $41 million at the end of the quarter. The company paid $16
million in dividends in the first quarter. The company’s previously announced $200 million accelerated stock repurchase program continues and will be completed in the second quarter of 2016.

[0001193125-16-543967:8k_2_02:21]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-16-543967:8k_2_02:22]
Residential Heating & Cooling

[0001193125-16-543967:8k_2_02:23]
Revenue in the
Residential Heating & Cooling business segment was $377 million, up 4% from the prior-year quarter. At constant currency, revenue was up 5%. Segment profit was $38 million, up 23% from the prior-year quarter. Segment profit margin was a
first-quarter record 10.2%, up 160 basis points from the prior-year quarter. Results were impacted by higher volume, lower material costs, lower freight costs, and higher productivity, with partial offsets from unfavorable price/mix, foreign
exchange and investments in SG&A and distribution expansion.

[0001193125-16-543967:8k_2_02:24]
Commercial Heating & Cooling

[0001193125-16-543967:8k_2_02:25]
Revenue in the Commercial Heating & Cooling business segment was $170 million in the first quarter, up 7% from the prior-year quarter. At constant
currency, revenue was up 8%. Segment profit was a first-quarter record $14 million, up 84% from the prior-year quarter. Segment profit margin was a first-quarter record 8.3%, up 350 basis points from the prior-year quarter. Results were impacted by
higher volume, favorable price/mix, lower material costs, and lower freight and distribution costs, with partial offsets from unfavorable foreign exchange and higher SG&A.

[0001193125-16-543967:8k_2_02:26]
Refrigeration

[0001193125-16-543967:8k_2_02:27]
Revenue in the Refrigeration business
segment was $168 million in the first quarter, up 3%. At constant currency, revenue was up 6%. Segment profit was $9 million, up 125% from the prior-year quarter. Segment profit margin was 5.4%, up 300 basis points from the prior-year quarter.
Results were impacted by higher volume, lower material costs, lower freight and distribution costs, and higher productivity, with a partial offset from unfavorable price/mix.

[0001193125-16-543967:8k_2_02:28]
FULL-YEAR OUTLOOK

[0001193125-16-543967:8k_2_02:29]
For 2016, the company is reiterating
guidance for revenue growth and raising guidance for EPS from continuing operations.

[0001193125-16-543967:8k_2_02:30]
|  | • |  | Reiterating guidance for revenue growth at constant currency of 4-8%; the company still expects a negative 1 point impact on revenue from foreign exchange on a full-year basis, equating to revenue growth guidance of 3-7% at actual currency. |

[0001193125-16-543967:8k_2_02:31]
|  | • |  | Raising adjusted EPS from continuing operations guidance from a range of $6.10-$6.60 to $6.30-$6.80, reflecting a new full-year effective tax rate of approximately 32% compared to prior guidance of 34-35%. |

[0001193125-16-543967:8k_2_02:32]
|  | • |  | Updating guidance for GAAP EPS from continuing operations from a range of $6.10-$6.60 to $6.26-$6.76. |

[0001193125-16-543967:8k_2_02:33]
|  | • |  | Updating fully diluted share count guidance from 44-45 million shares to approximately 44 million shares on a full-year basis. |

[0001193125-16-543967:8k_2_02:34]
|  | • |  | Reiterating capital expenditure guidance of approximately $95 million. |

[0001193125-16-543967:8k_2_02:35]
CONFERENCE CALL INFORMATION

[0001193125-16-543967:8k_2_02:36]
A conference call to discuss the company’s first quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call
line at 612-332-0107 at least 10 minutes prior to the scheduled start time and use reservation number 390891. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available
from 11:00 a.m. Central time on April 18 through May 2, 2016 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 390891. The call also will be archived on the company’s web site.

[0001193125-16-543967:8k_2_02:37]
About Lennox International

[0001193125-16-543967:8k_2_02:38]
Lennox International Inc. is
a global leader in the heating, air conditioning, and refrigeration markets. Lennox International is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at:
www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-16-543967:8k_2_02:39]
Forward-Looking Statements

[0001193125-16-543967:8k_2_02:40]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-543967:8k_2_02:41]
Consolidated Statements of Operations

[0001193125-16-543967:8k_2_02:42]
(Unaudited)

[0001193125-16-543967:8k_2_02:43]
| (Amounts in millions, except per share data) |  | For the Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 715.2 |  |  | $ | 685.8 |  |
| Cost of goods sold |  |  | 531.6 |  |  |  | 522.8 |  |
| Gross profit |  |  | 183.6 |  |  |  | 163.0 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 140.4 |  |  |  | 133.4 |  |
| Losses and other expenses, net |  |  | 4.3 |  |  |  | 5.6 |  |
| Restructuring (gains) charges |  |  | (0.2 | ) |  |  | 0.3 |  |
| Income from equity method investments |  |  | (4.6 | ) |  |  | (3.3 | ) |
| Operational income from continuing operations |  |  | 43.7 |  |  |  | 27.0 |  |
| Interest expense, net |  |  | 5.8 |  |  |  | 5.7 |  |
| Other expense (income), net |  |  | — |  |  |  | — |  |
| Income from continuing operations before income taxes |  |  | 37.9 |  |  |  | 21.3 |  |
| Provision for income taxes |  |  | 13.0 |  |  |  | 7.3 |  |
| Income from continuing operations |  |  | 24.9 |  |  |  | 14.0 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | — |  |  |  | (0.2 | ) |
| Benefit from income taxes |  |  | — |  |  |  | (0.1 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | (0.1 | ) |
| Net income |  | $ | 24.9 |  |  | $ | 13.9 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.57 |  |  | $ | 0.31 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 0.57 |  |  | $ | 0.31 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.56 |  |  | $ | 0.31 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 0.56 |  |  | $ | 0.31 |  |
| Weighted Average Number of Shares Outstanding—Basic |  |  | 44.0 |  |  |  | 44.7 |  |
| Weighted Average Number of Shares Outstanding—Diluted |  |  | 44.7 |  |  |  | 45.5 |  |
| Cash dividends declared per share |  | $ | 0.36 |  |  | $ | 0.30 |  |

[0001193125-16-543967:8k_2_02:44]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-543967:8k_2_02:45]
Segment Net Sales and Profit (Loss)

[0001193125-16-543967:8k_2_02:46]
(Unaudited)

[0001193125-16-543967:8k_2_02:47]
| (Amounts in millions) |  | For the Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Net sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 377.3 |  |  | $ | 362.5 |  |
| Commercial Heating & Cooling |  |  | 170.3 |  |  |  | 159.9 |  |
| Refrigeration |  |  | 167.6 |  |  |  | 163.4 |  |
|  |  | $ | 715.2 |  |  | $ | 685.8 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 38.3 |  |  | $ | 31.2 |  |
| Commercial Heating & Cooling |  |  | 14.2 |  |  |  | 7.7 |  |
| Refrigeration |  |  | 9.0 |  |  |  | 4.0 |  |
| Corporate and other |  |  | (14.8 | ) |  |  | (11.7 | ) |
| Total segment profit |  |  | 46.7 |  |  |  | 31.2 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (0.4 | ) |  |  | (0.2 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 3.6 |  |  |  | 4.1 |  |
| Restructuring charges |  |  | (0.2 | ) |  |  | 0.3 |  |
| Interest expense, net |  |  | 5.8 |  |  |  | 5.7 |  |
| Income from continuing operations before income taxes |  | $ | 37.9 |  |  | $ | 21.3 |  |

[0001193125-16-543967:8k_2_02:48]
| (1) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-16-543967:8k_2_02:49]
|  | • |  | Special product quality adjustments; |

[0001193125-16-543967:8k_2_02:50]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-16-543967:8k_2_02:51]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-16-543967:8k_2_02:52]
|  | • |  | Special legal contingency charges, |

[0001193125-16-543967:8k_2_02:53]
|  | • |  | Asbestos-related litigation, |

[0001193125-16-543967:8k_2_02:54]
|  | • |  | Contractor tax payments, |

[0001193125-16-543967:8k_2_02:55]
|  | • |  | Environmental liabilities, |

[0001193125-16-543967:8k_2_02:56]
|  | • |  | and Other items, net; |

[0001193125-16-543967:8k_2_02:57]
|  | • |  | Restructuring charges; |

[0001193125-16-543967:8k_2_02:58]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments; |

[0001193125-16-543967:8k_2_02:59]
|  | • |  | Interest expense, net; and |

[0001193125-16-543967:8k_2_02:60]
|  | • |  | Other expense, net. |

[0001193125-16-543967:8k_2_02:61]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-543967:8k_2_02:62]
Consolidated Balance Sheets

[0001193125-16-543967:8k_2_02:63]
| (Amounts in millions, except shares and par values) |  | As of March 31,2016 |  |  | As of December 31,2015 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 40.6 |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net of allowances of $6.5 and $6.3 in 2016 and 2015, respectively |  |  | 469.8 |  |  |  | 422.8 |  |
| Inventories, net |  |  | 518.1 |  |  |  | 418.8 |  |
| Other assets |  |  | 93.1 |  |  |  | 57.7 |  |
| Total current assets |  |  | 1,121.6 |  |  |  | 938.2 |  |
| Property, plant and equipment, net of accumulated depreciation of $691.0 and $682.9 in 2016 and 2015, respectively |  |  | 338.5 |  |  |  | 339.6 |  |
| Goodwill |  |  | 197.0 |  |  |  | 195.1 |  |
| Deferred income taxes |  |  | 140.5 |  |  |  | 145.7 |  |
| Other assets, net |  |  | 63.4 |  |  |  | 58.8 |  |
| Total assets |  | $ | 1,861.0 |  |  | $ | 1,677.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 184.0 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt |  |  | 30.9 |  |  |  | 31.0 |  |
| Accounts payable |  |  | 378.3 |  |  |  | 320.1 |  |
| Accrued expenses |  |  | 209.4 |  |  |  | 242.6 |  |
| Income taxes payable |  |  | 0.6 |  |  |  | 26.0 |  |
| Total current liabilities |  |  | 803.2 |  |  |  | 823.8 |  |
| Long-term debt |  |  | 884.5 |  |  |  | 506.0 |  |
| Post-retirement benefits, other than pensions |  |  | 3.4 |  |  |  | 4.1 |  |
| Pensions |  |  | 121.9 |  |  |  | 120.8 |  |
| Other liabilities |  |  | 121.3 |  |  |  | 121.1 |  |
| Total liabilities |  |  | 1,934.3 |  |  |  | 1,575.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 966.9 |  |  |  | 1,002.4 |  |
| Retained earnings |  |  | 1,155.8 |  |  |  | 1,146.7 |  |
| Accumulated other comprehensive loss |  |  | (190.7 | ) |  |  | (204.7 | ) |
| Treasury stock, at cost, 43,571,220 shares and 42,491,910 shares as of March 31, 2016 and December 31, 2015, respectively |  |  | (2,006.7 | ) |  |  | (1,844.1 | ) |
| Noncontrolling interests |  |  | 0.5 |  |  |  | 0.4 |  |
| Total stockholders’ equity |  |  | (73.3 | ) |  |  | 101.6 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,861.0 |  |  | $ | 1,677.4 |  |

[0001193125-16-543967:8k_2_02:64]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-543967:8k_2_02:65]
Consolidated Statements of Cash Flows

[0001193125-16-543967:8k_2_02:66]
(Unaudited)

[0001193125-16-543967:8k_2_02:67]
| (Amounts in millions) |  | For the Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 24.9 |  |  | $ | 13.9 |  |
| Net loss from discontinued operations |  |  | — |  |  |  | 0.1 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (4.6 | ) |  |  | (3.3 | ) |
| Restructuring expenses, net of cash paid |  |  | (0.5 | ) |  |  | (0.1 | ) |
| Provision for bad debts |  |  | 1.3 |  |  |  | 0.9 |  |
| Unrealized (gains) losses on derivative contracts |  |  | (0.5 | ) |  |  | 0.2 |  |
| Stock-based compensation expense |  |  | 6.3 |  |  |  | 3.5 |  |
| Depreciation and amortization |  |  | 14.2 |  |  |  | 15.5 |  |
| Deferred income taxes |  |  | (0.5 | ) |  |  | (1.1 | ) |
| Other items, net |  |  | 0.1 |  |  |  | 0.1 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (44.5 | ) |  |  | (40.1 | ) |
| Inventories |  |  | (95.5 | ) |  |  | (78.5 | ) |
| Other current assets |  |  | (6.2 | ) |  |  | 1.0 |  |
| Accounts payable |  |  | 67.9 |  |  |  | 29.6 |  |
| Accrued expenses |  |  | (28.0 | ) |  |  | (29.0 | ) |
| Income taxes payable and receivable |  |  | (49.4 | ) |  |  | (40.1 | ) |
| Other |  |  | 1.6 |  |  |  | 5.3 |  |
| Net cash used in discontinued operations |  |  | — |  |  |  | (0.1 | ) |
| Net cash used in operating activities |  |  | (113.4 | ) |  |  | (122.2 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (23.8 | ) |  |  | (18.0 | ) |
| Net cash used in investing activities |  |  | (23.8 | ) |  |  | (18.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (0.4 | ) |  |  | (0.2 | ) |
| Asset securitization payments |  |  | (20.0 | ) |  |  | (40.0 | ) |
| Long-term debt payments |  |  | (0.3 | ) |  |  | — |  |
| Borrowings from credit facility |  |  | 770.5 |  |  |  | 580.5 |  |
| Payments on credit facility |  |  | (392.0 | ) |  |  | (379.0 | ) |
| Proceeds from employee stock purchases |  |  | 0.6 |  |  |  | 0.6 |  |
| Repurchases of common stock |  |  | (200.0 | ) |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (16.8 | ) |  |  | (20.5 | ) |
| Excess tax benefits related to share-based payments |  |  | 11.8 |  |  |  | 16.0 |  |
| Cash dividends paid |  |  | (16.1 | ) |  |  | (13.4 | ) |
| Net cash provided by financing activities |  |  | 137.3 |  |  |  | 144.0 |  |
| Increase in cash and cash equivalents |  |  | 0.1 |  |  |  | 3.8 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | 1.6 |  |  |  | (4.6 | ) |
| Cash and cash equivalents, beginning of period |  |  | 38.9 |  |  |  | 37.5 |  |
| Cash and cash equivalents, end of period |  | $ | 40.6 |  |  | $ | 36.7 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 3.3 |  |  | $ | 3.1 |  |
| Income taxes paid (net of refunds) |  | $ | 51.2 |  |  | $ | 32.2 |  |

[0001193125-16-543967:8k_2_02:68]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-543967:8k_2_02:69]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-16-543967:8k_2_02:70]
(Unaudited, in millions, except per share and ratio data)

[0001193125-16-543967:8k_2_02:71]
Use of Non-GAAP Financial Measures

[0001193125-16-543967:8k_2_02:72]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide
information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating
performance.

[0001193125-16-543967:8k_2_02:73]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-16-543967:8k_2_02:74]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Income from continuing operations, a GAAP measure |  | $ | 24.9 |  |  | $ | 14.0 |  |
| Restructuring charges, after tax |  |  | (0.1 | ) |  |  | 0.2 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.3 | ) |  |  | (0.1 | ) |
| Special legal contingency charges, after tax (a) |  |  | 1.2 |  |  |  | 2.2 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.5 |  |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | (0.3 | ) |  |  | (0.1 | ) |
| Environmental liabilities, after tax (a) |  |  | 0.5 |  |  |  | 0.5 |  |
| Contractor tax payments (a) |  |  | 0.3 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | 0.3 |  |  |  | — |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 27.0 |  |  | $ | 16.8 |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 0.56 |  |  | $ | 0.31 |  |
| Restructuring charges, after tax |  |  | (0.01 | ) |  |  | — |  |
| Special product quality adjustments, after tax (b) |  |  | (0.01 | ) |  |  | — |  |
| Special legal contingency charges, after tax (a) |  |  | 0.03 |  |  |  | 0.05 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.01 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | (0.01 | ) |  |  | — |  |
| Environmental liabilities, after tax (a) |  |  | 0.01 |  |  |  | 0.01 |  |
| Contractor tax payments, after tax (a) |  |  | 0.01 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | 0.01 |  |  |  | — |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  | $ | 0.60 |  |  | $ | 0.37 |  |

[0001193125-16-543967:8k_2_02:75]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-16-543967:8k_2_02:76]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-16-543967:8k_2_02:77]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.5 |  |  | $ | 0.4 |  |
| Foreign currency exchange losses (gains) (a) |  |  | 0.2 |  |  |  | 1.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | (0.5 | ) |  |  | (0.1 | ) |
| Special legal contingency charges (b) |  |  | 1.7 |  |  |  | 3.4 |  |
| Asbestos-related litigation (b) |  |  | 0.8 |  |  |  | 0.1 |  |
| Environmental liabilities (b) |  |  | 0.7 |  |  |  | 0.7 |  |
| Contractor tax payments (b) |  |  | 0.5 |  |  |  | — |  |
| Acquisition costs (b) |  |  | 0.4 |  |  |  | — |  |
| Losses and other expenses, net (pre-tax) |  | $ | 4.3 |  |  | $ | 5.6 |  |

[0001193125-16-543967:8k_2_02:78]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-16-543967:8k_2_02:79]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-16-543967:8k_2_02:80]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations—Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations—Diluted, a GAAP measure

[0001193125-16-543967:8k_2_02:81]
|  |  | For the Year EndedDecember 31, 2016ESTIMATED |  |
| Adjusted income per share from continuing operations—diluted, a Non-GAAP measure |  | $ | 6.30 - $6.80 |  |
| Special loss contingencies and other items |  |  | (0.04 | ) |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 6.26 - $6.76 |  |

[0001193125-16-543967:8k_2_02:82]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars
in millions)

[0001193125-16-543967:8k_2_02:83]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | (113.4 | ) |  | $ | (122.2 | ) |
| Purchases of property, plant and equipment |  |  | (23.8 | ) |  |  | (18.0 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | (137.2 | ) |  | $ | (140.2 | ) |

[0001193125-16-543967:8k_2_02:84]
|  |  | TrailingTwelveMonths toMarch 31, 2016 |  |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |
| Adjusted EBIT (a) |  | $ | 393.1 |  |
| Depreciation and amortization expense (b) |  |  | 61.5 |  |
| EBITDA (a + b) |  | $ | 454.6 |  |
| Total debt at March 31, 2016 (c) |  |  | 1,099.4 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.4 |  |

[0001193125-16-543967:8k_2_02:85]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP
measure (dollars in millions)

[0001193125-16-543967:8k_2_02:86]
|  |  | TrailingTwelveMonths toMarch 31, 2016 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 393.1 |  |
| Special product quality adjustments |  |  | (2.3 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 15.2 |  |
| Restructuring charges |  |  | 2.7 |  |
| Interest expense, net |  |  | 23.6 |  |
| Special inventory write down |  |  | 5.6 |  |
| Goodwill impairment |  |  | 5.5 |  |
| Asset impairment |  |  | 44.5 |  |
| Other expenses, net |  |  | (0.8 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 299.1 |  |
