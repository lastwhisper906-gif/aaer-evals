# LII notes — 0001628280-23-035265


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-23-035265:notes:1]
[same as prior period, unchanged from 0001628280-23-025847:notes:1]

[0001628280-23-035265:notes:2]
[same as prior period, unchanged from 0001628280-23-025847:notes:2]

[0001628280-23-035265:notes:3]
[same as prior period, unchanged from 0001628280-23-025847:notes:3]

[0001628280-23-035265:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2023, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three and nine months ended September 30, 2023 and 2022, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2023 and 2022 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2022.

[0001628280-23-035265:notes:5]
[same as prior period, unchanged from 0001628280-23-025847:notes:5]

[0001628280-23-035265:notes:6]
[same as prior period, unchanged from 0001628280-23-025847:notes:6]

[0001628280-23-035265:notes:7]
[same as prior period, unchanged from 0001628280-23-025847:notes:7]

[0001628280-23-035265:notes:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-23-035265:notes:9]
[same as prior period, unchanged from 0001628280-23-025847:notes:9]

[0001628280-23-035265:notes:10]
[same as prior period, unchanged from 0001628280-23-025847:notes:10]

[0001628280-23-035265:notes:11]
[same as prior period, unchanged from 0001628280-23-025847:notes:11]

[0001628280-23-035265:notes:12]
[same as prior period, unchanged from 0001628280-23-025847:notes:12]

[0001628280-23-035265:notes:13]
[same as prior period, unchanged from 0001628280-23-025847:notes:13]

[0001628280-23-035265:notes:14]
[same as prior period, unchanged from 0001628280-23-025847:notes:14]

[0001628280-23-035265:notes:15]
[same as prior period, unchanged from 0001628280-23-025847:notes:15]

[0001628280-23-035265:notes:16]
[same as prior period, unchanged from 0001628280-23-025847:notes:16]

[0001628280-23-035265:notes:17]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 (2) |  | 2023 |  | 2022 (2) |
| Net sales |  |  |  |  |  |  |  |
| Residential | $ | 896.3 |  |  | $ | 835.3 |  |  | $ | 2,513.6 |  |  | $ | 2,494.9 |  |
| Commercial (2) | 405.5 |  |  | 352.3 |  |  | 1,121.5 |  |  | 959.2 |  |
| Corporate and other (2) | 64.5 |  |  | 57.3 |  |  | 192.0 |  |  | 170.5 |  |
|  | $ | 1,366.3 |  |  | $ | 1,244.9 |  |  | $ | 3,827.1 |  |  | $ | 3,624.6 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential | $ | 181.4 |  |  | $ | 153.8 |  |  | $ | 495.2 |  |  | $ | 477.7 |  |
| Commercial (2) | 97.3 |  |  | 52.4 |  |  | 250.3 |  |  | 117.4 |  |
| Corporate and other (2) | (23.4) |  |  | (16.9) |  |  | (65.2) |  |  | (61.4) |  |
| Total segment profit | 255.3 |  |  | 189.3 |  |  | 680.3 |  |  | 533.7 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Impairment on assets held for sale | $ | 63.2 |  |  | — |  |  | $ | 63.2 |  |  | — |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 5.0 |  |  | 3.3 |  |  | 12.1 |  |  | 7.9 |  |
| Restructuring charges | 0.3 |  |  | 0.2 |  |  | 0.2 |  |  | 1.2 |  |
| Operating income | $ | 186.8 |  |  | $ | 185.8 |  |  | $ | 604.8 |  |  | $ | 524.6 |  |

[0001628280-23-035265:notes:18]
[same as prior period, unchanged from 0001628280-23-025847:notes:18]

[0001628280-23-035265:notes:19]
[same as prior period, unchanged from 0001628280-23-025847:notes:19]

[0001628280-23-035265:notes:20]
▪Net change in unrealized (gains) losses on unsettled futures contracts,

[0001628280-23-035265:notes:21]
▪Environmental liabilities and special litigation charges, and;

[0001628280-23-035265:notes:22]
▪Other items, net

[0001628280-23-035265:notes:23]
◦Restructuring charges and;

[0001628280-23-035265:notes:24]
◦Impairment on assets held for sale
(2) 2022 results have been recast to reflect the realignment of our reportable segments.


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-035265:notes:25]
[same as prior period, unchanged from 0001628280-23-025847:notes:24]

[0001628280-23-035265:notes:26]
[same as prior period, unchanged from 0001628280-23-025847:notes:25]

[0001628280-23-035265:notes:27]
[same as prior period, unchanged from 0001628280-23-025847:notes:26]

[0001628280-23-035265:notes:28]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income | $ | 130.4 |  |  | $ | 141.9 |  |  | $ | 445.6 |  |  | $ | 402.7 |  |
| Weighted-average shares outstanding – basic | 35.5 |  |  | 35.4 |  |  | 35.5 |  |  | 35.8 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Weighted-average shares outstanding – diluted | 35.7 |  |  | 35.5 |  |  | 35.6 |  |  | 35.9 |  |
| Earnings per share – Basic: | $ | 3.67 |  |  | $ | 4.00 |  |  | $ | 12.55 |  |  | $ | 11.25 |  |
| Earnings per share – Diluted: | $ | 3.65 |  |  | $ | 3.99 |  |  | $ | 12.51 |  |  | $ | 11.22 |  |

[0001628280-23-035265:notes:29]
[same as prior period, unchanged from 0001628280-23-025847:notes:28]

[0001628280-23-035265:notes:30]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Weighted-average number of shares | 0.1 |  |  | 0.3 |  |  | 0.1 |  |  | 0.3 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-23-035265:notes:31]
4. Commitments and Contingencies:

[0001628280-23-035265:notes:32]
Leases

[0001628280-23-035265:notes:33]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001628280-23-035265:notes:34]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001628280-23-035265:notes:35]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001628280-23-035265:notes:36]
We lease certain real and personal property under non-cancelable operating leases. Approximately 81% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001628280-23-035265:notes:37]
Product Warranties and Product Related Contingencies

[0001628280-23-035265:notes:38]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001628280-23-035265:notes:39]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:

[0001628280-23-035265:notes:40]
|  | September 30, 2023 |  | December 31, 2022 |
| Accrued expenses | $ | 44.0 |  |  | $ | 41.3 |  |
| Other liabilities | 100.6 |  |  | 101.4 |  |
| Total warranty liability | $ | 144.6 |  |  | $ | 142.7 |  |

[0001628280-23-035265:notes:41]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2023 were as follows (in millions):

[0001628280-23-035265:notes:42]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Warranty claims paid | (33.2) |  |
| Changes resulting from issuance of new warranties | 44.7 |  |
| Changes in estimates associated with pre-existing liabilities | (5.2) |  |
| Changes in foreign currency translation rates and other | (0.1) |  |
| Warranty liability reclassified as liabilities held for sale | (4.3) |  |
| Total warranty liability as of September 30, 2023 | $ | 144.6 |  |

[0001628280-23-035265:notes:43]
Litigation

[0001628280-23-035265:notes:44]
We are involved in a number of claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-23-035265:notes:45]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-23-035265:notes:46]
5. Stock Repurchases:Our Board of Directors has authorized a total of $4.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in July 2021. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of September 30, 2023, $546 million was available for repurchase under the Share Repurchase Plans.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001628280-23-035265:notes:47]
6. Assets Held for Sale:

[0001628280-23-035265:notes:48]
During the third quarter of 2023, we obtained Board approval and reached agreements to sell our European commercial HVAC and refrigeration businesses as well as our European Process Cooling business, both of which are expected to close in the fourth quarter of 2023.  All of these businesses are included in the Corporate and Other segment.  We have reclassified the assets and liabilities associated with these businesses to assets and liabilities held for sale.  The following table presents the assets and liabilities classified as held for sale as of September 30, 2023 (in millions).

[0001628280-23-035265:notes:49]
| Assets held for sale |  |
| Cash and cash equivalents | $ | 7.6 |  |
| Accounts and notes receivable, net of allowances | 51.8 |  |
| Inventories, net | 49.8 |  |
| Other assets | 16.4 |  |
| Property, plant, and equipment, net of accumulated depreciation | 3.2 |  |
| Goodwill | 2.3 |  |
| Valuation allowance | (38.3) |  |
| Total assets held for sale as of September 30, 2023 | $ | 92.8 |  |
| Liabilities held for sale |  |
| Current liabilities | $ | 61.0 |  |
| Non-current liabilities | 8.7 |  |
| Total liabilities held for sale as of September 30, 2023 | $ | 69.7 |  |

[0001628280-23-035265:notes:50]
Based on the expected fair value of the consideration to be received for these businesses, net of our costs to sell, we recorded an impairment on assets held for sale of $63.2 million related to the sale of our European commercial HVAC and refrigeration businesses. The consideration will be a combination of cash, a note receivable, and contingent consideration. The impairment consists of a $38.3 million valuation allowance for the difference between the consideration, net of our cost to sell and the carrying value of the net assets, including related amounts in Accumulated Other Comprehensive Loss, $22.6 million impairment of Property, plant, and equipment, and a $2.3 million impairment of goodwill.  The operating profits and losses generated from these businesses are not material for any period presented.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-035265:notes:51]
7. Revenue Recognition:

[0001628280-23-035265:notes:52]
[same as prior period, unchanged from 0001628280-23-025847:notes:47]

[0001628280-23-035265:notes:53]
|  | For the Three Months Ended September 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 842.1 |  |  | $ | 376.8 |  |  | $ | — |  |  | $ | 1,218.9 |  |
| Canada | 54.2 |  |  | 28.7 |  |  | — |  |  | 82.9 |  |
| Other international | — |  |  | — |  |  | 64.5 |  |  | 64.5 |  |
| Total | $ | 896.3 |  |  | $ | 405.5 |  |  | $ | 64.5 |  |  | $ | 1,366.3 |  |

[0001628280-23-035265:notes:54]
|  | For the Three Months Ended September 30, 2022(1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 779.8 |  |  | $ | 331.9 |  |  | $ | — |  |  | $ | 1,111.7 |  |
| Canada | 55.5 |  |  | 20.3 |  |  | — |  |  | 75.8 |  |
| Other international | — |  |  | 0.1 |  |  | 57.3 |  |  | 57.4 |  |
| Total | $ | 835.3 |  |  | $ | 352.3 |  |  | $ | 57.3 |  |  | $ | 1,244.9 |  |

[0001628280-23-035265:notes:55]
|  | For the Nine Months Ended September 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,350.0 |  |  | $ | 1,053.5 |  |  | $ | — |  |  | $ | 3,403.5 |  |
| Canada | 163.6 |  |  | 68.0 |  |  | — |  |  | 231.6 |  |
| Other international | — |  |  | — |  |  | 192.0 |  |  | 192.0 |  |
| Total | $ | 2,513.6 |  |  | $ | 1,121.5 |  |  | $ | 192.0 |  |  | $ | 3,827.1 |  |

[0001628280-23-035265:notes:56]
|  | For the Nine Months Ended September 30, 2022 (1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,311.2 |  |  | $ | 915.4 |  |  | $ | — |  |  | $ | 3,226.6 |  |
| Canada | 183.7 |  |  | 43.2 |  |  | — |  |  | 226.9 |  |
| Other international | — |  |  | 0.6 |  |  | 170.5 |  |  | 171.1 |  |
| Total | $ | 2,494.9 |  |  | $ | 959.2 |  |  | $ | 170.5 |  |  | $ | 3,624.6 |  |

[0001628280-23-035265:notes:57]
(1) As discussed in Note 2, we adjusted our segment reporting to include the results of our Heatcraft businesses in Commercial and the results of our European portfolio in Corporate and Other.  The amounts for the three and nine months ended September 30, 2022 have been recast to reflect the revised segment presentation.

[0001628280-23-035265:notes:58]
Residential - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2023 and 2022, direct sales represented 77% and 72% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2023 and 2022, direct sales represented 75% and 70% of revenues, and sales to independent distributors represented the remainder.

[0001628280-23-035265:notes:59]
Commercial - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended September 30, 2023 and 2022, equipment sales represented 88% and 88% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2023 and 2022, equipment sales represented 87% and 87% of revenues and the remainder of our revenue was generated from our service business.

[0001628280-23-035265:notes:60]
[same as prior period, unchanged from 0001628280-23-025847:notes:56]

[0001628280-23-035265:notes:61]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Net contract liabilities consisted of the following (in millions) as of:

[0001628280-23-035265:notes:62]
|  | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Contract liabilities - current | $ | (4.9) |  |  | $ | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.2) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (12.1) |  |  | $ | (16.0) |  |  |  |  |  |

[0001628280-23-035265:notes:63]
For the three months ended September 30, 2023 and 2022, we recognized revenue of $2.8 million and $3.6 million and for the nine months ended we recognized revenue of $7.0 million and $9.5 million related to our contract liabilities at January 1, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2023 and 2022.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-23-035265:notes:64]
8. Other Financial Statement Details:

[0001628280-23-035265:notes:65]
[same as prior period, unchanged from 0001628280-23-025847:notes:61]

[0001628280-23-035265:notes:66]
The components of inventories are as follows (in millions) as of:

[0001628280-23-035265:notes:67]
|  | September 30, 2023 |  | December 31, 2022 |
| Finished goods | $ | 544.7 |  |  | $ | 534.6 |  |
| Work in process | 8.6 |  |  | 8.9 |  |
| Raw materials and parts | 322.9 |  |  | 328.7 |  |
| Subtotal | 876.2 |  |  | 872.2 |  |
| Excess of current cost over last-in, first-out cost | (128.3) |  |  | (119.2) |  |
| Total inventories, net | $ | 747.9 |  |  | $ | 753.0 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-23-035265:notes:68]
[same as prior period, unchanged from 0001628280-23-025847:notes:64]

[0001628280-23-035265:notes:69]
[same as prior period, unchanged from 0001628280-23-025847:notes:65]

[0001628280-23-035265:notes:70]
|  | Balance as of December 31, 2022 |  | Goodwill Reallocation (1) |  | Reallocation to Assets Held for Sale (2) |  | Balance as of September 30, 2023 |
| Residential | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial (1) | 61.1 |  |  | 94.5 |  |  | — |  |  | 155.6 |  |
| Refrigeration (1) | 99.1 |  |  | (99.1) |  |  | — |  |  | $ | — |  |
| Corporate and Other (1) | — |  |  | 4.6 |  |  | (4.6) |  |  | — |  |
| Total Goodwill | $ | 186.3 |  |  | $ | — |  |  | $ | (4.6) |  |  | 181.7 |  |

[0001628280-23-035265:notes:71]
[same as prior period, unchanged from 0001628280-23-025847:notes:67]

[0001628280-23-035265:notes:72]
(2) As discussed in Note 6, we are presenting the assets and liabilities of our European businesses as Assets Held for Sale.  There was $4.6 million of goodwill related to our European portfolio.  As part of the loss on assets held for sale, we recorded an impairment of $2.3 million for a portion of the goodwill transferred. 
    We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We have not recorded any goodwill impairments for the nine months ended September 30, 2023 or in any periods presented for our continuing businesses.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-23-035265:notes:73]
[same as prior period, unchanged from 0001628280-23-025847:notes:69]

[0001628280-23-035265:notes:74]
[same as prior period, unchanged from 0001628280-23-025847:notes:70]

[0001628280-23-035265:notes:75]
[same as prior period, unchanged from 0001628280-23-025847:notes:71]

[0001628280-23-035265:notes:76]
[same as prior period, unchanged from 0001628280-23-025847:notes:72]

[0001628280-23-035265:notes:77]
[same as prior period, unchanged from 0001628280-23-025847:notes:73]

[0001628280-23-035265:notes:78]
[same as prior period, unchanged from 0001628280-23-025847:notes:74]

[0001628280-23-035265:notes:79]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through August 2024.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 12 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions) as of:

[0001628280-23-035265:notes:80]
|  | September 30, 2023 |  | December 31, 2022 |
| Unrealized losses (gains), net on unsettled contracts | $ | 1.5 |  |  | $ | 6.3 |  |
| Income tax (benefit) expense | (0.2) |  |  | (1.4) |  |
| Unrealized losses (gains), net included in AOCL, net of tax (1) | $ | 1.3 |  |  | $ | 4.9 |  |

[0001628280-23-035265:notes:81]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $1.2 million of derivative losses as of September 30, 2023 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-23-035265:notes:82]
[same as prior period, unchanged from 0001628280-23-025847:notes:78]

[0001628280-23-035265:notes:83]
[same as prior period, unchanged from 0001628280-23-025847:notes:79]

[0001628280-23-035265:notes:84]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Stock-based compensation expense | $ | 9.7 |  |  | $ | 5.8 |  |  | $ | 23.5 |  |  | $ | 16.4 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-23-035265:notes:85]
9. Pension Benefit Plans:

[0001628280-23-035265:notes:86]
[same as prior period, unchanged from 0001628280-23-025847:notes:82]

[0001628280-23-035265:notes:87]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Service cost | $ | 0.5 |  |  | $ | 1.1 |  |  | $ | 1.6 |  |  | $ | 3.2 |  |
| Interest cost | 2.2 |  |  | 1.5 |  |  | 6.7 |  |  | 4.5 |  |
| Expected return on plan assets | (2.4) |  |  | (2.3) |  |  | (7.1) |  |  | (7.0) |  |
| Recognized actuarial loss | — |  |  | 1.5 |  |  | 0.6 |  |  | 4.4 |  |
| Other | 0.3 |  |  | 0.2 |  |  | (0.1) |  |  | 0.2 |  |
| Settlements and curtailments | 0.3 |  |  | — |  |  | 0.4 |  |  | 0.3 |  |
| Net periodic benefit cost | $ | 0.9 |  |  | $ | 2.0 |  |  | $ | 2.1 |  |  | $ | 5.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-035265:notes:88]
10. Income Taxes:

[0001628280-23-035265:notes:89]
As of September 30, 2023, we had approximately $4.0 million in total gross unrecognized tax benefits. All of this amount, if recognized, would be recorded through the Consolidated Statements of Operations.  Our effective tax rate was 25.6% for the three months ended September 30, 2023 compared to 18.7% for the three months ended September 30, 2022, 21.0% for the nine months ended September 30, 2023 and 18.9% for the nine months ended September 30, 2022.  The change in the rate is primarily due to the allocation of income to higher tax jurisdictions and a discrete adjustment related to the European divestiture.

[0001628280-23-035265:notes:90]
We are currently under a U.S. federal income tax audit by the Internal Revenue Service for 2021. We are also subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2016.


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-035265:notes:91]
11. Lines of Credit and Financing Arrangements:

[0001628280-23-035265:notes:92]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:

[0001628280-23-035265:notes:93]
|  | September 30, 2023 |  | December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.6 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | — |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 361.6 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.9 |  |  | 28.3 |  |
| Credit agreement | — |  |  | 192.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 600.0 |  |
| Debt issuance costs | (10.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,121.6 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,483.2 |  |  | $ | 1,524.8 |  |

[0001628280-23-035265:notes:94]
Foreign Obligations

[0001628280-23-035265:notes:95]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2023 or December 31, 2022 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2023.

[0001628280-23-035265:notes:96]
Asset Securitization Program

[0001628280-23-035265:notes:97]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale. Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001628280-23-035265:notes:98]
We renewed the ASP in November 2021, extending its term to November 2023 and increasing the maximum securitization amount to a range from $300.0 million to $450.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions) as of:

[0001628280-23-035265:notes:99]
|  | September 30, 2023 |  | December 31, 2022 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 400.0 |  |  | $ | 350.0 |  |
| Less: Beneficial interest transferred | — |  |  | (350.0) |  |
| Remaining amount available | $ | 400.0 |  |  | $ | — |  |

[0001628280-23-035265:notes:100]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on the floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2023 and December 31, 2022 were 0.00% and 5.17%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001628280-23-035265:notes:101]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of September 30, 2023, we were in compliance with all covenant requirements.  The ASP will expire according to its terms in November 2023 and we do not intend to renew it.

[0001628280-23-035265:notes:102]
Second Amendment to the Credit Agreement

[0001628280-23-035265:notes:103]
In August 2023, we entered into the Second Amendment (the “Second Amendment”) to our existing Credit Agreement, dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.  Under the Second Amendment, the revolving commitments were increased by $350 million and certain representations required to be made as conditions precedent to borrowing were revised to provide us greater flexibility to enter into additional future financing.

[0001628280-23-035265:notes:104]
The Credit Agreement consists of a $1.1 billion unsecured revolving credit facility.  We had outstanding borrowings of $0.0 million as well as $1.7 million committed to standby letters of credit as of September 30, 2023. Subject to covenant limitations, $1,098.3 million was available for future borrowings.  The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-23-035265:notes:105]
Our weighted average borrowing rate on the facility was as follows as of:

[0001628280-23-035265:notes:106]
|  | September 30, 2023 |  | December 31, 2022 |
| Weighted average borrowing rate | — | % |  | 5.57 | % |

[0001628280-23-035265:notes:107]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-23-035265:notes:108]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitization (cross default), and bankruptcy. A cross default under our Credit Agreement could occur if:

[0001628280-23-035265:notes:109]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-23-035265:notes:110]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-23-035265:notes:111]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Credit Agreement, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-23-035265:notes:112]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2023, we were in compliance with all covenant requirements.

[0001628280-23-035265:notes:113]
Senior Unsecured Notes

[0001628280-23-035265:notes:114]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes, 2027 Notes, and the 2028 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.

[0001628280-23-035265:notes:115]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2023, we believe we were in compliance with all covenant requirements.

[0001628280-23-035265:notes:116]
Commercial Paper Program

[0001628280-23-035265:notes:117]
On October 25, 2023, we established a commercial paper program (the “Program”) pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes will have maturities of up to 397 days from the date of issue. The CP Notes will rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds of the issuances of the CP Notes are expected to be used for general corporate purposes. We plan to use our revolving credit facility as a liquidity backstop for the repayment of CP Notes outstanding under the Program. No CP Notes are currently outstanding under the Program.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-23-035265:notes:118]
12. Comprehensive Income (Loss):

[0001628280-23-035265:notes:119]
[same as prior period, unchanged from 0001628280-23-025847:notes:113]

[0001628280-23-035265:notes:120]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| (Losses) Gains on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | (0.8) |  |  | $ | (3.7) |  |  | $ | (1.2) |  |  | $ | 12.5 |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax (expense) benefit |  | 0.2 |  |  | 0.8 |  |  | 0.3 |  |  | (2.9) |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.6) |  |  | $ | (2.9) |  |  | $ | (0.9) |  |  | $ | 9.6 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | — |  |  | $ | (1.5) |  |  | $ | (0.6) |  |  | $ | (4.4) |  |  | Other expense (income), net |
| Pension settlements |  | (0.3) |  |  | — |  |  | (0.4) |  |  | (0.3) |  |  | Pension settlements |
| Income tax benefit |  | 0.1 |  |  | 0.4 |  |  | 0.2 |  |  | 1.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.2) |  |  | $ | (1.1) |  |  | $ | (0.8) |  |  | $ | (3.5) |  |  |  |
| Total reclassifications from AOCL |  | $ | (0.8) |  |  | $ | (4.0) |  |  | $ | (1.7) |  |  | $ | 6.1 |  |  |  |

[0001628280-23-035265:notes:121]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2023 (in millions):

[0001628280-23-035265:notes:122]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2022 |  | $ | (4.9) |  |  | $ | (0.5) |  |  | $ | (46.2) |  |  | $ | (39.0) |  |  | $ | (90.6) |  |
| Other comprehensive income (loss) before reclassifications |  | 2.7 |  |  | 1.1 |  |  | (0.6) |  |  | 8.7 |  |  | 11.9 |  |
| Amounts reclassified from AOCL |  | 0.9 |  |  | — |  |  | 0.8 |  |  | — |  |  | 1.7 |  |
| Net other comprehensive income |  | 3.6 |  |  | 1.1 |  |  | 0.2 |  |  | 8.7 |  |  | 13.6 |  |
| Balance as of September 30, 2023 |  | $ | (1.3) |  |  | $ | 0.6 |  |  | $ | (46.0) |  |  | $ | (30.3) |  |  | $ | (77.0) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-035265:notes:123]
13. Fair Value Measurements:

[0001628280-23-035265:notes:124]
[same as prior period, unchanged from 0001628280-23-025847:notes:118]

[0001628280-23-035265:notes:125]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2023 were the same as those used at December 31, 2022.

[0001628280-23-035265:notes:126]
[same as prior period, unchanged from 0001628280-23-025847:notes:120]

[0001628280-23-035265:notes:127]
Derivatives were classified as Level 2 and primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives. We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, however, they were insignificant to the overall value of the derivatives.  Refer to Note 8 for more information related to our derivative instruments.

[0001628280-23-035265:notes:128]
[same as prior period, unchanged from 0001628280-23-025847:notes:122]

[0001628280-23-035265:notes:129]
[same as prior period, unchanged from 0001628280-23-025847:notes:123]

[0001628280-23-035265:notes:130]
The fair value of our senior unsecured notes in Long-term debt, classified as Level 2, was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents their fair value (in millions) as of:

[0001628280-23-035265:notes:131]
|  | September 30, 2023 |  | December 31, 2022 |
| Senior unsecured notes | $ | 1,386.2 |  |  | $ | 878.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001628280-23-035265:notes:132]
14. Subsequent Event:On October 25, 2023, we announced the acquisition of AES, a company dedicated to service and sustainability in the light commercial markets.  Across North America, AES provides installation services, adapter curbs, and recycling services.  AES will become part of the Commercial segment.
