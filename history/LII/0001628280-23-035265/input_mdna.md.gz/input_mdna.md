# LII MD&A — 0001628280-23-035265


## mdna

[0001628280-23-035265:mdna:1]
[same as prior period, unchanged from 0001628280-23-025847:mdna:1]

[0001628280-23-035265:mdna:2]
[same as prior period, unchanged from 0001628280-23-025847:mdna:2]

[0001628280-23-035265:mdna:3]
[same as prior period, unchanged from 0001628280-23-025847:mdna:3]

[0001628280-23-035265:mdna:4]
[same as prior period, unchanged from 0001628280-23-025847:mdna:4]

[0001628280-23-035265:mdna:5]
[same as prior period, unchanged from 0001628280-23-025847:mdna:5]

[0001628280-23-035265:mdna:6]
[same as prior period, unchanged from 0001628280-23-025847:mdna:6]

[0001628280-23-035265:mdna:7]
[same as prior period, unchanged from 0001628280-23-025847:mdna:7]

[0001628280-23-035265:mdna:8]
Prior to January 1, 2023, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses. We continue to operate and invest in our Heatcraft Worldwide Refrigeration business which became part of the Commercial segment effective on January 1, 2023, while the European portfolio will be presented with Corporate and Other until disposition. The consolidation of our Heatcraft business within the Commercial segment provides the opportunity to leverage synergies and create long-term growth opportunities by integrating entities with similar products, end consumers and financial performance metrics under the same management. The change in segment reporting better aligns with how the businesses are managed and evaluated given the change in portfolio.  All amounts discussed in this Management's Discussion and Analysis of Financial Condition and Results of Operations reflect the revised segment presentation.

[0001628280-23-035265:mdna:9]
[same as prior period, unchanged from 0001628280-23-025847:mdna:9]

[0001628280-23-035265:mdna:10]
Results for the third quarter of 2023 were driven by overall year-over-year sales and profit increases. Net sales increased 15% and segment profit increased $45 million for the Commercial segment. Net sales increased 7% and segment profit increased $28 million for the Residential segment. Net sales increased 13% and segment loss decreased $7 million for the Corporate & Other segment.

[0001628280-23-035265:mdna:11]
[same as prior period, unchanged from 0001628280-23-025847:mdna:11]

[0001628280-23-035265:mdna:12]
•Net sales increased $121 million to $1,366 million in the third quarter of 2023 driven by favorable mix and price partially offset by lower sales volumes and unfavorable foreign currency.

[0001628280-23-035265:mdna:13]
•Operating income in the third quarter of 2023 increased $1 million to $187 million primarily driven by favorable mix and price partially offset by a $63 million loss on assets held for sale.

[0001628280-23-035265:mdna:14]
•Net income for the third quarter of 2023 was $130 million.

[0001628280-23-035265:mdna:15]
•Diluted earnings per share was $3.65 per share in the third quarter of 2023 compared to $3.99 per share in the third quarter of 2022.

[0001628280-23-035265:mdna:16]
•For the nine months ended September 30, 2023, we returned $153 million to shareholders through dividend payments.

[0001628280-23-035265:mdna:17]
Three Months Ended September 30, 2023 Compared to Three Months Ended September 30, 2022 - Consolidated Results

[0001628280-23-035265:mdna:18]
[same as prior period, unchanged from 0001628280-23-025847:mdna:18]

[0001628280-23-035265:mdna:19]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 1,366.3 |  |  | $ | 1,244.9 |  |  | 9.8 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 937.8 |  |  | 910.7 |  |  | (3.0) |  |  | 68.6 |  |  | 73.2 |  |
| Gross profit | 428.5 |  |  | 334.2 |  |  | 28.2 |  |  | 31.4 |  |  | 26.8 |  |
| Selling, general and administrative expenses | 178.9 |  |  | 147.3 |  |  | (21.5) |  |  | 13.1 |  |  | 11.8 |  |
| Losses (gains) and other expenses, net | 3.5 |  |  | 3.3 |  |  | (6.1) |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.3 |  |  | 0.2 |  |  | (50.0) |  |  | — |  |  | — |  |
| Impairment on assets held for sale | 63.2 |  |  | — |  |  | (100.0) |  |  | 4.6 |  |  | — |  |
| Income from equity method investments | (4.2) |  |  | (2.4) |  |  | 75.0 |  |  | (0.3) |  |  | (0.2) |  |
| Operating income | $ | 186.8 |  |  | $ | 185.8 |  |  | 0.5 | % |  | 13.7 | % |  | 14.9 | % |

[0001628280-23-035265:mdna:20]
[same as prior period, unchanged from 0001628280-23-025847:mdna:20]

[0001628280-23-035265:mdna:21]
Net sales for the third quarter of 2023 compared to the third quarter of 2022 increased 10% as a result of favorable mix of 6% and favorable product price of 5% which was partially offset by lower sales volumes of 1%.

[0001628280-23-035265:mdna:22]
[same as prior period, unchanged from 0001628280-23-025847:mdna:22]

[0001628280-23-035265:mdna:23]
Gross profit margins in the third quarter of 2023 increased 460 basis points ("bps") to 31.4% compared to 26.8% in the third quarter of 2022. Gross margins increased 280 bps from favorable price, 220 bps from favorable product mix, and 70 bps from favorable commodity costs.  Partially offsetting these increases were 40 bps from higher warranty costs, 30 bps from higher component costs, 20 bps from higher freight and distribution costs, 10 bps from lower sales volume, and 10 bps from higher other miscellaneous costs.

[0001628280-23-035265:mdna:24]
[same as prior period, unchanged from 0001628280-23-025847:mdna:24]

[0001628280-23-035265:mdna:25]
Selling, general and administrative expenses ("SG&A") increased $32 million to $179 million in the third quarter of 2023 compared to $147 million in the third quarter of 2022 primarily due to higher employee-related costs including incentive compensation and wage inflation. As a percentage of net sales, SG&A increased 130 bps to 13.1%.

[0001628280-23-035265:mdna:26]
[same as prior period, unchanged from 0001628280-23-025847:mdna:26]

[0001628280-23-035265:mdna:27]
Losses (gains) and other expenses, net for the third quarter of 2023 and 2022 included the following (in millions):

[0001628280-23-035265:mdna:28]
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |  |  |
| Realized losses on settled future contracts | $ | — |  |  | $ | 0.3 |  |  |  |  |  |  |  |
| Foreign currency exchange (gains) losses | (1.2) |  |  | 0.3 |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.2) |  |  | (0.4) |  |  |  |  |  |  |  |
| Other operating income | (0.1) |  |  | (0.2) |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 3.9 |  |  | 3.1 |  |  |  |  |  |  |  |
| Other items, net | 1.1 |  |  | 0.2 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.5 |  |  | $ | 3.3 |  |  |  |  |  |  |  |

[0001628280-23-035265:mdna:29]
Impairment on Assets Held for Sale

[0001628280-23-035265:mdna:30]
We recorded a $63 million impairment on assets held for sale in the third quarter of 2023 related to the sale of our European commercial HVAC and refrigeration businesses.  The loss is the result of the difference between the expected fair value of the consideration received for these businesses, net of our costs to sell, and the carrying value of the net assets.

[0001628280-23-035265:mdna:31]
[same as prior period, unchanged from 0001628280-23-025847:mdna:31]

[0001628280-23-035265:mdna:32]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation. Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated. We recognized income from equity method investments of $4 million in the third quarter of 2023 and $2 million in the third quarter of 2022.

[0001628280-23-035265:mdna:33]
[same as prior period, unchanged from 0001628280-23-025847:mdna:33]

[0001628280-23-035265:mdna:34]
Interest expense, net remained relatively unchanged at $11 million in the third quarter of 2023 as compared to the third quarter of 2022.

[0001628280-23-035265:mdna:35]
[same as prior period, unchanged from 0001628280-23-025847:mdna:35]

[0001628280-23-035265:mdna:36]
Our effective tax rate was 25.6% for the third quarter of 2023 compared to 18.7% for the third quarter of 2022.  The rate increased primarily due to the allocation of income to higher tax jurisdictions and a discrete adjustment related to the European businesses.

[0001628280-23-035265:mdna:37]
We expect our annual effective tax rate to be 20-22%, excluding the impacts of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001628280-23-035265:mdna:38]
Third Quarter of 2023 Compared to Third Quarter of 2022 - Results by Segment

[0001628280-23-035265:mdna:39]
[same as prior period, unchanged from 0001628280-23-025847:mdna:39]

[0001628280-23-035265:mdna:40]
The following table presents our Residential segment's net sales and profit for the third quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-035265:mdna:41]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 896.3 |  |  | $ | 835.3 |  |  | $ | 61.0 |  |  | 7 | % |
| Profit | $ | 181.4 |  |  | $ | 153.8 |  |  | $ | 27.6 |  |  | 18 | % |
| % of net sales | 20.2 | % |  | 18.4 | % |  |  |  |  |

[0001628280-23-035265:mdna:42]
Net sales increased 7% in the third quarter of 2023 compared to 2022 due to favorable product mix of 7% and higher price of 2%.  Partially offsetting these increases were lower sales volumes of 2%.

[0001628280-23-035265:mdna:43]
Segment profit in the third quarter of 2023 compared to 2022 increased by $28 million, primarily due to $37 million from favorable product mix, $14 million from higher price and $10 million from lower commodity costs.  Partially offsetting these increases were $16 million from higher SG&A costs, $7 million from higher factory inefficiencies, $6 million from miscellaneous other items and $4 million from lower sales volumes.

[0001628280-23-035265:mdna:44]
[same as prior period, unchanged from 0001628280-23-025847:mdna:44]

[0001628280-23-035265:mdna:45]
The following table presents our Commercial segment's net sales and profit for the third quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-035265:mdna:46]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 405.5 |  |  | $ | 352.3 |  |  | $ | 53.2 |  |  | 15 | % |
| Profit | $ | 97.3 |  |  | $ | 52.4 |  |  | $ | 44.9 |  |  | 86 | % |
| % of net sales | 24.0 | % |  | 14.9 | % |  |  |  |  |

[0001628280-23-035265:mdna:47]
[same as prior period, unchanged from 0001628280-23-025847:mdna:47]

[0001628280-23-035265:mdna:48]
Net sales increased 15% in the third quarter of 2023 compared to 2022 as price increased 10%, product mix increased 3% and sales volumes increased 2%.

[0001628280-23-035265:mdna:49]
Segment profit in the third quarter of 2023 compared to 2022 increased $45 million primarily due to $37 million from favorable price, $10 million from favorable product mix, and $1 million from higher sales volumes.  Partially offsetting these increases were $3 million from higher SG&A costs.

[0001628280-23-035265:mdna:50]
[same as prior period, unchanged from 0001628280-23-025847:mdna:50]

[0001628280-23-035265:mdna:51]
The following table presents our Corporate and Other segment's net sales and loss for the third quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-035265:mdna:52]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 64.5 |  |  | $ | 57.3 |  |  | $ | 7.2 |  |  | 13 | % |
| Loss | $ | (23.4) |  |  | $ | (16.9) |  |  | $ | (6.5) |  |  | (38) | % |

[0001628280-23-035265:mdna:53]
[same as prior period, unchanged from 0001628280-23-025847:mdna:53]

[0001628280-23-035265:mdna:54]
Net sales increased $7 million and segment loss increased $7 million in the third quarter of 2023 as compared to 2022.  Our European businesses generated $4 million profit in the third quarter of 2023 and a loss of less than $1 million in the third quarter of 2022.  Excluding our European businesses, Corporate and Other costs increased to $11 million in the third quarter of 2023 compared to 2022 due primarily to higher incentive compensation and wage inflation.

[0001628280-23-035265:mdna:55]
Year-to-Date through September 30, 2023 Compared to Year-to-Date through September 30, 2022 - Consolidated Results

[0001628280-23-035265:mdna:56]
[same as prior period, unchanged from 0001628280-23-025847:mdna:56]

[0001628280-23-035265:mdna:57]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 3,827.1 |  |  | $ | 3,624.6 |  |  | 5.6 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 2,634.1 |  |  | 2,625.1 |  |  | (0.3) |  |  | 68.8 |  |  | 72.4 |  |
| Gross profit | 1,193.0 |  |  | 999.5 |  |  | 19.4 |  |  | 31.2 |  |  | 27.6 |  |
| Selling, general and administrative expenses | 527.6 |  |  | 472.2 |  |  | (11.7) |  |  | 13.8 |  |  | 13.0 |  |
| Losses (gains) and other expenses, net | 5.2 |  |  | 5.4 |  |  | 3.7 |  |  | 0.1 |  |  | 0.1 |  |
| Restructuring charges | 0.2 |  |  | 1.2 |  |  | 83.3 |  |  | — |  |  | — |  |
| Impairment on assets held for sale | 63.2 |  |  | — |  |  | (100.0) |  |  | 1.7 |  |  | — |  |
| Income from equity method investments | (8.0) |  |  | (3.9) |  |  | 105.1 |  |  | (0.2) |  |  | (0.1) |  |
| Operating income | $ | 604.8 |  |  | $ | 524.6 |  |  | 15.3 | % |  | 15.8 | % |  | 14.5 | % |

[0001628280-23-035265:mdna:58]
[same as prior period, unchanged from 0001628280-23-025847:mdna:58]

[0001628280-23-035265:mdna:59]
Net sales increased 6% for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022 due to favorable product mix of 6% and higher price of 5%.  Partially offsetting these increases were lower sales volumes of 5%.

[0001628280-23-035265:mdna:60]
[same as prior period, unchanged from 0001628280-23-025847:mdna:60]

[0001628280-23-035265:mdna:61]
Gross profit margins for the nine months ended September 30, 2023 increased 360 bps to 31.2% compared to 27.6% for the nine months ended September 30, 2022. Gross margins increased 350 bps from higher price, 140 bps from favorable mix and 90 bps from lower commodity costs.  Partially offsetting these increases were 70 bps from higher other product costs, 60 bps from higher component costs, 40 bps from lower sales volumes, 30 bps from higher freight and distribution costs and 20 bps from higher miscellaneous other costs.

[0001628280-23-035265:mdna:62]
[same as prior period, unchanged from 0001628280-23-025847:mdna:62]

[0001628280-23-035265:mdna:63]
SG&A increased $55 million to $528 million for the nine months ended September 30, 2023 compared to $472 million for

[0001628280-23-035265:mdna:64]
the nine months ended September 30, 2022 primarily due to higher employee-related costs. As a percentage of net sales, SG&A increased 80 bps to 13.8% from 13.0%.

[0001628280-23-035265:mdna:65]
[same as prior period, unchanged from 0001628280-23-025847:mdna:65]

[0001628280-23-035265:mdna:66]
Losses (gains) and other expenses, net for the nine months ended September 30, 2023 and 2022 included the following (in millions):

[0001628280-23-035265:mdna:67]
|  | For the Nine Months Ended September 30, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | (0.1) |  |  |  |  |  |  |  |
| Foreign currency exchange gains | (4.2) |  |  | (0.5) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (1.4) |  |  | (1.3) |  |  |  |  |  |  |  |
| Other operating income | (1.4) |  |  | (0.6) |  |  |  |  |  |  |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.1) |  |  | 1.2 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 11.1 |  |  | 6.2 |  |  |  |  |  |  |  |
| Other items, net | 1.1 |  |  | 0.5 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 5.2 |  |  | $ | 5.4 |  |  |  |  |  |  |  |

[0001628280-23-035265:mdna:68]
Impairment on Assets Held for Sale

[0001628280-23-035265:mdna:69]
We recorded a $63 million impairment on assets held for sale in the third quarter of 2023 related to the sale of our European commercial HVAC and refrigeration businesses.  The loss is the result of the difference between the expected fair value of the consideration received for these businesses, net of our costs to sell, and the carrying value of the net assets.

[0001628280-23-035265:mdna:70]
[same as prior period, unchanged from 0001628280-23-025847:mdna:70]

[0001628280-23-035265:mdna:71]
Income from equity method investments increased to $8 million for the nine months ended September 30, 2023 as compared to $4 million for the nine months ended September 30, 2022.  The increase was due to lower operating costs at the investments.

[0001628280-23-035265:mdna:72]
[same as prior period, unchanged from 0001628280-23-025847:mdna:72]

[0001628280-23-035265:mdna:73]
Interest expense, net increased $14 million for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022 primarily due to higher interest rates.

[0001628280-23-035265:mdna:74]
[same as prior period, unchanged from 0001628280-23-025847:mdna:74]

[0001628280-23-035265:mdna:75]
Our effective tax rate increased to 21.0% for the nine months ended September 30, 2023 compared to 18.9% for the nine months ended September 30, 2022 primarily due to the allocation of income to higher tax jurisdictions and a discrete adjustment related to the European divestiture.

[0001628280-23-035265:mdna:76]
Year-to-Date through September 30, 2023 Compared to Year-to-Date through September 30, 2022 - Results by Segment

[0001628280-23-035265:mdna:77]
[same as prior period, unchanged from 0001628280-23-025847:mdna:77]

[0001628280-23-035265:mdna:78]
The following table presents our Residential segment's net sales and profit for the nine months ended September 30, 2023 and 2022 (dollars in millions):

[0001628280-23-035265:mdna:79]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 2,513.6 |  |  | $ | 2,494.9 |  |  | $ | 18.7 |  |  | 1 | % |
| Profit | $ | 495.2 |  |  | $ | 477.7 |  |  | $ | 17.5 |  |  | 4 | % |
| % of net sales | 19.7 | % |  | 19.1 | % |  |  |  |  |

[0001628280-23-035265:mdna:80]
Net sales increased 1% for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022 due to favorable product mix of 7% and higher price of 2%.  Partially offsetting these increases was lower sales volumes of 8%.

[0001628280-23-035265:mdna:81]
Segment profit for the first nine months of 2023 compared to 2022 increased $17 million primarily due to $65 million from favorable product mix, $60 million from higher price, and $27 million from lower commodity costs.  Partially offsetting these increases was $62 million from lower sales volumes, $34 million from higher SG&A costs, $17 million from higher freight and distribution costs, $13 million from higher component costs, and $9 million from miscellaneous other items.

[0001628280-23-035265:mdna:82]
[same as prior period, unchanged from 0001628280-23-025847:mdna:83]

[0001628280-23-035265:mdna:83]
The following table presents our Commercial segment's net sales and profit for the nine months ended September 30, 2023 and 2022 (dollars in millions):

[0001628280-23-035265:mdna:84]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 1,121.5 |  |  | $ | 959.2 |  |  | $ | 162.3 |  |  | 17 | % |
| Profit | $ | 250.3 |  |  | $ | 117.4 |  |  | $ | 132.9 |  |  | 113 | % |
| % of net sales | 22.3 | % |  | 12.2 | % |  |  |  |  |

[0001628280-23-035265:mdna:85]
[same as prior period, unchanged from 0001628280-23-025847:mdna:91]

[0001628280-23-035265:mdna:86]
Net sales increased 17% for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022 as price increased 11% and product mix was 6% favorable.

[0001628280-23-035265:mdna:87]
Segment profit for the first nine months of 2023 compared to 2022 increased $133 million primarily due to $112 million from higher price, $43 million from favorable product mix, $6 million from lower commodity costs, and $6 million from lower freight and distribution costs.  Partially offsetting these increases were $16 million from higher other product costs including warranty costs, $9 million from higher component costs, and $9 million from higher SG&A costs.

[0001628280-23-035265:mdna:88]
[same as prior period, unchanged from 0001628280-23-025847:mdna:88]

[0001628280-23-035265:mdna:89]
The following table presents our Corporate and Other segment's net sales and loss for the nine months ended September 30, 2023 and 2022 (dollars in millions):

[0001628280-23-035265:mdna:90]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 192.0 |  |  | $ | 170.5 |  |  | $ | 21.5 |  |  | 13 | % |
| Loss | $ | (65.2) |  |  | $ | (61.4) |  |  | $ | (3.8) |  |  | (6) | % |

[0001628280-23-035265:mdna:91]
(1) 2022 amounts have been recast to reflect the changes in segment reporting.  Please see Note 2 in the Notes to the Consolidated Financial Statements for further detail.

[0001628280-23-035265:mdna:92]
Net sales increased $21 million and segment loss increased $4 million during the nine months ended September 30, 2023 as compared to 2022.  Our European businesses generated a profit of $6 million in the nine months ended September 30, 2023 and a loss of $4 million in the nine months ended September 30, 2022.  Excluding our European businesses, Corporate and Other costs increased $14 million due primarily to higher incentive compensation costs and wage inflation.

[0001628280-23-035265:mdna:93]
[same as prior period, unchanged from 0001628280-23-025847:mdna:93]

[0001628280-23-035265:mdna:94]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement. Upon expiration of the asset securitization arrangement, our new commercial

[0001628280-23-035265:mdna:95]
paper program (described below) will serve as an additional source of liquidity.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001628280-23-035265:mdna:96]
[same as prior period, unchanged from 0001628280-23-025847:mdna:95]

[0001628280-23-035265:mdna:97]
The following table summarizes our cash flow activity for the nine months ended September 30, 2023 and 2022 (in millions):

[0001628280-23-035265:mdna:98]
|  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 |
| Net cash provided by operating activities | $ | 429.9 |  |  | $ | 170.1 |  |
| Net cash used in investing activities | (124.5) |  |  | (68.2) |  |
| Net cash used in financing activities | (215.6) |  |  | (89.1) |  |

[0001628280-23-035265:mdna:99]
Net Cash Provided By Operating Activities -  The change in net cash provided by operating activities for the nine months ended September 30, 2023 compared to the net cash provided by operating activities for the same period in 2022 reflects changes in working capital and an increase in net income.

[0001628280-23-035265:mdna:100]
Net Cash Used In Investing Activities - Capital expenditures were $125 million for the nine months ended September 30, 2023 compared to $67 million in the same period of 2022.  Capital expenditures in 2023 were related to our Commercial factory in Mexico, the general expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-23-035265:mdna:101]
Net Cash Used In Financing Activities - Net cash used in financing activities for the nine months ended September 30, 2023 increased to $216 million compared to $89 million used in financing activities in the same period of 2022.  The change was primarily due to changes net borrowings and repayments of long-term debt partially offset by less share repurchases.  We did not repurchase any shares for the nine months ended September 30, 2023 and we repurchased $300 million in shares in the same period of 2022.  We returned $153 million to shareholders through dividend payments for the nine months ended September 30, 2023 and $142 million in the same period of 2022. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001628280-23-035265:mdna:102]
[same as prior period, unchanged from 0001628280-23-025847:mdna:101]

[0001628280-23-035265:mdna:103]
The following table details our lines of credit and financing arrangements as of September 30, 2023 (in millions):

[0001628280-23-035265:mdna:104]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (1) | $ | — |  |
| Finance lease obligations | 11.6 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | — |  |
| Total current maturities of long-term debt | $ | 361.6 |  |
| Long-term debt: |  |
| Finance lease obligations | 31.9 |  |
| Credit agreement (2) | — |  |
| Senior unsecured notes | 1,100.0 |  |
| Debt issuance costs | (10.3) |  |
| Total long-term debt | 1,121.6 |  |
| Total debt | $ | 1,483.2 |  |

[0001628280-23-035265:mdna:105]
(1)    The maximum securitization amount ranges from $300.0 million to $450.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-23-035265:mdna:106]
(2)   The available future borrowings on our Credit Agreement (as defined below) are $1,098.3 million, after being reduced by the outstanding borrowings and $1.7 million in outstanding standby letters of credit.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-23-035265:mdna:107]
Second Amendment to the Credit Agreement

[0001628280-23-035265:mdna:108]
In August 2023, we entered into the Second Amendment (the “Second Amendment”) to the Credit Agreement, dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.  Under the Second Amendment, the revolving commitments were increased by $350 million and certain representations required to be made as conditions precedent to borrowing were revised to provide us greater flexibility to enter into additional future financing.

[0001628280-23-035265:mdna:109]
The Credit Agreement provides for revolving credit commitments of $1.1 billion with sublimits for swingline loans of up to $65 million, letters of credit up to $100 million and revolving loans in certain non-U.S. currencies up to the U.S. dollar equivalent of $40 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-23-035265:mdna:110]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control. As of September 30, 2023, we believe we were in compliance with all covenant requirements.

[0001628280-23-035265:mdna:111]
Senior Unsecured Notes

[0001628280-23-035265:mdna:112]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes, 2027 Notes, and the 2028 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.

[0001628280-23-035265:mdna:113]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2023, we believe we were in compliance with all covenant requirements.

[0001628280-23-035265:mdna:114]
[same as prior period, unchanged from 0001628280-23-025847:mdna:111]

[0001628280-23-035265:mdna:115]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 90% at September 30, 2023 from 115% at December 31, 2022.

[0001628280-23-035265:mdna:116]
As of September 30, 2023, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-23-035265:mdna:117]
[same as prior period, unchanged from 0001628280-23-025847:mdna:114]

[0001628280-23-035265:mdna:118]
We believe our cash and cash equivalents of $132 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $132 million as of September 30, 2023 was $18 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-23-035265:mdna:119]
Both our ASP as well as our $350.0 million 2023 Notes will mature during the fourth quarter. We pre-funded the 2023 notes maturity through the issuance of the 2028 Notes.  We are replacing the expiring ASP with a $500.0 million commercial paper program, as described below.  We do not believe that these changes will have any material impact on our results of operation or liquidity.

[0001628280-23-035265:mdna:120]
[same as prior period, unchanged from 0001628280-23-025847:mdna:116]

[0001628280-23-035265:mdna:121]
[same as prior period, unchanged from 0001628280-23-025847:mdna:117]

[0001628280-23-035265:mdna:122]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of September 30, 2023 and December 31, 2022 and for the three and nine months ended September 30, 2023 (in millions):

[0001628280-23-035265:mdna:123]
|  | September 30, 2023 |  | December 31, 2022 |
| Current assets | 933.7 |  |  | 772.1 |  |
| Non-current assets | 6,086.7 |  |  | 4,844.4 |  |
| Current liabilities | 1,004.9 |  |  | 1,023.2 |  |
| Non-current liabilities | 1,456.2 |  |  | 1,149.0 |  |
| Amounts due to non-guarantor subsidiaries | (725.4) |  |  | (537.7) |  |

[0001628280-23-035265:mdna:124]
|  | For the Three Months Ended September 30, 2023 |  | For the Nine Months Ended, September 30, 2023 |
| Net Sales | 1,289.0 |  |  | 3,559.3 |  |
| Gross Profit | 339.5 |  |  | 888.4 |  |
| Net Income | 372.2 |  |  | 1,072.6 |  |

[0001628280-23-035265:mdna:125]
[same as prior period, unchanged from 0001628280-23-025847:mdna:118]

[0001628280-23-035265:mdna:126]
[same as prior period, unchanged from 0001628280-23-025847:mdna:119]

[0001628280-23-035265:mdna:127]
Commitments, Contingencies and Guarantees

[0001628280-23-035265:mdna:128]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-23-035265:mdna:129]
[same as prior period, unchanged from 0001628280-23-025847:mdna:122]

[0001628280-23-035265:mdna:130]
[same as prior period, unchanged from 0001628280-23-025847:mdna:123]
