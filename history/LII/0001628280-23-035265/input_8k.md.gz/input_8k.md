# LII 8-K — 0001628280-23-035187 filed 2023-10-26

## item codes, every 8-K on or before 2023-10-26

- 2023-10-26 0001628280-23-035187 — 2.02, 5.02, 7.01, 9.01
- 2023-09-21 0001628280-23-032729 — 8.01, 9.01
- 2023-09-15 0001628280-23-032385 — 1.01, 2.03, 8.01, 9.01
- 2023-09-12 0001628280-23-032078 — 8.01, 9.01
- 2023-08-28 0001628280-23-030777 — 1.01, 2.03, 9.01
- 2023-08-25 0001628280-23-030602 — 8.01, 9.01
- 2023-07-27 0001628280-23-025808 — 2.02, 9.01
- 2023-05-19 0001628280-23-019040 — 5.07
- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2023-10-26

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-035187:8k_2_02:1]
EX-99.1
2
lii-2023930xexx991pressrel.htm
EX-99.1

[0001628280-23-035187:8k_2_02:2]
Document

[0001628280-23-035187:8k_2_02:3]
Exhibit 99.1

[0001628280-23-035187:8k_2_02:4]
Lennox Reports Record Third Quarter Results and Raises 2023 Guidance

[0001628280-23-035187:8k_2_02:5]
______________________________________________________________________________

[0001628280-23-035187:8k_2_02:6]
Q3 Results Summary

[0001628280-23-035187:8k_2_02:7]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-23-035187:8k_2_02:8]
•       Revenue up 10% to $1.37 billion; core revenue excluding European Operations up 10% to $1.30 billion

[0001628280-23-035187:8k_2_02:9]
•       GAAP diluted EPS down 9% to $3.65, impacted by impairment related to European divestiture; adjusted

[0001628280-23-035187:8k_2_02:10]
diluted EPS up 30% to $5.37

[0001628280-23-035187:8k_2_02:11]
•       Operating cash flow up 83% to $313 million

[0001628280-23-035187:8k_2_02:12]
•       Raising 2023 outlook with core revenue up ~5% and an adjusted EPS range of $17.25 to $17.75

[0001628280-23-035187:8k_2_02:13]
_____________________________________________________________________________

[0001628280-23-035187:8k_2_02:14]
Highlights from recent press announcements:

[0001628280-23-035187:8k_2_02:15]
•       Company announced the acquisition of AES to expand Lennox commercial HVAC services

[0001628280-23-035187:8k_2_02:16]
•       Company announced CFO Joseph Reitmeier has elected to retire and is being succeeded by Michael

[0001628280-23-035187:8k_2_02:17]
Quenzer, effective January 1, 2024

[0001628280-23-035187:8k_2_02:18]
___________________________________________________________________________

[0001628280-23-035187:8k_2_02:19]
DALLAS, October 26, 2023 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported record third quarter revenue of $1.37 billion. Operating income was $187 million for the third quarter, including a $63M non-cash impairment related to the planned European divestiture. Operating margin was 13.7% and GAAP diluted earnings per share was $3.65.

[0001628280-23-035187:8k_2_02:20]
Core revenue, excluding European Operations, grew 10% to $1.30 billion. Adjusted segment profit rose 33% to $251 million. Adjusted segment margin was 19.3%, up 334 basis points. Adjusted earnings per share rose 30% to $5.37.

[0001628280-23-035187:8k_2_02:21]
“The record results Lennox achieved this quarter are a testament to our consistent leadership performance, the dedication and teamwork of our employees, and the focus on our transformational self-help initiatives,” said Chief Executive Officer, Alok Maskara. “With continued momentum and solid execution on driving top line growth and expanding margins, we are confidently raising our 2023 full year earnings estimate and increasing our revenue and free cash flow guidance.”

[0001628280-23-035187:8k_2_02:22]
“In addition to the impressive third quarter results, we have announced the planned transition of our Chief Financial Officer at the beginning of next year and portfolio updates including our strategic bolt-on acquisition of AES,” Maskara continued.

[0001628280-23-035187:8k_2_02:23]
In the third quarter, our Residential segment maintained a positive mix with increased sales of higher-efficiency products, which, along with effective pricing, led to a 7% sales growth and an 18% rise in operating profits.  Although unit sales volumes for the segment declined by 2%, our direct-to-contractor sales volume increased by 5%, reflecting healthy end markets and ongoing market share gains. Unit sales volumes through independent distribution channels declined mid-teens, primarily due to continued industry destocking, which decelerated during the quarter.

[0001628280-23-035187:8k_2_02:24]
The Commercial segment continues to achieve remarkable profit growth through pricing and higher efficiency product mix. Increased factory productivity has offset inflation and we have made significant progress on our new factory construction which will support growth and productivity.

[0001628280-23-035187:8k_2_02:25]
THIRD QUARTER 2023 FINANCIAL HIGHLIGHTS

[0001628280-23-035187:8k_2_02:26]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-23-035187:8k_2_02:27]
Revenue: $1.37 billion; Core revenue, which excludes our European operations, was $1.30 billion, up 10%.  Revenue growth was driven by price and favorable mix and partially offset by lower sales volumes.

[0001628280-23-035187:8k_2_02:28]
Operating Income: $187 million with operating profit margin of 13.7%.

[0001628280-23-035187:8k_2_02:29]
Adjusted Segment Profit: $251 million, up 33%, and adjusted segment profit margin of 19.3%, up 334 basis points. Adjusted segment profit increased $62 million as $97 million of price and mix benefits were partially offset by lower sales volumes and inflationary impacts on SG&A and distribution costs.

[0001628280-23-035187:8k_2_02:30]
Net Income: $130.4 million, or $3.65 per share, compared to $141.9 million, or $3.99 per share, in the prior year quarter.

[0001628280-23-035187:8k_2_02:31]
Adjusted Net Income: $191.6 million, or $5.37 per share, compared to $146.8 million, or $4.13 per share, in the prior year quarter.

[0001628280-23-035187:8k_2_02:32]
Cash: Operating cash flow was $313 million compared to $171 million in the prior-year quarter. Capital expenditures were $40 million compared to $20 million in the prior year quarter with the increase driven by the new Commercial factory investment in Saltillo, Mexico. Total debt at the end of the third quarter was approximately $1.5 billion. Total cash, cash equivalents and short-term investments were $142 million at the end of the quarter.

[0001628280-23-035187:8k_2_02:33]
Residential: Business segment revenue was $896 million, 7% greater than the prior year. Segment profit was $181 million, up 18%, and segment margin was 20.2%, up 183 basis points. Versus prior year, profit increased $28 million. The increase was driven by $51 million in pricing and mix benefits, partially offset by $4 million lower volume, along with headwinds of $19 million primarily from incentive compensation and inflationary wage and distribution impacts.

[0001628280-23-035187:8k_2_02:34]
Commercial: Business segment revenue was $406 million, up 15%. Segment profit was $97 million, up 86%, and segment margin expanded 912 basis points to 24.0%.  Segment profit increased $45 million compared to prior year, driven by $47 million of price and mix benefits and $1 million generated by higher sales volumes. Minor inflationary impacts on materials and production costs partially offset these gains.

[0001628280-23-035187:8k_2_02:35]
Corporate and Other: Revenue in the European Refrigeration operations was $64.5 million, up 13%. European operations had $3.9 million in profit compared to a $0.4 million loss in the prior year quarter.  Corporate expenses were $27 million, or up $11 million compared to the prior year quarter as a result of higher incentive compensation and wage inflation.

[0001628280-23-035187:8k_2_02:36]
Loss on Divestiture: Lennox recently announced the exclusive agreements for its European businesses. In the third quarter a non-cash impairment of $63 million was recorded. Both transactions are expected to close in the fourth quarter.

[0001628280-23-035187:8k_2_02:37]
FULL-YEAR 2023 GUIDANCE

[0001628280-23-035187:8k_2_02:38]
For the full year of 2023, we now expect core revenue to be up approximately 5% (previous: up 2% to up 4%) and we expect adjusted earnings per share of $17.25 to $17.75 (previous: $15.50 to $16.00).

[0001628280-23-035187:8k_2_02:39]
Based on exceptional year-to-date performance and end market outlook, we are updating our free cash flow outlook to include operating cash flow of $600 million to $650 million and capital expenditures of approximately $250 million.

[0001628280-23-035187:8k_2_02:40]
“As we close out this year, I am confident in our ability to achieve our 2023 targets and remain excited about the opportunities ahead. I want to extend a heartfelt thank you to Joe Reitmeier for his dedication over the years and congratulate Michael Quenzer on his new role as CFO. Lennox also warmly welcomes the AES team and is excited to integrate their expertise to deliver additional value to our customers,” Maskara concluded.

[0001628280-23-035187:8k_2_02:41]
CONFERENCE CALL INFORMATION

[0001628280-23-035187:8k_2_02:42]
A conference call to discuss the company’s third quarter results and 2023 full year outlook will be held this morning at 8:30 a.m. Central Time. To participate in the earnings conference, please call 800-274-8461 (U.S.) or +1 203-518-9765 (international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ323. The conference call also will be webcast live on the company’s investor relations web site at www.investor.lennox.com. A replay of the conference call will be available until November 9, 2023, by calling toll-free 800-938-2113 (U.S.) or +1 402-220-1118 (international). The call will also be archived on the company's investor relations website.

[0001628280-23-035187:8k_2_02:43]
ABOUT LENNOX

[0001628280-23-035187:8k_2_02:44]
Lennox (NYSE: LII) is a leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our cooling, heating, indoor air quality, and refrigeration systems. Additional information on Lennox is available at www.investor.lennox.com or by contacting investor@lennoxintl.com.

[0001628280-23-035187:8k_2_02:45]
FORWARD-LOOKING STATEMENTS & NON-GAAP FINANCIAL MEASURES

[0001628280-23-035187:8k_2_02:46]
A reconciliation of non-GAAP financial measures appearing in this document to financial measures prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP) are included in the Annex to this document.

[0001628280-23-035187:8k_2_02:47]
This document includes forward-looking statements regarding core revenue, adjusted earnings per share, and free cash flow which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, changes in environmental liabilities, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. Core revenue, adjusted segment profit, and adjusted earnings per share exclude net sales from our European portfolio, which we plan to divest.  We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on LII’s full year GAAP financial results.

[0001628280-23-035187:8k_2_02:48]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-23-035187:8k_2_02:49]
Consolidated Statements of Operations

[0001628280-23-035187:8k_2_02:50]
(Unaudited)

[0001628280-23-035187:8k_2_02:51]
| (Amounts in millions, except per share data) | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 1,366.3 |  |  | $ | 1,244.9 |  |  | $ | 3,827.1 |  |  | $ | 3,624.6 |  |
| Cost of goods sold | 937.8 |  |  | 910.7 |  |  | 2,634.1 |  |  | 2,625.1 |  |
| Gross profit | 428.5 |  |  | 334.2 |  |  | 1,193.0 |  |  | 999.5 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 178.9 |  |  | 147.3 |  |  | 527.6 |  |  | 472.2 |  |
| Losses (gains) and other expenses, net | 3.5 |  |  | 3.3 |  |  | 5.2 |  |  | 5.4 |  |
| Restructuring charges | 0.3 |  |  | 0.2 |  |  | 0.2 |  |  | 1.2 |  |
| Impairment on assets held for sale | 63.2 |  |  | — |  |  | 63.2 |  |  | — |  |
| Income from equity method investments | (4.2) |  |  | (2.4) |  |  | (8.0) |  |  | (3.9) |  |
| Operating income | 186.8 |  |  | 185.8 |  |  | 604.8 |  |  | 524.6 |  |
| Pension settlements | 0.3 |  |  | — |  |  | 0.4 |  |  | 0.3 |  |
| Interest expense, net | 11.2 |  |  | 10.5 |  |  | 40.4 |  |  | 26.1 |  |
| Other expense (income), net | 0.1 |  |  | 0.7 |  |  | (0.1) |  |  | 1.9 |  |
| Net income before income taxes | 175.2 |  |  | 174.6 |  |  | 564.1 |  |  | 496.3 |  |
| Provision for income taxes | 44.8 |  |  | 32.7 |  |  | 118.5 |  |  | 93.6 |  |
| Net income | $ | 130.4 |  |  | $ | 141.9 |  |  | $ | 445.6 |  |  | $ | 402.7 |  |
| Earnings per share – Basic: | $ | 3.67 |  |  | $ | 4.00 |  |  | $ | 12.55 |  |  | $ | 11.25 |  |
| Earnings per share – Diluted: | $ | 3.65 |  |  | $ | 3.99 |  |  | $ | 12.51 |  |  | $ | 11.22 |  |
| Weighted Average Number of Shares Outstanding - Basic | 35.5 |  |  | 35.4 |  |  | 35.5 |  |  | 35.8 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 35.7 |  |  | 35.5 |  |  | 35.6 |  |  | 35.9 |  |

[0001628280-23-035187:8k_2_02:52]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |
| Segment Net Sales and Profit (Loss) |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |

[0001628280-23-035187:8k_2_02:53]
| (Amounts in millions) | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022(2) |  | 2023 |  | 2022(2) |
| Net Sales |  |  |  |  |  |  |  |
| Residential | $ | 896.3 |  |  | $ | 835.3 |  |  | $ | 2,513.6 |  |  | $ | 2,494.9 |  |
| Commercial (2) | 405.5 |  |  | 352.3 |  |  | 1,121.5 |  |  | 959.2 |  |
| Corporate and other (2) | 64.5 |  |  | 57.3 |  |  | 192.0 |  |  | 170.5 |  |
|  | $ | 1,366.3 |  |  | $ | 1,244.9 |  |  | $ | 3,827.1 |  |  | $ | 3,624.6 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |
| Residential | $ | 181.4 |  |  | $ | 153.8 |  |  | $ | 495.2 |  |  | $ | 477.7 |  |
| Commercial (2) | 97.3 |  |  | 52.4 |  |  | 250.3 |  |  | 117.4 |  |
| Corporate and other (2) | (23.4) |  |  | (16.9) |  |  | (65.2) |  |  | (61.4) |  |
| Total segment profit | 255.3 |  |  | 189.3 |  |  | 680.3 |  |  | 533.7 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Impairment on assets held for sale | 63.2 |  |  | — |  |  | 63.2 |  |  | — |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) | 5.0 |  |  | $ | 3.3 |  |  | 12.1 |  |  | 7.9 |  |
| Restructuring charges | 0.3 |  |  | 0.2 |  |  | 0.2 |  |  | 1.2 |  |
| Operating income | $ | 186.8 |  |  | $ | 185.8 |  |  | $ | 604.8 |  |  | $ | 524.6 |  |

[0001628280-23-035187:8k_2_02:54]
(1)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-23-035187:8k_2_02:55]
•The following items in Losses (gains) and other expenses, net:

[0001628280-23-035187:8k_2_02:56]
◦Net change in unrealized (gains) losses on unsettled futures contracts,

[0001628280-23-035187:8k_2_02:57]
◦Environmental liabilities and special litigation charges, and;

[0001628280-23-035187:8k_2_02:58]
◦Other items, net

[0001628280-23-035187:8k_2_02:59]
•Restructuring charges, and;

[0001628280-23-035187:8k_2_02:60]
•Impairment on assets held for sale

[0001628280-23-035187:8k_2_02:61]
(2) Previously, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European portfolio and that we would continue to invest in our Heatcraft Worldwide Refrigeration business, all of which were previously in our Refrigeration segment.  On January 1, 2023, we adjusted our segment presentation to better align with how the segments are managed and evaluated after the change in portfolio.  Heatcraft Worldwide Refrigeration is now part of the Commercial segment while the European portfolio is presented with Corporate and Other until disposition. Amounts presented in this table have been recast to reflect the revised segment presentation.

[0001628280-23-035187:8k_2_02:62]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-23-035187:8k_2_02:63]
Consolidated Balance Sheets

[0001628280-23-035187:8k_2_02:64]
(Unaudited)

[0001628280-23-035187:8k_2_02:65]
| (Amounts in millions, except shares and par values) | As of September 30, 2023 |  | As of December 31, 2022 |
| ASSETS | (Unaudited) |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 132.0 |  |  | $ | 52.6 |  |
| Short-term investments | 9.6 |  |  | 8.5 |  |
| Accounts and notes receivable, net of allowances of $15.3 and $15.5 in 2023 and 2022, respectively | 694.8 |  |  | 608.5 |  |
| Inventories, net | 747.9 |  |  | 753.0 |  |
| Assets held for sale | 92.8 |  |  | — |  |
| Other assets | 65.3 |  |  | 73.9 |  |
| Total current assets | 1,742.4 |  |  | 1,496.5 |  |
| Property, plant and equipment, net of accumulated depreciation of $897.5 and $920.8 in 2023 and 2022, respectively | 602.1 |  |  | 548.9 |  |
| Right-of-use assets from operating leases | 214.1 |  |  | 219.9 |  |
| Goodwill | 181.7 |  |  | 186.3 |  |
| Deferred income taxes | 50.1 |  |  | 27.5 |  |
| Other assets, net | 99.7 |  |  | 88.5 |  |
| Total assets | $ | 2,890.1 |  |  | $ | 2,567.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | $ | 361.6 |  |  | $ | 710.6 |  |
| Current operating lease liabilities | 60.2 |  |  | 63.3 |  |
| Accounts payable | 345.8 |  |  | 427.3 |  |
| Accrued expenses | 408.7 |  |  | 376.9 |  |
| Liabilities held for sale | 69.7 |  |  | — |  |
| Income taxes payable | 9.0 |  |  | 17.6 |  |
| Total current liabilities | 1,255.0 |  |  | 1,595.7 |  |
| Long-term debt | 1,121.6 |  |  | 814.2 |  |
| Long-term operating lease liabilities | 162.5 |  |  | 161.8 |  |
| Pensions | 33.9 |  |  | 40.1 |  |
| Other liabilities | 157.6 |  |  | 158.9 |  |
| Total liabilities | 2,730.6 |  |  | 2,770.7 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' equity (deficit): |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,178.9 |  |  | 1,155.2 |  |
| Retained earnings | 3,400.3 |  |  | 3,070.6 |  |
| Accumulated other comprehensive loss | (77.0) |  |  | (90.6) |  |
| Treasury stock, at cost, 51,633,264 shares and 51,700,260 shares for 2023 and 2022, respectively | (4,343.6) |  |  | (4,339.2) |  |
| Total stockholders' equity (deficit) | 159.5 |  |  | (203.1) |  |
| Total liabilities and stockholders' equity (deficit) | $ | 2,890.1 |  |  | $ | 2,567.6 |  |

[0001628280-23-035187:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-23-035187:8k_2_02:67]
Consolidated Statements of Cash Flows

[0001628280-23-035187:8k_2_02:68]
(Unaudited)

[0001628280-23-035187:8k_2_02:69]
| (Amounts in millions) | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 445.6 |  |  | $ | 402.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Income from equity method investments | (8.0) |  |  | (3.9) |  |
| Impairment on assets held for sale | 63.2 |  |  | — |  |
| Dividends from affiliates | — |  |  | 1.2 |  |
| Restructuring charges, net of cash paid | — |  |  | 0.7 |  |
| Provision for credit losses | 4.7 |  |  | 4.3 |  |
| Unrealized losses, net on derivative contracts | 5.6 |  |  | 0.8 |  |
| Stock-based compensation expense | 23.5 |  |  | 16.4 |  |
| Depreciation and amortization | 62.0 |  |  | 56.2 |  |
| Deferred income taxes | (24.9) |  |  | (16.6) |  |
| Pension expense | 2.4 |  |  | 5.1 |  |
| Pension contributions | (2.8) |  |  | (0.7) |  |
| Other items, net | (1.4) |  |  | (1.4) |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts and notes receivable | (142.5) |  |  | (214.9) |  |
| Inventories | (44.9) |  |  | (245.7) |  |
| Other current assets | (0.5) |  |  | (5.1) |  |
| Accounts payable | (10.9) |  |  | 78.7 |  |
| Accrued expenses | 69.4 |  |  | 36.0 |  |
| Income taxes payable and receivable, net | (6.7) |  |  | 35.5 |  |
| Leases, net | 3.4 |  |  | 0.8 |  |
| Other, net | (7.3) |  |  | 20.0 |  |
| Net cash provided by operating activities | 429.9 |  |  | 170.1 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 1.6 |  |  | 1.2 |  |
| Purchases of property, plant and equipment | (125.0) |  |  | (67.0) |  |
| Purchases of short-term investments | (1.1) |  |  | (2.4) |  |
| Net cash used in investing activities | (124.5) |  |  | (68.2) |  |
| Cash flows from financing activities: |  |  |  |
| Asset securitization borrowings | 190.0 |  |  | 382.0 |  |
| Asset securitization payments | (540.0) |  |  | (232.0) |  |
| Long-term debt payments | (10.6) |  |  | (9.8) |  |
| Issuance of senior unsecured notes | 500.0 |  |  |  |
| Borrowings from credit facility | 1,547.5 |  |  | 1,967.5 |  |
| Payments on credit facility | (1,739.5) |  |  | (1,752.0) |  |
| Payments of deferred financing costs | (5.4) |  |  | — |  |
| Proceeds from employee stock purchases | 2.9 |  |  | 2.7 |  |
| Repurchases of common stock | — |  |  | (300.0) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (7.1) |  |  | (5.5) |  |
| Cash dividends paid | (153.4) |  |  | (142.0) |  |
| Net cash used in financing activities | (215.6) |  |  | (89.1) |  |
| Increase in cash and cash equivalents | 89.8 |  |  | 12.8 |  |
| Cash balances classified as assets held for sale | (7.6) |  |  | — |  |
| Effect of exchange rates on cash and cash equivalents | (2.8) |  |  | (3.1) |  |
| Cash and cash equivalents, beginning of period | 52.6 |  |  | 31.0 |  |
| Cash and cash equivalents, end of period | $ | 132.0 |  |  | $ | 40.7 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 42.0 |  |  | $ | 23.2 |  |
| Income taxes paid (net of refunds) | $ | 151.3 |  |  | $ | 75.4 |  |

[0001628280-23-035187:8k_2_02:70]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |  |  |
| (Unaudited, in millions, except per share and ratio data) |  |  |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit (loss) presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company's business trends and operating performance. In November 2022, we announced the decision to explore strategic alternatives for our European portfolio. The results from operations for these businesses have been shown in the tables below as "Non-Core business results." The prior period results have been updated to provide period-over-period comparability. |  |  |
| Reconciliation of Net income, a GAAP measure, to Adjusted Net income, a Non-GAAP measure |  |  |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  |  |  |  |
|  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  |  |  |  |  |  |
| Net income, a GAAP measure | $ | 130.4 |  | $ | 3.65 |  |  | $ | 141.9 |  | $ | 3.99 |  |  | $ | 445.6 |  | $ | 12.51 |  |  | $ | 402.7 |  | $ | 11.22 |  |  |  |  |  |  |  |
| Restructuring charges | 0.3 |  | 0.01 |  |  | 0.2 |  | — |  |  | 0.2 |  | 0.01 |  |  | 1.0 |  | 0.03 |  |  |  |  |  |  |  |
| Pension settlements | 0.2 |  | 0.01 |  |  | — |  | — |  |  | 0.3 |  | 0.01 |  |  | 0.2 |  | 0.01 |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) | 4.3 |  | 0.11 |  |  | 3.0 |  | 0.09 |  |  | 9.6 |  | 0.26 |  |  | 6.7 |  | 0.18 |  |  |  |  |  |  |  |
| Excess tax benefit from share-based compensation (b) | (2.3) |  | (0.06) |  |  | (0.2) |  | — |  |  | (2.4) |  | (0.07) |  |  | 0.3 |  | 0.01 |  |  |  |  |  |  |  |
| Other tax items, net (b) | — |  | — |  |  | 0.7 |  | 0.02 |  |  | 0.4 |  | 0.01 |  |  | (0.8) |  | (0.02) |  |  |  |  |  |  |  |
| Impairment on assets held for sale | 62.0 |  | 1.74 |  |  | — |  | — |  |  | 62.0 |  | 1.74 |  |  | — |  | — |  |  |  |  |  |  |  |
| Non-core business results (c) | (3.3) |  | (0.09) |  |  | 1.2 |  | 0.03 |  |  | (4.8) |  | (0.13) |  |  | 6.2 |  | 0.17 |  |  |  |  |  |  |  |
| Adjusted net income, a non-GAAP measure | $ | 191.6 |  | $ | 5.37 |  |  | $ | 146.8 |  | $ | 4.13 |  |  | $ | 510.9 |  | $ | 14.34 |  |  | $ | 416.3 |  | $ | 11.60 |  |  |  |  |  |  |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (c) Non-core business results represent activity related to our business operations in Europe not included elsewhere in the reconciliations |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-23-035187:8k_2_02:71]
| Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net cash provided by operating activities | $ | 313.2 |  |  | $ | 170.9 |  |  | $ | 429.9 |  |  | $ | 170.1 |  |
| Purchases of property, plant and equipment | (39.7) |  |  | (20.3) |  |  | (125.0) |  |  | (67.0) |  |
| Proceeds from the disposal of property, plant and equipment | 0.1 |  |  | 0.7 |  |  | 1.6 |  |  | 1.2 |  |
| Free cash flow, a Non-GAAP measure | $ | 273.6 |  |  | $ | 151.3 |  |  | $ | 306.5 |  |  | $ | 104.3 |  |

[0001628280-23-035187:8k_2_02:72]
| Reconciliation of Net sales, a GAAP measure to Core net sales, a Non-GAAP measure |
|  | For the Three Months Ended September 30, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales, a GAAP measure | $ | 64.5 |  |  | $ | 57.3 |  |  | $ | 1,366.3 |  |  | $ | 1,244.9 |  |
| Net sales from non-core businesses (a) | (64.5) |  |  | (57.3) |  |  | (64.5) |  |  | (57.3) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | — |  |  | $ | 1,301.8 |  |  | $ | 1,187.6 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
|  | For the Nine Months Ended September 30, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales, a GAAP measure | $ | 192.0 |  |  | $ | 170.5 |  |  | $ | 3,827.1 |  |  | $ | 3,624.6 |  |
| Net sales from non-core businesses (a) | (192.0) |  |  | (170.5) |  |  | (192.0) |  |  | (170.5) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | — |  |  | $ | 3,635.1 |  |  | $ | 3,454.1 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
| Reconciliation of Segment profit (loss), a Non-GAAP measure to Adjusted Segment profit (loss), a Non-GAAP measure |
|  | For the Three Months Ended September 30, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment profit (loss), a Non-GAAP measure | $ | (23.4) |  |  | $ | (16.9) |  |  | $ | 255.3 |  |  | $ | 189.3 |  |
| Profit (loss) from non-core businesses (a) | 3.9 |  |  | (0.4) |  |  | 3.9 |  |  | (0.4) |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (27.3) |  |  | $ | (16.5) |  |  | $ | 251.4 |  |  | $ | 189.7 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
|  | For the Nine Months Ended September 30, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment profit (loss), a Non-GAAP measure | $ | (65.2) |  |  | $ | (61.4) |  |  | $ | 680.3 |  |  | $ | 533.7 |  |
| Profit (loss) from non-core businesses (a) | 6.1 |  |  | (4.4) |  |  | 6.1 |  |  | (4.4) |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (71.3) |  |  | $ | (57.0) |  |  | $ | 674.2 |  |  | $ | 538.1 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |

## item 5.02 — body, verbatim

[0001628280-23-035187:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001628280-23-035187:8k_body:2]
On October 23, 2023, Joseph W. Reitmeier, Executive Vice President and Chief Financial Officer, notified the Company of his decision to retire as Chief Financial Officer effective December 31, 2023.  Thereafter, Mr. Reitmeier will continue to serve as Executive Vice President, with no changes to his current compensation package, and provide advice and assistance related to the Chief Financial Officer leadership transition until his retirement from the Company effective February 29, 2024.  Mr. Reitmeier's decision to retire is not the result of any disagreement with management related to the Company’s operations, policies, or practices.

[0001628280-23-035187:8k_body:3]
Effective January 1, 2024, Michael Quenzer, age 46, who is currently serving as Vice President, Financial Planning & Analysis and Investor Relations, will succeed Mr. Reitmeier as Executive Vice President and Chief Financial Officer of the Company. Mr. Quenzer has served in his current role since January 2023.  Prior to that, he was the chief financial officer for the Company’s Commercial segment from November 2016 until January 2023.  Mr. Quenzer has served in various capacities of increasing responsibility within the Company’s Finance department since 2004.

[0001628280-23-035187:8k_body:4]
There are no arrangements or understandings between Mr. Quenzer and any other persons pursuant to which he was selected as CFO.  There are also no family relationships between Mr. Quenzer and any director or executive officer of the Company, and he has no direct or indirect material interest in any transaction required to be disclosed pursuant to Item 404(a) of Regulation S-K.

[0001628280-23-035187:8k_body:5]
At this time, any changes to Mr. Quenzer’s compensatory arrangements in connection with his appointment as Chief Financial Officer have not been determined.  The Company will file an amendment to this Current Report on Form 8-K after such arrangements are determined.
