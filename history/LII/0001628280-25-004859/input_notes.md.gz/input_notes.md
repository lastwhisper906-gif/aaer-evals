# LII notes — 0001628280-25-004859


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-25-004859:notes:1]
Portions of the registrant’s 2025 Definitive Proxy Statement to be filed with the Securities and Exchange Commission in connection with the registrant’s 2025 Annual Meeting of Stockholders to be held on May 22, 2025 are incorporated by reference into Part III of this report.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001628280-25-004859:notes:2]
We manage cybersecurity risk through three core teams: cybersecurity engineering, data privacy, and a security operation center. These teams are responsible for overseeing data safety during new system and infrastructure deployments, maintaining appropriate cybersecurity controls, and monitoring, documenting and investigating any anomalies affecting employees, suppliers, and customers. Our IT security controls are designed to align with the NIST (National Institute of Standards and Technology) standards and are tested on an ongoing basis. These controls and procedures include processes that oversee and identify cybersecurity risks associated with third-party service providers that we engage, as described below.  For instance, we conduct risk and compliance assessments of third-party service providers that request access to our information assets.  To support our internal risk management structure, we use third-party specialists to monitor for emerging threats, conduct vulnerability scans and analysis including simulated hacker attacks, and audit our cybersecurity framework.  We also maintain an information security risk insurance policy in the event of a security breach.  Our internal audit function also performs independent testing on aspects of the operations of our cybersecurity program and the supporting controls based upon its risk-based internal audit plan and reports the results of these audits in its periodic reports to the Audit Committee.

[0001628280-25-004859:notes:3]
Leadership receives training on how to respond to ransomware events and participates in breach simulations at least once a year. Additionally, employees throughout the organization support LII’s risk management efforts by participating in mandatory cybersecurity training at least once a year, ongoing awareness campaigns, and quarterly simulated phishing attempts.

[0001628280-25-004859:notes:4]
To our knowledge, LII’s business strategy, results of operations and financial condition have not been materially affected by risks from cybersecurity threats within the last three years, including as a result of previously identified cybersecurity incidents.  However, we cannot provide assurance that they will not be materially affected in the future by such risks or any future material incidents. For more information on our cybersecurity related risks, see Item 1A, “Risk Factors.”


## cyd:CybersecurityRiskProcessForInformingManagementOrCommitteesResponsibleTextBlock

[0001628280-25-004859:notes:5]
Our Chief Technology Officer is ultimately responsible for overseeing all cybersecurity management, including the three core teams mentioned above, and reports to the Board of Directors twice a year on our cybersecurity tactical responses and strategic roadmap. The entire Board of Directors reviews significant cybersecurity risks and works with the Audit Committee to address enterprise risk management processes and policies. 
At the management level, our Data Protection & Cybersecurity Steering Committee (“DPCSC”) meets on a quarterly basis. The DPCSC includes representatives from communications, ethics and compliance, human resources, information technology, corporate audit, legal, risk, privacy, and sourcing.  This committee is responsible for overseeing LII’s data protection and cybersecurity policies and procedures.  These cybersecurity policies and procedures include an IT security and privacy incident response plan to notify the appropriate parties, including our Chief Technology Officer, our Disclosure Committee, and our Board of Directors, in a timely manner.


## cyd:CybersecurityRiskManagementExpertiseOfManagementResponsibleTextBlock

[0001628280-25-004859:notes:6]
Our Chief Technology Officer has served in the role since 2008, and has more than 15 years of  experience in developing and executing large enterprise data privacy and cyber security roadmaps at publicly-traded companies.  He holds undergraduate and graduate degrees in engineering.  Our Vice President, Information Technology, has served in the role since 2003, and has more than 35 years of cybersecurity experience.  He holds an undergraduate degree in computer science.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-25-004859:notes:7]
2. Summary of Significant Accounting Policies:

[0001628280-25-004859:notes:8]
Principles of Consolidation

[0001628280-25-004859:notes:9]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.

[0001628280-25-004859:notes:10]
Cash and Cash Equivalents

[0001628280-25-004859:notes:11]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.

[0001628280-25-004859:notes:12]
Short-term Investments

[0001628280-25-004859:notes:13]
Short-term investments include all investments, exclusive of cash equivalents, with a stated maturity date of one year or less from the balance sheet date.

[0001628280-25-004859:notes:14]
Accounts and Notes Receivable

[0001628280-25-004859:notes:15]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheet, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management’s judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management’s review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.

[0001628280-25-004859:notes:16]
Inventories

[0001628280-25-004859:notes:17]
Inventory costs include material, labor, and capitalized overhead.  Inventories of $494.3 million and $438.9 million as of December 31, 2024 and 2023, respectively, were valued at the lower of cost or net realizable value using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or net realizable value with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001628280-25-004859:notes:18]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method. See Note 9 for more information on our inventories.

[0001628280-25-004859:notes:19]
Property, Plant and Equipment

[0001628280-25-004859:notes:20]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001628280-25-004859:notes:21]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001628280-25-004859:notes:22]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 40 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 5 years |
| Vehicles | 3 to 10 years |

[0001628280-25-004859:notes:23]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable. To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 9 for additional information on our property, plant and equipment. Based on the expected fair value of the consideration to be received from the sale of our European commercial HVAC and refrigeration businesses, net of our costs to sell, we recorded an impairment on assets held for sale during the third quarter of 2023 which included a $22.6 million impairment of property, plant and equipment.

[0001628280-25-004859:notes:24]
Goodwill and Intangible Assets

[0001628280-25-004859:notes:25]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually during the third quarter and whenever events or changes in circumstances indicate the asset may be impaired.  See Note 9 for additional information on our goodwill.

[0001628280-25-004859:notes:26]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for the Company as a whole and for each reporting unit.

[0001628280-25-004859:notes:27]
If a quantitative goodwill impairment test is determined to be necessary, we estimate reporting unit fair values using a combination of the discounted cash flow approach and a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. The market approach is based on objective evidence of market values.  In the third quarter of 2023, we recorded a $2.3 million impairment of goodwill related to our agreement to sell our European commercial HVAC and refrigeration businesses which was included in our impairment on assets held for sale.

[0001628280-25-004859:notes:28]
Intangible assets such as customer relationships, non-compete agreements and trade names with finite lives are amortized based on the pattern in which the economic benefits of the intangible assets are utilized. If a pattern of economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, then straight-line amortization may be used.

[0001628280-25-004859:notes:29]
The range of useful lives approximates the following (in years):

[0001628280-25-004859:notes:30]
| Customer relationships | 2 to 20 years |
| Non-compete agreements | Contracted term |
| Trade names | 2 to 10 years |

[0001628280-25-004859:notes:31]
We assess the recoverability of the carrying amount of our intangible assets with finite lives whenever events or changes in circumstances indicate that the carrying value of the asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less then the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001628280-25-004859:notes:32]
Product Warranties

[0001628280-25-004859:notes:33]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from 1 to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded in cost of goods sold on the date that revenue is recognized. Our estimates of future warranty costs are determined by product category. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. In most cases, the estimated units to be repaired under warranty are multiplied by the estimated cost of replacement parts to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 5 for more information on our estimated future warranty costs.

[0001628280-25-004859:notes:34]
Pensions and Post-retirement Benefits

[0001628280-25-004859:notes:35]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheet.  Changes in the funded status are recognized in the year in which the changes occur through Accumulated other comprehensive loss (“AOCL”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001628280-25-004859:notes:36]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management’s estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 10 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001628280-25-004859:notes:37]
Self-Insurance

[0001628280-25-004859:notes:38]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information, industry factors, and trends.  The self-insurance liabilities as of December 31, 2024 represent our best estimate of the future payments to be made on reported and unreported losses for 2024 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 5 for additional information on our self-insured risks and liabilities.

[0001628280-25-004859:notes:39]
Derivatives

[0001628280-25-004859:notes:40]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheet at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 9 for more information on our derivatives.

[0001628280-25-004859:notes:41]
Leases

[0001628280-25-004859:notes:42]
We lease certain real and personal property under non-cancelable leases including real estate, IT equipment, fleet vehicles and manufacturing and distribution equipment.  At inception of the lease, we determine a lease exists if the contract conveys the right to control an identified asset for a period of time in exchange for consideration.  Control is considered to exist when the lessee has the right to obtain substantially all the economic benefits from the use of an identified asset as well as the right to direct the use of the asset.  If a contract is considered to be a lease, we recognize a lease liability based on the present value of the future minimum lease payments and a right-of-use asset.  For contracts that are 12 months or less, we do not recognize a right-of-use asset or liability.  We do not separate non-lease components from the lease components to which they relate and account for the combined lease and non-lease components as a single lease component.

[0001628280-25-004859:notes:43]
Income Taxes

[0001628280-25-004859:notes:44]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date. Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 12 for more information related to income taxes.

[0001628280-25-004859:notes:45]
Revenue Recognition

[0001628280-25-004859:notes:46]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where control does not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.  See Note 8 for more information on our revenue recognition practices.

[0001628280-25-004859:notes:47]
Cost of Goods Sold

[0001628280-25-004859:notes:48]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense, and freight and distribution costs.

[0001628280-25-004859:notes:49]
Selling, General and Administrative Expenses

[0001628280-25-004859:notes:50]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other SG&A related costs such as insurance, travel, non-production depreciation, and rent.

[0001628280-25-004859:notes:51]
Stock-Based Compensation

[0001628280-25-004859:notes:52]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs based on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 15 for more information.

[0001628280-25-004859:notes:53]
Translation of Foreign Currencies

[0001628280-25-004859:notes:54]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCL in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.

[0001628280-25-004859:notes:55]
Use of Estimates

[0001628280-25-004859:notes:56]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001628280-25-004859:notes:57]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001628280-25-004859:notes:58]
Changes in Accounting Standards Effective for Future Reporting Periods

[0001628280-25-004859:notes:59]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which updates income tax disclosure requirements, primarily through enhanced disclosures regarding income rate reconciliation and income taxes paid. This is effective for fiscal years beginning after December 15, 2024. ASU 2023-09 requires that on an annual basis, entities disclose specific categories in the rate reconciliation and additional information for reconciling items that meet a certain quantitative threshold. The amendment also requires enhanced disclosures around taxes paid and income tax expense by federal, state and foreign jurisdictions. We will adopt ASU 2023-09 in the fourth quarter of 2025.

[0001628280-25-004859:notes:60]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40), which will require public entities to disclose additional information about specific expense categories in the notes to the financial statements at interim and annual reporting periods. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027. We are currently evaluating the impact of this standard on our financial statements.

[0001628280-25-004859:notes:61]
Recently Adopted Accounting Pronouncements

[0001628280-25-004859:notes:62]
In March 2023, the FASB issued ASU No. 2023-02, Investments – Equity Method and Joint Ventures (Topic 323): Accounting for Investments in Tax Credit Structures using the Proportional Amortization Method. ASU 2023-02 replaces the guidance related to accounting for investments in tax credit structures to allow the use of the proportional amortization method. The amendment permits reporting entities to elect to account for their equity investments in tax credit structures using the proportional amortization method if certain conditions are met. This amendment requires entities to make disclosures about all investments in a tax credit program for which they have elected to account for using the proportional amortization method, including those investments in an elected tax credit program that do not meet the conditions to apply the proportional amortization method. ASU 2023-02 is effective for fiscal years beginning after December 15, 2023, including interim periods within those fiscal years. The adoption of ASU 2023-02 did not have a material impact on our financial statements.
In November 2023, the FASB issued ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. This is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. We adopted the standard in the current period. See Note 3 for more information.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-25-004859:notes:63]
Components of Property, plant and equipment, net were as follows (in millions):

[0001628280-25-004859:notes:64]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Land | $ | 30.3 |  |  | $ | 23.7 |  |
| Buildings and improvements | 427.8 |  |  | 371.9 |  |
| Machinery and equipment | 1,056.6 |  |  | 965.0 |  |
| Finance leases | 84.9 |  |  | 72.2 |  |
| Construction in progress and equipment not yet in service | 157.3 |  |  | 198.4 |  |
| Total | 1,756.9 |  |  | 1,631.2 |  |
| Less accumulated depreciation | (956.8) |  |  | (910.8) |  |
| Property, plant and equipment, net | $ | 800.1 |  |  | $ | 720.4 |  |


## us-gaap:LesseeLeasesPolicyTextBlock

[0001628280-25-004859:notes:65]
We lease certain real and personal property under non-cancelable leases.  Approximately 81% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-004859:notes:66]
3. Reportable Business Segments:

[0001628280-25-004859:notes:67]
Description of Segments

[0001628280-25-004859:notes:68]
We operate in two reportable business segments of the HVACR industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001628280-25-004859:notes:69]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Home Comfort Solutions |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Building Climate Solutions |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products, curb, curb adapters, drop box diffusers, HVAC recycling and salvage service, condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks |  | Light Commercial; Food Preservation; Non-Food Industry |  | United StatesCanada |

[0001628280-25-004859:notes:70]
Prior to January 1, 2023, we operated in three reportable business segments.  In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses.  We continue to invest in our Heatcraft Worldwide Refrigeration business which is included in the Building Climate Solutions segment. The consolidation of our Heatcraft business within the Building Climate Solutions segment provides the opportunity to leverage synergies and create long-term growth opportunities by integrating entities with similar products, end consumers and financial performance metrics under the same management. The change in segment reporting better aligns with how the businesses are managed and evaluated given the change in portfolio.

[0001628280-25-004859:notes:71]
In the fourth quarter of 2023, we successfully completed the divestiture of our European operations, which until that time, were presented with the Corporate and Other segment.

[0001628280-25-004859:notes:72]
Segment Data

[0001628280-25-004859:notes:73]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation in the table below details the items excluded.

[0001628280-25-004859:notes:74]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results. There were no significant intercompany eliminations for the periods presented.

[0001628280-25-004859:notes:75]
The chief operating decision maker uses segment profit or loss from operations before interest and income taxes, excluding certain items, to allocate resources (including employees, financial, or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances in segment profit or loss and its individual components on a monthly basis when evaluating segment performance and making decisions about allocating resources to the segments.

[0001628280-25-004859:notes:76]
The Company’s chief operating decision maker is Alok Maskara, Chief Executive Officer.

[0001628280-25-004859:notes:77]
Key financial information for each segment is shown below (in millions):

[0001628280-25-004859:notes:78]
|  | Home Comfort Solutions |  | Business Climate Solutions |  | Corporate and Other (1) |  | Total |
| For the Year Ended December 31, 2024 |  |  |  |  |  |  |  |
| Net Sales(2) | $ | 3,577.1 |  |  | $ | 1,764.2 |  |  | $ | — |  |  | $ | 5,341.3 |  |
| Cost of Goods Sold | 2,426.2 |  |  | 1,142.5 |  |  | 0.7 |  |  | 3,569.4 |  |
| Selling, general and administrative | 393.8 |  |  | 229.9 |  |  | 107.0 |  |  | 730.6 |  |
| Other (income) expense(3) | (2.5) |  |  | (5.2) |  |  | 12.7 |  |  | 5.0 |  |
| Segment profit (loss)(4) | $ | 759.7 |  |  | $ | 396.9 |  |  | $ | (120.3) |  |  | $ | 1,036.3 |  |
| For the Year Ended December 31, 2023 |  |  |  |  |  |  |  |
| Net Sales(2) | $ | 3,222.9 |  |  | $ | 1,511.4 |  |  | $ | 247.6 |  |  | $ | 4,981.9 |  |
| Cost of Goods Sold | 2,277.3 |  |  | 977.9 |  |  | 178.9 |  |  | 3,434.1 |  |
| Selling, general and administrative | 350.2 |  |  | 197.5 |  |  | 157.8 |  |  | 705.5 |  |
| Other (income) expense(3) | (14.8) |  |  | (4.8) |  |  | 4.8 |  |  | (14.8) |  |
| Segment profit (loss)(4) | $ | 610.2 |  |  | $ | 340.8 |  |  | $ | (93.9) |  |  | $ | 857.1 |  |
| For the Year Ended December 31, 2022 |  |  |  |  |  |  |  |
| Net Sales(2) | $ | 3,198.3 |  |  | $ | 1,286.4 |  |  | $ | 233.7 |  |  | $ | 4,718.4 |  |
| Cost of Goods Sold | 2,302.2 |  |  | 948.5 |  |  | 183.0 |  |  | 3,433.7 |  |
| Selling, general and administrative | 303.3 |  |  | 179.7 |  |  | 144.2 |  |  | 627.2 |  |
| Other (income) expense(3) | (4.1) |  |  | (4.7) |  |  | 0.5 |  |  | (8.3) |  |
| Segment profit (loss)(4) | $ | 596.9 |  |  | $ | 162.9 |  |  | $ | (94.0) |  |  | $ | 665.8 |  |

[0001628280-25-004859:notes:79]
(1) The Corporate and Other segment included our European portfolio. In the fourth quarter of 2023, we completed the divestiture of our European operations.

[0001628280-25-004859:notes:80]
(2) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001628280-25-004859:notes:81]
(3) Other (income) expense is primarily comprised of (income) loss from equity method investments and other (gains) loss, net.

[0001628280-25-004859:notes:82]
(4) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-25-004859:notes:83]
•The following items in Losses and other expenses, net:

[0001628280-25-004859:notes:84]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001628280-25-004859:notes:85]
◦Environmental liabilities and special litigation charges, and

[0001628280-25-004859:notes:86]
◦Other items, net

[0001628280-25-004859:notes:87]
•Restructuring charges;

[0001628280-25-004859:notes:88]
•Impairment on assets held for sale; and

[0001628280-25-004859:notes:89]
•Loss (gain) on sale from previous dispositions.

[0001628280-25-004859:notes:90]
The reconciliations of segment profit to Operating income and Net income before income taxes are presented below (in millions):

[0001628280-25-004859:notes:91]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Total segment profit | $ | 1,036.3 |  |  | $ | 857.1 |  |  | $ | 665.8 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| Loss (gain) on sale from previous dispositions | 1.5 |  |  | (14.1) |  |  | — |  |
| Impairment of net assets held for sale | — |  |  | 63.2 |  |  | — |  |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) | — |  |  | 14.8 |  |  | 8.1 |  |
| Restructuring charges | — |  |  | 3.1 |  |  | 1.5 |  |
| Operating income | 1,034.8 |  |  | 790.1 |  |  | 656.2 |  |
| Reconciliation to income before income taxes: |  |  |  |  |  |
| Pension settlements | 0.4 |  |  | 0.8 |  |  | (0.2) |  |
| Interest expense, net | 38.7 |  |  | 51.7 |  |  | 38.7 |  |
| Other expense, net | 1.9 |  |  | 0.1 |  |  | 1.9 |  |
| Income before income taxes | $ | 993.8 |  |  | $ | 737.5 |  |  | $ | 615.8 |  |

[0001628280-25-004859:notes:92]
(1) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-25-004859:notes:93]
◦Environmental liabilities and special litigation charges, and;

[0001628280-25-004859:notes:94]
•Special product quality adjustments;

[0001628280-25-004859:notes:95]
•Loss (gain) on sale of businesses.

[0001628280-25-004859:notes:96]
Total assets by segment are shown below (in millions):

[0001628280-25-004859:notes:97]
|  | As of December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Total Assets: |  |  |  |  |  |
| Home Comfort Solutions | $ | 1,626.0 |  |  | $ | 1,449.4 |  |  | $ | 1,456.4 |  |
| Building Climate Solutions | 1,052.6 |  |  | 989.2 |  |  | 730.3 |  |
| Corporate and Other | 793.2 |  |  | 359.7 |  |  | 380.9 |  |
| Total assets | $ | 3,471.8 |  |  | $ | 2,798.3 |  |  | $ | 2,567.6 |  |

[0001628280-25-004859:notes:98]
The assets in the Corporate and Other segment primarily consist of cash, property, plant and equipment and short-term investments and deferred tax assets as well as the assets in the European portfolio which was disposed of in the fourth quarter of 2023.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001628280-25-004859:notes:99]
Total capital expenditures by segment are shown below (in millions):

[0001628280-25-004859:notes:100]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Capital Expenditures: |  |  |  |  |  |
| Home Comfort Solutions | $ | 78.1 |  |  | $ | 59.1 |  |  | $ | 42.4 |  |
| Building Climate Solutions | 57.8 |  |  | 119.6 |  |  | 29.7 |  |
| Corporate and Other | 27.7 |  |  | 71.5 |  |  | 29.0 |  |
| Total capital expenditures | $ | 163.6 |  |  | $ | 250.2 |  |  | $ | 101.1 |  |

[0001628280-25-004859:notes:101]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001628280-25-004859:notes:102]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Depreciation and Amortization: |  |  |  |  |  |
| Home Comfort Solutions | $ | 39.0 |  |  | $ | 35.3 |  |  | $ | 31.5 |  |
| Building Climate Solutions | 25.6 |  |  | 19.4 |  |  | 17.9 |  |
| Corporate and Other | 30.5 |  |  | 31.3 |  |  | 28.5 |  |
| Total depreciation and amortization | $ | 95.1 |  |  | $ | 86.0 |  |  | $ | 77.9 |  |

[0001628280-25-004859:notes:103]
The income from equity method investments is shown below (in millions):

[0001628280-25-004859:notes:104]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Home Comfort Solutions | $ | 4.4 |  |  | $ | 5.5 |  |  | $ | 0.9 |  |
| Building Climate Solutions | 3.5 |  |  | 3.0 |  |  | 4.2 |  |
| Total income from equity method investments | $ | 7.9 |  |  | $ | 8.5 |  |  | $ | 5.1 |  |

[0001628280-25-004859:notes:105]
Geographic Information

[0001628280-25-004859:notes:106]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001628280-25-004859:notes:107]
|  | As of December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 537.3 |  |  | $ | 487.1 |  |  | $ | 408.8 |  |
| Mexico | 254.0 |  |  | 228.7 |  |  | 110.9 |  |
| Canada | 2.9 |  |  | 2.2 |  |  | 2.1 |  |
| Other international | 5.9 |  |  | 2.4 |  |  | 27.1 |  |
| Total Property, plant and equipment, net | $ | 800.1 |  |  | $ | 720.4 |  |  | $ | 548.9 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-25-004859:notes:108]
The following table describes each segment:

[0001628280-25-004859:notes:109]
•Impairment on assets held for sale; and
•Loss (gain) on sale from previous dispositions.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-004859:notes:110]
4. Earnings Per Share:

[0001628280-25-004859:notes:111]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001628280-25-004859:notes:112]
The computations of basic and diluted earnings per share were as follows (in millions, except per share data):

[0001628280-25-004859:notes:113]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Net income | $ | 806.9 |  |  | $ | 590.1 |  |  | $ | 497.1 |  |
| Weighted-average shares outstanding – basic | 35.6 |  |  | 35.5 |  |  | 35.7 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.2 |  |  | 0.2 |  |  | 0.1 |  |
| Weighted-average shares outstanding – diluted | $ | 35.8 |  |  | $ | 35.7 |  |  | $ | 35.8 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Net income | $ | 22.67 |  |  | $ | 16.61 |  |  | $ | 13.92 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Net income | $ | 22.54 |  |  | $ | 16.54 |  |  | $ | 13.88 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-25-004859:notes:114]
The components of lease expense were as follows (in millions):

[0001628280-25-004859:notes:115]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Finance lease cost: |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 15.4 |  |  | $ | 14.5 |  |  | $ | 13.2 |  |
| Interest on lease liabilities | 2.7 |  |  | 1.7 |  |  | 0.7 |  |
| Operating lease cost | 83.3 |  |  | 74.1 |  |  | 67.7 |  |
| Short-term lease cost | 5.0 |  |  | 5.3 |  |  | 5.0 |  |
| Variable lease cost | 27.6 |  |  | 26.8 |  |  | 24.5 |  |
| Total lease cost | $ | 134.0 |  |  | $ | 122.4 |  |  | $ | 111.1 |  |
| Other information |  |  |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 76.6 |  |  | $ | 70.5 |  |  | $ | 66.0 |  |
| Financing cash flows from finance leases | $ | 17.3 |  |  | $ | 15.8 |  |  | $ | 13.6 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 26.1 |  |  | $ | 21.3 |  |  | $ | 14.4 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 177.1 |  |  | $ | 56.4 |  |  | $ | 98.8 |  |

[0001628280-25-004859:notes:116]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Finance lease right-of-use assets(1) | $ | 48.1 |  |  | $ | 38.4 |  |
| Operating lease right-of-use assets | $ | 327.2 |  |  | $ | 213.6 |  |
| Finance lease liability, current(2) | $ | 14.9 |  |  | $ | 12.1 |  |
| Finance lease liability, non-current(3) | $ | 39.5 |  |  | $ | 32.7 |  |
| Operating lease liability, current | $ | 73.4 |  |  | $ | 57.5 |  |
| Operating lease liability, non-current | $ | 267.6 |  |  | $ | 164.6 |  |
| Weighted-average remaining lease term – finance leases | 3.3 years |  | 3.4 years |
| Weighted-average remaining lease term – operating leases | 5.5 years |  | 5.0 years |
| Weighted-average discount rate – finance leases | 4.73 | % |  | 4.30 | % |
| Weighted-average discount rate – operating leases | 4.67 | % |  | 4.14 | % |
| (1) Recorded in Property, plant and equipment in Consolidated Balance Sheet |
| (2) Recorded in Current maturities of long-term debt in Consolidated Balance Sheet |
| (3) Recorded in Long-term debt in Consolidated Balance Sheet |

[0001628280-25-004859:notes:117]
Future annual minimum lease payments and finance lease commitments as of December 31, 2024 were as follows (in millions).

[0001628280-25-004859:notes:118]
|  | Operating Leases |  | Finance Leases |
| 2025 | $ | 82.4 |  |  | $ | 16.5 |  |
| 2026 | 75.6 |  |  | 12.8 |  |
| 2027 | 56.2 |  |  | 8.7 |  |
| 2028 | 46.4 |  |  | 17.1 |  |
| 2029 | 36.2 |  |  | 1.8 |  |
| Thereafter | 93.1 |  |  | 1.6 |  |
| Total minimum lease payments | $ | 389.9 |  |  | $ | 58.5 |  |
| Less imputed interest | (48.9) |  |  | (4.1) |  |
| Present value of minimum payments | $ | 341.0 |  |  | $ | 54.4 |  |

[0001628280-25-004859:notes:119]
As of December 31, 2024, the Company has an additional operating lease commitment of $28.7 million for a distribution facility that has not yet commenced and is not included in the amounts in the table above.

[0001628280-25-004859:notes:120]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024. The property consists of an office building of approximately 192,000 square feet, land and related improvements.  In December 2023, we purchased the property for $41.2 million.

[0001628280-25-004859:notes:121]
Environmental

[0001628280-25-004859:notes:122]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties, properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities; however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included in Accrued expenses and Other liabilities on the accompanying Consolidated Balance Sheets. Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001628280-25-004859:notes:123]
Product Warranties and Product Related Contingencies

[0001628280-25-004859:notes:124]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have

[0001628280-25-004859:notes:125]
an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001628280-25-004859:notes:126]
Total product warranty liabilities are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-25-004859:notes:127]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Accrued expenses | $ | 49.1 |  |  | $ | 45.4 |  |
| Other liabilities | 109.4 |  |  | 97.4 |  |
| Total product warranty liabilities | $ | 158.4 |  |  | $ | 142.8 |  |

[0001628280-25-004859:notes:128]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2024 and 2023 were as follows (in millions):

[0001628280-25-004859:notes:129]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Payments made in 2023 | (40.1) |  |
| Changes resulting from issuance of new warranties | 53.9 |  |
| Changes in estimates associated with pre-existing liabilities | (13.9) |  |
| Changes in foreign currency translation rates and other | 0.2 |  |
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Payments made in 2024 | (41.2) |  |
| Changes resulting from issuance of new warranties | 59.0 |  |
| Changes in estimates associated with pre-existing liabilities | (1.4) |  |
| Changes in foreign currency translation rates and other | (0.8) |  |
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |

[0001628280-25-004859:notes:130]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures. We use large deductible insurance plans, written through third-party insurance providers, for workers’ compensation/employers’ liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors’ and officers’ liability, property damage and certain other insurance programs.    For directors’ and officers’ liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001628280-25-004859:notes:131]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.

[0001628280-25-004859:notes:132]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-25-004859:notes:133]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Accrued expenses | $ | 4.6 |  |  | $ | 3.8 |  |
| Other liabilities | 15.6 |  |  | 15.1 |  |
| Total self-insurance liabilities | $ | 20.2 |  |  | $ | 18.9 |  |

[0001628280-25-004859:notes:134]
Litigation

[0001628280-25-004859:notes:135]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-25-004859:notes:136]
It is management’s opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-25-004859:notes:137]
6. Stock Repurchases:

[0001628280-25-004859:notes:138]
Our Board of Directors have authorized a total of $4 billion to repurchase shares of our common stock (collectively referred to as the “Share Repurchase Plans”), including a $1.0 billion share repurchase authorization in July 2021. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of December 31, 2024, $492 million of shares are available for repurchase under the Share Repurchase Plans.

[0001628280-25-004859:notes:139]
We repurchased 0.1 million shares at an aggregate cost, inclusive of fees, of $54.2 million in 2024 and 1.3 million shares for $300.0 million in 2022. No shares were repurchased in 2023. The shares repurchased are held as treasury shares.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-25-004859:notes:140]
7. Restructuring Charges:

[0001628280-25-004859:notes:141]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 3.

[0001628280-25-004859:notes:142]
We recorded restructuring charges of $3.1 million in 2023 to reorganize or remove duplicative headcount and infrastructure,  and $1.5 million in 2022 from activities initiated in prior years including the economic impact of COVID-19. There were no  restructuring charges in 2024. 
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-004859:notes:143]
8. Revenue Recognition:

[0001628280-25-004859:notes:144]
The following table disaggregates our revenue by business segment by geography to provide information as to the major sources of revenue.  See Note 3 for additional description of our reportable business segments and the products and services being sold in each segment.

[0001628280-25-004859:notes:145]
|  | For the Year Ended December 31, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 3,346.0 |  |  | $ | 1,675.8 |  |  | $ | — |  |  | $ | 5,021.8 |  |
| Canada | 231.1 |  |  | 88.4 |  |  | — |  |  | 319.5 |  |
| International |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 3,577.1 |  |  | $ | 1,764.2 |  |  | $ | — |  |  | $ | 5,341.3 |  |

[0001628280-25-004859:notes:146]
|  | For the Year Ended December 31, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 3,001.3 |  |  | $ | 1,415.6 |  |  | $ | — |  |  | $ | 4,416.9 |  |
| Canada | 221.6 |  |  | 95.8 |  |  | — |  |  | 317.4 |  |
| International | — |  |  | — |  |  | 247.6 |  |  | 247.6 |  |
| Total | $ | 3,222.9 |  |  | $ | 1,511.4 |  |  | $ | 247.6 |  |  | $ | 4,981.9 |  |

[0001628280-25-004859:notes:147]
|  | For the Year Ended December 31, 2022 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,957.1 |  |  | $ | 1,223.4 |  |  | $ | — |  |  | $ | 4,180.5 |  |
| Canada | 241.2 |  |  | 62.4 |  |  | — |  |  | 303.6 |  |
| International | — |  |  | 0.6 |  |  | 233.7 |  |  | 234.3 |  |
| Total | $ | 3,198.3 |  |  | $ | 1,286.4 |  |  | $ | 233.7 |  |  | $ | 4,718.4 |  |

[0001628280-25-004859:notes:148]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Building Climate Solutions segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  Revenue from extended warranties is insignificant. See Note 5 for more information on product warranties.

[0001628280-25-004859:notes:149]
Home Comfort Solutions  - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the years ended December 31, 2024, 2023 and 2022, direct sales represented 74%, 75% and 70% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001628280-25-004859:notes:150]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers and also offers HVAC recycling and salvage services, as well as focusing on multi-family HVAC replacement for expired mechanical assets.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the years ended December 31, 2024, 2023 and 2022, equipment sales represented 80%, 86% and 82% of revenues, respectively, and the remainder of our revenue was generated from our service business.

[0001628280-25-004859:notes:151]
Corporate and Other - In Europe, we manufactured and marketed equipment for the global commercial refrigeration markets.  We also manufactured and sold unitary heating and cooling products and applied systems. A de minimis amount of segment revenue related to services for start-up and commissioning activities. In the fourth quarter of 2023, we successfully completed the divestiture of our European operations.

[0001628280-25-004859:notes:152]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to SG&A expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001628280-25-004859:notes:153]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001628280-25-004859:notes:154]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheets.

[0001628280-25-004859:notes:155]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.

[0001628280-25-004859:notes:156]
Net contract assets (liabilities) consisted of the following:

[0001628280-25-004859:notes:157]
|  | December 31, 2024 |  | December 31, 2023 |  |  |  |  |
| Contract assets | $ | 1.2 |  |  | $ | 2.2 |  |  |  |  |  |
| Contract liabilities - current | (5.0) |  |  | (4.7) |  |  |  |  |  |
| Contract liabilities - noncurrent | (8.4) |  |  | (7.5) |  |  |  |  |  |
| Total | $ | (12.2) |  |  | $ | (10.0) |  |  |  |  |  |

[0001628280-25-004859:notes:158]
For the years ended December 31, 2024,  2023, and 2022 we recognized revenue of $7.4 million, $7.7 million and $10.1 million related to our contract liabilities at January 1, 2024, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2024, 2023 and 2022.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-25-004859:notes:159]
The components of inventories are as follows (in millions):

[0001628280-25-004859:notes:160]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Finished goods | $ | 422.6 |  |  | $ | 509.4 |  |
| Work in process | 11.0 |  |  | 9.6 |  |
| Raw materials and parts | 410.7 |  |  | 314.2 |  |
| Total | 844.3 |  |  | 833.2 |  |
| Excess of current cost over last-in, first-out cost | (139.5) |  |  | (134.1) |  |
| Total inventories, net | $ | 704.8 |  |  | $ | 699.1 |  |

[0001628280-25-004859:notes:161]
The Company recorded a pre-tax gain of $0.2 million in 2024 from LIFO liquidations. There were no pre-tax gains in 2023 or 2022 from LIFO inventory liquidations. Obsolete and slow-moving inventories were $55.8 million and $40.2 million as of December 31, 2024 and December 31, 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-25-004859:notes:162]
Goodwill

[0001628280-25-004859:notes:163]
The changes in the carrying amount of goodwill in 2024 and 2023, in total and by segment, are summarized in the table below (in millions):

[0001628280-25-004859:notes:164]
| Segment: | Balance at December 31, 2022 (1) |  |  |  | Goodwill reallocation (2) | Goodwill related to divested entities (3) | Goodwill from business acquisition (4) |  |  | Balance at December 31, 2023 |  | Goodwill Adjustment (5) |  |  |  |  |  | Balance at December 31, 2024 |
| Home Comfort Solutions | $ | 26.1 |  |  |  |  | $ | — |  | $ | — |  | $ | — |  |  |  | $ | 26.1 |  |  | $ | — |  |  |  |  |  |  | $ | 26.1 |  |
| Building Climate Solutions | 61.1 |  |  |  |  | 94.5 |  | — |  | 40.4 |  |  |  | 196.0 |  |  | (2.1) |  |  |  |  |  |  | 193.9 |  |
| Historical Refrigeration segment | 99.1 |  |  |  |  | (99.1) |  | — |  | — |  |  |  | — |  |  | — |  |  |  |  |  |  | — |  |
| Corporate and Other | — |  |  |  |  | 4.6 |  | (4.6) |  | — |  |  |  | — |  |  |  |  |  |  |  |  | — |  |
|  | $ | 186.3 |  |  |  |  | $ | — |  | $ | (4.6) |  | $ | 40.4 |  |  |  | $ | 222.1 |  |  | $ | (2.1) |  |  |  |  |  |  | $ | 220.0 |  |

[0001628280-25-004859:notes:165]
(1) The goodwill balances in the table above are presented net of accumulated impairment charges of $32.7 million, all of which relate to impairments in periods prior to 2022.

[0001628280-25-004859:notes:166]
(2) As discussed in Note 3, we recast our segment presentation to present our Heatcraft Worldwide Refrigeration business as a component of our Building Climate Solutions segment and our European portfolio as a component of Corporate and Other. Since there is no longer a Refrigeration segment, we allocated goodwill to each segment based upon the relative fair value of the business.

[0001628280-25-004859:notes:167]
(3) There was $4.6 million of goodwill related to our European portfolio. As part of the loss on assets held for sale that was recorded in the third quarter of 2023, we recorded an impairment of $2.3 million for a portion of the goodwill transferred. The remaining goodwill was included in the balance of disposed net assets.

[0001628280-25-004859:notes:168]
(4) On October 25, 2023, we announced the acquisition of AES.  In connection with this acquisition, $40.4 million of goodwill was recorded and included in the Building Climate Solutions reporting unit. AES is included in the Building Climate Solutions segment. See Note 17 for additional information on the AES acquisition.

[0001628280-25-004859:notes:169]
(5)  As discussed in Note 17, in the first and fourth quarters of 2024 we made adjustments to our purchase price allocation of AES that resulted in a $2.1 million reduction of goodwill. 
A qualitative review of impairment indicators was performed in 2024 for the Home Comfort Solutions and Building Climate Solutions segments.  No impairment charges were recorded in 2024, 2023 or 2022, except to the extent of respective goodwill impaired in connection with the disposition of our European operations.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-25-004859:notes:170]
No impairment charges were recorded in 2024 or 2023, except to the extent of respective property, plant and equipment  impaired in connection with the disposition of our European operations.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-25-004859:notes:171]
Accrued Expenses

[0001628280-25-004859:notes:172]
The significant components of Accrued expenses are presented below (in millions):

[0001628280-25-004859:notes:173]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Accrued rebates and promotions | $ | 128.2 |  |  | $ | 121.5 |  |
| Accrued compensation and benefits | 130.0 |  |  | 111.8 |  |
| Accrued warranties | 49.1 |  |  | 45.4 |  |
| Accrued sales, use, property and VAT taxes | 18.0 |  |  | 27.1 |  |
| Accrued freight | 12.9 |  |  | 19.6 |  |
| Accrued asbestos reserves | 15.8 |  |  | 17.9 |  |
| Accrued interest | 11.2 |  |  | 11.3 |  |
| Accrued pension | 6.4 |  |  | 11.2 |  |
| Derivative contracts | 5.7 |  |  | 5.7 |  |
| Deferred income | 5.0 |  |  | 4.7 |  |
| Self insurance reserves | 4.6 |  |  | 3.8 |  |
| Other | 48.5 |  |  | 36.1 |  |
| Total Accrued expenses | $ | 435.4 |  |  | $ | 416.1 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-25-004859:notes:174]
Objectives and Strategies for Using Derivative Instruments

[0001628280-25-004859:notes:175]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001628280-25-004859:notes:176]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001628280-25-004859:notes:177]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001628280-25-004859:notes:178]
Cash Flow Hedges

[0001628280-25-004859:notes:179]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through June 2026 and December 2025, respectively. We currently have cash flow hedge contracts with a notional amount of 105.9 million pounds of aluminum and copper. Unrealized gains or losses from our cash flow hedges are included in AOCL and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.

[0001628280-25-004859:notes:180]
We recorded the following amounts related to our cash flow hedges in AOCL (in millions):

[0001628280-25-004859:notes:181]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Unrealized losses, net on unsettled contracts | $ | 2.0 |  |  | $ | 2.6 |  |
| Income tax benefit | (0.6) |  |  | (0.6) |  |
| Unrealized losses included in AOCL, net of tax (1) | $ | 1.4 |  |  | $ | 2.0 |  |

[0001628280-25-004859:notes:182]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $1.2 million of derivative losses into earnings within the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-25-004859:notes:183]
Expenses included in our Consolidated Statements of Operations

[0001628280-25-004859:notes:184]
Below is information about expenses included in Selling, general and administrative expenses in our Consolidated Statements of Operations (in millions):

[0001628280-25-004859:notes:185]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Research and development | $ | 93.6 |  |  | $ | 94.0 |  |  | $ | 80.3 |  |
| Advertising, promotions and marketing | 49.7 |  |  | 39.5 |  |  | 32.4 |  |
| Cooperative advertising expenditures | 22.5 |  |  | 28.7 |  |  | 28.1 |  |


## us-gaap:ScheduleOfOtherOperatingCostAndExpenseByComponentTextBlock

[0001628280-25-004859:notes:186]
Losses (gains) and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001628280-25-004859:notes:187]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Realized losses on settled future contracts | $ | — |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Foreign currency exchange losses (gains) | 7.7 |  |  | (4.3) |  |  | (1.3) |  |
| Gain on disposal of fixed assets | (2.1) |  |  | (0.5) |  |  | (1.0) |  |
| Other operating (income) loss | 0.5 |  |  | (1.6) |  |  | (1.0) |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | — |  |  | (0.1) |  |  | 0.4 |  |
| Environmental liabilities and special litigation charges | 6.8 |  |  | 15.6 |  |  | 7.5 |  |
| Charges incurred related to COVID-19 pandemic | — |  |  | — |  |  | 0.8 |  |
| Other items, net | — |  |  | (0.7) |  |  | (0.6) |  |
| Losses and other expenses, net (pre-tax) | $ | 12.9 |  |  | $ | 8.5 |  |  | $ | 4.9 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001628280-25-004859:notes:188]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001628280-25-004859:notes:189]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Interest expense, net of capitalized interest | $ | 44.1 |  |  | $ | 56.0 |  |  | $ | 39.8 |  |
| Less: Interest income | 5.4 |  |  | 4.3 |  |  | 1.1 |  |
| Interest expense, net | $ | 38.7 |  |  | $ | 51.7 |  |  | $ | 38.7 |  |

[0001628280-25-004859:notes:190]
Our provision for income taxes consisted of the following (in millions):

[0001628280-25-004859:notes:191]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Current: |  |  |  |  |  |
| Federal | $ | 158.0 |  |  | $ | 131.8 |  |  | $ | 104.0 |  |
| State | 33.5 |  |  | 26.6 |  |  | 21.6 |  |
| Foreign | 20.0 |  |  | 14.5 |  |  | 7.8 |  |
| Total current | 211.5 |  |  | 172.9 |  |  | 133.4 |  |
| Deferred: |  |  |  |  |  |
| Federal | (19.6) |  |  | (22.2) |  |  | (13.9) |  |
| State | (4.0) |  |  | (4.9) |  |  | (3.1) |  |
| Foreign | (1.0) |  |  | 1.6 |  |  | 2.3 |  |
| Total deferred | (24.6) |  |  | (25.5) |  |  | (14.7) |  |
| Total provision for income taxes | $ | 186.9 |  |  | $ | 147.4 |  |  | $ | 118.7 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001628280-25-004859:notes:192]
Losses (Gains) and Other Expenses, net


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-25-004859:notes:193]
10. Employee Benefit Plans: 
Many of our defined benefit pension and profit sharing plans have been frozen and replaced with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen. We also have several active defined benefit plans that provide benefits based on years of service. Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.

[0001628280-25-004859:notes:194]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.

[0001628280-25-004859:notes:195]
Defined Contribution Plans

[0001628280-25-004859:notes:196]
We recorded the following contributions to our defined contribution plans (in millions):

[0001628280-25-004859:notes:197]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Contributions to defined contribution plans | $ | 26.9 |  |  | $ | 22.5 |  |  | $ | 22.7 |  |

[0001628280-25-004859:notes:198]
Pension and Post-retirement Benefit Plans

[0001628280-25-004859:notes:199]
Benefit Obligations, Fair Value of Plan Assets, Funded Status, and Balance Sheet Position

[0001628280-25-004859:notes:200]
The following tables set forth amounts recognized in our financial statements and the plans’ funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001628280-25-004859:notes:201]
|  | Pension Benefits |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Accumulated benefit obligation | $ | 161.4 |  |  | $ | 176.9 |  |  |  |  |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 179.1 |  |  | $ | 174.3 |  |  |  |  |  |
| Service cost | 1.5 |  |  | 2.1 |  |  |  |  |  |
| Interest cost | 8.5 |  |  | 8.9 |  |  |  |  |  |
| Actuarial loss (gain) | (9.9) |  |  | 4.5 |  |  |  |  |  |
| Effect of exchange rates | (0.9) |  |  | 1.1 |  |  |  |  |  |
| Adjustment upon sale of businesses | (1.2) |  |  | (4.8) |  |  |  |  |  |
| Settlements | (9.5) |  |  | (0.5) |  |  |  |  |  |
| Benefits paid | (5.5) |  |  | (6.5) |  |  |  |  |  |
| Benefit obligation at end of year | $ | 162.1 |  |  | $ | 179.1 |  |  |  |  |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 156.5 |  |  | $ | 131.1 |  |  |  |  |  |
| Actual return on plan assets | (4.9) |  |  | 16.4 |  |  |  |  |  |
| Employer contributions | 9.3 |  |  | 15.0 |  |  |  |  |  |
| Effect of exchange rates | (0.9) |  |  | 1.0 |  |  |  |  |  |
| Plan settlements | (9.5) |  |  | (0.5) |  |  |  |  |  |
| Benefits paid | (5.5) |  |  | (6.5) |  |  |  |  |  |
| Fair value of plan assets at end of year | 145.0 |  |  | 156.5 |  |  |  |  |  |
| Funded status / net amount recognized | $ | (17.1) |  |  | $ | (22.6) |  |  |  |  |  |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Non-current assets | $ | 8.2 |  |  | $ | 11.1 |  |  |  |  |  |
| Current liability | (6.4) |  |  | (11.2) |  |  |  |  |  |
| Non-current liability | (18.9) |  |  | (22.5) |  |  |  |  |  |
| Net amount recognized | $ | (17.1) |  |  | $ | (22.6) |  |  |  |  |  |

[0001628280-25-004859:notes:202]
Plans with Benefit Obligations in Excess of Plan Assets

[0001628280-25-004859:notes:203]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 25.3 |  |  | $ | 38.9 |  |
| Accumulated benefit obligation | 24.6 |  |  | 36.9 |  |
| Fair value of plan assets | — |  |  | — |  |

[0001628280-25-004859:notes:204]
Net Periodic Benefit Cost

[0001628280-25-004859:notes:205]
Our U.S.-based pension plans comprised approximately 88% of the projected benefit obligation and 85% of plan assets as of December 31, 2024.

[0001628280-25-004859:notes:206]
|  | Pension Benefits |  |  |
|  | 2024 |  | 2023 |  | 2022 |  |  |  |  |  |  |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 1.5 |  |  | $ | 2.1 |  |  | $ | 3.8 |  |  |  |  |  |  |  |
| Interest cost | 8.5 |  |  | 8.9 |  |  | 6.2 |  |  |  |  |  |  |  |
| Expected return on plan assets | (7.6) |  |  | (9.4) |  |  | (9.1) |  |  |  |  |  |  |  |
| Amortization of prior service costs | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  |  |  |  |  |  |
| Recognized actuarial loss | 1.1 |  |  | 1.1 |  |  | 5.3 |  |  |  |  |  |  |  |
| Settlements | 0.4 |  |  | 0.8 |  |  | (0.2) |  |  |  |  |  |  |  |
| Other | — |  |  | (0.4) |  |  | (0.1) |  |  |  |  |  |  |  |
| Net periodic benefit cost | $ | 4.0 |  |  | $ | 3.2 |  |  | $ | 6.0 |  |  |  |  |  |  |  |

[0001628280-25-004859:notes:207]
Amounts recognized in AOCL and Other Comprehensive Income (Loss)

[0001628280-25-004859:notes:208]
The following table sets forth amounts recognized in AOCL and Other comprehensive income (loss) in our financial statements for 2024 and 2023 (in millions):

[0001628280-25-004859:notes:209]
|  | Pension Benefits |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Amounts recognized in AOCL: |  |  |  |  |  |  |  |
| Prior service costs | $ | (0.2) |  |  | $ | (0.3) |  |  |  |  |  |
| Pension adjustments upon sale of businesses | — |  |  | (1.8) |  |  |  |  |  |
| Actuarial loss | (54.7) |  |  | (52.6) |  |  |  |  |  |
| Subtotal | (54.9) |  |  | (54.7) |  |  |  |  |  |
| Deferred taxes | 13.5 |  |  | 14.7 |  |  |  |  |  |
| Net amount recognized | $ | (41.4) |  |  | $ | (40.0) |  |  |  |  |  |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Current year actuarial gain | 2.5 |  |  | (1.8) |  |  |  |  |  |
| Effect of exchange rates | (0.5) |  |  | 0.4 |  |  |  |  |  |
| Amortization of prior service costs | (0.1) |  |  | (0.1) |  |  |  |  |  |
| Amortization of actuarial loss, including settlements and other | (1.5) |  |  | (1.5) |  |  |  |  |  |
| Total recognized in other comprehensive income (loss) | $ | 0.5 |  |  | $ | (3.0) |  |  |  |  |  |
| Total recognized in net periodic benefit cost and other comprehensive income | $ | 4.5 |  |  | $ | 0.2 |  |  |  |  |  |

[0001628280-25-004859:notes:210]
The estimated prior service costs and actuarial losses for pension benefits that will be amortized from AOCL in 2025 are $0.1 million and $1.4 million, respectively.

[0001628280-25-004859:notes:211]
Assumptions

[0001628280-25-004859:notes:212]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2024 and 2023:

[0001628280-25-004859:notes:213]
|  |  | Pension Benefits |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |
| Discount rate |  | 5.68 | % |  | 5.23 | % |  |  |  |  |
| Rate of compensation increase |  | 3.95 | % |  | 4.02 | % |  |  |  |  |

[0001628280-25-004859:notes:214]
|  | Pension Benefits |  |  |
|  | 2024 |  | 2023 |  | 2022 |  |  |  |  |  |  |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate - service cost | 5.23 | % |  | 5.39 | % |  | 2.53 | % |  |  |  |  |  |  |
| Discount rate - interest cost | 5.15 | % |  | 5.38 | % |  | 2.48 | % |  |  |  |  |  |  |
| Expected long-term return on plan assets | 4.50 | % |  | 6.50 | % |  | 6.50 | % |  |  |  |  |  |  |
| Rate of compensation increase | 4.02 | % |  | 4.02 | % |  | 4.13 | % |  |  |  |  |  |  |

[0001628280-25-004859:notes:215]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the non-U.S.-based plans in 2024 and 2023:

[0001628280-25-004859:notes:216]
|  | Pension Benefits |
|  | 2024 |  | 2023 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 5.16 | % |  | 4.30 | % |
| Rate of compensation increase | 3.75 | % |  | 3.07 | % |

[0001628280-25-004859:notes:217]
|  | Pension Benefits |
|  | 2024 |  | 2023 |  | 2022 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | — | % |  | 3.75 | % |  | 0.86 | % |
| Discount rate - interest cost | 4.62 | % |  | 4.79 | % |  | 2.07 | % |
| Expected long-term return on plan assets | 4.53 | % |  | 4.94 | % |  | 2.75 | % |
| Rate of compensation increase | 3.07 | % |  | 3.11 | % |  | 3.14 | % |

[0001628280-25-004859:notes:218]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 4.50% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001628280-25-004859:notes:219]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis to select the discount rate for each plan. The analysis was completed separately for each U.S. pension and other post-employment benefits (“OPEB”) plan. A similar process was followed for the non-U.S.-based plans with sufficient corporate bond information. In other countries, the discount rate was selected based on the approximate duration of plan obligations.

[0001628280-25-004859:notes:220]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001628280-25-004859:notes:221]
|  | 2024 |  | 2023 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 7.50 | % |  | 6.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 4.50 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2037 |  | 2030 |

[0001628280-25-004859:notes:222]
Expected future benefit payments are shown in the table below (in millions):

[0001628280-25-004859:notes:223]
|  | For the Years Ended December 31, |
|  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030-2034 |
| Pension benefits | $ | 12.3 |  |  | $ | 8.0 |  |  | $ | 16.3 |  |  | $ | 10.9 |  |  | $ | 12.8 |  |  | $ | 51.4 |  |

[0001628280-25-004859:notes:224]
Composition of Pension Plan Assets

[0001628280-25-004859:notes:225]
In the fourth quarter of 2023, based on the strong funded status of our U.S. pension plan, we opted to make a $12.2 million voluntary contribution to the plan to increase the funded status and fully fund the plan.  With the U.S. pension plan fully funded, the asset allocation was changed from a blend of 50% equities and 50% fixed income to 100% fixed income in order to align changes in asset values with changes in liabilities, therefore reducing funded status volatility, which effectively placed the plan in hibernation status.  As a result, we reduced the expected long-term rate of return for our U.S. pension plan assets to 4.5%.  Our U.S. pension plan represents 85%, our Canadian pension plan 7%, and our United Kingdom (“U.K.”) pension plan 8% of the total fair value of our plan assets as of December 31, 2024.

[0001628280-25-004859:notes:226]
Our U.S. pension plans’ weighted-average asset allocations as of December 31, 2024 and 2023, by asset category, were as follows:

[0001628280-25-004859:notes:227]
|  | Plan Assets as of December 31, |
| Asset Category: | 2024 |  | 2023 |
| U.S. equity | — | % |  | — | % |
| International equity | — | % |  | — | % |
| Fixed income | 100.0 | % |  | 100.0 | % |
| Money market/cash | — | % |  | — | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001628280-25-004859:notes:228]
Our U.S. pension plans’ assets were invested according to the following targets:

[0001628280-25-004859:notes:229]
| Asset Category: | Target |
| U.S. equity | — | % |
| International equity | — | % |
| Fixed income | 100.0 | % |

[0001628280-25-004859:notes:230]
Similarly, in 2023, based on the strong funded status of our Canadian pension plans, the asset allocation was adjusted as well, with the Salaried plan moving from 75% fixed income and 25% equity to 100% fixed income, and the Hourly plan moving from 75% fixed income and 25% equity to 90% fixed income and 10% equity.  As with the U.S. pension plan, this change in asset allocation will greatly reduce funded status volatility.

[0001628280-25-004859:notes:231]
Our U.K. pension plan was invested in fixed income securities, including corporate and government bonds.

[0001628280-25-004859:notes:232]
The fair values of our pension plan assets, by asset category, were as follows (in millions):

[0001628280-25-004859:notes:233]
|  | Fair Value Measurements as of December 31, 2024 |  |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |  |
| Asset Category: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |  |  |  |
| Fixed income (1) | — |  |  | 122.7 |  |  | — |  |  | 122.7 |  |  |
| Balanced pension trust: (2) |  |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |  |
| Fixed income | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  |
| Pension fund: |  |  |  |  |  |  |  |  |
| Fixed income (3) | — |  |  | 12.5 |  |  | — |  |  | 12.5 |  |  |
| Total | $ | 0.1 |  |  | $ | 144.9 |  |  | $ | — |  |  | $ | 145.0 |  |  |

[0001628280-25-004859:notes:234]
|  | Fair Value Measurements as of December 31, 2023 |  |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |  |
| Asset Category: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |  |  |  |
| Fixed income (1) | — |  |  | 130.8 |  |  | — |  |  | 130.8 |  |  |
| Balanced pension trust: (2) |  |  |  |  |  |  |  |  |
| International equity | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |  |
| Fixed income | — |  |  | 11.1 |  |  | — |  |  | 11.1 |  |  |
| Pension fund: |  |  |  |  |  |  |  |  |
| Fixed income (3) | — |  |  | 14.0 |  |  | — |  |  | 14.0 |  |  |
| Total | $ | 0.1 |  |  | $ | 156.4 |  |  | $ | — |  |  | $ | 156.5 |  |  |

[0001628280-25-004859:notes:235]
| (1) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (2) | The investment objectives of the plan are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The plan also holds a portion of its assets in international equities, a portion of which may be invested in U.S. securities. |
| (3) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer with a derivatives overlay and investment grade corporate bonds denominated in sterling. The plan also holds a portion of its assets in international instruments, a portion of which may be invested in U.S. securities. |

[0001628280-25-004859:notes:236]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001628280-25-004859:notes:237]
|  | As of December 31, 2024 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |
| Fixed income (1) | 122.7 |  |  | Daily |  | 5 days |
| Balanced pension trust: (2) |  |  |  |  |  |
| International equity | 4.7 |  |  | Daily |  | 3-5 days |
| Fixed income | 5.0 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (3) | 12.5 |  |  | Daily |  | 1-3 days |
| Total | $ | 144.9 |  |  |  |  |  |

[0001628280-25-004859:notes:238]
|  | As of December 31, 2023 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |
| Fixed income (1) | 130.8 |  |  | Daily |  | 5 days |
| Balanced pension trust: (2) |  |  |  |  |  |
| International equity | 0.5 |  |  | Daily |  | 3-5 days |
| Fixed income | 11.1 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (3) | 14.0 |  |  | Daily |  | 1-3 days |
| Total | $ | 156.4 |  |  |  |  |  |

[0001628280-25-004859:notes:239]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund’s NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the number of units owned.  See Note 16 for information about our fair value hierarchies and valuation techniques.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001628280-25-004859:notes:240]
11. Joint Ventures and Other Investments:

[0001628280-25-004859:notes:241]
We participate in three joint ventures. Two are located in the U.S. and the third in Mexico. These three joint ventures are engaged in the manufacturing and distribution of compressors, condensing units, unit and module coolers, heat pumps, ductless heat pump mini-split and Variable Refrigerant Flow system. We exert significant influence over these affiliates based upon our respective 25%, 49.9% and 50% ownership, but do not control them due to venture partner participation.  Accordingly, two of these joint ventures have been accounted for under the equity method and the other as a held-to-maturity investment, and their financial position and results of operations are not consolidated.

[0001628280-25-004859:notes:242]
The combined balance of equity method and other investments included in Other assets, net totaled (in millions):

[0001628280-25-004859:notes:243]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Equity method investments | $ | 56.4 |  |  | $ | 58.4 |  |
| Held-to-maturity investment | 7.9 |  |  | — |  |
| Total investments | $ | 64.3 |  |  | $ | 58.4 |  |

[0001628280-25-004859:notes:244]
We purchase compressors from one of our U.S. joint ventures for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001628280-25-004859:notes:245]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Purchases of compressors from joint venture | $ | 173.3 |  |  | $ | 148.3 |  |  | $ | 156.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-004859:notes:246]
12. Income Taxes:

[0001628280-25-004859:notes:247]
Income before income taxes was comprised of the following (in millions):

[0001628280-25-004859:notes:248]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Domestic | $ | 620.2 |  |  | $ | 471.4 |  |  | $ | 340.2 |  |
| Foreign | 373.6 |  |  | 266.1 |  |  | 275.6 |  |
| Total | $ | 993.8 |  |  | $ | 737.5 |  |  | $ | 615.8 |  |

[0001628280-25-004859:notes:249]
The difference between the income tax provision computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001628280-25-004859:notes:250]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Provision at the U.S. statutory rate of 21% | $ | 208.7 |  |  | $ | 154.9 |  |  | $ | 129.3 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 23.0 |  |  | 16.4 |  |  | 14.6 |  |
| Tax credits, net of unrecognized tax benefits | (5.3) |  |  | (3.4) |  |  | (8.0) |  |
| Change in unrecognized tax benefits | 0.5 |  |  | 0.4 |  |  | 0.2 |  |
| Change in valuation allowance | — |  |  | 0.1 |  |  | — |  |
| Foreign taxes at rates other than U.S. statutory rate | (61.1) |  |  | (40.3) |  |  | (47.4) |  |
| Deemed inclusions | 7.6 |  |  | 6.1 |  |  | 10.0 |  |
| Global intangible low-taxed income | 20.8 |  |  | 17.5 |  |  | 23.9 |  |
| Change in rates from the Tax Act & other law changes | — |  |  | 0.2 |  |  | 0.1 |  |
| Excess tax benefits from stock-based compensation | (8.0) |  |  | (5.2) |  |  | (0.6) |  |
| Miscellaneous other | 0.7 |  |  | 0.7 |  |  | (3.4) |  |
| Total provision for income taxes | $ | 186.9 |  |  | $ | 147.4 |  |  | $ | 118.7 |  |

[0001628280-25-004859:notes:251]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001628280-25-004859:notes:252]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001628280-25-004859:notes:253]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 39.4 |  |  | $ | 35.9 |  |
| Loss carryforwards (foreign, U.S. and state) | 2.7 |  |  | 10.9 |  |
| Post-retirement and pension benefits | 4.5 |  |  | 4.7 |  |
| Inventory reserves | 16.2 |  |  | 12.3 |  |
| Receivables allowance | 7.4 |  |  | 6.6 |  |
| Compensation liabilities | 6.6 |  |  | 6.2 |  |
| Legal reserves | 14.2 |  |  | 14.2 |  |
| Tax credits, net of federal effect | 12.3 |  |  | 12.1 |  |
| Research and development capitalization | 55.8 |  |  | 39.7 |  |
| Other | 11.9 |  |  | 9.0 |  |
| Total deferred tax assets | 171.0 |  |  | 151.6 |  |
| Valuation allowance | (10.6) |  |  | (17.8) |  |
| Total deferred tax assets, net of valuation allowance | 160.4 |  |  | 133.8 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (64.4) |  |  | (61.8) |  |
| Intangibles | (17.4) |  |  | (15.9) |  |
| Insurance liabilities | (2.0) |  |  | (2.4) |  |
| Other | (1.5) |  |  | (1.9) |  |
| Total deferred tax liabilities | (85.3) |  |  | (82.0) |  |
| Net deferred tax assets | $ | 75.1 |  |  | $ | 51.8 |  |

[0001628280-25-004859:notes:254]
As of December 31, 2024 and 2023, we had $2.7 million and $10.8 million in tax-effected foreign net operating loss carryforwards, respectively. The deferred tax asset valuation allowance relates primarily to loss carryforwards. The remainder of the valuation allowance relates to state tax credits.

[0001628280-25-004859:notes:255]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of  December 31, 2024.

[0001628280-25-004859:notes:256]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries’ earnings. An actual repatriation in the future from our non-U.S. subsidiaries could still be subject to foreign withholding taxes and U.S. state taxes, but we expect any amounts to be immaterial.

[0001628280-25-004859:notes:257]
We and our subsidiaries file income tax returns with the U.S. federal government, various U.S. states, and various foreign jurisdictions throughout the world. We regularly engage in discussions and negotiations with tax authorities regarding tax matters, and we continue to defend any and all such claims presented. Our U.S. federal and state tax returns remain open to examination for 2017 through 2023. We are currently under a limited scope audit by the Internal Revenue Service for our 2021 and 2022 tax years. There are also ongoing U.S. state and local audits and other foreign audits covering fiscal years 2017 through 2023. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2016. We have no material uncertain tax provisions recorded as of December 31, 2024. We do not expect the results from any ongoing income tax audit to have a material impact on our consolidated financial condition, results of operations, or cash flows.


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-004859:notes:258]
13. Lines of Credit and Financing Arrangements:

[0001628280-25-004859:notes:259]
The following tables summarize our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001628280-25-004859:notes:260]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Commercial paper: | $ | — |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 14.9 |  |  | $ | 12.1 |  |
| Senior unsecured notes | 300.0 |  |  | — |  |
| Debt issuance costs | (0.4) |  |  | — |  |
| Total current maturities of long-term debt | $ | 314.5 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 39.5 |  |  | 32.7 |  |
| Credit agreement | — |  |  | 20.0 |  |
| Senior unsecured notes | 800.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (6.4) |  |  | (9.6) |  |
| Total long-term debt | $ | 833.1 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,147.6 |  |  | $ | 1,305.2 |  |

[0001628280-25-004859:notes:261]
As of December 31, 2024, the aggregate amounts of required principal payments on total debt excluding finance lease obligations (see Note 5) were as follows (in millions):

[0001628280-25-004859:notes:262]
| 2025 | $ | 300.0 |  |
| 2026 | — |  |
| 2027 | 300.0 |  |
| 2028 | 500.0 |  |
| Thereafter | — |  |

[0001628280-25-004859:notes:263]
Commercial Paper Program

[0001628280-25-004859:notes:264]
On October 25, 2023, we established a commercial paper program (the “Program”) pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes will have maturities of up to 397 days from the date of issue. The CP Notes will rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds of the issuances of the CP Notes are expected to be used for general corporate purposes. We plan to use our revolving credit facility as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were no CP Notes outstanding under the Program as of December 31, 2024.

[0001628280-25-004859:notes:265]
Below is a summary of the weighted average interest rate for CP notes as of December 31, 2024 and 2023:

[0001628280-25-004859:notes:266]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Weighted average borrowing rate | — | % |  | 5.66 | % |

[0001628280-25-004859:notes:267]
Long-Term Debt

[0001628280-25-004859:notes:268]
Credit Agreement

[0001628280-25-004859:notes:269]
In August 2023, we entered into the Second Amendment (the “Second Amendment”) to our existing Credit Agreement, dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. Under the Second Amendment, the revolving commitments were increased by $350 million and certain representations required to be made as conditions precedent to borrowing were revised to provide us greater flexibility to enter into additional future financings.

[0001628280-25-004859:notes:270]
The Credit Agreement consists of a $1.1 billion unsecured revolving credit facility that matures in July 2026. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of December 31, 2024. Subject to covenant limitations, $1,098.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Commercial Paper Program. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-25-004859:notes:271]
Below is a summary of the weighted average interest rate as of December 31, 2024 and 2023:

[0001628280-25-004859:notes:272]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Weighted average borrowing rate | — | % |  | 6.67 | % |

[0001628280-25-004859:notes:273]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and its subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of its assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-25-004859:notes:274]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001628280-25-004859:notes:275]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-25-004859:notes:276]
•We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-25-004859:notes:277]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-25-004859:notes:278]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001628280-25-004859:notes:279]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee payment by us of any indebtedness under our Credit Agreement.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001628280-25-004859:notes:280]
We are currently in compliance with all covenant requirements.

[0001628280-25-004859:notes:281]
Senior Unsecured Notes

[0001628280-25-004859:notes:282]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum (the 2025 Notes, the 2027 Notes, and the 2028 Notes, collectively the “Notes”).

[0001628280-25-004859:notes:283]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  We are currently in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-25-004859:notes:284]
14. Comprehensive Income:

[0001628280-25-004859:notes:285]
The following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001628280-25-004859:notes:286]
|  |  | For the Years Ended December 31, |  |  |
| AOCL Component |  | 2024 |  | 2023 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Derivative contracts |  | $ | (0.9) |  |  | $ | (0.4) |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax benefit (expense) |  | (0.2) |  |  | 0.1 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.7) |  |  | $ | (0.3) |  |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and post-retirement benefits costs |  | $ | (1.4) |  |  | $ | (5.5) |  |  | Cost of goods sold; Selling, general, and administrative expenses and other (income) expense, net |
| Pension settlements |  | (0.4) |  |  | (0.8) |  |  | Pension settlements |
| Pension adjustments upon sale of businesses |  | — |  |  | 1.8 |  |  | Gain on sale of businesses |
| Income tax benefit (expense) |  | (0.4) |  |  | 1.6 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.4) |  |  | $ | (2.9) |  |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Foreign currency adjustments upon sale of businesses |  | $ | — |  |  | $ | (15.8) |  |  | Gain on sale of businesses |
| Income tax expense |  | — |  |  | — |  |  | Provision for income taxes |
| Net of tax |  | $ | — |  |  | $ | (15.8) |  |  |  |
| Total reclassifications from AOCL |  | $ | (2.1) |  |  | $ | (19.0) |  |  |  |

[0001628280-25-004859:notes:287]
The following tables provide information on changes in AOCL, by component (net of tax), for the years ended December 31, 2024 and 2023 (in millions):

[0001628280-25-004859:notes:288]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2023 |  | $ | (2.0) |  |  | $ | 0.6 |  |  | $ | (44.2) |  |  | $ | (11.3) |  |  | $ | (56.9) |  |
| Other comprehensive loss before reclassifications |  | (0.2) |  |  | (0.2) |  |  | (2.9) |  |  | (35.6) |  |  | (38.9) |  |
| Amounts reclassified from AOCL |  | 0.7 |  |  | — |  |  | 1.4 |  |  | — |  |  | 2.1 |  |
| Net other comprehensive income (loss) |  | 0.5 |  |  | (0.2) |  |  | (1.5) |  |  | (35.6) |  |  | (36.8) |  |
| Balance as of December 31, 2024 |  | $ | (1.5) |  |  | $ | 0.4 |  |  | $ | (45.7) |  |  | $ | (46.9) |  |  | $ | (93.7) |  |

[0001628280-25-004859:notes:289]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2022 |  | $ | (4.9) |  |  | $ | (0.5) |  |  | $ | (46.2) |  |  | $ | (39.0) |  |  | $ | (90.6) |  |
| Other comprehensive income (loss) before reclassifications |  | 2.6 |  |  | 1.1 |  |  | (0.9) |  |  | 11.9 |  |  | 14.7 |  |
| Amounts reclassified from AOCL |  | 0.3 |  |  | — |  |  | 2.9 |  |  | 15.8 |  |  | 19.0 |  |
| Net other comprehensive income |  | 2.9 |  |  | 1.1 |  |  | 2.0 |  |  | 27.7 |  |  | 33.7 |  |
| Balance as of December 31, 2023 |  | $ | (2.0) |  |  | $ | 0.6 |  |  | $ | (44.2) |  |  | $ | (11.3) |  |  | $ | (56.9) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-25-004859:notes:290]
15. Stock-Based Compensation:

[0001628280-25-004859:notes:291]
Stock-based compensation expense was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001628280-25-004859:notes:292]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Compensation expense | $ | 28.5 |  |  | $ | 30.1 |  |  | $ | 21.8 |  |

[0001628280-25-004859:notes:293]
Incentive Plan

[0001628280-25-004859:notes:294]
Under the Lennox International Inc. 2019 Equity and Incentive Compensation Plan, we are authorized to issue awards for 1.7 million shares of common stock. The plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below. As of December 31, 2024, there were 1.6 million shares available for future issuance.

[0001628280-25-004859:notes:295]
Historically our annual equity awards were granted in December.  In 2023, we made the decision to move the annual grant for 2023 to February 2024.  Thus, there were no equity grants in 2023. We also made the decision to award the Board of Directors fully vested shares on an annual basis. As a result, approximately $1.3 million of compensation expense was recognized in 2024 for the 2024 director grant.

[0001628280-25-004859:notes:296]
Performance Share Units

[0001628280-25-004859:notes:297]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII’s performance over the three-year performance period.

[0001628280-25-004859:notes:298]
Performance share units are classified as equity awards. Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded. Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001628280-25-004859:notes:299]
The following table provides information on our performance share units:

[0001628280-25-004859:notes:300]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Compensation expense for performance share units (in millions) | $ | 14.9 |  |  | $ | 15.2 |  |  | $ | 6.9 |  |
| Weighted-average fair value of grants, per share | $ | 403.68 |  |  | $ | — |  |  | $ | 237.68 |  |
| Payout ratio for shares paid | 189 | % |  | 131 | % |  | 126 | % |

[0001628280-25-004859:notes:301]
A summary of the status of our undistributed performance share units as of December 31, 2024, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001628280-25-004859:notes:302]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2023 | 106.4 |  |  | $ | 261.91 |  |
| Granted | 23.7 |  |  | $ | 403.68 |  |
| Adjustment to shares paid based on payout ratio | 16.5 |  |  | $ | 314.27 |  |
| Distributed | (37.3) |  |  | $ | 265.96 |  |
| Forfeited | (10.2) |  |  | $ | 279.73 |  |
| Undistributed performance share units as of December 31, 2024 (1) | 99.1 |  |  | $ | 305.14 |  |

[0001628280-25-004859:notes:303]
(1) Undistributed performance share units include approximately 66.2 thousand units with a weighted-average grant date fair value of $300.60 per share that had not yet vested and 32.9 thousand units that have vested but were not yet distributed with a fair value of $10.3 million.

[0001628280-25-004859:notes:304]
As of December 31, 2024, we had $14.3 million of total unrecognized compensation cost related to non-vested performance share units that are expected to be recognized over a weighted-average period of 1.8 years. Our weighted-average estimated forfeiture rate for these performance share units was 33.0% as of December 31, 2024.

[0001628280-25-004859:notes:305]
The total fair value of performance share units distributed and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001628280-25-004859:notes:306]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Fair value of performance share units distributed | $ | 19.5 |  |  | $ | 13.5 |  |  | $ | 6.1 |  |
| Realized tax benefits from tax deductions | $ | 4.8 |  |  | $ | 3.3 |  |  | $ | 1.5 |  |

[0001628280-25-004859:notes:307]
Restricted Stock Units

[0001628280-25-004859:notes:308]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001628280-25-004859:notes:309]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001628280-25-004859:notes:310]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Compensation expense for restricted stock units | $ | 9.4 |  |  | $ | 10.8 |  |  | $ | 11.0 |  |
| Weighted-average fair value of grants, per share | $ | 404.91 |  |  | $ | — |  |  | $ | 240.87 |  |

[0001628280-25-004859:notes:311]
A summary of our non-vested restricted stock units as of December 31, 2024 and changes during the year then ended is presented below (in thousands, except per share data):

[0001628280-25-004859:notes:312]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2023 | 82.3 |  |  | $ | 268.39 |  |
| Granted | 28.0 |  |  | $ | 404.91 |  |
| Vested | (29.5) |  |  | $ | 304.41 |  |
| Forfeited | (9.9) |  |  | $ | 286.05 |  |
| Non-vested restricted stock units as of December 31, 2024 (1) | 70.9 |  |  | $ | 306.01 |  |

[0001628280-25-004859:notes:313]
(1) As of December 31, 2024, we had $9.0 million of total unrecognized compensation cost related to non-vested restricted stock units that are expected to be recognized over a weighted-average period of 2.15 years.  Our estimated forfeiture rate for restricted stock units was 32.0% as of December 31, 2024.

[0001628280-25-004859:notes:314]
The total fair value of restricted stock units vested and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001628280-25-004859:notes:315]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Fair value of restricted stock units vested | $ | 17.3 |  |  | $ | 15.0 |  |  | $ | 9.7 |  |
| Realized tax benefits from tax deductions | $ | 4.2 |  |  | $ | 3.7 |  |  | $ | 2.4 |  |

[0001628280-25-004859:notes:316]
Stock Appreciation Rights

[0001628280-25-004859:notes:317]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive compensation, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001628280-25-004859:notes:318]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001628280-25-004859:notes:319]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Compensation expense for stock appreciation rights | $ | 4.2 |  |  | $ | 4.1 |  |  | $ | 3.9 |  |
| Weighted-average fair value of grants, per share | $ | 136.37 |  |  | $ | — |  |  | $ | 64.54 |  |

[0001628280-25-004859:notes:320]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001628280-25-004859:notes:321]
The fair value of the stock appreciation rights granted in 2024 and 2022 were estimated on the date of grant using the following assumptions. In 2023 there were no stock appreciation rights granted:

[0001628280-25-004859:notes:322]
|  |  | 2024 |  | 2022 |
| Expected dividend yield |  | 1.23 | % |  | 2.01 | % |
| Risk-free interest rate |  | 4.05 | % |  | 3.88 | % |
| Expected volatility |  | 34.89 | % |  | 29.90 | % |
| Expected life (in years) |  | 4.18 |  | 4.18 |

[0001628280-25-004859:notes:323]
A summary of our stock appreciation rights as of December 31, 2024, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001628280-25-004859:notes:324]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2023 | 292.5 |  |  | $ | 266.57 |  |
| Granted | 47.2 |  |  | $ | 418.69 |  |
| Exercised | (123.3) |  |  | $ | 255.73 |  |
| Forfeited | (12.7) |  |  | $ | 295.44 |  |
| Outstanding stock appreciation rights as of December 31, 2024 | 203.7 |  |  | $ | 306.61 |  |
| Exercisable stock appreciation rights as of December 31, 2024 | 153.1 |  |  | $ | 287.75 |  |

[0001628280-25-004859:notes:325]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2024 (in millions, except per share data and years; shares in thousands):

[0001628280-25-004859:notes:326]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares (1) |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $214.63 to $257.08 |  | 33.4 |  |  | 1.73 |  | $ | 12.1 |  |  | 33.4 |  |  | 1.7 |  | $ | 12.1 |  |
| $278.00 to $328.65 |  | 57.8 |  |  | 3.58 |  | $ | 17.4 |  |  | 57.8 |  |  | 3.58 |  | $ | 17.4 |  |
| $259.56 to $418.69 |  | 112.5 |  |  | 5.81 |  | $ | 32.1 |  |  | 61.9 |  |  | 5.41 |  | $ | 19.6 |  |

[0001628280-25-004859:notes:327]
(1) Share amounts are rounded but the balance accurately reflects the actual amount of exercisable stock appreciation rights as of December 31, 2024.

[0001628280-25-004859:notes:328]
As of December 31, 2024, we had $5.4 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 1.9 years. Our estimated forfeiture rate for stock appreciation rights was 25.0% as of December 31, 2024.

[0001628280-25-004859:notes:329]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001628280-25-004859:notes:330]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Intrinsic value of stock appreciation rights exercised | $ | 25.4 |  |  | $ | 19.8 |  |  | $ | 3.5 |  |
| Realized tax benefits from tax deductions | $ | 6.2 |  |  | $ | 4.8 |  |  | $ | 0.9 |  |

[0001628280-25-004859:notes:331]
Employee Stock Purchase Plan

[0001628280-25-004859:notes:332]
On May 24, 2022, the Company commenced a new Employee Stock Purchase Plan to succeed the prior agreement from 2012. Under the 2022 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 1.0 million shares is authorized for purchase until issuance of all shares available under the plan, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 8,800 shares under the ESPP during the year ended December 31, 2024.  Approximately 0.9 million shares remain available for purchase under the ESPP as of December 31, 2024.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-004859:notes:333]
16. Fair Value Measurements:

[0001628280-25-004859:notes:334]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities. Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001628280-25-004859:notes:335]
Level 1 -      Quoted prices for identical instruments in active markets at the measurement date.

[0001628280-25-004859:notes:336]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001628280-25-004859:notes:337]
Level 3 -   Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001628280-25-004859:notes:338]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2024 and 2023, the measurement dates.

[0001628280-25-004859:notes:339]
The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2024 were the same as those used as of December 31, 2023.

[0001628280-25-004859:notes:340]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001628280-25-004859:notes:341]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001628280-25-004859:notes:342]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives. We also considered the counterparty’s creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 9 for more information related to our derivative instruments.  Refer to Note 10 for more information related to the fair value assumptions related to our pension assets and liabilities.

[0001628280-25-004859:notes:343]
Other Fair Value Disclosures

[0001628280-25-004859:notes:344]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Credit Agreement in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001628280-25-004859:notes:345]
We purchased the held-to-maturity investment in 2024. The carrying value of the investment approximates fair value.

[0001628280-25-004859:notes:346]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001628280-25-004859:notes:347]
|  | As of December 31, |
|  | 2024 |  | 2023 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 1,093.4 |  |  | $ | 1,079.3 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-25-004859:notes:348]
17. Prior Year Acquisition:

[0001628280-25-004859:notes:349]
In October 2023, we completed the acquisition of AES, a company dedicated to service and sustainability in the light commercial market.  Under the terms of the purchase agreement, a final working capital adjustment was completed in the first quarter of 2024.  This working capital adjustment resulted in a $1.8 million reduction in the purchase price.  Additionally, in the first and fourth quarters of 2024, we made certain purchase price adjustments.  The following table details the purchase price adjustments that were made during the first and fourth quarters of 2024 (in millions):


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001628280-25-004859:notes:350]
The following table details the purchase price adjustments that were made during the first and fourth quarters of 2024 (in millions):

[0001628280-25-004859:notes:351]
| (Amounts in millions) | December 31, 2023 |  | Adjustment |  | December 31, 2024 |
| Net tangible assets acquired | $ | 17.6 |  |  | $ | (1.7) |  |  | $ | 15.9 |  |
| Intangible assets acquired | 36.9 |  |  | 2.1 |  |  | 39.0 |  |
| Goodwill | 40.4 |  |  | (2.1) |  |  | 38.3 |  |
| Total investment | $ | 94.9 |  |  | $ | (1.7) |  |  | $ | 93.2 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-25-004859:notes:352]
Chris A. Kosel, Vice President, Corporate Controller and Chief Accounting Officer, entered into a prearranged stock trading plan on November 22, 2024. Mr. Kosel’s plan provides for the sale of approximately 856 shares of the Company's common stock between February 21, 2025 and April 31, 2025. The amount of shares to be sold includes shares subject to the vesting of restricted stock unit and performance share unit awards, and accordingly the actual amount may vary based on tax withholding and satisfaction of performance conditions.

[0001628280-25-004859:notes:353]
Daniel M. Sessa, Executive Vice President and Chief Human Resources Officer, entered into a prearranged stock trading plan on November 26, 2024. Mr. Sessa’s plan provides for the sale of approximately 2,811 shares of the Company's common stock between February 26, 2025 and December 31, 2025. The amount of shares to be sold includes shares subject to the vesting of restricted stock unit and performance share unit awards, and accordingly the actual amount may vary based on tax withholding and satisfaction of performance conditions.

[0001628280-25-004859:notes:354]
These trading plans were entered into during an open insider trading window and are intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act and the Company's policies regarding transactions in the Company's securities.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-25-004859:notes:355]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001628280-25-004859:notes:356]
For the Years Ended December 31, 2024, 2023 and 2022

[0001628280-25-004859:notes:357]
(In millions)

[0001628280-25-004859:notes:358]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other(1) |  | Balance at end of year |
| 2022 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 10.7 |  |  | $ | 6.9 |  |  | $ | (0.4) |  |  | $ | — |  |  | $ | (1.7) |  |  | $ | 15.5 |  |
| 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 15.5 |  |  | $ | 9.8 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | (10.7) |  |  | $ | 14.4 |  |
| 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 14.4 |  |  | $ | 8.0 |  |  | $ | (0.6) |  |  | $ | — |  |  | $ | (4.0) |  |  | $ | 17.8 |  |
| (1) 2023 consists of the sale of our European businesses and other miscellaneous items. |
