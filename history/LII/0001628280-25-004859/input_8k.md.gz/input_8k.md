# LII 8-K — 0001628280-25-002910 filed 2025-01-29

## item codes, every 8-K on or before 2025-02-11

- 2025-01-29 0001628280-25-002910 — 2.02, 9.01
- 2024-12-06 0001628280-24-050201 — 5.02
- 2024-10-23 0001628280-24-043349 — 2.02, 5.02, 7.01, 9.01
- 2024-07-24 0001628280-24-032683 — 2.02, 9.01
- 2024-05-23 0001628280-24-024875 — 5.02, 9.01
- 2024-05-20 0001628280-24-024385 — 5.07
- 2024-04-24 0001628280-24-017515 — 2.02, 9.01
- 2024-03-18 0001628280-24-011594 — 5.02, 9.01
- 2024-01-31 0001628280-24-002634 — 2.02, 9.01
- 2023-12-11 0001628280-23-041239 — 5.02, 9.01 — amendment of 0001628280-23-035187
- 2023-12-08 0001628280-23-041128 — 5.02
- 2023-10-26 0001628280-23-035187 — 2.02, 5.02, 7.01, 9.01
- 2023-09-21 0001628280-23-032729 — 8.01, 9.01
- 2023-09-15 0001628280-23-032385 — 1.01, 2.03, 8.01, 9.01
- 2023-09-12 0001628280-23-032078 — 8.01, 9.01
- 2023-08-28 0001628280-23-030777 — 1.01, 2.03, 9.01
- 2023-08-25 0001628280-23-030602 — 8.01, 9.01
- 2023-07-27 0001628280-23-025808 — 2.02, 9.01
- 2023-05-19 0001628280-23-019040 — 5.07
- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2025-02-11

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-002910:8k_2_02:1]
EX-99.1
2
lii-20241231xexx991pressre.htm
EX-99.1

[0001628280-25-002910:8k_2_02:2]
Document

[0001628280-25-002910:8k_2_02:3]
Exhibit 99.1

[0001628280-25-002910:8k_2_02:4]
Lennox Reports Fourth Quarter and Full Year 2024 Results;

[0001628280-25-002910:8k_2_02:5]
Provides Full Year 2025 Guidance

[0001628280-25-002910:8k_2_02:6]
____________________________________________________________________________

[0001628280-25-002910:8k_2_02:7]
Q4 Highlights

[0001628280-25-002910:8k_2_02:8]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-25-002910:8k_2_02:9]
(Prior-year adjusted results and core revenue exclude European operations that were divested in the 4Q 2023)

[0001628280-25-002910:8k_2_02:10]
•     Revenue $1.3 billion  –  Core revenue up 22%, including 1% growth from acquisitions

[0001628280-25-002910:8k_2_02:11]
•     GAAP diluted EPS $5.52  –  Adjusted diluted EPS up 54% to $5.60

[0001628280-25-002910:8k_2_02:12]
•     Net cash from operations was $332 million  –  Free cash flow was $273 million, up 50%

[0001628280-25-002910:8k_2_02:13]
____________________________________________________________________________

[0001628280-25-002910:8k_2_02:14]
2024 Full Year Highlights

[0001628280-25-002910:8k_2_02:15]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-25-002910:8k_2_02:16]
•Revenue $5.3 billion  –  Core revenue up 13%, including 2% growth from acquisitions

[0001628280-25-002910:8k_2_02:17]
•GAAP diluted EPS $22.54  –  Adjusted diluted EPS up 26% to $22.58

[0001628280-25-002910:8k_2_02:18]
•Net cash from operations was $946 million  –  Free cash flow was $785 million, up 61%

[0001628280-25-002910:8k_2_02:19]
____________________________________________________________________________

[0001628280-25-002910:8k_2_02:20]
DALLAS, January 29, 2025 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported fourth quarter financial results with $1.3 billion of revenue, a record $245 million of operating income and $5.52 GAAP diluted earnings per share.

[0001628280-25-002910:8k_2_02:21]
Core revenue grew 22% to $1.3 billion. Adjusted segment profit rose 41% to $248 million. Adjusted segment margin was up 250 basis points to a record 18.4%. Adjusted diluted earnings per share rose 54% to $5.60.

[0001628280-25-002910:8k_2_02:22]
"2024 was a remarkable year filled with record achievements, and last quarter continued that momentum as we delivered impressive results across the board," said CEO, Alok Maskara. "Our significant progress in cash conversion reflects a relentless focus on operational excellence. We successfully navigated the complex product transition to the new refrigerant while maintaining a disciplined approach to M&A. These accomplishments not only highlight the strength of our execution but also reinforce our confidence in driving differentiated growth and creating long-term value for our stakeholders.”

[0001628280-25-002910:8k_2_02:23]
The Home Comfort Solutions segment delivered 25% revenue growth in the fourth quarter, fueled by strong sales volume and continued pricing excellence. Sales volume benefited from industry R-410A prebuy ahead of the refrigerant transition in 2025. Segment profit margins increased by 550 basis points, driven by strong volume leverage, favorable trends in component and commodity costs, and significant gains in factory productivity.

[0001628280-25-002910:8k_2_02:24]
Building Climate Solutions segment revenue increased by 17% this quarter, partially driven by early benefits from the new commercial factory. The new factory ramp-up costs, along with existing factory inefficiencies, put pressure on segment profit margins compared to the fourth quarter of last year. The AES integration continues to outperform expectations, exceeding synergies and driving notable customer wins. Additionally, early results from the emergency replacement pilot launch set a promising foundation for volume growth in 2025.

[0001628280-25-002910:8k_2_02:25]
FOURTH QUARTER 2024 FINANCIAL HIGHLIGHTS

[0001628280-25-002910:8k_2_02:26]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-25-002910:8k_2_02:27]
Revenue: $1.3 billion was up 16% and up 22% for core operations, with organic revenue up 21% driven by favorable sales volume as well as price/mix benefits.

[0001628280-25-002910:8k_2_02:28]
Operating Income: $245 million, up 32%, with operating profit margin of 18.2%, up 220 basis points.

[0001628280-25-002910:8k_2_02:29]
Adjusted Segment Profit: $248 million, up 41%, and adjusted segment profit margin of 18.4%, up 250 basis points. Profit growth was driven by $75 million in organic and inorganic sales volume, and $35 million of price/mix benefits. This was partially offset by inflation and the new commercial factory, SG&A, and distribution investments.

[0001628280-25-002910:8k_2_02:30]
Net Income: $198 million, or $5.52 per share, compared to $145 million, or $4.04 per share, in the prior-year quarter.

[0001628280-25-002910:8k_2_02:31]
Adjusted Net Income: $201 million, or $5.60 per share, compared to $130 million, or $3.63 per share, in the prior-year quarter.

[0001628280-25-002910:8k_2_02:32]
Cash Flow: Operating cash flow was $332 million compared to $306 million in the prior-year quarter. Capital expenditures were $60 million compared to $125 million in the prior-year quarter. This quarter the company repurchased $41 million in shares.

[0001628280-25-002910:8k_2_02:33]
Home Comfort Solutions: Business segment revenue was $887 million, up 25%. Segment profit was $193 million, up 67%, and segment margin was 21.7%, up 550 basis points. Segment profit increased $78 million compared to the prior-year quarter. The increase was attributed to $56 million in sales volume and $28 million in price/mix benefits. Additional benefits from factory productivity and favorable product costs, including LIFO, contributed an additional $16 million in profit. This was partially offset by a $22 million impact from inflation and investments in distribution and selling.

[0001628280-25-002910:8k_2_02:34]
Building Climate Solutions: Business segment revenue was $458 million, up 17%. Organic revenue was $448 million, up 14%. Segment profit was $99 million, up $8 million or 9%, and segment margin decreased 160 basis points to 21.6%. This profit improvement was driven by a $19 million increase in organic and inorganic sales volume, $7 million in price/mix improvement and $2 million in distribution productivity. This was offset by $20 million in expenses related to the new factory ramp-up, manufacturing inefficiencies at existing facilities, and inflationary impacts.

[0001628280-25-002910:8k_2_02:35]
Corporate and Other: Corporate expenses were $44 million, an increase of $13 million versus the prior-year quarter adjusted amount. This increase was primarily driven by SG&A expenses related to inflation, investments and timing of incentive compensation.

[0001628280-25-002910:8k_2_02:36]
FULL YEAR 2024 FINANCIAL HIGHLIGHTS

[0001628280-25-002910:8k_2_02:37]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-25-002910:8k_2_02:38]
Revenue: $5.3 billion was up 7% and up 13% for core operations, with organic revenue up 11% driven by favorable sales volume as well as price/mix benefits.

[0001628280-25-002910:8k_2_02:39]
Operating Income: $1.0 billion, up 31%, with operating profit margin of 19.4%, up 350 basis points.

[0001628280-25-002910:8k_2_02:40]
Adjusted Segment Profit: $1.0 billion, up 22%, and adjusted segment profit margin of 19.4%, up 150 basis points. Profit growth was driven by $149 million in organic and inorganic sales volume, and $162 million of price/mix benefits. This was partially offset by $124 million of inflation as well as investments in the new commercial factory, SG&A, and distribution.

[0001628280-25-002910:8k_2_02:41]
Net Income: $807 million, or $22.54 per share, compared to $590 million, or $16.54 per share, in the prior-year.

[0001628280-25-002910:8k_2_02:42]
Adjusted Net Income: $808 million, or $22.58 per share, compared to $641 million, or $17.96 per share, in the prior-year.

[0001628280-25-002910:8k_2_02:43]
Cash Flow: Operating cash flow was $946 million compared to $736 million in the prior-year. Net capital expenditures were $161 million compared to $248 million in the prior-year. This year the company repurchased $54 million in shares.

[0001628280-25-002910:8k_2_02:44]
Home Comfort Solutions: Business segment revenue was $3.6 billion, up 11%. Segment profit was $760 million, up 25%, and segment margin was 21.2%, up 230 basis points. Segment profit increased $150 million compared to the prior year. The increase was attributed to $90 million in sales volume and $122 million in price/mix benefits. Benefits from factory productivity and favorable product costs, including LIFO, contributed an additional $10 million in profit. This was partially offset by a $72 million impact from inflation and investments in distribution and selling.

[0001628280-25-002910:8k_2_02:45]
Building Climate Solutions: Business segment revenue was $1.8 billion, up 17%. Organic revenue was $1.7 billion, up 12%. Segment profit was $397 million, up $56 million or 16%, and segment margin was flat at 22.5%. This profit improvement was driven by a $59 million increase in organic and inorganic sales volume and $39 million in price/mix improvement. This was offset by $33 million in higher product costs primarily related to the new factory ramp-up and manufacturing inefficiencies at existing facilities. In addition, there were $9 million of other expense increases related to SG&A, inflation, and investments.

[0001628280-25-002910:8k_2_02:46]
Corporate and Other: Corporate expenses were $120 million, an increase of $19 million versus the prior-year adjusted amount.

[0001628280-25-002910:8k_2_02:47]
FULL YEAR 2025 GUIDANCE

[0001628280-25-002910:8k_2_02:48]
For full year 2025, core revenue is anticipated to increase by approximately 2%, primarily driven by the mix of new refrigerant products, along with low single-digit increases in price and volume. Volume expectations were tempered by the effects of the pre-buy for legacy refrigerant products in 2024.

[0001628280-25-002910:8k_2_02:49]
Adjusted earnings per share is expected to be within the range of $22.00 to $23.50.

[0001628280-25-002910:8k_2_02:50]
Capital expenditures are projected to be approximately $150 million, and Free Cash Flow is estimated to fall within the range of $650 million to $800 million.

[0001628280-25-002910:8k_2_02:51]
CONFERENCE CALL INFORMATION

[0001628280-25-002910:8k_2_02:52]
A conference call to discuss the company’s fourth quarter and full year results, as well as 2025 full year guidance, will be held this morning at 8:30 a.m. Central Time. To participate in the earnings conference, please call 800-445-7795 (U.S.) or +1 785-424-1699 (international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ424. The conference call also will be webcast live on the company’s investor relations web site at investor.lennox.com. A replay of the conference call will be available until February 5, 2025, by calling toll-free 800-839-3742 (U.S.) or +1 402-220-2979 (international). The call will also be archived on the company's investor relations website at investor.lennox.com.

[0001628280-25-002910:8k_2_02:53]
ABOUT LENNOX

[0001628280-25-002910:8k_2_02:54]
Lennox (NYSE: LII) is a leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our cooling, heating, indoor air quality, and refrigeration systems. Additional information on Lennox is available at Lennox.com or by contacting investor@lennox.com.

[0001628280-25-002910:8k_2_02:55]
FORWARD-LOOKING STATEMENTS & NON-GAAP FINANCIAL MEASURES

[0001628280-25-002910:8k_2_02:56]
For information concerning these and other risks and uncertainties, see LII’s publicly available filings with the Securities and Exchange Commission. LII disclaims any intention or obligation to update or revise any forward-looking statements, whether as a result of new information, future events or otherwise, except as required by law.

[0001628280-25-002910:8k_2_02:57]
A reconciliation of non-GAAP financial measures appearing in this document to financial measures prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP) are included in the Annex to this document.

[0001628280-25-002910:8k_2_02:58]
This document includes forward-looking statements regarding core revenue, segment profit, adjusted segment profit, adjusted net income, adjusted diluted earnings per share, free cash flow, and Debt to EBITDA, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, changes in environmental liabilities, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. Core revenue, adjusted segment profit, and adjusted diluted earnings per share exclude net sales and profit/(loss) from our European portfolio, which was sold in 4Q 2023. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on LII’s full year GAAP financial results.

[0001628280-25-002910:8k_2_02:59]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-25-002910:8k_2_02:60]
Consolidated Statements of Operations

[0001628280-25-002910:8k_2_02:61]
(Unaudited)

[0001628280-25-002910:8k_2_02:62]
| (Amounts in millions, except per share data) | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 1,345.0 |  |  | $ | 1,154.8 |  |  | $ | 5,341.3 |  |  | $ | 4,981.9 |  |
| Cost of goods sold | 889.7 |  |  | 800.0 |  |  | 3,569.4 |  |  | 3,434.1 |  |
| Gross profit | 455.3 |  |  | 354.8 |  |  | 1,771.9 |  |  | 1,547.8 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 207.0 |  |  | 177.8 |  |  | 730.6 |  |  | 705.5 |  |
| Losses and other expenses, net | 2.4 |  |  | 3.4 |  |  | 12.9 |  |  | 8.5 |  |
| Restructuring charges | — |  |  | 2.9 |  |  | — |  |  | 3.1 |  |
| Loss (gain) on sale from previous dispositions | 3.1 |  |  | (14.1) |  |  | 1.5 |  |  | (14.1) |  |
| Impairment on assets held for sale | — |  |  | — |  |  | — |  |  | 63.2 |  |
| Income from equity method investments | (1.8) |  |  | (0.5) |  |  | (7.9) |  |  | (8.5) |  |
| Operating income | 244.6 |  |  | 185.3 |  |  | 1,034.8 |  |  | 790.1 |  |
| Pension settlements | — |  |  | 0.2 |  |  | 0.4 |  |  | 0.8 |  |
| Interest expense, net | 5.5 |  |  | 11.3 |  |  | 38.7 |  |  | 51.7 |  |
| Other expense (income), net | 0.4 |  |  | 0.4 |  |  | 1.9 |  |  | 0.1 |  |
| Income before income taxes | 238.7 |  |  | 173.4 |  |  | 993.8 |  |  | 737.5 |  |
| Provision for income taxes | 41.0 |  |  | 28.9 |  |  | 186.9 |  |  | 147.4 |  |
| Net income | $ | 197.7 |  |  | $ | 144.5 |  |  | $ | 806.9 |  |  | $ | 590.1 |  |
| Earnings per share – Basic: | $ | 5.55 |  |  | $ | 4.07 |  |  | $ | 22.67 |  |  | $ | 16.61 |  |
| Earnings per share – Diluted: | $ | 5.52 |  |  | $ | 4.04 |  |  | $ | 22.54 |  |  | $ | 16.54 |  |
| Weighted Average Number of Shares Outstanding - Basic | 35.6 |  |  | 35.6 |  |  | 35.6 |  |  | 35.5 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 35.8 |  |  | 35.8 |  |  | 35.8 |  |  | 35.7 |  |

[0001628280-25-002910:8k_2_02:63]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |
| Segment Net Sales and Profit (Loss) |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |

[0001628280-25-002910:8k_2_02:64]
| (Amounts in millions) | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net Sales |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 887.4 |  |  | $ | 709.4 |  |  | $ | 3,577.1 |  |  | $ | 3,222.9 |  |
| Building Climate Solutions | 457.6 |  |  | 390.0 |  |  | 1,764.2 |  |  | 1,511.4 |  |
| Corporate and other (1) | — |  |  | 55.4 |  |  | — |  |  | 247.6 |  |
| Total segment sales | $ | 1,345.0 |  |  | $ | 1,154.8 |  |  | $ | 5,341.3 |  |  | $ | 4,981.9 |  |
| Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 192.6 |  |  | $ | 115.0 |  |  | $ | 759.7 |  |  | $ | 610.2 |  |
| Building Climate Solutions | 98.8 |  |  | 90.5 |  |  | 396.9 |  |  | 340.8 |  |
| Corporate and other | (43.7) |  |  | (28.7) |  |  | (120.3) |  |  | (93.9) |  |
| Total segment profit | 247.7 |  |  | 176.8 |  |  | 1,036.3 |  |  | 857.1 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Loss (gain) on sale from previous dispositions | 3.1 |  |  | (14.1) |  |  | 1.5 |  |  | (14.1) |  |
| Impairment of net assets held for sale | — |  |  | — |  |  | — |  |  | 63.2 |  |
| Items in Losses and other expenses, net which are excluded from segment profit (loss) (2) | — |  |  | 2.7 |  |  | — |  |  | 14.8 |  |
| Restructuring charges | — |  |  | 2.9 |  |  | — |  |  | 3.1 |  |
| Operating income | $ | 244.6 |  |  | $ | 185.3 |  |  | $ | 1,034.8 |  |  | $ | 790.1 |  |

[0001628280-25-002910:8k_2_02:65]
(1) The Corporate and Other segment included our European portfolio. In the fourth quarter of 2023 we completed the divestiture of our European operations.

[0001628280-25-002910:8k_2_02:66]
(2) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-25-002910:8k_2_02:67]
•The following items in Losses and other expenses, net:

[0001628280-25-002910:8k_2_02:68]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001628280-25-002910:8k_2_02:69]
◦Environmental liabilities and special litigation charges, and;

[0001628280-25-002910:8k_2_02:70]
◦Other items, net

[0001628280-25-002910:8k_2_02:71]
•Restructuring charges,

[0001628280-25-002910:8k_2_02:72]
•Impairment on assets held for sale, and;

[0001628280-25-002910:8k_2_02:73]
•Loss (Gain) on sale of previous dispositions

[0001628280-25-002910:8k_2_02:74]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-25-002910:8k_2_02:75]
Consolidated Balance Sheets

[0001628280-25-002910:8k_2_02:76]
(Unaudited)

[0001628280-25-002910:8k_2_02:77]
| (Amounts in millions, except shares and par values) | As of December 31, 2024 |  | As of December 31, 2023 |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 415.1 |  |  | $ | 60.7 |  |
| Short-term investments | 7.2 |  |  | 8.4 |  |
| Accounts and notes receivable, net of allowances of $17.8 and $14.4 in 2024 and 2023, respectively | 661.1 |  |  | 594.6 |  |
| Inventories, net | 704.8 |  |  | 699.1 |  |
| Other assets | 96.0 |  |  | 70.7 |  |
| Total current assets | 1,884.2 |  |  | 1,433.5 |  |
| Property, plant and equipment, net of accumulated depreciation of $956.8 and $910.8 in 2024 and 2023, respectively | 800.1 |  |  | 720.4 |  |
| Right-of-use assets from operating leases | 327.2 |  |  | 213.6 |  |
| Goodwill | 220.0 |  |  | 222.1 |  |
| Deferred income taxes | 75.1 |  |  | 51.8 |  |
| Other assets, net | 165.2 |  |  | 156.9 |  |
| Total assets | $ | 3,471.8 |  |  | $ | 2,798.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current Liabilities: |  |  |  |
| Accounts payable | $ | 490.0 |  |  | $ | 374.7 |  |
| Accrued expenses | 435.4 |  |  | 416.1 |  |
| Income taxes payable | — |  |  | 4.2 |  |
| Commercial paper | — |  |  | 150.0 |  |
| Current maturities of long-term debt | 314.5 |  |  | 12.1 |  |
| Current operating lease liabilities | 73.4 |  |  | 57.5 |  |
| Total current liabilities | 1,313.3 |  |  | 1,014.6 |  |
| Long-term debt | 833.1 |  |  | 1,143.1 |  |
| Long-term operating lease liabilities | 267.6 |  |  | 164.6 |  |
| Pensions | 18.9 |  |  | 22.5 |  |
| Other liabilities | 188.7 |  |  | 168.2 |  |
| Total liabilities | 2,621.6 |  |  | 2,513.0 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' equity: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,213.3 |  |  | 1,184.6 |  |
| Retained earnings | 4,150.8 |  |  | 3,506.2 |  |
| Accumulated other comprehensive loss | (93.7) |  |  | (56.9) |  |
| Treasury stock, at cost, 51,573,986 shares and 51,588,103 shares for 2024 and 2023, respectively | (4,421.1) |  |  | (4,349.5) |  |
| Total stockholders' equity | 850.2 |  |  | 285.3 |  |
| Total liabilities and stockholders' equity | $ | 3,471.8 |  |  | $ | 2,798.3 |  |

[0001628280-25-002910:8k_2_02:78]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-25-002910:8k_2_02:79]
Consolidated Statements of Cash Flows

[0001628280-25-002910:8k_2_02:80]
(Unaudited)

[0001628280-25-002910:8k_2_02:81]
| (Amounts in millions) | For the Years Ended December 31, |  |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income | $ | 806.9 |  |  | $ | 590.1 |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Loss (gain) on sale from previous dispositions | 1.5 |  |  | (14.1) |  |  |  |  |  |  |
| Income from equity method investments | (7.9) |  |  | (8.5) |  |  |  |  |  |  |
| Dividends from affiliates | 3.0 |  |  | 0.5 |  |  |  |  |  |  |
| Impairment on assets held for sale | — |  |  | 63.2 |  |  |  |  |  |  |
| Restructuring charges, net of cash paid | — |  |  | 2.6 |  |  |  |  |  |  |
| Provision for credit losses | 8.0 |  |  | 9.8 |  |  |  |  |  |  |
| Unrealized (gains) losses, net on derivative contracts | (2.3) |  |  | 6.0 |  |  |  |  |  |  |
| Stock-based compensation expense | 28.5 |  |  | 30.1 |  |  |  |  |  |  |
| Depreciation and amortization | 95.1 |  |  | 86.0 |  |  |  |  |  |  |
| Deferred income taxes | (24.5) |  |  | (26.0) |  |  |  |  |  |  |
| Pension expense | 4.2 |  |  | 3.2 |  |  |  |  |  |  |
| Pension contributions | (9.3) |  |  | (15.0) |  |  |  |  |  |  |
| Other items, net | — |  |  | (0.5) |  |  |  |  |  |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable | (80.4) |  |  | (32.7) |  |  |  |  |  |  |
| Inventories | (10.1) |  |  | 11.1 |  |  |  |  |  |  |
| Other current assets | (8.3) |  |  | 7.1 |  |  |  |  |  |  |
| Accounts payable | 115.0 |  |  | (29.2) |  |  |  |  |  |  |
| Accrued expenses | 30.4 |  |  | 65.0 |  |  |  |  |  |  |
| Income taxes payable and receivable, net | (21.9) |  |  | (24.1) |  |  |  |  |  |  |
| Leases, net | 5.5 |  |  | 3.1 |  |  |  |  |  |  |
| Other, net | 12.3 |  |  | 8.5 |  |  |  |  |  |  |
| Net cash provided by operating activities | 945.7 |  |  | 736.2 |  |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 2.5 |  |  | 2.1 |  |  |  |  |  |  |
| Purchases of property, plant and equipment | (163.6) |  |  | (250.2) |  |  |  |  |  |  |
| Net (disbursements) proceeds from previous disposition | (7.7) |  |  | 23.2 |  |  |  |  |  |  |
| Acquisitions, net of cash | 1.8 |  |  | (94.9) |  |  |  |  |  |  |
| (Purchases of) proceeds from investments | (7.4) |  |  | 0.1 |  |  |  |  |  |  |
| Net cash used in investing activities | (174.4) |  |  | (319.7) |  |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Commercial paper borrowings | 424.1 |  |  | 150.0 |  |  |  |  |  |  |
| Commercial paper payments | (574.1) |  |  | — |  |  |  |  |  |  |
| Borrowings from debt arrangements | 156.7 |  |  | 1,911.0 |  |  |  |  |  |  |
| Payments on debt arrangements | (194.3) |  |  | (2,797.4) |  |  |  |  |  |  |
| Issuance of senior unsecured notes | — |  |  | 500.0 |  |  |  |  |  |  |
| Payments of deferred financing costs | — |  |  | (5.4) |  |  |  |  |  |  |
| Proceeds from employee stock purchases | 4.5 |  |  | 3.9 |  |  |  |  |  |  |
| Repurchases of common stock | (53.6) |  |  | — |  |  |  |  |  |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (21.6) |  |  | (14.9) |  |  |  |  |  |  |
| Cash dividends paid | (160.3) |  |  | (153.4) |  |  |  |  |  |  |
| Net cash used in financing activities | (418.6) |  |  | (406.2) |  |  |  |  |  |  |
| Increase in cash and cash equivalents | 352.7 |  |  | 10.3 |  |  |  |  |  |  |
| Effect of exchange rates on cash and cash equivalents | 1.7 |  |  | (2.2) |  |  |  |  |  |  |
| Cash and cash equivalents, beginning of period | 60.7 |  |  | 52.6 |  |  |  |  |  |  |
| Cash and cash equivalents, end of period | $ | 415.1 |  |  | $ | 60.7 |  |  |  |  |  |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid | $ | 45.2 |  |  | $ | 50.2 |  |  |  |  |  |  |
| Income taxes paid (net of refunds) | $ | 231.9 |  |  | $ | 197.8 |  |  |  |  |  |  |

[0001628280-25-002910:8k_2_02:82]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit (loss) presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company's business trends and operating performance. In our reconciliation of Net Income, a GAAP measure, to Adjusted net income, a Non-GAAP measure, certain items are no longer excluded from GAAP net income for the periods related to 2024 in the table presented below. |
| Reconciliation of Net income, a GAAP measure, to Adjusted net income, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |  |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |
|  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  |  |
| Net income, a GAAP measure | $ | 197.7 |  | $ | 5.52 |  |  | $ | 144.5 |  | $ | 4.04 |  |  | $ | 806.9 |  | $ | 22.54 |  |  | $ | 590.1 |  | $ | 16.54 |  |  |  |
| Restructuring charges | — |  | — |  |  | 2.2 |  | 0.06 |  |  | — |  | — |  |  | 2.4 |  | 0.07 |  |  |  |
| Loss (gain) on sale from previous dispositions | 3.1 |  | 0.08 |  |  | (11.1) |  | (0.31) |  |  | 1.5 |  | 0.04 |  |  | (11.1) |  | (0.31) |  |  |  |
| Pension settlements | — |  | — |  |  | — |  | — |  |  | — |  | — |  |  | 0.3 |  | 0.01 |  |  |  |
| Items in Losses and other expenses, net which are excluded from segment profit (loss) (a) | — |  | — |  |  | 1.5 |  | 0.05 |  |  | — |  | — |  |  | 11.1 |  | 0.31 |  |  |  |
| Excess tax benefit from share-based compensation (b) | — |  | — |  |  | (2.8) |  | (0.08) |  |  | — |  | — |  |  | (5.2) |  | (0.15) |  |  |  |
| Other tax items, net (b) | — |  |  |  | (4.1) |  | (0.11) |  |  | — |  | — |  |  | (3.7) |  | (0.10) |  |  |  |
| Impairment on assets held for sale (c) | — |  | — |  |  | — |  | — |  |  | — |  | — |  |  | 62.0 |  | 1.74 |  |  |  |
| Non-core business results (d) | — |  | — |  |  | (0.6) |  | (0.02) |  |  | — |  | — |  |  | (5.4) |  | (0.15) |  |  |  |
| Adjusted net income, a non-GAAP measure | $ | 200.8 |  | $ | 5.60 |  |  | $ | 129.6 |  | $ | 3.63 |  |  | $ | 808.4 |  | $ | 22.58 |  |  | $ | 640.5 |  | $ | 17.96 |  |  |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |
| (b) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |
| (c) Impairment on assets held for sale relate to the divestiture of our European operations that was completed in the fourth quarter of 2023. |  |  |  |  |  |  |  |  |
| (d) Non-core business results represent activity related to our business operations in Europe not included elsewhere in the reconciliations. |  |  |  |  |  |  |  |  |

[0001628280-25-002910:8k_2_02:83]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net cash provided by operating activities | $ | 332.4 |  |  | $ | 306.3 |  |  | $ | 945.7 |  |  | $ | 736.2 |  |
| Purchases of property, plant and equipment | (60.2) |  |  | (125.2) |  |  | (163.6) |  |  | (250.2) |  |
| Proceeds from the disposal of property, plant and equipment | 0.6 |  |  | 0.5 |  |  | 2.5 |  |  | 2.1 |  |
| Free cash flow, a Non-GAAP measure | $ | 272.8 |  |  | $ | 181.6 |  |  | $ | 784.6 |  |  | $ | 488.1 |  |

[0001628280-25-002910:8k_2_02:84]
| Reconciliation of Net sales, a GAAP measure to Core net sales, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |
|  | Corporate and Other |  | Consolidated |
|  | 2023 |  | 2023 |
| Net sales, a GAAP measure | $ | 55.4 |  |  | $ | 1,154.8 |  |
| Net sales from non-core businesses (a) | (55.4) |  |  | (55.4) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | 1,099.4 |  |
| (a) Non-Core businesses represent our business operations in Europe, which were sold in the fourth quarter of 2023. |
| Reconciliation of Net sales, a GAAP measure to Core net sales, a Non-GAAP measure |
|  | For the Years Ended December 31, |
|  | Corporate and Other |  | Consolidated |
|  | 2023 |  | 2023 |
| Net sales, a GAAP measure | $ | 247.6 |  |  | $ | 4,981.9 |  |
| Net sales from non-core businesses (a) | (247.6) |  |  | (247.6) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | 4,734.3 |  |
| (a) Non-Core businesses represent our business operations in Europe, which were sold in the fourth quarter of 2023. |
| Reconciliation of Segment profit (loss), a Non-GAAP measure to Adjusted Segment profit (loss), a Non-GAAP measure |
|  | For the Three Months Ended December 31, |
|  | Corporate and Other |  | Consolidated |
|  | 2023 |  | 2023 |
| Segment profit (loss), a Non-GAAP measure | $ | (28.7) |  |  | $ | 176.8 |  |
| Profit from non-core businesses (a) | 1.6 |  |  | 1.6 |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (30.3) |  |  | $ | 175.2 |  |
| (a) Non-Core businesses represent our business operations in Europe, which were sold in the fourth quarter of 2023. |
| Reconciliation of Segment profit, a Non-GAAP measure to Adjusted Segment profit, a Non-GAAP measure |
|  | For the Years Ended December 31, |
|  | Corporate and Other |  | Consolidated |
|  | 2023 |  | 2023 |
| Segment profit (loss), a Non-GAAP measure | $ | (93.9) |  |  | $ | 857.1 |  |
| Profit from non-core businesses (a) | 7.6 |  |  | 7.6 |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (101.5) |  |  | $ | 849.5 |  |
| (a) Non-Core businesses represent our business operations in Europe, which were sold in the fourth quarter of 2023. |
