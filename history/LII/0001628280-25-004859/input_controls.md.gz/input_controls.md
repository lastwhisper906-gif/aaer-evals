# LII 10-K controls and the auditor's report


## auditors_report

[0001628280-25-004859:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001628280-25-004859:auditors_report:2]
To the Stockholders and Board of Directors

[0001628280-25-004859:auditors_report:3]
Lennox International Inc.:

[0001628280-25-004859:auditors_report:4]
Opinions on the Consolidated Financial Statements and Internal Control Over Financial Reporting

[0001628280-25-004859:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Lennox International Inc. and subsidiaries (the Company) as of December 31, 2024 and 2023, the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity (deficit), and cash flows for each of the years in the three-year period ended December 31, 2024, and the related notes and Schedule II – Valuation and Qualifying Accounts and Reserves (collectively, the consolidated financial statements). We also have audited the Company’s internal control over financial reporting as of December 31, 2024, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001628280-25-004859:auditors_report:6]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2024 and 2023, and the results of its operations and its cash flows for each of the years in the three-year period ended December 31, 2024, in conformity with U.S. generally accepted accounting principles. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2024 based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001628280-25-004859:auditors_report:7]
Basis for Opinions

[0001628280-25-004859:auditors_report:8]
The Company’s management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s consolidated financial statements and an opinion on the Company’s internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001628280-25-004859:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001628280-25-004859:auditors_report:10]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001628280-25-004859:auditors_report:11]
Definition and Limitations of Internal Control Over Financial Reporting

[0001628280-25-004859:auditors_report:12]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001628280-25-004859:auditors_report:13]
33

[0001628280-25-004859:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001628280-25-004859:auditors_report:15]
Critical Audit Matter

[0001628280-25-004859:auditors_report:16]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of a critical audit matter does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001628280-25-004859:auditors_report:17]
Evaluation of the product warranty liability

[0001628280-25-004859:auditors_report:18]
As discussed in Notes 2 and 5 to the consolidated financial statements, the Company provides a product warranty for certain of its products with the warranty period generally ranging from 1 to 20 years. The product warranty liability is estimated by product category based on the estimated future costs to repair or replace the products under warranty. The Company’s product warranty liability was $158.4 million as of December 31, 2024.

[0001628280-25-004859:auditors_report:19]
We identified the evaluation of the product warranty liability as a critical audit matter. Assessing the assumptions used to estimate the product warranty liability, specifically, the estimated failure rates by product category by year, and estimated cost per failure, involved subjective and complex auditor judgment.

[0001628280-25-004859:auditors_report:20]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls over the Company’s estimate of the failure rates by product category and controls to estimate the cost of failures by product category for products subject to warranty. We assessed the estimated failure rates by product category and the estimated cost per failure by product category used in the estimation of the product warranty liability by comparing them to the Company’s underlying historical data. We assessed the sensitivity of the estimated failure rates and cost of failures and tested a sample of the historical data used as the basis for these assumptions by comparing to the relevant underlying documentation.

[0001628280-25-004859:auditors_report:21]
/s/ KPMG LLP

[0001628280-25-004859:auditors_report:22]
We have served as the Company’s auditor since 2002.

[0001628280-25-004859:auditors_report:23]
Dallas, Texas

[0001628280-25-004859:auditors_report:24]
February 11, 2025

[0001628280-25-004859:auditors_report:25]
34

[0001628280-25-004859:auditors_report:26]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES


## item_9a

[0001628280-25-004859:item_9a:1]
Item 9A.  Controls and Procedures

[0001628280-25-004859:item_9a:2]
Disclosure Controls and Procedures

[0001628280-25-004859:item_9a:3]
As required by Rule 13a-15 under the Exchange Act, we carried out an evaluation, under the supervision and with the participation of our current management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures as of the end of the period covered by this report.  There are inherent limitations to the effectiveness of any system of disclosure controls and procedures, including the possibility of human error and circumvention or overriding of the controls and procedures. Accordingly, even effective disclosure controls and procedures can only provide reasonable assurance of achieving their control objectives. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that, as of December 31, 2024, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in the reports we file or submit under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the applicable rules and forms, and that such information is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosure.

[0001628280-25-004859:item_9a:4]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001628280-25-004859:item_9a:5]
See “Management’s Report on Internal Control Over Financial Reporting” included in Item 8 “Financial Statements and Supplementary Data.”

[0001628280-25-004859:item_9a:6]
Attestation Report of the Independent Registered Public Accounting Firm

[0001628280-25-004859:item_9a:7]
See “Report of Independent Registered Public Accounting Firm” included in Item 8 “Financial Statements and Supplementary Data.”

[0001628280-25-004859:item_9a:8]
Changes in Internal Control Over Financial Reporting

[0001628280-25-004859:item_9a:9]
There were no changes during the year ended December 31, 2024 in our internal control over financial reporting that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
