# LII note change history — 0001069202-25-000017 → 0001069202-25-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-07-23):
[0001069202-25-000032:note_history:1]
|  | June 30, 2025 |  | December 31, 2024 |
| Accrued expenses | $ | 47.4 |  |  | $ | 49.1 |  |
| Other liabilities | 116.7 |  |  | 109.4 |  |
| Total warranty liability | $ | 164.1 |  |  | $ | 158.4 |  |
  (was, 2025-04-23, similarity 0.9721):
[0001069202-25-000017:note_history:1]
|  | March 31, 2025 |  | December 31, 2024 |
| Accrued expenses | $ | 51.2 |  |  | $ | 49.1 |  |
| Other liabilities | 111.3 |  |  | 109.4 |  |
| Total warranty liability | $ | 162.5 |  |  | $ | 158.4 |  |

- changed (2025-07-23):
[0001069202-25-000032:note_history:2]
The changes in product warranty liabilities for the six months ended June 30, 2025 were as follows (in millions):
  (was, 2025-04-23, similarity 0.9224):
[0001069202-25-000017:note_history:2]
The changes in product warranty liabilities for the three months ended March 31, 2025 were as follows (in millions):

- changed (2025-07-23):
[0001069202-25-000032:note_history:3]
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Warranty claims paid | (20.4) |  |
| Changes resulting from issuance of new warranties | 24.8 |  |
| Changes in estimates associated with pre-existing liabilities | 0.8 |  |
| Changes in foreign currency translation rates and other | 0.5 |  |
| Total warranty liability as of June 30, 2025 | $ | 164.1 |  |
  (was, 2025-04-23, similarity 0.9869):
[0001069202-25-000017:note_history:3]
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Warranty claims paid | (8.0) |  |
| Changes resulting from issuance of new warranties | 11.4 |  |
| Changes in estimates associated with pre-existing liabilities | 0.6 |  |
| Changes in foreign currency translation rates and other | 0.1 |  |
| Total warranty liability as of March 31, 2025 | $ | 162.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-07-23):
[0001069202-25-000032:note_history:4]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2025, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three and six months ended June 30, 2025 and 2024, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2025 and 2024 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2024.
  (was, 2025-04-23, similarity 0.8698):
[0001069202-25-000017:note_history:4]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2025, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2025 and 2024, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2025 and 2024, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three months ended March 31, 2025 and 2024, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2025 and 2024 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2024.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-07-23):
[0001069202-25-000032:note_history:5]
Our weighted average borrowing rate on the Program was as follows as of:

- added (2025-07-23):
[0001069202-25-000032:note_history:6]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.57 | % |  | — | % |

- added (2025-07-23):
[0001069202-25-000032:note_history:7]
Our weighted average borrowing rate on the Amended Credit Agreement was as follows as of:

- added (2025-07-23):
[0001069202-25-000032:note_history:8]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-23):
[0001069202-25-000032:note_history:9]
|  | June 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 29.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.5 |  |  | $ | 14.9 |  |
| Senior unsecured notes | 300.0 |  |  | 300.0 |  |
| Debt issuance costs | (0.1) |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 316.4 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 42.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (7.0) |  |  | (6.4) |  |
| Total long-term debt | $ | 835.7 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,181.1 |  |  | $ | 1,147.6 |  |
  (was, 2025-04-23, similarity 0.9145):
[0001069202-25-000017:note_history:9]
|  | March 31, 2025 |  | December 31, 2024 |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 15.4 |  |  | $ | 14.9 |  |
| Senior unsecured notes | 300.0 |  |  | 300.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 315.2 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 40.0 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (5.8) |  |  | (6.4) |  |
| Total long-term debt | $ | 834.2 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,149.4 |  |  | $ | 1,147.6 |  |

- changed (2025-07-23):
[0001069202-25-000032:note_history:10]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $29.0 million CP Notes outstanding under the Program as of June 30, 2025.
  (was, 2025-04-23, similarity 0.9392):
[0001069202-25-000017:note_history:10]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were no CP Notes currently outstanding under the Program as of March 31, 2025.

- added (2025-07-23):
[0001069202-25-000032:note_history:11]
Our weighted average borrowing rate on the Program was as follows as of:

- added (2025-07-23):
[0001069202-25-000032:note_history:12]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.57 | % |  | — | % |

- added (2025-07-23):
[0001069202-25-000032:note_history:13]
On May 9, 2025, we entered into an Amendment and Restatement Agreement ("Amended Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Amended Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Amended Credit Agreement. The Amended Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of June 30, 2025. Subject to covenant limitations, $969.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Amended Credit Agreement is reduced by borrowings under the Program. The Amended Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Amended Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Amended Credit Agreement.

- added (2025-07-23):
[0001069202-25-000032:note_history:14]
Our weighted average borrowing rate on the Amended Credit Agreement was as follows as of:

- added (2025-07-23):
[0001069202-25-000032:note_history:15]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |

- changed (2025-07-23):
[0001069202-25-000032:note_history:16]
The Amended Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Amended Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).
  (was, 2025-04-23, similarity 0.9864):
[0001069202-25-000017:note_history:16]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

- changed (2025-07-23):
[0001069202-25-000032:note_history:17]
Our Amended Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our credit facility could occur if:
  (was, 2025-04-23, similarity 0.9912):
[0001069202-25-000017:note_history:17]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our credit facility could occur if:

- changed (2025-07-23):
[0001069202-25-000032:note_history:18]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Amended Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.
  (was, 2025-04-23, similarity 0.9893):
[0001069202-25-000017:note_history:18]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

- changed (2025-07-23):
[0001069202-25-000032:note_history:19]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Amended Credit Agreement and accelerate amounts due under our Amended Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).
  (was, 2025-04-23, similarity 0.8683):
[0001069202-25-000017:note_history:19]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

- changed (2025-07-23):
[0001069202-25-000032:note_history:20]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Amended Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.
  (was, 2025-04-23, similarity 0.9976):
[0001069202-25-000017:note_history:20]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.

- removed (2025-07-23):
[0001069202-25-000017:note_history:21]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of March 31, 2025. Subject to covenant limitations, $1,098.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-23):
[0001069202-25-000032:note_history:22]
|  | June 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 29.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.5 |  |  | $ | 14.9 |  |
| Senior unsecured notes | 300.0 |  |  | 300.0 |  |
| Debt issuance costs | (0.1) |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 316.4 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 42.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (7.0) |  |  | (6.4) |  |
| Total long-term debt | $ | 835.7 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,181.1 |  |  | $ | 1,147.6 |  |
  (was, 2025-04-23, similarity 0.9145):
[0001069202-25-000017:note_history:22]
|  | March 31, 2025 |  | December 31, 2024 |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 15.4 |  |  | $ | 14.9 |  |
| Senior unsecured notes | 300.0 |  |  | 300.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 315.2 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 40.0 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (5.8) |  |  | (6.4) |  |
| Total long-term debt | $ | 834.2 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,149.4 |  |  | $ | 1,147.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-07-23):
[0001069202-25-000032:note_history:23]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.
  (was, 2025-04-23, similarity 0.8941):
[0001069202-25-000017:note_history:23]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.  All amount presented reflect the revised segment presentation.

- changed (2025-07-23):
[0001069202-25-000032:note_history:24]
|  | For the Three Months Ended June 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 941.0 |  |  | $ | 455.6 |  |  | $ | — |  |  | $ | 1,396.6 |  |
| Canada | 68.3 |  |  | 36.0 |  |  | — |  |  | 104.3 |  |
| Total | $ | 1,009.3 |  |  | $ | 491.6 |  |  | $ | — |  |  | $ | 1,500.9 |  |
  (was, 2025-04-23, similarity 0.7636):
[0001069202-25-000017:note_history:24]
|  | For the Three Months Ended March 31, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 667.8 |  |  | $ | 332.6 |  |  | $ | — |  |  | $ | 1,000.4 |  |
| Canada | 53.6 |  |  | 18.6 |  |  | — |  |  | 72.2 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 721.4 |  |  | $ | 351.2 |  |  | $ | — |  |  | $ | 1,072.6 |  |

- changed (2025-07-23):
[0001069202-25-000032:note_history:25]
|  | For the Three Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 923.5 |  |  | $ | 445.0 |  |  | $ | — |  |  | $ | 1,368.5 |  |
| Canada | 58.8 |  |  | 23.8 |  |  | — |  |  | 82.6 |  |
| Total | $ | 982.3 |  |  | $ | 468.8 |  |  | $ | — |  |  | $ | 1,451.1 |  |
  (was, 2025-04-23, similarity 0.7636):
[0001069202-25-000017:note_history:25]
|  | For the Three Months Ended March 31, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 626.1 |  |  | $ | 357.3 |  |  | $ | — |  |  | $ | 983.4 |  |
| Canada | 48.5 |  |  | 15.2 |  |  | — |  |  | 63.7 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 674.6 |  |  | $ | 372.5 |  |  | $ | — |  |  | $ | 1,047.1 |  |

- added (2025-07-23):
[0001069202-25-000032:note_history:26]
|  | For the Six Months Ended June 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,608.9 |  |  | $ | 788.3 |  |  | $ | — |  |  | $ | 2,397.2 |  |
| Canada | 121.8 |  |  | 54.5 |  |  | — |  |  | 176.3 |  |
| Total | $ | 1,730.7 |  |  | $ | 842.8 |  |  | $ | — |  |  | $ | 2,573.5 |  |

- added (2025-07-23):
[0001069202-25-000032:note_history:27]
|  | For the Six Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,549.6 |  |  | $ | 802.3 |  |  | $ | — |  |  | $ | 2,351.9 |  |
| Canada | 107.3 |  |  | 39.0 |  |  | — |  |  | 146.3 |  |
| Total | $ | 1,656.9 |  |  | $ | 841.3 |  |  | $ | — |  |  | $ | 2,498.2 |  |

- changed (2025-07-23):
[0001069202-25-000032:note_history:28]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent
  (was, 2025-04-23, similarity 0.7193):
[0001069202-25-000017:note_history:28]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2025 and 2024, direct sales represented 73% and 74% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- added (2025-07-23):
[0001069202-25-000032:note_history:29]
installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2025 and 2024, direct sales represented 74% and 76% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2025 and 2024, direct sales represented 74% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2025-07-23):
[0001069202-25-000032:note_history:30]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada; manufacture curb, curb adapters, drop box diffusers; offer HVAC recycling and salvage services; and focus on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended June 30, 2025 and 2024, equipment sales represented 81% and 82% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2025 and 2024, equipment sales represented 80% and 81% of revenues and the remainder of our revenue was generated from our service business.
  (was, 2025-04-23, similarity 0.9293):
[0001069202-25-000017:note_history:30]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada, and manufacture curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2025 and 2024, equipment sales represented 79% and 83% of revenues and the remainder of our revenue was generated from our service business.

- changed (2025-07-23):
[0001069202-25-000032:note_history:31]
|  | June 30, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 1.7 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (9.7) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (9.5) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (17.5) |  |  | $ | (12.2) |  |  |  |  |  |
  (was, 2025-04-23, similarity 0.9826):
[0001069202-25-000017:note_history:31]
|  | March 31, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 1.6 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (4.6) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (8.8) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (11.8) |  |  | $ | (12.2) |  |  |  |  |  |

- changed (2025-07-23):
[0001069202-25-000032:note_history:32]
For the three months ended June 30, 2025 and 2024, we recognized revenue of $0.8 million and $0.4 million and for the six months ended June 30, 2025 and 2024, we recognized revenue of $3.1 million and $6.1 million related to our contract liabilities at January 1, 2025 and 2024, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025 and 2024.
  (was, 2025-04-23, similarity 0.8301):
[0001069202-25-000017:note_history:32]
For the three months ended March 31, 2025 and 2024, we recognized revenue of $2.3 million and $5.7 million related to our contract liabilities at January 1, 2025 and 2024, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025 and 2024.
