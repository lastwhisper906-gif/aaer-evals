# LII MD&A — 0001069202-25-000032


## mdna

[0001069202-25-000032:mdna:1]
[same as prior period, unchanged from 0001069202-25-000017:mdna:1]

[0001069202-25-000032:mdna:2]
[same as prior period, unchanged from 0001069202-25-000017:mdna:2]

[0001069202-25-000032:mdna:3]
[same as prior period, unchanged from 0001069202-25-000017:mdna:3]

[0001069202-25-000032:mdna:4]
[same as prior period, unchanged from 0001069202-25-000017:mdna:4]

[0001069202-25-000032:mdna:5]
[same as prior period, unchanged from 0001069202-25-000017:mdna:5]

[0001069202-25-000032:mdna:6]
[same as prior period, unchanged from 0001069202-25-000017:mdna:6]

[0001069202-25-000032:mdna:7]
[same as prior period, unchanged from 0001069202-25-000017:mdna:7]

[0001069202-25-000032:mdna:8]
Results for the second quarter of 2025 were primarily driven by overall year-over-year net sales and profit increases. Net sales increased 3% and segment profit increased $27 million for our Home Comfort Solutions segment. Net sales increased 5% and segment profit increased $9 million for our Building Climate Solutions segment. Segment loss decreased $0.3 million for our Corporate and Other segment.

[0001069202-25-000032:mdna:9]
[same as prior period, unchanged from 0001069202-25-000017:mdna:9]

[0001069202-25-000032:mdna:10]
•Net sales of $1,501 million in the second quarter of 2025 reflected a 3% increase as compared to the same period in 2024.

[0001069202-25-000032:mdna:11]
•Operating income in the second quarter of 2025 increased $34 million to $354 million as favorable mix and price were partially offset by lower sales volumes, higher product costs, primarily related to inflationary impacts, including tariffs, and higher freight and distribution costs.

[0001069202-25-000032:mdna:12]
•Net income for the second quarter of 2025 was $278 million.

[0001069202-25-000032:mdna:13]
•Diluted earnings per share was $7.82 per share in the second quarter of 2025 as compared to $6.87 per share in the same period in 2024.

[0001069202-25-000032:mdna:14]
•For the six months ended June 30, 2025, we returned $82 million to shareholders through dividend payments and repurchased $295.4 million of common stock through our share repurchase program.

[0001069202-25-000032:mdna:15]
[same as prior period, unchanged from 0001069202-25-000017:mdna:15]

[0001069202-25-000032:mdna:16]
Recent Developments

[0001069202-25-000032:mdna:17]
On July 4, 2025, the “One Big Beautiful Bill Act” was signed into law, which includes significant changes to federal tax law and other regulatory provisions that may impact the Company. We are currently evaluating the provisions of the new law and the potential effects on our financial position, results of operations, and cash flows.

[0001069202-25-000032:mdna:18]
Three Months Ended June 30, 2025 Compared to Three Months Ended June 30, 2024 - Consolidated Results

[0001069202-25-000032:mdna:19]
[same as prior period, unchanged from 0001069202-25-000017:mdna:17]

[0001069202-25-000032:mdna:20]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 1,500.9 |  |  | $ | 1,451.1 |  |  | 3.4 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 978.4 |  |  | 962.9 |  |  | (1.6) |  |  | 65.2 |  |  | 66.4 |  |
| Gross profit | 522.5 |  |  | 488.2 |  |  | 7.0 |  |  | 34.8 |  |  | 33.6 |  |
| Selling, general and administrative expenses | 173.3 |  |  | 168.5 |  |  | (2.8) |  |  | 11.5 |  |  | 11.6 |  |
| (Gains) losses and other expenses, net | (2.7) |  |  | 3.7 |  |  | 173.0 |  |  | (0.2) |  |  | 0.3 |  |
| Gain on sale from previous dispositions | — |  |  | (1.6) |  |  | 100.0 |  |  | — |  |  | (0.1) |  |
| Income from equity method investments | (2.1) |  |  | (2.5) |  |  | (16.0) |  |  | (0.1) |  |  | (0.2) |  |
| Operating income | $ | 354.0 |  |  | $ | 320.1 |  |  | 10.6 | % |  | 23.6 | % |  | 22.1 | % |

[0001069202-25-000032:mdna:21]
[same as prior period, unchanged from 0001069202-25-000017:mdna:19]

[0001069202-25-000032:mdna:22]
Net sales for the second quarter of 2025 increased 3% as compared to the same period in 2024 primarily due to a 11% increase in mix and price, which was partially offset by a 8% decrease in sales volumes.

[0001069202-25-000032:mdna:23]
[same as prior period, unchanged from 0001069202-25-000017:mdna:21]

[0001069202-25-000032:mdna:24]
Gross profit margins in the second quarter of 2025 increased 120 basis points ("bps") to 34.8% as compared to 33.6% in the same period in 2024. Gross margins increased 350 bps from favorable mix and price, which were partially offset by 130 bps from higher freight and distribution costs and 100 bps from higher product costs, primarily related to inflationary impacts,

[0001069202-25-000032:mdna:25]
including tariffs.

[0001069202-25-000032:mdna:26]
[same as prior period, unchanged from 0001069202-25-000017:mdna:23]

[0001069202-25-000032:mdna:27]
Selling, general and administrative expenses ("SG&A") increased $4 million to $173 million in the second quarter of 2025 as compared to $169 million in the same period in 2024, primarily due to higher employee-related costs partially offset by decreased professional fees.

[0001069202-25-000032:mdna:28]
(Gains) losses and Other Expenses, Net

[0001069202-25-000032:mdna:29]
(Gains) losses and other expenses, net for the second quarter of 2025 and 2024 included the following (in millions):

[0001069202-25-000032:mdna:30]
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |  |
| Foreign currency exchange (gains) losses | $ | (4.3) |  |  | $ | 1.5 |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.2) |  |  | (0.5) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | — |  |  | 0.1 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 1.8 |  |  | 2.4 |  |  |  |  |  |  |  |
| Other items, net | — |  |  | 0.3 |  |  |  |  |  |  |  |
| (Gains) losses and other expenses, net (pre-tax) | $ | (2.7) |  |  | $ | 3.7 |  |  |  |  |  |  |  |

[0001069202-25-000032:mdna:31]
[same as prior period, unchanged from 0001069202-25-000017:mdna:28]

[0001069202-25-000032:mdna:32]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments was $2 million in the second quarter of 2025 consistent with 2024.

[0001069202-25-000032:mdna:33]
[same as prior period, unchanged from 0001069202-25-000017:mdna:30]

[0001069202-25-000032:mdna:34]
Interest expense, net decreased to $8 million in the second quarter of 2025 from $13 million in the same period in 2024 primarily due to lower borrowings.

[0001069202-25-000032:mdna:35]
[same as prior period, unchanged from 0001069202-25-000017:mdna:32]

[0001069202-25-000032:mdna:36]
Our effective tax rate was 19.5% for the second quarter of 2025 as compared to 19.9% in the same period in 2024.  The decrease in rate is primarily due to higher income in low tax jurisdictions.

[0001069202-25-000032:mdna:37]
Second Quarter of 2025 Compared to Second Quarter of 2024 - Results by Segment

[0001069202-25-000032:mdna:38]
[same as prior period, unchanged from 0001069202-25-000017:mdna:35]

[0001069202-25-000032:mdna:39]
The following table presents our Home Comfort Solutions segment's net sales and profit for the second quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000032:mdna:40]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 1,009.3 |  |  | $ | 982.3 |  |  | $ | 27.0 |  |  | 3 | % |
| Profit | $ | 255.2 |  |  | $ | 228.5 |  |  | $ | 26.7 |  |  | 12 | % |
| % of net sales | 25.3 | % |  | 23.3 | % |  |  |  |  |

[0001069202-25-000032:mdna:41]
Net sales increased 3% in the second quarter of 2025 as compared to the same period in 2024 primarily due to a 12% increase in mix and price, which was partially offset by a 9% decrease in sales volumes.

[0001069202-25-000032:mdna:42]
Segment profit in the second quarter of 2025 increased $27 million as compared to the same period in 2024 primarily due to  $84 million from favorable mix and price, and $6 million in factory efficiencies, which were partially offset by $36 million in

[0001069202-25-000032:mdna:43]
decreased sales volumes, $17 million from higher product costs, primarily related to inflationary impacts, including tariffs, and $10 million from higher freight and distribution costs as well as other inflationary impacts.

[0001069202-25-000032:mdna:44]
[same as prior period, unchanged from 0001069202-25-000017:mdna:40]

[0001069202-25-000032:mdna:45]
The following table presents our Building Climate Solutions segment's net sales and profit for the second quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000032:mdna:46]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 491.6 |  |  | $ | 468.8 |  |  | $ | 22.8 |  |  | 5 | % |
| Profit | $ | 122.5 |  |  | $ | 114.0 |  |  | $ | 8.5 |  |  | 7 | % |
| % of net sales | 24.9 | % |  | 24.3 | % |  |  |  |  |

[0001069202-25-000032:mdna:47]
Net sales increased 5% in the second quarter of 2025 as compared to the same period in 2024 primarily due to a 8% increase in mix and price, which was partially offset by a 3% decrease in sales volumes.

[0001069202-25-000032:mdna:48]
Segment profit in the second quarter of 2025 increased $9 million as compared to the same period in 2024 primarily due to $31 million in favorable mix and price and $6 million in higher factory efficiencies, which were partially offset by $11 million in higher product costs, primarily related to inflationary impacts, including tariffs, $11 million in increases in distribution and selling as well as other inflationary impacts, and $6 million in decreased sales volumes.

[0001069202-25-000032:mdna:49]
[same as prior period, unchanged from 0001069202-25-000017:mdna:45]

[0001069202-25-000032:mdna:50]
The following table presents our Corporate and Other segment's net sales and loss for the second quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000032:mdna:51]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | — | % |
| Loss | $ | (23.7) |  |  | $ | (24.0) |  |  | $ | 0.3 |  |  | 1 | % |

[0001069202-25-000032:mdna:52]
Segment loss remained flat at $24 million in the second quarter of 2025 as compared to the same period in 2024.

[0001069202-25-000032:mdna:53]
Year-to-Date through June 30, 2025 Compared to Year-to-Date through June 30, 2024 - Consolidated Results

[0001069202-25-000032:mdna:54]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-25-000032:mdna:55]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 2,573.5 |  |  | $ | 2,498.2 |  |  | 3.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,722.5 |  |  | 1,670.0 |  |  | (3.1) |  |  | 66.9 |  |  | 66.8 |  |
| Gross profit | 851.0 |  |  | 828.2 |  |  | 2.8 |  |  | 33.1 |  |  | 33.2 |  |
| Selling, general and administrative expenses | 344.6 |  |  | 339.2 |  |  | (1.6) |  |  | 13.4 |  |  | 13.6 |  |
| (Gains) losses and other expenses, net | 0.1 |  |  | 7.4 |  |  | 98.6 |  |  | — |  |  | 0.3 |  |
| Gain on sale from previous dispositions | — |  |  | (1.6) |  |  | 100.0 |  |  | — |  |  | (0.1) |  |
| Income from equity method investments | (3.3) |  |  | (3.7) |  |  | (10.8) |  |  | (0.1) |  |  | (0.1) |  |
| Operating income | $ | 509.6 |  |  | $ | 486.9 |  |  | 4.7 | % |  | 19.8 | % |  | 19.5 | % |

[0001069202-25-000032:mdna:56]
Net Sales

[0001069202-25-000032:mdna:57]
Net sales increased 3% for the six months ended June 30, 2025 as compared to the same period in 2024, primarily due to a 9% increase in mix and price, which was partially offset by a 6% decrease in sales volumes.

[0001069202-25-000032:mdna:58]
Gross Profit

[0001069202-25-000032:mdna:59]
Gross profit margins for the six months ended June 30, 2025 decreased 10 bps to 33.1% as compared to 33.2% in the same period in 2024. Gross margins decreased 170 bps from higher product costs, primarily related to inflationary impacts, including tariffs, and 120 bps from higher freight and distribution costs, which were partially offset by 280 bps from favorable mix and price.

[0001069202-25-000032:mdna:60]
Selling, General and Administrative Expenses

[0001069202-25-000032:mdna:61]
SG&A increased $5 million to $345 million for the six months ended June 30, 2025 as compared to $339 million in the same period in 2024 primarily due to higher employee-related costs partially offset by decreased professional fees. As a percentage of net sales, SG&A decreased 20 bps to 13.4% from 13.6%.

[0001069202-25-000032:mdna:62]
[same as prior period, unchanged from 0001069202-25-000017:mdna:25]

[0001069202-25-000032:mdna:63]
Losses (gains) and other expenses, net for the six months ended June 30, 2025 and 2024 included the following (in millions):

[0001069202-25-000032:mdna:64]
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |  |
| Foreign currency exchange (gains) losses | $ | (3.5) |  |  | $ | 2.8 |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.3) |  |  | (1.0) |  |  |  |  |  |  |  |
| Other operating loss | — |  |  | 0.8 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 3.9 |  |  | 4.7 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 0.1 |  |  | $ | 7.4 |  |  |  |  |  |  |  |

[0001069202-25-000032:mdna:65]
Income from Equity Method Investments

[0001069202-25-000032:mdna:66]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments decreased slightly to $3 million for the six months ended June 30, 2025 as compared to $4 million in the same period in 2024.

[0001069202-25-000032:mdna:67]
Interest Expense, net

[0001069202-25-000032:mdna:68]
Interest expense, net decreased $10 million for the six months ended June 30, 2025 to $14 million as compared to $24 million in the same period in 2024 primarily due to lower borrowings.

[0001069202-25-000032:mdna:69]
Income Taxes

[0001069202-25-000032:mdna:70]
Our effective tax rate was 19.4% for the six months ended June 30, 2025 as compared to 19.7% in the same period in 2024. The decrease in rate was primarily due to higher income in low tax jurisdictions.

[0001069202-25-000032:mdna:71]
Year-to-Date through June 30, 2025 Compared to Year-to-Date through June 30, 2024 - Results by Segment

[0001069202-25-000032:mdna:72]
Home Comfort Solutions

[0001069202-25-000032:mdna:73]
The following table presents our Home Comfort Solutions segment's net sales and profit for the six months ended June 30, 2025 and 2024 (dollars in millions):

[0001069202-25-000032:mdna:74]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 1,730.7 |  |  | $ | 1,656.9 |  |  | $ | 73.8 |  |  | 4 | % |
| Profit | $ | 372.0 |  |  | $ | 340.6 |  |  | $ | 31.4 |  |  | 9 | % |
| % of net sales | 21.5 | % |  | 20.6 | % |  |  |  |  |

[0001069202-25-000032:mdna:75]
Net sales increased 4% for the six months ended June 30, 2025 as compared to the same period in 2024 primarily due to a 10% increase in mix and price, which was partially offset by a 6% decrease in sales volumes.

[0001069202-25-000032:mdna:76]
Segment profit for the first six months of 2025 increased $31 million as compared to the same period in 2024 primarily due to $115 million from favorable mix and price, $11 million in increased factory efficiencies and $2 million in miscellaneous other costs, which were partially offset by $37 million from higher product costs, primarily related to inflationary impacts, including tariffs, $36 million from decreased sales volumes, and $24 million from higher freight and distribution costs as well as other inflationary impacts.

[0001069202-25-000032:mdna:77]
Building Climate Solutions

[0001069202-25-000032:mdna:78]
The following table presents our Building Climate Solutions segment's net sales and profit for the six months ended June 30, 2025 and 2024 (dollars in millions):

[0001069202-25-000032:mdna:79]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 842.8 |  |  | $ | 841.3 |  |  | $ | 1.5 |  |  | — | % |
| Profit | $ | 176.0 |  |  | $ | 192.2 |  |  | $ | (16.2) |  |  | (8) | % |
| % of net sales | 20.9 | % |  | 22.8 | % |  |  |  |  |

[0001069202-25-000032:mdna:80]
Net sales remained flat for the six months ended June 30, 2025 as compared to the same period in 2024 primarily due to a 6% increase in mix and price, which was offset by a 6% decrease in sales volumes.

[0001069202-25-000032:mdna:81]
Segment profit for the first six months of 2025 decreased $16 million as compared to the same period in 2024 primarily due to $19 million from decreased sales volumes, $19 million from higher product costs, primarily related to inflationary impacts, including tariffs, and $18 million in increases in distribution and selling as well as other inflationary impacts, which were partially offset by $40 million from favorable mix and price.

[0001069202-25-000032:mdna:82]
Corporate and Other

[0001069202-25-000032:mdna:83]
The following table presents our Corporate and Other segment's net sales and loss for the six months ended June 30, 2025 and 2024 (dollars in millions):

[0001069202-25-000032:mdna:84]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | — | % |
| Loss | $ | (38.4) |  |  | $ | (47.5) |  |  | $ | 9.1 |  |  | 19 | % |

[0001069202-25-000032:mdna:85]
Segment loss decreased $9 million for the six months ended June 30, 2025 as compared to the same period in 2024 due to higher employee related costs and miscellaneous and other items.

[0001069202-25-000032:mdna:86]
[same as prior period, unchanged from 0001069202-25-000017:mdna:49]

[0001069202-25-000032:mdna:87]
[same as prior period, unchanged from 0001069202-25-000017:mdna:50]

[0001069202-25-000032:mdna:88]
[same as prior period, unchanged from 0001069202-25-000017:mdna:51]

[0001069202-25-000032:mdna:89]
The following table summarizes our cash flow activity for the six months ended June 30, 2025 and 2024 (in millions):

[0001069202-25-000032:mdna:90]
|  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |
| Net cash provided by operating activities | $ | 51.0 |  |  | $ | 161.2 |  |
| Net cash used in investing activities | (51.6) |  |  | (57.2) |  |
| Net cash used in financing activities | (368.2) |  |  | (118.3) |  |

[0001069202-25-000032:mdna:91]
Net Cash Provided By Operating Activities - The change in net cash provided by operating activities for the six months ended June 30, 2025 compared to the net cash provided by operating activities for the same period in 2024 primarily reflects less favorable changes in working capital.

[0001069202-25-000032:mdna:92]
Net Cash Used In Investing Activities - Capital expenditures were $54 million for the six months ended June 30, 2025 compared to $62 million in the same period of 2024.  The reduction in capital expenditures was primarily driven by the general expansion of manufacturing capacity and equipment of the Commercial factory in Mexico that was completed in 2024.

[0001069202-25-000032:mdna:93]
Net Cash Used In Financing Activities - Net cash used in financing activities for the six months ended June 30, 2025 increased to $368 million as compared to $118 million provided by in the same period of 2024.  The change was primarily due to changes in net borrowings and repayments of long-term debt and repurchase of common stock through our share repurchase program.  We repurchased $295.4 million of shares for the six months ended June 30, 2025 and returned $82 million to shareholders through dividend payments.

[0001069202-25-000032:mdna:94]
[same as prior period, unchanged from 0001069202-25-000017:mdna:57]

[0001069202-25-000032:mdna:95]
The following table details our lines of credit and financing arrangements as of June 30, 2025 (in millions):

[0001069202-25-000032:mdna:96]
|  | Outstanding Borrowings |
| Commercial paper: | $ | 29.0 |  |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 16.5 |  |
| Senior unsecured notes | 300.0 |  |
| Debt issuance costs | (0.1) |  |
| Total current maturities of long-term debt | $ | 316.4 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 42.7 |  |
| Senior unsecured notes | 800.0 |  |
| Debt issuance costs | (7.0) |  |
| Total long-term debt | $ | 835.7 |  |
| Total debt | $ | 1,181.1 |  |

[0001069202-25-000032:mdna:97]
[same as prior period, unchanged from 0001069202-25-000017:mdna:60]

[0001069202-25-000032:mdna:98]
On October 25, 2023, we established a commercial paper program (the "Program"), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There are $29.0 million CP Notes outstanding under the Program as of June 30, 2025.

[0001069202-25-000032:mdna:99]
[same as prior period, unchanged from 0001069202-25-000017:mdna:62]

[0001069202-25-000032:mdna:100]
On May 9, 2025, we entered into an Amendment and Restatement Agreement ("Amended Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Amended Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Amended Credit Agreement. The Amended Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of June 30, 2025. Subject to covenant limitations, $969.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Amended Credit Agreement is reduced by borrowings under the Program. The Amended Credit Agreement includes a subfacility for swingline loans up to  $65.0 million. Maturity of the Amended Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Amended Credit Agreement.

[0001069202-25-000032:mdna:101]
[same as prior period, unchanged from 0001069202-25-000017:mdna:64]

[0001069202-25-000032:mdna:102]
[same as prior period, unchanged from 0001069202-25-000017:mdna:65]

[0001069202-25-000032:mdna:103]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase

[0001069202-25-000032:mdna:104]
price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2025, we believe we were in compliance with all covenant requirements.

[0001069202-25-000032:mdna:105]
[same as prior period, unchanged from 0001069202-25-000017:mdna:67]

[0001069202-25-000032:mdna:106]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio remains unchanged at 57% as of June 30, 2025, as compared to December 31, 2024.

[0001069202-25-000032:mdna:107]
As of June 30, 2025, our senior credit ratings were Baa2 with a POS outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-25-000032:mdna:108]
[same as prior period, unchanged from 0001069202-25-000017:mdna:70]

[0001069202-25-000032:mdna:109]
We believe our cash and cash equivalents of $49.2 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends, and other needs in the foreseeable future, including the maturity of $300.0 million senior unsecured notes on August 1, 2025.  Included in our cash and cash equivalents of $49.2 million as of June 30, 2025 was $26.4 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-25-000032:mdna:110]
[same as prior period, unchanged from 0001069202-25-000017:mdna:72]

[0001069202-25-000032:mdna:111]
[same as prior period, unchanged from 0001069202-25-000017:mdna:73]

[0001069202-25-000032:mdna:112]
Commitments, Contingencies, and Guarantees

[0001069202-25-000032:mdna:113]
For information regarding our commitments, contingencies, and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-25-000032:mdna:114]
[same as prior period, unchanged from 0001069202-25-000017:mdna:76]

[0001069202-25-000032:mdna:115]
[same as prior period, unchanged from 0001069202-25-000017:mdna:77]
