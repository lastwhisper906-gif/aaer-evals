# LII notes — 0001069202-25-000032


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-25-000032:notes:1]
[same as prior period, unchanged from 0001069202-25-000017:notes:1]

[0001069202-25-000032:notes:2]
[same as prior period, unchanged from 0001069202-25-000017:notes:2]

[0001069202-25-000032:notes:3]
[same as prior period, unchanged from 0001069202-25-000017:notes:3]

[0001069202-25-000032:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2025, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three and six months ended June 30, 2025 and 2024, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2025 and 2024 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2024.

[0001069202-25-000032:notes:5]
[same as prior period, unchanged from 0001069202-25-000017:notes:5]

[0001069202-25-000032:notes:6]
[same as prior period, unchanged from 0001069202-25-000017:notes:6]

[0001069202-25-000032:notes:7]
[same as prior period, unchanged from 0001069202-25-000017:notes:7]

[0001069202-25-000032:notes:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-25-000032:notes:9]
[same as prior period, unchanged from 0001069202-25-000017:notes:9]

[0001069202-25-000032:notes:10]
[same as prior period, unchanged from 0001069202-25-000017:notes:10]

[0001069202-25-000032:notes:11]
[same as prior period, unchanged from 0001069202-25-000017:notes:11]

[0001069202-25-000032:notes:12]
[same as prior period, unchanged from 0001069202-25-000017:notes:12]

[0001069202-25-000032:notes:13]
[same as prior period, unchanged from 0001069202-25-000017:notes:13]

[0001069202-25-000032:notes:14]
[same as prior period, unchanged from 0001069202-25-000017:notes:14]

[0001069202-25-000032:notes:15]
[same as prior period, unchanged from 0001069202-25-000017:notes:15]

[0001069202-25-000032:notes:16]
[same as prior period, unchanged from 0001069202-25-000017:notes:16]

[0001069202-25-000032:notes:17]
|  | Home Comfort Solutions |  | Business Climate Solutions |  | Corporate and Other |  | Total |
| Three months ended June 30, 2025 |  |  |  |  |  |  |  |
| Net Sales(1) | $ | 1,009.3 |  |  | $ | 491.6 |  |  | $ | — |  |  | $ | 1,500.9 |  |
| Cost of Goods Sold | 668.3 |  |  | 308.9 |  |  | 1.2 |  |  | 978.4 |  |
| Selling, general and administrative | 91.4 |  |  | 61.1 |  |  | 20.8 |  |  | 173.3 |  |
| Other (income) expense(2) | (5.6) |  |  | (0.9) |  |  | 1.7 |  |  | (4.8) |  |
| Segment profit (loss)(3) | $ | 255.2 |  |  | $ | 122.5 |  |  | $ | (23.7) |  |  | $ | 354.0 |  |
| Three months ended June 30, 2024 |  |  |  |  |  |  |  |
| Net Sales(1) | $ | 982.3 |  |  | $ | 468.8 |  |  | $ | — |  |  | $ | 1,451.1 |  |
| Cost of Goods Sold | 661.1 |  |  | 301.0 |  |  | 0.8 |  |  | 962.9 |  |
| Selling, general and administrative | 94.5 |  |  | 55.3 |  |  | 18.7 |  |  | 168.5 |  |
| Other (income) expense(2) | (1.8) |  |  | (1.5) |  |  | 4.5 |  |  | 1.2 |  |
| Segment profit (loss)(3) | $ | 228.5 |  |  | $ | 114.0 |  |  | $ | (24.0) |  |  | $ | 318.5 |  |

[0001069202-25-000032:notes:18]
|  | Home Comfort Solutions |  | Business Climate Solutions |  | Corporate and Other |  | Total |
| Six months ended June 30, 2025 |  |  |  |  |  |  |  |
| Net Sales(1) | $ | 1,730.7 |  |  | $ | 842.8 |  |  | $ | — |  |  | $ | 2,573.5 |  |
| Cost of Goods Sold | 1,175.5 |  |  | 546.0 |  |  | 0.9 |  |  | 1,722.5 |  |
| Selling, general and administrative | 189.8 |  |  | 121.4 |  |  | 33.4 |  |  | 344.6 |  |
| Other (income) expense(2) | (6.6) |  |  | (0.8) |  |  | 4.2 |  |  | (3.2) |  |
| Segment profit (loss)(3) | $ | 372.0 |  |  | $ | 176.0 |  |  | $ | (38.4) |  |  | $ | 509.6 |  |
| Six months ended June 30, 2024 |  |  |  |  |  |  |  |
| Net Sales(1) | $ | 1,656.9 |  |  | $ | 841.3 |  |  | $ | — |  |  | $ | 2,498.2 |  |
| Cost of Goods Sold | 1,127.2 |  |  | 542.3 |  |  | 0.5 |  |  | 1,670.0 |  |
| Selling, general and administrative | 192.1 |  |  | 108.9 |  |  | 38.2 |  |  | 339.2 |  |
| Other (income) expense(2) | (3.0) |  |  | (2.1) |  |  | 8.8 |  |  | 3.7 |  |
| Segment profit (loss)(3) | $ | 340.6 |  |  | $ | 192.2 |  |  | $ | (47.5) |  |  | $ | 485.3 |  |

[0001069202-25-000032:notes:19]
[same as prior period, unchanged from 0001069202-25-000017:notes:18]

[0001069202-25-000032:notes:20]
(2) Other (income) expense is primarily comprised of income from equity method investments and (gains) losses and other expenses, net.

[0001069202-25-000032:notes:21]
[same as prior period, unchanged from 0001069202-25-000017:notes:20]

[0001069202-25-000032:notes:22]
•Restructuring charges, and

[0001069202-25-000032:notes:23]
[same as prior period, unchanged from 0001069202-25-000017:notes:22]

[0001069202-25-000032:notes:24]
[same as prior period, unchanged from 0001069202-25-000017:notes:23]

[0001069202-25-000032:notes:25]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Total segment profit(1) | $ | 354.0 |  |  | $ | 318.5 |  |  | $ | 509.6 |  |  | $ | 485.3 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Restructuring charges | — |  |  | — |  |  | — |  |  | — |  |
| Gain on sale from previous dispositions | — |  |  | (1.6) |  |  | — |  |  | (1.6) |  |
| Operating income | 354.0 |  |  | 320.1 |  |  | 509.6 |  |  | 486.9 |  |
| Reconciliation to income before income taxes: |  |  |  |  |  |  |  |
| Pension settlements | 0.1 |  |  | 0.3 |  |  | 0.2 |  |  | 0.3 |  |
| Interest expense, net | 8.3 |  |  | 12.5 |  |  | 14.5 |  |  | 24.3 |  |
| Other expense, net | 0.6 |  |  | 0.3 |  |  | 1.5 |  |  | 1.1 |  |
| Income before income taxes | $ | 345.0 |  |  | $ | 307.0 |  |  | $ | 493.4 |  |  | $ | 461.2 |  |

[0001069202-25-000032:notes:26]
[same as prior period, unchanged from 0001069202-25-000017:notes:25]

[0001069202-25-000032:notes:27]
[same as prior period, unchanged from 0001069202-25-000017:notes:26]

[0001069202-25-000032:notes:28]
|  | June 30, 2025 |  | December 31, 2024 |
| Total Assets: |  |  |  |
| Home Comfort Solutions | $ | 1,989.3 |  |  | $ | 1,626.0 |  |
| Building Climate Solutions | 1,249.1 |  |  | 1,052.6 |  |
| Corporate and Other | 414.3 |  |  | 793.2 |  |
| Total assets | $ | 3,652.7 |  |  | $ | 3,471.8 |  |

[0001069202-25-000032:notes:29]
The assets in the Corporate and Other segment primarily consist of cash, property, plant and equipment, short-term investments, and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-25-000032:notes:30]
[same as prior period, unchanged from 0001069202-25-000017:notes:29]

[0001069202-25-000032:notes:31]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Capital Expenditures: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 11.8 |  |  | $ | 14.6 |  |  | $ | 23.2 |  |  | $ | 28.8 |  |
| Building Climate Solutions | 6.2 |  |  | 11.8 |  |  | 12.5 |  |  | 22.2 |  |
| Corporate and Other | 10.5 |  |  | 6.3 |  |  | 18.3 |  |  | 11.2 |  |
| Total capital expenditures | $ | 28.5 |  |  | $ | 32.7 |  |  | $ | 54.0 |  |  | $ | 62.2 |  |

[0001069202-25-000032:notes:32]
[same as prior period, unchanged from 0001069202-25-000017:notes:31]

[0001069202-25-000032:notes:33]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Depreciation and Amortization: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 11.5 |  |  | $ | 11.5 |  |  | $ | 21.9 |  |  | $ | 22.3 |  |
| Building Climate Solutions | 8.0 |  |  | 6.3 |  |  | 15.9 |  |  | 12.0 |  |
| Corporate and Other | 7.3 |  |  | 7.4 |  |  | 14.6 |  |  | 14.9 |  |
| Total depreciation and amortization | $ | 26.8 |  |  | $ | 25.2 |  |  | $ | 52.4 |  |  | $ | 49.2 |  |

[0001069202-25-000032:notes:34]
[same as prior period, unchanged from 0001069202-25-000017:notes:33]

[0001069202-25-000032:notes:35]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Income from Equity Method Investments: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 1.7 |  |  | $ | 1.7 |  |  | $ | 2.4 |  |  | $ | 2.6 |  |
| Building Climate Solutions | 0.4 |  |  | 0.8 |  |  | 0.8 |  |  | 1.2 |  |
| Corporate and Other | — |  |  | — |  |  | 0.1 |  |  | (0.1) |  |
| Total income from equity method investments | $ | 2.1 |  |  | $ | 2.5 |  |  | $ | 3.3 |  |  | $ | 3.7 |  |

[0001069202-25-000032:notes:36]
[same as prior period, unchanged from 0001069202-25-000017:notes:35]

[0001069202-25-000032:notes:37]
[same as prior period, unchanged from 0001069202-25-000017:notes:36]

[0001069202-25-000032:notes:38]
|  | June 30, 2025 |  | December 31, 2024 |  |  |  |  |
| Property, Plant and Equipment, net: |  |  |  |  |  |  |  |
| United States | $ | 549.8 |  |  | $ | 537.3 |  |  |  |  |  |
| Mexico | 264.2 |  |  | 254.0 |  |  |  |  |  |
| Canada | 4.1 |  |  | 2.9 |  |  |  |  |  |
| Other international | 7.5 |  |  | 5.9 |  |  |  |  |  |
| Total Property, plant and equipment, net | $ | 825.6 |  |  | $ | 800.1 |  |  |  |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-25-000032:notes:39]
[same as prior period, unchanged from 0001069202-25-000017:notes:38]

[0001069202-25-000032:notes:40]
[same as prior period, unchanged from 0001069202-25-000017:notes:39]

[0001069202-25-000032:notes:41]
[same as prior period, unchanged from 0001069202-25-000017:notes:40]

[0001069202-25-000032:notes:42]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income | $ | 277.6 |  |  | $ | 245.9 |  |  | $ | 397.9 |  |  | $ | 370.2 |  |
| Weighted-average shares outstanding – basic | 35.3 |  |  | 35.6 |  |  | 35.4 |  |  | 35.6 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Weighted-average shares outstanding – diluted | 35.5 |  |  | 35.8 |  |  | 35.6 |  |  | 35.8 |  |
| Earnings per share – Basic: | $ | 7.86 |  |  | $ | 6.91 |  |  | $ | 11.24 |  |  | $ | 10.40 |  |
| Earnings per share – Diluted: | $ | 7.82 |  |  | $ | 6.87 |  |  | $ | 11.18 |  |  | $ | 10.34 |  |

[0001069202-25-000032:notes:43]
[same as prior period, unchanged from 0001069202-25-000017:notes:42]

[0001069202-25-000032:notes:44]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Weighted-average number of shares | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-25-000032:notes:45]
4. Commitments and Contingencies:

[0001069202-25-000032:notes:46]
Leases

[0001069202-25-000032:notes:47]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001069202-25-000032:notes:48]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition of a lease under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-25-000032:notes:49]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-25-000032:notes:50]
We lease certain real and personal property under non-cancelable operating leases. Approximately 81% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-25-000032:notes:51]
Product Warranties and Product Related Contingencies

[0001069202-25-000032:notes:52]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001069202-25-000032:notes:53]
Liabilities for estimated product warranty costs are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:

[0001069202-25-000032:notes:54]
|  | June 30, 2025 |  | December 31, 2024 |
| Accrued expenses | $ | 47.4 |  |  | $ | 49.1 |  |
| Other liabilities | 116.7 |  |  | 109.4 |  |
| Total warranty liability | $ | 164.1 |  |  | $ | 158.4 |  |

[0001069202-25-000032:notes:55]
The changes in product warranty liabilities for the six months ended June 30, 2025 were as follows (in millions):

[0001069202-25-000032:notes:56]
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Warranty claims paid | (20.4) |  |
| Changes resulting from issuance of new warranties | 24.8 |  |
| Changes in estimates associated with pre-existing liabilities | 0.8 |  |
| Changes in foreign currency translation rates and other | 0.5 |  |
| Total warranty liability as of June 30, 2025 | $ | 164.1 |  |

[0001069202-25-000032:notes:57]
Litigation

[0001069202-25-000032:notes:58]
We are involved in a number of claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-25-000032:notes:59]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-25-000032:notes:60]
[same as prior period, unchanged from 0001069202-25-000017:notes:59]

[0001069202-25-000032:notes:61]
Our Board of Directors has authorized a total of $5.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in May 2025. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. Such repurchases may also be made in compliance with Rule 10b5-1 trading plans entered into by us, which would permit common stock to be repurchased when the Company might otherwise be precluded from doing so under insider trading laws or self-imposed trading restrictions. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of June 30, 2025, $1,196.5 million was available for repurchase under the Share Repurchase Plans.

[0001069202-25-000032:notes:62]
For the three and six months ended June 30, 2025, we repurchased 371,133 and 515,665 shares, respectively, at an aggregate cost, inclusive of fees, of $209.6 million and $295.4 million, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-25-000032:notes:63]
[same as prior period, unchanged from 0001069202-25-000017:notes:62]

[0001069202-25-000032:notes:64]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.

[0001069202-25-000032:notes:65]
|  | For the Three Months Ended June 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 941.0 |  |  | $ | 455.6 |  |  | $ | — |  |  | $ | 1,396.6 |  |
| Canada | 68.3 |  |  | 36.0 |  |  | — |  |  | 104.3 |  |
| Total | $ | 1,009.3 |  |  | $ | 491.6 |  |  | $ | — |  |  | $ | 1,500.9 |  |

[0001069202-25-000032:notes:66]
|  | For the Three Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 923.5 |  |  | $ | 445.0 |  |  | $ | — |  |  | $ | 1,368.5 |  |
| Canada | 58.8 |  |  | 23.8 |  |  | — |  |  | 82.6 |  |
| Total | $ | 982.3 |  |  | $ | 468.8 |  |  | $ | — |  |  | $ | 1,451.1 |  |

[0001069202-25-000032:notes:67]
|  | For the Six Months Ended June 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,608.9 |  |  | $ | 788.3 |  |  | $ | — |  |  | $ | 2,397.2 |  |
| Canada | 121.8 |  |  | 54.5 |  |  | — |  |  | 176.3 |  |
| Total | $ | 1,730.7 |  |  | $ | 842.8 |  |  | $ | — |  |  | $ | 2,573.5 |  |

[0001069202-25-000032:notes:68]
|  | For the Six Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,549.6 |  |  | $ | 802.3 |  |  | $ | — |  |  | $ | 2,351.9 |  |
| Canada | 107.3 |  |  | 39.0 |  |  | — |  |  | 146.3 |  |
| Total | $ | 1,656.9 |  |  | $ | 841.3 |  |  | $ | — |  |  | $ | 2,498.2 |  |

[0001069202-25-000032:notes:69]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent

[0001069202-25-000032:notes:70]
installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2025 and 2024, direct sales represented 74% and 76% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2025 and 2024, direct sales represented 74% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-25-000032:notes:71]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada; manufacture curb, curb adapters, drop box diffusers; offer HVAC recycling and salvage services; and focus on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended June 30, 2025 and 2024, equipment sales represented 81% and 82% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2025 and 2024, equipment sales represented 80% and 81% of revenues and the remainder of our revenue was generated from our service business.

[0001069202-25-000032:notes:72]
[same as prior period, unchanged from 0001069202-25-000017:notes:68]

[0001069202-25-000032:notes:73]
|  | June 30, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 1.7 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (9.7) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (9.5) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (17.5) |  |  | $ | (12.2) |  |  |  |  |  |

[0001069202-25-000032:notes:74]
For the three months ended June 30, 2025 and 2024, we recognized revenue of $0.8 million and $0.4 million and for the six months ended June 30, 2025 and 2024, we recognized revenue of $3.1 million and $6.1 million related to our contract liabilities at January 1, 2025 and 2024, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025 and 2024.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-25-000032:notes:75]
[same as prior period, unchanged from 0001069202-25-000017:notes:71]

[0001069202-25-000032:notes:76]
[same as prior period, unchanged from 0001069202-25-000017:notes:72]

[0001069202-25-000032:notes:77]
|  | June 30, 2025 |  | December 31, 2024 |
| Finished goods | $ | 692.5 |  |  | $ | 422.6 |  |
| Work in process | 13.3 |  |  | 11.0 |  |
| Raw materials and parts | 445.7 |  |  | 410.7 |  |
| Subtotal | 1,151.5 |  |  | 844.3 |  |
| Excess of current cost over last-in, first-out cost | (149.6) |  |  | (139.5) |  |
| Total inventories, net | $ | 1,001.9 |  |  | $ | 704.8 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-25-000032:notes:78]
[same as prior period, unchanged from 0001069202-25-000017:notes:74]

[0001069202-25-000032:notes:79]
[same as prior period, unchanged from 0001069202-25-000017:notes:75]

[0001069202-25-000032:notes:80]
|  | Balance as of December 31, 2024 |  | Goodwill Adjustment |  |  |  | Balance as of June 30, 2025 |
| Home Comfort Solutions | $ | 26.1 |  |  | $ | — |  |  |  |  | $ | 26.1 |  |
| Building Climate Solutions | 193.9 |  |  | — |  |  |  |  | 193.9 |  |
| Total Goodwill | $ | 220.0 |  |  | $ | — |  |  |  |  | $ | 220.0 |  |

[0001069202-25-000032:notes:81]
We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We have not recorded any goodwill impairments for the six months ended June 30, 2025 or in any periods presented.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-25-000032:notes:82]
[same as prior period, unchanged from 0001069202-25-000017:notes:78]

[0001069202-25-000032:notes:83]
[same as prior period, unchanged from 0001069202-25-000017:notes:79]

[0001069202-25-000032:notes:84]
[same as prior period, unchanged from 0001069202-25-000017:notes:80]

[0001069202-25-000032:notes:85]
Interest Rate Risk - A portion of our debt may bear interest at variable rates, and as a result, we are subject to variability in the cash paid for interest. To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows.  We are not currently hedged against interest rate risk.

[0001069202-25-000032:notes:86]
[same as prior period, unchanged from 0001069202-25-000017:notes:82]

[0001069202-25-000032:notes:87]
[same as prior period, unchanged from 0001069202-25-000017:notes:83]

[0001069202-25-000032:notes:88]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through December 2026.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions) as of:

[0001069202-25-000032:notes:89]
|  | June 30, 2025 |  | December 31, 2024 |
| Unrealized (gains) losses, net on unsettled contracts | $ | (14.2) |  |  | $ | 2.0 |  |
| Income tax expense (benefit) | 3.5 |  |  | (0.6) |  |
| Unrealized (gains) losses, net included in AOCL, net of tax (1) | $ | (10.7) |  |  | $ | 1.4 |  |

[0001069202-25-000032:notes:90]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $10.4 million of derivative gain as of June 30, 2025 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-25-000032:notes:91]
[same as prior period, unchanged from 0001069202-25-000017:notes:87]

[0001069202-25-000032:notes:92]
[same as prior period, unchanged from 0001069202-25-000017:notes:88]

[0001069202-25-000032:notes:93]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Stock-based compensation expense | $ | 8.2 |  |  | $ | 6.4 |  |  | $ | 14.5 |  |  | $ | 13.3 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-25-000032:notes:94]
[same as prior period, unchanged from 0001069202-25-000017:notes:92]

[0001069202-25-000032:notes:95]
[same as prior period, unchanged from 0001069202-25-000017:notes:93]

[0001069202-25-000032:notes:96]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Service cost | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |  | $ | 0.8 |  |
| Interest cost | 2.0 |  |  | 2.2 |  |  | 4.1 |  |  | 4.3 |  |
| Expected return on plan assets | (1.8) |  |  | (1.9) |  |  | (3.6) |  |  | (3.8) |  |
| Amortization of prior service cost | (0.1) |  |  | — |  |  | (0.1) |  |  | — |  |
| Recognized actuarial loss | 0.5 |  |  | 0.2 |  |  | 0.9 |  |  | 0.4 |  |
| Settlements and curtailments | 0.1 |  |  | 0.3 |  |  | 0.2 |  |  | 0.3 |  |
| Net periodic benefit cost | $ | 1.0 |  |  | $ | 1.2 |  |  | $ | 2.1 |  |  | $ | 2.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-25-000032:notes:97]
[same as prior period, unchanged from 0001069202-25-000017:notes:95]

[0001069202-25-000032:notes:98]
As of June 30, 2025, we had approximately $4.9 million in total gross unrecognized tax benefits. If recognized, $4.9 million would be recorded through the Consolidated Statements of Operations.

[0001069202-25-000032:notes:99]
Our effective tax rate was 19.5% for the three months ended June 30, 2025 compared to 19.9% for the three months ended June 30, 2024. The decrease in rate is primarily due to higher income in low tax jurisdictions.

[0001069202-25-000032:notes:100]
We are currently under a limited scope audit by the Internal Revenue Service for our 2021 and 2022 tax years. There are also ongoing U.S. state and local audits and other foreign audits covering fiscal years 2018 through 2023. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2018.


## us-gaap:DebtDisclosureTextBlock

[0001069202-25-000032:notes:101]
10. Lines of Credit and Financing Arrangements:

[0001069202-25-000032:notes:102]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:

[0001069202-25-000032:notes:103]
|  | June 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 29.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.5 |  |  | $ | 14.9 |  |
| Senior unsecured notes | 300.0 |  |  | 300.0 |  |
| Debt issuance costs | (0.1) |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 316.4 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 42.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (7.0) |  |  | (6.4) |  |
| Total long-term debt | $ | 835.7 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,181.1 |  |  | $ | 1,147.6 |  |

[0001069202-25-000032:notes:104]
Commercial Paper Program

[0001069202-25-000032:notes:105]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $29.0 million CP Notes outstanding under the Program as of June 30, 2025.

[0001069202-25-000032:notes:106]
Our weighted average borrowing rate on the Program was as follows as of:

[0001069202-25-000032:notes:107]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.57 | % |  | — | % |

[0001069202-25-000032:notes:108]
Credit Agreement

[0001069202-25-000032:notes:109]
On May 9, 2025, we entered into an Amendment and Restatement Agreement ("Amended Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Amended Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Amended Credit Agreement. The Amended Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of June 30, 2025. Subject to covenant limitations, $969.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Amended Credit Agreement is reduced by borrowings under the Program. The Amended Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Amended Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Amended Credit Agreement.

[0001069202-25-000032:notes:110]
Our weighted average borrowing rate on the Amended Credit Agreement was as follows as of:

[0001069202-25-000032:notes:111]
|  | June 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |

[0001069202-25-000032:notes:112]
The Amended Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Amended Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001069202-25-000032:notes:113]
Our Amended Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001069202-25-000032:notes:114]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001069202-25-000032:notes:115]
• We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-25-000032:notes:116]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Amended Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-25-000032:notes:117]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Amended Credit Agreement and accelerate amounts due under our Amended Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-25-000032:notes:118]
We are currently in compliance with all covenant requirements.

[0001069202-25-000032:notes:119]
Senior Unsecured Notes

[0001069202-25-000032:notes:120]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Amended Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-25-000032:notes:121]
[same as prior period, unchanged from 0001069202-25-000017:notes:116]

[0001069202-25-000032:notes:122]
[same as prior period, unchanged from 0001069202-25-000017:notes:117]

[0001069202-25-000032:notes:123]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Gains (Losses) on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | 3.4 |  |  | $ | 1.6 |  |  | $ | 6.0 |  |  | $ | (0.4) |  |  | Cost of goods sold; Losses and other expenses, net |
| Income tax (expense) benefit |  | (0.8) |  |  | (0.4) |  |  | (1.4) |  |  | 0.1 |  |  | Provision for income taxes |
| Net of tax |  | $ | 2.6 |  |  | $ | 1.2 |  |  | $ | 4.6 |  |  | $ | (0.3) |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (0.4) |  |  | $ | (0.1) |  |  | $ | (0.8) |  |  | $ | (0.4) |  |  | Other expense, net |
| Pension settlements |  | (0.1) |  |  | (0.3) |  |  | (0.2) |  |  | (0.3) |  |  | Pension settlements |
| Income tax benefit |  | 0.2 |  |  | 0.1 |  |  | 0.3 |  |  | 0.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.3) |  |  | $ | (0.3) |  |  | $ | (0.7) |  |  | $ | (0.5) |  |  |  |
| Total reclassifications from AOCL |  | $ | 2.3 |  |  | $ | 0.9 |  |  | $ | 3.9 |  |  | $ | (0.8) |  |  |  |

[0001069202-25-000032:notes:124]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2025 (in millions):

[0001069202-25-000032:notes:125]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2024 |  | $ | (1.5) |  |  | $ | 0.4 |  |  | $ | (45.7) |  |  | $ | (46.9) |  |  | $ | (93.7) |  |
| Other comprehensive income (loss) before reclassifications |  | 16.8 |  |  | — |  |  | (0.7) |  |  | 21.4 |  |  | 37.5 |  |
| Amounts reclassified from AOCL |  | (4.6) |  |  | — |  |  | 0.7 |  |  | (1.3) |  |  | (5.2) |  |
| Net other comprehensive income |  | 12.2 |  |  | — |  |  | — |  |  | 20.1 |  |  | 32.3 |  |
| Balance as of June 30, 2025 |  | $ | 10.7 |  |  | $ | 0.4 |  |  | $ | (45.7) |  |  | $ | (26.8) |  |  | $ | (61.4) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-25-000032:notes:126]
[same as prior period, unchanged from 0001069202-25-000017:notes:121]

[0001069202-25-000032:notes:127]
[same as prior period, unchanged from 0001069202-25-000017:notes:122]

[0001069202-25-000032:notes:128]
The methodologies used to determine the fair value of our financial assets and liabilities as of June 30, 2025 were the same as those used as of December 31, 2024.

[0001069202-25-000032:notes:129]
[same as prior period, unchanged from 0001069202-25-000017:notes:124]

[0001069202-25-000032:notes:130]
[same as prior period, unchanged from 0001069202-25-000017:notes:125]

[0001069202-25-000032:notes:131]
[same as prior period, unchanged from 0001069202-25-000017:notes:126]

[0001069202-25-000032:notes:132]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Amended Credit Agreement in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-25-000032:notes:133]
[same as prior period, unchanged from 0001069202-25-000017:notes:128]

[0001069202-25-000032:notes:134]
|  | June 30, 2025 |  | December 31, 2024 |
| Senior unsecured notes | $ | 1,111.6 |  |  | $ | 1,093.4 |  |
