# LII MD&A — 0001628280-23-013427


## mdna

[0001628280-23-013427:mdna:1]
[same as prior period, unchanged from 0001628280-22-027168:mdna:1]

[0001628280-23-013427:mdna:2]
[same as prior period, unchanged from 0001628280-22-027168:mdna:2]

[0001628280-23-013427:mdna:3]
We operate in two reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential and Commercial.  For  additional information regarding our reportable segments, see Note 2 in the Notes to the Consolidated Financial Statements.

[0001628280-23-013427:mdna:4]
[same as prior period, unchanged from 0001628280-22-027168:mdna:4]

[0001628280-23-013427:mdna:5]
[same as prior period, unchanged from 0001628280-22-027168:mdna:5]

[0001628280-23-013427:mdna:6]
[same as prior period, unchanged from 0001628280-22-027168:mdna:6]

[0001628280-23-013427:mdna:7]
Change in Segment Reporting

[0001628280-23-013427:mdna:8]
Prior to January 1, 2023, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses. We will continue to operate and invest in our Heatcraft Worldwide Refrigeration business which became part of the Commercial segment effective on January 1, 2023, while the European portfolio will be presented with Corporate and Other until disposition. The consolidation of our Heatcraft business within the Commercial segment provides the opportunity to leverage synergies and create long-term growth opportunities by integrating entities with similar products, end consumers and financial performance metrics under the same management. The change in segment reporting better aligns with how the businesses are managed and evaluated given the change in portfolio.  All amounts discussed in this Management's Discussion and Analysis of Financial Condition and Results of Operations reflect the revised segment presentation.  See "Recast Segment Results" in Note 2 for both the previously presented segment results as well as the recast financial information to reflect the change in segment presentation.

[0001628280-23-013427:mdna:9]
[same as prior period, unchanged from 0001628280-22-027168:mdna:11]

[0001628280-23-013427:mdna:10]
Results for the first quarter of 2023 were driven by overall year-over-year sales and profit increases.  Net sales decreased less than 1% and segment profit increased $3 million for the Residential segment. Net sales increased 10% and segment profit increased $26 million for the Commercial segment. Net sales increased 15% and segment loss increased $3 million for the Corporate & Other segment.

[0001628280-23-013427:mdna:11]
[same as prior period, unchanged from 0001628280-22-027168:mdna:13]

[0001628280-23-013427:mdna:12]
•Net sales increased $36 million to $1,049 million in the first quarter of 2023 driven by favorable price and mix partially offset by lower sales volume and unfavorable foreign currency.

[0001628280-23-013427:mdna:13]
•Operating income in the first quarter of 2023 increased $28 million to $139.5 million primarily driven by higher net sales partially offset by rising costs.

[0001628280-23-013427:mdna:14]
•Net income for the first quarter of 2023 was $98 million.

[0001628280-23-013427:mdna:15]
•Diluted earnings per share was $2.75 per share in the first quarter of 2023 compared to $2.29 per share in the first quarter of 2022.

[0001628280-23-013427:mdna:16]
•For the three months ended March 31, 2023, we returned $38 million to shareholders through dividend payments.

[0001628280-23-013427:mdna:17]
Three Months Ended March 31, 2023 Compared to Three Months Ended March 31, 2022 - Consolidated Results

[0001628280-23-013427:mdna:18]
[same as prior period, unchanged from 0001628280-22-027168:mdna:20]

[0001628280-23-013427:mdna:19]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 1,049.4 |  |  | $ | 1,013.4 |  |  | 3.6 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 742.8 |  |  | 745.2 |  |  | 0.3 |  |  | 70.8 |  |  | 73.5 |  |
| Gross profit | 306.6 |  |  | 268.2 |  |  | 14.3 |  |  | 29.2 |  |  | 26.5 |  |
| Selling, general and administrative expenses | 167.5 |  |  | 155.3 |  |  | (7.9) |  |  | 16.0 |  |  | 15.3 |  |
| Losses (gains) and other expenses, net | 0.3 |  |  | 0.4 |  |  | 25.0 |  |  | — |  |  | — |  |
| Restructuring charges | — |  |  | 0.5 |  |  | 100.0 |  |  | — |  |  | — |  |
| (Income) loss from equity method investments | (0.7) |  |  | 0.1 |  |  | (800.0) |  |  | (0.1) |  |  | — |  |
| Operating income | $ | 139.5 |  |  | $ | 111.9 |  |  | 24.7 | % |  | 13.3 | % |  | 11.0 | % |

[0001628280-23-013427:mdna:20]
[same as prior period, unchanged from 0001628280-22-027168:mdna:22]

[0001628280-23-013427:mdna:21]
Net sales for the first quarter of 2023 compared to the first quarter of 2022 increased as a result of favorable price of 6% and favorable product mix of 5% which was partially offset by lower sales volume of 7% due to general lower residential industry volumes.

[0001628280-23-013427:mdna:22]
[same as prior period, unchanged from 0001628280-22-027168:mdna:24]

[0001628280-23-013427:mdna:23]
Gross profit margins in the first quarter of 2023 increased 270 basis points ("bps") to 29.2% compared to 26.5% in the first quarter of 2022. Gross margins increased 400 bps from favorable price, 290 bps from favorable product mix and 90 bps from favorable commodity costs.  Partially offsetting these increases were 180 bps from lower volume, 120 bps from higher other product costs, 100 bps from higher component costs, 60 bps from factory inefficiencies, 40 bps from higher freight and distribution costs, and 10 bps from miscellaneous other items.

[0001628280-23-013427:mdna:24]
[same as prior period, unchanged from 0001628280-22-027168:mdna:26]

[0001628280-23-013427:mdna:25]
Selling, general and administrative expenses ("SG&A") increased $12 million to $167.5 million in the first quarter of 2023 compared to $155.3 million in the first quarter of 2022 due to higher employee related costs. As a percentage of net sales, SG&A increased 70 bps to 16.0%.

[0001628280-23-013427:mdna:26]
[same as prior period, unchanged from 0001628280-22-027168:mdna:28]

[0001628280-23-013427:mdna:27]
Losses (gains) and other expenses, net for the first quarter of 2023 and 2022 included the following (in millions):

[0001628280-23-013427:mdna:28]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |  |  |
| Realized gains on settled future contracts | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |
| Foreign currency exchange gains | (0.8) |  |  | (0.3) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.3) |  |  | (0.9) |  |  |  |  |  |  |  |
| Other operating income | (0.8) |  |  | (0.3) |  |  |  |  |  |  |  |
| Net change in unrealized gains (losses) on unsettled futures contracts | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 2.4 |  |  | 2.1 |  |  |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic | — |  |  | 0.3 |  |  |  |  |  |  |  |
| Other items, net | — |  |  | 0.5 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 0.3 |  |  | $ | 0.4 |  |  |  |  |  |  |  |

[0001628280-23-013427:mdna:29]
[same as prior period, unchanged from 0001628280-22-027168:mdna:31]

[0001628280-23-013427:mdna:30]
Restructuring charges were immaterial in the first quarter of 2023 and 2022.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-23-013427:mdna:31]
[same as prior period, unchanged from 0001628280-22-027168:mdna:33]

[0001628280-23-013427:mdna:32]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  We recognized income from equity method investments of $1 million in the first quarter of 2023 and a loss of $0.1 million in the first quarter of 2022.

[0001628280-23-013427:mdna:33]
[same as prior period, unchanged from 0001628280-22-027168:mdna:35]

[0001628280-23-013427:mdna:34]
Interest expense, net increased to $14 million in the first quarter of 2023 from $7 million in the first quarter of 2022 due to higher borrowings costs during the period.

[0001628280-23-013427:mdna:35]
[same as prior period, unchanged from 0001628280-22-027168:mdna:37]

[0001628280-23-013427:mdna:36]
Our effective tax rate was 21.7% for the first quarter of 2023 compared to 19.9% for the first quarter of 2022.  The rate increased primarily due to a shift in earnings between jurisdictions.

[0001628280-23-013427:mdna:37]
We expect our annual effective tax rate to be 19-21%, excluding the impacts of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001628280-23-013427:mdna:38]
First Quarter of 2023 Compared to First Quarter of 2022 - Results by Segment

[0001628280-23-013427:mdna:39]
Residential

[0001628280-23-013427:mdna:40]
The following table presents our Residential segment's net sales and profit for the first quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-013427:mdna:41]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 681.0 |  |  | $ | 682.2 |  |  | $ | (1.2) |  |  | (0.2) | % |
| Profit | $ | 111.1 |  |  | $ | 107.6 |  |  | $ | 3.5 |  |  | 3.3 | % |
| % of net sales | 16.3 | % |  | 15.8 | % |  |  |  |  |

[0001628280-23-013427:mdna:42]
Net sales decreased 0.2% in the first quarter of 2023 compared to 2022, as sales volume declined 8% and foreign currency and other was 1% unfavorable.  Offsetting these declines were favorable product mix of 5% and higher price of 4%.

[0001628280-23-013427:mdna:43]
Segment profit in the first quarter of 2023 compared to 2022 increased by $3 million, driven by $25 million from higher price, $9 million from favorable product mix, $6 million from lower commodity costs and $5 million from lower product warranty costs. Partially offsetting these increases were $12 million from lower sales volume, $6 million from higher component costs, $6 million from higher distribution and freight charges, $6 million from higher SG&A costs, $5 million from factory inefficiencies, $4 million from miscellaneous other costs, and $3 million from higher other product costs.

[0001628280-23-013427:mdna:44]
Commercial

[0001628280-23-013427:mdna:45]
The following table presents our Commercial segment's net sales and profit for the first quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-013427:mdna:46]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 308.7 |  |  | $ | 279.5 |  |  | $ | 29.2 |  |  | 10.4 | % |
| Profit | $ | 50.0 |  |  | $ | 23.8 |  |  | $ | 26.2 |  |  | 110.1 | % |
| % of net sales | 16.2 | % |  | 8.5 | % |  |  |  |  |

[0001628280-23-013427:mdna:47]
(1) 2022 amounts have been recast to reflect the changes in segment reporting.  Please see Note 2 in the Notes to the Consolidated Financial Statements for further detail.

[0001628280-23-013427:mdna:48]
Net sales increased 10% in the first quarter of 2023 compared to 2022 as price increased 9% and improved product mix was 7% favorable.  Partially offsetting these increases was a decline in sales volume of 6%.

[0001628280-23-013427:mdna:49]
Segment profit in the first quarter of 2023 compared to 2022 increased $26 million due to $26 million from favorable price,$16 million from favorable product mix, $4 million from lower commodity prices, $2 million from favorable freight and distribution costs, and $1 million from favorable factory productivity.  Partially offsetting these increases was $9 million from higher other product costs, $5 million from lower sales volume, $3 million from higher component costs, $3 million from higher SG&A costs, $2 million from higher product warranty costs, and $1 million from higher miscellaneous other costs.

[0001628280-23-013427:mdna:50]
[same as prior period, unchanged from 0001628280-22-027168:mdna:55]

[0001628280-23-013427:mdna:51]
The following table presents our Corporate and Other segment's net sales and profit for the first quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-013427:mdna:52]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 59.7 |  |  | $ | 51.7 |  |  | $ | 8.0 |  |  | 15.5 | % |
| Profit | $ | (19.4) |  |  | $ | (16.8) |  |  | $ | (2.6) |  |  | 15.5 | % |

[0001628280-23-013427:mdna:53]
(1) 2022 amounts have been recast to reflect the changes in segment reporting.  Please see Note 2 in the Notes to the Consolidated Financial Statements for further detail.

[0001628280-23-013427:mdna:54]
Net sales increased $8 million and segment profit decreased $3 million in the first quarter of 2023 compared to 2022.  Corporate and Other profit excluding the results of Europe decreased $6 million to $19 million in the first quarter of 2023 compared to 2022, primarily due to increased incentive compensation costs.

[0001628280-23-013427:mdna:55]
[same as prior period, unchanged from 0001628280-22-027168:mdna:95]

[0001628280-23-013427:mdna:56]
[same as prior period, unchanged from 0001628280-22-027168:mdna:96]

[0001628280-23-013427:mdna:57]
[same as prior period, unchanged from 0001628280-22-027168:mdna:97]

[0001628280-23-013427:mdna:58]
The following table summarizes our cash flow activity for the three months ended March 31, 2023 and 2022 (in millions):

[0001628280-23-013427:mdna:59]
|  | For the Three Months Ended March 31, |
|  | 2023 |  | 2022 |
| Net cash used in operating activities | $ | (78.8) |  |  | $ | (97.9) |  |
| Net cash used in investing activities | (33.7) |  |  | (25.7) |  |
| Net cash provided by financing activities | 101.1 |  |  | 129.1 |  |

[0001628280-23-013427:mdna:60]
Net Cash Used In Operating Activities -  The change in net cash used in operating activities for the three months ended March 31, 2023 compared to the net cash used in operating activities for the same period in 2022 reflects changes in working capital and an increase in net income.

[0001628280-23-013427:mdna:61]
Net Cash Used In Investing Activities - Capital expenditures were $35 million for the three months ended March 31, 2023 compared to $26 million in the same period of 2022.  Capital expenditures in 2023 were related to our Commercial factory in Mexico, the general expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-23-013427:mdna:62]
Net Cash Provided By Financing Activities - Net cash provided by financing activities for the three months ended March 31, 2023 decreased to $101 million compared to $129 million used in the same period of 2022.  The change was primarily due to less net borrowings partially offset by less spent on share repurchases.  We did not repurchase any shares for the three months ended March 31, 2023 and $200 million in the same period of 2022.  We returned $38 million to shareholders through dividend payments for the three months ended March 31, 2023 and $34 million in the same period of 2022. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001628280-23-013427:mdna:63]
[same as prior period, unchanged from 0001628280-22-027168:mdna:104]

[0001628280-23-013427:mdna:64]
The following table details our lines of credit and financing arrangements as of March 31, 2023 (in millions):

[0001628280-23-013427:mdna:65]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (2) | $ | 297.0 |  |
| Finance lease obligations | 10.9 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (0.4) |  |
| Total current maturities of long-term debt | $ | 657.5 |  |
| Long-term debt: |  |
| Finance lease obligations | 27.8 |  |
| Credit agreement (1) | 388.0 |  |
| Senior unsecured notes | 600.0 |  |
| Debt issuance costs | (5.7) |  |
| Total long-term debt | 1,010.1 |  |
| Total debt | $ | 1,667.6 |  |

[0001628280-23-013427:mdna:66]
(1)   The available future borrowings on our Credit Agreement (as defined below) are $360.0 million, after being reduced by the outstanding borrowings and $2.0 million in outstanding standby letters of credit.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-23-013427:mdna:67]
[same as prior period, unchanged from 0001628280-22-027168:mdna:108]

[0001628280-23-013427:mdna:68]
Both our Asset Securitization Program as well as our $350.0 million 2023 Notes will mature during the year. We are currently evaluating our options related to these obligations including refinancing and other alternatives.  We do not believe that our options or alternatives will have any material impact on our results of operations or liquidity.

[0001628280-23-013427:mdna:69]
Credit Agreement

[0001628280-23-013427:mdna:70]
In July 2021, we entered into a new Credit agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-23-013427:mdna:71]
[same as prior period, unchanged from 0001628280-22-027168:mdna:112]

[0001628280-23-013427:mdna:72]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control. As of March 31, 2023, we believe we were in compliance with all covenant requirements.

[0001628280-23-013427:mdna:73]
[same as prior period, unchanged from 0001628280-22-027168:mdna:114]

[0001628280-23-013427:mdna:74]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations,

[0001628280-23-013427:mdna:75]
the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 108% at March 31, 2023 from 115% at December 31, 2022.

[0001628280-23-013427:mdna:76]
As of March 31, 2023, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-23-013427:mdna:77]
[same as prior period, unchanged from 0001628280-22-027168:mdna:117]

[0001628280-23-013427:mdna:78]
We believe our cash and cash equivalents of $40 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $40 million as of March 31, 2023 was $22 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-23-013427:mdna:79]
[same as prior period, unchanged from 0001628280-22-027168:mdna:119]

[0001628280-23-013427:mdna:80]
Our senior unsecured notes were issued by Lennox International Inc. and are unconditionally guaranteed by certain of our subsidiaries (the "Guarantor Subsidiaries").  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001628280-23-013427:mdna:81]
[same as prior period, unchanged from 0001628280-22-027168:mdna:121]

[0001628280-23-013427:mdna:82]
[same as prior period, unchanged from 0001628280-22-027168:mdna:122]

[0001628280-23-013427:mdna:83]
Commitments, Contingencies and Guarantees

[0001628280-23-013427:mdna:84]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-23-013427:mdna:85]
[same as prior period, unchanged from 0001628280-22-027168:mdna:125]

[0001628280-23-013427:mdna:86]
[same as prior period, unchanged from 0001628280-22-027168:mdna:126]
