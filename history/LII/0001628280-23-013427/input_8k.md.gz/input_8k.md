# LII 8-K — 0001193125-23-120058 filed 2023-04-27

## item codes, every 8-K on or before 2023-04-27

- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2023-04-27

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-23-120058:8k_2_02:1]
EX-99.1
2
d486213dex991.htm
EX-99.1

[0001193125-23-120058:8k_2_02:2]
EX-99.1

[0001193125-23-120058:8k_2_02:3]
Exhibit 99.1

[0001193125-23-120058:8k_2_02:4]
Lennox Reports Record First Quarter Results

[0001193125-23-120058:8k_2_02:5]
Q1
Highlights

[0001193125-23-120058:8k_2_02:6]
(All comparisons are year-over-year, unless otherwise noted)

[0001193125-23-120058:8k_2_02:7]
|  | • |  | Revenue $1.05 billion; core revenue excluding European Operations up 3% to $990 million |

[0001193125-23-120058:8k_2_02:8]
|  | • |  | Operating Income $140 million; adjusted segment profit up 20% to $142 million |

[0001193125-23-120058:8k_2_02:9]
|  | • |  | GAAP diluted EPS $2.75; adjusted diluted EPS up 15% to $2.83 |

[0001193125-23-120058:8k_2_02:10]
|  | • |  | Reiterating 2023 outlook: core revenue flat to up 4%, EPS $14.25-$15.25 |

[0001193125-23-120058:8k_2_02:11]
DALLAS, April 27, 2023 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions,
today reported first quarter record revenue of $1.05 billion in the quarter. Operating income was a record $140 million. GAAP diluted earnings per share was a record $2.75.

[0001193125-23-120058:8k_2_02:12]
Core revenue, excluding European Operations, grew 3% to $990 million. Adjusted segment profit rose 20% to $142 million. Adjusted segment margin was
14.4%, up 210 basis points. Adjusted earnings per share rose 15% to $2.83.

[0001193125-23-120058:8k_2_02:13]
“Lennox delivered exceptional performance this quarter including record
quarterly earnings per share,” Chief Executive Officer Alok Maskara said. “We take pride in the achievements of our team for gaining share and expanding margins, while seamlessly transitioning our product portfolio to meet the new minimum
efficiency regulations. The successful quarter reflects our company’s product leadership, strong direct customer relationships and advanced digital platforms that will continue to fuel our share gain and margin expansion.”

[0001193125-23-120058:8k_2_02:14]
During the first quarter, our Residential segment delivered flat revenue as unit volume declines were offset with price and mix benefits. Profit margin
improved 50bps as price exceeded inflation and new minimum efficiency products generated mix benefits offsetting the impact of the volume decline.

[0001193125-23-120058:8k_2_02:15]
Our
Commercial segment, which now incorporates our North American refrigeration operations, delivered a 10% increase in revenue and a 110% increase in segment profit driven by price and mix benefits. We maintained a strong backlog as industry lead times
remained extended and our sales volume remains constrained due to ongoing supply chain challenges.

[0001193125-23-120058:8k_2_02:16]
FIRST QUARTER 2023 FINANCIAL HIGHLIGHTS

[0001193125-23-120058:8k_2_02:17]
(All comparisons are year-over-year, unless otherwise noted)

[0001193125-23-120058:8k_2_02:18]
Revenue: $1.05 billion; Core Revenue, which excludes our European operations was $990 million, up 3%. Revenue growth was driven by price and
favorable mix and partially offset by lower sales volume.

[0001193125-23-120058:8k_2_02:19]
Operating Income: $140 million with operating profit margin of 13.3%.

[0001193125-23-120058:8k_2_02:20]
Adjusted Segment Profit: $142 million, up 20%, and adjusted segment profit margin of 14.4%, up 210 basis points. Adjusted segment profit increased
$24 million as price and mix benefits were partially offset by lower sales volumes, and inflationary impacts on material, labor, distribution, and SG&A costs.

[0001193125-23-120058:8k_2_02:21]
Net Income: $98.0 million, or $2.75 per share, compared to $83.6 million, or $2.29 per share, in the prior year quarter.

[0001193125-23-120058:8k_2_02:22]
Adjusted Net Income: $100.5 million, or $2.83 per share, compared to $89.9 million, or $2.47 per share, in the prior year quarter.

[0001193125-23-120058:8k_2_02:23]
Cash: Net cash used in operations was $79 million compared to $98 million in the prior-year quarter. Capital expenditures were approximately
$35 million compared to $25 million in the prior year quarter with the increase driven by the new Commercial factory in Saltillo, Mexico. Free cash flow was a $114 million usage compared to a $123 million usage in the first
quarter a year ago. Total debt at the end of the first quarter was $1.67 billion. Total cash, cash equivalents and short-term investments were $48 million at the end of the quarter.

[0001193125-23-120058:8k_2_02:24]
Residential: Business segment revenue was $681 million, flat to prior year. Segment Profit was a first quarter record $111 million, up 3%,
and segment margin was 16.3%, up 50 basis points. Profit increased $3 million compared to prior year as $34 million of pricing and mix benefits were partially offset with $12 million of lower sales volumes, $3 million of higher
materials and factory expenses and $16 million of higher distribution and other expenses.

[0001193125-23-120058:8k_2_02:25]
Commercial: Business segment revenue was
$309 million, up 10%. Segment profit was $50 million, up 110%, and segment margin expanded 770 basis points to 16.2%. Segment profit increased $26 million compared to prior year as $42 million of pricing and mix benefits were
partially offset with $5 million of lower sales volumes and $11 million increase of all other expenses.

[0001193125-23-120058:8k_2_02:26]
Corporate and Other: Revenue in
the European Refrigeration operations was $59.7 million, up 15%. European operations had a loss of $0.4 million compared to a $3.4 million loss in the prior year quarter. Corporate expenses were $19 million, or up $6 million
compared to prior year quarter due to timing of incentive compensation.

[0001193125-23-120058:8k_2_02:27]
As previously announced, beginning in 2023 our North American Refrigeration
operations are reported in the Commercial Segment and European operations are classified as non-core and included in the Corporate and Other Segment until disposition. See appendix for the previously reported
and recast results for each operating segment.

[0001193125-23-120058:8k_2_02:28]
FULL-YEAR 2023 GUIDANCE

[0001193125-23-120058:8k_2_02:29]
For the full year of 2023, we still expect; core revenue to be flat to up 4% and earnings per share of $14.25 to $15.25.

[0001193125-23-120058:8k_2_02:30]
“Given the strong start to the year and the current end-market conditions, we remain confident in our full year
outlook. Our capital deployment priorities remain unchanged, and we will support organic growth investments as well as smaller, bolt-on acquisitions while maintaining a healthy balance sheet,” Maskara
continued. “We believe that our best days are ahead of us.”

[0001193125-23-120058:8k_2_02:31]
CONFERENCE CALL INFORMATION

[0001193125-23-120058:8k_2_02:32]
A conference call to discuss the company’s first-quarter results and 2023 outlook will be held this morning at 8:30 a.m. Central Time. To participate in
the earnings conference, please call 800-274-8461 (U.S.) or +1 203-518-9765
(international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ123. The conference call also will be webcast live on the company’s web site at www.lennoxinternational.com. A replay of the conference call will be
available until May 11, 2023, by calling toll-free 800-934-8367 (U.S.) or +1
402-220-6994 (international). The call will also be archived on the company’s web site.

[0001193125-23-120058:8k_2_02:33]
ABOUT LENNOX

[0001193125-23-120058:8k_2_02:34]
Lennox (NYSE: LII) is a leader in
energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our
cooling, heating, indoor air quality, and refrigeration systems. Additional information on Lennox is available at www.lennoxinternational.com or by contacting investor@lennoxintl.com.

[0001193125-23-120058:8k_2_02:35]
FORWARD-LOOKING STATEMENTS

[0001193125-23-120058:8k_2_02:36]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-120058:8k_2_02:37]
Consolidated Statements of Operations

[0001193125-23-120058:8k_2_02:38]
(Unaudited)

[0001193125-23-120058:8k_2_02:39]
| (Amounts in millions, except per share data) |  | For the Three Months EndedMarch 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net sales |  | $ | 1,049.4 |  |  | $ | 1,013.4 |  |
| Cost of goods sold |  |  | 742.8 |  |  |  | 745.2 |  |
| Gross profit |  |  | 306.6 |  |  |  | 268.2 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 167.5 |  |  |  | 155.3 |  |
| Losses (gains) and other expenses, net |  |  | 0.3 |  |  |  | 0.4 |  |
| Restructuring charges |  |  | — |  |  |  | 0.5 |  |
| (Income) loss from equity method investments |  |  | (0.7 | ) |  |  | 0.1 |  |
| Operating income |  |  | 139.5 |  |  |  | 111.9 |  |
| Pension settlements |  |  | 0.2 |  |  |  | 0.1 |  |
| Interest expense, net |  |  | 14.2 |  |  |  | 6.8 |  |
| Other expense (income), net |  |  | — |  |  |  | 0.6 |  |
| Net income before income taxes |  |  | 125.1 |  |  |  | 104.4 |  |
| Provision for income taxes |  |  | 27.1 |  |  |  | 20.8 |  |
| Net income |  | $ | 98.0 |  |  | $ | 83.6 |  |
| Earnings per share – Basic: |  | $ | 2.76 |  |  | $ | 2.30 |  |
| Earnings per share – Diluted: |  | $ | 2.75 |  |  | $ | 2.29 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 35.5 |  |  |  | 36.3 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 35.6 |  |  |  | 36.5 |  |

[0001193125-23-120058:8k_2_02:40]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-120058:8k_2_02:41]
Segment Net Sales and Profit (Loss)

[0001193125-23-120058:8k_2_02:42]
(Unaudited)

[0001193125-23-120058:8k_2_02:43]
| (Amounts in millions) |  | For the Three MonthsEnded March 31, |  |
|  |  | 2023 |  |  | 2022(2) |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential |  | $ | 681.0 |  |  | $ | 682.2 |  |
| Commercial |  |  | 308.7 |  |  |  | 279.5 |  |
| Corporate and other |  |  | 59.7 |  |  |  | 51.7 |  |
|  |  | $ | 1,049.4 |  |  | $ | 1,013.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |
| Residential |  | $ | 111.1 |  |  | $ | 107.6 |  |
| Commercial |  |  | 50.0 |  |  |  | 23.8 |  |
| Corporate and other |  |  | (19.4 | ) |  |  | (16.8 | ) |
| Total segment profit |  |  | 141.7 |  |  |  | 114.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) |  |  | 2.2 |  |  | $ | 2.2 |  |
| Restructuring charges |  |  | — |  |  |  | 0.5 |  |
| Operating income |  | $ | 139.5 |  |  | $ | 111.9 |  |

[0001193125-23-120058:8k_2_02:44]
| (1) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-23-120058:8k_2_02:45]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-23-120058:8k_2_02:46]
|  | • |  | Net change in unrealized gains (losses) on unsettled futures contracts, |

[0001193125-23-120058:8k_2_02:47]
|  | • |  | Environmental liabilities and special litigation charges, |

[0001193125-23-120058:8k_2_02:48]
|  | • |  | Charges incurred related to COVID-19 pandemic; and |

[0001193125-23-120058:8k_2_02:49]
|  | • |  | Other items, net, |

[0001193125-23-120058:8k_2_02:50]
|  | • |  | Restructuring charges. |

[0001193125-23-120058:8k_2_02:51]
| (2) | Previously, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European portfolio and that we would continue to invest in our Heatcraft Worldwide Refrigeration business, all of which were previously in our Refrigeration segment. On January 1, 2023, we adjusted our segment presentation to better align with how the segments are managed and evaluated after the change in portfolio. Heatcraft Worldwide Refrigeration is now part of the Commercial segment while the European portfolio is presented with Corporate and Other until disposition. Amounts presented in this table have been recast to reflect the revised segment presentation. See “Recast Segment Results” in Appendix A for both the previously presented segment results as well as the recast financial information to reflect the change in segment presentation. |

[0001193125-23-120058:8k_2_02:52]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-120058:8k_2_02:53]
Consolidated Balance Sheets

[0001193125-23-120058:8k_2_02:54]
(Unaudited)

[0001193125-23-120058:8k_2_02:55]
| (Amounts in millions, except shares and par values) |  | As of March 31, 2023 |  |  | As of December 31, 2022 |  |
|  |  | (Unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 40.4 |  |  | $ | 52.6 |  |
| Short-term investments |  |  | 7.1 |  |  |  | 8.5 |  |
| Accounts and notes receivable, net of allowances of $16.8 and $15.5 in 2023 and 2022, respectively |  |  | 642.5 |  |  |  | 608.5 |  |
| Inventories, net |  |  | 904.1 |  |  |  | 753.0 |  |
| Other assets |  |  | 77.5 |  |  |  | 73.9 |  |
| Total current assets |  |  | 1,671.6 |  |  |  | 1,496.5 |  |
| Property, plant and equipment, net of accumulated depreciation of $938.9 and $920.8 in 2023 and 2022, respectively |  |  | 567.2 |  |  |  | 548.9 |  |
| Right-of-use assets from operating leases |  |  | 217.8 |  |  |  | 219.9 |  |
| Goodwill |  |  | 186.3 |  |  |  | 186.3 |  |
| Deferred income taxes |  |  | 34.0 |  |  |  | 27.5 |  |
| Other assets, net |  |  | 93.5 |  |  |  | 88.5 |  |
| Total assets |  | $ | 2,770.4 |  |  | $ | 2,567.6 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 657.5 |  |  | $ | 710.6 |  |
| Current operating lease liabilities |  |  | 63.8 |  |  |  | 63.3 |  |
| Accounts payable |  |  | 445.0 |  |  |  | 427.3 |  |
| Accrued expenses |  |  | 341.7 |  |  |  | 376.9 |  |
| Income taxes payable |  |  | 18.4 |  |  |  | 17.6 |  |
| Total current liabilities |  |  | 1,526.4 |  |  |  | 1,595.7 |  |
| Long-term debt |  |  | 1,010.1 |  |  |  | 814.2 |  |
| Long-term operating lease liabilities |  |  | 159.3 |  |  |  | 161.8 |  |
| Pensions |  |  | 39.7 |  |  |  | 40.1 |  |
| Other liabilities |  |  | 160.8 |  |  |  | 158.9 |  |
| Total liabilities |  |  | 2,896.3 |  |  |  | 2,770.7 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ deficit: |  |  |  |  |  |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,161.1 |  |  |  | 1,155.2 |  |
| Retained earnings |  |  | 3,130.9 |  |  |  | 3,070.6 |  |
| Accumulated other comprehensive loss |  |  | (78.6 | ) |  |  | (90.6 | ) |
| Treasury stock, at cost, 51,672,744 shares and 51,700,260 shares for 2023 and 2022, respectively |  |  | (4,340.2 | ) |  |  | (4,339.2 | ) |
| Total stockholders’ deficit |  |  | (125.9 | ) |  |  | (203.1 | ) |
| Total liabilities and stockholders’ deficit |  | $ | 2,770.4 |  |  | $ | 2,567.6 |  |

[0001193125-23-120058:8k_2_02:56]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-120058:8k_2_02:57]
Consolidated Statements of Cash Flows

[0001193125-23-120058:8k_2_02:58]
(Unaudited)

[0001193125-23-120058:8k_2_02:59]
| (Amounts in millions) |  | For the Three MonthsEnded March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 98.0 |  |  | $ | 83.6 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| (Income) loss from equity method investments |  |  | (0.7 | ) |  |  | 0.1 |  |
| Restructuring charges, net of cash paid |  |  | — |  |  |  | 0.5 |  |
| Provision for credit losses |  |  | 2.0 |  |  |  | 1.4 |  |
| Unrealized losses, net on derivative contracts |  |  | 1.6 |  |  |  | 0.1 |  |
| Stock-based compensation expense |  |  | 6.1 |  |  |  | 4.7 |  |
| Depreciation and amortization |  |  | 19.6 |  |  |  | 18.8 |  |
| Deferred income taxes |  |  | (8.2 | ) |  |  | (5.3 | ) |
| Pension expense |  |  | 0.7 |  |  |  | 1.4 |  |
| Pension contributions |  |  | (1.2 | ) |  |  | (0.1 | ) |
| Other items, net |  |  | (0.3 | ) |  |  | (0.9 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (34.9 | ) |  |  | (96.9 | ) |
| Inventories |  |  | (150.4 | ) |  |  | (168.8 | ) |
| Other current assets |  |  | 1.2 |  |  |  | 1.1 |  |
| Accounts payable |  |  | 22.3 |  |  |  | 67.5 |  |
| Accrued expenses |  |  | (32.5 | ) |  |  | (33.0 | ) |
| Income taxes payable and receivable, net |  |  | 0.8 |  |  |  | 20.8 |  |
| Leases, net |  |  | 0.1 |  |  |  | 0.5 |  |
| Other, net |  |  | (3.0 | ) |  |  | 6.6 |  |
| Net cash used in operating activities |  |  | (78.8 | ) |  |  | (97.9 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.3 |  |  |  | 0.3 |  |
| Purchases of property, plant and equipment |  |  | (35.4 | ) |  |  | (25.8 | ) |
| Proceeds from (purchases of) short-term investments, net |  |  | 1.4 |  |  |  | (0.2 | ) |
| Net cash used in investing activities |  |  | (33.7 | ) |  |  | (25.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Asset securitization borrowings |  |  | — |  |  |  | 90.0 |  |
| Asset securitization payments |  |  | (53.0 | ) |  |  | (61.0 | ) |
| Long-term debt payments |  |  | (3.2 | ) |  |  | (3.2 | ) |
| Borrowings from credit facility |  |  | 610.5 |  |  |  | 722.5 |  |
| Payments on credit facility |  |  | (414.5 | ) |  |  | (381.5 | ) |
| Proceeds from employee stock purchases |  |  | 0.9 |  |  |  | 0.9 |  |
| Repurchases of common stock |  |  | — |  |  |  | (200.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (2.0 | ) |  |  | (4.9 | ) |
| Cash dividends paid |  |  | (37.6 | ) |  |  | (33.7 | ) |
| Net cash provided by financing activities |  |  | 101.1 |  |  |  | 129.1 |  |
| (Decrease) increase in cash and cash equivalents |  |  | (11.4 | ) |  |  | 5.5 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (0.8 | ) |  |  | (2.2 | ) |
| Cash and cash equivalents, beginning of period |  |  | 52.6 |  |  |  | 31.0 |  |
| Cash and cash equivalents, end of period |  | $ | 40.4 |  |  | $ | 34.3 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 13.0 |  |  | $ | 5.8 |  |
| Income taxes paid (net of refunds) |  | $ | 34.4 |  |  | $ | 5.2 |  |

[0001193125-23-120058:8k_2_02:60]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-120058:8k_2_02:61]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-23-120058:8k_2_02:62]
(Unaudited, in millions, except per share and ratio data)

[0001193125-23-120058:8k_2_02:63]
Use of Non-GAAP Financial Measures

[0001193125-23-120058:8k_2_02:64]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company’s business trends and operating performance.

[0001193125-23-120058:8k_2_02:65]
In November 2022, we announced the decision to explore strategic alternatives for our European portfolio. The results from operations for these businesses
have been shown in the tables below as “Non-Core business results.” The prior period results have been updated to provide period-over-period comparability.

[0001193125-23-120058:8k_2_02:66]
Reconciliation of Net income, a GAAP measure, to Adjusted Net income, a Non-GAAP measure

[0001193125-23-120058:8k_2_02:67]
|  |  | For the Three Months Ended March 31,(Unaudited) |  |
|  |  | 2023 |  |  | 2022 |  |
|  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |
| Net income, a GAAP measure |  | $ | 125.1 |  |  | $ | (27.1 | ) |  | $ | 98.0 |  |  | $ | 104.4 |  |  | $ | (20.8 | ) |  | $ | 83.6 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 0.4 |  |
| Pension settlements |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  | 2.2 |  |  |  | (1.3 | ) |  |  | 0.9 |  |  |  | 2.2 |  |  |  | (0.7 | ) |  |  | 1.5 |  |
| Excess tax expense from share-based compensation (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.5 |  |  |  | 0.5 |  |
| Non-core business results (d) |  |  | 0.4 |  |  |  | 1.0 |  |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 0.3 |  |  |  | 3.8 |  |
| Adjusted net income, a non-GAAP measure |  | $ | 127.9 |  |  | $ | (27.4 | ) |  | $ | 100.5 |  |  | $ | 110.7 |  |  | $ | (20.8 | ) |  | $ | 89.9 |  |
| Earnings per share - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.75 |  |  |  |  |  |  |  |  |  |  | $ | 2.29 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.04 |  |
| Excess tax expense from share-based compensation (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Non-core business results (d) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | 0.11 |  |
| Adjusted earnings per share - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.83 |  |  |  |  |  |  |  |  |  |  | $ | 2.47 |  |

[0001193125-23-120058:8k_2_02:68]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-23-120058:8k_2_02:69]
| (b) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-23-120058:8k_2_02:70]
| (c) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-23-120058:8k_2_02:71]
| (d) | Non-core business results represent activity related to our business operations in Europe not included elsewhere in the reconciliations |

[0001193125-23-120058:8k_2_02:72]
Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares
Outstanding - Diluted, a Non-GAAP measure (shares in millions):

[0001193125-23-120058:8k_2_02:73]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Average shares outstanding - diluted, a GAAP measure |  |  | 35.6 |  |  |  | 36.5 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | — |  |  |  | (0.1 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure |  |  | 35.6 |  |  |  | 36.4 |  |

[0001193125-23-120058:8k_2_02:74]
Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-23-120058:8k_2_02:75]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net cash used in operating activities, a GAAP measure |  | $ | (78.8 | ) |  | $ | (97.9 | ) |
| Purchases of property, plant and equipment |  |  | (35.4 | ) |  |  | (25.8 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.3 |  |  |  | 0.3 |  |
| Free cash flow, a Non-GAAP measure |  | $ | (113.9 | ) |  | $ | (123.4 | ) |

[0001193125-23-120058:8k_2_02:76]
Reconciliation of Net sales, a GAAP measure to Core net sales, a Non-GAAP measure

[0001193125-23-120058:8k_2_02:77]
|  |  | For the Three Months Ended March 31, |  |
|  |  | Corporate and other |  |  | Consolidated |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net sales, a GAAP measure |  | $ | 59.7 |  |  | $ | 51.7 |  |  | $ | 1,049.4 |  |  | $ | 1,013.4 |  |
| Net sales from non-core businesses (a) |  |  | (59.7 | ) |  |  | (51.7 | ) |  |  | (59.7 | ) |  |  | (51.7 | ) |
| Core net sales, a Non-GAAP measure |  | $ | — |  |  | $ | — |  |  | $ | 989.7 |  |  | $ | 961.7 |  |

[0001193125-23-120058:8k_2_02:78]
| (a) | Non-Core businesses represent our business operations in Europe |

[0001193125-23-120058:8k_2_02:79]
Reconciliation of Segment profit, a Non-GAAP measure to Adjusted Segment profit, a Non-GAAP measure

[0001193125-23-120058:8k_2_02:80]
|  |  | For the Three Months Ended March 31, |  |
|  |  | Corporate and other |  |  | Consolidated |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Segment profit, a Non-GAAP measure |  | $ | (19.4 | ) |  | $ | (16.8 | ) |  | $ | 141.7 |  |  | $ | 114.6 |  |
| Loss from non-core businesses (a) |  |  | 0.4 |  |  |  | 3.4 |  |  |  | 0.4 |  |  |  | 3.4 |  |
| Adjusted Segment profit, a Non-GAAP measure |  | $ | (19.0 | ) |  | $ | (13.4 | ) |  | $ | 142.1 |  |  | $ | 118.0 |  |

[0001193125-23-120058:8k_2_02:81]
| (a) | Non-Core businesses represent our business operations in Europe |

[0001193125-23-120058:8k_2_02:82]
Appendix A

[0001193125-23-120058:8k_2_02:83]
Recast Segment Results

[0001193125-23-120058:8k_2_02:84]
The following tables
present the previously reported and recast financial results reflecting the change in segment reporting.

[0001193125-23-120058:8k_2_02:85]
|  |  | Q1 2022 |  |  | Q2 2022 |  |  | Q3 2022 |  |  | Q4 2022 |  |  | 2022 |  |
|  |  | AsReported |  |  | AsAdjusted |  |  | AsReported |  |  | AsAdjusted |  |  | AsReported |  |  | AsAdjusted |  |  | AsReported |  |  | AsAdjusted |  |  | AsReported |  |  | AsAdjusted |  |
| Residential segment net sales |  | $ | 682.2 |  |  | $ | 682.2 |  |  | $ | 977.5 |  |  | $ | 977.5 |  |  | $ | 835.3 |  |  | $ | 835.3 |  |  | $ | 703.4 |  |  | $ | 703.4 |  |  | $ | 3,198.3 |  |  | $ | 3,198.3 |  |
| Residential segment profit |  | $ | 107.6 |  |  | $ | 107.6 |  |  | $ | 216.3 |  |  | $ | 216.3 |  |  | $ | 153.8 |  |  | $ | 153.8 |  |  | $ | 119.2 |  |  | $ | 119.2 |  |  | $ | 596.9 |  |  | $ | 596.9 |  |
| Commercial segment net sales |  | $ | 187.7 |  |  | $ | 279.5 |  |  | $ | 219.6 |  |  | $ | 327.4 |  |  | $ | 252.9 |  |  | $ | 352.3 |  |  | $ | 240.5 |  |  | $ | 327.2 |  |  | $ | 900.7 |  |  | $ | 1,286.4 |  |
| Commercial segment profit |  | $ | 6.3 |  |  | $ | 23.8 |  |  | $ | 17.2 |  |  | $ | 41.2 |  |  | $ | 29.6 |  |  | $ | 52.4 |  |  | $ | 27.9 |  |  | $ | 45.6 |  |  | $ | 80.9 |  |  | $ | 163.0 |  |
| Refrigeration segment net sales |  | $ | 143.5 |  |  | $ | — |  |  | $ | 169.2 |  |  | $ | — |  |  | $ | 156.7 |  |  | $ | — |  |  | $ | 149.9 |  |  | $ | — |  |  | $ | 619.4 |  |  | $ | — |  |
| Refrigeration segment profit |  | $ | 14.1 |  |  | $ | — |  |  | $ | 23.4 |  |  | $ | — |  |  | $ | 22.4 |  |  | $ | — |  |  | $ | 18.8 |  |  | $ | — |  |  | $ | 78.8 |  |  | $ | — |  |
| Corporate net sales |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net sales from European operations |  | $ | — |  |  | $ | 51.7 |  |  | $ | — |  |  | $ | 61.4 |  |  | $ | — |  |  | $ | 57.3 |  |  | $ | — |  |  | $ | 63.2 |  |  | $ | — |  |  | $ | 233.7 |  |
| Corporate and other net sales |  | $ | — |  |  | $ | 51.7 |  |  | $ | — |  |  | $ | 61.4 |  |  | $ | — |  |  | $ | 57.3 |  |  | $ | — |  |  | $ | 63.2 |  |  | $ | — |  |  | $ | 233.7 |  |
| Corporate costs |  | $ | (13.4 | ) |  | $ | (13.4 | ) |  | $ | (27.1 | ) |  | $ | (27.1 | ) |  | $ | (16.5 | ) |  | $ | (16.5 | ) |  | $ | (33.7 | ) |  | $ | (33.7 | ) |  | $ | (90.8 | ) |  | $ | (90.8 | ) |
| Segment profit from European operations |  | $ | — |  |  | $ | (3.4 | ) |  | $ | — |  |  | $ | (0.6 | ) |  | $ | — |  |  | $ | (0.4 | ) |  | $ | — |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | (3.3 | ) |
| Corporate and other segment profit |  | $ | (13.4 | ) |  | $ | (16.8 | ) |  | $ | (27.1 | ) |  | $ | (27.7 | ) |  | $ | (16.5 | ) |  | $ | (16.9 | ) |  | $ | (33.7 | ) |  | $ | (32.6 | ) |  | $ | (90.8 | ) |  | $ | (94.1 | ) |
| LII net sales |  | $ | 1,013.4 |  |  | $ | 1,013.4 |  |  | $ | 1,366.3 |  |  | $ | 1,366.3 |  |  | $ | 1,244.9 |  |  | $ | 1,244.9 |  |  | $ | 1,093.8 |  |  | $ | 1,093.8 |  |  | $ | 4,718.4 |  |  | $ | 4,718.4 |  |
| LII total segment profit |  | $ | 114.6 |  |  | $ | 114.6 |  |  | $ | 229.8 |  |  | $ | 229.8 |  |  | $ | 189.3 |  |  | $ | 189.3 |  |  | $ | 132.2 |  |  | $ | 132.2 |  |  | $ | 665.8 |  |  | $ | 665.8 |  |

[0001193125-23-120058:8k_2_02:86]
|  |  | Q1 2021 |  |  | Q2 2021 |  |  | Q3 2021 |  |  | Q4 2021 |  |  | 2021 |  |
|  |  | AsReported |  |  | AsAdjusted |  |  | AsReported |  |  | AsAdjusted |  |  | AsReported |  |  | AsAdjusted |  |  | AsReported |  |  | AsAdjusted |  |  | AsReported |  |  | AsAdjusted |  |
| Residential segment net sales |  | $ | 606.3 |  |  | $ | 606.3 |  |  | $ | 838.0 |  |  | $ | 838.0 |  |  | $ | 711.0 |  |  | $ | 711.0 |  |  | $ | 620.3 |  |  | $ | 620.3 |  |  | $ | 2,775.6 |  |  | $ | 2,775.6 |  |
| Residential segment profit |  | $ | 96.4 |  |  | $ | 96.4 |  |  | $ | 189.7 |  |  | $ | 189.7 |  |  | $ | 144.0 |  |  | $ | 144.0 |  |  | $ | 110.3 |  |  | $ | 110.3 |  |  | $ | 540.3 |  |  | $ | 540.3 |  |
| Commercial segment net sales |  | $ | 199.2 |  |  | $ | 274.8 |  |  | $ | 252.8 |  |  | $ | 335.0 |  |  | $ | 211.5 |  |  | $ | 292.7 |  |  | $ | 201.4 |  |  | $ | 286.3 |  |  | $ | 864.8 |  |  | $ | 1,188.8 |  |
| Commercial segment profit |  | $ | 27.4 |  |  | $ | 39.6 |  |  | $ | 45.3 |  |  | $ | 58.9 |  |  | $ | 22.6 |  |  | $ | 36.3 |  |  | $ | 15.6 |  |  | $ | 29.8 |  |  | $ | 110.9 |  |  | $ | 164.6 |  |
| Refrigeration segment net sales |  | $ | 125.0 |  |  | $ | — |  |  | $ | 148.2 |  |  | $ | — |  |  | $ | 137.4 |  |  | $ | — |  |  | $ | 143.1 |  |  | $ | — |  |  | $ | 553.7 |  |  | $ | — |  |
| Refrigeration segment profit |  | $ | 7.9 |  |  | $ | — |  |  | $ | 13.5 |  |  | $ | — |  |  | $ | 14.5 |  |  | $ | — |  |  | $ | 13.2 |  |  | $ | — |  |  | $ | 49.1 |  |  | $ | — |  |
| Corporate net sales |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net sales from European operations |  | $ | — |  |  | $ | 49.4 |  |  | $ | — |  |  | $ | 66.0 |  |  | $ | — |  |  | $ | 56.2 |  |  | $ | — |  |  | $ | 58.2 |  |  | $ | — |  |  | $ | 229.7 |  |
| Corporate and other net sales |  | $ | — |  |  | $ | 49.4 |  |  | $ | — |  |  | $ | 66.0 |  |  | $ | — |  |  | $ | 56.2 |  |  | $ | — |  |  | $ | 58.2 |  |  | $ | — |  |  | $ | 229.7 |  |
| Corporate costs |  | $ | (16.0 | ) |  | $ | (16.0 | ) |  | $ | (26.9 | ) |  | $ | (26.9 | ) |  | $ | (16.3 | ) |  | $ | (16.3 | ) |  | $ | (37.2 | ) |  | $ | (37.2 | ) |  | $ | (96.4 | ) |  | $ | (96.4 | ) |
| Segment profit from European operations |  | $ | — |  |  | $ | (4.3 | ) |  | $ | — |  |  | $ | (0.1 | ) |  | $ | — |  |  | $ | 0.8 |  |  | $ | — |  |  | $ | (1.0 | ) |  | $ | — |  |  | $ | (4.6 | ) |
| Corporate and other segment profit |  | $ | (16.0 | ) |  | $ | (20.3 | ) |  | $ | (26.9 | ) |  | $ | (27.0 | ) |  | $ | (16.3 | ) |  | $ | (15.5 | ) |  | $ | (37.2 | ) |  | $ | (38.2 | ) |  | $ | (96.4 | ) |  | $ | (101.0 | ) |
| LII net sales |  | $ | 930.5 |  |  | $ | 930.5 |  |  | $ | 1,239.0 |  |  | $ | 1,239.0 |  |  | $ | 1,059.9 |  |  | $ | 1,059.9 |  |  | $ | 964.8 |  |  | $ | 964.8 |  |  | $ | 4,194.1 |  |  | $ | 4,194.1 |  |
| LII total segment profit |  | $ | 115.7 |  |  | $ | 115.7 |  |  | $ | 221.6 |  |  | $ | 221.6 |  |  | $ | 164.8 |  |  | $ | 164.8 |  |  | $ | 101.9 |  |  | $ | 101.9 |  |  | $ | 603.9 |  |  | $ | 603.9 |  |
