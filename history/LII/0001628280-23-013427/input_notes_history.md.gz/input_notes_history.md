# LII note change history — 0001628280-22-027168 → 0001628280-23-013427


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0001628280-23-013427:note_history:1]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To
  (was, 2022-10-27, similarity 0.802):
[0001628280-22-027168:note_history:1]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

- added (2023-04-27):
[0001628280-23-013427:note_history:2]
estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

- changed (2023-04-27):
[0001628280-23-013427:note_history:3]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Accrued expenses | $ | 42.3 |  |  | $ | 41.3 |  |
| Other liabilities | 103.0 |  |  | 101.4 |  |
| Total warranty liability | $ | 145.3 |  |  | $ | 142.7 |  |
  (was, 2022-10-27, similarity 0.9716):
[0001628280-22-027168:note_history:3]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Accrued expenses | $ | 39.8 |  |  | $ | 37.2 |  |
| Other liabilities | 110.4 |  |  | 97.0 |  |
| Total warranty liability | $ | 150.2 |  |  | $ | 134.2 |  |

- changed (2023-04-27):
[0001628280-23-013427:note_history:4]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2023 were as follows (in millions):
  (was, 2022-10-27, similarity 0.9416):
[0001628280-22-027168:note_history:4]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2022 were as follows (in millions):

- changed (2023-04-27):
[0001628280-23-013427:note_history:5]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Warranty claims paid | (8.0) |  |
| Changes resulting from issuance of new warranties | 11.1 |  |
| Changes in estimates associated with pre-existing liabilities | (0.6) |  |
| Changes in foreign currency translation rates and other | 0.1 |  |
| Total warranty liability as of March 31, 2023 | $ | 145.3 |  |
  (was, 2022-10-27, similarity 0.7003):
[0001628280-22-027168:note_history:5]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Warranty claims paid | (27.1) |  |
| Changes resulting from issuance of new warranties | 41.8 |  |
| Changes in estimates associated with pre-existing liabilities | 2.7 |  |
| Changes in foreign currency translation rates and other | (1.4) |  |
| Total warranty liability as of September 30, 2022 | $ | 150.2 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0001628280-23-013427:note_history:6]
References in this Quarterly Report on Form 10-Q to "we","our","us","LII" or the "Company" refer to Lennox International Inc. and its subsidiaries, unless the context requires otherwise.
  (was, 2022-10-27, similarity 0.9733):
[0001628280-22-027168:note_history:6]
References in this Quarterly Report on Form 10-Q to "we," "our," "us," "LII," or the "Company" refer to Lennox International Inc. and its subsidiaries, unless the context requires otherwise.

- changed (2023-04-27):
[0001628280-23-013427:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2023, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2023 and 2022, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2023 and 2022, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2023 and 2022 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2022.
  (was, 2022-10-27, similarity 0.8524):
[0001628280-22-027168:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2022, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2022 and 2021, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2022 and 2021 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2021.

- changed (2023-04-27):
[0001628280-23-013427:note_history:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.
  (was, 2022-10-27, similarity 0.6878):
[0001628280-22-027168:note_history:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

- removed (2023-04-27):
[0001628280-22-027168:note_history:9]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.

- removed (2023-04-27):
[0001628280-22-027168:note_history:10]
Impact of COVID-19 Pandemic

- removed (2023-04-27):
[0001628280-22-027168:note_history:11]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations since 2020. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows. 
Executive Leadership TransitionOn March 23, 2022, the Board of Directors appointed Alok Maskara as Chief Executive Officer ("CEO") effective May 9, 2022.  Mr. Maskara succeeded Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and served as interim CEO until Mr. Maskara assumed the role on May 9, 2022.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0001628280-23-013427:note_history:12]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.06 | % |  | 5.57 | % |
  (was, 2022-10-27, similarity 0.95):
[0001628280-22-027168:note_history:12]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 4.21 | % |  | 1.38 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-04-27):
[0001628280-23-013427:note_history:13]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 297.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 10.9 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.4) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 657.5 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 28.3 |  |
| Credit agreement | 388.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.7) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,010.1 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,667.6 |  |  | $ | 1,524.8 |  |

- changed (2023-04-27):
[0001628280-23-013427:note_history:14]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2023 or December 31, 2022 and there were no borrowings or repayments on these facilities during the three months ended March 31, 2023.
  (was, 2022-10-27, similarity 0.727):
[0001628280-22-027168:note_history:14]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2022 or December 31, 2021 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2022.

- added (2023-04-27):
[0001628280-23-013427:note_history:15]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 297.3 |  |  | $ | 350.0 |  |
| Less: Beneficial interest transferred | (297.0) |  |  | (350.0) |  |
| Remaining amount available | $ | 0.3 |  |  | $ | — |  |

- changed (2023-04-27):
[0001628280-23-013427:note_history:16]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2023 and December 31, 2022 were 5.58% and 5.17%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2022-10-27, similarity 0.9913):
[0001628280-22-027168:note_history:16]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2022 and December 31, 2021 were 3.85% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2023-04-27):
[0001628280-23-013427:note_history:17]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of March 31, 2023, we believe we were in compliance with all covenant requirements.
  (was, 2022-10-27, similarity 0.9865):
[0001628280-22-027168:note_history:17]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of September 30, 2022, we believe we were in compliance with all covenant requirements.

- changed (2023-04-27):
[0001628280-23-013427:note_history:18]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.
  (was, 2022-10-27, similarity 0.9203):
[0001628280-22-027168:note_history:18]
In July 2021, we entered into a new domestic credit facility (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

- changed (2023-04-27):
[0001628280-23-013427:note_history:19]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $388.0 million as well as $2.0 million committed to standby letters of credit as of March 31, 2023. Subject to covenant limitations, $360.0 million was available for future borrowings.  The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.
  (was, 2022-10-27, similarity 0.9137):
[0001628280-22-027168:note_history:19]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $222.0 million as well as $2.0 million committed to standby letters of credit as of September 30, 2022. Subject to covenant limitations, $526.0 million was available for future borrowings.  The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

- changed (2023-04-27):
[0001628280-23-013427:note_history:20]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.06 | % |  | 5.57 | % |
  (was, 2022-10-27, similarity 0.95):
[0001628280-22-027168:note_history:20]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 4.21 | % |  | 1.38 | % |

- added (2023-04-27):
[0001628280-23-013427:note_history:21]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or

- changed (2023-04-27):
[0001628280-23-013427:note_history:22]
substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).
  (was, 2022-10-27, similarity 0.7372):
[0001628280-22-027168:note_history:22]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

- changed (2023-04-27):
[0001628280-23-013427:note_history:23]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2023, we believe we were in compliance with all covenant requirements.
  (was, 2022-10-27, similarity 0.987):
[0001628280-22-027168:note_history:23]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2022, we believe we were in compliance with all covenant requirements.

- changed (2023-04-27):
[0001628280-23-013427:note_history:24]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2023, we believe we were in compliance with all covenant requirements.
  (was, 2022-10-27, similarity 0.9946):
[0001628280-22-027168:note_history:24]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2022, we believe we were in compliance with all covenant requirements.

- removed (2023-04-27):
[0001628280-22-027168:note_history:25]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.1 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 28.6 |  |  | 29.0 |  |
| Credit agreement | 222.0 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.2) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,593.4 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,604.5 |  |  | $ | 1,237.8 |  |

- removed (2023-04-27):
[0001628280-22-027168:note_history:26]
Short-Term Debt

- removed (2023-04-27):
[0001628280-22-027168:note_history:27]
Long-Term Debt

- removed (2023-04-27):
[0001628280-22-027168:note_history:28]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 443.3 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (400.0) |  |  | (250.0) |  |
| Remaining amount available | $ | 43.3 |  |  | $ | 85.6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-04-27):
[0001628280-23-013427:note_history:29]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 297.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 10.9 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.4) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 657.5 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 28.3 |  |
| Credit agreement | 388.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.7) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,010.1 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,667.6 |  |  | $ | 1,524.8 |  |

- removed (2023-04-27):
[0001628280-22-027168:note_history:30]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.1 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 28.6 |  |  | 29.0 |  |
| Credit agreement | 222.0 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.2) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,593.4 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,604.5 |  |  | $ | 1,237.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0001628280-23-013427:note_history:31]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.  All amount presented reflect the revised segment presentation.
  (was, 2022-10-27, similarity 0.8941):
[0001628280-22-027168:note_history:31]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.

- added (2023-04-27):
[0001628280-23-013427:note_history:32]
|  | For the Three Months Ended March 31, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 639.3 |  |  | $ | 294.6 |  |  | $ | — |  |  | $ | 933.9 |  |
| Canada | 41.7 |  |  | 14.1 |  |  | — |  |  | 55.8 |  |
| Other international | — |  |  | — |  |  | 59.7 |  |  | 59.7 |  |
| Total | $ | 681.0 |  |  | $ | 308.7 |  |  | $ | 59.7 |  |  | $ | 1,049.4 |  |

- added (2023-04-27):
[0001628280-23-013427:note_history:33]
|  | For the Three Months Ended March 31,2022 (1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 629.7 |  |  | $ | 268.6 |  |  | $ | — |  |  | $ | 898.3 |  |
| Canada | 52.5 |  |  | 10.4 |  |  | — |  |  | 62.9 |  |
| Other international | — |  |  | 0.5 |  |  | 51.7 |  |  | 52.2 |  |
| Total | $ | 682.2 |  |  | $ | 279.5 |  |  | $ | 51.7 |  |  | $ | 1,013.4 |  |

- added (2023-04-27):
[0001628280-23-013427:note_history:34]
(1) As discussed in Note 2, we adjusted our segment reporting to include the results of our Heatcraft businesses in Commercial and the results of our European portfolio in Corporate and Other.  The amounts for the three months ended March 31, 2022 have been recast to reflect the revised segment presentation.

- changed (2023-04-27):
[0001628280-23-013427:note_history:35]
Residential - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2023 and 2022, direct sales represented 70% and 66% of revenues, and sales to independent distributors represented the remainder.
  (was, 2022-10-27, similarity 0.8832):
[0001628280-22-027168:note_history:35]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2022 and 2021, direct sales represented 72% and 73% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2022 and 2021, direct sales represented 70% and 72% of revenues, and sales to independent distributors represented the remainder.

- added (2023-04-27):
[0001628280-23-013427:note_history:36]
Commercial - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended March 31, 2023 and 2022, equipment sales represented 85% and 87% of revenues and the remainder of our revenue was generated from our service business.

- added (2023-04-27):
[0001628280-23-013427:note_history:37]
Corporate and Other - In Europe, we manufacture and market equipment for the global commercial refrigeration markets.  We also manufacture and sell unitary heating and cooling products and applied systems.   A de minimis amount of segment revenue relates to services for start-up and commissioning activities.

- added (2023-04-27):
[0001628280-23-013427:note_history:38]
|  | March 31, 2023 |  | December 31, 2022 |  |  |  |  |
| Contract liabilities - current | $ | (12.5) |  |  | $ | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (6.7) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (19.2) |  |  | $ | (16.0) |  |  |  |  |  |

- changed (2023-04-27):
[0001628280-23-013427:note_history:39]
For the three months ended March 31, 2023 and 2022, we recognized revenue of $3.0 million and $3.7 million related to our contract liabilities at January 1, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2023 and 2022.
  (was, 2022-10-27, similarity 0.8154):
[0001628280-22-027168:note_history:39]
For the three months ended September 30, 2022 and 2021, we recognized revenue of $3.6 million and $0.6 million and for the nine months ended September 30, 2022 and 2021 we recognized revenue of $9.5 million and $2.9 million related to our contract liabilities at January 1, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2022 and 2021.

- removed (2023-04-27):
[0001628280-22-027168:note_history:40]
|  | For the Three Months Ended September 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 779.8 |  |  | $ | 232.5 |  |  | $ | 99.4 |  |  | $ | 1,111.7 |  |
| Canada | 55.5 |  |  | 20.3 |  |  | — |  |  | 75.8 |  |
| Other international | — |  |  | 0.1 |  |  | 57.3 |  |  | 57.4 |  |
| Total | $ | 835.3 |  |  | $ | 252.9 |  |  | $ | 156.7 |  |  | $ | 1,244.9 |  |

- removed (2023-04-27):
[0001628280-22-027168:note_history:41]
|  | For the Three Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 655.0 |  |  | $ | 194.0 |  |  | $ | 81.2 |  |  | $ | 930.2 |  |
| Canada | 56.0 |  |  | 16.8 |  |  | — |  |  | 72.8 |  |
| Other international | — |  |  | 0.7 |  |  | 56.2 |  |  | 56.9 |  |
| Total | $ | 711.0 |  |  | $ | 211.5 |  |  | $ | 137.4 |  |  | $ | 1,059.9 |  |

- removed (2023-04-27):
[0001628280-22-027168:note_history:42]
|  | For the Nine Months Ended September 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,311.2 |  |  | $ | 616.4 |  |  | $ | 299.0 |  |  | $ | 3,226.6 |  |
| Canada | 183.7 |  |  | 43.2 |  |  | — |  |  | 226.9 |  |
| Other international | — |  |  | 0.6 |  |  | 170.5 |  |  | 171.1 |  |
| Total | $ | 2,494.9 |  |  | $ | 660.2 |  |  | $ | 469.5 |  |  | $ | 3,624.6 |  |

- removed (2023-04-27):
[0001628280-22-027168:note_history:43]
|  | For the Nine Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,976.8 |  |  | $ | 605.0 |  |  | $ | 239.1 |  |  | $ | 2,820.9 |  |
| Canada | 178.5 |  |  | 57.6 |  |  | — |  |  | 236.1 |  |
| Other international | — |  |  | 0.8 |  |  | 171.5 |  |  | 172.3 |  |
| Total | $ | 2,155.3 |  |  | $ | 663.4 |  |  | $ | 410.6 |  |  | $ | 3,229.3 |  |

- removed (2023-04-27):
[0001628280-22-027168:note_history:44]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.   Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended September 30, 2022 and 2021, equipment sales represented 83% and 81% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2022 and 2021, equipment sales represented 82% and 83% of revenues and the remainder of our revenue was generated from our service business.

- removed (2023-04-27):
[0001628280-22-027168:note_history:45]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems.   Less than 1% of segment revenue relates to services for start-up and commissioning activities.

- removed (2023-04-27):
[0001628280-22-027168:note_history:46]
|  | September 30, 2022 |  | December 31, 2021 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (11.8) |  |  | $ | (10.2) |  |  | $ | (1.6) |  |  | 15.7 | % |
| Contract liabilities - noncurrent | (6.0) |  |  | (5.5) |  |  | (0.5) |  |  | 9.1 | % |
| Total | $ | (17.8) |  |  | $ | (15.7) |  |  | $ | (2.1) |  |  |  |
