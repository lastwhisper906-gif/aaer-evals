# LII note change history — 0001069202-18-000013 → 0001069202-18-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-10-22):
[0001069202-18-000020:note_history:1]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 36.6 |  |  | $ | 34.8 |  |
| Other liabilities | 73.6 |  |  | 75.1 |  |
| Total warranty liability | $ | 110.2 |  |  | $ | 109.9 |  |
  (was, 2018-07-23, similarity 0.9687):
[0001069202-18-000013:note_history:1]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 35.0 |  |  | $ | 34.8 |  |
| Other liabilities | 75.4 |  |  | 75.1 |  |
| Total warranty liability | $ | 110.4 |  |  | $ | 109.9 |  |

- changed (2018-10-22):
[0001069202-18-000020:note_history:2]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2018 were as follows (in millions):
  (was, 2018-07-23, similarity 0.9444):
[0001069202-18-000013:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2018 were as follows (in millions):

- changed (2018-10-22):
[0001069202-18-000020:note_history:3]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (23.9 | ) |
| Changes resulting from issuance of new warranties | 29.0 |  |
| Changes in estimates associated with pre-existing liabilities | (3.1 | ) |
| Changes in foreign currency translation rates and other | (0.4 | ) |
| Warranty liability from Divestitures | (1.3 | ) |
| Total warranty liability as of September 30, 2018 | $ | 110.2 |  |
  (was, 2018-07-23, similarity 0.8267):
[0001069202-18-000013:note_history:3]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (21.7 | ) |
| Changes resulting from issuance of new warranties | 24.2 |  |
| Changes in estimates associated with pre-existing liabilities | (3.3 | ) |
| Changes in foreign currency translation rates and other | 2.7 |  |
| Warranty liability from assets held for sale | (1.4 | ) |
| Total warranty liability as of June 30, 2018 | $ | 110.4 |  |

- changed (2018-10-22):
[0001069202-18-000020:note_history:4]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2018 and 2017, expense for asbestos-related litigation was $3.3 million and $3.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.  For the three months ended  September 30, 2018 and 2017, expense for asbestos-related litigation was $1.4 million and $1.5 million, respectively, net of probable insurance recoveries.
  (was, 2018-07-23, similarity 0.9661):
[0001069202-18-000013:note_history:4]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2018 and 2017, expense for asbestos-related litigation was $1.9 million and $2.4 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations. For the three months ended  June 30, 2018 and 2017,  expense for asbestos-related litigation was $(0.2) million and $0.7 million, respectively, net of probable insurance recoveries.

- added (2018-10-22):
[0001069202-18-000020:note_history:5]
Marshalltown Tornado and Recovery

- added (2018-10-22):
[0001069202-18-000020:note_history:6]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the full amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Loss from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations.

- added (2018-10-22):
[0001069202-18-000020:note_history:7]
The following table summarizes the loss from natural disaster, net of insurance recoveries:

- added (2018-10-22):
[0001069202-18-000020:note_history:8]
| (Amounts in millions) | For the Nine Months Ended September 30, 2018 |
| Write-off of property, plant and equipment | $ | 4.2 |  |
| Write-off of inventory | 5.2 |  |
| Site clean-up and remediation | 28.4 |  |
| Factory inefficiencies due to lower productivity | 4.9 |  |
| Other | 6.7 |  |
| Total expense | 49.4 |  |
| Insurance recoveries received | 45.0 |  |
| Insurance recoveries receivable (1) | 4.1 |  |
| Loss from natural disaster, net of insurance recoveries | $ | 0.3 |  |

- added (2018-10-22):
[0001069202-18-000020:note_history:9]
(1) The insurance recoveries receivable is recorded in Other assets in the Consolidated Balance Sheets.

- removed (2018-10-22):
[0001069202-18-000013:note_history:10]
In October 2016, we self-reported to the Securities and Exchange Commission ("SEC") and the Department of Justice ("DOJ") an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We concluded our investigation and communicated our findings to the SEC and the DOJ. We fully cooperated with the SEC and the DOJ regarding this matter. The  DOJ has declined to prosecute this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-10-22):
[0001069202-18-000020:note_history:11]
The accompanying unaudited Consolidated Balance Sheet as of  September 30, 2018, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2018-07-23, similarity 0.9487):
[0001069202-18-000013:note_history:11]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2018, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2018-10-22):
[0001069202-18-000020:note_history:12]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.  We will adopt the standard using the prospective approach.  We have completed a qualitative and quantitative assessment of our lease portfolio and are in the process of testing our new lease accounting system, collecting data for leases entered into during 2018 and implementing new processes and controls to account for our leases in accordance with the new standard.  Upon adoption, we expect to record right-of-use assets and operating lease liabilities between $150 million and $200 million in our Consolidated Balance Sheet.
  (was, 2018-07-23, similarity 0.7972):
[0001069202-18-000013:note_history:12]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.  We will adopt the standard using the prospective approach.  We have completed a qualitative assessment of our lease portfolio and are in the process of implementing a new system, collecting data and designing processes and controls to account for our leases in accordance with the new standard.

- added (2018-10-22):
[0001069202-18-000020:note_history:13]
In August 2018, the SEC issued Release No. 33-10532 that amends and clarifies certain financial reporting requirements.  The principal change to our financial reporting will be the inclusion of the annual disclosure requirement of changes in stockholders’ equity in Rule 3-04 of Regulation S-X to interim periods.  We will adopt this new rule beginning with our financial reporting for the quarter ended March 31, 2019.  Upon adoption, we will include our Consolidated Statements of Stockholders' Equity with each quarterly filing on Form 10-Q.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-10-22):
[0001069202-18-000020:note_history:14]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.41 | % |  | 2.76 | % |
  (was, 2018-07-23, similarity 0.9447):
[0001069202-18-000013:note_history:14]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.27 | % |  | 2.76 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-10-22):
[0001069202-18-000020:note_history:15]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | — |  |  | $ | 0.9 |  |
| Total short-term debt | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 22.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 22.3 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 377.3 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 368.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.6 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,103.6 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,125.9 |  |  | $ | 1,004.0 |  |

- changed (2018-10-22):
[0001069202-18-000020:note_history:16]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $0.0 million and $0.9 million of foreign obligations outstanding as of September 30, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $40.2 million  and $19.1 million during the nine months ended September 30, 2018 and 2017, respectively. Repayments on the facilities were $38.5 million and $20.5 million during the nine months ended September 30, 2018 and 2017, respectively.
  (was, 2018-07-23, similarity 0.904):
[0001069202-18-000013:note_history:16]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $3.8 million and $0.9 million of foreign obligations outstanding as of June 30, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $21.3 million  and $0.8 million during the six months ended June 30, 2018 and 2017, respectively. Repayments on the facilities were $15.6 million and $1.8 million during the six months ended June 30, 2018 and 2017, respectively.

- added (2018-10-22):
[0001069202-18-000020:note_history:17]
|  | September 30, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 380.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (377.3 | ) |  | (276.0 | ) |
| Remaining amount available | $ | 2.7 |  |  | $ | 14.0 |  |

- changed (2018-10-22):
[0001069202-18-000020:note_history:18]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2018 and December 31, 2017 were 2.98% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2018-07-23, similarity 0.9913):
[0001069202-18-000013:note_history:18]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2018 and December 31, 2017 were 2.93% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2018-10-22):
[0001069202-18-000020:note_history:19]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of September 30, 2018, we believe we were in compliance with all covenant requirements.
  (was, 2018-07-23, similarity 0.9357):
[0001069202-18-000013:note_history:19]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2018, we believe we were in compliance with all covenant requirements.

- changed (2018-10-22):
[0001069202-18-000020:note_history:20]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $390.5 million, of which $190.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of September 30, 2018. Subject to covenant limitations, $447.0 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.
  (was, 2018-07-23, similarity 0.9933):
[0001069202-18-000013:note_history:20]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $701.0 million, of which $205.0 million was the term loan balance, as well as $2.9 million committed to standby letters of credit as of June 30, 2018. Subject to covenant limitations, $151.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2018-10-22):
[0001069202-18-000020:note_history:21]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.41 | % |  | 2.76 | % |
  (was, 2018-07-23, similarity 0.9447):
[0001069202-18-000013:note_history:21]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.27 | % |  | 2.76 | % |

- changed (2018-10-22):
[0001069202-18-000020:note_history:22]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2018, we believe we were in compliance with all covenant requirements.
  (was, 2018-07-23, similarity 0.8959):
[0001069202-18-000013:note_history:22]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2018, we believe we were in compliance with all covenant requirements.

- changed (2018-10-22):
[0001069202-18-000020:note_history:23]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2018, we believe we were in compliance with all covenant requirements.
  (was, 2018-07-23, similarity 0.9449):
[0001069202-18-000013:note_history:23]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2018, we believe we were in compliance with all covenant requirements.

- removed (2018-10-22):
[0001069202-18-000013:note_history:24]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 3.8 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 3.8 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.8 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 671.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.9 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,319.0 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,352.6 |  |  | $ | 1,004.0 |  |

- removed (2018-10-22):
[0001069202-18-000013:note_history:25]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 290.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (290.0 | ) |  | (276.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 14.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-10-22):
[0001069202-18-000020:note_history:26]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | — |  |  | $ | 0.9 |  |
| Total short-term debt | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 22.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 22.3 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 377.3 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 368.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.6 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,103.6 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,125.9 |  |  | $ | 1,004.0 |  |

- removed (2018-10-22):
[0001069202-18-000013:note_history:27]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 3.8 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 3.8 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.8 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 671.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.9 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,319.0 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,352.6 |  |  | $ | 1,004.0 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-10-22):
[0001069202-18-000020:note_history:28]
|  | September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 580.9 |  |  | $ | 572.4 |  |  | $ | 8.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 371.6 |  |  | 361.4 |  |  | 10.2 |  |
| Retained earnings | 1,805.0 |  |  | 1,806.7 |  |  | (1.7 | ) |
|  | For the Three Months Ended September 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 1,030.2 |  |  | $ | 1,030.2 |  |  | $ | — |  |
| Net income | 108.0 |  |  | 108.1 |  |  | (0.1 | ) |
  (was, 2018-07-23, similarity 0.9167):
[0001069202-18-000013:note_history:28]
|  | June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 741.3 |  |  | $ | 730.5 |  |  | $ | 10.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 437.5 |  |  | 424.2 |  |  | 13.3 |  |
| Retained earnings | 1,722.8 |  |  | 1,725.3 |  |  | (2.5 | ) |
|  | For the Three Months Ended June 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 1,175.4 |  |  | $ | 1,175.5 |  |  | $ | (0.1 | ) |
| Net income | 137.6 |  |  | 137.6 |  |  | — |  |

- changed (2018-10-22):
[0001069202-18-000020:note_history:29]
|  | For the Nine Months Ended September 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 3,040.4 |  |  | $ | 3,040.6 |  |  | $ | (0.2 | ) |
| Net income | 283.4 |  |  | 283.5 |  |  | (0.1 | ) |
  (was, 2018-07-23, similarity 0.9371):
[0001069202-18-000013:note_history:29]
|  | For the Six Months Ended June 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 2,010.2 |  |  | $ | 2,010.4 |  |  | $ | (0.2 | ) |
| Net income | 175.5 |  |  | 175.5 |  |  | — |  |

- added (2018-10-22):
[0001069202-18-000020:note_history:30]
|  | For the Three Months Ended September 30,2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 594.7 |  |  | $ | 236.9 |  |  | $ | 132.0 |  |  | $ | 963.6 |  |
| Europe | — |  |  | 38.9 |  |  | 27.7 |  |  | 66.6 |  |
| Total | $ | 594.7 |  |  | 275.8 |  |  | 159.7 |  |  | 1,030.2 |  |

- added (2018-10-22):
[0001069202-18-000020:note_history:31]
|  | For the Nine Months Ended September 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 1,764.4 |  |  | $ | 668.1 |  |  | $ | 369.4 |  |  | $ | 2,801.9 |  |
| Europe | — |  |  | 105.4 |  |  | 83.4 |  |  | 188.8 |  |
| Asia Pacific | — |  |  | — |  |  | 49.7 |  |  | 49.7 |  |
| Total | $ | 1,764.4 |  |  | 773.5 |  |  | 502.5 |  |  | 3,040.4 |  |

- changed (2018-10-22):
[0001069202-18-000020:note_history:32]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment, for the three and nine months ended September 30, 2018, direct sales represent approximately $459.9 million and $1,346.2 million of revenues and sales to independent distributors represent approximately $134.8 million and $418.2 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2018-07-23, similarity 0.9754):
[0001069202-18-000013:note_history:32]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment, for the three and six months ended June 30, 2018, direct sales represent approximately $546.7 million and $886.3 million of revenues and sales to independent distributors represent approximately $169.3 million and $283.4 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2018-10-22):
[0001069202-18-000020:note_history:33]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, for the three and nine months ended September 30, 2018, equipment sales represent approximately $242.6 million and $679.2 million of revenues while $33.2 million and $94.3 million of our revenue is generated from our service business, respectively.
  (was, 2018-07-23, similarity 0.9803):
[0001069202-18-000013:note_history:33]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, for the three and six months ended June 30, 2018, equipment sales represent approximately $279.3 million and $457.2 million of revenues while $12.9 million and $40.5 million of our revenue is generated from our service business, respectively.

- changed (2018-10-22):
[0001069202-18-000020:note_history:34]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $156.8 million and $495.8 million for the three and nine months ended September 30, 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.
  (was, 2018-07-23, similarity 0.6553):
[0001069202-18-000013:note_history:34]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $165.4 million and $339 million for the three and six months ended June 30, 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

- added (2018-10-22):
[0001069202-18-000020:note_history:35]
|  | September 30, 2018 |  | December 31, 2017 |  | $ Change |  | % Change |
| Contract assets | $ | 3.5 |  |  | $ | 2.1 |  |  | $ | 1.4 |  |  | 66.7 | % |
| Contract liabilities - current | (6.2 | ) |  | (7.3 | ) |  | 1.1 |  |  | (15.1 | )% |
| Contract liabilities - noncurrent | (6.0 | ) |  | (5.5 | ) |  | (0.5 | ) |  | 9.1 | % |
| Total | $ | (8.7 | ) |  | $ | (10.7 | ) |  | $ | 2.0 |  |  |  |

- changed (2018-10-22):
[0001069202-18-000020:note_history:36]
For the three and nine months ended September 30, 2018, we recognized revenue of $1.3 million and $4.2 million related to our contract liabilities at January 1, 2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the third quarter of 2018.
  (was, 2018-07-23, similarity 0.8954):
[0001069202-18-000013:note_history:36]
For the three and six months ended June 30, 2018, we recognized revenue of $1.3 million and $2.9 million related to our contract liabilities at January 1, 2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the second quarter of 2018.

- removed (2018-10-22):
[0001069202-18-000013:note_history:37]
|  | For the Three Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 716.0 |  |  | $ | 252.1 |  |  | $ | 127.6 |  |  | $ | 1,095.7 |  |
| Europe | — |  |  | 40.1 |  |  | 29.0 |  |  | 69.1 |  |
| Asia Pacific | — |  |  | — |  |  | 10.6 |  |  | 10.6 |  |
| Total | $ | 716.0 |  |  | 292.2 |  |  | 167.2 |  |  | 1,175.4 |  |

- removed (2018-10-22):
[0001069202-18-000013:note_history:38]
|  | For the Six Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 1,169.7 |  |  | $ | 431.2 |  |  | $ | 237.4 |  |  | $ | 1,838.3 |  |
| Europe | — |  |  | 66.5 |  |  | 55.7 |  |  | 122.2 |  |
| Asia Pacific | — |  |  | — |  |  | 49.7 |  |  | 49.7 |  |
| Total | $ | 1,169.7 |  |  | 497.7 |  |  | 342.8 |  |  | 2,010.2 |  |

- removed (2018-10-22):
[0001069202-18-000013:note_history:39]
|  | June 30, 2018 |  | December 31, 2017 |  | $ change |  | % change |
| Contract assets | $ | 3.5 |  |  | $ | 2.1 |  |  | $ | 1.4 |  |  | 66.7 | % |
| Contract liabilities - current | (5.0 | ) |  | (7.3 | ) |  | 2.3 |  |  | (31.5 | )% |
| Contract liabilities - noncurrent | (5.6 | ) |  | (5.5 | ) |  | (0.1 | ) |  | 1.8 | % |
| Total | $ | (7.1 | ) |  | $ | (10.7 | ) |  | $ | 3.6 |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2018-10-22):
[0001069202-18-000013:note_history:40]
Subsequent Event:

- removed (2018-10-22):
[0001069202-18-000013:note_history:41]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was damaged by a tornado. The extent of damage to the facility is being assessed and we currently do not have an estimate of the financial or operational impact of the damage, including any potential insurance recoveries.
