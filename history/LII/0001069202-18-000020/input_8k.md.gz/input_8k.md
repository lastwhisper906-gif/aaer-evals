# LII 8-K — 0001069202-18-000018 filed 2018-10-22

## item codes, every 8-K on or before 2018-10-22

- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2018-10-22

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-18-000018:8k_2_02:1]
EX-99.1
2
pressreleasetables2018930.htm
EXHIBIT 99.1

[0001069202-18-000018:8k_2_02:2]
Exhibit

[0001069202-18-000018:8k_2_02:3]
Exhibit-99.1

[0001069202-18-000018:8k_2_02:4]
Lennox International Reports Third Quarter Results

[0001069202-18-000018:8k_2_02:5]
| • | Updating 2018 estimate for Iowa tornado impact on core business from approximately $100 million of revenue, $55 million of segment profit, and $1.05 of EPS with approximately one-third of impact in third quarter and two-thirds in fourth quarter to guidance of approximately $115 million of revenue, $65 million of segment profit, and $1.25 of EPS with approximately 40% of impact in third quarter and 60% in fourth quarter |

[0001069202-18-000018:8k_2_02:6]
| • | Estimating 2019 tornado impact on core business at approximately $85 million of revenue, $35 million of segment profit, and $0.70 of EPS |

[0001069202-18-000018:8k_2_02:7]
| • | 2018-2019 lost profits from tornado impact expected to be fully offset by insurance proceeds in 2019 |

[0001069202-18-000018:8k_2_02:8]
| • | 2018 non-core special pre-tax charges related to tornado still expected to be approximately $80 million, offset by insurance proceeds this year; $45 million in insurance proceeds received to-date |

[0001069202-18-000018:8k_2_02:9]
| • | Estimating 2019 non-core special pre-tax charges relating to the tornado of $15 million, expected to be more than offset by insurance proceeds in line with costs to replace |

[0001069202-18-000018:8k_2_02:10]
| • | Third-quarter GAAP revenue down 2%; adjusted revenue, excluding divested non-core Refrigeration businesses, up 2% to third-quarter record $1.02 billion |

[0001069202-18-000018:8k_2_02:11]
| • | GAAP EPS from continuing operations up 8% to third-quarter record $2.65 |

[0001069202-18-000018:8k_2_02:12]
| • | Adjusted EPS from continuing operations up 8% to third-quarter record $2.72 |

[0001069202-18-000018:8k_2_02:13]
| • | Reiterating 2018 guidance for GAAP revenue growth of 2-4% |

[0001069202-18-000018:8k_2_02:14]
| • | Reiterating 2018 guidance for adjusted revenue growth of 4-6% |

[0001069202-18-000018:8k_2_02:15]
| • | Updating 2018 guidance for GAAP EPS from continuing operations from $8.38-$8.78 to $8.11-$8.51 |

[0001069202-18-000018:8k_2_02:16]
| • | Updating 2018 guidance for adjusted EPS from continuing operations from $8.90-$9.30 to $8.70-$9.10 |

[0001069202-18-000018:8k_2_02:17]
| • | $100 million of stock repurchases planned for fourth quarter |

[0001069202-18-000018:8k_2_02:18]
DALLAS, October 22, 2018 - Lennox International Inc. (NYSE: LII) today reported financial results for the third quarter of 2018. All comparisons are to the prior-year period. Adjusted revenue and profit exclude the non-core Refrigeration businesses divested in 2018. The company closed on the sale of its Australia and Asia refrigeration businesses in the second quarter, as well as on the sale of real estate in the Sydney area, and closed on the sale of its South America business in the third quarter. The company had $7 million of revenue and $0.6 million of operating loss from the South America business in the third quarter of 2018. The company’s tornado references relate to the July 19 tornado damage at a Residential manufacturing facility in Iowa.

[0001069202-18-000018:8k_2_02:19]
For the third quarter, Lennox International reported GAAP revenue of $1.03 billion, down 2%. Adjusted revenue was up 2% to a third-quarter record $1.02 billion. Foreign exchange was neutral.

[0001069202-18-000018:8k_2_02:20]
GAAP operating income was $145 million in the third quarter, down 6%. GAAP earnings per share from continuing operations was a third-quarter record $2.65, up 8%. On an adjusted basis in the third quarter, total segment profit declined 3% to $155 million. Total segment margin was down 80 basis points to 15.2%. Adjusted EPS from continuing operations rose 8% to a third-quarter record $2.72.

[0001069202-18-000018:8k_2_02:21]
“For 2018, we are raising the estimated business interruption impact from the tornado, which will reverse to a benefit in 2019 upon the receipt of insurance proceeds,” said Chairman and CEO Todd Bluedorn. “We are also rebalancing the expected tornado impact between the third and fourth quarters of 2018. We had

[0001069202-18-000018:8k_2_02:22]
guided that one-third of the impact would be in the third quarter and now expect that approximately 40% of the impact was in the third quarter. We had estimated two-thirds of the impact to come in the fourth quarter and now expect that approximately 60% of the impact will be in the fourth quarter. Third-quarter EPS was up 8% but was impacted by lost profits from the tornado of $0.52 per share, about $0.17 higher than estimated for the quarter.

[0001069202-18-000018:8k_2_02:23]
“Turning to business segment results, Residential and Commercial set new third-quarter highs for revenue, and Refrigeration established a new high for segment margin. In Residential, impacted by the tornado, revenue rose 1%, profit was down 1%, and segment margin was down 40 basis points to 19.0%. In Commercial, revenue rose 2%. Segment profit was down 7%, and margin was down 170 basis points to 16.9%. Commercial national account equipment revenue, lumpy on a quarter-to-quarter basis, was down low-single digits compared to 20% growth in the prior-year quarter, and Europe HVAC revenue was down double digits on continued softness in the region. In Refrigeration, revenue was up 4%. Refrigeration profit rose 19%, and margin expanded 190 basis points to 15.4%.

[0001069202-18-000018:8k_2_02:24]
“While there are moving pieces and noise from the tornado impact in the reported results, we remain focused on normalizing Residential production and continuing to execute on all our corporate initiatives to drive performance and shareholder value. We plan to repurchase $100 million of stock in the fourth quarter as we look toward a strong close to 2018 and ahead to 2019.”

[0001069202-18-000018:8k_2_02:25]
FINANCIAL HIGHLIGHTS

[0001069202-18-000018:8k_2_02:26]
Revenue: On a GAAP basis, revenue was $1.03 billion, down 2%. On an adjusted basis, revenue was a third-quarter record $1.02 billion, up 2%. Foreign exchange was neutral to revenue. Volume was flat, mix was unfavorable, and price was up.

[0001069202-18-000018:8k_2_02:27]
Gross Profit: On a GAAP basis, gross profit was $302 million, down 4%. Gross margin was 29.3%, down 50 basis points. On an adjusted basis, gross profit was $301 million, relatively flat. Adjusted gross margin was 29.4%, down 50 basis points. Gross profit on a GAAP and adjusted basis was impacted by the tornado, higher commodity, freight, distribution and other product costs, and unfavorable foreign exchange. Partial offsets included higher price, sourcing and engineering-led cost reductions, and factory productivity and other product costs.

[0001069202-18-000018:8k_2_02:28]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the third quarter was $108.0 million, or $2.65 per share, compared to $104.0 million, or $2.45 per share, in the prior-year quarter.

[0001069202-18-000018:8k_2_02:29]
The company had $49 million of non-core pre-tax charges related to the tornado offset by $49 million of insurance recovery in the third quarter.

[0001069202-18-000018:8k_2_02:30]
Adjusted income from continuing operations in the third quarter was $110.4 million, or $2.72 per share, compared to $107.0 million, or $2.53 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the third quarter of 2018 excludes net after-tax charges of $2.4 million: $2.4 million for the net loss on the sale of business and related property; a total of $3.1 million for various other items; a $1.7 million benefit for excess tax benefits from share-based compensation; and a $1.4 million benefit for other tax items, net.

[0001069202-18-000018:8k_2_02:31]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from operations in the third quarter was $266 million, including $45 million in cash from insurance proceeds, compared to $177 million in the prior-year quarter. Capital expenditures were $18 million compared to $17 million in the prior-year

[0001069202-18-000018:8k_2_02:32]
quarter. Free cash flow was approximately $248 million compared to $160 million in the third quarter a year ago. Total debt at the end of the third quarter was $1.13 billion. Total cash and cash equivalents were $46 million at the end of September. In the third quarter, the company paid $26 million in dividends.

[0001069202-18-000018:8k_2_02:33]
BUSINESS SEGMENT HIGHLIGHTS

[0001069202-18-000018:8k_2_02:34]
Residential Heating & Cooling

[0001069202-18-000018:8k_2_02:35]
Revenue in the Residential Heating & Cooling business segment was up 1% to a third-quarter record $595 million. Foreign exchange was neutral to revenue. Segment profit was $113 million, down 1%. Segment margin was 19.0%, down 40 basis points. Residential financial results were impacted by the tornado, and the business had lower volume, higher commodity, freight, distribution and other product costs, and unfavorable foreign exchange. Partial offsets included higher price, sourcing and engineering-led cost reductions, factory productivity, and lower SG&A expenses.

[0001069202-18-000018:8k_2_02:36]
Commercial Heating & Cooling

[0001069202-18-000018:8k_2_02:37]
Revenue in the Commercial Heating & Cooling business segment was up 2% to a third-quarter record $276 million. Foreign exchange was neutral to revenue. Commercial profit was down 7% to $47 million, and segment margin was down 170 basis points to 16.9%. Results were impacted by higher commodity, freight and distribution, and other product costs, lower factory productivity, higher SG&A expenses, and unfavorable foreign exchange. Partial offsets included higher volume, favorable price, and sourcing and engineering-led cost reductions.

[0001069202-18-000018:8k_2_02:38]
Refrigeration

[0001069202-18-000018:8k_2_02:39]
On an adjusted basis for the Refrigeration business segment, revenue was $153 million, up 4%. Foreign exchange was neutral to revenue. Refrigeration profit was up 19% to $24 million, and segment margin expanded 190 basis points to 15.4%. Results were positively impacted by higher volume, higher price, sourcing and engineering-led cost reductions, and lower SG&A expenses. Partial offsets included higher commodity and freight costs.

[0001069202-18-000018:8k_2_02:40]
FULL-YEAR OUTLOOK

[0001069202-18-000018:8k_2_02:41]
| • | Reiterating 2018 guidance for GAAP revenue growth of 2-4% and adjusted revenue growth of 4-6%. |

[0001069202-18-000018:8k_2_02:42]
| • | Updating 2018 guidance for GAAP EPS from continuing operations from $8.38-$8.78 to $8.11-$8.51, reflecting additional tornado impact in 2018 than prior guidance; to be a benefit in 2019 upon receipt of insurance proceeds. |

[0001069202-18-000018:8k_2_02:43]
| • | Updating 2018 guidance for adjusted EPS from continuing operations from $8.90-$9.30 to $8.70-9.10, reflecting additional tornado impact in 2018 than prior guidance; to be a benefit in 2019 upon receipt of insurance proceeds. |

[0001069202-18-000018:8k_2_02:44]
| • | Reiterating corporate expense guidance of approximately $85 million. |

[0001069202-18-000018:8k_2_02:45]
| • | Reiterating guidance for an effective tax rate of 22-24% on an adjusted basis for the full year. |

[0001069202-18-000018:8k_2_02:46]
| • | Reiterating capital expenditures of approximately $100 million, excluding the impact of the tornado repairs. |

[0001069202-18-000018:8k_2_02:47]
| • | Reiterating stock repurchase guidance of $450 million in total for 2018, and reiterating guidance for the company’s average diluted share count of approximately 41 million shares on a full-year basis. |

[0001069202-18-000018:8k_2_02:48]
CONFERENCE CALL INFORMATION

[0001069202-18-000018:8k_2_02:49]
A conference call to discuss the company's third-quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-332-1020 at least 10 minutes prior to the scheduled start time and use reservation number 455465. The conference call also will be webcast on Lennox International's web site at www.lennoxinternational.com. A replay will be available from 11:00

[0001069202-18-000018:8k_2_02:50]
a.m. Central time on October 22 through November 5, 2018 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 455465. The call also will be archived on the company's website.

[0001069202-18-000018:8k_2_02:51]
About Lennox International

[0001069202-18-000018:8k_2_02:52]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol "LII". Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-18-000018:8k_2_02:53]
FORWARD-LOOKING STATEMENTS

[0001069202-18-000018:8k_2_02:54]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Statements of Operations(Unaudited) |
| (Amounts in millions, except per share data) | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 1,030.2 |  |  | $ | 1,052.3 |  |  | $ | 3,040.4 |  |  | $ | 2,947.9 |  |
| Cost of goods sold | 728.3 |  |  | 738.6 |  |  | 2,153.8 |  |  | 2,082.4 |  |
| Gross profit | 301.9 |  |  | 313.7 |  |  | 886.6 |  |  | 865.5 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 149.4 |  |  | 158.7 |  |  | 466.1 |  |  | 479.6 |  |
| Losses and other expenses, net | 2.7 |  |  | 3.0 |  |  | 10.0 |  |  | 8.5 |  |
| Restructuring charges | 0.5 |  |  | 1.9 |  |  | 1.9 |  |  | 2.1 |  |
| Loss (gain), net on sale of businesses and related property | 6.2 |  |  | — |  |  | 25.8 |  |  | — |  |
| Loss from natural disaster, net of insurance recoveries | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |
| Income from equity method investments | (2.4 | ) |  | (4.5 | ) |  | (10.8 | ) |  | (15.5 | ) |
| Operating income | 145.2 |  |  | 154.6 |  |  | 393.3 |  |  | 390.8 |  |
| Interest expense, net | 10.3 |  |  | 7.6 |  |  | 28.5 |  |  | 23.3 |  |
| Other expense (income), net | 1.1 |  |  | — |  |  | 2.4 |  |  | (0.2 | ) |
| Income from continuing operations before income taxes | 133.8 |  |  | 147.0 |  |  | 362.4 |  |  | 367.7 |  |
| Provision for income taxes | 25.8 |  |  | 43.0 |  |  | 77.3 |  |  | 103.8 |  |
| Income from continuing operations | 108.0 |  |  | 104.0 |  |  | 285.1 |  |  | 263.9 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| (Loss) income from discontinued operations before income taxes | — |  |  | (0.8 | ) |  | 0.4 |  |  | (2.3 | ) |
| Income tax (benefit) expense | — |  |  | (0.3 | ) |  | 2.1 |  |  | (0.9 | ) |
| Loss from discontinued operations | — |  |  | (0.5 | ) |  | (1.7 | ) |  | (1.4 | ) |
| Net income | $ | 108.0 |  |  | $ | 103.5 |  |  | $ | 283.4 |  |  | $ | 262.5 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.68 |  |  | $ | 2.48 |  |  | $ | 6.98 |  |  | $ | 6.23 |  |
| Loss from discontinued operations | — |  |  | (0.01 | ) |  | (0.04 | ) |  | (0.03 | ) |
| Net income | $ | 2.68 |  |  | $ | 2.47 |  |  | $ | 6.94 |  |  | $ | 6.20 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.65 |  |  | $ | 2.45 |  |  | $ | 6.90 |  |  | $ | 6.15 |  |
| Loss from discontinued operations | — |  |  | (0.01 | ) |  | (0.04 | ) |  | (0.03 | ) |
| Net income | $ | 2.65 |  |  | $ | 2.44 |  |  | $ | 6.86 |  |  | $ | 6.12 |  |
| Weighted Average Number of Shares Outstanding - Basic | 40.3 |  |  | 41.9 |  |  | 40.8 |  |  | 42.3 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 40.7 |  |  | 42.4 |  |  | 41.3 |  |  | 42.9 |  |
| Cash dividends declared per share | $ | 0.64 |  |  | $ | 0.51 |  |  | $ | 1.79 |  |  | $ | 1.45 |  |

[0001069202-18-000018:8k_2_02:55]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Adjusted Segment Net Sales and Profit (Loss) |
| (Unaudited) |

[0001069202-18-000018:8k_2_02:56]
| (Amounts in millions) | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 594.7 |  |  | $ | 590.5 |  |  | $ | 1,764.4 |  |  | $ | 1,663.8 |  |
| Commercial Heating & Cooling | 275.8 |  |  | 269.4 |  |  | 773.5 |  |  | 723.5 |  |
| Refrigeration (1) | 152.8 |  |  | 147.0 |  |  | 431.5 |  |  | 425.2 |  |
|  | $ | 1,023.3 |  |  | $ | 1,006.9 |  |  | $ | 2,969.4 |  |  | $ | 2,812.5 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 113.0 |  |  | $ | 114.7 |  |  | $ | 317.9 |  |  | $ | 297.6 |  |
| Commercial Heating & Cooling | 46.7 |  |  | 50.0 |  |  | 118.9 |  |  | 113.8 |  |
| Refrigeration (1) | 23.6 |  |  | 19.8 |  |  | 55.2 |  |  | 52.3 |  |
| Corporate and other | (28.1 | ) |  | (23.7 | ) |  | (61.8 | ) |  | (58.5 | ) |
| Total adjusted segment profit | 155.2 |  |  | 160.8 |  |  | 430.2 |  |  | 405.2 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Special inventory write down | — |  |  | — |  |  | 0.2 |  |  | — |  |
| Special product quality adjustment | — |  |  | 0.5 |  |  | — |  |  | 5.7 |  |
| Loss (gain), net on sale of businesses and related property | 6.2 |  |  | — |  |  | 25.8 |  |  | — |  |
| Loss from natural disaster, net of insurance recoveries | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 2.4 |  |  | 4.0 |  |  | 9.3 |  |  | 10.0 |  |
| Restructuring charges | 0.5 |  |  | 1.9 |  |  | 1.9 |  |  | 2.1 |  |
| Operating loss (income) from non-core businesses | 0.6 |  |  | (0.2 | ) |  | (0.6 | ) |  | (3.4 | ) |
| Operating income | $ | 145.2 |  |  | $ | 154.6 |  |  | $ | 393.3 |  |  | $ | 390.8 |  |

[0001069202-18-000018:8k_2_02:57]
(1) Excludes the non-core business results related to our business operations in Australia, Asia, and South America for 2018 and 2017.

[0001069202-18-000018:8k_2_02:58]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-18-000018:8k_2_02:59]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-18-000018:8k_2_02:60]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-18-000018:8k_2_02:61]
| ◦ | Special legal contingency charges, |

[0001069202-18-000018:8k_2_02:62]
| ◦ | Asbestos-related litigation, |

[0001069202-18-000018:8k_2_02:63]
| ◦ | Environmental liabilities, |

[0001069202-18-000018:8k_2_02:64]
| ◦ | Divestiture costs, |

[0001069202-18-000018:8k_2_02:65]
| ◦ | Other items, net, |

[0001069202-18-000018:8k_2_02:66]
| • | Special inventory write down, |

[0001069202-18-000018:8k_2_02:67]
| • | Loss (gain), net on sale of businesses and related property, |

[0001069202-18-000018:8k_2_02:68]
| • | Loss from natural disaster, net of insurance recoveries |

[0001069202-18-000018:8k_2_02:69]
| • | Special product quality adjustment, |

[0001069202-18-000018:8k_2_02:70]
| • | Operating income from non-core businesses; and, |

[0001069202-18-000018:8k_2_02:71]
| • | Restructuring charges. |

[0001069202-18-000018:8k_2_02:72]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Balance Sheets |
| (Amounts in millions, except shares and par values) | As of September 30, 2018 |  | As of December 31, 2017 |
|  | (unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 46.1 |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net of allowances of $6.1 and $5.9 in 2018 and 2017, respectively | 580.9 |  |  | 506.5 |  |
| Inventories, net | 501.5 |  |  | 484.2 |  |
| Other assets | 58.7 |  |  | 78.4 |  |
| Total current assets | 1,187.2 |  |  | 1,137.3 |  |
| Property, plant and equipment, net of accumulated depreciation of $772.9 and $774.2 in 2018 and 2017, respectively | 374.4 |  |  | 397.8 |  |
| Goodwill | 186.9 |  |  | 200.5 |  |
| Deferred income taxes | 95.4 |  |  | 94.4 |  |
| Other assets, net | 66.9 |  |  | 61.5 |  |
| Total assets | $ | 1,910.8 |  |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current Liabilities: |  |  |  |
| Short-term debt | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt | 22.3 |  |  | 32.6 |  |
| Accounts payable | 371.6 |  |  | 348.6 |  |
| Accrued expenses | 292.5 |  |  | 270.3 |  |
| Income taxes payable | 4.1 |  |  | 2.1 |  |
| Total current liabilities | 690.5 |  |  | 654.5 |  |
| Long-term debt | 1,103.6 |  |  | 970.5 |  |
| Post-retirement benefits, other than pensions | 2.5 |  |  | 2.6 |  |
| Pensions | 70.7 |  |  | 84.5 |  |
| Other liabilities | 130.3 |  |  | 129.3 |  |
| Total liabilities | 1,997.6 |  |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' (deficit) equity: |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,075.5 |  |  | 1,061.5 |  |
| Retained earnings | 1,805.0 |  |  | 1,575.9 |  |
| Accumulated other comprehensive loss | (175.6 | ) |  | (157.4 | ) |
| Treasury stock, at cost, shares 46,891,591 and 45,361,145 shares as of September 30, 2018 and December 31, 2017, respectively | (2,792.6 | ) |  | (2,430.8 | ) |
| Total stockholders' (deficit) equity | (86.8 | ) |  | 50.1 |  |
| Total liabilities and stockholders' equity | $ | 1,910.8 |  |  | $ | 1,891.5 |  |

[0001069202-18-000018:8k_2_02:73]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-18-000018:8k_2_02:74]
Consolidated Statements of Cash Flows

[0001069202-18-000018:8k_2_02:75]
(Unaudited)

[0001069202-18-000018:8k_2_02:76]
| (Amounts in millions) | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 283.4 |  |  | $ | 262.5 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Gain on sale of real estate | (23.8 | ) |  | — |  |
| Impairment/loss on the sale of Australia business | 13.0 |  |  | — |  |
| Impairment/loss on the sale of Brazil business | 36.6 |  |  | — |  |
| Income from equity method investments | (10.8 | ) |  | (15.5 | ) |
| Dividend from Affiliates | 6.6 |  |  | 7.8 |  |
| Restructuring charges, net of cash paid | 0.5 |  |  | 1.0 |  |
| Provision for bad debts | 3.8 |  |  | 3.2 |  |
| Unrealized losses (gains) on derivative contracts | 1.4 |  |  | (0.7 | ) |
| Stock-based compensation expense | 21.0 |  |  | 18.8 |  |
| Depreciation and amortization | 49.4 |  |  | 48.1 |  |
| Deferred income taxes | (5.6 | ) |  | (3.9 | ) |
| Pension expense | 6.5 |  |  | 4.1 |  |
| Pension contributions | (20.3 | ) |  | (1.4 | ) |
| Other items, net | 0.3 |  |  | 1.0 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (114.0 | ) |  | (118.3 | ) |
| Inventories | (73.7 | ) |  | (102.6 | ) |
| Other current assets | (8.6 | ) |  | (7.3 | ) |
| Accounts payable | 46.9 |  |  | 31.0 |  |
| Accrued expenses | 35.6 |  |  | 7.6 |  |
| Income taxes payable and receivable | (1.4 | ) |  | (9.9 | ) |
| Other | (15.5 | ) |  | 3.5 |  |
| Net cash provided by operating activities | 231.3 |  |  | 129.0 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.1 |  |  | 0.2 |  |
| Purchases of property, plant and equipment | (60.9 | ) |  | (60.5 | ) |
| Net proceeds from sale of businesses and related property | 115.9 |  |  | — |  |
| Insurance recoveries received for property damage incurred from natural disaster | 4.2 |  |  | — |  |
| Net cash provided by (used in) investing activities | 59.3 |  |  | (60.3 | ) |
| Cash flows from financing activities: |  |  |  |
| Short-term borrowings, net | (1.5 | ) |  | (1.4 | ) |
| Asset securitization borrowings | 155.0 |  |  | 275.0 |  |
| Asset securitization payments | (53.7 | ) |  | — |  |
| Long-term debt payments | (32.9 | ) |  | (200.8 | ) |
| Borrowings from credit facility | 1,820.0 |  |  | 1,883.0 |  |
| Payments on credit facility | (1,766.5 | ) |  | (1,701.0 | ) |
| Proceeds from employee stock purchases | 2.5 |  |  | 2.3 |  |
| Repurchases of common stock | (350.2 | ) |  | (250.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (21.1 | ) |  | (16.0 | ) |
| Cash dividends paid | (68.2 | ) |  | (58.4 | ) |
| Net cash used in financing activities | (316.6 | ) |  | (67.3 | ) |
| (Decrease) increase in cash and cash equivalents | (26.0 | ) |  | 1.4 |  |
| Effect of exchange rates on cash and cash equivalents | 3.9 |  |  | 9.1 |  |
| Cash and cash equivalents, beginning of period | 68.2 |  |  | 50.2 |  |
| Cash and cash equivalents, end of period | $ | 46.1 |  |  | $ | 60.7 |  |

[0001069202-18-000018:8k_2_02:77]
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 25.9 |  |  | $ | 22.5 |  |
| Income taxes paid (net of refunds) | $ | 87.2 |  |  | $ | 115.5 |  |
| Insurance recoveries received | $ | 45.0 |  |  | $ | — |  |

[0001069202-18-000018:8k_2_02:78]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. In the first quarter of 2018, the Company announced the planned sales of its businesses in Australia, Asia, and South America. The results from operations for these businesses have been shown in the tables below as “Non-core business results”. The sale of our business in Australia and Asia and the related property was completed in the second quarter of 2018 and sale of our business in Brazil was completed in the third quarter of 2018. The prior period results have been updated to provide period-over-period comparability. |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |
|  | For the Three Months Ended September 30, |
|  | 2018 |  | 2017 |
|  | Pre-Tax |  | Tax Impact (e) |  | After Tax |  |  | Pre-Tax |  | Tax Impact (e) |  | After Tax |  |
| Income from continuing operations, a GAAP measure | $ | 133.8 |  | $ | (25.8 | ) | $ | 108.0 |  |  | $ | 147.0 |  | $ | (43.0 | ) | $ | 104.0 |  |
| Restructuring charges | 0.5 |  | (0.1 | ) | 0.4 |  |  | 1.9 |  | (0.8 | ) | 1.1 |  |
| Special product quality adjustments (b) | — |  | — |  | — |  |  | 0.5 |  | (0.2 | ) | 0.3 |  |
| Special legal contingency charges (a) | 0.1 |  | — |  | 0.1 |  |  | 1.5 |  | (0.2 | ) | 1.3 |  |
| Asbestos-related litigation (a) | 1.4 |  | (0.4 | ) | 1.0 |  |  | 1.5 |  | (0.5 | ) | 1.0 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | 0.2 |  | (0.1 | ) | 0.1 |  |  | 0.2 |  | (0.1 | ) | 0.1 |  |
| Environmental liabilities (a) | 0.2 |  | — |  | 0.2 |  |  | 0.5 |  | (0.1 | ) | 0.4 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (1.7 | ) | (1.7 | ) |  | — |  | (1.5 | ) | (1.5 | ) |
| Other tax items, net (c) | — |  | (1.4 | ) | (1.4 | ) |  | — |  | — |  |  |
| Loss (gain), net on sale of businesses and related property | 6.2 |  | (3.8 | ) | 2.4 |  |  | — |  | — |  | — |  |
| Loss from natural disaster, net of insurance recoveries ($49.4M charges net of $45.0M cash and $4.1M receivable) | 0.3 |  | (0.1 | ) | 0.2 |  |  | — |  | — |  | — |  |
| Other items, net (a) | 0.5 |  | — |  | 0.5 |  |  | 0.3 |  | (0.1 | ) | 0.2 |  |
| Non-core business results (f) | 0.6 |  | — |  | 0.6 |  |  | 0.2 |  | (0.1 | ) | 0.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 143.8 |  | $ | (33.4 | ) | $ | 110.4 |  |  | $ | 153.6 |  | $ | (46.6 | ) | $ | 107.0 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 2.65 |  |  |  |  |  |  | $ | 2.45 |  |
| Restructuring charges |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.03 |  |
| Special product quality adjustments (b) |  |  | — |  |  |  |  | 0.01 |  |
| Special legal contingency charges (a) |  |  | — |  |  |  |  | 0.03 |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.02 |  |  |  |  |  |  | 0.02 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.01 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.04 | ) |  |  |  |  |  | (0.03 | ) |
| Other tax items, net (c) |  |  |  |  | (0.03 | ) |  |  |  |  |  | — |  |
| Loss (gain), net on sale of businesses and related property |  |  | 0.06 |  |  |  |  | — |  |
| Loss from natural disaster, net of insurance recoveries |  |  | 0.01 |  |  |  |  | — |  |
| Other items, net (a) |  |  | 0.01 |  |  |  |  | 0.01 |  |
| Non-core business results (f) |  |  | 0.01 |  |  |  |  | — |  |

[0001069202-18-000018:8k_2_02:79]
| Change in share counts from share-based compensation (d) |  |  | 0.01 |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  | $ | 2.72 |  |  |  |  |  |  | $ | 2.53 |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |
|  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |
|  | Pre-Tax |  | Tax Impact (e) | After Tax |  |  | Pre-Tax |  | Tax Impact (e) | After Tax |  |
| Income from continuing operations, a GAAP measure | $ | 362.4 |  | $ | (77.3 | ) | $ | 285.1 |  |  | $ | 367.7 |  | $ | (103.8 | ) | $ | 263.9 |  |
| Restructuring charges | 1.9 |  | (0.5 | ) | 1.4 |  |  | 2.1 |  | (0.8 | ) | 1.3 |  |
| Special product quality adjustments (b) | — |  | — |  | — |  |  | 5.7 |  | (2.0 | ) | 3.7 |  |
| Special legal contingency charges (a) | 1.8 |  | (0.4 | ) | 1.4 |  |  | 3.6 |  | (0.4 | ) | 3.2 |  |
| Asbestos-related litigation (a) | 3.3 |  | (0.8 | ) | 2.5 |  |  | 3.9 |  | (1.3 | ) | 2.6 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | 1.4 |  | (0.3 | ) | 1.1 |  |  | 1.0 |  | (0.4 | ) | 0.6 |  |
| Inventory write down (b) | 0.2 |  | — |  | 0.2 |  |  | — |  | — |  | — |  |
| Environmental liabilities (a) | 1.4 |  | (0.3 | ) | 1.1 |  |  | 1.2 |  | (0.3 | ) | 0.9 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (6.6 | ) | (6.6 | ) |  | — |  | (9.6 | ) | (9.6 | ) |
| Other tax items, net (c) | — |  | (4.7 | ) | (4.7 | ) |  | — |  | — |  | — |  |
| Loss (gain), net on sale of businesses and related property | 25.8 |  | 0.3 |  | 26.1 |  |  | — |  | — |  | — |  |
| Loss from natural disaster, net of insurance recoveries ($49.4M charges net of $45.0M cash and $4.1M receivable) | 0.3 |  | (0.1 | ) | 0.2 |  |  | — |  | — |  | — |  |
| Other items, net (a) | 1.4 |  | (0.7 | ) | 0.7 |  |  | 0.3 |  | (0.1 | ) | 0.2 |  |
| Non-core business results (f) | (0.4 | ) | 0.1 |  | (0.3 | ) |  | 2.6 |  | (0.9 | ) | 1.7 |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 399.5 |  | $ | (91.3 | ) | $ | 308.2 |  |  | $ | 388.1 |  | $ | (119.6 | ) | $ | 268.5 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 6.90 |  |  |  |  |  |  | $ | 6.15 |  |
| Restructuring charges |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.03 |  |
| Special product quality adjustments (b) |  |  |  |  | — |  |  |  |  |  |  | 0.09 |  |
| Special legal contingency charges (a) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.07 |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.06 |  |  |  |  |  |  | 0.06 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.01 |  |
| Inventory write down (b) |  |  | — |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  | 0.03 |  |  |  |  | 0.02 |  |
| Excess tax benefits from share-based compensation (c) |  |  | (0.16 | ) |  |  |  | (0.22 | ) |
| Other tax items, net (c) |  |  | (0.11 | ) |  |  |  | — |  |
| Loss (gain), net on sale of businesses and related property |  |  |  |  | 0.64 |  |  |  |  |  |  | — |  |
| Loss from natural disaster, net of insurance recoveries |  |  | — |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  | 0.02 |  |  |  |  |  |  | — |  |
| Non-core business results (f) |  |  |  |  | (0.01 | ) |  |  |  |  |  | 0.05 |  |

[0001069202-18-000018:8k_2_02:80]
| Change in share counts from share-based compensation (d) |  |  | 0.03 |  |  |  |  | 0.02 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  | $ | 7.49 |  |  |  |  |  |  | $ | 6.28 |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |

[0001069202-18-000018:8k_2_02:81]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Components of (Gains) Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts (a) | $ | 0.2 |  |  | $ | (0.5 | ) |  | $ | (0.6 | ) |  | $ | (1.3 | ) |
| Foreign currency exchange losses (gains) (a) | 0.1 |  |  | (0.6 | ) |  | 1.2 |  |  | (0.3 | ) |
| Loss on disposal of fixed assets (a) | — |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Net change in unrealized losses on unsettled futures contracts (b) | 0.2 |  |  | 0.2 |  |  | 1.4 |  |  | 1.0 |  |
| Special legal contingency charges (b) | 0.1 |  |  | 1.5 |  |  | 1.8 |  |  | 3.6 |  |
| Asbestos-related litigation (b) | 1.4 |  |  | 1.5 |  |  | 3.3 |  |  | 3.9 |  |
| Environmental liabilities (b) | 0.2 |  |  | 0.5 |  |  | 1.4 |  |  | 1.2 |  |
| Other items, net (b) | 0.5 |  |  | 0.3 |  |  | 1.4 |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) | $ | 2.7 |  |  | $ | 3.0 |  |  | $ | 10.0 |  |  | $ | 8.5 |  |

[0001069202-18-000018:8k_2_02:82]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001069202-18-000018:8k_2_02:83]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |
|  |  |  |  |  | For the Year Ended December 31, 2018ESTIMATED |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $8.11 - $8.51 |  |
| Charges associated with the divestiture of the Australia, Asia and Brazil businesses and other items partially offset by gain on sale of property and excess tax benefits from share-based compensation |  | 0.59 |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $8.70 - $9.10 |  |
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Average shares outstanding - diluted, a GAAP measure | 40.7 |  |  | 42.4 |  |  | 41.3 |  |  | 42.9 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 40.6 |  |  | 42.3 |  |  | 41.2 |  |  | 42.8 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales, a GAAP measure | $ | 159.7 |  |  | $ | 192.4 |  |  | $ | 1,030.2 |  |  | $ | 1,052.3 |  |
| Net sales from non-core businesses (a) | 6.9 |  |  | 45.4 |  |  | 6.9 |  |  | 45.4 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 152.8 |  |  | $ | 147.0 |  |  | $ | 1,023.3 |  |  | $ | 1,006.9 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Nine Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales, a GAAP measure | $ | 502.5 |  |  | $ | 560.6 |  |  | $ | 3,040.4 |  |  | $ | 2,947.9 |  |
| Net sales from non-core businesses (a) | 71.0 |  |  | 135.4 |  |  | 71.0 |  |  | 135.4 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 431.5 |  |  | $ | 425.2 |  |  | $ | 2,969.4 |  |  | $ | 2,812.5 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross profit, a GAAP measure | $ | 47.8 |  |  | $ | 56.2 |  |  | $ | 301.9 |  |  | $ | 313.7 |  |
| Non-GAAP adjustments to gross profit | — |  |  | — |  |  | — |  |  | (0.5 | ) |
| Gross profit from non-core businesses (a) | 1.0 |  |  | 12.7 |  |  | 1.0 |  |  | 12.7 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 46.8 |  |  | $ | 43.5 |  |  | $ | 300.9 |  |  | $ | 301.5 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |

[0001069202-18-000018:8k_2_02:84]
|  | Refrigeration Segment |  | Consolidated |
|  | For the Nine Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross profit, a GAAP measure | $ | 147.0 |  |  | $ | 165.7 |  |  | $ | 886.6 |  |  | $ | 865.5 |  |
| Non-GAAP adjustments to gross profit | (0.2 | ) |  | — |  |  | (0.2 | ) |  | (5.7 | ) |
| Gross profit from non-core businesses (a) | 19.0 |  |  | 40.1 |  |  | 19.0 |  |  | 40.1 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 128.2 |  |  | $ | 125.6 |  |  | $ | 867.8 |  |  | $ | 831.1 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Segment profit, a GAAP measure | $ | 23.0 |  |  | $ | 20.0 |  |  | $ | 154.6 |  |  | $ | 161.0 |  |
| Gross (loss) profit from non-core businesses (a) | (0.6 | ) |  | 0.2 |  |  | (0.6 | ) |  | 0.2 |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 23.6 |  |  | $ | 19.8 |  |  | $ | 155.2 |  |  | $ | 160.8 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Nine Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Segment profit, a GAAP measure | $ | 55.8 |  |  | $ | 55.7 |  |  | $ | 430.8 |  |  | $ | 408.6 |  |
| Gross profit from non-core businesses (a) | 0.6 |  |  | 3.4 |  |  | 0.6 |  |  | 3.4 |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 55.2 |  |  | $ | 52.3 |  |  | $ | 430.2 |  |  | $ | 405.2 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Selling, general and administrative expenses, a GAAP measure | $ | 149.4 |  |  | $ | 158.7 |  |  | $ | 466.1 |  |  | $ | 479.6 |  |
| Selling, general and administrative expenses from non-core businesses (a) | 1.6 |  |  | 12.6 |  |  | 18.8 |  |  | 36.6 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 147.8 |  |  | $ | 146.1 |  |  | $ | 447.3 |  |  | $ | 443.0 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
| Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net cash provided by operating activities, a GAAP measure | $ | 266.3 |  |  | $ | 177.3 |  |  | $ | 231.3 |  |  | $ | 129.0 |  |
| Purchases of property, plant and equipment | (17.5 | ) |  | (17.1 | ) |  | (60.9 | ) |  | (60.5 | ) |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | 0.2 |  |
| Free cash flow, a Non-GAAP measure | 248.8 |  |  | 160.2 |  |  | 170.5 |  |  | 68.7 |  |

[0001069202-18-000018:8k_2_02:85]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to September 30, 2018 |
| Adjusted EBIT(a) (a) |  |  |  |  |  |  | $ | 533.1 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  | 64.9 |  |
| EBITDA (a + b) |  |  |  |  |  |  | $ | 598.0 |  |
| Total debt at September 30, 2018 (c) |  |  |  |  |  |  | $ | 1,125.9 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  | 1.9 |  |
| (a) Adjusted EBIT excludes the non-core business results related to our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |
|  |  |  |  |  |  |  | Trailing Twelve Months to September 30, 2018 |
| Adjusted EBIT per above, a Non-GAAP measure | $ | 533.1 |  |
| Special product quality adjustments | (0.3 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit | 10.7 |  |
| Inventory write down | 0.2 |  |
| Restructuring charges | 3.0 |  |
| Interest expense, net | 35.8 |  |
| Loss from natural disaster, net of insurance recoveries | 0.3 |  |
| Loss (gain), net on sale of businesses and related property | 25.8 |  |
| Non-core business results (a) | (3.7 | ) |
| Other expenses, net | 2.5 |  |
| Income from continuing operations before income taxes, a GAAP measure | $ | 458.8 |  |
| (a) Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |
