# LII notes — 0001069202-18-000020


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-18-000020:notes:1]
[same as prior period, unchanged from 0001069202-18-000013:notes:1]


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-18-000020:notes:2]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-18-000020:notes:3]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-18-000020:notes:4]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-18-000020:notes:5]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.41 | % |  | 2.76 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-18-000020:notes:6]
[same as prior period, unchanged from 0001069202-18-000013:notes:6]

[0001069202-18-000020:notes:7]
The accompanying unaudited Consolidated Balance Sheet as of  September 30, 2018, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-18-000020:notes:8]
[same as prior period, unchanged from 0001069202-18-000013:notes:8]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-18-000020:notes:9]
Commitments and Contingencies:

[0001069202-18-000020:notes:10]
Product Warranties and Product Related Contingencies

[0001069202-18-000020:notes:11]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-18-000020:notes:12]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000020:notes:13]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 36.6 |  |  | $ | 34.8 |  |
| Other liabilities | 73.6 |  |  | 75.1 |  |
| Total warranty liability | $ | 110.2 |  |  | $ | 109.9 |  |

[0001069202-18-000020:notes:14]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2018 were as follows (in millions):

[0001069202-18-000020:notes:15]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (23.9 | ) |
| Changes resulting from issuance of new warranties | 29.0 |  |
| Changes in estimates associated with pre-existing liabilities | (3.1 | ) |
| Changes in foreign currency translation rates and other | (0.4 | ) |
| Warranty liability from Divestitures | (1.3 | ) |
| Total warranty liability as of September 30, 2018 | $ | 110.2 |  |

[0001069202-18-000020:notes:16]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above.  Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities, for such quality related issues, are not material.

[0001069202-18-000020:notes:17]
Litigation

[0001069202-18-000020:notes:18]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-18-000020:notes:19]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2018 and 2017, expense for asbestos-related litigation was $3.3 million and $3.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.  For the three months ended  September 30, 2018 and 2017, expense for asbestos-related litigation was $1.4 million and $1.5 million, respectively, net of probable insurance recoveries.

[0001069202-18-000020:notes:20]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.

[0001069202-18-000020:notes:21]
Marshalltown Tornado and Recovery

[0001069202-18-000020:notes:22]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the full amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Loss from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations.

[0001069202-18-000020:notes:23]
The following table summarizes the loss from natural disaster, net of insurance recoveries:

[0001069202-18-000020:notes:24]
| (Amounts in millions) | For the Nine Months Ended September 30, 2018 |
| Write-off of property, plant and equipment | $ | 4.2 |  |
| Write-off of inventory | 5.2 |  |
| Site clean-up and remediation | 28.4 |  |
| Factory inefficiencies due to lower productivity | 4.9 |  |
| Other | 6.7 |  |
| Total expense | 49.4 |  |
| Insurance recoveries received | 45.0 |  |
| Insurance recoveries receivable (1) | 4.1 |  |
| Loss from natural disaster, net of insurance recoveries | $ | 0.3 |  |

[0001069202-18-000020:notes:25]
(1) The insurance recoveries receivable is recorded in Other assets in the Consolidated Balance Sheets.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-18-000020:notes:26]
[same as prior period, unchanged from 0001069202-18-000013:notes:22]

[0001069202-18-000020:notes:27]
[same as prior period, unchanged from 0001069202-18-000013:notes:23]

[0001069202-18-000020:notes:28]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts/foreign exchange forward contracts |  | $ | 0.3 |  |  | $ | 3.5 |  |  | $ | 7.3 |  |  | $ | 9.4 |  |  | Cost of goods sold |
| Income tax expense |  | (0.1 | ) |  | (1.3 | ) |  | (1.7 | ) |  | (3.4 | ) |  | Provision for income taxes |
| Net of tax |  | $ | 0.2 |  |  | $ | 2.2 |  |  | $ | 5.6 |  |  | $ | 6.0 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (2.4 | ) |  | $ | (1.8 | ) |  | $ | (7.0 | ) |  | $ | (5.5 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.6 |  |  | 0.7 |  |  | 1.7 |  |  | 2.0 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.8 | ) |  | $ | (1.1 | ) |  | $ | (5.3 | ) |  | $ | (3.5 | ) |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency adjustments upon sale of business |  | $ | (5.0 | ) |  | $ | — |  |  | $ | (27.9 | ) |  | $ | — |  |  | Loss (gain), net on sale of businesses and related property |
| Income tax benefit |  | — |  |  | — |  |  | — |  |  | — |  |  | Provision for income taxes |
| Net of tax |  | $ | (5.0 | ) |  | $ | — |  |  | $ | (27.9 | ) |  | $ | — |  |  |  |
| Total reclassifications from AOCL |  | $ | (6.6 | ) |  | $ | 1.1 |  |  | $ | (27.6 | ) |  | $ | 2.5 |  |  |  |

[0001069202-18-000020:notes:29]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2018 (in millions):

[0001069202-18-000020:notes:30]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2017 |  | $ | 7.4 |  |  | $ | 1.8 |  |  | $ | (127.5 | ) |  | $ | (39.1 | ) |  | $ | (157.4 | ) |
| Other comprehensive loss before reclassifications |  | (5.6 | ) |  | (1.8 | ) |  | (29.0 | ) |  | (9.4 | ) |  | (45.8 | ) |
| Amounts reclassified from AOCL |  | (5.6 | ) |  | — |  |  | 5.3 |  |  | 27.9 |  |  | 27.6 |  |
| Net other comprehensive (loss) income |  | (11.2 | ) |  | (1.8 | ) |  | (23.7 | ) |  | 18.5 |  |  | (18.2 | ) |
| Balance as of September 30, 2018 |  | $ | (3.8 | ) |  | $ | — |  |  | $ | (151.2 | ) |  | $ | (20.6 | ) |  | $ | (175.6 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-18-000020:notes:31]
[same as prior period, unchanged from 0001069202-18-000013:notes:27]

[0001069202-18-000020:notes:32]
[same as prior period, unchanged from 0001069202-18-000013:notes:28]

[0001069202-18-000020:notes:33]
The condensed consolidating financial statements reflect our investments in our subsidiaries using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Our condensed consolidating financial statements and our Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of September 30, 2018 and December 31, 2017, and for the three and nine months ended September 30, 2018 and 2017 are shown on the following pages.

[0001069202-18-000020:notes:34]
[same as prior period, unchanged from 0001069202-18-000013:notes:30]

[0001069202-18-000020:notes:35]
[same as prior period, unchanged from 0001069202-18-000013:notes:31]

[0001069202-18-000020:notes:36]
As of September 30, 2018

[0001069202-18-000020:notes:37]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.4 |  |  | $ | 24.0 |  |  | $ | 20.7 |  |  | $ | — |  |  | $ | 46.1 |  |
| Accounts and notes receivable, net | — |  |  | 54.7 |  |  | 526.2 |  |  | — |  |  | 580.9 |  |
| Inventories, net | — |  |  | 403.4 |  |  | 102.8 |  |  | (4.7 | ) |  | 501.5 |  |
| Other assets | 3.3 |  |  | 35.2 |  |  | 54.0 |  |  | (33.8 | ) |  | 58.7 |  |
| Total current assets | 4.7 |  |  | 517.3 |  |  | 703.7 |  |  | (38.5 | ) |  | 1,187.2 |  |
| Property, plant and equipment, net | — |  |  | 262.3 |  |  | 115.9 |  |  | (3.8 | ) |  | 374.4 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.8 |  |  | — |  |  | 186.9 |  |
| Investment in subsidiaries | 1,785.7 |  |  | 337.5 |  |  | (0.5 | ) |  | (2,122.7 | ) |  | — |  |
| Deferred income taxes | 6.6 |  |  | 75.5 |  |  | 25.5 |  |  | (12.2 | ) |  | 95.4 |  |
| Other assets, net | 1.5 |  |  | 49.8 |  |  | 17.0 |  |  | (1.4 | ) |  | 66.9 |  |
| Intercompany (payables) receivables, net | (1,140.1 | ) |  | 1,113.4 |  |  | 129.5 |  |  | (102.8 | ) |  | — |  |
| Total assets | $ | 658.4 |  |  | $ | 2,521.9 |  |  | $ | 1,011.9 |  |  | $ | (2,281.4 | ) |  | $ | 1,910.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Current maturities of long-term debt | 21.9 |  |  | 0.1 |  |  | 0.3 |  |  | — |  |  | 22.3 |  |
| Accounts payable | 25.8 |  |  | 242.9 |  |  | 102.9 |  |  | — |  |  | 371.6 |  |
| Accrued expenses | 10.1 |  |  | 240.8 |  |  | 41.6 |  |  | — |  |  | 292.5 |  |
| Income taxes (receivable) payable | (25.1 | ) |  | 31.4 |  |  | 48.6 |  |  | (50.8 | ) |  | 4.1 |  |
| Total current liabilities | 32.7 |  |  | 515.2 |  |  | 193.4 |  |  | (50.8 | ) |  | 690.5 |  |
| Long-term debt | 714.7 |  |  | 11.6 |  |  | 377.3 |  |  | — |  |  | 1,103.6 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Pensions | — |  |  | 61.8 |  |  | 8.9 |  |  | — |  |  | 70.7 |  |
| Other liabilities | (2.2 | ) |  | 124.4 |  |  | 8.1 |  |  | — |  |  | 130.3 |  |
| Total liabilities | 745.2 |  |  | 715.5 |  |  | 587.7 |  |  | (50.8 | ) |  | 1,997.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' (deficit) equity | (86.8 | ) |  | 1,806.4 |  |  | 424.2 |  |  | (2,230.6 | ) |  | (86.8 | ) |
| Total liabilities and stockholders' (deficit) equity | $ | 658.4 |  |  | $ | 2,521.9 |  |  | $ | 1,011.9 |  |  | $ | (2,281.4 | ) |  | $ | 1,910.8 |  |

[0001069202-18-000020:notes:38]
[same as prior period, unchanged from 0001069202-18-000013:notes:34]

[0001069202-18-000020:notes:39]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.6 |  |  | $ | 28.0 |  |  | $ | 38.6 |  |  | $ | — |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net | — |  |  | 35.3 |  |  | 471.2 |  |  | — |  |  | 506.5 |  |
| Inventories, net | — |  |  | 355.7 |  |  | 131.9 |  |  | (3.4 | ) |  | 484.2 |  |
| Other assets | 16.2 |  |  | 23.1 |  |  | 67.5 |  |  | (28.4 | ) |  | 78.4 |  |
| Total current assets | 17.8 |  |  | 442.1 |  |  | 709.2 |  |  | (31.8 | ) |  | 1,137.3 |  |
| Property, plant and equipment, net | — |  |  | 257.6 |  |  | 144.4 |  |  | (4.2 | ) |  | 397.8 |  |
| Goodwill | — |  |  | 134.9 |  |  | 65.6 |  |  | — |  |  | 200.5 |  |
| Investment in subsidiaries | 1,257.7 |  |  | 365.8 |  |  | (0.6 | ) |  | (1,622.9 | ) |  | — |  |
| Deferred income taxes | 3.9 |  |  | 69.1 |  |  | 33.6 |  |  | (12.2 | ) |  | 94.4 |  |
| Other assets, net | 2.1 |  |  | 41.3 |  |  | 19.6 |  |  | (1.5 | ) |  | 61.5 |  |
| Intercompany (payables) receivables, net | (559.3 | ) |  | 554.7 |  |  | 107.4 |  |  | (102.8 | ) |  | — |  |
| Total assets | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.9 |  |  | 0.3 |  |  | — |  |  | 32.6 |  |
| Accounts payable | 21.3 |  |  | 228.0 |  |  | 99.3 |  |  | — |  |  | 348.6 |  |
| Accrued expenses | 3.1 |  |  | 209.4 |  |  | 57.8 |  |  | — |  |  | 270.3 |  |
| Income taxes (receivable) payable | (64.5 | ) |  | 56.5 |  |  | 60.9 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | (10.7 | ) |  | 496.8 |  |  | 219.2 |  |  | (50.8 | ) |  | 654.5 |  |
| Long-term debt | 682.8 |  |  | 11.7 |  |  | 276.0 |  |  | — |  |  | 970.5 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.6 |  |  | — |  |  | — |  |  | 2.6 |  |
| Pensions | — |  |  | 74.7 |  |  | 9.8 |  |  | — |  |  | 84.5 |  |
| Other liabilities | — |  |  | 120.6 |  |  | 8.7 |  |  | — |  |  | 129.3 |  |
| Total liabilities | 672.1 |  |  | 706.4 |  |  | 513.7 |  |  | (50.8 | ) |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 50.1 |  |  | 1,159.1 |  |  | 565.5 |  |  | (1,724.6 | ) |  | 50.1 |  |
| Total liabilities and stockholders' equity | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |

[0001069202-18-000020:notes:40]
[same as prior period, unchanged from 0001069202-18-000013:notes:36]

[0001069202-18-000020:notes:41]
For the Three Months Ended September 30, 2018

[0001069202-18-000020:notes:42]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 930.5 |  |  | $ | 283.6 |  |  | $ | (183.9 | ) |  | $ | 1,030.2 |  |
| Cost of goods sold | — |  |  | 660.5 |  |  | 252.1 |  |  | (184.3 | ) |  | 728.3 |  |
| Gross profit | — |  |  | 270.0 |  |  | 31.5 |  |  | 0.4 |  |  | 301.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 138.4 |  |  | 11.3 |  |  | (0.3 | ) |  | 149.4 |  |
| Losses (gains) and other expenses, net | 0.2 |  |  | 1.9 |  |  | 0.6 |  |  | — |  |  | 2.7 |  |
| Restructuring charges | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Loss (gain), net on sale of businesses and related property | — |  |  | 40.1 |  |  | (33.9 | ) |  | — |  |  | 6.2 |  |
| Loss from natural disaster, net of insurance recoveries | — |  |  | (1.7 | ) |  | 2.0 |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (109.7 | ) |  | (45.7 | ) |  | (1.6 | ) |  | 154.6 |  |  | (2.4 | ) |
| Operating income | 109.5 |  |  | 137.0 |  |  | 52.6 |  |  | (153.9 | ) |  | 145.2 |  |
| Interest expense, net | 2.0 |  |  | 5.0 |  |  | 3.3 |  |  | — |  |  | 10.3 |  |
| Other expense, net | — |  |  | 0.7 |  |  | 0.4 |  |  | — |  |  | 1.1 |  |
| Income (loss) from continuing operations before income taxes | 107.5 |  |  | 131.3 |  |  | 48.9 |  |  | (153.9 | ) |  | 133.8 |  |
| Provision for income tax (benefit) expense | (0.5 | ) |  | 13.3 |  |  | 12.9 |  |  | 0.1 |  |  | 25.8 |  |
| Income (loss) from continuing operations | 108.0 |  |  | 118.0 |  |  | 36.0 |  |  | (154.0 | ) |  | 108.0 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income (loss) | $ | 108.0 |  |  | $ | 118.0 |  |  | $ | 36.0 |  |  | $ | (154.0 | ) |  | $ | 108.0 |  |
| Other comprehensive (loss) income, net of tax | (2.5 | ) |  | 1.2 |  |  | 6.7 |  |  | — |  |  | 5.4 |  |
| Comprehensive income (loss) | $ | 105.5 |  |  | $ | 119.2 |  |  | $ | 42.7 |  |  | $ | (154.0 | ) |  | $ | 113.4 |  |

[0001069202-18-000020:notes:43]
For the Three Months Ended September 30, 2017

[0001069202-18-000020:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 905.6 |  |  | $ | 300.0 |  |  | $ | (153.3 | ) |  | $ | 1,052.3 |  |
| Cost of goods sold | — |  |  | 644.8 |  |  | 249.0 |  |  | (155.2 | ) |  | 738.6 |  |
| Gross profit | — |  |  | 260.8 |  |  | 51.0 |  |  | 1.9 |  |  | 313.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 140.7 |  |  | 18.8 |  |  | (0.8 | ) |  | 158.7 |  |
| Losses (gains) and other expenses, net | 0.2 |  |  | 1.9 |  |  | 0.9 |  |  | — |  |  | 3.0 |  |
| Restructuring charges | — |  |  | 1.2 |  |  | 0.7 |  |  | — |  |  | 1.9 |  |
| Income from equity method investments | (108.2 | ) |  | (21.7 | ) |  | (3.5 | ) |  | 128.9 |  |  | (4.5 | ) |
| Operating income | 108.0 |  |  | 138.7 |  |  | 34.1 |  |  | (126.2 | ) |  | 154.6 |  |
| Interest expense, net | 6.2 |  |  | (0.6 | ) |  | 2.0 |  |  | — |  |  | 7.6 |  |
| Other expense, net | — |  |  | — |  |  | 0.2 |  |  | (0.2 | ) |  | — |  |
| Income from continuing operations before income taxes | 101.8 |  |  | 139.3 |  |  | 31.9 |  |  | (126.0 | ) |  | 147.0 |  |
| Provision for income tax (benefit) expense | (1.7 | ) |  | 30.5 |  |  | 13.5 |  |  | 0.7 |  |  | 43.0 |  |
| Income from continuing operations | 103.5 |  |  | 108.8 |  |  | 18.4 |  |  | (126.7 | ) |  | 104.0 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Net income | $ | 103.5 |  |  | $ | 108.8 |  |  | $ | 17.9 |  |  | $ | (126.7 | ) |  | $ | 103.5 |  |
| Other comprehensive income (loss), net of tax | 0.4 |  |  | 2.1 |  |  | 6.9 |  |  | — |  |  | 9.4 |  |
| Comprehensive income (loss) | $ | 103.9 |  |  | $ | 110.9 |  |  | $ | 24.8 |  |  | $ | (126.7 | ) |  | $ | 112.9 |  |

[0001069202-18-000020:notes:45]
[same as prior period, unchanged from 0001069202-18-000013:notes:41]

[0001069202-18-000020:notes:46]
For the Nine Months Ended  September 30, 2018

[0001069202-18-000020:notes:47]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 57.2 |  |  | $ | 362.5 |  |  | $ | (188.4 | ) |  | $ | — |  |  | $ | 231.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (46.1 | ) |  | (14.8 | ) |  | — |  |  | (60.9 | ) |
| Net proceeds from sale of businesses and related property | — |  |  | 4.0 |  |  | 111.9 |  |  | — |  |  | 115.9 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 4.2 |  |  | — |  |  | — |  |  | 4.2 |  |
| Net cash (used in) provided by investing activities | — |  |  | (37.9 | ) |  | 97.2 |  |  | — |  |  | 59.3 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.5 | ) |  | — |  |  | (1.5 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 155.0 |  |  | — |  |  | 155.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (53.7 | ) |  | — |  |  | (53.7 | ) |
| Long-term debt payments | (30.0 | ) |  | (2.8 | ) |  | (0.1 | ) |  | — |  |  | (32.9 | ) |
| Long-term borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Borrowings from credit facility | 1,820.0 |  |  | — |  |  | — |  |  | — |  |  | 1,820.0 |  |
| Payments on credit facility | (1,766.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,766.5 | ) |
| Proceeds from employee stock purchases | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |
| Repurchases of common stock | (350.2 | ) |  | — |  |  | — |  |  | — |  |  | (350.2 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (21.1 | ) |  | — |  |  | — |  |  | — |  |  | (21.1 | ) |
| Intercompany debt | (29.8 | ) |  | 83.3 |  |  | (53.5 | ) |  | — |  |  | — |  |
| Intercompany financing activity | 385.9 |  |  | (406.3 | ) |  | 20.4 |  |  | — |  |  | — |  |
| Cash dividends paid | (68.2 | ) |  | — |  |  | — |  |  | — |  |  | (68.2 | ) |
| Net cash (used in) provided by financing activities | (57.4 | ) |  | (325.8 | ) |  | 66.6 |  |  | — |  |  | (316.6 | ) |
| Decrease in cash and cash equivalents | (0.2 | ) |  | (1.2 | ) |  | (24.6 | ) |  | — |  |  | (26.0 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | (2.8 | ) |  | 6.7 |  |  | — |  |  | 3.9 |  |
| Cash and cash equivalents, beginning of period | 1.6 |  |  | 28.0 |  |  | 38.6 |  |  | — |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 1.4 |  |  | $ | 24.0 |  |  | $ | 20.7 |  |  | $ | — |  |  | $ | 46.1 |  |

[0001069202-18-000020:notes:48]
For the Nine Months Ended  September 30, 2017

[0001069202-18-000020:notes:49]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 411.6 |  |  | $ | (2.4 | ) |  | $ | (279.6 | ) |  | $ | (0.6 | ) |  | $ | 129.0 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (48.3 | ) |  | (12.2 | ) |  | — |  |  | (60.5 | ) |
| Net cash (used in) provided by investing activities | — |  |  | (48.2 | ) |  | (12.2 | ) |  | 0.1 |  |  | (60.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.4 | ) |  | — |  |  | (1.4 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 275.0 |  |  | — |  |  | 275.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | (200.0 | ) |  | (0.2 | ) |  | (0.1 | ) |  | (0.5 | ) |  | (200.8 | ) |
| Long-term borrowings | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Borrowings from credit facility | 1,883.0 |  |  | (0.2 | ) |  | (0.2 | ) |  | 0.4 |  |  | 1,883.0 |  |
| Payments on credit facility | (1,701.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,701.0 | ) |
| Proceeds from employee stock purchases | 2.3 |  |  | — |  |  | — |  |  | — |  |  | 2.3 |  |
| Repurchases of common stock | (250.0 | ) |  | — |  |  | — |  |  | — |  |  | (250.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (16.0 | ) |  | — |  |  | — |  |  | — |  |  | (16.0 | ) |
| Intercompany debt | 102.8 |  |  | (34.8 | ) |  | (68.0 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (174.3 | ) |  | 91.0 |  |  | 82.7 |  |  | 0.6 |  |  | — |  |
| Cash dividends paid | (58.4 | ) |  | — |  |  | — |  |  | — |  |  | (58.4 | ) |
| Net cash (used in) provided by financing activities | (411.6 | ) |  | 55.9 |  |  | 287.9 |  |  | 0.5 |  |  | (67.3 | ) |
| Increase (decrease) in cash and cash equivalents | — |  |  | 5.3 |  |  | (3.9 | ) |  | — |  |  | 1.4 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 9.1 |  |  | — |  |  | 9.1 |  |
| Cash and cash equivalents, beginning of period | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of period | $ | 1.2 |  |  | $ | 22.4 |  |  | $ | 37.1 |  |  | $ | — |  |  | $ | 60.7 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001069202-18-000020:notes:50]
[same as prior period, unchanged from 0001069202-18-000013:notes:46]

[0001069202-18-000020:notes:51]
|  | September 30, 2018 |  | December 31, 2017 |  | $ Change |  | % Change |
| Contract assets | $ | 3.5 |  |  | $ | 2.1 |  |  | $ | 1.4 |  |  | 66.7 | % |
| Contract liabilities - current | (6.2 | ) |  | (7.3 | ) |  | 1.1 |  |  | (15.1 | )% |
| Contract liabilities - noncurrent | (6.0 | ) |  | (5.5 | ) |  | (0.5 | ) |  | 9.1 | % |
| Total | $ | (8.7 | ) |  | $ | (10.7 | ) |  | $ | 2.0 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-18-000020:notes:52]
Lines of Credit and Financing Arrangements:

[0001069202-18-000020:notes:53]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000020:notes:54]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | — |  |  | $ | 0.9 |  |
| Total short-term debt | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 22.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 22.3 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 377.3 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 368.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.6 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,103.6 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,125.9 |  |  | $ | 1,004.0 |  |

[0001069202-18-000020:notes:55]
Short-Term Debt

[0001069202-18-000020:notes:56]
Foreign Obligations

[0001069202-18-000020:notes:57]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $0.0 million and $0.9 million of foreign obligations outstanding as of September 30, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $40.2 million  and $19.1 million during the nine months ended September 30, 2018 and 2017, respectively. Repayments on the facilities were $38.5 million and $20.5 million during the nine months ended September 30, 2018 and 2017, respectively.

[0001069202-18-000020:notes:58]
Asset Securitization Program

[0001069202-18-000020:notes:59]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001069202-18-000020:notes:60]
The ASP provides for a maximum securitization amount ranging from $225.0 million to $380.0 million, depending on the period. The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-18-000020:notes:61]
|  | September 30, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 380.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (377.3 | ) |  | (276.0 | ) |
| Remaining amount available | $ | 2.7 |  |  | $ | 14.0 |  |

[0001069202-18-000020:notes:62]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2018 and December 31, 2017 were 2.98% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-18-000020:notes:63]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of September 30, 2018, we believe we were in compliance with all covenant requirements.

[0001069202-18-000020:notes:64]
Long-Term Debt

[0001069202-18-000020:notes:65]
Domestic Credit Facility

[0001069202-18-000020:notes:66]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $390.5 million, of which $190.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of September 30, 2018. Subject to covenant limitations, $447.0 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-18-000020:notes:67]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-18-000020:notes:68]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-18-000020:notes:69]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-18-000020:notes:70]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-18-000020:notes:71]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-18-000020:notes:72]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2018, we believe we were in compliance with all covenant requirements.

[0001069202-18-000020:notes:73]
Senior Unsecured Notes

[0001069202-18-000020:notes:74]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2018, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-18-000020:notes:75]
[same as prior period, unchanged from 0001069202-18-000013:notes:71]

[0001069202-18-000020:notes:76]
[same as prior period, unchanged from 0001069202-18-000013:notes:72]

[0001069202-18-000020:notes:77]
[same as prior period, unchanged from 0001069202-18-000013:notes:73]

[0001069202-18-000020:notes:78]
[same as prior period, unchanged from 0001069202-18-000013:notes:74]

[0001069202-18-000020:notes:79]
[same as prior period, unchanged from 0001069202-18-000013:notes:75]

[0001069202-18-000020:notes:80]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 intends to simplify the application of hedge accounting guidance and better align an entity's risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results. The amendments expand and refine hedge accounting for both nonfinancial and financial risk components and align the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. We early adopted ASU No. 2017-12 during the first quarter of 2018. The adoption of ASU No. 2017-12 did not have a material impact on our consolidated results of operations, cash flows, and statement of financial position. With the early adoption of ASU No. 2017-12 we began entering into commodity futures contracts designated as cash flow hedges related to aluminum purchases.

[0001069202-18-000020:notes:81]
[same as prior period, unchanged from 0001069202-18-000013:notes:77]

[0001069202-18-000020:notes:82]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through December 2018 and February 2020, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-18-000020:notes:83]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Unrealized losses (gains) on unsettled contracts | $ | 4.9 |  |  | $ | (11.3 | ) |
| Income tax (benefit) expense | (1.1 | ) |  | 3.9 |  |
| Losses (Gains) included in AOCL, net of tax (1) | $ | 3.8 |  |  | $ | (7.4 | ) |

[0001069202-18-000020:notes:84]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $2.9 million of derivative losses into earnings within the next 12 months.

[0001069202-18-000020:notes:85]
[same as prior period, unchanged from 0001069202-18-000013:notes:81]

[0001069202-18-000020:notes:86]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Copper | 13.7 |  |  | 20.6 |  |
| Aluminum | 29.3 |  |  | — |  |

[0001069202-18-000020:notes:87]
[same as prior period, unchanged from 0001069202-18-000013:notes:83]

[0001069202-18-000020:notes:88]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 49.2 |  |  | 207.3 |  |
| Canadian Dollar | 12.6 |  |  | 68.6 |  |

[0001069202-18-000020:notes:89]
[same as prior period, unchanged from 0001069202-18-000013:notes:85]

[0001069202-18-000020:notes:90]
[same as prior period, unchanged from 0001069202-18-000013:notes:86]

[0001069202-18-000020:notes:91]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Copper | 0.8 |  |  | 1.8 |  |
| Aluminum | 1.0 |  |  | 1.8 |  |

[0001069202-18-000020:notes:92]
[same as prior period, unchanged from 0001069202-18-000013:notes:88]

[0001069202-18-000020:notes:93]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Notional Amounts (in local currency): |  |  |  |
| Chinese Yuan | — |  |  | 73.8 |  |
| Mexican Peso | 68.0 |  |  | 136.6 |  |
| Euro | 28.8 |  |  | 64.4 |  |
| Canadian Dollar | 23.0 |  |  | 27.3 |  |
| British Pound | 8.3 |  |  | 4.5 |  |
| Singapore Dollar | — |  |  | 7.0 |  |
| Australian Dollar | — |  |  | 107.0 |  |
| New Zealand Dollar | — |  |  | 5.0 |  |
| Indian Rupee | — |  |  | 39.8 |  |

[0001069202-18-000020:notes:94]
[same as prior period, unchanged from 0001069202-18-000013:notes:90]

[0001069202-18-000020:notes:95]
[same as prior period, unchanged from 0001069202-18-000013:notes:91]

[0001069202-18-000020:notes:96]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of September 30, 2018 |  | As of December 31, 2017 |  | As of September 30, 2018 |  | As of December 31, 2017 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 11.0 |  |  | $ | — |  |  | $ | 1.2 |  |
| Foreign currency forward contracts | 0.5 |  |  | 0.1 |  |  | — |  |  | 0.9 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.6 |  |  | — |  |  | 0.1 |  |
| Total Assets | $ | 0.5 |  |  | $ | 11.7 |  |  | $ | — |  |  | $ | 2.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 5.2 |  |  | $ | — |  |  | $ | 0.3 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | 0.3 |  |  | 0.1 |  |  | 1.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.3 |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 5.5 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 1.1 |  |

[0001069202-18-000020:notes:97]
[same as prior period, unchanged from 0001069202-18-000013:notes:93]

[0001069202-18-000020:notes:98]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amount of Gain reclassified from AOCL into Income (effective portion) (1) |  | $ | (0.3 | ) |  | $ | (3.5 | ) |  | $ | (7.3 | ) |  | $ | (9.4 | ) |
| Amount of (Gains)/Loss recognized in Net income (ineffective portion) (2)(3) |  | — |  |  | (0.1 | ) |  | $ | — |  |  | 1.1 |  |

[0001069202-18-000020:notes:99]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amount of Loss/(Gain) Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | 0.3 |  |  | $ | (0.2 | ) |  | $ | 0.9 |  |  | $ | (1.3 | ) |
| Foreign currency forward contracts (2) |  | — |  |  | (0.4 | ) |  | (0.3 | ) |  | (4.3 | ) |
|  |  | $ | 0.3 |  |  | $ | (0.6 | ) |  | $ | 0.6 |  |  | $ | (5.6 | ) |

[0001069202-18-000020:notes:100]
[same as prior period, unchanged from 0001069202-18-000013:notes:96]

[0001069202-18-000020:notes:101]
[same as prior period, unchanged from 0001069202-18-000013:notes:97]

[0001069202-18-000020:notes:102]
(3) ASU 2017-12 eliminates the requirement to disclose the amount of hedge ineffectiveness prospectively because this        amount is no longer separately measured and reported.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-18-000020:notes:103]
[same as prior period, unchanged from 0001069202-18-000013:notes:99]

[0001069202-18-000020:notes:104]
[same as prior period, unchanged from 0001069202-18-000013:notes:100]

[0001069202-18-000020:notes:105]
|  | For the Three Months Ended September 30, | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 | 2018 |  | 2017 |
| Stock-based compensation expense (1) | $ | 7.4 |  |  | $ | 6.3 |  | $ | 21.0 |  |  | $ | 18.8 |  |

[0001069202-18-000020:notes:106]
[same as prior period, unchanged from 0001069202-18-000013:notes:102]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-18-000020:notes:107]
[same as prior period, unchanged from 0001069202-18-000013:notes:103]

[0001069202-18-000020:notes:108]
[same as prior period, unchanged from 0001069202-18-000013:notes:104]

[0001069202-18-000020:notes:109]
During the first quarter of 2018, we obtained board approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia, New Zealand and Asia business except for the Milperra property that was sold during the second quarter of 2018. We completed the sale to Beijer Ref AB in the second quarter of 2018 with the final post-completion adjustment being recorded in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-18-000020:notes:110]
| (Amounts in millions) | For the Nine Months Ended September 30, 2018 |
| Cash received from the buyer | $ | 82.9 |  |
| Net assets sold (1) | (87.2 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (3.2 | ) |
| Direct costs to sell | (5.5 | ) |
| Loss on sale of business | $ | (13.0 | ) |

[0001069202-18-000020:notes:111]
[same as prior period, unchanged from 0001069202-18-000013:notes:107]

[0001069202-18-000020:notes:112]
[same as prior period, unchanged from 0001069202-18-000013:notes:108]

[0001069202-18-000020:notes:113]
[same as prior period, unchanged from 0001069202-18-000013:notes:109]

[0001069202-18-000020:notes:114]
During the second quarter of 2018, we obtained board approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale was subject to Brazilian antitrust approval.  We obtained antitrust approval and completed the sale to Elgin SA in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-18-000020:notes:115]
| (Amounts in millions) | For the Nine Months Ended September 30, 2018 |
| Cash received from the buyer | $ | 4.2 |  |
| Net assets sold (2) | (13.2 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (24.7 | ) |
| Direct costs to sell | (2.9 | ) |
| Loss on sale of business | $ | (36.6 | ) |

[0001069202-18-000020:notes:116]
(2) Includes $1.2 of net assets that were written down during the quarter ended June 30, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Brazil business.

[0001069202-18-000020:notes:117]
The total Loss (gain), net on sale of businesses and related property in our Consolidated Statements of Operations of $25.8 million  is comprised of the $13.0 million loss on the sale of our Australia, New Zealand and Asia business, the $23.8 million gain on the sale of our Milperra property, and the $36.6 million loss on the sale of our Brazil business.


## us-gaap:EarningsPerShareTextBlock

[0001069202-18-000020:notes:118]
[same as prior period, unchanged from 0001069202-18-000013:notes:114]

[0001069202-18-000020:notes:119]
[same as prior period, unchanged from 0001069202-18-000013:notes:115]

[0001069202-18-000020:notes:120]
[same as prior period, unchanged from 0001069202-18-000013:notes:116]

[0001069202-18-000020:notes:121]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net income | $ | 108.0 |  |  | $ | 103.5 |  |  | $ | 283.4 |  |  | $ | 262.5 |  |
| Add: Loss from discontinued operations | — |  |  | 0.5 |  |  | 1.7 |  |  | 1.4 |  |
| Income from continuing operations | $ | 108.0 |  |  | $ | 104.0 |  |  | $ | 285.1 |  |  | $ | 263.9 |  |
| Weighted-average shares outstanding – basic | 40.3 |  |  | 41.9 |  |  | 40.8 |  |  | 42.3 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.4 |  |  | 0.5 |  |  | 0.5 |  |  | 0.6 |  |
| Weighted-average shares outstanding – diluted | 40.7 |  |  | 42.4 |  |  | 41.3 |  |  | 42.9 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.68 |  |  | $ | 2.48 |  |  | $ | 6.98 |  |  | $ | 6.23 |  |
| Loss from discontinued operations | — |  |  | (0.01 | ) |  | (0.04 | ) |  | (0.03 | ) |
| Net income | $ | 2.68 |  |  | $ | 2.47 |  |  | $ | 6.94 |  |  | $ | 6.20 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.65 |  |  | $ | 2.45 |  |  | $ | 6.90 |  |  | $ | 6.15 |  |
| Loss from discontinued operations | — |  |  | (0.01 | ) |  | (0.04 | ) |  | (0.03 | ) |
| Net income | $ | 2.65 |  |  | $ | 2.44 |  |  | $ | 6.86 |  |  | $ | 6.12 |  |

[0001069202-18-000020:notes:122]
[same as prior period, unchanged from 0001069202-18-000013:notes:118]

[0001069202-18-000020:notes:123]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Weighted-average number of shares | 0.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Price per share | $ | 205.53 |  |  | $ | 156.94 |  |  | $ | 205.53 |  |  | $ | 156.94 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-18-000020:notes:124]
[same as prior period, unchanged from 0001069202-18-000013:notes:120]

[0001069202-18-000020:notes:125]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Senior unsecured notes | $ | 293.2 |  |  | $ | 308.1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-18-000020:notes:126]
[same as prior period, unchanged from 0001069202-18-000013:notes:122]

[0001069202-18-000020:notes:127]
[same as prior period, unchanged from 0001069202-18-000013:notes:123]

[0001069202-18-000020:notes:128]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2018 were the same as those used at December 31, 2017.

[0001069202-18-000020:notes:129]
[same as prior period, unchanged from 0001069202-18-000013:notes:125]

[0001069202-18-000020:notes:130]
[same as prior period, unchanged from 0001069202-18-000013:notes:126]

[0001069202-18-000020:notes:131]
[same as prior period, unchanged from 0001069202-18-000013:notes:127]

[0001069202-18-000020:notes:132]
[same as prior period, unchanged from 0001069202-18-000013:notes:128]

[0001069202-18-000020:notes:133]
[same as prior period, unchanged from 0001069202-18-000013:notes:129]

[0001069202-18-000020:notes:134]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Investment in marketable equity securities | $ | — |  |  | $ | 4.1 |  |

[0001069202-18-000020:notes:135]
[same as prior period, unchanged from 0001069202-18-000013:notes:131]

[0001069202-18-000020:notes:136]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-18-000020:notes:137]
[same as prior period, unchanged from 0001069202-18-000013:notes:133]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-18-000020:notes:138]
[same as prior period, unchanged from 0001069202-18-000013:notes:134]

[0001069202-18-000020:notes:139]
The changes in the carrying amount of goodwill for the first nine months of 2018, in total and by segment, are summarized in the table below (in millions):

[0001069202-18-000020:notes:140]
|  | Balance at December 31, 2017 |  | Write-off due to divested businesses |  | Changes in foreign currency translation rates |  | Balance at September 30, 2018 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 62.2 |  |  | — |  |  | (0.5 | ) |  | 61.7 |  |
| Refrigeration | 112.2 |  |  | (11.5 | ) |  | (1.6 | ) |  | 99.1 |  |
| Total Goodwill | $ | 200.5 |  |  | $ | (11.5 | ) |  | $ | (2.1 | ) |  | $ | 186.9 |  |

[0001069202-18-000020:notes:141]
We perform our annual goodwill impairment test in the fourth quarter of each year.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  In the current year, we wrote off $11.5 million of goodwill as a part of the completed sales of our Australia, New Zealand, Asia and Brazil businesses (discussed further in Note 14 of the Notes to the Consolidated Financial Statements).


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-18-000020:notes:142]
[same as prior period, unchanged from 0001069202-18-000013:notes:138]

[0001069202-18-000020:notes:143]
As of September 30, 2018, we had approximately $0.3 million in total gross unrecognized tax benefits and of this amount, all if recognized, would be recorded through the Consolidated Statement of Operations.  As of September 30, 2018, we had an insignificant amount in interest recognized in income tax expense in accordance with FASB Accounting Standards Codification (“ASC”) Topic 740.

[0001069202-18-000020:notes:144]
[same as prior period, unchanged from 0001069202-18-000013:notes:140]

[0001069202-18-000020:notes:145]
[same as prior period, unchanged from 0001069202-18-000013:notes:141]

[0001069202-18-000020:notes:146]
On October 24, 2016, the FASB issued ASU No. 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory, which requires companies to recognize the income tax effects of intercompany sales and transfers of assets other than inventory in the period in which the transfer occurs.  Prior to ASU 2016-16, companies were required to defer the income tax effects of intercompany transfers of assets until the asset had been sold to an outside party or otherwise recognized.  The new guidance is effective for public business entities for annual periods beginning after December 15, 2017 and interim periods within those annual periods.  The guidance requires companies to apply a modified retrospective approach with a cumulative catch-up adjustment to opening retained earnings in the period of adoption.  Accordingly, we recorded a $5.1 million decrease to opening retained earnings in the period ending March 31, 2018.

[0001069202-18-000020:notes:147]
[same as prior period, unchanged from 0001069202-18-000013:notes:143]

[0001069202-18-000020:notes:148]
On February 14, 2018, the FASB issued ASU No. 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits companies to reclassify stranded tax effects caused by 2017 tax reform between accumulated other comprehensive income (“AOCI”) and retained earnings.  We have elected to adopt ASU 2018-02 to reclassify the income tax effects of the 2017 Act from AOCI to retained earnings for the period ending March 31, 2018.  Accordingly, we recorded a $22.7 million increase to opening retained earnings in the period ending March 31, 2018 to reclassify the effect of the change in the U.S. federal corporate income tax rate, including the reduction in the federal benefit associated with state taxes, on the gross deferred tax amounts and related valuation allowances at the date of enactment of the Tax Cuts and Jobs Act related to items remaining in AOCI.

[0001069202-18-000020:notes:149]
[same as prior period, unchanged from 0001069202-18-000013:notes:145]

[0001069202-18-000020:notes:150]
Due to the Tax Act, several applications for changes in accounting method have been filed with the IRS to accelerate deductions into the 2017 U.S. federal income tax return.  As of September 30, 2018 we have recognized discrete tax benefits of $4.3 million associated with the finalization of the calculations for accounting method changes for credit reserves, prepaid expenses, IBNR medical expenses and depreciable asset reclassifications and repairs.  In addition, we have recognized a discrete tax benefit of $3.0 million associated with the finalization of the Domestic Production Activities deduction due to Tax Act impacts.  As of September 30, 2018, we have recognized a discrete tax expense of $2.7 million for the transition tax on the mandatory deemed repatriation of undistributed foreign earnings required by the Tax Act and $0.1 million of tax expense due to changes in estimate of the decrease of our net federal deferred tax assets (“DTA”) from our year-end provision.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-18-000020:notes:151]
[same as prior period, unchanged from 0001069202-18-000013:notes:147]

[0001069202-18-000020:notes:152]
[same as prior period, unchanged from 0001069202-18-000013:notes:148]

[0001069202-18-000020:notes:153]
|  | As of September 30, 2018 |  | As of December 31, 2017 |
| Finished goods | $ | 315.4 |  |  | $ | 331.9 |  |
| Work in process | 6.3 |  |  | 5.5 |  |
| Raw materials and parts | 232.2 |  |  | 199.2 |  |
| Subtotal | 553.9 |  |  | 536.6 |  |
| Excess of current cost over last-in, first-out cost | (52.4 | ) |  | (52.4 | ) |
| Total inventories, net | $ | 501.5 |  |  | $ | 484.2 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001069202-18-000020:notes:154]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.  We will adopt the standard using the prospective approach.  We have completed a qualitative and quantitative assessment of our lease portfolio and are in the process of testing our new lease accounting system, collecting data for leases entered into during 2018 and implementing new processes and controls to account for our leases in accordance with the new standard.  Upon adoption, we expect to record right-of-use assets and operating lease liabilities between $150 million and $200 million in our Consolidated Balance Sheet.

[0001069202-18-000020:notes:155]
In August 2018, the SEC issued Release No. 33-10532 that amends and clarifies certain financial reporting requirements.  The principal change to our financial reporting will be the inclusion of the annual disclosure requirement of changes in stockholders’ equity in Rule 3-04 of Regulation S-X to interim periods.  We will adopt this new rule beginning with our financial reporting for the quarter ended March 31, 2019.  Upon adoption, we will include our Consolidated Statements of Stockholders' Equity with each quarterly filing on Form 10-Q.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-18-000020:notes:156]
[same as prior period, unchanged from 0001069202-18-000013:notes:151]

[0001069202-18-000020:notes:157]
[same as prior period, unchanged from 0001069202-18-000013:notes:152]

[0001069202-18-000020:notes:158]
[same as prior period, unchanged from 0001069202-18-000013:notes:153]

[0001069202-18-000020:notes:159]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-18-000020:notes:160]
[same as prior period, unchanged from 0001069202-18-000013:notes:155]

[0001069202-18-000020:notes:161]
[same as prior period, unchanged from 0001069202-18-000013:notes:156]

[0001069202-18-000020:notes:162]
[same as prior period, unchanged from 0001069202-18-000013:notes:157]

[0001069202-18-000020:notes:163]
Recently Adopted Accounting Guidance

[0001069202-18-000020:notes:164]
In August 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees. For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017. This standard did not have a material impact on our consolidated financial statements.

[0001069202-18-000020:notes:165]
[same as prior period, unchanged from 0001069202-18-000013:notes:160]

[0001069202-18-000020:notes:166]
[same as prior period, unchanged from 0001069202-18-000013:notes:161]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-18-000020:notes:167]
[same as prior period, unchanged from 0001069202-18-000013:notes:162]

[0001069202-18-000020:notes:168]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other expense (income), net in the Statement of Operations. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We elected the practical expedient to use the prior year's disclosure as a basis for the retroactive adoption of the ASU.  The ASU did not have a material impact on our financial results.

[0001069202-18-000020:notes:169]
[same as prior period, unchanged from 0001069202-18-000013:notes:164]

[0001069202-18-000020:notes:170]
|  | For the Three Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.1 |  |  | 3.2 |  |  | — |  |  | — |  |
| Expected return on plan assets | (4.7 | ) |  | (5.3 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | — |  |  | (0.3 | ) |  | (0.6 | ) |
| Recognized actuarial loss | 2.3 |  |  | 2.0 |  |  | 0.3 |  |  | 0.4 |  |
| Settlements and curtailments | 0.3 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 2.4 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | (0.2 | ) |

[0001069202-18-000020:notes:171]
|  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 4.0 |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 9.3 |  |  | 9.5 |  |  | — |  |  | — |  |
| Expected return on plan assets | (14.1 | ) |  | (16.0 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (1.0 | ) |  | (1.8 | ) |
| Recognized actuarial loss | 6.9 |  |  | 6.1 |  |  | 1.0 |  |  | 1.1 |  |
| Settlements and curtailments | 0.3 |  |  | 0.6 |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 6.5 |  |  | $ | 4.1 |  |  | $ | — |  |  | $ | (0.7 | ) |

[0001069202-18-000020:notes:172]
[same as prior period, unchanged from 0001069202-18-000013:notes:167]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-18-000020:notes:173]
[same as prior period, unchanged from 0001069202-18-000013:notes:168]

[0001069202-18-000020:notes:174]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 594.7 |  |  | $ | 590.5 |  |  | $ | 1,764.4 |  |  | $ | 1,663.8 |  |
| Commercial Heating & Cooling | 275.8 |  |  | 269.4 |  |  | 773.5 |  |  | 723.5 |  |
| Refrigeration | 159.7 |  |  | 192.4 |  |  | 502.5 |  |  | 560.6 |  |
|  | $ | 1,030.2 |  |  | $ | 1,052.3 |  |  | $ | 3,040.4 |  |  | $ | 2,947.9 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 113.0 |  |  | $ | 114.7 |  |  | $ | 317.9 |  |  | $ | 297.6 |  |
| Commercial Heating & Cooling | 46.7 |  |  | 50.0 |  |  | 118.9 |  |  | 113.8 |  |
| Refrigeration | 23.0 |  |  | 20.0 |  |  | 55.8 |  |  | 55.7 |  |
| Corporate and other | (28.1 | ) |  | (23.7 | ) |  | (61.8 | ) |  | (58.5 | ) |
| Total segment profit | 154.6 |  |  | 161.0 |  |  | 430.8 |  |  | 408.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special inventory write down | — |  |  | — |  |  | 0.2 |  |  | — |  |
| Special product quality adjustment | — |  |  | 0.5 |  |  | — |  |  | 5.7 |  |
| Loss (gain), net on sale of businesses and related property | 6.2 |  |  | — |  |  | 25.8 |  |  | — |  |
| Loss from natural disaster, net of insurance recoveries | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 2.4 |  |  | 4.0 |  |  | 9.3 |  |  | 10.0 |  |
| Restructuring charges | 0.5 |  |  | 1.9 |  |  | 1.9 |  |  | 2.1 |  |
| Operating income | $ | 145.2 |  |  | $ | 154.6 |  |  | $ | 393.3 |  |  | $ | 390.8 |  |

[0001069202-18-000020:notes:175]
[same as prior period, unchanged from 0001069202-18-000013:notes:170]

[0001069202-18-000020:notes:176]
[same as prior period, unchanged from 0001069202-18-000013:notes:171]

[0001069202-18-000020:notes:177]
[same as prior period, unchanged from 0001069202-18-000013:notes:172]

[0001069202-18-000020:notes:178]
| ◦ | Special legal contingency charges, |

[0001069202-18-000020:notes:179]
| ◦ | Asbestos-related litigation, |

[0001069202-18-000020:notes:180]
[same as prior period, unchanged from 0001069202-18-000013:notes:176]

[0001069202-18-000020:notes:181]
[same as prior period, unchanged from 0001069202-18-000013:notes:177]

[0001069202-18-000020:notes:182]
[same as prior period, unchanged from 0001069202-18-000013:notes:178]

[0001069202-18-000020:notes:183]
| • | Special inventory write down, |

[0001069202-18-000020:notes:184]
| • | Loss (gain), net on sale of businesses and related property, |

[0001069202-18-000020:notes:185]
| • | Loss from natural disaster, net of insurance recoveries; and, |

[0001069202-18-000020:notes:186]
[same as prior period, unchanged from 0001069202-18-000013:notes:182]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-18-000020:notes:187]
[same as prior period, unchanged from 0001069202-18-000013:notes:183]

[0001069202-18-000020:notes:188]
We record restructuring charges associated with management-approved restructuring plans when we reorganize or remove duplicative headcount or infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 16.

[0001069202-18-000020:notes:189]
[same as prior period, unchanged from 0001069202-18-000013:notes:185]

[0001069202-18-000020:notes:190]
[same as prior period, unchanged from 0001069202-18-000013:notes:186]

[0001069202-18-000020:notes:191]
|  | Charges Incurred in 2018 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 0.7 |  |  | $ | 12.0 |  |  | $ | 12.0 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 3.2 |  |  | 3.2 |  |
| Lease termination | 0.7 |  |  | 0.9 |  |  | 0.9 |  |
| Other | 0.5 |  |  | 4.6 |  |  | 4.8 |  |
| Total restructuring charges | $ | 1.9 |  |  | $ | 20.7 |  |  | $ | 20.9 |  |

[0001069202-18-000020:notes:192]
[same as prior period, unchanged from 0001069202-18-000013:notes:188]

[0001069202-18-000020:notes:193]
|  | Charges Incurred in 2018 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.5 |  |  | $ | 1.9 |  |  | $ | 2.1 |  |
| Commercial Heating & Cooling | 0.8 |  |  | 2.8 |  |  | 2.8 |  |
| Refrigeration | 0.7 |  |  | 13.8 |  |  | 13.8 |  |
| Corporate & Other | (0.1 | ) |  | 2.2 |  |  | 2.2 |  |
| Total restructuring charges | $ | 1.9 |  |  | $ | 20.7 |  |  | $ | 20.9 |  |

[0001069202-18-000020:notes:194]
[same as prior period, unchanged from 0001069202-18-000013:notes:190]

[0001069202-18-000020:notes:195]
|  | Balance as ofDecember 31, 2017 |  | Included inEarnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of September 30,2018 |
| Severance and related expense | $ | 0.2 |  |  | $ | 0.7 |  |  | $ | (0.8 | ) |  | $ | — |  |  | $ | 0.1 |  |
| Lease termination | — |  |  | 0.7 |  |  | (0.1 | ) |  | (0.2 | ) |  | 0.4 |  |
| Other | — |  |  | 0.5 |  |  | (0.5 | ) |  | — |  |  | — |  |
| Total restructuring accruals | $ | 0.2 |  |  | $ | 1.9 |  |  | $ | (1.4 | ) |  | $ | (0.2 | ) |  | $ | 0.5 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-18-000020:notes:196]
[same as prior period, unchanged from 0001069202-18-000013:notes:192]

[0001069202-18-000020:notes:197]
[same as prior period, unchanged from 0001069202-18-000013:notes:193]

[0001069202-18-000020:notes:198]
[same as prior period, unchanged from 0001069202-18-000013:notes:194]

[0001069202-18-000020:notes:199]
[same as prior period, unchanged from 0001069202-18-000013:notes:195]

[0001069202-18-000020:notes:200]
[same as prior period, unchanged from 0001069202-18-000013:notes:196]

[0001069202-18-000020:notes:201]
|  | September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 580.9 |  |  | $ | 572.4 |  |  | $ | 8.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 371.6 |  |  | 361.4 |  |  | 10.2 |  |
| Retained earnings | 1,805.0 |  |  | 1,806.7 |  |  | (1.7 | ) |
|  | For the Three Months Ended September 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 1,030.2 |  |  | $ | 1,030.2 |  |  | $ | — |  |
| Net income | 108.0 |  |  | 108.1 |  |  | (0.1 | ) |

[0001069202-18-000020:notes:202]
|  | For the Nine Months Ended September 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 3,040.4 |  |  | $ | 3,040.6 |  |  | $ | (0.2 | ) |
| Net income | 283.4 |  |  | 283.5 |  |  | (0.1 | ) |

[0001069202-18-000020:notes:203]
[same as prior period, unchanged from 0001069202-18-000013:notes:199]

[0001069202-18-000020:notes:204]
|  | For the Three Months Ended September 30,2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 594.7 |  |  | $ | 236.9 |  |  | $ | 132.0 |  |  | $ | 963.6 |  |
| Europe | — |  |  | 38.9 |  |  | 27.7 |  |  | 66.6 |  |
| Total | $ | 594.7 |  |  | 275.8 |  |  | 159.7 |  |  | 1,030.2 |  |

[0001069202-18-000020:notes:205]
|  | For the Nine Months Ended September 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 1,764.4 |  |  | $ | 668.1 |  |  | $ | 369.4 |  |  | $ | 2,801.9 |  |
| Europe | — |  |  | 105.4 |  |  | 83.4 |  |  | 188.8 |  |
| Asia Pacific | — |  |  | — |  |  | 49.7 |  |  | 49.7 |  |
| Total | $ | 1,764.4 |  |  | 773.5 |  |  | 502.5 |  |  | 3,040.4 |  |

[0001069202-18-000020:notes:206]
[same as prior period, unchanged from 0001069202-18-000013:notes:202]

[0001069202-18-000020:notes:207]
[same as prior period, unchanged from 0001069202-18-000013:notes:203]

[0001069202-18-000020:notes:208]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment, for the three and nine months ended September 30, 2018, direct sales represent approximately $459.9 million and $1,346.2 million of revenues and sales to independent distributors represent approximately $134.8 million and $418.2 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-18-000020:notes:209]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, for the three and nine months ended September 30, 2018, equipment sales represent approximately $242.6 million and $679.2 million of revenues while $33.2 million and $94.3 million of our revenue is generated from our service business, respectively.

[0001069202-18-000020:notes:210]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $156.8 million and $495.8 million for the three and nine months ended September 30, 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

[0001069202-18-000020:notes:211]
[same as prior period, unchanged from 0001069202-18-000013:notes:207]

[0001069202-18-000020:notes:212]
[same as prior period, unchanged from 0001069202-18-000013:notes:208]

[0001069202-18-000020:notes:213]
[same as prior period, unchanged from 0001069202-18-000013:notes:209]

[0001069202-18-000020:notes:214]
[same as prior period, unchanged from 0001069202-18-000013:notes:210]

[0001069202-18-000020:notes:215]
For the three and nine months ended September 30, 2018, we recognized revenue of $1.3 million and $4.2 million related to our contract liabilities at January 1, 2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the third quarter of 2018.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001069202-18-000020:notes:216]
[same as prior period, unchanged from 0001069202-18-000013:notes:212]


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001069202-18-000020:notes:217]
[same as prior period, unchanged from 0001069202-18-000013:notes:213]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-18-000020:notes:218]
[same as prior period, unchanged from 0001069202-18-000013:notes:214]

[0001069202-18-000020:notes:219]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEuropeCentral AmericaSouth America |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia Pacific*South America*Central America |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-18-000020:notes:220]
[same as prior period, unchanged from 0001069202-18-000013:notes:216]

[0001069202-18-000020:notes:221]
[same as prior period, unchanged from 0001069202-18-000013:notes:217]

[0001069202-18-000020:notes:222]
*Our businesses in the Asia Pacific and South America area were sold in the second and third quarter of 2018, respectively. Refer to Note 14 for details regarding the divestiture of the business.

[0001069202-18-000020:notes:223]
[same as prior period, unchanged from 0001069202-18-000013:notes:219]

[0001069202-18-000020:notes:224]
[same as prior period, unchanged from 0001069202-18-000013:notes:220]

[0001069202-18-000020:notes:225]
[same as prior period, unchanged from 0001069202-18-000013:notes:221]

[0001069202-18-000020:notes:226]
[same as prior period, unchanged from 0001069202-18-000013:notes:222]

[0001069202-18-000020:notes:227]
[same as prior period, unchanged from 0001069202-18-000013:notes:223]

[0001069202-18-000020:notes:228]
[same as prior period, unchanged from 0001069202-18-000013:notes:224]

[0001069202-18-000020:notes:229]
Except for the seasonal increase in total assets across all reportable segments, there have not been any material changes in the composition of total assets by segment since December 31, 2017; however, during the first nine months we sold our Australia, New Zealand, Asia and Brazil businesses. Refer to Note 14 for details regarding divestiture of businesses.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-18-000020:notes:230]
[same as prior period, unchanged from 0001069202-18-000013:notes:226]

[0001069202-18-000020:notes:231]
Our Board of Directors has authorized a total of $2.5 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in  March 2018. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time.  As of September 30, 2018, $546 million of shares may be repurchased under the Share Repurchase Plans.

[0001069202-18-000020:notes:232]
[same as prior period, unchanged from 0001069202-18-000013:notes:228]

[0001069202-18-000020:notes:233]
[same as prior period, unchanged from 0001069202-18-000013:notes:229]

[0001069202-18-000020:notes:234]
We also repurchased 0.1 million shares for $21.1 million during the nine months ended September 30, 2018 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
