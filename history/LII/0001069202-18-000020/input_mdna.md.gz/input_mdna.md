# LII MD&A — 0001069202-18-000020


## mdna

[0001069202-18-000020:mdna:1]
[same as prior period, unchanged from 0001069202-18-000013:mdna:1]

[0001069202-18-000020:mdna:2]
[same as prior period, unchanged from 0001069202-18-000013:mdna:2]

[0001069202-18-000020:mdna:3]
[same as prior period, unchanged from 0001069202-18-000013:mdna:3]

[0001069202-18-000020:mdna:4]
[same as prior period, unchanged from 0001069202-18-000013:mdna:4]

[0001069202-18-000020:mdna:5]
[same as prior period, unchanged from 0001069202-18-000013:mdna:5]

[0001069202-18-000020:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated warranty costs, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components, including the impact of newly imposed tariffs on the import of certain of our raw materials and components, has impacted us and the HVACR industry in general.  We seek to mitigate the impact of volatility in commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-18-000020:mdna:7]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the full amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.  For the three months ended September 30, 2018 we incurred expenses of $49.4 million related to damages caused by the tornado, which included the write-off of damaged property, equipment and inventory, freight to move product to other warehouses and professional fees to secure and maintain the site.  We are working closely with our insurance company and have received insurance recoveries of $45.0 million for the three months ended September 30, 2018 and recorded an insurance receivable of $4.1 million.  These costs and insurance recoveries are shown in Loss from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations.

[0001069202-18-000020:mdna:8]
We estimate the impact from the tornado will be a loss of approximately $100 million of revenue and $55 million of segment profit in 2018 and $85 million of revenue and $35 million of segment profit in 2019.  The lost segment profits in 2018 and 2019 from business interruption due to the tornado are expected to be fully offset by insurance proceeds in 2019.  We estimate that total pre-tax charges related to damage caused by the tornado will be approximately $80 million in 2018, which we expect to be offset by insurance recoveries in the current year.  In 2019, we estimate an additional $15 million in pre-tax charges and we expect our insurance recoveries to more than offset the write-off of the net book value of the damaged assets and in line with our costs to repair or replace.

[0001069202-18-000020:mdna:9]
[same as prior period, unchanged from 0001069202-18-000013:mdna:8]

[0001069202-18-000020:mdna:10]
In the third quarter of 2018, the Residential Heating & Cooling segment had a 1% increase in net sales and had $2 million in decreased segment profit compared to the third quarter of 2017.   The segment results were negatively impacted by the supply disruption caused by the tornado at our Marshalltown facility.  Our Commercial Heating & Cooling segment had a 2% increase in net sales and had $3 million in decreased segment profit compared to the third quarter of 2017.  The increased revenue was driven by volume and price gains.  The decrease in segment profit was driven by increase commodity and other product costs as well as increased freight and distribution.  Sales in our Refrigeration segment decreased by 17% due to the sale of our Australia, New Zealand, Asia and Brazil businesses.  The segment also had $3 million in increased segment profit compared to the third quarter of 2017, largely due to price increases.

[0001069202-18-000020:mdna:11]
[same as prior period, unchanged from 0001069202-18-000013:mdna:10]

[0001069202-18-000020:mdna:12]
| • | Net sales decreased $22 million, or 2%, to $1,030 million in the third quarter of 2018 compared to the third quarter of 2017. |

[0001069202-18-000020:mdna:13]
| • | Operating income in the third quarter of 2018 decreased $9 million to $145 million. |

[0001069202-18-000020:mdna:14]
| • | Net income for the third quarter of 2018 increased $4.5 million to $108 million, including $6 million loss on sale of business and related property. |

[0001069202-18-000020:mdna:15]
| • | Diluted earnings per share from continuing operations were $2.65 per share in the third quarter of 2018 compared to $2.45 per share in the third quarter of 2017. |

[0001069202-18-000020:mdna:16]
| • | During the nine months ended September 30, 2018, we returned $68 million to shareholders through dividend payments and have repurchased $350 million of common stock. We also received $116 million in proceeds from the sale of our businesses in Australia, New Zealand, Asia and Brazil along with the sale of the related property. |

[0001069202-18-000020:mdna:17]
Third Quarter of 2018 Compared to Third Quarter of 2017 - Consolidated Results

[0001069202-18-000020:mdna:18]
[same as prior period, unchanged from 0001069202-18-000013:mdna:17]

[0001069202-18-000020:mdna:19]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 1,030.2 |  |  | $ | 1,052.3 |  |  | (2.1 | )% |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 728.3 |  |  | 738.6 |  |  | 1.4 |  |  | 70.7 |  |  | 70.2 |  |
| Gross profit | 301.9 |  |  | 313.7 |  |  | (3.8 | ) |  | 29.3 |  |  | 29.8 |  |
| Selling, general and administrative expenses | 149.4 |  |  | 158.7 |  |  | 5.9 |  |  | 14.5 |  |  | 15.1 |  |
| Losses and other expenses, net | 2.7 |  |  | 3.0 |  |  | 10.0 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 0.5 |  |  | 1.9 |  |  | 73.7 |  |  | — |  |  | 0.2 |  |
| Loss, net on sale of business and related property | 6.2 |  |  | — |  |  | N/A |  | 0.6 |  |  | — |  |
| Loss from natural disaster, net of insurance recoveries | 0.3 |  |  | — |  |  | N/A |  | — |  |  | — |  |
| Income from equity method investments | (2.4 | ) |  | (4.5 | ) |  | (46.7 | ) |  | (0.2 | ) |  | (0.4 | ) |
| Operating income | $ | 145.2 |  |  | $ | 154.6 |  |  | (6.1 | )% |  | 14.1 | % |  | 14.7 | % |

[0001069202-18-000020:mdna:20]
[same as prior period, unchanged from 0001069202-18-000013:mdna:19]

[0001069202-18-000020:mdna:21]
Net sales decreased 2% in the third quarter of 2018 compared to the third quarter of 2017, primarily from 4% related to our divested businesses in Australia, New Zealand, Asia and Brazil, partially offset by 2% from favorable price.  The Commercial

[0001069202-18-000020:mdna:22]
Heating & Cooling segment delivered higher volume from our North American equipment business as well as higher volume from our North American Service business. The Refrigeration segment sales increased from our North American equipment business after removing the impact due to our divested businesses in Australia, New Zealand, Asia and Brazil.  The Residential Heating & Cooling segment experienced volume declines given the supply disruption caused by the tornado at our Marshalltown facility.

[0001069202-18-000020:mdna:23]
[same as prior period, unchanged from 0001069202-18-000013:mdna:21]

[0001069202-18-000020:mdna:24]
Gross profit margin in the third quarter of 2018 decreased to 29.3% compared to 29.8% in the third quarter of 2017.  We saw decreases in profit margin of 160 basis points ("bps") from higher commodity prices, 100 bps from higher freight and distribution costs, and 30 bps from other costs.  Partially offsetting these decreases were positive margin increases of 190 bps from favorable price and mix and 50 bps from lower material costs.

[0001069202-18-000020:mdna:25]
[same as prior period, unchanged from 0001069202-18-000013:mdna:24]

[0001069202-18-000020:mdna:26]
Selling, general and administrative expenses, or SG&A, was $149 million in the third quarter of 2018 compared to $159 million in the third quarter of 2017, and as a percentage of net sales decreased 60 bps to 14.5%.  SG&A decreased primarily due to the sale of our divested businesses in Australia, New Zealand, Asia and Brazil.

[0001069202-18-000020:mdna:27]
[same as prior period, unchanged from 0001069202-18-000013:mdna:26]

[0001069202-18-000020:mdna:28]
Losses and other expenses, net for the third quarter of 2018 and 2017 included the following (in millions):

[0001069202-18-000020:mdna:29]
|  | For the Three Months Ended September 30, |
|  | 2018 |  | 2017 |
| Realized losses (gains) on settled future contracts | $ | 0.2 |  |  | $ | (0.5 | ) |
| Foreign currency exchange losses (gains) | 0.1 |  |  | (0.6 | ) |
| Loss on disposal of fixed assets | — |  |  | 0.1 |  |
| Net change in unrealized losses on unsettled futures contracts | 0.2 |  |  | 0.2 |  |
| Special legal contingency charges | 0.1 |  |  | 1.5 |  |
| Asbestos-related litigation | 1.4 |  |  | 1.5 |  |
| Environmental liabilities | 0.2 |  |  | 0.5 |  |
| Other items, net | 0.5 |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) | $ | 2.7 |  |  | $ | 3.0 |  |

[0001069202-18-000020:mdna:30]
The net change in unrealized losses (gains) on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.

[0001069202-18-000020:mdna:31]
[same as prior period, unchanged from 0001069202-18-000013:mdna:30]

[0001069202-18-000020:mdna:32]
Restructuring charges were less than $1 million in the third quarter of 2018. The charges in 2018 were primarily for projects to realign resources and enhance distribution capabilities.  For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000020:mdna:33]
[same as prior period, unchanged from 0001069202-18-000013:mdna:32]

[0001069202-18-000020:mdna:34]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $2 million in the third quarter of 2018 was down from $5 million when compared to the third quarter of 2017.  The decrease is because the joint ventures have experienced increased costs related to commodities and components and have not passed along these increased costs to us via price increases.

[0001069202-18-000020:mdna:35]
[same as prior period, unchanged from 0001069202-18-000013:mdna:34]

[0001069202-18-000020:mdna:36]
Interest expense, net of $10 million in the third quarter of 2018 was up from $8 million in the third quarter of 2017 due to an increase in our average net borrowings and rising interest rates.

[0001069202-18-000020:mdna:37]
[same as prior period, unchanged from 0001069202-18-000013:mdna:36]

[0001069202-18-000020:mdna:38]
We expect our annual effective tax rate to be between 22% and 24%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001069202-18-000020:mdna:39]
Our effective tax rate was 19.3% for the three months ended September 30, 2018, after the impact of excess tax benefits, compared to 29.2% for the three months ended September 30, 2017, after the impact of excess tax benefits.  The rate for the three months ended September 30, 2018 is lower as compared to the three months ended September 30, 2017 primarily due to the reduced U.S. federal corporate tax rate from enactment of the Tax Cuts and Jobs Act on December 22, 2017.

[0001069202-18-000020:mdna:40]
Third Quarter of 2018 Compared to Third Quarter of 2017 - Results by Segment

[0001069202-18-000020:mdna:41]
[same as prior period, unchanged from 0001069202-18-000013:mdna:40]

[0001069202-18-000020:mdna:42]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000020:mdna:43]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 594.7 |  |  | $ | 590.5 |  |  | $ | 4.2 |  |  | 0.7 | % |
| Profit | $ | 113.0 |  |  | $ | 114.7 |  |  | $ | (1.7 | ) |  | (1.5 | )% |
| % of net sales | 19.0 | % |  | 19.4 | % |  |  |  |  |

[0001069202-18-000020:mdna:44]
Net sales increased 1% in the third quarter of 2018 compared to the third quarter of 2017.  Price and mix combined increased by 3% and sales volume declined by 2% primarily as a result of the supply disruption caused by the tornado that severely damaged our Marshalltown manufacturing facility.

[0001069202-18-000020:mdna:45]
Segment profit in the third quarter of 2018 decreased $2 million compared to the third quarter of 2017 due to $14 million of higher commodity costs, $9 million from freight and costs associated with distribution investments, $3 million from lower sales volume which was primarily caused by the supply disruption resulting from the tornado that damaged our Marshalltown manufacturing facility, $2 million from unfavorable foreign currency exchange rates, and $1 million from higher other product costs.  Partially offsetting these decreases is $21 million from favorable price and mix combined, $3 million from lower SG&A expenses, $2 million from engineering-led cost reductions, and $1 million from higher factory productivity.

[0001069202-18-000020:mdna:46]
[same as prior period, unchanged from 0001069202-18-000013:mdna:45]

[0001069202-18-000020:mdna:47]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000020:mdna:48]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 275.8 |  |  | $ | 269.4 |  |  | $ | 6.4 |  |  | 2.4 | % |
| Profit | $ | 46.7 |  |  | $ | 50.0 |  |  | $ | (3.3 | ) |  | (6.6 | )% |
| % of net sales | 16.9 | % |  | 18.6 | % |  |  |  |  |

[0001069202-18-000020:mdna:49]
Net sales increased by 2% in the third quarter of 2018 compared to the third quarter of 2017.  Sales volume increased 1% and price increased by 1%.

[0001069202-18-000020:mdna:50]
Segment profit in the third quarter of 2018 decreased by $3 million compared to the third quarter of 2017 due to $3 million of higher commodity costs, $2 million of higher other product costs, $2 million of higher freight and distribution expense, $2 million

[0001069202-18-000020:mdna:51]
of higher SG&A, and $1 million of lower factory productivity.  Partially offsetting these decreases is $5 million of favorable price and mix combined, $1 million of higher sales volume, and $1 million from sourcing and engineering-led cost reductions.

[0001069202-18-000020:mdna:52]
[same as prior period, unchanged from 0001069202-18-000013:mdna:50]

[0001069202-18-000020:mdna:53]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000020:mdna:54]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 159.7 |  |  | $ | 192.4 |  |  | $ | (32.7 | ) |  | (17.0 | )% |
| Profit | $ | 23.0 |  |  | $ | 20.0 |  |  | $ | 3.0 |  |  | 15.0 | % |
| % of net sales | 14.4 | % |  | 10.4 | % |  |  |  |  |

[0001069202-18-000020:mdna:55]
Net sales decreased 17% in the third quarter of 2018 compared to the third quarter of 2017.  The loss of sales from the divested Australia, New Zealand, Asia and Brazil businesses contributed 20% and unfavorable mix decreased sales by 1%  which was partially offset by 3% higher sales volume and 1% higher price.

[0001069202-18-000020:mdna:56]
Segment profit increased $3 million in the third quarter of 2018 compared to the third quarter of 2017 primarily due to $3 million of favorable price, $1 million from higher sales volume, $1 million of sourcing and engineering-led cost reductions, and $1 million of lower SG&A.  Partially offsetting these increases was $2 million of higher commodity costs, and $1 million of lost profit from the divested businesses.

[0001069202-18-000020:mdna:57]
[same as prior period, unchanged from 0001069202-18-000013:mdna:55]

[0001069202-18-000020:mdna:58]
Corporate and other expenses were $4 million higher in the third quarter of 2018 compared to the third quarter of 2017 primarily due to the timing of planned technology investments.

[0001069202-18-000020:mdna:59]
Year-to-Date through September 30, 2018 Compared to Year-to-Date through September 30, 2017 - Consolidated Results

[0001069202-18-000020:mdna:60]
[same as prior period, unchanged from 0001069202-18-000013:mdna:58]

[0001069202-18-000020:mdna:61]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 3,040.4 |  |  | $ | 2,947.9 |  |  | 3.1 |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 2,153.8 |  |  | 2,082.4 |  |  | (3.4 | ) |  | 70.8 |  |  | 70.6 |  |
| Gross profit | 886.6 |  |  | 865.5 |  |  | 2.4 |  |  | 29.2 |  |  | 29.4 |  |
| Selling, general and administrative expenses | 466.1 |  |  | 479.6 |  |  | 2.8 |  |  | 15.3 |  |  | 16.3 |  |
| Losses and other expenses, net | 10.0 |  |  | 8.5 |  |  | (17.6 | ) |  | 0.3 |  |  | 0.3 |  |
| Restructuring charges | 1.9 |  |  | 2.1 |  |  | 9.5 |  |  | 0.1 |  |  | 0.1 |  |
| (Gain) loss, net on sale of business and related property | 25.8 |  |  | — |  |  | N/A |  |  | 0.8 |  |  | — |  |
| Loss on assets held for sale | — |  |  | — |  |  | N/A |  |  | — |  |  | — |  |
| Loss from natural disaster, net of insurance recoveries | 0.3 |  |  | — |  |  | N/A |  |  | — |  |  | — |  |
| Income from equity method investments | (10.8 | ) |  | (15.5 | ) |  | (30.3 | ) |  | (0.4 | ) |  | (0.5 | ) |
| Operating income | $ | 393.3 |  |  | $ | 390.8 |  |  | 0.6 |  |  | 12.9 | % |  | 13.3 | % |

[0001069202-18-000020:mdna:62]
[same as prior period, unchanged from 0001069202-18-000013:mdna:60]

[0001069202-18-000020:mdna:63]
Net sales increased 3% in the first nine months of 2018 compared to the first nine months of 2017 due to a 3% increase in sales volumes and 2% from favorable price.  These increases were partially offset by 2% related to our divested Australia, New Zealand, Asia and Brazil businesses.  The Residential Heating & Cooling segment delivered higher volume from increased replacement

[0001069202-18-000020:mdna:64]
equipment, new construction business and increased parts and supplies sales.  The Commercial Heating & Cooling segment delivered higher volume from our North American equipment business as well as from our North American Service business. The Refrigeration sales declined due to our divested businesses in Australia, New Zealand, Asia and Brazil.

[0001069202-18-000020:mdna:65]
[same as prior period, unchanged from 0001069202-18-000013:mdna:62]

[0001069202-18-000020:mdna:66]
Gross profit margins in the first nine months of 2018 decreased 20 bps to 29.2% when compared to the first nine months of 2017.  Our profit margin decreased 130 bps from higher commodity costs and 100 bps from freight and distribution.  Offsetting these decreases were increases of 140 bps from favorable price and mix combined and 70 bps from material cost savings.

[0001069202-18-000020:mdna:67]
[same as prior period, unchanged from 0001069202-18-000013:mdna:64]

[0001069202-18-000020:mdna:68]
SG&A was $466 million for the first nine months of 2018 compared to $480 million for the first nine months of 2017, and as a percentage of net sales, decreased 100 bps to 15.3% from 16.3%. SG&A decreased due the sale of our divested businesses in Australia, New Zealand, Asia and Brazil.

[0001069202-18-000020:mdna:69]
[same as prior period, unchanged from 0001069202-18-000013:mdna:66]

[0001069202-18-000020:mdna:70]
Losses and other expenses, net for the first nine months of 2018 and 2017 included the following (in millions):

[0001069202-18-000020:mdna:71]
|  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |
| Realized gains on settled future contracts | $ | (0.6 | ) |  | $ | (1.3 | ) |
| Foreign currency exchange losses | 1.2 |  |  | (0.3 | ) |
| Loss on disposal of fixed assets | 0.1 |  |  | 0.1 |  |
| Net change in unrealized losses on unsettled futures contracts | 1.4 |  |  | 1.0 |  |
| Special legal contingency charges | 1.8 |  |  | 3.6 |  |
| Asbestos-related litigation | 3.3 |  |  | 3.9 |  |
| Environmental liabilities | 1.4 |  |  | 1.2 |  |
| Other items, net | 1.4 |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) | $ | 10.0 |  |  | $ | 8.5 |  |

[0001069202-18-000020:mdna:72]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.

[0001069202-18-000020:mdna:73]
[same as prior period, unchanged from 0001069202-18-000013:mdna:70]

[0001069202-18-000020:mdna:74]
Restructuring charges were $2 million in the first nine months of 2018. The charges in 2018 were primarily for projects to realign resources and enhance distribution capabilities.  For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000020:mdna:75]
[same as prior period, unchanged from 0001069202-18-000013:mdna:72]

[0001069202-18-000020:mdna:76]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $11 million in the first nine months of 2018 was down from $16 million when compared to the first nine months of 2017.  The decrease is because the joint ventures have experienced increased costs related to commodities and components and have not passed along these increased costs to us via price increases.

[0001069202-18-000020:mdna:77]
[same as prior period, unchanged from 0001069202-18-000013:mdna:74]

[0001069202-18-000020:mdna:78]
Interest expense, net of $29 million in the first nine months of 2018 increased from $23 million in the first nine months of 2017 due to an increase in our average net borrowings and rising interest rates.

[0001069202-18-000020:mdna:79]
[same as prior period, unchanged from 0001069202-18-000013:mdna:76]

[0001069202-18-000020:mdna:80]
We expect our annual effective tax rate to be between 22% and 24%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001069202-18-000020:mdna:81]
Our  effective tax rate was 21.3% for the nine months ended September 30, 2018, after the impact of excess tax benefits, compared to 28.2% for the nine months ended September 30, 2017, after the impact of excess tax benefits.  The rate for the nine months ended September 30, 2018 is lower as compared to the nine months ended September 30, 2017 primarily due to the reduced U.S. federal corporate tax rate from enactment of the Tax Cuts and Jobs Act on December 22, 2017.

[0001069202-18-000020:mdna:82]
Year-to-Date through September 30, 2018 Compared to Year-to-Date through September 30, 2017 - Results by Segment

[0001069202-18-000020:mdna:83]
[same as prior period, unchanged from 0001069202-18-000013:mdna:80]

[0001069202-18-000020:mdna:84]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first nine months of 2018 and 2017 (dollars in millions):

[0001069202-18-000020:mdna:85]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 1,764.4 |  |  | $ | 1,663.8 |  |  | $ | 100.6 |  |  | 6.0 | % |
| Profit | $ | 317.9 |  |  | $ | 297.6 |  |  | $ | 20.3 |  |  | 6.8 | % |
| % of net sales | 18.0 | % |  | 17.9 | % |  |  |  |  |

[0001069202-18-000020:mdna:86]
Net sales increased by 6%  in the first nine months of 2018 compared to the first nine months of 2017.  Sales volume increased 4% and price and mix combined increased 2%.

[0001069202-18-000020:mdna:87]
Segment profit for the first nine months of 2018 increased $20 million compared to the first nine months of 2017 due to $44 million from favorable price and mix, $20 million from higher sales volume, $11 million from sourcing and engineering-led cost reductions, $2 million from SG&A savings,  $1 million from improved factory productivity, and $1 million from lower other product costs.  Partially offsetting these increases was $28 million higher commodity costs, $26 million of freight and costs associated with distribution investments, $4 million from lower equity method investments, and $1 million from unfavorable foreign currency exchange rates.

[0001069202-18-000020:mdna:88]
[same as prior period, unchanged from 0001069202-18-000013:mdna:85]

[0001069202-18-000020:mdna:89]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first nine months of 2018 and 2017 (dollars in millions):

[0001069202-18-000020:mdna:90]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 773.5 |  |  | $ | 723.5 |  |  | $ | 50.0 |  |  | 6.9 | % |
| Profit | $ | 118.9 |  |  | $ | 113.8 |  |  | $ | 5.1 |  |  | 4.5 | % |
| % of net sales | 15.4 | % |  | 15.7 | % |  |  |  |  |

[0001069202-18-000020:mdna:91]
Commercial Heating & Cooling net sales increased by 7% in the first nine months of 2018 compared to the first nine months of 2017.  Sales volume increased 5%, price and mix combined increased 1%, and favorable foreign currency exchange rates increased by 1%.

[0001069202-18-000020:mdna:92]
Segment profit in the first nine months of 2018 increased $5 million compared to the first nine months of 2017 due to the benefits of $11 million in higher sales volume, $9 million from favorable price, and $4 million from sourcing and engineering-

[0001069202-18-000020:mdna:93]
led cost reductions.  Partially offsetting these increases was $7 million from higher commodity costs, $5 million from unfavorable mix, $4 million from higher freight and distribution expense, $1 million from unfavorable factory productivity, $1 million from higher other product costs, and $1 million from lower income from equity method investments.

[0001069202-18-000020:mdna:94]
[same as prior period, unchanged from 0001069202-18-000013:mdna:90]

[0001069202-18-000020:mdna:95]
The following table presents our Refrigeration segment's net sales and profit for the first nine months of 2018 and 2017 (dollars in millions):

[0001069202-18-000020:mdna:96]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 502.5 |  |  | $ | 560.6 |  |  | $ | (58.1 | ) |  | (10.4 | )% |
| Profit | $ | 55.8 |  |  | $ | 55.7 |  |  | $ | 0.1 |  |  | 0.2 | % |
| % of net sales | 11.1 | % |  | 9.9 | % |  |  |  |  |

[0001069202-18-000020:mdna:97]
Refrigeration net sales decreased 10% in the first nine months of 2018 compared to the first nine months of 2017.   The loss of sales from the divested Asia Pacific and Brazilian businesses contributed 11%, and mix was unfavorable by 1%, partially offset by 1% higher price and 1% favorable foreign currency exchange rates.

[0001069202-18-000020:mdna:98]
Segment  profit for the first nine months of 2018 was flat compared to the first nine months of 2017 due to $5 million of favorable price, $4 million from sourcing and engineering-led cost reductions, $2 million from selling refrigerant allocations in Europe, $2 million lower SG&A, $1 million lower other product costs, and $1 million favorable foreign exchange rates.  Partially offsetting these increases was $4 million of higher commodity costs, $4 million of unfavorable mix, $3 million from lower factory productivity, $2 million of lost profit from the divested Australia, New Zealand, Asia and Brazil businesses, $1 million of higher freight and distribution expense, and $1 million of lower income from equity method investments.

[0001069202-18-000020:mdna:99]
[same as prior period, unchanged from 0001069202-18-000013:mdna:95]

[0001069202-18-000020:mdna:100]
Corporate  and other expenses increased $3 million to $62 million in the first nine months of 2018 from $59 million in the first nine months of 2017 due primarily to the timing of planned technology investments.

[0001069202-18-000020:mdna:101]
[same as prior period, unchanged from 0001069202-18-000013:mdna:97]

[0001069202-18-000020:mdna:102]
[same as prior period, unchanged from 0001069202-18-000013:mdna:98]

[0001069202-18-000020:mdna:103]
[same as prior period, unchanged from 0001069202-18-000013:mdna:99]

[0001069202-18-000020:mdna:104]
The following table summarizes our cash flow activity for the nine months ended September 30, 2018 and 2017 (in millions):

[0001069202-18-000020:mdna:105]
|  | For the Nine Months Ended September 30, |
|  | 2018 |  | 2017 |
| Net cash provided by operating activities | $ | 231.3 |  |  | $ | 129.0 |  |
| Net cash provided by (used in) investing activities | 59.3 |  |  | (60.3 | ) |
| Net cash used in financing activities | (316.6 | ) |  | (67.3 | ) |

[0001069202-18-000020:mdna:106]
Net Cash Provided by Operating Activities - The net cash provided by operating activities in the first nine months of 2018 and 2017 reflects the seasonal increase in working capital requirements. The increase in cash provided by operating activities in the first nine months of 2018 as compared to 2017 was mainly due to the timing of working capital payments and due in part by the supply disruption caused by the tornado at our Marshalltown facility.

[0001069202-18-000020:mdna:107]
Net Cash Provided by (Used in) Investing Activities - Capital expenditures were $61 million in the first nine months of both 2018 and 2017.  Capital expenditures in 2018 were primarily related to expansion of our manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.  Net proceeds of $116 million were provided by the

[0001069202-18-000020:mdna:108]
sale of our business in the Asia Pacific area along with the related property as well as the sale of our business in Brazil.

[0001069202-18-000020:mdna:109]
Net Cash Used in Financing Activities - Net cash used in financing activities in the first nine months of 2018 was $317 million as compared to $67 million in the first nine months of 2017.  The increase in cash used in financing activities is largely due to a decrease in net borrowings against our credit facility and an increase in share repurchases.  During the first nine months of 2018, we repurchased $350 million of shares as compared to $250 million of shares in the first nine months of 2017.  We also we returned $68 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000020:mdna:110]
[same as prior period, unchanged from 0001069202-18-000013:mdna:106]

[0001069202-18-000020:mdna:111]
The following table details our lines of credit and financing arrangements as of September 30, 2018 (in millions):

[0001069202-18-000020:mdna:112]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Capital lease obligations | $ | 0.4 |  |
| Domestic credit facility(1) | 22.5 |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 22.3 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | 377.3 |  |
| Capital lease obligations | 11.9 |  |
| Domestic credit facility(1) | 368.0 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (3.6 | ) |
| Total long-term debt | 1,103.6 |  |
| Total debt | $ | 1,125.9 |  |

[0001069202-18-000020:mdna:113]
(1) The available future borrowings on our domestic credit facility are $447.0 million after being reduced by the outstanding borrowings and $2.5 million in outstanding standby letters of credit.  We also had $30.7 million in outstanding standby letters of credit outside of the domestic credit facility as of September 30, 2018.

[0001069202-18-000020:mdna:114]
[same as prior period, unchanged from 0001069202-18-000013:mdna:110]

[0001069202-18-000020:mdna:115]
[same as prior period, unchanged from 0001069202-18-000013:mdna:111]

[0001069202-18-000020:mdna:116]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 108.4% at September 30, 2018 from 95.2% at December 31, 2017.

[0001069202-18-000020:mdna:117]
As of September 30, 2018, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-18-000020:mdna:118]
[same as prior period, unchanged from 0001069202-18-000013:mdna:114]

[0001069202-18-000020:mdna:119]
We believe our cash and cash equivalents of $46 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, potential dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $46 million as of September 30, 2018 was $20.7 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities

[0001069202-18-000020:mdna:120]
in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-18-000020:mdna:121]
Our expected capital expenditures for 2018 are $100 million, excluding capital expenditures made in conjunction with repair of our Marshalltown facility as those repairs will be covered by insurance.  We also continue to increase shareholder value through our share repurchase programs and dividend payments, with the completion of $350 million of share repurchases in the first nine months of 2018 and the declaration of $68 million of cash dividends in the first nine months of 2018.

[0001069202-18-000020:mdna:122]
[same as prior period, unchanged from 0001069202-18-000013:mdna:117]

[0001069202-18-000020:mdna:123]
[same as prior period, unchanged from 0001069202-18-000013:mdna:118]

[0001069202-18-000020:mdna:124]
Commitments, Contingencies and Guarantees

[0001069202-18-000020:mdna:125]
For information regarding our commitments, contingencies and guarantees, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000020:mdna:126]
[same as prior period, unchanged from 0001069202-18-000013:mdna:121]

[0001069202-18-000020:mdna:127]
[same as prior period, unchanged from 0001069202-18-000013:mdna:122]
