# LII notes — 0001193125-12-311640


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-311640:notes:1]
[same as prior period, unchanged from 0001193125-12-177598:notes:1]

[0001193125-12-311640:notes:2]
[same as prior period, unchanged from 0001193125-12-177598:notes:2]

[0001193125-12-311640:notes:3]
[same as prior period, unchanged from 0001193125-12-177598:notes:3]

[0001193125-12-311640:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2012, the accompanying unaudited Consolidated Statements of
   Operations for the three and six months ended June 30, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2012 and 2011, and the accompanying unaudited Consolidated
   Statements of Cash Flows for the six months ended June 30, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended
   December 31, 2011. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to
   Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position,
   results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we
   believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001193125-12-311640:notes:5]
Our fiscal year ends on December 31 and each of our quarters are comprised of 13 weeks. For convenience, throughout these financial
   statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.

[0001193125-12-311640:notes:6]
[same as prior period, unchanged from 0001193125-12-177598:notes:6]

[0001193125-12-311640:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the
   underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable,
   inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, and pension and postretirement medical benefits, among others.
   These estimates and assumptions are based on management’s best estimates and judgment.

[0001193125-12-311640:notes:8]
[same as prior period, unchanged from 0001193125-12-177598:notes:8]

[0001193125-12-311640:notes:9]
[same as prior period, unchanged from 0001193125-12-177598:notes:9]

[0001193125-12-311640:notes:10]
[same as prior period, unchanged from 0001193125-12-177598:notes:10]


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-311640:notes:11]
[same as prior period, unchanged from 0001193125-12-177598:notes:15]

[0001193125-12-311640:notes:12]
[same as prior period, unchanged from 0001193125-12-177598:notes:16]

[0001193125-12-311640:notes:13]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
| Finished goods |  | $ | 308.7 |  |  | $ | 222.3 |  |
| Work in process |  |  | 15.2 |  |  |  | 13.3 |  |
| Raw materials and repair parts |  |  | 177.1 |  |  |  | 162.3 |  |
|  |  |  | 501.0 |  |  |  | 397.9 |  |
| Excess of current cost over last-in, first-out cost and other items |  |  | (73.7 | ) |  |  | (73.9 | ) |
| Total inventories, net |  | $ | 427.3 |  |  | $ | 324.0 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-12-311640:notes:14]
[same as prior period, unchanged from 0001193125-12-177598:notes:18]

[0001193125-12-311640:notes:15]
The changes in the carrying amount of goodwill for the first half of 2012, in total and by segment, are as follows (in
   millions):

[0001193125-12-311640:notes:16]
|  |  | Balance atDecember 31,2011 |  |  |  |  |  |  |  |  | Balance atJune 30,2012 |  |
| Segment: |  | Goodwill |  |  | Acquisitions/(Dispositions) |  |  | Other(2) |  |  | Goodwill |  |
| Residential Heating & Cooling |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling |  |  | 29.4 |  |  |  | — |  |  |  | (0.7 | ) |  |  | 28.7 |  |
| Service Experts (1) |  |  | 116.5 |  |  |  | — |  |  |  | (0.8 | ) |  |  | 115.7 |  |
| Refrigeration |  |  | 133.6 |  |  |  | — |  |  |  | (1.9 | ) |  |  | 131.7 |  |
|  |  | $ | 305.6 |  |  | $ | — |  |  | $ | (3.4 | ) |  | $ | 302.2 |  |

[0001193125-12-311640:notes:17]
[same as prior period, unchanged from 0001193125-12-177598:notes:21]

[0001193125-12-311640:notes:18]
[same as prior period, unchanged from 0001193125-12-177598:notes:22]

[0001193125-12-311640:notes:19]
We will continue to monitor our reporting units throughout the year to determine if a change in facts and circumstances
   warrants a re-evaluation of our goodwill.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-12-311640:notes:20]
[same as prior period, unchanged from 0001193125-12-177598:notes:24]

[0001193125-12-311640:notes:21]
[same as prior period, unchanged from 0001193125-12-177598:notes:25]

[0001193125-12-311640:notes:22]
[same as prior period, unchanged from 0001193125-12-177598:notes:26]

[0001193125-12-311640:notes:23]
[same as prior period, unchanged from 0001193125-12-177598:notes:27]

[0001193125-12-311640:notes:24]
[same as prior period, unchanged from 0001193125-12-177598:notes:28]

[0001193125-12-311640:notes:25]
A
   portion of our debt bears interest at variable interest rates, and therefore, we are subject to variability in the cash paid for interest. In order to mitigate a portion of the risk, we use a hedging strategy to eliminate the variability of cash
   flows in the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the benchmark interest rate. This strategy allows us to fix a
   portion of our variable interest payments.

[0001193125-12-311640:notes:26]
[same as prior period, unchanged from 0001193125-12-177598:notes:30]

[0001193125-12-311640:notes:27]
[same as prior period, unchanged from 0001193125-12-177598:notes:31]

[0001193125-12-311640:notes:28]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in
   foreign currencies. Our objective for entering into foreign currency forward contracts is to mitigate the impact of short-term currency exchange rate movements on certain short-term intercompany
   transactions. In order to meet that objective, we periodically enter into foreign currency forward contracts that act as economic hedges against changes in foreign currency exchange rates. These
   forward contracts are not designated as hedges and generally expire during the quarter that we enter into them. By entering into these forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate
   and gains should the U.S. dollar depreciate.

[0001193125-12-311640:notes:29]
[same as prior period, unchanged from 0001193125-12-177598:notes:33]

[0001193125-12-311640:notes:30]
We include gains or losses in AOCI in connection with our commodity cash flow hedges. The gains or losses related to commodity price hedges are expected to be reclassified into earnings within the next 18
   months based on the prices of the commodities at the settlement dates. Assuming that commodity prices remain constant, $2.2 million of derivative losses are expected to be reclassified into earnings within the next 12 months. Commodity futures
   contracts that are designated as cash flow hedges and are in place as of June 30, 2012 are scheduled to mature through November 2013.

[0001193125-12-311640:notes:31]
We also include gains or losses in AOCI from our $100 million pay-fixed, receive-variable interest rate swap. Assuming that the benchmark interest rate remains constant, $0.4 million of derivative losses
   are expected to be reclassified into earnings within the next 12 months. The interest rate swap expires October 12, 2012.

[0001193125-12-311640:notes:32]
We recorded the following amounts related to our cash flow hedges (in millions):

[0001193125-12-311640:notes:33]
|  |  | As of June 30, |  |  | As ofDecember 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Commodity Price Hedges: |  |  |  |  |  |  |  |  |
| Losses included in AOCI, net of tax |  | $ | 2.4 |  |  | $ | 6.1 |  |
| Benefit from income taxes |  |  | (1.3 | ) |  |  | (3.5 | ) |
| Interest Rate Swap: |  |  |  |  |  |  |  |  |
| Losses included in AOCI, net of tax |  | $ | 0.4 |  |  | $ | 1.1 |  |
| Benefit from income taxes |  |  | (0.2 | ) |  |  | (0.6 | ) |

[0001193125-12-311640:notes:34]
[same as prior period, unchanged from 0001193125-12-177598:notes:38]

[0001193125-12-311640:notes:35]
|  |  | As ofJune 30, 2012 |  |  | As ofDecember 31,2011 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 20.1 |  |  |  |  |  | 23.3 |  |

[0001193125-12-311640:notes:36]
[same as prior period, unchanged from 0001193125-12-177598:notes:40]

[0001193125-12-311640:notes:37]
[same as prior period, unchanged from 0001193125-12-177598:notes:41]

[0001193125-12-311640:notes:38]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 2.5 |  |  |  |  |  | 2.8 |  |
| Aluminum |  |  | 2.6 |  |  |  |  |  | 3.0 |  |

[0001193125-12-311640:notes:39]
We had the following
   outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001193125-12-311640:notes:40]
|  |  | As of June 30, |  |  | As ofDecember 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Notional amounts: |  |  |  |  |  |  |  |  |
| Brazilian Real |  |  | 3.1 |  |  |  | 4.5 |  |
| U.S. Dollars |  |  | 6.0 |  |  |  | 2.0 |  |
| Mexican Peso |  |  | 269.0 |  |  |  | 172.0 |  |
| Euros |  |  | — |  |  |  | 7.8 |  |
| British Pounds |  |  | 5.6 |  |  |  | 6.5 |  |
| Indian Rupees |  |  | 136.5 |  |  |  | — |  |

[0001193125-12-311640:notes:41]
[same as prior period, unchanged from 0001193125-12-177598:notes:45]

[0001193125-12-311640:notes:42]
[same as prior period, unchanged from 0001193125-12-177598:notes:46]

[0001193125-12-311640:notes:43]
|  |  | Fair Values of Derivative Instruments(1) |  |
|  |  | Derivatives Designated asHedging Instruments |  |  | Derivatives Not Designated asHedging Instruments |  |
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.4 |  |  |  | 1.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |
| Total Assets |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | 1.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 3.3 |  |  | $ | 9.4 |  |  | $ | 0.8 |  |  | $ | 1.8 |  |
| Interest rate swap |  |  | 0.7 |  |  |  | 1.8 |  |  |  | — |  |  |  | — |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | 0.3 |  |  |  | 0.3 |  |  |  | 0.1 |  |  |  | 0.2 |  |
| Interest rate swap |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total Liabilities |  | $ | 4.3 |  |  | $ | 11.5 |  |  | $ | 0.9 |  |  | $ | 2.1 |  |

[0001193125-12-311640:notes:44]
[same as prior period, unchanged from 0001193125-12-177598:notes:48]

[0001193125-12-311640:notes:45]
| Derivatives in Cash Flow Hedging Relationships |  |
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Amount of Loss or (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts (1) |  | $ | 1.6 |  |  | $ | (4.7 | ) |  | $ | 3.5 |  |  | $ | (9.9 | ) |
| Interest rate swap (2) |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 1.2 |  |  |  | 1.2 |  |
|  |  | $ | 2.2 |  |  | $ | (4.1 | ) |  | $ | 4.7 |  |  | $ | (8.7 | ) |
| Amount of (Gain) or Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts (3) |  | $ | — |  |  | $ | — |  |  | $ | (0.1 | ) |  | $ | — |  |

[0001193125-12-311640:notes:46]
| Derivatives Not Designated as Hedging Instruments |  |
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Amount of (Gain) or Loss Recognized in Income on Derivatives: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts (3) |  | $ | 1.2 |  |  | $ | 0.4 |  |  | $ | (0.1 | ) |  | $ | 0.5 |  |
| Foreign currency forward contracts (3) |  |  | (0.3 | ) |  |  | 0.4 |  |  |  | (0.3 | ) |  |  | 1.4 |  |
|  |  | $ | 0.9 |  |  | $ | 0.8 |  |  | $ | (0.4 | ) |  | $ | 1.9 |  |

[0001193125-12-311640:notes:47]
[same as prior period, unchanged from 0001193125-12-177598:notes:51]

[0001193125-12-311640:notes:48]
| (2) | The loss is recorded in Interest expense, net in the accompanying Consolidated Statements of Operations. |

[0001193125-12-311640:notes:49]
[same as prior period, unchanged from 0001193125-12-177598:notes:53]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-311640:notes:50]
[same as prior period, unchanged from 0001193125-12-177598:notes:54]

[0001193125-12-311640:notes:51]
As of June 30, 2012, we had approximately $6.0 million in total gross unrecognized tax benefits. Of this amount,
   $5.9 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations. As of June 30, 2012, we recognized $0.1 million (net of federal tax benefits) in interest and penalties in
   income tax expense in accordance with FASB Accounting Standards Codification (“ASC”) Topic 740.

[0001193125-12-311640:notes:52]
We are currently
   under examination for our U.S. federal income taxes for 2011 and 2012 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany. We are generally no
   longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years before 2007.

[0001193125-12-311640:notes:53]
Since January 1, 2012, numerous states, including Pennsylvania and Idaho, enacted legislation effective for tax years beginning after January 1, 2012, including changes to rates and
   apportionment methods. We believe any adjustments related to these changes will be immaterial.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-311640:notes:54]
6. Commitments and Contingencies:

[0001193125-12-311640:notes:55]
We are subject to contingencies that arise in the normal course of business, including product warranties and other
   product related contingencies, pending litigation, environmental matters and other guarantees or claims.

[0001193125-12-311640:notes:56]
We use a combination
   of third-party insurance and self-insurance plans (large deductible or captive) to provide protection against claims relating to contingencies such as workers’ compensation, general liability, product liability, property damage, aviation
   liability, directors’ and officers’ liability, auto liability, physical damage and other exposures. Self-insurance expense and liabilities are actuarially determined based on our historical claims information, as well as industry factors
   and trends. Because we have a captive insurance company, we are required to maintain specified levels of liquid assets from which we must pay claims. The majority of our self-insured risks (excluding auto liability and physical damage) will be paid
   over an extended period of time. There have been no material changes in our insurance liability since our latest fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our large deductible or captive insurance
   plans. The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were $62.8 million and $63.3 million as of June 30, 2012 and December 31, 2011, respectively.

[0001193125-12-311640:notes:57]
Product Warranties and Product
   Related Contingencies

[0001193125-12-311640:notes:58]
Total liabilities for estimated product warranty are included in the following captions on the
   accompanying Consolidated Balance Sheets (in millions):

[0001193125-12-311640:notes:59]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
| Accrued expenses |  | $ | 27.7 |  |  | $ | 29.4 |  |
| Other liabilities |  |  | 44.2 |  |  |  | 41.8 |  |
|  |  | $ | 71.9 |  |  | $ | 71.2 |  |

[0001193125-12-311640:notes:60]
The changes in total product warranty liabilities for the first half of 2012 were as follows (in millions):

[0001193125-12-311640:notes:61]
| Total warranty liability as of December 31, 2011 |  | $ | 71.2 |  |
| Payments made in 2012 |  |  | (12.5 | ) |
| Changes resulting from issuance of new warranties |  |  | 14.1 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (0.6 | ) |
| Changes in foreign currency translation rates and other |  |  | (0.3 | ) |
| Total warranty liability as of June 30, 2012 |  | $ | 71.9 |  |

[0001193125-12-311640:notes:62]
At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year,
   we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities. As a result of this re-evaluation, we decreased our warranty liability by $0.4 million.

[0001193125-12-311640:notes:63]
We incur the risk of liability claims for the installation and service of heating and air conditioning products, and we maintain
   liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an
   adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material
   changes in the circumstances that affect our product warranties since our latest fiscal year-end.

[0001193125-12-311640:notes:64]
We may also incur costs
   related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect
   our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001193125-12-311640:notes:65]
In addition to normal product warranty, we identified product quality issues we believe resulted from vendor supplied materials: a
   heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in the second quarter of 2012. The expense for these product quality issues, and the related liabilities, are not included in the above tables related
   to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the
   Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the first half of 2012 were as follows (in millions):

[0001193125-12-311640:notes:66]
| Total accrued product quality issue as of December 31, 2011 |  | $ | 7.5 |  |
| Estimated expense for expected product quality claims |  |  | 0.7 |  |
| Product quality claims |  |  | (1.7 | ) |
| Total accrued product quality issue as of June 30, 2012 |  | $ | 6.5 |  |

[0001193125-12-311640:notes:67]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts
   known. We do not believe that any current or pending or threatened litigation will have a material adverse effect on our financial position. Litigation and arbitration, however, involve uncertainties and it is possible that the eventual
   outcome of litigation could adversely affect our results of operations for a particular period.

[0001193125-12-311640:notes:68]
Our obligations under the Lake
   Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic
   Revolving Credit Facility. We were in compliance with these financial covenants as of June 30, 2012.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-311640:notes:69]
7. Lines of Credit and Financing Arrangements:

[0001193125-12-311640:notes:70]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated
   Balance Sheets (in millions):

[0001193125-12-311640:notes:71]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Total short-term debt |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: |  | $ | 0.5 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.7 |  |  |  | 16.6 |  |
| Domestic revolving credit facility |  |  | 297.5 |  |  |  | 243.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 514.2 |  |  | $ | 459.6 |  |
| Total debt |  | $ | 528.9 |  |  | $ | 465.1 |  |

[0001193125-12-311640:notes:72]
Short-Term Debt

[0001193125-12-311640:notes:73]
Foreign Obligations

[0001193125-12-311640:notes:74]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs
   for our foreign locations. We had $14.2 million and $4.7 million of foreign obligations as of June 30, 2012 and December 31, 2011, respectively.

[0001193125-12-311640:notes:75]
Asset Securitization Program

[0001193125-12-311640:notes:76]
Under the Receivables Purchase Agreement, or
   Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to renewal and contains a provision
   whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. The
   sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying
   Consolidated Statements of Cash Flows. The ASP provides for a maximum securitization amount of the lesser of $150.0 million or 100% of the net pool balance as defined by the ASP. However, eligibility for securitization is limited based on the amount
   and quality of the qualifying accounts receivable and is calculated monthly. On March 30, 2012, the parties involved with this securitization program agreed to remove Lennox Hearth Products LLC from the program. Any receivables originated by
   Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. The eligible amounts available and beneficial interests sold were as follows (in
   millions):

[0001193125-12-311640:notes:77]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
| Eligible amount available under the ASP on qualified accounts receivable |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 150.0 |  |  | $ | 150.0 |  |

[0001193125-12-311640:notes:78]
Under the ASP, we pay certain discount fees to use the program and have the facility available to us. These fees relate
   to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee
   of 0.60%. The average rate for June 30, 2012 was 0.86% and the average rate at December 31, 2011 was 0.91%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed
   rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP recorded was as follows (in millions):

[0001193125-12-311640:notes:79]
|  |  | For the Three Months Ended June 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Interest expense (including fees) |  | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.6 |  |  | $ | 0.2 |  |

[0001193125-12-311640:notes:80]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default
   provisions with our Domestic Revolving Credit Facility and senior unsecured notes. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade
   credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the ASP. As of June 30, 2012, we were in compliance with all covenant requirements.

[0001193125-12-311640:notes:81]
Long-Term Debt

[0001193125-12-311640:notes:82]
Domestic
   Revolving Credit Facility

[0001193125-12-311640:notes:83]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of
   $297.5 million and $58.5 million committed to standby letters of credit as of June 30, 2012. Subject to covenant limitations, $294.0 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of
   letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of
   $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001193125-12-311640:notes:84]
Our weighted average borrowing rate on the
   facility was as follows:

[0001193125-12-311640:notes:85]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Weighted average borrowing rate |  |  | 1.49 | % |  |  | 1.53 | % |

[0001193125-12-311640:notes:86]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants
   relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit
   Facility are detailed below:

[0001193125-12-311640:notes:87]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |

[0001193125-12-311640:notes:88]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default
   include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our revolving credit
   facility could occur if:

[0001193125-12-311640:notes:89]
|  | • |  | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001193125-12-311640:notes:90]
|  | • |  | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001193125-12-311640:notes:91]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross
   default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or
   lease commitment.

[0001193125-12-311640:notes:92]
If any event of
   default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic
   Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of June 30, 2012, we were in
   compliance with all covenant requirements.

[0001193125-12-311640:notes:93]
Senior Unsecured Notes

[0001193125-12-311640:notes:94]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and
   November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

[0001193125-12-311640:notes:95]
The notes are
   guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other
   things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our
   assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded
   within 30 days of the notice date. As of June 30, 2012, we were in compliance with all covenant requirements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-12-311640:notes:96]
[same as prior period, unchanged from 0001193125-12-177598:notes:99]

[0001193125-12-311640:notes:97]
[same as prior period, unchanged from 0001193125-12-177598:notes:100]

[0001193125-12-311640:notes:98]
|  |  | For the Three Months Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
|  |  | Pension Benefits |  |  | Other Benefits |  |
| Service cost |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | — |  |  | $ | 0.2 |  |
| Interest cost |  |  | 4.3 |  |  |  | 4.5 |  |  |  | 0.1 |  |  |  | 0.3 |  |
| Expected return on plan assets |  |  | (4.7 | ) |  |  | (4.8 | ) |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.1 |  |  |  | 0.1 |  |  |  | (0.8 | ) |  |  | (0.5 | ) |
| Amortization of net loss |  |  | 2.1 |  |  |  | 1.7 |  |  |  | 0.4 |  |  |  | 0.3 |  |
| Settlements or curtailments (1) |  |  | 6.3 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |
| Total net periodic pension cost |  | $ | 9.4 |  |  | $ | 3.0 |  |  | $ | (0.3 | ) |  | $ | 0.3 |  |

[0001193125-12-311640:notes:99]
|  |  | For the Six Months Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
|  |  | Pension Benefits |  |  | Other Benefits |  |
| Service cost |  | $ | 2.7 |  |  | $ | 2.7 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |
| Interest cost |  |  | 8.6 |  |  |  | 9.0 |  |  |  | 0.3 |  |  |  | 0.5 |  |
| Expected return on plan assets |  |  | (9.4 | ) |  |  | (9.5 | ) |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.2 |  |  |  | 0.2 |  |  |  | (1.3 | ) |  |  | (1.0 | ) |
| Amortization of net loss |  |  | 4.3 |  |  |  | 3.5 |  |  |  | 0.7 |  |  |  | 0.6 |  |
| Settlements or curtailments (1) |  |  | 6.3 |  |  |  | 1.6 |  |  |  | — |  |  |  | — |  |
| Total net periodic pension cost |  | $ | 12.7 |  |  | $ | 7.5 |  |  | $ | — |  |  | $ | 0.5 |  |

[0001193125-12-311640:notes:100]
|  | (1) | Settlements and curtailments in the three and six months ended June 30, 2012 are settlement charges related to actuarial losses recognized upon transition of a pension obligation to the acquirer of the Lennox Hearth Products business (“Hearth business”). |

[0001193125-12-311640:notes:101]
Pension expense of $3.1 million and $6.4 million is included in Income from continuing operations for the three and six months ended
   June 30, 2012, respectively, and $2.9 million and $7.0 million in Income from continuing operations for the three and six months ended June 30, 2011, respectively. Pension expense of $6.3 million is included in Loss from discontinued
   operations for the three and six months ended June 30, 2012, and $0.1 and $0.5 million in Loss from discontinued operations for the three and six months ended June 30, 2011, respectively.

[0001193125-12-311640:notes:102]
The pension expense for other benefits is included in Income from continuing operations for the three and six months ended June 30, 2012 and 2011.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-311640:notes:103]
[same as prior period, unchanged from 0001193125-12-177598:notes:103]

[0001193125-12-311640:notes:104]
[same as prior period, unchanged from 0001193125-12-177598:notes:104]

[0001193125-12-311640:notes:105]
|  |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net stock-based compensation expense |  | $ | 4.5 |  |  | $ | 4.2 |  |  | $ | 8.3 |  |  | $ | 9.1 |  |

[0001193125-12-311640:notes:106]
Net stock-based compensation expense includes $4.5 million and $8.8 million in Selling, General and Administrative
   Expenses for the three and six months ended June 30, 2012, respectively, and none and a $0.5 million benefit in Loss from discontinued operations for the three and six months ended June 30, 2012, respectively. The benefit in Loss from
   discontinued operations was for shares that were probable of forfeiture as of the first quarter of 2012 due to the sale of the Hearth business.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-12-311640:notes:107]
[same as prior period, unchanged from 0001193125-12-177598:notes:107]

[0001193125-12-311640:notes:108]
As part of our strategic priorities of manufacturing and sourcing excellence and expense reduction, we initiated
   various manufacturing rationalization actions designed to lower our cost structure. We expanded these expense reductions across the company by initiating a number of activities to rationalize and reorganize various support and administrative
   functions. Restructuring charges are not included in our calculation of segment profit (loss).See Note 13 for further discussion. Detailed below are the restructuring activities that we incurred additional expense in 2012.

[0001193125-12-311640:notes:109]
[same as prior period, unchanged from 0001193125-12-177598:notes:109]

[0001193125-12-311640:notes:110]
[same as prior period, unchanged from 0001193125-12-177598:notes:110]

[0001193125-12-311640:notes:111]
We began to exit certain Refrigeration manufacturing operations in Milperra, Australia in 2010, specifically our OEM coil
   manufacturing and contract coil manufacturing. The exit of our OEM coil manufacturing was substantially complete in 2010. We initiated restructuring activities related to exiting contract coil manufacturing in the third quarter of 2010. The
   remaining costs related to this restructuring activity primarily relate to plant closure costs. In the first half of 2012, we recognized $0.4 million in plant closure costs. We reversed $0.3 million in severance charges in the first half of 2012 to
   adjust estimated charges for our OEM coil manufacturing restructuring to actual.

[0001193125-12-311640:notes:112]
[same as prior period, unchanged from 0001193125-12-177598:notes:112]

[0001193125-12-311640:notes:113]
We began to reorganize certain administrative functions and the management structure of our Service Experts business in 2010 and initiated
   two actions. The first action was to reorganize the administrative operations of an acquired company and was completed in 2010. The second action, initiated in the fourth quarter of 2010, was to reorganize the management structure of our Service
   Experts business. We recognized $1.0 million in severance and other costs in the first half of 2012.

[0001193125-12-311640:notes:114]
[same as prior period, unchanged from 0001193125-12-177598:notes:114]

[0001193125-12-311640:notes:115]
[same as prior period, unchanged from 0001193125-12-177598:notes:115]

[0001193125-12-311640:notes:116]
In the fourth quarter of 2008, we commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa to other locations, including our North American Distribution
   Center in Marshalltown, Iowa. In the first half of 2012, we recognized $2.5 million primarily in lease termination charges. The total expected restructuring charges for the regional distribution network is $6.6 million of which $6.1 million were
   incurred to date.

[0001193125-12-311640:notes:117]
[same as prior period, unchanged from 0001193125-12-177598:notes:117]

[0001193125-12-311640:notes:118]
[same as prior period, unchanged from 0001193125-12-177598:notes:118]

[0001193125-12-311640:notes:119]
|  |  | ChargesIncurred in2012 |  |  | ChargesIncurred toDate |  |  | TotalChargesExpected tobe Incurred |  |
| Severance and related expense |  | $ | 0.4 |  |  | $ | 28.9 |  |  | $ | 29.3 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 10.1 |  |  |  | 10.1 |  |
| Equipment moves |  |  | 0.1 |  |  |  | 1.7 |  |  |  | 1.9 |  |
| Lease termination |  |  | 2.4 |  |  |  | 9.2 |  |  |  | 9.2 |  |
| Other |  |  | 0.8 |  |  |  | 15.3 |  |  |  | 16.3 |  |
| Total |  | $ | 3.7 |  |  | $ | 65.2 |  |  | $ | 66.8 |  |

[0001193125-12-311640:notes:120]
[same as prior period, unchanged from 0001193125-12-177598:notes:120]

[0001193125-12-311640:notes:121]
|  |  | ChargesIncurred in2012 |  |  | ChargesIncurred toDate |  |  | TotalChargesExpected tobe Incurred |  |
| Residential Heating & Cooling |  | $ | 2.6 |  |  | $ | 20.3 |  |  | $ | 21.5 |  |
| Commercial Heating & Cooling |  |  | — |  |  |  | 6.9 |  |  |  | 6.9 |  |
| Service Experts |  |  | 0.9 |  |  |  | 9.3 |  |  |  | 9.4 |  |
| Refrigeration |  |  | 0.3 |  |  |  | 23.0 |  |  |  | 23.3 |  |
| Corporate & Other |  |  | (0.1 | ) |  |  | 5.7 |  |  |  | 5.7 |  |
| Total |  | $ | 3.7 |  |  | $ | 65.2 |  |  | $ | 66.8 |  |

[0001193125-12-311640:notes:122]
Restructuring reserves are included in Accrued Expenses in the accompanying Consolidated Balance Sheets. The table
   below details activity within the restructuring reserves for the first half of 2012 (in millions):

[0001193125-12-311640:notes:123]
| Description of Reserves |  | Balance as ofDecember 31,2011 |  |  | Chargedto Earnings |  |  | CashUtilization |  |  | Non-CashUtilizationand Other |  |  | Balance as ofJune 30,2012 |  |
| Severance and related expense |  | $ | 2.5 |  |  | $ | 0.4 |  |  | $ | (1.2 | ) |  | $ | — |  |  | $ | 1.7 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |
| Lease termination |  |  | — |  |  |  | 2.4 |  |  |  | — |  |  |  | — |  |  |  | 2.4 |  |
| Other |  |  | 0.1 |  |  |  | 0.8 |  |  |  | (0.9 | ) |  |  | 0.1 |  |  |  | 0.1 |  |
| Total restructuring reserves |  | $ | 2.6 |  |  | $ | 3.7 |  |  | $ | (2.2 | ) |  | $ | 0.1 |  |  | $ | 4.2 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001193125-12-311640:notes:124]
[same as prior period, unchanged from 0001193125-12-177598:notes:124]

[0001193125-12-311640:notes:125]
In April 2012, the Company announced the sale of its Hearth business to Comvest Investment Partners IV in an all cash
   transaction. The Hearth business had historically been included in the Company’s Residential Heating & Cooling Segment. We sold the Hearth business on April 24, 2012 for net proceeds of $7.2 million, subject to a working capital
   adjustment. The net proceeds exclude transaction costs and cash transferred to the buyer with the sale of the business.

[0001193125-12-311640:notes:126]
A
   summary of net trade sales and pre-tax operating losses are detailed below (in millions):

[0001193125-12-311640:notes:127]
|  |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net trade sales |  | $ | 4.9 |  |  | $ | 22.9 |  |  | $ | 23.5 |  |  | $ | 41.3 |  |
| Pre-tax operating loss (1) |  |  | (3.4 | ) |  |  | (1.7 | ) |  |  | (11.9 | ) |  |  | (7.4 | ) |
| Loss on sale |  |  | (3.8 | ) |  |  | — |  |  |  | (3.8 | ) |  |  | — |  |

[0001193125-12-311640:notes:128]
|  | (1) | Pre-tax operating loss includes a $6.3 million first quarter 2012 pre-tax charge for the write-down of net assets to their estimated fair value and a $6.3 million settlement charge in the second quarter of 2012 related to actuarial losses recognized upon transition of a pension obligation to the acquirer of the Hearth business (See Note 8). Offsetting these charges was a $3.5 million gain in the second quarter of 2012 related to realized foreign currency translation adjustments. |

[0001193125-12-311640:notes:129]
The assets and liabilities of the
   discontinued operations are presented as follows in the accompanying Consolidated Balance Sheets (in millions):

[0001193125-12-311640:notes:130]
|  |  | As of June 30, |  |  | As ofDecember 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Assets of discontinued operations: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | — |  |  | $ | 7.3 |  |
| Inventories, net |  |  | — |  |  |  | 12.4 |  |
| Deferred income taxes |  |  | — |  |  |  | 9.1 |  |
| Property, Plant and Equipment |  |  | — |  |  |  | 5.4 |  |
| Other assets |  |  | — |  |  |  | 0.8 |  |
| Liabilities of discontinued operations: |  |  |  |  |  |  |  |  |
| Accounts Payable |  | $ | — |  |  | $ | 6.0 |  |
| Accrued expenses |  |  | — |  |  |  | 5.2 |  |
| Pensions |  |  | — |  |  |  | — |  |
| Other Liabilities |  |  | — |  |  |  | 0.4 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-311640:notes:131]
12. Earnings Per Share:

[0001193125-12-311640:notes:132]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares
   outstanding during the period. Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based
   compensation plans.

[0001193125-12-311640:notes:133]
The computations of basic and diluted earnings per share for Income from Continuing Operations were as
   follows (in millions, except per share data):

[0001193125-12-311640:notes:134]
|  |  | For theThree Months EndedJune 30, |  |  | For theSix Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net income |  | $ | 44.7 |  |  | $ | 45.0 |  |  | $ | 38.6 |  |  | $ | 37.8 |  |
| Loss from discontinued operations |  |  | (3.5 | ) |  |  | (1.1 | ) |  |  | (9.1 | ) |  |  | (4.8 | ) |
| Income from continuing operations |  | $ | 48.2 |  |  | $ | 46.1 |  |  | $ | 47.7 |  |  | $ | 42.6 |  |
| Weighted-average shares outstanding – basic |  |  | 51.0 |  |  |  | 53.2 |  |  |  | 50.9 |  |  |  | 53.4 |  |
| Effect of diluted securities attributable to stock-based payments |  |  | 0.6 |  |  |  | 1.1 |  |  |  | 0.6 |  |  |  | 1.1 |  |
| Weighted-average shares outstanding – diluted |  |  | 51.6 |  |  |  | 54.3 |  |  |  | 51.5 |  |  |  | 54.5 |  |
| Earnings per share from continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.95 |  |  | $ | 0.87 |  |  | $ | 0.94 |  |  | $ | 0.80 |  |
| Diluted |  | $ | 0.93 |  |  | $ | 0.85 |  |  | $ | 0.93 |  |  | $ | 0.78 |  |

[0001193125-12-311640:notes:135]
Stock appreciation rights were outstanding, but not included in the diluted earnings per share calculation because the
   assumed exercise of such rights would have been anti-dilutive. The details are as follows:

[0001193125-12-311640:notes:136]
|  |  | For the Six Months Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Number of shares |  |  | 1,072,808 |  |  |  | 464,314 |  |
| Price ranges per share |  | $ | 34.06-46.78 |  |  | $ | 46.78 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-311640:notes:137]
[same as prior period, unchanged from 0001193125-12-177598:notes:137]

[0001193125-12-311640:notes:138]
[same as prior period, unchanged from 0001193125-12-177598:notes:138]

[0001193125-12-311640:notes:139]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Heating Air Conditioning |  | Residential Replacement Residential New Construction |  | United States Canada |
| Commercial Heating & Cooling |  | Rooftop Products Chillers Air Handlers |  | Light Commercial |  | United States Canada Europe |
| Service Experts |  | Equipment Sales Installation Maintenance Repair |  | Residential Light Commercial |  | United States Canada |
| Refrigeration |  | Unit Coolers Condensing Units Other Commercial Refrigeration Products Display Cases and Systems |  | Light Commercial Food Preservation and Non-Food/Industrial |  | United States Canada Europe Asia Pacific South America |

[0001193125-12-311640:notes:140]
[same as prior period, unchanged from 0001193125-12-177598:notes:140]

[0001193125-12-311640:notes:141]
[same as prior period, unchanged from 0001193125-12-177598:notes:141]

[0001193125-12-311640:notes:142]
[same as prior period, unchanged from 0001193125-12-177598:notes:142]

[0001193125-12-311640:notes:143]
Net sales and segment profit (loss) by business segment, along with a reconciliation of segment profit (loss) to Income from continuing
   operations before income taxes are shown below (in millions):

[0001193125-12-311640:notes:144]
|  |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 411.9 |  |  | $ | 372.3 |  |  | $ | 684.5 |  |  | $ | 625.9 |  |
| Commercial Heating & Cooling |  |  | 200.7 |  |  |  | 198.3 |  |  |  | 337.7 |  |  |  | 337.1 |  |
| Service Experts |  |  | 133.1 |  |  |  | 145.4 |  |  |  | 234.7 |  |  |  | 261.9 |  |
| Refrigeration |  |  | 207.1 |  |  |  | 217.5 |  |  |  | 392.2 |  |  |  | 392.6 |  |
| Eliminations (1) |  |  | (19.0 | ) |  |  | (19.4 | ) |  |  | (31.1 | ) |  |  | (34.0 | ) |
|  |  | $ | 933.8 |  |  | $ | 914.1 |  |  | $ | 1,618.0 |  |  | $ | 1,583.5 |  |
| Segment Profit (Loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 42.0 |  |  | $ | 35.2 |  |  | $ | 53.0 |  |  | $ | 39.6 |  |
| Commercial Heating & Cooling |  |  | 30.1 |  |  |  | 27.1 |  |  |  | 36.1 |  |  |  | 33.0 |  |
| Service Experts |  |  | 2.0 |  |  |  | 3.2 |  |  |  | (9.5 | ) |  |  | (5.0 | ) |
| Refrigeration |  |  | 21.3 |  |  |  | 21.4 |  |  |  | 35.5 |  |  |  | 35.0 |  |
| Corporate and other |  |  | (15.7 | ) |  |  | (11.6 | ) |  |  | (30.1 | ) |  |  | (26.0 | ) |
| Eliminations |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | (0.4 | ) |  |  | (0.2 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 79.5 |  |  |  | 75.5 |  |  |  | 84.6 |  |  |  | 76.4 |  |

[0001193125-12-311640:notes:145]
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | 0.5 |  |  |  | (2.4 | ) |  |  | 0.1 |  |  |  | (2.4 | ) |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (2) |  |  | 0.6 |  |  |  | 1.3 |  |  |  | (0.9 | ) |  |  | 2.3 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | 2.4 |  |  |  | 3.7 |  |  |  | 3.6 |  |
| Interest expense, net |  |  | 4.3 |  |  |  | 4.3 |  |  |  | 9.0 |  |  |  | 8.4 |  |
| Other expense, net |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 73.4 |  |  | $ | 69.8 |  |  | $ | 72.6 |  |  | $ | 64.4 |  |

[0001193125-12-311640:notes:146]
| (1) | The net sales of the Residential Heating & Cooling segment include $19.0 million and $31.1 million for the three and six months ended June 30, 2012, respectively, and $19.4 million and $34.0 million for the three and six months of June 30, 2011, respectively, of intersegment revenues for HVAC equipment sold to our Service Experts segment. These intersegment sales are eliminated in the consolidated results. The net sales for all other segments are related to sales to external customers. |

[0001193125-12-311640:notes:147]
| (2) | Items in Losses and other expenses, net that are excluded from segment profit are net change in unrealized gains and/or losses on open futures contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, and other items. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-311640:notes:148]
[same as prior period, unchanged from 0001193125-12-177598:notes:154]

[0001193125-12-311640:notes:149]
[same as prior period, unchanged from 0001193125-12-177598:notes:155]

[0001193125-12-311640:notes:150]
[same as prior period, unchanged from 0001193125-12-177598:notes:156]

[0001193125-12-311640:notes:151]
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Assets: |  |  |  |  |  |  |  |  |
| Investment in marketable equity securities (1) |  | $ | 10.5 |  |  | $ | 8.4 |  |

[0001193125-12-311640:notes:152]
[same as prior period, unchanged from 0001193125-12-177598:notes:158]

[0001193125-12-311640:notes:153]
[same as prior period, unchanged from 0001193125-12-177598:notes:159]

[0001193125-12-311640:notes:154]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net, accounts payable, other current liabilities, and short-term debt approximate fair value due to the short maturities
   of these instruments. The fair values of each of our long-term debt instruments are based on the quoted market prices for the same issues or on the amount of future cash flows associated with each instrument using current market rates for debt
   instruments of similar maturities and credit risk. The fair values presented are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently or indicative of our intent or ability to dispose of or
   liquidate them. The estimated fair value of our debt was as follows (in millions):

[0001193125-12-311640:notes:155]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Senior unsecured notes |  | $ |  |  |  |  | 213.0 |  |  | $ |  |  |  |  | 207.0 |  |


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0001193125-12-311640:notes:156]
[same as prior period, unchanged from 0001193125-12-177598:notes:162]

[0001193125-12-311640:notes:157]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries
   (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned; all guarantees are full and unconditional; and all guarantees are
   joint and several. As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001193125-12-311640:notes:158]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting. Intercompany account balances have been included in Accounts
   and notes receivable, Other assets (Current), Other assets, net, Short-term debt, Accounts payable, and Long-term debt line items of the Parent, Guarantor and Non-Guarantor balance sheets. The principal elimination entries eliminate investments in
   subsidiaries and intercompany balances and transactions.

[0001193125-12-311640:notes:159]
Condensed consolidating financial statements of the Company, its
   Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of June 30, 2012 and December 31, 2011 and for the three and six months ended June 30, 2012 and 2011 are shown below:

[0001193125-12-311640:notes:160]
Condensed Consolidating Balance Sheets

[0001193125-12-311640:notes:161]
As of June 30, 2012

[0001193125-12-311640:notes:162]
[same as prior period, unchanged from 0001193125-12-177598:notes:168]

[0001193125-12-311640:notes:163]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1.0 |  |  | $ | 24.2 |  |  | $ | 43.9 |  |  | $ | — |  |  | $ | 69.1 |  |
| Accounts and notes receivable, net |  |  | (921.4 | ) |  |  | 898.1 |  |  |  | 512.9 |  |  |  | 23.6 |  |  |  | 513.2 |  |
| Inventories, net |  |  | — |  |  |  | 314.4 |  |  |  | 118.0 |  |  |  | (5.1 | ) |  |  | 427.3 |  |
| Deferred income taxes, net |  |  | 1.5 |  |  |  | 23.3 |  |  |  | 8.0 |  |  |  | (1.3 | ) |  |  | 31.5 |  |
| Other assets |  |  | 0.6 |  |  |  | 22.1 |  |  |  | 118.6 |  |  |  | (69.7 | ) |  |  | 71.6 |  |
| Total current assets |  |  | (918.3 | ) |  |  | 1,282.1 |  |  |  | 801.4 |  |  |  | (52.5 | ) |  |  | 1,112.7 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 242.3 |  |  |  | 50.3 |  |  |  | — |  |  |  | 292.6 |  |
| GOODWILL |  |  | — |  |  |  | 133.9 |  |  |  | 168.3 |  |  |  | — |  |  |  | 302.2 |  |
| DEFERRED INCOME TAXES |  |  | (0.7 | ) |  |  | 89.6 |  |  |  | 17.5 |  |  |  | (9.7 | ) |  |  | 96.7 |  |
| OTHER ASSETS, net |  |  | 2,113.7 |  |  |  | 842.9 |  |  |  | 27.7 |  |  |  | (2,900.3 | ) |  |  | 84.0 |  |
| TOTAL ASSETS |  | $ | 1,194.7 |  |  | $ | 2,590.8 |  |  | $ | 1,065.2 |  |  | $ | (2,962.5 | ) |  | $ | 1,888.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 111.5 |  |  | $ | — |  |  | $ | (61.0 | ) |  | $ | (36.3 | ) |  | $ | 14.2 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.3 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.5 |  |
| Accounts payable |  |  | 9.2 |  |  |  | 235.4 |  |  |  | 92.2 |  |  |  | 34.4 |  |  |  | 371.2 |  |
| Accrued expenses |  |  | 7.1 |  |  |  | 189.3 |  |  |  | 90.6 |  |  |  | (0.1 | ) |  |  | 286.9 |  |
| Income taxes payable |  |  | (10.7 | ) |  |  | 20.0 |  |  |  | 30.5 |  |  |  | (34.1 | ) |  |  | 5.7 |  |
| Total current liabilities |  |  | 117.1 |  |  |  | 445.0 |  |  |  | 152.5 |  |  |  | (36.1 | ) |  |  | 678.5 |  |
| LONG-TERM DEBT |  |  | 497.5 |  |  |  | 16.2 |  |  |  | 95.9 |  |  |  | (95.4 | ) |  |  | 514.2 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 18.5 |  |  |  | — |  |  |  | — |  |  |  | 18.5 |  |
| PENSIONS |  |  | — |  |  |  | 107.1 |  |  |  | 12.0 |  |  |  | — |  |  |  | 119.1 |  |
| OTHER LIABILITIES |  |  | 0.9 |  |  |  | 62.1 |  |  |  | 13.4 |  |  |  | (11.0 | ) |  |  | 65.4 |  |
| Total liabilities |  |  | 615.5 |  |  |  | 648.9 |  |  |  | 273.8 |  |  |  | (142.5 | ) |  |  | 1,395.7 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 579.2 |  |  |  | 1,941.9 |  |  |  | 791.4 |  |  |  | (2,820.0 | ) |  |  | 492.5 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,194.7 |  |  | $ | 2,590.8 |  |  | $ | 1,065.2 |  |  | $ | (2,962.5 | ) |  | $ | 1,888.2 |  |

[0001193125-12-311640:notes:164]
Condensed Consolidating Statements of Operations

[0001193125-12-311640:notes:165]
For the Three Months Ended June 30, 2012

[0001193125-12-311640:notes:166]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 761.5 |  |  | $ | 226.4 |  |  | $ | (54.1 | ) |  | $ | 933.8 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 565.6 |  |  |  | 173.2 |  |  |  | (53.8 | ) |  |  | 685.1 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 195.9 |  |  |  | 53.2 |  |  |  | (0.3 | ) |  |  | 248.7 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 134.6 |  |  |  | 38.0 |  |  |  | 0.1 |  |  |  | 172.7 |  |
| (Gains) losses and other expenses, net |  |  | (0.6 | ) |  |  | 1.3 |  |  |  | 0.8 |  |  |  | — |  |  |  | 1.5 |  |
| Restructuring charges |  |  | — |  |  |  | 0.4 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.6 |  |
| (Income) loss from equity method investments |  |  | (50.3 | ) |  |  | (3.7 | ) |  |  | (3.1 | ) |  |  | 53.2 |  |  |  | (3.9 | ) |
| Income (loss) from continuing operations |  |  | 50.8 |  |  |  | 63.3 |  |  |  | 17.3 |  |  |  | (53.6 | ) |  |  | 77.8 |  |
| INTEREST EXPENSE (INCOME), net |  |  | 4.4 |  |  |  | (0.7 | ) |  |  | 0.6 |  |  |  | — |  |  |  | 4.3 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 46.4 |  |  |  | 64.0 |  |  |  | 16.6 |  |  |  | (53.6 | ) |  |  | 73.4 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (1.4 | ) |  |  | 21.8 |  |  |  | 4.9 |  |  |  | (0.1 | ) |  |  | 25.2 |  |
| Income (loss) from continuing operations |  |  | 47.8 |  |  |  | 42.2 |  |  |  | 11.7 |  |  |  | (53.5 | ) |  |  | 48.2 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (2.2 | ) |  |  | (1.3 | ) |  |  | — |  |  |  | (3.5 | ) |
| Net income (loss) |  | $ | 47.8 |  |  | $ | 40.0 |  |  | $ | 10.4 |  |  | $ | (53.5 | ) |  | $ | 44.7 |  |
| OTHER COMPREHENSIVE (LOSS) INCOME |  | $ | (4.5 | ) |  | $ | (2.9 | ) |  | $ | (21.1 | ) |  | $ | 3.5 |  |  | $ | (25.0 | ) |

[0001193125-12-311640:notes:167]
For the Six Months Ended June 30, 2012

[0001193125-12-311640:notes:168]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-Guarantor Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 1,284.7 |  |  | $ | 434.5 |  |  | $ | (101.2 | ) |  | $ | 1,618.0 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 973.8 |  |  |  | 330.1 |  |  |  | (100.8 | ) |  |  | 1,203.2 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 310.9 |  |  |  | 104.4 |  |  |  | (0.4 | ) |  |  | 414.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 256.2 |  |  |  | 79.4 |  |  |  | 0.1 |  |  |  | 335.7 |  |
| (Gains) losses and other expenses, net |  |  | (2.2 | ) |  |  | 0.6 |  |  |  | 1.6 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | 3.5 |  |  |  | 0.2 |  |  |  | — |  |  |  | 3.7 |  |
| (Income) loss from equity method investments |  |  | (43.5 | ) |  |  | (1.6 | ) |  |  | (5.0 | ) |  |  | 43.8 |  |  |  | (6.3 | ) |
| Income (loss) from continuing operations |  |  | 45.6 |  |  |  | 52.2 |  |  |  | 28.2 |  |  |  | (44.3 | ) |  |  | 81.7 |  |
| INTEREST EXPENSE (INCOME), net |  |  | 8.8 |  |  |  | (1.2 | ) |  |  | 1.4 |  |  |  | — |  |  |  | 9.0 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  |  |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 36.8 |  |  |  | 53.4 |  |  |  | 26.7 |  |  |  | (44.3 | ) |  |  | 72.6 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (2.4 | ) |  |  | 19.0 |  |  |  | 8.5 |  |  |  | (0.2 | ) |  |  | 24.9 |  |
| Income (loss) from continuing operations |  |  | 39.2 |  |  |  | 34.4 |  |  |  | 18.2 |  |  |  | (44.1 | ) |  |  | 47.7 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (4.4 | ) |  |  | (4.7 | ) |  |  | — |  |  |  | (9.1 | ) |
| Net income (loss) |  | $ | 39.2 |  |  | $ | 30.0 |  |  | $ | 13.5 |  |  | $ | (44.1 | ) |  | $ | 38.6 |  |
| OTHER COMPREHENSIVE INCOME (LOSS) |  | $ | 2.3 |  |  | $ | (0.2 | ) |  | $ | (9.0 | ) |  | $ | 4.4 |  |  | $ | (2.5 | ) |

[0001193125-12-311640:notes:169]
[same as prior period, unchanged from 0001193125-12-177598:notes:173]

[0001193125-12-311640:notes:170]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1.0 |  |  | $ | 9.7 |  |  | $ | 34.4 |  |  | $ | (0.1 | ) |  | $ | 45.0 |  |
| Accounts and notes receivable, net |  |  | (991.9 | ) |  |  | 950.1 |  |  |  | 422.6 |  |  |  | 20.6 |  |  |  | 401.4 |  |
| Inventories, net |  |  | — |  |  |  | 221.2 |  |  |  | 107.5 |  |  |  | (4.7 | ) |  |  | 324.0 |  |
| Deferred income taxes, net |  |  | 4.7 |  |  |  | 23.5 |  |  |  | 8.3 |  |  |  | (1.3 | ) |  |  | 35.2 |  |
| Other assets |  |  | 1.6 |  |  |  | 21.7 |  |  |  | 108.6 |  |  |  | (56.5 | ) |  |  | 75.4 |  |
| Assets of discontinued operations |  |  | — |  |  |  | 24.7 |  |  |  | 10.3 |  |  |  | — |  |  |  | 35.0 |  |
| Total current assets |  |  | (984.6 | ) |  |  | 1,250.9 |  |  |  | 691.7 |  |  |  | (42.0 | ) |  |  | 916.0 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 251.7 |  |  |  | 52.8 |  |  |  | — |  |  |  | 304.5 |  |
| GOODWILL |  |  | — |  |  |  | 133.4 |  |  |  | 172.2 |  |  |  | — |  |  |  | 305.6 |  |
| DEFERRED INCOME TAXES |  |  | 0.2 |  |  |  | 89.8 |  |  |  | 19.2 |  |  |  | (9.7 | ) |  |  | 99.5 |  |
| OTHER ASSETS, net |  |  | 2,174.6 |  |  |  | 532.8 |  |  |  | 22.2 |  |  |  | (2,649.5 | ) |  |  | 80.1 |  |
| TOTAL ASSETS |  | $ | 1,190.2 |  |  | $ | 2,258.6 |  |  | $ | 958.1 |  |  | $ | (2,701.2 | ) |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 112.1 |  |  | $ | — |  |  | $ | (67.3 | ) |  | $ | (40.1 | ) |  | $ | 4.7 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.6 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.8 |  |
| Accounts payable |  |  | 9.2 |  |  |  | 133.5 |  |  |  | 96.9 |  |  |  | 31.4 |  |  |  | 271.0 |  |
| Accrued expenses |  |  | 15.3 |  |  |  | 177.0 |  |  |  | 87.3 |  |  |  | (0.1 | ) |  |  | 279.5 |  |
| Income taxes payable |  |  | (29.9 | ) |  |  | 28.0 |  |  |  | 24.7 |  |  |  | (17.1 | ) |  |  | 5.7 |  |
| Liabilities of discontinued operations |  |  | — |  |  |  | 8.2 |  |  |  | 3.4 |  |  |  | — |  |  |  | 11.6 |  |
| Total current liabilities |  |  | 106.7 |  |  |  | 347.3 |  |  |  | 145.2 |  |  |  | (25.9 | ) |  |  | 573.3 |  |
| LONG-TERM DEBT |  |  | 443.0 |  |  |  | 16.2 |  |  |  | 97.3 |  |  |  | (96.9 | ) |  |  | 459.6 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 18.6 |  |  |  | — |  |  |  | — |  |  |  | 18.6 |  |
| PENSIONS |  |  | — |  |  |  | 111.9 |  |  |  | 12.8 |  |  |  | — |  |  |  | 124.7 |  |
| OTHER LIABILITIES |  |  | 0.8 |  |  |  | 58.6 |  |  |  | 13.3 |  |  |  | (11.0 | ) |  |  | 61.7 |  |
| Total liabilities |  |  | 550.5 |  |  |  | 552.6 |  |  |  | 268.6 |  |  |  | (133.8 | ) |  |  | 1,237.9 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 639.7 |  |  |  | 1,706.0 |  |  |  | 689.5 |  |  |  | (2,567.4 | ) |  |  | 467.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,190.2 |  |  | $ | 2,258.6 |  |  | $ | 958.1 |  |  | $ | (2,701.2 | ) |  | $ | 1,705.7 |  |

[0001193125-12-311640:notes:171]
For the Three Months Ended June 30, 2011

[0001193125-12-311640:notes:172]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 729.2 |  |  | $ | 236.9 |  |  | $ | (52.0 | ) |  | $ | 914.1 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 542.2 |  |  |  | 179.1 |  |  |  | (51.5 | ) |  |  | 669.9 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 187.0 |  |  |  | 57.8 |  |  |  | (0.5 | ) |  |  | 244.2 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 126.4 |  |  |  | 43.4 |  |  |  | — |  |  |  | 169.8 |  |
| Losses (gains) and other expenses, net |  |  | 1.3 |  |  |  | 0.2 |  |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | 1.2 |  |
| Restructuring charges |  |  | — |  |  |  | 2.5 |  |  |  | (0.1 | ) |  |  | — |  |  |  | 2.4 |  |
| (Income) loss from equity method investments |  |  | (54.9 | ) |  |  | (6.8 | ) |  |  | (2.6 | ) |  |  | 60.9 |  |  |  | (3.4 | ) |
| Operational income (loss) from continuing operations |  |  | 53.5 |  |  |  | 64.7 |  |  |  | 17.2 |  |  |  | (61.2 | ) |  |  | 74.2 |  |
| INTEREST EXPENSE (INCOME), net |  |  | 4.0 |  |  |  | (1.0 | ) |  |  | 1.2 |  |  |  | 0.1 |  |  |  | 4.3 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 49.5 |  |  |  | 65.7 |  |  |  | 15.9 |  |  |  | (61.3 | ) |  |  | 69.8 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (1.7 | ) |  |  | 20.8 |  |  |  | 5.1 |  |  |  | (0.5 | ) |  |  | 23.7 |  |
| Income (loss) from continuing operations |  |  | 51.2 |  |  |  | 44.9 |  |  |  | 10.8 |  |  |  | (60.8 | ) |  |  | 46.1 |  |
| (Loss) income from discontinued operations |  |  | — |  |  |  | (1.8 | ) |  |  | 0.7 |  |  |  | — |  |  |  | (1.1 | ) |
| Net income (loss) |  | $ | 51.2 |  |  | $ | 43.1 |  |  | $ | 11.5 |  |  | $ | (60.8 | ) |  | $ | 45.0 |  |
| OTHER COMPREHENSIVE (LOSS) INCOME |  | $ | (2.6 | ) |  | $ | 3.7 |  |  | $ | 4.5 |  |  | $ | 0.3 |  |  | $ | 5.9 |  |

[0001193125-12-311640:notes:173]
For the Six Months Ended June 30, 2011

[0001193125-12-311640:notes:174]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 1,229.8 |  |  | $ | 450.2 |  |  | $ | (96.5 | ) |  | $ | 1,583.5 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 930.2 |  |  |  | 341.8 |  |  |  | (97.1 | ) |  |  | 1,175.0 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 299.6 |  |  |  | 108.4 |  |  |  | 0.6 |  |  |  | 408.5 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 248.7 |  |  |  | 88.4 |  |  |  | — |  |  |  | 337.1 |  |
| Losses (gains) and other expenses, net |  |  | 2.2 |  |  |  | (1.0 | ) |  |  | (0.3 | ) |  |  | — |  |  |  | 0.9 |  |
| Restructuring charges |  |  | — |  |  |  | 3.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 3.6 |  |
| (Income) loss from equity method investments |  |  | (48.9 | ) |  |  | (5.7 | ) |  |  | (4.9 | ) |  |  | 53.5 |  |  |  | (6.0 | ) |
| Operational income (loss) from continuing operations |  |  | 46.6 |  |  |  | 54.4 |  |  |  | 24.8 |  |  |  | (52.9 | ) |  |  | 72.9 |  |
| INTEREST EXPENSE (INCOME), net |  |  | 8.0 |  |  |  | (1.8 | ) |  |  | 2.2 |  |  |  | — |  |  |  | 8.4 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 38.6 |  |  |  | 56.2 |  |  |  | 22.5 |  |  |  | (52.9 | ) |  |  | 64.4 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES |  |  | (3.5 | ) |  |  | 17.8 |  |  |  | 7.9 |  |  |  | (0.4 | ) |  |  | 21.8 |  |
| Income (loss) from continuing operations |  |  | 42.1 |  |  |  | 38.4 |  |  |  | 14.6 |  |  |  | (52.5 | ) |  |  | 42.6 |  |
| (Loss) income from discontinued operations |  |  | — |  |  |  | (5.2 | ) |  |  | 0.4 |  |  |  | — |  |  |  | (4.8 | ) |
| Net income (loss) |  | $ | 42.1 |  |  | $ | 33.2 |  |  | $ | 15.0 |  |  | $ | (52.5 | ) |  | $ | 37.8 |  |
| OTHER COMPREHENSIVE (LOSS) INCOME |  | $ | (6.7 | ) |  | $ | 5.7 |  |  | $ | 16.8 |  |  | $ | 1.3 |  |  | $ | 17.1 |  |

[0001193125-12-311640:notes:175]
Condensed Consolidating Statements of Cash Flows

[0001193125-12-311640:notes:176]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | 34.6 |  |  | $ | (51.6 | ) |  | $ | 6.4 |  |  | $ | — |  |  | $ | (10.6 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.2 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (14.2 | ) |  |  | (2.6 | ) |  |  | — |  |  |  | (16.8 | ) |
| Net proceeds from sale of business |  |  | — |  |  |  | 7.2 |  |  |  | — |  |  |  | — |  |  |  | 7.2 |  |
| Net cash used in discontinued operations |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Net cash used in investing activities |  |  | — |  |  |  | (7.0 | ) |  |  | (2.5 | ) |  |  | — |  |  |  | (9.5 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 9.9 |  |  |  | — |  |  |  | 9.9 |  |
| Asset securitization borrowings |  |  | — |  |  |  | — |  |  |  | 310.0 |  |  |  | — |  |  |  | 310.0 |  |
| Asset securitization payments |  |  | — |  |  |  | — |  |  |  | (310.0 | ) |  |  | — |  |  |  | (310.0 | ) |
| Long-term payments |  |  | — |  |  |  | (0.4 | ) |  |  | (0.2 | ) |  |  | — |  |  |  | (0.6 | ) |
| Borrowings from revolving credit facility |  |  | 526.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 526.0 |  |
| Payments on revolving credit facility |  |  | (471.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (471.5 | ) |
| Proceeds from stock option exercises |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.2 |  |
| Repurchases of common stock |  |  | (2.6 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2.6 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.2 |  |
| Intercompany debt |  |  | 0.8 |  |  |  | 0.4 |  |  |  | (1.2 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (70.4 | ) |  |  | 73.1 |  |  |  | (2.7 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (18.3 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (18.3 | ) |
| Net cash (used in) provided by financing activities |  |  | (34.6 | ) |  |  | 73.1 |  |  |  | 5.8 |  |  |  | — |  |  |  | 44.3 |  |
| INCREASE IN CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | 14.5 |  |  |  | 9.7 |  |  |  | — |  |  |  | 24.2 |  |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | 1.0 |  |  |  | 9.7 |  |  |  | 34.3 |  |  |  | — |  |  |  | 45.0 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | 1.0 |  |  | $ | 24.2 |  |  | $ | 43.9 |  |  | $ | — |  |  | $ | 69.1 |  |

[0001193125-12-311640:notes:177]
|  |  | Parent |  |  | GuarantorSubsidiaries |  |  | Non-GuarantorSubsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | 51.0 |  |  | $ | (184.9 | ) |  | $ | (8.5 | ) |  | $ | — |  |  | $ | (142.4 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.7 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.9 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (16.0 | ) |  |  | (2.0 | ) |  |  | — |  |  |  | (18.0 | ) |
| Net proceeds from sale of business |  |  | — |  |  |  | — |  |  |  | 0.6 |  |  |  | — |  |  |  | 0.6 |  |
| Acquisition of business |  |  | — |  |  |  | (139.8 | ) |  |  | (7.9 | ) |  |  | — |  |  |  | (147.7 | ) |
| Change in restricted cash |  |  | — |  |  |  | — |  |  |  | 11.7 |  |  |  | — |  |  |  | 11.7 |  |
| Net cash used in discontinued operations |  |  | — |  |  |  | (0.4 | ) |  |  | (0.2 | ) |  |  | — |  |  |  | (0.6 | ) |
| Net cash (used in) provided by investing activities |  |  | — |  |  |  | (155.5 | ) |  |  | 2.4 |  |  |  | — |  |  |  | (153.1 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 5.1 |  |  |  | — |  |  |  | 5.1 |  |
| Asset securitization borrowings |  |  | — |  |  |  | — |  |  |  | 80.0 |  |  |  | — |  |  |  | 80.0 |  |
| Asset securitization payments |  |  | — |  |  |  | — |  |  |  | (80.0 | ) |  |  | — |  |  |  | (80.0 | ) |
| Long-term payments |  |  | — |  |  |  | (0.4 | ) |  |  | — |  |  |  | — |  |  |  | (0.4 | ) |
| Borrowings from revolving credit facility |  |  | 683.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 683.0 |  |
| Payments on revolving credit facility |  |  | (429.0 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (429.0 | ) |
| Proceeds from stock option exercises |  |  | 1.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.3 |  |
| Repurchases of common stock |  |  | (36.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (36.5 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.5 |  |
| Intercompany debt |  |  | 35.8 |  |  |  | (11.6 | ) |  |  | (24.2 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (370.3 | ) |  |  | 365.2 |  |  |  | 5.1 |  |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (17.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (17.7 | ) |
| Net cash (used in) provided by financing activities |  |  | (131.9 | ) |  |  | 353.2 |  |  |  | (14.0 | ) |  |  | — |  |  |  | 207.3 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | (80.9 | ) |  |  | 12.8 |  |  |  | (20.1 | ) |  |  | — |  |  |  | (88.2 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 4.7 |  |  |  | — |  |  |  | 4.7 |  |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | 81.1 |  |  |  | 14.7 |  |  |  | 64.2 |  |  |  | — |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | 0.2 |  |  | $ | 27.5 |  |  | $ | 48.8 |  |  | $ | — |  |  | $ | 76.5 |  |
