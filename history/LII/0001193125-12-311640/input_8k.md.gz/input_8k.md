# LII 8-K — 0001193125-12-311373 filed 2012-07-24

## item codes, every 8-K on or before 2012-07-24

- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2012-07-24

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-12-311373:8k_2_02:1]
EX-99.1
2
d383675dex991.htm
PRESS RELEASE DATED JULY 24, 2012

[0001193125-12-311373:8k_2_02:2]
Press Release dated July 24, 2012

[0001193125-12-311373:8k_2_02:3]
Exhibit 99.1

[0001193125-12-311373:8k_2_02:4]
Lennox International Reports Second Quarter Results

[0001193125-12-311373:8k_2_02:5]
|  | • |  | Revenue up 4% at constant currency, led by 11% Residential growth |

[0001193125-12-311373:8k_2_02:6]
|  | • |  | Adjusted EPS from continuing operations of $0.96, up 12% |

[0001193125-12-311373:8k_2_02:7]
|  | • |  | GAAP EPS from continuing operations of $0.93, up 9% |

[0001193125-12-311373:8k_2_02:8]
|  | • |  | Raising 2012 adjusted EPS from continuing operations guidance range from $2.20-$2.60 to $2.35-$2.65 |

[0001193125-12-311373:8k_2_02:9]
|  | • |  | Minimum of $50 million of stock repurchases planned for second half of 2012 |

[0001193125-12-311373:8k_2_02:10]
DALLAS, July 24, 2012 – Lennox International Inc. (NYSE: LII) today reported financial results for the second quarter of 2012. Financial
results presented have been adjusted for discontinued operations related to the company’s sale of its Hearth business, which was completed in April 2012.

[0001193125-12-311373:8k_2_02:11]
Revenue for the second quarter was $934 million, up 2% from the prior-year quarter. At constant currency, revenue was up 4%. Adjusted earnings per share from continuing operations was $0.96, up 12% from
$0.86 in the prior-year quarter. On a GAAP basis, earnings per share from continuing operations was $0.93, up 9% from $0.85 in the prior-year quarter.

[0001193125-12-311373:8k_2_02:12]
“Continued strong execution drove 11% revenue growth and 19% profit growth in our Residential business in the second quarter,” said Todd Bluedorn, Chairman and CEO of Lennox International.
“Residential again realized strong growth in both new construction and replacement business, with warm weather comparable overall to the second quarter a year ago. Commercial revenue was up 5% at constant currency, with growth in both North
America and Europe, and margin expanded 130 basis points to 15.0%. Refrigeration revenue was flat at constant currency on softness in Australia and Europe in the second quarter, but margin expanded 50 basis points to 10.3%. In Service Experts,
revenue was down 8% at constant currency, and margin declined 70 basis points. Looking ahead for the company overall, we remain cautious on the global macroeconomic environment for the second half of the year but continue to be encouraged by the
strength in our Residential and Commercial businesses, and Refrigeration backlog remains solid. We are raising our 2012 adjusted EPS from continuing operations guidance range, with a new midpoint of $2.50, and plan a minimum of $50 million of stock
repurchases in the second half of this year.”

[0001193125-12-311373:8k_2_02:13]
FINANCIAL HIGHLIGHTS

[0001193125-12-311373:8k_2_02:14]
Revenue: Revenue for the second quarter was $934 million, up 2% from the prior-year quarter. At constant currency, revenue was up 4%. Volume and price were up, and mix was down from the prior-year
quarter.

[0001193125-12-311373:8k_2_02:15]
Gross Profit: Gross profit for the second quarter was $249 million, up 2% from the prior-year quarter. Gross margin was 26.6%
compared to 26.7% in the prior-year quarter. Gross margin was negatively impacted by lower product mix and foreign exchange, partially offset by price and productivity initiatives. The annual adjustment for warranty reserves was neutral in the
second quarter of 2012 compared to a favorable adjustment of $3 million in the prior-year quarter.

[0001193125-12-311373:8k_2_02:16]
Income from Continuing Operations:
Adjusted income from continuing operations in the second quarter was $49.6 million, or $0.96 earnings per share, compared to $46.8 million, or $0.86 earnings per share, in the prior-year quarter. Adjusted earnings from continuing operations for the
second quarter of 2012 excludes an after-tax charge of $0.4 million for restructuring activities, $0.3 million after-tax for the net change in unrealized losses on open future contracts, and an after-tax charge of $0.7 million for other items, net.

[0001193125-12-311373:8k_2_02:17]
On a GAAP basis, income from continuing operations for the second quarter was $48.2 million, or $0.93 earnings per share, compared to $46.1
million, or $0.85 earnings per share, in the prior-year quarter.

[0001193125-12-311373:8k_2_02:18]
Loss from Discontinued Operations: The Hearth business was placed in
discontinued operations in the first quarter of 2012 due to the planned sale by the company. The transaction was completed in April 2012. The loss from discontinued operations in the second quarter of 2012 was $3.5 million, or $0.06 per share,
including transaction costs, compared to a loss of $1.1 million, or $0.02 per share, in the second quarter of 2011. (Revised 2011 quarterly and annual earnings statements, which show the effect of the removal of the Hearth business on the
company’s 2011 results, are available at www.lennoxinternational.com.)

[0001193125-12-311373:8k_2_02:19]
Free Cash Flow and Total Debt: Cash from operations in the
second quarter was $24 million compared to $6 million in the prior-year quarter. The company invested $10 million in capital assets in the second quarter. Free cash flow was $14 million, compared to ($4) million in the prior-year quarter. Total debt
at the end of the second quarter was $529 million. Total cash and cash equivalents were $69 million at the end of the quarter.

[0001193125-12-311373:8k_2_02:20]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-12-311373:8k_2_02:21]
Residential Heating & Cooling

[0001193125-12-311373:8k_2_02:22]
Second quarter 2012 revenue in the Residential
Heating & Cooling business segment was $412 million, up 11% from the prior-year quarter. Currency was neutral to revenue growth. Segment profit was $42 million, up 19% from the prior-year quarter. Segment profit margin was 10.2%, up 70
basis points. Results were primarily impacted by higher volume, favorable price, and sourcing and productivity initiatives, with offsets from lower mix and a less favorable warranty reserve adjustment than in the prior-year quarter.

[0001193125-12-311373:8k_2_02:23]
Commercial Heating & Cooling

[0001193125-12-311373:8k_2_02:24]
Revenue in the Commercial Heating & Cooling business segment was $201 million, up 1% from the prior-year quarter. At constant currency, revenue
was up 5%. Segment profit was $30 million, up 11% from the prior-year quarter. Segment profit margin was 15.0%, up 130 basis points. Results were primarily impacted by higher volume, favorable price/mix, and sourcing and productivity initiatives,
with offsets from higher freight expenses and negative foreign exchange.

[0001193125-12-311373:8k_2_02:25]
Service Experts

[0001193125-12-311373:8k_2_02:26]
Revenue in the Service Experts business segment was $133 million in the second quarter, down 9% from the prior-year quarter. At constant currency, revenue
was down 8%. Segment profit was $2 million and segment profit margin was 1.5%, compared to segment profit of $3 million and segment profit margin of 2.2% in the prior-year quarter. Results were primarily impacted by lower volume, partially offset by
lower SG&A expenses driven by productivity initiatives.

[0001193125-12-311373:8k_2_02:27]
Refrigeration

[0001193125-12-311373:8k_2_02:28]
Revenue in the Refrigeration business segment was $207 million in the second quarter, down 5% from the prior-year quarter. At constant currency, revenue was flat. Segment profit was $21 million, flat with
the prior-year quarter. Segment profit margin was 10.3%, up 50 basis points from the prior-year quarter. Results were primarily impacted by favorable price/mix and sourcing initiatives, with offsets from lower volume and negative foreign exchange.

[0001193125-12-311373:8k_2_02:29]
FULL-YEAR OUTLOOK

[0001193125-12-311373:8k_2_02:30]
The company is updating its revenue and EPS from continuing operations guidance ranges for 2012.

[0001193125-12-311373:8k_2_02:31]
|  | • |  | Narrowing guidance for revenue growth at constant currency from 2-6% to a range of 3-6%. The company now assumes a negative 1 point impact from foreign exchange on a full-year basis, resulting in new revenue growth guidance of 2-5% at actual currency. |

[0001193125-12-311373:8k_2_02:32]
|  | • |  | Raising adjusted EPS from continuing operations guidance from $2.20-$2.60 to a range of $2.35-$2.65. |

[0001193125-12-311373:8k_2_02:33]
|  | • |  | Raising GAAP EPS from continuing operations guidance from $2.17-$2.57 to a range of $2.30-$2.60. |

[0001193125-12-311373:8k_2_02:34]
|  | • |  | Reiterating tax rate guidance of 33-34% for the full year. |

[0001193125-12-311373:8k_2_02:35]
|  | • |  | Reiterating average diluted share count guidance of approximately 51 million shares for the full year, including a minimum of $50 million of stock repurchases in the second half of 2012. |

[0001193125-12-311373:8k_2_02:36]
|  | • |  | Reiterating capital expenditure guidance of approximately $55 million in 2012. |

[0001193125-12-311373:8k_2_02:37]
CONFERENCE CALL INFORMATION

[0001193125-12-311373:8k_2_02:38]
A
conference call to discuss the company’s second quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-288-0337 at least 10 minutes prior to the scheduled start time and use
reservation number 253246. This conference call will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0001193125-12-311373:8k_2_02:39]
A replay will be available from 11:00 a.m. Central time on July 24 through July 31, 2012 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 253246. This call
will also be archived on the company’s web site.

[0001193125-12-311373:8k_2_02:40]
Lennox International Inc. is a global leader in the heating, air conditioning, and
refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under the symbol “LII.” Additional information is available at: http://www.lennoxinternational.com or by contacting Steve Harrison, Vice President,
Investor Relations, at 972-497-6670.

[0001193125-12-311373:8k_2_02:41]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-311373:8k_2_02:42]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-12-311373:8k_2_02:43]
(Unaudited, in millions, except per share data)

[0001193125-12-311373:8k_2_02:44]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| NET SALES |  | $ | 933.8 |  |  | $ | 914.1 |  |  | $ | 1,618.0 |  |  | $ | 1,583.5 |  |
| COST OF GOODS SOLD |  |  | 685.1 |  |  |  | 669.9 |  |  |  | 1,203.2 |  |  |  | 1,175.0 |  |
| Gross profit |  |  | 248.7 |  |  |  | 244.2 |  |  |  | 414.8 |  |  |  | 408.5 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 172.7 |  |  |  | 169.8 |  |  |  | 335.7 |  |  |  | 337.1 |  |
| Losses and other expenses, net |  |  | 1.5 |  |  |  | 1.2 |  |  |  | — |  |  |  | 0.9 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | 2.4 |  |  |  | 3.7 |  |  |  | 3.6 |  |
| Income from equity method investments |  |  | (3.9 | ) |  |  | (3.4 | ) |  |  | (6.3 | ) |  |  | (6.0 | ) |
| Operational income from continuing operations |  |  | 77.8 |  |  |  | 74.2 |  |  |  | 81.7 |  |  |  | 72.9 |  |
| INTEREST EXPENSE, net |  |  | 4.3 |  |  |  | 4.3 |  |  |  | 9.0 |  |  |  | 8.4 |  |
| OTHER EXPENSE |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 73.4 |  |  |  | 69.8 |  |  |  | 72.6 |  |  |  | 64.4 |  |
| PROVISION FOR INCOME TAXES |  |  | 25.2 |  |  |  | 23.7 |  |  |  | 24.9 |  |  |  | 21.8 |  |
| Income from continuing operations |  |  | 48.2 |  |  |  | 46.1 |  |  |  | 47.7 |  |  |  | 42.6 |  |
| DISCONTINUED OPERATIONS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations |  |  | (7.2 | ) |  |  | (1.7 | ) |  |  | (15.7 | ) |  |  | (7.4 | ) |
| Benefit from income taxes |  |  | (3.7 | ) |  |  | (0.6 | ) |  |  | (6.6 | ) |  |  | (2.6 | ) |
| Loss from discontinued operations |  |  | (3.5 | ) |  |  | (1.1 | ) |  |  | (9.1 | ) |  |  | (4.8 | ) |
| Net income |  | $ | 44.7 |  |  | $ | 45.0 |  |  | $ | 38.6 |  |  | $ | 37.8 |  |
| INCOME PER SHARE—BASIC: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.95 |  |  | $ | 0.87 |  |  | $ | 0.94 |  |  | $ | 0.80 |  |
| Loss from discontinued operations |  |  | (0.07 | ) |  |  | (0.02 | ) |  |  | (0.18 | ) |  |  | (0.09 | ) |
| Net income |  | $ | 0.88 |  |  | $ | 0.85 |  |  | $ | 0.76 |  |  | $ | 0.71 |  |
| INCOME PER SHARE—DILUTED: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.93 |  |  | $ | 0.85 |  |  | $ | 0.93 |  |  | $ | 0.78 |  |
| Loss from discontinued operations |  |  | (0.06 | ) |  |  | (0.02 | ) |  |  | (0.18 | ) |  |  | (0.09 | ) |
| Net income |  | $ | 0.87 |  |  | $ | 0.83 |  |  | $ | 0.75 |  |  | $ | 0.69 |  |
| AVERAGE SHARES OUTSTANDING: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 51.0 |  |  |  | 53.2 |  |  |  | 50.9 |  |  |  | 53.4 |  |
| Diluted |  |  | 51.6 |  |  |  | 54.3 |  |  |  | 51.5 |  |  |  | 54.5 |  |
| CASH DIVIDENDS DECLARED PER SHARE |  | $ | 0.18 |  |  | $ | 0.18 |  |  | $ | 0.36 |  |  | $ | 0.36 |  |

[0001193125-12-311373:8k_2_02:45]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-311373:8k_2_02:46]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001193125-12-311373:8k_2_02:47]
(Unaudited, in millions)

[0001193125-12-311373:8k_2_02:48]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 411.9 |  |  | $ | 372.3 |  |  | $ | 684.5 |  |  | $ | 625.9 |  |
| Commercial Heating & Cooling |  |  | 200.7 |  |  |  | 198.3 |  |  |  | 337.7 |  |  |  | 337.1 |  |
| Service Experts |  |  | 133.1 |  |  |  | 145.4 |  |  |  | 234.7 |  |  |  | 261.9 |  |
| Refrigeration |  |  | 207.1 |  |  |  | 217.5 |  |  |  | 392.2 |  |  |  | 392.6 |  |
| Eliminations (A) |  |  | (19.0 | ) |  |  | (19.4 | ) |  |  | (31.1 | ) |  |  | (34.0 | ) |
|  |  | $ | 933.8 |  |  | $ | 914.1 |  |  | $ | 1,618.0 |  |  | $ | 1,583.5 |  |
| Segment Profit (Loss) (B) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 42.0 |  |  | $ | 35.2 |  |  | $ | 53.0 |  |  | $ | 39.6 |  |
| Commercial Heating & Cooling |  |  | 30.1 |  |  |  | 27.1 |  |  |  | 36.1 |  |  |  | 33.0 |  |
| Service Experts |  |  | 2.0 |  |  |  | 3.2 |  |  |  | (9.5 | ) |  |  | (5.0 | ) |
| Refrigeration |  |  | 21.3 |  |  |  | 21.4 |  |  |  | 35.5 |  |  |  | 35.0 |  |
| Corporate and other |  |  | (15.7 | ) |  |  | (11.6 | ) |  |  | (30.1 | ) |  |  | (26.0 | ) |
| Eliminations (A) |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | (0.4 | ) |  |  | (0.2 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 79.5 |  |  |  | 75.5 |  |  |  | 84.6 |  |  |  | 76.4 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | 0.5 |  |  |  | (2.4 | ) |  |  | 0.1 |  |  |  | (2.4 | ) |
| Items in losses and other expenses, net that are excluded from segment profit (loss) (C) |  |  | 0.6 |  |  |  | 1.3 |  |  |  | (0.9 | ) |  |  | 2.3 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | 2.4 |  |  |  | 3.7 |  |  |  | 3.6 |  |
| Interest expense, net |  |  | 4.3 |  |  |  | 4.3 |  |  |  | 9.0 |  |  |  | 8.4 |  |
| Other Expense, net |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 73.4 |  |  | $ | 69.8 |  |  | $ | 72.6 |  |  | $ | 64.4 |  |

[0001193125-12-311373:8k_2_02:49]
| (A) | Eliminations consist of intercompany sales of products to Service Experts from the Residential Heating & Cooling segment. |

[0001193125-12-311373:8k_2_02:50]
| (B) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |

[0001193125-12-311373:8k_2_02:51]
Excluding:

[0001193125-12-311373:8k_2_02:52]
|  | • |  | Special product quality adjustment. |

[0001193125-12-311373:8k_2_02:53]
|  | • |  | Items within Gains and/or losses and other expenses, net that are noted in (C) . |

[0001193125-12-311373:8k_2_02:54]
|  | • |  | Restructuring charges. |

[0001193125-12-311373:8k_2_02:55]
|  | • |  | Goodwill and equity method investment impairments. |

[0001193125-12-311373:8k_2_02:56]
|  | • |  | Interest expense, net. |

[0001193125-12-311373:8k_2_02:57]
|  | • |  | Other expense, net. |

[0001193125-12-311373:8k_2_02:58]
| (C) | Items in losses and other expenses, net that are excluded from segment profit or loss are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, and other items. |

[0001193125-12-311373:8k_2_02:59]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-311373:8k_2_02:60]
CONSOLIDATED BALANCE SHEETS

[0001193125-12-311373:8k_2_02:61]
(In millions, except share and per share data)

[0001193125-12-311373:8k_2_02:62]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 69.1 |  |  | $ | 45.0 |  |
| Accounts and notes receivable, net of allowances of $9.5 and $12.0 in 2012 and 2011, respectively |  |  | 513.2 |  |  |  | 401.4 |  |
| Inventories, net |  |  | 427.3 |  |  |  | 324.0 |  |
| Deferred income taxes |  |  | 31.5 |  |  |  | 35.2 |  |
| Other assets |  |  | 71.6 |  |  |  | 75.4 |  |
| Assets of discontinued operations |  |  | — |  |  |  | 35.0 |  |
| Total current assets |  |  | 1,112.7 |  |  |  | 916.0 |  |
| PROPERTY, PLANT AND EQUIPMENT, net of accumulated depreciation of $582.0 and $571.6 in 2012 and 2011, respectively |  |  | 292.6 |  |  |  | 304.5 |  |
| GOODWILL |  |  | 302.2 |  |  |  | 305.6 |  |
| DEFERRED INCOME TAXES |  |  | 96.7 |  |  |  | 99.5 |  |
| OTHER ASSETS, net |  |  | 84.0 |  |  |  | 80.1 |  |
| TOTAL ASSETS |  | $ | 1,888.2 |  |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt |  |  | 0.5 |  |  |  | 0.8 |  |
| Accounts payable |  |  | 371.2 |  |  |  | 271.0 |  |
| Accrued expenses |  |  | 286.9 |  |  |  | 279.5 |  |
| Income taxes payable |  |  | 5.7 |  |  |  | 5.7 |  |
| Liabilities of discontinued operations |  |  | — |  |  |  | 11.6 |  |
| Total current liabilities |  |  | 678.5 |  |  |  | 573.3 |  |
| LONG-TERM DEBT |  |  | 514.2 |  |  |  | 459.6 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | 18.5 |  |  |  | 18.6 |  |
| PENSIONS |  |  | 119.1 |  |  |  | 124.7 |  |
| OTHER LIABILITIES |  |  | 65.4 |  |  |  | 61.7 |  |
| Total liabilities |  |  | 1,395.7 |  |  |  | 1,237.9 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares and 86,938,004 shares issued for 2012 and 2011, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 890.8 |  |  |  | 881.2 |  |
| Retained earnings |  |  | 713.2 |  |  |  | 692.9 |  |
| Accumulated other comprehensive income |  |  | (39.7 | ) |  |  | (37.1 | ) |
| Treasury stock, at cost, 36,155,832 shares and 36,093,966 shares for 2012 and 2011, respectively |  |  | (1,072.7 | ) |  |  | (1,070.1 | ) |
| Total stockholders’ equity |  |  | 492.5 |  |  |  | 467.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,888.2 |  |  | $ | 1,705.7 |  |

[0001193125-12-311373:8k_2_02:63]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-311373:8k_2_02:64]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-12-311373:8k_2_02:65]
(Unaudited, in millions)

[0001193125-12-311373:8k_2_02:66]
|  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 38.6 |  |  | $ | 37.8 |  |
| Net loss from discontinued operations |  |  | 9.1 |  |  |  | 4.8 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (6.3 | ) |  |  | (6.0 | ) |
| Dividends from affiliates |  |  | 2.0 |  |  |  | 2.4 |  |
| Restructuring expenses, net of cash paid |  |  | 1.5 |  |  |  | (3.1 | ) |
| Provision for bad debts |  |  | 1.7 |  |  |  | 3.3 |  |
| Unrealized (gain) loss on derivative contracts |  |  | (0.3 | ) |  |  | 1.6 |  |
| Stock-based compensation expense |  |  | 8.3 |  |  |  | 9.1 |  |
| Depreciation and amortization |  |  | 27.9 |  |  |  | 28.8 |  |
| Deferred income taxes |  |  | 4.4 |  |  |  | 1.2 |  |
| Other items, net |  |  | 4.2 |  |  |  | (0.9 | ) |
| Changes in assets and liabilities, net of effects of acquisitions and divestures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (117.5 | ) |  |  | (97.2 | ) |
| Inventories |  |  | (113.7 | ) |  |  | (137.1 | ) |
| Other current assets |  |  | 1.1 |  |  |  | (2.1 | ) |
| Accounts payable |  |  | 102.6 |  |  |  | 79.0 |  |
| Accrued expenses |  |  | 16.2 |  |  |  | (41.2 | ) |
| Income taxes payable and receivable |  |  | 7.7 |  |  |  | (9.3 | ) |
| Other |  |  | 1.9 |  |  |  | (2.2 | ) |
| Net cash used in discontinued operations |  |  | — |  |  |  | (11.3 | ) |
| Net cash used in operating activities |  |  | (10.6 | ) |  |  | (142.4 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.2 |  |  |  | 0.9 |  |
| Purchases of property, plant and equipment |  |  | (16.8 | ) |  |  | (18.0 | ) |
| Net proceeds from sale of businesses |  |  | 7.2 |  |  |  | 0.6 |  |
| Acquisition of business |  |  | — |  |  |  | (147.7 | ) |
| Change in restricted cash |  |  | — |  |  |  | 11.7 |  |
| Net cash used in discontinued operations |  |  | (0.1 | ) |  |  | (0.6 | ) |
| Net cash used in investing activities |  |  | (9.5 | ) |  |  | (153.1 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 9.9 |  |  |  | 5.1 |  |
| Asset securitization borrowings |  |  | 310.0 |  |  |  | 80.0 |  |
| Asset securitization payments |  |  | (310.0 | ) |  |  | (80.0 | ) |
| Long-term payments |  |  | (0.6 | ) |  |  | (0.4 | ) |
| Borrowings from revolving credit facility |  |  | 526.0 |  |  |  | 683.0 |  |
| Payments on revolving credit facility |  |  | (471.5 | ) |  |  | (429.0 | ) |
| Proceeds from stock option exercises |  |  | 0.2 |  |  |  | 1.3 |  |
| Repurchases of common stock |  |  | (2.6 | ) |  |  | (36.5 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.2 |  |  |  | 1.5 |  |
| Cash dividends paid |  |  | (18.3 | ) |  |  | (17.7 | ) |
| Net cash provided by financing activities |  |  | 44.3 |  |  |  | 207.3 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | 24.2 |  |  |  | (88.2 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | (0.1 | ) |  |  | 4.7 |  |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | 45.0 |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | 69.1 |  |  | $ | 76.5 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the period for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 9.5 |  |  | $ | 8.0 |  |
| Income taxes (net of refunds) |  | $ | 8.0 |  |  | $ | 25.4 |  |

[0001193125-12-311373:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-311373:8k_2_02:68]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-12-311373:8k_2_02:69]
(Unaudited, in millions, except per share, ratio, sales growth rate and margin data)

[0001193125-12-311373:8k_2_02:70]
Use of Non-GAAP Financial Measures

[0001193125-12-311373:8k_2_02:71]
To
supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that
these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial
measures enhance the ability of investors to analyze the Company's business trends and operating performance.

[0001193125-12-311373:8k_2_02:72]
Reconciliation of Income
From Continuing Operations, a GAAP measure, to Adjusted Income From Continuing Operations, a Non-GAAP measure

[0001193125-12-311373:8k_2_02:73]
|  |  | For The Three Months |  |  | For The Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Income from continuing operations, a GAAP measure |  | $ | 48.2 |  |  | $ | 46.1 |  |  | $ | 47.7 |  |  | $ | 42.6 |  |
| Restructuring charges, after tax |  |  | 0.4 |  |  |  | 1.6 |  |  |  | 2.4 |  |  |  | 2.4 |  |
| Net change in unrealized losses (gains) on open future contracts, after tax (a) |  |  | 0.3 |  |  |  | 0.5 |  |  |  | (0.8 | ) |  |  | 0.9 |  |
| Special product quality adjustment, after-tax (b) |  |  | 0.6 |  |  |  | (1.5 | ) |  |  | 0.3 |  |  |  | (1.5 | ) |
| Other items, net, after tax (a) |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 49.6 |  |  | $ | 46.8 |  |  | $ | 49.9 |  |  | $ | 44.7 |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 0.93 |  |  | $ | 0.85 |  |  | $ | 0.93 |  |  | $ | 0.78 |  |
| Restructuring charges |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.05 |  |  |  | 0.04 |  |
| Special product quality adjustment, after-tax (b) |  |  | 0.01 |  |  |  | (0.03 | ) |  |  | 0.01 |  |  |  | (0.03 | ) |
| Net change in unrealized losses (gains) on open future contracts and other items, net (a) |  |  | 0.01 |  |  |  | 0.01 |  |  |  | (0.02 | ) |  |  | 0.03 |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  | $ | 0.96 |  |  | $ | 0.86 |  |  | $ | 0.97 |  |  | $ | 0.82 |  |

[0001193125-12-311373:8k_2_02:74]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-12-311373:8k_2_02:75]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-12-311373:8k_2_02:76]
|  |  | For The Three Months |  |  | For The Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized loss (gains) on settled future contracts (a) |  | $ | 0.7 |  |  |  | (0.4 | ) |  | $ | 1.0 |  |  |  | (1.0 | ) |
| Foreign currency exchange loss (gain) (a) |  |  | 0.1 |  |  |  | 0.4 |  |  |  | (0.2 | ) |  |  | 0.5 |  |
| Loss (gain) on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | 0.1 |  |  |  | (0.9 | ) |
| Net change in unrealized losses (gains) on open futures contracts (b) |  |  | 0.5 |  |  |  | 0.7 |  |  |  | (1.2 | ) |  |  | 1.5 |  |
| Gain on sale of entity (b) |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |
| Other items, net (b) |  |  | 0.1 |  |  |  | 0.7 |  |  |  | 0.3 |  |  |  | 0.9 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 0.9 |  |

[0001193125-12-311373:8k_2_02:77]
| (a) | Included in segment profit (loss) and adjusted income from continuing operations |

[0001193125-12-311373:8k_2_02:78]
| (b) | Excluded from segment profit (loss) and adjusted income from continuing operations |

[0001193125-12-311373:8k_2_02:79]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations—Diluted, a Non-GAAP
Measure, to Income per Share from Continuing Operations—Diluted, a GAAP Measure

[0001193125-12-311373:8k_2_02:80]
|  |  | For the |  |
|  |  | Year Ended |  |
|  |  | December 31, |  |
|  |  | 2012 |  |
|  |  | ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 2.35 - $2.65 |  |
| Restructuring charges |  |  | (0.05 | ) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 2.30 - $2.60 |  |

[0001193125-12-311373:8k_2_02:81]
Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP Measure, to Free Cash Flow, a Non-GAAP
Measure

[0001193125-12-311373:8k_2_02:82]
|  |  | For the Three Months |  |  | For the Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 23.7 |  |  | $ | 5.9 |  |  | $ | (10.6 | ) |  | $ | (142.4 | ) |
| Purchases of property, plant and equipment |  |  | (10.0 | ) |  |  | (10.1 | ) |  |  | (16.8 | ) |  |  | (18.0 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | 13.7 |  |  | $ | (4.2 | ) |  | $ | (27.4 | ) |  | $ | (160.4 | ) |

[0001193125-12-311373:8k_2_02:83]
Calculation of Debt to EBITDA Ratio:

[0001193125-12-311373:8k_2_02:84]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | June 30, |  |
|  |  | 2012 |  |
| EBIT (a) |  | $ | 199.1 |  |
| Depreciation and amortization expense (b) |  |  | 56.9 |  |
| EBITDA (a + b) |  | $ | 256.0 |  |
| Total debt at June 30, 2012 (c) |  | $ | 528.9 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 2.1 |  |

[0001193125-12-311373:8k_2_02:85]
Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure

[0001193125-12-311373:8k_2_02:86]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | June 30, |  |
|  |  | 2012 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 199.1 |  |
| Special product quality adjustment |  |  | (1.8 | ) |
| Items in gains and other expenses, net that are excluded from segment profit |  |  | 1.7 |  |
| Restructuring charges |  |  | 16.1 |  |
| Asset Impairment |  |  | 0.3 |  |
| Other expenses, net |  |  | 0.3 |  |
| Interest expense, net |  |  | 17.4 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 165.1 |  |
