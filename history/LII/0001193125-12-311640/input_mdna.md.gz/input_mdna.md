# LII MD&A — 0001193125-12-311640


## mdna

[0001193125-12-311640:mdna:1]
[same as prior period, unchanged from 0001193125-12-177598:mdna:1]

[0001193125-12-311640:mdna:2]
[same as prior period, unchanged from 0001193125-12-177598:mdna:2]

[0001193125-12-311640:mdna:3]
We operate in
four reportable business segments of the heating, ventilation, air conditioning and refrigeration (‘HVACR’) industry. Our reportable segments consist of Residential Heating & Cooling, Commercial Heating & Cooling, Service
Experts and Refrigeration. For more detailed information regarding our reportable segments, see Note 13 in the Notes to our Consolidated Financial Statements.

[0001193125-12-311640:mdna:4]
Our fiscal year ends on December 31 and our interim fiscal quarters are each comprised of 13 weeks. For convenience, throughout this Management’s Discussion and Analysis of Financial Condition
and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted by the last day of the calendar quarter.

[0001193125-12-311640:mdna:5]
Our products and services are sold through a combination of distributors, independent and company-owned dealer service centers, other installing contractors, wholesalers, manufacturers’
representatives, original equipment manufacturers and directly to national accounts. The demand for our products and services is seasonal and dependent on the weather. Warmer than normal summer temperatures generate strong demand for replacement air
conditioning and refrigeration products and services and colder than normal winter temperatures have the same effect on heating products and services. Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR
products and services. In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment
trends, new construction, general economic conditions and consumer spending habits and confidence.

[0001193125-12-311640:mdna:6]
The principal elements of
cost of goods sold in our manufacturing operations are components, raw materials, factory overhead, labor and estimated costs of warranty expense. The principal raw materials used in our manufacturing processes are steel, copper and aluminum. In
recent years, increased prices for these commodities and related components have challenged us and the HVACR industry in general. We seek to mitigate the impact of higher commodity prices through a combination of price increases for our products and
services, commodity contracts, improved production efficiency and cost reduction initiatives. We also seek to mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts. In our Service
Experts segment, the principal components of cost of goods sold are equipment, parts and supplies and labor.

[0001193125-12-311640:mdna:7]
In the second
quarter of 2012, our Residential Heating & Cooling segment led our overall operational improvement with an 11% increase in net sales and $7 million in increased profit. This segment’s improvement can be attributed to an increase in its
new construction business and replacement business in the second quarter of 2012. Our Commercial Heating & Cooling segment performance also improved in the second quarter of 2012 when compared to the same period in 2011, with a 1% increase
in sales and $3 million in increased profit. Excluding the 4% unfavorable impact from foreign currency, sales for this segment increased 5%. The improved performance of this business was primarily due to an increase in business with our existing
customers and the addition of new customers particularly in our European business. A slight increase from improved pricing also added to the performance for Commercial Heating & Cooling. Our sales were down almost 5% for our

[0001193125-12-311640:mdna:8]
Refrigeration segment; however, excluding the 5% unfavorable foreign currency impact, the Refrigeration segment sales were flat. This segment’s profit was also flat when compared to the
second quarter of 2011. Partially offsetting the results in our other segments, our Service Experts segment experienced an 9% decline in net sales and a $1 million decline in profit for the second quarter of 2012 compared to the second quarter of
2011. Our Service Experts segment did not benefit from the increase in residential new construction business that our Residential Heating & Cooling segment did, as Service Experts has limited exposure to residential new construction.

[0001193125-12-311640:mdna:9]
We sold the Hearth business in the second quarter of 2012 for $7.2 million in net proceeds which excludes the transaction
costs and cash transferred with the business. The net loss from the sale of the Hearth business was $3.8 million.

[0001193125-12-311640:mdna:10]
[same as prior period, unchanged from 0001193125-12-177598:mdna:8]

[0001193125-12-311640:mdna:11]
|  | • |  | Net sales for the second quarter of 2012 increased to $933.8 million compared to $914.1 million in 2011, or a 2% increase. We had a 4% increase in overall net sales for LII excluding foreign currency exchange rate impact. |

[0001193125-12-311640:mdna:12]
|  | • |  | Operational income for the second quarter of 2012 increased to $77.8 million as compared to $74.2 million in 2011. The increase in operational income was primarily due to higher volume and higher margins from non-commodity material cost savings partially offset by a less favorable warranty adjustment. |

[0001193125-12-311640:mdna:13]
|  | • |  | Net income for the second quarter of 2012 was $44.7 million compared to $45.0 million in 2011. Diluted earnings per share from continuing operations were $0.93 in the second quarter of 2012 compared to diluted earnings per share from continuing operations of $0.85 in 2011. |

[0001193125-12-311640:mdna:14]
|  | • |  | Cash used in operating activities was $11 million in the first half of 2012 compared to $142 million in the first half of 2011. The decline in cash used in operating activities in the first half of 2012 was due to favorable working capital in the first half of 2012 compared to the first half of 2011 and an increase in accrued expenses due to an increase in incentive compensation from our improved operating results. |

[0001193125-12-311640:mdna:15]
Second Quarter of 2012 Compared to Second Quarter of 2011 – Consolidated Results

[0001193125-12-311640:mdna:16]
[same as prior period, unchanged from 0001193125-12-177598:mdna:13]

[0001193125-12-311640:mdna:17]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001193125-12-311640:mdna:18]
|  |  | Three Months Ended June 30, |  |
|  |  |  |  |  | PercentChange Fav/(Unfav) |  |  |  |  |
|  |  | Dollars |  |  |  | Percent Sales |  |
|  |  | 2012 |  |  | 2011 |  |  |  | 2012 |  |  | 2011 |  |
| Net sales |  | $ | 933.8 |  |  | $ | 914.1 |  |  |  | 2.2 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 685.1 |  |  |  | 669.9 |  |  |  | (2.3 | ) |  |  | 73.4 |  |  |  | 73.3 |  |
| Gross profit |  |  | 248.7 |  |  |  | 244.2 |  |  |  | (1.8 | ) |  |  | 26.6 |  |  |  | 26.7 |  |
| Selling, general and administrative expenses |  |  | 172.7 |  |  |  | 169.8 |  |  |  | (1.7 | ) |  |  | 18.5 |  |  |  | 18.6 |  |
| Losses and other expenses, net |  |  | 1.5 |  |  |  | 1.2 |  |  |  | (25.0 | ) |  |  | 0.2 |  |  |  | 0.1 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | 2.4 |  |  |  | 75.0 |  |  |  | — |  |  |  | 0.3 |  |
| Income from equity method investments |  |  | (3.9 | ) |  |  | (3.4 | ) |  |  | 14.7 |  |  |  | (0.4 | ) |  |  | (0.4 | ) |
| Operational income |  | $ | 77.8 |  |  | $ | 74.2 |  |  |  | 4.9 | % |  |  | 8.3 | % |  |  | 8.1 | % |

[0001193125-12-311640:mdna:19]
[same as prior period, unchanged from 0001193125-12-177598:mdna:17]

[0001193125-12-311640:mdna:20]
Net sales increased 2% in the second quarter of 2012 compared to the second quarter of 2011. Our sales volume was up 5%, while price and mix were down 1% from the comparable period. The increase in volume
was in our Residential Heating & Cooling and Commercial Heating & Cooling segments. Changes in foreign currency exchange rates unfavorably impacted net sales by 2%. Excluding the impact from unfavorable foreign currency exchange
rates, net sales in the second quarter of 2012 were up approximately 4% from the second quarter of 2011.

[0001193125-12-311640:mdna:21]
[same as prior period, unchanged from 0001193125-12-177598:mdna:19]

[0001193125-12-311640:mdna:22]
Gross profit margins were relatively flat at 26.6% for the second quarter of 2012 compared to 26.7% for the second quarter of 2011. Non-commodity material cost savings added approximately 60 basis points.
Almost fully offsetting these increases to profit margins were a less favorable warranty adjustment of 30 basis points, unfavorable other product costs of 20 basis points, and an increase in freight and distribution costs of 20 basis points.

[0001193125-12-311640:mdna:23]
[same as prior period, unchanged from 0001193125-12-177598:mdna:21]

[0001193125-12-311640:mdna:24]
Selling, general and administrative (“SG&A”) expenses increased by $3 million in the second quarter of 2012 compared to 2011; and as a percentage of net sales, SG&A expense was flat at
19% in 2012 compared to 2011. The increase in SG&A expenses was principally due to higher incentive compensation due to overall improved operating results in the second quarter of 2012 partially offset by lower bad debt expense and favorable
foreign currency exchange rates.

[0001193125-12-311640:mdna:25]
Losses and Other Expenses, Net

[0001193125-12-311640:mdna:26]
Losses and other expenses, net for the second quarters of 2012 and 2011 included the following (in millions):

[0001193125-12-311640:mdna:27]
|  |  | Three Months Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Realized losses (gains) on settled futures contracts |  | $ | 0.7 |  |  | $ | (0.4 | ) |
| Unrealized loss on unsettled futures contracts not designated as cash flow hedges |  |  | 0.5 |  |  |  | 0.7 |  |
| Foreign currency exchange losses |  |  | 0.1 |  |  |  | 0.4 |  |
| Other items, net |  |  | 0.2 |  |  |  | 0.5 |  |
| Losses and other expenses, net |  | $ | 1.5 |  |  | $ | 1.2 |  |

[0001193125-12-311640:mdna:28]
[same as prior period, unchanged from 0001193125-12-177598:mdna:26]

[0001193125-12-311640:mdna:29]
[same as prior period, unchanged from 0001193125-12-177598:mdna:27]

[0001193125-12-311640:mdna:30]
Restructuring charges declined from $2 million in
the second quarter of 2011 to less than $1 million in the second quarter of 2012. As we did not initiate any new large projects in the second quarter of 2012, the charges in this period related to minor charges from various open projects initiated
in prior years, principally the reorganization of the Service Experts administrative functions and management structure. The restructuring charges from the second quarter of 2011 were also primarily related to the reorganization of Service Experts
with the remaining restructuring charges from the second quarter of 2011 from various open projects initiated in 2010 and prior years. For more information, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001193125-12-311640:mdna:31]
Results from Equity Method and Other Equity Investments

[0001193125-12-311640:mdna:32]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments increased slightly from $3.4
million in 2011 to $3.9 million in the second quarter of 2012, primarily due to increased performance from our joint ventures.

[0001193125-12-311640:mdna:33]
Interest
Expense, Net

[0001193125-12-311640:mdna:34]
Interest expense, net, was flat at $4 million in the second quarters of 2012 and 2011, as both our weighted
average borrowings and weighted average interest rate were relatively flat in the comparable periods.

[0001193125-12-311640:mdna:35]
Income Tax Expense

[0001193125-12-311640:mdna:36]
Income tax expense was $25 million in the second quarter of 2012 compared to $24 million in 2011. The effective tax rate was 34.3% for the second quarter of 2012 and 34.0% for the second quarter of 2011.
Our effective rates differ from the statutory federal rate of 35% for certain items, such as state and local taxes, non-deductible expenses, foreign operating losses for which no tax benefits have been recognized and foreign taxes at rates other
than 35%.

[0001193125-12-311640:mdna:37]
Loss from Discontinued Operations

[0001193125-12-311640:mdna:38]
In the fourth quarter of 2011, we began to pursue strategic alternatives for our Hearth reporting unit. We sold this business in the second quarter of 2012 for $7.2 million in net proceeds subject to a
working capital adjustment.

[0001193125-12-311640:mdna:39]
We had a pre-tax loss of $7.2 million in discontinued operations in the second quarter of 2012
for the Hearth reporting unit compared to a pre-tax loss of $1.7 million in the second quarter of 2011. The loss from discontinued operations in the second quarter of 2012 included a $6.3 million pension settlement charge for realization of pension
losses related to the transfer of a pension to the buyer, $3.8 million for a loss on the sale of the business, and a $3.5 million gain for the realization of foreign currency translation adjustments.

[0001193125-12-311640:mdna:40]
Second Quarter of 2012 Compared to Second Quarter of 2011 – Results by Segment

[0001193125-12-311640:mdna:41]
[same as prior period, unchanged from 0001193125-12-177598:mdna:40]

[0001193125-12-311640:mdna:42]
The following table summarizes our Residential Heating & Cooling segment’s net sales and profit for the second quarters of 2012 and 2011 (dollars in millions):

[0001193125-12-311640:mdna:43]
|  |  | Three Months EndedJune 30, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 411.9 |  |  | $ | 372.3 |  |  | $ | 39.6 |  |  |  | 10.6 | % |
| Profit |  |  | 42.0 |  |  |  | 35.2 |  |  |  | 6.8 |  |  |  | 19.3 | % |
| % of net sales |  |  | 10.2 | % |  |  | 9.5 | % |  |  |  |  |  |  |  |  |

[0001193125-12-311640:mdna:44]
Residential Heating & Cooling’s net sales increased by 11% in the second quarter of 2012
compared to the second quarter of 2011. Sales volumes increased by 14%, partially offset by a 3% decline in price and mix in 2012 compared to 2011.

[0001193125-12-311640:mdna:45]
Segment profit increased $7 million, including a $16 million increase from sales volume and $2 million from non-commodity material cost savings. Segment profit was adversely affected by a $7 million
decline from price and mix and $2 million in commodity headwinds. Comparisons were also adversely affected $2 million from a less favorable warranty adjustment.

[0001193125-12-311640:mdna:46]
[same as prior period, unchanged from 0001193125-12-177598:mdna:45]

[0001193125-12-311640:mdna:47]
The following table summarizes our
Commercial Heating & Cooling segment’s net sales and profit for the second quarters of 2012 and 2011 (dollars in millions):

[0001193125-12-311640:mdna:48]
|  |  | Three Months EndedJune 30, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 200.7 |  |  | $ | 198.3 |  |  | $ | 2.4 |  |  |  | 1.2 | % |
| Profit |  |  | 30.1 |  |  |  | 27.1 |  |  |  | 3.0 |  |  |  | 11.1 | % |
| % of net sales |  |  | 15.0 | % |  |  | 13.7 | % |  |  |  |  |  |  |  |  |

[0001193125-12-311640:mdna:49]
Our Commercial Heating & Cooling business experienced a 1% increase in net sales in the second
quarter of 2012 compared to 2011. Excluding the 4% unfavorable impact from foreign currency exchange rates, our net sales increased by 5%. Sales volume increased by 4% and price increased 1%.

[0001193125-12-311640:mdna:50]
Segment profit for the second quarter of 2012 increased $3 million compared to the second
quarter of 2011. Segment profit increased $5 million from the impact of higher net sales. Partially offsetting the positive impact from the higher net sales was a $1 million increase in freight and distribution and $1 million of unfavorable
foreign currency exchange rates.

[0001193125-12-311640:mdna:51]
[same as prior period, unchanged from 0001193125-12-177598:mdna:50]

[0001193125-12-311640:mdna:52]
The following table summarizes our Service Experts segment’s net sales and profit for the second quarters of 2012 and 2011 (dollars in millions):

[0001193125-12-311640:mdna:53]
|  |  | Three Months EndedJune 30, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 133.1 |  |  | $ | 145.4 |  |  | $ | (12.3 | ) |  |  | (8.5 | )% |
| Profit |  |  | 2.0 |  |  |  | 3.2 |  |  |  | (1.2 | ) |  |  | (37.5 | )% |
| % of net sales |  |  | 1.5 | % |  |  | 2.2 | % |  |  |  |  |  |  |  |  |

[0001193125-12-311640:mdna:54]
In total, net sales declined by 9%. Sales volume declined by 9% and unfavorable foreign currency exchange
rates added another 1% to the decline in net sales. Partially offsetting these declines is a 1% increase in mix from our commercial service business. The decline in this segment’s sales volume is primarily due to the decline in residential
service business with some offset from growth in the commercial service business.

[0001193125-12-311640:mdna:55]
The decrease in segment profit was
primarily due to the impact of the volume decline in net sales. This decline was partially offset by a $3 million decrease in SG&A expense from productivity initiatives.

[0001193125-12-311640:mdna:56]
[same as prior period, unchanged from 0001193125-12-177598:mdna:55]

[0001193125-12-311640:mdna:57]
The following table summarizes our Refrigeration
segment’s net sales and profit for the second quarters of 2012 and 2011 (dollars in millions):

[0001193125-12-311640:mdna:58]
|  |  | Three Months EndedJune 30, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 207.1 |  |  | $ | 217.5 |  |  | $ | (10.4 | ) |  |  | (4.8 | )% |
| Profit |  |  | 21.3 |  |  |  | 21.4 |  |  |  | (0.1 | ) |  |  | (0.5 | )% |
| % of net sales |  |  | 10.3 | % |  |  | 9.8 | % |  |  |  |  |  |  |  |  |

[0001193125-12-311640:mdna:59]
Net sales decreased 5% in the second quarter of 2012 when compared to 2011. Unfavorable foreign currency
exchange rates accounted for the 5% decline in sales. Sales volumes declined 1% which was fully offset by a 1% increase in price.

[0001193125-12-311640:mdna:60]
Segment profit was flat. Although segment profit was flat, this segment generated $3 million in non-commodity material cost savings. These savings were fully offset by $3 million of unfavorable foreign
currency exchange rates and $1 million increase in SG&A expense.

[0001193125-12-311640:mdna:61]
Corporate and Other

[0001193125-12-311640:mdna:62]
Corporate and other expenses were $16 million in the second quarter of 2012, up from $12 million in 2011. The increase was primarily
driven by higher incentive compensation expense in 2012 compared to 2011 due to the overall increase in operating performance in the second quarter of 2012.

[0001193125-12-311640:mdna:63]
Year-to-Date through June 30, 2012 Compared to Year-to-Date through June 30, 2011 –
Consolidated Results

[0001193125-12-311640:mdna:64]
Results of Operations

[0001193125-12-311640:mdna:65]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001193125-12-311640:mdna:66]
|  |  | Six Months Ended June 30, |  |
|  |  |  |  |  | PercentChange Fav/(Unfav) |  |  |  |  |
|  |  | Dollars |  |  |  | Percent Sales |  |
|  |  | 2012 |  |  | 2011 |  |  |  | 2012 |  |  | 2011 |  |
| Net sales |  | $ | 1,618.0 |  |  | $ | 1,583.5 |  |  |  | 2.2 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 1,203.2 |  |  |  | 1,175.0 |  |  |  | (2.4 | ) |  |  | 74.4 |  |  |  | 74.2 |  |
| Gross profit |  |  | 414.8 |  |  |  | 408.5 |  |  |  | 1.5 |  |  |  | 25.6 |  |  |  | 25.8 |  |
| Selling, general and administrative expenses |  |  | 335.7 |  |  |  | 337.1 |  |  |  | 0.4 |  |  |  | 20.8 |  |  |  | 21.3 |  |
| Losses and other expenses, net |  |  | — |  |  |  | 0.9 |  |  |  | 100.0 |  |  |  | — |  |  |  | 0.1 |  |
| Restructuring charges |  |  | 3.7 |  |  |  | 3.6 |  |  |  | (2.8 | ) |  |  | 0.2 |  |  |  | 0.2 |  |
| Income from equity method investments |  |  | (6.3 | ) |  |  | (6.0 | ) |  |  | 5.0 |  |  |  | (0.4 | ) |  |  | (0.4 | ) |
| Operational income |  | $ | 81.7 |  |  | $ | 72.9 |  |  |  | 12.1 | % |  |  | 5.0 | % |  |  | 4.6 | % |

[0001193125-12-311640:mdna:67]
Net Sales

[0001193125-12-311640:mdna:68]
Net sales increased 2% in the first half of 2012 compared to the first half of 2011. Unfavorable foreign currency exchange rates negatively affected our sales by 2%. Excluding the impact from foreign
currency, our net sales increased by 4%. Our sales volumes were up 4% and our price and mix were flat in the comparable period. The increase in volume was predominantly in our Residential Heating & Cooling segment with modest volume
increases in our Commercial Heating & Cooling and Refrigeration segments.

[0001193125-12-311640:mdna:69]
Gross Profit

[0001193125-12-311640:mdna:70]
Gross profit margins were relatively flat at 25.6% for the first half of 2012 compared to gross profit margins of 25.8% for the first half
of 2011. The components of gross profit, including commodities and freight and distribution costs, in the first half of 2012 were comparable to the components of gross profit in the first half of 2011.

[0001193125-12-311640:mdna:71]
Selling, General and Administrative Expenses

[0001193125-12-311640:mdna:72]
SG&A expenses decreased by $1 million in the first half of 2012 compared to 2011, and as a percentage of net sales, SG&A expenses declined to 20.8% in 2012 from 21.3% in 2011. The decline in
SG&A expenses was principally due to favorable foreign currency exchange rates partially offset by higher incentive compensation due to overall improved operating results in the second quarter of 2012.

[0001193125-12-311640:mdna:73]
Losses and Other Expenses, Net

[0001193125-12-311640:mdna:74]
Losses and other expenses, net included the following (in millions):

[0001193125-12-311640:mdna:75]
|  |  | Six Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Realized losses (gains) on settled futures contracts |  | $ | 1.0 |  |  | $ | (1.0 | ) |
| Unrealized (gain) loss on unsettled futures contracts not designated as cash flow hedges |  |  | (1.2 | ) |  |  | 1.5 |  |
| Foreign currency exchange (gain) loss |  |  | (0.2 | ) |  |  | 0.5 |  |
| Other items, net |  |  | 0.4 |  |  |  | (0.1 | ) |
| Losses and other expenses, net |  | $ | — |  |  | $ | 0.9 |  |

[0001193125-12-311640:mdna:76]
The change in gains and losses on futures contracts was primarily due to decreases in commodity prices
relative to our futures contract prices during 2012 as compared to 2011 for the contracts that settled during the period. Conversely, the change in unrealized losses related to unsettled futures contracts not designated as cash flow hedges was
primarily due to higher commodity prices relative to the futures contract prices for those contracts. For more information, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001193125-12-311640:mdna:77]
Restructuring Charges

[0001193125-12-311640:mdna:78]
Restructuring charges were approximately $4 million in first six months of 2012 and 2011. As we did not initiate any new large projects in the first half of 2012, the restructuring changes in the first
half of 2012 were $3 million for our Regional Distribution Network project and $1 million for the reorganization of the Service Experts administrative functions and management structure. The restructuring charges from the first half of 2011 were $1
million for the exit of the coil manufacturing in Milperra, Australia and $2 million for the reorganization of the Service Experts administrative functions and management structure. The remaining restructuring charges were for various other
remaining restructuring projects. For more information, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001193125-12-311640:mdna:79]
Results from
Equity Method and Other Equity Investments

[0001193125-12-311640:mdna:80]
Investments over which we do not exercise control but have significant
influence are accounted for using the equity method of accounting. Income from equity method investments were approximately $6 million for the first six months of 2012 and the first six months of 2011.

[0001193125-12-311640:mdna:81]
[same as prior period, unchanged from 0001193125-12-177598:mdna:31]

[0001193125-12-311640:mdna:82]
Interest expense, net, increased to $9 million in the first six months of 2012 from $8 million in the same period in 2011. The increase in
interest expense was primarily attributable to an increase in the average amounts borrowed in the first half of 2012 compared to 2011 as well as an increase in our weighted average interest rate in the comparable period.

[0001193125-12-311640:mdna:83]
Income Tax Expense

[0001193125-12-311640:mdna:84]
The
income tax expense was $25 million in the first six months of 2012 compared to $22 million in 2011. The effective tax rate was 34.3% for 2012 and 33.9% in 2011. Our effective rates differ from the statutory federal rate of 35% for certain items,
such as state and local taxes, non-deductible expenses, foreign operating losses for which no tax benefits have been recognized and foreign taxes at rates other than 35%.

[0001193125-12-311640:mdna:85]
Loss from Discontinued Operations

[0001193125-12-311640:mdna:86]
In the fourth quarter of 2011, we began
to pursue strategic alternatives for our Hearth reporting unit due. We sold this business in the second quarter of 2012 for $7.2 million in net proceeds subject to a working capital adjustment.

[0001193125-12-311640:mdna:87]
We had a pre-tax loss of $15.7 million in discontinued operations in the first half of 2012 for the Hearth reporting unit compared to a
pre-tax loss of $7.4 million in the first half of 2011. The loss from discontinued operations in the first half of 2012 included a $6.3 million charge to write-down the related assets to their estimated fair value, a $6.3 million pension settlement
charge for realization of pension losses related to the transfer of a pension to the buyer, $3.8 million for a loss on the sale of the business, and a $3.5 million gain for the realization of foreign currency translation adjustments.

[0001193125-12-311640:mdna:88]
Year-to-Date Through June 30, 2012 Compared to Year-to-Date Through June 30, 2011 – Results by Segment

[0001193125-12-311640:mdna:89]
Residential Heating & Cooling

[0001193125-12-311640:mdna:90]
The following table summarizes our Residential Heating & Cooling segment’s net sales and profit for the first half of 2012 and 2011 (dollars in millions):

[0001193125-12-311640:mdna:91]
|  |  | Six Months EndedJune 30, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 684.5 |  |  | $ | 625.9 |  |  | $ | 58.6 |  |  |  | 9.4 | % |
| Profit |  |  | 53.0 |  |  |  | 39.6 |  |  |  | 13.4 |  |  |  | 33.8 | % |
| % of net sales |  |  | 7.7 | % |  |  | 6.3 | % |  |  |  |  |  |  |  |  |

[0001193125-12-311640:mdna:92]
Residential Heating & Cooling net sales increased by 9% in the first half of 2012
compared to the first half of 2011. Sales volumes increased by 12% in the first half of 2012 as compared to 2011. Partially offsetting the increase in sales volume was lower price and mix of 3%.

[0001193125-12-311640:mdna:93]
Segment profit increased $13 million due to $23 million in higher sales volumes, $3 million in non -commodity material costs savings, and
$3 million in lower SG&A. Partially offsetting these increases in segment profit were $9 million in unfavorable price and mix, $3 million in commodity headwinds. Comparisons were also adversely affected $2 million from a less favorable warranty
adjustment. The lower SG&A expenses were the result of lower bad debt expense and lower selling costs in the comparable period.

[0001193125-12-311640:mdna:94]
Commercial Heating & Cooling

[0001193125-12-311640:mdna:95]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit for the first half of 2012 and 2011 (dollars in millions):

[0001193125-12-311640:mdna:96]
|  |  | Six Months EndedJune 30, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 337.7 |  |  | $ | 337.1 |  |  | $ | 0.6 |  |  |  | 0.2 | % |
| Profit |  |  | 36.1 |  |  |  | 33.0 |  |  |  | 3.1 |  |  |  | 9.4 | % |
| % of net sales |  |  | 10.7 | % |  |  | 9.8 | % |  |  |  |  |  |  |  |  |

[0001193125-12-311640:mdna:97]
Our Commercial Heating & Cooling business sales were flat in the first half of 2012 compared to
2011. Unfavorable foreign currency exchange rates negatively affected our sales by 3%. Excluding the foreign impact, our sales increased 3%. Our sales volume increased by 2% and price and mix added 1% to the increase in sales.

[0001193125-12-311640:mdna:98]
Segment profit for the first half of 2012 increased $3 million from the first half of 2011. Segment profit increased from the impact of
higher sales by $7 million and productivity initiatives of $3 million. Partially offsetting these increases to segment profit were commodity headwinds of $2 million and freight and distribution charges of $2 million, increased SG&A expenses of
$2 million and higher non-commodity material costs of $1 million.

[0001193125-12-311640:mdna:99]
Service Experts

[0001193125-12-311640:mdna:100]
The following table summarizes our Service Experts segment’s net sales and loss for the first half of 2012 and 2011 (dollars in
millions):

[0001193125-12-311640:mdna:101]
|  |  | Six Months EndedJune 30, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 234.7 |  |  | $ | 261.9 |  |  | $ | (27.2 | ) |  |  | (10.4 | )% |
| Loss |  |  | (9.5 | ) |  |  | (5.0 | ) |  |  | (4.5 | ) |  |  | (90.0 | )% |
| % of net sales |  |  | (4.0 | )% |  |  | (1.9 | )% |  |  |  |  |  |  |  |  |

[0001193125-12-311640:mdna:102]
In total, sales volumes declined 13% which was partially offset by a 4% increase in price and mix.
Foreign currency exchange rates decreased net sales by 1%. The decline in this segment’s sales volume is primarily due to the decline in residential service business with some offset from growth in the commercial service business.

[0001193125-12-311640:mdna:103]
Segment loss for the first half of 2012 increased almost $5 million from the first half of 2011. The increase in segment loss in the
first half of 2012 was due to a $12 million decline in sales volumes. Partially offsetting the volume decline was a SG&A expense improvement of $5 million and $2 million in lower other product costs. The SG&A expense improvement was
primarily related to productivity initiatives.

[0001193125-12-311640:mdna:104]
Refrigeration

[0001193125-12-311640:mdna:105]
The following table summarizes our Refrigeration segment’s net sales and profit for the first half of 2012 and 2011 (dollars in millions):

[0001193125-12-311640:mdna:106]
|  |  | Six Months EndedJune 30, |  |  |  |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 392.2 |  |  | $ | 392.6 |  |  | $ | (0.4 | ) |  |  | (0.1 | )% |
| Profit |  |  | 35.5 |  |  |  | 35.0 |  |  |  | 0.5 |  |  |  | 1.4 | % |
| % of net sales |  |  | 9.1 | % |  |  | 8.9 | % |  |  |  |  |  |  |  |  |

[0001193125-12-311640:mdna:107]
Net sales were flat in the first half of 2012 compared to the first half of 2011. Unfavorable foreign
currency exchange rates reduced sales by 3%. Excluding the impact from foreign currency, our net sales increased 3%. The increase in sales volume added 2% to sales and price and mix added 1%.

[0001193125-12-311640:mdna:108]
Segment profit was relatively flat when comparing the first six months of 2012 to the same period in 2011. The net sales increase related
to volume and price and mix increases added $5 million to segment profit. Partially offsetting the increase in net sales was $2 million in increased SG&A expense and $3 million of unfavorable foreign currency exchange rates.

[0001193125-12-311640:mdna:109]
Corporate and Other

[0001193125-12-311640:mdna:110]
Corporate and other expenses were $30 million in the first half of 2012, up from $26 million in 2011. The increase was primarily driven by higher incentive compensation expense in 2012 compared to 2011
due to the overall increase in operating performance in the first half of 2012.

[0001193125-12-311640:mdna:111]
[same as prior period, unchanged from 0001193125-12-177598:mdna:62]

[0001193125-12-311640:mdna:112]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and a
revolving period asset securitization arrangement. Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001193125-12-311640:mdna:113]
Statement of Cash Flows

[0001193125-12-311640:mdna:114]
The following table summarizes our cash activity for the six months ended June 30, 2012 and 2011 (in millions):

[0001193125-12-311640:mdna:115]
|  |  | Six Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Net cash used in operating activities |  | $ | (10.6 | ) |  | $ | (142.4 | ) |
| Net cash used in investing activities |  |  | (9.5 | ) |  |  | (153.1 | ) |
| Net cash provided by financing activities |  |  | 44.3 |  |  |  | 207.3 |  |

[0001193125-12-311640:mdna:116]
Net Cash Used in by Operating Activities

[0001193125-12-311640:mdna:117]
Operating activities resulted in a lower use of cash in 2012 compared to 2011. This decreased use was primarily due to lower working capital requirements and an increase in accrued expenses in 2012. Our
working capital requirements resulted in a $129 million use of cash in the first half of 2012 compared to a $155 million use of cash in 2011. The decrease in working capital requirements was primarily related to accounts payable and inventory. As we
prepare for the peak cooling season, we carry higher than average inventory balances in the first and second quarters to meet the summer demand. In addition to the higher than average inventory balances, in the first quarter of 2011 our inventory
increase was greater than what we normally see in this period due to an increased effort to level load our factories. The improved operating performance in the first half of 2012 is the primary reason for the increase in accounts payable and accrued
expenses. The improved operating performance resulted in higher incentive compensation in the first half of 2012 compared to the same period in 2011 in accrued expenses.

[0001193125-12-311640:mdna:118]
[same as prior period, unchanged from 0001193125-12-177598:mdna:69]

[0001193125-12-311640:mdna:119]
Net cash used in investing
activities for the first six months of 2012 included $7.2 million in net proceeds from the sale of the Hearth business. For the first six months of 2011, net cash used in investing activities included $143.3 million for the acquisition of the
Kysor/Warren business from The Manitowoc Company and $4.4 million for the acquisition of a commercial services business in our Service Experts segment.

[0001193125-12-311640:mdna:120]
Capital expenditures in the first half of 2012 were $17 million, which was slightly lower
than the $18 million in the first half of 2011. Capital expenditures in the quarter were primarily related to investments in our distribution network, investments in systems and software to support the overall enterprise and maintenance capital
expenditures.

[0001193125-12-311640:mdna:121]
[same as prior period, unchanged from 0001193125-12-177598:mdna:72]

[0001193125-12-311640:mdna:122]
Net cash provided by financing activities decreased by $163 million in the first six months of 2012 compared to the first six months of 2011. This decrease was primarily related to a decrease in net
borrowings. The net borrowings were higher in the first half of 2011 to support the Kysor/Warren acquisition and the increase in working capital needs in the first half of 2011.

[0001193125-12-311640:mdna:123]
[same as prior period, unchanged from 0001193125-12-177598:mdna:74]

[0001193125-12-311640:mdna:124]
The following table details our lines of credit and financing arrangements as of June 30, 2012 (in millions):

[0001193125-12-311640:mdna:125]
|  |  | MaximumCapacity |  |  | OutstandingBorrowings |  |  | Available forFutureBorrowings |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign Obligations |  | $ | 14.2 |  |  | $ | 14.2 |  |  | $ | — |  |
| Asset Securitization (1) |  |  | 150.0 |  |  |  | — |  |  |  | 150.0 |  |
| Total short-term debt |  | $ | 164.2 |  |  | $ | 14.2 |  |  | $ | 150.0 |  |
| Current Maturities of Long-Term Debt: |  | $ | 0.5 |  |  | $ | 0.5 |  |  | $ | — |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital lease obligations |  | $ | 16.7 |  |  |  | 16.7 |  |  |  | — |  |
| Domestic revolving credit facility (2) |  |  | 650.0 |  |  |  | 297.5 |  |  |  | 294.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |  |  | — |  |
| Total long-term debt |  | $ | 866.7 |  |  | $ | 514.2 |  |  |  | 294.0 |  |
| Total |  | $ | 1,031.4 |  |  | $ | 528.9 |  |  | $ | 444.0 |  |

[0001193125-12-311640:mdna:126]
[same as prior period, unchanged from 0001193125-12-177598:mdna:77]

[0001193125-12-311640:mdna:127]
| (2) | The available future borrowings on our domestic revolving credit facility exclude $58.5 million in standby letters of credit. We had an additional $20.0 million in stand-by letters of credit with other banks. |

[0001193125-12-311640:mdna:128]
As our peak season arrives, we typically pay down debt. We believe
our available future borrowings combined with our cash of $69.1 million and future cash from operations are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, dividends and other needs
in the foreseeable future. Included in our cash and cash equivalents of $69.1 million at June 30, 2012, we had $43.9 million of cash held in foreign locations. Our cash in foreign locations is used for investing and operating activities in
those locations, and we currently do not have the need or intent to repatriate those funds to the United States. If we were to repatriate this cash, we would be required to accrue and to pay taxes in the United States for the amounts that were
repatriated. Our expected capital expenditures are $55 million for 2012.

[0001193125-12-311640:mdna:129]
Our debt-to-total-capital ratio increased to 51.8%
at June 30, 2012 compared to 49.9% at December 31, 2011. The increase in the ratio is due to an increase in the total debt balance at June 30, 2012 primarily related to the seasonal build in inventory to meet peak seasonal demand.

[0001193125-12-311640:mdna:130]
Covenants on our outstanding debt did not change in the second quarter of 2012 and we were in compliance with all of our debt
covenants as of June 30, 2012. For a more detailed discussion of our debt, see Note 7 in the Notes to the Consolidated Financial Statements set forth in Part I, Item I of this Quarterly Report on Form 10-Q.

[0001193125-12-311640:mdna:131]
[same as prior period, unchanged from 0001193125-12-177598:mdna:82]

[0001193125-12-311640:mdna:132]
On March 30, 2012, the parties involved with the asset securitization program
(“ASP”) agreed to remove Lennox Hearth Products LLC from the ASP. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0
million was not modified. We do not believe the removal of Lennox Hearth Products LLC from the ASP will have a significant impact on the available borrowings under the ASP. The eligible amount to borrow under the program as of June 30, 2012 was
$150.0 million.

[0001193125-12-311640:mdna:133]
Dividend payments are expected to be approximately $36 million in 2012. We also continue to increase
shareholder value through our share repurchase program. We are planning a minimum of $50 million in share repurchases in 2012.

[0001193125-12-311640:mdna:134]
Off-Balance
Sheet Arrangements

[0001193125-12-311640:mdna:135]
In addition to the credit facilities and promissory notes described above, we also lease real estate
and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.

[0001193125-12-311640:mdna:136]
Commitments, Contingencies and Guarantees

[0001193125-12-311640:mdna:137]
For a detailed discussion of commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001193125-12-311640:mdna:138]
The estimate of our liability for future warranty costs requires us to make significant assumptions about the amount, timing and nature
of the costs we will incur in the future. We review the assumptions used to determine the liability periodically and we adjust our assumptions based upon factors such as actual failure rates and cost experience. Numerous factors could affect actual
failure rates and cost experience, including the amount and timing of new product introductions, and changes in manufacturing techniques or locations, components or suppliers used. In recent years, changes in the warranty liability as the result of
the issuance of new warranties and the payments made have remained relatively stable. Should actual warranty costs differ from our estimates, we may be required to record adjustments to accruals and expense in the future. At the end of each
accounting period, we evaluate our warranty liabilities and during the second quarter of each year, we perform a complete re-evaluation of our warranty liabilities.

[0001193125-12-311640:mdna:139]
We also may incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products
experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications. We identified product quality issues we
believe resulted from vendor supplied materials: a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in the second quarter of 2012. We recorded $0.7 million for these matters in the second quarter of
2012. As of June 30, 2012, we had $6.5 million accrued for these matters. We may incur additional charges in the future as more information becomes available.

[0001193125-12-311640:mdna:140]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts known. We do not believe that any current, pending or threatened litigation will have a
material adverse effect on our financial position. Litigation, however, involves uncertainties and it is possible that the eventual outcome of litigation could adversely affect our results of operations for a particular period.
