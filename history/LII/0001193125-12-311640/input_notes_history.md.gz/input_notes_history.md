# LII note change history — 0001193125-12-177598 → 0001193125-12-311640


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-07-24):
[0001193125-12-311640:note_history:1]
We use a combination
   of third-party insurance and self-insurance plans (large deductible or captive) to provide protection against claims relating to contingencies such as workers’ compensation, general liability, product liability, property damage, aviation
   liability, directors’ and officers’ liability, auto liability, physical damage and other exposures. Self-insurance expense and liabilities are actuarially determined based on our historical claims information, as well as industry factors
   and trends. Because we have a captive insurance company, we are required to maintain specified levels of liquid assets from which we must pay claims. The majority of our self-insured risks (excluding auto liability and physical damage) will be paid
   over an extended period of time. There have been no material changes in our insurance liability since our latest fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our large deductible or captive insurance
   plans. The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were $62.8 million and $63.3 million as of June 30, 2012 and December 31, 2011, respectively.
  (was, 2012-04-24, similarity 0.9962):
[0001193125-12-177598:note_history:1]
We use a combination
   of third-party insurance and self-insurance plans (large deductible or captive) to provide protection against claims relating to contingencies such as workers’ compensation, general liability, product liability, property damage, aviation
   liability, directors’ and officers’ liability, auto liability, physical damage and other exposures. Self-insurance expense and liabilities are actuarially determined based on our historical claims information, as well as industry factors
   and trends. Because we have a captive insurance company, we are required to maintain specified levels of liquid assets from which we must pay claims. The majority of our self-insured risks (excluding auto liability and physical damage) will be paid
   over an extended period of time. There have been no material changes in our insurance liability since our latest fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our large deductible or captive insurance
   plans. The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were $65.0 million and $63.3 million as of March 31, 2012 and December 31, 2011, respectively.

- changed (2012-07-24):
[0001193125-12-311640:note_history:2]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
| Accrued expenses |  | $ | 27.7 |  |  | $ | 29.4 |  |
| Other liabilities |  |  | 44.2 |  |  |  | 41.8 |  |
|  |  | $ | 71.9 |  |  | $ | 71.2 |  |
  (was, 2012-04-24, similarity 0.9086):
[0001193125-12-177598:note_history:2]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Accrued expenses |  | $ | 28.3 |  |  | $ | 29.4 |  |
| Other liabilities |  |  | 43.4 |  |  |  | 41.8 |  |
|  |  | $ | 71.7 |  |  | $ | 71.2 |  |

- changed (2012-07-24):
[0001193125-12-311640:note_history:3]
The changes in total product warranty liabilities for the first half of 2012 were as follows (in millions):
  (was, 2012-04-24, similarity 0.9573):
[0001193125-12-177598:note_history:3]
The changes in total product warranty liabilities for the first quarter of 2012 were as follows (in millions):

- changed (2012-07-24):
[0001193125-12-311640:note_history:4]
| Total warranty liability as of December 31, 2011 |  | $ | 71.2 |  |
| Payments made in 2012 |  |  | (12.5 | ) |
| Changes resulting from issuance of new warranties |  |  | 14.1 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (0.6 | ) |
| Changes in foreign currency translation rates and other |  |  | (0.3 | ) |
| Total warranty liability as of June 30, 2012 |  | $ | 71.9 |  |
  (was, 2012-04-24, similarity 0.963):
[0001193125-12-177598:note_history:4]
| Total warranty liability as of December 31, 2011 |  | $ | 71.2 |  |
| Payments made in 2012 |  |  | (6.1 | ) |
| Changes resulting from issuance of new warranties |  |  | 6.2 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | 0.1 |  |
| Changes in foreign currency translation rates and other |  |  | 0.3 |  |
| Total warranty liability as of March 31, 2012 |  | $ | 71.7 |  |

- changed (2012-07-24):
[0001193125-12-311640:note_history:5]
At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year,
   we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities. As a result of this re-evaluation, we decreased our warranty liability by $0.4 million.
  (was, 2012-04-24, similarity 0.8448):
[0001193125-12-177598:note_history:5]
At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year,
   we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities.

- added (2012-07-24):
[0001193125-12-311640:note_history:6]
In addition to normal product warranty, we identified product quality issues we believe resulted from vendor supplied materials: a
   heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in the second quarter of 2012. The expense for these product quality issues, and the related liabilities, are not included in the above tables related
   to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the
   Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the first half of 2012 were as follows (in millions):

- changed (2012-07-24):
[0001193125-12-311640:note_history:7]
| Total accrued product quality issue as of December 31, 2011 |  | $ | 7.5 |  |
| Estimated expense for expected product quality claims |  |  | 0.7 |  |
| Product quality claims |  |  | (1.7 | ) |
| Total accrued product quality issue as of June 30, 2012 |  | $ | 6.5 |  |
  (was, 2012-04-24, similarity 0.818):
[0001193125-12-177598:note_history:7]
| Total accrued product quality issue as of December 31, 2011 |  | $ | 7.5 |  |
| Product quality claims |  |  | (1.2 | ) |
| Total accrued product quality issue as of March 31, 2012 |  | $ | 6.3 |  |

- changed (2012-07-24):
[0001193125-12-311640:note_history:8]
Our obligations under the Lake
   Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic
   Revolving Credit Facility. We were in compliance with these financial covenants as of June 30, 2012.
  (was, 2012-04-24, similarity 0.988):
[0001193125-12-177598:note_history:8]
Our obligations under the Lake
   Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic
   Revolving Credit Facility. We were in compliance with these financial covenants as of March 31, 2012.

- removed (2012-07-24):
[0001193125-12-177598:note_history:9]
In addition to normal product warranty, we identified a product quality issue in a heating and cooling product line produced in 2006 and 2007 that we believe resulted from a vendor-supplied materials
   quality issue. The expense for this product quality issue, and the related liability, is not included in the above tables related to our estimated warranty liabilities. The expense related to this product quality issue was classified in Cost of
   Goods Sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in
   the accrued product quality issue for the first quarter of 2012 were as follows (in millions):


## us-gaap:ProductLiabilityContingenciesTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2012-07-24):
[0001193125-12-311640:note_history:10]
| Total accrued product quality issue as of December 31, 2011 |  | $ | 7.5 |  |
| Estimated expense for expected product quality claims |  |  | 0.7 |  |
| Product quality claims |  |  | (1.7 | ) |
| Total accrued product quality issue as of June 30, 2012 |  | $ | 6.5 |  |


## lii:BasisOfPresentationPolicyTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2012-07-24):
[0001193125-12-177598:note_history:11]
Basis of Presentation

- removed (2012-07-24):
[0001193125-12-177598:note_history:12]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2012, the accompanying unaudited Consolidated Statements of
   Operations for the three months ended March 31, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2012 and 2011, and the accompanying unaudited Consolidated Statements of Cash
   Flows for the three months ended March 31, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2011. The
   accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of
   Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash
   flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures
   herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- removed (2012-07-24):
[0001193125-12-177598:note_history:13]
Our fiscal year ends on December 31 and our quarters are each comprised of 13 weeks. For convenience, throughout these financial
   statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-07-24):
[0001193125-12-311640:note_history:14]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2012, the accompanying unaudited Consolidated Statements of
   Operations for the three and six months ended June 30, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2012 and 2011, and the accompanying unaudited Consolidated
   Statements of Cash Flows for the six months ended June 30, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended
   December 31, 2011. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to
   Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position,
   results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we
   believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2012-04-24, similarity 0.9533):
[0001193125-12-177598:note_history:14]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2012, the accompanying unaudited Consolidated Statements of
   Operations for the three months ended March 31, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2012 and 2011, and the accompanying unaudited Consolidated Statements of Cash
   Flows for the three months ended March 31, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2011. The
   accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of
   Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash
   flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures
   herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2012-07-24):
[0001193125-12-311640:note_history:15]
Our fiscal year ends on December 31 and each of our quarters are comprised of 13 weeks. For convenience, throughout these financial
   statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.
  (was, 2012-04-24, similarity 0.9738):
[0001193125-12-177598:note_history:15]
Our fiscal year ends on December 31 and our quarters are each comprised of 13 weeks. For convenience, throughout these financial
   statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.

- removed (2012-07-24):
[0001193125-12-177598:note_history:16]
New Accounting Pronouncements

- removed (2012-07-24):
[0001193125-12-177598:note_history:17]
In June 2011, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”)
   No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income (“ASU 2011-05”). This ASU eliminates the option to present the components of other comprehensive income as part of the statement of
   stockholders’ equity. Rather, it gives an entity the choice to present the components of net income and other comprehensive income in either a single continuous statement or two separate but consecutive statements. The components of
   comprehensive income and timing of reclassification of an item to net income do not change with this update. ASU 2011-05 requires retrospective application and is effective for annual and interim periods beginning after December 15, 2011. We adopted this ASU in the
   first quarter of 2012 and have presented separate Consolidated Statements of Comprehensive Income.

- removed (2012-07-24):
[0001193125-12-177598:note_history:18]
In September 2011, the FASB issued ASU No. 2011-08, Intangibles – Goodwill and Other (Topic 350):Testing
   Goodwill for Impairment (“ASU 2011-08”) related to goodwill impairment guidance. This ASU gives an option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that
   it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If after assessing all events and circumstances, an entity determines it is not more likely than not that the fair value of a reporting unit is less
   than its carrying amount, the performance of the two-step impairment test is unnecessary. The effective date is for fiscal years beginning after December 15, 2011. We adopted this ASU in the first quarter of 2012. See Note 3 for the results of
   our annual goodwill impairment test.

- removed (2012-07-24):
[0001193125-12-177598:note_history:19]
In December 2011, the FASB issued ASU No. 2011-12, Comprehensive Income
   (Topic 220): Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update No. 2011-05. This ASU defers including the
   reclassification adjustments in the income statement but does not defer reclassification adjustments in other comprehensive income. We have included the reclassification adjustments in other comprehensive income in the Consolidated Statements of
   Comprehensive Income as allowed in this ASU.


## lii:DebtAndCapitalLeasesDisclosuresTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2012-07-24):
[0001193125-12-177598:note_history:20]
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 11.4 |  |  | $ | 4.7 |  |
| Total short-term debt |  | $ | 11.4 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: |  | $ | 0.6 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.5 |  |  |  | 16.6 |  |
| Domestic revolving credit facility |  |  | 295.0 |  |  |  | 243.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 511.5 |  |  | $ | 459.6 |  |
| Total debt |  | $ | 523.5 |  |  | $ | 465.1 |  |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-07-24):
[0001193125-12-311640:note_history:21]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Weighted average borrowing rate |  |  | 1.49 | % |  |  | 1.53 | % |
  (was, 2012-04-24, similarity 0.9573):
[0001193125-12-177598:note_history:21]
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Weighted average borrowing rate |  |  | 1.49 | % |  |  | 1.53 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2012-07-24):
[0001193125-12-311640:note_history:22]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Total short-term debt |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: |  | $ | 0.5 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.7 |  |  |  | 16.6 |  |
| Domestic revolving credit facility |  |  | 297.5 |  |  |  | 243.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 514.2 |  |  | $ | 459.6 |  |
| Total debt |  | $ | 528.9 |  |  | $ | 465.1 |  |

- changed (2012-07-24):
[0001193125-12-311640:note_history:23]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs
   for our foreign locations. We had $14.2 million and $4.7 million of foreign obligations as of June 30, 2012 and December 31, 2011, respectively.
  (was, 2012-04-24, similarity 0.983):
[0001193125-12-177598:note_history:23]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs
   for our foreign locations. We had $11.4 million and $4.7 million of foreign obligations as of March 31, 2012 and December 31, 2011, respectively.

- changed (2012-07-24):
[0001193125-12-311640:note_history:24]
Under the Receivables Purchase Agreement, or
   Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to renewal and contains a provision
   whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. The
   sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying
   Consolidated Statements of Cash Flows. The ASP provides for a maximum securitization amount of the lesser of $150.0 million or 100% of the net pool balance as defined by the ASP. However, eligibility for securitization is limited based on the amount
   and quality of the qualifying accounts receivable and is calculated monthly. On March 30, 2012, the parties involved with this securitization program agreed to remove Lennox Hearth Products LLC from the program. Any receivables originated by
   Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. The eligible amounts available and beneficial interests sold were as follows (in
   millions):
  (was, 2012-04-24, similarity 0.9041):
[0001193125-12-177598:note_history:24]
Under a Receivables Purchase Agreement (“RPA”), we are eligible to sell beneficial interests in a portion of our
   trade accounts receivable to participating financial institutions for cash. The RPA is subject to renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued
   involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the
   accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. The RPA provides for a maximum securitization amount of $150.0 million or
   100% of the net pool balance as defined by the RPA. However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The beneficial interest sold cannot exceed the
   maximum amount even if our qualifying accounts receivable is greater than the maximum amount at any point in time. On March 30, 2012, the parties involved with this securitization program agreed to remove Lennox Hearth Products LLC from the
   program. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. The eligible amounts available and beneficial
   interests sold were as follows (in millions):

- changed (2012-07-24):
[0001193125-12-311640:note_history:25]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
| Eligible amount available under the ASP on qualified accounts receivable |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 150.0 |  |  | $ | 150.0 |  |
  (was, 2012-04-24, similarity 0.8478):
[0001193125-12-177598:note_history:25]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Eligible amount available under the RPA on qualified accounts receivable |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 150.0 |  |  | $ | 150.0 |  |

- changed (2012-07-24):
[0001193125-12-311640:note_history:26]
Under the ASP, we pay certain discount fees to use the program and have the facility available to us. These fees relate
   to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee
   of 0.60%. The average rate for June 30, 2012 was 0.86% and the average rate at December 31, 2011 was 0.91%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed
   rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP recorded was as follows (in millions):
  (was, 2012-04-24, similarity 0.9874):
[0001193125-12-177598:note_history:26]
Under the RPA, we pay certain discount fees to use the program and have the facility available to us. These fees relate
   to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee
   of 0.60%. The average rate for March 31, 2012 was 0.85% and the average rate at December 31, 2011 was 0.91%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed
   rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the RPA recorded was as follows (in millions):

- changed (2012-07-24):
[0001193125-12-311640:note_history:27]
|  |  | For the Three Months Ended June 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Interest expense (including fees) |  | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.6 |  |  | $ | 0.2 |  |
  (was, 2012-04-24, similarity 0.7378):
[0001193125-12-177598:note_history:27]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2012 |  |  | 2011 |  |
| Interest expense (including fees) |  | $ | 0.3 |  |  | $ | 0.1 |  |

- changed (2012-07-24):
[0001193125-12-311640:note_history:28]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default
   provisions with our Domestic Revolving Credit Facility and senior unsecured notes. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade
   credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the ASP. As of June 30, 2012, we were in compliance with all covenant requirements.
  (was, 2012-04-24, similarity 0.976):
[0001193125-12-177598:note_history:28]
The RPA contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default
   provisions with our Domestic Revolving Credit Facility and senior unsecured notes. The administrative agent under the RPA is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade
   credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the RPA. As of March 31, 2012, we were in compliance with all covenant requirements.

- added (2012-07-24):
[0001193125-12-311640:note_history:29]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of
   $297.5 million and $58.5 million committed to standby letters of credit as of June 30, 2012. Subject to covenant limitations, $294.0 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of
   letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of
   $100 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2012-07-24):
[0001193125-12-311640:note_history:30]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Weighted average borrowing rate |  |  | 1.49 | % |  |  | 1.53 | % |
  (was, 2012-04-24, similarity 0.9573):
[0001193125-12-177598:note_history:30]
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Weighted average borrowing rate |  |  | 1.49 | % |  |  | 1.53 | % |

- changed (2012-07-24):
[0001193125-12-311640:note_history:31]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross
   default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or
   lease commitment.
  (was, 2012-04-24, similarity 0.995):
[0001193125-12-177598:note_history:31]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross
   default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, or our RPA were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or
   lease commitment.

- changed (2012-07-24):
[0001193125-12-311640:note_history:32]
If any event of
   default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic
   Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of June 30, 2012, we were in
   compliance with all covenant requirements.
  (was, 2012-04-24, similarity 0.9915):
[0001193125-12-177598:note_history:32]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may
   require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such
   amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2012, we were in compliance with all covenant requirements.

- changed (2012-07-24):
[0001193125-12-311640:note_history:33]
The notes are
   guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other
   things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our
   assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded
   within 30 days of the notice date. As of June 30, 2012, we were in compliance with all covenant requirements.
  (was, 2012-04-24, similarity 0.9947):
[0001193125-12-177598:note_history:33]
The notes are
   guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other
   things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our
   assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded
   within 30 days of the notice date. As of March 31, 2012, we were in compliance with all covenant requirements.

- removed (2012-07-24):
[0001193125-12-177598:note_history:34]
|  |  | As of March 31,2012 |  |  | As of December 31,2011 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 11.4 |  |  | $ | 4.7 |  |
| Total short-term debt |  | $ | 11.4 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: |  | $ | 0.6 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.5 |  |  |  | 16.6 |  |
| Domestic revolving credit facility |  |  | 295.0 |  |  |  | 243.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 511.5 |  |  | $ | 459.6 |  |
| Total debt |  | $ | 523.5 |  |  | $ | 465.1 |  |

- removed (2012-07-24):
[0001193125-12-177598:note_history:35]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of
   $295.0 million and $78.5 million committed to standby letters of credit as of March 31, 2012. Subject to covenant limitations, $276.5 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of
   letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of
   $100 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2012-07-24):
[0001193125-12-311640:note_history:36]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Total short-term debt |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: |  | $ | 0.5 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.7 |  |  |  | 16.6 |  |
| Domestic revolving credit facility |  |  | 297.5 |  |  |  | 243.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 514.2 |  |  | $ | 459.6 |  |
| Total debt |  | $ | 528.9 |  |  | $ | 465.1 |  |
