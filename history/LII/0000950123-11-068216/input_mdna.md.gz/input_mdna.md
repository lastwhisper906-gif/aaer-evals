# LII MD&A — 0000950123-11-068216


## mdna

[0000950123-11-068216:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.

[0000950123-11-068216:mdna:2]
[same as prior period, unchanged from 0000950123-11-039069:mdna:2]

[0000950123-11-068216:mdna:3]
We operate in four reportable business segments of the heating, ventilation, air conditioning
and refrigeration (‘HVACR’) industry. Our reportable segments consist of Residential Heating &
Cooling, Commercial Heating & Cooling, Service Experts and Refrigeration. For more detailed
information regarding our reportable segments, see Note 14 in the Notes to our Consolidated
Financial Statements.

[0000950123-11-068216:mdna:4]
Our fiscal year ends on December 31 and our interim fiscal quarters are each comprised of 13
weeks. For convenience, throughout this Management’s Discussion and Analysis of Financial
Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted
by the last day of the calendar quarter.

[0000950123-11-068216:mdna:5]
Our products and services are sold through a combination of distributors, independent and
company-owned dealer service centers, other installing contractors, wholesalers, manufacturers’
representatives, original equipment manufacturers and directly to national accounts. The demand for
our products and services is seasonal and dependent on the weather. Warmer than normal summer
temperatures generate strong demand for replacement air conditioning and refrigeration products and
services and colder than normal winter temperatures have the same effect on heating products and
services. Conversely, cooler than normal summers and warmer than normal winters depress the demand
for HVACR products and services. In addition to weather, demand for our products and services is
influenced by national and regional economic and demographic factors, such as interest rates, the
availability of financing, regional population and employment trends, new construction, general
economic conditions and consumer spending habits and confidence.

[0000950123-11-068216:mdna:6]
The principal elements of cost of goods sold in our manufacturing operations are components,
raw materials, factory overhead, labor and estimated costs of warranty expense. The principal raw
materials used in our manufacturing processes are steel, copper and aluminum. In recent years,
increased prices for these commodities and related components have challenged us and the HVACR
industry in general. We seek to mitigate the impact of higher commodity prices through a
combination of price increases for our products and services, commodity contracts, improved
production efficiency and cost reduction initiatives. We also seek to mitigate volatility in the
prices of these commodities by entering into futures contracts and fixed forward contracts. In our
Service Experts segment, the principal components of cost of goods sold are equipment, parts and
supplies and labor.

[0000950123-11-068216:mdna:7]
[same as prior period, unchanged from 0000950123-11-039069:mdna:6]

[0000950123-11-068216:mdna:8]
The second quarter of the fiscal year is the beginning of summer, typically one of our most
profitable quarters. However, our Residential Heating & Cooling and Service Experts businesses
were weaker than the second quarter of 2010 due to consumer weakness, product mix due to the
significant reduction in the federal tax credit and cooler temperatures in key regions during the
current quarter. In 2010, the government had a $1,500 tax credit for high-efficiency heating and
cooling products compared to a $500 tax credit in 2011. In 2010 we

[0000950123-11-068216:mdna:9]
saw a number of full system replacements encouraged by the 2010 tax credit; whereas, in 2011
we are seeing replacement of components, rather than entire systems. Our Commercial Heating &
Cooling and Refrigeration Businesses performed well in the second quarter of 2011 compared to 2010.
Our Commercial Heating & Cooling business showed strong growth in the quarter with almost 13%
revenue growth, largely driven by volume. The Refrigeration segment also showed strong growth with
a 56% increase in net sales for the quarter. The increase in net sales for this segment was
comprised of organic growth of 4%, excluding a 9% impact of foreign currency exchange rates, with
the remainder of the growth from the acquisition of the Kysor/Warren business in January 2011.

[0000950123-11-068216:mdna:10]
We are seeing margin pressure in all of our segments largely driven by commodity prices
putting a strain on raw material and component costs. Margins were also negatively affected by mix
from our Residential Heating & Cooling Segment. We are managing our pricing structure to offset a
large portion of our commodity price increases on raw materials and
components. We believe we are managing our
other costs well and continue to look for ways to lower our controllable cost structure through
manufacturing and sourcing excellence.

[0000950123-11-068216:mdna:11]
[same as prior period, unchanged from 0000950123-11-039069:mdna:9]

[0000950123-11-068216:mdna:12]
|  | • |  | Net sales for the second quarter of 2011 increased to $937 million as compared to $872 million in 2010, or a 7% increase. The Kysor/Warren acquisition contributed 6% to the net sales growth and favorable currency exchange rates positively impacted our growth by 3%. We had a slight decline in overall net sales of 2% for LII excluding Kysor/Warren and currency impact. |
|  | • |  | Operational income for the second quarter of 2011 decreased to $73 million as compared to $79 million in 2010. The decline in operational income was primarily due to lower volume and lower margins from commodity headwinds. |
|  | • |  | Net income for the second quarter of 2011 was $45 million compared to $48 million in 2010. Diluted earnings per share from continuing operations were $0.83 in the second quarter of 2011 compared to diluted earnings per share from continuing operations of $0.86 in 2010. |
|  | • |  | Cash of $142 million was used in operating activities for the first half of 2011 compared to cash used in operating activities of $26 million in the first half of 2010. Cash used in operating activities was higher primarily due to higher working capital and higher incentive payouts in the first six months of 2011 compared to the first six months of 2010. |
|  | • |  | During the first half of 2011, we returned $53 million to shareholders through share repurchases and dividends. |

[0000950123-11-068216:mdna:13]
30

[0000950123-11-068216:mdna:14]
Second Quarter of 2011 Compared to Second Quarter of 2010 — Consolidated Results

[0000950123-11-068216:mdna:15]
[same as prior period, unchanged from 0000950123-11-039069:mdna:11]

[0000950123-11-068216:mdna:16]
[same as prior period, unchanged from 0000950123-11-039069:mdna:12]

[0000950123-11-068216:mdna:17]
|  |  | Three Months Ended June 30, |  |
|  |  |  |  |  |  |  |  |  |  | Percent |  |  |  |  |
|  |  | Dollars |  |  | Change |  |  | Percent Sales |  |
|  |  | 2011 |  |  | 2010 |  |  | Fav/(Unfav) |  |  | 2011 |  |  | 2010 |  |
| Net sales |  | $ | 937.0 |  |  | $ | 872.1 |  |  |  | 7.4 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 689.4 |  |  |  | 607.4 |  |  |  | (13.5 | ) |  |  | 73.6 |  |  |  | 69.6 |  |
| Gross profit |  |  | 247.6 |  |  |  | 264.7 |  |  |  | (6.5 | ) |  |  | 26.4 |  |  |  | 30.4 |  |
| Selling, general and administrative expenses |  |  | 175.2 |  |  |  | 180.5 |  |  |  | 2.9 |  |  |  | 18.7 |  |  |  | 20.7 |  |
| Losses and other expenses, net |  |  | 0.9 |  |  |  | 5.8 |  |  |  | 84.5 |  |  |  | 0.1 |  |  |  | 0.7 |  |
| Restructuring charges |  |  | 2.4 |  |  |  | 3.2 |  |  |  | 25.0 |  |  |  | 0.3 |  |  |  | 0.4 |  |
| Income from equity method investments |  |  | (3.4 | ) |  |  | (4.1 | ) |  |  | (17.1 | ) |  |  | (0.4 | ) |  |  | (0.5 | ) |
| Operational income |  | $ | 72.5 |  |  | $ | 79.3 |  |  |  | (8.6 | )% |  |  | 7.7 | % |  |  | 9.1 | % |
| Net income |  | $ | 45.0 |  |  | $ | 48.3 |  |  |  | (6.8 | )% |  |  | 4.8 | % |  |  | 5.5 | % |

[0000950123-11-068216:mdna:18]
[same as prior period, unchanged from 0000950123-11-039069:mdna:15]

[0000950123-11-068216:mdna:19]
Net sales increased 7% in the second quarter of 2011 compared to the second quarter of 2010.
The Kysor/Warren acquisition added 6% to our net sales. Our price and mix were up 1% while sales
volume was down 3% in the comparable period. The decline in volume was predominantly in our
Residential Heating & Cooling and Service Experts segments partially offset by volume growth in our
Commercial Heating & Cooling and Refrigeration segments. Changes in foreign currency exchange
rates favorably impacted net sales by 3%. Excluding the impact from the Kysor/Warren acquisition
and favorable foreign currency exchange rates, net sales in the second quarter of 2011 were down 2%
from the second quarter of 2010.

[0000950123-11-068216:mdna:20]
[same as prior period, unchanged from 0000950123-11-039069:mdna:17]

[0000950123-11-068216:mdna:21]
Gross profit margins declined 400 basis points to 26% for the second quarter of 2011 when
compared to gross profit margins of 30% in 2010. Commodity headwinds contributed approximately 155
basis points to the decline which was partially offset by improved price and mix of 80 basis
points. In addition, gross profit margins were negatively impacted by 120 basis points from
non-commodity costs changes and freight and distribution costs and 50
basis points from unfavorable
foreign currency translation rates. Comparisons were also negatively impacted by 50 basis points
from a less favorable warranty adjustment in the second quarter of 2011 compared to 2010.

[0000950123-11-068216:mdna:22]
[same as prior period, unchanged from 0000950123-11-039069:mdna:19]

[0000950123-11-068216:mdna:23]
Selling, general and administrative (“SG&A”) expenses decreased by $5 million in the second
quarter of 2011 compared to 2010; and as a percentage of net sales, SG&A expenses declined to 19%
in 2011 from 21% in 2010. The decline in SG&A expenses was principally due to an $11 million
decline in 2011 incentive compensation expense largely offset from Kysor/Warren SG&A expenses
included in 2011.

[0000950123-11-068216:mdna:24]
Losses and Other Expenses, Net

[0000950123-11-068216:mdna:25]
Losses and other expenses, net for the second quarters of 2011 and 2010 included the following
(in millions):

[0000950123-11-068216:mdna:26]
|  |  | Three Months Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Realized gains on settled futures contracts |  | $ | (0.4 | ) |  | $ | (0.4 | ) |
| Unrealized loss on unsettled futures contracts not designated as cash flow hedges |  |  | 0.7 |  |  |  | 1.3 |  |
| Special legal contingency charge |  |  | (0.2 | ) |  |  | 4.5 |  |
| Foreign currency exchange losses |  |  | 0.4 |  |  |  | 0.1 |  |
| Other items, net |  |  | 0.4 |  |  |  | 0.3 |  |
| Losses and other expenses, net |  | $ | 0.9 |  |  | $ | 5.8 |  |

[0000950123-11-068216:mdna:27]
The change in losses and other expenses, net is primarily due to the special legal contingency
charge related to the class action lawsuit that concluded in the second quarter of 2011. Refer to
Part II, Item 1 “Legal Proceedings” and Note 7 in the Notes to the Consolidated Financial
Statements for more information.

[0000950123-11-068216:mdna:28]
[same as prior period, unchanged from 0000950123-11-039069:mdna:25]

[0000950123-11-068216:mdna:29]
Restructuring charges declined from $3 million in the second quarter of 2010 to $2 million in
the second quarter of 2011. As we didn’t initiate any new large projects in the second quarter of
2011, the charges in this period related to minor charges from various open projects initiated in
prior years, principally the reorganization of the Service Experts administrative functions and
management structure. The restructuring charges from the second quarter of 2010 were primarily
related to the consolidation of certain Refrigeration manufacturing operations from Parets, Spain
into Genas, France. The remaining restructuring charges from the second quarter of 2010 were minor
charges from various open projects initiated in 2010 and prior years.

[0000950123-11-068216:mdna:30]
[same as prior period, unchanged from 0000950123-11-039069:mdna:27]

[0000950123-11-068216:mdna:31]
Investments over which we do not exercise control but have significant influence are accounted
for using the equity method of accounting. Income from equity method investments decreased to $3
million in the second quarter of 2011 from $4 million in 2010, primarily from a slight decline in
performance from our compressor manufacturing joint venture.

[0000950123-11-068216:mdna:32]
[same as prior period, unchanged from 0000950123-11-039069:mdna:29]

[0000950123-11-068216:mdna:33]
Interest expense, net, increased to $4 million in 2011 from $3 million in 2010. The increase
in interest expense was primarily attributable to the increase in average amounts borrowed in the
second quarter of 2011 compared to 2010 and an increase in our weighted average interest rate
in the comparable period.

[0000950123-11-068216:mdna:34]
Income Tax Expense

[0000950123-11-068216:mdna:35]
Income tax expense was $23 million in the second quarter of 2011 compared $27 million in 2010.
The effective tax rate was 34% for 2011 and 36% in 2010. Our effective rates differ from the
statutory federal rate of 35% for certain items, such as state and local taxes, non-deductible
expenses, foreign operating losses for which no tax benefits have been recognized and foreign taxes
at rates other than 35%.

[0000950123-11-068216:mdna:36]
Second Quarter of 2011 Compared to Second Quarter of 2010 — Results by Segment

[0000950123-11-068216:mdna:37]
[same as prior period, unchanged from 0000950123-11-039069:mdna:34]

[0000950123-11-068216:mdna:38]
The following table summarizes our Residential Heating & Cooling segment’s net sales and
profit for the second quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-068216:mdna:39]
|  |  | Three Months Ended |  |  |  |  |
|  |  | June 30, |  |  |  |  |
|  |  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales |  | $ | 395.1 |  |  | $ | 413.4 |  |  | $ | (18.3 | ) |  |  | (4.4 | )% |
| Profit |  |  | 33.2 |  |  |  | 52.5 |  |  |  | (19.3 | ) |  |  | (36.8 | )% |
| % of net sales |  |  | 8.4 | % |  |  | 12.7 | % |  |  |  |  |  |  |  |  |

[0000950123-11-068216:mdna:40]
Residential Heating & Cooling net sales declined by 4% in the second quarter of 2011 compared
to the second quarter of 2010. Sales volumes declined by almost 5% with price and mix flat in 2011
as compared to 2010. Partially offsetting the decline in sales volume was a favorable impact from
foreign currency exchange rates of 1%. The decline in sales volumes was due to consumer weakness,
the reduction of $1,500 tax credit in 2010 to $500 in 2011, and cooler weather.

[0000950123-11-068216:mdna:41]
Segment profit decreased $19 million, including $9 million from a decline in volume and $8
million from commodity headwinds. Comparisons were also adversely affected by a less favorable
warranty adjustment, $2 million in 2011 versus $4 million in 2010. An increase in freight and
distribution charges of $4 million also added to the decline in segment profit in the comparable
period. Partially offsetting this decline was a $1 million
increase in price and mix.
Additionally, a
  decrease
in SG&A expense in 2011 by $5 million
partially offset the decline in segment profit
 due to lower  incentive compensation expense and
advertising expenses in 2011.

[0000950123-11-068216:mdna:42]
[same as prior period, unchanged from 0000950123-11-039069:mdna:39]

[0000950123-11-068216:mdna:43]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit
for the second quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-068216:mdna:44]
|  |  | Three Months Ended |  |  |  |  |
|  |  | June 30, |  |  |  |  |
|  |  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales |  | $ | 198.3 |  |  | $ | 175.8 |  |  | $ | 22.5 |  |  |  | 12.8 | % |
| Profit |  |  | 27.1 |  |  |  | 27.8 |  |  |  | (0.7 | ) |  |  | (2.5 | )% |
| % of net sales |  |  | 13.7 | % |  |  | 15.8 | % |  |  |  |  |  |  |  |  |

[0000950123-11-068216:mdna:45]
Our Commercial Heating & Cooling business experienced a 13% increase in net sales in the
second quarter of 2011 compared to 2010 primarily due to an increase in our replacement business
which resulted in a 6% increase in sales volume and a 3% increase in price and mix. Changes in
foreign currency exchange rates favorably impacted sales by 4%.

[0000950123-11-068216:mdna:46]
Segment profit for the second quarter of 2011 was relatively flat when compared to the second
quarter of 2010. Segment profit increased from the impact of higher net sales of $5 million and
favorable foreign currency exchange rates of $1 million. Offsetting our higher sales were
commodity headwinds of $4 million and a less favorable warranty adjustment in 2011 versus 2010 of
$1 million.

[0000950123-11-068216:mdna:47]
[same as prior period, unchanged from 0000950123-11-039069:mdna:44]

[0000950123-11-068216:mdna:48]
The following table summarizes our Service Experts segment’s net sales and profit for the
second quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-068216:mdna:49]
|  |  | Three Months Ended |  |  |  |  |
|  |  | June 30, |  |  |  |  |
|  |  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales |  | $ | 145.4 |  |  | $ | 167.6 |  |  | $ | (22.2 | ) |  |  | (13.2 | )% |
| Profit |  |  | 3.2 |  |  |  | 12.8 |  |  |  | (9.6 | ) |  |  | (75.0 | )% |
| % of net sales |  |  | 2.2 | % |  |  | 7.6 | % |  |  |  |  |  |  |  |  |

[0000950123-11-068216:mdna:50]
In total, sales volumes declined 14%. Foreign currency exchange rates increased net sales by
1%. The decline in this segment’s sales volume is primarily due to the decline in residential HVAC
equipment installations.

[0000950123-11-068216:mdna:51]
Segment profit decreased $10 million due to the impact of the volume decline in net sales.

[0000950123-11-068216:mdna:52]
[same as prior period, unchanged from 0000950123-11-039069:mdna:49]

[0000950123-11-068216:mdna:53]
The following table summarizes our Refrigeration segment’s net sales and profit for the second
quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-068216:mdna:54]
|  |  | Three Months Ended |  |  |  |  |
|  |  | June 30, |  |  |  |  |
|  |  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales |  | $ | 217.5 |  |  | $ | 139.8 |  |  | $ | 77.7 |  |  |  | 55.6 | % |
| Profit |  |  | 21.4 |  |  |  | 15.3 |  |  |  | 6.1 |  |  |  | 39.9 | % |
| % of net sales |  |  | 9.8 | % |  |  | 10.9 | % |  |  |  |  |  |  |  |  |

[0000950123-11-068216:mdna:55]
Net sales, excluding Kysor/Warren and foreign currency impact, increased 4% in the second
quarter of 2011 when compared to 2010 due to 1% increase in sales volume and a 3% increase in price
and mix. Favorable foreign exchange rates accounted for 9% of the increase in net sales and the
Kysor/Warren acquisition contributed 43% to the increase in net sales.

[0000950123-11-068216:mdna:56]
Segment profit increased $6 million primarily due to a $6 million increase in our price and
mix. We also had a favorable change in SG&A expenses which contributed $2 million to the segment
profit increase. Offsetting these increases were commodity headwinds of $3 million.

[0000950123-11-068216:mdna:57]
[same as prior period, unchanged from 0000950123-11-039069:mdna:54]

[0000950123-11-068216:mdna:58]
Corporate and other expenses were $12 million in the second quarter of 2011, down from $20
million in 2010. The decrease was primarily driven by lower incentive compensation expense in 2011
compared to 2010 as well as general expense control and productivity.

[0000950123-11-068216:mdna:59]
Year-to-Date through June 30, 2011 Compared to Year-to-Date through June 30, 2010 — Consolidated
Results

[0000950123-11-068216:mdna:60]
Results of Operations

[0000950123-11-068216:mdna:61]
The following table provides a summary of our financial results, including information
presented as a percentage of net sales (dollars in millions):

[0000950123-11-068216:mdna:62]
|  |  | Six Months Ended June 30, |  |
|  |  |  |  |  |  |  |  |  |  | Percent |  |  |  |  |
|  |  | Dollars |  |  | Change |  |  | Percent Sales |  |
|  |  | 2011 |  |  | 2010 |  |  | Fav/(Unfav) |  |  | 2011 |  |  | 2010 |  |
| Net sales |  | $ | 1,624.7 |  |  | $ | 1,516.2 |  |  |  | 7.2 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 1,212.0 |  |  |  | 1,077.1 |  |  |  | (12.5 | ) |  |  | 74.6 |  |  |  | 71.0 |  |
| Gross profit |  |  | 412.7 |  |  |  | 439.1 |  |  |  | (6.0 | ) |  |  | 25.4 |  |  |  | 29.0 |  |
| Selling, general and administrative expenses |  |  | 348.9 |  |  |  | 349.6 |  |  |  | 0.2 |  |  |  | 21.5 |  |  |  | 23.1 |  |
| Losses and other expenses, net |  |  | 0.6 |  |  |  | 5.5 |  |  |  | 89.1 |  |  |  | — |  |  |  | 0.4 |  |
| Restructuring charges |  |  | 3.6 |  |  |  | 10.3 |  |  |  | 65.0 |  |  |  | 0.2 |  |  |  | 0.7 |  |
| Income from equity method investments |  |  | (5.9 | ) |  |  | (6.1 | ) |  |  | (3.3 | ) |  |  | (0.4 | ) |  |  | (0.4 | ) |
| Operational income |  | $ | 65.5 |  |  | $ | 79.8 |  |  |  | (17.9 | )% |  |  | 4.1 | % |  |  | 5.2 | % |
| Net income |  | $ | 37.8 |  |  | $ | 46.7 |  |  |  | (19.1 | )% |  |  | 2.3 | % |  |  | 3.1 | % |

[0000950123-11-068216:mdna:63]
Net Sales

[0000950123-11-068216:mdna:64]
Net sales increased 7% in the first half of 2011 compared to the first half of 2010. The
Kysor/Warren acquisition added 6% to our net sales. Our price and mix were up 2% while sales
volume was down 3% in the comparable period. The decline in volume was predominantly in our
residential segment partially offset by volume growth in our commercial and refrigeration segments.
Changes in foreign currency exchange rates favorably impacted net sales by 2%. Excluding the
favorable impact from the Kysor/Warren acquisition and foreign currency exchange rates, our net
sales for the first half were down 1%.

[0000950123-11-068216:mdna:65]
Gross Profit

[0000950123-11-068216:mdna:66]
Gross profit margins declined approximately 360 basis points to 25% for the first half of 2011
compared to gross profit margins of 29% in 2010. Commodity headwinds contributed approximately 165
basis points to the decline which was partially offset by improved price and mix of 90 basis
points. Contributing to the decline in

[0000950123-11-068216:mdna:67]
gross profit margins were non-commodity cost changes and freight and distribution costs of 145
basis points and foreign currency translation rates of 35 basis points. Additionally, comparisons
were negatively impacted by 25 basis points from a less favorable warranty adjustment in the second
quarter of 2011 compared to 2010. Along with our improved price and mix, productivity improvement
initiatives partially offset the declines in gross margin by 65 basis points.

[0000950123-11-068216:mdna:68]
Selling, General and Administrative Expenses

[0000950123-11-068216:mdna:69]
SG&A expenses decreased by $1 million in the first half of 2011 compared to 2010, and as a
percentage of net sales, SG&A expenses declined to 22% in 2011 from 23% in 2010. The decline in
SG&A expenses was principally due to a $10 million decline in 2011 incentive compensation expense.
Additionally, bad debt expense declined almost $2 million in the quarter. These declines were
partially offset by Kysor/Warren SG&A expenses included in 2011.

[0000950123-11-068216:mdna:70]
Losses and Other Expenses, Net

[0000950123-11-068216:mdna:71]
Losses and other expenses, net included the following (in millions):

[0000950123-11-068216:mdna:72]
|  |  | Six Months Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Realized gains losses on settled futures contracts |  | $ | (1.0 | ) |  | $ | (0.8 | ) |
| Unrealized loss on unsettled futures contracts not designated as cash flow hedges |  |  | 1.5 |  |  |  | 1.3 |  |
| Special legal contingency charge |  |  | (0.2 | ) |  |  | 4.5 |  |
| Foreign currency exchange loss (gains) |  |  | 0.5 |  |  |  | — |  |
| Other items, net |  |  | (0.2 | ) |  |  | 0.5 |  |
| Losses and other expenses, net |  | $ | 0.6 |  |  | $ | 5.5 |  |

[0000950123-11-068216:mdna:73]
The change in losses and other expenses, net is primarily due to the special legal contingency
charge related to the class action lawsuit that concluded in the second quarter of 2011. refer to
Part II, Item 1 “Legal Proceedings” and Note 7 in the Notes to the Consolidated Financial
Statements for more information.

[0000950123-11-068216:mdna:74]
Restructuring Charges

[0000950123-11-068216:mdna:75]
Restructuring charges declined from $10 million in first six months of 2010 to almost $4
million in the first six months of 2011. As we didn’t initiate any new large projects in the first
half of 2011, the charges in this period primarily related to minor charges from various open
projects initiated in prior years, principally the reorganization of the Service Experts
administrative functions and management structure and the exit of coil manufacturing in
Milperra, Australia. The restructuring charges from the first half of 2010 were primarily related
to the exit of coil manufacturing in Milperra, Australia and consolidation of certain Refrigeration
manufacturing operations from Parets, Spain into Genas, France. The remaining restructuring
charges from the second quarter of 2010 were minor charges from various open projects initiated in
2010 and prior years.

[0000950123-11-068216:mdna:76]
Results from Equity Method and Other Equity Investments

[0000950123-11-068216:mdna:77]
Investments over which we do not exercise control but have significant influence are accounted
for using the equity method of accounting. Income from equity method investments decreased to $5.9
million in the second half of 2011 from $6.1 million in 2010, primarily from a slight decline in
performance from our compressor manufacturing joint venture.

[0000950123-11-068216:mdna:78]
Interest Expense, Net

[0000950123-11-068216:mdna:79]
Interest expense, net, increased to $8 million in the first six months of 2011 from $6 million
in the same period in 2010. The increase in interest expense was primarily attributable to an
increase in the average amounts borrowed in the first half of 2011 compared to 2010 as well as an
increase in our weighted average interest rate in the comparable period.

[0000950123-11-068216:mdna:80]
Income Tax Expense

[0000950123-11-068216:mdna:81]
The income tax expense was $19 million in the first six months of 2011 compared to $27 million
in 2010.

[0000950123-11-068216:mdna:82]
The effective tax rate was 34% for 2011 and 36% in 2010. Our effective rates differ from the
statutory federal rate of 35% for certain items, such as state and local taxes, non-deductible
expenses, foreign operating losses for which no tax benefits have been recognized and foreign taxes
at rates other than 35%.

[0000950123-11-068216:mdna:83]
Year-to-Date Through June 30, 2011 Compared to Year-to-Date Through June 30, 2010 — Results by
Segment

[0000950123-11-068216:mdna:84]
Residential Heating & Cooling

[0000950123-11-068216:mdna:85]
The following table summarizes our Residential Heating & Cooling segment’s net sales and
profit for the first half of 2011 and 2010 (dollars in millions):

[0000950123-11-068216:mdna:86]
|  |  | Six Months Ended |  |  |  |  |
|  |  | June 30, |  |  |  |  |
|  |  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales |  | $ | 667.1 |  |  | $ | 697.6 |  |  | $ | (30.5 | ) |  |  | (4.4 | )% |
| Profit |  |  | 32.0 |  |  |  | 59.6 |  |  |  | (27.6 | ) |  |  | (46.3 | )% |
| % of net sales |  |  | 4.8 | % |  |  | 8.5 | % |  |  |  |  |  |  |  |  |

[0000950123-11-068216:mdna:87]
Residential Heating & Cooling net sales declined by 4% in the first half of 2011 compared to
the first half of 2010. Sales volumes declined by almost 7% in 2011 as compared to 2010.
Partially offsetting the decline in sales volume was higher price and mix of 2% and favorable
foreign currency exchange rates of 1%. Our Residential Heating & Cooling segment’s sales volumes
were negatively affected by consumer weakness, a significant reduction in the federal tax credits
in 2011, and cooler temperatures.

[0000950123-11-068216:mdna:88]
Segment profit decreased $28 million due to $19 million in lower sales volumes, $16 million in
commodity headwinds, and $12 million in higher freight and distribution charges. Partially
offsetting these declines in segment profit was $13 million in favorable price and mix. Other
product cost savings and SG&A combined to favorably impact segment profit by $16 million. The lower
SG&A expenses were the result of $1 million in favorable bad debt experience and $4 million in
lower incentive compensation expense.

[0000950123-11-068216:mdna:89]
Commercial Heating & Cooling

[0000950123-11-068216:mdna:90]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit
for the first half of 2011 and 2010 (dollars in millions):

[0000950123-11-068216:mdna:91]
|  |  | Six Months Ended |  |  |  |  |
|  |  | June 30, |  |  |  |  |
|  |  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales |  | $ | 337.1 |  |  | $ | 295.4 |  |  | $ | 41.7 |  |  |  | 14.1 | % |
| Profit |  |  | 33.0 |  |  |  | 31.3 |  |  |  | 1.7 |  |  |  | 5.4 | % |
| % of net sales |  |  | 9.8 | % |  |  | 10.6 | % |  |  |  |  |  |  |  |  |

[0000950123-11-068216:mdna:92]
Our Commercial Heating & Cooling business experienced 14% in higher net sales in the first
half of 2011 compared to 2010 primarily due to an increase in our replacement business which
resulted in a 10% increase in sales volume. Additionally, our price and mix increased 2% in the
comparable period and changes in foreign currency exchange rates favorably impacted net sales by
2%.

[0000950123-11-068216:mdna:93]
Segment profit for the first half of 2011 increased almost $2 million from the first half of
2010. Segment profit increased from the impact of higher sales of $10 million and productivity
initiatives of $2 million. Partially offsetting these increases to segment profit were commodity
headwinds of $7 million and freight and distribution charges of $2 million.

[0000950123-11-068216:mdna:94]
Service Experts

[0000950123-11-068216:mdna:95]
The following table summarizes our Service Experts segment’s net sales and (loss) profit for the
first half of 2011 and 2010 (dollars in millions):

[0000950123-11-068216:mdna:96]
|  |  | Six Months Ended |  |  |  |  |
|  |  | June 30, |  |  |  |  |
|  |  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales |  | $ | 261.9 |  |  | $ | 294.7 |  |  | $ | (32.8 | ) |  |  | (11.1 | )% |
| (Loss) profit |  |  | (5.0 | ) |  |  | 8.2 |  |  |  | (13.2 | ) |  |  | (161.0 | )% |
| % of net sales |  |  | (1.9 | )% |  |  | 2.8 | % |  |  |  |  |  |  |  |  |

[0000950123-11-068216:mdna:97]
In total, sales volumes declined 14% which was partially offset by a 1% increase in price and
mix. Foreign currency exchange rates increased net sales by 2%. The decline in this segment’s
sales volume is primarily due to the decline in residential HVAC equipment installations.

[0000950123-11-068216:mdna:98]
Segment profit of $8 million in the first half of 2010 declined to a segment loss of $5
million in the first half of 2011. The decline to a segment loss in the first half of 2011 was due
to a $14 million decline in sales volumes. Partially offsetting the volume decline was an SG&A
expense improvement of $2 million due to $1 million in favorable bad debt experience and $2 million
in lower commissions due to the decline in net sales.

[0000950123-11-068216:mdna:99]
Refrigeration

[0000950123-11-068216:mdna:100]
The following table summarizes our Refrigeration segment’s net sales and profit for the first
half of 2011 and 2010 (dollars in millions):

[0000950123-11-068216:mdna:101]
|  |  | Six Months Ended |  |  |  |  |
|  |  | June 30, |  |  |  |  |
|  |  | 2011 |  | 2010 |  | Difference |  | % Change |
| Net sales |  | $ | 392.6 |  |  | $ | 271.2 |  |  | $ | 121.4 |  |  |  | 44.8 | % |
| Profit |  |  | 35.0 |  |  |  | 30.2 |  |  |  | 4.8 |  |  |  | 15.9 | % |
| % of net sales |  |  | 8.9 | % |  |  | 11.1 | % |  |  |  |  |  |  |  |  |

[0000950123-11-068216:mdna:102]
Net sales, excluding Kysor/Warren, increased 12% due to higher sales volumes of 3%, higher
price and mix of 2% and favorable foreign currency exchange rates of 7%. The Kysor/Warren
acquisition contributed 33% to the increase in net sales.

[0000950123-11-068216:mdna:103]
Segment profit increased by $5 million, including $9 million from the increase in net sales.
Partially offsetting the increase in net sales were declines of $4 million from commodity headwinds
and $2 million from higher freight and distribution charges. Foreign currency exchange rates had a
$2 million favorable impact on segment profit.

[0000950123-11-068216:mdna:104]
Corporate and Other

[0000950123-11-068216:mdna:105]
Corporate and other expenses were $26 million in the first half of 2011, down from $33 million
in the first half of 2010. The decrease was primarily driven by a $7 million decline in incentive
compensation expense for 2011 as well as expense control and productivity.

[0000950123-11-068216:mdna:106]
[same as prior period, unchanged from 0000950123-11-039069:mdna:56]

[0000950123-11-068216:mdna:107]
Our working capital and capital expenditure requirements are generally met through internally
generated funds, bank lines of credit and a revolving asset securitization arrangement.
Working capital needs are generally greater in the first and second quarters due to the seasonal
nature of our business cycle.

[0000950123-11-068216:mdna:108]
[same as prior period, unchanged from 0000950123-11-039069:mdna:58]

[0000950123-11-068216:mdna:109]
The following table summarizes our cash activity for the six months ended June 30, 2011 and
2010 (in millions):

[0000950123-11-068216:mdna:110]
|  |  | Six Months Ended |
|  |  | June 30, |
|  |  | 2011 |  | 2010 |
| Net cash used in operating activities |  | $ | (142.4 | ) |  | $ | (26.0 | ) |
| Net cash used in investing activities |  |  | (153.1 | ) |  |  | (46.3 | ) |
| Net cash provided by financing activities |  |  | 207.3 |  |  |  | 9.8 |  |

[0000950123-11-068216:mdna:111]
[same as prior period, unchanged from 0000950123-11-039069:mdna:61]

[0000950123-11-068216:mdna:112]
Operating activities resulted in a higher use of cash in 2011 compared to 2010. This
increased use was primarily due to higher working capital requirements in 2011 and a higher
incentive payout in 2011 for improved operating results in 2010. Our working capital requirements
resulted in a $162.5 million use of cash in the first

[0000950123-11-068216:mdna:113]
half of 2011 compared to a $141.5 million use of cash in 2010. The increase in working
capital requirements is primarily due to a larger increase in inventory of $139.2 million in the
first quarter of 2011 compared to $107.8 million in 2010. The inventory increase is primarily
related to our Residential Heating & Cooling segment. We build a significant portion of our
inventory in the first quarter and early part of our second quarter based on our expectation for
our summer season to ensure we have enough products to meet expected demand. As of the end of the
second quarter, our summer season sales were lower than expected because of cooler temperatures in
the second quarter, consumer weakness and a greater impact on our sales volumes and mix than
expected from the loss of the $1,500 tax credit.

[0000950123-11-068216:mdna:114]
[same as prior period, unchanged from 0000950123-11-039069:mdna:63]

[0000950123-11-068216:mdna:115]
Net cash used in investing activities for the first six months of 2011 included $143.3 million
for the acquisition of the Kysor/Warren business from The Manitowoc Company and $4.4 million for
the acquisition of a commercial services business in our Service Experts segment. Kysor/Warren is
a leading manufacturer of refrigerated systems and display cases for supermarkets throughout North
America and is included in our Refrigeration Segment.

[0000950123-11-068216:mdna:116]
Capital expenditures in the first half of 2011 were $18.6 million, which was slightly lower
than the $19.7 million in the first half of 2010. Capital expenditures in the quarter were
primarily related to investments in our distribution network and investments in systems and
software to support the overall enterprise.

[0000950123-11-068216:mdna:117]
Offsetting the cash used for capital expenditures and to acquire businesses in the first six
months of 2011 was a change in the security requirements for the remaining claims for our captive
insurance subsidiary. In the second quarter of 2011, we transferred primarily all security from
restricted cash to stand-by letters of credit resulting in a refund of $9.3 million of restricted
cash with the remaining $2.4 million used for claim payments.

[0000950123-11-068216:mdna:118]
In addition to the $19.7 million in capital expenditures in the first half of 2010, net cash
used in investing activities included $23.8 million placed in a trust for our captive insurance
subsidiary and $6.4 million for business acquisitions. Offsetting these uses were $3.5 million in
proceeds from the sale of businesses.

[0000950123-11-068216:mdna:119]
[same as prior period, unchanged from 0000950123-11-039069:mdna:67]

[0000950123-11-068216:mdna:120]
Net cash provided by financing activities increased by $197.5 million in the first six months
of 2011 compared to the first six months of 2010. This increase was primarily related to an
increase in net borrowings to support the Kysor/Warren acquisition and the increase in working
capital needs in the first half of 2011. We had fewer repurchases of common stock in 2011 which
also increased the net cash provided by financing activities.

[0000950123-11-068216:mdna:121]
[same as prior period, unchanged from 0000950123-11-039069:mdna:69]

[0000950123-11-068216:mdna:122]
The following table details our lines of credit and financing arrangements as of June 30,
2011:

[0000950123-11-068216:mdna:123]
|  |  |  |  |  |  |  |  |  |  | Available for |  |
|  |  | Maximum |  |  | Outstanding |  |  | Future |  |
|  |  | Capacity |  |  | Borrowings |  |  | Borrowings |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign Obligations |  |  |  |  |  |  |  |  |  |  |  |  |
| Committed |  | $ | 4.1 |  |  | $ | — |  |  | $ | 4.1 |  |
| Non-committed |  |  | 6.7 |  |  |  | 6.7 |  |  |  | — |  |
| Asset Securitization (1) |  |  | 100.0 |  |  |  | — |  |  |  | 100.0 |  |
| Total short-term debt |  | $ | 110.8 |  |  | $ | 6.7 |  |  | $ | 104.1 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital lease obligations |  | $ | 17.2 |  |  |  | 17.2 |  |  |  | — |  |
| Domestic revolving credit facility (2) |  |  | 650.0 |  |  |  | 354.0 |  |  |  | 218.5 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |  |  | — |  |
| Total long-term debt |  | $ | 867.2 |  |  | $ | 571.2 |  |  |  | 218.5 |  |
| Total |  | $ | 978.0 |  |  | $ | 577.9 |  |  | $ | 322.6 |  |

[0000950123-11-068216:mdna:124]
| (1) |  | The maximum capacity under the asset securitization arrangement (“ASA”) is the lesser of $100.0 million or 100% of the net pool balance defined under the ASA. |
| (2) |  | The available future borrowings on our domestic revolving credit facility exclude $77.5 million in standby letters of credit. |

[0000950123-11-068216:mdna:125]
As discussed above, we utilized our domestic revolving credit facility (“credit facility”) to
support the acquisition of the Kysor/Warren business and the increase in working capital needs in
the first half of 2011. In addition to the $577.9 million in outstanding borrowings as of June 30,
2011, we had average borrowings under the ASA of $60.2 million that were paid down by the end of
June. As our peak season arrives, we typically pay down debt. We believe our available future
borrowings combined with our cash of $76.5 million and anticipated cash from operations in the
latter half of the year will be more than sufficient to fund our operations, capital expenditures,
share repurchases, dividends and other needs in the foreseeable future. Our expected
capital expenditures are $60 million for 2011.

[0000950123-11-068216:mdna:126]
Our debt-to-total-capital ratio increased to 49.1% at June 30, 2011 compared to 35.1% at
December 31, 2010. The increase in the ratio is primarily due to the increase in debt since
December 31, 2010 from the acquisition of the Kysor/Warren business as well as our increase in
working capital needs.

[0000950123-11-068216:mdna:127]
Covenants on our outstanding debt did not change in the first half of 2011 and we were in
compliance with all of our debt covenants as of June 30, 2011. For a more detailed discussion of
our debt, see Note 8 in the Notes to the Consolidated Financial Statements set forth in Part I,
Item I of this Quarterly Report on Form 10-Q.

[0000950123-11-068216:mdna:128]
We periodically review our capital structure, including our primary bank facility, to ensure
that it has adequate liquidity. Our ASA expires on November 18, 2011 and our credit facility
matures in October 2012. We expect to amend, renew or replace these facilities prior to or upon
their expiration. We also periodically consider various other financing alternatives and may, from
time to time, seek to take advantage of favorable interest rate environments or other market
conditions, which may include accessing the capital markets. We filed a shelf registration
statement with the SEC that became effective on December 1, 2008, which allows us to offer and sell
an indeterminate number or amount of debt securities, common shares, preferred shares, subscription
rights, warrants, depositary shares and units.

[0000950123-11-068216:mdna:129]
On March 11, 2011, we announced that our Board of Directors approved a 20% increase in our
quarterly dividend on common stock from $0.15 to $0.18 effective with the April dividend payment.
Dividend payments are expected to be approximately $35 million in 2011. We also continue to
increase shareholder value through our share repurchase program. During the first six months of
2011, we returned $35 million to our investors through share repurchases. We are targeting at
least $100 million in share repurchases in 2011.

[0000950123-11-068216:mdna:130]
[same as prior period, unchanged from 0000950123-11-039069:mdna:79]

[0000950123-11-068216:mdna:131]
[same as prior period, unchanged from 0000950123-11-039069:mdna:80]

[0000950123-11-068216:mdna:132]
Commitments, Contingencies and Guarantees

[0000950123-11-068216:mdna:133]
For a detailed discussion of commitments, contingencies and guarantees, see Note 7 in the
Notes to the Consolidated Financial Statements.

[0000950123-11-068216:mdna:134]
[same as prior period, unchanged from 0000950123-11-039069:mdna:83]

[0000950123-11-068216:mdna:135]
We also may incur costs related to our products that may not be covered under our warranties
and are not covered by insurance, and we may, from time to time, repair or replace installed
products experiencing quality issues in order to satisfy our customers and to protect our brand.
These product quality issues may be caused by vendor-supplied components that fail to meet required
specifications. We have identified a product quality issue in a heating and cooling product line
produced in 2006 and 2007  related to a vendor-supplied materials

[0000950123-11-068216:mdna:136]
quality issue. To date, we recorded expenses of $22.7 million for the portion of the issue
that is probable and can be reasonably estimated. We decreased this liability by $1.4 million in
the second quarter of 2011 to adjust the estimated claim cost based on historical claims paid. As
of June 30, 2011, we had $10.9 million accrued for this matter. We may incur additional charges in
the future as more information becomes available.

[0000950123-11-068216:mdna:137]
We estimate the costs to settle pending litigation based on experience involving similar
claims and specific facts known. We do not believe that any current or pending or threatened
litigation will have a material adverse effect on our financial position. Litigation and
arbitration, however, involve uncertainties and it is possible that the eventual outcome of
litigation could adversely affect our results of operations for a particular period.

[0000950123-11-068216:mdna:138]
We were the defendant in a class action lawsuit related to certain hearth products we produced
and sold that claimed such products are hazardous and that consumers were not adequately warned.
On August 23, 2010, the Company and plaintiffs entered into a binding Memorandum of Understanding
(“MOU”) and reached tentative terms for settlement of the case. At the parties’ request, the court
stayed the lawsuit shortly after the MOU was signed. On June 10, 2011, the litigation of this
matter concluded when the court issued its Order Granting Final Approval of Class Settlement; Final
Judgment and Order of Dismissal. We had $9.4 million in expenses to date related to this matter
and made minor adjustments to the reserve in the second quarter of 2011.
