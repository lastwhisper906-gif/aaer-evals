# LII 8-K — 0000950123-11-068114 filed 2011-07-26

## item codes, every 8-K on or before 2011-07-26

- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2011-07-26

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000950123-11-068114:8k_2_02:1]
EX-99.1
2
d83751exv99w1.htm
EX-99.1

[0000950123-11-068114:8k_2_02:2]
exv99w1

[0000950123-11-068114:8k_2_02:3]
Exhibit 99.1

[0000950123-11-068114:8k_2_02:4]
Lennox International Reports Second Quarter Results

[0000950123-11-068114:8k_2_02:5]
| • |  | Total revenue up 7%, with organic revenue up 1% |
| • |  | Adjusted EPS of $0.84 and GAAP EPS of $0.83 |
| • |  | Lowering guidance range for 2011 revenue growth to 8-11%, with 1-4% organic growth |
| • |  | Lowering guidance range for 2011 adjusted EPS to $2.00 to $2.30 |
| • |  | More than $65 million of stock repurchases planned in second half of 2011 |

[0000950123-11-068114:8k_2_02:6]
DALLAS, July 26 — Lennox International Inc. (NYSE: LII) today reported financial results for the
second quarter of 2011.

[0000950123-11-068114:8k_2_02:7]
Revenue for the second quarter was $937 million, up 7% from the prior-year quarter including a 3
point positive impact from foreign exchange. Excluding the Kysor/Warren acquisition that closed in
January 2011, organic revenue was up 1% in the second quarter. At constant currency, organic
revenue was down 2% from the prior-year quarter. Diluted earnings per share from continuing
operations on an adjusted basis was $0.84, compared to $0.97 in the prior-year quarter. Diluted
earnings per share from continuing operations on a GAAP basis was $0.83, compared to $0.86 in the
prior-year quarter.

[0000950123-11-068114:8k_2_02:8]
“Our residential equipment and service businesses were soft in the second quarter, impacted by
consumer weakness, cooler weather in key regions, and lower system sales and product mix versus a
year ago when the federal government’s $1,500 tax credit for high-efficiency heating and cooling
products was in place,” said Todd Bluedorn, CEO of Lennox International. “Residential was also
impacted by lower new construction business than a year ago when federal tax credits for homebuyers
were in place. In constant currency, Residential segment revenue was down 5% in the second quarter,
and Service Experts segment revenue was down 14%. Given weak residential market conditions, the
company is lowering revenue and EPS guidance ranges for the year and has taken cost reduction
measures accordingly. In our Commercial and Refrigeration businesses, we saw broad-based growth in
the second quarter. In constant currency, Commercial revenue was up 9%, and Refrigeration organic
revenue was up 8% adjusted for the strategic exit of third-party coil business in Australia last
year. Backlog in both business segments continues to look strong. For the full year, we continue to
expect industry shipments in the refrigeration market to be up mid single digits, and we now expect
the North America commercial unitary market to be up high single digits versus prior expectations
of mid single digits.”

[0000950123-11-068114:8k_2_02:9]
FINANCIAL HIGHLIGHTS

[0000950123-11-068114:8k_2_02:10]
Revenue: Revenue for the second quarter was $937 million, up 7% from the prior-year quarter
including a positive 3 point impact from foreign exchange. On an organic basis, revenue at constant
currency was down 2% from the second quarter a year ago. Volume was down, and price/mix was up from
the prior-year quarter.

[0000950123-11-068114:8k_2_02:11]
Gross Profit: Gross profit for the second quarter was $248 million, down 6% from $265 million in
the prior-year quarter. Gross margin was 26.4% compared to 30.4% in the prior-year quarter. Gross
margin was impacted primarily by higher commodity costs and the Kysor/Warren acquisition, with
offsets from improved price/mix and productivity initiatives. The annual adjustment for warranty
was favorable by $3 million in the second quarter of 2011, which compares to a favorable adjustment
of $6 million in the second quarter a year ago.

[0000950123-11-068114:8k_2_02:12]
Income from Continuing Operations: Adjusted income from continuing operations in the second quarter
was $45.6 million, or $0.84 diluted earnings per share, compared to adjusted income from continuing
operations of $54.7 million, or $0.97 diluted earnings per share in the prior-year quarter.
Adjusted income from continuing operations for the second quarter of 2011 excludes: an after-tax
charge of $1.5 million for restructuring activities; a $1.5 million favorable special product
quality adjustment, net; $0.5 million after-tax for the net change in unrealized losses on open
future contracts; and $0.3 million for other items, net.

[0000950123-11-068114:8k_2_02:13]
On a GAAP basis, income from continuing operations for the second quarter was $45.0 million, or
$0.83 diluted earnings per share, compared to $48.7 million income from continuing operations, or
$0.86 diluted earnings per share, in the prior-year quarter.

[0000950123-11-068114:8k_2_02:14]
Free Cash Flow and Total Debt: Net cash from operations in the second quarter was $6 million
compared to $14 million in the prior-year quarter. The company invested $10 million in capital
assets in the second quarter. Free cash flow was ($5) million, compared to $5 million in the
prior-year quarter. Total debt at the end of the second quarter was $578 million. The company paid
$10 million in dividends and repurchased $12 million of stock in the quarter. Total cash and cash
equivalents were $77 million at the end of the quarter.

[0000950123-11-068114:8k_2_02:15]
BUSINESS SEGMENT HIGHLIGHTS

[0000950123-11-068114:8k_2_02:16]
Residential Heating & Cooling

[0000950123-11-068114:8k_2_02:17]
Second quarter revenue in the Residential Heating & Cooling business segment was $395 million, down
4% from $413 million in the prior-year quarter. At constant currency, revenue was down 5%. Segment
profit was $33 million and segment profit margin was 8.4%, compared to segment profit of $53
million and segment profit margin of 12.7% in the prior-year quarter. Results were primarily
impacted by lower volume, higher commodity costs, and a lower favorable warranty adjustment than in
the prior-year quarter, with offsets from productivity initiatives and lower SG&A expenses.
Price/mix was flat with the prior-year quarter due to a lower product mix.

[0000950123-11-068114:8k_2_02:18]
Commercial Heating & Cooling

[0000950123-11-068114:8k_2_02:19]
Revenue in the Commercial Heating & Cooling business segment was $198 million, up 13% from $176
million in the prior-year quarter. At constant currency, revenue was up 9%. Total segment profit
was $27 million, and segment profit margin was 13.7%, compared to segment profit of $28 million and
segment profit margin of 15.8% in the prior-year quarter. Results were primarily impacted by higher
volume and favorable price/mix, with offsets from higher commodity costs and a lower favorable
warranty adjustment than in the prior-year quarter.

[0000950123-11-068114:8k_2_02:20]
Service Experts

[0000950123-11-068114:8k_2_02:21]
Revenue in the Service Experts business segment was $145 million in the second quarter, down 13%
from $168 million in the prior-year quarter. At constant currency, revenue was down 14%. Segment
profit was $3 million and segment profit margin was 2.2%, compared to segment profit of $13 million
and segment profit margin of 7.6% in the prior-year quarter. Results were primarily impacted by
lower volume, with a partial offset from lower SG&A expenses.

[0000950123-11-068114:8k_2_02:22]
Refrigeration

[0000950123-11-068114:8k_2_02:23]
Revenue in the Refrigeration business segment was $218 million in the second quarter, up 56% from
$140 million in the prior-year quarter. At constant currency, revenue was up 47%. Excluding the
Kysor/Warren acquisition, organic revenue was up 4% at constant currency. Segment profit was $21
million and segment profit margin was 9.8% in the second quarter, compared to segment profit of $15
million and segment profit margin of 10.9% in the year-ago quarter. Excluding the Kysor/Warren
acquisition, segment profit margin was up 260 basis points from the prior-year quarter. Results
were primarily impacted by higher volume and favorable price/mix, with offsets from higher
commodity costs and selling expenses.

[0000950123-11-068114:8k_2_02:24]
FULL-YEAR OUTLOOK

[0000950123-11-068114:8k_2_02:25]
The company is lowering its revenue and EPS guidance ranges for 2011.

[0000950123-11-068114:8k_2_02:26]
|  | • |  | Adjusting the guidance range for revenue growth from 11-14% to a range of 8-11%; adjusting the guidance range for organic revenue growth from 5-8% to a range of 1-4%; foreign exchange is estimated to have 2 points of positive impact versus 1 point of positive impact previously. |
|  | • |  | Lowering the guidance range for adjusted EPS from continuing operations from $2.80-$3.10 to a range of $2.00-$2.30. |
|  | • |  | Lowering the guidance range for GAAP EPS from continuing operations from $2.75-$3.05 to a range of $1.93-$2.23. |
|  | • |  | The company now expects $60-65 million of headwind from raw and component commodity costs for the full year, up from $45-50 million previously. |
|  | • |  | Lowering tax rate guidance from approximately 35% to 34% for the full year. |
|  | • |  | Lowering capital expenditure guidance from approximately $65 million to $60 million for the full year. |
|  | • |  | The company plans more than $65 million of stock repurchases in the second half of 2011. |

[0000950123-11-068114:8k_2_02:27]
CONFERENCE CALL INFORMATION

[0000950123-11-068114:8k_2_02:28]
A conference call to discuss the company’s second quarter results will be held this morning at 8:30
a.m. Central time. To listen, please call the conference call line at 651-291-5254 at least 10
minutes prior to the scheduled start time and use reservation number 209152. This conference call
will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0000950123-11-068114:8k_2_02:29]
A replay will be available from 11:00 a.m. Central time on July 26 through August 2, 2011, by
dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 209152. This call
will also be archived on the company’s web site.

[0000950123-11-068114:8k_2_02:30]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration
markets. Lennox International stock is traded on the New York Stock Exchange under the symbol
“LII.” Additional information is available at: http://www.lennoxinternational.com or by contacting
Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0000950123-11-068114:8k_2_02:31]
FORWARD-LOOKING AND CAUTIONARY STATEMENTS

[0000950123-11-068114:8k_2_02:32]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-068114:8k_2_02:33]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950123-11-068114:8k_2_02:34]
(Unaudited, in millions, except per share data)

[0000950123-11-068114:8k_2_02:35]
|  |  | For the Three Months |  |  | For the Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| NET SALES |  | $ | 937.0 |  |  | $ | 872.1 |  |  | $ | 1,624.7 |  |  | $ | 1,516.2 |  |
| COST OF GOODS SOLD |  |  | 689.4 |  |  |  | 607.4 |  |  |  | 1,212.0 |  |  |  | 1,077.1 |  |
| Gross profit |  |  | 247.6 |  |  |  | 264.7 |  |  |  | 412.7 |  |  |  | 439.1 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 175.2 |  |  |  | 180.5 |  |  |  | 348.9 |  |  |  | 349.6 |  |
| Losses and other expenses, net |  |  | 0.9 |  |  |  | 5.8 |  |  |  | 0.6 |  |  |  | 5.5 |  |
| Restructuring charges |  |  | 2.4 |  |  |  | 3.2 |  |  |  | 3.6 |  |  |  | 10.3 |  |
| Income from equity method investments |  |  | (3.4 | ) |  |  | (4.1 | ) |  |  | (5.9 | ) |  |  | (6.1 | ) |
| Operational income from continuing operations |  |  | 72.5 |  |  |  | 79.3 |  |  |  | 65.5 |  |  |  | 79.8 |  |
| INTEREST EXPENSE, net |  |  | 4.3 |  |  |  | 3.1 |  |  |  | 8.4 |  |  |  | 5.6 |  |
| OTHER EXPENSE, net |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 68.1 |  |  |  | 76.1 |  |  |  | 57.0 |  |  |  | 74.1 |  |
| PROVISION FOR INCOME TAXES |  |  | 23.1 |  |  |  | 27.4 |  |  |  | 19.2 |  |  |  | 26.7 |  |
| Income from continuing operations |  |  | 45.0 |  |  |  | 48.7 |  |  |  | 37.8 |  |  |  | 47.4 |  |
| DISCONTINUED OPERATIONS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operational loss from discontinued operations |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.8 |  |
| Income tax benefit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.7 |  |
| Net income |  | $ | 45.0 |  |  | $ | 48.3 |  |  | $ | 37.8 |  |  | $ | 46.7 |  |
| EARNINGS PER SHARE — BASIC: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.85 |  |  | $ | 0.88 |  |  | $ | 0.71 |  |  | $ | 0.85 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.01 | ) |
| Net income |  | $ | 0.85 |  |  | $ | 0.88 |  |  | $ | 0.71 |  |  | $ | 0.84 |  |
| EARNINGS PER SHARE — DILUTED: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.83 |  |  | $ | 0.86 |  |  | $ | 0.69 |  |  | $ | 0.83 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.01 | ) |
| Net income |  | $ | 0.83 |  |  | $ | 0.86 |  |  | $ | 0.69 |  |  | $ | 0.82 |  |
| AVERAGE SHARES OUTSTANDING: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 53.2 |  |  |  | 55.1 |  |  |  | 53.4 |  |  |  | 55.6 |  |
| Diluted |  |  | 54.3 |  |  |  | 56.3 |  |  |  | 54.5 |  |  |  | 56.8 |  |
| CASH DIVIDENDS DECLARED PER SHARE |  | $ | 0.18 |  |  | $ | 0.15 |  |  | $ | 0.36 |  |  | $ | 0.30 |  |

[0000950123-11-068114:8k_2_02:36]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-068114:8k_2_02:37]
SEGMENT NET SALES AND PROFIT

[0000950123-11-068114:8k_2_02:38]
(Unaudited, in millions)

[0000950123-11-068114:8k_2_02:39]
|  |  | For the Three Months |  |  | For the Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 395.1 |  |  | $ | 413.4 |  |  | $ | 667.1 |  |  | $ | 697.6 |  |
| Commercial Heating & Cooling |  |  | 198.3 |  |  |  | 175.8 |  |  |  | 337.1 |  |  |  | 295.4 |  |
| Service Experts |  |  | 145.4 |  |  |  | 167.6 |  |  |  | 261.9 |  |  |  | 294.7 |  |
| Refrigeration |  |  | 217.5 |  |  |  | 139.8 |  |  |  | 392.6 |  |  |  | 271.2 |  |
| Eliminations (A) |  |  | (19.3 | ) |  |  | (24.5 | ) |  |  | (34.0 | ) |  |  | (42.7 | ) |
|  |  | $ | 937.0 |  |  | $ | 872.1 |  |  | $ | 1,624.7 |  |  | $ | 1,516.2 |  |
| Segment Profit (Loss) (B) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 33.2 |  |  | $ | 52.5 |  |  | $ | 32.0 |  |  | $ | 59.6 |  |
| Commercial Heating & Cooling |  |  | 27.1 |  |  |  | 27.8 |  |  |  | 33.0 |  |  |  | 31.3 |  |
| Service Experts |  |  | 3.2 |  |  |  | 12.8 |  |  |  | (5.0 | ) |  |  | 8.2 |  |
| Refrigeration |  |  | 21.4 |  |  |  | 15.3 |  |  |  | 35.0 |  |  |  | 30.2 |  |
| Corporate and other |  |  | (11.6 | ) |  |  | (19.6 | ) |  |  | (26.0 | ) |  |  | (32.8 | ) |
| Eliminations (A) |  |  | 0.2 |  |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.2 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 73.5 |  |  |  | 88.5 |  |  |  | 68.7 |  |  |  | 96.3 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | (2.4 | ) |  |  | — |  |  |  | (2.4 | ) |  |  | — |  |
| Items in losses and other expenses, net that are excluded from segment profit (C) |  |  | 1.0 |  |  |  | 6.0 |  |  |  | 2.0 |  |  |  | 6.2 |  |
| Restructuring charges |  |  | 2.4 |  |  |  | 3.2 |  |  |  | 3.6 |  |  |  | 10.3 |  |
| Interest expense, net |  |  | 4.3 |  |  |  | 3.1 |  |  |  | 8.4 |  |  |  | 5.6 |  |
| Other expense, net |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 68.1 |  |  | $ | 76.1 |  |  | $ | 57.0 |  |  | $ | 74.1 |  |

[0000950123-11-068114:8k_2_02:40]
| (A) |  | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |
| (B) |  | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |

[0000950123-11-068114:8k_2_02:41]
|  |  | Excluding: |

[0000950123-11-068114:8k_2_02:42]
|  | • |  | Special product quality adjustment. |
|  | • |  | Items within Gains and/or losses and other expenses, net that are noted in (C) . |
|  | • |  | Restructuring charges. |
|  | • |  | Goodwill and equity method investment impairments. |
|  | • |  | Interest expense, net. |
|  | • |  | Other expense, net. |

[0000950123-11-068114:8k_2_02:43]
| (C) |  | Items in Gains and/or losses and other expenses, net that are excluded from segment profit or loss are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |

[0000950123-11-068114:8k_2_02:44]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-068114:8k_2_02:45]
CONSOLIDATED BALANCE SHEETS

[0000950123-11-068114:8k_2_02:46]
(In millions, except share and per share data)

[0000950123-11-068114:8k_2_02:47]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 76.5 |  |  | $ | 160.0 |  |
| Restricted cash |  |  | 0.5 |  |  |  | 12.2 |  |
| Accounts and notes receivable, net of allowances of $15.9 and $12.8 in 2011 and 2010, respectively |  |  | 525.4 |  |  |  | 384.8 |  |
| Inventories, net |  |  | 460.1 |  |  |  | 286.2 |  |
| Deferred income taxes, net |  |  | 44.0 |  |  |  | 36.7 |  |
| Other assets |  |  | 58.9 |  |  |  | 67.0 |  |
| Total current assets |  |  | 1,165.4 |  |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net of accumulated depreciation of $606.9 and $584.7 in 2011 and 2010, respectively |  |  | 347.0 |  |  |  | 324.3 |  |
| GOODWILL |  |  | 325.9 |  |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | 87.3 |  |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 93.4 |  |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 2,019.0 |  |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 6.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt |  |  | 0.4 |  |  |  | 0.6 |  |
| Accounts payable |  |  | 371.8 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 299.6 |  |  |  | 334.5 |  |
| Income taxes payable |  |  | — |  |  |  | 5.3 |  |
| Total current liabilities |  |  | 678.5 |  |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 570.8 |  |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | 15.7 |  |  |  | 15.9 |  |
| PENSIONS |  |  | 89.0 |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 64.0 |  |  |  | 65.7 |  |
| Total liabilities |  |  | 1,418.0 |  |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 86,632,842 shares and 86,480,816 shares issued for 2011 and 2010, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 875.5 |  |  |  | 863.5 |  |
| Retained earnings |  |  | 660.9 |  |  |  | 642.2 |  |
| Accumulated other comprehensive income |  |  | 47.3 |  |  |  | 30.2 |  |
| Treasury stock, at cost, 33,513,633 shares and 32,784,503 shares for 2011 and 2010, respectively |  |  | (983.6 | ) |  |  | (947.1 | ) |
| Total stockholders’ equity |  |  | 601.0 |  |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 2,019.0 |  |  | $ | 1,692.0 |  |

[0000950123-11-068114:8k_2_02:48]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-068114:8k_2_02:49]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0000950123-11-068114:8k_2_02:50]
(Unaudited, in millions, except per share and ratio data)

[0000950123-11-068114:8k_2_02:51]
Use of Non-GAAP Financial Measures

[0000950123-11-068114:8k_2_02:52]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP,
additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP
financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding
period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance.

[0000950123-11-068114:8k_2_02:53]
Reconciliation of Income From Continuing Operations, a GAAP Measure, to Adjusted Income From Continuing Operations,
a Non-GAAP Measure

[0000950123-11-068114:8k_2_02:54]
|  |  | For The Three Months |  |  | For The Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Income from continuing operations, a GAAP measure |  | $ | 45.0 |  |  | $ | 48.7 |  |  | $ | 37.8 |  |  | $ | 47.4 |  |
| Restructuring charges, after tax |  |  | 1.5 |  |  |  | 2.1 |  |  |  | 2.3 |  |  |  | 6.7 |  |
| Special product quality adjustment, net (b) |  |  | (1.5 | ) |  |  | — |  |  |  | (1.5 | ) |  |  | — |  |
| Special legal contingency charge, after-tax (a) |  |  | (0.2 | ) |  |  | 2.9 |  |  |  | (0.2 | ) |  |  | 2.9 |  |
| Net change in unrealized losses on open future contracts, after tax (a) |  |  | 0.5 |  |  |  | 0.8 |  |  |  | 1.0 |  |  |  | 0.8 |  |
| Other items, net, after tax (a) |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | 0.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 45.6 |  |  | $ | 54.7 |  |  | $ | 39.8 |  |  | $ | 58.1 |  |

[0000950123-11-068114:8k_2_02:55]
Reconciliation of Earnings per Share from Continuing Operations — Diluted, a GAAP Measure,
to Adjusted Earnings per Share From Continuing Operations — Diluted, a Non-GAAP Measure

[0000950123-11-068114:8k_2_02:56]
| Earnings per share from continuing operations — diluted, a GAAP measure |  | $ | 0.83 |  |  | $ | 0.86 |  |  | $ | 0.69 |  |  | $ | 0.83 |  |
| Restructuring charges |  |  | 0.03 |  |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.12 |  |
| Special product quality adjustment (b) |  |  | (0.03 | ) |  |  | — |  |  |  | (0.03 | ) |  |  | — |  |
| Special legal contingency charge (a) |  |  | — |  |  |  | 0.05 |  |  |  | — |  |  |  | 0.05 |  |
| Net change in unrealized losses on open future contracts and other items, net (a) |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.03 |  |  |  | 0.02 |  |
| Adjusted earnings per share from continuing operations — diluted, a non-GAAP measure |  | $ | 0.84 |  |  | $ | 0.97 |  |  | $ | 0.73 |  |  | $ | 1.02 |  |

[0000950123-11-068114:8k_2_02:57]
| (a) |  | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |
| (b) |  | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0000950123-11-068114:8k_2_02:58]
|  |  | For The Three Months |  |  | For The Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized gains on settled future contracts (a) |  |  | (0.4 | ) |  |  | (0.4 | ) |  |  | (1.0 | ) |  |  | (0.8 | ) |
| Foreign currency exchange loss (a) |  |  | 0.4 |  |  |  | 0.1 |  |  |  | 0.5 |  |  |  | — |  |
| (Gain) loss on disposal of fixed assets (a) |  |  | (0.1 | ) |  |  | — |  |  |  | (0.9 | ) |  |  | 0.1 |  |
| Special legal contingency charge (b) |  |  | (0.2 | ) |  |  | 4.5 |  |  |  | (0.2 | ) |  |  | 4.5 |  |
| Net change in unrealized losses on open futures contracts (b) |  |  | 0.7 |  |  |  | 1.3 |  |  |  | 1.5 |  |  |  | 1.3 |  |
| (Gain) loss on sale of entity (b) |  |  | (0.1 | ) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | 0.1 |  |
| Other items, net (b) |  |  | 0.6 |  |  |  | 0.2 |  |  |  | 0.8 |  |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 0.9 |  |  | $ | 5.8 |  |  | $ | 0.6 |  |  | $ | 5.5 |  |

[0000950123-11-068114:8k_2_02:59]
| (a) |  | Included in segment profit and adjusted income from continuing operations |
| (b) |  | Excluded from segment profit and adjusted income from continuing operations |

[0000950123-11-068114:8k_2_02:60]
| Reconciliation of Estimated Adjusted Earnings per Share from Continuing Operations — Diluted, a Non-GAAP Measure, to |
| Earnings per Share from Continuing Operations — Diluted, a GAAP Measure |

[0000950123-11-068114:8k_2_02:61]
|  |  | For the |  |
|  |  | Year Ended |  |
|  |  | December 31, |  |
|  |  | 2011 |  |
|  |  | ESTIMATED |  |
| Adjusted earnings per share from continuing operations — diluted |  | $ | 2.00 — $2.30 |  |
| Restructuring charges |  |  | (0.07 | ) |
| Special legal contingency charge |  |  | — |  |
| Special product quality adjustment, net |  |  | 0.03 |  |
| Net change in unrealized losses on open futures contracts and other items, net |  |  | (0.03 | ) |
| GAAP earnings per share from continuing operations — diluted |  | $ | 1.93 — $2.23 |  |

[0000950123-11-068114:8k_2_02:62]
Reconciliation of Net Cash Used in Operating Activities, a GAAP Measure, to Free Cash Flow, a Non-GAAP Measure

[0000950123-11-068114:8k_2_02:63]
|  |  | For the Three Months |  |  | For the Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 5.9 |  |  | $ | 14.3 |  |  | $ | (142.4 | ) |  | $ | (26.0 | ) |
| Purchase of property, plant and equipment |  |  | (10.4 | ) |  |  | (9.0 | ) |  |  | (18.6 | ) |  |  | (19.7 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | (4.5 | ) |  | $ | 5.3 |  |  | $ | (161.0 | ) |  | $ | (45.7 | ) |

[0000950123-11-068114:8k_2_02:64]
Calculation of Debt to EBITDA Ratio:

[0000950123-11-068114:8k_2_02:65]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | June 30, |  |
|  |  | 2011 |  |
| EBIT (a) |  | $ | 189.4 |  |
| Depreciation and amortization expense (b) |  |  | 57.5 |  |
| EBITDA (a + b) |  | $ | 246.9 |  |
| Total debt at June 30, 2011 (c) |  | $ | 577.9 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 2.3 |  |

[0000950123-11-068114:8k_2_02:66]
Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income Taxes, a GAAP
Measure

[0000950123-11-068114:8k_2_02:67]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | June 30, |  |
|  |  | 2011 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 189.4 |  |
| Special product quality adjustment |  |  | (2.6 | ) |
| Items in losses and other expenses, net that are excluded from segment profit |  |  | 7.0 |  |
| Restructuring charges |  |  | 8.9 |  |
| Interest expense, net |  |  | 15.6 |  |
| Other expenses, net |  |  | 1.0 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 159.5 |  |

[0000950123-11-068114:8k_2_02:68]
Reconciliation of Reported Revenue Growth, a GAAP Measure, to Organic Revenue Growth, a
non-GAAP Measure

[0000950123-11-068114:8k_2_02:69]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Translational |  |  | Net Sales |  |
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |  | Currency |  |  | Growth % |  |
|  |  | For The Three Months |  |  | Net |  |  | Net |  |  | Impact |  |  | Excluding |  |
|  |  | Ended June 30, |  |  | Sales |  |  | Sales |  |  | Favorable |  |  | Currency |  |
|  |  | 2011 |  |  | 2010 |  |  | Variance |  |  | Growth % |  |  | (Unfavorable) |  |  | Impact |  |
| Lennox International Inc. and Subsidiaries |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 937.0 |  |  | $ | 872.1 |  |  | $ | 64.9 |  |  |  | 7.4 | % |  | $ | 25.5 |  |  |  | 4.5 | % |
| Less: Kysor/Warren acquisition |  |  | (60.2 | ) |  |  | — |  |  |  | (60.2 | ) |  |  |  |  |  |  | (1.1 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 876.8 |  |  | $ | 872.1 |  |  | $ | 4.7 |  |  |  | 0.5 | % |  | $ | 24.4 |  |  |  | -2.3 | % |
| Refrigeration Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 217.5 |  |  | $ | 139.8 |  |  | $ | 77.7 |  |  |  | 55.6 | % |  | $ | 13.8 |  |  |  | 45.7 | % |
| Less: Kysor/Warren acquisition |  |  | (60.2 | ) |  |  | — |  |  |  | (60.2 | ) |  |  |  |  |  |  | (1.1 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 157.3 |  |  | $ | 139.8 |  |  | $ | 17.5 |  |  |  | 12.5 | % |  | $ | 12.7 |  |  |  | 3.4 | % |

[0000950123-11-068114:8k_2_02:70]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Translational |  |  | Net Sales |  |
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |  | Currency |  |  | Growth % |  |
|  |  | For The Six Months |  |  | Net |  |  | Net |  |  | Impact |  |  | Excluding |  |
|  |  | Ended June 30, |  |  | Sales |  |  | Sales |  |  | Favorable |  |  | Currency |  |
|  |  | 2011 |  |  | 2010 |  |  | Variance |  |  | Growth % |  |  | (Unfavorable) |  |  | Impact |  |
| Lennox International Inc. and Subsidiaries |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 1,624.7 |  |  | $ | 1,516.2 |  |  | $ | 108.5 |  |  |  | 7.2 | % |  | $ | 35.5 |  |  |  | 4.8 | % |
| Less: Kysor/Warren acquisition |  |  | (94.1 | ) |  |  | — |  |  |  | (94.1 | ) |  |  |  |  |  |  | (1.4 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 1,530.6 |  |  | $ | 1,516.2 |  |  | $ | 14.4 |  |  |  | 0.9 | % |  | $ | 34.1 |  |  |  | -1.3 | % |
| Refrigeration Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 392.6 |  |  | $ | 271.2 |  |  | $ | 121.4 |  |  |  | 44.8 | % |  | $ | 20.2 |  |  |  | 37.3 | % |
| Less: Kysor/Warren acquisition |  |  | (94.1 | ) |  |  | — |  |  |  | (94.1 | ) |  |  |  |  |  |  | (1.4 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 298.5 |  |  | $ | 271.2 |  |  | $ | 27.3 |  |  |  | 10.1 | % |  | $ | 18.8 |  |  |  | 3.1 | % |

[0000950123-11-068114:8k_2_02:71]
Reconciliation of Reported Refrigeration Segment Profit Margin to Organic Segment Profit
Margin

[0000950123-11-068114:8k_2_02:72]
|  |  | For the Three Months Ended June 30, 2011 |  |  | For the Three Months Ended June 30, 2010 |  |
|  |  |  |  |  |  |  |  |  |  | Segment |  |  |  |  |  |  |  |  |  |  | Segment |  |
|  |  | Net |  |  | Segment |  |  | Profit |  |  | Net |  |  | Segment |  |  | Profit |  |
|  |  | Sales |  |  | Profit |  |  | Margin |  |  | Sales |  |  | Profit |  |  | Margin |  |
| Refrigeration Segment, as reported |  | $ | 217.5 |  |  | $ | 21.4 |  |  |  | 9.8 | % |  | $ | 139.8 |  |  | $ | 15.3 |  |  |  | 10.9 | % |
| Less: Kysor/Warren acquisition |  |  | (60.2 | ) |  |  | (0.1 | ) |  |  | -0.2 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Refrigeration Segment, organic |  | $ | 157.3 |  |  | $ | 21.3 |  |  |  | 13.5 | % |  | $ | 139.8 |  |  | $ | 15.3 |  |  |  | 10.9 | % |

[0000950123-11-068114:8k_2_02:73]
|  |  | For the Six Months Ended June 30, 2011 |  |  | For the Six Months Ended June 30, 2010 |  |
|  |  |  |  |  |  |  |  |  |  | Segment |  |  |  |  |  |  |  |  |  |  | Segment |  |
|  |  | Net |  |  | Segment |  |  | Profit |  |  | Net |  |  | Segment |  |  | Profit |  |
|  |  | Sales |  |  | Profit |  |  | Margin |  |  | Sales |  |  | Profit |  |  | Margin |  |
| Refrigeration Segment, as reported |  | $ | 392.6 |  |  | $ | 35.0 |  |  |  | 8.9 | % |  | $ | 271.2 |  |  | $ | 30.2 |  |  |  | 11.1 | % |
| Less: Kysor/Warren acquisition |  |  | (94.1 | ) |  |  | 1.6 |  |  |  | 1.7 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Refrigeration Segment, organic |  | $ | 298.5 |  |  | $ | 36.6 |  |  |  | 12.3 | % |  | $ | 271.2 |  |  | $ | 30.2 |  |  |  | 11.1 | % |

[0000950123-11-068114:8k_2_02:74]
Reconciliation of Operational Working Capital, a Non-GAAP Measure, to GAAP Balance Sheet Line
Items

[0000950123-11-068114:8k_2_02:75]
|  |  |  |  |  |  | June 30, |  |  |  |  |  |  | June 30, |  |
|  |  |  |  |  |  | 2011 |  |  |  |  |  |  | 2010 |  |
|  |  | June 30, |  |  | Trailing |  |  | June 30, |  |  | Trailing |  |
|  |  | 2011 (c) |  |  | 12 Mo. Avg. (c) |  |  | 2010 |  |  | 12 Mo. Avg. |  |
| Accounts and Notes Receivable, Net |  | $ | 481.5 |  |  |  |  |  |  | $ | 458.0 |  |  |  |  |  |
| Asset Securitization |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Allowance for Doubtful Accounts |  |  | 13.3 |  |  |  |  |  |  |  | 16.0 |  |  |  |  |  |
| Accounts and Notes Receivable, Gross |  |  | 494.8 |  |  | $ | 416.7 |  |  |  | 474.0 |  |  | $ | 404.6 |  |
| Inventories |  |  | 424.3 |  |  |  |  |  |  |  | 338.4 |  |  |  |  |  |
| Excess of Current Cost Over Last-in, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| First-out |  |  | 71.1 |  |  |  |  |  |  |  | 71.6 |  |  |  |  |  |
| Inventories as Adjusted |  |  | 495.4 |  |  |  | 443.0 |  |  |  | 410.0 |  |  |  | 369.4 |  |
| Accounts Payable |  |  | (345.9 | ) |  |  | (291.4 | ) |  |  | (314.7 | ) |  |  | (273.5 | ) |
| Operating Working Capital (a) |  |  | 644.3 |  |  |  | 568.3 |  |  |  | 569.3 |  |  |  | 500.5 |  |
| Net Sales, Trailing Twelve Months (b) |  |  | 3,110.8 |  |  |  | 3,110.8 |  |  |  | 2,999.2 |  |  |  | 2,999.2 |  |
| Operational Working Capital Ratio (a / b) |  |  | 20.7 | % |  |  | 18.3 | % |  |  | 19.0 | % |  |  | 16.7 | % |

[0000950123-11-068114:8k_2_02:76]
| (c) |  | Excludes the impact of the Kysor/Warren acquisition completed in January 2011. Including the impact of the Kysor/Warren acquisition to the June 30, 2011 operational working capital items above would increase Accounts and Notes Receivable, Gross from $494.8 to $541.3, Inventories as Adjusted from $495.4 to $532.2 and Accounts Payable from $(345.9) to $(371.8). Net Sales, Trailing Twelve Months would increase $94.1 (representing approximately five and a half months of Net Sales) to $3,204.9 resulting in an Operational Working Capital Ratio of 21.9%. |
