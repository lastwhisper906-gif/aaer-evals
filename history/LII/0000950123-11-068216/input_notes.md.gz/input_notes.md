# LII notes — 0000950123-11-068216


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950123-11-068216:notes:1]
[same as prior period, unchanged from 0000950123-11-039069:notes:1]

[0000950123-11-068216:notes:2]
[same as prior period, unchanged from 0000950123-11-039069:notes:2]

[0000950123-11-068216:notes:3]
[same as prior period, unchanged from 0000950123-11-039069:notes:3]

[0000950123-11-068216:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2011, the accompanying
   unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2011
   and 2010, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months
   ended June 30, 2011 and 2010 should be read in conjunction with our audited consolidated financial
   statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31,
   2010. The accompanying unaudited consolidated financial statements have been prepared in
   accordance with generally accepted accounting principles (“GAAP”) for interim financial information
   and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying
   consolidated financial statements contain all material adjustments, consisting principally of
   normal recurring adjustments, necessary for a fair presentation of our financial position, results
   of operations and cash flows. Certain information and footnote disclosures normally included in
   financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to
   applicable rules and regulations, although we believe that the disclosures herein are adequate to
   make the information presented not misleading. The operating results for the interim periods are
   not necessarily indicative of the results that may be expected for a full year.

[0000950123-11-068216:notes:5]
[same as prior period, unchanged from 0000950123-11-039069:notes:5]

[0000950123-11-068216:notes:6]
[same as prior period, unchanged from 0000950123-11-039069:notes:6]

[0000950123-11-068216:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about
   future events. These estimates and the underlying assumptions affect the amounts of assets and
   liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of
   revenues and expenses. Such estimates include the valuation of accounts receivable, inventories,
   goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations,
   indemnifications, and assumptions used in the calculation of income taxes, pension and
   postretirement medical benefits, among others. These estimates and assumptions are based on
   management’s best estimates and judgment.

[0000950123-11-068216:notes:8]
[same as prior period, unchanged from 0000950123-11-039069:notes:8]

[0000950123-11-068216:notes:9]
Reclassifications

[0000950123-11-068216:notes:10]
Certain prior year amounts have been reclassified to conform to the current year presentation.

[0000950123-11-068216:notes:11]
New Accounting Pronouncements

[0000950123-11-068216:notes:12]
In June 2011, the Financial Accounting Standards Board (“FASB”) issued Accounting
   Standards Update (“ASU”) No. 2011-05, Comprehensive Income (Topic 220): Presentation of
   Comprehensive Income (“ASU 2011-05”). This ASU eliminates the option to present the components of
   other comprehensive income as part of the statement of changes in stockholders’ equity. Rather, it
   gives an entity the choice to present the components of net income and other
   comprehensive income in either a single continuous statement or two separate but consecutive
   statements. Companies will continue to present reclassification adjustments from other
   comprehensive income to
   net income on the face of the financial statements. The components of comprehensive
   income and timing of reclassification of an item to net income do not change with this update. ASU
   2011-05 requires retrospective application and is effective for annual and interim periods
   beginning after December 15, 2011. Early adoption is permitted. We are currently evaluating which
   presentation to apply and will include the new presentation in the first quarter of 2012.

[0000950123-11-068216:notes:13]
In April 2011, the FASB issued ASU No. 2011-02, Receivables (Topic 310): A Creditor’s
   Determination of Whether a Restructuring Is a Troubled Debt Restructuring (“ASU 2011-02”). This ASU
   provides additional guidance clarifying when the restructuring of a receivable should be considered
   a troubled debt restructuring. The additional guidance this update provides is for determining
   whether a creditor has granted a concession and whether the debtor is experiencing financial
   difficulty. ASU 2011-02 also ends the deferral of activity-based disclosures related to troubled
   debt restructurings. This ASU should be applied retrospectively and is effective for interim and
   annual periods beginning on or after June 15, 2011. Early adoption is permitted. We are currently
   evaluating the effect of this ASU and do not anticipate a material impact on our financial
   statements and related disclosures. We will adopt ASU 2011-02 in the third quarter of 2011.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-068216:notes:14]
[same as prior period, unchanged from 0000950123-11-039069:notes:9]

[0000950123-11-068216:notes:15]
[same as prior period, unchanged from 0000950123-11-039069:notes:10]

[0000950123-11-068216:notes:16]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Finished goods |  | $ | 318.0 |  |  | $ | 213.7 |  |
| Work in process |  |  | 16.9 |  |  |  | 6.5 |  |
| Raw materials and repair parts |  |  | 197.3 |  |  |  | 137.0 |  |
|  |  |  | 532.2 |  |  |  | 357.2 |  |
| Excess of current cost over last-in, first-out cost and other items |  |  | (72.1 | ) |  |  | (71.0 | ) |
| Total inventories, net |  | $ | 460.1 |  |  | $ | 286.2 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950123-11-068216:notes:17]
[same as prior period, unchanged from 0000950123-11-039069:notes:12]

[0000950123-11-068216:notes:18]
On January 14, 2011, we acquired substantially all the assets of the Kysor/Warren business
   from The Manitowoc Company. Kysor/Warren is a leading manufacturer of refrigerated systems and
   display cases for supermarkets throughout North America and is included in our Refrigeration
   Segment. The total consideration for the acquisition was $143.3 million, including post-closing
   purchase price working capital adjustments. In connection with this acquisition, we recorded
   goodwill of $42.0 million and intangible assets of $33.9 million. The intangible assets consisted
   of the following: trade names of $5.0 million with indefinite lives, customer relationships of
   $26.7 million with 11 to 12 year lives, and other intangibles of $2.2 million with lives ranging
   from one to eight years. We paid more than the fair value of the underlying net assets as a result
   of expected operational synergies. The entire $42.0 million of goodwill is expected to be
   deductible for tax purposes. The initial accounting for this acquisition is substantially
   complete with the exception of additional minor adjustments as allowed under the purchase
   agreement. Overall, the acquisition would not have had a significant impact on our historical
   results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950123-11-068216:notes:19]
[same as prior period, unchanged from 0000950123-11-039069:notes:14]

[0000950123-11-068216:notes:20]
The changes in the carrying amount of goodwill for the first half of 2011, in total and by
   segment, are as follows (in millions):

[0000950123-11-068216:notes:21]
|  |  | Balance at |  |  |  |  |  |  |  |  |  |  | Balance at |  |
|  |  | December 31, |  |  | Acquisitions/ |  |  |  |  |  |  | June 30, |  |
|  |  | 2010 |  |  | (Dispositions) |  |  |  |  |  |  | 2011 |  |
| Segment: |  | Goodwill |  |  | (2) |  |  | Other(3) |  |  | Goodwill |  |
| Residential Heating & Cooling |  | $ | 33.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 33.7 |  |
| Commercial Heating & Cooling |  |  | 30.0 |  |  |  | — |  |  |  | 1.6 |  |  |  | 31.6 |  |
| Service Experts(1) |  |  | 116.6 |  |  |  | 2.9 |  |  |  | 3.9 |  |  |  | 123.4 |  |
| Refrigeration |  |  | 91.5 |  |  |  | 42.0 |  |  |  | 3.7 |  |  |  | 137.2 |  |
|  |  | $ | 271.8 |  |  | $ | 44.9 |  |  | $ | 9.2 |  |  | $ | 325.9 |  |

[0000950123-11-068216:notes:22]
| (1) |  | Service Experts goodwill includes accumulated impairment losses of $208.0 million from prior periods with no impairment losses in the current year. |
| (2) |  | During the second quarter of 2011, our Service Experts segment acquired a company, which resulted in additional goodwill of $2.9 million. During the first quarter of 2011, our Refrigeration segment acquired Kysor/Warren which resulted in additional goodwill of $42.0 million. See Note 3 for more information on the Kysor/Warren acquisition. |
| (3) |  | Other consists primarily of changes in foreign currency translation rates. |

[0000950123-11-068216:notes:23]
We performed our annual goodwill impairment test in the first quarter of 2011 and no
   indications of impairment existed in the second quarter of 2011. Our fair values exceeded the
   carrying values for each of our reporting units in our annual test; therefore, we recognized no
   goodwill impairment for any of our reporting units.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950123-11-068216:notes:24]
[same as prior period, unchanged from 0000950123-11-039069:notes:19]

[0000950123-11-068216:notes:25]
[same as prior period, unchanged from 0000950123-11-039069:notes:20]

[0000950123-11-068216:notes:26]
[same as prior period, unchanged from 0000950123-11-039069:notes:21]

[0000950123-11-068216:notes:27]
We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of
   metal commodities used in our production processes. The hedging program includes the use of
   futures contracts. We enter into these contracts based on our hedging strategy, a dollar cost
   averaging strategy. As part of this strategy, a higher percentage of commodity price exposures are
   hedged near term with lower percentages hedged at future dates. This strategy provides us with
   protection against near-term price volatility. Upon entering into futures contracts, we lock in
   prices and are subject to derivative losses should the metal commodity prices decrease and gains
   should the prices increase.

[0000950123-11-068216:notes:28]
[same as prior period, unchanged from 0000950123-11-039069:notes:23]

[0000950123-11-068216:notes:29]
A portion of our debt bears interest at variable interest rates and therefore, we are subject
   to variability in cash paid for interest expense. In order to mitigate a portion of the risk, we
   use a hedging strategy to eliminate the variability of cash flows in the interest payments
   associated with the first $100 million outstanding under our revolving credit facility that is
   solely due to changes in the benchmark interest rate. This strategy allows us to fix a portion of
   our variable interest payments.

[0000950123-11-068216:notes:30]
[same as prior period, unchanged from 0000950123-11-039069:notes:25]

[0000950123-11-068216:notes:31]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar
   value of assets and liabilities arising in foreign currencies. Our objective for entering into
   foreign currency forward contracts is to mitigate the impact of short-term currency exchange rate
   movements on certain short-term intercompany
   transactions. In order to meet that objective, we periodically enter into foreign currency forward
   contracts that act as economic hedges against changes in foreign currency exchange rates. These
   forward contracts are not designated as hedges and generally expire within three months. By
   entering into these forward contracts, we lock in exchange rates that would otherwise cause losses
   should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0000950123-11-068216:notes:32]
[same as prior period, unchanged from 0000950123-11-039069:notes:27]

[0000950123-11-068216:notes:33]
We include gains or losses from our commodity cash flow hedges in accumulated other
   comprehensive income (“AOCI”). The gains or losses related to commodity price hedges are expected
   to be reclassified into earnings based on the prices of the commodities at the settlement dates.
   Assuming that commodity prices remain constant, $3.6
   million of derivative gains are expected to be
   reclassified into earnings within the next 12 months. Commodity futures contracts that are
   designated as cash flow hedges and are in place as of June 30, 2011 are scheduled to mature through
   November 2012.

[0000950123-11-068216:notes:34]
We also include gains or losses in AOCI from our $100 million pay-fixed, receive-variable
   interest rate swap with a financial institution at a fixed interest rate of 2.66%. The variable
   portion of the interest rate swap is tied to 1-Month LIBOR (the benchmark interest rate). On a
   monthly basis, the interest rates under both the interest rate swap and the underlying debt are
   reset, the swap is settled with the counterparty, and interest is paid. Assuming that the interest
   rate environment remains constant, $1.4 million of derivative losses are expected to be
   reclassified into earnings within the next 12 months. The interest rate swap expires October 12,
   2012.

[0000950123-11-068216:notes:35]
[same as prior period, unchanged from 0000950123-11-039069:notes:30]

[0000950123-11-068216:notes:36]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Commodity Price Hedges: |  |  |  |  |  |  |  |  |
| Gains included in AOCI, net of tax |  | $ | (3.7 | ) |  | $ | (11.7 | ) |
| Provision for income taxes |  |  | 2.1 |  |  |  | 6.7 |  |
| Interest Rate Swap: |  |  |  |  |  |  |  |  |
| Losses included in AOCI, net of tax |  | $ | 1.8 |  |  | $ | 2.3 |  |
| Benefit from income taxes |  |  | (1.1 | ) |  |  | (1.3 | ) |

[0000950123-11-068216:notes:37]
[same as prior period, unchanged from 0000950123-11-039069:notes:32]

[0000950123-11-068216:notes:38]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 18.6 |  |  |  | 18.5 |  |

[0000950123-11-068216:notes:39]
[same as prior period, unchanged from 0000950123-11-039069:notes:34]

[0000950123-11-068216:notes:40]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging
   strategy as derivatives designated as cash flow hedges. We elect not to designate these derivatives
   as cash flow hedges at the inception of the arrangement. We had the following outstanding commodity
   futures contracts not designated as cash flow hedges (in millions):

[0000950123-11-068216:notes:41]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 2.8 |  |  |  | 1.4 |  |
| Aluminum |  |  | 3.0 |  |  |  | 1.4 |  |

[0000950123-11-068216:notes:42]
[same as prior period, unchanged from 0000950123-11-039069:notes:37]

[0000950123-11-068216:notes:43]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Notional amounts: |  |  |  |  |  |  |  |  |
| Brazilian Real |  |  | 3.6 |  |  |  | 5.6 |  |
| Mexican Peso |  |  | 160.0 |  |  |  | 138.0 |  |
| Euros |  |  | 7.8 |  |  |  | 15.6 |  |
| British Pounds |  |  | 5.0 |  |  |  | 2.0 |  |

[0000950123-11-068216:notes:44]
[same as prior period, unchanged from 0000950123-11-039069:notes:39]

[0000950123-11-068216:notes:45]
[same as prior period, unchanged from 0000950123-11-039069:notes:40]

[0000950123-11-068216:notes:46]
|  |  | Fair Values of Derivative Instruments(1) |  |
|  |  | Derivatives Designated as |  |  | Derivatives Not Designated as |  |
|  |  | Hedging Instruments |  |  | Hedging Instruments |  |
|  |  | As of June 30, |  |  | As of December 31, |  |  | As of June 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 5.8 |  |  | $ | 17.4 |  |  | $ | 0.3 |  |  | $ | 1.4 |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.4 |  |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | — |  |  |  | 1.3 |  |  |  | — |  |  |  | 0.1 |  |
| Total Assets |  | $ | 5.8 |  |  | $ | 18.7 |  |  | $ | 0.7 |  |  | $ | 1.7 |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | $ | 2.2 |  |  | $ | 2.2 |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  |  | 0.7 |  |  |  | 1.4 |  |  |  | — |  |  |  | — |  |
| Total Liabilities |  | $ | 2.9 |  |  | $ | 3.6 |  |  | $ | 0.1 |  |  | $ | — |  |

[0000950123-11-068216:notes:47]
[same as prior period, unchanged from 0000950123-11-039069:notes:42]

[0000950123-11-068216:notes:48]
| Derivatives in Cash Flow Hedging Relationships |  |
|  |  | For the Three Months |  |  | For the Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Amount of Loss or (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(1) |  | $ | (4.7 | ) |  | $ | (4.8 | ) |  | $ | (9.9 | ) |  | $ | (7.6 | ) |
| Interest rate swap(2) |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 1.2 |  |  |  | 1.2 |  |
|  |  | $ | (4.1 | ) |  | $ | (4.2 | ) |  | $ | (8.7 | ) |  | $ | (6.4 | ) |
| Amount of (Gain) or Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(3) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (0.1 | ) |

[0000950123-11-068216:notes:49]
| Derivatives Not Designated as Hedging Instruments |  |
|  |  | For the Three Months |  |  | For the Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Amount of (Gain) or Loss Recognized in Income on Derivatives: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(3) |  | $ | 0.4 |  |  | $ | 1.0 |  |  | $ | 0.5 |  |  | $ | 0.6 |  |
| Foreign currency forward contracts(3) |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 1.4 |  |  |  | (0.8 | ) |
|  |  | $ | 0.8 |  |  | $ | 0.9 |  |  | $ | 1.9 |  |  | $ | (0.2 | ) |

[0000950123-11-068216:notes:50]
| (1) |  | The loss (gain) is recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations. |
| (2) |  | The loss (gain) is recorded in Interest expense, net in the accompanying Consolidated Statements of Operations. |
| (3) |  | The loss (gain) is recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-068216:notes:51]
[same as prior period, unchanged from 0000950123-11-039069:notes:46]

[0000950123-11-068216:notes:52]
As of June 30, 2011, we had approximately $1.1 million in total gross unrecognized tax
   benefits. Of this amount, $0.7 million (net of federal benefit on state issues), if recognized,
   would be recorded through the Consolidated Statement of Operations. As of June 30, 2011, we
   recognized $0.1 million (net of federal tax benefits) in interest and penalties in income tax
   expense in accordance with Financial Accounting Standards Board (“FASB”) Accounting Standards
   Codification (“ASC”) Topic 740.

[0000950123-11-068216:notes:53]
The IRS completed its examination of our consolidated tax returns for the years ended 2008 —
   2009 and reached a settlement on April 7, 2011, which resulted in an immaterial impact to the
   Consolidated Statements of Operations.

[0000950123-11-068216:notes:54]
We are currently under examination for our U.S. federal income taxes for 2010 and 2011 and are
   subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such
   as Australia, Belgium, France, Canada, and Germany. We are generally no longer subject to U.S.
   federal, state and local, or non-U.S. income tax examinations by taxing authorities for years
   before 2005.

[0000950123-11-068216:notes:55]
Since January 1, 2011, numerous states including Arizona, Illinois, New Jersey, Indiana and
   Michigan have enacted legislation effective for tax years beginning on or after January 1, 2011,
   including changes to rates, to apportionment methods and to overall taxation systems. We believe
   any adjustments will be immaterial.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-068216:notes:56]
7. Commitments and Contingencies:

[0000950123-11-068216:notes:57]
We are subject to contingencies that arise in the normal course of business, including product
   warranties and other product related contingencies, pending litigation, environmental matters and
   other guarantees or claims.

[0000950123-11-068216:notes:58]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to provide protection against claims relating to contingencies such as workers’
   compensation, general liability, product liability, property damage, aviation liability, directors’
   and officers’ liability, auto liability, physical damage and other exposures. Self-insurance
   expense and liabilities are actuarially determined based on our historical claims information, as
   well as industry factors and trends. Because we have a captive insurance company, we are required
   to maintain specified levels of liquid assets from which we must pay claims. The majority of our
   self-insured risks (excluding auto liability and physical damage) will be paid over an extended
   period of time. There have been no material changes in our insurance liability since our latest
   fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our
   large deductible or captive insurance plans. The self-insurance liabilities recorded in Accrued
   expenses in the accompanying Consolidated Balance Sheets were $66.5 million and $61.3 million as of
   June 30, 2011 and December 31, 2010, respectively.

[0000950123-11-068216:notes:59]
Product Warranties and Product Related Contingencies

[0000950123-11-068216:notes:60]
Total liabilities for estimated product warranty are included in the following captions on the
   accompanying Consolidated Balance Sheets (in millions):

[0000950123-11-068216:notes:61]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Accrued expenses |  | $ | 32.6 |  |  | $ | 31.2 |  |
| Other liabilities |  |  | 41.4 |  |  |  | 44.3 |  |
|  |  | $ | 74.0 |  |  | $ | 75.5 |  |

[0000950123-11-068216:notes:62]
The changes in total product warranty liabilities for the first half of 2011 were as follows
   (in millions):

[0000950123-11-068216:notes:63]
| Total warranty liability as of December 31, 2010 |  | $ | 75.5 |  |
| Payments made in 2011 |  |  | (13.9 | ) |
| Changes resulting from issuance of new warranties |  |  | 13.3 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (2.7 | ) |
| Changes in foreign currency translation rates and other |  |  | 1.8 |  |
| Total warranty liability as of June 30, 2011 |  | $ | 74.0 |  |

[0000950123-11-068216:notes:64]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete re-evaluation of our heating, ventilation and
   air conditioning (“HVAC”) warranty liabilities. As a result of this re-evaluation, we decreased our
   warranty liability by $2.5 million.

[0000950123-11-068216:notes:65]
We incur the risk of liability claims for the installation and service of heating and air
   conditioning products, and we maintain liabilities for those claims that we self-insure. We are
   involved in various claims and lawsuits related to our products. Our product liability insurance
   policies have limits that, if exceeded, may result in substantial costs that could have an adverse
   effect on our results of operations. In addition, warranty claims are not covered by our product
   liability insurance and certain product liability claims also may not be covered by our product
   liability insurance. There have been no material changes in the circumstances that affect our
   product warranties since our latest fiscal year-end.

[0000950123-11-068216:notes:66]
We may also incur costs related to our products that may not be covered under our warranties
   and are not covered by insurance, and we may, from time to time, repair or replace installed
   products experiencing quality issues in order to satisfy our customers and to protect our brand.
   These product quality issues may be caused by vendor-supplied components that fail to meet required
   specifications.

[0000950123-11-068216:notes:67]
In addition to normal product warranty, we identified a product quality issue in a heating and
   cooling product line produced in 2006 and 2007 that we believe resulted from a vendor-supplied
   materials quality issue. The expense for this product quality issue, and the related liability, is
   not included in the above tables related to our estimated warranty liabilities. We did not incur
   any additional expense in the first six months of 2011; however, we may incur additional charges in
   the future as more information becomes available. We decreased this liability by $1.4 million in
   the second quarter of 2011 to adjust the estimated claim cost based on historical claims paid. The
   changes in the accrued product quality issue for the first half of 2011 were as follows (in
   millions):

[0000950123-11-068216:notes:68]
| Total accrued product quality issue as of December 31, 2010 |  | $ | 16.0 |  |
| Product quality claims |  |  | (3.7 | ) |
| Changes in estimates associated with pre-existing liabilities |  |  | (1.4 | ) |
| Total accrued product quality issue as of June 30, 2011 |  | $ | 10.9 |  |

[0000950123-11-068216:notes:69]
We estimate the costs to settle pending litigation based on experience involving similar
   claims and specific facts known. We do not believe that any current or pending or threatened
   litigation will have a material adverse effect on our financial position. Litigation and
   arbitration, however, involve uncertainties and it is possible that the eventual outcome of
   litigation could adversely affect our results of operations for a particular period.

[0000950123-11-068216:notes:70]
We were the defendant in a class action lawsuit related to certain hearth products we produced
   and sold that claimed such products are hazardous and that consumers were not adequately warned.
   On August 23, 2010, the Company and plaintiffs entered into a binding Memorandum of Understanding
   (“MOU”) and reached tentative terms for settlement of the case. At the parties’ request, the court
   stayed the lawsuit shortly after the MOU was signed. On June 10, 2011, the litigation of this
   matter concluded when the court issued its Order Granting Final Approval of Class Settlement; Final
   Judgment and Order of Dismissal. We had $9.4 million in expenses to date related to this matter
   and made minor adjustments to the reserve in the second quarter of 2011.

[0000950123-11-068216:notes:71]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We were in compliance with these financial covenants as of June 30, 2011.


## us-gaap:DebtDisclosureTextBlock

[0000950123-11-068216:notes:72]
8. Lines of Credit and Financing Arrangements:

[0000950123-11-068216:notes:73]
The following tables summarize our outstanding debt obligations and the classification in the
   accompanying Consolidated Balance Sheets (in millions):

[0000950123-11-068216:notes:74]
|  |  | As of June 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 6.7 |  |  | $ | 1.4 |  |
| Total short-term debt |  | $ | 6.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt: |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.8 |  |  |  | 17.0 |  |
| Domestic revolving credit facility |  |  | 354.0 |  |  |  | 100.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 570.8 |  |  | $ | 317.0 |  |
| Total debt |  | $ | 577.9 |  |  | $ | 319.0 |  |

[0000950123-11-068216:notes:75]
Short-Term Debt

[0000950123-11-068216:notes:76]
Foreign Obligations

[0000950123-11-068216:notes:77]
Through several of our foreign subsidiaries, we have $4.1 million in committed combined
   foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We
   had $4.1 million and $10.1 million of available capacity as of June 30, 2011 and December 31, 2010,
   respectively. Our foreign obligations of $6.7 million represented borrowings under non-committed
   facilities.

[0000950123-11-068216:notes:78]
Asset Securitization

[0000950123-11-068216:notes:79]
Under a revolving period asset securitization arrangement (“ASA”), we are eligible to sell
   beneficial interests in a portion of our trade accounts receivable to participating financial
   institutions for cash. The arrangement is subject to renewal and contains a provision whereby we
   retain the right to repurchase all of the outstanding beneficial interests transferred. Our
   continued involvement with the transferred assets includes servicing, collection and administration
   of the transferred beneficial interests. The sale of the beneficial interests in our trade
   accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance
   Sheets and proceeds received are included in cash flows from financing activities in the
   accompanying Consolidated Statements of Cash Flows. The
   ASA provides for a maximum securitization amount of $100.0 million or 100% of the net pool balance
   as defined by the ASA. However, eligibility for securitization is limited based on the amount and
   quality of the qualifying accounts receivable and is calculated monthly. The beneficial interest
   sold cannot exceed the maximum amount even if our qualifying accounts receivable is greater than
   the maximum amount at any point in time. During the second quarter, the average amount of
   beneficial interest sold under the ASA was $60.2 million. We did not have any beneficial interest
   sold as of June 30, 2011. The eligible amounts available and beneficial interests sold were as
   follows (in millions):

[0000950123-11-068216:notes:80]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 100.0 |  |  | $ | 100.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 100.0 |  |  | $ | 100.0 |  |

[0000950123-11-068216:notes:81]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 0.75%. The rate
   as of June 30, 2011 was 1.00% and the rate at December 31, 2010 was 1.06%. The unused fee is based
   on 102% of the maximum available amount less the beneficial interest sold and calculated at a
   0.375% fixed rate throughout the term of the agreement. We recorded these fees in Selling, General
   and Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):

[0000950123-11-068216:notes:82]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |

[0000950123-11-068216:notes:83]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our domestic revolving credit facility and
   senior unsecured notes. The administrative agent under the ASA is also a participant in our
   domestic revolving credit facility. The participating financial institution has an investment grade
   credit rating and we continue to evaluate its credit rating. We have no reason to believe it will
   not perform under the ASA. As of June 30, 2011, we were in compliance with all covenant
   requirements.

[0000950123-11-068216:notes:84]
Long-Term Debt

[0000950123-11-068216:notes:85]
Domestic Revolving Credit Facility

[0000950123-11-068216:notes:86]
Under the $650 million domestic revolving credit facility, we had outstanding borrowings of
   $354.0 million and $77.5 million committed to standby letters of credit as of June 30, 2011.
   Subject to covenant limitations, $218.5 million was available for future borrowings. Included in
   this facility is a subfacility for swingline loans of up to $50 million of which $29 million was
   outstanding at June 30, 2011. This domestic revolving credit facility provides for issuance of
   letters of credit for the full amount of the credit facility and matures in October 2012.

[0000950123-11-068216:notes:87]
Our weighted average borrowing rate on the facility was as follows:

[0000950123-11-068216:notes:88]
|  |  | As of June 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Weighted average borrowing rate |  |  | 1.01 | % |  |  | 0.96 | % |

[0000950123-11-068216:notes:89]
Our domestic revolving credit facility contains financial covenants relating to leverage
   and interest coverage. Other covenants contained in the domestic revolving credit facility
   restrict, among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to
   Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net
   Interest Expense Ratio. The required ratios under our domestic revolving credit facility as of
   June 30, 2011 are detailed below:

[0000950123-11-068216:notes:90]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |

[0000950123-11-068216:notes:91]
Our domestic revolving credit facility contains customary events of default. These events of
   default include nonpayment of principal or interest, breach of covenants or other restrictions or
   requirements, default on certain
   other indebtedness or receivables securitizations (cross default),
   and bankruptcy. A cross default under our revolving credit facility could occur if:

[0000950123-11-068216:notes:92]
|  | • |  | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $40.0 million; or |
|  | • |  | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $40.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0000950123-11-068216:notes:93]
Each of our major debt agreements contains provisions by which a default under one agreement
   causes a default in the others (a cross default). If a cross default under the revolving credit
   facility, our senior unsecured notes, or our ASA were to occur, it could have a wider impact on our
   liquidity than might otherwise occur from a default of a single debt instrument or lease
   commitment.

[0000950123-11-068216:notes:94]
If any event of default occurs and is continuing, lenders with a majority of the aggregate
   commitments may require the administrative agent to terminate our right to borrow under our
   domestic revolving credit facility and accelerate amounts due under our domestic revolving credit
   facility (except for a bankruptcy event of default, in which case such amounts will automatically
   become due and payable and the lenders’ commitments will automatically terminate). As of June 30,
   2011, we were in compliance with all covenant requirements.

[0000950123-11-068216:notes:95]
Senior Unsecured Notes

[0000950123-11-068216:notes:96]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering.
   Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per
   annum. These notes mature on May 15, 2017.

[0000950123-11-068216:notes:97]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries
   that guarantee payment by us of any indebtedness under our domestic revolving credit facility. The
   indenture governing the notes contains covenants that, among other things, limit our ability and
   the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale
   and leaseback transactions; enter into certain mergers, consolidations and transfers of
   substantially all of our assets; and transfer certain properties. The indenture also contains a
   cross default provision which is triggered if we default on other debt of at least $75 million in
   principal which is then accelerated, and such acceleration is not rescinded within 30 days of the
   notice date. As of June 30, 2011, we were in compliance with all covenant requirements and these
   covenants have not changed from December 31, 2010.

[0000950123-11-068216:notes:98]
Credit Rating

[0000950123-11-068216:notes:99]
At June 30, 2011, our senior credit ratings were Baa3, with a stable outlook, and BBB-, with a
   stable outlook by Moody’s and Standard & Poor’s Rating Group (“S&P”), respectively.

[0000950123-11-068216:notes:100]
Other Financing Arrangements

[0000950123-11-068216:notes:101]
In the first quarter 2010, our captive insurance subsidiary entered into an agreement in which
   cash was placed into a trust for the benefit of a third-party insurance provider. The purpose of
   the trust is to pay workers compensation claims for policy years 2003 — 2009 until the liabilities
   are fully extinguished. These policies were written by the third-party insurance provider, and
   then reinsured by our captive insurance subsidiary. In the second quarter of 2011, we changed how
   these claims were secured. Substantially all claims for the workers compensation
   claims for policy years 2003-2009 are now secured by standby letters of credit. As of June
   30, 2011 and December 31, 2010, we had $0.5 million and $12.2 million, respectively, in Restricted
   Cash on the accompanying Consolidated Balance Sheets to pay these claims.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950123-11-068216:notes:102]
[same as prior period, unchanged from 0000950123-11-039069:notes:95]

[0000950123-11-068216:notes:103]
[same as prior period, unchanged from 0000950123-11-039069:notes:96]

[0000950123-11-068216:notes:104]
|  |  | For the Three Months Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
|  |  | Pension Benefits |  |  | Other Benefits |  |
| Service cost |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |
| Interest cost |  |  | 4.5 |  |  |  | 4.4 |  |  |  | 0.3 |  |  |  | 0.2 |  |
| Expected return on plan assets |  |  | (4.8 | ) |  |  | (4.9 | ) |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.1 |  |  |  | 0.1 |  |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Amortization of net loss |  |  | 1.7 |  |  |  | 2.1 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Settlements or curtailments |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total net periodic pension cost |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 0.3 |  |  | $ | 0.2 |  |

[0000950123-11-068216:notes:105]
|  |  | For the Six Months Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
|  |  | Pension Benefits |  |  | Other Benefits |  |
| Service cost |  | $ | 2.7 |  |  | $ | 2.5 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |
| Interest cost |  |  | 9.0 |  |  |  | 8.8 |  |  |  | 0.5 |  |  |  | 0.4 |  |
| Expected return on plan assets |  |  | (9.5 | ) |  |  | (9.7 | ) |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.2 |  |  |  | 0.2 |  |  |  | (1.0 | ) |  |  | (1.0 | ) |
| Amortization of net loss |  |  | 3.5 |  |  |  | 4.3 |  |  |  | 0.6 |  |  |  | 0.6 |  |
| Settlements or curtailments |  |  | 1.6 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total net periodic pension cost |  | $ | 7.5 |  |  | $ | 6.1 |  |  | $ | 0.5 |  |  | $ | 0.4 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950123-11-068216:notes:106]
[same as prior period, unchanged from 0000950123-11-039069:notes:98]

[0000950123-11-068216:notes:107]
[same as prior period, unchanged from 0000950123-11-039069:notes:99]

[0000950123-11-068216:notes:108]
|  |  | For the Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net income |  | $ | 37.8 |  |  | $ | 46.7 |  |
| Foreign currency translation adjustments, net |  |  | 27.7 |  |  |  | (18.7 | ) |
| Derivatives and other, net of tax benefit of $4.4 and $5.2 in 2011 and 2010, respectively. |  |  | (10.6 | ) |  |  | (5.6 | ) |
| Comprehensive income |  | $ | 54.9 |  |  | $ | 22.4 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-068216:notes:109]
[same as prior period, unchanged from 0000950123-11-039069:notes:101]

[0000950123-11-068216:notes:110]
The Lennox International Inc. 2010 Incentive Plan, as amended and restated provides for
   various long-term incentive awards, which include stock options, performance share units,
   restricted stock units and stock appreciation rights. Net stock-based compensation expense
   recognized was as follows (in millions):

[0000950123-11-068216:notes:111]
|  |  | For the Three Months |  |  | For the Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net stock-based compensation expense |  | $ | 4.2 |  |  | $ | 3.4 |  |  | $ | 9.1 |  |  | $ | 7.7 |  |

[0000950123-11-068216:notes:112]
[same as prior period, unchanged from 0000950123-11-039069:notes:104]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950123-11-068216:notes:113]
[same as prior period, unchanged from 0000950123-11-039069:notes:105]

[0000950123-11-068216:notes:114]
As part of our strategic priorities of manufacturing and sourcing excellence and expense
   reduction, we initiated various manufacturing rationalization actions designed to lower our cost
   structure. We expanded these expense reductions across the organization by initiating a number of
   activities to rationalize and reorganize various support
   and administrative functions.
   Restructuring charges are not included in our calculation of segment profit (loss), see Note 14 for
   further discussion. Detailed below are the restructuring activities that we anticipate incurring
   additional expense in 2011.

[0000950123-11-068216:notes:115]
[same as prior period, unchanged from 0000950123-11-039069:notes:107]

[0000950123-11-068216:notes:116]
[same as prior period, unchanged from 0000950123-11-039069:notes:108]

[0000950123-11-068216:notes:117]
We began to exit certain Refrigeration manufacturing operations in Milperra, Australia in
   2010, specifically our OEM coil manufacturing and contract coil. In the first quarter of 2010, we
   began to exit the OEM coil manufacturing with total expected restructuring charges of $5.3 million
   composed of $3.9 million in severance, $1.2 million in asset impairment charges, and $0.2 million
   in other charges. We reversed approximately $0.5 million in severance in the first half of 2011 to
   adjust estimated charges to actual. This activity was substantially complete in 2010. We initiated
   the restructuring activities related to exiting contract coil manufacturing in the third quarter of
   2010. The total expected restructuring charges related to this activity were $4.8 million composed
   of $3.1 million in severance, $0.4 million in asset impairment and accelerated depreciation, and
   $1.3 million in other charges. In the first half of 2011, we recognized $0.7 million in other plant
   closure costs related to these restructuring activities.

[0000950123-11-068216:notes:118]
[same as prior period, unchanged from 0000950123-11-039069:notes:110]

[0000950123-11-068216:notes:119]
We began to reorganize certain administrative functions and the management structure of our
   Service Experts business in 2010 and initiated two actions. The first action, started in the
   second quarter of 2010, was to reorganize the administrative operations of an acquired company.
   This project was completed in 2010. The second action, initiated in the fourth quarter of 2010,
   was to reorganize the management structure of our Service Experts business. Expected restructuring
   charges for this project are $2.8 million and consist of $1.6 million in severance charges, $0.2
   million in lease termination costs, and $1.0 million in other restructuring costs. We anticipate
   this action to complete in the third quarter of 2011. We recognized $1.7 million in severance,
   lease termination and other costs in the first half of 2011.

[0000950123-11-068216:notes:120]
[same as prior period, unchanged from 0000950123-11-039069:notes:112]

[0000950123-11-068216:notes:121]
In the fourth quarter of 2009, we began to consolidate certain Refrigeration manufacturing
   operations located in Parets, Spain into our existing operations in Genas, France. This activity
   had total restructuring charges of $8.4 million, consisting of $6.1 million in severance, $1.2
   million in asset impairment and equipment moves, and $1.1 million in other charges, and was
   substantially complete by the fourth quarter of 2010.

[0000950123-11-068216:notes:122]
[same as prior period, unchanged from 0000950123-11-039069:notes:114]

[0000950123-11-068216:notes:123]
We completed the consolidation of certain manufacturing operations from Mions, France into our
   Longvic, France operations in the first quarter of 2010. This activity had total restructuring
   charges of $6.3 million which consisted primarily of severance charges. We reversed $0.1 million
   in severance charges in the first half of 2011 to adjust estimated charges to actual.

[0000950123-11-068216:notes:124]
[same as prior period, unchanged from 0000950123-11-039069:notes:116]

[0000950123-11-068216:notes:125]
Included in our 2009 and Prior Plans was a consolidation of our manufacturing operations from
   Blackville, South
   Carolina into our Orangeburg, South Carolina and Saltillo, Mexico operations. The
   consolidation is expected to be complete by the fourth quarter of 2011 with expected total
   restructuring charges of $13.7 million. These charges consist of $3.0 million in severance, $7.1
   million in equipment moves, asset impairment and accelerated depreciation, and $3.6 million in
   other costs. We recognized $0.6 million in restructuring charges in the first half of 2011 related
   to other plant closure costs.

[0000950123-11-068216:notes:126]
[same as prior period, unchanged from 0000950123-11-039069:notes:118]

[0000950123-11-068216:notes:127]
In the fourth quarter of 2008, we commenced the transition of activities performed at our
   North American Parts Center in Des Moines, Iowa to other locations, including our North American
   Distribution Center in Marshalltown, Iowa. To date, we incurred $3.5 million, primarily severance
   costs, and we expect the total cost to be $4.4 million. The total expected costs of this project
   include $2.9 million in severance costs, $0.5 million in moving costs, and $1.0 million in other
   costs. In the first half of 2011, we recognized $0.3 million primarily in other restructuring
   charges.

[0000950123-11-068216:notes:128]
[same as prior period, unchanged from 0000950123-11-039069:notes:120]

[0000950123-11-068216:notes:129]
[same as prior period, unchanged from 0000950123-11-039069:notes:121]

[0000950123-11-068216:notes:130]
|  |  |  |  |  |  |  |  |  |  | Total |  |
|  |  | Charges |  |  | Charges |  |  | Charges |  |
|  |  | Incurred in |  |  | Incurred to |  |  | Expected to |  |
|  |  | 2011 |  |  | Date |  |  | be Incurred |  |
| Severance and related expense |  | $ | — |  |  | $ | 50.5 |  |  | $ | 50.7 |  |
| Asset write-offs and accelerated depreciation |  |  | 0.4 |  |  |  | 11.6 |  |  |  | 11.6 |  |
| Equipment moves |  |  | 0.3 |  |  |  | 1.5 |  |  |  | 2.2 |  |
| Lease termination |  |  | 0.2 |  |  |  | 2.6 |  |  |  | 2.6 |  |
| Other |  |  | 2.7 |  |  |  | 7.5 |  |  |  | 9.6 |  |
| Total |  | $ | 3.6 |  |  | $ | 73.7 |  |  | $ | 76.7 |  |

[0000950123-11-068216:notes:131]
[same as prior period, unchanged from 0000950123-11-039069:notes:123]

[0000950123-11-068216:notes:132]
|  |  |  |  |  |  |  |  |  |  | Total |  |
|  |  | Charges |  |  | Charges |  |  | Charges |  |
|  |  | Incurred in |  |  | Incurred to |  |  | Expected to |  |
|  |  | 2011 |  |  | Date |  |  | be Incurred |  |
| Residential Heating & Cooling |  | $ | 0.9 |  |  | $ | 16.5 |  |  | $ | 18.9 |  |
| Commercial Heating & Cooling |  |  | (0.1 | ) |  |  | 16.6 |  |  |  | 16.8 |  |
| Service Experts |  |  | 0.7 |  |  |  | 23.6 |  |  |  | 24.0 |  |
| Refrigeration |  |  | 2.1 |  |  |  | 5.5 |  |  |  | 5.5 |  |
| Corporate & Other |  |  | — |  |  |  | 11.5 |  |  |  | 11.5 |  |
| Total |  | $ | 3.6 |  |  | $ | 73.7 |  |  | $ | 76.7 |  |

[0000950123-11-068216:notes:133]
Restructuring reserves are included in Accrued Expenses in the accompanying Consolidated
   Balance Sheets. The table below details activity within the restructuring reserves for the first
   half of 2011 (in millions):

[0000950123-11-068216:notes:134]
|  |  | Balance as of |  |  | Charged |  |  |  |  |  |  | Non-Cash |  |  | Balance as of |  |
|  |  | December 31, |  |  | to |  |  | Cash |  |  | Utilization |  |  | June 30, |  |
| Description of Reserves |  | 2010 |  |  | Earnings |  |  | Utilization |  |  | and Other |  |  | 2011 |  |
| Severance and related expense |  | $ | 6.2 |  |  | $ | — |  |  | $ | (2.7 | ) |  | $ | — |  |  | $ | 3.5 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | (0.4 | ) |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 0.3 |  |  |  | (0.3 | ) |  |  | — |  |  |  | — |  |
| Lease termination |  |  | 0.3 |  |  |  | 0.2 |  |  |  | (0.3 | ) |  |  | — |  |  |  | 0.2 |  |
| Other |  |  | 0.7 |  |  |  | 2.7 |  |  |  | (3.4 | ) |  |  | — |  |  |  | — |  |
| Total restructuring reserves |  | $ | 7.2 |  |  | $ | 3.6 |  |  | $ | (6.7 | ) |  | $ | (0.4 | ) |  | $ | 3.7 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-068216:notes:135]
13. Earnings Per Share:

[0000950123-11-068216:notes:136]
Basic earnings per share are computed by dividing net income by the weighted-average number of
   common shares outstanding during the period. Diluted earnings per share are computed by dividing
   net income by the sum of the weighted-average number of shares and the number of equivalent shares
   assumed outstanding, if dilutive, under our stock-based compensation plans.

[0000950123-11-068216:notes:137]
The computations of basic and diluted earnings per share for Income from Continuing Operations
   were as follows (in millions, except per share data):

[0000950123-11-068216:notes:138]
|  |  | For the |  |  | For the |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net income |  | $ | 45.0 |  |  | $ | 48.3 |  |  | $ | 37.8 |  |  | $ | 46.7 |  |
| Add: Loss from discontinued operations |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.7 |  |
| Income from continuing operations |  | $ | 45.0 |  |  | $ | 48.7 |  |  | $ | 37.8 |  |  | $ | 47.4 |  |
| Weighted-average shares outstanding — basic |  |  | 53.2 |  |  |  | 55.1 |  |  |  | 53.4 |  |  |  | 55.6 |  |
| Effect of diluted securities attributable to stock-based payments |  |  | 1.1 |  |  |  | 1.2 |  |  |  | 1.1 |  |  |  | 1.2 |  |
| Weighted-average shares outstanding — diluted |  |  | 54.3 |  |  |  | 56.3 |  |  |  | 54.5 |  |  |  | 56.8 |  |
| Earnings per share from continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.85 |  |  | $ | 0.88 |  |  | $ | 0.71 |  |  | $ | 0.85 |  |
| Diluted |  | $ | 0.83 |  |  | $ | 0.86 |  |  | $ | 0.69 |  |  | $ | 0.83 |  |

[0000950123-11-068216:notes:139]
Stock appreciation rights were outstanding, but not included in the diluted earnings per share
   calculation because the assumed exercise of such rights would have been anti-dilutive. The details
   are as follows:

[0000950123-11-068216:notes:140]
|  |  | For the Six Months Ended June 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Number of shares |  |  | 464,314 |  |  |  | 546,289 |  |
| Price ranges per share |  | $ | 46.78 |  |  | $ | $36.94 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-068216:notes:141]
[same as prior period, unchanged from 0000950123-11-039069:notes:134]

[0000950123-11-068216:notes:142]
[same as prior period, unchanged from 0000950123-11-039069:notes:135]

[0000950123-11-068216:notes:143]
[same as prior period, unchanged from 0000950123-11-039069:notes:136]

[0000950123-11-068216:notes:144]
[same as prior period, unchanged from 0000950123-11-039069:notes:137]

[0000950123-11-068216:notes:145]
We use segment profit or loss as the primary measure of profitability to evaluate operating
   performance and to allocate capital resources. We define segment profit or loss as a segment’s
   income or loss from continuing operations before income taxes included in the accompanying
   Consolidated Statements of Operations excluding certain items. The reconciliation below details the
   items excluded.

[0000950123-11-068216:notes:146]
[same as prior period, unchanged from 0000950123-11-039069:notes:143]

[0000950123-11-068216:notes:147]
Net sales and segment profit (loss) by business segment, along with a reconciliation of
   segment profit (loss) to Income from Continuing Operations Before Income Taxes are shown below (in
   millions):

[0000950123-11-068216:notes:148]
|  |  | For the Three Months |  |  | For the Six Months Ended |  |
|  |  | Ended June 30, |  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 395.1 |  |  | $ | 413.4 |  |  | $ | 667.1 |  |  | $ | 697.6 |  |
| Commercial Heating & Cooling |  |  | 198.3 |  |  |  | 175.8 |  |  |  | 337.1 |  |  |  | 295.4 |  |
| Service Experts |  |  | 145.4 |  |  |  | 167.6 |  |  |  | 261.9 |  |  |  | 294.7 |  |
| Refrigeration |  |  | 217.5 |  |  |  | 139.8 |  |  |  | 392.6 |  |  |  | 271.2 |  |
| Eliminations (1) |  |  | (19.3 | ) |  |  | (24.5 | ) |  |  | (34.0 | ) |  |  | (42.7 | ) |
|  |  | $ | 937.0 |  |  | $ | 872.1 |  |  | $ | 1,624.7 |  |  | $ | 1,516.2 |  |
| Segment Profit (Loss)(2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 33.2 |  |  | $ | 52.5 |  |  | $ | 32.0 |  |  | $ | 59.6 |  |
| Commercial Heating & Cooling |  |  | 27.1 |  |  |  | 27.8 |  |  |  | 33.0 |  |  |  | 31.3 |  |
| Service Experts |  |  | 3.2 |  |  |  | 12.8 |  |  |  | (5.0 | ) |  |  | 8.2 |  |
| Refrigeration |  |  | 21.4 |  |  |  | 15.3 |  |  |  | 35.0 |  |  |  | 30.2 |  |
| Corporate and other |  |  | (11.6 | ) |  |  | (19.6 | ) |  |  | (26.0 | ) |  |  | (32.8 | ) |
| Eliminations (1) |  |  | 0.2 |  |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.2 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 73.5 |  |  |  | 88.5 |  |  |  | 68.7 |  |  |  | 96.3 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | (2.4 | ) |  |  | — |  |  |  | (2.4 | ) |  |  | — |  |
| Items in losses and other expenses, net that are excluded from segment profit (3) |  |  | 1.0 |  |  |  | 6.0 |  |  |  | 2.0 |  |  |  | 6.2 |  |
| Restructuring charges |  |  | 2.4 |  |  |  | 3.2 |  |  |  | 3.6 |  |  |  | 10.3 |  |
| Interest expense, net |  |  | 4.3 |  |  |  | 3.1 |  |  |  | 8.4 |  |  |  | 5.6 |  |
| Other expense, net |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 68.1 |  |  | $ | 76.1 |  |  | $ | 57.0 |  |  | $ | 74.1 |  |

[0000950123-11-068216:notes:149]
| (1) |  | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |
| (2) |  | We define segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: Excluding: |

[0000950123-11-068216:notes:150]
|  | • |  | Special product quality adjustments. |
|  | • |  | Items within Losses and Other Expenses, net that are noted in (3). |
|  | • |  | Restructuring charges. |
|  | • |  | Goodwill and equity method investment impairments. |
|  | • |  | Interest expense, net. |
|  | • |  | Other expense, net. |

[0000950123-11-068216:notes:151]
| (3) |  | Items in Losses and Other Expenses, net that are excluded from segment profit are net change in unrealized gains and/or losses on open futures contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |

[0000950123-11-068216:notes:152]
[same as prior period, unchanged from 0000950123-11-039069:notes:150]

[0000950123-11-068216:notes:153]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Total Assets |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 669.7 |  |  | $ | 519.8 |  |
| Commercial Heating & Cooling |  |  | 316.1 |  |  |  | 252.7 |  |
| Service Experts |  |  | 197.7 |  |  |  | 186.2 |  |
| Refrigeration |  |  | 590.0 |  |  |  | 389.7 |  |
| Corporate and other |  |  | 257.4 |  |  |  | 354.9 |  |
| Eliminations(1) |  |  | (11.9 | ) |  |  | (11.3 | ) |
| Total assets |  | $ | 2,019.0 |  |  | $ | 1,692.0 |  |

[0000950123-11-068216:notes:154]
| (1) |  | Eliminations consist of net intercompany receivables and intercompany profit included in inventory from products sold between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |


## us-gaap:FairValueDisclosuresTextBlock

[0000950123-11-068216:notes:155]
[same as prior period, unchanged from 0000950123-11-039069:notes:153]

[0000950123-11-068216:notes:156]
[same as prior period, unchanged from 0000950123-11-039069:notes:154]

[0000950123-11-068216:notes:157]
[same as prior period, unchanged from 0000950123-11-039069:notes:155]

[0000950123-11-068216:notes:158]
|  |  | Quoted Prices in Active Markets for |
|  |  | Identical Assets (Level 1) |
|  |  | As of June 30, |  | As of December 31, |
|  |  | 2011 |  | 2010 |
| Assets: |  |  |  |  |  |  |  |  |
| Investment in marketable equity securities (1) |  | $ | 13.7 |  |  | $ | 18.0 |  |

[0000950123-11-068216:notes:159]
[same as prior period, unchanged from 0000950123-11-039069:notes:157]

[0000950123-11-068216:notes:160]
[same as prior period, unchanged from 0000950123-11-039069:notes:158]

[0000950123-11-068216:notes:161]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net,
   accounts payable and other current liabilities approximate fair value due to the short maturities
   of these instruments. The fair values of each of our long-term debt instruments are based on the
   quoted market prices for the same issues or on the amount of future cash flows associated with each
   instrument using current market rates for debt instruments of similar maturities and credit risk.
   The fair values presented are estimates and are not necessarily indicative of amounts for which we
   could settle such instruments currently or indicative of our intent or ability to dispose of or
   liquidate them. The estimated fair value of our debt was as follows (in millions):

[0000950123-11-068216:notes:162]
|  |  | As of June 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Long-term debt (1) |  | $ | 366.7 |  |  | $ | 114.6 |  |
| Senior unsecured notes |  |  | 202.6 |  |  |  | 203.0 |  |

[0000950123-11-068216:notes:163]
| (1) |  | Long-term debt includes our domestic revolving credit facility, capital lease obligations, foreign obligations and any related current maturities. |


## us-gaap:ScheduleOfCondensedFinancialStatementsTextBlock

[0000950123-11-068216:notes:164]
[same as prior period, unchanged from 0000950123-11-039069:notes:162]

[0000950123-11-068216:notes:165]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the
   Company’s subsidiaries (the “Guarantor Subsidiaries”) while they are not by other subsidiaries (the
   “Non-Guarantor Subsidiaries”). As a result of the guarantee arrangements, we are required to
   present the following condensed consolidating financial statements. During the first quarter of
   2011, our guarantor and non-guarantor subsidiary structure changed as required by our credit
   facility due to the Kysor/Warren acquisition. Three subsidiaries previously classified as
   non-guarantor subsidiaries as of December 31, 2010 are now classified as guarantor subsidiaries as
   of June 30, 2011. These changes will be reflected in the condensed consolidating financial
   statements for periods after December 31, 2010.

[0000950123-11-068216:notes:166]
[same as prior period, unchanged from 0000950123-11-039069:notes:164]

[0000950123-11-068216:notes:167]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and
   Non-Guarantor Subsidiaries as of June 30, 2011 and December 31, 2010 and for the three and six
   months ended June 30, 2011 and 2010 are shown below:

[0000950123-11-068216:notes:168]
[same as prior period, unchanged from 0000950123-11-039069:notes:166]

[0000950123-11-068216:notes:169]
As of June 30, 2011

[0000950123-11-068216:notes:170]
[same as prior period, unchanged from 0000950123-11-039069:notes:168]

[0000950123-11-068216:notes:171]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 0.2 |  |  | $ | 27.5 |  |  | $ | 48.8 |  |  | $ | — |  |  | $ | 76.5 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 0.5 |  |  |  | — |  |  |  | 0.5 |  |
| Accounts and notes receivable, net |  |  | (799.3 | ) |  |  | 897.3 |  |  |  | 429.4 |  |  |  | (2.0 | ) |  |  | 525.4 |  |
| Inventories, net |  |  | — |  |  |  | 330.4 |  |  |  | 135.2 |  |  |  | (5.5 | ) |  |  | 460.1 |  |
| Deferred income taxes, net |  |  | 8.1 |  |  |  | 30.7 |  |  |  | 9.5 |  |  |  | (4.3 | ) |  |  | 44.0 |  |
| Other assets |  |  | 27.3 |  |  |  | 21.6 |  |  |  | 117.3 |  |  |  | (107.3 | ) |  |  | 58.9 |  |
| Total current assets |  |  | (763.7 | ) |  |  | 1,307.5 |  |  |  | 740.7 |  |  |  | (119.1 | ) |  |  | 1,165.4 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 263.0 |  |  |  | 84.1 |  |  |  | (0.1 | ) |  |  | 347.0 |  |
| GOODWILL |  |  | — |  |  |  | 111.7 |  |  |  | 214.2 |  |  |  | — |  |  |  | 325.9 |  |
| DEFERRED INCOME TAXES |  |  | (3.0 | ) |  |  | 80.1 |  |  |  | 23.3 |  |  |  | (13.1 | ) |  |  | 87.3 |  |
| OTHER ASSETS, net |  |  | 2,097.0 |  |  |  | 526.6 |  |  |  | 34.5 |  |  |  | (2,564.7 | ) |  |  | 93.4 |  |
| TOTAL ASSETS |  | $ | 1,330.3 |  |  | $ | 2,288.9 |  |  | $ | 1,096.8 |  |  | $ | (2,697.0 | ) |  | $ | 2,019.0 |  |

[0000950123-11-068216:notes:172]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 64.2 |  |  | $ | — |  |  | $ | 6.9 |  |  | $ | (64.4 | ) |  | $ | 6.7 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | — |  |  |  | 0.4 |  |
| Accounts payable |  |  | 9.6 |  |  |  | 250.6 |  |  |  | 102.9 |  |  |  | 8.7 |  |  |  | 371.8 |  |
| Accrued expenses |  |  | 7.1 |  |  |  | 217.6 |  |  |  | 103.8 |  |  |  | (28.9 | ) |  |  | 299.6 |  |
| Income taxes payable |  |  | 13.6 |  |  |  | 2.3 |  |  |  | 1.7 |  |  |  | (17.6 | ) |  |  | — |  |
| Total current liabilities |  |  | 94.5 |  |  |  | 470.9 |  |  |  | 215.3 |  |  |  | (102.2 | ) |  |  | 678.5 |  |
| LONG-TERM DEBT |  |  | 554.0 |  |  |  | 16.8 |  |  |  | 111.2 |  |  |  | (111.2 | ) |  |  | 570.8 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 15.7 |  |  |  | — |  |  |  | — |  |  |  | 15.7 |  |
| PENSIONS |  |  | — |  |  |  | 79.1 |  |  |  | 9.9 |  |  |  | — |  |  |  | 89.0 |  |
| OTHER LIABILITIES |  |  | 6.6 |  |  |  | 55.4 |  |  |  | 16.6 |  |  |  | (14.6 | ) |  |  | 64.0 |  |
| Total liabilities |  |  | 655.1 |  |  |  | 637.9 |  |  |  | 353.0 |  |  |  | (228.0 | ) |  |  | 1,418.0 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 675.2 |  |  |  | 1,651.0 |  |  |  | 743.8 |  |  |  | (2,469.0 | ) |  |  | 601.0 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,330.3 |  |  | $ | 2,288.9 |  |  | $ | 1,096.8 |  |  | $ | (2,697.0 | ) |  | $ | 2,019.0 |  |

[0000950123-11-068216:notes:173]
[same as prior period, unchanged from 0000950123-11-039069:notes:171]

[0000950123-11-068216:notes:174]
For the Three Months Ended June 30, 2011

[0000950123-11-068216:notes:175]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 744.9 |  |  | $ | 243.9 |  |  | $ | (51.8 | ) |  | $ | 937.0 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 556.7 |  |  |  | 184.2 |  |  |  | (51.6 | ) |  |  | 689.4 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 188.2 |  |  |  | 59.7 |  |  |  | (0.2 | ) |  |  | 247.6 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 130.7 |  |  |  | 44.4 |  |  |  | 0.1 |  |  |  | 175.2 |  |
| Losses (gains) and other expenses, net |  |  | 1.3 |  |  |  | (0.3 | ) |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | 0.9 |  |
| Restructuring charges |  |  | — |  |  |  | 2.5 |  |  |  | (0.1 | ) |  |  | — |  |  |  | 2.4 |  |
| (Income) loss from equity method investments |  |  | (55.1 | ) |  |  | (6.8 | ) |  |  | (2.6 | ) |  |  | 61.1 |  |  |  | (3.4 | ) |
| Operational income (loss) from continuing operations |  |  | 53.7 |  |  |  | 62.1 |  |  |  | 18.2 |  |  |  | (61.5 | ) |  |  | 72.5 |  |
| INTEREST EXPENSE, net |  |  | 4.0 |  |  |  | (1.0 | ) |  |  | 1.2 |  |  |  | 0.1 |  |  |  | 4.3 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 49.7 |  |  |  | 63.1 |  |  |  | 16.9 |  |  |  | (61.6 | ) |  |  | 68.1 |  |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (1.7 | ) |  |  | 19.5 |  |  |  | 5.3 |  |  |  | — |  |  |  | 23.1 |  |
| Net income (loss) |  | $ | 51.4 |  |  | $ | 43.6 |  |  | $ | 11.6 |  |  | $ | (61.6 | ) |  | $ | 45.0 |  |

[0000950123-11-068216:notes:176]
For the Six Months Ended June 30, 2011

[0000950123-11-068216:notes:177]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 1,260.8 |  |  | $ | 460.4 |  |  | $ | (96.5 | ) |  | $ | 1,624.7 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 959.5 |  |  |  | 349.6 |  |  |  | (97.2 | ) |  |  | 1,212.0 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 301.3 |  |  |  | 110.8 |  |  |  | 0.7 |  |  |  | 412.7 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 258.4 |  |  |  | 90.5 |  |  |  | — |  |  |  | 348.9 |  |
| Losses (gains) and other expenses, net |  |  | 2.2 |  |  |  | (1.2 | ) |  |  | (0.4 | ) |  |  | — |  |  |  | 0.6 |  |
| Restructuring charges |  |  | — |  |  |  | 3.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 3.6 |  |
| (Income) loss from equity method investments |  |  | (48.9 | ) |  |  | (5.7 | ) |  |  | (4.9 | ) |  |  | 53.6 |  |  |  | (5.9 | ) |
| Operational income (loss) from continuing operations |  |  | 46.6 |  |  |  | 46.6 |  |  |  | 25.2 |  |  |  | (52.9 | ) |  |  | 65.5 |  |
| INTEREST EXPENSE, net |  |  | 8.0 |  |  |  | (1.8 | ) |  |  | 2.2 |  |  |  | — |  |  |  | 8.4 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 38.6 |  |  |  | 48.4 |  |  |  | 22.9 |  |  |  | (52.9 | ) |  |  | 57.0 |  |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (3.5 | ) |  |  | 14.5 |  |  |  | 7.9 |  |  |  | 0.3 |  |  |  | 19.2 |  |
| Net income (loss) |  | $ | 42.1 |  |  | $ | 33.9 |  |  | $ | 15.0 |  |  | $ | (53.2 | ) |  | $ | 37.8 |  |

[0000950123-11-068216:notes:178]
[same as prior period, unchanged from 0000950123-11-039069:notes:174]

[0000950123-11-068216:notes:179]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 81.1 |  |  | $ | 14.7 |  |  | $ | 64.2 |  |  | $ | — |  |  | $ | 160.0 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 12.2 |  |  |  | — |  |  |  | 12.2 |  |
| Accounts and notes receivable, net |  |  | (1,169.7 | ) |  |  | 933.3 |  |  |  | 613.2 |  |  |  | 8.0 |  |  |  | 384.8 |  |
| Inventories, net |  |  | — |  |  |  | 163.7 |  |  |  | 128.7 |  |  |  | (6.2 | ) |  |  | 286.2 |  |
| Deferred income taxes, net |  |  | — |  |  |  | 27.6 |  |  |  | 12.1 |  |  |  | (3.0 | ) |  |  | 36.7 |  |
| Other assets |  |  | 19.3 |  |  |  | 21.0 |  |  |  | 121.2 |  |  |  | (94.5 | ) |  |  | 67.0 |  |
| Total current assets |  |  | (1,069.3 | ) |  |  | 1,160.3 |  |  |  | 951.6 |  |  |  | (95.7 | ) |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 202.8 |  |  |  | 121.6 |  |  |  | (0.1 | ) |  |  | 324.3 |  |
| GOODWILL |  |  | — |  |  |  | 50.8 |  |  |  | 225.8 |  |  |  | (4.8 | ) |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | — |  |  |  | 77.3 |  |  |  | 22.6 |  |  |  | (12.7 | ) |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 2,068.3 |  |  |  | 415.6 |  |  |  | 51.8 |  |  |  | (2,473.9 | ) |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 31.1 |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | (31.5 | ) |  | $ | 1.4 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |
| Accounts payable |  |  | 8.1 |  |  |  | 133.1 |  |  |  | 131.0 |  |  |  | 1.6 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 6.6 |  |  |  | 262.0 |  |  |  | 115.5 |  |  |  | (49.6 | ) |  |  | 334.5 |  |
| Income taxes payable |  |  | (36.1 | ) |  |  | 30.6 |  |  |  | 28.3 |  |  |  | (17.5 | ) |  |  | 5.3 |  |
| Total current liabilities |  |  | 9.7 |  |  |  | 425.9 |  |  |  | 277.0 |  |  |  | (97.0 | ) |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 300.0 |  |  |  | 5.4 |  |  |  | 139.6 |  |  |  | (128.0 | ) |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 15.9 |  |  |  | — |  |  |  | — |  |  |  | 15.9 |  |
| PENSIONS |  |  | — |  |  |  | 77.4 |  |  |  | 10.7 |  |  |  | — |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 5.8 |  |  |  | 46.8 |  |  |  | 25.9 |  |  |  | (12.8 | ) |  |  | 65.7 |  |
| Total liabilities |  |  | 315.5 |  |  |  | 571.4 |  |  |  | 453.2 |  |  |  | (237.8 | ) |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 683.5 |  |  |  | 1,335.4 |  |  |  | 920.2 |  |  |  | (2,349.4 | ) |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |

[0000950123-11-068216:notes:180]
For the Three Months Ended June 30, 2010

[0000950123-11-068216:notes:181]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 614.3 |  |  | $ | 329.9 |  |  | $ | (72.1 | ) |  | $ | 872.1 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 434.8 |  |  |  | 244.6 |  |  |  | (72.1 | ) |  |  | 607.4 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 179.5 |  |  |  | 85.3 |  |  |  | — |  |  |  | 264.7 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 130.9 |  |  |  | 49.6 |  |  |  | — |  |  |  | 180.5 |  |
| Losses (gains) and other expenses, net |  |  | 1.6 |  |  |  | 4.6 |  |  |  | (0.5 | ) |  |  | 0.1 |  |  |  | 5.8 |  |
| Restructuring charges |  |  | — |  |  |  | 1.2 |  |  |  | 2.1 |  |  |  | (0.1 | ) |  |  | 3.2 |  |
| (Income) loss from equity method investments |  |  | (56.0 | ) |  |  | (6.4 | ) |  |  | (4.1 | ) |  |  | 62.4 |  |  |  | (4.1 | ) |
| Operational |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| income (loss) from continuing operations |  |  | 54.3 |  |  |  | 49.2 |  |  |  | 38.2 |  |  |  | (62.4 | ) |  |  | 79.3 |  |
| INTEREST EXPENSE, net |  |  | 0.3 |  |  |  | 1.9 |  |  |  | 0.9 |  |  |  | — |  |  |  | 3.1 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 54.0 |  |  |  | 47.3 |  |  |  | 37.2 |  |  |  | (62.4 | ) |  |  | 76.1 |  |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (0.8 | ) |  |  | 15.1 |  |  |  | 13.0 |  |  |  | 0.1 |  |  |  | 27.4 |  |
| Income (loss) from continuing operations |  |  | 54.8 |  |  |  | 32.2 |  |  |  | 24.2 |  |  |  | (62.5 | ) |  |  | 48.7 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.4 |  |
| Net income (loss) |  | $ | 54.8 |  |  | $ | 32.2 |  |  | $ | 23.8 |  |  | $ | (62.5 | ) |  | $ | 48.3 |  |

[0000950123-11-068216:notes:182]
For the Six Months Ended June 30, 2010

[0000950123-11-068216:notes:183]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 1,043.7 |  |  | $ | 604.1 |  |  | $ | (131.6 | ) |  | $ | 1,516.2 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 757.5 |  |  |  | 451.1 |  |  |  | (131.6 | ) |  |  | 1,077.1 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 286.2 |  |  |  | 153.0 |  |  |  | — |  |  |  | 439.1 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 247.3 |  |  |  | 102.2 |  |  |  | 0.1 |  |  |  | 349.6 |  |
| Losses (gains) and other expenses, net |  |  | 1.4 |  |  |  | 4.5 |  |  |  | (0.5 | ) |  |  | 0.1 |  |  |  | 5.5 |  |
| Restructuring charges |  |  | — |  |  |  | 3.2 |  |  |  | 7.2 |  |  |  | (0.1 | ) |  |  | 10.3 |  |
| (Income) loss from equity method investments |  |  | (51.2 | ) |  |  | (3.5 | ) |  |  | (6.1 | ) |  |  | 54.7 |  |  |  | (6.1 | ) |
| Operational income (loss) from continuing operations |  |  | 49.7 |  |  |  | 34.7 |  |  |  | 50.2 |  |  |  | (54.8 | ) |  |  | 79.8 |  |
| INTEREST EXPENSE, net |  |  | — |  |  |  | 3.8 |  |  |  | 1.8 |  |  |  | — |  |  |  | 5.6 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 49.7 |  |  |  | 30.9 |  |  |  | 48.3 |  |  |  | (54.8 | ) |  |  | 74.1 |  |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (0.6 | ) |  |  | 10.1 |  |  |  | 17.1 |  |  |  | 0.1 |  |  |  | 26.7 |  |
| Income (loss) from continuing operations |  |  | 50.3 |  |  |  | 20.8 |  |  |  | 31.2 |  |  |  | (54.9 | ) |  |  | 47.4 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.7 |  |  |  | — |  |  |  | 0.7 |  |
| Net income (loss) |  | $ | 50.3 |  |  | $ | 20.8 |  |  | $ | 30.5 |  |  | $ | (54.9 | ) |  | $ | 46.7 |  |

[0000950123-11-068216:notes:184]
[same as prior period, unchanged from 0000950123-11-039069:notes:178]

[0000950123-11-068216:notes:185]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | 51.0 |  |  | $ | (184.9 | ) |  | $ | (8.5 | ) |  | $ | — |  |  | $ | (142.4 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.7 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.9 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (16.4 | ) |  |  | (2.2 | ) |  |  | — |  |  |  | (18.6 | ) |
| Proceeds from sale of business |  |  | — |  |  |  | — |  |  |  | 0.6 |  |  |  | — |  |  |  | 0.6 |  |
| Acquisition of business |  |  | — |  |  |  | (139.8 | ) |  |  | (7.9 | ) |  |  | — |  |  |  | (147.7 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 11.7 |  |  |  | — |  |  |  | 11.7 |  |
| Net cash used in investing activities |  |  | — |  |  |  | (155.5 | ) |  |  | 2.4 |  |  |  | — |  |  |  | (153.1 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 5.1 |  |  |  | — |  |  |  | 5.1 |  |
| Asset securitization borrowings |  |  | — |  |  |  | — |  |  |  | 80.0 |  |  |  | — |  |  |  | 80.0 |  |
| Asset securitization payments |  |  | — |  |  |  | — |  |  |  | (80.0 | ) |  |  | — |  |  |  | (80.0 | ) |
| Long-term payments |  |  | — |  |  |  | (0.4 | ) |  |  | — |  |  |  | — |  |  |  | (0.4 | ) |
| Revolver long-term borrowings |  |  | 683.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 683.0 |  |
| Revolver long-term payments |  |  | (429.0 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (429.0 | ) |
| Proceeds from stock option exercises |  |  | 1.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.3 |  |
| Repurchases of common stock |  |  | (36.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (36.5 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.5 |  |
| Intercompany debt |  |  | 35.8 |  |  |  | (11.6 | ) |  |  | (24.2 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (370.3 | ) |  |  | 365.2 |  |  |  | 5.1 |  |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (17.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (17.7 | ) |
| Net cash (used in) provided by financing activities |  |  | (131.9 | ) |  |  | 353.2 |  |  |  | (14.0 | ) |  |  | — |  |  |  | 207.3 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | (80.9 | ) |  |  | 12.8 |  |  |  | (20.1 | ) |  |  | — |  |  |  | (88.2 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 4.7 |  |  |  | — |  |  |  | 4.7 |  |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 81.1 |  |  |  | 14.7 |  |  |  | 64.2 |  |  |  | — |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | 0.2 |  |  | $ | 27.5 |  |  | $ | 48.8 |  |  | $ | — |  |  | $ | 76.5 |  |

[0000950123-11-068216:notes:186]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | 26.9 |  |  | $ | 2.7 |  |  | $ | (55.6 | ) |  | $ | — |  |  | $ | (26.0 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (15.7 | ) |  |  | (4.0 | ) |  |  | — |  |  |  | (19.7 | ) |
| Proceeds from sale of business |  |  | — |  |  |  | 0.1 |  |  |  | 3.4 |  |  |  | — |  |  |  | 3.5 |  |
| Acquisition of business |  |  | — |  |  |  | (6.4 | ) |  |  | — |  |  |  | — |  |  |  | (6.4 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | (23.8 | ) |  |  | — |  |  |  | (23.8 | ) |
| Net cash used in investing activities |  |  | — |  |  |  | (22.0 | ) |  |  | (24.3 | ) |  |  | — |  |  |  | (46.3 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 4.2 |  |  |  | — |  |  |  | 4.2 |  |
| Long-term payments |  |  | (35.0 | ) |  |  | — |  |  |  | (0.3 | ) |  |  | — |  |  |  | (35.3 | ) |
| Issuance of senior unsecured notes |  |  | 199.8 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 199.8 |  |
| Revolver long-term borrowings |  |  | 579.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 579.5 |  |
| Revolver long-term payments |  |  | (624.0 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (624.0 | ) |
| Additional investment in affiliates |  |  | — |  |  |  | — |  |  |  | (1.0 | ) |  |  | — |  |  |  | (1.0 | ) |
| Proceeds from stock option exercises |  |  | 1.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.4 |  |
| Payments of deferred financing costs |  |  | (1.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.7 | ) |
| Repurchases of common stock |  |  | (99.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (99.5 | ) |
| Excess tax benefits related to share-based payments |  |  | 2.6 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2.6 |  |
| Intercompany debt |  |  | (14.8 | ) |  |  | 8.4 |  |  |  | 6.4 |  |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (19.6 | ) |  |  | 23.6 |  |  |  | (4.0 | ) |  |  | — |  |  |  | — |  |
| Intercompany investments |  |  | (7.9 | ) |  |  | — |  |  |  | 7.9 |  |  |  | — |  |  |  | — |  |
| Intercompany dividends |  |  | 9.0 |  |  |  | — |  |  |  | (9.0 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (16.2 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (16.2 | ) |
| Net cash (used in) provided by financing activities |  |  | (26.4 | ) |  |  | 32.0 |  |  |  | 4.2 |  |  |  | — |  |  |  | 9.8 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | 0.5 |  |  |  | 12.7 |  |  |  | (75.7 | ) |  |  | — |  |  |  | (62.5 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 0.8 |  |  |  | 6.6 |  |  |  | 116.9 |  |  |  | — |  |  |  | 124.3 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | 1.3 |  |  | $ | 19.3 |  |  | $ | 41.3 |  |  | $ | — |  |  | $ | 61.9 |  |
