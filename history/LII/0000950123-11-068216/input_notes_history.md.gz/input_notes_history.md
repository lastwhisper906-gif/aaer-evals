# LII note change history — 0000950123-11-039069 → 0000950123-11-068216


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2011-07-26):
[0000950123-11-068216:note_history:1]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to provide protection against claims relating to contingencies such as workers’
   compensation, general liability, product liability, property damage, aviation liability, directors’
   and officers’ liability, auto liability, physical damage and other exposures. Self-insurance
   expense and liabilities are actuarially determined based on our historical claims information, as
   well as industry factors and trends. Because we have a captive insurance company, we are required
   to maintain specified levels of liquid assets from which we must pay claims. The majority of our
   self-insured risks (excluding auto liability and physical damage) will be paid over an extended
   period of time. There have been no material changes in our insurance liability since our latest
   fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our
   large deductible or captive insurance plans. The self-insurance liabilities recorded in Accrued
   expenses in the accompanying Consolidated Balance Sheets were $66.5 million and $61.3 million as of
   June 30, 2011 and December 31, 2010, respectively.
  (was, 2011-04-26, similarity 0.7299):
[0000950123-11-039069:note_history:1]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to provide protection against claims relating to contingencies such as workers’
   compensation, general liability, product liability, property damage, aviation liability, directors’
   and officers’ liability, auto liability, physical damage and other exposures. Self-insurance
   expense and liabilities are actuarially determined based on our historical claims information, as
   well as industry factors and trends and because we have a captive insurance company, we are
   required to maintain specified levels of liquid assets from which we must pay claims. The majority
   of our self-insured risks (excluding auto liability and physical damage) will be paid over an
   extended period of time. There have been no material changes since our latest fiscal year-end. We
   also maintain third-party insurance coverage for risks not retained within our large deductible or
   captive insurance plans. The self-insurance liabilities recorded in Accrued expenses in the
   accompanying Consolidated Balance Sheets were $64.8 million and $61.3 million as of March 31, 2011
   and December 31, 2010, respectively.

- changed (2011-07-26):
[0000950123-11-068216:note_history:2]
Total liabilities for estimated product warranty are included in the following captions on the
   accompanying Consolidated Balance Sheets (in millions):
  (was, 2011-04-26, similarity 0.9726):
[0000950123-11-039069:note_history:2]
Total liabilities for estimated warranty are included in the following captions on the
   accompanying Consolidated Balance Sheets (in millions):

- changed (2011-07-26):
[0000950123-11-068216:note_history:3]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Accrued expenses |  | $ | 32.6 |  |  | $ | 31.2 |  |
| Other liabilities |  |  | 41.4 |  |  |  | 44.3 |  |
|  |  | $ | 74.0 |  |  | $ | 75.5 |  |
  (was, 2011-04-26, similarity 0.9771):
[0000950123-11-039069:note_history:3]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Accrued expenses |  | $ | 32.8 |  |  | $ | 31.2 |  |
| Other liabilities |  |  | 43.5 |  |  |  | 44.3 |  |
|  |  | $ | 76.3 |  |  | $ | 75.5 |  |

- changed (2011-07-26):
[0000950123-11-068216:note_history:4]
The changes in total product warranty liabilities for the first half of 2011 were as follows
   (in millions):
  (was, 2011-04-26, similarity 0.8986):
[0000950123-11-039069:note_history:4]
The changes in the total warranty liabilities for the first quarter of 2011 were as
   follows (in millions):

- changed (2011-07-26):
[0000950123-11-068216:note_history:5]
| Total warranty liability as of December 31, 2010 |  | $ | 75.5 |  |
| Payments made in 2011 |  |  | (13.9 | ) |
| Changes resulting from issuance of new warranties |  |  | 13.3 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (2.7 | ) |
| Changes in foreign currency translation rates and other |  |  | 1.8 |  |
| Total warranty liability as of June 30, 2011 |  | $ | 74.0 |  |
  (was, 2011-04-26, similarity 0.9752):
[0000950123-11-039069:note_history:5]
| Total warranty liability as of December 31, 2010 |  | $ | 75.5 |  |
| Payments made in 2011 |  |  | (6.5 | ) |
| Changes resulting from issuance of new warranties |  |  | 5.6 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | 0.2 |  |
| Changes in foreign currency translation rates and other |  |  | 1.5 |  |
| Total warranty liability as of March 31, 2011 |  | $ | 76.3 |  |

- changed (2011-07-26):
[0000950123-11-068216:note_history:6]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete re-evaluation of our heating, ventilation and
   air conditioning (“HVAC”) warranty liabilities. As a result of this re-evaluation, we decreased our
   warranty liability by $2.5 million.
  (was, 2011-04-26, similarity 0.8427):
[0000950123-11-039069:note_history:6]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete reevaluation of our heating, ventilation and air
   conditioning (“HVAC”) warranty liabilities.

- changed (2011-07-26):
[0000950123-11-068216:note_history:7]
We incur the risk of liability claims for the installation and service of heating and air
   conditioning products, and we maintain liabilities for those claims that we self-insure. We are
   involved in various claims and lawsuits related to our products. Our product liability insurance
   policies have limits that, if exceeded, may result in substantial costs that could have an adverse
   effect on our results of operations. In addition, warranty claims are not covered by our product
   liability insurance and certain product liability claims also may not be covered by our product
   liability insurance. There have been no material changes in the circumstances that affect our
   product warranties since our latest fiscal year-end.
  (was, 2011-04-26, similarity 0.9751):
[0000950123-11-039069:note_history:7]
We incur the risk of liability claims for the installation and service of heating and air
   conditioning products, and we maintain liabilities for those claims that we self-insure. We are
   involved in various claims and lawsuits related to our products. Our product liability insurance
   policies have limits that, if exceeded, may result in substantial costs that could have an adverse
   effect on our results of operations. In addition, warranty claims are not covered by our product
   liability insurance and certain product liability claims also may not be covered by our product
   liability insurance. There have been no material changes in the circumstances since our latest
   fiscal year-end.

- added (2011-07-26):
[0000950123-11-068216:note_history:8]
In addition to normal product warranty, we identified a product quality issue in a heating and
   cooling product line produced in 2006 and 2007 that we believe resulted from a vendor-supplied
   materials quality issue. The expense for this product quality issue, and the related liability, is
   not included in the above tables related to our estimated warranty liabilities. We did not incur
   any additional expense in the first six months of 2011; however, we may incur additional charges in
   the future as more information becomes available. We decreased this liability by $1.4 million in
   the second quarter of 2011 to adjust the estimated claim cost based on historical claims paid. The
   changes in the accrued product quality issue for the first half of 2011 were as follows (in
   millions):

- changed (2011-07-26):
[0000950123-11-068216:note_history:9]
| Total accrued product quality issue as of December 31, 2010 |  | $ | 16.0 |  |
| Product quality claims |  |  | (3.7 | ) |
| Changes in estimates associated with pre-existing liabilities |  |  | (1.4 | ) |
| Total accrued product quality issue as of June 30, 2011 |  | $ | 10.9 |  |
  (was, 2011-04-26, similarity 0.7972):
[0000950123-11-039069:note_history:9]
| Total accrued product quality issue as of December 31, 2010 |  | $ | 16.0 |  |
| Product quality claims |  |  | (2.0 | ) |
| Total accrued product quality issue as of March 31, 2011 |  | $ | 14.0 |  |

- added (2011-07-26):
[0000950123-11-068216:note_history:10]
We estimate the costs to settle pending litigation based on experience involving similar
   claims and specific facts known. We do not believe that any current or pending or threatened
   litigation will have a material adverse effect on our financial position. Litigation and
   arbitration, however, involve uncertainties and it is possible that the eventual outcome of
   litigation could adversely affect our results of operations for a particular period.

- added (2011-07-26):
[0000950123-11-068216:note_history:11]
We were the defendant in a class action lawsuit related to certain hearth products we produced
   and sold that claimed such products are hazardous and that consumers were not adequately warned.
   On August 23, 2010, the Company and plaintiffs entered into a binding Memorandum of Understanding
   (“MOU”) and reached tentative terms for settlement of the case. At the parties’ request, the court
   stayed the lawsuit shortly after the MOU was signed. On June 10, 2011, the litigation of this
   matter concluded when the court issued its Order Granting Final Approval of Class Settlement; Final
   Judgment and Order of Dismissal. We had $9.4 million in expenses to date related to this matter
   and made minor adjustments to the reserve in the second quarter of 2011.

- changed (2011-07-26):
[0000950123-11-068216:note_history:12]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We were in compliance with these financial covenants as of June 30, 2011.
  (was, 2011-04-26, similarity 0.988):
[0000950123-11-039069:note_history:12]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We were in compliance with these financial covenants as of March 31, 2011.

- removed (2011-07-26):
[0000950123-11-039069:note_history:13]
In addition to normal product warranty, we have identified a product quality issue in a
   heating and cooling product line produced in 2006 and 2007 that we believe results from a
   vendor-supplied materials quality issue. The expense for this product quality issue, and the
   related liability, is not included in the tables related to our estimated warranty liabilities.
   The expense related to this product quality issue was classified in Cost of Goods Sold in the
   Consolidated Statements of Operations and the related liability is included in Accrued Expenses in
   the accompanying Consolidated Balance Sheets. We may incur additional charges in the future as more
   information becomes available. The changes in the accrued product quality issue for the first
   quarter of 2011 were as follows (in millions):

- removed (2011-07-26):
[0000950123-11-039069:note_history:14]
We estimate the costs to settle pending litigation based on experience involving similar
   claims and specific facts known. We do not believe that any current or pending or threatened
   litigation will have a material adverse effect on our financial position. Litigation and
   arbitration, however, involve uncertainties and it is possible that the eventual outcome of
   litigation could adversely affect our results of operations for a particular period. We are the
   defendant in a class action lawsuit related to certain hearth products we produced and sold that
   claims such products are hazardous and that consumers were not adequately warned. On August, 23,
   2010, the Company and plaintiffs entered into a binding Memorandum of Understanding (“MOU”) and
   reached tentative terms for settlement of the case. At the parties’ request, the court stayed the
   lawsuit shortly after the MOU was signed. On January 11, 2011, the court granted preliminary
   approval of the settlement. The court set June 2, 2011 as the date for the final approval hearing.
   We had $9.3 million in expenses to date related to this matter with no additional charges during
   the first quarter of 2011.


## lii:BasisOfPresentationPolicyTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2011-07-26):
[0000950123-11-068216:note_history:15]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2011, the accompanying
   unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2011
   and 2010, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months
   ended June 30, 2011 and 2010 should be read in conjunction with our audited consolidated financial
   statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31,
   2010. The accompanying unaudited consolidated financial statements have been prepared in
   accordance with generally accepted accounting principles (“GAAP”) for interim financial information
   and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying
   consolidated financial statements contain all material adjustments, consisting principally of
   normal recurring adjustments, necessary for a fair presentation of our financial position, results
   of operations and cash flows. Certain information and footnote disclosures normally included in
   financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to
   applicable rules and regulations, although we believe that the disclosures herein are adequate to
   make the information presented not misleading. The operating results for the interim periods are
   not necessarily indicative of the results that may be expected for a full year.

- added (2011-07-26):
[0000950123-11-068216:note_history:16]
Our fiscal year ends on December 31 and our quarters are each comprised of 13 weeks. For
   convenience, throughout these financial statements, the 13 weeks comprising each quarterly period
   are denoted by the last day of the respective calendar quarter.


## lii:UseOfEstimatesPolicyTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2011-07-26):
[0000950123-11-068216:note_history:17]
The preparation of financial statements requires us to make estimates and assumptions about
   future events. These estimates and the underlying assumptions affect the amounts of assets and
   liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of
   revenues and expenses. Such estimates include the valuation of accounts receivable, inventories,
   goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations,
   indemnifications, and assumptions used in the calculation of income taxes, pension and
   postretirement medical benefits, among others. These estimates and assumptions are based on
   management’s best estimates and judgment.

- added (2011-07-26):
[0000950123-11-068216:note_history:18]
We evaluate these estimates and assumptions on an ongoing basis using historical experience
   and other factors, including the current economic environment. We believe these estimates and
   assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when
   facts and circumstances dictate.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2011-07-26):
[0000950123-11-068216:note_history:19]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2011, the accompanying
   unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2011
   and 2010, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months
   ended June 30, 2011 and 2010 should be read in conjunction with our audited consolidated financial
   statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31,
   2010. The accompanying unaudited consolidated financial statements have been prepared in
   accordance with generally accepted accounting principles (“GAAP”) for interim financial information
   and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying
   consolidated financial statements contain all material adjustments, consisting principally of
   normal recurring adjustments, necessary for a fair presentation of our financial position, results
   of operations and cash flows. Certain information and footnote disclosures normally included in
   financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to
   applicable rules and regulations, although we believe that the disclosures herein are adequate to
   make the information presented not misleading. The operating results for the interim periods are
   not necessarily indicative of the results that may be expected for a full year.
  (was, 2011-04-26, similarity 0.9651):
[0000950123-11-039069:note_history:19]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2011, the accompanying
   unaudited Consolidated Statements of Operations for the three months ended March 31, 2011 and 2010,
   and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended
   March 31, 2011 and 2010 should be read in conjunction with our audited consolidated financial
   statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31,
   2010. The accompanying unaudited consolidated financial statements have been prepared in
   accordance with generally accepted accounting principles (“GAAP”) for interim financial information
   and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying
   consolidated financial statements contain all material adjustments, consisting principally of
   normal recurring adjustments, necessary for a fair presentation of our financial position, results
   of operations and cash flows. Certain information and footnote disclosures normally included in
   financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to
   applicable rules and regulations, although we believe that the disclosures herein are adequate to
   make the information presented not misleading. The operating results for the interim periods are
   not necessarily indicative of the results that may be expected for a full year.

- added (2011-07-26):
[0000950123-11-068216:note_history:20]
Reclassifications

- added (2011-07-26):
[0000950123-11-068216:note_history:21]
Certain prior year amounts have been reclassified to conform to the current year presentation.

- added (2011-07-26):
[0000950123-11-068216:note_history:22]
New Accounting Pronouncements

- added (2011-07-26):
[0000950123-11-068216:note_history:23]
In June 2011, the Financial Accounting Standards Board (“FASB”) issued Accounting
   Standards Update (“ASU”) No. 2011-05, Comprehensive Income (Topic 220): Presentation of
   Comprehensive Income (“ASU 2011-05”). This ASU eliminates the option to present the components of
   other comprehensive income as part of the statement of changes in stockholders’ equity. Rather, it
   gives an entity the choice to present the components of net income and other
   comprehensive income in either a single continuous statement or two separate but consecutive
   statements. Companies will continue to present reclassification adjustments from other
   comprehensive income to
   net income on the face of the financial statements. The components of comprehensive
   income and timing of reclassification of an item to net income do not change with this update. ASU
   2011-05 requires retrospective application and is effective for annual and interim periods
   beginning after December 15, 2011. Early adoption is permitted. We are currently evaluating which
   presentation to apply and will include the new presentation in the first quarter of 2012.

- added (2011-07-26):
[0000950123-11-068216:note_history:24]
In April 2011, the FASB issued ASU No. 2011-02, Receivables (Topic 310): A Creditor’s
   Determination of Whether a Restructuring Is a Troubled Debt Restructuring (“ASU 2011-02”). This ASU
   provides additional guidance clarifying when the restructuring of a receivable should be considered
   a troubled debt restructuring. The additional guidance this update provides is for determining
   whether a creditor has granted a concession and whether the debtor is experiencing financial
   difficulty. ASU 2011-02 also ends the deferral of activity-based disclosures related to troubled
   debt restructurings. This ASU should be applied retrospectively and is effective for interim and
   annual periods beginning on or after June 15, 2011. Early adoption is permitted. We are currently
   evaluating the effect of this ASU and do not anticipate a material impact on our financial
   statements and related disclosures. We will adopt ASU 2011-02 in the third quarter of 2011.


## lii:DebtAndCapitalLeasesDisclosuresTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2011-07-26):
[0000950123-11-068216:note_history:25]
|  |  | As of June 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 6.7 |  |  | $ | 1.4 |  |
| Total short-term debt |  | $ | 6.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt: |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.8 |  |  |  | 17.0 |  |
| Domestic revolving credit facility |  |  | 354.0 |  |  |  | 100.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 570.8 |  |  | $ | 317.0 |  |
| Total debt |  | $ | 577.9 |  |  | $ | 319.0 |  |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2011-07-26):
[0000950123-11-068216:note_history:26]
|  |  | As of June 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Weighted average borrowing rate |  |  | 1.01 | % |  |  | 0.96 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2011-07-26):
[0000950123-11-068216:note_history:27]
|  |  | As of June 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 6.7 |  |  | $ | 1.4 |  |
| Total short-term debt |  | $ | 6.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt: |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.8 |  |  |  | 17.0 |  |
| Domestic revolving credit facility |  |  | 354.0 |  |  |  | 100.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 570.8 |  |  | $ | 317.0 |  |
| Total debt |  | $ | 577.9 |  |  | $ | 319.0 |  |

- changed (2011-07-26):
[0000950123-11-068216:note_history:28]
Through several of our foreign subsidiaries, we have $4.1 million in committed combined
   foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We
   had $4.1 million and $10.1 million of available capacity as of June 30, 2011 and December 31, 2010,
   respectively. Our foreign obligations of $6.7 million represented borrowings under non-committed
   facilities.
  (was, 2011-04-26, similarity 0.988):
[0000950123-11-039069:note_history:28]
Through several of our foreign subsidiaries, we have $10.9 million in committed combined
   foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We
   had $10.9 million and $10.1 million of available capacity as of March 31, 2011 and December 31,
   2010, respectively. Our foreign obligations of $2.7 million represented borrowings under
   non-committed facilities.

- changed (2011-07-26):
[0000950123-11-068216:note_history:29]
Under a revolving period asset securitization arrangement (“ASA”), we are eligible to sell
   beneficial interests in a portion of our trade accounts receivable to participating financial
   institutions for cash. The arrangement is subject to renewal and contains a provision whereby we
   retain the right to repurchase all of the outstanding beneficial interests transferred. Our
   continued involvement with the transferred assets includes servicing, collection and administration
   of the transferred beneficial interests. The sale of the beneficial interests in our trade
   accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance
   Sheets and proceeds received are included in cash flows from financing activities in the
   accompanying Consolidated Statements of Cash Flows. The
   ASA provides for a maximum securitization amount of $100.0 million or 100% of the net pool balance
   as defined by the ASA. However, eligibility for securitization is limited based on the amount and
   quality of the qualifying accounts receivable and is calculated monthly. The beneficial interest
   sold cannot exceed the maximum amount even if our qualifying accounts receivable is greater than
   the maximum amount at any point in time. During the second quarter, the average amount of
   beneficial interest sold under the ASA was $60.2 million. We did not have any beneficial interest
   sold as of June 30, 2011. The eligible amounts available and beneficial interests sold were as
   follows (in millions):
  (was, 2011-04-26, similarity 0.8859):
[0000950123-11-039069:note_history:29]
Under a revolving period asset securitization arrangement (“ASA”), we are eligible to sell
   beneficial interests in a portion of our trade accounts receivable to participating financial
   institutions for cash. The arrangement is subject to renewal and contains a provision whereby we
   retained the right to repurchase all of the outstanding beneficial interests transferred. Our
   continued involvement with the transferred assets includes servicing, collection and administration
   of the transferred beneficial interests. The sale of the beneficial interests in our trade
   accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance
   Sheets and proceeds received are included in cash flows from financing activities in the
   accompanying Consolidated Statements of Cash Flows. The ASA provides for a maximum securitization
   amount of $100.0 million or 100% of the net pool balance as defined by the ASA. However,
   eligibility for securitization is limited based on the amount and quality of the qualifying
   accounts receivable and is calculated monthly. The beneficial interest sold cannot exceed the
   maximum amount even if our qualifying accounts receivable is greater than the maximum amount at any
   point in time. In the first quarter of 2011, we sold a beneficial interest in $50.0 million of our
   trade accounts receivable under the ASA. Because the ASA matures in November 2011, we classified
   the related debt as short-term on the Consolidated Balance Sheet. The eligible amounts available
   and beneficial interests sold were as follows (in millions):

- changed (2011-07-26):
[0000950123-11-068216:note_history:30]
|  |  | As of |  |  | As of |  |
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 100.0 |  |  | $ | 100.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 100.0 |  |  | $ | 100.0 |  |
  (was, 2011-04-26, similarity 0.9494):
[0000950123-11-039069:note_history:30]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 94.0 |  |  | $ | 100.0 |  |
| Beneficial interest sold |  |  | 50.0 |  |  |  | — |  |
| Remaining amount available |  | $ | 44.0 |  |  | $ | 100.0 |  |

- changed (2011-07-26):
[0000950123-11-068216:note_history:31]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 0.75%. The rate
   as of June 30, 2011 was 1.00% and the rate at December 31, 2010 was 1.06%. The unused fee is based
   on 102% of the maximum available amount less the beneficial interest sold and calculated at a
   0.375% fixed rate throughout the term of the agreement. We recorded these fees in Selling, General
   and Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):
  (was, 2011-04-26, similarity 0.8078):
[0000950123-11-039069:note_history:31]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 0.75%. The rate
   as of March 31, 2011 and December 31, 2010 was 1.06% for both periods. The unused fee is based on
   102% of the maximum available amount less the beneficial interest sold and calculated at a 0.375%
   fixed rate throughout the term of the agreement. We recorded these fees in Selling, General and
   Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):

- changed (2011-07-26):
[0000950123-11-068216:note_history:32]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |
  (was, 2011-04-26, similarity 0.7048):
[0000950123-11-039069:note_history:32]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.1 |  |

- changed (2011-07-26):
[0000950123-11-068216:note_history:33]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our domestic revolving credit facility and
   senior unsecured notes. The administrative agent under the ASA is also a participant in our
   domestic revolving credit facility. The participating financial institution has an investment grade
   credit rating and we continue to evaluate its credit rating. We have no reason to believe it will
   not perform under the ASA. As of June 30, 2011, we were in compliance with all covenant
   requirements.
  (was, 2011-04-26, similarity 0.7674):
[0000950123-11-039069:note_history:33]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our domestic revolving credit facility and
   senior unsecured notes. The administrative agent under the ASA is also a participant in our
   domestic revolving credit facility. The participating financial institution has an investment grade
   credit rating. We continue to evaluate its credit rating and have no reason to believe it will not
   perform under the ASA. As of March 31, 2011, we were in compliance with all covenant requirements.

- changed (2011-07-26):
[0000950123-11-068216:note_history:34]
Under the $650 million domestic revolving credit facility, we had outstanding borrowings of
   $354.0 million and $77.5 million committed to standby letters of credit as of June 30, 2011.
   Subject to covenant limitations, $218.5 million was available for future borrowings. Included in
   this facility is a subfacility for swingline loans of up to $50 million of which $29 million was
   outstanding at June 30, 2011. This domestic revolving credit facility provides for issuance of
   letters of credit for the full amount of the credit facility and matures in October 2012.
  (was, 2011-04-26, similarity 0.6109):
[0000950123-11-039069:note_history:34]
Under the $650 million domestic revolving credit facility, we had outstanding borrowings of
   $271.5 million and $69.5 million committed to standby letters of credit as of March 31, 2011.
   Subject to covenant limitations, $309.0 million was available for future borrowings. Included in
   this facility is a subfacility for swingline loans of up to $50 million and provides for the
   issuance of letters of credit for the full amount of the credit facility. The subfacility is fully
   drawn and is included in our outstanding borrowings. This domestic revolving credit facility
   matures in October 2012.

- changed (2011-07-26):
[0000950123-11-068216:note_history:35]
|  |  | As of June 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Weighted average borrowing rate |  |  | 1.01 | % |  |  | 0.96 | % |
  (was, 2011-04-26, similarity 0.9641):
[0000950123-11-039069:note_history:35]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Weighted average borrowing rate |  |  | 1.05 | % |  |  | 0.96 | % |

- changed (2011-07-26):
[0000950123-11-068216:note_history:36]
Our domestic revolving credit facility contains financial covenants relating to leverage
   and interest coverage. Other covenants contained in the domestic revolving credit facility
   restrict, among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to
   Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net
   Interest Expense Ratio. The required ratios under our domestic revolving credit facility as of
   June 30, 2011 are detailed below:
  (was, 2011-04-26, similarity 0.9932):
[0000950123-11-039069:note_history:36]
Our domestic revolving credit facility contains financial covenants relating to leverage
   and interest coverage. Other covenants contained in the domestic revolving credit facility
   restrict, among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a
   Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The
   required ratios under our domestic revolving credit facility as of March 31, 2011 are detailed
   below:

- changed (2011-07-26):
[0000950123-11-068216:note_history:37]
Each of our major debt agreements contains provisions by which a default under one agreement
   causes a default in the others (a cross default). If a cross default under the revolving credit
   facility, our senior unsecured notes, or our ASA were to occur, it could have a wider impact on our
   liquidity than might otherwise occur from a default of a single debt instrument or lease
   commitment.
  (was, 2011-04-26, similarity 0.9415):
[0000950123-11-039069:note_history:37]
Each of our major debt agreements contains provisions by which a default under one agreement
   causes a default in the others (a cross default). If a cross default under the revolving credit
   facility, our senior unsecured notes, or our revolving period asset securitization program were to
   occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a
   single debt instrument or lease commitment.

- changed (2011-07-26):
[0000950123-11-068216:note_history:38]
If any event of default occurs and is continuing, lenders with a majority of the aggregate
   commitments may require the administrative agent to terminate our right to borrow under our
   domestic revolving credit facility and accelerate amounts due under our domestic revolving credit
   facility (except for a bankruptcy event of default, in which case such amounts will automatically
   become due and payable and the lenders’ commitments will automatically terminate). As of June 30,
   2011, we were in compliance with all covenant requirements.
  (was, 2011-04-26, similarity 0.9915):
[0000950123-11-039069:note_history:38]
If any event of default occurs and is continuing, lenders with a majority of the aggregate
   commitments may require the administrative agent to terminate our right to borrow under our
   domestic revolving credit facility and accelerate amounts due under our domestic revolving credit
   facility (except for a bankruptcy event of default, in which case such amounts will automatically
   become due and payable and the lenders’ commitments will
   automatically terminate). As of March 31, 2011, we were in compliance with all covenant
   requirements.

- changed (2011-07-26):
[0000950123-11-068216:note_history:39]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries
   that guarantee payment by us of any indebtedness under our domestic revolving credit facility. The
   indenture governing the notes contains covenants that, among other things, limit our ability and
   the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale
   and leaseback transactions; enter into certain mergers, consolidations and transfers of
   substantially all of our assets; and transfer certain properties. The indenture also contains a
   cross default provision which is triggered if we default on other debt of at least $75 million in
   principal which is then accelerated, and such acceleration is not rescinded within 30 days of the
   notice date. As of June 30, 2011, we were in compliance with all covenant requirements and these
   covenants have not changed from December 31, 2010.
  (was, 2011-04-26, similarity 0.995):
[0000950123-11-039069:note_history:39]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic
   subsidiaries that guarantee payment by us of any indebtedness under our domestic revolving credit
   facility. The indenture governing the notes contains covenants that, among other things, limit our
   ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into
   certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers
   of substantially all of our assets; and transfer certain properties. The indenture also contains a
   cross default provision which is triggered if we default on other debt of at least $75 million in
   principal which is then accelerated, and such acceleration is not rescinded within 30 days of the
   notice date. As of March 31, 2011, we were in compliance with all covenant requirements and these
   covenants have not changed from December 31, 2010.

- changed (2011-07-26):
[0000950123-11-068216:note_history:40]
At June 30, 2011, our senior credit ratings were Baa3, with a stable outlook, and BBB-, with a
   stable outlook by Moody’s and Standard & Poor’s Rating Group (“S&P”), respectively.
  (was, 2011-04-26, similarity 0.9738):
[0000950123-11-039069:note_history:40]
At March 31, 2011, our senior credit ratings were Baa3, with a stable outlook, and BBB-, with
   a stable outlook by Moody’s and Standard & Poor’s Rating Group (“S&P”), respectively.

- changed (2011-07-26):
[0000950123-11-068216:note_history:41]
In the first quarter 2010, our captive insurance subsidiary entered into an agreement in which
   cash was placed into a trust for the benefit of a third-party insurance provider. The purpose of
   the trust is to pay workers compensation claims for policy years 2003 — 2009 until the liabilities
   are fully extinguished. These policies were written by the third-party insurance provider, and
   then reinsured by our captive insurance subsidiary. In the second quarter of 2011, we changed how
   these claims were secured. Substantially all claims for the workers compensation
   claims for policy years 2003-2009 are now secured by standby letters of credit. As of June
   30, 2011 and December 31, 2010, we had $0.5 million and $12.2 million, respectively, in Restricted
   Cash on the accompanying Consolidated Balance Sheets to pay these claims.
  (was, 2011-04-26, similarity 0.6366):
[0000950123-11-039069:note_history:41]
In the first quarter 2010, our captive insurance subsidiary entered into an agreement in which
   cash was placed into a trust for the benefit of a third-party insurance provider. The purpose of
   the trust is to pay workers compensation claims for policy years 2003 — 2009 until the liabilities
   are fully extinguished. These policies were written by the third-party insurance provider, and
   then reinsured by our captive insurance subsidiary. As of March 31, 2011 and December 31, 2010, we
   had $10.5 million and $12.2 million in Restricted Cash on the accompanying Consolidated Balance
   Sheets to pay these claims.

- removed (2011-07-26):
[0000950123-11-039069:note_history:42]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 2.7 |  |  | $ | 1.4 |  |
| Asset securitization |  |  | 50.0 |  |  |  | — |  |
| Total short-term debt |  | $ | 52.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt: |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 17.0 |  |  |  | 17.0 |  |
| Domestic revolving credit facility |  |  | 271.5 |  |  |  | 100.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 488.5 |  |  | $ | 317.0 |  |
| Total debt |  | $ | 541.6 |  |  | $ | 319.0 |  |
