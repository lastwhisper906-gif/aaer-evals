# LII 8-K — 0001193125-17-032530 filed 2017-02-07

## item codes, every 8-K on or before 2017-02-21

- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2017-02-21

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-032530:8k_2_02:1]
EX-99.1
2
d275437dex991.htm
EX-99.1

[0001193125-17-032530:8k_2_02:2]
EX-99.1

[0001193125-17-032530:8k_2_02:3]
Exhibit 99.1

[0001193125-17-032530:8k_2_02:4]
Lennox International Reports Strong Fourth Quarter to Cap Year of Record Profit and Cash Flow

[0001193125-17-032530:8k_2_02:5]
| • |  | Fourth-quarter record revenue of $897 million, up 8% |

[0001193125-17-032530:8k_2_02:6]
| • |  | Fourth-quarter GAAP EPS from continuing operations up 276% to $0.94, and adjusted EPS from continuing operations up 35% to fourth-quarter record $1.50 |

[0001193125-17-032530:8k_2_02:7]
| • |  | 2016 revenue up 5% |

[0001193125-17-032530:8k_2_02:8]
| • |  | 2016 GAAP EPS from continuing operations up 54% to record $6.34, and adjusted EPS from continuing operations up 35% to record $6.95 |

[0001193125-17-032530:8k_2_02:9]
| • |  | 2016 cash from operations a record $355 million and free cash flow a record $270 million |

[0001193125-17-032530:8k_2_02:10]
| • |  | Reiterating guidance for 2017 revenue growth of 3-7% and EPS from continuing operations of $7.55-$8.15 |

[0001193125-17-032530:8k_2_02:11]
DALLAS, February 7, 2017 – Lennox International Inc. (NYSE: LII) today reported fourth- quarter and full-year 2016 results. All comparisons are
against the prior-year period.

[0001193125-17-032530:8k_2_02:12]
For the fourth quarter, revenue was a fourth-quarter record $897 million, up 8%. Foreign exchange was neutral to
revenue. GAAP operating income was $68 million, up 233%. GAAP earnings per share from continuing operations was $0.94, up 276%. On an adjusted basis, total segment profit increased 30% to a fourth-quarter record $105 million, and margin
expanded 200 basis points to a fourth-quarter record 11.7%. Adjusted earnings per share from continuing operations rose 35% to a fourth-quarter record $1.50.

[0001193125-17-032530:8k_2_02:13]
For the full year, revenue was $3.6 billion, up 5%. Foreign exchange was neutral to revenue. GAAP operating income was a record $429 million, up
41%. GAAP earnings per share from continuing operations was a record $6.34, up 54%. On an adjusted basis, total segment profit increased 24% to a record $470 million as total segment margin expanded 200 basis points to a record 12.9%. Adjusted
earnings per share from continuing operations for the full year rose 35% to a record $6.95.

[0001193125-17-032530:8k_2_02:14]
“2016 was a year of record margin, profit, and cash flow
for the company,” said Chairman and CEO Todd Bluedorn. “All three of our businesses were up in 2016, and Residential and Commercial set new highs for sales, margin, and profit. In Refrigeration, profit rose 30% as margin expanded 210 basis
points to 9.5%. The company generated a record $355 million in cash from operations for the year, and we continued to make investments for the future growth and profitability of the company, as well as raise the dividend and repurchase company
stock.

[0001193125-17-032530:8k_2_02:15]
“In the fourth quarter, our Residential and Commercial businesses set new fourth-quarter records for revenue, margin, and profit. In
Residential, revenue was up 10%, and profit rose 43% as segment margin expanded 400 basis points to 17.2%. In Commercial, revenue grew 7%, and profit rose 11% as segment margin expanded 60 basis points to 15.9%. Refrigeration revenue and profit were
up 1% on flat segment margin of 8.8% in the quarter.

[0001193125-17-032530:8k_2_02:16]
“Looking ahead at 2017 overall, Lennox International is well positioned for another year of strong growth
and profitability. The company reiterates its guidance for revenue growth of 3-7% and EPS from continuing operations of $7.55-$8.15. With a strong balance sheet and cash
generation, the company will continue to invest in the business to drive growth and profitability, as well as repurchase company stock, with $250 million planned for 2017.”

[0001193125-17-032530:8k_2_02:17]
FOURTH QUARTER 2016 FINANCIAL HIGHLIGHTS

[0001193125-17-032530:8k_2_02:18]
Revenue:
Revenue for the fourth quarter was $897 million, up 8%. Foreign exchange was neutral to revenue. Volume and price/mix were up from the fourth quarter a year ago.

[0001193125-17-032530:8k_2_02:19]
Gross Profit: Gross profit in the fourth quarter was $268 million, up 18%. Gross margin was 29.8%, up 250 basis points. Gross profit was
positively impacted by higher volume, favorable price/mix, and lower material and other product costs, with a partial offset from investments in distribution expansion.

[0001193125-17-032530:8k_2_02:20]
Income from Continuing Operations: On a GAAP basis, fourth quarter income from continuing operations was $40.7 million, or
$0.94 diluted earnings per share, compared to $11.2 million, or $0.25 diluted earnings per share, in the prior-year quarter. The fourth quarter of 2016 included a previously announced $20.5 million
after-tax charge for a one-time, lump-sum pension buyout program to certain vested participants. The fourth quarter of 2015
included $32.6 million of after-tax impairment charges related to the company’s Kysor/Warren refrigerated display case business.

[0001193125-17-032530:8k_2_02:21]
For the fourth quarter of 2016, adjusted income from continuing operations was $65.2 million, or $1.50 diluted earnings per share, compared to
$50.3 million, or $1.11 diluted earnings per share, in the prior-year quarter. Adjusted income from continuing operations for the fourth quarter of 2016 excludes net after-tax charges of
$24.5 million, including: $20.5 million for the pension buyout program, $2.6 million for asbestos-related litigation, and $1.4 million in special legal contingency charges.

[0001193125-17-032530:8k_2_02:22]
FULL YEAR 2016 FINANCIAL HIGHLIGHTS

[0001193125-17-032530:8k_2_02:23]
Revenue: For the full year, revenue was $3.6 billion, up 5%. Foreign exchange was neutral to revenue. Volume was up, and price/mix was neutral from
the prior year.

[0001193125-17-032530:8k_2_02:24]
Gross Profit: Gross profit for the full year was $1.08 billion, up 14%. Gross margin was 29.6%, up 230 basis points.
Gross profit was positively impacted by higher volume, favorable price, lower material costs, and higher productivity, with partial offsets from unfavorable mix, negative foreign exchange, and investments in distribution expansion.

[0001193125-17-032530:8k_2_02:25]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for 2016 was $279 million, or $6.34
diluted earnings per share, compared to $187 million, or $4.11 diluted earnings per share, in the prior year. The year 2016 included a previously announced $20.5 million after-tax charge for a one-time, lump-sum pension buyout program to certain vested participants. The year 2015 included $32.6 million after-tax of
impairment charges related to the company’s Kysor/Warren refrigerated display case business.

[0001193125-17-032530:8k_2_02:26]
Adjusted income from continuing operations for 2016 was
$306 million, or $6.95 diluted earnings per share, compared to $234 million, or $5.14 diluted earnings per share, in the prior year. Adjusted income from continuing operations for 2016 excludes net
after-tax charges of $27.0 million: $20.5 million for the pension buyout program, $4.1 million for asbestos-related litigation, $1.8 million in special legal contingency charges,
$1.4 million for environmental liabilities, a net total of $1.5 million for other charges, and a gain of $2.3 million for the net change in unrealized gains on unsettled futures contracts.

[0001193125-17-032530:8k_2_02:27]
Free Cash Flow and Total Debt: For the full year, cash from operations was a record $355 million compared to
$331 million in the prior year. Capital expenditures were $84 million compared to $70 million in the prior year. Free cash flow was a record at approximately $270 million for the full year compared to $261 million in the
prior year. In 2016, the company repatriated approximately $50 million of cash resulting from tax-planning initiatives and made a $50 million discretionary pension contribution, which lowered cash
from operations and free cash flow as reported for the year by that amount. In 2016, the company paid $69 million in dividends and repurchased $300 million of company stock. Total debt at the end of 2016 was $868 million. Total cash and
cash equivalents were $50 million at the end of the year.

[0001193125-17-032530:8k_2_02:28]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001193125-17-032530:8k_2_02:29]
Residential Heating and Cooling

[0001193125-17-032530:8k_2_02:30]
| • |  | 4Q16 revenue a fourth-quarter record $476 million, up 10%; neutral foreign exchange |

[0001193125-17-032530:8k_2_02:31]
| • |  | 4Q16 segment profit a fourth-quarter record $82 million, up 43% |

[0001193125-17-032530:8k_2_02:32]
| • |  | 4Q16 segment profit margin a fourth-quarter record 17.2%, up 400 basis points |

[0001193125-17-032530:8k_2_02:33]
| • |  | 2016 revenue a record $2,001 million, up 7%; neutral foreign exchange |

[0001193125-17-032530:8k_2_02:34]
| • |  | 2016 segment profit a record $349 million, up 25% |

[0001193125-17-032530:8k_2_02:35]
| • |  | 2016 segment profit margin a record 17.4%, up 250 basis points |

[0001193125-17-032530:8k_2_02:36]
Fourth-quarter results were positively
impacted by higher volume, favorable price/mix, higher productivity, and lower material and other product costs, with partial offsets from investments in distribution expansion, information technology and research and development. Full-year results
were positively impacted by higher volume, favorable price, higher productivity, and lower material and other product costs, with partial offsets from unfavorable mix, negative foreign exchange, higher SG&A, and investments in distribution
expansion, information technology and research and development.

[0001193125-17-032530:8k_2_02:37]
Commercial Heating and Cooling

[0001193125-17-032530:8k_2_02:38]
| • |  | 4Q16 revenue a fourth-quarter record $243 million, up 7%; neutral foreign exchange |

[0001193125-17-032530:8k_2_02:39]
| • |  | 4Q16 segment profit a fourth-quarter record $39 million, up 11% |

[0001193125-17-032530:8k_2_02:40]
| • |  | 4Q16 segment profit margin a fourth-quarter record 15.9%, up 60 basis points |

[0001193125-17-032530:8k_2_02:41]
| • |  | 2016 revenue a record $918 million, up 3%; up 4% at constant currency |

[0001193125-17-032530:8k_2_02:42]
| • |  | 2016 segment profit a record $149 million, up 14% |

[0001193125-17-032530:8k_2_02:43]
| • |  | 2016 segment profit margin a record 16.3%, up 160 basis points |

[0001193125-17-032530:8k_2_02:44]
Fourth-quarter results were positively
impacted by higher volume, lower material costs, and favorable foreign exchange, with partial offsets from higher SG&A, investments in distribution expansion and other product costs. Full-year results were positively impacted by higher volume,
favorable price/mix, lower material costs, and lower freight expenses, with partial offsets from factory productivity and other product costs, higher SG&A, and investments in the commercial service business.

[0001193125-17-032530:8k_2_02:45]
Refrigeration

[0001193125-17-032530:8k_2_02:46]
| • |  | 4Q16 revenue of $178 million, up 1%; flat at constant currency |

[0001193125-17-032530:8k_2_02:47]
| • |  | 4Q16 segment profit of $16 million, up 1% |

[0001193125-17-032530:8k_2_02:48]
| • |  | 4Q16 segment profit margin of 8.8%, flat |

[0001193125-17-032530:8k_2_02:49]
| • |  | 2016 revenue of $723 million, up 1%; up 2% at constant currency |

[0001193125-17-032530:8k_2_02:50]
| • |  | 2016 segment profit of $69 million, up 30% |

[0001193125-17-032530:8k_2_02:51]
| • |  | 2016 segment profit margin of 9.5%, up 210 basis points |

[0001193125-17-032530:8k_2_02:52]
Fourth-quarter results were positively impacted by
lower material and other product costs, with offsets from higher SG&A and the timing of national account revenue and factory loading of our Kysor/Warren business. Full-year results were positively impacted by higher volume, lower material costs,
and lower factory costs and higher productivity, with partial offsets from unfavorable price/mix, negative foreign exchange, and higher SG&A expenses.

[0001193125-17-032530:8k_2_02:53]
2017 FULL-YEAR OUTLOOK

[0001193125-17-032530:8k_2_02:54]
The company reiterates all of its guidance points for 2017.

[0001193125-17-032530:8k_2_02:55]
| • |  | Revenue growth of 3-7%, with a minimal impact from foreign exchange |

[0001193125-17-032530:8k_2_02:56]
| • |  | GAAP and adjusted EPS from continuing operations of $7.55-$8.15 |

[0001193125-17-032530:8k_2_02:57]
| • |  | Corporate expenses of approximately $85 million |

[0001193125-17-032530:8k_2_02:58]
| • |  | An effective tax rate of approximately 32% on a full-year basis |

[0001193125-17-032530:8k_2_02:59]
| • |  | Capital expenditures of approximately $100 million |

[0001193125-17-032530:8k_2_02:60]
| • |  | Stock repurchases of $250 million in 2017 |

[0001193125-17-032530:8k_2_02:61]
CONFERENCE CALL INFORMATION

[0001193125-17-032530:8k_2_02:62]
A conference call to discuss the company’s fourth-quarter and full-year 2016 results will be held this morning at 8:30 a.m. Central time. To listen, call
the conference call line at 612-234-9960 at least 10 minutes prior to the scheduled start time and use reservation number 415379. The conference call also will be
webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on February 7 through February 21, 2017, by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 415379. The call also will be archived on the
company’s web site.

[0001193125-17-032530:8k_2_02:63]
About Lennox International

[0001193125-17-032530:8k_2_02:64]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York
Stock Exchange and traded under the symbol “LII”. Additional information on Lennox International is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-17-032530:8k_2_02:65]
FORWARD-LOOKING STATEMENTS

[0001193125-17-032530:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-032530:8k_2_02:67]
Consolidated Statements of Operations

[0001193125-17-032530:8k_2_02:68]
| (Amounts in millions, except per share data) |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 897.3 |  |  | $ | 834.1 |  |  | $ | 3,641.6 |  |  | $ | 3,467.4 |  |
| Cost of goods sold |  |  | 629.7 |  |  |  | 606.5 |  |  |  | 2,565.1 |  |  |  | 2,520.0 |  |
| Gross profit |  |  | 267.6 |  |  |  | 227.6 |  |  |  | 1,076.5 |  |  |  | 947.4 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 164.9 |  |  |  | 150.6 |  |  |  | 621.0 |  |  |  | 580.5 |  |
| Losses and other expenses, net |  |  | 5.8 |  |  |  | 6.8 |  |  |  | 11.3 |  |  |  | 21.7 |  |
| Restructuring charges |  |  | 0.7 |  |  |  | 1.4 |  |  |  | 1.8 |  |  |  | 3.2 |  |
| Goodwill impairment |  |  | — |  |  |  | 5.5 |  |  |  | — |  |  |  | 5.5 |  |
| Asset impairment |  |  | — |  |  |  | 44.5 |  |  |  | — |  |  |  | 44.5 |  |
| Pension settlement |  |  | 31.4 |  |  |  | — |  |  |  | 31.4 |  |  |  | — |  |
| Income from equity method investments |  |  | (3.2 | ) |  |  | (1.6 | ) |  |  | (18.4 | ) |  |  | (13.4 | ) |
| Operating income |  |  | 68.0 |  |  |  | 20.4 |  |  |  | 429.4 |  |  |  | 305.4 |  |
| Interest expense, net |  |  | 7.4 |  |  |  | 5.8 |  |  |  | 27.0 |  |  |  | 23.6 |  |
| Other income, net |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.3 | ) |  |  | (0.8 | ) |
| Income from continuing operations before income taxes |  |  | 60.7 |  |  |  | 14.7 |  |  |  | 402.7 |  |  |  | 282.6 |  |
| Provision for income taxes |  |  | 20.0 |  |  |  | 3.5 |  |  |  | 124.1 |  |  |  | 95.4 |  |
| Income from continuing operations |  |  | 40.7 |  |  |  | 11.2 |  |  |  | 278.6 |  |  |  | 187.2 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | (0.5 | ) |  |  | — |  |  |  | (1.3 | ) |  |  | (1.0 | ) |
| Benefit from income taxes |  |  | (0.2 | ) |  |  | — |  |  |  | (0.5 | ) |  |  | (0.4 | ) |
| Loss from discontinued operations |  |  | (0.3 | ) |  |  | — |  |  |  | (0.8 | ) |  |  | (0.6 | ) |
| Net income |  | $ | 40.4 |  |  | $ | 11.2 |  |  | $ | 277.8 |  |  | $ | 186.6 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.95 |  |  | $ | 0.25 |  |  | $ | 6.41 |  |  | $ | 4.17 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | — |  |  |  | (0.02 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 0.94 |  |  | $ | 0.25 |  |  | $ | 6.39 |  |  | $ | 4.16 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.94 |  |  | $ | 0.25 |  |  | $ | 6.34 |  |  | $ | 4.11 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | — |  |  |  | (0.02 | ) |  |  | (0.02 | ) |
| Net income |  | $ | 0.93 |  |  | $ | 0.25 |  |  | $ | 6.32 |  |  | $ | 4.09 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 42.9 |  |  |  | 44.9 |  |  |  | 43.4 |  |  |  | 44.9 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 43.4 |  |  |  | 45.5 |  |  |  | 44.0 |  |  |  | 45.6 |  |
| Cash dividends declared per share |  | $ | 0.43 |  |  | $ | 0.36 |  |  | $ | 1.65 |  |  | $ | 1.38 |  |

[0001193125-17-032530:8k_2_02:69]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-032530:8k_2_02:70]
Segment Net Sales and Profit (Loss)

[0001193125-17-032530:8k_2_02:71]
| (Amounts in millions) |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 476.3 |  |  | $ | 431.2 |  |  | $ | 2,000.8 |  |  | $ | 1,866.9 |  |
| Commercial Heating & Cooling |  |  | 243.3 |  |  |  | 226.9 |  |  |  | 917.9 |  |  |  | 887.2 |  |
| Refrigeration |  |  | 177.7 |  |  |  | 176.0 |  |  |  | 722.9 |  |  |  | 713.3 |  |
|  |  | $ | 897.3 |  |  | $ | 834.1 |  |  | $ | 3,641.6 |  |  | $ | 3,467.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 81.9 |  |  | $ | 57.1 |  |  | $ | 348.8 |  |  | $ | 278.4 |  |
| Commercial Heating & Cooling |  |  | 38.7 |  |  |  | 34.8 |  |  |  | 149.3 |  |  |  | 130.4 |  |
| Refrigeration |  |  | 15.6 |  |  |  | 15.4 |  |  |  | 68.9 |  |  |  | 52.9 |  |
| Corporate and other |  |  | (31.6 | ) |  |  | (26.5 | ) |  |  | (97.4 | ) |  |  | (84.1 | ) |
| Total segment profit |  |  | 104.6 |  |  |  | 80.8 |  |  |  | 469.6 |  |  |  | 377.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | — |  |  |  | (1.5 | ) |  |  | (0.4 | ) |  |  | (2.2 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (1) |  |  | 4.5 |  |  |  | 4.9 |  |  |  | 7.4 |  |  |  | 15.6 |  |
| Restructuring charges |  |  | 0.7 |  |  |  | 1.4 |  |  |  | 1.8 |  |  |  | 3.2 |  |
| Pension settlement |  |  | 31.4 |  |  |  | — |  |  |  | 31.4 |  |  |  | — |  |
| Goodwill impairment |  |  | — |  |  |  | 5.5 |  |  |  | — |  |  |  | 5.5 |  |
| Asset impairment |  |  | — |  |  |  | 44.5 |  |  |  | — |  |  |  | 44.5 |  |
| One time inventory write down |  |  | — |  |  |  | 5.6 |  |  |  | — |  |  |  | 5.6 |  |
| Operating income |  | $ | 68.0 |  |  | $ | 20.4 |  |  | $ | 429.4 |  |  | $ | 305.4 |  |

[0001193125-17-032530:8k_2_02:72]
| (1) | The Company defines segment profit and loss as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-17-032530:8k_2_02:73]
|  | • |  | Special product quality adjustments; |

[0001193125-17-032530:8k_2_02:74]
|  | • |  | The following items in Losses and other expenses, net: |

[0001193125-17-032530:8k_2_02:75]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-17-032530:8k_2_02:76]
|  | • |  | Special legal contingency charges, |

[0001193125-17-032530:8k_2_02:77]
|  | • |  | Asbestos-related litigation, |

[0001193125-17-032530:8k_2_02:78]
|  | • |  | Environmental liabilities, |

[0001193125-17-032530:8k_2_02:79]
|  | • |  | Contractor tax payments, |

[0001193125-17-032530:8k_2_02:80]
|  | • |  | Acquisition costs, and |

[0001193125-17-032530:8k_2_02:81]
|  | • |  | Other items, net; |

[0001193125-17-032530:8k_2_02:82]
|  | • |  | Restructuring charges; |

[0001193125-17-032530:8k_2_02:83]
|  | • |  | Goodwill and asset impairments; |

[0001193125-17-032530:8k_2_02:84]
|  | • |  | Pension settlement; and |

[0001193125-17-032530:8k_2_02:85]
|  | • |  | One time inventory write down. |

[0001193125-17-032530:8k_2_02:86]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-032530:8k_2_02:87]
Consolidated Balance Sheets

[0001193125-17-032530:8k_2_02:88]
| (Amounts in millions, except shares and par values) |  | As of December 31,2016 |  |  | As of December 31,2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 50.2 |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net of allowances of $6.7 and $6.3 in 2016 and 2015, respectively |  |  | 469.8 |  |  |  | 422.8 |  |
| Inventories, net |  |  | 418.5 |  |  |  | 418.8 |  |
| Other assets |  |  | 67.4 |  |  |  | 57.7 |  |
| Total current assets |  |  | 1,005.9 |  |  |  | 938.2 |  |
| Property, plant and equipment, net of accumulated depreciation of $717.2 and $682.9 in 2016 and 2015, respectively |  |  | 361.4 |  |  |  | 339.6 |  |
| Goodwill |  |  | 195.1 |  |  |  | 195.1 |  |
| Deferred income taxes |  |  | 136.7 |  |  |  | 145.7 |  |
| Other assets, net |  |  | 61.2 |  |  |  | 58.8 |  |
| Total assets |  | $ | 1,760.3 |  |  | $ | 1,677.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 52.4 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt |  |  | 200.1 |  |  |  | 31.0 |  |
| Accounts payable |  |  | 361.2 |  |  |  | 320.1 |  |
| Accrued expenses |  |  | 265.9 |  |  |  | 242.6 |  |
| Income taxes payable |  |  | 9.0 |  |  |  | 26.0 |  |
| Total current liabilities |  |  | 888.6 |  |  |  | 823.8 |  |
| Long-term debt |  |  | 615.7 |  |  |  | 506.0 |  |
| Post-retirement benefits, other than pensions |  |  | 2.8 |  |  |  | 4.1 |  |
| Pensions |  |  | 87.5 |  |  |  | 120.8 |  |
| Other liabilities |  |  | 127.7 |  |  |  | 121.1 |  |
| Total liabilities |  |  | 1,722.3 |  |  |  | 1,575.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,046.2 |  |  |  | 1,002.4 |  |
| Retained earnings |  |  | 1,353.0 |  |  |  | 1,146.7 |  |
| Accumulated other comprehensive loss |  |  | (195.1 | ) |  |  | (204.7 | ) |
| Treasury stock, at cost, 44,195,250 shares and 42,491,910 shares for 2016 and 2015, respectively |  |  | (2,167.4 | ) |  |  | (1,844.1 | ) |
| Noncontrolling interests |  |  | 0.4 |  |  |  | 0.4 |  |
| Total stockholders’ equity |  |  | 38.0 |  |  |  | 101.6 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,760.3 |  |  | $ | 1,677.4 |  |

[0001193125-17-032530:8k_2_02:89]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-032530:8k_2_02:90]
Consolidated Statements of Cash Flow

[0001193125-17-032530:8k_2_02:91]
| (Amounts in millions) |  | For the Years Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 277.8 |  |  | $ | 186.6 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (18.4 | ) |  |  | (13.4 | ) |
| Dividends from affiliates |  |  | 14.9 |  |  |  | 11.0 |  |
| Restructuring expenses, net of cash paid |  |  | (0.8 | ) |  |  | — |  |
| Goodwill impairment |  |  | — |  |  |  | 5.5 |  |
| Impairment of assets |  |  | — |  |  |  | 44.5 |  |
| Provision for bad debts |  |  | 2.4 |  |  |  | 2.8 |  |
| Unrealized (gains) losses on derivative contracts |  |  | (0.7 | ) |  |  | 0.8 |  |
| Stock-based compensation expense |  |  | 31.7 |  |  |  | 26.6 |  |
| Depreciation and amortization |  |  | 58.1 |  |  |  | 62.8 |  |
| Deferred income taxes |  |  | (4.0 | ) |  |  | (21.3 | ) |
| Pension expense |  |  | 37.7 |  |  |  | 10.6 |  |
| Pension contributions |  |  | (53.9 | ) |  |  | (3.9 | ) |
| Other items, net |  |  | 0.9 |  |  |  | 1.0 |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (50.6 | ) |  |  | (23.5 | ) |
| Inventories |  |  | 0.3 |  |  |  | 28.8 |  |
| Other current assets |  |  | 0.1 |  |  |  | (1.6 | ) |
| Accounts payable |  |  | 40.1 |  |  |  | (2.9 | ) |
| Accrued expenses |  |  | 36.2 |  |  |  | 4.2 |  |
| Income taxes payable and receivable |  |  | (19.5 | ) |  |  | 10.9 |  |
| Other, net |  |  | 2.2 |  |  |  | 1.7 |  |
| Net cash provided by operating activities |  |  | 354.5 |  |  |  | 331.2 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.2 |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | (84.3 | ) |  |  | (69.9 | ) |
| Net cash used in investing activities |  |  | (84.1 | ) |  |  | (69.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (2.4 | ) |  |  | (1.7 | ) |
| Asset securitization borrowings |  |  | 70.0 |  |  |  | 40.0 |  |
| Asset securitization payments |  |  | (220.0 | ) |  |  | (60.0 | ) |
| Term loan borrowings from credit facility |  |  | 350.0 |  |  |  | — |  |
| Long-term debt payments |  |  | (58.8 | ) |  |  | (24.0 | ) |
| Borrowings from credit facility |  |  | 2,336.5 |  |  |  | 1,671.0 |  |
| Payments on credit facility |  |  | (2,346.0 | ) |  |  | (1,807.5 | ) |
| Payments of deferred financing costs |  |  | (4.2 | ) |  |  | — |  |
| Proceeds from employee stock purchases |  |  | 2.6 |  |  |  | 2.4 |  |
| Repurchases of common stock |  |  | (300.0 | ) |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (33.3 | ) |  |  | (32.0 | ) |
| Excess tax benefits related to share-based payments |  |  | 19.4 |  |  |  | 22.4 |  |
| Cash dividends paid |  |  | (69.0 | ) |  |  | (59.3 | ) |
| Net cash used in financing activities |  |  | (255.2 | ) |  |  | (248.7 | ) |
| Increase in cash and cash equivalents |  |  | 15.2 |  |  |  | 12.7 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (3.9 | ) |  |  | (11.3 | ) |
| Cash and cash equivalents, beginning of year |  |  | 38.9 |  |  |  | 37.5 |  |
| Cash and cash equivalents, end of year |  | $ | 50.2 |  |  | $ | 38.9 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the year for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 26.3 |  |  | $ | 23.7 |  |
| Income taxes (net of refunds) |  | $ | 127.4 |  |  | $ | 83.2 |  |

[0001193125-17-032530:8k_2_02:92]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-032530:8k_2_02:93]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-17-032530:8k_2_02:94]
(Unaudited, in millions, except per share and ratio data)

[0001193125-17-032530:8k_2_02:95]
Use of Non-GAAP Financial Measures

[0001193125-17-032530:8k_2_02:96]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance.

[0001193125-17-032530:8k_2_02:97]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted
Income from Continuing Operations, a Non-GAAP measure

[0001193125-17-032530:8k_2_02:98]
|  |  | For the Three Months Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  |  |  |  | Tax |  |  |  |  |  |  |  |  | Tax |  |  |  |  |
|  |  | Pre-Tax |  |  | Impact (c) |  |  | After Tax |  |  | Pre-Tax |  |  | Impact (c) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  |  | 60.7 |  |  |  | (20.0 | ) |  |  | 40.7 |  |  | $ | 14.7 |  |  | $ | (3.5 | ) |  | $ | 11.2 |  |
| Restructuring charges, after tax |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 0.5 |  |  |  | 1.4 |  |  |  | (0.4 | ) |  |  | 1.0 |  |
| Asset impairment, after tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 44.5 |  |  |  | (15.5 | ) |  |  | 29.0 |  |
| Goodwill impairment, after tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.5 |  |  |  | (1.9 | ) |  |  | 3.6 |  |
| Special product quality adjustments, after tax (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.5 | ) |  |  | 0.6 |  |  |  | (0.9 | ) |
| Special legal contingency charges, after tax (a) |  |  | 1.4 |  |  |  | — |  |  |  | 1.4 |  |  |  | 1.9 |  |  |  | (1.3 | ) |  |  | 0.6 |  |
| Asbestos-related litigation, after tax (a) |  |  | 4.0 |  |  |  | (1.4 | ) |  |  | 2.6 |  |  |  | 2.0 |  |  |  | (0.7 | ) |  |  | 1.3 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts, after tax (a) |  |  | (1.7 | ) |  |  | 0.6 |  |  |  | (1.1 | ) |  |  | (0.2 | ) |  |  | — |  |  |  | (0.2 | ) |
| Inventory write down, after tax (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.6 |  |  |  | (1.8 | ) |  |  | 3.8 |  |
| Environmental liabilities, after tax (a) |  |  | 0.8 |  |  |  | (0.2 | ) |  |  | 0.6 |  |  |  | 0.3 |  |  |  | — |  |  |  | 0.3 |  |
| Contractor tax payments, after tax (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Pension settlement charges |  |  | 31.4 |  |  |  | (10.9 | ) |  |  | 20.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.7 |  |  |  | (0.3 | ) |  |  | 0.4 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 97.3 |  |  | $ | (32.1 | ) |  | $ | 65.2 |  |  | $ | 75.1 |  |  | $ | (24.8 | ) |  | $ | 50.3 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 0.94 |  |  |  |  |  |  |  |  |  |  | $ | 0.25 |  |
| Restructuring charges, after tax |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Asset impairment, after tax |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.64 |  |
| Goodwill impairment, after tax |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.08 |  |
| Special product quality adjustments, after tax (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |
| Special legal contingency charges, after tax (a) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Asbestos-related litigation, after tax (a) |  |  |  |  |  |  |  |  |  |  | 0.06 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts, after tax (a) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Inventory write down, after tax (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.08 |  |
| Environmental liabilities, after tax (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Contractor tax payments, after tax (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Pension settlement charges |  |  |  |  |  |  |  |  |  |  | 0.47 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Other items, net, after tax (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 1.50 |  |  |  |  |  |  |  |  |  |  | $ | 1.11 |  |

[0001193125-17-032530:8k_2_02:99]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-17-032530:8k_2_02:100]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-17-032530:8k_2_02:101]
| (c) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-17-032530:8k_2_02:102]
|  |  | For the Years Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  |  |  |  | Tax |  |  |  |  |  |  |  |  | Tax |  |  |  |  |
|  |  | Pre-Tax |  |  | Impact (c) |  |  | After Tax |  |  | Pre-Tax |  |  | Impact (c) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 402.7 |  |  | $ | (124.1 | ) |  | $ | 278.6 |  |  | $ | 282.6 |  |  | $ | (95.4 | ) |  | $ | 187.2 |  |
| Restructuring charges, after tax |  |  | 1.8 |  |  |  | (0.6 | ) |  |  | 1.2 |  |  |  | 3.2 |  |  |  | (0.9 | ) |  |  | 2.3 |  |
| Asset impairment, after tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 44.5 |  |  |  | (15.5 | ) |  |  | 29.0 |  |
| Goodwill impairment, after tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.5 |  |  |  | (1.9 | ) |  |  | 3.6 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |  |  | (2.1 | ) |  |  | 0.8 |  |  |  | (1.3 | ) |
| Special legal contingency charges, after tax (a) |  |  | 1.9 |  |  |  | (0.1 | ) |  |  | 1.8 |  |  |  | 7.4 |  |  |  | (3.4 | ) |  |  | 4.0 |  |
| Asbestos-related litigation, after tax (a) |  |  | 6.3 |  |  |  | (2.2 | ) |  |  | 4.1 |  |  |  | 3.0 |  |  |  | (1.1 | ) |  |  | 1.9 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts, after tax (a) |  |  | (3.6 | ) |  |  | 1.3 |  |  |  | (2.3 | ) |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | 0.4 |  |
| Inventory write down, after tax (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.6 |  |  |  | (1.8 | ) |  |  | 3.8 |  |
| Environmental liabilities, after tax (a) |  |  | 1.9 |  |  |  | (0.5 | ) |  |  | 1.4 |  |  |  | 1.0 |  |  |  | — |  |  |  | 1.0 |  |
| Contractor tax payments, after tax (a) |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | 0.4 |  |  |  | 2.6 |  |  |  | (0.9 | ) |  |  | 1.7 |  |
| Pension settlement charges |  |  | 31.4 |  |  |  | (10.9 | ) |  |  | 20.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other items, net, after tax (a) |  | $ | 0.4 |  |  | $ | (0.2 | ) |  | $ | 0.2 |  |  |  | 0.9 |  |  |  | (0.3 | ) |  |  | 0.6 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 443.0 |  |  | $ | (137.4 | ) |  | $ | 305.6 |  |  | $ | 354.8 |  |  | $ | (120.6 | ) |  | $ | 234.2 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 6.34 |  |  |  |  |  |  |  |  |  |  | $ | 4.11 |  |
| Restructuring charges, after tax |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.05 |  |
| Asset impairment, after tax |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.64 |  |
| Goodwill impairment, after tax |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.08 |  |
| Special product quality adjustments, after tax (b) |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |
| Special legal contingency charges, after tax (a) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | 0.09 |  |
| Asbestos-related litigation, after tax (a) |  |  |  |  |  |  |  |  |  |  | 0.09 |  |  |  |  |  |  |  |  |  |  |  | 0.04 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts and other items, net, after tax (a) |  |  |  |  |  |  |  |  |  |  | (0.05 | ) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Inventory write down (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.08 |  |
| Environmental liabilities, after tax (a) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Contractor tax payments, after tax (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.04 |  |
| Pension settlement charges |  |  |  |  |  |  |  |  |  |  | 0.47 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Other items, net, after tax (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 6.95 |  |  |  |  |  |  |  |  |  |  | $ | 5.14 |  |

[0001193125-17-032530:8k_2_02:103]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-17-032530:8k_2_02:104]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-17-032530:8k_2_02:105]
| (c) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-17-032530:8k_2_02:106]
|  |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Components of Losses and other expenses, net (pre- tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | (0.2 | ) |  | $ | 0.6 |  |  | $ | 1.1 |  |  | $ | 1.9 |  |
| Foreign currency exchange losses (a) |  |  | 1.2 |  |  |  | 0.8 |  |  |  | 2.2 |  |  |  | 3.6 |  |
| Gain on disposal of fixed assets (a) |  |  | 0.3 |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | 0.6 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | (1.7 | ) |  |  | (0.2 | ) |  |  | (3.6 | ) |  |  | 0.6 |  |
| Special legal contingency charges (b) |  |  | 1.4 |  |  |  | 1.9 |  |  |  | 1.9 |  |  |  | 7.4 |  |
| Asbestos-related litigation (b) |  |  | 4.0 |  |  |  | 2.0 |  |  |  | 6.3 |  |  |  | 3.0 |  |
| Environmental liabilities (b) |  |  | 0.8 |  |  |  | 0.3 |  |  |  | 1.9 |  |  |  | 1.0 |  |
| Contractor tax payments (b) |  |  | — |  |  |  | 0.2 |  |  |  | 0.6 |  |  |  | 2.6 |  |
| Acquisition costs (b) |  |  | — |  |  |  | 0.7 |  |  |  | 0.4 |  |  |  | 1.0 |  |
| Other items, net (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Losses and other expenses, net (pre-tax) |  | $ | 5.8 |  |  | $ | 6.8 |  |  | $ | 11.3 |  |  | $ | 21.7 |  |

[0001193125-17-032530:8k_2_02:107]
| (a) | Included in segment profit (loss) and Adjusted income from continuing operations |

[0001193125-17-032530:8k_2_02:108]
| (b) | Excluded from segment profit (loss) and Adjusted income from continuing operations |

[0001193125-17-032530:8k_2_02:109]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-17-032530:8k_2_02:110]
|  |  | For the YearEndedDecember 31,2017ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 7.55-$8.15 |  |
| Restructuring and other items |  |  | 0.00 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 7.55-$8.15 |  |

[0001193125-17-032530:8k_2_02:111]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-17-032530:8k_2_02:112]
|  |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 247.6 |  |  | $ | 224.3 |  |  | $ | 354.5 |  |  | $ | 331.2 |  |
| Purchases of property, plant and equipment |  |  | (24.9 | ) |  |  | (22.9 | ) |  |  | (84.3 | ) |  |  | (69.9 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.1 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 222.9 |  |  | $ | 201.5 |  |  | $ | 270.4 |  |  | $ | 261.4 |  |

[0001193125-17-032530:8k_2_02:113]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelveMonths toDecember 31,2016 |  |
| Adjusted EBIT (a) |  | $ | 469.6 |  |
| Depreciation and amortization expense (b) |  |  | 58.1 |  |
| EBITDA (a + b) |  | $ | 527.7 |  |
| Total debt at December 31, 2016 (c) |  | $ | 868.2 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 1.6 |  |

[0001193125-17-032530:8k_2_02:114]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing
Operations Before Income Taxes, a GAAP measure (dollars in millions)

[0001193125-17-032530:8k_2_02:115]
|  |  | TrailingTwelveMonths toDecember 31,2016 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 469.6 |  |
| Special product quality adjustments |  |  | (0.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 7.4 |  |
| Restructuring charges |  |  | 1.8 |  |
| Interest expense, net |  |  | 27.0 |  |
| Pension settlement charges |  |  | 31.4 |  |
| Other expenses, net |  |  | (0.3 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 402.7 |  |
