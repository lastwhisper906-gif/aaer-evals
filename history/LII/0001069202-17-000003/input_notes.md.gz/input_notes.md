# LII notes — 0001069202-17-000003


## us-gaap:ScheduleOfChangesInProjectedBenefitObligationsTableTextBlock

[0001069202-17-000003:notes:1]
$50.6 million.


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-17-000003:notes:2]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 250.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 50.0 |  |  | 200.0 |  |
| Remaining amount available | $ | 200.0 |  |  | $ | 20.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-17-000003:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-17-000003:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:ScheduleOfFairValueOfPerformanceShareUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-17-000003:notes:5]
The total fair value of performance share units distributed and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-17-000003:notes:6]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Fair value of performance share units distributed | $ | 39.4 |  |  | $ | 44.9 |  |  | $ | 19.6 |  |
| Realized tax benefits from tax deductions | $ | 15.0 |  |  | $ | 17.1 |  |  | $ | 7.5 |  |


## lii:ScheduleOfFairValueOfRestrictedStockUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-17-000003:notes:7]
The total fair value of restricted stock units vested and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-17-000003:notes:8]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Fair value of restricted stock units vested | $ | 17.0 |  |  | $ | 19.7 |  |  | $ | 19.5 |  |
| Realized tax benefits from tax deductions | 6.5 |  |  | 7.5 |  |  | 7.4 |  |


## lii:ScheduleOfIntrinsicValueAndTaxBenefitsRelatedToStockAppreciationRightsTableTextBlock

[0001069202-17-000003:notes:9]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-17-000003:notes:10]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Intrinsic value of stock appreciation rights exercised | $ | 36.9 |  |  | $ | 27.3 |  |  | $ | 27.3 |  |
| Realized tax benefits from tax deductions | $ | 14.1 |  |  | $ | 10.4 |  |  | $ | 10.4 |  |


## lii:ScheduleOfShareBasedCompensationSharesAuthorizedUnderEquityInstrumentOtherThanOptionPlansByExercisePriceRangeTableTextBlock

[0001069202-17-000003:notes:11]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2016 (in millions, except per share data and years):

[0001069202-17-000003:notes:12]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $34.06 to $51.40 |  | 0.3 |  |  | 2.44 |  | $ | 34.3 |  |  | 0.3 |  |  | 2.44 |  | $ | 34.3 |  |
| $81.11 to $92.64 |  | 0.4 |  |  | 4.54 |  | $ | 25.2 |  |  | 0.3 |  |  | 4.44 |  | $ | 21.0 |  |
| $124.97 to $156.94 |  | 0.4 |  |  | 6.55 |  | $ | 4.3 |  |  | 0.1 |  |  | 5.93 |  | $ | 1.4 |  |


## lii:SummaryOfTargetAllocationPercentageOfAssetsTableTextBlock

[0001069202-17-000003:notes:13]
U.S. pension plan assets are invested according to the following targets:

[0001069202-17-000003:notes:14]
| Asset Category: | Target |
| U.S. equity | 25.0 | % |
| International equity | 17.0 | % |
| Fixed income | 56.0 | % |
| Money market/cash | 2.0 | % |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-17-000003:notes:15]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-17-000003:notes:16]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Weighted average borrowing rate | 2.00 | % |  | 1.90 | % |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-17-000003:notes:17]
Accrued Expenses:

[0001069202-17-000003:notes:18]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-17-000003:notes:19]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Accrued compensation and benefits | $ | 89.8 |  |  | $ | 69.0 |  |
| Accrued rebates and promotions | 64.6 |  |  | 53.6 |  |
| Accrued warranties | 30.0 |  |  | 26.7 |  |
| Accrued Sales, Use, Property and VAT taxes | 20.2 |  |  | 15.4 |  |
| Accrued asbestos reserves | 9.8 |  |  | 7.7 |  |
| Self insurance reserves | 8.2 |  |  | 9.2 |  |
| Deferred income | 6.4 |  |  | 6.8 |  |
| Derivative contracts | 4.0 |  |  | 14.4 |  |
| Other | 32.9 |  |  | 39.8 |  |
| Total Accrued expenses | $ | 265.9 |  |  | $ | 242.6 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-17-000003:notes:20]
Supplemental Information:

[0001069202-17-000003:notes:21]
Below is information about expenses included in our Consolidated Statements of Operations (in millions):

[0001069202-17-000003:notes:22]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Research and development | $ | 64.6 |  |  | $ | 62.3 |  |  | $ | 60.7 |  |
| Advertising, promotions and marketing (1) | 41.0 |  |  | 42.5 |  |  | 41.9 |  |
| Cooperative advertising expenditures (2) | 14.7 |  |  | 13.7 |  |  | 13.1 |  |
| Rent expense | 57.9 |  |  | 53.5 |  |  | 50.5 |  |

[0001069202-17-000003:notes:23]
(1) Cooperative advertising expenditures were not included in these amounts.

[0001069202-17-000003:notes:24]
(2) Cooperative advertising expenditures were included in Selling, general and administrative expenses in the Consolidated Statements of Operations.

[0001069202-17-000003:notes:25]
Interest Expense, net

[0001069202-17-000003:notes:26]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-17-000003:notes:27]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Interest expense, net of capitalized interest | $ | 28.1 |  |  | $ | 25.2 |  |  | $ | 18.9 |  |
| Interest income | 1.1 |  |  | 1.6 |  |  | 1.7 |  |
| Interest expense, net | $ | 27.0 |  |  | $ | 23.6 |  |  | $ | 17.2 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001069202-17-000003:notes:28]
Cash and Cash Equivalents

[0001069202-17-000003:notes:29]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-17-000003:notes:30]
Commitments and Contingencies:

[0001069202-17-000003:notes:31]
Leases

[0001069202-17-000003:notes:32]
We lease certain real and personal property under non-cancelable operating leases.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions.  We recognize our minimum rental expense on a straight-line basis.  We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use.

[0001069202-17-000003:notes:33]
Future annual minimum lease payments and capital lease commitments as of December 31, 2016 were as follows (in millions):

[0001069202-17-000003:notes:34]
|  | Operating Leases |  | Capital Leases |
| 2017 | $ | 48.3 |  |  | $ | 1.4 |  |
| 2018 | 38.1 |  |  | 0.8 |  |
| 2019 | 27.5 |  |  | 0.2 |  |
| 2020 | 16.9 |  |  | 0.1 |  |
| 2021 | 9.8 |  |  | — |  |
| Thereafter | 18.2 |  |  | 14.6 |  |
| Total minimum lease payments | $ | 158.8 |  |  | $ | 17.1 |  |
| Less amount representing interest |  |  | 0.4 |  |
| Present value of minimum payments |  |  | $ | 16.7 |  |

[0001069202-17-000003:notes:35]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the “Lake Park Renewal”).  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-17-000003:notes:36]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Sixth Amended and Restated Credit Facility Agreement.  We believe we were in compliance with these financial covenants as of December 31, 2016.

[0001069202-17-000003:notes:37]
Environmental

[0001069202-17-000003:notes:38]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities; however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000003:notes:39]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Accrued expenses | $ | 1.2 |  |  | $ | 1.3 |  |
| Other liabilities | 4.4 |  |  | 4.0 |  |
| Total environmental accruals | $ | 5.6 |  |  | $ | 5.3 |  |

[0001069202-17-000003:notes:40]
Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-17-000003:notes:41]
Product Warranties and Product Related Contingencies

[0001069202-17-000003:notes:42]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-17-000003:notes:43]
Total product warranty liabilities related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000003:notes:44]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Accrued expenses | $ | 30.0 |  |  | $ | 26.7 |  |
| Other liabilities | 71.1 |  |  | 65.6 |  |
| Total product warranty liabilities | $ | 101.1 |  |  | $ | 92.3 |  |

[0001069202-17-000003:notes:45]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2016 and 2015 were as follows (in millions):

[0001069202-17-000003:notes:46]
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |
| Payments made in 2015 | (27.2 | ) |
| Changes resulting from issuance of new warranties | 37.1 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | (2.2 | ) |
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |
| Payments made in 2016 | (24.7 | ) |
| Changes resulting from issuance of new warranties | 36.2 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | (0.1 | ) |
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |

[0001069202-17-000003:notes:47]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.  Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a certain supplier quality issue within a range of $0.9 million  and $9.1 million with all amounts in that range equally likely.  We have accrued a $0.9 million liability in Accrued expenses on the Consolidated Balance Sheet at December 31, 2016. The supplier is reimbursing the majority of costs related to this liability.

[0001069202-17-000003:notes:48]
Self-Insurance

[0001069202-17-000003:notes:49]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability, auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers' compensation/employers' liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors' and officers' liability, property damage and certain other insurance programs.    For directors' and officers' liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-17-000003:notes:50]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001069202-17-000003:notes:51]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000003:notes:52]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Accrued expenses | $ | 8.2 |  |  | $ | 9.2 |  |
| Other liabilities | 22.7 |  |  | 23.9 |  |
| Total self-insurance liabilities | $ | 30.9 |  |  | $ | 33.1 |  |

[0001069202-17-000003:notes:53]
Litigation

[0001069202-17-000003:notes:54]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-17-000003:notes:55]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors, and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the years ended December 31, 2016, 2015 and 2014, we recorded expense of $6.3 million, $3.0 million and $0.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation.

[0001069202-17-000003:notes:56]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants. The alleged payment was purportedly made to release a shipment of goods being held by Russian customs officials due to inaccurate paperwork. The value of the shipment was approximately €62,000 (approximately US $68,500). The allegations are related to our subsidiary in Russia, which had 2016 annual sales of approximately US $4 million. The scope of the investigation was later expanded to include our operations in Poland because our operations in Russia and Poland used the same third-party logistics provider.  To date, the investigation has not resulted in any evidence of other potentially improper payments. However, the investigation has raised questions regarding possible irregularities with respect to possible non-compliance with customs documents and procedures related to these operations.  The investigation is ongoing. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.

[0001069202-17-000003:notes:57]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-17-000003:notes:58]
Comprehensive Income:

[0001069202-17-000003:notes:59]
The following table provides information on items not reclassified in their entirety from AOCI to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-17-000003:notes:60]
|  |  | For the Years Ended December 31, |  |  |
| AOCI Component |  | 2016 |  | 2015 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Losses on cash flow hedges: |  |  |  |  |  |  |
| Commodity derivative contracts |  | $ | (12.3 | ) |  | $ | (12.5 | ) |  | Cost of goods sold |
| Income tax benefit |  | 4.3 |  |  | 4.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (8.0 | ) |  | $ | (8.1 | ) |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and Post-Retirement Benefits costs |  | $ | (6.3 | ) |  | $ | (9.7 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 2.2 |  |  | 3.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (4.1 | ) |  | $ | (6.3 | ) |  |  |
| Total reclassifications from AOCI |  | $ | (12.1 | ) |  | $ | (14.4 | ) |  |  |

[0001069202-17-000003:notes:61]
The following tables provide information on changes in AOCI, by component (net of tax), for the years ended December 31, 2016 and 2015 (in millions):

[0001069202-17-000003:notes:62]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2015 |  | $ | (8.4 | ) |  | $ | 4.4 |  |  | $ | (139.3 | ) |  | $ | (61.4 | ) |  | $ | (204.7 | ) |
| Other comprehensive income (loss) before reclassifications |  | 6.0 |  |  | (2.1 | ) |  | 5.2 |  |  | (11.6 | ) |  | (2.5 | ) |
| Amounts reclassified from AOCI |  | 8.0 |  |  | — |  |  | 4.1 |  |  | — |  |  | 12.1 |  |
| Net other comprehensive income (loss) |  | 14.0 |  |  | (2.1 | ) |  | 9.3 |  |  | (11.6 | ) |  | 9.6 |  |
| Balance as of December 31, 2016 |  | $ | 5.6 |  |  | $ | 2.3 |  |  | $ | (130.0 | ) |  | $ | (73.0 | ) |  | $ | (195.1 | ) |

[0001069202-17-000003:notes:63]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2014 |  | $ | (4.6 | ) |  | $ | 3.2 |  |  | $ | (149.4 | ) |  | $ | (2.7 | ) |  | $ | (153.5 | ) |
| Other comprehensive income (loss) before reclassifications |  | (11.9 | ) |  | 1.2 |  |  | 3.8 |  |  | (58.7 | ) |  | (65.6 | ) |
| Amounts reclassified from AOCI |  | 8.1 |  |  | — |  |  | 6.3 |  |  | — |  |  | 14.4 |  |
| Net other comprehensive income (loss) |  | (3.8 | ) |  | 1.2 |  |  | 10.1 |  |  | (58.7 | ) |  | (51.2 | ) |
| Balance as of December 31, 2015 |  | $ | (8.4 | ) |  | $ | 4.4 |  |  | $ | (139.3 | ) |  | $ | (61.4 | ) |  | $ | (204.7 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-17-000003:notes:64]
Condensed Consolidating Financial Statements:

[0001069202-17-000003:notes:65]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-17-000003:notes:66]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present condensed consolidating financial statements.

[0001069202-17-000003:notes:67]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001069202-17-000003:notes:68]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2016 and December 31, 2015 and for the years ended December 31, 2016, 2015 and 2014 are shown on the following pages.

[0001069202-17-000003:notes:69]
Condensed Consolidating Balance Sheets

[0001069202-17-000003:notes:70]
As of December 31, 2016

[0001069202-17-000003:notes:71]
(In millions)

[0001069202-17-000003:notes:72]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 17.1 |  |  | $ | 31.9 |  |  | $ | — |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net | — |  |  | 30.6 |  |  | 439.2 |  |  | — |  |  | 469.8 |  |
| Inventories, net | — |  |  | 314.7 |  |  | 108.9 |  |  | (5.1 | ) |  | 418.5 |  |
| Other assets | 12.8 |  |  | 48.8 |  |  | 67.5 |  |  | (61.7 | ) |  | 67.4 |  |
| Total current assets | 14.0 |  |  | 411.2 |  |  | 647.5 |  |  | (66.8 | ) |  | 1,005.9 |  |
| Property, plant and equipment, net | — |  |  | 237.6 |  |  | 123.8 |  |  | — |  |  | 361.4 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 1,166.9 |  |  | 524.7 |  |  | (0.5 | ) |  | (1,691.1 | ) |  | — |  |
| Deferred income taxes | 6.8 |  |  | 113.5 |  |  | 31.1 |  |  | (14.7 | ) |  | 136.7 |  |
| Other assets, net | 3.6 |  |  | 40.0 |  |  | 19.0 |  |  | (1.4 | ) |  | 61.2 |  |
| Intercompany receivables (payables), net | (382.4 | ) |  | 375.2 |  |  | 80.4 |  |  | (73.2 | ) |  | — |  |
| Total assets | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | — |  |  | $ | 52.4 |  |
| Current maturities of long-term debt | 199.3 |  |  | 0.4 |  |  | 0.4 |  |  | — |  |  | 200.1 |  |
| Accounts payable | 18.5 |  |  | 248.5 |  |  | 94.2 |  |  | — |  |  | 361.2 |  |
| Accrued expenses | 6.3 |  |  | 206.3 |  |  | 53.3 |  |  | — |  |  | 265.9 |  |
| Income taxes payable | (54.0 | ) |  | 89.8 |  |  | 52.5 |  |  | (79.3 | ) |  | 9.0 |  |
| Total current liabilities | 170.1 |  |  | 545.0 |  |  | 252.8 |  |  | (79.3 | ) |  | 888.6 |  |
| Long-term debt | 600.9 |  |  | 14.5 |  |  | 0.3 |  |  | — |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.8 |  |  | — |  |  | — |  |  | 2.8 |  |
| Pensions | — |  |  | 75.5 |  |  | 12.0 |  |  | — |  |  | 87.5 |  |
| Other liabilities | — |  |  | 119.1 |  |  | 11.1 |  |  | (2.5 | ) |  | 127.7 |  |
| Total liabilities | 771.0 |  |  | 756.9 |  |  | 276.2 |  |  | (81.8 | ) |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 37.9 |  |  | 1,080.2 |  |  | 685.3 |  |  | (1,765.4 | ) |  | 38.0 |  |
| Total liabilities and stockholders' equity | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |

[0001069202-17-000003:notes:73]
As of December 31, 2015

[0001069202-17-000003:notes:74]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.5 |  |  | $ | 7.8 |  |  | $ | 30.6 |  |  | $ | — |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net | — |  |  | 25.9 |  |  | 396.9 |  |  | — |  |  | 422.8 |  |
| Inventories, net | — |  |  | 324.3 |  |  | 98.9 |  |  | (4.4 | ) |  | 418.8 |  |
| Other assets | 3.3 |  |  | 46.9 |  |  | 67.4 |  |  | (59.9 | ) |  | 57.7 |  |
| Total current assets | 3.8 |  |  | 404.9 |  |  | 593.8 |  |  | (64.3 | ) |  | 938.2 |  |
| Property, plant and equipment, net | — |  |  | 261.8 |  |  | 77.8 |  |  | — |  |  | 339.6 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 879.0 |  |  | 337.6 |  |  | (0.6 | ) |  | (1,216.0 | ) |  | — |  |
| Deferred income taxes | 5.4 |  |  | 126.6 |  |  | 28.4 |  |  | (14.7 | ) |  | 145.7 |  |
| Other assets, net | 1.5 |  |  | 38.2 |  |  | 20.6 |  |  | (1.5 | ) |  | 58.8 |  |
| Intercompany receivables (payables), net | (278.6 | ) |  | 253.3 |  |  | 25.3 |  |  | — |  |  | — |  |
| Total assets | $ | 611.1 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,677.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 204.1 |  |  | $ | — |  |  | $ | 204.1 |  |
| Current maturities of long-term debt | 29.8 |  |  | 0.8 |  |  | 0.4 |  |  | — |  |  | 31.0 |  |
| Accounts payable | 16.1 |  |  | 237.9 |  |  | 66.1 |  |  | — |  |  | 320.1 |  |
| Accrued expenses | 15.8 |  |  | 176.7 |  |  | 50.1 |  |  | — |  |  | 242.6 |  |
| Income taxes payable | (43.0 | ) |  | 106.6 |  |  | 37.9 |  |  | (75.5 | ) |  | 26.0 |  |
| Total current liabilities | 18.7 |  |  | 522.0 |  |  | 358.6 |  |  | (75.5 | ) |  | 823.8 |  |
| Long-term debt | 490.4 |  |  | 15.1 |  |  | 0.5 |  |  | — |  |  | 506.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.1 |  |  | — |  |  | — |  |  | 4.1 |  |
| Pensions | — |  |  | 111.9 |  |  | 8.9 |  |  | — |  |  | 120.8 |  |
| Other liabilities | 0.4 |  |  | 114.4 |  |  | 10.5 |  |  | (4.2 | ) |  | 121.1 |  |
| Total liabilities | 509.5 |  |  | 767.5 |  |  | 378.5 |  |  | (79.7 | ) |  | 1,575.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 101.6 |  |  | 789.8 |  |  | 427.0 |  |  | (1,216.8 | ) |  | 101.6 |  |
| Total liabilities and stockholders' equity | $ | 611.1 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,677.4 |  |

[0001069202-17-000003:notes:75]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-17-000003:notes:76]
For the Year Ended December 31, 2016

[0001069202-17-000003:notes:77]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 3,117.6 |  |  | $ | 728.0 |  |  | $ | (204.0 | ) |  | $ | 3,641.6 |  |
| Cost of goods sold | — |  |  | 2,203.8 |  |  | 564.5 |  |  | (203.2 | ) |  | 2,565.1 |  |
| Gross profit | — |  |  | 913.8 |  |  | 163.5 |  |  | (0.8 | ) |  | 1,076.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 524.3 |  |  | 96.7 |  |  | — |  |  | 621.0 |  |
| Losses and other expenses, net | (3.3 | ) |  | 9.7 |  |  | 5.1 |  |  | (0.2 | ) |  | 11.3 |  |
| Restructuring charges | — |  |  | 1.9 |  |  | (0.1 | ) |  | — |  |  | 1.8 |  |
| Goodwill impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Pension settlement | — |  |  | 30.5 |  |  | 0.9 |  |  | — |  |  | 31.4 |  |
| Income from equity method investments | (292.4 | ) |  | (40.7 | ) |  | (14.4 | ) |  | 329.1 |  |  | (18.4 | ) |
| Operational income | 295.7 |  |  | 388.1 |  |  | 75.3 |  |  | (329.7 | ) |  | 429.4 |  |
| Interest expense, net | 24.4 |  |  | (2.2 | ) |  | 4.8 |  |  | — |  |  | 27.0 |  |
| Other expense, net | — |  |  | — |  |  | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Income from continuing operations before income taxes | 271.3 |  |  | 390.3 |  |  | 70.8 |  |  | (329.7 | ) |  | 402.7 |  |
| Provision for income taxes | (6.5 | ) |  | 108.2 |  |  | 22.6 |  |  | (0.2 | ) |  | 124.1 |  |
| Income from continuing operations | 277.8 |  |  | 282.1 |  |  | 48.2 |  |  | (329.5 | ) |  | 278.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Net income | $ | 277.8 |  |  | $ | 282.1 |  |  | $ | 47.4 |  |  | $ | (329.5 | ) |  | $ | 277.8 |  |
| Other comprehensive income (loss) | $ | 14.0 |  |  | $ | 8.5 |  |  | $ | (14.2 | ) |  | $ | 1.3 |  |  | $ | 9.6 |  |
| Comprehensive Income | $ | 291.8 |  |  | $ | 290.6 |  |  | $ | 33.2 |  |  | $ | (328.2 | ) |  | $ | 287.4 |  |

[0001069202-17-000003:notes:78]
For the Year Ended December 31, 2015

[0001069202-17-000003:notes:79]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net sales | $ | — |  |  | $ | 2,950.6 |  |  | $ | 701.8 |  |  | $ | (185.0 | ) |  | $ | 3,467.4 |  |
| Cost of goods sold | — |  |  | 2,150.9 |  |  | 556.4 |  |  | (187.3 | ) |  | 2,520.0 |  |
| Gross profit | — |  |  | 799.7 |  |  | 145.4 |  |  | 2.3 |  |  | 947.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 485.6 |  |  | 94.9 |  |  | — |  |  | 580.5 |  |
| Losses (gains) and other expenses, net | 0.7 |  |  | 13.7 |  |  | 7.5 |  |  | (0.2 | ) |  | 21.7 |  |
| Restructuring charges | — |  |  | (0.5 | ) |  | 3.7 |  |  | — |  |  | 3.2 |  |
| Goodwill Impairment | — |  |  | 5.5 |  |  | — |  |  | — |  |  | 5.5 |  |
| Asset Impairment | — |  |  | 44.5 |  |  | — |  |  | — |  |  | 44.5 |  |
| Pension settlement | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| (Income) loss from equity method investments | (201.8 | ) |  | (5.9 | ) |  | (10.5 | ) |  | 204.8 |  |  | (13.4 | ) |
| Operational income | 201.1 |  |  | 256.8 |  |  | 49.8 |  |  | (202.3 | ) |  | 305.4 |  |
| Interest expense, net | 22.4 |  |  | (2.0 | ) |  | 3.2 |  |  | — |  |  | 23.6 |  |
| Other expense, net | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Income from continuing operations before income taxes | 178.7 |  |  | 258.8 |  |  | 47.4 |  |  | (202.3 | ) |  | 282.6 |  |
| Provision for income taxes | (7.8 | ) |  | 87.9 |  |  | 14.3 |  |  | 1.0 |  |  | 95.4 |  |
| Income from continuing operations | 186.5 |  |  | 170.9 |  |  | 33.1 |  |  | (203.3 | ) |  | 187.2 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.6 | ) |  | — |  |  | (0.6 | ) |
| Net income | $ | 186.5 |  |  | $ | 170.9 |  |  | $ | 32.5 |  |  | $ | (203.3 | ) |  | $ | 186.6 |  |
| Other comprehensive income (loss) | $ | (3.5 | ) |  | $ | (3.3 | ) |  | $ | (40.4 | ) |  | $ | (4.0 | ) |  | $ | (51.2 | ) |
| Comprehensive income | $ | 183.0 |  |  | $ | 167.6 |  |  | $ | (7.9 | ) |  | $ | (207.3 | ) |  | $ | 135.4 |  |

[0001069202-17-000003:notes:80]
For the Year Ended December 31, 2014

[0001069202-17-000003:notes:81]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,775.7 |  |  | $ | 818.0 |  |  | $ | (226.3 | ) |  | $ | 3,367.4 |  |
| Cost of goods sold | — |  |  | 2,057.8 |  |  | 628.3 |  |  | (222.0 | ) |  | 2,464.1 |  |
| Gross profit | — |  |  | 717.9 |  |  | 189.7 |  |  | (4.3 | ) |  | 903.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 454.5 |  |  | 119.2 |  |  | — |  |  | 573.7 |  |
| Losses and other expenses, net | — |  |  | 3.2 |  |  | 3.6 |  |  | — |  |  | 6.8 |  |
| Restructuring charges | — |  |  | 0.4 |  |  | 1.5 |  |  | — |  |  | 1.9 |  |
| Goodwill impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Pension settlement | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from equity method investments | (216.4 | ) |  | (25.4 | ) |  | (11.3 | ) |  | 239.3 |  |  | (13.8 | ) |
| Operational income | 216.4 |  |  | 285.2 |  |  | 76.7 |  |  | (243.6 | ) |  | 334.7 |  |
| Interest expense, net | 16.0 |  |  | (3.0 | ) |  | 4.2 |  |  | — |  |  | 17.2 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 200.4 |  |  | 288.2 |  |  | 72.6 |  |  | (243.6 | ) |  | 317.6 |  |
| Provision for income taxes | (5.6 | ) |  | 91.7 |  |  | 24.9 |  |  | (1.5 | ) |  | 109.5 |  |
| Income from continuing operations | 206.0 |  |  | 196.5 |  |  | 47.7 |  |  | (242.1 | ) |  | 208.1 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (2.3 | ) |  | — |  |  | (2.3 | ) |
| Net income | $ | 206.0 |  |  | $ | 196.5 |  |  | $ | 45.4 |  |  | $ | (242.1 | ) |  | $ | 205.8 |  |
| Other comprehensive income (loss) | $ | (4.1 | ) |  | $ | (51.2 | ) |  | $ | (34.8 | ) |  | $ | (2.3 | ) |  | $ | (92.4 | ) |
| Comprehensive Income | $ | 201.9 |  |  | $ | 145.3 |  |  | $ | 10.6 |  |  | $ | (244.4 | ) |  | $ | 113.4 |  |

[0001069202-17-000003:notes:82]
Condensed Consolidating Statements of Cash Flows

[0001069202-17-000003:notes:83]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (1.6 | ) |  | $ | 218.5 |  |  | $ | 137.6 |  |  | $ | — |  |  | $ | 354.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (71.5 | ) |  | (12.8 | ) |  | — |  |  | (84.3 | ) |
| Net cash used in investing activities | — |  |  | (71.5 | ) |  | (12.6 | ) |  | — |  |  | (84.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (2.4 | ) |  | — |  |  | (2.4 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 145.0 |  |  | — |  |  | 145.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (295.0 | ) |  | — |  |  | (295.0 | ) |
| Long-term debt borrowings | 350.0 |  |  | — |  |  | — |  |  | — |  |  | 350.0 |  |
| Borrowings from credit facility | 2,336.5 |  |  | — |  |  | — |  |  | — |  |  | 2,336.5 |  |
| Long-term debt payments | (57.5 | ) |  | (0.9 | ) |  | (0.4 | ) |  | — |  |  | (58.8 | ) |
| Payments on credit facility | (2,346.0 | ) |  | — |  |  | — |  |  | — |  |  | (2,346.0 | ) |
| Payments of deferred financing costs | (4.2 | ) |  | — |  |  | — |  |  | — |  |  | (4.2 | ) |
| Proceeds from employee stock purchases | 2.6 |  |  | — |  |  | — |  |  | — |  |  | 2.6 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (33.3 | ) |  | — |  |  | — |  |  | — |  |  | (33.3 | ) |
| Repurchases of common stock | (300.0 | ) |  | — |  |  | — |  |  | — |  |  | (300.0 | ) |
| Excess tax benefits related to share-based payments | 19.4 |  |  | — |  |  | — |  |  | — |  |  | 19.4 |  |
| Intercompany debt | 30.0 |  |  | (65.8 | ) |  | 35.8 |  |  | — |  |  | — |  |
| Intercompany financing activity | 73.8 |  |  | (71.0 | ) |  | (2.8 | ) |  | — |  |  | — |  |
| Cash dividends paid | (69.0 | ) |  | — |  |  | — |  |  | — |  |  | (69.0 | ) |
| Net cash provided by (used in) financing activities | 2.3 |  |  | (137.7 | ) |  | (119.8 | ) |  | — |  |  | (255.2 | ) |
| Increase (decrease) in cash and cash equivalents | 0.7 |  |  | 9.3 |  |  | 5.2 |  |  | — |  |  | 15.2 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (3.9 | ) |  | — |  |  | (3.9 | ) |
| Cash and cash equivalents, beginning of year | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of year | $ | 1.2 |  |  | $ | 17.1 |  |  | $ | 31.9 |  |  | $ | — |  |  | $ | 50.2 |  |

[0001069202-17-000003:notes:84]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 226.9 |  |  | $ | 49.3 |  |  | $ | 55.0 |  |  | $ | — |  |  | $ | 331.2 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (60.2 | ) |  | (9.7 | ) |  | — |  |  | (69.9 | ) |
| Net cash used in investing activities | — |  |  | (60.1 | ) |  | (9.7 | ) |  | — |  |  | (69.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.7 | ) |  | — |  |  | (1.7 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (60.0 | ) |  | — |  |  | (60.0 | ) |
| Long-term debt borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Borrowings from credit facility | 1,671.0 |  |  | — |  |  | — |  |  | — |  |  | 1,671.0 |  |
| Long-term debt payments | (22.5 | ) |  | (1.2 | ) |  | (0.3 | ) |  | — |  |  | (24.0 | ) |
| Payments on credit facility | (1,807.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,807.5 | ) |
| Payments of deferred financing costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Proceeds from employee stock purchases | 2.4 |  |  | — |  |  | — |  |  | — |  |  | 2.4 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (32.0 | ) |  | — |  |  | — |  |  | — |  |  | (32.0 | ) |
| Repurchases of common stock | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Excess tax benefits related to share-based payments | 22.4 |  |  | — |  |  | — |  |  | — |  |  | 22.4 |  |
| Intercompany debt | (9.4 | ) |  | 7.1 |  |  | 2.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | 7.5 |  |  | 1.2 |  |  | (8.7 | ) |  | — |  |  | — |  |
| Cash dividends paid | (59.3 | ) |  | — |  |  | — |  |  | — |  |  | (59.3 | ) |
| Net cash provided by (used in) financing activities | (227.4 | ) |  | 7.1 |  |  | (28.4 | ) |  | — |  |  | (248.7 | ) |
| Increase (decrease) in cash and cash equivalents | (0.5 | ) |  | (3.7 | ) |  | 16.9 |  |  | — |  |  | 12.7 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (11.3 | ) |  | — |  |  | (11.3 | ) |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of year | $ | 0.5 |  |  | $ | 7.8 |  |  | $ | 30.6 |  |  | $ | — |  |  | $ | 38.9 |  |

[0001069202-17-000003:notes:85]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 328.8 |  |  | $ | (97.2 | ) |  | $ | (46.8 | ) |  | $ | — |  |  | $ | 184.8 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 1.0 |  |  | 0.1 |  |  | — |  |  | 1.1 |  |
| Purchases of property, plant and equipment | — |  |  | (70.5 | ) |  | (17.9 | ) |  | — |  |  | (88.4 | ) |
| Net cash used in investing activities | — |  |  | (69.5 | ) |  | (17.8 | ) |  | — |  |  | (87.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.5 |  |  | — |  |  | 1.5 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 100.0 |  |  | — |  |  | 100.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Long-term debt borrowings | 300.0 |  |  | — |  |  | — |  |  | — |  |  | 300.0 |  |
| Borrowings from revolving credit facility | 2,073.5 |  |  | — |  |  | — |  |  | — |  |  | 2,073.5 |  |
| Long-term debt payments | — |  |  | (1.9 | ) |  | (0.4 | ) |  | — |  |  | (2.3 | ) |
| Payments on revolving credit facility | (1,908.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,908.5 | ) |
| Payments of deferred financing costs | (2.2 | ) |  | — |  |  | — |  |  | — |  |  | (2.2 | ) |
| Proceeds from employee stock purchases | 2.0 |  |  | — |  |  | — |  |  | — |  |  | 2.0 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (22.4 | ) |  | — |  |  | — |  |  | — |  |  | (22.4 | ) |
| Repurchases of common stock | (550.3 | ) |  | — |  |  | — |  |  | — |  |  | (550.3 | ) |
| Excess tax benefits related to share-based payments | 11.8 |  |  | — |  |  | — |  |  | — |  |  | 11.8 |  |
| Intercompany debt | (0.1 | ) |  | 4.7 |  |  | (4.6 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (180.1 | ) |  | 164.9 |  |  | 15.2 |  |  | — |  |  | — |  |
| Cash dividends paid | (52.6 | ) |  | — |  |  | — |  |  | — |  |  | (52.6 | ) |
| Net cash provided by (used in) financing activities | (328.9 | ) |  | 167.7 |  |  | 71.7 |  |  | — |  |  | (89.5 | ) |
| Decrease in cash and cash equivalents | (0.1 | ) |  | 1.0 |  |  | 7.1 |  |  | — |  |  | 8.0 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (8.5 | ) |  | — |  |  | (8.5 | ) |
| Cash and cash equivalents, beginning of year | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of year | $ | 1.0 |  |  | $ | 11.5 |  |  | $ | 25.0 |  |  | $ | — |  |  | $ | 37.5 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001069202-17-000003:notes:86]
Principles of Consolidation

[0001069202-17-000003:notes:87]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.


## us-gaap:CostOfSalesPolicyTextBlock

[0001069202-17-000003:notes:88]
Cost of Goods Sold

[0001069202-17-000003:notes:89]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.


## us-gaap:DebtDisclosureTextBlock

[0001069202-17-000003:notes:90]
Lines of Credit and Financing Arrangements:

[0001069202-17-000003:notes:91]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000003:notes:92]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 50.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 2.4 |  |  | 4.1 |  |
| Total short-term debt | $ | 52.4 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.8 |  |  | $ | 1.2 |  |
| Domestic credit facility | — |  |  | 30.0 |  |
| Senior unsecured notes | 200.0 |  |  | — |  |
| Debt issuance costs | (0.7 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 200.1 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.0 |  |  | $ | 15.6 |  |
| Domestic credit facility | 256.0 |  |  | 293.0 |  |
| Senior unsecured notes | 350.0 |  |  | 200.0 |  |
| Debt issuance costs | (5.3 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 615.7 |  |  | $ | 506.0 |  |
| Total debt | $ | 868.2 |  |  | $ | 741.1 |  |

[0001069202-17-000003:notes:93]
As of December 31, 2016, the aggregate amounts of required principal payments on total debt were as follows (in millions):

[0001069202-17-000003:notes:94]
| 2017 | $ | 253.2 |  |
| 2018 | 33.3 |  |
| 2019 | 30.0 |  |
| 2020 | 30.0 |  |
| 2021 | 166.0 |  |
| Thereafter | 361.7 |  |

[0001069202-17-000003:notes:95]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. We adopted this guidance in the first quarter of 2016 and have reclassified the unamortized debt issuance costs into the debt liability as shown in the table above.

[0001069202-17-000003:notes:96]
Short-Term Debt

[0001069202-17-000003:notes:97]
Foreign Obligations

[0001069202-17-000003:notes:98]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $2.4 million and $4.1 million of foreign obligations as of December 31, 2016 and 2015, respectively, that were primarily borrowings under non-committed facilities.  Proceeds on these facilities were $28.4 million, $79.0 million and $85.3 million during the years ended December 31, 2016, 2015 and 2014, respectively. Repayments on the facilities were $30.8 million, $85.4 million and $87.8 million during the years ended December 31, 2016, 2015 and 2014, respectively.

[0001069202-17-000003:notes:99]
Asset Securitization Program

[0001069202-17-000003:notes:100]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-17-000003:notes:101]
Prior to the amendment in July 2016, the ASP provided for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The ASP was amended effective as of July 5, 2016 to increase the maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-17-000003:notes:102]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rates as of December 31, 2016 and 2015 were 1.66% and 1.06%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-17-000003:notes:103]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over  $75.0 million.  The administrative agent under the ASP is also a participant in our Domestic Credit Facility.  The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of December 31, 2016, we believe we were in compliance with all covenant requirements.

[0001069202-17-000003:notes:104]
Long-Term Debt

[0001069202-17-000003:notes:105]
Domestic Credit Facility

[0001069202-17-000003:notes:106]
On August 30, 2016, we replaced an earlier  $950.0 million credit facility with a $900.0 million Credit Facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $256.0 million, of which $220.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of December 31, 2016.  Subject to covenant limitations, $609.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million beginning in March 2017; however, we made $30.0 million of required principal repayments for 2017 in November 2016.  The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-17-000003:notes:107]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-17-000003:notes:108]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our Domestic Credit Facility could occur if:

[0001069202-17-000003:notes:109]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-17-000003:notes:110]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-17-000003:notes:111]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-17-000003:notes:112]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2016, we believe we were in compliance with all covenant requirements.

[0001069202-17-000003:notes:113]
Senior Unsecured Notes

[0001069202-17-000003:notes:114]
We issued $350.0 million of senior unsecured notes in November 2016 (the "2016 Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also have $200.0 million of senior unsecured notes issued in 2010 (the "2010 Notes") which will mature on May 15, 2017  with interest being paid at 4.90% per annum semiannually. Both Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and, in the case of the 2010 Notes, transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of December 31, 2016, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-17-000003:notes:115]
Derivatives:

[0001069202-17-000003:notes:116]
Objectives and Strategies for Using Derivative Instruments

[0001069202-17-000003:notes:117]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-17-000003:notes:118]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001069202-17-000003:notes:119]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001069202-17-000003:notes:120]
Cash Flow Hedges

[0001069202-17-000003:notes:121]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through May 2018 and December 2017, respectively.  Unrealized gains or losses from our cash flow hedges are included in AOCI and are expected to be reclassified into earnings within the next 17 months based on the prices of the commodities at the settlement dates.

[0001069202-17-000003:notes:122]
We recorded the following amounts related to our cash flow hedges in AOCI (in millions):

[0001069202-17-000003:notes:123]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Unrealized (gains) losses on unsettled contracts | $ | (8.9 | ) |  | $ | 13.2 |  |
| Income tax expense (benefit) | 3.3 |  |  | (4.8 | ) |
| (Gains) losses included in AOCI, net of tax (1) | $ | (5.6 | ) |  | $ | 8.4 |  |

[0001069202-17-000003:notes:124]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $4.5 million of derivative gains into earnings within the next 12 months.

[0001069202-17-000003:notes:125]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions of pounds):

[0001069202-17-000003:notes:126]
|  | As of December 31, |
| Notional Amounts | 2016 |  | 2015 |
| Copper | 30.4 |  |  | 34.7 |  |

[0001069202-17-000003:notes:127]
We had the following outstanding foreign exchange forward contracts designated as cash flow hedges (in millions):

[0001069202-17-000003:notes:128]
|  | As of December 31, |
| Notional Amounts (in local currency): | 2016 |  | 2015 |
| Mexican Peso | 310.1 |  |  | 201.4 |  |
| Canadian Dollar | 24.9 |  | — |  |

[0001069202-17-000003:notes:129]
Derivatives not Designated as Cash Flow Hedges

[0001069202-17-000003:notes:130]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges, except that we elect not to designate them as cash flow hedges at the inception of the arrangement. We had

[0001069202-17-000003:notes:131]
the following outstanding commodity futures contracts not designated as cash flow hedges (in millions of pounds):

[0001069202-17-000003:notes:132]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Copper | 2.4 |  |  | 3.3 |  |
| Aluminum | 2.6 |  |  | 3.2 |  |

[0001069202-17-000003:notes:133]
We had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001069202-17-000003:notes:134]
|  | As of December 31, |
| Notional amounts (in local currency): | 2016 |  | 2015 |
| Chinese Yuan | 10.5 |  |  | — |  |
| Mexican Peso | 64.5 |  |  | 53.0 |  |
| Euro | 46.9 |  |  | 3.2 |  |
| British Pound | 1.3 |  |  | — |  |
| Indian Rupee | 584.6 |  |  | 30.8 |  |
| Polish Zloty | — |  |  | 25.4 |  |

[0001069202-17-000003:notes:135]
Information About the Locations and Amounts of Derivative Instruments

[0001069202-17-000003:notes:136]
The following tables provide the locations and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of Operations (in millions):

[0001069202-17-000003:notes:137]
|  | Fair Values of Derivative Instruments as of December 31 (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Current Assets: |  |  |  |  |  |  |  |
| Other assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 8.7 |  |  | $ | — |  |  | $ | 0.7 |  |  | $ | — |  |
| Foreign currency forward contracts | 0.5 |  |  | — |  |  | 0.2 |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 1.9 |  |  | — |  |  | 0.2 |  |  | — |  |
| Foreign currency forward contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total Assets | $ | 11.1 |  |  | $ | — |  |  | $ | 1.1 |  |  | $ | 0.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 12.5 |  |  | $ | — |  |  | $ | 1.5 |  |
| Foreign currency forward contracts | 0.8 |  |  | 0.4 |  |  | 3.2 |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.4 |  |  | — |  |  | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 0.8 |  |  | $ | 13.3 |  |  | $ | 3.2 |  |  | $ | 1.5 |  |

[0001069202-17-000003:notes:138]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 19 for more information on fair value measurements.

[0001069202-17-000003:notes:139]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Amount of Loss Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |
| Commodity futures contracts (1) | $ | 12.3 |  |  | $ | 12.5 |  |  | $ | 5.8 |  |
| Amount of (Gain) Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |
| Commodity futures contracts (2) | $ | (1.6 | ) |  | $ | 0.1 |  |  | $ | 0.1 |  |

[0001069202-17-000003:notes:140]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Amount of (Gain) Loss Recognized in Income on Derivatives: |  |  |  |  |  |
| Commodity futures contracts (2) | $ | (0.9 | ) |  | $ | 2.5 |  |  | $ | 1.2 |  |
| Foreign currency forward contracts (2) | 4.3 |  |  | 0.3 |  |  | (0.8 | ) |
|  | $ | 3.4 |  |  | $ | 2.8 |  |  | $ | 0.4 |  |

[0001069202-17-000003:notes:141]
(1) The loss was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-17-000003:notes:142]
(2) The (gain) loss was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DerivativesPolicyTextBlock

[0001069202-17-000003:notes:143]
Derivatives

[0001069202-17-000003:notes:144]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 8 for more information on our derivatives.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-17-000003:notes:145]
Stock-Based Compensation:

[0001069202-17-000003:notes:146]
Stock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-17-000003:notes:147]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Compensation expense(1) | $ | 31.7 |  |  | $ | 26.6 |  |  | $ | 23.3 |  |

[0001069202-17-000003:notes:148]
(1) Stock-based compensation expense was recorded in our Corporate and other business segment.

[0001069202-17-000003:notes:149]
Incentive Plan

[0001069202-17-000003:notes:150]
Under the Lennox International Inc. 2010 Incentive Plan, as amended and restated (the “2010 Incentive Plan”), we are authorized to issue awards for 24.3 million shares of common stock.  The 2010 Incentive Plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-17-000003:notes:151]
As of December 31, 2016, awards for 16.9 million shares of common stock had been granted, net of cancellations and repurchases, and there were 3.6 million shares available for future issuance.

[0001069202-17-000003:notes:152]
Performance Share Units

[0001069202-17-000003:notes:153]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII's performance over the three-year performance period.

[0001069202-17-000003:notes:154]
Performance share units are classified as equity awards.  Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-17-000003:notes:155]
The following table provides information on our performance share units:

[0001069202-17-000003:notes:156]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Compensation expense for performance share units (in millions) | $ | 18.1 |  |  | $ | 13.6 |  |  | $ | 11.5 |  |
| Weighted-average fair value of grants, per share | $ | 150.21 |  |  | $ | 126.31 |  |  | $ | 88.26 |  |
| Payout ratio for shares paid | 200.0 | % |  | 200.0 | % |  | 153.2 | % |

[0001069202-17-000003:notes:157]
A summary of the status of our undistributed performance share units as of December 31, 2016, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-17-000003:notes:158]
|  | Shares (2) |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2015 | 0.6 |  |  | $ | 67.91 |  |
| Granted | 0.1 |  |  | 150.21 |  |
| Adjustment to share paid based on payout ratio | 0.1 |  |  | 81.11 |  |
| Distributed | (0.3 | ) |  | 51.11 |  |
| Forfeited | — |  |  | — |  |
| Undistributed performance share units as of December 31, 2016 (1) | 0.4 |  |  | $ | 101.03 |  |

[0001069202-17-000003:notes:159]
(1) Undistributed performance share units include approximately 0.2 million units with a weighted-average grant date fair value of $117.60 per share that had not yet vested and 0.2 million units that have vested but were not yet distributed.

[0001069202-17-000003:notes:160]
(2) Share amounts are rounded but the balance of undistributed performance share units as of December 31, 2016                      accurately reflects actual units undistributed.

[0001069202-17-000003:notes:161]
As of December 31, 2016, we had $22.5 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.2 years. Our estimated forfeiture rate for these performance share units was 9.9% as of December 31, 2016.

[0001069202-17-000003:notes:162]
Restricted Stock Units

[0001069202-17-000003:notes:163]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-17-000003:notes:164]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-17-000003:notes:165]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Compensation expense for restricted stock units | $ | 9.0 |  |  | $ | 8.3 |  |  | $ | 7.0 |  |
| Weighted-average fair value of grants, per share | $ | 150.14 |  |  | $ | 126.15 |  |  | $ | 88.26 |  |

[0001069202-17-000003:notes:166]
A summary of our non-vested restricted stock units as of December 31, 2016 and changes during the year then ended is presented below (in millions, except per share data):

[0001069202-17-000003:notes:167]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2015 | 0.3 |  |  | $ | 94.23 |  |
| Granted | 0.1 |  |  | 150.14 |  |
| Distributed | (0.1 | ) |  | 80.40 |  |
| Forfeited | — |  |  | — |  |
| Non-vested restricted stock units as of December 31, 2016 | 0.3 |  |  | $ | 118.38 |  |

[0001069202-17-000003:notes:168]
As of December 31, 2016, we had $17.7 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.4 years.  Our estimated forfeiture rate for restricted stock units was 14.4% as of December 31, 2016.

[0001069202-17-000003:notes:169]
Stock Appreciation Rights

[0001069202-17-000003:notes:170]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive a value, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-17-000003:notes:171]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-17-000003:notes:172]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Compensation expense for stock appreciation rights | $ | 4.6 |  |  | $ | 4.7 |  |  | $ | 4.8 |  |
| Weighted-average fair value of grants, per share | 22.93 |  |  | 22.74 |  |  | 19.55 |  |

[0001069202-17-000003:notes:173]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-17-000003:notes:174]
The fair value of the stock appreciation rights granted in 2016, 2015 and 2014 were estimated on the date of grant using the following assumptions:

[0001069202-17-000003:notes:175]
|  | 2016 |  | 2015 |  | 2014 |
| Expected dividend yield | 1.62 | % |  | 1.61 | % |  | 1.75 | % |
| Risk-free interest rate | 1.66 | % |  | 1.36 | % |  | 1.27 | % |
| Expected volatility | 19.60 | % |  | 23.78 | % |  | 29.60 | % |
| Expected life (in years) | 3.99 |  |  | 4.00 |  |  | 4.04 |  |

[0001069202-17-000003:notes:176]
A summary of our stock appreciation rights as of December 31, 2016, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-17-000003:notes:177]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2015 | 1.3 |  |  | $ | 72.54 |  |
| Granted | 0.2 |  |  | 156.94 |  |
| Exercised | (0.4 | ) |  | 47.34 |  |
| Forfeited | — |  |  | — |  |
| Outstanding stock appreciation rights as of December 31, 2016 | 1.1 |  |  | $ | 98.35 |  |
| Exercisable stock appreciation rights as of December 31, 2016 | 0.7 |  |  | $ | 72.17 |  |

[0001069202-17-000003:notes:178]
As of December 31, 2016, we had $9.0 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.37 years. Our estimated forfeiture rate for stock appreciation rights was 13.1% as of December 31, 2016.

[0001069202-17-000003:notes:179]
Employee Stock Purchase Plan

[0001069202-17-000003:notes:180]
Under the 2012 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 17,000 shares under the ESPP during the year ended December 31, 2016.  Approximately 2.4 million shares remain available for purchase under the ESPP as of December 31, 2016.


## us-gaap:EarningsPerShareTextBlock

[0001069202-17-000003:notes:181]
Earnings Per Share:

[0001069202-17-000003:notes:182]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-17-000003:notes:183]
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-17-000003:notes:184]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Net income | $ | 277.8 |  |  | $ | 186.6 |  |  | $ | 205.8 |  |
| Add: Loss from discontinued operations | 0.8 |  |  | 0.6 |  |  | 2.3 |  |
| Income from continuing operations | $ | 278.6 |  |  | $ | 187.2 |  |  | $ | 208.1 |  |
| Weighted-average shares outstanding – basic | 43.4 |  |  | 44.9 |  |  | 47.9 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.6 |  |  | 0.7 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 44.0 |  |  | 45.6 |  |  | 48.6 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 6.41 |  |  | $ | 4.17 |  |  | $ | 4.35 |  |
| Loss from discontinued operations | (0.02 | ) |  | (0.01 | ) |  | (0.05 | ) |
| Net income | $ | 6.39 |  |  | $ | 4.16 |  |  | $ | 4.30 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 6.34 |  |  | $ | 4.11 |  |  | $ | 4.28 |  |
| Loss from discontinued operations | (0.02 | ) |  | (0.02 | ) |  | (0.05 | ) |
| Net income | $ | 6.32 |  |  | $ | 4.09 |  |  | $ | 4.23 |  |

[0001069202-17-000003:notes:185]
The following stock appreciation rights were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive (in millions, except for per share data):

[0001069202-17-000003:notes:186]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Weighted-average number of shares | — |  |  | — |  |  | 0.3 |  |
| Price ranges per share | $ | — |  |  | $ | — |  |  | $81.11 - $92.64 |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-17-000003:notes:187]
Joint Ventures and Other Equity Investments:

[0001069202-17-000003:notes:188]
We participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001069202-17-000003:notes:189]
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001069202-17-000003:notes:190]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Equity method investments | $ | 30.7 |  |  | $ | 30.3 |  |

[0001069202-17-000003:notes:191]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-17-000003:notes:192]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Purchases of compressors from joint venture | $ | 97.7 |  |  | $ | 103.5 |  |  | $ | 114.7 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001069202-17-000003:notes:193]
The fair values of our pension plan assets, by asset category, are as follows (in millions):

[0001069202-17-000003:notes:194]
|  | Fair Value Measurements as of December 31, 2016 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 5.3 |  |  | — |  |  | — |  |  | 5.3 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 69.5 |  |  | — |  |  | 69.5 |  |
| International equity (2) | — |  |  | 47.6 |  |  | — |  |  | 47.6 |  |
| Fixed income (3) | — |  |  | 134.9 |  |  | — |  |  | 134.9 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |
| Fixed income | — |  |  | 11.9 |  |  | — |  |  | 11.9 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 13.5 |  |  | — |  |  | 13.5 |  |
| Fixed income (6) | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Total | 5.3 |  |  | 287.2 |  |  | — |  |  | 292.5 |  |

[0001069202-17-000003:notes:195]
|  | Fair Value Measurements as of December 31, 2015 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 3.8 |  |  | — |  |  | — |  |  | 3.8 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 69.7 |  |  | — |  |  | 69.7 |  |
| International equity (2) | — |  |  | 45.5 |  |  | — |  |  | 45.5 |  |
| Fixed income (3) | — |  |  | 138.1 |  |  | — |  |  | 138.1 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |
| Fixed income | — |  |  | 12.1 |  |  | — |  |  | 12.1 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 11.0 |  |  | — |  |  | 11.0 |  |
| Fixed income (6) | — |  |  | 8.1 |  |  | — |  |  | 8.1 |  |
| Total | 3.8 |  |  | 289.2 |  |  | — |  |  | 293.0 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-17-000003:notes:196]
The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-17-000003:notes:197]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 499.3 |  |  | $ | 207.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-17-000003:notes:198]
Fair Value Measurements:

[0001069202-17-000003:notes:199]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001069202-17-000003:notes:200]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-17-000003:notes:201]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-17-000003:notes:202]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-17-000003:notes:203]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party's creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2016 and 2015, the measurement dates.  The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2016 were the same as those used as of December 31, 2015.

[0001069202-17-000003:notes:204]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-17-000003:notes:205]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-17-000003:notes:206]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 8 for more information related to our derivative instruments.

[0001069202-17-000003:notes:207]
Marketable Equity Securities

[0001069202-17-000003:notes:208]
The following table presents the fair values of an investment in marketable equity securities, related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000003:notes:209]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Quoted Prices in Active Markets for Identical Assets (Level 1): |  |  |  |
| Investment in marketable equity securities | $ | 4.4 |  |  | $ | 6.5 |  |

[0001069202-17-000003:notes:210]
Other Fair Value Disclosures

[0001069202-17-000003:notes:211]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-17-000003:notes:212]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):


## us-gaap:FairValueInvestmentsEntitiesThatCalculateNetAssetValuePerShareTableTextBlock

[0001069202-17-000003:notes:213]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-17-000003:notes:214]
|  | As of December 31, 2016 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 69.5 |  |  | Daily |  | 5 days |
| International equity (2) | 47.6 |  |  | Daily |  | 5 days |
| Fixed income (3) | 134.9 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.7 |  |  | Daily |  | 3-5 days |
| Fixed income | 11.9 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 13.5 |  |  | Daily |  | 1-7 days |
| Fixed income (6) | 5.1 |  |  | Daily |  | 1-7 days |
| Total | $ | 287.2 |  |  |  |  |  |

[0001069202-17-000003:notes:215]
|  | As of December 31, 2015 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 69.7 |  |  | Daily |  | 5 days |
| International equity (2) | 45.5 |  |  | Daily |  | 5 days |
| Fixed income (3) | 138.1 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.7 |  |  | Daily |  | 3-5 days |
| Fixed income | 12.1 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 11.0 |  |  | Daily |  | 1-7 days |
| Fixed income (6) | 8.1 |  |  | Daily |  | 1-7 days |
| Total | $ | 289.2 |  |  |  |  |  |

[0001069202-17-000003:notes:216]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the fund are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The fund also holds a portion of its assets in international equities. |
| (5) | This category includes investments in international equity securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (6) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer and investment grade corporate bonds denominated in sterling. |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001069202-17-000003:notes:217]
Amortization expense related to these intangible and other assets was as follows (in millions):

[0001069202-17-000003:notes:218]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Amortization expense (1) | $ | 0.4 |  |  | $ | 2.7 |  |  | $ | 2.9 |  |

[0001069202-17-000003:notes:219]
(1) The impairment related to customer relationships has been removed from the gross amount as well as the accumulated amortization, but is included in amortization expense for the previous year.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001069202-17-000003:notes:220]
Translation of Foreign Currencies

[0001069202-17-000003:notes:221]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCI in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-17-000003:notes:222]
Goodwill and Intangible Assets:

[0001069202-17-000003:notes:223]
Goodwill

[0001069202-17-000003:notes:224]
The changes in the carrying amount of goodwill in 2016 and 2015, in total and by segment, are summarized in the table below (in millions):

[0001069202-17-000003:notes:225]
| Segment: | Balance at December 31, 2014 (2) |  | Impairment |  | Other(1) |  | Balance at December 31, 2015 |  | Impairment |  | Other(1) |  | Balance at December 31, 2016 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 62.3 |  |  | — |  |  | (1.7 | ) |  | 60.6 |  |  | — |  |  | (0.5 | ) |  | 60.1 |  |
| Refrigeration | 121.0 |  |  | (5.5 | ) |  | (7.1 | ) |  | 108.4 |  |  | — |  |  | 0.5 |  |  | 108.9 |  |
|  | $ | 209.4 |  |  | $ | (5.5 | ) |  | $ | (8.8 | ) |  | $ | 195.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 195.1 |  |

[0001069202-17-000003:notes:226]
(1) Other consists of changes in foreign currency translation rates.

[0001069202-17-000003:notes:227]
(2) The goodwill balances in the table above are presented net of accumulated impairment charges of $15.7 million, all of which relate to impairments in periods prior to 2014.

[0001069202-17-000003:notes:228]
We reviewed our reporting unit structure as part of our annual goodwill impairment testing.  We identified several components one level below our operating segments which were determined to be reporting units.  We then performed our analysis to determine the proper aggregation of our reporting units, which considered similar economic and other characteristics, including product types, gross profits, production processes, customer types, distribution processes, and regulatory environments.  Our analysis incorporated qualitative and quantitative measures to evaluate economic similarity  and concluded that our reporting units continue to be equivalent to our operating segments except that we began evaluating our North America supermarket display cases and systems business separately beginning in 2015.

[0001069202-17-000003:notes:229]
A qualitative review of impairment indicators was performed in 2016 for the Residential Heating & Cooling, the Commercial Heating & Cooling segments, and the Refrigeration segments we determined that it was not more likely than not the fair values of our reporting units, individually or collectively, were less than their carrying values.  Accordingly, a quantitative impairment analysis was not performed for these segments. During the fourth quarter of 2015 we performed a quantitative impairment analysis of our North American supermarket display cases and systems business. Based on the results of the quantitative impairment test, we recorded impairment of $5.5 million in "Goodwill impairment" in the Consolidated Statement of Operations.  No indicators of goodwill impairment were identified during the current year.  Also, we did not record any goodwill impairments related to continuing operations in 2014.

[0001069202-17-000003:notes:230]
Intangible Assets

[0001069202-17-000003:notes:231]
As of December 31, 2016 and 2015, there were $4.3 million and $4.3 million, respectively, of indefinite-lived intangible assets recorded in Other assets, net in the accompanying Consolidated Balance Sheets.  These intangible assets consisted primarily of trademarks and are not subject to amortization.

[0001069202-17-000003:notes:232]
Identifiable intangible and other assets subject to amortization were recorded in Other assets, net in the accompanying Consolidated Balance Sheets and were comprised of the following (in millions):

[0001069202-17-000003:notes:233]
|  | As of December 31, |
|  | 2016 |  | 2015 |
|  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships (1) | 15.9 |  |  | (14.9 | ) |  | 1.0 |  |  | 15.9 |  |  | (14.6 | ) |  | 1.3 |  |
| Patents and others | 12.7 |  |  | (6.4 | ) |  | 6.3 |  |  | 11.2 |  |  | (6.3 | ) |  | 4.9 |  |
| Total | $ | 28.6 |  |  | $ | (21.3 | ) |  | $ | 7.3 |  |  | $ | 27.1 |  |  | $ | (20.9 | ) |  | $ | 6.2 |  |

[0001069202-17-000003:notes:234]
Estimated amortization expense for the next five years and thereafter is as follows (in millions):

[0001069202-17-000003:notes:235]
| Estimated Future Amortization Expense: |  |
| 2017 | $ | 0.4 |  |
| 2018 | 0.4 |  |
| 2019 | 0.4 |  |
| 2020 | 0.4 |  |
| 2021 | 0.2 |  |
| Thereafter | 5.5 |  |

[0001069202-17-000003:notes:236]
Deferred financing costs were reclassified out of intangible assets and removed from the tables above and are included as offsets against our debt balances as disclosed in Note 11.

[0001069202-17-000003:notes:237]
During the fourth quarter of 2015, we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed an impairment analysis using a market approach and determined that intangible assets relating to the North American supermarket display case business trade name and its customer relationships were impaired and we recorded a charge of $21.2 million in "Asset impairment" in the Consolidated Statement of Operations. We did not have any impairments of intangible assets related to continuing operations in 2016 or 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-17-000003:notes:238]
Income Taxes:

[0001069202-17-000003:notes:239]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-17-000003:notes:240]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Current: |  |  |  |  |  |
| Federal | $ | 106.0 |  |  | $ | 101.0 |  |  | $ | 84.3 |  |
| State | 14.5 |  |  | 13.1 |  |  | 10.1 |  |
| Foreign | 9.7 |  |  | 3.6 |  |  | 9.6 |  |
| Total current | 130.2 |  |  | 117.7 |  |  | 104.0 |  |
| Deferred: |  |  |  |  |  |
| Federal | (4.5 | ) |  | (21.4 | ) |  | 2.3 |  |
| State | (1.2 | ) |  | (0.6 | ) |  | 1.0 |  |
| Foreign | (0.4 | ) |  | (0.3 | ) |  | 2.2 |  |
| Total deferred | (6.1 | ) |  | (22.3 | ) |  | 5.5 |  |
| Total provision for income taxes | $ | 124.1 |  |  | $ | 95.4 |  |  | $ | 109.5 |  |

[0001069202-17-000003:notes:241]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-17-000003:notes:242]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Domestic | $ | 374.8 |  |  | $ | 276.7 |  |  | $ | 283.7 |  |
| Foreign | 27.9 |  |  | 5.9 |  |  | 33.9 |  |
| Total | $ | 402.7 |  |  | $ | 282.6 |  |  | $ | 317.6 |  |

[0001069202-17-000003:notes:243]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-17-000003:notes:244]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Provision at the U.S. statutory rate of 35% | $ | 141.0 |  |  | $ | 98.9 |  |  | $ | 111.2 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 12.8 |  |  | 8.0 |  |  | 8.8 |  |
| Other permanent items | 4.2 |  |  | (9.1 | ) |  | (8.2 | ) |
| Tax credits, net of unrecognized tax benefits | (27.9 | ) |  | (0.7 | ) |  | — |  |
| Change in unrecognized tax benefits | (0.3 | ) |  | (0.9 | ) |  | 0.2 |  |
| Change in valuation allowance | (4.3 | ) |  | (0.6 | ) |  | 0.2 |  |
| Foreign taxes at rates other than 35% and miscellaneous other | (1.4 | ) |  | (0.2 | ) |  | (2.7 | ) |
| Total provision for income taxes | $ | 124.1 |  |  | $ | 95.4 |  |  | $ | 109.5 |  |

[0001069202-17-000003:notes:245]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-17-000003:notes:246]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-17-000003:notes:247]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 36.3 |  |  | $ | 33.7 |  |
| Loss carryforwards (foreign, U.S. and state) | 19.8 |  |  | 20.0 |  |
| Post-retirement and pension benefits | 33.9 |  |  | 47.7 |  |
| Inventory reserves | 9.6 |  |  | 9.0 |  |
| Receivables allowance | 4.5 |  |  | 4.1 |  |
| Compensation liabilities | 20.6 |  |  | 19.3 |  |
| Deferred income | 1.5 |  |  | 1.6 |  |
| Insurance liabilities | 6.5 |  |  | 6.3 |  |
| Legal reserves | 12.0 |  |  | 10.9 |  |
| Hedges | — |  |  | 5.3 |  |
| State credits, net of federal effect | 18.4 |  |  | 8.3 |  |
| Other | 5.4 |  |  | 7.1 |  |
| Total deferred tax assets | 168.5 |  |  | 173.3 |  |
| Valuation allowance | (17.1 | ) |  | (19.9 | ) |
| Total deferred tax assets, net of valuation allowance | 151.4 |  |  | 153.4 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (3.3 | ) |  | (2.5 | ) |
| Hedges | (3.2 | ) |  | — |  |
| Intangibles | (4.9 | ) |  | (2.2 | ) |
| Other | (3.3 | ) |  | (3.0 | ) |
| Total deferred tax liabilities | (14.7 | ) |  | (7.7 | ) |
| Net deferred tax assets | $ | 136.7 |  |  | $ | 145.7 |  |

[0001069202-17-000003:notes:248]
As of December 31, 2016 and 2015, we had $1.6 million and $ 2.6 million in tax-effected state net operating loss carryforwards, respectively, and $16.8 million and $16.1 million  in tax-effected foreign net operating loss carryforwards, respectively.  The state and foreign net operating loss carryforwards began expiring in 2014.  The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards in various states in the U.S., European and Asian tax jurisdictions.  The remainder of the valuation allowance relates to state tax credits which began to expire in 2014.

[0001069202-17-000003:notes:249]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of December 31, 2016.

[0001069202-17-000003:notes:250]
To realize the net deferred tax asset, we will need to generate future foreign taxable income of approximately $62.7 million during the periods in which those temporary differences become deductible.  We do not need to generate additional U.S. federal income as we have sufficient carryback capacity to fully realize the federal deferred tax asset.  U.S. taxable income for the years ended December 31, 2016 and 2015 was $315.0 million and $225.7 million, respectively.

[0001069202-17-000003:notes:251]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries' earnings.  These earnings were approximately $107.7 million as of December 31, 2016.  It is not practicable to estimate the amount of tax that might be payable because our intent is to permanently reinvest these earnings or to repatriate earnings when it is tax effective to do so.

[0001069202-17-000003:notes:252]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001069202-17-000003:notes:253]
| Balance as of December 31, 2014 | $ | 1.6 |  |
| Increases related to prior year tax positions | 0.5 |  |
| Decreases related to prior year tax positions | (1.2 | ) |
| Increases related to current year tax positions | — |  |
| Settlement | (0.4 | ) |
| Balance as of December 31, 2015 | 0.5 |  |
| Increases related to prior year tax positions | 1.0 |  |
| Decreases related to prior year tax positions | — |  |
| Increases related to current year tax positions | 1.4 |  |
| Settlement | (0.5 | ) |
| Balance as of December 31, 2016 | $ | 2.4 |  |

[0001069202-17-000003:notes:254]
Included in the balance of unrecognized tax benefits as of December 31, 2016 are potential benefits of $2.4 million that, if recognized, would affect the effective tax rate on income from continuing operations.

[0001069202-17-000003:notes:255]
We are currently under examination for our U.S. federal income taxes for 2016 and 2015 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years before 2011.

[0001069202-17-000003:notes:256]
Since January 1, 2016, numerous states, including Delaware, North Carolina and the District of Columbia have enacted legislation effective for tax years beginning on or after January 1, 2016, including changes to rates and apportionment methods.  The impact of these changes is immaterial.

[0001069202-17-000003:notes:257]
In November 2015, the Financial Accounting Standards Board issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (Topic 740). The Update requires that all deferred tax assets and liabilities be classified as noncurrent in a classified statement of financial position.  We adopted this Update retrospectively in the 2015 financial statements.


## us-gaap:IncomeTaxPolicyTextBlock

[0001069202-17-000003:notes:258]
Income Taxes

[0001069202-17-000003:notes:259]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 9 for more information related to income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-17-000003:notes:260]
Inventories:

[0001069202-17-000003:notes:261]
The components of inventories are as follows (in millions):

[0001069202-17-000003:notes:262]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Finished goods | $ | 287.2 |  |  | $ | 300.0 |  |
| Work in process | 5.1 |  |  | 4.2 |  |
| Raw materials and parts | 183.4 |  |  | 178.3 |  |
| Total | 475.7 |  |  | 482.5 |  |
| Excess of current cost over last-in, first-out cost | (57.2 | ) |  | (63.7 | ) |
| Total inventories, net | $ | 418.5 |  |  | $ | 418.8 |  |

[0001069202-17-000003:notes:263]
The Company recorded pre-tax loss of $0.2 million in 2016, pre-tax loss of $0.2 million in 2015 and pre-tax loss of $0.9 million in 2014 from LIFO inventory liquidations.   Reserve balances, primarily related to obsolete and slow-moving inventories, were$19.7 million and $21.5 million at December 31, 2016 and December 31, 2015, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001069202-17-000003:notes:264]
Inventories

[0001069202-17-000003:notes:265]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $221.4 million and $212.4 million as of December 31, 2016 and 2015, respectively, were valued at the lower of cost or market using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or market with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001069202-17-000003:notes:266]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 3 for more information on our inventories.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-17-000003:notes:267]
Losses and Other Expenses, net:

[0001069202-17-000003:notes:268]
Losses and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-17-000003:notes:269]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Realized losses on settled futures contracts | $ | 1.1 |  |  | $ | 1.9 |  |  | $ | 0.8 |  |
| Foreign currency exchange losses | 2.2 |  |  | 3.6 |  |  | 1.6 |  |
| Losses (gains) on disposal of fixed assets | 0.5 |  |  | 0.6 |  |  | (0.3 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts | (3.6 | ) |  | 0.6 |  |  | 0.6 |  |
| Asbestos-related litigation | 6.3 |  |  | 3.0 |  |  | 0.9 |  |
| Acquisition expenses | 0.4 |  |  | 1.0 |  |  | — |  |
| Special legal contingency charges | 1.9 |  |  | 7.4 |  |  | 0.9 |  |
| Environmental liabilities | 1.9 |  |  | 1.0 |  |  | 2.0 |  |
| Contractor tax payments | 0.6 |  |  | 2.6 |  |  | — |  |
| Other items, net | — |  |  | — |  |  | 0.3 |  |
| Losses and other expenses, net | $ | 11.3 |  |  | $ | 21.7 |  |  | $ | 6.8 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-17-000003:notes:270]
Employee Benefit Plans:

[0001069202-17-000003:notes:271]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.  We also have several active defined benefit plans that provide benefits based on years of service.

[0001069202-17-000003:notes:272]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.  In 2012, we amended the post-retirement benefit plan to shift pre-65 medical coverage for the employees of our largest manufacturing plant so that by 2016, retirees would pay 100% of the cost of post-retirement medical coverage.  This change resulted in a significant reduction in the projected benefit obligation for post-retirement medical benefits in 2012.

[0001069202-17-000003:notes:273]
Effective for fiscal year 2016, we adopted the full yield curve approach for estimating the service cost and interest cost components of expense for plans that use a yield curve to determine the discount rate. The new method applies the specific spot rates along the yield curve used in the most recent measurement of the benefit obligation, resulting in a more precise estimate of expense. The impact for fiscal year 2016 was a decrease in expense of approximately $3.2 million.

[0001069202-17-000003:notes:274]
In 2016, we offered certain former employees with vested pension benefits a lump sum payout in an effort to reduce our long-term pension obligations.  As a result, for 2016, the net periodic benefit cost for our pension plans includes a non-cash settlement charge of $31.4 million and the projected benefit obligation decreased by $50.6 million.

[0001069202-17-000003:notes:275]
Defined Contribution Plans

[0001069202-17-000003:notes:276]
We recorded the following expenses related to our contributions to the defined contribution plans (in millions):

[0001069202-17-000003:notes:277]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Contributions to defined contribution plans | $ | 16.3 |  |  | $ | 16.1 |  |  | $ | 14.8 |  |

[0001069202-17-000003:notes:278]
Pension and Post-retirement Benefit Plans

[0001069202-17-000003:notes:279]
The following tables set forth amounts recognized in our financial statements and the plans' funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-17-000003:notes:280]
|  | Pension Benefits |  | Other Benefits |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Accumulated benefit obligation | $ | 374.1 |  |  | $ | 409.2 |  |  | N/A |  |  | N/A |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 415.4 |  |  | $ | 446.5 |  |  | $ | 4.9 |  |  | $ | 5.4 |  |
| Service cost | 4.4 |  |  | 4.8 |  |  | — |  |  | — |  |
| Interest cost | 15.3 |  |  | 17.2 |  |  | 0.1 |  |  | 0.2 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.3 |  |  | 0.5 |  |
| Amendments | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial (gain) loss | 22.8 |  |  | (29.6 | ) |  | (0.7 | ) |  | 0.1 |  |
| Effect of exchange rates | (3.8 | ) |  | (5.2 | ) |  | — |  |  | — |  |
| Divestiture | — |  |  | — |  |  | — |  |  | — |  |
| Settlements and curtailments | (50.6 | ) |  | (0.8 | ) |  | — |  |  | — |  |
| Benefits paid | (22.0 | ) |  | (17.6 | ) |  | (1.3 | ) |  | (1.3 | ) |
| Benefit obligation at end of year | $ | 381.6 |  |  | $ | 415.4 |  |  | $ | 3.3 |  |  | $ | 4.9 |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 293.0 |  |  | $ | 315.0 |  |  | $ | — |  |  | $ | — |  |
| Actual gain (loss) return on plan assets | 21.0 |  |  | (3.2 | ) |  | — |  |  | — |  |
| Employer contribution | 53.9 |  |  | 3.8 |  |  | 1.0 |  |  | 0.8 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.3 |  |  | 0.5 |  |
| Effect of exchange rates | (2.8 | ) |  | (4.2 | ) |  | — |  |  | — |  |
| Divestiture | — |  |  | — |  |  | — |  |  | — |  |
| Plan settlements | (50.6 | ) |  | (0.8 | ) |  | — |  |  | — |  |
| Benefits paid | (22.0 | ) |  | (17.6 | ) |  | (1.3 | ) |  | (1.3 | ) |
| Fair value of plan assets at end of year | 292.5 |  |  | 293.0 |  |  | — |  |  | — |  |
| Funded status / net amount recognized | $ | (89.1 | ) |  | $ | (122.4 | ) |  | $ | (3.3 | ) |  | $ | (4.9 | ) |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Current liability | $ | (1.6 | ) |  | $ | (1.6 | ) |  | $ | (0.5 | ) |  | $ | (0.8 | ) |
| Non-current liability | (87.5 | ) |  | (120.8 | ) |  | (2.8 | ) |  | (4.1 | ) |
| Net amount recognized | $ | (89.1 | ) |  | $ | (122.4 | ) |  | $ | (3.3 | ) |  | $ | (4.9 | ) |

[0001069202-17-000003:notes:281]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 370.2 |  |  | $ | 404.5 |  |
| Accumulated benefit obligation | 362.9 |  |  | 398.4 |  |
| Fair value of plan assets | 280.8 |  |  | 281.8 |  |

[0001069202-17-000003:notes:282]
Our U.S.-based pension plans comprised approximately 88%  of the projected benefit obligation and 88% of plan assets as of December 31, 2016.

[0001069202-17-000003:notes:283]
|  | Pension Benefits |  | Other Benefits |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 4.4 |  |  | $ | 4.8 |  |  | $ | 4.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 15.3 |  |  | 17.2 |  |  | 17.7 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on plan assets | (21.5 | ) |  | (21.4 | ) |  | (22.7 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.3 |  |  | 0.2 |  |  | 0.3 |  |  | (3.0 | ) |  | (3.1 | ) |  | (3.1 | ) |
| Recognized actuarial loss | 7.6 |  |  | 9.5 |  |  | 6.6 |  |  | 1.4 |  |  | 1.5 |  |  | 1.5 |  |
| Settlements and curtailments(1) | 31.6 |  |  | 0.4 |  |  | 0.4 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (2) | $ | 37.7 |  |  | $ | 10.7 |  |  | $ | 6.5 |  |  | $ | (1.5 | ) |  | $ | (1.4 | ) |  | $ | (1.4 | ) |

[0001069202-17-000003:notes:284]
(1)  The Consolidated Statements of Operations discloses $31.4 million related to pension settlement charges that represent the lump-sum payments made in the fourth quarter of 2016.

[0001069202-17-000003:notes:285]
(2)  No pension expense was included in Loss from discontinued operations in 2014, 2015 or 2016.

[0001069202-17-000003:notes:286]
The following table sets forth amounts recognized in AOCI and Other comprehensive income (loss) in our financial statements for 2016 and 2015 (in millions):

[0001069202-17-000003:notes:287]
|  | Pension Benefits |  | Other Benefits |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amounts recognized in AOCI: |  |  |  |  |  |  |  |
| Prior service costs | $ | (0.9 | ) |  | $ | (1.2 | ) |  | $ | 12.0 |  |  | $ | 15.0 |  |
| Actuarial loss | (197.3 | ) |  | (214.7 | ) |  | (16.3 | ) |  | (18.4 | ) |
| Subtotal | (198.2 | ) |  | (215.9 | ) |  | (4.3 | ) |  | (3.4 | ) |
| Deferred taxes | 71.0 |  |  | 78.7 |  |  | 1.6 |  |  | 1.3 |  |
| Net amount recognized | $ | (127.2 | ) |  | $ | (137.2 | ) |  | $ | (2.7 | ) |  | $ | (2.1 | ) |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Current year prior service costs | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |
| Current year actuarial (gain) loss | 23.3 |  |  | (5.0 | ) |  | (0.7 | ) |  | 0.1 |  |
| Effect of exchange rates | (1.5 | ) |  | (2.2 | ) |  | — |  |  | — |  |
| Amortization of prior service (costs) credits | (0.3 | ) |  | (0.3 | ) |  | 3.1 |  |  | 3.1 |  |
| Amortization of actuarial loss | (39.2 | ) |  | (9.9 | ) |  | (1.4 | ) |  | (1.5 | ) |
| Total recognized in other comprehensive income (loss) | $ | (17.6 | ) |  | $ | (17.3 | ) |  | $ | 1.0 |  |  | $ | 1.7 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) | $ | 20.1 |  |  | $ | (6.6 | ) |  | $ | (0.5 | ) |  | $ | 0.3 |  |

[0001069202-17-000003:notes:288]
The estimated prior service (costs) credits and actuarial losses that will be amortized from AOCI in 2016 are $(0.2) million  and (8.9) million, respectively, for pension benefits and $2.4 million  and $(1.4) million, respectively, for other benefits.

[0001069202-17-000003:notes:289]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2016 and 2015:

[0001069202-17-000003:notes:290]
|  | Pension Benefits |  | Other Benefits |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |
| Discount rate | 4.17 | % |  | 4.51 | % |  | 3.50 | % |  | 3.55 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |

[0001069202-17-000003:notes:291]
|  | Pension Benefits |  | Other Benefits |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate - service cost | 4.30 | % |  | 3.97 | % |  | 4.88 | % |  | 4.95 | % |  | 3.23 | % |  | 3.57 | % |
| Discount rate - interest cost | 3.76 | % |  | 3.97 | % |  | 4.88 | % |  | 2.49 | % |  | 3.23 | % |  | 3.57 | % |
| Expected long-term return on plan assets | 7.50 | % |  | 7.50 | % |  | 8.00 | % |  | — |  |  | — |  |  | — |  |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |  | — |  |

[0001069202-17-000003:notes:292]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the non-U.S.-based plans in 2016 and 2015:

[0001069202-17-000003:notes:293]
|  | Pension Benefits |
|  | 2016 |  | 2015 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 2.83 | % |  | 3.59 | % |
| Rate of compensation increase | 3.78 | % |  | 3.70 | % |

[0001069202-17-000003:notes:294]
|  | Pension Benefits |
|  | 2016 |  | 2015 |  | 2014 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 2.04 | % |  | 4.12 | % |  | 4.38 | % |
| Discount rate - interest cost | 3.45 | % |  | 4.12 | % |  | 4.38 | % |
| Expected long-term return on plan assets | 4.87 | % |  | 5.22 | % |  | 6.32 | % |
| Rate of compensation increase | 3.70 | % |  | 3.48 | % |  | 3.31 | % |

[0001069202-17-000003:notes:295]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns and the future expectations for returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 7.5% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-17-000003:notes:296]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available.  We used the results of the yield curve analysis to select the discount rate for each plan.  The analysis was completed separately for each U.S. pension and post-retirement benefit plan.  A similar process was followed for the non-U.S.-based plans.

[0001069202-17-000003:notes:297]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-17-000003:notes:298]
|  | 2016 |  | 2015 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 6.50 | % |  | 7.00 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2020 |  |  | 2020 |  |

[0001069202-17-000003:notes:299]
A one percentage-point change in assumed healthcare cost trend rates would have the following effects (in millions):

[0001069202-17-000003:notes:300]
|  | 1-Percentage-Point Increase |  | 1-Percentage-Point Decrease |
| Effect on total of service and interest cost | $ | — |  |  | $ | — |  |
| Effect on the post-retirement benefit obligation | 0.1 |  |  | (0.1 | ) |

[0001069202-17-000003:notes:301]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-17-000003:notes:302]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022-2026 |
| Pension benefits | $ | 18.7 |  |  | $ | 18.9 |  |  | $ | 19.2 |  |  | $ | 19.6 |  |  | $ | 24.9 |  |  | $ | 135.1 |  |
| Other benefits | 0.6 |  |  | 0.5 |  |  | 0.4 |  |  | 0.4 |  |  | 0.3 |  |  | 1.1 |  |

[0001069202-17-000003:notes:303]
Pension Plan Assets

[0001069202-17-000003:notes:304]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets between equity and fixed income.  In the first quarter of 2014, in order to increase diversification, we changed the targeted allocations for our plan assets. The target allocations for fixed income, money market, cash and guaranteed investment contracts investments remained unchanged at 58%, targeted equity investment allocations remained unchanged at 42%. Our targeted exposure to International equity remained unchanged at 17% of total assets and our exposure to domestic equity remained unchanged at 25%. These categories are further diversified among various asset classes including high yield and emerging markets debt, and international and emerging markets equities in order to avoid significant concentrations of risk. Our U.S. pension plan represents 88%, our Canadian pension plan 6%, and our United Kingdom (“U.K.”) pension plan 6% of the total fair value of our plan assets as of December 31, 2016.

[0001069202-17-000003:notes:305]
Our U.S. pension plans' weighted-average asset allocations as of December 31, 2016 and 2015, by asset category, are as follows:

[0001069202-17-000003:notes:306]
|  | Plan Assets as of December 31, |
| Asset Category: | 2016 |  | 2015 |
| U.S. equity | 27.0 | % |  | 27.1 | % |
| International equity | 18.5 | % |  | 17.7 | % |
| Fixed income | 52.5 | % |  | 53.8 | % |
| Money market/cash | 2.0 | % |  | 1.4 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-17-000003:notes:307]
Our Canadian pension plans were invested approximately 70% in Canadian bonds and 30% in international equities. Our U.K. pension plan was invested in a broad mix of assets consisting of U.K., international equities, and U.K. fixed income securities, including corporate and government bonds.

[0001069202-17-000003:notes:308]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund's NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust's underlying assets divided by the number of units owned.  See Note 19 for information about our fair value hierarchies and valuation techniques.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-17-000003:notes:309]
Property, Plant and Equipment:

[0001069202-17-000003:notes:310]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-17-000003:notes:311]
|  | As of December 31, |
|  | 2016 |  | 2015 |
| Land | $ | 33.9 |  |  | $ | 33.9 |  |
| Buildings and improvements | 218.2 |  |  | 211.8 |  |
| Machinery and equipment | 742.1 |  |  | 699.4 |  |
| Capital leases | 27.3 |  |  | 27.1 |  |
| Construction in progress and equipment not yet in service | 57.1 |  |  | 50.3 |  |
| Total | 1,078.6 |  |  | 1,022.5 |  |
| Less accumulated depreciation | (717.2 | ) |  | (682.9 | ) |
| Property, plant and equipment, net | $ | 361.4 |  |  | $ | 339.6 |  |

[0001069202-17-000003:notes:312]
During the fourth quarter of 2015, we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed an impairment analysis using a market approach and determined that property, plant and equipment relating to the North American supermarket display case  business unit were impaired and we recorded a charge of $23.3 million in "Asset impairment" in the Consolidated Statement of Operations. No impairment charges were recorded in 2016 or 2014.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001069202-17-000003:notes:313]
Property, Plant and Equipment

[0001069202-17-000003:notes:314]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001069202-17-000003:notes:315]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-17-000003:notes:316]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 30 years |
| Leasehold improvements | 1 to 20 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 15 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 10 years |
| Vehicles | 2 to 6 years |

[0001069202-17-000003:notes:317]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 5 for additional information on our property, plant and equipment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-17-000003:notes:318]
Selected Quarterly Financial Information (unaudited):

[0001069202-17-000003:notes:319]
The following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-17-000003:notes:320]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (Loss) (1) |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| First Quarter | $ | 715.2 |  |  | $ | 685.8 |  |  | $ | 183.6 |  |  | $ | 163.0 |  |  | $ | 24.9 |  |  | $ | 13.9 |  |
| Second Quarter | 1,019.2 |  |  | 992.5 |  |  | 315.0 |  |  | 283.4 |  |  | 110.7 |  |  | 81.2 |  |
| Third Quarter | 1,010.0 |  |  | 955.0 |  |  | 310.3 |  |  | 273.4 |  |  | 101.7 |  |  | 80.3 |  |
| Fourth Quarter | 897.3 |  |  | 834.1 |  |  | 267.6 |  |  | 227.6 |  |  | 40.4 |  |  | 11.2 |  |

[0001069202-17-000003:notes:321]
|  | Basic Earnings (Loss) per Share (2) |  | Diluted Earnings (Loss) per Share (2) |  | Cash Dividends per Common Share |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| First Quarter | $ | 0.57 |  |  | $ | 0.31 |  |  | $ | 0.56 |  |  | $ | 0.31 |  |  | $ | 0.36 |  |  | $ | 0.30 |  |
| Second Quarter | 2.54 |  |  | 1.80 |  |  | 2.51 |  |  | 1.78 |  |  | 0.43 |  |  | 0.36 |  |
| Third Quarter | 2.35 |  |  | 1.78 |  |  | 2.33 |  |  | 1.76 |  |  | 0.43 |  |  | 0.36 |  |
| Fourth Quarter | 0.94 |  |  | 0.25 |  |  | 0.93 |  |  | 0.25 |  |  | 0.43 |  |  | 0.36 |  |

[0001069202-17-000003:notes:322]
(1)  The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-17-000003:notes:323]
(2)  EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.

[0001069202-17-000003:notes:324]
Summary of 2016 Quarterly Results

[0001069202-17-000003:notes:325]
The following unusual or infrequent pre-tax items were included in the 2016 quarterly results:

[0001069202-17-000003:notes:326]
1st Quarter.  No significant unusual or infrequent items.

[0001069202-17-000003:notes:327]
2nd Quarter.  No significant unusual or infrequent items.

[0001069202-17-000003:notes:328]
3rd Quarter.  No significant unusual or infrequent items.

[0001069202-17-000003:notes:329]
4th Quarter. As part of our ongoing strategy to de-risk our pension plan obligations, we completed a one-time, lump sum pension buyout in the fourth quarter of 2016 for certain vested participants. As a result of the pension buy-out, we recorded a pension settlement charge of $31 million in the fourth quarter.

[0001069202-17-000003:notes:330]
Summary of 2015 Quarterly Results

[0001069202-17-000003:notes:331]
The following unusual or infrequent pre-tax items were included in the 2015 quarterly results:

[0001069202-17-000003:notes:332]
3rd Quarter.   No significant unusual or infrequent items.

[0001069202-17-000003:notes:333]
4th Quarter.  We recorded goodwill impairment and asset impairment charges of $5.5 million  and $44.5 million, respectively,  to our North American supermarket display case business. Refer to Notes 4 and 5 for more information related to our impairment charges.


## us-gaap:ReceivablesPolicyTextBlock

[0001069202-17-000003:notes:334]
Accounts and Notes Receivable

[0001069202-17-000003:notes:335]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management's judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management's review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001069202-17-000003:notes:336]
Total assets by segment are shown below (in millions):

[0001069202-17-000003:notes:337]
|  | As of December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 673.4 |  |  | $ | 628.3 |  |  | $ | 632.3 |  |
| Commercial Heating & Cooling | 385.8 |  |  | 363.6 |  |  | 353.4 |  |
| Refrigeration | 442.8 |  |  | 444.9 |  |  | 551.5 |  |
| Corporate and other | 258.3 |  |  | 240.6 |  |  | 227.1 |  |
| Total assets | $ | 1,760.3 |  |  | $ | 1,677.4 |  |  | $ | 1,764.3 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-17-000003:notes:338]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001069202-17-000003:notes:339]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 2,000.8 |  |  | $ | 1,866.9 |  |  | $ | 1,736.5 |  |
| Commercial Heating & Cooling | 917.9 |  |  | 887.2 |  |  | 878.5 |  |
| Refrigeration | 722.9 |  |  | 713.3 |  |  | 752.4 |  |
|  | $ | 3,641.6 |  |  | $ | 3,467.4 |  |  | $ | 3,367.4 |  |
| Segment Profit (Loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 348.8 |  |  | $ | 278.4 |  |  | $ | 235.8 |  |
| Commercial Heating & Cooling | 149.3 |  |  | 130.4 |  |  | 124.0 |  |
| Refrigeration | 68.9 |  |  | 52.9 |  |  | 55.4 |  |
| Corporate and other | (97.4 | ) |  | (84.1 | ) |  | (74.3 | ) |
| Subtotal segment profit | 469.6 |  |  | 377.6 |  |  | 340.9 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| Special product quality adjustments | (0.4 | ) |  | (2.2 | ) |  | (1.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (2) | 7.4 |  |  | 15.6 |  |  | 4.7 |  |
| Restructuring charges | 1.8 |  |  | 3.2 |  |  | 1.9 |  |
| Pension settlement | 31.4 |  |  | — |  |  | — |  |
| Goodwill impairment | — |  |  | 5.5 |  |  | — |  |
| Asset impairment | — |  |  | 44.5 |  |  | — |  |
| One time inventory write down | — |  |  | 5.6 |  |  | 1.0 |  |
| Operating income | $ | 429.4 |  |  | $ | 305.4 |  |  | $ | 334.7 |  |

[0001069202-17-000003:notes:340]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-17-000003:notes:341]
(2) The


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001069202-17-000003:notes:342]
Total capital expenditures by segment are shown below (in millions):

[0001069202-17-000003:notes:343]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 36.7 |  |  | $ | 28.1 |  |  | $ | 39.4 |  |
| Commercial Heating & Cooling | 11.5 |  |  | 8.6 |  |  | 14.1 |  |
| Refrigeration | 12.1 |  |  | 11.4 |  |  | 15.8 |  |
| Corporate and other | 24.0 |  |  | 21.8 |  |  | 19.1 |  |
| Total capital expenditures (1) | $ | 84.3 |  |  | $ | 69.9 |  |  | $ | 88.4 |  |

[0001069202-17-000003:notes:344]
(1) Includes amounts recorded under capital leases. There were no significant new capital leases in 2016, 2015 or 2014.

[0001069202-17-000003:notes:345]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-17-000003:notes:346]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 21.0 |  |  | $ | 20.7 |  |  | $ | 20.7 |  |
| Commercial Heating & Cooling | 9.8 |  |  | 9.7 |  |  | 9.3 |  |
| Refrigeration | 9.7 |  |  | 15.5 |  |  | 16.3 |  |
| Corporate and other | 17.6 |  |  | 16.9 |  |  | 14.5 |  |
| Total depreciation and amortization | $ | 58.1 |  |  | $ | 62.8 |  |  | $ | 60.8 |  |

[0001069202-17-000003:notes:347]
The equity method investments are shown below (in millions):

[0001069202-17-000003:notes:348]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Refrigeration | $ | 4.0 |  |  | $ | 2.8 |  |  | $ | 2.5 |  |
| Residential | 14.4 |  |  | 10.6 |  |  | 11.3 |  |
| Total income from equity method investments | $ | 18.4 |  |  | $ | 13.4 |  |  | $ | 13.8 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-17-000003:notes:349]
Restructuring Charges:

[0001069202-17-000003:notes:350]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 18.

[0001069202-17-000003:notes:351]
Restructuring Activities in 2016

[0001069202-17-000003:notes:352]
Information regarding the restructuring charges for all ongoing activities are presented in the table below (in millions):

[0001069202-17-000003:notes:353]
|  | Incurred in 2016 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | (0.2 | ) |  | $ | 9.3 |  |  | $ | 9.3 |  |
| Asset write-offs and accelerated depreciation | 0.3 |  |  | 2.4 |  |  | 2.4 |  |
| Lease termination | — |  |  | 0.2 |  |  | 0.2 |  |
| Other | 1.7 |  |  | 3.7 |  |  | 4.1 |  |
| Total | $ | 1.8 |  |  | $ | 15.6 |  |  | $ | 16.0 |  |

[0001069202-17-000003:notes:354]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-17-000003:notes:355]
|  | Incurred in 2016 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Commercial Heating & Cooling | 0.2 |  |  | 1.1 |  |  | 1.1 |  |
| Refrigeration | (0.1 | ) |  | 11.9 |  |  | 11.9 |  |
| Corporate & Other | 1.7 |  |  | 1.7 |  |  | 2.1 |  |
| Total | $ | 1.8 |  |  | $ | 15.6 |  |  | $ | 16.0 |  |

[0001069202-17-000003:notes:356]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.  The activity within the restructuring accruals is summarized in the tables below (in millions):

[0001069202-17-000003:notes:357]
| Description of Reserves: | Balance as of December 31, 2015 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2016 |
| Severance and related expense | $ | 0.7 |  |  | $ | (0.2 | ) |  | $ | (0.5 | ) |  | $ | — |  |  | $ | — |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.3 |  |  | (0.2 | ) |  | (0.1 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | 0.2 |  |  | — |  |  | (0.2 | ) |  | — |  |  | — |  |
| Other | — |  |  | 1.7 |  |  | (1.8 | ) |  | 0.1 |  |  | — |  |
| Total restructuring reserves | $ | 0.9 |  |  | $ | 1.8 |  |  | $ | (2.7 | ) |  | $ | — |  |  | $ | — |  |

[0001069202-17-000003:notes:358]
| Description of Reserves: | Balance as of December 31, 2014 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2015 |
| Severance and related expense | $ | 1.5 |  |  | $ | 2.6 |  |  | $ | (2.9 | ) |  | $ | (0.5 | ) |  | $ | 0.7 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 0.3 |  |  | (0.2 | ) |  | (0.2 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Other | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Total restructuring reserves | $ | 1.6 |  |  | $ | 3.2 |  |  | $ | (3.2 | ) |  | $ | (0.7 | ) |  | $ | 0.9 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001069202-17-000003:notes:359]
Revenue Recognition

[0001069202-17-000003:notes:360]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where title and risk of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.

[0001069202-17-000003:notes:361]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for these services is recognized over the life of the contract.

[0001069202-17-000003:notes:362]
We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.  See Note 22 for more information on these costs.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001069202-17-000003:notes:363]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-17-000003:notes:364]
|  | As of December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 237.6 |  |  | $ | 224.8 |  |  | $ | 243.4 |  |
| Mexico | 69.4 |  |  | 60.0 |  |  | 52.4 |  |
| Canada | 1.4 |  |  | 1.2 |  |  | 0.6 |  |
| International | 53.0 |  |  | 53.6 |  |  | 62.2 |  |
| Total Property, plant and equipment, net | $ | 361.4 |  |  | $ | 339.6 |  |  | $ | 358.6 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001069202-17-000003:notes:365]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-17-000003:notes:366]
| Asset | Useful Life |
| Deferred financing costs | Effective interest method |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001069202-17-000003:notes:367]
Net sales for each major geographic area in which we operate are shown below (in millions):

[0001069202-17-000003:notes:368]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Net Sales to External Customers by Point of Shipment: |  |  |  |  |  |
| United States | $ | 2,966.8 |  |  | $ | 2,793.4 |  |  | $ | 2,576.4 |  |
| Canada | 218.8 |  |  | 217.7 |  |  | 236.3 |  |
| International | 456.0 |  |  | 456.3 |  |  | 554.7 |  |
| Total net sales to external customers | $ | 3,641.6 |  |  | $ | 3,467.4 |  |  | $ | 3,367.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-17-000003:notes:369]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-17-000003:notes:370]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air- cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-17-000003:notes:371]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-17-000003:notes:372]
For the Years Ended December 31, 2016, 2015 and 2014

[0001069202-17-000003:notes:373]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 9.8 |  |  | $ | 2.6 |  |  | $ | (4.6 | ) |  | $ | 1.1 |  |  | $ | (1.0 | ) |  | $ | 7.9 |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 7.9 |  |  | $ | 2.8 |  |  | $ | (4.9 | ) |  | $ | 1.1 |  |  | $ | (0.6 | ) |  | $ | 6.3 |  |
| 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.3 |  |  | $ | 2.4 |  |  | $ | (2.7 | ) |  | $ | 0.9 |  |  | $ | (0.2 | ) |  | $ | 6.7 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-17-000003:notes:374]
Reportable Business Segments:

[0001069202-17-000003:notes:375]
Description of Segments

[0001069202-17-000003:notes:376]
Segment Data

[0001069202-17-000003:notes:377]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001069202-17-000003:notes:378]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-17-000003:notes:379]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-17-000003:notes:380]
(2) The Company defines segment profit and loss as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-17-000003:notes:381]
| • | Special product quality adjustments; |

[0001069202-17-000003:notes:382]
| • | The following items in Losses and other expenses, net: |

[0001069202-17-000003:notes:383]
| ◦ | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001069202-17-000003:notes:384]
| ◦ | Special legal contingency charges, |

[0001069202-17-000003:notes:385]
| ◦ | Asbestos-related litigation, |

[0001069202-17-000003:notes:386]
| ◦ | Environmental liabilities, |

[0001069202-17-000003:notes:387]
| ◦ | Contractor tax payments, |

[0001069202-17-000003:notes:388]
| ◦ | Acquisition costs, and |

[0001069202-17-000003:notes:389]
| ◦ | Other items, net; |

[0001069202-17-000003:notes:390]
| • | Restructuring charges; |

[0001069202-17-000003:notes:391]
| • | Goodwill and asset impairments; |

[0001069202-17-000003:notes:392]
| • | Pension settlement ; and |

[0001069202-17-000003:notes:393]
| • | One time inventory write down. |

[0001069202-17-000003:notes:394]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-17-000003:notes:395]
Geographic Information


## us-gaap:SelfInsuranceReservePolicyTextBlock

[0001069202-17-000003:notes:396]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information and industry factors and trends.  The self-insurance liabilities as of December 31, 2016 represent the best estimate of the future payments to be made on reported and unreported losses for 2016 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 10 for additional information on our self-insured risks and liabilities.


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001069202-17-000003:notes:397]
Selling, General and Administrative Expenses

[0001069202-17-000003:notes:398]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-17-000003:notes:399]
Summary of Significant Accounting Policies:

[0001069202-17-000003:notes:400]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually and whenever events or changes in circumstances indicate the asset may be impaired (See Note 4 for additional information on our goodwill).  The annual goodwill impairment test was performed during the fourth quarter of 2016.

[0001069202-17-000003:notes:401]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-17-000003:notes:402]
For those reporting units which are evaluated using the two-step quantitative goodwill impairment test, we estimate reporting unit fair values using either the discounted cash flow approach or a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. If market approach is used, it is based on objective evidence of market values.

[0001069202-17-000003:notes:403]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-17-000003:notes:404]
We review our indefinite-lived intangible assets for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets. For those intangible assets which are evaluated using the two-step quantitative impairment test, we compare the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets. If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 4 for additional information on our intangible assets.

[0001069202-17-000003:notes:405]
Product Warranties

[0001069202-17-000003:notes:406]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined by product line. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. The estimated units to be repaired under warranty are multiplied by the average cost to repair or replace such products to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 10 for more information on our estimated future warranty costs.

[0001069202-17-000003:notes:407]
Pensions and Post-retirement Benefits

[0001069202-17-000003:notes:408]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheets.  Changes in the funded status are recognized in the year in which the changes occur through accumulated other comprehensive income (“AOCI”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-17-000003:notes:409]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management's estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 12 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-17-000003:notes:410]
Stock-Based Compensation

[0001069202-17-000003:notes:411]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 14 for more information.

[0001069202-17-000003:notes:412]
Use of Estimates

[0001069202-17-000003:notes:413]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-17-000003:notes:414]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-17-000003:notes:415]
Reclassifications

[0001069202-17-000003:notes:416]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:SubsequentEventsTextBlock

[0001069202-17-000003:notes:417]
Subsequent Events:

[0001069202-17-000003:notes:418]
On February 9, 2017, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “ASR Agreement”) with J.P.Morgan Stanley ,to effect an accelerated stock buyback of the Company’s common stock (the “Common Stock”).

[0001069202-17-000003:notes:419]
Under the ASR Agreement, on February 9, 2017, the Company will pay J.P.Morgan Stanley an initial purchase price of $75 million , and J.P.Morgan Stanley will deliver to the Company a total of approximately 0.4 million shares of Common Stock, representing approximately 85%  of the shares expected to be purchased under the ASR Agreement.


## us-gaap:TreasuryStockTextBlock

[0001069202-17-000003:notes:420]
Stock Repurchases:

[0001069202-17-000003:notes:421]
Our Board of Directors has authorized a total of $2 billion  towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $550 million share repurchase authorization in 2016. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date. As of December 31, 2016, $646.0 million of shares may still be repurchased under the Share Repurchase Plans.

[0001069202-17-000003:notes:422]
On February 10, 2016, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “First ASR Agreement”) with Merrill Lynch International (“Merrill Lynch”), acting through its agent, Merrill Lynch, Pierce, Fenner and Smith Incorporated to effect an accelerated stock buyback of the Company’s common stock (the “Common Stock”).

[0001069202-17-000003:notes:423]
Under the First ASR Agreement, on February 10, 2016, the Company paid Merrill Lynch an initial purchase price of $200.0 million, and Merrill Lynch delivered to the Company a total of 1.3 million shares of Common Stock, representing approximately 75% of the shares expected to be purchased under the ASR Agreement. The First ASR Agreement was completed in the third quarter and Merrill Lynch delivered an additional 0.2 million shares of Common Stock to the Company.

[0001069202-17-000003:notes:424]
On August 1, 2016, the Company entered into another Fixed Dollar ASR Agreement (the "Second ASR Agreement) with Wells Fargo to effect an accelerated stock buyback of Common Stock.

[0001069202-17-000003:notes:425]
Under the Second ASR Agreement, on August 1, 2016, the Company paid Wells Fargo an initial purchase price of $100.0 million, and Wells Fargo delivered to the Company a total of 0.5 million shares of Common Stock, representing approximately 75% of the shares expected to be purchased under the Second ASR Agreement. The Second ASR Agreement was completed in the fourth quarter and Wells Fargo delivered an additional  0.2 million shares of Common Stock to the Company.

[0001069202-17-000003:notes:426]
We also repurchased 0.2 million  shares for $33.3 million and 0.3 million shares for $32.0 million for the years ended December 31, 2016 and 2015, respectively, from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the vesting of stock-based compensation awards.
