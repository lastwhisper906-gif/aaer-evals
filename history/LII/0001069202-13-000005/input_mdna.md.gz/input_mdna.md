# LII MD&A — 0001069202-13-000005


## mdna

[0001069202-13-000005:mdna:1]
Item 2.  Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-13-000005:mdna:2]
Business Overview

[0001069202-13-000005:mdna:3]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For  additional information regarding our reportable segments, see Note 15 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000005:mdna:4]
Our fiscal year ends on December 31 and our interim fiscal quarters are each comprised of 13 weeks.  For convenience, throughout this Management’s Discussion and Analysis of Financial Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted by the last day of the calendar quarter.

[0001069202-13-000005:mdna:5]
Our products and services are sold through a combination of direct sales, distributors and company-owned parts and supplies stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  Also, a substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-13-000005:mdna:6]
The principal elements of cost of goods sold in our manufacturing operations are components, raw materials, factory overhead, labor and estimated costs of warranty expense.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components have impacted us and the HVACR industry in general.  We seek to mitigate the impact of higher commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-13-000005:mdna:7]
Financial Overview

[0001069202-13-000005:mdna:8]
In the first quarter of 2013, the Residential Heating & Cooling segment continued to lead our overall operational performance with a 15% increase in net sales and a $10 million increase in segment profit compared to the first quarter of 2012.  The primary growth driver for this segment was industry growth in our new construction and replacement businesses.  Our Commercial Heating & Cooling segment also performed well in the first quarter of 2013 with a 4% increase in net sales and $3 million in increased segment profit compared to the first quarter of 2012.  This segment's profits were up largely due to improved product profit margins that were driven by volume increases from national accounts business and favorable sales price and mix.  Sales in our Refrigeration segment were also up 3%, or were up 4% when excluding a 1% unfavorable currency impact.  The segment profit for Refrigeration increased $3 million compared to the first quarter of 2012 primarily due to growth in our Australia refrigerant distribution business.

[0001069202-13-000005:mdna:9]
On a consolidated basis, our product profit margins improved quarter over quarter due to volume increases primarily in our Residential Heating & Cooling segment, growth in the Australia refrigerant distribution business, and overall favorable commodity

[0001069202-13-000005:mdna:10]
pricing on raw materials.  We continue to manage our cost structure by utilizing a combination of commodity hedging practices and controllable product cost management practices through manufacturing, sourcing and engineering initiatives.

[0001069202-13-000005:mdna:11]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer"), in an all cash transaction, for proceeds of $10.4 million.  The proceeds include a determinable working capital adjustment of $3.8 million to be received in the second quarter of 2013 and exclude transaction costs.  The $1.7 million gain on sale of the business and the operating results for the business through March 22, 2013 are presented in discontinued operations.  The Company also entered into a two-year equipment and parts supply agreement with the Buyer.

[0001069202-13-000005:mdna:12]
Financial Highlights

[0001069202-13-000005:mdna:13]
| • | Net sales in the first quarter increased $54 million, or 9%, from $614 million in 2012 to $668 million in 2013. Foreign currency exchange rates were neutral to net sales quarter over quarter. |

[0001069202-13-000005:mdna:14]
| • | Operational income from continuing operations for the first quarter of 2013 was $28 million compared to $19 million for the same quarter of 2012. The increase was primarily due to higher volumes and higher gross profit margins from favorable price and material cost savings, partially offset by higher freight and distribution costs and higher incentive compensation due to overall improved operating results in 2013. |

[0001069202-13-000005:mdna:15]
| • | Net income for the first quarter of 2013 was $8 million compared to a net loss of $6 million in the first quarter of 2012. |

[0001069202-13-000005:mdna:16]
| • | Diluted earnings per share from continuing operations were $0.31 per share in the first quarter of 2013 compared to $0.18 per share in the first quarter of 2012. |

[0001069202-13-000005:mdna:17]
| • | We used $137 million of cash for operating activities in the first quarter of 2013 compared to $34 million in the first quarter of 2012. |

[0001069202-13-000005:mdna:18]
[same as prior period, unchanged from 0001069202-12-000005:mdna:16]

[0001069202-13-000005:mdna:19]
[same as prior period, unchanged from 0001069202-12-000005:mdna:17]

[0001069202-13-000005:mdna:20]
|  | For the Three Months Ended March 31, |
|  | Dollars |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net sales | $ | 668.4 |  |  | $ | 614.4 |  |  | 8.8 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 506.4 |  |  | 473.5 |  |  | (6.9 | ) |  | 75.8 |  |  | 77.1 |  |
| Gross profit | 162.0 |  |  | 140.9 |  |  | 15.0 |  |  | 24.2 |  |  | 22.9 |  |
| Selling, general and administrative expenses | 135.6 |  |  | 123.2 |  |  | (10.1 | ) |  | 20.3 |  |  | 20.1 |  |
| Losses (gains) and other expenses, net | 1.1 |  |  | (1.4 | ) |  | (178.6 | ) |  | 0.2 |  |  | (0.2 | ) |
| Restructuring charges | 0.5 |  |  | 2.6 |  |  | 80.8 |  |  | 0.1 |  |  | 0.4 |  |
| Income from equity method investments | (3.1 | ) |  | (2.4 | ) |  | 29.2 |  |  | (0.5 | ) |  | (0.4 | ) |
| Operational income from continuing operations | $ | 27.9 |  |  | $ | 18.9 |  |  | 47.6 | % |  | 4.2 | % |  | 3.1 | % |

[0001069202-13-000005:mdna:21]
First Quarter of 2013 Compared to First Quarter of 2012 - Consolidated Results

[0001069202-13-000005:mdna:22]
[same as prior period, unchanged from 0001069202-12-000005:mdna:19]

[0001069202-13-000005:mdna:23]
Net sales increased 9% in the first quarter of 2013 compared to the first quarter of 2012.  Our sales volume was up 7% and price and mix were up 2% from the comparable period.  The increase in volume was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  The increase in price and mix was driven primarily by improvements in the Refrigeration segment's Australia refrigerant distribution business.

[0001069202-13-000005:mdna:24]
[same as prior period, unchanged from 0001069202-12-000005:mdna:21]

[0001069202-13-000005:mdna:25]
Gross profit margins improved 130 basis points to 24.2% in the first quarter of 2013 compared to 22.9% in the first quarter of 2012.  Improved price and mix contributed 220 basis points to profit margin and improved commodity and non-commodity material costs contributed a collective 30 basis points over the first quarter of 2012.  Partially offsetting these increases were approximately

[0001069202-13-000005:mdna:26]
120 basis points of higher freight and distribution costs.

[0001069202-13-000005:mdna:27]
[same as prior period, unchanged from 0001069202-12-000005:mdna:24]

[0001069202-13-000005:mdna:28]
Selling, General & Administrative (“SG&A”) expenses increased by $12 million in the first quarter of 2013 compared to the first quarter of 2012.  As a percentage of net sales, SG&A expenses increased 20 basis points from 20.1% to 20.3% in the same periods.  The increase in SG&A expenses was principally due to higher incentive compensation due to overall improved operating results in the first quarter of 2013.

[0001069202-13-000005:mdna:29]
Losses (gains) and Other Expenses, Net

[0001069202-13-000005:mdna:30]
Losses and other expenses, net for first quarters of 2013 and 2012 included the following (in millions):

[0001069202-13-000005:mdna:31]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Realized losses (gains) on settled futures contracts | $ | — |  |  | $ | 0.3 |  |
| Foreign currency exchange losses | (0.2 | ) |  | (0.2 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts | 1.0 |  |  | (1.7 | ) |
| Special legal contingency charge | 0.2 |  |  | — |  |
| Other items, net | 0.1 |  |  | 0.2 |  |
| Losses (gains) and other expenses, net | $ | 1.1 |  |  | $ | (1.4 | ) |

[0001069202-13-000005:mdna:32]
The change in realized gains and losses on settled futures contracts in the first quarter of 2013 was attributable to increases in commodity prices relative to our futures contract prices.  Conversely, the change in unrealized gains on unsettled futures contracts was primarily due to lower commodity prices relative to the futures contract prices.  For more information on our derivatives, see Note 4 in the Notes to the Consolidated Financial Statements.  The special legal contingency charge in the first quarter of 2013 relates to ongoing patent litigation.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for more information on this litigation.

[0001069202-13-000005:mdna:33]
[same as prior period, unchanged from 0001069202-12-000005:mdna:30]

[0001069202-13-000005:mdna:34]
Restructuring charges were $0.5 million in the first quarter of 2013 compared to $2.6 million in the first quarter of 2012.  We did not initiate any new large projects in 2013.  The charges in both years related primarily to our Regional Distribution Network project.  Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on our restructuring activity.

[0001069202-13-000005:mdna:35]
Income from Equity Method Investments

[0001069202-13-000005:mdna:36]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments increased slightly to $3 million in the first quarter of 2013 compared to $2 million in the first quarter of 2012 primarily due to improved operational performance from our joint ventures.

[0001069202-13-000005:mdna:37]
Interest Expense, net

[0001069202-13-000005:mdna:38]
Interest expense, net of $3 million in the first quarter of 2013 declined from $5 million in the first quarter of 2012 due to a decrease in our weighted average borrowings in the comparable periods.  Our weighted average interest rates were relatively flat.

[0001069202-13-000005:mdna:39]
Income Taxes

[0001069202-13-000005:mdna:40]
The income tax provision was $9 million in the first quarter of 2013 compared to $5 million in the first quarter of 2012.  The effective tax rate was 35.2% for the first quarter of 2013 compared to 34.6% for the first quarter of 2012.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, such as tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-13-000005:mdna:41]
[same as prior period, unchanged from 0001069202-12-000005:mdna:38]

[0001069202-13-000005:mdna:42]
The loss from discontinued operations relates to the Service Experts business, which we sold on March 22, 2013, and the Hearth business, which we sold in April 2012.  The pre-tax loss from discontinued operations was $13 million in the first quarter of 2013 compared to $23 million in the first quarter of 2012.

[0001069202-13-000005:mdna:43]
The Service Experts business had a pre-tax loss of $13 million in the first quarter of 2013 compared to a pre-tax loss of $14 million in the first quarter of 2012.  The pre-tax loss from discontinued operations in the first quarter of 2013 included operating losses of $13 million and $2 million for certain retention bonuses and severance costs, partially offset by a $2 million gain on the sale of the business.  The pre-tax loss in the first quarter of 2012 consisted of operating losses of $14 million.

[0001069202-13-000005:mdna:44]
The Hearth business had no significant gains, losses or other activity in the first quarter of 2013.  The business had a pre-tax loss of $8 million in the first quarter of 2012 that included $2 million of operating losses and a $6 million charge to write down certain long-lived assets to their fair value.

[0001069202-13-000005:mdna:45]
First Quarter of 2013 Compared to First Quarter of 2012 - Results by Segment

[0001069202-13-000005:mdna:46]
Residential Heating & Cooling

[0001069202-13-000005:mdna:47]
The following table details our Residential Heating & Cooling segment's net sales and profit for for the first quarters of 2013 and 2012 (dollars in millions):

[0001069202-13-000005:mdna:48]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 314.5 |  |  | $ | 272.6 |  |  | $ | 41.9 |  |  | 15.4 | % |
| Profit | $ | 20.5 |  |  | $ | 11.0 |  |  | $ | 9.5 |  |  | 86.4 | % |
| % of net sales | 6.5 | % |  | 4.0 | % |  |  |  |  |

[0001069202-13-000005:mdna:49]
Residential Heating & Cooling net sales increased by 15% in the first quarter of 2013 compared to first quarter of 2012 primarily due to increases in sales volumes.  The increase in volumes was attributable to industry growth in our new construction and replacement businesses quarter over quarter.  Sales price and mix and other factors in first quarter of 2013 were all relatively comparable to first quarter of 2012.

[0001069202-13-000005:mdna:50]
Segment profit for the first quarter of 2013 increased $10 million due to $11 million in higher sales volumes, $3 million in material cost savings and $2 million in favorable price and mix.  Partially offsetting these increases were $2 million in higher SG&A costs due primarily to higher employee compensation costs and $4 million of higher freight and distribution expenses due to continued investment in distribution initiatives.

[0001069202-13-000005:mdna:51]
Commercial Heating & Cooling

[0001069202-13-000005:mdna:52]
The following table details our Commercial Heating & Cooling segment's net sales and profit for the first quarters of 2013 and 2012 (dollars in millions):

[0001069202-13-000005:mdna:53]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 163.0 |  |  | $ | 156.7 |  |  | $ | 6.3 |  |  | 4.0 | % |
| Profit | $ | 11.1 |  |  | $ | 8.3 |  |  | $ | 2.8 |  |  | 33.7 | % |
| % of net sales | 6.8 | % |  | 5.3 | % |  |  |  |  |

[0001069202-13-000005:mdna:54]
Commercial Heating & Cooling net sales increased 4% in the first quarter of 2013 compared to the first quarter of 2012 due  to increased sales volumes.  Sales volume growth was primarily attributable to increases in our national accounts business.

[0001069202-13-000005:mdna:55]
Segment profit in the first quarter of 2013 increased $3 million compared to the first quarter of 2012.  Increases of $2 million for higher sales volumes and $2 million for favorable price and mix were partially offset by $1 million of higher freight and distribution expenses due to continued investment in distribution initiatives.

[0001069202-13-000005:mdna:56]
[same as prior period, unchanged from 0001069202-12-000005:mdna:54]

[0001069202-13-000005:mdna:57]
The following table details our Refrigeration segment's net sales and profit for the first quarters of 2013 and 2012 (dollars in millions):

[0001069202-13-000005:mdna:58]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 190.9 |  |  | $ | 185.1 |  |  | $ | 5.8 |  |  | 3.1 | % |
| Profit | $ | 16.7 |  |  | $ | 14.2 |  |  | $ | 2.5 |  |  | 17.6 | % |
| % of net sales | 8.7 | % |  | 7.7 | % |  |  |  |  |

[0001069202-13-000005:mdna:59]
Refrigeration net sales increased 3% in the first quarter of 2013 compared to the first quarter of 2012.  Net sales were up 4% excluding the 1% unfavorable impact from foreign currency exchange rates.  The increase in the first quarter of 2013 was attributable to growth of 6% in the Australia wholesale refrigerant business that were offset by volume declines of 2%.  Sales volumes declined in first quarter of 2013 because certain supermarket customers slowed order rates.

[0001069202-13-000005:mdna:60]
Segment profit for the first quarter of 2013 increased $3 million over the first quarter of 2012, with increases of $7 million from growth in the Australia wholesale refrigerant business which benefited from one-time purchases of lower cost inventory and investments in related operations.  Partially offsetting this benefit was $4 million of higher SG&A expenses.

[0001069202-13-000005:mdna:61]
[same as prior period, unchanged from 0001069202-12-000005:mdna:59]

[0001069202-13-000005:mdna:62]
Corporate and other expenses increased $5 million to $19 million in the first quarter of 2013 from $14 million in the first quarter of 2012.  The increase was driven by an approximate $5 million increase in incentive compensation due to improved overall operating results.

[0001069202-13-000005:mdna:63]
[same as prior period, unchanged from 0001069202-12-000005:mdna:107]

[0001069202-13-000005:mdna:64]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-13-000005:mdna:65]
[same as prior period, unchanged from 0001069202-12-000005:mdna:109]

[0001069202-13-000005:mdna:66]
The following table summarizes our cash flow activity for the three months ended March 31, 2013 and 2012 (in millions):

[0001069202-13-000005:mdna:67]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Net cash used in operating activities | $ | (137.3 | ) |  | $ | (34.3 | ) |
| Net cash used in investing activities | (6.9 | ) |  | (6.8 | ) |
| Net cash provided by financing activities | 128.6 |  |  | 48.2 |  |

[0001069202-13-000005:mdna:68]
Net Cash Used in Operating Activities.  Net cash used in operating activities increased $103 million to $137 million in the first quarter of 2013 compared to $34 million in the first quarter of 2012.  This increase in use of cash was primarily attributable to higher working capital requirements and a decrease in accrued expenses.  Generally, we carry higher than average inventory balances in the first and second quarters to meet the demand of the peak cooling season.  Working capital was higher in the first quarter of 2013 because of increases in inventory as we prepare for expected summer demand as well as an increase in accounts receivable due to higher sales volumes quarter over quarter, partially offset by increases in accounts payable.  The reduction in accrued expenses was primarily due to payments of employee incentive compensation earned in 2012 and payments of annual volume rebates.

[0001069202-13-000005:mdna:69]
Net Cash Used in Investing Activities.  Capital expenditures were $12 million and $7 million in the first quarters of 2013 and

[0001069202-13-000005:mdna:70]
2012, respectively.  Capital expenditures in 2013 were primarily investments in our distribution network, investments in systems and software to support the overall enterprise, and investments for manufacturing and sourcing excellence.  Net cash used in investing activities also included net proceeds of $5 million in the first quarter of 2013 from the sale of the Service Experts business.

[0001069202-13-000005:mdna:71]
Net Cash Provided by Financing Activities.  Net cash provided by financing activities increased to $129 million in the first quarter of 2013 primarily due to an increase in net borrowings.  The net borrowings were higher in 2013 to support the increasing sales and seasonal rise in working capital requirements.

[0001069202-13-000005:mdna:72]
Debt Position

[0001069202-13-000005:mdna:73]
The following table details our lines of credit and financing arrangements as of March 31, 2013 (in millions):

[0001069202-13-000005:mdna:74]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-Term Debt: |  |  |  |  |  |
| Foreign Obligations | $ | 29.0 |  |  | $ | 6.0 |  |  | $ | 23.0 |  |
| Asset Securitization Program (1) | 160.0 |  |  | 20.0 |  |  | 140.0 |  |
| Total short-term debt | $ | 189.0 |  |  | $ | 26.0 |  |  | $ | 163.0 |  |
| Current Maturities: |  |  |  |  |  |
| Capital lease obligations | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | — |  |
| Long-Term Debt: |  |  |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 15.8 |  |  | $ | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 274.0 |  |  | 326.1 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 865.8 |  |  | 489.8 |  |  | 326.1 |  |
| Total debt | $ | 1,055.4 |  |  | $ | 516.4 |  |  | $ | 489.1 |  |

[0001069202-13-000005:mdna:75]
| (1) | The maximum capacity under the Asset Securitization Program (“ASP”) is the lesser of $160.0 million or 100% of the net pool balance less reserves, as defined under the ASP. |

[0001069202-13-000005:mdna:76]
| (2) | The available future borrowings on our domestic revolving credit facility were reduced by $49.9 million in outstanding standby letters of credit. We had an additional $20.0 million in standby letters of credit with other banks. |

[0001069202-13-000005:mdna:77]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage.  We consider various other financing alternatives and may, from time to time, seek to take advantage of favorable interest rate environments or other market conditions, which may include accessing the capital markets.  Also, as our peak season arrives, we typically pay down debt.

[0001069202-13-000005:mdna:78]
Financial Leverage

[0001069202-13-000005:mdna:79]
Our debt-to-total-capital ratio increased to 53.3% at March 31, 2013 compared to 43.8% at December 31, 2012.  The increase in the ratio in the first quarter of 2013 is due to the increase in our net borrowings, as noted above, as well as a decrease in equity primarily related to the reclassification of currency translation adjustments from accumulated other comprehensive income into net income.  (Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on this reclassification).  We evaluate our debt-to-capital ratio as well as our debt-to-EBITDA ratio in order to determine the appropriate targets for share repurchases under our share repurchase programs.  Our senior credit ratings were investment grade as of March 31, 2013 and our goal is to retain investment grade ratings.

[0001069202-13-000005:mdna:80]
Liquidity

[0001069202-13-000005:mdna:81]
We believe our available future borrowings combined with our cash of $35 million and future cash from operations are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Our expected capital expenditures for 2013 are $60 million.

[0001069202-13-000005:mdna:82]
Included in our cash and cash equivalents of $35 million as of March 31, 2013 was $21 million of cash held in foreign locations.  Our cash in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and to pay taxes in the United States for the amounts that were repatriated.

[0001069202-13-000005:mdna:83]
We also continue to increase shareholder value through dividend payments and our share repurchase programs.  In 2013, we are targeting approximately $100 million in share repurchases under the existing share repurchase programs and over $30 million of dividend payments.

[0001069202-13-000005:mdna:84]
Off Balance Sheet Arrangements

[0001069202-13-000005:mdna:85]
[same as prior period, unchanged from 0001069202-12-000005:mdna:133]

[0001069202-13-000005:mdna:86]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019.  The agreement provides for financial covenants consistent with our credit agreement and we were in compliance with those covenants as of March 31, 2013.  The lease is classified as an operating lease and we expect to realize annual savings of approximately $2 million in net rent costs from this renewal compared to our previous leasing arrangement.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for more details.

[0001069202-13-000005:mdna:87]
Commitments, Contingencies and Guarantees

[0001069202-13-000005:mdna:88]
For more information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000005:mdna:89]
We incur the risk of liability claims for the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance.  The estimate of our liability for future warranty costs requires us to make significant assumptions about the amount, timing and nature of the costs we will incur in the future. We periodically review the assumptions used to determine the liability and adjust our assumptions based upon factors such as actual failure rates and cost experience. Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, and changes in manufacturing techniques or locations, components or suppliers used. In recent years, changes in the warranty liability as the result of the issuance of new warranties and the payments made have remained relatively stable. Should actual warranty costs differ from our estimates, we may be required to record adjustments to accruals and expense in the future. At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year, we perform a complete re-evaluation of our warranty liabilities.

[0001069202-13-000005:mdna:90]
We also may incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications. We identified product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in 2012.  As of March 31, 2013, we have $6 million accrued for these matters. We may incur additional charges in the future as more information becomes available.

[0001069202-13-000005:mdna:91]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts known and do not believe that any current, pending or threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Litigation, however, involves uncertainties and it is possible that the eventual outcome of litigation could adversely affect our results of operations for a particular period.

[0001069202-13-000005:mdna:92]
Recent Accounting Pronouncements

[0001069202-13-000005:mdna:93]
In February 2013, the FASB updated its guidance related to the presentation of comprehensive income and accumulated other comprehensive income ("AOCI").  The updated guidance requires additional footnote disclosure of items reclassified out of AOCI and into net income as well as the effect of the reclassifications on each affected Statement of Operations line item.  This updated

[0001069202-13-000005:mdna:94]
guidance was applicable beginning in the first quarter of 2013 on a prospective basis.  The required disclosures can be found in Note 11 of the Notes to the Consolidated Financial Statements.
