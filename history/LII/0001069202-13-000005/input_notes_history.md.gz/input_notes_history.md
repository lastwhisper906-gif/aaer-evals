# LII note change history — 0001069202-12-000005 → 0001069202-13-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2013-04-22):
[0001069202-13-000005:note_history:1]
Leases

- added (2013-04-22):
[0001069202-13-000005:note_history:2]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas (the "Lake Park Renewal") for a term of approximately six years through March 1, 2019.  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease.

- added (2013-04-22):
[0001069202-13-000005:note_history:3]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Domestic Credit Facility.  We were in compliance with those covenants as of March 31, 2013.

- changed (2013-04-22):
[0001069202-13-000005:note_history:4]
Total liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):
  (was, 2012-10-22, similarity 0.885):
[0001069202-12-000005:note_history:4]
Total liabilities for estimated product warranty are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

- changed (2013-04-22):
[0001069202-13-000005:note_history:5]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Accrued expenses | $ | 24.2 |  |  | $ | 25.1 |  |
| Other liabilities | 49.6 |  |  | 46.8 |  |
|  | $ | 73.8 |  |  | $ | 71.9 |  |
  (was, 2012-10-22, similarity 0.9669):
[0001069202-12-000005:note_history:5]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Accrued expenses | $ | 25.5 |  |  | $ | 26.7 |  |
| Other liabilities | 45.1 |  |  | 41.6 |  |
|  | $ | 70.6 |  |  | $ | 68.3 |  |

- changed (2013-04-22):
[0001069202-13-000005:note_history:6]
The changes in total product warranty liabilities related to continuing operations for the three months ended March 31, 2013 were as follows (in millions):
  (was, 2012-10-22, similarity 0.7739):
[0001069202-12-000005:note_history:6]
The changes in total product warranty liabilities for the first nine months of 2012 were as follows (in millions):

- changed (2013-04-22):
[0001069202-13-000005:note_history:7]
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (3.9 | ) |
| Changes resulting from issuance of new warranties | 6.1 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Changes in foreign currency translation rates and other | (0.3 | ) |
| Total warranty liability as of March 31, 2013 | $ | 73.8 |  |
  (was, 2012-10-22, similarity 0.8596):
[0001069202-12-000005:note_history:7]
| Total warranty liability as of December 31, 2011 | $ | 68.3 |  |
| Payments made in 2012 | (18.2 | ) |
| Changes resulting from issuance of new warranties | 20.0 |  |
| Changes in estimates associated with pre-existing liabilities | 0.2 |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of September 30, 2012 | $ | 70.6 |  |

- added (2013-04-22):
[0001069202-13-000005:note_history:8]
We evaluate our heating, ventilation and air conditioning ("HVAC") warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.

- added (2013-04-22):
[0001069202-13-000005:note_history:9]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the three months ended March 31, 2013 were as follows (in millions):

- added (2013-04-22):
[0001069202-13-000005:note_history:10]
| Total accrued product quality issue as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims | (0.6 | ) |
| Total accrued product quality issue as of March 31, 2013 | $ | 6.1 |  |

- added (2013-04-22):
[0001069202-13-000005:note_history:11]
Litigation

- added (2013-04-22):
[0001069202-13-000005:note_history:12]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

- added (2013-04-22):
[0001069202-13-000005:note_history:13]
Some of these claims and lawsuits allege health problems resulting from exposure to asbestos and we expect that additional claims will be brought against us in the future. However, our liability exposure from those additional future claims cannot be estimated because of numerous uncertainties, including the number of such claims and lawsuits and the costs of defending and settling them, possible adverse judgments in amounts greater than previously experienced, and possible changes in the laws and process governing the compensation of asbestos claimants.  In the first quarter of 2013, we recorded charges of $0.6 million, net of insurance recoveries, related to asbestos matters in Selling, general and administrative expenses in the accompanying Consolidated Statement of Operation.

- added (2013-04-22):
[0001069202-13-000005:note_history:14]
We are also involved in patent litigation claims related to products from an acquired business.  The Company believes it has indemnification protection (with certain limitations) for these claims.

- added (2013-04-22):
[0001069202-13-000005:note_history:15]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.

- removed (2013-04-22):
[0001069202-12-000005:note_history:16]
We are subject to contingencies that arise in the normal course of business, including pending litigation, product warranties and other product related contingencies, environmental matters and other guarantees or claims.

- removed (2013-04-22):
[0001069202-12-000005:note_history:17]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts known. We do not believe that any current or pending or threatened litigation will have a material adverse effect on our financial position. Litigation and arbitration, however, involve uncertainties and it is possible that the eventual outcome of litigation could adversely affect our results of operations for a particular period.

- removed (2013-04-22):
[0001069202-12-000005:note_history:18]
We use a combination of third-party insurance and large deductible self-insurance plans to provide protection against claims relating to contingencies such as workers’ compensation, general liability, product liability, property damage, aviation liability, directors’ and officers’ liability, auto liability, physical damage and other exposures. Self-insurance expense and liabilities are actuarially determined based on our historical claims information, as well as industry factors and trends. The majority of our self-insured risks (excluding auto liability and physical damage) will be paid over an extended period of time. There have been no material changes in our insurance liability since our latest fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our large deductible plans. The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were $64.0 million and $63.1 million as of September 30, 2012 and December 31, 2011, respectively.

- removed (2013-04-22):
[0001069202-12-000005:note_history:19]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic Revolving Credit Facility. We were in compliance with these financial covenants as of September 30, 2012.

- removed (2013-04-22):
[0001069202-12-000005:note_history:20]
At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year, we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities. As a result of the second quarter re-evaluation, we decreased our warranty liability by $0.4 million.

- removed (2013-04-22):
[0001069202-12-000005:note_history:21]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in the second quarter of 2012. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the first nine months of 2012 were as follows (in millions):

- removed (2013-04-22):
[0001069202-12-000005:note_history:22]
| Total accrued product quality issue as of December 31, 2011 | $ | 7.5 |  |
| Estimated expense for expected product quality claims | 1.7 |  |
| Product quality claims | (2.1 | ) |
| Total accrued product quality issue as of September 30, 2012 | $ | 7.1 |  |


## us-gaap:ProductLiabilityContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-04-22):
[0001069202-13-000005:note_history:23]
The changes in the accrued product quality issues for the three months ended March 31, 2013 were as follows (in millions):
  (was, 2012-10-22, similarity 0.886):
[0001069202-12-000005:note_history:23]
The changes in the accrued product quality issues for the first nine months of 2012 were as follows (in millions):

- added (2013-04-22):
[0001069202-13-000005:note_history:24]
| Total accrued product quality issue as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims | (0.6 | ) |
| Total accrued product quality issue as of March 31, 2013 | $ | 6.1 |  |

- removed (2013-04-22):
[0001069202-12-000005:note_history:25]
| Total accrued product quality issue as of December 31, 2011 | $ | 7.5 |  |
| Estimated expense for expected product quality claims | 1.7 |  |
| Product quality claims | (2.1 | ) |
| Total accrued product quality issue as of September 30, 2012 | $ | 7.1 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-04-22):
[0001069202-13-000005:note_history:26]
References in this Quarterly Report on Form 10-Q to "we," "our," "us," "LII," or the "Company" refer to Lennox International Inc. and its subsidiaries, unless the context requires otherwise.
  (was, 2012-10-22, similarity 0.9443):
[0001069202-12-000005:note_history:26]
References in this Quarterly Report on Form 10-Q to “we,” “our,” “us,” “LII” or the “Company” refer to Lennox International Inc. and its subsidiaries, unless the context requires otherwise.

- changed (2013-04-22):
[0001069202-13-000005:note_history:27]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2013, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2013 and 2012, the unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2013 and 2012, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2013 and 2012 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2012. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2012-10-22, similarity 0.9461):
[0001069202-12-000005:note_history:27]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2012, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2012 and 2011, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2011. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2013-04-22):
[0001069202-13-000005:note_history:28]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.
  (was, 2012-10-22, similarity 0.9037):
[0001069202-12-000005:note_history:28]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, and pension and postretirement medical benefits, among others. These estimates and assumptions are based on management’s best estimates and judgment.

- added (2013-04-22):
[0001069202-13-000005:note_history:29]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency, and commodity markets combined to increase the uncertainty inherent in such estimates and assumptions.  As future events and their effects cannot be determined with precision, actual results could differ significantly from these estimates.  Changes in those estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

- changed (2013-04-22):
[0001069202-13-000005:note_history:30]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.
  (was, 2012-10-22, similarity 0.7905):
[0001069202-12-000005:note_history:30]
Certain prior year amounts have been reclassified to conform to the current year presentation.

- removed (2013-04-22):
[0001069202-12-000005:note_history:31]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when facts and circumstances dictate.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-04-22):
[0001069202-13-000005:note_history:32]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.20 | % |  | 1.46 | % |
  (was, 2012-10-22, similarity 0.95):
[0001069202-12-000005:note_history:32]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Weighted average borrowing rate | 1.47 | % |  | 1.53 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2013-04-22):
[0001069202-13-000005:note_history:33]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 20.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 6.0 |  |  | 4.9 |  |
| Total short-term debt | $ | 26.0 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.6 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 274.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 489.8 |  |  | $ | 351.0 |  |
| Total debt | $ | 516.4 |  |  | $ | 386.6 |  |

- changed (2013-04-22):
[0001069202-13-000005:note_history:34]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $6.0 million and $4.9 million of foreign obligations as of March 31, 2013 and December 31, 2012, respectively, that are primarily borrowings under non-committed facilities.
  (was, 2012-10-22, similarity 0.7886):
[0001069202-12-000005:note_history:34]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $6.1 million and $4.7 million of foreign obligations as of September 30, 2012 and December 31, 2011, respectively.

- added (2013-04-22):
[0001069202-13-000005:note_history:35]
Under the Receivables Purchase Agreement, or Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.

- added (2013-04-22):
[0001069202-13-000005:note_history:36]
The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

- added (2013-04-22):
[0001069202-13-000005:note_history:37]
The ASP provides for a maximum securitization amount of the lesser of $160.0 million or 100% of the net pool balance as defined by the ASP.  However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- added (2013-04-22):
[0001069202-13-000005:note_history:38]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 20.0 |  |  | 30.0 |  |
| Remaining amount available | $ | 140.0 |  |  | $ | 130.0 |  |

- changed (2013-04-22):
[0001069202-13-000005:note_history:39]
Under the ASP, we pay certain discount fees to use the program and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates for March 31, 2013 and for December 31, 2012 were 0.84% and 0.85%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):
  (was, 2012-10-22, similarity 0.9366):
[0001069202-12-000005:note_history:39]
Under the ASP, we pay certain discount fees to use the program and have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for September 30, 2012 was 0.87% and the average rate at December 31, 2011 was 0.91%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):

- changed (2013-04-22):
[0001069202-13-000005:note_history:40]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.3 |  |
  (was, 2012-10-22, similarity 0.7161):
[0001069202-12-000005:note_history:40]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.9 |  |  | $ | 0.5 |  |

- changed (2013-04-22):
[0001069202-13-000005:note_history:41]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2013, we were in compliance with all covenant requirements.
  (was, 2012-10-22, similarity 0.8337):
[0001069202-12-000005:note_history:41]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Domestic Revolving Credit Facility and senior unsecured notes. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the ASP. As of September 30, 2012, we were in compliance with all covenant requirements.

- added (2013-04-22):
[0001069202-13-000005:note_history:42]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $274.0 million and $49.9 million committed to standby letters of credit as of March 31, 2013. Subject to covenant limitations, $326.1 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2013-04-22):
[0001069202-13-000005:note_history:43]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.20 | % |  | 1.46 | % |
  (was, 2012-10-22, similarity 0.95):
[0001069202-12-000005:note_history:43]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Weighted average borrowing rate | 1.47 | % |  | 1.53 | % |

- changed (2013-04-22):
[0001069202-13-000005:note_history:44]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.
  (was, 2012-10-22, similarity 0.7692):
[0001069202-12-000005:note_history:44]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

- changed (2013-04-22):
[0001069202-13-000005:note_history:45]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2013, we were in compliance with all covenant requirements.
  (was, 2012-10-22, similarity 0.9869):
[0001069202-12-000005:note_history:45]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2012, we were in compliance with all covenant requirements.

- changed (2013-04-22):
[0001069202-13-000005:note_history:46]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.   As of March 31, 2013, we were in compliance with all covenant requirements.
  (was, 2012-10-22, similarity 0.9918):
[0001069202-12-000005:note_history:46]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2012, we were in compliance with all covenant requirements.

- removed (2013-04-22):
[0001069202-12-000005:note_history:47]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 25.0 |  |  | $ | — |  |
| Foreign obligations | 6.1 |  |  | 4.7 |  |
| Total short-term debt | $ | 31.1 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: | $ | 0.3 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.6 |  |  | $ | 16.6 |  |
| Domestic revolving credit facility | 233.0 |  |  | 243.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 449.6 |  |  | $ | 459.6 |  |
| Total debt | $ | 481.0 |  |  | $ | 465.1 |  |

- removed (2013-04-22):
[0001069202-12-000005:note_history:48]
Under the Receivables Purchase Agreement, or Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. The ASP provides for a maximum securitization amount of the lesser of $150.0 million or 100% of the net pool balance as defined by the ASP. However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. On March 30, 2012, the parties involved with this securitization program agreed to remove Lennox Hearth Products LLC from the program. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. The eligible amounts available and beneficial interests sold were as follows (in millions):

- removed (2013-04-22):
[0001069202-12-000005:note_history:49]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 150.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold | 25.0 |  |  | — |  |
| Remaining amount available | $ | 125.0 |  |  | $ | 150.0 |  |

- removed (2013-04-22):
[0001069202-12-000005:note_history:50]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $233.0 million and $49.9 million committed to standby letters of credit as of September 30, 2012. Subject to covenant limitations, $367.1 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2013-04-22):
[0001069202-13-000005:note_history:51]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 20.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 6.0 |  |  | 4.9 |  |
| Total short-term debt | $ | 26.0 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.6 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 274.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 489.8 |  |  | $ | 351.0 |  |
| Total debt | $ | 516.4 |  |  | $ | 386.6 |  |

- removed (2013-04-22):
[0001069202-12-000005:note_history:52]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 25.0 |  |  | $ | — |  |
| Foreign obligations | 6.1 |  |  | 4.7 |  |
| Total short-term debt | $ | 31.1 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: | $ | 0.3 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.6 |  |  | $ | 16.6 |  |
| Domestic revolving credit facility | 233.0 |  |  | 243.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 449.6 |  |  | $ | 459.6 |  |
| Total debt | $ | 481.0 |  |  | $ | 465.1 |  |
