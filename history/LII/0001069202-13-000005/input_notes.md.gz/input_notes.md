# LII notes — 0001069202-13-000005


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-13-000005:notes:1]
[same as prior period, unchanged from 0001069202-12-000005:notes:1]

[0001069202-13-000005:notes:2]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2013, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2013 and 2012, the unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2013 and 2012, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2013 and 2012 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2012. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-13-000005:notes:3]
[same as prior period, unchanged from 0001069202-12-000005:notes:3]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-13-000005:notes:4]
Commitments and Contingencies:

[0001069202-13-000005:notes:5]
Leases

[0001069202-13-000005:notes:6]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas (the "Lake Park Renewal") for a term of approximately six years through March 1, 2019.  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease.

[0001069202-13-000005:notes:7]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Domestic Credit Facility.  We were in compliance with those covenants as of March 31, 2013.

[0001069202-13-000005:notes:8]
Product Warranties and Product Related Contingencies

[0001069202-13-000005:notes:9]
Total liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000005:notes:10]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Accrued expenses | $ | 24.2 |  |  | $ | 25.1 |  |
| Other liabilities | 49.6 |  |  | 46.8 |  |
|  | $ | 73.8 |  |  | $ | 71.9 |  |

[0001069202-13-000005:notes:11]
The changes in total product warranty liabilities related to continuing operations for the three months ended March 31, 2013 were as follows (in millions):

[0001069202-13-000005:notes:12]
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (3.9 | ) |
| Changes resulting from issuance of new warranties | 6.1 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Changes in foreign currency translation rates and other | (0.3 | ) |
| Total warranty liability as of March 31, 2013 | $ | 73.8 |  |

[0001069202-13-000005:notes:13]
We evaluate our heating, ventilation and air conditioning ("HVAC") warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.

[0001069202-13-000005:notes:14]
We incur the risk of liability claims for the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material changes in the circumstances that affect our product warranties since our latest fiscal year-end.

[0001069202-13-000005:notes:15]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001069202-13-000005:notes:16]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the three months ended March 31, 2013 were as follows (in millions):

[0001069202-13-000005:notes:17]
| Total accrued product quality issue as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims | (0.6 | ) |
| Total accrued product quality issue as of March 31, 2013 | $ | 6.1 |  |

[0001069202-13-000005:notes:18]
Litigation

[0001069202-13-000005:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-13-000005:notes:20]
Some of these claims and lawsuits allege health problems resulting from exposure to asbestos and we expect that additional claims will be brought against us in the future. However, our liability exposure from those additional future claims cannot be estimated because of numerous uncertainties, including the number of such claims and lawsuits and the costs of defending and settling them, possible adverse judgments in amounts greater than previously experienced, and possible changes in the laws and process governing the compensation of asbestos claimants.  In the first quarter of 2013, we recorded charges of $0.6 million, net of insurance recoveries, related to asbestos matters in Selling, general and administrative expenses in the accompanying Consolidated Statement of Operation.

[0001069202-13-000005:notes:21]
We are also involved in patent litigation claims related to products from an acquired business.  The Company believes it has indemnification protection (with certain limitations) for these claims.

[0001069202-13-000005:notes:22]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-13-000005:notes:23]
Comprehensive Income:

[0001069202-13-000005:notes:24]
The following table provides information on items not reclassified in their entirety from AOCI to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-13-000005:notes:25]
| AOCI Component |  | For the three months ended March 31, 2013 |  | Affected Line Item in the Consolidated Statement of Operations |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |
| Commodity derivative contracts |  | $ | 0.4 |  |  | Cost of goods sold |
| Interest rate derivative contracts |  | — |  |  | Interest expense |
|  |  | $ | 0.4 |  |  | Total before tax |
|  |  | — |  |  | Income tax expense |
|  |  | $ | 0.4 |  |  | Net of tax |
| Foreign currency translation adjustments: |  |  |  |  |
| Sale of foreign business (1) |  | $ | 41.1 |  |  | Loss from discontinued operations |
| Total reclassifications from AOCI |  | $ | 41.5 |  |  |  |

[0001069202-13-000005:notes:26]
(1) The reclassification of foreign currency translation adjustments relates to the sale of the Service Experts business.  Refer to Note 13 for details.

[0001069202-13-000005:notes:27]
The following table provides information on changes in AOCI by component (net of tax) for the three months ended March 31, 2013 (in millions):

[0001069202-13-000005:notes:28]
|  |  | Gains / (Losses) on Cash Flow Hedges |  | Unrealized Gains / (Losses) on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total |
| Balance as of December 31, 2012 |  | $ | 1.1 |  |  | $ | 9.3 |  |  | $ | (147.5 | ) |  | $ | 114.8 |  |  | $ | (22.3 | ) |
| Other comprehensive income/(loss) before reclassifications |  | (3.0 | ) |  | (1.5 | ) |  | 0.7 |  |  | (4.0 | ) |  | (7.8 | ) |
| Amounts reclassified from AOCI |  | (0.4 | ) |  | — |  |  | — |  |  | (41.1 | ) |  | (41.5 | ) |
| Net other comprehensive income/(loss) |  | (3.4 | ) |  | (1.5 | ) |  | 0.7 |  |  | (45.1 | ) |  | (49.3 | ) |
| Balance as of March 31, 2013 |  | $ | (2.3 | ) |  | $ | 7.8 |  |  | $ | (146.8 | ) |  | $ | 69.7 |  |  | $ | (71.6 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001069202-13-000005:notes:29]
Lines of Credit and Financing Arrangements:

[0001069202-13-000005:notes:30]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000005:notes:31]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 20.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 6.0 |  |  | 4.9 |  |
| Total short-term debt | $ | 26.0 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.6 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 274.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 489.8 |  |  | $ | 351.0 |  |
| Total debt | $ | 516.4 |  |  | $ | 386.6 |  |

[0001069202-13-000005:notes:32]
Short-Term Debt

[0001069202-13-000005:notes:33]
Foreign Obligations

[0001069202-13-000005:notes:34]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $6.0 million and $4.9 million of foreign obligations as of March 31, 2013 and December 31, 2012, respectively, that are primarily borrowings under non-committed facilities.

[0001069202-13-000005:notes:35]
Asset Securitization Program

[0001069202-13-000005:notes:36]
Under the Receivables Purchase Agreement, or Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.

[0001069202-13-000005:notes:37]
The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-13-000005:notes:38]
The ASP provides for a maximum securitization amount of the lesser of $160.0 million or 100% of the net pool balance as defined by the ASP.  However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-13-000005:notes:39]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 20.0 |  |  | 30.0 |  |
| Remaining amount available | $ | 140.0 |  |  | $ | 130.0 |  |

[0001069202-13-000005:notes:40]
Under the ASP, we pay certain discount fees to use the program and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates for March 31, 2013 and for December 31, 2012 were 0.84% and 0.85%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):

[0001069202-13-000005:notes:41]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.3 |  |

[0001069202-13-000005:notes:42]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2013, we were in compliance with all covenant requirements.

[0001069202-13-000005:notes:43]
Long-Term Debt

[0001069202-13-000005:notes:44]
Domestic Revolving Credit Facility

[0001069202-13-000005:notes:45]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $274.0 million and $49.9 million committed to standby letters of credit as of March 31, 2013. Subject to covenant limitations, $326.1 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-13-000005:notes:46]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-13-000005:notes:47]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.20 | % |  | 1.46 | % |

[0001069202-13-000005:notes:48]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-13-000005:notes:49]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-13-000005:notes:50]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our revolving credit facility could occur if:

[0001069202-13-000005:notes:51]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-13-000005:notes:52]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-13-000005:notes:53]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-13-000005:notes:54]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2013, we were in compliance with all covenant requirements.

[0001069202-13-000005:notes:55]
Senior Unsecured Notes

[0001069202-13-000005:notes:56]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

[0001069202-13-000005:notes:57]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.   As of March 31, 2013, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-13-000005:notes:58]
[same as prior period, unchanged from 0001069202-12-000005:notes:46]

[0001069202-13-000005:notes:59]
[same as prior period, unchanged from 0001069202-12-000005:notes:47]

[0001069202-13-000005:notes:60]
[same as prior period, unchanged from 0001069202-12-000005:notes:48]

[0001069202-13-000005:notes:61]
We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes. The hedging program includes the use of futures contracts, which we enter into using a dollar cost average hedging strategy.  As part of this strategy, a higher percentage of commodity price exposures are hedged near term with lower percentages hedged at future dates. This strategy provides us with protection against near-term price volatility while allowing us to adjust to market price movements over time. Using futures contracts, we lock in prices and are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.

[0001069202-13-000005:notes:62]
[same as prior period, unchanged from 0001069202-12-000005:notes:50]

[0001069202-13-000005:notes:63]
A portion of our debt bears interest at variable interest rates, and therefore, we are subject to variability in the cash paid for interest. In order to mitigate a portion of the risk, we may choose from time to time to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows.

[0001069202-13-000005:notes:64]
Prior to 2013, we used an interest rate swap hedge to fix the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the benchmark interest rate.  The variable portion of the interest rate swap was tied to the 1-Month LIBOR (the benchmark interest rate). On a monthly basis, the interest rates for both the interest rate swap and the underlying debt were reset, the swap was settled with the counterparty, and the interest was paid.  The interest rate swap was classified as a cash flow hedge.  That interest rate swap expired on October 12, 2012, and, subsequently, we were no longer hedged against interest rate risk.

[0001069202-13-000005:notes:65]
[same as prior period, unchanged from 0001069202-12-000005:notes:53]

[0001069202-13-000005:notes:66]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. We seek to mitigate the impact of short-term currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts that act as economic hedges against changes in foreign currency exchange rates. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them. By entering into these forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-13-000005:notes:67]
[same as prior period, unchanged from 0001069202-12-000005:notes:55]

[0001069202-13-000005:notes:68]
We include gains or losses in accumulated other comprehensive income (“AOCI”) in connection with our commodity cash flow hedges. The gains or losses in AOCI related to commodity price hedges are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.  Assuming that commodity prices remain constant, we expect to reclassify $1.9 million of derivative losses into earnings within the next 12 months. Commodity futures contracts that are designated as cash flow hedges and that are in place as of March 31, 2013 are scheduled to mature through September 2014.

[0001069202-13-000005:notes:69]
[same as prior period, unchanged from 0001069202-12-000005:notes:58]

[0001069202-13-000005:notes:70]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Commodity Price Hedges: |  |  |  |
| Losses (gains) included in AOCI, net of tax | $ | 2.3 |  |  | $ | (1.1 | ) |
| Expense for (benefit from) income taxes | (1.3 | ) |  | 0.7 |  |

[0001069202-13-000005:notes:71]
[same as prior period, unchanged from 0001069202-12-000005:notes:60]

[0001069202-13-000005:notes:72]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
|  | (pounds) |  | (pounds) |
| Copper | 24.4 |  |  | 22.8 |  |

[0001069202-13-000005:notes:73]
[same as prior period, unchanged from 0001069202-12-000005:notes:62]

[0001069202-13-000005:notes:74]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges, except that we elect not to designate these derivatives as cash flow hedges at the inception of the arrangement. We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions):

[0001069202-13-000005:notes:75]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
|  | (pounds) |  | (pounds) |
| Copper | 2.4 |  |  | 2.1 |  |
| Aluminum | 2.7 |  |  | 2.8 |  |

[0001069202-13-000005:notes:76]
[same as prior period, unchanged from 0001069202-12-000005:notes:65]

[0001069202-13-000005:notes:77]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Notional Amounts: |  |  |  |
| Brazilian Real | 6.0 |  |  | 10.8 |  |
| Mexican Peso | 260.2 |  |  | 220.2 |  |
| Euro | — |  |  | 1.3 |  |
| British Pound | 2.4 |  |  | 5.4 |  |
| Indian Rupee | 265.0 |  |  | 19.5 |  |
| Polish Zloty | 18.0 |  |  | 12.4 |  |

[0001069202-13-000005:notes:78]
Information About the Locations and Amounts of Derivative Instruments

[0001069202-13-000005:notes:79]
The following tables provide the locations and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of Operations (in millions):

[0001069202-13-000005:notes:80]
|  | Fair Values of Derivative Instruments(1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | As of March 31, 2013 |  | As of December 31, 2012 |  | As of March 31, 2013 |  | As of December 31, 2012 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 1.6 |  |  | $ | — |  |  | $ | 0.2 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.4 |  |  | 0.1 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Total Assets | $ | — |  |  | $ | 1.9 |  |  | $ | 0.4 |  |  | $ | 0.3 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 3.1 |  |  | $ | — |  |  | $ | 0.5 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.8 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total Liabilities | $ | 3.9 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 0.1 |  |

[0001069202-13-000005:notes:81]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 16 for more information.

[0001069202-13-000005:notes:82]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Amount of Loss (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |
| Commodity futures contracts(1) | $ | (0.4 | ) |  | $ | 1.9 |  |
| Interest rate swap(2) | — |  |  | 0.6 |  |
|  | $ | (0.4 | ) |  | $ | 2.5 |  |
| Amount of Loss (Gain) Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |
| Commodity futures contracts(3) | $ | 0.2 |  |  | $ | (0.1 | ) |

[0001069202-13-000005:notes:83]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Amount of Loss (Gain) Recognized in Income on Derivatives: |  |  |  |
| Commodity futures contracts(3) | $ | 0.8 |  |  | $ | (1.3 | ) |
| Foreign currency forward contracts(3) | (0.5 | ) |  | — |  |
|  | $ | 0.3 |  |  | $ | (1.3 | ) |

[0001069202-13-000005:notes:84]
(1) The loss (gain) was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-13-000005:notes:85]
(2) The loss was recorded in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-13-000005:notes:86]
(3) The loss (gain) was recorded in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-13-000005:notes:87]
[same as prior period, unchanged from 0001069202-12-000005:notes:76]

[0001069202-13-000005:notes:88]
The Lennox International Inc. 2010 Incentive Plan, as amended and restated, provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights. Stock-based compensation expense related to continuing operations is included in Selling, General and Administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-13-000005:notes:89]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Compensation expense(1) | $ | 7.7 |  |  | $ | 4.3 |  |

[0001069202-13-000005:notes:90]
(1) Stock-Based Compensation expense is recorded in our Corporate and other business segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-13-000005:notes:91]
[same as prior period, unchanged from 0001069202-12-000005:notes:80]

[0001069202-13-000005:notes:92]
Service Experts

[0001069202-13-000005:notes:93]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer"), in an all cash transaction, for proceeds of $10.4 million.  The proceeds include a determinable working capital adjustment of $3.8 million to be received in the second quarter of 2013 and exclude transaction costs.

[0001069202-13-000005:notes:94]
A summary of net trade sales, pre-tax operating losses and other supplemental information for our Service Experts business is detailed below (in millions):

[0001069202-13-000005:notes:95]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Net trade sales(1) | $ | 73.5 |  |  | $ | 81.9 |  |
| Pre-tax operating income (loss) (1)(2) | (15.1 | ) |  | (14.3 | ) |
| Gain on sale of business | 1.7 |  |  | — |  |

[0001069202-13-000005:notes:96]
(1) Excludes eliminations of intercompany sales and any associated profit.

[0001069202-13-000005:notes:97]
(2) Pre-tax operating loss for the three months ended March 31, 2013 includes $2.3 million in retention bonus and severance costs and $0.2 million in stock-based compensation expense.

[0001069202-13-000005:notes:98]
The assets and liabilities of the Service Experts business include the following in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000005:notes:99]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Assets of discontinued operations: |  |  |  |
| Accounts receivable, net | $ | — |  |  | $ | 11.2 |  |
| Inventories, net | — |  |  | 4.8 |  |
| Property, plant and equipment, net | — |  |  | 3.6 |  |
| Goodwill and intangible assets, net (1) | — |  |  | 66.2 |  |
| Deferred income taxes | — |  |  | 5.5 |  |
| Other assets | — |  |  | 7.3 |  |
| Liabilities of discontinued operations: |  |  |  |
| Accounts payable | $ | — |  |  | $ | 16.7 |  |
| Accrued expenses | — |  |  | 38.5 |  |

[0001069202-13-000005:notes:100]
(1) Goodwill was $66.0 million as of December 31, 2012 and included accumulated impairment charges of $228.5 million, of which $208.0 million was from years prior to 2012 and $20.5 million was from 2012.  No impairments were recorded in 2013, and all goodwill was eliminated on March 22, 2013 as a result of the sale of the business.

[0001069202-13-000005:notes:101]
Hearth

[0001069202-13-000005:notes:102]
In April 2012, the Company sold its Hearth business to Comvest Investment Partners IV, in an all cash transaction, for net proceeds of $10.1 million, excluding the transaction costs and cash transferred with the business.

[0001069202-13-000005:notes:103]
[same as prior period, unchanged from 0001069202-12-000005:notes:89]

[0001069202-13-000005:notes:104]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Net trade sales | $ | — |  |  | $ | 18.6 |  |
| Pre-tax operating income (loss)(1) | 0.1 |  |  | (8.5 | ) |

[0001069202-13-000005:notes:105]
| (1) | Pre-tax operating loss includes a $6.3 million first quarter 2012 pre-tax charge for the write-down of net assets to their estimated fair value. |

[0001069202-13-000005:notes:106]
There were no assets and liabilities related to the Hearth business included in the accompanying Consolidated Balance Sheets as of March 31, 2013 or December 31, 2012.


## us-gaap:EarningsPerShareTextBlock

[0001069202-13-000005:notes:107]
Earnings (Loss) Per Share:

[0001069202-13-000005:notes:108]
[same as prior period, unchanged from 0001069202-12-000005:notes:95]

[0001069202-13-000005:notes:109]
The computations of basic and diluted earnings per share for Net Income (Loss) were as follows (in millions, except per share data):

[0001069202-13-000005:notes:110]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Net income (loss) | $ | 8.0 |  |  | $ | (6.1 | ) |
| Add: Loss from discontinued operations | 7.8 |  |  | 15.4 |  |
| Income from continuing operations | $ | 15.8 |  |  | $ | 9.3 |  |
| Weighted-average shares outstanding – basic | 50.3 |  |  | 50.9 |  |
| Effect of diluted securities attributable to stock-based payments | 0.7 |  |  | — |  |
| Weighted-average shares outstanding – diluted | 51.0 |  |  | 50.9 |  |
| Earnings per share – Basic: |  |  |  |
| Income from continuing operations | $ | 0.32 |  |  | $ | 0.18 |  |
| Loss from discontinued operations | (0.16 | ) |  | (0.30 | ) |
| Net income (loss) | $ | 0.16 |  |  | $ | (0.12 | ) |
| Earnings per share – Diluted: |  |  |  |
| Income from continuing operations | $ | 0.31 |  |  | $ | 0.18 |  |
| Loss from discontinued operations | (0.15 | ) |  | (0.30 | ) |
| Net income (loss) | $ | 0.16 |  |  | $ | (0.12 | ) |

[0001069202-13-000005:notes:111]
Not included in the 2012 computation of diluted loss per share were 0.6 million shares of potentially dilutive securities, including performance share units, restricted stock units and stock appreciation rights.  These shares would be anti-dilutive due to the loss position for the period.  Additionally, the following stock appreciation rights were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive (in millions, except for per share data):

[0001069202-13-000005:notes:112]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Weighted-average number of shares | 0.4 |  |  | 1.1 |  |
| Price ranges per share | $51.11 - $51.40 |  |  | $34.06 - $46.78 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-13-000005:notes:113]
The estimated fair values of our Senior unsecured notes were as follows (in millions):

[0001069202-13-000005:notes:114]
|  | Quoted Prices in Active Markets forSimilar Instruments (Level 2) |
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Senior unsecured notes | $ | 213.6 |  |  | $ | 212.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-13-000005:notes:115]
[same as prior period, unchanged from 0001069202-12-000005:notes:102]

[0001069202-13-000005:notes:116]
Assets Measured at Fair Value on a Recurring Basis

[0001069202-13-000005:notes:117]
The following table presents the fair value hierarchy for those assets measured at fair value on a recurring basis (in millions):

[0001069202-13-000005:notes:118]
|  | Quoted Prices in Active Markets forIdentical Assets (Level 1) |
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Investment in marketable equity securities (1) | $ | 9.5 |  |  | $ | 10.6 |  |

[0001069202-13-000005:notes:119]
| (1) | Investment in marketable equity securities is recorded in Other assets, net in the accompanying Consolidated Balance Sheets. |

[0001069202-13-000005:notes:120]
[same as prior period, unchanged from 0001069202-12-000005:notes:107]

[0001069202-13-000005:notes:121]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net, accounts payable, other current liabilities, and short-term debt approximate fair value due to the short maturities of these instruments. The carrying amount of our Domestic Revolving Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.  The fair values of our Senior unsecured notes in Long-term debt are based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk. The fair values presented are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently or indicative of our intent or ability to dispose of or liquidate them.    The estimated fair values of our Senior unsecured notes were as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-13-000005:notes:122]
[same as prior period, unchanged from 0001069202-12-000005:notes:109]

[0001069202-13-000005:notes:123]
The changes in the carrying amount of goodwill for the first three months of 2013, in total and by segment, are summarized in the table below (in millions):

[0001069202-13-000005:notes:124]
|  | Balance at December 31, 2012 |  |  |  |  |  | Balance at March 31, 2013 |
| Segment: | Goodwill (1) |  | Acquisitions / (Dispositions) |  | Other(2) |  | Goodwill |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 63.8 |  |  | — |  |  | (0.5 | ) |  | 63.3 |  |
| Refrigeration | 133.9 |  |  | — |  |  | 0.1 |  |  | 134.0 |  |
|  | $ | 223.8 |  |  | $ | — |  |  | $ | (0.4 | ) |  | $ | 223.4 |  |

[0001069202-13-000005:notes:125]
(1)  The Goodwill balances presented in the table above are presented net of accumulated impairment charges of $17.0 million, all of which relate to impairments in periods prior to 2012.

[0001069202-13-000005:notes:126]
(2)  Other consists of changes in foreign currency translation rates.

[0001069202-13-000005:notes:127]
We performed our annual goodwill impairment test in the first quarter of 2013.  Based on our qualitative assessment, as of the date of our impairment test, we believe it is more likely than not the fair values of our reporting units exceed their carrying values.  Therefore, a quantitative impairment test was not performed and we did not recognize any goodwill impairments for our reporting units.  We will continue to monitor our reporting units throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.

[0001069202-13-000005:notes:128]
Refer to Note 13 for information on goodwill related to discontinued operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-13-000005:notes:129]
[same as prior period, unchanged from 0001069202-12-000005:notes:119]

[0001069202-13-000005:notes:130]
As of March 31, 2013, we had approximately $1.1 million in total gross unrecognized tax benefits. Of this amount, $0.8 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of March 31, 2013, we recognized $0.1 million (net of federal tax benefits) in interest and penalties in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-13-000005:notes:131]
We are currently under examination for our U.S. federal income taxes for 2012 and 2013 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years before 2007.

[0001069202-13-000005:notes:132]
Since January 1, 2013, numerous states, including New Mexico, enacted legislation effective for tax years beginning on or after January 1, 2013, including changes to rates.  The impact of these changes is immaterial.

[0001069202-13-000005:notes:133]
On January 2, 2013, the American Taxpayer Relief Act of 2012 was enacted which retroactively reinstated and extended the Federal Research and Development Tax Credit (Federal R&D Tax Credit) from January 1, 2012 to December 31, 2013, in addition to other extenders.  As a result, the Company's income tax provision for the first quarter of calendar year 2013 includes a discrete tax benefit that will reduce the annual effective income tax rate.  On a full year basis, the impact to the annual effective income tax rate is not expected to be material.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-13-000005:notes:134]
[same as prior period, unchanged from 0001069202-12-000005:notes:123]

[0001069202-13-000005:notes:135]
[same as prior period, unchanged from 0001069202-12-000005:notes:124]

[0001069202-13-000005:notes:136]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Finished goods | $ | 335.1 |  |  | $ | 258.0 |  |
| Work in process | 13.5 |  |  | 12.0 |  |
| Raw materials and parts | 191.2 |  |  | 180.1 |  |
|  | 539.8 |  |  | 450.1 |  |
| Excess of current cost over last-in, first-out cost | (75.5 | ) |  | (75.3 | ) |
| Total inventories, net | $ | 464.3 |  |  | $ | 374.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-13-000005:notes:137]
[same as prior period, unchanged from 0001069202-12-000005:notes:126]

[0001069202-13-000005:notes:138]
References in this Quarterly Report on Form 10-Q to "we," "our," "us," "LII," or the "Company" refer to Lennox International Inc. and its subsidiaries, unless the context requires otherwise.

[0001069202-13-000005:notes:139]
[same as prior period, unchanged from 0001069202-12-000005:notes:128]

[0001069202-13-000005:notes:140]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-13-000005:notes:141]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency, and commodity markets combined to increase the uncertainty inherent in such estimates and assumptions.  As future events and their effects cannot be determined with precision, actual results could differ significantly from these estimates.  Changes in those estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-13-000005:notes:142]
[same as prior period, unchanged from 0001069202-12-000005:notes:131]

[0001069202-13-000005:notes:143]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-13-000005:notes:144]
Pension and Post-retirement Benefit Plans:

[0001069202-13-000005:notes:145]
[same as prior period, unchanged from 0001069202-12-000005:notes:134]

[0001069202-13-000005:notes:146]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | — |  |  | $ | 0.3 |  |
| Interest cost | 4.1 |  |  | 4.3 |  |  | 0.1 |  |  | 0.2 |  |
| Expected return on plan assets | (5.2 | ) |  | (4.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.8 | ) |  | (0.5 | ) |
| Recognized actuarial loss | 2.4 |  |  | 2.2 |  |  | 0.4 |  |  | 0.3 |  |
| Settlements and curtailments | 0.5 |  |  | — |  |  |  |  |  |  |  |
| Net periodic benefit cost(1) | $ | 3.2 |  |  | $ | 3.3 |  |  | $ | (0.3 | ) |  | $ | 0.3 |  |

[0001069202-13-000005:notes:147]
(1) All net periodic benefit cost for the three months ended March 31, 2013 and 2012 related to continuing operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-13-000005:notes:148]
[same as prior period, unchanged from 0001069202-12-000005:notes:140]

[0001069202-13-000005:notes:149]
As part of the efforts to achieve our strategic priorities of manufacturing and sourcing excellence and expense reduction, we initiated various rationalization actions designed to lower our cost structure.  As more fully explained in Note 15, restructuring charges are not included in our calculation of segment profit (loss).

[0001069202-13-000005:notes:150]
Detailed below is the description of our significant ongoing restructuring action and its related activity in 2013.

[0001069202-13-000005:notes:151]
[same as prior period, unchanged from 0001069202-12-000005:notes:146]

[0001069202-13-000005:notes:152]
In the fourth quarter of 2008, we commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa to other locations, including our North American Distribution Center in Marshalltown, Iowa. In the first quarter of 2013, we recorded expense of $0.2 million and we expect to incur an additional $0.6 million in future costs related to this restructuring activity.  As of March 31, 2013, we have incurred $6.5 million in costs related to this restructuring activity.

[0001069202-13-000005:notes:153]
[same as prior period, unchanged from 0001069202-12-000005:notes:148]

[0001069202-13-000005:notes:154]
Restructuring charges can include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, lease termination costs and other related costs. Restructuring charges are generally recorded based on planned employee termination dates and site closure and consolidation plans. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.

[0001069202-13-000005:notes:155]
Information regarding the restructuring charges for all ongoing plans related to continuing operations is as follows (in millions):

[0001069202-13-000005:notes:156]
|  | Charges Incurred in 2013 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 0.2 |  |  | $ | 11.3 |  |  | $ | 11.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 1.0 |  |  | 1.0 |  |
| Equipment moves | — |  |  | 0.3 |  |  | 0.3 |  |
| Lease termination | — |  |  | 2.6 |  |  | 2.6 |  |
| Other | 0.3 |  |  | 5.9 |  |  | 6.5 |  |
| Total | $ | 0.5 |  |  | $ | 21.1 |  |  | $ | 21.8 |  |

[0001069202-13-000005:notes:157]
[same as prior period, unchanged from 0001069202-12-000005:notes:151]

[0001069202-13-000005:notes:158]
|  | Charges Incurred in 2013 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.2 |  |  | $ | 6.5 |  |  | $ | 7.1 |  |
| Commercial Heating & Cooling | — |  |  | 7.8 |  |  | 7.8 |  |
| Refrigeration | 0.3 |  |  | 6.8 |  |  | 6.9 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total | $ | 0.5 |  |  | $ | 21.1 |  |  | $ | 21.8 |  |

[0001069202-13-000005:notes:159]
Restructuring reserves related to continuing operations are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below details activity within the restructuring reserves (in millions):

[0001069202-13-000005:notes:160]
| Description of Reserves | Balance as ofDecember 31, 2012 |  | ChargedtoEarnings |  | CashUtilization |  | Non-CashUtilizationand Other |  | Balance as ofMarch 31, 2013 |
| Severance and related expense | $ | 0.7 |  |  | $ | 0.2 |  |  | $ | (0.5 | ) |  | $ | — |  |  | $ | 0.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | 1.2 |  |  | — |  |  | (1.2 | ) |  | — |  |  | — |  |
| Other | 0.5 |  |  | 0.3 |  |  | (0.2 | ) |  | (0.1 | ) |  | 0.5 |  |
| Total restructuring reserves | $ | 2.4 |  |  | $ | 0.5 |  |  | $ | (1.9 | ) |  | $ | (0.1 | ) |  | $ | 0.9 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-13-000005:notes:161]
[same as prior period, unchanged from 0001069202-12-000005:notes:157]

[0001069202-13-000005:notes:162]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Net Sales |  |  |  |
| Residential Heating & Cooling | $ | 314.5 |  |  | $ | 272.6 |  |
| Commercial Heating & Cooling | 163.0 |  |  | 156.7 |  |
| Refrigeration | 190.9 |  |  | 185.1 |  |
|  | $ | 668.4 |  |  | $ | 614.4 |  |
| Segment Profit (Loss) (1) |  |  |  |
| Residential Heating & Cooling | $ | 20.5 |  |  | $ | 11.0 |  |
| Commercial Heating & Cooling | 11.1 |  |  | 8.3 |  |
| Refrigeration | 16.7 |  |  | 14.2 |  |
| Corporate and other | (18.9 | ) |  | (13.9 | ) |
| Subtotal that includes segment profit and eliminations | 29.4 |  |  | 19.6 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |
| Special product quality adjustment | (0.2 | ) |  | (0.4 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss)(2) | 1.3 |  |  | (1.5 | ) |
| Restructuring charges | 0.5 |  |  | 2.6 |  |
| Interest expense, net | 3.4 |  |  | 4.7 |  |
| Other expense, net | — |  |  | — |  |
| Income from continuing operations before income taxes | $ | 24.4 |  |  | $ | 14.2 |  |

[0001069202-13-000005:notes:163]
(1) We define segment profit and loss as a segment's income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding the following:

[0001069202-13-000005:notes:164]
| • | Special product quality adjustments; |

[0001069202-13-000005:notes:165]
| • | Items in Losses (gains) and other expenses, net (see table note 2 below); |

[0001069202-13-000005:notes:166]
| • | Restructuring charges; |

[0001069202-13-000005:notes:167]
| • | Goodwill, long-lived asset, and equity method investment impairments; |

[0001069202-13-000005:notes:168]
| • | Interest expense, net; |

[0001069202-13-000005:notes:169]
| • | Other expense, net. |

[0001069202-13-000005:notes:170]
(2) Items in Losses (gains) and other expenses, net that are excluded from segment profit include the following:  asset impairment, net change in unrealized gains and/or losses on open futures contracts, special legal contingency charge, and other items.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-13-000005:notes:171]
[same as prior period, unchanged from 0001069202-12-000005:notes:160]

[0001069202-13-000005:notes:172]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our segments are organized primarily by the nature of the products and services we provide.

[0001069202-13-000005:notes:173]
In March 2013, we sold our Service Experts business to a majority-owned entity of American Capital, Ltd.  The Service Experts business had previously been reported within our Service Experts segment along with a commercial service business called Lennox National Account Services (NAS).  Beginning in the third quarter of 2012, the Service Experts business was included in discontinued operations, NAS was included in our Commercial Heating & Cooling segment, and the Service Experts reportable segment was eliminated. Segment results for all periods have been revised to conform to this new presentation.

[0001069202-13-000005:notes:174]
[same as prior period, unchanged from 0001069202-12-000005:notes:162]

[0001069202-13-000005:notes:175]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |

[0001069202-13-000005:notes:176]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources. We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation below details the items excluded.

[0001069202-13-000005:notes:177]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII. We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-13-000005:notes:178]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results. There were no significant intercompany eliminations included in the results presented in the table below.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-13-000005:notes:179]
[same as prior period, unchanged from 0001069202-12-000005:notes:167]

[0001069202-13-000005:notes:180]
In 2008, our Board of Directors approved a $300.0 million share repurchase plan, with no stated expiration date, authorizing the repurchase of shares of our common stock through open market purchases (the “2008 Share Repurchase Plan”).  In December 2011, our Board of Directors increased the authorized amount of shares that could be repurchased under the 2008 Share Repurchase Plan by $100.0 million to $400.0 million.  During the first three months of 2013, no shares were purchased under this plan and as of March 31, 2013, $71.2 million of shares may yet be purchased.

[0001069202-13-000005:notes:181]
In December 2012, our Board of Directors approved a $300.0 million share repurchase plan, with no stated expiration date,  authorizing the repurchase of shares of our common stock through open market purchases (the "2012 Share Repurchase Plan").  As of March 31, 2013, no shares were repurchased under this plan.


## lii:CondensedConsolidatingFinancialStatementsTableTextBlock

[0001069202-13-000005:notes:182]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of March 31, 2013 and December 31, 2012 and for the three months ended March 31, 2013 and 2012 are shown on the following pages:

[0001069202-13-000005:notes:183]
Lennox International Inc. and Subsidiaries

[0001069202-13-000005:notes:184]
[same as prior period, unchanged from 0001069202-12-000005:notes:170]

[0001069202-13-000005:notes:185]
As of March 31, 2013

[0001069202-13-000005:notes:186]
[same as prior period, unchanged from 0001069202-12-000005:notes:172]

[0001069202-13-000005:notes:187]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 14.0 |  |  | $ | 20.9 |  |  | $ | — |  |  | $ | 34.9 |  |
| Accounts and notes receivable, net | (990.1 | ) |  | 873.3 |  |  | 471.1 |  |  | 52.7 |  |  | 407.0 |  |
| Inventories, net | — |  |  | 340.2 |  |  | 129.7 |  |  | (5.6 | ) |  | 464.3 |  |
| Deferred income taxes, net | 2.2 |  |  | 23.0 |  |  | 6.2 |  |  | (1.7 | ) |  | 29.7 |  |
| Other assets | (14.5 | ) |  | 26.3 |  |  | 113.2 |  |  | (56.8 | ) |  | 68.2 |  |
| Assets of discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total current assets | (1,002.4 | ) |  | 1,276.8 |  |  | 741.1 |  |  | (11.4 | ) |  | 1,004.1 |  |
| Property, plant and equipment, net | — |  |  | 235.5 |  |  | 59.6 |  |  | — |  |  | 295.1 |  |
| Goodwill | — |  |  | 131.8 |  |  | 91.6 |  |  | — |  |  | 223.4 |  |
| Deferred income taxes | 0.9 |  |  | 94.2 |  |  | 20.6 |  |  | (5.8 | ) |  | 109.9 |  |
| Other assets, net(1) | 2,190.2 |  |  | 534.8 |  |  | 27.8 |  |  | (2,671.2 | ) |  | 81.6 |  |
| Total assets | $ | 1,188.7 |  |  | $ | 2,273.1 |  |  | $ | 940.7 |  |  | $ | (2,688.4 | ) |  | $ | 1,714.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 86.5 |  |  | $ | — |  |  | $ | (60.3 | ) |  | $ | (0.2 | ) |  | $ | 26.0 |  |
| Current maturities of long-term debt | — |  |  | 0.4 |  |  | 0.2 |  |  | — |  |  | 0.6 |  |
| Accounts payable | 13.4 |  |  | 152.8 |  |  | 82.8 |  |  | 63.4 |  |  | 312.4 |  |
| Accrued expenses | 8.4 |  |  | 155.9 |  |  | 58.6 |  |  | (0.3 | ) |  | 222.6 |  |
| Income taxes payable | 2.6 |  |  | 4.5 |  |  | 49.5 |  |  | (55.8 | ) |  | 0.8 |  |
| Liabilities of discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total current liabilities | 110.9 |  |  | 313.6 |  |  | 130.8 |  |  | 7.1 |  |  | 562.4 |  |
| Long-term debt | 474.0 |  |  | 15.6 |  |  | 99.4 |  |  | (99.2 | ) |  | 489.8 |  |
| Post-retirement benefits, other than pensions | — |  |  | 5.8 |  |  | — |  |  | — |  |  | 5.8 |  |
| Pensions | — |  |  | 117.3 |  |  | 18.4 |  |  | — |  |  | 135.7 |  |
| Other liabilities | 1.3 |  |  | 63.9 |  |  | 10.4 |  |  | (7.2 | ) |  | 68.4 |  |
| Total liabilities | 586.2 |  |  | 516.2 |  |  | 259.0 |  |  | (99.3 | ) |  | 1,262.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 602.5 |  |  | 1,756.9 |  |  | 681.7 |  |  | (2,589.1 | ) |  | 452.0 |  |
| Total liabilities and stockholders' equity | $ | 1,188.7 |  |  | $ | 2,273.1 |  |  | $ | 940.7 |  |  | $ | (2,688.4 | ) |  | $ | 1,714.1 |  |

[0001069202-13-000005:notes:188]
| (1) | Other assets, net consists primarily of Investments in subsidiaries which eliminate upon consolidation. |

[0001069202-13-000005:notes:189]
As of December 31, 2012

[0001069202-13-000005:notes:190]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 13.4 |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net | (1,178.0 | ) |  | 1,076.0 |  |  | 427.2 |  |  | 48.2 |  |  | 373.4 |  |
| Inventories, net | — |  |  | 257.3 |  |  | 121.5 |  |  | (4.0 | ) |  | 374.8 |  |
| Deferred income taxes, net | — |  |  | 22.9 |  |  | 6.3 |  |  | (1.7 | ) |  | 27.5 |  |
| Other assets | (0.6 | ) |  | 23.8 |  |  | 97.5 |  |  | (59.7 | ) |  | 61.0 |  |
| Assets of discontinued operations | — |  |  | 21.2 |  |  | 77.4 |  |  | — |  |  | 98.6 |  |
| Total current assets | (1,177.6 | ) |  | 1,414.6 |  |  | 767.3 |  |  | (17.2 | ) |  | 987.1 |  |
| Property, plant and equipment, net | — |  |  | 239.7 |  |  | 58.5 |  |  | — |  |  | 298.2 |  |
| Goodwill | — |  |  | 131.8 |  |  | 92.0 |  |  | — |  |  | 223.8 |  |
| Deferred income taxes | — |  |  | 87.8 |  |  | 20.8 |  |  | (5.8 | ) |  | 102.8 |  |
| Other assets, net(1) | 2,176.3 |  |  | 488.5 |  |  | 30.3 |  |  | (2,615.1 | ) |  | 80.0 |  |
| Total assets | $ | 998.7 |  |  | $ | 2,362.4 |  |  | $ | 968.9 |  |  | $ | (2,638.1 | ) |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 101.9 |  |  | $ | — |  |  | $ | (51.0 | ) |  | $ | (16.0 | ) |  | $ | 34.9 |  |
| Current maturities of long-term debt | — |  |  | 0.5 |  |  | 0.2 |  |  | — |  |  | 0.7 |  |
| Accounts payable | — |  |  | 133.7 |  |  | 92.0 |  |  | 59.0 |  |  | 284.7 |  |
| Accrued expenses | 2.5 |  |  | 196.6 |  |  | 60.8 |  |  | (0.3 | ) |  | 259.6 |  |
| Income taxes payable | (27.3 | ) |  | 35.1 |  |  | 38.5 |  |  | (41.8 | ) |  | 4.5 |  |
| Liabilities of discontinued operations | — |  |  | 42.3 |  |  | 12.9 |  |  | — |  |  | 55.2 |  |
| Total current liabilities | 77.1 |  |  | 408.2 |  |  | 153.4 |  |  | 0.9 |  |  | 639.6 |  |
| Long-term debt | 335.0 |  |  | 15.6 |  |  | 98.7 |  |  | (98.3 | ) |  | 351.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 6.1 |  |  | — |  |  | — |  |  | 6.1 |  |
| Pensions | — |  |  | 114.7 |  |  | 19.7 |  |  | — |  |  | 134.4 |  |
| Other liabilities | 0.5 |  |  | 60.1 |  |  | 10.6 |  |  | (7.2 | ) |  | 64.0 |  |
| Total liabilities | 412.6 |  |  | 604.7 |  |  | 282.4 |  |  | (104.6 | ) |  | 1,195.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 586.1 |  |  | 1,757.7 |  |  | 686.5 |  |  | (2,533.5 | ) |  | 496.8 |  |
| Total liabilities and stockholders' equity | $ | 998.7 |  |  | $ | 2,362.4 |  |  | $ | 968.9 |  |  | $ | (2,638.1 | ) |  | $ | 1,691.9 |  |

[0001069202-13-000005:notes:191]
[same as prior period, unchanged from 0001069202-12-000005:notes:175]

[0001069202-13-000005:notes:192]
For the Three Months Ended March 31, 2013

[0001069202-13-000005:notes:193]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 520.7 |  |  | $ | 189.5 |  |  | $ | (41.8 | ) |  | $ | 668.4 |  |
| Cost of goods sold | — |  |  | 404.4 |  |  | 143.3 |  |  | (41.3 | ) |  | 506.4 |  |
| Gross profit | — |  |  | 116.3 |  |  | 46.2 |  |  | (0.5 | ) |  | 162.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 102.6 |  |  | 33.0 |  |  | — |  |  | 135.6 |  |
| Losses and other expenses, net | 0.4 |  |  | 0.4 |  |  | 0.3 |  |  | — |  |  | 1.1 |  |
| Restructuring charges | — |  |  | 0.3 |  |  | 0.2 |  |  | — |  |  | 0.5 |  |
| Income from equity method investments | (7.9 | ) |  | 2.5 |  |  | (2.8 | ) |  | 5.1 |  |  | (3.1 | ) |
| Operational income from continuing operations | 7.5 |  |  | 10.5 |  |  | 15.5 |  |  | (5.6 | ) |  | 27.9 |  |
| Interest expense, net | 3.3 |  |  | (0.5 | ) |  | 0.6 |  |  | — |  |  | 3.4 |  |
| Other expense, net | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from continuing operations before income taxes | 4.2 |  |  | 11.0 |  |  | 14.8 |  |  | (5.6 | ) |  | 24.4 |  |
| Provision for income taxes | (1.3 | ) |  | 4.8 |  |  | 5.3 |  |  | (0.2 | ) |  | 8.6 |  |
| Income from continuing operations | 5.5 |  |  | 6.2 |  |  | 9.5 |  |  | (5.4 | ) |  | 15.8 |  |
| Loss from discontinued operations | — |  |  | (7.8 | ) |  | — |  |  | — |  |  | (7.8 | ) |
| Net income | $ | 5.5 |  |  | $ | (1.6 | ) |  | $ | 9.5 |  |  | $ | (5.4 | ) |  | $ | 8.0 |  |
| Other comprehensive loss | $ | (3.4 | ) |  | $ | 0.8 |  |  | $ | (46.0 | ) |  | $ | (0.7 | ) |  | $ | (49.3 | ) |

[0001069202-13-000005:notes:194]
For the Three Months Ended March 31, 2012

[0001069202-13-000005:notes:195]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 472.0 |  |  | $ | 189.5 |  |  | $ | (47.1 | ) |  | $ | 614.4 |  |
| Cost of goods sold | — |  |  | 375.9 |  |  | 144.5 |  |  | (46.9 | ) |  | 473.5 |  |
| Gross profit | — |  |  | 96.1 |  |  | 45.0 |  |  | (0.2 | ) |  | 140.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 88.4 |  |  | 34.8 |  |  | — |  |  | 123.2 |  |
| Losses and other expenses, net | (1.6 | ) |  | (0.7 | ) |  | 0.9 |  |  | — |  |  | (1.4 | ) |
| Restructuring charges | — |  |  | 2.6 |  |  | — |  |  | — |  |  | 2.6 |  |
| Income from equity method investments | 6.8 |  |  | 2.1 |  |  | (1.9 | ) |  | (9.4 | ) |  | (2.4 | ) |
| Operational income from continuing operations | (5.2 | ) |  | 3.7 |  |  | 11.2 |  |  | 9.2 |  |  | 18.9 |  |
| Interest expense, net | 4.4 |  |  | (0.5 | ) |  | 0.8 |  |  | — |  |  | 4.7 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | (9.6 | ) |  | 4.2 |  |  | 10.4 |  |  | 9.2 |  |  | 14.2 |  |
| Provision for income taxes | (1.0 | ) |  | 2.6 |  |  | 2.8 |  |  | 0.5 |  |  | 4.9 |  |
| Income from continuing operations | (8.6 | ) |  | 1.6 |  |  | 7.6 |  |  | 8.7 |  |  | 9.3 |  |
| Loss from discontinued operations | — |  |  | (10.8 | ) |  | (4.6 | ) |  | — |  |  | (15.4 | ) |
| Net loss | $ | (8.6 | ) |  | $ | (9.2 | ) |  | $ | 3.0 |  |  | $ | 8.7 |  |  | $ | (6.1 | ) |
| Other comprehensive income | $ | 6.9 |  |  | $ | 2.7 |  |  | $ | 12.1 |  |  | $ | 0.7 |  |  | $ | 22.4 |  |

[0001069202-13-000005:notes:196]
[same as prior period, unchanged from 0001069202-12-000005:notes:186]

[0001069202-13-000005:notes:197]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 54.3 |  |  | $ | (168.3 | ) |  | $ | (23.3 | ) |  | $ | — |  |  | $ | (137.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Purchases of property, plant and equipment | — |  |  | (9.3 | ) |  | (2.8 | ) |  | — |  |  | (12.1 | ) |
| Net proceeds from sale of business | 2.0 |  |  | — |  |  | 3.3 |  |  | — |  |  | 5.3 |  |
| Net cash used in discontinued operations | — |  |  | (0.1 | ) |  | — |  |  | — |  |  | (0.1 | ) |
| Net cash used in investing activities | 2.0 |  |  | (9.4 | ) |  | 0.5 |  |  | — |  |  | (6.9 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.2 |  |  | — |  |  | 1.2 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 130.0 |  |  | — |  |  | 130.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (140.0 | ) |  | — |  |  | (140.0 | ) |
| Long-term debt payments | — |  |  | (0.2 | ) |  | — |  |  | — |  |  | (0.2 | ) |
| Borrowings from revolving credit facility | 435.5 |  |  | — |  |  | — |  |  | — |  |  | 435.5 |  |
| Payments on revolving credit facility | (296.5 | ) |  | — |  |  | — |  |  | — |  |  | (296.5 | ) |
| Proceeds from stock option exercises | 0.5 |  |  | — |  |  | — |  |  | — |  |  | 0.5 |  |
| Repurchases of common stock | (4.2 | ) |  | — |  |  | — |  |  | — |  |  | (4.2 | ) |
| Excess tax benefits related to share-based payments | 2.3 |  |  | — |  |  | — |  |  | — |  |  | 2.3 |  |
| Intercompany debt | (7.1 | ) |  | (0.7 | ) |  | 7.8 |  |  | — |  |  | — |  |
| Intercompany financing activity | (187.8 | ) |  | 179.2 |  |  | 8.6 |  |  | — |  |  | — |  |
| Cash dividends paid | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by financing activities | (57.3 | ) |  | 178.3 |  |  | 7.6 |  |  | — |  |  | 128.6 |  |
| Decrease in cash and cash equivalents | (1.0 | ) |  | 0.6 |  |  | (15.2 | ) |  | — |  |  | (15.6 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (1.3 | ) |  | — |  |  | (1.3 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of period | $ | — |  |  | $ | 14.0 |  |  | $ | 20.9 |  |  | $ | — |  |  | $ | 34.9 |  |

[0001069202-13-000005:notes:198]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 30.9 |  |  | $ | (71.5 | ) |  | $ | 6.3 |  |  | $ | — |  |  | $ | (34.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (5.5 | ) |  | (1.1 | ) |  | — |  |  | (6.6 | ) |
| Net proceeds from sale of business | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in discontinued operations | — |  |  | (0.3 | ) |  | — |  |  | — |  |  | (0.3 | ) |
| Net cash used in investing activities | — |  |  | (5.7 | ) |  | (1.1 | ) |  | — |  |  | (6.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 170.0 |  |  | — |  |  | 170.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (170.0 | ) |  | — |  |  | (170.0 | ) |
| Long-term debt payments | — |  |  | (0.2 | ) |  | — |  |  | — |  |  | (0.2 | ) |
| Borrowings from revolving credit facility | 267.5 |  |  | — |  |  | — |  |  | — |  |  | 267.5 |  |
| Payments on revolving credit facility | (215.5 | ) |  | — |  |  | — |  |  | — |  |  | (215.5 | ) |
| Proceeds from stock option exercises | 0.1 |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Payments of deferred financing costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Repurchases of common stock | (1.9 | ) |  | — |  |  | — |  |  | — |  |  | (1.9 | ) |
| Excess tax benefits related to share-based payments | 0.8 |  |  | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Intercompany debt | 8.5 |  |  | (2.2 | ) |  | (6.3 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (81.3 | ) |  | 86.8 |  |  | (5.5 | ) |  | — |  |  | — |  |
| Cash dividends paid | (9.2 | ) |  | — |  |  | — |  |  | — |  |  | (9.2 | ) |
| Net cash provided by financing activities | (31.0 | ) |  | 84.4 |  |  | (5.2 | ) |  | — |  |  | 48.2 |  |
| Increase in cash and cash equivalents | (0.1 | ) |  | 7.2 |  |  | — |  |  | — |  |  | 7.1 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 2.6 |  |  | — |  |  | 2.6 |  |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 9.7 |  |  | 34.3 |  |  | — |  |  | 45.0 |  |
| Cash and cash equivalents, end of period | $ | 0.9 |  |  | $ | 16.9 |  |  | $ | 36.9 |  |  | $ | — |  |  | $ | 54.7 |  |


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0001069202-13-000005:notes:199]
[same as prior period, unchanged from 0001069202-12-000005:notes:189]

[0001069202-13-000005:notes:200]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-13-000005:notes:201]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001069202-13-000005:notes:202]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd.  The primary subsidiary for the U.S. Service Experts business had previously been included as a "Guarantor Subsidiary" and the Canada Service Experts subsidiary had previously been included as a "Non-Guarantor Subsidiary."  As of March 31, 2013, the U.S. and Canada Service Experts businesses are included in discontinued operations of the condensed consolidating financial statements.

[0001069202-13-000005:notes:203]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  Intercompany account balances have been included in Accounts and notes receivable, Other assets (Current), Other assets, net, Short-term debt, Accounts payable, and Long-term debt line items of the Parent, Guarantor and Non-Guarantor balance sheets. The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.
