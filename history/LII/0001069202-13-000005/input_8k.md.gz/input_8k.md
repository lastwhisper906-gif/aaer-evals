# LII 8-K — 0001193125-13-163938 filed 2013-04-22

## item codes, every 8-K on or before 2013-04-22

- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2013-04-22

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-13-163938:8k_2_02:1]
EX-99.1
2
d523315dex991.htm
EX-99.1

[0001193125-13-163938:8k_2_02:2]
EX-99.1

[0001193125-13-163938:8k_2_02:3]
Exhibit 99.1

[0001193125-13-163938:8k_2_02:4]
Lennox International Reports First Quarter Results

[0001193125-13-163938:8k_2_02:5]
| • |  | Revenue up 9%, led by 15% growth in Residential |

[0001193125-13-163938:8k_2_02:6]
| • |  | Adjusted EPS from continuing operations of $0.33, up 74% |

[0001193125-13-163938:8k_2_02:7]
| • |  | GAAP EPS from continuing operations of $0.31, up 72% |

[0001193125-13-163938:8k_2_02:8]
| • |  | Narrowing 2013 revenue growth guidance range from 2-6% to 3-6% |

[0001193125-13-163938:8k_2_02:9]
| • |  | Narrowing 2013 adjusted EPS from continuing operations guidance from $3.15-$3.55 to a range of $3.25-$3.55 |

[0001193125-13-163938:8k_2_02:10]
DALLAS, April 22, 2013 – Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2013. Financial
results presented have been adjusted for discontinued operations related to the company’s previously announced plans to sell its Service Experts business. The transaction was completed on March 22, 2013.

[0001193125-13-163938:8k_2_02:11]
Revenue for the first quarter was $668 million, up 9% from the prior-year quarter. Adjusted earnings per share from continuing operations was $0.33, up
74% from $0.19 in the prior-year quarter. On a GAAP basis, earnings per share from continuing operations was $0.31, up 72% from $0.18 in the prior-year quarter.

[0001193125-13-163938:8k_2_02:12]
“Growth continued across all three of our businesses in the first quarter with strong operational execution driving revenue up 9% and EPS up more than 70%,” said Todd Bluedorn, Chairman and CEO
of Lennox International. “Our Residential business continued to lead our growth on the strength of new construction and our growth initiatives in the replacement market. Residential revenue was up 15% in the first quarter and margin expanded
250 basis points to drive segment profit up 86%. In our Commercial business, revenue was up 4%, led by strong growth in national account services. Commercial profit was up 34% as margin expanded 150 basis points. Refrigeration revenue was up 4% at
constant currency on double-digit growth in Asia Pacific and South America. Refrigeration margin expanded 100 basis points, and profit grew 18%.

[0001193125-13-163938:8k_2_02:13]
“We have seen the company’s business momentum continue, and the year is off to a good start. However, the largest seasonal periods of the year are still ahead of us, and macroeconomic
uncertainty remains. On balance, we are raising the low end of our revenue and earnings guidance for 2013 to reflect our first quarter performance and current view on the full year. With our strong balance sheet, we will continue to invest in the
business and maintain a competitive dividend, and we plan to repurchase $100 million of stock in 2013.”

[0001193125-13-163938:8k_2_02:14]
FINANCIAL HIGHLIGHTS

[0001193125-13-163938:8k_2_02:15]
Revenue: Revenue for the first quarter was $668 million, up 9% from the prior-year quarter. Foreign exchange was neutral to revenue. Volume and price/mix were up from the prior-year quarter.

[0001193125-13-163938:8k_2_02:16]
Gross Profit: Gross profit for the first quarter was $162 million, up 15% from the prior-year quarter. Gross margin was 24.2%, up 130
basis points from 22.9% in the prior-year quarter. Gross profit was primarily impacted by higher volume, favorable price/mix and lower material costs, partially offset by investments in distribution.

[0001193125-13-163938:8k_2_02:17]
Income from Continuing Operations: Adjusted income from continuing operations in the first quarter was $17.0 million, or $0.33 per share, compared
to $9.8 million, or $0.19 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the first quarter of 2013 excludes $0.7 million after-tax for the net change in unrealized losses on open future contracts, an after-tax
charge of $0.3 million for restructuring activities, and an after-tax charge of $0.2 million for other items, net.

[0001193125-13-163938:8k_2_02:18]
On a GAAP basis, income
from continuing operations for the first quarter was $15.8 million, or $0.31 per share, compared to $9.3 million, or $0.18 per share, in the prior-year quarter.

[0001193125-13-163938:8k_2_02:19]
Loss from Discontinued Operations: The loss from discontinued operations for the divested Service Experts business in the first quarter of 2013 was $7.8 million, or $0.15 per share, compared to a
loss of $15.4 million, or $0.30 per share, in the first quarter of 2012.

[0001193125-13-163938:8k_2_02:20]
Free Cash Flow and Total Debt: Net cash used in operations in
the first quarter was $137 million compared to $34 million in the prior-year quarter. The company invested $12 million in capital assets in the first quarter. Free cash flow was ($149) million, compared to ($41) million in the prior-year quarter.
Total debt at the end of the first quarter was $516 million. Total cash and cash equivalents were $35 million at the end of the quarter.

[0001193125-13-163938:8k_2_02:21]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-13-163938:8k_2_02:22]
Residential Heating & Cooling

[0001193125-13-163938:8k_2_02:23]
First quarter 2013 revenue in the Residential
Heating & Cooling business segment was $315 million, up 15% from the prior-year quarter. Currency was neutral to revenue growth. Segment profit was $21 million, up 86% from the prior-year quarter. Segment profit margin was 6.5%, up 250
basis points. Results were primarily impacted by higher volume, favorable price, and lower material costs, with partial offsets from investments in distribution expansion, higher SG&A, and lower mix.

[0001193125-13-163938:8k_2_02:24]
Commercial Heating & Cooling

[0001193125-13-163938:8k_2_02:25]
Revenue in the Commercial Heating & Cooling business segment was $163 million, up 4% from the prior-year quarter. Currency was neutral to revenue
growth. Segment profit was $11 million, up 34% from the prior-year quarter. Segment profit margin was 6.8%, up 150 basis points. Results were primarily impacted by higher volume, favorable price/mix, lower material costs, with partial offsets from
investments in distribution expansion and higher SG&A.

[0001193125-13-163938:8k_2_02:26]
Refrigeration

[0001193125-13-163938:8k_2_02:27]
Revenue in the Refrigeration business segment was $191 million in the first quarter, up 3% from the prior-year quarter. At constant currency, revenue was up 4%. Segment profit was $17 million, up 18%.
Segment profit margin was 8.7%, up 100 basis points. Results were primarily impacted by favorable price/mix and lower material costs, with a partial offset from higher SG&A.

[0001193125-13-163938:8k_2_02:28]
FULL-YEAR OUTLOOK

[0001193125-13-163938:8k_2_02:29]
The company is narrowing its revenue and EPS from continuing operations
guidance ranges for 2013.

[0001193125-13-163938:8k_2_02:30]
|  | • |  | Raising the low end of revenue growth guidance from 2-6% to a range of 3-6%; foreign exchange is still expected to have a neutral impact on revenue. |

[0001193125-13-163938:8k_2_02:31]
|  | • |  | Raising the low end of adjusted EPS from continuing operations guidance from $3.15-$3.55 to a range of $3.25-$3.55. |

[0001193125-13-163938:8k_2_02:32]
|  | • |  | Narrowing GAAP EPS from continuing operations guidance from a range of $3.15-$3.55 to a new range of $3.23-$3.53. |

[0001193125-13-163938:8k_2_02:33]
|  | • |  | Reiterating tax rate guidance of 34-35% on a full-year basis. |

[0001193125-13-163938:8k_2_02:34]
|  | • |  | Reiterating capital expenditure guidance of approximately $60 million in 2013. |

[0001193125-13-163938:8k_2_02:35]
|  | • |  | Reiterating plans to repurchase $100 million of stock in 2013, and the company now expects its average diluted share count for the full year to be approximately 50 million shares. |

[0001193125-13-163938:8k_2_02:36]
CONFERENCE CALL INFORMATION

[0001193125-13-163938:8k_2_02:37]
A conference call to discuss the company’s first quarter results will be held this morning at 8:30 a.m. Central time. To listen, please call the conference call line at 612-332-0630 at least 10
minutes prior to the scheduled start time and use reservation number 287735. The conference call will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0001193125-13-163938:8k_2_02:38]
A replay will be available from 11:00 a.m. Central time on April 22 through April 29, 2013 by dialing 800-475-6701 (U.S.) or 320-365-3844
(international) and using access code 287735. The call will also be archived on the company’s web site.

[0001193125-13-163938:8k_2_02:39]
Lennox International Inc. is a
global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under the symbol “LII.” Additional information is available at:
http://www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-13-163938:8k_2_02:40]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-163938:8k_2_02:41]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-13-163938:8k_2_02:42]
(Unaudited, in millions, except per share data)

[0001193125-13-163938:8k_2_02:43]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Net sales |  | $ | 668.4 |  |  | $ | 614.4 |  |
| Cost of goods sold |  |  | 506.4 |  |  |  | 473.5 |  |
| Gross profit |  |  | 162.0 |  |  |  | 140.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 135.6 |  |  |  | 123.2 |  |
| Losses (gains) and other expenses, net |  |  | 1.1 |  |  |  | (1.4 | ) |
| Restructuring charges |  |  | 0.5 |  |  |  | 2.6 |  |
| Income from equity method investments |  |  | (3.1 | ) |  |  | (2.4 | ) |
| Operational income from continuing operations |  |  | 27.9 |  |  |  | 18.9 |  |
| Interest expense, net |  |  | 3.4 |  |  |  | 4.7 |  |
| Other expense, net |  |  | 0.1 |  |  |  | — |  |
| Income from continuing operations before income taxes |  |  | 24.4 |  |  |  | 14.2 |  |
| Provision for income taxes |  |  | 8.6 |  |  |  | 4.9 |  |
| Income from continuing operations |  |  | 15.8 |  |  |  | 9.3 |  |
| Discontinued operations: |  |  |  |  |  |  |  |  |
| Loss from discontinued operations |  |  | (13.4 | ) |  |  | (23.5 | ) |
| Benefit from income taxes |  |  | (5.6 | ) |  |  | (8.1 | ) |
| Loss from discontinued operations |  |  | (7.8 | ) |  |  | (15.4 | ) |
| Net income (loss) |  | $ | 8.0 |  |  | $ | (6.1 | ) |
| Earnings per share—Basic: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.32 |  |  | $ | 0.18 |  |
| Loss from discontinued operations |  |  | (0.16 | ) |  |  | (0.30 | ) |
| Net income (loss) |  | $ | 0.16 |  |  | $ | (0.12 | ) |
| Earnings per share—Diluted: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.31 |  |  | $ | 0.18 |  |
| Loss from discontinued operations |  |  | (0.15 | ) |  |  | (0.30 | ) |
| Net income (loss) |  | $ | 0.16 |  |  | $ | (0.12 | ) |
| Average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 50.3 |  |  |  | 50.9 |  |
| Diluted |  |  | 51.0 |  |  |  | 50.9 |  |
| Cash dividends declared per share |  | $ | 0.20 |  |  | $ | 0.18 |  |

[0001193125-13-163938:8k_2_02:44]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-163938:8k_2_02:45]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001193125-13-163938:8k_2_02:46]
(Unaudited, in millions)

[0001193125-13-163938:8k_2_02:47]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 314.5 |  |  | $ | 272.6 |  |
| Commercial Heating & Cooling |  |  | 163.0 |  |  |  | 156.7 |  |
| Refrigeration |  |  | 190.9 |  |  |  | 185.1 |  |
|  |  | $ | 668.4 |  |  | $ | 614.4 |  |
| Segment Profit (Loss) (A) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 20.5 |  |  | $ | 11.0 |  |
| Commercial Heating & Cooling |  |  | 11.1 |  |  |  | 8.3 |  |
| Refrigeration |  |  | 16.7 |  |  |  | 14.2 |  |
| Corporate and other |  |  | (18.9 | ) |  |  | (13.9 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 29.4 |  |  |  | 19.6 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | (0.2 | ) |  |  | (0.4 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) |  |  | 1.3 |  |  |  | (1.5 | ) |
| Restructuring charges |  |  | 0.5 |  |  |  | 2.6 |  |
| Interest expense, net |  |  | 3.4 |  |  |  | 4.7 |  |
| Other Expense, net |  |  | — |  |  |  | — |  |
| Income from continuing operations before income taxes |  | $ | 24.4 |  |  | $ | 14.2 |  |

[0001193125-13-163938:8k_2_02:48]
| (A) | The Company defines segment profit and loss as a segment’s Income or Loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |

[0001193125-13-163938:8k_2_02:49]
Excluding:

[0001193125-13-163938:8k_2_02:50]
|  | • |  | Special product quality adjustments; |

[0001193125-13-163938:8k_2_02:51]
|  | • |  | Items within Losses (gains) and other expenses, net that are noted in (B); |

[0001193125-13-163938:8k_2_02:52]
|  | • |  | Restructuring charges; |

[0001193125-13-163938:8k_2_02:53]
|  | • |  | Goodwill, long-lived assets and and equity method investment impairments; |

[0001193125-13-163938:8k_2_02:54]
|  | • |  | Interest expense, net; |

[0001193125-13-163938:8k_2_02:55]
|  | • |  | Other expense, net; |

[0001193125-13-163938:8k_2_02:56]
| (B) | Items in Losses (gains) and other expenses, net that are excluded from segment profit or loss are asset impairments, net change in unrealized gains and/or losses on open future contracts, special legal contingency charges, and other items. |

[0001193125-13-163938:8k_2_02:57]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-163938:8k_2_02:58]
CONSOLIDATED BALANCE SHEETS

[0001193125-13-163938:8k_2_02:59]
(In millions, except shares and par value)

[0001193125-13-163938:8k_2_02:60]
|  |  | As of March 31,2013 |  |  | As of December 31,2012 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 34.9 |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net of allowances of $10.0 and $9.5 in 2013 and 2012, respectively |  |  | 407.0 |  |  |  | 373.4 |  |
| Inventories, net |  |  | 464.3 |  |  |  | 374.8 |  |
| Deferred income taxes |  |  | 29.7 |  |  |  | 27.5 |  |
| Other assets |  |  | 68.2 |  |  |  | 61.0 |  |
| Assets of discontinued operations |  |  | — |  |  |  | 98.6 |  |
| Total current assets |  |  | 1,004.1 |  |  |  | 987.1 |  |
| Property, plant and equipment, net of accumulated depreciation of $593.0 and $584.8 in 2013 and 2012, respectively |  |  | 295.1 |  |  |  | 298.2 |  |
| Goodwill |  |  | 223.4 |  |  |  | 223.8 |  |
| Deferred income taxes |  |  | 109.9 |  |  |  | 102.8 |  |
| Other assets, net |  |  | 81.6 |  |  |  | 80.0 |  |
| Total assets |  | $ | 1,714.1 |  |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 26.0 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt |  |  | 0.6 |  |  |  | 0.7 |  |
| Accounts payable |  |  | 312.4 |  |  |  | 284.7 |  |
| Accrued expenses |  |  | 222.6 |  |  |  | 259.6 |  |
| Income taxes payable |  |  | 0.8 |  |  |  | 4.5 |  |
| Liabilities of discontinued operations |  |  | — |  |  |  | 55.2 |  |
| Total current liabilities |  |  | 562.4 |  |  |  | 639.6 |  |
| Long-term debt |  |  | 489.8 |  |  |  | 351.0 |  |
| Postretirement benefits, other than pensions |  |  | 5.8 |  |  |  | 6.1 |  |
| Pensions |  |  | 135.7 |  |  |  | 134.4 |  |
| Other liabilities |  |  | 68.4 |  |  |  | 64.0 |  |
| Total liabilities |  |  | 1,262.1 |  |  |  | 1,195.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 906.7 |  |  |  | 898.3 |  |
| Retained earnings |  |  | 742.4 |  |  |  | 744.4 |  |
| Accumulated other comprehensive loss |  |  | (71.6 | ) |  |  | (22.3 | ) |
| Treasury stock, at cost, 36,785,644 shares and 36,937,632 shares for 2013 and 2012, respectively |  |  | (1,126.4 | ) |  |  | (1,124.5 | ) |
| Total stockholders’ equity |  |  | 452.0 |  |  |  | 496.8 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,714.1 |  |  | $ | 1,691.9 |  |

[0001193125-13-163938:8k_2_02:61]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-163938:8k_2_02:62]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-13-163938:8k_2_02:63]
(Unaudited, in millions)

[0001193125-13-163938:8k_2_02:64]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 8.0 |  |  | $ | (6.1 | ) |
| Net loss from discontinued operations |  |  | 7.8 |  |  |  | 15.4 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (3.1 | ) |  |  | (2.4 | ) |
| Restructuring expenses, net of cash paid |  |  | (1.4 | ) |  |  | 1.7 |  |
| Provision for bad debts |  |  | 1.2 |  |  |  | 1.5 |  |
| Unrealized loss (gain) on derivative contracts |  |  | 0.5 |  |  |  | (0.5 | ) |
| Stock-based compensation expense |  |  | 7.7 |  |  |  | 3.8 |  |
| Depreciation and amortization |  |  | 14.1 |  |  |  | 13.9 |  |
| Deferred income taxes |  |  | (1.6 | ) |  |  | (0.6 | ) |
| Other items, net |  |  | 9.0 |  |  |  | 0.5 |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (35.8 | ) |  |  | 3.7 |  |
| Inventories |  |  | (100.9 | ) |  |  | (75.2 | ) |
| Other current assets |  |  | (3.5 | ) |  |  | 3.4 |  |
| Accounts payable |  |  | 18.8 |  |  |  | 34.3 |  |
| Accrued expenses |  |  | (42.1 | ) |  |  | (15.4 | ) |
| Income taxes payable and receivable |  |  | (9.6 | ) |  |  | (8.6 | ) |
| Other |  |  | 5.6 |  |  |  | 1.9 |  |
| Net cash used in discontinued operations |  |  | (12.0 | ) |  |  | (5.6 | ) |
| Net cash used in operating activities |  |  | (137.3 | ) |  |  | (34.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | (12.1 | ) |  |  | (6.6 | ) |
| Net proceeds from sale of business |  |  | 5.3 |  |  |  | — |  |
| Net cash used in discontinued operations |  |  | (0.1 | ) |  |  | (0.3 | ) |
| Net cash used in investing activities |  |  | (6.9 | ) |  |  | (6.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 1.2 |  |  |  | 6.6 |  |
| Asset securitization borrowings |  |  | 130.0 |  |  |  | 170.0 |  |
| Asset securitization payments |  |  | (140.0 | ) |  |  | (170.0 | ) |
| Long-term debt payments |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Borrowings from revolving credit facility |  |  | 435.5 |  |  |  | 267.5 |  |
| Payments on revolving credit facility |  |  | (296.5 | ) |  |  | (215.5 | ) |
| Proceeds from stock option exercises |  |  | 0.5 |  |  |  | 0.1 |  |
| Repurchases of common stock |  |  | (4.2 | ) |  |  | (1.9 | ) |
| Excess tax benefits related to share-based payments |  |  | 2.3 |  |  |  | 0.8 |  |
| Cash dividends paid |  |  | — |  |  |  | (9.2 | ) |
| Net cash provided by financing activities |  |  | 128.6 |  |  |  | 48.2 |  |
| Increase (decrease) in cash and cash equivalents |  |  | (15.6 | ) |  |  | 7.1 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (1.3 | ) |  |  | 2.6 |  |
| Cash and cash equivalents, beginning of period |  |  | 51.8 |  |  |  | 45.0 |  |
| Cash and cash equivalents, end of period |  | $ | 34.9 |  |  | $ | 54.7 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the period for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 1.2 |  |  | $ | 2.3 |  |
| Income taxes (net of refunds) |  | $ | 11.9 |  |  | $ | 5.1 |  |

[0001193125-13-163938:8k_2_02:65]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-163938:8k_2_02:66]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-13-163938:8k_2_02:67]
(Unaudited, In millions, except per share and ratio data)

[0001193125-13-163938:8k_2_02:68]
Use of Non-GAAP Financial Measures

[0001193125-13-163938:8k_2_02:69]
To supplement the Company’s consolidated financial
statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when
considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors
to analyze the Company’s business trends and operating performance.

[0001193125-13-163938:8k_2_02:70]
Reconciliation of Income From Continuing Operations, a GAAP
measure, to Adjusted Income From Continuing Operations, a Non-GAAP measure

[0001193125-13-163938:8k_2_02:71]
|  |  | For The Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Income from continuing operations, a GAAP measure |  | $ | 15.8 |  |  | $ | 9.3 |  |
| Restructuring charges, after tax |  |  | 0.3 |  |  |  | 1.7 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.1 | ) |  |  | (0.3 | ) |
| Special legal contingency charges, after tax (a) |  |  | 0.2 |  |  |  | — |  |
| Net change in unrealized losses (gains) on open future contracts, after tax (a) |  |  | 0.7 |  |  |  | (1.1 | ) |
| Other items, net, after tax (a) |  |  | 0.1 |  |  |  | 0.2 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 17.0 |  |  | $ | 9.8 |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 0.31 |  |  | $ | 0.18 |  |
| Restructuring charges, after tax |  |  | 0.01 |  |  |  | 0.03 |  |
| Special product quality adjustments, after tax (b) |  |  | — |  |  |  | — |  |
| Special legal contingency charges, after tax (a) |  |  | — |  |  |  | — |  |
| Net change in unrealized losses (gains) on open future contracts, after tax (a) |  |  | 0.01 |  |  |  | (0.02 | ) |
| Other items, net, after tax (a) |  |  | — |  |  |  | — |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  | $ | 0.33 |  |  | $ | 0.19 |  |

[0001193125-13-163938:8k_2_02:72]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-13-163938:8k_2_02:73]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-13-163938:8k_2_02:74]
|  |  | For The Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |
| Realized loss on settled future contracts (a) |  | $ | — |  |  | $ | 0.3 |  |
| Foreign currency exchange gain (a) |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Net change in unrealized losses (gains) on open futures contracts (b) |  |  | 1.0 |  |  |  | (1.7 | ) |
| Special legal contingency charge (b) |  |  | 0.2 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.1 |  |  |  | 0.2 |  |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 1.1 |  |  | $ | (1.4 | ) |

[0001193125-13-163938:8k_2_02:75]
| (a) | Included in segment profit (loss) and adjusted income from continuing operations |

[0001193125-13-163938:8k_2_02:76]
| (b) | Excluded from segment profit (loss) and adjusted income from continuing operations |

[0001193125-13-163938:8k_2_02:77]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations—Diluted, a Non-GAAP
Measure, to Income per Share from Continuing Operations—Diluted, a GAAP Measure

[0001193125-13-163938:8k_2_02:78]
|  |  | For the |  |
|  |  | Year Ended |  |
|  |  | December 31, |  |
|  |  | 2013 |  |
|  |  | ESTIMATED |  |
| Adjusted income per share from continuing operations—diluted, a Non-GAAP measure |  | $ | 3.25 - $3.55 |  |
| Restructuring charges and net change in unrealized losses on open future contracts |  |  | (0.02 | ) |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 3.23 - $3.53 |  |

[0001193125-13-163938:8k_2_02:79]
Reconciliation of Net Cash Used in Operating Activities, a GAAP Measure, to Free Cash Flow, a Non-GAAP Measure

[0001193125-13-163938:8k_2_02:80]
|  |  | For the Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Net cash used in operating activities, a GAAP measure |  | $ | (137.3 | ) |  | $ | (34.3 | ) |
| Purchases of property, plant and equipment |  |  | (12.1 | ) |  |  | (6.6 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |
| Free cash flow, a Non-GAAP measure |  | $ | (149.4 | ) |  | $ | (40.8 | ) |

[0001193125-13-163938:8k_2_02:81]
Calculation of Debt to EBITDA Ratio:

[0001193125-13-163938:8k_2_02:82]
|  |  | Trailing Twelve |  |
|  |  | Months to |  |
|  |  | March 31, |  |
|  |  | 2013 |  |
| EBIT (a) |  | $ | 234.0 |  |
| Depreciation and amortization expense (b) |  |  | 55.6 |  |
| EBITDA (a + b) |  | $ | 289.6 |  |
| Total debt at March 31, 2013 (c) |  | $ | 516.4 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 1.8 |  |

[0001193125-13-163938:8k_2_02:83]
Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure

[0001193125-13-163938:8k_2_02:84]
|  |  | Trailing Twelve |  |
|  |  | Months to |  |
|  |  | March 31, |  |
|  |  | 2013 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 234.0 |  |
| Special product quality adjustments |  |  | 1.3 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 2.6 |  |
| Restructuring charges |  |  | 2.1 |  |
| Interest expense, net |  |  | 15.8 |  |
| Other expenses, net |  |  | 0.3 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 211.9 |  |
