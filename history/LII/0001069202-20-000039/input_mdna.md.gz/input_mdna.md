# LII MD&A — 0001069202-20-000039


## mdna

[0001069202-20-000039:mdna:1]
[same as prior period, unchanged from 0001069202-20-000015:mdna:1]

[0001069202-20-000039:mdna:2]
[same as prior period, unchanged from 0001069202-20-000015:mdna:2]

[0001069202-20-000039:mdna:3]
[same as prior period, unchanged from 0001069202-20-000015:mdna:3]

[0001069202-20-000039:mdna:4]
[same as prior period, unchanged from 0001069202-20-000015:mdna:4]

[0001069202-20-000039:mdna:5]
[same as prior period, unchanged from 0001069202-20-000015:mdna:5]

[0001069202-20-000039:mdna:6]
[same as prior period, unchanged from 0001069202-20-000015:mdna:6]

[0001069202-20-000039:mdna:7]
[same as prior period, unchanged from 0001069202-20-000015:mdna:7]

[0001069202-20-000039:mdna:8]
[same as prior period, unchanged from 0001069202-20-000015:mdna:8]

[0001069202-20-000039:mdna:9]
In response to the COVID-19 pandemic various national, state, and local governments where we, our suppliers, and our customers operate issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work.  Those decrees have resulted in supply chain disruption and higher employee absenteeism in our factories.

[0001069202-20-000039:mdna:10]
Additionally, certain of our manufacturing facilities experienced short-term suspensions of operations for COVID-19 employee health concerns during the second quarter of 2020.

[0001069202-20-000039:mdna:11]
Due to the adverse impact of the COVID-19 pandemic on our European manufacturing facilities and the resulting downturn in the related business, we recorded an $8 million valuation allowance in the first quarter of 2020 on certain foreign deferred tax assets as we concluded that it was no longer more likely than not that these foreign tax loss carryforwards would be realized. In April 2020, we implemented cost reduction actions to realize $115 million of SG&A savings for the balance of the year.  In connection with these cost saving actions, we incurred pre-tax charges of $10 million in the second quarter of 2020 related primarily to personnel severance and benefits and facility exit costs. Also, during the second quarter of 2020, we incurred $3 million of expenses for facility cleaning and supplies to ensure the health and safety of our employees.

[0001069202-20-000039:mdna:12]
The magnitude of the impact of COVID-19 remains unpredictable and we, therefore, continue to anticipate potential supply chain disruptions, employee absenteeism and short-term suspensions of manufacturing facilities, and additional health and safety costs related to the COVID-19 pandemic that could unfavorably impact our business.  We also anticipate significant challenges in the remainder of 2020 due to uncertain market conditions.  Accordingly, our revised downward financial outlook remains but we made slight adjustments to our expectations.

[0001069202-20-000039:mdna:13]
Currently, we continue to believe that the North America unitary HVAC and refrigeration market will be negatively impacted about 20% this year by the pandemic.  Since the first quarter of 2020, we have reset our financial expectations for the year based on that level of market impact and now expect revenue to be down 10% to 15% from last year versus our initial guidance for growth of 4% to 8% (and down from our first quarter expectations of a 11% to 17% decline).  We now expect Diluted EPS from continuing operations in the range of $7.31 to $8.11 for the year (as compared to our first quarter expected range of $7.07 to $8.07).

[0001069202-20-000039:mdna:14]
We expect our cash generation to remain strong for 2020 as our working capital requirements decline and are projecting approximately $460 million in cash flows from operations for the year. We have reduced our capital expenditure plans for 2020 from $153 million initially to $120 million. We are rated investment grade by both S&P and Moody’s, and we expect to remain well within our debt covenants. Our bank revolver and asset securitization line do not mature until the latter half of 2021, and our senior notes do not mature until November 2023.  Our quarterly dividend plans are unchanged, most recently $0.77 per share, or more than $115 million in total payments for the year.  We repurchased $100 million of stock in the first quarter of the $400 million we had planned to repurchase for the year. However, we placed the remaining repurchase plans for 2020 on hold and we will review plans for the third and fourth quarters as the year progresses.

[0001069202-20-000039:mdna:15]
[same as prior period, unchanged from 0001069202-20-000015:mdna:15]

[0001069202-20-000039:mdna:16]
Results for the second quarter of 2020 were impacted by the business downturn caused by the COVID-19 pandemic. Year over year sales and profit were down in each of our business segments primarily due to lower sales volumes. The Residential Heating & Cooling segment saw a 6% decrease in net sales and a $26 million decrease in segment profit. The Commercial Heating & Cooling segment had a 28% decrease in net sales and a $18 million decrease in segment profit. The Refrigeration segment had a 27% decline in net sales and a $10 million decline in segment profit.

[0001069202-20-000039:mdna:17]
[same as prior period, unchanged from 0001069202-20-000015:mdna:17]

[0001069202-20-000039:mdna:18]
•Net sales decreased $158 million to $941 million in the second quarter of 2020 driven by volume declines in each of our operating segments.

[0001069202-20-000039:mdna:19]
•Operating income in the second quarter of 2020 decreased $78 million to $136 million primarily due to lower volumes, factory inefficiencies, and non-recurring insurance recoveries in 2019 for lost profits related to the Marshalltown tornado.

[0001069202-20-000039:mdna:20]
•Net income for the second quarter of 2020 decreased $11 million to $100 million.

[0001069202-20-000039:mdna:21]
•Diluted earnings per share from continuing operations were $2.62 per share in the second quarter of 2020 compared to $2.81 per share in the second quarter of 2019.

[0001069202-20-000039:mdna:22]
•For the six months ended June 30, 2020, we returned $59 million to shareholders through dividend payments and repurchased $100 million of common stock through our share repurchase program.

[0001069202-20-000039:mdna:23]
Second Quarter of 2020 Compared to Second Quarter of 2019 - Consolidated Results

[0001069202-20-000039:mdna:24]
[same as prior period, unchanged from 0001069202-20-000015:mdna:24]

[0001069202-20-000039:mdna:25]
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |  |  |
|  | Dollars (in millions) |  |  |  | PercentChangeFav/(Unfav) |  | Percent of Sales |  |  |
|  | 2020 |  | 2019 |  |  |  | 2020 |  | 2019 |
| Net sales | $ | 941.3 |  |  | $ | 1,099.1 |  |  | (14.4) | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 665.6 |  |  | 767.0 |  |  | 13.2 |  |  | 70.7 |  |  | 69.8 |  |
| Gross profit | 275.7 |  |  | 332.1 |  |  | (17.0) |  |  | 29.3 |  |  | 30.2 |  |
| Selling, general and administrative expenses | 129.5 |  |  | 152.4 |  |  | 15.0 |  |  | 13.8 |  |  | 13.9 |  |
| Losses (gains) and other expenses, net | 3.6 |  |  | 2.1 |  |  | (71.4) |  |  | 0.4 |  |  | 0.2 |  |
| Restructuring charges | 10.0 |  |  | (0.1) |  |  | (10,100.0) |  |  | 1.1 |  |  | — |  |
| Loss on sale of business | — |  |  | 0.4 |  |  | 100.0 |  |  | — |  |  | — |  |
| Insurance proceeds for lost profits | — |  |  | (26.0) |  |  | 100.0 |  |  | — |  |  | (2.4) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.0 |  |  | (5.9) |  |  | (116.9) |  |  | 0.1 |  |  | (0.5) |  |
| Income from equity method investments | (4.4) |  |  | (4.6) |  |  | (4.3) |  |  | (0.5) |  |  | (0.4) |  |
| Operating income | $ | 136.0 |  |  | $ | 213.8 |  |  | (36.4) | % |  | 14.4 | % |  | 19.5 | % |

[0001069202-20-000039:mdna:26]
[same as prior period, unchanged from 0001069202-20-000015:mdna:26]

[0001069202-20-000039:mdna:27]
Net sales declined 14% in the second quarter of 2020 compared to the second quarter of 2019, driven by a 15% decline  decline in volume, partially offset by a 1% increase in higher combined price and mix.

[0001069202-20-000039:mdna:28]
[same as prior period, unchanged from 0001069202-20-000015:mdna:28]

[0001069202-20-000039:mdna:29]
Gross profit margin in the second quarter of 2020 decreased 90 basis points ("bps") to 29.3% compared to 30.2% in the second quarter of 2019. We saw margin decreases of 200 bps from lower combined price and mix, 100 bps from factory inefficiencies, and 50 bps from higher product warranty costs. Partially offsetting these were margin increases of 90 bps from lower freight and distribution costs, 70 bps from lower commodities costs, 60 bps from lower tariffs and sourcing and engineering-led cost reductions, and 40 bps from lower other product costs.

[0001069202-20-000039:mdna:30]
[same as prior period, unchanged from 0001069202-20-000015:mdna:30]

[0001069202-20-000039:mdna:31]
Selling, general and administrative expenses ("SG&A") declined approximately $23 million to $130 million in the second quarter of 2020 compared to $152 million in the second quarter of 2019 primarily due to lower salary and incentive compensation costs. As a percentage of net sales, SG&A decreased 10 bps to 13.8% .

[0001069202-20-000039:mdna:32]
Losses (gains) and Other Expenses, Net

[0001069202-20-000039:mdna:33]
Losses (gains) losses and other expenses, net for the second quarter of 2020 and 2019 included the following (in millions):

[0001069202-20-000039:mdna:34]
|  | For the Three Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Realized losses on settled futures contracts | $ | 0.1 |  |  | $ | 0.1 |  |
| Foreign currency exchange gains | (2.1) |  |  | (0.2) |  |
| Gain on disposal of fixed assets | (0.2) |  |  | (0.4) |  |
| Other operating income | (1.2) |  |  | — |  |
| Net change in unrealized losses on unsettled futures contracts | 0.8 |  |  | 0.1 |  |
| Special legal contingency charges | 0.7 |  |  | (0.1) |  |
| Asbestos-related litigation | 1.2 |  |  | 0.4 |  |
| Environmental liabilities | 1.1 |  |  | 1.3 |  |
| Charges incurred related to COVID-19 pandemic | 3.4 |  |  | — |  |
| Other items, net | (0.2) |  |  | 0.9 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.6 |  |  | $ | 2.1 |  |

[0001069202-20-000039:mdna:35]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 9 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities related to estimated remediation costs for contamination at some of our facilities. The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and supplies to ensure the health and safety of our employees.

[0001069202-20-000039:mdna:36]
[same as prior period, unchanged from 0001069202-20-000015:mdna:36]

[0001069202-20-000039:mdna:37]
Restructuring charges were $10 million in the second quarter of 2020 and related to several cost reduction actions taken in response to the economic impact of COVID-19 on our business. These actions consisted of employee terminations for positions that are no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities. For additional information on our restructuring activities, refer to Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000039:mdna:38]
[same as prior period, unchanged from 0001069202-20-000015:mdna:40]

[0001069202-20-000039:mdna:39]
[same as prior period, unchanged from 0001069202-20-000015:mdna:41]

[0001069202-20-000039:mdna:40]
[same as prior period, unchanged from 0001069202-20-000015:mdna:42]

[0001069202-20-000039:mdna:41]
During the second quarter of 2020, we incurred expenses of $1 million related to damages caused by the tornado, which included site clean up, waste disposal and other restoration costs. See Note 4 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-20-000039:mdna:42]
[same as prior period, unchanged from 0001069202-20-000015:mdna:44]

[0001069202-20-000039:mdna:43]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $4 million in the second quarter of 2020 was comparable to the second quarter of 2019.

[0001069202-20-000039:mdna:44]
Pension Settlement

[0001069202-20-000039:mdna:45]
In the second quarter of 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and $105.6 million of related pension benefit obligations. We recognized a $60.6 million pension settlement charge in the Statement of Operations as a result of this transaction. There were no pension settlements in the second quarter of 2020. For additional information, refer to Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000039:mdna:46]
[same as prior period, unchanged from 0001069202-20-000015:mdna:46]

[0001069202-20-000039:mdna:47]
Interest expense, net of $7 million in the second quarter of 2020 was down $6 million from $13 million in the second quarter of 2019 due to lower borrowing costs and lower borrowings.

[0001069202-20-000039:mdna:48]
[same as prior period, unchanged from 0001069202-20-000015:mdna:48]

[0001069202-20-000039:mdna:49]
Our effective tax rate was 21.4% for the second quarter of 2020 compared to 20.6% for the second quarter of 2019.  The rate increased primarily due to lower excess tax benefits.  We expect our annual effective tax rate to be between 21% and 22%, after excluding the impacts of excess tax benefits recorded under ASU No. 2016-09, the $8 million valuation allowance recorded in the first quarter of 2020 and the tax impacts of restructuring and pandemic-related charges.

[0001069202-20-000039:mdna:50]
Second Quarter of 2020 Compared to Second Quarter of 2019 - Results by Segment

[0001069202-20-000039:mdna:51]
[same as prior period, unchanged from 0001069202-20-000015:mdna:52]

[0001069202-20-000039:mdna:52]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the second quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000039:mdna:53]
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 644.8 |  |  | $ | 689.1 |  |  | $ | (44.3) |  |  | (6.4) | % |
| Profit | $ | 127.3 |  |  | $ | 153.4 |  |  | $ | (26.1) |  |  | (17.0) | % |
| % of net sales | 19.7 | % |  | 22.3 | % |  |  |  |  |

[0001069202-20-000039:mdna:54]
Net sales decreased 6% in the second quarter of 2020 compared to the second quarter of 2019.  Sales volumes declined 8%, partially offset by 2% higher combined price and mix.

[0001069202-20-000039:mdna:55]
Segment profit in the second quarter of 2020 declined $26 million compared to the second quarter of 2019 due to $25 million from lower sales volumes, $18 million of non-recurring insurance proceeds for lost profits due to the Marshalltown tornado, $9 million of factory inefficiencies and lower absorption, $6 million from non-recurring warranty adjustments and other product costs, and $1 million of lower income from equity method investments.  Partially offsetting these declines was $12 million of lower SG&A expenses, $8 million of lower freight and distribution expenses, $6 million of favorable combined price and mix, $4 million of lower commodities costs, and $3 million from engineering and sourcing-led cost reductions.

[0001069202-20-000039:mdna:56]
[same as prior period, unchanged from 0001069202-20-000015:mdna:57]

[0001069202-20-000039:mdna:57]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000039:mdna:58]
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 188.3 |  |  | $ | 261.3 |  |  | $ | (73.0) |  |  | (27.9) | % |
| Profit | $ | 35.6 |  |  | $ | 53.9 |  |  | $ | (18.3) |  |  | (34.0) | % |
| % of net sales | 18.9 | % |  | 20.6 | % |  |  |  |  |

[0001069202-20-000039:mdna:59]
Net sales decreased 28% in the second quarter of 2020 compared to the second quarter of 2019.  Sales volumes declined 27% and mix was unfavorable 1%.

[0001069202-20-000039:mdna:60]
Segment profit in the second quarter of 2020 declined $18 million compared to the second quarter of 2019 due to $24 million from lower sales volumes and $5 million of unfavorable mix.  Partially offsetting these declines was $5 million of lower SG&A expenses, $2 million of lower commodities costs, $2 million of engineering and sourcing-led cost reductions, $1 million of lower freight and distribution expenses, and $1 million from favorable foreign currency exchange rates.

[0001069202-20-000039:mdna:61]
[same as prior period, unchanged from 0001069202-20-000015:mdna:62]

[0001069202-20-000039:mdna:62]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000039:mdna:63]
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 108.2 |  |  | $ | 148.7 |  |  | $ | (40.5) |  |  | (27.2) | % |
| Profit | $ | 8.9 |  |  | $ | 19.1 |  |  | $ | (10.2) |  |  | (53.4) | % |
| % of net sales | 8.2 | % |  | 12.8 | % |  |  |  |  |

[0001069202-20-000039:mdna:64]
Net sales decreased 27% in the second quarter of 2020 compared to the second quarter of 2019 due to lower sales volumes.

[0001069202-20-000039:mdna:65]
Segment profit in the second quarter of 2020 declined $10 million compared to the second quarter of 2019 due to $13 million of lower sales volumes, and $3 million of factory inefficiencies and lower absorption. Partially offsetting these declines were $2 million of lower SG&A expenses, $1 million of lower commodities costs, $1 million from engineering and sourcing-led cost reductions, $1 million of lower freight and distribution expenses, and $1 million from favorable foreign currency exchange rates.

[0001069202-20-000039:mdna:66]
[same as prior period, unchanged from 0001069202-20-000015:mdna:67]

[0001069202-20-000039:mdna:67]
Corporate and other expenses decreased $5 million in the second quarter of 2020 compared to the second quarter of 2019 primarily due to lower salary, incentive compensation, and discretionary expenses.

[0001069202-20-000039:mdna:68]
Year-to-Date through June 30, 2020 Compared to Year-to-Date through June 30, 2019 - Consolidated Results

[0001069202-20-000039:mdna:69]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-20-000039:mdna:70]
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |  |  |
|  | Dollars (in millions) |  |  |  | PercentChangeFav/(Unfav) |  | Percent of Sales |  |  |
|  | 2020 |  | 2019 |  |  |  | 2020 |  | 2019 |
| Net sales | $ | 1,665.1 |  |  | $ | 1,889.4 |  |  | (11.9) |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,223.7 |  |  | 1,355.8 |  |  | 9.7 |  |  | 73.5 |  |  | 71.8 |  |
| Gross profit | 441.4 |  |  | 533.6 |  |  | (17.3) |  |  | 26.5 |  |  | 28.2 |  |
| Selling, general and administrative expenses | 260.8 |  |  | 298.2 |  |  | 12.5 |  |  | 15.7 |  |  | 15.8 |  |
| Losses (gains) and other expenses, net | 2.3 |  |  | 3.2 |  |  | 28.1 |  |  | 0.1 |  |  | 0.2 |  |
| Restructuring charges | 10.5 |  |  | 0.4 |  |  | (2,525.0) |  |  | 0.6 |  |  | — |  |
| Loss on sale of business | — |  |  | 8.8 |  |  | 100.0 |  |  | — |  |  | 0.5 |  |
| Insurance proceeds for lost profits | — |  |  | (65.5) |  |  | 100.0 |  |  | — |  |  | (3.5) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 2.7 |  |  | (12.8) |  |  | (121.1) |  |  | 0.2 |  |  | (0.7) |  |
| Income from equity method investments | (7.2) |  |  | (7.2) |  |  | — |  |  | (0.4) |  |  | (0.4) |  |
| Operating income | $ | 172.3 |  |  | $ | 308.5 |  |  | (44.1) |  |  | 10.3 | % |  | 16.3 | % |

[0001069202-20-000039:mdna:71]
Net Sales

[0001069202-20-000039:mdna:72]
Net sales decreased 12% in the six months ended June 30, 2020 compared to the six months ended June 30, 2019 due to a 11% decline in sales volumes and a 2% decline related to the sale of our Kysor Warren business in the first quarter of 2019, partially offset by 1% from favorable combined price and mix.

[0001069202-20-000039:mdna:73]
Gross Profit

[0001069202-20-000039:mdna:74]
Gross profit margins for the six months ended June 30, 2020 decreased 170 bps to 26.5% compared to the six months ended June 30, 2019. Our profit margin decreased 200 bps from unfavorable combined price and mix, 120 bps from factory inefficiencies, and 90 bps from higher product warranties and other product costs.  These were partially offset by 80 bps from lower commodities costs, 80 bps from sourcing and engineering-led cost reductions and lower tariffs, 50 bps from lower freight and distribution costs, and 30 bps from the divested Kysor Warren business which had lower margins.

[0001069202-20-000039:mdna:75]
Selling, General and Administrative Expenses

[0001069202-20-000039:mdna:76]
SG&A declined $37 million to $261 million for the six months ended June 30, 2020 compared to $298 million for the six months ended June 30, 2019 primarily due to lower salaries and incentive compensation costs, the sale of our Kysor Warren business in the first quarter of 2019, and lower discretionary expenditures. As a percentage of net sales, SG&A decreased 10 bps to 15.7% from 15.8%.

[0001069202-20-000039:mdna:77]
Losses (gains) and Other Expenses, Net

[0001069202-20-000039:mdna:78]
Losses (gains) and other expenses, net for the six months ended June 30, 2020 and 2019 included the following (in millions):

[0001069202-20-000039:mdna:79]
|  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Realized losses on settled futures contracts | $ | 0.2 |  |  | $ | 0.2 |  |
| Foreign currency exchange losses | (2.6) |  |  | (0.7) |  |
| Gain on disposal of fixed assets | (0.1) |  |  | (0.2) |  |
| Other operating income | (1.3) |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 1.4 |  |  | (0.3) |  |
| Special legal contingency charges | 0.7 |  |  | 0.2 |  |
| Asbestos-related litigation | (0.5) |  |  | 1.8 |  |
| Environmental liabilities | 1.3 |  |  | 1.3 |  |
| Charges incurred related to COVID-19 pandemic | 3.4 |  |  | — |  |
| Other items, net | (0.2) |  |  | 0.9 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.3 |  |  | $ | 3.2 |  |

[0001069202-20-000039:mdna:80]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 9 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities related to estimated remediation costs for contamination at some of our facilities.  The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and supplies to ensure the health and safety of our employees.

[0001069202-20-000039:mdna:81]
Restructuring Charges

[0001069202-20-000039:mdna:82]
Restructuring charges were approximately $11 million in the six months ended June 30, 2020 and related to several cost reduction actions taken in response to the economic impact of COVID-19 on our business. These actions consisted of employee terminations for positions that are no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities. For additional information on our restructuring activities, refer to Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000039:mdna:83]
[same as prior period, unchanged from 0001069202-20-000015:mdna:38]

[0001069202-20-000039:mdna:84]
We recognized a loss of $9 million for the six months ended June 30, 2019 related to the sale of our Kysor Warren business in the first quarter of 2019.  There were no losses related to this sale for the six months ended June 30, 2020.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for additional information on this divestiture.

[0001069202-20-000039:mdna:85]
Gains and Losses related to Marshalltown Tornado

[0001069202-20-000039:mdna:86]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covered the repair or replacement of our assets that suffered damage or loss and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Loss (gain) from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations. Our insurance policies also provided business interruption coverage, including lost profits, related to the losses suffered.  These insurance recoveries are shown in Insurance proceeds for lost profits in the Consolidated Statements of Operations.

[0001069202-20-000039:mdna:87]
In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019.

[0001069202-20-000039:mdna:88]
For the six months ended June 30, 2020, we incurred expenses of $3 million related to damages caused by the tornado, which included site clean up, waste disposal and other restoration costs. See Note 4 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-20-000039:mdna:89]
Income from Equity Method Investments

[0001069202-20-000039:mdna:90]
Income from equity method investments of $7 million for the six months ended June 30, 2020 was flat compared to the six months ended June 30, 2019.

[0001069202-20-000039:mdna:91]
Pension Settlement

[0001069202-20-000039:mdna:92]
In the second quarter of 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and $105.6 million of related pension benefit obligations. We recognized a $60.6 million pension settlement charge in the Statement of Operations as a result of this transaction. There were no pension settlements for the six months ended June 30, 2020. For additional information, refer to Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000039:mdna:93]
Interest Expense, net

[0001069202-20-000039:mdna:94]
Interest expense, net of $16 million in the six months ended June 30, 2020 decreased $8 million from $24 million in the six months ended June 30, 2019 primarily due to lower borrowing costs and lower borrowings.

[0001069202-20-000039:mdna:95]
Income Taxes

[0001069202-20-000039:mdna:96]
Our effective tax rate increased to 26.8% for the six months ended June 30, 2020 compared to 19.0% for the six months ended June 30, 2019 primarily due to a $8 million valuation allowance on certain foreign deferred tax assets recorded in the first quarter of 2020 and lower excess tax benefits.

[0001069202-20-000039:mdna:97]
Year-to-Date through June 30, 2020 Compared to Year-to-Date through June 30, 2019 - Results by Segment

[0001069202-20-000039:mdna:98]
Residential Heating & Cooling

[0001069202-20-000039:mdna:99]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the six months ended June 30, 2020 and 2019 (dollars in millions):

[0001069202-20-000039:mdna:100]
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 1,086.9 |  |  | $ | 1,154.6 |  |  | $ | (67.7) |  |  | (5.9) | % |
| Profit | $ | 159.8 |  |  | $ | 240.1 |  |  | $ | (80.3) |  |  | (33.4) | % |
| % of net sales | 14.7 | % |  | 20.8 | % |  |  |  |  |

[0001069202-20-000039:mdna:101]
Net sales decreased 6% in the six months ended June 30, 2020 compared to the six months ended June 30, 2019. Sales volumes declined 7% partially offset by favorable combined price and mix of 1%.

[0001069202-20-000039:mdna:102]
Segment profit for the six months ended June 30, 2020 decreased $80 million compared to the six months ended June 30, 2019 due to $58 million of non-recurring insurance proceeds for lost profits related to the Marshalltown tornado, $33 million from lower sales volumes, $17 million from lower factory absorption and efficiency, $15 million from non-recurring warranty adjustments and other product costs, $11 million from unfavorable mix, and $1 million from lower income from equity method investments. Partially offsetting these declines was $18 million of lower SG&A expenses, $9 million of favorable price, $9 million from sourcing and engineering-led cost reductions, $8 million of lower commodities costs, $7 million from lower freight and distribution expense, $2 million from lower tariffs on imported Chinese components, and $2 million from favorable foreign currency exchange rates.

[0001069202-20-000039:mdna:103]
Commercial Heating & Cooling

[0001069202-20-000039:mdna:104]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the six months ended June 30, 2020 and 2019 (dollars in millions):

[0001069202-20-000039:mdna:105]
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 366.7 |  |  | $ | 434.7 |  |  | $ | (68.0) |  |  | (15.6) | % |
| Profit | $ | 54.3 |  |  | $ | 68.9 |  |  | $ | (14.6) |  |  | (21.2) | % |
| % of net sales | 14.8 | % |  | 15.9 | % |  |  |  |  |

[0001069202-20-000039:mdna:106]
Net sales decreased 16% in the six months ended June 30, 2020 compared to the six months ended June 30, 2019 due to 17% from lower sales volumes partially offset by favorable mix of 1%.

[0001069202-20-000039:mdna:107]
Segment profit for the six months ended June 30, 2020 decreased $15 million compared to the first six months of 2019 due to $26 million from lower sales volumes, $3 million from unfavorable mix, and $1 million from higher product warranty costs.  Partially offsetting these declines was $6 million of lower SG&A expenses, $4 million from sourcing and engineering-led cost reductions, $3 million from lower commodities costs, $1 million from lower freight and distribution expenses, and $1 million from favorable foreign currency exchange rates.

[0001069202-20-000039:mdna:108]
Refrigeration

[0001069202-20-000039:mdna:109]
The following table presents our Refrigeration segment's net sales and profit for the six months ended June 30, 2019 and 2019 (dollars in millions):

[0001069202-20-000039:mdna:110]
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 211.5 |  |  | $ | 300.1 |  |  | $ | (88.6) |  |  | (29.5) | % |
| Profit | $ | 9.6 |  |  | $ | 27.5 |  |  | $ | (17.9) |  |  | (65.1) | % |
| % of net sales | 4.5 | % |  | 9.2 | % |  |  |  |  |

[0001069202-20-000039:mdna:111]
Net sales decreased 30% in the six months ended June 30, 2020 compared to the six months ended June 30, 2019.  Sales volumes decreased 18%, the loss of sales from our divested Kysor Warren business contributed 12%, and unfavorable foreign currency exchange rates contributed 1%, which was partially offset by 1% of favorable combined price and mix.

[0001069202-20-000039:mdna:112]
Segment profit for the six months ended June 30, 2020 decreased $18 million compared to the six months ended June 30, 2019 due to $17 million from lower sales volumes, $7 million from lower factory absorption and efficiency, $3 million from other product costs, and $2 million from non-recurring European refrigerant quota sales. Partially offsetting these declines was $5 million of lower SG&A expenses, $2 million from lower commodities costs, $1 million from sourcing and engineering-led cost reductions, $1 million from lower freight and distribution expenses, $1 million from favorable foreign currency exchange rates, and $1 million of higher profit due to the divestiture of the Kysor Warren business.

[0001069202-20-000039:mdna:113]
Corporate and Other

[0001069202-20-000039:mdna:114]
Corporate and other expenses decreased $3 million in the six months ended June 30, 2020 compared to the six months ended June 30, 2019 due to lower salary, incentive compensation and discretionary expenses.

[0001069202-20-000039:mdna:115]
[same as prior period, unchanged from 0001069202-20-000015:mdna:69]

[0001069202-20-000039:mdna:116]
[same as prior period, unchanged from 0001069202-20-000015:mdna:70]

[0001069202-20-000039:mdna:117]
[same as prior period, unchanged from 0001069202-20-000015:mdna:71]

[0001069202-20-000039:mdna:118]
The following table summarizes our cash flow activity for the six months ended June 30, 2020 and 2019 (in millions):

[0001069202-20-000039:mdna:119]
|  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Net cash provided by (used in) operating activities | $ | 6.5 |  |  | $ | (111.0) |  |
| Net cash (used in) provided by investing activities | (44.3) |  |  | 1.9 |  |
| Net cash provided by financing activities | 52.3 |  |  | 97.0 |  |

[0001069202-20-000039:mdna:120]
Net Cash Provided by Operating Activities - We generated cash from operating activities during the six months ended June 30, 2020 primarily due to lower working capital requirements resulting from the business downturn caused by the COVID-19 pandemic. The net cash used in operating activities for the six months ended June 30, 2019 reflects the seasonal increase in working capital requirements.

[0001069202-20-000039:mdna:121]
Net Cash (Used in) Provided by Investing Activities - Capital expenditures were $44 million in the six months ended June 30, 2020 compared to $54 million in the same period of 2019.  Capital expenditures in 2020 were primarily related to the expansion of manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.  For the six months ended June 30, 2019, we also received net proceeds of $44 million for the sale of our Kysor Warren business and insurance recoveries of $13 million to replace property and equipment damaged by the Marshalltown tornado.

[0001069202-20-000039:mdna:122]
Net Cash Provided by Financing Activities - Net cash provided by financing activities in the six months ended June 30, 2020 was $52 million compared to $97 million in the same period of 2019.  The decrease was primarily due to lower net borrowings on our revolving credit facility partially offset by fewer stock repurchases.  We repurchased $100 million of shares for the six months ended June 30, 2020 and returned $59 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000039:mdna:123]
[same as prior period, unchanged from 0001069202-20-000015:mdna:77]

[0001069202-20-000039:mdna:124]
The following table details our lines of credit and financing arrangements as of June 30, 2020 (in millions):

[0001069202-20-000039:mdna:125]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (2) | $ | 306.0 |  |
| Finance lease obligations | 8.5 |  |
| Domestic credit facility (1) | 30.0 |  |
| Debt issuance costs | (0.9) |  |
| Total current maturities of long-term debt | $ | 343.6 |  |
| Long-term debt: |  |
| Finance lease obligations | 26.3 |  |
| Domestic credit facility (1) | 672.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (1.6) |  |
| Total long-term debt | 1,047.2 |  |
| Total debt | $ | 1,390.8 |  |

[0001069202-20-000039:mdna:126]
(1) The available future borrowings on our domestic credit facility are $440.1 million, after being reduced by the outstanding borrowings and $2.4 million in outstanding standby letters of credit.  We also had $29.6 million in outstanding standby letters of credit outside of the domestic credit facility as of June 30, 2020. The domestic credit facility matures in August 2021 and we will seek to extend it prior to the end of its term.

[0001069202-20-000039:mdna:127]
[same as prior period, unchanged from 0001069202-20-000015:mdna:81]

[0001069202-20-000039:mdna:128]
[same as prior period, unchanged from 0001069202-20-000015:mdna:82]

[0001069202-20-000039:mdna:129]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 119.7% at June 30, 2020 from 117.0% at December 31, 2019.

[0001069202-20-000039:mdna:130]
As of June 30, 2020, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-20-000039:mdna:131]
[same as prior period, unchanged from 0001069202-20-000015:mdna:85]

[0001069202-20-000039:mdna:132]
We believe our cash and cash equivalents of $45 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $45 million as of June 30, 2020 was $21 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-20-000039:mdna:133]
Guarantees related to our Debt Obligations

[0001069202-20-000039:mdna:134]
Our senior unsecured notes were issued by Lennox International Inc. (the "Parent") and are unconditionally guaranteed by certain of our subsidiaries (the "Guarantor Subsidiaries") and are not secured by our other subsidiaries.  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001069202-20-000039:mdna:135]
The following combined Parent and Guarantor Subsidiary financial information is presented as of June 30, 2020 and December 31, 2019 and for the three and six months ended June 30, 2020 (in millions):

[0001069202-20-000039:mdna:136]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Current assets | $ | 540.9 |  |  | $ | 594.5 |  |
| Non-current assets | $ | 2,513.0 |  |  | $ | 2,297.8 |  |
| Current liabilities | $ | 528.4 |  |  | $ | 619.7 |  |
| Non-current liabilities | $ | 1,375.1 |  |  | $ | 1,169.4 |  |
| Amounts due to non-guarantor subsidiaries | $ | (299.2) |  |  | $ | (339.2) |  |

[0001069202-20-000039:mdna:137]
|  | For the Three Months Ended June 30, 2020 |  | For the Six Months Ended June 30, 2020 |  | For the Year Ended December 31, 2019 |
| Net sales | $ | 906.1 |  |  | $ | 1,571.1 |  |  | $ | 3,479.8 |  |
| Gross profit | $ | 285.0 |  |  | $ | 431.3 |  |  | $ | 966.6 |  |
| Income from continuing operations | $ | 199.5 |  |  | $ | 238.2 |  |  | $ | 828.4 |  |
| Net income | $ | 199.5 |  |  | $ | 238.2 |  |  | $ | 828.4 |  |
| Net sales to non-guarantor subsidiaries | $ | 78.8 |  |  | $ | 123.1 |  |  | $ | 228.3 |  |

[0001069202-20-000039:mdna:138]
[same as prior period, unchanged from 0001069202-20-000015:mdna:87]

[0001069202-20-000039:mdna:139]
[same as prior period, unchanged from 0001069202-20-000015:mdna:88]

[0001069202-20-000039:mdna:140]
Commitments, Contingencies and Guarantees

[0001069202-20-000039:mdna:141]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000039:mdna:142]
[same as prior period, unchanged from 0001069202-20-000015:mdna:91]

[0001069202-20-000039:mdna:143]
[same as prior period, unchanged from 0001069202-20-000015:mdna:92]
