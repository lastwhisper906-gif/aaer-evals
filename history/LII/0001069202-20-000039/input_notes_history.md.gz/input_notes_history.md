# LII note change history — 0001069202-20-000015 → 0001069202-20-000039


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-07-20):
[0001069202-20-000039:note_history:1]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.
  (was, 2020-04-20, similarity 0.9993):
[0001069202-20-000015:note_history:1]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component

- changed (2020-07-20):
[0001069202-20-000039:note_history:2]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.
  (was, 2020-04-20, similarity 0.8371):
[0001069202-20-000015:note_history:2]
event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

- changed (2020-07-20):
[0001069202-20-000039:note_history:3]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Accrued expenses | $ | 37.5 |  |  | $ | 38.2 |  |
| Other liabilities | 79.4 |  |  | 74.6 |  |
| Total warranty liability | $ | 116.9 |  |  | $ | 112.8 |  |
  (was, 2020-04-20, similarity 0.9741):
[0001069202-20-000015:note_history:3]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Accrued expenses | $ | 37.8 |  |  | $ | 38.2 |  |
| Other liabilities | 76.3 |  |  | 74.6 |  |
| Total warranty liability | $ | 114.1 |  |  | $ | 112.8 |  |

- changed (2020-07-20):
[0001069202-20-000039:note_history:4]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2020 were as follows (in millions):
  (was, 2020-04-20, similarity 0.9404):
[0001069202-20-000015:note_history:4]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2020 were as follows (in millions):

- changed (2020-07-20):
[0001069202-20-000039:note_history:5]
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Warranty claims paid | (15.2) |  |
| Changes resulting from issuance of new warranties | 19.5 |  |
| Changes in estimates associated with pre-existing liabilities | 0.1 |  |
| Changes in foreign currency translation rates and other | (0.3) |  |
| Total warranty liability as of June 30, 2020 | $ | 116.9 |  |
  (was, 2020-04-20, similarity 0.9812):
[0001069202-20-000015:note_history:5]
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Warranty claims paid | (5.9) |  |
| Changes resulting from issuance of new warranties | 8.4 |  |
| Changes in estimates associated with pre-existing liabilities | (0.7) |  |
| Changes in foreign currency translation rates and other | (0.5) |  |
| Total warranty liability as of March 31, 2020 | $ | 114.1 |  |

- changed (2020-07-20):
[0001069202-20-000039:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.
  (was, 2020-04-20, similarity 0.9937):
[0001069202-20-000015:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in (Gains) losses and other expenses, net in the Consolidated Statements of Operations.

- changed (2020-07-20):
[0001069202-20-000039:note_history:7]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Expense (gain) for asbestos-related litigation, net | $ | 1.2 |  |  | $ | 0.4 |  |  | $ | (0.5) |  |  | $ | 1.8 |  |
  (was, 2020-04-20, similarity 0.7627):
[0001069202-20-000015:note_history:7]
|  |  |  |  |  | For the Three Months Ended March 31, |  |  |
|  |  |  |  |  | 2020 |  | 2019 |
| (Gain) expense for asbestos-related litigation, net |  |  |  |  | $ | (1.7) |  |  | $ | 1.4 |  |

- added (2020-07-20):
[0001069202-20-000039:note_history:8]
| (Amounts in millions) | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Insurance recoveries received | $ | — |  |  | $ | 52.0 |  |  | $ | — |  |  | $ | 128.0 |  |
| Losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | — |  |  | 6.2 |  |  | — |  |  | 23.3 |  |
| Factory inefficiencies due to lower productivity | — |  |  | 4.5 |  |  | — |  |  | 8.0 |  |
| Other | 1.0 |  |  | 9.4 |  |  | 2.7 |  |  | 18.4 |  |
| Total losses and expenses | $ | 1.0 |  |  | $ | 20.1 |  |  | $ | 2.7 |  |  | $ | 49.7 |  |
| Presentation in the Consolidated Statements of Operations: |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits | — |  |  | (26.0) |  |  | — |  |  | (65.5) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.0 |  |  | (5.9) |  |  | 2.7 |  |  | (12.8) |  |

- removed (2020-07-20):
[0001069202-20-000015:note_history:9]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering

- removed (2020-07-20):
[0001069202-20-000015:note_history:10]
| (Amounts in millions) | For the Three months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Insurance recoveries received | $ | — |  |  | $ | 76.0 |  |  |  |  |  |
| Less losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | — |  |  | 17.1 |  |  |  |  |  |
| Factory inefficiencies due to lower productivity | — |  |  | 4.0 |  |  |  |  |  |
| Other | 1.6 |  |  | 8.5 |  |  |  |  |  |
| Total losses and expenses | $ | 1.6 |  |  | $ | 29.6 |  |  |  |  |  |
| Presentation in the Consolidated Statements of Operations: |  |  |  |  |  |  |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.6 |  |  | (6.9) |  |  |  |  |  |
| Insurance proceeds for lost profits | — |  |  | (39.5) |  |  |  |  |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-07-20):
[0001069202-20-000039:note_history:11]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2020, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and six months ended June 30, 2020 and 2019, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2020 and 2019 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2019.

- changed (2020-07-20):
[0001069202-20-000039:note_history:12]
The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2020-04-20, similarity 0.7279):
[0001069202-20-000015:note_history:12]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2020, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2020 and 2019, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2020 and 2019, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2020 and 2019, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2020 and 2019 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2019. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2020-07-20):
[0001069202-20-000039:note_history:13]
In response to the COVID-19 pandemic, various national, state, and local governments where we, our suppliers, and our customers operate issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work.  Those decrees have resulted in supply chain disruption and higher employee absenteeism in our factories.
  (was, 2020-04-20, similarity 0.8284):
[0001069202-20-000015:note_history:13]
In response to the COVID-19 pandemic, various national, state, and local governments where we, our suppliers, and our customers operate have issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work.  Those decrees have resulted in supply chain disruption and higher employee absenteeism in our factories.  Additionally, certain of our manufacturing facilities have experienced a short-term suspension of operations for COVID-19 employee health concerns.

- added (2020-07-20):
[0001069202-20-000039:note_history:14]
Additionally, certain of our manufacturing facilities experienced short-term suspensions of operations for COVID-19 employee health concerns.

- added (2020-07-20):
[0001069202-20-000039:note_history:15]
The magnitude of the impact of COVID-19 remains unpredictable and we, therefore, continue to anticipate potential supply chain disruptions, employee absenteeism, short-term suspensions of manufacturing facilities and additional health and safety costs related to the COVID-19 pandemic that could unfavorably impact our business.  Although these disruptions and costs are expected to be temporary, there is significant uncertainty around the duration and overall impact to our business operations.  We believe it is possible that the impact of the COVID-19 pandemic could have a material adverse effect on the results of our operations, financial position and cash flows as of and for the year ended December 31, 2020.

- changed (2020-07-20):
[0001069202-20-000039:note_history:16]
In January 2017, the FASB issued ASU No. 2017-04, Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates step two of the goodwill impairment test and specifies that goodwill impairment should be measured by comparing the fair value of a reporting unit with its carrying amount. Additionally, the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount of net assets should be disclosed. ASU 2017-04 is effective for annual or interim goodwill impairment tests performed in fiscal years beginning after December 15, 2019.  The adoption of ASU 2017-04 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.
In August 2018, the FASB issued ASU No. 2018-15, Intangibles – Internal-Use Software (Topic 350-40): Customer’s Accounting for Implementation Costs incurred in a Cloud Computing Arrangement That is a Service Contract.  ASU 2018-15 provides guidance to determine how implementation costs associated with cloud computing arrangements that are incurred to develop or obtain internal-use software should be capitalized or expensed as incurred. ASU 2018-15 is effective for fiscal years beginning after December 15, 2019.  The adoption of ASU 2018-15 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.
  (was, 2020-04-20, similarity 0.9956):
[0001069202-20-000015:note_history:16]
In January 2017, the FASB issued ASU No. 2017-04, Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates step two of the goodwill impairment test and specifies that goodwill impairment should be measured by comparing the fair value of a reporting unit with its carrying amount. Additionally, the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount of net assets should be disclosed. ASU 2017-04 is effective for annual or interim goodwill impairment tests performed in fiscal years beginning after December 15, 2019.  The adoption of ASU 2017-04 did not have a material impact on our consolidated results of operations, cash flow, and statement of financial position.
In August 2018, the FASB issued ASU No. 2018-15, Intangibles – Internal-Use Software (Topic 350-40): Customer’s Accounting for Implementation Costs incurred in a Cloud Computing Arrangement That is a Service Contract.  ASU 2018-15 provides guidance to determine how implementation costs associated with cloud computing arrangements that are incurred to develop or obtain internal-use software should be capitalized or expensed as incurred. ASU 2018-15 is effective for fiscal years beginning after December 15, 2019.  The adoption of ASU 2018-15 did not have a material impact on our consolidated results of operations, cash flow, and statement of financial position.

- removed (2020-07-20):
[0001069202-20-000015:note_history:17]
We anticipate potential supply chain disruptions, employee absenteeism and short-term suspensions of manufacturing facilities related to the COVID-19 pandemic that could unfavorably impact our business.  Although these disruptions are expected to be temporary, there is significant uncertainty around the duration and overall impact to our business operations.  We believe it is possible that the impact of the COVID-19 pandemic could have a material adverse effect on the results of our operations, financial position and cash flows as of and for the year ended December 31, 2020.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-20):
[0001069202-20-000039:note_history:18]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 1.36 | % |  | 2.93 | % |
  (was, 2020-04-20, similarity 0.9538):
[0001069202-20-000015:note_history:18]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 2.13 | % |  | 2.93 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-20):
[0001069202-20-000039:note_history:19]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 306.0 |  |  | $ | 285.0 |  |
| Finance lease obligations | 8.5 |  |  | 7.8 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 343.6 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 26.3 |  |  | 25.9 |  |
| Domestic credit facility | 672.5 |  |  | 475.5 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (1.6) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,047.2 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,390.8 |  |  | $ | 1,171.2 |  |
  (was, 2020-04-20, similarity 0.9928):
[0001069202-20-000015:note_history:19]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 215.0 |  |  | $ | 285.0 |  |
| Finance lease obligations | 8.2 |  |  | 7.8 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 252.3 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 26.2 |  |  | 25.9 |  |
| Domestic credit facility | 815.5 |  |  | 475.5 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (1.8) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,189.9 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,442.2 |  |  | $ | 1,171.2 |  |

- changed (2020-07-20):
[0001069202-20-000039:note_history:20]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2020 or December 31, 2019 and there were $1.9 million of borrowings and repayments on these facilities for the six months ended June 30, 2020.  There were no significant borrowings or repayments on these facilities for the six months ended June 30, 2019.
  (was, 2020-04-20, similarity 0.7022):
[0001069202-20-000015:note_history:20]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2020 or December 31, 2019 and there were no proceeds and repayments on these facilities for the three months ended March 31, 2020 or March 31, 2019.

- changed (2020-07-20):
[0001069202-20-000039:note_history:21]
We renewed the ASP in November 2019, extending its term to November 2021 and increasing the maximum securitization amount to a range from $250.0 million to $400.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):
  (was, 2020-04-20, similarity 0.9991):
[0001069202-20-000015:note_history:21]
We renewed the ASP in November 2019, extending its term to November 2021 and increasing the maximum securitization amount to a range from$250.0 million to $400.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- changed (2020-07-20):
[0001069202-20-000039:note_history:22]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 306.0 |  |  | $ | 320.0 |  |
| Less: Beneficial interest transferred | (306.0) |  |  | (285.0) |  |
| Remaining amount available | $ | — |  |  | $ | 35.0 |  |
  (was, 2020-04-20, similarity 0.9824):
[0001069202-20-000015:note_history:22]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 215.0 |  |  | $ | 320.0 |  |
| Less: Beneficial interest transferred | (215.0) |  |  | (285.0) |  |
| Remaining amount available | $ | — |  |  | $ | 35.0 |  |

- changed (2020-07-20):
[0001069202-20-000039:note_history:23]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average
  (was, 2020-04-20, similarity 0.8051):
[0001069202-20-000015:note_history:23]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of

- changed (2020-07-20):
[0001069202-20-000039:note_history:24]
LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2020 and December 31, 2019 were 1.02% and 2.51%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2020-04-20, similarity 0.8645):
[0001069202-20-000015:note_history:24]
0.70%. The average rates as of March 31, 2020 and December 31, 2019 were 2.23% and 2.51%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2020-07-20):
[0001069202-20-000039:note_history:25]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2020, we believe we were in compliance with all covenant requirements.
  (was, 2020-04-20, similarity 0.9918):
[0001069202-20-000015:note_history:25]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of March 31, 2020, we believe we were in compliance with all covenant requirements.

- added (2020-07-20):
[0001069202-20-000039:note_history:26]
On January 22, 2019, we amended our Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $160.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). We will seek to extend the Maturity Date of the Domestic Credit Facility prior to its expiration.

- changed (2020-07-20):
[0001069202-20-000039:note_history:27]
Under our Domestic Credit Facility, we had outstanding borrowings of $702.5 million, of which $145.0 million was the term loan balance, as well as $2.4 million committed to standby letters of credit as of June 30, 2020. Subject to covenant limitations, $440.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.
  (was, 2020-04-20, similarity 0.7589):
[0001069202-20-000015:note_history:27]
On January 22, 2019, we amended our Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $160.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $845.5 million, of which $160.0 million was the term loan balance, as well as $2.4 million committed to standby letters of credit as of March 31, 2020. Subject to covenant limitations, $312.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

- changed (2020-07-20):
[0001069202-20-000039:note_history:28]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 1.36 | % |  | 2.93 | % |
  (was, 2020-04-20, similarity 0.9538):
[0001069202-20-000015:note_history:28]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 2.13 | % |  | 2.93 | % |

- added (2020-07-20):
[0001069202-20-000039:note_history:29]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due

- added (2020-07-20):
[0001069202-20-000039:note_history:30]
and payable and the lenders’ commitments will automatically terminate). As of June 30, 2020, we believe we were in compliance with all covenant requirements.

- changed (2020-07-20):
[0001069202-20-000039:note_history:31]
Senior Unsecured Notes
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2020, we believe we were in compliance with all covenant requirements.
  (was, 2020-04-20, similarity 0.759):
[0001069202-20-000015:note_history:31]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2020, we believe we were in compliance with all covenant requirements.
Senior Unsecured NotesWe issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2020, we believe we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-20):
[0001069202-20-000039:note_history:32]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 306.0 |  |  | $ | 285.0 |  |
| Finance lease obligations | 8.5 |  |  | 7.8 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 343.6 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 26.3 |  |  | 25.9 |  |
| Domestic credit facility | 672.5 |  |  | 475.5 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (1.6) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,047.2 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,390.8 |  |  | $ | 1,171.2 |  |
  (was, 2020-04-20, similarity 0.9928):
[0001069202-20-000015:note_history:32]
|  | As of March 31, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 215.0 |  |  | $ | 285.0 |  |
| Finance lease obligations | 8.2 |  |  | 7.8 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 252.3 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 26.2 |  |  | 25.9 |  |
| Domestic credit facility | 815.5 |  |  | 475.5 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (1.8) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,189.9 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,442.2 |  |  | $ | 1,171.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-07-20):
[0001069202-20-000039:note_history:33]
|  | For the Three Months Ended June 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 603.8 |  |  | $ | 173.1 |  |  | $ | 61.3 |  |  | $ | 838.2 |  |
| Canada | 41.0 |  |  | 15.0 |  |  | — |  |  | 56.0 |  |
| Other international | — |  |  | 0.2 |  |  | 46.9 |  |  | 47.1 |  |
| Total | $ | 644.8 |  |  | $ | 188.3 |  |  | $ | 108.2 |  |  | $ | 941.3 |  |

- added (2020-07-20):
[0001069202-20-000039:note_history:34]
|  | For the Three Months Ended June 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 647.2 |  |  | $ | 239.1 |  |  | $ | 80.0 |  |  | $ | 966.3 |  |
| Canada | 41.9 |  |  | 21.9 |  |  | — |  |  | 63.8 |  |
| Other international | — |  |  | 0.3 |  |  | 68.7 |  |  | 69.0 |  |
| Total | $ | 689.1 |  |  | $ | 261.3 |  |  | $ | 148.7 |  |  | $ | 1,099.1 |  |

- added (2020-07-20):
[0001069202-20-000039:note_history:35]
|  | For the Six Months Ended June 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,016.2 |  |  | $ | 334.3 |  |  | $ | 120.8 |  |  | $ | 1,471.3 |  |
| Canada | 70.7 |  |  | 32.0 |  |  | — |  |  | $ | 102.7 |  |
| Other international | — |  |  | 0.4 |  |  | 90.7 |  |  | $ | 91.1 |  |
| Total | $ | 1,086.9 |  |  | $ | 366.7 |  |  | $ | 211.5 |  |  | $ | 1,665.1 |  |

- added (2020-07-20):
[0001069202-20-000039:note_history:36]
|  | For the Six Months Ended June 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,080.3 |  |  | $ | 396.4 |  |  | $ | 171.6 |  |  | $ | 1,648.3 |  |
| Canada | 74.3 |  |  | 37.8 |  |  | 0.7 |  |  | 112.8 |  |
| International | — |  |  | 0.5 |  |  | 127.8 |  |  | 128.3 |  |
| Total | $ | 1,154.6 |  |  | $ | 434.7 |  |  | $ | 300.1 |  |  | $ | 1,889.4 |  |

- changed (2020-07-20):
[0001069202-20-000039:note_history:37]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2020 and 2019, direct sales represented 76% and 75% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2020 and 2019, direct sales represented 75% and 74% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2020-04-20, similarity 0.7932):
[0001069202-20-000015:note_history:37]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2020 and 2019, direct sales represented 73% and 72% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2020-07-20):
[0001069202-20-000039:note_history:38]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the
  (was, 2020-04-20, similarity 0.8882):
[0001069202-20-000015:note_history:38]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2020 and 2019, equipment sales represented 84% and 83% of revenues and the remainder of our revenue was generated from our service business.

- added (2020-07-20):
[0001069202-20-000039:note_history:39]
relative fair value of the services provided. For the three months ended June 30, 2020 and 2019, equipment sales represented 86% and 87% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2020 and 2019, equipment sales represented 85% and 85% of revenues, and the remainder of our revenue was generated from our service business.

- added (2020-07-20):
[0001069202-20-000039:note_history:40]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

- changed (2020-07-20):
[0001069202-20-000039:note_history:41]
|  | June 30, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (6.8) |  |  | $ | (8.4) |  |  | $ | 1.6 |  |  | (19.0) | % |
| Contract liabilities - noncurrent | (5.6) |  |  | (5.9) |  |  | 0.3 |  |  | (5.1) | % |
| Total | $ | (12.4) |  |  | $ | (14.3) |  |  | $ | 1.9 |  |  |  |
  (was, 2020-04-20, similarity 0.9353):
[0001069202-20-000015:note_history:41]
|  | March 31, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (8.5) |  |  | $ | (8.4) |  |  | $ | (0.1) |  |  | (1.2) | % |
| Contract liabilities - noncurrent | (5.8) |  |  | (5.9) |  |  | 0.1 |  |  | 1.7 | % |
| Total | $ | (14.3) |  |  | $ | (14.3) |  |  | $ | — |  |  |  |

- changed (2020-07-20):
[0001069202-20-000039:note_history:42]
For the three months ended June 30, 2020 and 2019, we recognized revenue of $2.9 million and $1.5 million and for the six months ended June 30, 2020 and 2019 we recognized revenue of $4.5 million and $2.6 million related to our contract liabilities at January 1, 2020 and 2019, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020 and 2019.
  (was, 2020-04-20, similarity 0.8301):
[0001069202-20-000015:note_history:42]
For the three months ended March 31, 2020 and 2019, we recognized revenue of $1.5 million and $1.1 million related to our contract liabilities at January 1, 2020 and 2019, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020 and 2019.

- removed (2020-07-20):
[0001069202-20-000015:note_history:43]
|  | For the Three Months March 31, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 412.4 |  |  | $ | 161.1 |  |  | $ | 59.5 |  |  | $ | 633.0 |  |
| Canada | 29.7 |  |  | 17.1 |  |  | — |  |  | 46.8 |  |
| Other international | — |  |  | 0.2 |  |  | 43.8 |  |  | 44.0 |  |
| Total | $ | 442.1 |  |  | $ | 178.4 |  |  | $ | 103.3 |  |  | $ | 723.8 |  |

- removed (2020-07-20):
[0001069202-20-000015:note_history:44]
|  | For the Three Months Ended March 31, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 433.2 |  |  | $ | 157.3 |  |  | $ | 91.6 |  |  | $ | 682.1 |  |
| Canada | 32.4 |  |  | 15.9 |  |  | 0.7 |  |  | 49.0 |  |
| Other international | — |  |  | 0.1 |  |  | 59.1 |  |  | 59.2 |  |
| Total | $ | 465.6 |  |  | $ | 173.3 |  |  | $ | 151.4 |  |  | $ | 790.3 |  |

- removed (2020-07-20):
[0001069202-20-000015:note_history:45]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the

- removed (2020-07-20):
[0001069202-20-000015:note_history:46]
practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-07-20):
[0001069202-20-000015:note_history:47]
15. Subsequent Event:Due to the economic impact of the COVID-19 pandemic on our business, we implemented cost reduction actions in April 2020 to realize SG&A savings for the balance of the year.  In connection with these cost saving actions, we expect to incur pre-tax charges of approximately $10 million in the second quarter of 2020 related to personnel severance and benefits and facility exit costs.
