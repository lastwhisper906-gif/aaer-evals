# LII 8-K — 0001069202-20-000037 filed 2020-07-20

## item codes, every 8-K on or before 2020-07-20

- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2020-07-20

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-20-000037:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetabl.htm
EX-99.1

[0001069202-20-000037:8k_2_02:2]
Document

[0001069202-20-000037:8k_2_02:3]
Exhibit-99.1

[0001069202-20-000037:8k_2_02:4]
Lennox International Reports Second Quarter Results and Raises 2020 Guidance

[0001069202-20-000037:8k_2_02:5]
•Revenue down 14%, impacted by the COVID-19 pandemic

[0001069202-20-000037:8k_2_02:6]
•GAAP EPS from continuing operations of $2.62, down 7%

[0001069202-20-000037:8k_2_02:7]
•Adjusted EPS from continuing operations of $2.97, down 21%

[0001069202-20-000037:8k_2_02:8]
•Raising 2020 guidance for adjusted revenue from a decline of 11-17% to a decline of 10-15%

[0001069202-20-000037:8k_2_02:9]
•Raising 2020 guidance for GAAP EPS from continuing operations from $7.07-$8.07 to $7.31-$8.11

[0001069202-20-000037:8k_2_02:10]
•Raising 2020 guidance for adjusted EPS from continuing operations from $7.50-$8.50 to $7.90-$8.70

[0001069202-20-000037:8k_2_02:11]
DALLAS, July 20, 2020 – Lennox International Inc. (NYSE: LII) today reported financial results for the second quarter of 2020. All comparisons are to the prior-year period. The company’s insurance references relate to the July 2018 tornado damage at a Residential manufacturing facility in Iowa. Adjusted revenue and profit exclude non-core Refrigeration businesses divested in prior periods.

[0001069202-20-000037:8k_2_02:12]
For the second quarter of 2020, Lennox International reported revenue of $941 million, down 14%. GAAP operating income was $136 million compared to $214 million in the prior-year quarter. GAAP earnings per share from continuing operations was $2.62 compared to $2.81 in the prior-year quarter. The second quarter of 2019 included an insurance benefit of $26 million and a pension settlement charge of $61 million.

[0001069202-20-000037:8k_2_02:13]
Total adjusted segment profit was $153 million in the second quarter compared to $202 million in the prior-year quarter that included $18 million of insurance benefit. Total adjusted segment margin was 16.3% compared to 18.4% in the prior-year quarter. Adjusted earnings per share from continuing operations was $2.97 compared to $3.74 in the prior-year quarter.

[0001069202-20-000037:8k_2_02:14]
“The COVID-19 pandemic significantly impacted all our businesses in the second quarter, but our Residential business improved each month through the quarter and was up 7% year-over-year in June as the economy continued to re-open and weather heated up,” said Todd Bluedorn, Chairman and CEO. “With hot weather continuing month-to-date in July, we are seeing strong Residential growth on excellent operational execution by the team to capitalize on market opportunities.

[0001069202-20-000037:8k_2_02:15]
“In total for the second quarter, Residential revenue was down 6%. Segment profit was $127 million, down 17% as reported. From an operational perspective excluding $18 million of insurance benefit in the prior-year quarter, segment profit was down 6%. Segment margin was 19.7%, down 260 basis points as reported. On an operational basis, segment margin was up 10 basis points.

[0001069202-20-000037:8k_2_02:16]
“As expected, our commercial-facing businesses were more heavily impacted from the pandemic. In our Commercial business segment, revenue was down 28%, driven primarily by national account customers pushing out orders as previously discussed. Regional and local business was also down significantly in the quarter. Commercial segment profit was down 34%, and segment margin contracted 170 basis points to 18.9%. In the Refrigeration segment, adjusted revenue was down broadly across our businesses in North America and Europe, declining 26% at constant currency. Segment profit was down 53%, and segment margin contracted 460 basis points to 8.2%.

[0001069202-20-000037:8k_2_02:17]
“We continue to face highly uncertain market conditions in the second half of the year, and the company’s stock repurchase program currently remains on hold. Lennox International maintains a strong balance sheet and continues to expect a strong year of cash generation, targeting approximately $340 million of

[0001069202-20-000037:8k_2_02:18]
free cash flow. The company has executed well on its $115 million of in-year SG&A savings for 2020 and managed decremental total adjusted segment profit margin of 20% on an operational basis in the second quarter. We are raising our financial guidance for 2020 and now expect adjusted revenue to be down 10-15% and adjusted EPS from continuing operations of $7.90-$8.70. Lennox has a focused and seasoned team with experience managing through economic downturns while continuing to invest and advance the company’s position to capitalize on share gains and market opportunities.”

[0001069202-20-000037:8k_2_02:19]
FINANCIAL HIGHLIGHTS

[0001069202-20-000037:8k_2_02:20]
Revenue: Revenue was $941 million in the second quarter, down 14%. Foreign exchange was neutral to revenue. Volume was down, and price and mix were favorable to revenue.

[0001069202-20-000037:8k_2_02:21]
Gross Profit: Gross profit was $276 million on a GAAP basis and $275 million on an adjusted basis, both compared to $332 million in the prior-year quarter. GAAP gross margin was 29.3% and adjusted gross margin was 29.2%, compared to 30.2% in the prior-year quarter. Gross profit was impacted by lower volume due to the COVID-19 pandemic, lower factory absorption, higher warranty expense, and unfavorable mix.

[0001069202-20-000037:8k_2_02:22]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the second quarter was $100.6 million, or $2.62 per share, compared to $111.0 million, or $2.81 per share, in the prior-year quarter.

[0001069202-20-000037:8k_2_02:23]
Adjusted income from continuing operations in the second quarter was $114.0 million, or $2.97 per share, compared to $147.6 million, or $3.74 per share, in the prior-year quarter. Adjusted income from continuing operations for the second quarter of 2020 excludes net after-tax charges of $13.4 million, consisting of: $7.9 million for restructuring activities, $2.6 million for personal protective equipment and facility deep cleaning expenses incurred due to the COVID-19 pandemic, and a net $2.9 million in charges for various other items.

[0001069202-20-000037:8k_2_02:24]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from operations in the second quarter was $105 million, compared to $30 million in the prior-year quarter. Capital expenditures were $19 million in the second quarter, compared to $16 million in the prior-year quarter that also had approximately $6 million in proceeds from insurance and property disposals. Free cash flow was approximately $87 million compared to $20 million in the second quarter a year ago. Total debt at the end of the second quarter was $1.39 billion. Total cash, cash equivalents and short-term investments were $49 million at the end of June. In the second quarter, the company paid approximately $30 million in dividends.

[0001069202-20-000037:8k_2_02:25]
BUSINESS SEGMENT HIGHLIGHTS

[0001069202-20-000037:8k_2_02:26]
Residential Heating & Cooling

[0001069202-20-000037:8k_2_02:27]
Revenue in the Residential Heating & Cooling business segment was $645 million, down 6%. Foreign exchange was neutral. Segment profit was $127 million, compared to $153 million in the prior-year quarter that included $18 million of insurance benefit. Segment margin was 19.7%. In the prior-year quarter, segment margin was 22.3% as reported or 19.6% excluding the $18 million insurance benefit. Residential results were negatively impacted by the year-over-year difference in insurance benefit, higher warranty expense, and the COVID-19 pandemic that led to lower volume and factory inefficiencies. Partial offsets included favorable price and mix, lower material, freight and distribution costs, and lower SG&A expense.

[0001069202-20-000037:8k_2_02:28]
Commercial Heating & Cooling

[0001069202-20-000037:8k_2_02:29]
Revenue in the Commercial Heating & Cooling business segment was $188 million, down 28%. Foreign exchange was neutral. Segment margin was 18.9% compared to 20.6% in the prior-year quarter. Segment profit was $36 million compared to $54 million in the prior-year quarter. Commercial results were negatively impacted by unfavorable mix, higher warranty expense, and the COVID-19 pandemic that led to lower volume.  Partial offsets included lower material, freight and distribution costs, and lower SG&A expense.

[0001069202-20-000037:8k_2_02:30]
Refrigeration

[0001069202-20-000037:8k_2_02:31]
Adjusted revenue in the Refrigeration business segment was $108 million, down 27%. Foreign exchange had a negative 1% impact on revenue. Adjusted segment profit was $9 million compared to $19 million in the prior-year quarter. Segment margin was 8.2% compared to 12.8% in the prior-year quarter. Refrigeration results were negatively impacted by higher warranty expense and the COVID-19 pandemic that led to lower volume and factory inefficiencies. Partial offsets included lower material, freight and distribution costs, lower SG&A expense, and favorable foreign exchange.

[0001069202-20-000037:8k_2_02:32]
FULL-YEAR GUIDANCE

[0001069202-20-000037:8k_2_02:33]
The company is updating its 2020 guidance and raising estimates for revenue and EPS from continuing operations.

[0001069202-20-000037:8k_2_02:34]
•Raising guidance for adjusted revenue to be down 10-15% from the prior year compared to previous guidance to be down 11-17%.

[0001069202-20-000037:8k_2_02:35]
•Raising guidance for GAAP EPS from continuing operations to $7.31-$8.11 from previous guidance of $7.07-$8.07.

[0001069202-20-000037:8k_2_02:36]
•Raising guidance for adjusted EPS from continuing operations to $7.90-$8.70 from previous guidance of $7.50-$8.50.

[0001069202-20-000037:8k_2_02:37]
•Corporate expense is still expected to be approximately $75 million.

[0001069202-20-000037:8k_2_02:38]
•The effective tax rate is still expected to be 21-22% on an adjusted basis for the full year.

[0001069202-20-000037:8k_2_02:39]
•Capital expenditures are still targeted to be $120 million.

[0001069202-20-000037:8k_2_02:40]
•Guidance for free cash flow remains approximately $340 million.

[0001069202-20-000037:8k_2_02:41]
•The company’s remaining 2020 stock repurchase program of $300 million currently remains on hold; the company repurchased $100 million of stock in the first quarter.

[0001069202-20-000037:8k_2_02:42]
•The company’s quarterly dividend plans remain unchanged at $0.77 per share, or more than $115 million in total for the year.

[0001069202-20-000037:8k_2_02:43]
CONFERENCE CALL INFORMATION

[0001069202-20-000037:8k_2_02:44]
A conference call to discuss the company’s second-quarter results and outlook will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 844-721-7239 (U.S.) or 409-207-6953 (international) at least 10 minutes prior to the scheduled start time and use participant code 5188986. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from approximately 11:00 a.m. Central time on July 20 through August 3, 2020 by dialing 866-207-1041 (U.S.) or 402-970-0847 (international) and using access code 2654797. The call also will be archived on the company’s website.

[0001069202-20-000037:8k_2_02:45]
About Lennox International

[0001069202-20-000037:8k_2_02:46]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-20-000037:8k_2_02:47]
FORWARD-LOOKING STATEMENTS

[0001069202-20-000037:8k_2_02:48]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000037:8k_2_02:49]
Consolidated Statements of Operations

[0001069202-20-000037:8k_2_02:50]
(Unaudited)

[0001069202-20-000037:8k_2_02:51]
| (Amounts in millions, except per share data) | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales | $ | 941.3 |  |  | $ | 1,099.1 |  |  | $ | 1,665.1 |  |  | $ | 1,889.4 |  |
| Cost of goods sold | 665.6 |  |  | 767.0 |  |  | 1,223.7 |  |  | 1,355.8 |  |
| Gross profit | 275.7 |  |  | 332.1 |  |  | 441.4 |  |  | 533.6 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 129.5 |  |  | 152.4 |  |  | 260.8 |  |  | 298.2 |  |
| Losses (gains) and other expenses, net | 3.6 |  |  | 2.1 |  |  | 2.3 |  |  | 3.2 |  |
| Restructuring charges | 10.0 |  |  | (0.1) |  |  | 10.5 |  |  | 0.4 |  |
| Loss on sale of business | — |  |  | 0.4 |  |  | — |  |  | 8.8 |  |
| Insurance proceeds for lost profits | — |  |  | (26.0) |  |  | — |  |  | (65.5) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.0 |  |  | (5.9) |  |  | 2.7 |  |  | (12.8) |  |
| Income from equity method investments | (4.4) |  |  | (4.6) |  |  | (7.2) |  |  | (7.2) |  |
| Operating income | 136.0 |  |  | 213.8 |  |  | 172.3 |  |  | 308.5 |  |
| Pension settlement | — |  |  | 60.6 |  |  | — |  |  | 60.6 |  |
| Interest expense, net | 6.9 |  |  | 13.1 |  |  | 15.6 |  |  | 23.9 |  |
| Other expense (income), net | 1.1 |  |  | 0.3 |  |  | 2.2 |  |  | 1.2 |  |
| Income from continuing operations before income taxes | 128.0 |  |  | 139.8 |  |  | 154.5 |  |  | 222.8 |  |
| Provision for income taxes | 27.4 |  |  | 28.8 |  |  | 41.4 |  |  | 42.4 |  |
| Income from continuing operations | 100.6 |  |  | 111.0 |  |  | 113.1 |  |  | 180.4 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes | (0.8) |  |  | (0.3) |  |  | (0.8) |  |  | (0.4) |  |
| Income tax benefit | (0.2) |  |  | — |  |  | (0.6) |  |  | — |  |
| Loss from discontinued operations | (0.6) |  |  | (0.3) |  |  | (0.2) |  |  | (0.4) |  |
| Net income | $ | 100.0 |  |  | $ | 110.7 |  |  | $ | 112.9 |  |  | $ | 180.0 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.63 |  |  | $ | 2.84 |  |  | $ | 2.95 |  |  | $ | 4.58 |  |
| Loss from discontinued operations | (0.01) |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net income | $ | 2.62 |  |  | $ | 2.83 |  |  | $ | 2.95 |  |  | $ | 4.57 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.62 |  |  | $ | 2.81 |  |  | $ | 2.93 |  |  | $ | 4.53 |  |
| Loss from discontinued operations | (0.02) |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net income | $ | 2.60 |  |  | $ | 2.80 |  |  | $ | 2.93 |  |  | $ | 4.52 |  |
| Weighted Average Number of Shares Outstanding - Basic | 38.2 |  |  | 39.1 |  |  | 38.3 |  |  | 39.4 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 38.4 |  |  | 39.5 |  |  | 38.6 |  |  | 39.8 |  |

[0001069202-20-000037:8k_2_02:52]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |
| Adjusted Segment Net Sales and Profit (Loss) |  |  |  |
| (Unaudited) |  |  |  |

[0001069202-20-000037:8k_2_02:53]
| (Amounts in millions) | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 644.8 |  |  | $ | 689.1 |  |  | $ | 1,086.9 |  |  | $ | 1,154.6 |  |
| Commercial Heating & Cooling | 188.3 |  |  | 261.3 |  |  | 366.7 |  |  | 434.7 |  |
| Refrigeration (1) | 108.2 |  |  | 148.7 |  |  | $ | 211.5 |  |  | 265.8 |  |
|  | $ | 941.3 |  |  | $ | 1,099.1 |  |  | $ | 1,665.1 |  |  | $ | 1,855.1 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 127.3 |  |  | $ | 153.4 |  |  | $ | 159.8 |  |  | $ | 240.1 |  |
| Commercial Heating & Cooling | 35.6 |  |  | 53.9 |  |  | 54.3 |  |  | 68.9 |  |
| Refrigeration (1) | 8.9 |  |  | 19.1 |  |  | 9.6 |  |  | 28.5 |  |
| Corporate and other | (18.8) |  |  | (24.1) |  |  | (33.1) |  |  | (36.2) |  |
| Total adjusted segment profit | 153.0 |  |  | 202.3 |  |  | 190.6 |  |  | 301.3 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Special product quality adjustments | (1.0) |  |  | (0.5) |  |  | (1.0) |  |  | (0.5) |  |
| Loss on sale of business | — |  |  | 0.4 |  |  | — |  |  | 8.8 |  |
| Partial advance of insurance recoveries related to lost profits | — |  |  | (8.0) |  |  | — |  |  | (8.0) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.0 |  |  | (5.9) |  |  | 2.7 |  |  | (12.8) |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 7.0 |  |  | 2.6 |  |  | 6.1 |  |  | 3.9 |  |
| Restructuring charges | 10.0 |  |  | (0.1) |  |  | 10.5 |  |  | 0.4 |  |
| Operating loss from non-core business (1) | — |  |  | — |  |  | — |  |  | 1.0 |  |
| Operating income | $ | 136.0 |  |  | $ | 213.8 |  |  | $ | 172.3 |  |  | $ | 308.5 |  |

[0001069202-20-000037:8k_2_02:54]
(1) Excludes the non-core business results related to Kysor Warren, which was sold in March 2019.

[0001069202-20-000037:8k_2_02:55]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-20-000037:8k_2_02:56]
•The following items in Losses (gains) and other expenses, net:

[0001069202-20-000037:8k_2_02:57]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001069202-20-000037:8k_2_02:58]
◦Special legal contingency charges,

[0001069202-20-000037:8k_2_02:59]
◦Asbestos-related litigation,

[0001069202-20-000037:8k_2_02:60]
◦Environmental liabilities,

[0001069202-20-000037:8k_2_02:61]
◦Charges incurred related to COVID-19 pandemic,

[0001069202-20-000037:8k_2_02:62]
◦Other items, net,

[0001069202-20-000037:8k_2_02:63]
•Loss on sale of business,

[0001069202-20-000037:8k_2_02:64]
•Special product quality adjustments,

[0001069202-20-000037:8k_2_02:65]
•Partial advance of insurance recoveries related to lost profits,

[0001069202-20-000037:8k_2_02:66]
•Loss (gain) from natural disaster, net of insurance recoveries,

[0001069202-20-000037:8k_2_02:67]
•Operating loss (income) from non-core businesses; and

[0001069202-20-000037:8k_2_02:68]
•Restructuring charges.

[0001069202-20-000037:8k_2_02:69]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000037:8k_2_02:70]
Consolidated Balance Sheets

[0001069202-20-000037:8k_2_02:71]
| (Amounts in millions, except shares and par values) | As of June 30, 2020 |  | As of December 31, 2019 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 44.8 |  |  | $ | 37.3 |  |
| Short-term investments | 3.8 |  |  | 2.9 |  |
| Accounts and notes receivable, net of allowances of $7.2 and $6.1 in 2020 and 2019, respectively | 624.2 |  |  | 477.8 |  |
| Inventories, net | 499.7 |  |  | 544.1 |  |
| Other assets | 54.4 |  |  | 58.8 |  |
| Total current assets | 1,226.9 |  |  | 1,120.9 |  |
| Property, plant and equipment, net of accumulated depreciation of $848.5 and $824.3 in 2020 and 2019, respectively | 441.2 |  |  | 445.4 |  |
| Right-of-use assets from operating leases | 177.1 |  |  | 181.6 |  |
| Goodwill | 186.5 |  |  | 186.5 |  |
| Deferred income taxes | 15.5 |  |  | 21.5 |  |
| Other assets, net | 77.1 |  |  | 79.0 |  |
| Total assets | $ | 2,124.3 |  |  | $ | 2,034.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 343.6 |  |  | 321.9 |  |
| Current operating lease liabilities | 52.0 |  |  | 52.7 |  |
| Accounts payable | 295.0 |  |  | 372.4 |  |
| Accrued expenses | 251.0 |  |  | 255.7 |  |
| Income taxes payable | 4.6 |  |  | — |  |
| Total current liabilities | 946.2 |  |  | 1,002.7 |  |
| Long-term debt | 1,047.2 |  |  | 849.3 |  |
| Long-term operating lease liabilities | 127.9 |  |  | 131.0 |  |
| Pensions | 91.8 |  |  | 87.4 |  |
| Other liabilities | 140.1 |  |  | 134.7 |  |
| Total liabilities | 2,353.2 |  |  | 2,205.1 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,102.4 |  |  | 1,093.5 |  |
| Retained earnings | 2,201.5 |  |  | 2,148.7 |  |
| Accumulated other comprehensive loss | (121.7) |  |  | (103.8) |  |
| Treasury stock, at cost, 48,919,279 shares and 48,575,901 shares for 2020 and 2019, respectively | (3,412.0) |  |  | (3,309.5) |  |
| Total stockholders' deficit | (228.9) |  |  | (170.2) |  |
| Total liabilities and stockholders' deficit | $ | 2,124.3 |  |  | $ | 2,034.9 |  |

[0001069202-20-000037:8k_2_02:72]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000037:8k_2_02:73]
Consolidated Statements of Cash Flows

[0001069202-20-000037:8k_2_02:74]
(Unaudited)

[0001069202-20-000037:8k_2_02:75]
| (Amounts in millions) | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 112.9 |  |  | $ | 180.0 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Loss on sale of business | — |  |  | 8.8 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | (12.8) |  |
| Income from equity method investments | (7.2) |  |  | (7.2) |  |
| Dividends from affiliates | 2.5 |  |  | 2.0 |  |
| Restructuring charges, net of cash paid | 5.9 |  |  | (0.2) |  |
| Provision for bad debts | 3.1 |  |  | 2.2 |  |
| Unrealized losses (gains), net on derivative contracts | 1.1 |  |  | (0.2) |  |
| Stock-based compensation expense | 10.4 |  |  | 11.4 |  |
| Depreciation and amortization | 37.9 |  |  | 34.9 |  |
| Deferred income taxes | 6.6 |  |  | 15.7 |  |
| Pension expense | 4.9 |  |  | 64.2 |  |
| Pension contributions | (1.2) |  |  | (1.0) |  |
| Other items, net | 0.7 |  |  | (0.1) |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (151.5) |  |  | (270.0) |  |
| Inventories | 43.1 |  |  | (149.9) |  |
| Other current assets | (1.1) |  |  | 10.2 |  |
| Accounts payable | (66.2) |  |  | 52.6 |  |
| Accrued expenses | (11.9) |  |  | (21.0) |  |
| Income taxes payable / receivable | 10.2 |  |  | (11.5) |  |
| Other, net | 6.3 |  |  | (19.1) |  |
| Net cash provided by (used in) operating activities | 6.5 |  |  | (111.0) |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.3 |  |  | 0.8 |  |
| Purchases of property, plant and equipment | (43.5) |  |  | (53.5) |  |
| Net proceeds from sale of business | — |  |  | 43.6 |  |
| Purchases of short-term investments | (1.1) |  |  | (1.8) |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 12.8 |  |
| Net cash (used in) provided by investing activities | (44.3) |  |  | 1.9 |  |
| Cash flows from financing activities: |  |  |  |
| Short-term debt payments | (1.9) |  |  | (2.1) |  |
| Short-term debt proceeds | 1.9 |  |  | 2.1 |  |
| Asset securitization borrowings | 91.0 |  |  | 65.5 |  |
| Asset securitization payments | (70.0) |  |  | (43.5) |  |
| Long-term debt payments | (2.6) |  |  | (33.3) |  |
| Long-term debt borrowings | — |  |  | — |  |
| Borrowings from credit facility | 1,060.5 |  |  | 1,459.5 |  |
| Payments on credit facility | (863.5) |  |  | (1,037.5) |  |
| Proceeds from employee stock purchases | 1.6 |  |  | 1.6 |  |
| Repurchases of common stock | (100.0) |  |  | (250.0) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (5.6) |  |  | (14.5) |  |
| Cash dividends paid | (59.1) |  |  | (50.8) |  |
| Net cash provided by financing activities | 52.3 |  |  | 97.0 |  |
| Increase (decrease) in cash and cash equivalents | 14.5 |  |  | (12.1) |  |
| Effect of exchange rates on cash and cash equivalents | (7.0) |  |  | 2.2 |  |
| Cash and cash equivalents, beginning of period | 37.3 |  |  | 46.3 |  |
| Cash and cash equivalents, end of period | $ | 44.8 |  |  | $ | 36.4 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 16.9 |  |  | $ | 23.5 |  |
| Income taxes paid (net of refunds) | $ | 22.8 |  |  | $ | 54.2 |  |
| Insurance recoveries received | $ | — |  |  | $ | 128.0 |  |

[0001069202-20-000037:8k_2_02:76]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |  |  |  |  |  |  |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |  |  |  |  |  |  |  |  |  |  |  |
| (Unaudited, in millions, except per share and ratio data) |  |  |  |  |  |  |  |  |  |  |  |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. During the first quarter of 2019, the Company completed the sale of its Kysor Warren business. The results from operations for this business have been shown in the tables below as “Non-core business results”. |  |  |  |  |  |  |  |  |  |  |  |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |  |  |  |  |  |  |  |  |  |  |  |
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |  |  |  |  |
| Income from continuing operations, a GAAP measure | $ | 128.0 |  | $ | (27.4) |  | $ | 100.6 |  |  | $ | 139.8 |  | $ | (28.8) |  | $ | 111.0 |  |  |  |  |  |
| Restructuring charges | 10.0 |  | (2.1) |  | 7.9 |  |  | (0.1) |  | — |  | (0.1) |  |  |  |  |  |
| Pension settlement | — |  | — |  | — |  |  | 60.6 |  | (15.1) |  | 45.5 |  |  |  |  |  |
| Special product quality adjustments (b) | (1.0) |  | 0.2 |  | (0.8) |  |  | (0.5) |  | 0.1 |  | (0.4) |  |  |  |  |  |
| Special legal contingency charges (a) | 0.7 |  | (0.1) |  | 0.6 |  |  | (0.1) |  | — |  | (0.1) |  |  |  |  |  |
| Asbestos-related litigation (a) | 1.2 |  | (0.3) |  | 0.9 |  |  | 0.4 |  | (0.1) |  | 0.3 |  |  |  |  |  |
| Net change in unrealized losses on unsettled futures contracts (a) | 0.8 |  | (0.1) |  | 0.7 |  |  | 0.1 |  | — |  | 0.1 |  |  |  |  |  |
| Environmental liabilities (a) | 1.1 |  | (0.2) |  | 0.9 |  |  | 1.3 |  | (0.3) |  | 1.0 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) | — |  | (0.1) |  | (0.1) |  |  | — |  | (1.0) |  | (1.0) |  |  |  |  |  |
| Other tax items, net (c) | — |  | — |  | — |  |  | — |  | 0.6 |  | 0.6 |  |  |  |  |  |
| Loss on sale of business | — |  | — |  | — |  |  | 0.4 |  | (0.1) |  | 0.3 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) | 3.4 |  | (0.8) |  | 2.6 |  |  | — |  | — |  | — |  |  |  |  |  |
| Partial advance of insurance recoveries related to lost profits (f) | — |  | — |  | — |  |  | (8.0) |  | 2.3 |  | (5.7) |  |  |  |  |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.0 |  | (0.2) |  | 0.8 |  |  | (5.9) |  | 1.2 |  | (4.7) |  |  |  |  |  |
| Other items, net (a) | (0.2) |  | 0.1 |  | (0.1) |  |  | 0.9 |  | (0.1) |  | 0.8 |  |  |  |  |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 145.0 |  | $ | (31.0) |  | $ | 114.0 |  |  | $ | 188.9 |  | $ | (41.3) |  | $ | 147.6 |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  | $ | 2.62 |  |  |  |  | $ | 2.81 |  |  |  |  |  |
| Restructuring charges |  |  | 0.21 |  |  |  |  | — |  |  |  |  |  |
| Pension settlement |  |  | — |  |  |  |  | 1.14 |  |  |  |  |  |
| Special product quality adjustments (b) |  |  | (0.02) |  |  |  |  | (0.01) |  |  |  |  |  |
| Special legal contingency charges (a) |  |  | 0.01 |  |  |  |  | — |  |  |  |  |  |
| Asbestos-related litigation (a) |  |  | 0.02 |  |  |  |  | 0.01 |  |  |  |  |  |
| Net change in unrealized losses on unsettled futures contracts (a) |  |  | 0.02 |  |  |  |  | — |  |  |  |  |  |
| Environmental liabilities (a) |  |  | 0.02 |  |  |  |  | 0.03 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  |  | (0.03) |  |  |  |  |  |
| Other tax items, net (c) |  |  | — |  |  |  |  | 0.02 |  |  |  |  |  |
| Loss on sale of business |  |  | — |  |  |  |  | 0.01 |  |  |  |  |  |

[0001069202-20-000037:8k_2_02:77]
| Charges incurred related to COVID-19 pandemic (a) |  |  | 0.07 |  |  |  |  | — |  |  |  |  |  |
| Partial advance of insurance recoveries related to lost profits (f) |  |  | — |  |  |  |  | (0.14) |  |  |  |  |  |
| Loss (gain) from natural disaster, net of insurance recoveries |  |  | 0.02 |  |  |  |  | (0.13) |  |  |  |  |  |
| Other items, net (a) |  |  | — |  |  |  |  | 0.02 |  |  |  |  |  |
| Change in share counts from share-based compensation (d) |  |  | — |  |  |  |  | 0.01 |  |  |  |  |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 2.97 |  |  |  |  | $ | 3.74 |  |  |  |  |  |
| (a) Recorded in (Gains) losses and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount.. |  |  |  |  |  |  |  |  |  |  |  |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |  |  |  |  |  |  |  |  |  |  |  |
| (f) Recorded in Insurance proceeds for lost profits in the Consolidated Statement of Operations. |  |  |  |  |  |  |  |  |  |  |  |
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |  |  |  |  |
| Income from continuing operations, a GAAP measure | $ | 154.5 |  | $ | (41.4) |  | $ | 113.1 |  |  | $ | 222.8 |  | $ | (42.4) |  | $ | 180.4 |  |  |  |  |  |
| Restructuring charges | 10.5 |  | (2.2) |  | 8.3 |  |  | 0.4 |  | (0.1) |  | 0.3 |  |  |  |  |  |
| Pension settlement | — |  | — |  | — |  |  | 60.6 |  | (15.1) |  | 45.5 |  |  |  |  |  |
| Special product quality adjustments (b) | (1.0) |  | 0.2 |  | (0.8) |  |  | (0.5) |  | 0.1 |  | (0.4) |  |  |  |  |  |
| Special legal contingency charges (a) | 0.7 |  | (0.1) |  | 0.6 |  |  | 0.2 |  | (0.1) |  | 0.1 |  |  |  |  |  |
| Asbestos-related litigation (a) | (0.5) |  | 0.1 |  | (0.4) |  |  | 1.8 |  | (0.4) |  | 1.4 |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (a) | 1.4 |  | (0.3) |  | 1.1 |  |  | (0.3) |  | 0.1 |  | (0.2) |  |  |  |  |  |
| Environmental liabilities (a) | 1.3 |  | (0.3) |  | 1.0 |  |  | 1.3 |  | (0.3) |  | 1.0 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) | — |  | — |  | — |  |  | — |  | (5.3) |  | (5.3) |  |  |  |  |  |
| Other tax items, net (c) | — |  | 8.1 |  | 8.1 |  |  | — |  | 0.6 |  | 0.6 |  |  |  |  |  |
| Loss on sale of business | — |  | — |  | — |  |  | 8.8 |  | (3.5) |  | 5.3 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) | 3.4 |  | (0.8) |  | 2.6 |  |  | — |  | — |  | — |  |  |  |  |  |
| Partial advance of insurance recoveries related to lost profits (f) | — |  | — |  | — |  |  | (8.0) |  | 2.3 |  | (5.7) |  |  |  |  |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 2.7 |  | (0.6) |  | 2.1 |  |  | (12.8) |  | 2.9 |  | (9.9) |  |  |  |  |  |
| Other items, net (a) | (0.2) |  | 0.1 |  | (0.1) |  |  | 0.9 |  | (0.2) |  | 0.7 |  |  |  |  |  |
| Non-core business results (g) | — |  | — |  | — |  |  | 1.3 |  | (0.3) |  | 1.0 |  |  |  |  |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 172.8 |  | $ | (37.2) |  | $ | 135.6 |  |  | $ | 276.5 |  | $ | (61.7) |  | $ | 214.8 |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  | $ | 2.93 |  |  |  |  | $ | 4.53 |  |  |  |  |  |
| Restructuring charges |  |  | 0.21 |  |  |  |  | 0.01 |  |  |  |  |  |
| Pension settlement |  |  | — |  |  |  |  | 1.14 |  |  |  |  |  |
| Special product quality adjustments (b) |  |  | (0.02) |  |  |  |  | (0.01) |  |  |  |  |  |
| Special legal contingency charges (a) |  |  | 0.02 |  |  |  |  | — |  |  |  |  |  |
| Asbestos-related litigation (a) |  |  | (0.01) |  |  |  |  | 0.04 |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (a) |  |  | 0.03 |  |  |  |  | (0.01) |  |  |  |  |  |

[0001069202-20-000037:8k_2_02:78]
| Environmental liabilities (a) |  |  | 0.03 |  |  |  |  | 0.03 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  |  | (0.13) |  |  |  |  |  |
| Other tax items, net (c) |  |  | 0.21 |  |  |  |  | 0.02 |  |  |  |  |  |
| Loss on sale of business |  |  | — |  |  |  |  | 0.13 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) |  |  | 0.07 |  |  |  |  | — |  |  |  |  |  |
| Partial advance of insurance recoveries related to lost profits (f) |  |  | — |  |  |  |  | (0.14) |  |  |  |  |  |
| Loss (gain) from natural disaster, net of insurance recoveries |  |  | 0.05 |  |  |  |  | (0.26) |  |  |  |  |  |
| Other items, net (a) |  |  | — |  |  |  |  | 0.02 |  |  |  |  |  |
| Non-core business results (g) |  |  | — |  |  |  |  | 0.03 |  |  |  |  |  |
| Change in share counts from share-based compensation (d) |  |  | — |  |  |  |  | 0.01 |  |  |  |  |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 3.52 |  |  |  |  | $ | 5.41 |  |  |  |  |  |
| (a) Recorded in Losses (Gains) and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |  |  |  |  |  |  |  |  |  |  |  |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |  |  |  |  |  |  |  |  |  |  |  |
| (f) Recorded in Insurance proceeds for lost profits in the Consolidated Statement of Operations. |  |  |  |  |  |  |  |  |  |  |  |
| (g) Non-core business results represent Kysor Warren business, not included elsewhere in the reconciliation. |  |  |  |  |  |  |  |  |  |  |  |

[0001069202-20-000037:8k_2_02:79]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |
| Foreign currency exchange gains (a) | (2.1) |  |  | (0.2) |  |  | (2.6) |  |  | (0.7) |  |
| Gain on disposal of fixed assets (a) | (0.2) |  |  | (0.4) |  |  | (0.1) |  |  | (0.2) |  |
| Other operating income (a) | (1.2) |  |  | — |  |  | (1.3) |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) | 0.8 |  |  | 0.1 |  |  | 1.4 |  |  | (0.3) |  |
| Special legal contingency charges (b) | 0.7 |  |  | (0.1) |  |  | 0.7 |  |  | 0.2 |  |
| Asbestos-related litigation (b) | 1.2 |  |  | 0.4 |  |  | (0.5) |  |  | 1.8 |  |
| Environmental liabilities (b) | 1.1 |  |  | 1.3 |  |  | 1.3 |  |  | 1.3 |  |
| Charges incurred related to COVID-19 pandemic (b) | 3.4 |  |  | — |  |  | 3.4 |  |  | — |  |
| Other items, net (b) | (0.2) |  |  | 0.9 |  |  | (0.2) |  |  | 0.9 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.6 |  |  | $ | 2.1 |  |  | $ | 2.3 |  |  | $ | 3.2 |  |

[0001069202-20-000037:8k_2_02:80]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |  |  |  |  |  |  |  |  |  |  |  |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |  |  |  |  |  |  |  |  |  |  |  |

[0001069202-20-000037:8k_2_02:81]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |  |  |  |  |  |  |  |
|  |  |  |  |  | For the Year Ended December 31, 2020ESTIMATED |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $7.31 - $8.11 |  |  |
| Other non-core EBIT charges and other non-core tax items, net, incurred in 1Q 2020 and 2Q 2020 |  |  |  |  | (0.59) |  |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  |  |  |  | $7.90 - $8.70 |  |  |

[0001069202-20-000037:8k_2_02:82]
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |  |  |  |  |  |  |  |
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Average shares outstanding - diluted, a GAAP measure | 38.4 |  | $ | 39.5 |  |  | 38.6 |  | $ | 39.8 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | — |  |  | (0.1) |  |  | (0.1) |  |  | (0.1) |  |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 38.4 |  | 39.4 |  |  | 38.5 |  | 39.7 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended June 30, |  |  |  | For the Three Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales, a GAAP measure | $ | 108.2 |  |  | $ | 148.7 |  |  | $ | 941.3 |  |  | $ | 1,099.1 |  |
| Net sales from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted net sales, a Non-GAAP measure | $ | 108.2 |  |  | $ | 148.7 |  |  | $ | 941.3 |  |  | $ | 1,099.1 |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Six Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales, a GAAP measure | $ | 211.5 |  |  | $ | 300.1 |  |  | $ | 1,665.1 |  |  | $ | 1,889.4 |  |
| Net sales from non-core business (a) | — |  |  | 34.3 |  |  | — |  |  | 34.3 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 211.5 |  |  | $ | 265.8 |  |  | $ | 1,665.1 |  |  | $ | 1,855.1 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended June 30, |  |  |  | For the Three Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit, a GAAP measure | $ | 32.2 |  |  | $ | 45.7 |  |  | $ | 275.7 |  |  | $ | 332.1 |  |
| Non-GAAP adjustments to gross profit | — |  |  | — |  |  | 1.0 |  |  | 0.5 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 32.2 |  |  | $ | 45.7 |  |  | $ | 274.7 |  |  | $ | 331.6 |  |

[0001069202-20-000037:8k_2_02:83]
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Six Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit, a GAAP measure | $ | 59.6 |  |  | $ | 88.3 |  |  | $ | 441.4 |  |  | $ | 533.6 |  |
| Non-GAAP adjustments to gross profit | — |  |  | — |  |  | 1.0 |  |  | 0.5 |  |
| Gross profit from non-core business (a) | — |  |  | 3.6 |  |  | — |  |  | 3.6 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 59.6 |  |  | $ | 84.7 |  |  | $ | 440.4 |  |  | $ | 529.5 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended June 30, |  |  |  | For the Three Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment profit, a Non-GAAP measure | $ | 8.9 |  |  | $ | 19.1 |  |  | $ | 153.0 |  |  | $ | 202.3 |  |
| (Loss) profit from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 8.9 |  |  | $ | 19.1 |  |  | $ | 153.0 |  |  | $ | 202.3 |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Six Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment profit, a Non-GAAP measure | $ | 9.6 |  |  | $ | 27.5 |  |  | $ | 190.6 |  |  | $ | 300.3 |  |
| (Loss) profit from non-core business (a) | — |  |  | (1.0) |  |  | — |  |  | (1.0) |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 9.6 |  |  | $ | 28.5 |  |  | $ | 190.6 |  |  | $ | 301.3 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended June 30, |  |  |  | For the Three Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Selling, general and administrative expenses, a GAAP measure | $ | 25.3 |  |  | $ | 29.5 |  |  | $ | 129.5 |  |  | $ | 152.4 |  |
| Selling, general and administrative expenses from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 25.3 |  |  | $ | 29.5 |  |  | $ | 129.5 |  |  | $ | 152.4 |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Six Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Selling, general and administrative expenses, a GAAP measure | $ | 53.6 |  |  | $ | 65.9 |  |  | $ | 260.8 |  |  | $ | 298.2 |  |
| Selling, general and administrative expenses from non-core business (a) | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 53.6 |  |  | $ | 61.3 |  |  | $ | 260.8 |  |  | $ | 293.6 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |

[0001069202-20-000037:8k_2_02:84]
| Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net cash provided by (used in) operating activities, a GAAP measure | $ | 105.3 |  |  | $ | 30.0 |  |  | $ | 6.5 |  |  | $ | (111.0) |  |
| Purchases of property, plant and equipment | (18.8) |  |  | (16.3) |  |  | (43.5) |  |  | (53.5) |  |
| Proceeds from the disposal of property, plant and equipment | 0.2 |  |  | 0.5 |  |  | 0.3 |  |  | 0.8 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 5.9 |  |  | — |  |  | 12.8 |  |
| Free cash flow, a Non-GAAP measure | 86.7 |  |  | 20.1 |  |  | (36.7) |  |  | (150.9) |  |

[0001069202-20-000037:8k_2_02:85]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to June 30, 2020 |
| Adjusted EBIT (a) |  |  |  |  |  |  | $ | 499.2 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  | 73.1 |  |
| EBITDA (a + b) |  |  |  |  |  |  | $ | 572.3 |  |
| Total debt at June 30, 2020 (c) |  |  |  |  |  |  | $ | 1,390.8 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  | 2.4 |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | Trailing Twelve Months to June 30, 2020 |
| Income from continuing operations before income taxes, a GAAP measure |  |  |  |  |  |  | $ | 439.6 |  |
| Items in (Gains) losses and other expenses, net that are excluded from segment profit |  |  |  |  |  |  | 13.6 |  |
| Special product quality adjustments |  |  |  |  |  |  | (1.2) |  |
| Restructuring charges |  |  |  |  |  |  | 20.4 |  |
| Interest expense, net |  |  |  |  |  |  | 39.2 |  |
| Pension settlements |  |  |  |  |  |  | 99.2 |  |
| Loss on sale of business |  |  |  |  |  |  | 1.7 |  |
| Insurance recoveries received for property damage incurred from natural disaster |  |  |  |  |  |  | (56.1) |  |
| Other expense (income), net |  |  |  |  |  |  | (57.2) |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  |  |  |  |  | $ | 499.2 |  |
