# LII notes — 0001069202-20-000039


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-20-000039:notes:1]
[same as prior period, unchanged from 0001069202-20-000015:notes:1]

[0001069202-20-000039:notes:2]
[same as prior period, unchanged from 0001069202-20-000015:notes:2]

[0001069202-20-000039:notes:3]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2020, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and six months ended June 30, 2020 and 2019, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2020 and 2019 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2019.

[0001069202-20-000039:notes:4]
The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-20-000039:notes:5]
[same as prior period, unchanged from 0001069202-20-000015:notes:4]

[0001069202-20-000039:notes:6]
[same as prior period, unchanged from 0001069202-20-000015:notes:5]

[0001069202-20-000039:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-20-000039:notes:8]
[same as prior period, unchanged from 0001069202-20-000015:notes:7]

[0001069202-20-000039:notes:9]
[same as prior period, unchanged from 0001069202-20-000015:notes:8]

[0001069202-20-000039:notes:10]
[same as prior period, unchanged from 0001069202-20-000015:notes:9]

[0001069202-20-000039:notes:11]
In response to the COVID-19 pandemic, various national, state, and local governments where we, our suppliers, and our customers operate issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work.  Those decrees have resulted in supply chain disruption and higher employee absenteeism in our factories.

[0001069202-20-000039:notes:12]
Additionally, certain of our manufacturing facilities experienced short-term suspensions of operations for COVID-19 employee health concerns.

[0001069202-20-000039:notes:13]
The magnitude of the impact of COVID-19 remains unpredictable and we, therefore, continue to anticipate potential supply chain disruptions, employee absenteeism, short-term suspensions of manufacturing facilities and additional health and safety costs related to the COVID-19 pandemic that could unfavorably impact our business.  Although these disruptions and costs are expected to be temporary, there is significant uncertainty around the duration and overall impact to our business operations.  We believe it is possible that the impact of the COVID-19 pandemic could have a material adverse effect on the results of our operations, financial position and cash flows as of and for the year ended December 31, 2020.

[0001069202-20-000039:notes:14]
Recently Adopted Accounting Guidance

[0001069202-20-000039:notes:15]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to estimate credit losses. ASU 2016-13 is effective for SEC filers for interim and annual periods beginning after December 15, 2019.  We adopted ASU 2016-13 using the modified retrospective method for all financial assets measured at amortized cost.  Results for periods after January 1, 2020 are presented under ASU 2016-13 while prior period amounts continue to be reported under previously applicable accounting standards.  We recorded a $1.3 million net decrease to retained earnings as of January 1, 2020 for the cumulative effect of adopting ASU 2016-13.

[0001069202-20-000039:notes:16]
In January 2017, the FASB issued ASU No. 2017-04, Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates step two of the goodwill impairment test and specifies that goodwill impairment should be measured by comparing the fair value of a reporting unit with its carrying amount. Additionally, the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount of net assets should be disclosed. ASU 2017-04 is effective for annual or interim goodwill impairment tests performed in fiscal years beginning after December 15, 2019.  The adoption of ASU 2017-04 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.
In August 2018, the FASB issued ASU No. 2018-15, Intangibles – Internal-Use Software (Topic 350-40): Customer’s Accounting for Implementation Costs incurred in a Cloud Computing Arrangement That is a Service Contract.  ASU 2018-15 provides guidance to determine how implementation costs associated with cloud computing arrangements that are incurred to develop or obtain internal-use software should be capitalized or expensed as incurred. ASU 2018-15 is effective for fiscal years beginning after December 15, 2019.  The adoption of ASU 2018-15 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-20-000039:notes:17]
[same as prior period, unchanged from 0001069202-20-000015:notes:15]

[0001069202-20-000039:notes:18]
[same as prior period, unchanged from 0001069202-20-000015:notes:16]

[0001069202-20-000039:notes:19]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income

[0001069202-20-000039:notes:20]
taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation in the table below details the items excluded.

[0001069202-20-000039:notes:21]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII. We record these share-based awards as corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-20-000039:notes:22]
[same as prior period, unchanged from 0001069202-20-000015:notes:20]

[0001069202-20-000039:notes:23]
[same as prior period, unchanged from 0001069202-20-000015:notes:21]

[0001069202-20-000039:notes:24]
[same as prior period, unchanged from 0001069202-20-000015:notes:22]

[0001069202-20-000039:notes:25]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 644.8 |  |  | $ | 689.1 |  |  | $ | 1,086.9 |  |  | $ | 1,154.6 |  |
| Commercial Heating & Cooling | 188.3 |  |  | 261.3 |  |  | 366.7 |  |  | 434.7 |  |
| Refrigeration | 108.2 |  |  | 148.7 |  |  | 211.5 |  |  | 300.1 |  |
|  | $ | 941.3 |  |  | $ | 1,099.1 |  |  | $ | 1,665.1 |  |  | $ | 1,889.4 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 127.3 |  |  | $ | 153.4 |  |  | $ | 159.8 |  |  | $ | 240.1 |  |
| Commercial Heating & Cooling | 35.6 |  |  | 53.9 |  |  | 54.3 |  |  | 68.9 |  |
| Refrigeration | 8.9 |  |  | 19.1 |  |  | 9.6 |  |  | 27.5 |  |
| Corporate and other | (18.8) |  |  | (24.1) |  |  | (33.1) |  |  | (36.2) |  |
| Total segment profit | 153.0 |  |  | 202.3 |  |  | 190.6 |  |  | 300.3 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special product quality adjustments | (1.0) |  |  | (0.5) |  |  | (1.0) |  |  | (0.5) |  |
| Loss on sale of business | — |  |  | 0.4 |  |  | — |  |  | 8.8 |  |
| Partial advance of insurance recoveries related to lost profits | — |  |  | (8.0) |  |  | — |  |  | (8.0) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.0 |  |  | (5.9) |  |  | 2.7 |  |  | (12.8) |  |
| Items in (Gains) losses and other expenses, net that are excluded from segment profit (loss) (1) | 7.0 |  |  | 2.6 |  |  | 6.1 |  |  | 3.9 |  |
| Restructuring charges | 10.0 |  |  | (0.1) |  |  | 10.5 |  |  | 0.4 |  |
| Operating income | $ | 136.0 |  |  | $ | 213.8 |  |  | $ | 172.3 |  |  | $ | 308.5 |  |

[0001069202-20-000039:notes:26]
[same as prior period, unchanged from 0001069202-20-000015:notes:24]

[0001069202-20-000039:notes:27]
•The following items in losses (gains) and other expenses, net:

[0001069202-20-000039:notes:28]
[same as prior period, unchanged from 0001069202-20-000015:notes:26]

[0001069202-20-000039:notes:29]
◦Special legal contingency charges,

[0001069202-20-000039:notes:30]
◦Asbestos-related litigation,

[0001069202-20-000039:notes:31]
[same as prior period, unchanged from 0001069202-20-000015:notes:29]

[0001069202-20-000039:notes:32]
◦Charges incurred related to COVID-19 pandemic,

[0001069202-20-000039:notes:33]
[same as prior period, unchanged from 0001069202-20-000015:notes:30]

[0001069202-20-000039:notes:34]
[same as prior period, unchanged from 0001069202-20-000015:notes:31]

[0001069202-20-000039:notes:35]
•Special product quality adjustments,

[0001069202-20-000039:notes:36]
•Partial advance of insurance recoveries related to lost profits,

[0001069202-20-000039:notes:37]
[same as prior period, unchanged from 0001069202-20-000015:notes:32]

[0001069202-20-000039:notes:38]
[same as prior period, unchanged from 0001069202-20-000015:notes:33]


## us-gaap:EarningsPerShareTextBlock

[0001069202-20-000039:notes:39]
[same as prior period, unchanged from 0001069202-20-000015:notes:34]

[0001069202-20-000039:notes:40]
[same as prior period, unchanged from 0001069202-20-000015:notes:35]

[0001069202-20-000039:notes:41]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net income | $ | 100.0 |  |  | $ | 110.7 |  |  | $ | 112.9 |  |  | $ | 180.0 |  |
| Exclude: (Income) loss from discontinued operations | 0.6 |  |  | 0.3 |  |  | 0.2 |  |  | 0.4 |  |
| Income from continuing operations | $ | 100.6 |  |  | $ | 111.0 |  |  | $ | 113.1 |  |  | $ | 180.4 |  |
| Weighted-average shares outstanding – basic | 38.2 |  |  | 39.1 |  |  | 38.3 |  |  | 39.4 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.4 |  |  | 0.2 |  |  | 0.4 |  |
| Weighted-average shares outstanding – diluted | 38.4 |  |  | 39.5 |  |  | 38.6 |  |  | 39.8 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.63 |  |  | $ | 2.84 |  |  | $ | 2.95 |  |  | $ | 4.58 |  |
| Income from discontinued operations | (0.01) |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net income | $ | 2.62 |  |  | $ | 2.83 |  |  | $ | 2.95 |  |  | $ | 4.57 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.62 |  |  | $ | 2.81 |  |  | $ | 2.93 |  |  | $ | 4.53 |  |
| Income from discontinued operations | (0.02) |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net income | $ | 2.60 |  |  | $ | 2.80 |  |  | $ | 2.93 |  |  | $ | 4.52 |  |

[0001069202-20-000039:notes:42]
[same as prior period, unchanged from 0001069202-20-000015:notes:37]

[0001069202-20-000039:notes:43]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Weighted-average number of shares | 0.5 |  |  | 0.2 |  |  | 0.5 |  |  | 0.2 |  |
| Price per share | $205.53 - $257.08 |  | $ | 205.53 |  |  | $205.53 - $257.08 |  | $ | 205.53 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-20-000039:notes:44]
4. Commitments and Contingencies:

[0001069202-20-000039:notes:45]
Leases

[0001069202-20-000039:notes:46]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001069202-20-000039:notes:47]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

[0001069202-20-000039:notes:48]
Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-20-000039:notes:49]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-20-000039:notes:50]
We lease certain real and personal property under non-cancelable operating leases. Approximately 75% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-20-000039:notes:51]
Product Warranties and Product Related Contingencies

[0001069202-20-000039:notes:52]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-20-000039:notes:53]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000039:notes:54]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Accrued expenses | $ | 37.5 |  |  | $ | 38.2 |  |
| Other liabilities | 79.4 |  |  | 74.6 |  |
| Total warranty liability | $ | 116.9 |  |  | $ | 112.8 |  |

[0001069202-20-000039:notes:55]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2020 were as follows (in millions):

[0001069202-20-000039:notes:56]
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Warranty claims paid | (15.2) |  |
| Changes resulting from issuance of new warranties | 19.5 |  |
| Changes in estimates associated with pre-existing liabilities | 0.1 |  |
| Changes in foreign currency translation rates and other | (0.3) |  |
| Total warranty liability as of June 30, 2020 | $ | 116.9 |  |

[0001069202-20-000039:notes:57]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

[0001069202-20-000039:notes:58]
Litigation

[0001069202-20-000039:notes:59]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-20-000039:notes:60]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

[0001069202-20-000039:notes:61]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Expense (gain) for asbestos-related litigation, net | $ | 1.2 |  |  | $ | 0.4 |  |  | $ | (0.5) |  |  | $ | 1.8 |  |

[0001069202-20-000039:notes:62]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.

[0001069202-20-000039:notes:63]
Marshalltown Tornado and Recovery

[0001069202-20-000039:notes:64]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covered the repair or replacement of our assets that suffered damage or loss, and business interruption costs, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Insurance proceeds for lost profits and Loss (gain) from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations.

[0001069202-20-000039:notes:65]
In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019.

[0001069202-20-000039:notes:66]
The following table summarizes the Gain from insurance recoveries, net of losses incurred:

[0001069202-20-000039:notes:67]
| (Amounts in millions) | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Insurance recoveries received | $ | — |  |  | $ | 52.0 |  |  | $ | — |  |  | $ | 128.0 |  |
| Losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | — |  |  | 6.2 |  |  | — |  |  | 23.3 |  |
| Factory inefficiencies due to lower productivity | — |  |  | 4.5 |  |  | — |  |  | 8.0 |  |
| Other | 1.0 |  |  | 9.4 |  |  | 2.7 |  |  | 18.4 |  |
| Total losses and expenses | $ | 1.0 |  |  | $ | 20.1 |  |  | $ | 2.7 |  |  | $ | 49.7 |  |
| Presentation in the Consolidated Statements of Operations: |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits | — |  |  | (26.0) |  |  | — |  |  | (65.5) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.0 |  |  | (5.9) |  |  | 2.7 |  |  | (12.8) |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-20-000039:notes:68]
Our Board of Directors have authorized a total of $3 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in December 2019. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of June 30, 2020, $446 million of shares may be repurchased under the Share Repurchase Plans.

[0001069202-20-000039:notes:69]
On February 13, 2020, we entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the "ASR Agreement") with Bank of America, to effect an accelerated stock buyback of the Company's common stock.  Under the ASR Agreement, we paid Bank of America $100.0 million and Bank of America delivered to us common stock representing approximately 85% of the shares expected to be purchased under the ASR Agreement.  The ASR was completed in March 2020 and Bank of America delivered a total of 0.4 million shares of common stock repurchased under this ASR Agreement.

[0001069202-20-000039:notes:70]
We also repurchased shares for $5.6 million during the six months ended June 30, 2020 from employees who tendered their shares to satisfy minimum tax withholding obligations upon the vesting and exercise of stock-based compensation awards.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-20-000039:notes:71]
During the first quarter of 2019, we obtained Board of Directors' approval and signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. The sale was completed on March 29, 2019 and the following table summarizes the net loss recognized in connection with this divestiture.  There were no gains or losses on the sale of this business for the six months ended June 30, 2020.

[0001069202-20-000039:notes:72]
[same as prior period, unchanged from 0001069202-20-000015:notes:67]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-20-000039:notes:73]
We record restructuring charges associated with management-approved restructuring plans when we reorganize or remove duplicative headcount or infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs, accelerated depreciation for impaired assets and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period. Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 2.

[0001069202-20-000039:notes:74]
Due to the economic impact of COVID-19 on our business, we implemented several cost reduction actions in the second quarter of 2020.  We recorded $10.0 million of restructuring charges in the second quarter of 2020 for these actions, which consisted of employee terminations for positions that are no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities.

[0001069202-20-000039:notes:75]
Information regarding the restructuring charges for all ongoing activities, including actions initiated in the third and fourth quarters of 2019, is presented in the following table (in millions):

[0001069202-20-000039:notes:76]
|  | Incurred in 2020 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 4.7 |  |  | $ | 6.0 |  |  | $ | 6.5 |  |
| Asset write-offs and accelerated depreciation | 1.5 |  |  | 3.2 |  |  | 3.2 |  |
| Lease termination | 0.1 |  |  | 1.2 |  |  | 1.2 |  |
| Other | 4.2 |  |  | 4.7 |  |  | 5.4 |  |
| Total restructuring charges | $ | 10.5 |  |  | $ | 15.1 |  |  | $ | 16.3 |  |

[0001069202-20-000039:notes:77]
[same as prior period, unchanged from 0001069202-20-000015:notes:72]

[0001069202-20-000039:notes:78]
|  | Incurred in 2020 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 6.7 |  |  | $ | 9.6 |  |  | $ | 9.6 |  |
| Commercial Heating & Cooling | 1.4 |  |  | 3.1 |  |  | 3.8 |  |
| Refrigeration | 2.0 |  |  | 2.0 |  |  | 2.2 |  |
| Corporate & Other | 0.4 |  |  | 0.4 |  |  | 0.7 |  |
| Total restructuring charges | $ | 10.5 |  |  | $ | 15.1 |  |  | $ | 16.3 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-20-000039:notes:79]
[same as prior period, unchanged from 0001069202-20-000015:notes:74]

[0001069202-20-000039:notes:80]
|  | For the Three Months Ended June 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 603.8 |  |  | $ | 173.1 |  |  | $ | 61.3 |  |  | $ | 838.2 |  |
| Canada | 41.0 |  |  | 15.0 |  |  | — |  |  | 56.0 |  |
| Other international | — |  |  | 0.2 |  |  | 46.9 |  |  | 47.1 |  |
| Total | $ | 644.8 |  |  | $ | 188.3 |  |  | $ | 108.2 |  |  | $ | 941.3 |  |

[0001069202-20-000039:notes:81]
|  | For the Three Months Ended June 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 647.2 |  |  | $ | 239.1 |  |  | $ | 80.0 |  |  | $ | 966.3 |  |
| Canada | 41.9 |  |  | 21.9 |  |  | — |  |  | 63.8 |  |
| Other international | — |  |  | 0.3 |  |  | 68.7 |  |  | 69.0 |  |
| Total | $ | 689.1 |  |  | $ | 261.3 |  |  | $ | 148.7 |  |  | $ | 1,099.1 |  |

[0001069202-20-000039:notes:82]
|  | For the Six Months Ended June 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,016.2 |  |  | $ | 334.3 |  |  | $ | 120.8 |  |  | $ | 1,471.3 |  |
| Canada | 70.7 |  |  | 32.0 |  |  | — |  |  | $ | 102.7 |  |
| Other international | — |  |  | 0.4 |  |  | 90.7 |  |  | $ | 91.1 |  |
| Total | $ | 1,086.9 |  |  | $ | 366.7 |  |  | $ | 211.5 |  |  | $ | 1,665.1 |  |

[0001069202-20-000039:notes:83]
|  | For the Six Months Ended June 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,080.3 |  |  | $ | 396.4 |  |  | $ | 171.6 |  |  | $ | 1,648.3 |  |
| Canada | 74.3 |  |  | 37.8 |  |  | 0.7 |  |  | 112.8 |  |
| International | — |  |  | 0.5 |  |  | 127.8 |  |  | 128.3 |  |
| Total | $ | 1,154.6 |  |  | $ | 434.7 |  |  | $ | 300.1 |  |  | $ | 1,889.4 |  |

[0001069202-20-000039:notes:84]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2020 and 2019, direct sales represented 76% and 75% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2020 and 2019, direct sales represented 75% and 74% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-20-000039:notes:85]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the

[0001069202-20-000039:notes:86]
relative fair value of the services provided. For the three months ended June 30, 2020 and 2019, equipment sales represented 86% and 87% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2020 and 2019, equipment sales represented 85% and 85% of revenues, and the remainder of our revenue was generated from our service business.

[0001069202-20-000039:notes:87]
[same as prior period, unchanged from 0001069202-20-000015:notes:79]

[0001069202-20-000039:notes:88]
[same as prior period, unchanged from 0001069202-20-000015:notes:80]

[0001069202-20-000039:notes:89]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001069202-20-000039:notes:90]
[same as prior period, unchanged from 0001069202-20-000015:notes:83]

[0001069202-20-000039:notes:91]
[same as prior period, unchanged from 0001069202-20-000015:notes:84]

[0001069202-20-000039:notes:92]
[same as prior period, unchanged from 0001069202-20-000015:notes:85]

[0001069202-20-000039:notes:93]
|  | June 30, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (6.8) |  |  | $ | (8.4) |  |  | $ | 1.6 |  |  | (19.0) | % |
| Contract liabilities - noncurrent | (5.6) |  |  | (5.9) |  |  | 0.3 |  |  | (5.1) | % |
| Total | $ | (12.4) |  |  | $ | (14.3) |  |  | $ | 1.9 |  |  |  |

[0001069202-20-000039:notes:94]
For the three months ended June 30, 2020 and 2019, we recognized revenue of $2.9 million and $1.5 million and for the six months ended June 30, 2020 and 2019 we recognized revenue of $4.5 million and $2.6 million related to our contract liabilities at January 1, 2020 and 2019, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020 and 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-20-000039:notes:95]
[same as prior period, unchanged from 0001069202-20-000015:notes:88]

[0001069202-20-000039:notes:96]
[same as prior period, unchanged from 0001069202-20-000015:notes:89]

[0001069202-20-000039:notes:97]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Finished goods | $ | 350.7 |  |  | $ | 402.9 |  |
| Work in process | 5.8 |  |  | 6.0 |  |
| Raw materials and parts | 206.7 |  |  | 198.8 |  |
| Subtotal | 563.2 |  |  | 607.7 |  |
| Excess of current cost over last-in, first-out cost | (63.5) |  |  | (63.6) |  |
| Total inventories, net | $ | 499.7 |  |  | $ | 544.1 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-20-000039:notes:98]
[same as prior period, unchanged from 0001069202-20-000015:notes:91]

[0001069202-20-000039:notes:99]
The changes in the carrying amount of goodwill in 2020, in total and by segment, are summarized in the table below (in millions):

[0001069202-20-000039:notes:100]
|  | Balance at December 31, 2019 |  |  |  | Changes in foreign currency translation rates |  | Balance at June 30, 2020 |
| Residential Heating & Cooling | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.3 |  |  |  |  | — |  |  | 99.3 |  |
| Total Goodwill | $ | 186.5 |  |  |  |  | $ | — |  |  | $ | 186.5 |  |

[0001069202-20-000039:notes:101]
[same as prior period, unchanged from 0001069202-20-000015:notes:94]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-20-000039:notes:102]
[same as prior period, unchanged from 0001069202-20-000015:notes:95]

[0001069202-20-000039:notes:103]
[same as prior period, unchanged from 0001069202-20-000015:notes:96]

[0001069202-20-000039:notes:104]
[same as prior period, unchanged from 0001069202-20-000015:notes:97]

[0001069202-20-000039:notes:105]
[same as prior period, unchanged from 0001069202-20-000015:notes:98]

[0001069202-20-000039:notes:106]
[same as prior period, unchanged from 0001069202-20-000015:notes:99]

[0001069202-20-000039:notes:107]
[same as prior period, unchanged from 0001069202-20-000015:notes:100]

[0001069202-20-000039:notes:108]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through January 2021 and November 2021, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-20-000039:notes:109]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Unrealized losses on unsettled contracts | $ | 1.5 |  |  | $ | 0.2 |  |
| Income tax benefit | (0.9) |  |  | (0.2) |  |
| Losses (gains) included in AOCL, net of tax (1) | $ | 0.6 |  |  | $ | — |  |

[0001069202-20-000039:notes:110]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $1.0 million of derivative losses into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-20-000039:notes:111]
[same as prior period, unchanged from 0001069202-20-000015:notes:104]

[0001069202-20-000039:notes:112]
[same as prior period, unchanged from 0001069202-20-000015:notes:105]

[0001069202-20-000039:notes:113]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Stock-based compensation expense (1) | $ | 6.7 |  |  | $ | 6.1 |  |  | $ | 10.4 |  |  | $ | 11.4 |  |

[0001069202-20-000039:notes:114]
[same as prior period, unchanged from 0001069202-20-000015:notes:107]


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001069202-20-000039:notes:115]
The components of net periodic benefit cost for pensions benefits were as follows (in millions):

[0001069202-20-000039:notes:116]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Service cost | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 2.8 |  |  | $ | 2.4 |  |
| Interest cost | 1.6 |  |  | 1.9 |  |  | 3.3 |  |  | 5.4 |  |
| Expected return on plan assets | (2.0) |  |  | (2.5) |  |  | (4.2) |  |  | (7.2) |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Recognized actuarial loss | 1.4 |  |  | 0.9 |  |  | 2.9 |  |  | 2.9 |  |
| Settlements and curtailments | — |  |  | 60.6 |  |  | — |  |  | 60.6 |  |
| Net periodic benefit cost | $ | 2.4 |  |  | $ | 62.2 |  |  | $ | 4.9 |  |  | $ | 64.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-20-000039:notes:117]
, we had approximately $3.1 million in total gross unrecognized tax benefits. Of this amount $3.1 million, if recognized, would be recorded through the Consolidated Statements of Operations.We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2019 and are subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2012.


## us-gaap:DebtDisclosureTextBlock

[0001069202-20-000039:notes:118]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000039:notes:119]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 306.0 |  |  | $ | 285.0 |  |
| Finance lease obligations | 8.5 |  |  | 7.8 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 343.6 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 26.3 |  |  | 25.9 |  |
| Domestic credit facility | 672.5 |  |  | 475.5 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (1.6) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,047.2 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,390.8 |  |  | $ | 1,171.2 |  |

[0001069202-20-000039:notes:120]
Short-Term Debt

[0001069202-20-000039:notes:121]
Foreign Obligations

[0001069202-20-000039:notes:122]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2020 or December 31, 2019 and there were $1.9 million of borrowings and repayments on these facilities for the six months ended June 30, 2020.  There were no significant borrowings or repayments on these facilities for the six months ended June 30, 2019.

[0001069202-20-000039:notes:123]
Asset Securitization Program

[0001069202-20-000039:notes:124]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale. Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001069202-20-000039:notes:125]
We renewed the ASP in November 2019, extending its term to November 2021 and increasing the maximum securitization amount to a range from $250.0 million to $400.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-20-000039:notes:126]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 306.0 |  |  | $ | 320.0 |  |
| Less: Beneficial interest transferred | (306.0) |  |  | (285.0) |  |
| Remaining amount available | $ | — |  |  | $ | 35.0 |  |

[0001069202-20-000039:notes:127]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average

[0001069202-20-000039:notes:128]
LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2020 and December 31, 2019 were 1.02% and 2.51%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-20-000039:notes:129]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2020, we believe we were in compliance with all covenant requirements.

[0001069202-20-000039:notes:130]
Long-Term Debt

[0001069202-20-000039:notes:131]
Domestic Credit Facility

[0001069202-20-000039:notes:132]
On January 22, 2019, we amended our Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $160.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). We will seek to extend the Maturity Date of the Domestic Credit Facility prior to its expiration.

[0001069202-20-000039:notes:133]
Under our Domestic Credit Facility, we had outstanding borrowings of $702.5 million, of which $145.0 million was the term loan balance, as well as $2.4 million committed to standby letters of credit as of June 30, 2020. Subject to covenant limitations, $440.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

[0001069202-20-000039:notes:134]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-20-000039:notes:135]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 1.36 | % |  | 2.93 | % |

[0001069202-20-000039:notes:136]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-20-000039:notes:137]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-20-000039:notes:138]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-20-000039:notes:139]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or

[0001069202-20-000039:notes:140]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-20-000039:notes:141]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-20-000039:notes:142]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due

[0001069202-20-000039:notes:143]
and payable and the lenders’ commitments will automatically terminate). As of June 30, 2020, we believe we were in compliance with all covenant requirements.

[0001069202-20-000039:notes:144]
Senior Unsecured Notes
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2020, we believe we were in compliance with all covenant requirements.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001069202-20-000039:notes:145]
The following table provides information on items not reclassified in their entirety from AOCL to Net income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-20-000039:notes:146]
|  |  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |
| (Losses) Gains on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | (5.8) |  |  | $ | (2.0) |  |  | $ | (7.0) |  |  | $ | (4.3) |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax benefit |  | 1.5 |  |  | 0.5 |  |  | 1.8 |  |  | 1.0 |  |  | Provision for income taxes |
| Net of tax |  | $ | (4.3) |  |  | $ | (1.5) |  |  | $ | (5.2) |  |  | $ | (3.3) |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.4) |  |  | $ | (1.0) |  |  | $ | (3.0) |  |  | $ | (3.0) |  |  | Cost of goods sold; Selling, general and administrative expenses |
| Pension settlement |  | — |  |  | (60.6) |  |  | — |  |  | (60.6) |  |  | Pension settlement |
| Income tax benefit |  | 0.3 |  |  | 15.3 |  |  | 0.7 |  |  | 15.8 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.1) |  |  | $ | (46.3) |  |  | $ | (2.3) |  |  | $ | (47.8) |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency adjustments on sale of business |  | — |  |  | — |  |  | — |  |  | (2.1) |  |  | Loss on sale of business |
| Net of tax |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (2.1) |  |  |  |
| Total reclassifications from AOCL |  | $ | (5.4) |  |  | $ | (47.8) |  |  | $ | (7.5) |  |  | $ | (53.2) |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-20-000039:notes:147]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2020 (in millions):

[0001069202-20-000039:notes:148]
|  |  | Gains (Losses) on Cash Flow Hedges |  |  |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2019 |  | $ | — |  |  |  |  | $ | (81.5) |  |  | $ | (22.3) |  |  | $ | (103.8) |  |
| Other comprehensive loss before reclassifications |  | (5.8) |  |  |  |  | (1.8) |  |  | (17.8) |  |  | (25.4) |  |
| Amounts reclassified from AOCL |  | 5.2 |  |  |  |  | 2.3 |  |  | — |  |  | 7.5 |  |
| Net other comprehensive (loss) income |  | (0.6) |  |  |  |  | 0.5 |  |  | (17.8) |  |  | (17.9) |  |
| Balance as of June 30, 2020 |  | $ | (0.6) |  |  |  |  | $ | (81.0) |  |  | $ | (40.1) |  |  | $ | (121.7) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-20-000039:notes:149]
[same as prior period, unchanged from 0001069202-20-000015:notes:141]

[0001069202-20-000039:notes:150]
The methodologies used to determine the fair value of our financial assets and liabilities at June 30, 2020 were the same as those used at December 31, 2019.

[0001069202-20-000039:notes:151]
[same as prior period, unchanged from 0001069202-20-000015:notes:143]

[0001069202-20-000039:notes:152]
[same as prior period, unchanged from 0001069202-20-000015:notes:144]

[0001069202-20-000039:notes:153]
[same as prior period, unchanged from 0001069202-20-000015:notes:145]

[0001069202-20-000039:notes:154]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-20-000039:notes:155]
[same as prior period, unchanged from 0001069202-20-000015:notes:147]

[0001069202-20-000039:notes:156]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Senior unsecured notes | $ | 362.7 |  |  | $ | 356.8 |  |
