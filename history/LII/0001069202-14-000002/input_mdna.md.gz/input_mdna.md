# LII MD&A — 0001069202-14-000002


## mdna

[0001069202-14-000002:mdna:1]
Item 7.  Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-14-000002:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the consolidated financial statements and related notes contained in Item 8 of this Annual Report on Form 10-K.

[0001069202-14-000002:mdna:3]
Business Overview

[0001069202-14-000002:mdna:4]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 19 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000002:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned parts and supplies stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-14-000002:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of higher commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-14-000002:mdna:7]
Recent Developments

[0001069202-14-000002:mdna:8]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer") in an all cash transaction for proceeds of $10.4 million, excluding transaction costs.  The gain on sale of the business, the operating results for the business through March 22, 2013, and other gains and losses associated with the business are presented in discontinued operations.  The Company also entered into a two-year equipment and parts supply agreement with the Buyer.

[0001069202-14-000002:mdna:9]
Financial Highlights

[0001069202-14-000002:mdna:10]
| • | Net sales increased $250 million, or 8%, to $3,199 million in 2013 from $2,949 million in 2012. |

[0001069202-14-000002:mdna:11]
| • | Operational income from continuing operations in 2013 was $289 million compared to $219 million in 2012. The increase was primarily due to higher volumes, higher margins from improved price and mix and material cost savings. |

[0001069202-14-000002:mdna:12]
| • | Net income in 2013 increased to $172 million from $90 million in 2012. |

[0001069202-14-000002:mdna:13]
| • | Diluted earnings per share from continuing operations were $3.55 per share in 2013 compared to $2.63 per share in 2012. |

[0001069202-14-000002:mdna:14]
| • | We generated $210 million of cash flow from operating activities in 2013 compared to $221 million in 2012. |

[0001069202-14-000002:mdna:15]
| • | In 2013, we returned $125 million to shareholders through share repurchases and $34 million through dividend payments. |

[0001069202-14-000002:mdna:16]
Overview of Results

[0001069202-14-000002:mdna:17]
The Residential Heating & Cooling segment led our overall financial performance in 2013, with a 15% increase in net sales and a $77 million increase in segment profit compared to 2012.  This segment's results benefited from industry growth in the replacement and new construction markets as well as market share gains.  Our Commercial Heating & Cooling segment also performed well in 2013 with an 8% increase in net sales and a $19 million increase in segment profit compared to 2012.  This segment's results benefited from market share gains, market growth in North America and material cost savings.  Sales in our Refrigeration segment were down 2% and segment profit increased $8 million compared to 2012.  This segment's sales were impacted by volume declines and unfavorable foreign currency exchange rates.  However, the segment's profits increased due to product price increases, favorable product mix, lower material costs and growth in the Australian refrigerant distribution business, improved price and mix and favorable material product costs.

[0001069202-14-000002:mdna:18]
On a consolidated basis, our product profit margins improved to 26.9% in 2013 due to volume increases in our Residential Heating & Cooling and Commercial Heating & Cooling segments, favorable commodity and non-commodity material costs across all of our segments and favorable price and mix across all of our segments.  These improvements were partially offset by higher distribution costs in the Residential Heating & Cooling segment, higher non-material product costs primarily in our Refrigeration segment and higher warranty costs in our Residential Heating & Cooling segment.

[0001069202-14-000002:mdna:19]
Results of Operations

[0001069202-14-000002:mdna:20]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-14-000002:mdna:21]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 3,199.1 |  |  | 100.0 | % |  | $ | 2,949.4 |  |  | 100.0 | % |  | $ | 2,840.9 |  |  | 100.0 | % |
| Cost of goods sold | 2,337.9 |  |  | 73.1 | % |  | 2,227.1 |  |  | 75.5 | % |  | 2,171.0 |  |  | 76.4 | % |
| Gross profit | 861.2 |  |  | 26.9 | % |  | 722.3 |  |  | 24.5 | % |  | 669.9 |  |  | 23.6 | % |
| Selling, general and administrative expenses | 570.1 |  |  | 17.8 | % |  | 507.0 |  |  | 17.2 | % |  | 476.9 |  |  | 16.8 | % |
| Losses and other expenses, net | 9.3 |  |  | 0.3 | % |  | 2.5 |  |  | 0.1 | % |  | 5.7 |  |  | 0.2 | % |
| Restructuring charges | 5.0 |  |  | 0.2 | % |  | 4.2 |  |  | 0.1 | % |  | 12.5 |  |  | 0.4 | % |
| Income from equity method investments | (12.2 | ) |  | (0.4 | )% |  | (10.5 | ) |  | (0.4 | )% |  | (9.6 | ) |  | (0.3 | )% |
| Operational income from continuing operations | $ | 289.0 |  |  | 9.0 | % |  | $ | 219.1 |  |  | 7.4 | % |  | $ | 184.4 |  |  | 6.5 | % |
| Loss from discontinued operations | (8.1 | ) |  | (0.3 | )% |  | (45.0 | ) |  | (1.5 | )% |  | (23.2 | ) |  | (0.8 | )% |
| Net income | $ | 171.8 |  |  | 5.4 | % |  | $ | 90.0 |  |  | 3.1 | % |  | $ | 88.3 |  |  | 3.1 | % |

[0001069202-14-000002:mdna:22]
The following table provides net sales by geographic market (dollars in millions):

[0001069202-14-000002:mdna:23]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net Sales by Geographic Market: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. | $ | 2,382.0 |  |  | 74.5 | % |  | $ | 2,147.2 |  |  | 72.8 | % |  | $ | 2,018.1 |  |  | 71.0 | % |
| Canada | 232.3 |  |  | 7.2 |  |  | 226.7 |  |  | 7.7 |  |  | 219.2 |  |  | 7.8 |  |
| International | 584.8 |  |  | 18.3 |  |  | 575.5 |  |  | 19.5 |  |  | 603.6 |  |  | 21.2 |  |
| Total net sales | $ | 3,199.1 |  |  | 100.0 | % |  | $ | 2,949.4 |  |  | 100.0 | % |  | $ | 2,840.9 |  |  | 100.0 | % |

[0001069202-14-000002:mdna:24]
Year Ended December 31, 2013 Compared to Year Ended December 31, 2012 - Consolidated Results

[0001069202-14-000002:mdna:25]
Net Sales

[0001069202-14-000002:mdna:26]
Net sales increased 8% in 2013 compared to 2012, with sales volumes up approximately 8% and price and mix up approximately 1%.  Also, foreign currency exchange rates had an unfavorable impact of less than 1%.  The increase in volume was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  The benefit of price and mix was a combination of price increases across all segments and favorable product mix predominantly in our Residential Heating & Cooling segment.

[0001069202-14-000002:mdna:27]
Gross Profit

[0001069202-14-000002:mdna:28]
Gross profit margins improved 240 basis points to 26.9% in 2013 compared to 24.5% in 2012.  Increased volume, along with favorable price and mix contributed 200 basis points to profit margin and lower commodity and non-commodity product costs contributed a collective 130 basis points.  Partially offsetting these improvements were 70 basis points of higher distribution costs and 20 basis points of higher warranty costs.

[0001069202-14-000002:mdna:29]
Selling, General and Administrative Expenses

[0001069202-14-000002:mdna:30]
SG&A expenses increased by $63 million in 2013 compared to 2012.  As a percentage of net sales, SG&A expenses increased 60 basis points from 17.2% to 17.8% in the same periods.  The increase in SG&A expenses was principally due to higher employee compensation.

[0001069202-14-000002:mdna:31]
Losses and Other Expenses, Net

[0001069202-14-000002:mdna:32]
Losses and other expenses, net for 2013 and 2012 included the following (in millions):

[0001069202-14-000002:mdna:33]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |
| Realized losses on settled futures contracts | $ | 1.0 |  |  | $ | 1.5 |  |
| Foreign currency exchange losses | 0.5 |  |  | 0.8 |  |
| Losses (gains) on disposal of fixed assets | (1.0 | ) |  | 0.4 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.4 |  |  | (2.2 | ) |
| Special legal contingency charges | 1.2 |  |  | 1.2 |  |
| Asbestos-related litigation | 6.3 |  |  | — |  |
| Other items, net | 0.9 |  |  | 0.8 |  |
| Losses and other expenses, net | $ | 9.3 |  |  | $ | 2.5 |  |

[0001069202-14-000002:mdna:34]
The decline in realized losses on settled futures contracts in 2013 was attributable to increases in commodity prices relative to our settled futures contract prices.  Conversely, the change in unrealized losses (gains) on unsettled futures contracts was primarily due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000002:mdna:35]
The special legal contingency charges relate to ongoing patent litigation.  We also recorded asbestos charges in the fourth quarter of 2013 for known and estimated future asbestos matters.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on this litigation and the asbestos charges.

[0001069202-14-000002:mdna:36]
Restructuring Charges

[0001069202-14-000002:mdna:37]
Restructuring charges were $5 million in 2013 compared to $4 million in 2012.  The charges in 2013 related to our Regional Distribution Network project as well as anticipated severance charges associated with a relocation of certain Residential Heating & Cooling manufacturing operations to lower cost facilities.  The charges in 2012 related primarily to our Regional Distribution Network project.  For more information on our restructuring activities, see Note 16 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000002:mdna:38]
Income from Equity Method Investments

[0001069202-14-000002:mdna:39]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments increased to $12 million in 2013 compared to $10 million in 2012 due to increases in earnings from our joint ventures.

[0001069202-14-000002:mdna:40]
Interest Expense, net

[0001069202-14-000002:mdna:41]
Net interest expense of $15 million in 2013 declined from $17 million in 2012 due to a decrease in our weighted-average interest rates in the comparable periods, partially offset by a slight increase in our average borrowings.

[0001069202-14-000002:mdna:42]
Income Taxes

[0001069202-14-000002:mdna:43]
The income tax provision was $94 million in 2013 compared to $67 million in 2012, and the effective tax rate was 34.4% in 2013 compared to 33.1% in 2012.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-14-000002:mdna:44]
Loss from Discontinued Operations

[0001069202-14-000002:mdna:45]
The Loss from discontinued operations related to the Service Experts business sold in March 2013 and the Hearth business sold in April 2012.  In 2013, there were $13 million of pre-tax losses from discontinued operations consisting primarily of operating losses in the Service Experts business.  The Hearth business had no significant gains or losses in 2013.

[0001069202-14-000002:mdna:46]
In 2012, there were pre-tax losses of $65 million consisting of $51 million of losses related to the Service Experts business and $14 million of losses related to the Hearth business.  The $51 million of Service Experts' losses included operating losses of $28 million, goodwill impairment charges of $21 million and $2 million of restructuring and other expenses.  The $14 million of losses related to the Hearth business included operating losses of $3 million, a $6 million charge to write down certain long-lived assets to their fair value, a $6 million pension settlement charge for the realization of pension losses related to the transfer of a pension to the buyer of the business, a $1 million loss on the sale of the business, $2 million of other expenses and a $4 million gain for the realization of foreign currency translation adjustments.

[0001069202-14-000002:mdna:47]
Year Ended December 31, 2013 Compared to Year Ended December 31, 2012 - Results by Segment

[0001069202-14-000002:mdna:48]
Residential Heating & Cooling

[0001069202-14-000002:mdna:49]
The following table presents our Residential Heating & Cooling segment's net sales and profit for 2013 and 2012 (dollars in millions):

[0001069202-14-000002:mdna:50]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 1,583.2 |  |  | $ | 1,375.8 |  |  | $ | 207.4 |  |  | 15.1 | % |
| Profit | $ | 180.1 |  |  | $ | 102.9 |  |  | $ | 77.2 |  |  | 75.0 | % |
| % of net sales | 11.4 | % |  | 7.5 | % |  |  |  |  |

[0001069202-14-000002:mdna:51]
Residential Heating & Cooling net sales increased 15% in 2013 compared to 2012 driven by strong volume increases and favorable price and mix.  Sales volume increases contributed 13% and were attributable to industry growth in new construction and replacement markets and market share gains.  Benefits of price increases and favorable product mix contributed 2%.

[0001069202-14-000002:mdna:52]
Segment profit in 2013 increased $77 million due to $57 million in higher sales volumes, $18 million from favorable price and mix, $33 million in commodity and non-commodity material cost savings and $3 million in favorable other product costs due primarily to factory efficiencies.  Partially offsetting these increases were $13 million in higher SG&A costs due primarily to higher advertising and employee compensation costs, $17 million of higher distribution expenses due to continued investment in distribution initiatives and $4 million in adjustments to the product warranty accrual.

[0001069202-14-000002:mdna:53]
Commercial Heating & Cooling

[0001069202-14-000002:mdna:54]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for 2013 and 2012 (dollars in millions):

[0001069202-14-000002:mdna:55]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 844.4 |  |  | $ | 785.4 |  |  | $ | 59.0 |  |  | 7.5 | % |
| Profit | $ | 118.1 |  |  | $ | 99.5 |  |  | $ | 18.6 |  |  | 18.7 | % |
| % of net sales | 14.0 | % |  | 12.7 | % |  |  |  |  |

[0001069202-14-000002:mdna:56]
Commercial Heating & Cooling net sales increased 8% in 2013 compared to 2012 driven by higher volumes.  The drivers of the volume increases were market share gains and industry growth in the North American markets.  Also, foreign currency exchange rates had a favorable impact of less than 1%.

[0001069202-14-000002:mdna:57]
Segment profit in 2013 increased $19 million compared to 2012 due to increases of $19 million from higher volumes, $11 million for favorable commodity and non-commodity material costs and $4 million for favorable price and mix.  Partially offsetting these increases were $4 million of higher distribution expenses due to continued investment in distribution initiatives, $6 million

[0001069202-14-000002:mdna:58]
of higher SG&A expenses and $5 million of increases primarily to investments in our commercial services network.

[0001069202-14-000002:mdna:59]
Refrigeration

[0001069202-14-000002:mdna:60]
The following table presents our Refrigeration segment's net sales and profit for 2013 and 2012 (dollars in millions):

[0001069202-14-000002:mdna:61]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 771.5 |  |  | $ | 788.2 |  |  | $ | (16.7 | ) |  | (2.1 | )% |
| Profit | $ | 90.2 |  |  | $ | 81.9 |  |  | $ | 8.3 |  |  | 10.1 | % |
| % of net sales | 11.7 | % |  | 10.4 | % |  |  |  |  |

[0001069202-14-000002:mdna:62]
Refrigeration net sales were down 2% in 2013 compared to 2012 due to volume declines and unfavorable foreign currency exchange rates, partially offset by growth in Australia.  Volumes declined 2% primarily because of weakness in the North America grocery markets.  Also, foreign currency exchange rates had a 1% unfavorable impact over the comparable period.  These declines were partially offset by growth of 1% related to the Australia wholesale refrigerant business.

[0001069202-14-000002:mdna:63]
Segment profit for 2013 increased $8 million over 2012, with increases of $14 million from growth in the Australia wholesale refrigerant business which benefited from one-time purchases of lower cost inventory and from investments in related operations, increases of $10 million from favorable price and mix and increases of $11 million from favorable commodity and non-commodity material costs.  Partially offsetting these increases were $13 million of higher SG&A expenses primarily related to investments in cost savings initiatives and increases in employee compensation, $11 million of volume-related declines, approximately $2 million from unfavorable foreign currency exchange rates and $1 million of higher distribution costs.

[0001069202-14-000002:mdna:64]
Corporate and Other

[0001069202-14-000002:mdna:65]
Corporate and other expenses increased $28 million in 2013 to $88 million from $60 million in 2012 driven primarily by an increase in incentive compensation due to improved operating results in 2013.

[0001069202-14-000002:mdna:66]
Year Ended December 31, 2012 Compared to Year Ended December 31, 2011 - Consolidated Results

[0001069202-14-000002:mdna:67]
Net Sales

[0001069202-14-000002:mdna:68]
Net sales increased 4% in 2012 compared to 2011, or increased 5% excluding a 1% unfavorable impact from changes in foreign currency exchange rates.  Sales volume was up 5% and price and mix were flat from the comparable period.  The increase in volume was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  Increases in price and mix at our Commercial Heating & Cooling and Refrigeration segments were largely offset by a decrease in price and mix at our Residential Heating & Cooling segments.

[0001069202-14-000002:mdna:69]
Gross Profit

[0001069202-14-000002:mdna:70]
Gross profit margins improved 90 basis points to 24.5% in 2012 from 23.6% in 2011.  Improved volume, price and mix contributed 50 basis points to profit margin and improved commodity and non-commodity material costs contributed a collective 90 basis points over 2011.  Partially offsetting these increases were 50 basis points of higher freight and distribution costs.

[0001069202-14-000002:mdna:71]
Selling, General and Administrative Expenses

[0001069202-14-000002:mdna:72]
SG&A expenses increased by $30 million in 2012 compared to 2011, and as a percentage of net sales, SG&A expenses increased 40 basis points from 16.8% in 2011 to 17.2% in 2012.  The increase in SG&A expenses was principally due to higher incentive compensation due to improved operating results in 2012.

[0001069202-14-000002:mdna:73]
Losses and Other Expenses, Net

[0001069202-14-000002:mdna:74]
Losses and other expenses, net for 2012 and 2011 included the following (in millions):

[0001069202-14-000002:mdna:75]
|  | For the Years Ended December 31, |
|  | 2012 |  | 2011 |
| Realized losses (gains) on settled futures contracts | $ | 1.5 |  |  | $ | (0.1 | ) |
| Foreign currency exchange losses | 0.8 |  |  | 1.4 |  |
| Losses (gains) on disposal of fixed assets | 0.4 |  |  | (0.8 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts | (2.2 | ) |  | 3.8 |  |
| Acquisition expenses | 0.1 |  |  | 1.0 |  |
| Special legal contingency charges | 1.2 |  |  | — |  |
| Other items, net | 0.7 |  |  | 0.4 |  |
| Losses and other expenses, net | $ | 2.5 |  |  | $ | 5.7 |  |

[0001069202-14-000002:mdna:76]
The change in realized gains and losses on settled futures contracts in 2012 was attributable to decreases in commodity prices relative to our futures contract prices.  Conversely, the change in unrealized gains on unsettled futures contracts was primarily due to higher commodity prices relative to the futures contract prices.  For more information on our derivatives, see Note 8 in the Notes to the Consolidated Financial Statements.  The special legal contingency charges in 2012 related primarily to ongoing patent litigation.  See Note 10 in the Notes to the Consolidated Financial Statements for more information on this litigation.

[0001069202-14-000002:mdna:77]
Restructuring Charges

[0001069202-14-000002:mdna:78]
Restructuring charges were $4 million in 2012 compared to $13 million in 2011.  We did not initiate any significant new projects in 2012 and the charges during the year related primarily to our Regional Distribution Network project.  The restructuring charges in 2011 were primarily from corporate restructuring charges that included the termination of our corporate airplane lease, closure of our aviation department, and reorganization of certain support functions.  Refer to Note 16 in the Notes to the Consolidated Financial Statements for more information on our restructuring activities.

[0001069202-14-000002:mdna:79]
Income from Equity Method Investments

[0001069202-14-000002:mdna:80]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments increased slightly to $11 million in 2012 compared to $10 million in 2011 primarily due to improved operational performance from our joint ventures.

[0001069202-14-000002:mdna:81]
Interest Expense, net

[0001069202-14-000002:mdna:82]
Net interest expense of $17 million in 2012 was flat compared to 2011.  Similarly, our weighted average interest rates and weighted average borrowings were relatively flat.

[0001069202-14-000002:mdna:83]
Income Taxes

[0001069202-14-000002:mdna:84]
The income tax provision was $67 million in 2012 compared to $56 million in 2011 and the effective tax rate was 33.1% for 2012 compared to 33.4% for 2011.  Our effective rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-14-000002:mdna:85]
Loss from Discontinued Operations

[0001069202-14-000002:mdna:86]
The loss from discontinued operations relates to the Service Experts business, which we announced plans to sell in September 2012, and the Hearth business, which we sold in April 2012.  The Service Experts business had a pre-tax loss of $51 million in 2012 compared to a pre-tax loss of $11 million in 2011.  The pre-tax loss from discontinued operations in 2012 included operating losses of $28 million, goodwill impairment of $21 million, and $2 million of restructuring and other expenses.  The pre-tax loss  in 2011 included operating losses of $7 million and restructuring expenses of $4 million.

[0001069202-14-000002:mdna:87]
The Hearth business had a pre-tax loss in discontinued operations of $14 million in 2012 compared to a pre-tax loss of $26 million in 2011.  The pre-tax loss in 2012 included $3 million of operating losses, a $6 million charge to write down the related

[0001069202-14-000002:mdna:88]
assets to their fair value, a $6 million pension settlement charge for the realization of pension losses related to the transfer of a pension obligation to the buyer, a $1 million loss on the sale of the business, $2 million of other expenses and a $4 million gain for the realization of foreign currency translation adjustments.  The pre-tax loss in 2011 included operating losses of $12 million and goodwill and long-lived asset impairments of $7 million each.

[0001069202-14-000002:mdna:89]
Year Ended December 31, 2012 Compared to Year Ended December 31, 2011 - Results by Segment

[0001069202-14-000002:mdna:90]
Residential Heating & Cooling

[0001069202-14-000002:mdna:91]
The following table details our Residential Heating & Cooling segment's net sales and profit for 2012 and 2011 (dollars in millions):

[0001069202-14-000002:mdna:92]
|  | Years Ended December 31, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 1,375.8 |  |  | $ | 1,259.5 |  |  | $ | 116.3 |  |  | 9.2 | % |
| Profit | $ | 102.9 |  |  | $ | 87.6 |  |  | $ | 15.3 |  |  | 17.5 | % |
| % of net sales | 7.5 | % |  | 7.0 | % |  |  |  |  |

[0001069202-14-000002:mdna:93]
Residential Heating & Cooling net sales increased by 9% in 2012 compared to 2011.  Sales volumes increased by 11% in 2012 and were partially offset by lower sales mix of 2%.  The increase in sales volumes was attributable to industry growth and market share gains in our new construction and replacement businesses during the year.  Sales mix was negatively affected by the growth in the new construction business, which generally trends towards lower efficiency products.

[0001069202-14-000002:mdna:94]
Segment profit for 2012 increased $15 million due to $40 million in higher sales volumes, $16 million in material cost savings and $4 million in favorable pricing.  Partially offsetting these increases were $25 million in unfavorable mix, $13 million in higher SG&A costs due primarily to higher incentive compensation from improved operating results in 2012, and higher freight and distribution expenses of $7 million due to continued investment in distribution initiatives.

[0001069202-14-000002:mdna:95]
Commercial Heating & Cooling

[0001069202-14-000002:mdna:96]
The following table details our Commercial Heating & Cooling segment's net sales and profit for 2012 and 2011 (dollars in millions):

[0001069202-14-000002:mdna:97]
|  | Years Ended December 31, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 785.4 |  |  | $ | 776.2 |  |  | $ | 9.2 |  |  | 1.2 | % |
| Profit | $ | 99.5 |  |  | $ | 87.6 |  |  | $ | 11.9 |  |  | 13.6 | % |
| % of net sales | 12.7 | % |  | 11.3 | % |  |  |  |  |

[0001069202-14-000002:mdna:98]
Commercial Heating & Cooling net sales increased 1% in 2012 compared to 2011, or increased 3% when excluding the 2% unfavorable impact from foreign currency exchange rates.  Sales volumes increased 2% and price and mix increased by 1%.  Sales volume growth was somewhat muted during the second half of 2012 as certain customers slowed order rates due to broad economic uncertainties.

[0001069202-14-000002:mdna:99]
Segment profit in 2012 increased $12 million compared to 2011, with increases of $5 million for higher sales volumes, $11 million for favorable price and mix and $5 million for productivity initiatives.  Partially offsetting these increases were $5 million in higher SG&A expenses due primarily to higher incentive compensation and higher freight and distribution expenses of $4 million.

[0001069202-14-000002:mdna:100]
Refrigeration

[0001069202-14-000002:mdna:101]
The following table details our Refrigeration segment's net sales and profit for 2012 and 2011 (dollars in millions):

[0001069202-14-000002:mdna:102]
|  | Years Ended December 31, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 788.2 |  |  | $ | 805.2 |  |  | $ | (17.0 | ) |  | (2.1 | )% |
| Profit | $ | 81.9 |  |  | $ | 77.5 |  |  | $ | 4.4 |  |  | 5.7 | % |
| % of net sales | 10.4 | % |  | 9.6 | % |  |  |  |  |

[0001069202-14-000002:mdna:103]
Net sales decreased by 2% in 2012 compared to 2011, or were flat excluding the 2% unfavorable impact from foreign currency exchange rates.  Price and mix improvements of approximately 3% were offset by volume declines of 3%.   Sales volumes were challenged in the second half of 2012 as we experienced some slowing in our European refrigeration markets as well as some customers pushing out orders due to broad economic uncertainties.

[0001069202-14-000002:mdna:104]
Segment profit in 2012 increased $4 million over 2011, with increases of $14 million from growth in our distribution business in Australia and overall favorable price and mix, and increases of approximately $5 million in material and other cost savings.  Partially offsetting these increases were volume declines of $4 million, higher freight and distribution costs of $2 million, and higher SG&A expenses of $9 million due primarily to higher incentive compensation.

[0001069202-14-000002:mdna:105]
Corporate and Other

[0001069202-14-000002:mdna:106]
Corporate and other expenses increased $5 million to $60 million in 2012 from $55 million in 2011.  The increase was driven by a $12 million increase in incentive compensation due to improved overall operating results that was partially offset by a $7 million reduction in self-insurance costs.

[0001069202-14-000002:mdna:107]
Accounting for Futures Contracts

[0001069202-14-000002:mdna:108]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 8 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 19 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to net income.

[0001069202-14-000002:mdna:109]
Liquidity and Capital Resources

[0001069202-14-000002:mdna:110]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-14-000002:mdna:111]
Statement of Cash Flows

[0001069202-14-000002:mdna:112]
The following table summarizes our cash flow activity for the years ended 2013, 2012 and 2011 (in millions):

[0001069202-14-000002:mdna:113]
|  | 2013 |  | 2012 |  | 2011 |
| Net cash provided by operating activities | $ | 210.3 |  |  | $ | 221.4 |  |  | $ | 76.2 |  |
| Net cash used in investing activities | (67.3 | ) |  | (40.4 | ) |  | (177.8 | ) |
| Net cash used in financing activities | (150.2 | ) |  | (180.1 | ) |  | (11.9 | ) |

[0001069202-14-000002:mdna:114]
Net Cash Provided by Operating Activities - Net cash provided by operating activities decreased $11 million to $210 million in 2013 compared to $221 million in 2012.  This decrease was primarily attributable to an increase in working capital requirements, partially offset by higher net income.  The majority of the increase in working capital in 2013 was related to higher accounts and notes receivable due to sales growth, higher inventory levels due to planned sales growth in 2014 and a decrease in accounts payable due to the timing of payments.  Also, contributions to pension plans were $10 million in 2013 compared to $29 million in 2012.

[0001069202-14-000002:mdna:115]
Net Cash Used in Investing Activities - Capital expenditures were $78 million, $50 million and $41 million in 2013, 2012 and 2011, respectively.  Capital expenditures in 2013 were primarily related to an expansion of manufacturing capacity for our Residential Heating & Cooling segment, investments in the operations of the Australia wholesale refrigerant business, investments in our North America distribution networks and other investments in systems and software to support the overall enterprise.

[0001069202-14-000002:mdna:116]
Net cash used in investing activities for 2013 also included $9 million in net proceeds from the sale of the Service Experts business.  Net cash used in investing activities for 2012 included $10 million in net proceeds from the sale of the Hearth business.  Net cash used in investing activities for 2011 included $143 million used for the acquisition of the Kysor/Warren business and $4 million used for the acquisition of a services business in our Commercial Heating & Cooling segment.

[0001069202-14-000002:mdna:117]
Net Cash Used in Financing Activities - Net cash used in financing activities declined to $150 million in 2013 from $180 million in 2012 primarily due to an increase in net borrowings and fewer dividend payments, partially offset by increased share repurchases.  Net borrowings increased by $14 million in 2013 primarily to support the working capital increase and we made $14 million less in dividend payments in 2013 due to timing of the payments.  We also used $125 million in 2013 to acquire 1.7 million shares of stock under our share repurchase plans compared to purchases of $50 million for 1.1 million shares in 2012.

[0001069202-14-000002:mdna:118]
Debt Position

[0001069202-14-000002:mdna:119]
The following table details our lines of credit and financing arrangements as of December 31, 2013 (in millions):

[0001069202-14-000002:mdna:120]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-Term Debt: |  |  |  |  |  |
| Foreign Obligations | $ | 29.7 |  |  | $ | 5.9 |  |  | $ | 23.8 |  |
| Asset Securitization Program (1) | 160.0 |  |  | 160.0 |  |  | — |  |
| Total short-term debt | 189.7 |  |  | 165.9 |  |  | 23.8 |  |
| Current Maturities: |  |  |  |  |  |
| Capital lease obligations | 1.3 |  |  | 1.3 |  |  | — |  |
| Long-Term Debt: |  |  |  |  |  |
| Capital lease obligations | 16.2 |  |  | 16.2 |  |  | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 17.0 |  |  | 599.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 866.2 |  |  | 233.2 |  |  | 599.5 |  |
| Total debt | $ | 1,057.2 |  |  | $ | 400.4 |  |  | $ | 623.3 |  |

[0001069202-14-000002:mdna:121]
| (1) | In November 2013, we amended the Asset Securitization Program ("ASP"), extending its term to November 14, 2014 and increasing the maximum securitization amount from $160.0 million to a range of $160.0 million to $220.0 million, depending on the period. The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP. |

[0001069202-14-000002:mdna:122]
| (2) | The available future borrowings on our domestic revolving credit facility are reduced by $33.5 million in outstanding standby letters of credit. We had an additional $26.0 million in standby letters of credit with other banks. |

[0001069202-14-000002:mdna:123]
Financial Leverage

[0001069202-14-000002:mdna:124]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001069202-14-000002:mdna:125]
As of December 31, 2013, our senior credit ratings were Baa3 with a stable outlook, and BBB- with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  Obligations rated Baa3 by Moody's and BBB- by S&P are both judged to be lowest investment grade and subject to moderate credit risk and may possess certain speculative characteristics.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject

[0001069202-14-000002:mdna:126]
to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to retain investment grade ratings from Moody's and S&P to ensure the capital markets remain available to us.

[0001069202-14-000002:mdna:127]
Our debt-to-total-capital ratio increased to 45.2% at December 31, 2013 compared to 43.7% at December 31, 2012.  The increase in the ratio in 2013 is primarily due to the increase in our net borrowings, as noted above.  We evaluate our debt-to-capital ratio as well as our debt-to-EBITDA ratio in order to determine the appropriate targets for share repurchases under our share repurchase programs.

[0001069202-14-000002:mdna:128]
Liquidity

[0001069202-14-000002:mdna:129]
We believe our cash of $38 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $38 million as of December 31, 2013 was $26 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and to pay taxes in the United States for the amounts that were repatriated.

[0001069202-14-000002:mdna:130]
As noted above, we made $10 million in contributions to pension plans in 2013.  We also made a $10 million contribution to our U.S. defined benefit plan in January 2014 and are not required to make any additional contributions to this plan for the remainder of 2014.

[0001069202-14-000002:mdna:131]
On May 15, 2013, our Board of Directors approved a 20% increase in our quarterly dividend on common stock from $0.20 to $0.24 per share effective with the July 2013 dividend payment.  Dividend payments were $34 million in 2013 compared to $48 million in 2012, with the decrease due primarily to the timing of payments of declared dividends.  Four quarterly dividends were declared in both 2012 and 2013, whereas five quarterly dividends were paid in 2012 compared to three payments in 2013.

[0001069202-14-000002:mdna:132]
We also continued to increase shareholder value through our share repurchase programs.  In 2013, we returned $125 million to our investors through share repurchases with another $246 million of repurchases still available under the programs.  We are planning $150 million in share repurchases in 2014 under the existing share repurchase programs.

[0001069202-14-000002:mdna:133]
Financial Covenants related to our Debt

[0001069202-14-000002:mdna:134]
Our revolving credit facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage.  Other covenants contained in the revolving credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio.  The required ratios under our revolving credit facility are detailed below:

[0001069202-14-000002:mdna:135]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-14-000002:mdna:136]
Our credit facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our credit facility could occur if:

[0001069202-14-000002:mdna:137]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-14-000002:mdna:138]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-14-000002:mdna:139]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the revolving credit facility, our senior unsecured notes, the Lake Park Renewal, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-14-000002:mdna:140]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our revolving credit facility and accelerate amounts due under our

[0001069202-14-000002:mdna:141]
revolving credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders' commitments will automatically terminate).

[0001069202-14-000002:mdna:142]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes repurchased, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our credit facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001069202-14-000002:mdna:143]
As of December 31, 2013, we were in compliance with all covenant requirements.

[0001069202-14-000002:mdna:144]
Leasing Commitments

[0001069202-14-000002:mdna:145]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the "Lake Park Renewal").  The agreement provides for financial covenants consistent with our credit agreement and we were in compliance with those covenants as of December 31, 2013.  The lease is classified as an operating lease and we expect to realize annualized savings of approximately $2 million in net rent costs from this renewal compared to our previous leasing arrangement.

[0001069202-14-000002:mdna:146]
In 2008, we expanded our Tifton, Georgia manufacturing facility using the proceeds from Industrial Development Bonds (“IDBs”). We entered into a lease agreement with the owner of the property and the issuer of the IDBs, and through our lease payments fund the interest payments to investors in the IDBs. We also guaranteed the repayment of the IDBs and entered into letters of credit totaling $14.5 million to fund a potential repurchase of the IDBs in the event investors exercised their right to tender the IDBs to the Trustee.  As of December 31, 2013 and 2012, we had a long-term capital lease obligation of $14.2 million related to these transactions.

[0001069202-14-000002:mdna:147]
Refer to Note 10 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001069202-14-000002:mdna:148]
Off Balance Sheet Arrangements

[0001069202-14-000002:mdna:149]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Rent expense for these leases was $54 million, $68 million, and $70 million in 2013, 2012, and 2011, respectively.  Refer to Notes 10 and 23 of the Notes to the Consolidated Financial Statements for more information on our lease commitments and rent expense, respectively.

[0001069202-14-000002:mdna:150]
Contractual Obligations

[0001069202-14-000002:mdna:151]
Summarized below are our contractual obligations as of December 31, 2013 and their expected impact on our liquidity and cash flows in future periods (in millions):

[0001069202-14-000002:mdna:152]
|  | Payments Due by Period |
|  | Total |  | 1 Year or Less |  | 1 - 3 Years |  | 3 - 5 Years |  | More than 5 Years |
| Total long-term debt obligations (1) | $ | 400.4 |  |  | $ | 167.2 |  |  | $ | 18.9 |  |  | $ | 202.6 |  |  | $ | 11.7 |  |
| Estimated interest payments on debt obligations | 38.7 |  |  | 13.8 |  |  | 20.2 |  |  | 4.2 |  |  | 0.5 |  |
| Operating leases | 137.4 |  |  | 40.1 |  |  | 52.4 |  |  | 31.8 |  |  | 13.1 |  |
| Uncertain tax positions (2) | 1.6 |  |  | 1.3 |  |  | 0.3 |  |  | — |  |  | — |  |
| Purchase obligations (3) | 38.1 |  |  | 34.7 |  |  | 3.4 |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 616.2 |  |  | $ | 257.1 |  |  | $ | 95.2 |  |  | $ | 238.6 |  |  | $ | 25.3 |  |

[0001069202-14-000002:mdna:153]
(1) Contractual obligations related to capital leases are included as part of long-term debt.

[0001069202-14-000002:mdna:154]
(2) The liability for uncertain tax positions includes interest and penalties.

[0001069202-14-000002:mdna:155]
(3) Purchase obligations consist of aluminum commitments and inventory that is part of our third party logistics programs.

[0001069202-14-000002:mdna:156]
The table above does not include pension, post-retirement benefit and warranty liabilities because it is not certain when these liabilities will be funded.  However, we expect to pay approximately $10 million in contributions to our U.S. defined benefit plans in 2014.  For additional information regarding our contractual obligations, see Notes 9, 10, and 11 of the Notes to the Consolidated Financial Statements.  See Note 12 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.

[0001069202-14-000002:mdna:157]
Fair Value Measurements

[0001069202-14-000002:mdna:158]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001069202-14-000002:mdna:159]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-14-000002:mdna:160]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-14-000002:mdna:161]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-14-000002:mdna:162]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-14-000002:mdna:163]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party's creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2013 and 2012, the measurement dates.

[0001069202-14-000002:mdna:164]
See Note 20 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001069202-14-000002:mdna:165]
Market Risk

[0001069202-14-000002:mdna:166]
Commodity Price Risk

[0001069202-14-000002:mdna:167]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001069202-14-000002:mdna:168]
| Notional amount (pounds of aluminum and copper) | 27.6 |  |
| Carrying amount and fair value of net liability | $ | 1.0 |  |
| Change in fair value from 10% change in forward prices | $ | 8.7 |  |

[0001069202-14-000002:mdna:169]
Refer to Note 8 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001069202-14-000002:mdna:170]
Interest Rate Risk

[0001069202-14-000002:mdna:171]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $0.2 and $0.4 million for the years ended December 31, 2013 and 2012, respectively.

[0001069202-14-000002:mdna:172]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2013 and 2012, no interest rate swaps were in effect.

[0001069202-14-000002:mdna:173]
Foreign Currency Exchange Rate Risk

[0001069202-14-000002:mdna:174]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  During 2013, 2012 and 2011, net sales from outside the U.S. represented 25.5%, 27.2% and 29.0%, respectively, of our total net sales.  For the years ended December 31, 2013 and 2012, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $5.0 million and $3.9 million impact to net income for the years ended December 31, 2013 and 2012, respectively.

[0001069202-14-000002:mdna:175]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 8 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001069202-14-000002:mdna:176]
Critical Accounting Estimates

[0001069202-14-000002:mdna:177]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following are our critical accounting estimates and describe how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements:

[0001069202-14-000002:mdna:178]
| • | Product warranties and product-related contingencies; |

[0001069202-14-000002:mdna:179]
| • | Self-insurance expense; |

[0001069202-14-000002:mdna:180]
| • | Pension benefits; |

[0001069202-14-000002:mdna:181]
| • | Derivative accounting; and |

[0001069202-14-000002:mdna:182]
| • | Goodwill and intangible assets. |

[0001069202-14-000002:mdna:183]
This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001069202-14-000002:mdna:184]
Product Warranties and Product-Related Contingencies

[0001069202-14-000002:mdna:185]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.  We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and, from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.

[0001069202-14-000002:mdna:186]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 10 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001069202-14-000002:mdna:187]
Self-Insurance Expense

[0001069202-14-000002:mdna:188]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability, auto liability, auto physical damage and other exposures.

[0001069202-14-000002:mdna:189]
Many of these plans have large deductibles and may also include per occurrence and annual aggregate limits.  As a result, we expect to incur costs related to these types of claims in future periods.

[0001069202-14-000002:mdna:190]
The estimates for self-insurance expense and liabilities involve assumptions about the amount, timing and nature of future claim costs.  The amounts and timing of payments for future claims may vary depending on numerous factors, including the development and ultimate settlement of reported and unreported claims.  We estimate these amounts actuarially based primarily on our historical claims information, as well as industry factors and trends.  To the extent actuarial assumptions change and claims experience differ from historical rates, our liabilities may change.  The self-insurance liabilities as of December 31, 2013 represent the best estimate of the future payments to be made on reported and unreported losses.  See Note 10 in the Notes to the Consolidated Financial Statements for additional information on our self-insurance expense and liabilities.

[0001069202-14-000002:mdna:191]
Pension Benefits

[0001069202-14-000002:mdna:192]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  We also have several active defined benefit plans that provide benefits based on years of service.  In 2013 and 2012, we contributed $10 million and $29 million, respectively, to our pension plans.

[0001069202-14-000002:mdna:193]
We make several assumptions to calculate our liability and the expense for these benefit plans, including the discount rate and expected return on assets.  We used an assumed discount rate of 4.88% for pension benefits of our U.S.-based plans as of December 31, 2013.  Our assumed discount rates were selected using the yield curve for high-quality corporate bonds, which is dependent upon risk-free interest rates and current credit market conditions.  In 2013 and 2012, we utilized an assumed long-term rate of return on assets of 8.00%.  These are long-term estimates of equity values and are not dependent on short-term variations of the equity markets.  Differences between actual experience and our assumptions are quantified as actuarial gains and losses.  These actuarial gains and losses do not immediately impact our earnings as they are deferred in accumulated other comprehensive income (“AOCI”) and are amortized into net periodic benefit cost over the estimated service period.

[0001069202-14-000002:mdna:194]
The assumed long-term rate of return on assets and the discount rate have significant effects on the amounts reported for our defined benefit plans.  A 25 basis point decrease in the long-term rate of return on assets or discount rate would have the following effects (in millions):

[0001069202-14-000002:mdna:195]
|  | 25 Basis Point Decrease in Long-Term Rate of Return |  | 25 Basis Point Decrease in Discount Rate |
| Increase to net periodic benefit cost for U.S. pension plans | $ | 0.6 |  |  | $ | 0.5 |  |
| Increase to the pension benefit obligations for U.S. pension plans | n/a |  |  | 11.0 |  |

[0001069202-14-000002:mdna:196]
Should actual results differ from our estimates and assumptions, revisions to the benefit plan liabilities and the related expenses would be required.  Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on our pension benefits.

[0001069202-14-000002:mdna:197]
Derivative Accounting

[0001069202-14-000002:mdna:198]
We use futures contracts and fixed forward contracts to mitigate our exposure to volatility in commodity prices in the ordinary course of business.  Fluctuations in metal commodity prices impact the value of the derivative instruments that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases and conversely, when commodity prices fall, the fair value of our futures contracts decreases.  We are required to prepare and maintain contemporaneous documentation for futures contracts that are formally designated as cash flow hedges.  Our failure to comply with the strict documentation requirements could result in the de-designation of cash flow hedges, which may significantly impact our consolidated financial statements.  Refer to Note 8 in the Notes to the Consolidated Financial Statements for more information on our derivatives.

[0001069202-14-000002:mdna:199]
Goodwill and Intangible Assets

[0001069202-14-000002:mdna:200]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually in the first quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance

[0001069202-14-000002:mdna:201]
of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-14-000002:mdna:202]
We test goodwill for impairment annually in the first quarter.  We assign goodwill to the reporting units that benefit from the synergies of our acquisitions.  If we reorganize our management structure, the related goodwill is allocated to the affected reporting units based upon the relative fair values of those reporting units.  Assets and liabilities, including deferred income taxes, are generally directly assigned to the reporting units.  However, certain assets and liabilities, including intellectual property assets, information technology assets and pension, self-insurance and environmental liabilities, are centrally managed and are not allocated to the segments in the normal course of our financial reporting process, and therefore must be assigned to the reporting units based upon appropriate methods.  Reporting units that we test are generally equivalent to our business segments, or in some cases one level below, and are determined based upon a review of the periodic financial information supplied to and reviewed by our Chief Executive Officer (the chief operating decision maker).  Operating units are aggregated into reporting units when those operating units share similar economic characteristics.  We review our reporting unit structure each year as part of our annual goodwill impairment testing.

[0001069202-14-000002:mdna:203]
We review our indefinite-lived intangible assets for impairment annually in the first quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets.

[0001069202-14-000002:mdna:204]
We also periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-14-000002:mdna:205]
Refer to Note 4 of the Notes to the Consolidated Financial Statements for more information on our goodwill and intangible assets.

[0001069202-14-000002:mdna:206]
Recent Accounting Pronouncements

[0001069202-14-000002:mdna:207]
In July 2012, the FASB updated its guidance on the impairment testing of indefinite-lived intangible assets to allow companies to first assess qualitative factors when determining if it is more likely than not that indefinite-lived intangible assets are impaired. If, as a result of the qualitative assessment, it is determined that it is not more likely than not that the indefinite-lived intangible assets are impaired, then the Company is not required to take further action. This guidance was applicable to our annual impairment tests beginning in the first quarter of 2013.

[0001069202-14-000002:mdna:208]
In February 2013, the FASB updated its guidance related to the presentation of comprehensive income and accumulated other

[0001069202-14-000002:mdna:209]
comprehensive income ("AOCI").  The updated guidance requires additional footnote disclosure of items reclassified out of AOCI and into net income as well as the effect of the reclassifications on each affected Statement of Operations line item.  This updated guidance was applicable beginning in the first quarter of 2013 on a prospective basis.  The required disclosures can be found in Note 13 of the Notes to the Consolidated Financial Statements.
