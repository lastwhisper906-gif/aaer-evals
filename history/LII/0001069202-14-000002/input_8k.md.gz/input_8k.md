# LII 8-K — 0001193125-14-035982 filed 2014-02-05

## item codes, every 8-K on or before 2014-02-13

- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2014-02-13

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-035982:8k_2_02:1]
EX-99.1
2
d667961dex991.htm
EX-99.1

[0001193125-14-035982:8k_2_02:2]
EX-99.1

[0001193125-14-035982:8k_2_02:3]
Exhibit 99.1

[0001193125-14-035982:8k_2_02:4]
Lennox International Reports Record Fourth-Quarter and Full-Year Profit

[0001193125-14-035982:8k_2_02:5]
|  | • |  | 4Q13 revenue up 9%, led by 18% Residential and 13% Commercial growth |

[0001193125-14-035982:8k_2_02:6]
|  | • |  | 4Q13 adjusted EPS from continuing operations of $0.77 up 38% and GAAP EPS from continuing operations of $0.68 up 31% |

[0001193125-14-035982:8k_2_02:7]
|  | • |  | 2013 revenue up 8%, with adjusted EPS from continuing operations of $3.70 up 37% and GAAP EPS from continuing operations of $3.55 up 35% |

[0001193125-14-035982:8k_2_02:8]
|  | • |  | Reiterate 2014 revenue growth guidance of 3-7% |

[0001193125-14-035982:8k_2_02:9]
|  | • |  | Reiterate 2014 EPS from continuing operations guidance of $4.20-$4.60 |

[0001193125-14-035982:8k_2_02:10]
DALLAS, February 5, 2014 –
Lennox International Inc. (NYSE: LII) today reported fourth quarter and full year 2013 results. Financial results in prior periods have been revised to reflect sold businesses in discontinued operations.

[0001193125-14-035982:8k_2_02:11]
For the fourth quarter, revenue was $750 million, up 9% from the prior-year quarter. At constant currency, revenue was up 10%. Total segment profit margin was
8.2%, up 200 basis points from the prior-year quarter. Diluted earnings per share from continuing operations on an adjusted basis was $0.77, up 38% from $0.56 in the prior-year quarter. On a GAAP basis, diluted earnings per share from continuing
operations was $0.68, up 31% from $0.52 in the fourth quarter a year ago.

[0001193125-14-035982:8k_2_02:12]
For the full year, revenue was $3.2 billion, up 8% from the prior year. Foreign
exchange was neutral. Total segment profit margin was a record 9.4%, up 180 basis points from the prior year. Diluted earnings per share from continuing operations on an adjusted basis was $3.70, up 37% from $2.70 in the prior year. On a GAAP basis,
diluted earnings per share from continuing operations was $3.55, up 35% from $2.63 in the prior year.

[0001193125-14-035982:8k_2_02:13]
“Lennox International’s strong business
momentum continued in 2013, with revenue up 8% and adjusted EPS from continuing operations up 37% to a record $3.70,” said Chairman and CEO Todd Bluedorn. “Growth was led by our Residential business, which again outpaced the market on
strength in both replacement and new construction business. Residential profit was up 75% on 15% revenue growth at constant currency. Our Commercial business also outpaced the market in 2013 on growth in national account equipment and service, as
well as from our strategic expansion in the emergency replacement market. Commercial profit rose 19% on 7% revenue growth at constant currency. Our Refrigeration business had strong operational performance despite choppy market conditions globally.
Refrigeration revenue was down 1% at constant currency, but profit was up 10% for the year. With the company’s strong performance throughout the year and solid balance sheet, we repurchased $125 million of stock and raised the dividend 20% in
2013.

[0001193125-14-035982:8k_2_02:14]
“In the fourth quarter, the company’s momentum continued, with revenue up 10% at constant currency and
adjusted EPS from continuing operations up 38%. Residential revenue was up 18% at constant currency, and profit was up 198% from the prior-year quarter. Commercial revenue was up 13% at constant currency, and profit rose 31%. In Refrigeration,
market conditions remained challenging in the quarter. Refrigeration revenue was down 4% at constant currency, but profit was up 11% over the fourth quarter a year ago.

[0001193125-14-035982:8k_2_02:15]
“Looking ahead at 2014 overall, Lennox International is competitively well-positioned for continued market outperformance with our strong product
portfolio and expanding distribution network. With a solid balance sheet and strong cash generation, we will continue to invest in the business for growth. In addition, the company will maintain a competitive dividend and plans to repurchase $150
million of stock in 2014.”

[0001193125-14-035982:8k_2_02:16]
FOURTH QUARTER 2013 FINANCIAL HIGHLIGHTS

[0001193125-14-035982:8k_2_02:17]
Revenue: Revenue for the fourth quarter was $750 million, up 9% from the prior-year quarter. At constant currency, revenue was up 10%. Volume was up and
price/mix was flat on a revenue basis from the fourth quarter a year ago.

[0001193125-14-035982:8k_2_02:18]
Gross Profit: Gross profit in the fourth quarter was $208 million, up
23% from $168 million in the prior-year quarter. Gross margin was 27.7%, up 310 basis points from 24.6% in the fourth quarter a year ago. Gross profit was positively impacted by higher volume, favorable price/mix, and lower material costs, with
partial offsets from warranty expense and strategic investments in distribution.

[0001193125-14-035982:8k_2_02:19]
Income from Continuing Operations: For the fourth quarter,
adjusted income from continuing operations was $38 million, or $0.77 diluted earnings per share, compared to $29 million, or $0.56 diluted earnings per share from continuing operations in the prior-year quarter. On a GAAP basis, fourth quarter 2013
income from continuing operations was $34 million, or $0.68 diluted earnings per share, compared to $27 million, or $0.52 diluted earnings per share from continuing operations in the prior-year quarter.

[0001193125-14-035982:8k_2_02:20]
Adjusted income from continuing operations for the fourth quarter of 2013 excludes after-tax charges of $4.3 million, net, which are derived from:

[0001193125-14-035982:8k_2_02:21]
|  | • |  | $3.9 million charge related to asbestos litigation |

[0001193125-14-035982:8k_2_02:22]
|  | • |  | $1.3 million charge related to restructuring activities |

[0001193125-14-035982:8k_2_02:23]
|  | • |  | $0.4 million charge for other items, net |

[0001193125-14-035982:8k_2_02:24]
|  | • |  | ($1.1) million special product quality adjustments |

[0001193125-14-035982:8k_2_02:25]
|  | • |  | ($0.2) million net change in unrealized gains on unsettled futures contracts |

[0001193125-14-035982:8k_2_02:26]
FULL YEAR 2013 FINANCIAL HIGHLIGHTS

[0001193125-14-035982:8k_2_02:27]
Revenue: For the full year, revenue was $3.2 billion, up 8%. Foreign exchange was neutral. Volume and price/mix were up from the prior year.

[0001193125-14-035982:8k_2_02:28]
Gross Profit: Gross profit for the full year was $861 million, up 19% from $722 million in the prior year. Gross margin was 26.9%, up 240 basis points
from 24.5% in the prior year. Gross profit was positively impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from warranty expense and strategic investments in distribution.

[0001193125-14-035982:8k_2_02:29]
Income from Continuing Operations: Adjusted income from continuing operations for 2013 was $187 million, or $3.70 diluted earnings per share, compared
to $139 million, or $2.70 diluted earnings per share from continuing operations in the prior year. On a GAAP basis, income from continuing operations for 2013 was $180 million, or $3.55 diluted earnings per share, compared to $135 million, or $2.63
diluted earnings per share from continuing operations in the prior year.

[0001193125-14-035982:8k_2_02:30]
Adjusted income from continuing operations for 2013 excludes after-tax
charges of $7.4 million, net, which are derived from:

[0001193125-14-035982:8k_2_02:31]
|  | • |  | $3.9 million charge related to asbestos litigation |

[0001193125-14-035982:8k_2_02:32]
|  | • |  | $3.4 million charge related to restructuring activities |

[0001193125-14-035982:8k_2_02:33]
|  | • |  | $0.7 million for a special legal contingency charge |

[0001193125-14-035982:8k_2_02:34]
|  | • |  | $0.3 million net change in unrealized losses on unsettled futures contracts |

[0001193125-14-035982:8k_2_02:35]
|  | • |  | $0.6 million charge for other items, net |

[0001193125-14-035982:8k_2_02:36]
|  | • |  | ($1.5) million special product quality adjustment |

[0001193125-14-035982:8k_2_02:37]
Free Cash Flow and Total Debt: Cash from operations
for the fourth quarter was $145 million, compared to $157 million in the prior-year quarter. Capital expenditures were $37 million in the fourth quarter compared to $22 million in the prior-year quarter. Including $2 million in proceeds from the
disposal of property, plant and equipment (PP&E), free cash flow was $110 million, compared to $135 million in the prior-year quarter. For the full year, cash from operations was $210 million, compared to $221 million in the prior year. Capital
expenditures were $78 million in 2013 compared to $50 million in 2012. Including $2 million from the disposal of PP&E, free cash flow was $134 million for the full year, compared to $171 million in the prior year. The company repurchased $125
million of stock in 2013. Total debt at the end of 2013 was $400 million. Total cash and cash equivalents were $38 million ending the year.

[0001193125-14-035982:8k_2_02:38]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001193125-14-035982:8k_2_02:39]
Residential Heating and Cooling

[0001193125-14-035982:8k_2_02:40]
|  | • |  | 4Q13 revenue of $359 million, up 18% from $305 million in 4Q12; foreign exchange was neutral |

[0001193125-14-035982:8k_2_02:41]
|  | • |  | 4Q13 segment profit of $36 million, up 198% from $12 million in 4Q12 |

[0001193125-14-035982:8k_2_02:42]
|  | • |  | 4Q13 segment profit margin of 10.2%, up 620 basis points from 4.0% in 4Q12 |

[0001193125-14-035982:8k_2_02:43]
|  | • |  | 2013 revenue of $1,583 million, up 15% from $1,376 million in 2012; foreign exchange was neutral |

[0001193125-14-035982:8k_2_02:44]
|  | • |  | 2013 segment profit of $180 million, up 75% from $103 million in 2012 |

[0001193125-14-035982:8k_2_02:45]
|  | • |  | 2013 profit margin of 11.4%, up 390 basis points from 7.5% in 2012 |

[0001193125-14-035982:8k_2_02:46]
Fourth quarter results were positively
impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from warranty expense, and strategic investments in distribution expansion. Full-year results were positively impacted by higher volume, favorable
price/mix, and lower material costs, with partial offsets from higher SG&A, warranty expense, and strategic investments in distribution expansion.

[0001193125-14-035982:8k_2_02:47]
Commercial Heating and Cooling

[0001193125-14-035982:8k_2_02:48]
|  | • |  | 4Q13 revenue of $213 million, up 13% from $188 million in 4Q12; foreign exchange was neutral |

[0001193125-14-035982:8k_2_02:49]
|  | • |  | 4Q13 segment profit of $33 million, up 31% from $25 million in 4Q12 |

[0001193125-14-035982:8k_2_02:50]
|  | • |  | 4Q13 segment profit margin of 15.7%, up 220 basis points from 13.5% in 4Q12 |

[0001193125-14-035982:8k_2_02:51]
|  | • |  | 2013 revenue of $844 million, up 8% from $785 million in 2012; up 7% at constant currency |

[0001193125-14-035982:8k_2_02:52]
|  | • |  | 2013 segment profit of $118 million, up 19% from approximately $100 million in 2012 |

[0001193125-14-035982:8k_2_02:53]
|  | • |  | 2013 segment profit margin of 14.0%, up 130 basis points from 12.7% in 2012 |

[0001193125-14-035982:8k_2_02:54]
Fourth quarter and full year
results were positively impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from higher SG&A and strategic investments in distribution expansion.

[0001193125-14-035982:8k_2_02:55]
Refrigeration

[0001193125-14-035982:8k_2_02:56]
|  | • |  | 4Q13 revenue of $178 million, down 7% from $192 million in 4Q12; down 4% at constant currency |

[0001193125-14-035982:8k_2_02:57]
|  | • |  | 4Q13 segment profit of $24 million, up 11% from $21 million in 4Q12 |

[0001193125-14-035982:8k_2_02:58]
|  | • |  | 4Q13 segment profit margin of 13.3%, up 220 basis points from 11.1% in 4Q12 |

[0001193125-14-035982:8k_2_02:59]
|  | • |  | 2013 revenue of $772 million, down 2% from $788 million in 2012; down 1% at constant currency |

[0001193125-14-035982:8k_2_02:60]
|  | • |  | 2013 segment profit of $90 million, up 10% from $82 million in 2012 |

[0001193125-14-035982:8k_2_02:61]
|  | • |  | 2013 segment profit margin of 11.7%, up 130 basis points from 10.4% in 2012 |

[0001193125-14-035982:8k_2_02:62]
Fourth quarter and full year
results were positively impacted by favorable price/mix and lower material costs, with partial offsets from lower volume and higher SG&A.

[0001193125-14-035982:8k_2_02:63]
2014 FULL YEAR OUTLOOK

[0001193125-14-035982:8k_2_02:64]
The company reiterates its 2014 guidance, originally provided on December 18, 2013:

[0001193125-14-035982:8k_2_02:65]
|  | • |  | Revenue growth of 3-7%, with a neutral impact from foreign exchange |

[0001193125-14-035982:8k_2_02:66]
|  | • |  | Adjusted and GAAP EPS from continuing operations of $4.20-$4.60 |

[0001193125-14-035982:8k_2_02:67]
|  | • |  | Effective tax rate of 34-35% |

[0001193125-14-035982:8k_2_02:68]
|  | • |  | Capital expenditures of approximately $90 million |

[0001193125-14-035982:8k_2_02:69]
|  | • |  | Stock repurchases of $150 million |

[0001193125-14-035982:8k_2_02:70]
CONFERENCE CALL INFORMATION

[0001193125-14-035982:8k_2_02:71]
A conference call to discuss the company’s fourth quarter and full year 2013 results will be held this morning at 8:30 a.m. Central time. To listen, call
the conference call line at 612-332-0228 at least 10 minutes prior to the scheduled start time and use reservation number 315637. This conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com.

[0001193125-14-035982:8k_2_02:72]
A replay will be available from 11:00 a.m. Central time on February 5 through February 12, 2014, by dialing 800-475-6701 (U.S.) or
320-365-3844 (international) and using access code 315637. This call will also be archived on the company’s web site.

[0001193125-14-035982:8k_2_02:73]
Lennox International
Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under the symbol “LII.” Additional information is available at
www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-14-035982:8k_2_02:74]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-035982:8k_2_02:75]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-14-035982:8k_2_02:76]
(In millions, except per share data)

[0001193125-14-035982:8k_2_02:77]
|  |  | (Unaudited) For the Three Months |  |  | For the Years Ended |  |
|  |  | Ended December 31, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net sales |  | $ | 749.5 |  |  | $ | 684.9 |  |  | $ | 3,199.1 |  |  | $ | 2,949.4 |  |
| Cost of goods sold |  |  | 541.8 |  |  |  | 516.5 |  |  |  | 2,337.9 |  |  |  | 2,227.1 |  |
| Gross profit |  |  | 207.7 |  |  |  | 168.4 |  |  |  | 861.2 |  |  |  | 722.3 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 146.0 |  |  |  | 127.2 |  |  |  | 570.1 |  |  |  | 507.0 |  |
| Losses and other expenses, net |  |  | 6.4 |  |  |  | 2.3 |  |  |  | 9.3 |  |  |  | 2.5 |  |
| Restructuring charges |  |  | 1.8 |  |  |  | 1.1 |  |  |  | 5.0 |  |  |  | 4.2 |  |
| Income from equity method investments |  |  | (1.4 | ) |  |  | (1.6 | ) |  |  | (12.2 | ) |  |  | (10.5 | ) |
| Operational income from continuing operations |  |  | 54.9 |  |  |  | 39.4 |  |  |  | 289.0 |  |  |  | 219.1 |  |
| Interest expense, net |  |  | 3.8 |  |  |  | 3.6 |  |  |  | 14.5 |  |  |  | 17.1 |  |
| Other expense, net |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.3 |  |
| Income from continuing operations before income taxes |  |  | 50.8 |  |  |  | 35.6 |  |  |  | 274.3 |  |  |  | 201.7 |  |
| Provision for income taxes |  |  | 16.8 |  |  |  | 9.1 |  |  |  | 94.4 |  |  |  | 66.7 |  |
| Income from continuing operations |  |  | 34.0 |  |  |  | 26.5 |  |  |  | 179.9 |  |  |  | 135.0 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from discontinued operations before income taxes |  |  | 2.4 |  |  |  | (7.7 | ) |  |  | (13.3 | ) |  |  | (64.9 | ) |
| Expense for (benefit from) income taxes |  |  | 1.2 |  |  |  | (3.1 | ) |  |  | (5.2 | ) |  |  | (19.9 | ) |
| Income (loss) from discontinued operations |  |  | 1.2 |  |  |  | (4.6 | ) |  |  | (8.1 | ) |  |  | (45.0 | ) |
| Net income |  | $ | 35.2 |  |  | $ | 21.9 |  |  | $ | 171.8 |  |  | $ | 90.0 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.69 |  |  | $ | 0.53 |  |  | $ | 3.61 |  |  | $ | 2.66 |  |
| Income (loss) from discontinued operations |  |  | 0.03 |  |  |  | (0.09 | ) |  |  | (0.16 | ) |  |  | (0.89 | ) |
| Net income |  | $ | 0.72 |  |  | $ | 0.44 |  |  | $ | 3.45 |  |  | $ | 1.77 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.68 |  |  | $ | 0.52 |  |  | $ | 3.55 |  |  | $ | 2.63 |  |
| Income (loss) from discontinued operations |  |  | 0.02 |  |  |  | (0.09 | ) |  |  | (0.16 | ) |  |  | (0.88 | ) |
| Net income |  | $ | 0.70 |  |  | $ | 0.43 |  |  | $ | 3.39 |  |  | $ | 1.75 |  |
| Average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 49.2 |  |  |  | 50.3 |  |  |  | 49.8 |  |  |  | 50.7 |  |
| Diluted |  |  | 50.1 |  |  |  | 51.1 |  |  |  | 50.6 |  |  |  | 51.4 |  |
| Cash dividends declared per share |  | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 0.92 |  |  | $ | 0.76 |  |

[0001193125-14-035982:8k_2_02:78]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-035982:8k_2_02:79]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001193125-14-035982:8k_2_02:80]
(In millions)

[0001193125-14-035982:8k_2_02:81]
|  |  | (Unaudited) For the Three Months |  |  | For the Years Ended |  |
|  |  | Ended December 31, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 358.6 |  |  | $ | 305.0 |  |  | $ | 1,583.2 |  |  | $ | 1,375.8 |  |
| Commercial Heating & Cooling |  |  | 212.6 |  |  |  | 187.5 |  |  |  | 844.4 |  |  |  | 785.4 |  |
| Refrigeration |  |  | 178.3 |  |  |  | 192.4 |  |  |  | 771.5 |  |  |  | 788.2 |  |
|  |  | $ | 749.5 |  |  | $ | 684.9 |  |  | $ | 3,199.1 |  |  | $ | 2,949.4 |  |
| Segment Profit (Loss) (A) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 36.4 |  |  | $ | 12.2 |  |  | $ | 180.1 |  |  | $ | 102.9 |  |
| Commercial Heating & Cooling |  |  | 33.3 |  |  |  | 25.4 |  |  |  | 118.1 |  |  |  | 99.5 |  |
| Refrigeration |  |  | 23.7 |  |  |  | 21.3 |  |  |  | 90.2 |  |  |  | 81.9 |  |
| Corporate and other |  |  | (31.8 | ) |  |  | (16.4 | ) |  |  | (87.9 | ) |  |  | (60.1 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 61.6 |  |  |  | 42.5 |  |  |  | 300.5 |  |  |  | 224.2 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (1.9 | ) |  |  | 0.1 |  |  |  | (2.3 | ) |  |  | 1.1 |  |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (B) |  |  | 6.8 |  |  |  | 1.9 |  |  |  | 8.8 |  |  |  | (0.2 | ) |
| Restructuring charges |  |  | 1.8 |  |  |  | 1.1 |  |  |  | 5.0 |  |  |  | 4.2 |  |
| Interest expense, net |  |  | 3.8 |  |  |  | 3.6 |  |  |  | 14.5 |  |  |  | 17.1 |  |
| Other expense, net |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.3 |  |
| Income from continuing operations before income taxes |  | $ | 50.8 |  |  | $ | 35.6 |  |  | $ | 274.3 |  |  | $ | 201.7 |  |

[0001193125-14-035982:8k_2_02:82]
| (A) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-14-035982:8k_2_02:83]
|  | • |  | Special product quality adjustments; |

[0001193125-14-035982:8k_2_02:84]
|  | • |  | Items in Losses and other expenses, net that are noted in (B); |

[0001193125-14-035982:8k_2_02:85]
|  | • |  | Restructuring charges; |

[0001193125-14-035982:8k_2_02:86]
|  | • |  | Goodwill, long-lived asset and equity method investment impairments; |

[0001193125-14-035982:8k_2_02:87]
|  | • |  | Interest expense, net; |

[0001193125-14-035982:8k_2_02:88]
|  | • |  | Other expense, net. |

[0001193125-14-035982:8k_2_02:89]
| (B) | Items in Losses and other expenses, net that are excluded from segment profit or loss are the net change in unrealized gains and/or losses on unsettled futures contracts, special legal contingency charges, asbestos-related litigation and other items. |

[0001193125-14-035982:8k_2_02:90]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-035982:8k_2_02:91]
CONSOLIDATED BALANCE SHEETS

[0001193125-14-035982:8k_2_02:92]
(In millions, except shares and par values)

[0001193125-14-035982:8k_2_02:93]
|  |  | As of December 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 38.0 |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net of allowances of $9.8 and $9.5 in 2013 and 2012, respectively |  |  | 408.1 |  |  |  | 373.4 |  |
| Inventories, net |  |  | 378.8 |  |  |  | 374.8 |  |
| Deferred income taxes, net |  |  | 24.5 |  |  |  | 27.5 |  |
| Other assets |  |  | 53.0 |  |  |  | 61.0 |  |
| Assets of discontinued operations |  |  | — |  |  |  | 98.6 |  |
| Total current assets |  |  | 902.4 |  |  |  | 987.1 |  |
| Property, plant and equipment, net |  |  | 335.5 |  |  |  | 298.2 |  |
| Goodwill |  |  | 216.8 |  |  |  | 223.8 |  |
| Deferred income taxes |  |  | 88.5 |  |  |  | 102.8 |  |
| Other assets, net |  |  | 83.5 |  |  |  | 80.0 |  |
| Total assets |  | $ | 1,626.7 |  |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 165.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt |  |  | 1.3 |  |  |  | 0.7 |  |
| Accounts payable |  |  | 283.1 |  |  |  | 284.7 |  |
| Accrued expenses |  |  | 232.1 |  |  |  | 220.0 |  |
| Income taxes payable |  |  | 31.6 |  |  |  | 4.5 |  |
| Liabilities of discontinued operations |  |  | — |  |  |  | 55.2 |  |
| Total current liabilities |  |  | 714.0 |  |  |  | 600.0 |  |
| Long-term debt |  |  | 233.2 |  |  |  | 351.0 |  |
| Post-retirement benefits, other than pensions |  |  | 4.6 |  |  |  | 6.1 |  |
| Pensions |  |  | 70.0 |  |  |  | 134.4 |  |
| Other liabilities |  |  | 119.2 |  |  |  | 102.1 |  |
| Total liabilities |  |  | 1,141.0 |  |  |  | 1,193.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 912.7 |  |  |  | 898.3 |  |
| Retained earnings |  |  | 870.5 |  |  |  | 744.4 |  |
| Accumulated other comprehensive loss |  |  | (61.1 | ) |  |  | (22.3 | ) |
| Treasury stock, at cost, 38,066,794 shares and 36,937,632 shares for 2013 and 2012, respectively |  |  | (1,238.1 | ) |  |  | (1,124.5 | ) |
| Noncontrolling interests |  |  | 0.8 |  |  |  | 1.5 |  |
| Total stockholders’ equity |  |  | 485.7 |  |  |  | 498.3 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,626.7 |  |  | $ | 1,691.9 |  |

[0001193125-14-035982:8k_2_02:94]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-035982:8k_2_02:95]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-14-035982:8k_2_02:96]
For the Years Ended December 31, 2013 and 2012

[0001193125-14-035982:8k_2_02:97]
(In millions)

[0001193125-14-035982:8k_2_02:98]
|  |  | 2013 |  |  | 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 171.8 |  |  | $ | 90.0 |  |
| Net loss from discontinued operations |  |  | 8.1 |  |  |  | 45.0 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (12.2 | ) |  |  | (10.5 | ) |
| Dividends from affiliates |  |  | 10.3 |  |  |  | 9.3 |  |
| Restructuring expenses, net of cash paid |  |  | 0.1 |  |  |  | 0.1 |  |
| Provision for bad debts |  |  | 3.6 |  |  |  | 3.9 |  |
| Unrealized losses (gains) on derivative contracts |  |  | 0.3 |  |  |  | (1.0 | ) |
| Stock-based compensation expense |  |  | 29.3 |  |  |  | 15.2 |  |
| Depreciation and amortization |  |  | 58.9 |  |  |  | 55.4 |  |
| Deferred income taxes |  |  | 3.5 |  |  |  | (2.7 | ) |
| Pension costs in excess of (less than) contributions |  |  | 1.7 |  |  |  | (15.1 | ) |
| Other items, net |  |  | 4.5 |  |  |  | 2.1 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (49.0 | ) |  |  | 13.3 |  |
| Inventories |  |  | (19.5 | ) |  |  | (55.8 | ) |
| Other current assets |  |  | (16.3 | ) |  |  | (1.5 | ) |
| Accounts payable |  |  | (10.9 | ) |  |  | 37.1 |  |
| Accrued expenses |  |  | 15.4 |  |  |  | 35.8 |  |
| Income taxes payable and receivable |  |  | 21.9 |  |  |  | 18.2 |  |
| Other, net |  |  | 4.4 |  |  |  | (2.2 | ) |
| Net cash used in discontinued operations |  |  | (15.6 | ) |  |  | (15.2 | ) |
| Net cash provided by operating activities |  |  | 210.3 |  |  |  | 221.4 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 2.4 |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | (78.3 | ) |  |  | (50.2 | ) |
| Net proceeds from sale of businesses |  |  | 8.6 |  |  |  | 10.1 |  |
| Net cash used in discontinued operations |  |  | — |  |  |  | (0.4 | ) |
| Net cash used in investing activities |  |  | (67.3 | ) |  |  | (40.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 2.0 |  |  |  | 0.2 |  |
| Asset securitization borrowings |  |  | 330.0 |  |  |  | 645.0 |  |
| Asset securitization payments |  |  | (200.0 | ) |  |  | (615.0 | ) |
| Long-term debt payments |  |  | (1.0 | ) |  |  | (1.1 | ) |
| Borrowings from revolving credit facility |  |  | 1,425.5 |  |  |  | 967.0 |  |
| Payments on revolving credit facility |  |  | (1,543.5 | ) |  |  | (1,075.0 | ) |
| Additional investment in subsidiary |  |  | (0.5 | ) |  |  | — |  |
| Proceeds from employee stock purchases |  |  | 1.8 |  |  |  | 0.8 |  |
| Repurchases of common stock |  |  | (125.0 | ) |  |  | (50.1 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (12.0 | ) |  |  | (7.8 | ) |
| Excess tax benefits related to share-based payments |  |  | 6.5 |  |  |  | 3.5 |  |
| Cash dividends paid |  |  | (34.0 | ) |  |  | (47.6 | ) |
| Net cash used in financing activities |  |  | (150.2 | ) |  |  | (180.1 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | (7.2 | ) |  |  | 0.9 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (6.6 | ) |  |  | 5.9 |  |
| Cash and cash equivalents, beginning of year |  |  | 51.8 |  |  |  | 45.0 |  |
| Cash and cash equivalents, end of year |  | $ | 38.0 |  |  | $ | 51.8 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the year for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 15.7 |  |  | $ | 18.2 |  |
| Income taxes (net of refunds) |  | $ | 56.8 |  |  | $ | 30.1 |  |

[0001193125-14-035982:8k_2_02:99]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-035982:8k_2_02:100]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-14-035982:8k_2_02:101]
(Unaudited)

[0001193125-14-035982:8k_2_02:102]
(In
millions, except per share and ratio data)

[0001193125-14-035982:8k_2_02:103]
Use of Non-GAAP Financial Measures

[0001193125-14-035982:8k_2_02:104]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP
financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in
understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating performance.

[0001193125-14-035982:8k_2_02:105]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-14-035982:8k_2_02:106]
|  |  | For the Three Months |  |  | For the Years Ended |  |
|  |  | Ended December 31, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Income from continuing operations, a GAAP measure |  | $ | 34.0 |  |  | $ | 26.5 |  |  | $ | 179.9 |  |  | $ | 135.0 |  |
| Restructuring charges, after tax |  |  | 1.3 |  |  |  | 0.7 |  |  |  | 3.4 |  |  |  | 2.7 |  |
| Special product quality adjustments, after tax (b) |  |  | (1.1 | ) |  |  | — |  |  |  | (1.5 | ) |  |  | 0.9 |  |
| Special legal contingency charges, after tax (a) |  |  | 0.1 |  |  |  | 0.8 |  |  |  | 0.7 |  |  |  | 0.8 |  |
| Asbestos-related litigation, after tax (a) |  |  | 3.9 |  |  |  | — |  |  |  | 3.9 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts, after tax (a) |  |  | (0.2 | ) |  |  | 0.3 |  |  |  | 0.3 |  |  |  | (1.4 | ) |
| Other items, net, after tax (a) |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.6 |  |  |  | 0.6 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 38.3 |  |  | $ | 28.5 |  |  | $ | 187.3 |  |  | $ | 138.6 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 0.68 |  |  | $ | 0.52 |  |  | $ | 3.55 |  |  | $ | 2.63 |  |
| Restructuring charges, after tax |  |  | 0.03 |  |  |  | 0.01 |  |  |  | 0.07 |  |  |  | 0.05 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.02 | ) |  |  | — |  |  |  | (0.03 | ) |  |  | 0.02 |  |
| Special legal contingency charges, after tax (a) |  |  | — |  |  |  | 0.02 |  |  |  | 0.01 |  |  |  | 0.02 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.08 |  |  |  | — |  |  |  | 0.08 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts and other items, net, after tax (a) |  |  | — |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | (0.02 | ) |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  | $ | 0.77 |  |  | $ | 0.56 |  |  | $ | 3.70 |  |  | $ | 2.70 |  |

[0001193125-14-035982:8k_2_02:107]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-14-035982:8k_2_02:108]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-14-035982:8k_2_02:109]
|  |  | For the Three Months |  |  | For the Years Ended |  |
|  |  | Ended December 31, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled futures contracts (a) |  | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | 1.0 |  |  | $ | 1.5 |  |
| Foreign currency exchange losses (a) |  |  | 0.4 |  |  |  | — |  |  |  | 0.5 |  |  |  | 0.8 |  |
| Losses (gains) on disposal of fixed assets (a) |  |  | (1.0 | ) |  |  | 0.3 |  |  |  | (1.0 | ) |  |  | 0.4 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | (0.2 | ) |  |  | 0.3 |  |  |  | 0.4 |  |  |  | (2.2 | ) |
| Special legal contingency charges (b) |  |  | 0.1 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Asbestos-related litigation (b) |  |  | 6.3 |  |  |  | — |  |  |  | 6.3 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.6 |  |  |  | 0.4 |  |  |  | 0.9 |  |  |  | 0.8 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 6.4 |  |  | $ | 2.3 |  |  | $ | 9.3 |  |  | $ | 2.5 |  |

[0001193125-14-035982:8k_2_02:110]
| (a) | Included in segment profit (loss) and adjusted income from continuing operations |

[0001193125-14-035982:8k_2_02:111]
| (b) | Excluded from segment profit (loss) and adjusted income from continuing operations |

[0001193125-14-035982:8k_2_02:112]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure:

[0001193125-14-035982:8k_2_02:113]
|  |  | For the Year |  |
|  |  | Ended |  |
|  |  | December 31, |  |
|  |  | 2014 |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 4.20 - $4.60 |  |
| Restructuring charges and other items |  |  | — |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 4.20 - $4.60 |  |

[0001193125-14-035982:8k_2_02:114]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure

[0001193125-14-035982:8k_2_02:115]
|  |  | For the Three Months |  |  | For the Years Ended |  |
|  |  | Ended December 31, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 145.3 |  |  | $ | 157.0 |  |  | $ | 210.3 |  |  | $ | 221.4 |  |
| Purchases of property, plant and equipment |  |  | (37.3 | ) |  |  | (22.2 | ) |  |  | (78.3 | ) |  |  | (50.2 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 2.3 |  |  |  | — |  |  |  | 2.4 |  |  |  | 0.1 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 110.3 |  |  | $ | 134.8 |  |  | $ | 134.4 |  |  | $ | 171.3 |  |

[0001193125-14-035982:8k_2_02:116]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | December 31, |  |
|  |  | 2013 |  |
| Calculation of Debt to EBITDA Ratio: |  |  |  |  |
| EBIT (a) |  | $ | 300.5 |  |
| Depreciation and amortization expense (b) |  | $ | 58.9 |  |
| EBITDA (a + b) |  | $ | 359.4 |  |
| Total debt at December 31, 2013 (c) |  | $ | 400.4 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 1.1 |  |

[0001193125-14-035982:8k_2_02:117]
Reconciliation of EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure:

[0001193125-14-035982:8k_2_02:118]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | December 31, |  |
|  |  | 2013 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 300.5 |  |
| Special product quality adjustments |  |  | (2.3 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 8.8 |  |
| Restructuring charges |  |  | 5.0 |  |
| Interest expense, net |  |  | 14.5 |  |
| Other expenses, net |  |  | 0.2 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 274.3 |  |
