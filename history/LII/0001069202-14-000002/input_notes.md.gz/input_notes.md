# LII notes — 0001069202-14-000002


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-14-000002:notes:1]
Accrued Expenses:

[0001069202-14-000002:notes:2]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-14-000002:notes:3]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Accrued compensation and benefits | $ | 85.7 |  |  | $ | 77.8 |  |
| Self insurance reserves | 13.4 |  |  | 17.6 |  |
| Deferred income | 9.8 |  |  | 16.0 |  |
| Accrued warranties | 28.7 |  |  | 25.1 |  |
| Accrued product quality issues | 4.7 |  |  | 6.7 |  |
| Accrued rebates and promotions | 37.0 |  |  | 35.8 |  |
| Derivative contracts | 1.5 |  |  | 0.1 |  |
| Other | 51.3 |  |  | 40.9 |  |
| Total Accrued expenses | $ | 232.1 |  |  | $ | 220.0 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-14-000002:notes:4]
Supplemental Information:

[0001069202-14-000002:notes:5]
Below is information about expenses included in our Consolidated Statements of Operations (in millions):

[0001069202-14-000002:notes:6]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Research and development (1) | $ | 53.7 |  |  | $ | 50.7 |  |  | $ | 50.3 |  |
| Advertising, promotions and marketing (2) | 45.2 |  |  | 59.4 |  |  | 58.4 |  |
| Cooperative advertising expenditures (3) | 10.9 |  |  | 9.5 |  |  | 9.7 |  |
| Rent expense (4) | 53.5 |  |  | 67.8 |  |  | 69.6 |  |

[0001069202-14-000002:notes:7]
(1) Includes research and development costs related to discontinued operations of $1.2 million and $3.3 million for the years ended December 31, 2012 and 2011, respectively.  No research and development costs related to discontinued operations were recorded for the year ended December 31, 2013.

[0001069202-14-000002:notes:8]
(2) Includes advertising, promotions and marketing costs related to discontinued operations of $4.1 million, $20.1 million and $22.2 million for the years ended December 31, 2013, 2012 and 2011, respectively. Cooperative advertising expenditures were not included in these amounts.

[0001069202-14-000002:notes:9]
(3) Cooperative advertising expenditures were included in Selling, general and administrative expenses in the Consolidated Statements of Operations.

[0001069202-14-000002:notes:10]
(4) Includes rent expense related to discontinued operations of $4.5 million, $20.1 million and $20.7 million for the years ended December 31, 2013, 2012 and 2011, respectively.

[0001069202-14-000002:notes:11]
Interest Expense, net

[0001069202-14-000002:notes:12]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-14-000002:notes:13]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Interest expense, net of capitalized interest | $ | 16.5 |  |  | $ | 18.9 |  |  | $ | 18.7 |  |
| Interest income | 2.0 |  |  | 1.8 |  |  | 1.9 |  |
| Interest expense, net | $ | 14.5 |  |  | $ | 17.1 |  |  | $ | 16.8 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001069202-14-000002:notes:14]
Cash and Cash Equivalents

[0001069202-14-000002:notes:15]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-14-000002:notes:16]
Commitments and Contingencies:

[0001069202-14-000002:notes:17]
Leases

[0001069202-14-000002:notes:18]
We lease certain real and personal property under non-cancelable operating leases.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions.  We recognize our minimum rental expense on a straight-line basis.  We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use.

[0001069202-14-000002:notes:19]
Future annual minimum lease payments and capital lease commitments as of December 31, 2013 were as follows (in millions):

[0001069202-14-000002:notes:20]
|  | Operating Leases |  | Capital Leases |
| 2014 | $ | 40.1 |  |  | $ | 1.7 |  |
| 2015 | 29.8 |  |  | 1.4 |  |
| 2016 | 22.6 |  |  | 0.4 |  |
| 2017 | 18.1 |  |  | 0.2 |  |
| 2018 | 13.7 |  |  | — |  |
| Thereafter | 13.1 |  |  | 14.5 |  |
| Total minimum lease payments | $ | 137.4 |  |  | 18.2 |  |
| Less amount representing interest |  |  | 0.7 |  |
| Present value of minimum payments |  |  | $ | 17.5 |  |

[0001069202-14-000002:notes:21]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the “Lake Park Renewal”).  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-14-000002:notes:22]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Fourth Amended and Restated Revolving Credit Facility Agreement.  We were in compliance with these financial covenants as of December 31, 2013.

[0001069202-14-000002:notes:23]
Environmental

[0001069202-14-000002:notes:24]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities, however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental reserves are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000002:notes:25]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Accrued expenses | $ | 1.4 |  |  | $ | 1.4 |  |
| Other liabilities | 3.8 |  |  | 3.7 |  |
| Total environmental reserves | $ | 5.2 |  |  | $ | 5.1 |  |

[0001069202-14-000002:notes:26]
Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-14-000002:notes:27]
Product Warranties and Product Related Contingencies

[0001069202-14-000002:notes:28]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-14-000002:notes:29]
Total product warranty liabilities related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000002:notes:30]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Accrued expenses | $ | 28.7 |  |  | $ | 25.1 |  |
| Other liabilities | 52.9 |  |  | 46.8 |  |
| Total product warranty liabilities | $ | 81.6 |  |  | $ | 71.9 |  |

[0001069202-14-000002:notes:31]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2013 and 2012 were as follows (in millions):

[0001069202-14-000002:notes:32]
| Total warranty liability as of December 31, 2011 | $ | 68.3 |  |
| Payments made in 2012 | (22.4 | ) |
| Changes resulting from issuance of new warranties | 25.1 |  |
| Changes in estimates associated with pre-existing liabilities | 0.6 |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (21.3 | ) |
| Changes resulting from issuance of new warranties | 29.6 |  |
| Changes in estimates associated with pre-existing liabilities | 1.6 |  |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |

[0001069202-14-000002:notes:33]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and, from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand.  We have non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue.  The expenses related to these product quality issues were classified in Cost of goods sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the Consolidated Balance Sheets.  The liabilities for these product quality issues are not included in the above tables related to our estimated warranty liabilities.  We may incur additional charges in the future as more information becomes available.

[0001069202-14-000002:notes:34]
The changes in the accrued product quality issues for the years ended December 31, 2013 and 2012 were as follows (in millions):

[0001069202-14-000002:notes:35]
| Total accrued product quality issues as of December 31, 2011 | $ | 7.5 |  |
| Changes in estimates associated with pre-existing liabilities | 2.2 |  |
| Product quality claims | (3.0 | ) |
| Total accrued product quality issues as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | (0.6 | ) |
| Product quality claims | (1.4 | ) |
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |

[0001069202-14-000002:notes:36]
Self Insurance

[0001069202-14-000002:notes:37]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability, auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers' compensation/employers' liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors' and officers' liability, property damage and certain other insurance programs.    For directors' and officers' liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-14-000002:notes:38]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001069202-14-000002:notes:39]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000002:notes:40]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Accrued expenses | $ | 13.4 |  |  | $ | 17.6 |  |
| Other liabilities | 32.0 |  |  | 39.6 |  |
| Total self-insurance liabilities | $ | 45.4 |  |  | $ | 57.2 |  |

[0001069202-14-000002:notes:41]
Litigation

[0001069202-14-000002:notes:42]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-14-000002:notes:43]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors, and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the year ended December 31, 2013, we recorded expense of $6.7 million, net of probable insurance recoveries, for known and future asbestos-related litigation.

[0001069202-14-000002:notes:44]
We are also involved in patent litigation claims related to products from an acquired business.  The Company has indemnification protection, with certain limitations, for these claims.  Costs related to this and all other non-asbestos matters were not material to the results of operations for the periods presented.

[0001069202-14-000002:notes:45]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-14-000002:notes:46]
Comprehensive Income:

[0001069202-14-000002:notes:47]
The following table provides information on items not reclassified in their entirety from AOCI to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-14-000002:notes:48]
| AOCI Component |  | For the Year Ended December 31, 2013 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Losses on cash flow hedges: |  |  |  |  |
| Commodity derivative contracts |  | $ | (4.2 | ) |  | Cost of goods sold |
| Income tax benefit |  | 1.5 |  |  | Provision for income taxes |
| Net of tax |  | $ | (2.7 | ) |  |  |
| Defined Benefit Plan Items: |  |  |  |  |
| Pension and Post-Retirement Benefits costs |  | $ | (9.5 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 3.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (6.1 | ) |  |  |
| Foreign currency translation adjustments: |  |  |  |  |
| Sale of foreign business (1) |  | $ | 41.1 |  |  | Loss from discontinued operations |
| Total reclassifications from AOCI |  | $ | 32.3 |  |  |  |

[0001069202-14-000002:notes:49]
(1) The reclassification of foreign currency translation adjustments related to the sale of the Service Experts business in the first quarter of 2013.  Refer to Note 17 for details.

[0001069202-14-000002:notes:50]
The following table provides information on changes in AOCI, by component (net of tax), for the year ended December 31, 2013 (in millions):

[0001069202-14-000002:notes:51]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2012 |  | $ | 1.1 |  |  | $ | 9.3 |  |  | $ | (147.5 | ) |  | $ | 114.8 |  |  | $ | (22.3 | ) |
| Other comprehensive (loss) income before reclassifications |  | (4.4 | ) |  | (6.8 | ) |  | 35.4 |  |  | (30.7 | ) |  | (6.5 | ) |
| Amounts reclassified from AOCI |  | 2.7 |  |  | — |  |  | 6.1 |  |  | (41.1 | ) |  | (32.3 | ) |
| Net other comprehensive (loss) income |  | (1.7 | ) |  | (6.8 | ) |  | 41.5 |  |  | (71.8 | ) |  | (38.8 | ) |
| Balance as of December 31, 2013 |  | $ | (0.6 | ) |  | $ | 2.5 |  |  | $ | (106.0 | ) |  | $ | 43.0 |  |  | $ | (61.1 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-14-000002:notes:52]
Condensed Consolidating Financial Statements:

[0001069202-14-000002:notes:53]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-14-000002:notes:54]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present condensed consolidating financial statements.

[0001069202-14-000002:notes:55]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd.  The primary subsidiary for the U.S. Service Experts business had previously been included as a "Guarantor Subsidiary" and the Canada Service Experts subsidiary had previously been included as a "Non-Guarantor Subsidiary."  As of December 31, 2013, the U.S. and Canada Service Experts businesses were included in discontinued operations of the condensed consolidating financial statements.

[0001069202-14-000002:notes:56]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001069202-14-000002:notes:57]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2013 and December 31, 2012 and for the years ended December 31, 2013, 2012 and 2011 are shown on the following pages.

[0001069202-14-000002:notes:58]
Condensed Consolidating Balance Sheets

[0001069202-14-000002:notes:59]
As of December 31, 2013

[0001069202-14-000002:notes:60]
(In millions)

[0001069202-14-000002:notes:61]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.1 |  |  | $ | 10.5 |  |  | $ | 26.4 |  |  | $ | — |  |  | $ | 38.0 |  |
| Accounts and notes receivable, net | — |  |  | 12.8 |  |  | 395.3 |  |  | — |  |  | 408.1 |  |
| Inventories, net | — |  |  | 253.6 |  |  | 128.4 |  |  | (3.2 | ) |  | 378.8 |  |
| Deferred income taxes, net | 0.9 |  |  | 21.2 |  |  | 5.7 |  |  | (3.3 | ) |  | 24.5 |  |
| Other assets | 3.4 |  |  | 38.4 |  |  | 70.2 |  |  | (59.0 | ) |  | 53.0 |  |
| Assets of discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total current assets | 5.4 |  |  | 336.5 |  |  | 626.0 |  |  | (65.5 | ) |  | 902.4 |  |
| Property, plant and equipment, net | — |  |  | 246.4 |  |  | 89.1 |  |  | — |  |  | 335.5 |  |
| Goodwill | — |  |  | 140.4 |  |  | 76.4 |  |  | — |  |  | 216.8 |  |
| Investment in subsidiaries | 1,138.8 |  |  | 337.5 |  |  | (0.6 | ) |  | (1,475.7 | ) |  | — |  |
| Deferred income taxes | — |  |  | 76.9 |  |  | 20.2 |  |  | (8.6 | ) |  | 88.5 |  |
| Other assets, net | 4.2 |  |  | 64.3 |  |  | 16.4 |  |  | (1.4 | ) |  | 83.5 |  |
| Intercompany receivables (payables), net | (460.6 | ) |  | 434.0 |  |  | 26.6 |  |  | — |  |  | — |  |
| Total assets | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 165.9 |  |  | $ | — |  |  | $ | 165.9 |  |
| Current maturities of long-term debt | — |  |  | 1.0 |  |  | 0.3 |  |  | — |  |  | 1.3 |  |
| Accounts payable | 11.8 |  |  | 187.8 |  |  | 83.5 |  |  | — |  |  | 283.1 |  |
| Accrued expenses | 3.3 |  |  | 168.4 |  |  | 60.4 |  |  | — |  |  | 232.1 |  |
| Income taxes payable | (30.3 | ) |  | 75.7 |  |  | 49.9 |  |  | (63.7 | ) |  | 31.6 |  |
| Liabilities of discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total current liabilities | (15.2 | ) |  | 432.9 |  |  | 360.0 |  |  | (63.7 | ) |  | 714.0 |  |
| Long-term debt | 217.0 |  |  | 15.8 |  |  | 0.4 |  |  | — |  |  | 233.2 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| Pensions | — |  |  | 58.4 |  |  | 11.6 |  |  | — |  |  | 70.0 |  |
| Other liabilities | 0.3 |  |  | 119.4 |  |  | 11.3 |  |  | (11.8 | ) |  | 119.2 |  |
| Total liabilities | 202.1 |  |  | 631.1 |  |  | 383.3 |  |  | (75.5 | ) |  | 1,141.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 485.7 |  |  | 1,004.9 |  |  | 470.8 |  |  | (1,475.7 | ) |  | 485.7 |  |
| Total liabilities and stockholders' equity | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |

[0001069202-14-000002:notes:62]
As of December 31, 2012

[0001069202-14-000002:notes:63]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 13.4 |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net | — |  |  | 225.8 |  |  | 344.7 |  |  | (197.1 | ) |  | 373.4 |  |
| Inventories, net | — |  |  | 257.3 |  |  | 121.5 |  |  | (4.0 | ) |  | 374.8 |  |
| Deferred income taxes, net | — |  |  | 22.9 |  |  | 6.3 |  |  | (1.7 | ) |  | 27.5 |  |
| Other assets | 2.0 |  |  | 19.7 |  |  | 78.1 |  |  | (38.8 | ) |  | 61.0 |  |
| Assets of discontinued operations | — |  |  | 25.2 |  |  | 78.4 |  |  | (5.0 | ) |  | 98.6 |  |
| Total current assets | 3.0 |  |  | 564.3 |  |  | 666.4 |  |  | (246.6 | ) |  | 987.1 |  |
| Property, plant and equipment, net | — |  |  | 239.7 |  |  | 58.5 |  |  | — |  |  | 298.2 |  |
| Goodwill | — |  |  | 131.8 |  |  | 92.0 |  |  | — |  |  | 223.8 |  |
| Investment in subsidiaries | 2,179.9 |  |  | 337.0 |  |  | (0.2 | ) |  | (2,516.7 | ) |  | — |  |
| Deferred income taxes | — |  |  | 87.8 |  |  | 20.8 |  |  | (5.8 | ) |  | 102.8 |  |
| Other assets, net | 3.7 |  |  | 53.0 |  |  | 23.3 |  |  | — |  |  | 80.0 |  |
| Intercompany receivables (payables), net | (1,289.8 | ) |  | 1,013.6 |  |  | 89.8 |  |  | 186.4 |  |  | — |  |
| Total assets | $ | 896.8 |  |  | $ | 2,427.2 |  |  | $ | 950.6 |  |  | $ | (2,582.7 | ) |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 34.9 |  |  | $ | — |  |  | $ | 34.9 |  |
| Current maturities of long-term debt | — |  |  | 0.5 |  |  | 0.2 |  |  | — |  |  | 0.7 |  |
| Accounts payable | — |  |  | 198.6 |  |  | 86.1 |  |  | — |  |  | 284.7 |  |
| Accrued expenses | 2.5 |  |  | 157.0 |  |  | 60.8 |  |  | (0.3 | ) |  | 220.0 |  |
| Income taxes payable | (27.3 | ) |  | 35.0 |  |  | 38.5 |  |  | (41.7 | ) |  | 4.5 |  |
| Liabilities of discontinued operations | — |  |  | 42.3 |  |  | 12.9 |  |  | — |  |  | 55.2 |  |
| Total current liabilities | (24.8 | ) |  | 433.4 |  |  | 233.4 |  |  | (42.0 | ) |  | 600.0 |  |
| Long-term debt | 335.0 |  |  | 15.6 |  |  | 0.4 |  |  | — |  |  | 351.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 6.1 |  |  | — |  |  | — |  |  | 6.1 |  |
| Pensions | — |  |  | 114.7 |  |  | 19.7 |  |  | — |  |  | 134.4 |  |
| Other liabilities | 0.5 |  |  | 99.7 |  |  | 9.2 |  |  | (7.3 | ) |  | 102.1 |  |
| Total liabilities | 310.7 |  |  | 669.5 |  |  | 262.7 |  |  | (49.3 | ) |  | 1,193.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 586.1 |  |  | 1,757.7 |  |  | 687.9 |  |  | (2,533.4 | ) |  | 498.3 |  |
| Total liabilities and stockholders' equity | $ | 896.8 |  |  | $ | 2,427.2 |  |  | $ | 950.6 |  |  | $ | (2,582.7 | ) |  | $ | 1,691.9 |  |

[0001069202-14-000002:notes:64]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-14-000002:notes:65]
For the Year Ended December 31, 2013

[0001069202-14-000002:notes:66]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net sales | $ | — |  |  | $ | 2,557.9 |  |  | $ | 837.0 |  |  | $ | (195.8 | ) |  | $ | 3,199.1 |  |
| Cost of goods sold | — |  |  | 1,900.9 |  |  | 632.8 |  |  | (195.8 | ) |  | 2,337.9 |  |
| Gross profit | — |  |  | 657.0 |  |  | 204.2 |  |  | — |  |  | 861.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 437.1 |  |  | 133.0 |  |  | — |  |  | 570.1 |  |
| Losses and other expenses, net | 1.1 |  |  | 7.9 |  |  | 0.3 |  |  | — |  |  | 9.3 |  |
| Restructuring charges | — |  |  | 2.9 |  |  | 2.1 |  |  | — |  |  | 5.0 |  |
| Income from equity method investments | (181.7 | ) |  | (26.4 | ) |  | (9.7 | ) |  | 205.6 |  |  | (12.2 | ) |
| Operational income from continuing operations | 180.6 |  |  | 235.5 |  |  | 78.5 |  |  | (205.6 | ) |  | 289.0 |  |
| Interest expense, net | 14.0 |  |  | (2.1 | ) |  | 2.6 |  |  | — |  |  | 14.5 |  |
| Other expense, net | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Income from continuing operations before income taxes | 166.6 |  |  | 237.6 |  |  | 75.7 |  |  | (205.6 | ) |  | 274.3 |  |
| Provision for income taxes | (5.2 | ) |  | 73.7 |  |  | 25.9 |  |  | — |  |  | 94.4 |  |
| Income from continuing operations | 171.8 |  |  | 163.9 |  |  | 49.8 |  |  | (205.6 | ) |  | 179.9 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (8.1 | ) |  | — |  |  | (8.1 | ) |
| Net income | $ | 171.8 |  |  | $ | 163.9 |  |  | $ | 41.7 |  |  | $ | (205.6 | ) |  | $ | 171.8 |  |
| Other comprehensive income (loss) | $ | (38.8 | ) |  | $ | 36.3 |  |  | $ | (6.1 | ) |  | $ | (30.2 | ) |  | $ | (38.8 | ) |
| Comprehensive income | $ | 133.0 |  |  | $ | 200.2 |  |  | $ | 35.6 |  |  | $ | (235.8 | ) |  | $ | 133.0 |  |

[0001069202-14-000002:notes:67]
For the Year Ended December 31, 2012

[0001069202-14-000002:notes:68]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,327.7 |  |  | $ | 824.0 |  |  | $ | (202.3 | ) |  | $ | 2,949.4 |  |
| Cost of goods sold | 0.2 |  |  | 1,799.6 |  |  | 629.2 |  |  | (201.9 | ) |  | 2,227.1 |  |
| Gross profit | (0.2 | ) |  | 528.1 |  |  | 194.8 |  |  | (0.4 | ) |  | 722.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 374.3 |  |  | 132.7 |  |  | — |  |  | 507.0 |  |
| Losses and other expenses, net | (1.7 | ) |  | 1.1 |  |  | 3.2 |  |  | (0.1 | ) |  | 2.5 |  |
| Restructuring charges | — |  |  | 2.8 |  |  | 1.4 |  |  | — |  |  | 4.2 |  |
| Income from equity method investments | (116.3 | ) |  | (17.0 | ) |  | (7.8 | ) |  | 130.6 |  |  | (10.5 | ) |
| Operational income from continuing operations | 117.8 |  |  | 166.9 |  |  | 65.3 |  |  | (130.9 | ) |  | 219.1 |  |
| Interest expense, net | 16.6 |  |  | (2.4 | ) |  | 2.9 |  |  | — |  |  | 17.1 |  |
| Other expense, net | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Income from continuing operations before income taxes | 101.2 |  |  | 169.3 |  |  | 62.1 |  |  | (130.9 | ) |  | 201.7 |  |
| Provision for income taxes | (4.9 | ) |  | 50.5 |  |  | 21.2 |  |  | (0.1 | ) |  | 66.7 |  |
| Income from continuing operations | 106.1 |  |  | 118.8 |  |  | 40.9 |  |  | (130.8 | ) |  | 135.0 |  |
| Loss from discontinued operations | — |  |  | (18.5 | ) |  | (26.5 | ) |  | — |  |  | (45.0 | ) |
| Net income | $ | 106.1 |  |  | $ | 100.3 |  |  | $ | 14.4 |  |  | $ | (130.8 | ) |  | $ | 90.0 |  |
| Other comprehensive income (loss) | $ | 6.7 |  |  | $ | (2.8 | ) |  | $ | 5.2 |  |  | $ | 5.7 |  |  | $ | 14.8 |  |
| Comprehensive Income | $ | 112.8 |  |  | $ | 97.5 |  |  | $ | 19.6 |  |  | $ | (125.1 | ) |  | $ | 104.8 |  |

[0001069202-14-000002:notes:69]
For the Year Ended December 31, 2011

[0001069202-14-000002:notes:70]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,190.1 |  |  | $ | 850.1 |  |  | $ | (199.3 | ) |  | $ | 2,840.9 |  |
| Cost of goods sold | 0.2 |  |  | 1,721.0 |  |  | 650.6 |  |  | (200.8 | ) |  | 2,171.0 |  |
| Gross profit | (0.2 | ) |  | 469.1 |  |  | 199.5 |  |  | 1.5 |  |  | 669.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 327.0 |  |  | 149.9 |  |  | — |  |  | 476.9 |  |
| Losses and other expenses, net | 12.1 |  |  | 1.4 |  |  | (7.8 | ) |  | — |  |  | 5.7 |  |
| Restructuring charges | — |  |  | 10.8 |  |  | 1.7 |  |  | — |  |  | 12.5 |  |
| Income from equity method investments | (135.3 | ) |  | (31.2 | ) |  | (7.1 | ) |  | 164.0 |  |  | (9.6 | ) |
| Operational income from continuing operations | 123.0 |  |  | 161.1 |  |  | 62.8 |  |  | (162.5 | ) |  | 184.4 |  |
| Interest expense, net | 16.8 |  |  | (4.0 | ) |  | 4.0 |  |  | — |  |  | 16.8 |  |
| Other expense, net | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Income from continuing operations before income taxes | 106.2 |  |  | 165.1 |  |  | 58.5 |  |  | (162.5 | ) |  | 167.3 |  |
| Provision for income taxes | (9.8 | ) |  | 46.0 |  |  | 19.1 |  |  | 0.5 |  |  | 55.8 |  |
| Income from continuing operations | 116.0 |  |  | 119.1 |  |  | 39.4 |  |  | (163.0 | ) |  | 111.5 |  |
| Loss from discontinued operations | — |  |  | (29.8 | ) |  | 6.6 |  |  | — |  |  | (23.2 | ) |
| Net income | $ | 116.0 |  |  | $ | 89.3 |  |  | $ | 46.0 |  |  | $ | (163.0 | ) |  | $ | 88.3 |  |
| Other comprehensive loss | $ | (16.9 | ) |  | $ | (22.4 | ) |  | $ | (27.3 | ) |  | $ | (0.7 | ) |  | $ | (67.3 | ) |
| Comprehensive Income | $ | 99.1 |  |  | $ | 66.9 |  |  | $ | 18.7 |  |  | $ | (163.7 | ) |  | $ | 21.0 |  |

[0001069202-14-000002:notes:71]
Condensed Consolidating Statements of Cash Flows

[0001069202-14-000002:notes:72]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (30.4 | ) |  | $ | 328.4 |  |  | $ | (87.7 | ) |  | $ | — |  |  | $ | 210.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 2.4 |  |  | — |  |  | — |  |  | 2.4 |  |
| Purchases of property, plant and equipment | — |  |  | (55.8 | ) |  | (22.5 | ) |  | — |  |  | (78.3 | ) |
| Net proceeds from sale of business | 5.3 |  |  | — |  |  | 3.3 |  |  | — |  |  | 8.6 |  |
| Net cash provided by (used in) in investing activities | 5.3 |  |  | (53.4 | ) |  | (19.2 | ) |  | — |  |  | (67.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 330.0 |  |  | — |  |  | 330.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (200.0 | ) |  | — |  |  | (200.0 | ) |
| Long-term debt payments | — |  |  | (0.7 | ) |  | (0.3 | ) |  | — |  |  | (1.0 | ) |
| Borrowings from revolving credit facility | 1,425.5 |  |  | — |  |  | — |  |  | — |  |  | 1,425.5 |  |
| Payments on revolving credit facility | (1,543.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,543.5 | ) |
| Proceeds from employee stock purchases | 1.8 |  |  | — |  |  | — |  |  | — |  |  | 1.8 |  |
| Additional investment in subsidiary | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Repurchases of common stock | (125.0 | ) |  | — |  |  | — |  |  | — |  |  | (125.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (12.0 | ) |  | — |  |  | — |  |  | — |  |  | (12.0 | ) |
| Excess tax benefits related to share-based payments | 6.5 |  |  | — |  |  | — |  |  | — |  |  | 6.5 |  |
| Intercompany debt | (26.8 | ) |  | 12.3 |  |  | 14.5 |  |  | — |  |  | — |  |
| Intercompany financing | 332.7 |  |  | (289.5 | ) |  | (43.2 | ) |  | — |  |  | — |  |
| Cash dividends paid | (34.0 | ) |  | — |  |  | — |  |  | — |  |  | (34.0 | ) |
| Net cash provided by (used in) in financing activities | 25.2 |  |  | (277.9 | ) |  | 102.5 |  |  | — |  |  | (150.2 | ) |
| Increase (decrease) in cash and cash equivalents | 0.1 |  |  | (2.9 | ) |  | (4.4 | ) |  | — |  |  | (7.2 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (6.6 | ) |  | — |  |  | (6.6 | ) |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of year | $ | 1.1 |  |  | $ | 10.5 |  |  | $ | 26.4 |  |  | $ | — |  |  | $ | 38.0 |  |

[0001069202-14-000002:notes:73]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 20.7 |  |  | $ | 207.3 |  |  | $ | (6.6 | ) |  | $ | — |  |  | $ | 221.4 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (37.7 | ) |  | (12.5 | ) |  | — |  |  | (50.2 | ) |
| Net proceeds from sale of business | — |  |  | 10.1 |  |  | — |  |  | — |  |  | 10.1 |  |
| Net cash used in discontinued operations | — |  |  | (0.5 | ) |  | 0.1 |  |  | — |  |  | (0.4 | ) |
| Net cash used in investing activities | — |  |  | (28.0 | ) |  | (12.4 | ) |  | — |  |  | (40.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 645.0 |  |  | — |  |  | 645.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (615.0 | ) |  | — |  |  | (615.0 | ) |
| Long-term debt payments | — |  |  | (0.7 | ) |  | (0.4 | ) |  | — |  |  | (1.1 | ) |
| Borrowings from revolving credit facility | 967.0 |  |  | — |  |  | — |  |  | — |  |  | 967.0 |  |
| Payments on revolving credit facility | (1,075.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,075.0 | ) |
| Proceeds from stock option exercises | 0.8 |  |  | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Repurchases of common stock | (50.1 | ) |  | — |  |  | — |  |  | — |  |  | (50.1 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (7.8 | ) |  | — |  |  | — |  |  | — |  |  | (7.8 | ) |
| Excess tax benefits related to share-based payments | 3.5 |  |  | — |  |  | — |  |  | — |  |  | 3.5 |  |
| Intercompany debt | 2.4 |  |  | (4.0 | ) |  | 1.6 |  |  | — |  |  | — |  |
| Intercompany financing activity | 186.1 |  |  | (170.9 | ) |  | (15.2 | ) |  | — |  |  | — |  |
| Cash dividends paid | (47.6 | ) |  | — |  |  | — |  |  | — |  |  | (47.6 | ) |
| Net cash provided by (used in) financing activities | (20.7 | ) |  | (175.6 | ) |  | 16.2 |  |  | — |  |  | (180.1 | ) |
| Increase (decrease) in cash and cash equivalents | — |  |  | 3.7 |  |  | (2.8 | ) |  | — |  |  | 0.9 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 9.7 |  |  | 34.3 |  |  | — |  |  | 45.0 |  |
| Cash and cash equivalents, end of year | $ | 1.0 |  |  | $ | 13.4 |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 51.8 |  |

[0001069202-14-000002:notes:74]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (2.6 | ) |  | $ | 18.0 |  |  | $ | 60.8 |  |  | $ | — |  |  | $ | 76.2 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (34.2 | ) |  | (7.2 | ) |  | — |  |  | (41.4 | ) |
| Net proceeds from sale of businesses | — |  |  | — |  |  | 0.6 |  |  | — |  |  | 0.6 |  |
| Acquisition of businesses | — |  |  | (147.7 | ) |  | — |  |  | — |  |  | (147.7 | ) |
| Change in restricted cash | — |  |  | — |  |  | 12.2 |  |  | — |  |  | 12.2 |  |
| Net cash used in discontinued operations | — |  |  | (1.5 | ) |  | (0.2 | ) |  | — |  |  | (1.7 | ) |
| Net cash provided by (used in) investing activities | — |  |  | (183.3 | ) |  | 5.5 |  |  | — |  |  | (177.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 345.0 |  |  | — |  |  | 345.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (345.0 | ) |  | — |  |  | (345.0 | ) |
| Long-term debt payments | — |  |  | (0.8 | ) |  | (0.1 | ) |  | — |  |  | (0.9 | ) |
| Borrowings from revolving credit facility | 1,539.5 |  |  | — |  |  | — |  |  | — |  |  | 1,539.5 |  |
| Payments on revolving credit facility | (1,396.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,396.5 | ) |
| Proceeds from stock option exercises | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |
| Payments of deferred financing costs | (2.2 | ) |  | — |  |  | — |  |  | — |  |  | (2.2 | ) |
| Repurchases of common stock | (119.7 | ) |  | — |  |  | — |  |  | — |  |  | (119.7 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (3.3 | ) |  | — |  |  | — |  |  | — |  |  | (3.3 | ) |
| Excess tax benefits related to share-based payments | 1.4 |  |  | — |  |  | — |  |  | — |  |  | 1.4 |  |
| Intercompany debt | 115.1 |  |  | (8.1 | ) |  | (107.0 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (177.8 | ) |  | 169.2 |  |  | 8.6 |  |  | — |  |  | — |  |
| Cash dividends paid | (36.5 | ) |  | — |  |  | — |  |  | — |  |  | (36.5 | ) |
| Net cash provided by (used in) financing activities | (77.5 | ) |  | 160.3 |  |  | (94.7 | ) |  | — |  |  | (11.9 | ) |
| Decrease in cash and cash equivalents | (80.1 | ) |  | (5.0 | ) |  | (28.4 | ) |  | — |  |  | (113.5 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (1.5 | ) |  | — |  |  | (1.5 | ) |
| Cash and cash equivalents, beginning of year | 81.1 |  |  | 14.7 |  |  | 64.2 |  |  | — |  |  | 160.0 |  |
| Cash and cash equivalents, end of year | $ | 1.0 |  |  | $ | 9.7 |  |  | $ | 34.3 |  |  | $ | — |  |  | $ | 45.0 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001069202-14-000002:notes:75]
Principles of Consolidation

[0001069202-14-000002:notes:76]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.


## us-gaap:CostOfSalesPolicyTextBlock

[0001069202-14-000002:notes:77]
Cost of Goods Sold

[0001069202-14-000002:notes:78]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.


## us-gaap:DebtDisclosureTextBlock

[0001069202-14-000002:notes:79]
Lines of Credit and Financing Arrangements:

[0001069202-14-000002:notes:80]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000002:notes:81]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 5.9 |  |  | 4.9 |  |
| Total short-term debt | $ | 165.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.2 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 17.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 233.2 |  |  | $ | 351.0 |  |
| Total debt | $ | 400.4 |  |  | $ | 386.6 |  |

[0001069202-14-000002:notes:82]
As of December 31, 2013, the aggregate amounts of required principal payments on total debt were as follows (in millions):

[0001069202-14-000002:notes:83]
| 2014 | $ | 167.2 |  |
| 2015 | 1.8 |  |
| 2016 | 17.1 |  |
| 2017 | 200.0 |  |
| 2018 | 2.6 |  |
| Thereafter | 11.7 |  |

[0001069202-14-000002:notes:84]
Short-Term Debt

[0001069202-14-000002:notes:85]
Foreign Obligations

[0001069202-14-000002:notes:86]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $5.9 million and $4.9 million of foreign obligations as of December 31, 2013 and 2012, respectively, that were primarily borrowings under non-committed facilities.

[0001069202-14-000002:notes:87]
Asset Securitization Program

[0001069202-14-000002:notes:88]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-14-000002:notes:89]
In November 2013, we amended the ASP, extending its term to November 14, 2014 and increasing the maximum securitization amount from $160.0 million to a range of $160.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-14-000002:notes:90]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 160.0 |  |  | 30.0 |  |
| Remaining amount available | $ | — |  |  | $ | 130.0 |  |

[0001069202-14-000002:notes:91]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates as of December 31, 2013 and 2012 were 0.78% and 0.85%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-14-000002:notes:92]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million.  The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility.  The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of December 31, 2013, we were in compliance with all covenant requirements.

[0001069202-14-000002:notes:93]
Long-Term Debt

[0001069202-14-000002:notes:94]
Domestic Revolving Credit Facility

[0001069202-14-000002:notes:95]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $17.0 million as well as $59.5 million committed to standby letters of credit as of December 31, 2013.  Subject to covenant limitations, $599.5 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-14-000002:notes:96]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-14-000002:notes:97]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Weighted average borrowing rate | 1.17 | % |  | 1.46 | % |

[0001069202-14-000002:notes:98]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-14-000002:notes:99]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-14-000002:notes:100]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our Domestic Revolving Credit Facility could occur if:

[0001069202-14-000002:notes:101]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-14-000002:notes:102]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-14-000002:notes:103]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-14-000002:notes:104]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2013, we were in compliance with all covenant requirements.

[0001069202-14-000002:notes:105]
Senior Unsecured Notes

[0001069202-14-000002:notes:106]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.   As of December 31, 2013, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-14-000002:notes:107]
Derivatives:

[0001069202-14-000002:notes:108]
Objectives and Strategies for Using Derivative Instruments

[0001069202-14-000002:notes:109]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-14-000002:notes:110]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows.  Prior to 2013, we used an interest rate swap hedge to fix the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility tied to changes in the benchmark interest rate. The variable portion of the interest rate swap was tied to the 1-Month LIBOR (the benchmark interest rate). On a monthly basis, the interest rates for both the interest rate swap and the underlying debt were reset, the swap was settled with the counterparty, and the interest was paid.  The interest rate swap was classified as a cash flow hedge and it expired on October 12, 2012. Subsequently, we have not hedged against interest rate risk.

[0001069202-14-000002:notes:111]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-14-000002:notes:112]
Cash Flow Hedges

[0001069202-14-000002:notes:113]
We have commodity futures contracts designated as cash flows hedges that are scheduled to mature through June 2015.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive income (“AOCI”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.  We recorded the following amounts related to our cash flow hedges in AOCI (in millions):

[0001069202-14-000002:notes:114]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Unrealized losses (gains) on unsettled contracts | $ | 0.8 |  |  | $ | (1.8 | ) |
| Income tax expense (benefit) | (0.2 | ) |  | 0.7 |  |
| Losses (gains) included in AOCI, net of tax (1) | $ | 0.6 |  |  | $ | (1.1 | ) |

[0001069202-14-000002:notes:115]
(1) Assuming commodity prices remain constant, we expect to reclassify $0.7 million of derivative losses into earnings within the next 12 months.

[0001069202-14-000002:notes:116]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions of pounds):

[0001069202-14-000002:notes:117]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Copper | 22.9 |  |  | 22.8 |  |

[0001069202-14-000002:notes:118]
Derivatives not Designated as Cash Flow Hedges

[0001069202-14-000002:notes:119]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges, except that we elect not to designate them as cash flow hedges at the inception of the arrangement. We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions of pounds):

[0001069202-14-000002:notes:120]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Copper | 2.0 |  |  | 2.1 |  |
| Aluminum | 2.7 |  |  | 2.8 |  |

[0001069202-14-000002:notes:121]
We had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001069202-14-000002:notes:122]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Notional amounts (in local currency): |  |  |  |
| Brazilian Real | 1.2 |  |  | 10.8 |  |
| Mexican Peso | 130.0 |  |  | 220.2 |  |
| Euro | — |  |  | 1.3 |  |
| British Pound | 3.4 |  |  | 5.4 |  |
| Indian Rupee | 28.0 |  |  | 19.5 |  |
| Polish Zloty | 32.6 |  |  | 12.4 |  |

[0001069202-14-000002:notes:123]
Information About the Locations and Amounts of Derivative Instruments

[0001069202-14-000002:notes:124]
The following tables provide the locations and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of Operations (in millions):

[0001069202-14-000002:notes:125]
|  | Fair Values of Derivative Instruments as of December 31 (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Current Assets: |  |  |  |  |  |  |  |
| Other assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 0.1 |  |  | $ | 1.6 |  |  | $ | — |  |  | $ | 0.2 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.3 |  |  | 0.3 |  |  | — |  |  | — |  |
| Total Assets | $ | 0.4 |  |  | $ | 1.9 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 1.2 |  |  | $ | — |  |  | $ | 0.3 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 1.2 |  |  | $ | — |  |  | $ | 0.3 |  |  | $ | 0.1 |  |

[0001069202-14-000002:notes:126]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 20 for more information on fair value measurements.

[0001069202-14-000002:notes:127]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Amount of Loss (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |
| Commodity futures contracts (1) | $ | 4.2 |  |  | $ | 6.0 |  |  | $ | (12.1 | ) |
| Interest rate swap (2) | — |  |  | 1.9 |  |  | 2.5 |  |
|  | $ | 4.2 |  |  | $ | 7.9 |  |  | $ | (9.6 | ) |
| Amount of (Gain) Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |
| Commodity futures contracts (3) | $ | 0.2 |  |  | $ | (0.1 | ) |  | $ | 0.1 |  |

[0001069202-14-000002:notes:128]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Amount of Loss (Gain) Recognized in Income on Derivatives: |  |  |  |  |  |
| Commodity futures contracts (3) | $ | 1.2 |  |  | $ | (0.5 | ) |  | $ | 3.5 |  |
| Foreign currency forward contracts (3) | 0.1 |  |  | 0.4 |  |  | 0.3 |  |
|  | $ | 1.3 |  |  | $ | (0.1 | ) |  | $ | 3.8 |  |

[0001069202-14-000002:notes:129]
(1) The loss (gain) was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-14-000002:notes:130]
(2) The loss was recorded in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-14-000002:notes:131]
(3) The loss (gain) was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DerivativesPolicyTextBlock

[0001069202-14-000002:notes:132]
Derivatives

[0001069202-14-000002:notes:133]
We use futures contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 8 for more information on our derivatives.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-14-000002:notes:134]
Stock-Based Compensation:

[0001069202-14-000002:notes:135]
Stock-Based compensation expense related to continuing operations was included in Selling, General and Administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-14-000002:notes:136]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Compensation expense(1) | $ | 29.3 |  |  | $ | 15.2 |  |  | $ | 13.7 |  |

[0001069202-14-000002:notes:137]
(1) Stock-Based Compensation expense was recorded in our Corporate and other business segment.

[0001069202-14-000002:notes:138]
Incentive Plan

[0001069202-14-000002:notes:139]
Under the Lennox International Inc. 2010 Incentive Plan, as amended and restated (the “2010 Incentive Plan”), we are authorized to issue awards for 24.3 million shares of common stock.  The 2010 Incentive Plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-14-000002:notes:140]
As of December 31, 2013, awards for 20.5 million shares of common stock had been granted, net of cancellations and repurchases, and there were 3.8 million shares available for future issuance.

[0001069202-14-000002:notes:141]
Performance Share Units

[0001069202-14-000002:notes:142]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII's performance over the three-year performance period.

[0001069202-14-000002:notes:143]
Performance share units are classified as equity awards.  Compensation expense is recognized ratably over the service period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-14-000002:notes:144]
The following table provides information on our performance share units:

[0001069202-14-000002:notes:145]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Compensation expense for performance share units (in millions) | $ | 17.1 |  |  | $ | 5.7 |  |  | $ | 1.7 |  |
| Weighted-average fair value of grants, per share | $ | 78.00 |  |  | $ | 48.64 |  |  | $ | 31.78 |  |
| Payout ratio for shares paid | 86.9 | % |  | 52.5 | % |  | — | % |

[0001069202-14-000002:notes:146]
A summary of the status of our undistributed performance share units as of December 31, 2013, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-14-000002:notes:147]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2012 | 0.7 |  |  | $ | 39.06 |  |
| Granted | 0.1 |  |  | 78.00 |  |
| Adjustments to shares paid based on payout ratio | 0.1 |  |  | 44.85 |  |
| Distributed | (0.2 | ) |  | 35.26 |  |
| Forfeited | — |  |  | — |  |
| Undistributed performance share units as of December 31, 2013 (1) | 0.7 |  |  | $ | 47.83 |  |

[0001069202-14-000002:notes:148]
(1) Undistributed performance share units include approximately 0.5 million units with a weighted-average grant date fair value of $47.81 per share that had not yet vested and 0.2 million units that have vested but were not yet distributed.

[0001069202-14-000002:notes:149]
As of December 31, 2013, we had $19.8 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.1 years. Our estimated forfeiture rate for these performance share units was 16.4% as of December 31, 2013.

[0001069202-14-000002:notes:150]
The total fair value of performance share units distributed and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-14-000002:notes:151]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Fair value of performance share units distributed | $ | 9.9 |  |  | $ | 6.0 |  |  | $ | — |  |
| Realized tax benefits from tax deductions | $ | 3.8 |  |  | $ | 2.3 |  |  | $ | — |  |

[0001069202-14-000002:notes:152]
Restricted Stock Units

[0001069202-14-000002:notes:153]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-14-000002:notes:154]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-14-000002:notes:155]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Compensation expense for restricted stock units | $ | 6.8 |  |  | $ | 5.0 |  |  | $ | 6.6 |  |
| Weighted-average fair value of grants, per share | $ | 77.26 |  |  | $ | 48.45 |  |  | $ | 32.34 |  |

[0001069202-14-000002:notes:156]
A summary of our non-vested restricted stock units as of December 31, 2013 and changes during the year then ended is presented below (in millions, except per share data):

[0001069202-14-000002:notes:157]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2012 | 0.5 |  |  | $ | 40.50 |  |
| Granted | 0.1 |  |  | 77.26 |  |
| Distributed | (0.1 | ) |  | 44.78 |  |
| Forfeited | — |  |  | — |  |
| Non-vested restricted stock units as of December 31, 2013 | 0.5 |  |  | $ | 48.83 |  |

[0001069202-14-000002:notes:158]
As of December 31, 2013, we had $13.6 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.3 years.  Our estimated forfeiture rate for restricted stock units was 17.5% as of December 31, 2013.

[0001069202-14-000002:notes:159]
The total fair value of restricted stock units vested and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-14-000002:notes:160]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Fair value of restricted stock units vested | $ | 11.1 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |
| Realized tax benefits from tax deductions | 4.3 |  |  | 3.3 |  |  | 3.4 |  |

[0001069202-14-000002:notes:161]
Stock Appreciation Rights

[0001069202-14-000002:notes:162]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive a value, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-14-000002:notes:163]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-14-000002:notes:164]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Compensation expense for stock appreciation rights | $ | 5.4 |  |  | $ | 4.5 |  |  | $ | 5.4 |  |
| Weighted-average fair value of grants, per share | 18.76 |  |  | 14.34 |  |  | 9.39 |  |

[0001069202-14-000002:notes:165]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-14-000002:notes:166]
The fair value of the stock appreciation rights granted in 2013, 2012 and 2011 were estimated on the date of grant using the following assumptions:

[0001069202-14-000002:notes:167]
|  | 2013 |  | 2012 |  | 2011 |
| Expected dividend yield | 1.36 | % |  | 1.75 | % |  | 2.39 | % |
| Risk-free interest rate | 1.12 | % |  | 0.48 | % |  | 0.62 | % |
| Expected volatility | 31.50 | % |  | 40.42 | % |  | 41.94 | % |
| Expected life (in years) | 4.02 |  |  | 4.14 |  |  | 4.07 |  |

[0001069202-14-000002:notes:168]
A summary of our stock appreciation rights as of December 31, 2013, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-14-000002:notes:169]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2012 | 2.2 |  |  | $ | 38.93 |  |
| Granted | 0.3 |  |  | 81.11 |  |
| Exercised | (0.6 | ) |  | 36.80 |  |
| Forfeited | (0.1 | ) |  | 40.16 |  |
| Outstanding stock appreciation rights as of December 31, 2013 | 1.8 |  |  | $ | 45.58 |  |
| Exercisable stock appreciation rights as of December 31, 2013 | 1.1 |  |  | $ | 37.81 |  |

[0001069202-14-000002:notes:170]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2013 (in millions, except per share data and years):

[0001069202-14-000002:notes:171]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $28.24 to $36.935 |  | 0.9 |  |  | 3.4 |  | $ | 49.5 |  |  | 0.8 |  |  | 3.1 |  | $ | 40.5 |  |
| $46.78 to $51.395 |  | 0.6 |  |  | 5.3 |  | $ | 21.6 |  |  | 0.3 |  |  | 4.7 |  | $ | 12.6 |  |
| $81.105 to $81.14 |  | 0.3 |  |  | 7.0 |  | $ | 1.0 |  |  | — |  |  | 0 |  | $ | — |  |

[0001069202-14-000002:notes:172]
As of December 31, 2013, we had $9.2 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for stock appreciation rights was 16.0% as of December 31, 2013.

[0001069202-14-000002:notes:173]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-14-000002:notes:174]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Intrinsic value of stock appreciation rights exercised | $ | 16.7 |  |  | $ | 14.4 |  |  | $ | 4.2 |  |
| Realized tax benefits from tax deductions | $ | 6.4 |  |  | $ | 5.5 |  |  | $ | 1.6 |  |

[0001069202-14-000002:notes:175]
Employee Stock Purchase Plan

[0001069202-14-000002:notes:176]
Under the 2012 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 20,500 shares under the ESPP during the year ended December 31, 2013.  Approximately 2.5 million shares remain available for purchase under the ESPP as of December 31, 2013.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-14-000002:notes:177]
Discontinued Operations:

[0001069202-14-000002:notes:178]
On March 22, 2013, we sold our Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer") in an all-cash transaction for net proceeds of $10.4 million, excluding transaction costs.  We also entered into a two-year equipment and parts supply agreement with the Buyer.  In April 2012, we sold our Hearth business to Comvest Investment Partners IV in an all-cash transaction for net proceeds of $10.1 million, excluding the transaction costs and cash transferred with the business.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in discontinued operations.

[0001069202-14-000002:notes:179]
Service Experts

[0001069202-14-000002:notes:180]
A summary of net sales and pre-tax gains and losses for the Service Experts business is detailed below (in millions):

[0001069202-14-000002:notes:181]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Net sales (1) | $ | 73.5 |  |  | $ | 385.1 |  |  | $ | 448.4 |  |
| Pre-tax operating loss (1)(2) | (15.1 | ) |  | (50.8 | ) |  | (10.5 | ) |
| Gain on sale of business | 1.4 |  |  | — |  |  | — |  |

[0001069202-14-000002:notes:182]
(1) Excludes eliminations of intercompany sales and any associated profit.

[0001069202-14-000002:notes:183]
(2) Pre-tax operating loss for the year ended December 31, 2012 included a $20.5 million goodwill impairment loss.

[0001069202-14-000002:notes:184]
The assets and liabilities of the Service Experts business included the following in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000002:notes:185]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Assets of discontinued operations: |  |  |  |
| Accounts receivable, net | $ | — |  |  | $ | 11.2 |  |
| Inventories, net | — |  |  | 4.8 |  |
| Property, plant and equipment, net | — |  |  | 3.6 |  |
| Goodwill and intangible assets, net (1) | — |  |  | 66.2 |  |
| Deferred income taxes | — |  |  | 5.5 |  |
| Other assets | — |  |  | 7.3 |  |
| Total assets of discontinued operations | $ | — |  |  | $ | 98.6 |  |
| Liabilities of discontinued operations: |  |  |  |
| Accounts payable | $ | — |  |  | $ | 16.7 |  |
| Accrued expenses | — |  |  | 38.5 |  |
| Total liabilities of discontinued operations | $ | — |  |  | $ | 55.2 |  |

[0001069202-14-000002:notes:186]
(1)  Included in the December 31, 2012 amount is goodwill of $66.0 million.  No goodwill impairments were recorded in 2013 and all goodwill was eliminated on March 22, 2013 as a result of the sale of the business.

[0001069202-14-000002:notes:187]
Hearth

[0001069202-14-000002:notes:188]
A summary of net sales and pre-tax gains and losses for the Hearth business is detailed below (in millions):

[0001069202-14-000002:notes:189]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Net sales | $ | — |  |  | $ | 23.5 |  |  | $ | 81.5 |  |
| Pre-tax operating income (loss) (1) | 0.5 |  |  | (13.7 | ) |  | (26.3 | ) |
| Loss on sale of business | — |  |  | (0.9 | ) |  | — |  |

[0001069202-14-000002:notes:190]
| (1) | Pre-tax operating loss in 2012 included a $6.3 million pre-tax impairment charge for the write-down of net assets to their estimated fair value, a $6.3 million settlement charge related to actuarial losses recognized upon transition of a pension obligation to the acquirer of the Hearth business and a $3.5 million gain related to realized foreign currency translation adjustments. |

[0001069202-14-000002:notes:191]
There were no assets or liabilities related to the Hearth business included in the accompanying Consolidated Balance Sheets as of December 31, 2013 or 2012.


## us-gaap:EarningsPerShareTextBlock

[0001069202-14-000002:notes:192]
Earnings Per Share:

[0001069202-14-000002:notes:193]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-14-000002:notes:194]
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-14-000002:notes:195]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Net income | $ | 171.8 |  |  | $ | 90.0 |  |  | $ | 88.3 |  |
| Add: Loss from discontinued operations | 8.1 |  |  | 45.0 |  |  | 23.2 |  |
| Income from continuing operations | $ | 179.9 |  |  | $ | 135.0 |  |  | $ | 111.5 |  |
| Weighted-average shares outstanding – basic | 49.8 |  |  | 50.7 |  |  | 52.5 |  |
| Effect of diluted securities attributable to stock-based payments | 0.8 |  |  | 0.7 |  |  | 0.9 |  |
| Weighted-average shares outstanding – diluted | 50.6 |  |  | 51.4 |  |  | 53.4 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 3.61 |  |  | $ | 2.66 |  |  | $ | 2.12 |  |
| Loss from discontinued operations | (0.16 | ) |  | (0.89 | ) |  | (0.44 | ) |
| Net income | $ | 3.45 |  |  | $ | 1.77 |  |  | $ | 1.68 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 3.55 |  |  | $ | 2.63 |  |  | $ | 2.09 |  |
| Loss from discontinued operations | (0.16 | ) |  | (0.88 | ) |  | (0.44 | ) |
| Net income | $ | 3.39 |  |  | $ | 1.75 |  |  | $ | 1.65 |  |

[0001069202-14-000002:notes:196]
The following stock appreciation rights were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive (shares in millions):

[0001069202-14-000002:notes:197]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Weighted-average number of shares | 0.1 |  |  | 0.1 |  |  | 1.5 |  |
| Price ranges per share | $81.11 - $81.14 |  |  | $51.11 - $51.40 |  |  | $34.06 - $46.78 |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-14-000002:notes:198]
Joint Ventures and Other Equity Investments:

[0001069202-14-000002:notes:199]
We participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001069202-14-000002:notes:200]
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001069202-14-000002:notes:201]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Equity method investments | $ | 28.0 |  |  | $ | 26.4 |  |

[0001069202-14-000002:notes:202]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-14-000002:notes:203]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Purchases of compressors from joint venture | $ | 96.7 |  |  | $ | 90.4 |  |  | $ | 80.2 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001069202-14-000002:notes:204]
The fair values of our pension plan assets, by asset category, are as follows (in millions):

[0001069202-14-000002:notes:205]
|  | Fair Value Measurements as of December 31, 2013 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 8.2 |  |  | — |  |  | — |  |  | 8.2 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 100.1 |  |  | — |  |  | 100.1 |  |
| International equity (2) | — |  |  | 70.8 |  |  | — |  |  | 70.8 |  |
| Fixed income (3) | — |  |  | 89.4 |  |  | — |  |  | 89.4 |  |
| Balanced pension trust: (6) |  |  |  |  |  |  |  |
| U.S. equity | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |
| International equity | — |  |  | 8.3 |  |  | — |  |  | 8.3 |  |
| Fixed income | — |  |  | 7.2 |  |  | — |  |  | 7.2 |  |
| Pension fund: |  |  |  |  |  |  |  |
| U.S. equity (7) | — |  |  | 1.5 |  |  | — |  |  | 1.5 |  |
| International equity (7) | — |  |  | 7.9 |  |  | — |  |  | 7.9 |  |
| Fixed income (8) | — |  |  | 6.9 |  |  | — |  |  | 6.9 |  |
| Total | 8.2 |  |  | 294.6 |  |  | — |  |  | 302.8 |  |

[0001069202-14-000002:notes:206]
|  | Fair Value Measurements as of December 31, 2012 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 36.7 |  |  | — |  |  | 36.7 |  |
| International equity (2) | — |  |  | 60.3 |  |  | — |  |  | 60.3 |  |
| Fixed income (3) | — |  |  | 85.3 |  |  | — |  |  | 85.3 |  |
| Mutual funds: |  |  |  |  |  |  |  |
| U.S. equity (4) | 47.3 |  |  | — |  |  | — |  |  | 47.3 |  |
| International equity (4) | 3.9 |  |  | — |  |  | — |  |  | 3.9 |  |
| Fixed income (5) | 7.8 |  |  | — |  |  | — |  |  | 7.8 |  |
| Balanced pension trust: (6) |  |  |  |  |  |  |  |
| U.S. equity | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| International equity | — |  |  | 7.9 |  |  | — |  |  | 7.9 |  |
| Fixed income | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| Pension fund: |  |  |  |  |  |  |  |
| U.S. equity (7) | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| International equity (7) | — |  |  | 6.7 |  |  | — |  |  | 6.7 |  |
| Fixed income (8) | — |  |  | 6.1 |  |  | — |  |  | 6.1 |  |
| Total | 63.5 |  |  | 213.3 |  |  | — |  |  | 276.8 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-14-000002:notes:207]
The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-14-000002:notes:208]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 214.0 |  |  | $ | 212.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-14-000002:notes:209]
Fair Value Measurements:

[0001069202-14-000002:notes:210]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001069202-14-000002:notes:211]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-14-000002:notes:212]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-14-000002:notes:213]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-14-000002:notes:214]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party's creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2013 and 2012, the measurement dates.  The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2013 were the same as those used as of December 31, 2012.

[0001069202-14-000002:notes:215]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-14-000002:notes:216]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-14-000002:notes:217]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 8 for more information related to our derivative instruments.

[0001069202-14-000002:notes:218]
Marketable Equity Securities

[0001069202-14-000002:notes:219]
The following table presents the fair values of an investment in marketable equity securities, related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000002:notes:220]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Quoted Prices in Active Markets for Identical Assets (Level 1): |  |  |  |
| Investment in marketable equity securities | $ | 4.4 |  |  | $ | 10.6 |  |

[0001069202-14-000002:notes:221]
Other Fair Value Disclosures

[0001069202-14-000002:notes:222]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Revolving Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-14-000002:notes:223]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):


## us-gaap:FairValueInvestmentsEntitiesThatCalculateNetAssetValuePerShareTableTextBlock

[0001069202-14-000002:notes:224]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-14-000002:notes:225]
|  | As of December 31, 2013 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 100.1 |  |  | Daily |  | 5 days |
| International equity (2) | 70.8 |  |  | Daily |  | 5 days |
| Fixed income (3) | 89.4 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (6) |  |  |  |  |  |
| U.S. equity | 2.5 |  |  | Daily |  | 3-5 days |
| International equity | 8.3 |  |  | Daily |  | 3-5 days |
| Fixed income | 7.2 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| U.S. equity (7) | 1.5 |  |  | Daily |  | 7 days |
| International equity (7) | 7.9 |  |  | Daily |  | 7 days |
| Fixed income (8) | 6.9 |  |  | Daily |  | 7 days |
| Total | $ | 294.6 |  |  |  |  |  |

[0001069202-14-000002:notes:226]
|  | As of December 31, 2012 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 36.7 |  |  | Daily |  | 5 days |
| International equity (2) | 60.3 |  |  | Daily |  | 5 days |
| Fixed income (3) | 85.3 |  |  | Daily |  | 5-15 days |
| Mutual funds: |  |  |  |  |  |
| U.S. equity (4) | 47.3 |  |  | n/a |  | n/a |
| International equity (4) | 3.9 |  |  | n/a |  | n/a |
| Fixed income (5) | 7.8 |  |  | n/a |  | n/a |
| Balanced pension trust: (6) |  |  |  |  |  |
| U.S. equity | 2.4 |  |  | Daily |  | 3-5 days |
| International equity | 7.9 |  |  | Daily |  | 3-5 days |
| Fixed income | 6.6 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| U.S. equity (7) | 1.3 |  |  | Daily |  | 7 days |
| International equity (7) | 6.7 |  |  | Daily |  | 7 days |
| Fixed income (8) | 6.1 |  |  | Daily |  | 7 days |
| Total | $ | 272.3 |  |  |  |  |  |

[0001069202-14-000002:notes:227]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in non-U.S. equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, non-U.S. fixed income securities and emerging markets fixed income securities. |
| (4) | These funds seek capital appreciation and generally invest in common stocks of U.S. and non-U.S. issuers. They may invest in growth stocks or value stocks. |
| (5) | This fund seeks to provide inflation protection. It currently invests at least 80% of its assets in inflation-indexed bonds issued by the U.S. government. It may invest in bonds of any maturity, though the fund typically maintains a dollar-weighted average maturity of 7 to 20 years. |
| (6) | The investment objectives of the fund are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The fund also holds a portion of its assets in U.S. and non-U.S. equities. |
| (7) | This category includes investments in U.S. and non-U.S. equity securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (8) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer and investment grade corporate bonds denominated in sterling. |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001069202-14-000002:notes:228]
Amortization expense related to these intangible and other assets was as follows (in millions):

[0001069202-14-000002:notes:229]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Amortization expense | $ | 3.9 |  |  | $ | 3.8 |  |  | $ | 4.7 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001069202-14-000002:notes:230]
Translation of Foreign Currencies

[0001069202-14-000002:notes:231]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCI in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-14-000002:notes:232]
Goodwill and Intangible Assets:

[0001069202-14-000002:notes:233]
Goodwill

[0001069202-14-000002:notes:234]
The changes in the carrying amount of goodwill in 2013 and 2012, in total and by segment, are summarized in the table below (in millions):

[0001069202-14-000002:notes:235]
| Segment: | Balance at December 31, 2011 (2) |  | Acquisitions / (Dispositions) |  | Other(1) |  | Balance at December 31, 2012 |  | Acquisitions / (Dispositions) |  | Other(1) |  | Balance at December 31, 2013 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 63.5 |  |  | — |  |  | 0.3 |  |  | 63.8 |  |  | — |  |  | 0.8 |  |  | 64.6 |  |
| Refrigeration | 133.6 |  |  | — |  |  | 0.3 |  |  | 133.9 |  |  | — |  |  | (7.8 | ) |  | 126.1 |  |
|  | $ | 223.2 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 223.8 |  |  | $ | — |  |  | $ | (7.0 | ) |  | $ | 216.8 |  |

[0001069202-14-000002:notes:236]
(1) Other consists of changes in foreign currency translation rates.

[0001069202-14-000002:notes:237]
(2) The goodwill balances in the table above are presented net of accumulated impairment charges of $16.4 million, all of which relate to impairments in periods prior to 2011.

[0001069202-14-000002:notes:238]
We performed our annual impairment test of goodwill for 2013 and determined that it was not more likely than not the fair values of our reporting units, individually or collectively, were less than their carrying values based on a qualitative review of impairment indicators.  Accordingly, a quantitative impairment analysis was not performed and no impairments were recognized as part of the annual test.  No other indicators of impairment were identified from the date of our annual impairment test through December 31, 2013.  Also, we did not record any goodwill impairments related to continuing operations in 2011 or 2012.  Refer to Note 17 for information on goodwill related to discontinued operations.

[0001069202-14-000002:notes:239]
Intangible Assets

[0001069202-14-000002:notes:240]
As of December 31, 2013 and 2012, there were $9.4 million of indefinite-lived intangible assets recorded in Other assets, net in the accompanying Consolidated Balance Sheets.  These intangible assets consisted primarily of trademarks and are not subject to amortization.

[0001069202-14-000002:notes:241]
Identifiable intangible and other assets subject to amortization were recorded in Other assets, net in the accompanying Consolidated Balance Sheets and were comprised of the following (in millions):

[0001069202-14-000002:notes:242]
|  | As of December 31, |
|  | 2013 |  | 2012 |
|  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Deferred financing costs | $ | 5.0 |  |  | $ | (2.3 | ) |  | $ | 2.7 |  |  | $ | 5.0 |  |  | $ | (1.5 | ) |  | $ | 3.5 |  |
| Customer relationships | 42.6 |  |  | (20.6 | ) |  | 22.0 |  |  | 42.6 |  |  | (18.2 | ) |  | 24.4 |  |
| Patents and others | 8.5 |  |  | (7.3 | ) |  | 1.2 |  |  | 8.1 |  |  | (6.6 | ) |  | 1.5 |  |
| Total | $ | 56.1 |  |  | $ | (30.2 | ) |  | $ | 25.9 |  |  | $ | 55.7 |  |  | $ | (26.3 | ) |  | $ | 29.4 |  |

[0001069202-14-000002:notes:243]
Estimated amortization expense for the next five years and thereafter is as follows (in millions):

[0001069202-14-000002:notes:244]
| Estimated Future Amortization Expense: |  |
| 2014 | $ | 3.7 |  |
| 2015 | 3.5 |  |
| 2016 | 3.4 |  |
| 2017 | 2.8 |  |
| 2018 | 2.7 |  |
| Thereafter | 9.8 |  |

[0001069202-14-000002:notes:245]
We did not have any impairments of intangible assets related to continuing operations in 2013 or 2012.  See Note 17 for information on impairments of intangible assets related to discontinued operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-14-000002:notes:246]
Income Taxes:

[0001069202-14-000002:notes:247]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-14-000002:notes:248]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Current: |  |  |  |  |  |
| Federal | $ | 71.9 |  |  | $ | 47.5 |  |  | $ | 41.4 |  |
| State | 8.5 |  |  | 7.3 |  |  | 5.3 |  |
| Foreign | 16.2 |  |  | 13.4 |  |  | 7.3 |  |
| Total current | 96.6 |  |  | 68.2 |  |  | 54.0 |  |
| Deferred: |  |  |  |  |  |
| Federal | (4.0 | ) |  | 0.7 |  |  | 0.4 |  |
| State | 2.5 |  |  | (0.2 | ) |  | (1.0 | ) |
| Foreign | (0.7 | ) |  | (2.0 | ) |  | 2.4 |  |
| Total deferred | (2.2 | ) |  | (1.5 | ) |  | 1.8 |  |
| Total provision for income taxes | $ | 94.4 |  |  | $ | 66.7 |  |  | $ | 55.8 |  |

[0001069202-14-000002:notes:249]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-14-000002:notes:250]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Domestic | $ | 231.1 |  |  | $ | 169.9 |  |  | $ | 134.9 |  |
| Foreign | 43.2 |  |  | 31.8 |  |  | 32.4 |  |
| Total | $ | 274.3 |  |  | $ | 201.7 |  |  | $ | 167.3 |  |

[0001069202-14-000002:notes:251]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-14-000002:notes:252]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Provision at the U.S. statutory rate of 35% | $ | 96.0 |  |  | $ | 70.6 |  |  | $ | 58.6 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 7.1 |  |  | 5.9 |  |  | 2.9 |  |
| Other permanent items | (6.4 | ) |  | (3.1 | ) |  | (3.5 | ) |
| Research tax credit | (0.5 | ) |  | — |  |  | (0.3 | ) |
| Change in unrecognized tax benefits | 0.7 |  |  | (5.1 | ) |  | (0.6 | ) |
| Change in valuation allowance | 0.7 |  |  | 2.3 |  |  | (0.7 | ) |
| Foreign taxes at rates other than 35% and miscellaneous other | (3.2 | ) |  | (3.9 | ) |  | (0.6 | ) |
| Total provision for income taxes | $ | 94.4 |  |  | $ | 66.7 |  |  | $ | 55.8 |  |

[0001069202-14-000002:notes:253]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and are reflected as current or non-current depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-14-000002:notes:254]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-14-000002:notes:255]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 29.3 |  |  | $ | 26.4 |  |
| Loss carryforwards (foreign, U.S. and state) | 28.2 |  |  | 20.1 |  |
| Post-retirement and pension benefits | 28.3 |  |  | 52.9 |  |
| Inventory reserves | 4.8 |  |  | 8.2 |  |
| Receivables allowance | 5.1 |  |  | 5.0 |  |
| Compensation liabilities | 22.6 |  |  | 17.2 |  |
| Deferred income | 0.9 |  |  | 0.8 |  |
| Insurance liabilities | 18.1 |  |  | 22.9 |  |
| Legal Reserves | 3.9 |  |  | 1.4 |  |
| State credits, net of federal effect | 8.7 |  |  | 1.1 |  |
| Other | 8.3 |  |  | 7.0 |  |
| Total deferred tax assets | 158.2 |  |  | 163.0 |  |
| Valuation allowance | (21.2 | ) |  | (10.9 | ) |
| Total deferred tax assets, net of valuation allowance | 137.0 |  |  | 152.1 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (12.4 | ) |  | (13.3 | ) |
| Intangibles | (8.7 | ) |  | (6.9 | ) |
| Other | (2.9 | ) |  | (1.6 | ) |
| Total deferred tax liabilities | (24.0 | ) |  | (21.8 | ) |
| Net deferred tax assets | $ | 113.0 |  |  | $ | 130.3 |  |

[0001069202-14-000002:notes:256]
As of December 31, 2013 and 2012, we had $5.0 million and $0.7 million in tax-effected state net operating loss carryforwards, respectively, and $21.8 million and $19.4 million in tax-effected foreign net operating loss carryforwards, respectively.  The state and foreign net operating loss carryforwards begin expiring in 2014.  The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards in various states in the U.S., European and Asian tax jurisdictions.  The remainder of the valuation allowance relates to state tax credits which begin to expire in 2014.

[0001069202-14-000002:notes:257]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of December 31, 2013.

[0001069202-14-000002:notes:258]
To realize the net deferred tax asset, we will need to generate future foreign taxable income of approximately $84.5 million during the periods in which those temporary differences become deductible.  We do not need to generate additional U.S. federal income as we have sufficient carryback capacity to fully realize the federal deferred tax asset.  U.S. taxable income for the years ended December 31, 2013 and 2012 was $194.1 million and $59.3 million, respectively.

[0001069202-14-000002:notes:259]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries' earnings.  It is not practicable to estimate the amount of tax that might be payable because our intent is to permanently reinvest these earnings or to repatriate earnings when it is tax effective to do so.

[0001069202-14-000002:notes:260]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001069202-14-000002:notes:261]
| Balance as of December 31, 2011 | $ | 5.9 |  |
| Increases related to prior year tax positions | 0.8 |  |
| Decreases related to prior year tax positions | (5.8 | ) |
| Increases related to current year tax positions | 0.1 |  |
| Balance as of December 31, 2012 | 1.0 |  |
| Increases related to prior year tax positions | 0.7 |  |
| Decreases related to prior year tax positions | (0.1 | ) |
| Increases related to current year tax positions | 0.1 |  |
| Balance as of December 31, 2013 | $ | 1.7 |  |

[0001069202-14-000002:notes:262]
Included in the balance of unrecognized tax benefits as of December 31, 2013 are potential benefits of $1.4 million that, if recognized, would affect the effective tax rate on income from continuing operations.  As of December 31, 2013, we recognized $0.2 million (net of federal tax benefits) in interest and penalties in income tax expense.

[0001069202-14-000002:notes:263]
We are currently under examination for our U.S. federal income taxes for 2014 and 2013 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years before 2008.

[0001069202-14-000002:notes:264]
Since January 1, 2013, numerous states, including New Mexico, North Carolina, North Dakota, Minnesota, Oregon, Texas and West Virginia enacted legislation effective for tax years beginning on or after January 1, 2013, including changes to rates and apportionment methods.  The impact of these changes is immaterial.

[0001069202-14-000002:notes:265]
On January 2, 2013, the American Taxpayer Relief Act of 2012 was enacted which retroactively reinstated and extended the Federal Research and Development Tax Credit (Federal R&D Tax Credit) from January 1, 2012 to December 31, 2013, in addition to other extenders.  As a result, the Company's income tax provision for 2013 includes a tax benefit of $0.2 million that reduced the annual effective income tax rate.


## us-gaap:IncomeTaxPolicyTextBlock

[0001069202-14-000002:notes:266]
Income Taxes

[0001069202-14-000002:notes:267]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 9 for more information related to income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-14-000002:notes:268]
Inventories:

[0001069202-14-000002:notes:269]
The components of inventories are as follows (in millions):

[0001069202-14-000002:notes:270]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Finished goods | $ | 251.4 |  |  | $ | 258.0 |  |
| Work in process | 11.8 |  |  | 12.0 |  |
| Raw materials and parts | 188.9 |  |  | 180.1 |  |
| Total | 452.1 |  |  | 450.1 |  |
| Excess of current cost over last-in, first-out cost | (73.3 | ) |  | (75.3 | ) |
| Total inventories, net | $ | 378.8 |  |  | $ | 374.8 |  |

[0001069202-14-000002:notes:271]
The Company recorded pre-tax income of $0.3 million and $0.1 million in 2013 and 2011, respectively, and pre-tax loss of $0.1 million in 2012 from LIFO inventory liquidations.


## us-gaap:InventoryPolicyTextBlock

[0001069202-14-000002:notes:272]
Inventories

[0001069202-14-000002:notes:273]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $187.3 million and $176.2 million as of December 31, 2013 and 2012, respectively, were valued at the lower of cost or market using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or market with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001069202-14-000002:notes:274]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-14-000002:notes:275]
Losses and Other Expenses, net:

[0001069202-14-000002:notes:276]
Losses and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-14-000002:notes:277]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Realized losses (gains) on settled futures contracts | $ | 1.0 |  |  | $ | 1.5 |  |  | $ | (0.1 | ) |
| Foreign currency exchange losses | 0.5 |  |  | 0.8 |  |  | 1.4 |  |
| Losses (gains) on disposal of fixed assets | (1.0 | ) |  | 0.4 |  |  | (0.8 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.4 |  |  | (2.2 | ) |  | 3.8 |  |
| Asbestos-related litigation | 6.3 |  |  | — |  |  | — |  |
| Acquisition expenses (1) | 0.2 |  |  | 0.1 |  |  | 1.0 |  |
| Special legal contingency charges (2) | 1.2 |  |  | 1.2 |  |  | — |  |
| Other items, net | 0.7 |  |  | 0.7 |  |  | 0.4 |  |
| Losses and other expenses, net | $ | 9.3 |  |  | $ | 2.5 |  |  | $ | 5.7 |  |

[0001069202-14-000002:notes:278]
(1)  Acquisition expenses in 2011 primarily relate to the Kysor/Warren acquisition.

[0001069202-14-000002:notes:279]
(2)  Special legal contingency charges in 2013 and 2012 relate to patent litigation claims involving products from an acquired business. See Note 10 for more information.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-14-000002:notes:280]
Employee Benefit Plans:

[0001069202-14-000002:notes:281]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.  We also have several active defined benefit plans that provide benefits based on years of service.

[0001069202-14-000002:notes:282]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.  In 2012, we amended the post-retirement benefit plan to shift pre-65 medical coverage for the employees of our largest manufacturing plant so that by 2015, retirees would pay 100% of the cost of post-retirement medical coverage.  This change resulted in a significant reduction in the projected benefit obligation for post-retirement medical benefits in 2012.

[0001069202-14-000002:notes:283]
Defined Contribution Plans

[0001069202-14-000002:notes:284]
We recorded the following expenses related to our contributions to the defined contribution plans (in millions):

[0001069202-14-000002:notes:285]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Contributions to defined contribution plans (1) | $ | 13.7 |  |  | $ | 13.2 |  |  | $ | 14.3 |  |

[0001069202-14-000002:notes:286]
(1)  Contributions of $0.4 million, $2.0 million and $2.7 million were included in Loss from discontinued operations for the years ended December 31, 2013, 2012 and 2011, respectively.

[0001069202-14-000002:notes:287]
Pension and Post-retirement Benefit Plans

[0001069202-14-000002:notes:288]
The following tables set forth amounts recognized in our financial statements and the plans' funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-14-000002:notes:289]
|  | Pension Benefits |  | Other Benefits |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Accumulated benefit obligation | $ | 367.3 |  |  | $ | 406.3 |  |  | N/A |  |  | N/A |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 413.9 |  |  | $ | 368.8 |  |  | $ | 7.6 |  |  | $ | 19.9 |  |
| Service cost | 5.2 |  |  | 5.8 |  |  | — |  |  | 0.2 |  |
| Interest cost | 16.2 |  |  | 17.5 |  |  | 0.2 |  |  | 0.4 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.7 |  |  | 0.8 |  |
| Amendments | — |  |  | — |  |  | — |  |  | (14.2 | ) |
| Other | 0.1 |  |  | 4.5 |  |  | — |  |  | — |  |
| Actuarial (gain) loss | (39.4 | ) |  | 47.0 |  |  | — |  |  | 2.8 |  |
| Effect of exchange rates | (0.7 | ) |  | 1.6 |  |  | — |  |  | — |  |
| Divestiture | — |  |  | (10.4 | ) |  | — |  |  | — |  |
| Settlements and curtailments | (1.6 | ) |  | (1.7 | ) |  | — |  |  | — |  |
| Benefits paid | (19.1 | ) |  | (19.2 | ) |  | (2.5 | ) |  | (2.3 | ) |
| Benefit obligation at end of year | $ | 374.6 |  |  | $ | 413.9 |  |  | $ | 6.0 |  |  | $ | 7.6 |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 276.8 |  |  | $ | 242.5 |  |  | $ | — |  |  | $ | — |  |
| Actual gain return on plan assets | 37.4 |  |  | 32.1 |  |  | — |  |  | — |  |
| Employer contribution | 9.9 |  |  | 29.4 |  |  | 1.8 |  |  | 1.5 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.7 |  |  | 0.8 |  |
| Effect of exchange rates | (0.6 | ) |  | 1.0 |  |  | — |  |  | — |  |
| Divestiture | — |  |  | (7.3 | ) |  | — |  |  | — |  |
| Plan settlements | (1.6 | ) |  | (1.7 | ) |  | — |  |  | — |  |
| Benefits paid | (19.1 | ) |  | (19.2 | ) |  | (2.5 | ) |  | (2.3 | ) |
| Fair value of plan assets at end of year | 302.8 |  |  | 276.8 |  |  | — |  |  | — |  |
| Funded status / net amount recognized | $ | (71.8 | ) |  | $ | (137.1 | ) |  | $ | (6.0 | ) |  | $ | (7.6 | ) |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Current liability | $ | (1.8 | ) |  | $ | (2.7 | ) |  | $ | (1.4 | ) |  | $ | (1.5 | ) |
| Non-current liability | (70.0 | ) |  | (134.4 | ) |  | (4.6 | ) |  | (6.1 | ) |
| Net amount recognized | $ | (71.8 | ) |  | $ | (137.1 | ) |  | $ | (6.0 | ) |  | $ | (7.6 | ) |

[0001069202-14-000002:notes:290]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 374.6 |  |  | $ | 413.2 |  |
| Accumulated benefit obligation | 367.3 |  |  | 405.5 |  |
| Fair value of plan assets | 302.8 |  |  | 276.1 |  |

[0001069202-14-000002:notes:291]
Our U.S.-based pension plans comprised approximately 87% of the projected benefit obligation and 87% of plan assets as of December 31, 2013.

[0001069202-14-000002:notes:292]
|  | Pension Benefits |  | Other Benefits |
|  | 2013 |  | 2012 |  | 2011 |  | 2013 |  | 2012 |  | 2011 |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 5.2 |  |  | $ | 5.8 |  |  | $ | 5.4 |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | 0.8 |  |
| Interest cost | 16.2 |  |  | 17.5 |  |  | 17.8 |  |  | 0.2 |  |  | 0.4 |  |  | 0.9 |  |
| Expected return on plan assets | (20.7 | ) |  | (19.0 | ) |  | (19.0 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.4 |  |  | 0.4 |  |  | 0.4 |  |  | (3.1 | ) |  | (2.7 | ) |  | (1.9 | ) |
| Recognized actuarial loss | 9.2 |  |  | 8.7 |  |  | 7.0 |  |  | 1.5 |  |  | 1.4 |  |  | 1.2 |  |
| Settlements and curtailments | 1.5 |  |  | 7.1 |  |  | 1.7 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 11.8 |  |  | $ | 20.5 |  |  | $ | 13.3 |  |  | $ | (1.4 | ) |  | $ | (0.7 | ) |  | $ | 1.0 |  |

[0001069202-14-000002:notes:293]
(1)  Pension expense of $0.2 million, $6.9 million and $0.8 million was included in Loss for discontinued operations for the years ended December 31, 2013, 2012 and 2011 respectively.

[0001069202-14-000002:notes:294]
The following table sets forth amounts recognized in AOCI and Other comprehensive income (loss) in our financial statements for 2013 and 2012 (in millions):

[0001069202-14-000002:notes:295]
|  | Pension Benefits |  | Other Benefits |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Amounts recognized in AOCI: |  |  |  |  |  |  |  |
| Prior service costs | $ | (1.7 | ) |  | $ | (2.8 | ) |  | $ | 21.1 |  |  | $ | 24.2 |  |
| Actuarial loss | (164.4 | ) |  | (231.2 | ) |  | (20.7 | ) |  | (22.2 | ) |
| Subtotal | (166.1 | ) |  | (234.0 | ) |  | 0.4 |  |  | 2.0 |  |
| Deferred taxes | 59.9 |  |  | 85.2 |  |  | (0.2 | ) |  | (0.8 | ) |
| Net amount recognized | $ | (106.2 | ) |  | $ | (148.8 | ) |  | $ | 0.2 |  |  | $ | 1.2 |  |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Adjustment to OCI due to reclassification | $ | — |  |  | $ | 0.8 |  |  | $ | — |  |  | $ | — |  |
| Current year prior service costs | — |  |  | — |  |  | — |  |  | (14.2 | ) |
| Current year actuarial (gain) loss | (56.1 | ) |  | 34.0 |  |  | — |  |  | 2.8 |  |
| Effect of exchange rates | (0.6 | ) |  | 0.7 |  |  | — |  |  | — |  |
| Amortization of prior service (costs) credits | (1.1 | ) |  | (0.4 | ) |  | 3.1 |  |  | 2.7 |  |
| Amortization of actuarial loss | (10.0 | ) |  | (15.8 | ) |  | (1.5 | ) |  | (1.4 | ) |
| Total recognized in other comprehensive income | $ | (67.8 | ) |  | $ | 19.3 |  |  | $ | 1.6 |  |  | $ | (10.1 | ) |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) | $ | (56.0 | ) |  | $ | 39.8 |  |  | $ | 0.2 |  |  | $ | (10.8 | ) |

[0001069202-14-000002:notes:296]
The estimated prior service (costs) credits and actuarial losses that will be amortized from AOCI in 2014 are $(0.3) million and $(7.7) million, respectively, for pension benefits and $3.1 million and $(1.5) million, respectively, for other benefits.

[0001069202-14-000002:notes:297]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the U.S.-based plans in 2013 and 2012:

[0001069202-14-000002:notes:298]
|  | Pension Benefits |  | Other Benefits |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |
| Discount rate | 4.88 | % |  | 3.97 | % |  | 3.57 | % |  | 2.72 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |

[0001069202-14-000002:notes:299]
|  | Pension Benefits |  | Other Benefits |
|  | 2013 |  | 2012 |  | 2011 |  | 2013 |  | 2012 |  | 2011 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 3.97 | % |  | 4.83 | % |  | 5.45 | % |  | 2.72 | % |  | 4.64 | % |  | 5.30 | % |
| Expected long-term return on plan assets | 8.00 | % |  | 8.00 | % |  | 8.00 | % |  | — |  |  | — |  |  | — |  |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |  | — |  |

[0001069202-14-000002:notes:300]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the non-U.S.-based plans in 2013 and 2012:

[0001069202-14-000002:notes:301]
|  | Pension Benefits |
|  | 2013 |  | 2012 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 4.38 | % |  | 4.12 | % |
| Rate of compensation increase | 3.31 | % |  | 3.48 | % |

[0001069202-14-000002:notes:302]
|  | Pension Benefits |
|  | 2013 |  | 2012 |  | 2011 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate | 4.12 | % |  | 4.93 | % |  | 5.43 | % |
| Expected long-term return on plan assets | 6.05 | % |  | 6.26 | % |  | 5.56 | % |
| Rate of compensation increase | 3.48 | % |  | 3.68 | % |  | 3.98 | % |

[0001069202-14-000002:notes:303]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns and the future expectations for returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 8.0% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-14-000002:notes:304]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the duration of projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available.  We used the results of the yield curve analysis to select the discount rate that matched the duration and payment stream of the benefits in each plan.  This resulted in the selection of the 4.94% discount rate assumption for the U.S. qualified pension plans, 4.30% for the U.S. non-qualified pension plans, and 3.57% for the other benefits.  A similar process was followed for the non-U.S.-based plans.

[0001069202-14-000002:notes:305]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-14-000002:notes:306]
|  | 2013 |  | 2012 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 8.00 | % |  | 8.40 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2020 |  |  | 2020 |  |

[0001069202-14-000002:notes:307]
A one percentage-point change in assumed healthcare cost trend rates would have the following effects (in millions):

[0001069202-14-000002:notes:308]
|  | 1-Percentage-Point Increase |  | 1-Percentage-Point Decrease |
| Effect on total of service and interest cost | $ | — |  |  | $ | — |  |
| Effect on the post-retirement benefit obligation | 0.2 |  |  | (0.2 | ) |

[0001069202-14-000002:notes:309]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-14-000002:notes:310]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019-2023 |
| Pension benefits | $ | 17.1 |  |  | $ | 17.9 |  |  | $ | 18.3 |  |  | $ | 19.0 |  |  | $ | 19.5 |  |  | $ | 112.1 |  |
| Other benefits | 1.4 |  |  | 0.8 |  |  | 0.7 |  |  | 0.6 |  |  | 0.5 |  |  | 1.7 |  |

[0001069202-14-000002:notes:311]
Pension Plan Assets

[0001069202-14-000002:notes:312]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets.  Since equity securities have historically generated higher returns than fixed income securities and the plan is not fully funded, we believe it is appropriate to allocate more assets to equities than fixed income securities. In addition, these categories are further diversified among various asset classes including high yield and emerging markets debt, and international and emerging markets equities in order to avoid significant concentrations of risk. Our U.S. pension plan represents 88%, our Canadian pension plan 6%, and our United Kingdom (“U.K.”) pension plan 6% of the total fair value of our plan assets as of December 31, 2013.

[0001069202-14-000002:notes:313]
Our U.S. pension plans' weighted-average asset allocations as of December 31, 2013 and 2012, by asset category, are as follows:

[0001069202-14-000002:notes:314]
|  | Plan Assets as of December 31, |
| Asset Category: | 2013 |  | 2012 |
| U.S. equity | 37.8 | % |  | 34.2 | % |
| International equity | 26.7 | % |  | 26.1 | % |
| Fixed income | 33.8 | % |  | 37.8 | % |
| Money market/cash | 1.7 | % |  | 1.9 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-14-000002:notes:315]
U.S. pension plan assets are invested within the following range targets:

[0001069202-14-000002:notes:316]
| Asset Category: | Target |
| U.S. equity | 36.0 | % |
| International equity | 24.0 | % |
| Fixed income | 38.0 | % |
| Money market/cash/guaranteed investment contracts | 2.0 | % |

[0001069202-14-000002:notes:317]
Our Canadian pension plan was invested solely in a balanced fund that maintains diversification among various asset classes, including Canadian common stocks, bonds and money market securities, U.S. equities, other international equities and fixed income investments. Our U.K. pension plan was invested in a broad mix of assets consisting of U.K., U.S. and international equities, and U.K. fixed income securities, including corporate and government bonds.

[0001069202-14-000002:notes:318]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 1 for mutual funds and Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund's NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust's underlying assets divided by the number of units owned.  See Note 20 for information about our fair value hierarchies and valuation techniques.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-14-000002:notes:319]
Property, Plant and Equipment:

[0001069202-14-000002:notes:320]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-14-000002:notes:321]
|  | As of December 31, |
|  | 2013 |  | 2012 |
| Land | $ | 39.5 |  |  | $ | 29.4 |  |
| Buildings and improvements | 212.6 |  |  | 208.6 |  |
| Machinery and equipment | 649.1 |  |  | 612.9 |  |
| Construction in progress and equipment not yet in service | 51.6 |  |  | 32.1 |  |
| Total | 952.8 |  |  | 883.0 |  |
| Less accumulated depreciation | (617.3 | ) |  | (584.8 | ) |
| Property, plant and equipment, net | $ | 335.5 |  |  | $ | 298.2 |  |

[0001069202-14-000002:notes:322]
Property, plant and equipment, net includes capital lease assets comprised of buildings, improvements, machinery and equipment totaling $15.6 million and $14.4 million, net of accumulated depreciation of $9.6 million and $8.9 million as of December 31, 2013 and 2012, respectively.

[0001069202-14-000002:notes:323]
No impairment charges were recorded in 2013 or 2012.  We recorded $0.2 million of impairment charges for machinery and equipment assets no longer in use for the year ended December 31, 2011.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001069202-14-000002:notes:324]
Property, Plant and Equipment

[0001069202-14-000002:notes:325]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.  Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-14-000002:notes:326]
| Buildings and improvements: |  |
| Buildings and improvements | 10 to 30 years |
| Leasehold improvements | 2 to 20 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 3 to 15 years |
| Research and development equipment | 3 to 15 years |
| Vehicles | 3 to 10 years |

[0001069202-14-000002:notes:327]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 5 for additional information on our property, plant and equipment.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001069202-14-000002:notes:328]
Depreciation is computed using the straight-line method over the following estimated useful lives:


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-14-000002:notes:329]
Quarterly Financial Information (unaudited):

[0001069202-14-000002:notes:330]
The following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-14-000002:notes:331]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (Loss) (1) |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| First Quarter | $ | 668.4 |  |  | $ | 614.4 |  |  | $ | 162.0 |  |  | $ | 140.9 |  |  | $ | 8.0 |  |  | $ | (6.1 | ) |
| Second Quarter | 913.1 |  |  | 840.4 |  |  | 254.0 |  |  | 208.1 |  |  | 64.3 |  |  | 44.7 |  |
| Third Quarter | 868.0 |  |  | 809.7 |  |  | 237.4 |  |  | 204.9 |  |  | 64.3 |  |  | 29.4 |  |
| Fourth Quarter | 749.5 |  |  | 684.9 |  |  | 207.7 |  |  | 168.4 |  |  | 35.2 |  |  | 21.9 |  |

[0001069202-14-000002:notes:332]
|  | Basic Earnings (Loss) per Share (2) |  | Diluted Earnings (Loss) per Share (2) |  | Cash Dividends per Common Share |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| First Quarter | $ | 0.16 |  |  | $ | (0.12 | ) |  | $ | 0.16 |  |  | $ | (0.12 | ) |  | $ | 0.20 |  |  | $ | 0.18 |  |
| Second Quarter | 1.28 |  |  | 0.88 |  |  | 1.26 |  |  | 0.87 |  |  | 0.24 |  |  | 0.18 |  |
| Third Quarter | 1.29 |  |  | 0.58 |  |  | 1.27 |  |  | 0.57 |  |  | 0.24 |  |  | 0.20 |  |
| Fourth Quarter | 0.72 |  |  | 0.44 |  |  | 0.70 |  |  | 0.43 |  |  | 0.24 |  |  | 0.20 |  |

[0001069202-14-000002:notes:333]
(1)  The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-14-000002:notes:334]
(2)  EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.

[0001069202-14-000002:notes:335]
Summary of 2013 Quarterly Results

[0001069202-14-000002:notes:336]
The following unusual or infrequent pre-tax items were included in the 2013 quarterly results:

[0001069202-14-000002:notes:337]
1st Quarter.  On March 22, 2013, we sold our Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer") in an all-cash transaction for net proceeds of $10.4 million, excluding transaction costs.  We recorded a $1.4 million gain on the sale of the business for the year ended December 31, 2013.  Refer to Note 17 for more information.

[0001069202-14-000002:notes:338]
2nd Quarter.  We recorded restructuring charges of $2.4 million primarily related to the completion of the transition activities with our North American Parts Center in Des Moines, Iowa.  Refer to Note 16 for more information related to our restructuring activities.

[0001069202-14-000002:notes:339]
3rd Quarter.  We recorded legal contingency charges of $0.8 million associated with ongoing patent litigation.  Refer to Note 10 for more information on our legal contingencies.

[0001069202-14-000002:notes:340]
4th Quarter.  We recorded expenses of $6.3 million for asbestos-related litigation.  Refer to Note 10 for more information.  We also recorded restructuring charges of $1.8 million primarily related to anticipated severance charges associated with a relocation of certain Residential Heating & Cooling manufacturing operations to lower cost facilities.

[0001069202-14-000002:notes:341]
Summary of 2012 Quarterly Results

[0001069202-14-000002:notes:342]
The following unusual or infrequent pre-tax items were included in the 2012 quarterly results:

[0001069202-14-000002:notes:343]
1st Quarter.  We recorded a $6.3 million impairment charge for the write-down of net assets to their estimated fair value related to our Hearth business.  Refer to Note 17 for more information.  We also recognized $2.6 million primarily in lease termination charges related to the Regional Distribution Network restructuring plan.  Refer to Note 16 for more details on this restructuring plan.

[0001069202-14-000002:notes:344]
2nd Quarter.  Related to the sale of our Hearth business, we recorded a $6.3 million settlement charge as a result of actuarial losses recognized upon transition of a pension obligation to the acquirer of the business.  Partially offsetting this charge was a $3.5 million gain in the second quarter of 2012 related to realized foreign currency translation adjustments.  Refer to Note 17 for more information.

[0001069202-14-000002:notes:345]
3rd Quarter.  We recorded a goodwill impairment of $20.5 million related to the Service Experts business.  Partially offsetting this charge was a $2.9 million gain for a working capital adjustment to the net proceeds associated with the sale of the Hearth business.  Refer to Note 17 for more information on these charges.

[0001069202-14-000002:notes:346]
4th Quarter.  No significant unusual or infrequent items.


## us-gaap:ReceivablesPolicyTextBlock

[0001069202-14-000002:notes:347]
Accounts and Notes Receivable

[0001069202-14-000002:notes:348]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management's judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off of uncollectible receivables after management's review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001069202-14-000002:notes:349]
Total assets by segment are shown below (in millions):

[0001069202-14-000002:notes:350]
|  | As of December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 500.0 |  |  | $ | 457.5 |  |  | $ | 453.2 |  |
| Commercial Heating & Cooling | 346.3 |  |  | 321.9 |  |  | 306.4 |  |
| Refrigeration | 572.0 |  |  | 585.3 |  |  | 558.2 |  |
| Corporate and other | 208.4 |  |  | 228.6 |  |  | 227.4 |  |
| Assets for continuing operations | 1,626.7 |  |  | 1,593.3 |  |  | 1,545.2 |  |
| Discontinued operations (See Note 17) | — |  |  | 98.6 |  |  | 160.5 |  |
| Total assets | $ | 1,626.7 |  |  | $ | 1,691.9 |  |  | $ | 1,705.7 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-14-000002:notes:351]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 1,583.2 |  |  | $ | 1,375.8 |  |  | $ | 1,259.5 |  |
| Commercial Heating & Cooling | 844.4 |  |  | 785.4 |  |  | 776.2 |  |
| Refrigeration | 771.5 |  |  | 788.2 |  |  | 805.2 |  |
|  | $ | 3,199.1 |  |  | $ | 2,949.4 |  |  | $ | 2,840.9 |  |
| Segment Profit (Loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 180.1 |  |  | $ | 102.9 |  |  | $ | 87.6 |  |
| Commercial Heating & Cooling | 118.1 |  |  | 99.5 |  |  | 87.6 |  |
| Refrigeration | 90.2 |  |  | 81.9 |  |  | 77.5 |  |
| Corporate and other | (87.9 | ) |  | (60.1 | ) |  | (54.9 | ) |
| Subtotal that includes segment profit and eliminations | 300.5 |  |  | 224.2 |  |  | 197.8 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |
| Special product quality adjustments | (2.3 | ) |  | 1.1 |  |  | (4.3 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (3) | 8.8 |  |  | (0.2 | ) |  | 5.2 |  |
| Restructuring charges | 5.0 |  |  | 4.2 |  |  | 12.5 |  |
| Interest expense, net | 14.5 |  |  | 17.1 |  |  | 16.8 |  |
| Other expense, net | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Income from continuing operations before income taxes | $ | 274.3 |  |  | $ | 201.7 |  |  | $ | 167.3 |  |

[0001069202-14-000002:notes:352]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-14-000002:notes:353]
(2) We define segment profit and loss as a segment's income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-14-000002:notes:354]
| • | Special product quality adjustments; |

[0001069202-14-000002:notes:355]
| • | Certain items in Losses and other expenses, net (see table note 3 below); |

[0001069202-14-000002:notes:356]
| • | Restructuring charges; |

[0001069202-14-000002:notes:357]
| • | Goodwill, long-lived asset and equity method investment impairments; |

[0001069202-14-000002:notes:358]
| • | Interest expense, net; |

[0001069202-14-000002:notes:359]
| • | Other expense, net. |

[0001069202-14-000002:notes:360]
(3) Items in Losses and other expenses, net that are excluded from segment profit or loss are the net change in unrealized gains and/or losses on unsettled futures contracts, special legal contingency charges, asbestos-related litigation and other items.


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001069202-14-000002:notes:361]
Total capital expenditures by segment are shown below (in millions):

[0001069202-14-000002:notes:362]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 34.2 |  |  | $ | 13.7 |  |  | $ | 10.9 |  |
| Commercial Heating & Cooling | 11.2 |  |  | 8.7 |  |  | 6.7 |  |
| Refrigeration | 16.5 |  |  | 15.6 |  |  | 13.2 |  |
| Corporate and other | 16.4 |  |  | 12.2 |  |  | 10.6 |  |
| Total capital expenditures (1) | $ | 78.3 |  |  | $ | 50.2 |  |  | $ | 41.4 |  |

[0001069202-14-000002:notes:363]
(1) Includes amounts recorded under capital leases. There were no significant new capital leases in 2013, 2012 or 2011.

[0001069202-14-000002:notes:364]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-14-000002:notes:365]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 20.5 |  |  | $ | 19.9 |  |  | $ | 19.6 |  |
| Commercial Heating & Cooling | 9.0 |  |  | 8.5 |  |  | 8.6 |  |
| Refrigeration | 15.3 |  |  | 13.0 |  |  | 14.8 |  |
| Corporate and other | 14.1 |  |  | 14.0 |  |  | 13.6 |  |
| Total depreciation and amortization | $ | 58.9 |  |  | $ | 55.4 |  |  | $ | 56.6 |  |

[0001069202-14-000002:notes:366]
The equity method investments are shown below (in millions):

[0001069202-14-000002:notes:367]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Refrigeration | $ | 2.5 |  |  | $ | 2.6 |  |  | $ | 2.5 |  |
| Corporate and other (1) | 9.7 |  |  | 7.9 |  |  | 7.1 |  |
| Total income from equity method investments | $ | 12.2 |  |  | $ | 10.5 |  |  | $ | 9.6 |  |

[0001069202-14-000002:notes:368]
(1) We allocated $9.6 million, $5.0 million and $4.9 million of income from equity method investments to our Residential Heating & Cooling and Commercial Heating & Cooling segments in 2013, 2012 and 2011, respectively.  These allocations were recorded as reductions to the segments' Cost of goods sold in the Consolidated Statements of Operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-14-000002:notes:369]
Restructuring Charges:

[0001069202-14-000002:notes:370]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 19.

[0001069202-14-000002:notes:371]
Restructuring Activities in 2013

[0001069202-14-000002:notes:372]
In 2008, our Residential Heating & Cooling segment commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa to other locations, including our North American Distribution Center in Marshalltown, Iowa. In 2013 and 2012, we recorded expenses of $1.3 million and $2.7 million, respectively, primarily related to the relocation of inventory and lease termination charges.  These activities were substantially completed in the third quarter of 2013 and we do not expect to incur any future costs.

[0001069202-14-000002:notes:373]
All other restructuring activities in 2013, including ongoing restructuring activities as of  December 31, 2013, were individually insignificant.

[0001069202-14-000002:notes:374]
Total Restructuring

[0001069202-14-000002:notes:375]
Information regarding the restructuring charges for all plans related to continuing operations is as follows (in millions):

[0001069202-14-000002:notes:376]
|  | Incurred in 2013 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 2.7 |  |  | $ | 12.7 |  |  | $ | 12.7 |  |
| Asset write-offs and accelerated depreciation | 0.7 |  |  | 1.7 |  |  | 1.7 |  |
| Equipment moves | 0.1 |  |  | 0.4 |  |  | 0.4 |  |
| Lease termination | — |  |  | 2.6 |  |  | 2.6 |  |
| Other | 1.5 |  |  | 8.2 |  |  | 8.2 |  |
| Total | $ | 5.0 |  |  | $ | 25.6 |  |  | $ | 25.6 |  |

[0001069202-14-000002:notes:377]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-14-000002:notes:378]
|  | Incurred in 2013 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 2.6 |  |  | $ | 8.9 |  |  | $ | 8.9 |  |
| Commercial Heating & Cooling | 1.2 |  |  | 8.1 |  |  | 8.1 |  |
| Refrigeration | 1.2 |  |  | 8.6 |  |  | 8.6 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total | $ | 5.0 |  |  | $ | 25.6 |  |  | $ | 25.6 |  |

[0001069202-14-000002:notes:379]
Restructuring reserves are included in Accrued expenses in the accompanying Consolidated Balance Sheets.  The table below details activity in within the restructuring reserves (in millions):

[0001069202-14-000002:notes:380]
| Description of Reserves: | Balance as of December 31, 2012 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2013 |
| Severance and related expense | $ | 0.7 |  |  | $ | 2.7 |  |  | $ | (1.6 | ) |  | $ | (0.2 | ) |  | $ | 1.6 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.7 |  |  | — |  |  | (0.7 | ) |  | — |  |
| Equipment moves | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Lease termination | 1.2 |  |  | — |  |  | (1.2 | ) |  | — |  |  | — |  |
| Other | 0.5 |  |  | 1.5 |  |  | (2.0 | ) |  | — |  |  | — |  |
| Total restructuring reserves | $ | 2.4 |  |  | $ | 5.0 |  |  | $ | (4.9 | ) |  | $ | (0.9 | ) |  | $ | 1.6 |  |

[0001069202-14-000002:notes:381]
| Description of Reserves: | Balance as of December 31, 2011 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2012 |
| Severance and related expense | $ | 2.3 |  |  | $ | 1.2 |  |  | $ | (2.8 | ) |  | $ | — |  |  | $ | 0.7 |  |
| Asset write-offs and accelerated depreciation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Equipment moves | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Lease termination | — |  |  | 2.4 |  |  | (1.2 | ) |  | — |  |  | 1.2 |  |
| Other | 0.1 |  |  | 0.5 |  |  | — |  |  | (0.1 | ) |  | 0.5 |  |
| Total restructuring reserves | $ | 2.4 |  |  | $ | 4.2 |  |  | $ | (4.1 | ) |  | $ | (0.1 | ) |  | $ | 2.4 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001069202-14-000002:notes:382]
Revenue Recognition

[0001069202-14-000002:notes:383]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where title and risk of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns based on historical experience at the time we recognize revenue.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.

[0001069202-14-000002:notes:384]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for these services is recognized over the life of the contract.

[0001069202-14-000002:notes:385]
We engage in cooperative advertising, customer rebate, cash discount and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, General and Administrative (“SG&A”) Expenses.  All other advertising, promotions and marketing costs are expensed as incurred.  See Note 23 for more information on these costs.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001069202-14-000002:notes:386]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-14-000002:notes:387]
|  | As of December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 230.3 |  |  | $ | 227.9 |  |  | $ | 233.4 |  |
| Mexico | 39.7 |  |  | 28.0 |  |  | 28.0 |  |
| Canada | 0.6 |  |  | 0.6 |  |  | 0.6 |  |
| International | 64.9 |  |  | 41.7 |  |  | 38.7 |  |
| Total Property, plant and equipment, net | $ | 335.5 |  |  | $ | 298.2 |  |  | $ | 300.7 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001069202-14-000002:notes:388]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-14-000002:notes:389]
| Asset | Useful Life |
| Deferred financing costs | Effective interest method |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001069202-14-000002:notes:390]
Net sales for each major geographic area in which we operate are shown below (in millions):

[0001069202-14-000002:notes:391]
|  | For the Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Net Sales to External Customers by Point of Shipment: |  |  |  |  |  |
| United States | $ | 2,382.0 |  |  | $ | 2,147.2 |  |  | $ | 2,018.1 |  |
| Canada | 232.3 |  |  | 226.7 |  |  | 219.2 |  |
| International | 584.8 |  |  | 575.5 |  |  | 603.6 |  |
| Total net sales to external customers | $ | 3,199.1 |  |  | $ | 2,949.4 |  |  | $ | 2,840.9 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-14-000002:notes:392]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-14-000002:notes:393]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-14-000002:notes:394]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-14-000002:notes:395]
For the Years Ended December 31, 2013, 2012 and 2011

[0001069202-14-000002:notes:396]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2011: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 11.4 |  |  | $ | 4.3 |  |  | $ | (8.8 | ) |  | $ | 1.6 |  |  | $ | 2.8 |  |  | $ | 11.3 |  |
| 2012: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 11.3 |  |  | $ | 3.9 |  |  | $ | (6.8 | ) |  | $ | 1.8 |  |  | $ | (0.7 | ) |  | $ | 9.5 |  |
| 2013: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 9.5 |  |  | $ | 3.6 |  |  | $ | (4.6 | ) |  | $ | 1.6 |  |  | $ | (0.3 | ) |  | $ | 9.8 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-14-000002:notes:397]
Reportable Business Segments:

[0001069202-14-000002:notes:398]
Description of Segments

[0001069202-14-000002:notes:399]
In September 2012, we announced the planned sale of our Service Experts business. The Service Experts business had previously been reported within the Service Experts reportable segment along with the Lennox National Account Services ("NAS") business.  Beginning in the third quarter of 2012, the Service Experts business was included in discontinued operations, NAS was included in our Commercial Heating & Cooling segment, and the Service Experts segment was eliminated. Results for all periods have been revised to reflect this new presentation.

[0001069202-14-000002:notes:400]
Segment Data

[0001069202-14-000002:notes:401]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001069202-14-000002:notes:402]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-14-000002:notes:403]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-14-000002:notes:404]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Income from continuing operations before income taxes, are shown below (in millions):

[0001069202-14-000002:notes:405]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.  Total assets by segment are shown below (in millions):

[0001069202-14-000002:notes:406]
Geographic Information


## us-gaap:SelfInsuranceReservePolicyTextBlock

[0001069202-14-000002:notes:407]
Self-Insurance

[0001069202-14-000002:notes:408]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information and industry factors and trends.  The self-insurance liabilities as of December 31, 2013 represent the best estimate of the future payments to be made on reported and unreported losses for 2013 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 10 for additional information on our self-insured risks and liabilities.


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001069202-14-000002:notes:409]
Selling, General and Administrative Expenses

[0001069202-14-000002:notes:410]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-14-000002:notes:411]
Summary of Significant Accounting Policies:

[0001069202-14-000002:notes:412]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 3 for more information on our inventories.

[0001069202-14-000002:notes:413]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually in the first quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.  See Note 4 for additional information on our goodwill.

[0001069202-14-000002:notes:414]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-14-000002:notes:415]
We review our indefinite-lived intangible assets for impairment annually in the first quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets.

[0001069202-14-000002:notes:416]
Product Warranties

[0001069202-14-000002:notes:417]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined by product line. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. The estimated units to be repaired under warranty are multiplied by the average cost to repair or replace such products to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 10 for more information on our estimated future warranty costs.

[0001069202-14-000002:notes:418]
Pensions and Post-retirement Benefits

[0001069202-14-000002:notes:419]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheets.  Changes in the funded status are recognized in the year in which the changes occur through accumulated other comprehensive income (“AOCI”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-14-000002:notes:420]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management's estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 12 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-14-000002:notes:421]
Stock-Based Compensation

[0001069202-14-000002:notes:422]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 14 for more information.

[0001069202-14-000002:notes:423]
Use of Estimates

[0001069202-14-000002:notes:424]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-14-000002:notes:425]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-14-000002:notes:426]
Reclassifications

[0001069202-14-000002:notes:427]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:TreasuryStockTextBlock

[0001069202-14-000002:notes:428]
Stock Repurchases:

[0001069202-14-000002:notes:429]
Our Board of Directors has authorized a total of $700.0 million towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $300.0 million share repurchase authorization in December 2012.  The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date.  There were no additional share repurchase authorizations in 2013.  As of December 31, 2013, $246.2 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-14-000002:notes:430]
For the years ended December 31, 2013 and 2012, we repurchased 1.7 million shares for $125.0 million and 1.1 million shares for $50.1 million, respectively, under the Share Repurchase Plans.  The repurchases in 2013 included 0.2 million shares repurchased in transactions that were executed in 2013 but settled in January 2014.

[0001069202-14-000002:notes:431]
We also repurchased 0.2 million shares for $12.0 million and 0.2 million shares for $7.8 million for the years ended December 31, 2013 and 2012, respectively, from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the vesting of stock-based compensation awards.
