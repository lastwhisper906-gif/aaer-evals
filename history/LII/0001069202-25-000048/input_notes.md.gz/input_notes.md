# LII notes — 0001069202-25-000048


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-25-000048:notes:1]
[same as prior period, unchanged from 0001069202-25-000032:notes:1]

[0001069202-25-000048:notes:2]
[same as prior period, unchanged from 0001069202-25-000032:notes:2]

[0001069202-25-000048:notes:3]
[same as prior period, unchanged from 0001069202-25-000032:notes:3]

[0001069202-25-000048:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2025, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three and nine months ended September 30, 2025 and 2024, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2025 and 2024 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2024.

[0001069202-25-000048:notes:5]
[same as prior period, unchanged from 0001069202-25-000032:notes:5]

[0001069202-25-000048:notes:6]
[same as prior period, unchanged from 0001069202-25-000032:notes:6]

[0001069202-25-000048:notes:7]
[same as prior period, unchanged from 0001069202-25-000032:notes:7]

[0001069202-25-000048:notes:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-25-000048:notes:9]
[same as prior period, unchanged from 0001069202-25-000032:notes:9]

[0001069202-25-000048:notes:10]
[same as prior period, unchanged from 0001069202-25-000032:notes:10]

[0001069202-25-000048:notes:11]
[same as prior period, unchanged from 0001069202-25-000032:notes:11]

[0001069202-25-000048:notes:12]
[same as prior period, unchanged from 0001069202-25-000032:notes:12]

[0001069202-25-000048:notes:13]
[same as prior period, unchanged from 0001069202-25-000032:notes:13]

[0001069202-25-000048:notes:14]
[same as prior period, unchanged from 0001069202-25-000032:notes:14]

[0001069202-25-000048:notes:15]
[same as prior period, unchanged from 0001069202-25-000032:notes:15]

[0001069202-25-000048:notes:16]
[same as prior period, unchanged from 0001069202-25-000032:notes:16]

[0001069202-25-000048:notes:17]
|  | Home Comfort Solutions |  | Business Climate Solutions |  | Corporate and Other |  | Total |
| Three months ended September 30, 2025 |  |  |  |  |  |  |  |
| Net sales(1) | $ | 912.9 |  |  | $ | 513.9 |  |  | $ | — |  |  | $ | 1,426.8 |  |
| Cost of goods sold | 634.0 |  |  | 323.1 |  |  | 1.1 |  |  | 958.2 |  |
| Selling, general and administrative | 81.2 |  |  | 58.0 |  |  | 22.4 |  |  | 161.6 |  |
| Other (income) expense(2) | (5.2) |  |  | (1.2) |  |  | 3.2 |  |  | (3.2) |  |
| Segment profit (loss)(3) | $ | 202.9 |  |  | $ | 134.0 |  |  | $ | (26.7) |  |  | $ | 310.2 |  |
| Three months ended September 30, 2024 |  |  |  |  |  |  |  |
| Net sales(1) | $ | 1,032.8 |  |  | $ | 465.3 |  |  | $ | — |  |  | $ | 1,498.1 |  |
| Cost of goods sold | 706.6 |  |  | 302.5 |  |  | 0.6 |  |  | 1,009.7 |  |
| Selling, general and administrative | 100.4 |  |  | 59.0 |  |  | 25.0 |  |  | 184.4 |  |
| Other (income) expense(2) | (0.7) |  |  | (2.1) |  |  | 3.5 |  |  | 0.7 |  |
| Segment profit (loss)(3) | $ | 226.5 |  |  | $ | 105.9 |  |  | $ | (29.1) |  |  | $ | 303.3 |  |

[0001069202-25-000048:notes:18]
|  | Home Comfort Solutions |  | Business Climate Solutions |  | Corporate and Other |  | Total |
| Nine months ended September 30, 2025 |  |  |  |  |  |  |  |
| Net sales(1) | $ | 2,643.6 |  |  | $ | 1,356.7 |  |  | $ | — |  |  | $ | 4,000.3 |  |
| Cost of goods sold | 1,809.5 |  |  | 869.3 |  |  | 1.9 |  |  | 2,680.7 |  |
| Selling, general and administrative | 271.0 |  |  | 179.4 |  |  | 55.8 |  |  | 506.2 |  |
| Other (income) expense(2) | (11.8) |  |  | (2.0) |  |  | 7.4 |  |  | (6.4) |  |
| Segment profit (loss)(3) | $ | 574.9 |  |  | $ | 310.0 |  |  | $ | (65.1) |  |  | $ | 819.8 |  |
| Nine months ended September 30, 2024 |  |  |  |  |  |  |  |
| Net sales(1) | $ | 2,689.7 |  |  | $ | 1,306.6 |  |  | $ | — |  |  | $ | 3,996.3 |  |
| Cost of goods sold | 1,833.8 |  |  | 844.8 |  |  | 1.1 |  |  | 2,679.7 |  |
| Selling, general and administrative | 292.5 |  |  | 167.9 |  |  | 63.2 |  |  | 523.6 |  |
| Other (income) expense(2) | (3.7) |  |  | (4.2) |  |  | 12.3 |  |  | 4.4 |  |
| Segment profit (loss)(3) | $ | 567.1 |  |  | $ | 298.1 |  |  | $ | (76.6) |  |  | $ | 788.6 |  |

[0001069202-25-000048:notes:19]
[same as prior period, unchanged from 0001069202-25-000032:notes:19]

[0001069202-25-000048:notes:20]
[same as prior period, unchanged from 0001069202-25-000032:notes:20]

[0001069202-25-000048:notes:21]
[same as prior period, unchanged from 0001069202-25-000032:notes:21]

[0001069202-25-000048:notes:22]
[same as prior period, unchanged from 0001069202-25-000032:notes:22]

[0001069202-25-000048:notes:23]
[same as prior period, unchanged from 0001069202-25-000032:notes:23]

[0001069202-25-000048:notes:24]
[same as prior period, unchanged from 0001069202-25-000032:notes:24]

[0001069202-25-000048:notes:25]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Total segment profit(1) | $ | 310.2 |  |  | $ | 303.3 |  |  | $ | 819.8 |  |  | $ | 788.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Restructuring charges | — |  |  | — |  |  | — |  |  | — |  |
| Gain on sale from previous dispositions | — |  |  | — |  |  | — |  |  | (1.6) |  |
| Operating income | 310.2 |  |  | 303.3 |  |  | 819.8 |  |  | 790.2 |  |
| Reconciliation to income before income taxes: |  |  |  |  |  |  |  |
| Pension settlements | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.4 |  |
| Interest expense, net | 10.5 |  |  | 8.9 |  |  | 25.0 |  |  | 33.2 |  |
| Other expense, net | 0.8 |  |  | 0.4 |  |  | 2.3 |  |  | 1.5 |  |
| Net income before income taxes | $ | 298.8 |  |  | $ | 293.9 |  |  | $ | 792.2 |  |  | $ | 755.1 |  |

[0001069202-25-000048:notes:26]
(1) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-25-000048:notes:27]
[same as prior period, unchanged from 0001069202-25-000032:notes:27]

[0001069202-25-000048:notes:28]
|  | September 30, 2025 |  | December 31, 2024 |
| Total Assets: |  |  |  |
| Home Comfort Solutions | $ | 1,869.5 |  |  | $ | 1,626.0 |  |
| Building Climate Solutions | 1,281.8 |  |  | 1,052.6 |  |
| Corporate and Other | 373.3 |  |  | 793.2 |  |
| Total assets | $ | 3,524.6 |  |  | $ | 3,471.8 |  |

[0001069202-25-000048:notes:29]
[same as prior period, unchanged from 0001069202-25-000032:notes:29]

[0001069202-25-000048:notes:30]
[same as prior period, unchanged from 0001069202-25-000032:notes:30]

[0001069202-25-000048:notes:31]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Capital Expenditures: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 7.2 |  |  | $ | 16.8 |  |  | $ | 30.4 |  |  | $ | 45.6 |  |
| Building Climate Solutions | 22.0 |  |  | 17.5 |  |  | 34.5 |  |  | 39.7 |  |
| Corporate and Other | 6.4 |  |  | 6.9 |  |  | 24.7 |  |  | 18.1 |  |
| Total capital expenditures | $ | 35.6 |  |  | $ | 41.2 |  |  | $ | 89.6 |  |  | $ | 103.4 |  |

[0001069202-25-000048:notes:32]
[same as prior period, unchanged from 0001069202-25-000032:notes:32]

[0001069202-25-000048:notes:33]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Depreciation and Amortization: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 11.5 |  |  | $ | 6.2 |  |  | $ | 33.4 |  |  | $ | 28.5 |  |
| Building Climate Solutions | 8.6 |  |  | 6.5 |  |  | 24.5 |  |  | 18.5 |  |
| Corporate and Other | 6.9 |  |  | 7.7 |  |  | 21.5 |  |  | 22.6 |  |
| Total depreciation and amortization | $ | 27.0 |  |  | $ | 20.4 |  |  | $ | 79.4 |  |  | $ | 69.6 |  |

[0001069202-25-000048:notes:34]
[same as prior period, unchanged from 0001069202-25-000032:notes:34]

[0001069202-25-000048:notes:35]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Income from Equity Method Investments: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 2.4 |  |  | $ | 1.1 |  |  | $ | 4.8 |  |  | $ | 3.7 |  |
| Building Climate Solutions | 0.3 |  |  | 1.1 |  |  | 1.1 |  |  | 2.3 |  |
| Corporate and Other | (0.2) |  |  | 0.2 |  |  | (0.1) |  |  | 0.1 |  |
| Total income from equity method investments | $ | 2.5 |  |  | $ | 2.4 |  |  | $ | 5.8 |  |  | $ | 6.1 |  |

[0001069202-25-000048:notes:36]
[same as prior period, unchanged from 0001069202-25-000032:notes:36]

[0001069202-25-000048:notes:37]
[same as prior period, unchanged from 0001069202-25-000032:notes:37]

[0001069202-25-000048:notes:38]
|  | September 30, 2025 |  | December 31, 2024 |  |  |  |  |
| Property, Plant and Equipment, net: |  |  |  |  |  |  |  |
| United States | $ | 570.4 |  |  | $ | 537.3 |  |  |  |  |  |
| Mexico | 266.6 |  |  | 254.0 |  |  |  |  |  |
| Canada | 3.7 |  |  | 2.9 |  |  |  |  |  |
| Other international | 6.8 |  |  | 5.9 |  |  |  |  |  |
| Total Property, plant and equipment, net | $ | 847.5 |  |  | $ | 800.1 |  |  |  |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-25-000048:notes:39]
[same as prior period, unchanged from 0001069202-25-000032:notes:39]

[0001069202-25-000048:notes:40]
[same as prior period, unchanged from 0001069202-25-000032:notes:40]

[0001069202-25-000048:notes:41]
[same as prior period, unchanged from 0001069202-25-000032:notes:41]

[0001069202-25-000048:notes:42]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income | $ | 245.8 |  |  | $ | 239.0 |  |  | $ | 643.7 |  |  | $ | 609.2 |  |
| Weighted-average shares outstanding – basic | 35.1 |  |  | 35.6 |  |  | 35.3 |  |  | 35.6 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.1 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Weighted-average shares outstanding – diluted | 35.2 |  |  | 35.8 |  |  | 35.5 |  |  | 35.8 |  |
| Earnings per share – Basic(1): | $ | 7.01 |  |  | $ | 6.71 |  |  | $ | 18.23 |  |  | $ | 17.11 |  |
| Earnings per share – Diluted(1): | $ | 6.98 |  |  | $ | 6.68 |  |  | $ | 18.15 |  |  | $ | 17.02 |  |

[0001069202-25-000048:notes:43]
(1) Amounts may not recalculate due to rounding.

[0001069202-25-000048:notes:44]
[same as prior period, unchanged from 0001069202-25-000032:notes:43]

[0001069202-25-000048:notes:45]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Weighted-average number of shares | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-25-000048:notes:46]
4. Commitments and Contingencies:

[0001069202-25-000048:notes:47]
Leases

[0001069202-25-000048:notes:48]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or

[0001069202-25-000048:notes:49]
less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001069202-25-000048:notes:50]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition of a lease under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-25-000048:notes:51]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-25-000048:notes:52]
We lease certain real and personal property under non-cancelable operating leases. Approximately 81% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-25-000048:notes:53]
Product Warranties and Product Related Contingencies

[0001069202-25-000048:notes:54]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001069202-25-000048:notes:55]
Liabilities for estimated product warranty costs are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:

[0001069202-25-000048:notes:56]
|  | September 30, 2025 |  | December 31, 2024 |
| Accrued expenses | $ | 50.7 |  |  | $ | 49.1 |  |
| Other liabilities | 114.3 |  |  | 109.4 |  |
| Total warranty liability | $ | 165.0 |  |  | $ | 158.4 |  |

[0001069202-25-000048:notes:57]
The changes in product warranty liabilities for the nine months ended September 30, 2025 were as follows (in millions):

[0001069202-25-000048:notes:58]
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Warranty claims paid | (36.3) |  |
| Changes resulting from issuance of new warranties | 39.9 |  |
| Changes in estimates associated with pre-existing liabilities | 2.7 |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of September 30, 2025 | $ | 165.0 |  |

[0001069202-25-000048:notes:59]
Litigation

[0001069202-25-000048:notes:60]
We are involved in a number of claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-25-000048:notes:61]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-25-000048:notes:62]
[same as prior period, unchanged from 0001069202-25-000032:notes:60]

[0001069202-25-000048:notes:63]
Our Board of Directors has authorized a total of $5.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in May 2025. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. Such repurchases may also be made in compliance with Rule 10b5-1 trading plans entered into by us, which would permit common stock to be repurchased when we might otherwise be precluded from doing so under insider trading laws or self-imposed trading restrictions. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of September 30, 2025, $1,159.5 million was available for repurchase under the Share Repurchase Plans.

[0001069202-25-000048:notes:64]
For the three and nine months ended September 30, 2025, we repurchased 63,000 and 578,665 shares, respectively, at an aggregate cost, inclusive of fees, of $36.9 million and $332.3 million, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-25-000048:notes:65]
[same as prior period, unchanged from 0001069202-25-000032:notes:63]

[0001069202-25-000048:notes:66]
[same as prior period, unchanged from 0001069202-25-000032:notes:64]

[0001069202-25-000048:notes:67]
| (Amounts in millions) | For the Three Months Ended September 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 850.1 |  |  | $ | 478.3 |  |  | $ | — |  |  | $ | 1,328.4 |  |
| Canada | 62.8 |  |  | 35.6 |  |  | — |  |  | 98.4 |  |
| Total | $ | 912.9 |  |  | $ | 513.9 |  |  | $ | — |  |  | $ | 1,426.8 |  |

[0001069202-25-000048:notes:68]
|  | For the Three Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 971.1 |  |  | $ | 441.9 |  |  | $ | — |  |  | $ | 1,413.0 |  |
| Canada | 61.7 |  |  | 23.4 |  |  | — |  |  | 85.1 |  |
| Total | $ | 1,032.8 |  |  | $ | 465.3 |  |  | $ | — |  |  | $ | 1,498.1 |  |

[0001069202-25-000048:notes:69]
|  | For the Nine Months Ended September 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,458.9 |  |  | $ | 1,266.6 |  |  | $ | — |  |  | $ | 3,725.5 |  |
| Canada | 184.7 |  |  | 90.1 |  |  | — |  |  | 274.8 |  |
| Total | $ | 2,643.6 |  |  | $ | 1,356.7 |  |  | $ | — |  |  | $ | 4,000.3 |  |

[0001069202-25-000048:notes:70]
|  | For the Nine Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,520.7 |  |  | $ | 1,244.2 |  |  | $ | — |  |  | $ | 3,764.9 |  |
| Canada | 169.0 |  |  | 62.4 |  |  | — |  |  | 231.4 |  |
| Total | $ | 2,689.7 |  |  | $ | 1,306.6 |  |  | $ | — |  |  | $ | 3,996.3 |  |

[0001069202-25-000048:notes:71]
[same as prior period, unchanged from 0001069202-25-000032:notes:69]

[0001069202-25-000048:notes:72]
installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2025 and 2024, direct sales represented 75% and 73% of revenues, respectively, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2025 and 2024, direct sales represented 74% and 74% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-25-000048:notes:73]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada; manufacture curb, curb adapters, drop box diffusers; offer HVAC recycling and salvage services; and focus on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2025 and 2024, equipment sales represented 80% and 80% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2025 and 2024, equipment sales represented 80% and 81% of revenues and the remainder of our revenue was generated from our service business.

[0001069202-25-000048:notes:74]
[same as prior period, unchanged from 0001069202-25-000032:notes:72]

[0001069202-25-000048:notes:75]
|  | September 30, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 3.1 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (11.1) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (10.1) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (18.1) |  |  | $ | (12.2) |  |  |  |  |  |

[0001069202-25-000048:notes:76]
For the three months ended September 30, 2025 and 2024, we recognized revenue of $5.4 million and $0.7 million and for the nine months ended September 30, 2025 and 2024, we recognized revenue of $8.5 million and $6.8 million related to our contract liabilities at January 1, 2025 and 2024, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025 and 2024.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-25-000048:notes:77]
[same as prior period, unchanged from 0001069202-25-000032:notes:75]

[0001069202-25-000048:notes:78]
[same as prior period, unchanged from 0001069202-25-000032:notes:76]

[0001069202-25-000048:notes:79]
|  | September 30, 2025 |  | December 31, 2024 |
| Finished goods | $ | 723.7 |  |  | $ | 422.6 |  |
| Work in process | 11.3 |  |  | 11.0 |  |
| Raw materials and parts | 414.1 |  |  | 410.7 |  |
| Subtotal | 1,149.1 |  |  | 844.3 |  |
| Excess of current cost over last-in, first-out cost | (157.6) |  |  | (139.5) |  |
| Total inventories, net | $ | 991.5 |  |  | $ | 704.8 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-25-000048:notes:80]
[same as prior period, unchanged from 0001069202-25-000032:notes:78]

[0001069202-25-000048:notes:81]
[same as prior period, unchanged from 0001069202-25-000032:notes:79]

[0001069202-25-000048:notes:82]
|  | Balance as of December 31, 2024 |  | Goodwill Adjustment |  |  |  | Balance as of September 30, 2025 |
| Home Comfort Solutions | $ | 26.1 |  |  | $ | — |  |  |  |  | $ | 26.1 |  |
| Building Climate Solutions | 193.9 |  |  | — |  |  |  |  | 193.9 |  |
| Total Goodwill | $ | 220.0 |  |  | $ | — |  |  |  |  | $ | 220.0 |  |

[0001069202-25-000048:notes:83]
We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We have not recorded any goodwill impairments for the nine months ended September 30, 2025 or in any periods presented.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-25-000048:notes:84]
[same as prior period, unchanged from 0001069202-25-000032:notes:82]

[0001069202-25-000048:notes:85]
[same as prior period, unchanged from 0001069202-25-000032:notes:83]

[0001069202-25-000048:notes:86]
[same as prior period, unchanged from 0001069202-25-000032:notes:84]

[0001069202-25-000048:notes:87]
[same as prior period, unchanged from 0001069202-25-000032:notes:85]

[0001069202-25-000048:notes:88]
[same as prior period, unchanged from 0001069202-25-000032:notes:86]

[0001069202-25-000048:notes:89]
[same as prior period, unchanged from 0001069202-25-000032:notes:87]

[0001069202-25-000048:notes:90]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through February 2027.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 17 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions) as of:

[0001069202-25-000048:notes:91]
|  | September 30, 2025 |  | December 31, 2024 |
| Unrealized (gains) losses, net on unsettled contracts | $ | (12.5) |  |  | $ | 2.0 |  |
| Income tax expense (benefit) | 3.2 |  |  | (0.6) |  |
| Unrealized (gains) losses, net included in AOCL, net of tax (1) | $ | (9.3) |  |  | $ | 1.4 |  |

[0001069202-25-000048:notes:92]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $11.3 million of derivative gain as of September 30, 2025 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-25-000048:notes:93]
[same as prior period, unchanged from 0001069202-25-000032:notes:91]

[0001069202-25-000048:notes:94]
[same as prior period, unchanged from 0001069202-25-000032:notes:92]

[0001069202-25-000048:notes:95]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Stock-based compensation expense | $ | 6.3 |  |  | $ | 6.8 |  |  | $ | 20.8 |  |  | $ | 20.1 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-25-000048:notes:96]
[same as prior period, unchanged from 0001069202-25-000032:notes:94]

[0001069202-25-000048:notes:97]
[same as prior period, unchanged from 0001069202-25-000032:notes:95]

[0001069202-25-000048:notes:98]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Service cost | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 1.2 |  |
| Interest cost | 2.2 |  |  | 2.2 |  |  | 6.3 |  |  | 6.5 |  |
| Expected return on plan assets | (1.8) |  |  | (1.9) |  |  | (5.4) |  |  | (5.7) |  |
| Amortization of prior service cost | — |  |  | — |  |  | (0.1) |  |  | — |  |
| Recognized actuarial loss | 0.4 |  |  | 0.3 |  |  | 1.3 |  |  | 0.7 |  |
| Settlements and curtailments | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.4 |  |
| Net periodic benefit cost | $ | 1.1 |  |  | $ | 1.1 |  |  | $ | 3.2 |  |  | $ | 3.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-25-000048:notes:99]
[same as prior period, unchanged from 0001069202-25-000032:notes:97]

[0001069202-25-000048:notes:100]
As of September 30, 2025, we had approximately $4.9 million in total gross unrecognized tax benefits. If recognized, $4.9 million would be recorded through the Consolidated Statements of Operations.

[0001069202-25-000048:notes:101]
Our effective tax rate was 18.7% for the nine months ended September 30, 2025 compared to 19.3% for the nine months ended September 30, 2024. The decrease in rate is primarily due to higher income in low tax jurisdictions.

[0001069202-25-000048:notes:102]
[same as prior period, unchanged from 0001069202-25-000032:notes:100]


## us-gaap:DebtDisclosureTextBlock

[0001069202-25-000048:notes:103]
10. Lines of Credit and Financing Arrangements:

[0001069202-25-000048:notes:104]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:

[0001069202-25-000048:notes:105]
|  | September 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 157.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.9 |  |  | $ | 14.9 |  |
| Senior unsecured notes | — |  |  | 300.0 |  |
| Debt issuance costs | — |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 16.9 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 44.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.5) |  |  | (6.4) |  |
| Total long-term debt | $ | 838.2 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,012.1 |  |  | $ | 1,147.6 |  |

[0001069202-25-000048:notes:106]
Commercial Paper Program

[0001069202-25-000048:notes:107]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $157.0 million CP Notes outstanding under the Program as of September 30, 2025.

[0001069202-25-000048:notes:108]
Our weighted average borrowing rate on the Program was as follows as of:

[0001069202-25-000048:notes:109]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.30 | % |  | — | % |

[0001069202-25-000048:notes:110]
Credit Agreement

[0001069202-25-000048:notes:111]
On May 9, 2025, we entered into an Amendment and Restatement Agreement ("Amended Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Amended Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Amended Credit Agreement. The Amended Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of September 30, 2025. Subject to covenant limitations, $841.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Amended Credit Agreement is reduced by borrowings under the Program. The Amended Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Amended Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Amended Credit Agreement.

[0001069202-25-000048:notes:112]
Our weighted average borrowing rate on the Amended Credit Agreement was as follows as of:

[0001069202-25-000048:notes:113]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |

[0001069202-25-000048:notes:114]
The Amended Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Amended Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001069202-25-000048:notes:115]
Our Amended Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001069202-25-000048:notes:116]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding      $75.0 million; or

[0001069202-25-000048:notes:117]
•We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-25-000048:notes:118]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Amended Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-25-000048:notes:119]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Amended Credit Agreement and accelerate amounts due under our Amended Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-25-000048:notes:120]
We are currently in compliance with all covenant requirements.

[0001069202-25-000048:notes:121]
Senior Unsecured Notes

[0001069202-25-000048:notes:122]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  In July 2020, we issued $300.0 million of senior unsecured notes, which will mature on August 1, 2027 (the "2027 Notes," and collectively with the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.70% per annum. On August 1, 2025, we repaid upon maturity $300.0 million of senior unsecured notes originally issued in 2020. 
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Amended Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-25-000048:notes:123]
[same as prior period, unchanged from 0001069202-25-000032:notes:121]

[0001069202-25-000048:notes:124]
[same as prior period, unchanged from 0001069202-25-000032:notes:122]

[0001069202-25-000048:notes:125]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Gains (Losses) on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | 9.3 |  |  | $ | (0.8) |  |  | $ | 15.3 |  |  | $ | (1.2) |  |  | Cost of goods sold; Losses and other expenses, net |
| Income tax (expense) benefit |  | (2.1) |  |  | 0.2 |  |  | (3.5) |  |  | 0.3 |  |  | Provision for income taxes |
| Net of tax |  | $ | 7.2 |  |  | $ | (0.6) |  |  | $ | 11.8 |  |  | $ | (0.9) |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (0.4) |  |  | $ | (0.3) |  |  | $ | (1.2) |  |  | $ | (0.7) |  |  | Other expense, net |
| Pension settlements |  | (0.1) |  |  | (0.1) |  |  | (0.3) |  |  | (0.4) |  |  | Pension settlements |
| Income tax benefit |  | 0.1 |  |  | 0.1 |  |  | 0.4 |  |  | 0.3 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.4) |  |  | $ | (0.3) |  |  | $ | (1.1) |  |  | $ | (0.8) |  |  |  |
| Total reclassifications from AOCL |  | $ | 6.8 |  |  | $ | (0.9) |  |  | $ | 10.7 |  |  | $ | (1.7) |  |  |  |

[0001069202-25-000048:notes:126]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2025 (in millions):

[0001069202-25-000048:notes:127]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2024 |  | $ | (1.5) |  |  | $ | 0.4 |  |  | $ | (45.7) |  |  | $ | (46.9) |  |  | $ | (93.7) |  |
| Other comprehensive income (loss) before reclassifications |  | 22.6 |  |  | (0.2) |  |  | (1.1) |  |  | 22.4 |  |  | 43.7 |  |
| Amounts reclassified from AOCL |  | (11.8) |  |  | — |  |  | 1.1 |  |  | (1.3) |  |  | (12.0) |  |
| Net other comprehensive income (loss) |  | 10.8 |  |  | (0.2) |  |  | — |  |  | 21.1 |  |  | 31.7 |  |
| Balance as of September 30, 2025 |  | $ | 9.3 |  |  | $ | 0.2 |  |  | $ | (45.7) |  |  | $ | (25.8) |  |  | $ | (62.0) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-25-000048:notes:128]
[same as prior period, unchanged from 0001069202-25-000032:notes:126]

[0001069202-25-000048:notes:129]
[same as prior period, unchanged from 0001069202-25-000032:notes:127]

[0001069202-25-000048:notes:130]
The methodologies used to determine the fair value of our financial assets and liabilities as of September 30, 2025 were the same as those used as of December 31, 2024.

[0001069202-25-000048:notes:131]
[same as prior period, unchanged from 0001069202-25-000032:notes:129]

[0001069202-25-000048:notes:132]
[same as prior period, unchanged from 0001069202-25-000032:notes:130]

[0001069202-25-000048:notes:133]
[same as prior period, unchanged from 0001069202-25-000032:notes:131]

[0001069202-25-000048:notes:134]
[same as prior period, unchanged from 0001069202-25-000032:notes:132]

[0001069202-25-000048:notes:135]
[same as prior period, unchanged from 0001069202-25-000032:notes:133]

[0001069202-25-000048:notes:136]
|  | September 30, 2025 |  | December 31, 2024 |
| Senior unsecured notes | $ | 806.9 |  |  | $ | 1,093.4 |  |


## us-gaap:SubsequentEventsTextBlock

[0001069202-25-000048:notes:137]
13. Subsequent Events:

[0001069202-25-000048:notes:138]
Acquisition – Duro Dyne and Supco

[0001069202-25-000048:notes:139]
On October 15, 2025, the Company completed the previously announced acquisition of Duro Dyne Buyer, Inc. and Sealed Unit Parts Buyer, Inc. (“Duro Dyne and Supco”). Duro Dyne and Supco offer a robust portfolio of HVAC parts and supplies that complement our existing residential and commercial offerings. Excluding cash received at the closing, the net purchase price for the acquisition was $546.3 million. We used cash on hand and available borrowing capacity to fund the purchase price.  The purchase price is subject to final adjustments for net working capital. The financial results of Duro Dyne and Supco will be included beginning in the fourth quarter of 2025.

[0001069202-25-000048:notes:140]
Due to the timing of this transaction, the allocation of the purchase price has not yet been finalized.

[0001069202-25-000048:notes:141]
Term Credit Agreement

[0001069202-25-000048:notes:142]
On October 16, 2025, we entered into a Term Credit Agreement (the “Term Credit Agreement”) with Wells Fargo Bank, National Association, as administrative agent, and the other lenders party thereto. We borrowed $300.0 million pursuant to the Term Credit Agreement and used the net proceeds to repay existing borrowings under the Amended Credit Agreement. The Term Credit Agreement matures on October 16, 2027. Loans under the Term Credit Agreement bear interest at our election at a rate per annum equal to (i) a forward-looking term rate based on the secured overnight financing rate for the applicable interest period ("Term SOFR"), plus an applicable margin ranging between 0.90% and 1.025% per annum depending on our long-term unsecured debt rating, or (ii) the highest of the Wells Fargo Bank, National Association prime rate, the Federal Funds rate plus 0.50%, and Term SOFR for a one month tenor in effect on such day plus 1.00%, plus an applicable margin ranging between 0.00% and 0.025% per annum depending on our long-term unsecured debt rating.

[0001069202-25-000048:notes:143]
The Term Credit Agreement is guaranteed by the Guarantor Subsidiaries and contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Amended Credit Agreement.
