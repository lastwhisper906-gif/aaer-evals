# LII MD&A — 0001069202-25-000048


## mdna

[0001069202-25-000048:mdna:1]
[same as prior period, unchanged from 0001069202-25-000032:mdna:1]

[0001069202-25-000048:mdna:2]
[same as prior period, unchanged from 0001069202-25-000032:mdna:2]

[0001069202-25-000048:mdna:3]
[same as prior period, unchanged from 0001069202-25-000032:mdna:3]

[0001069202-25-000048:mdna:4]
[same as prior period, unchanged from 0001069202-25-000032:mdna:4]

[0001069202-25-000048:mdna:5]
[same as prior period, unchanged from 0001069202-25-000032:mdna:5]

[0001069202-25-000048:mdna:6]
[same as prior period, unchanged from 0001069202-25-000032:mdna:6]

[0001069202-25-000048:mdna:7]
[same as prior period, unchanged from 0001069202-25-000032:mdna:7]

[0001069202-25-000048:mdna:8]
Results for the third quarter of 2025 were mixed as our Home Comfort Solutions segment faced volume headwinds driven by market softness. Overall our net sales decreased 5% to $1.4 billion and our segment profit increased 2% to $310 million. For our Home Comfort Solutions segment, net sales decreased 12% and segment profit decreased $24 million. For our Building Climate Solutions segment, net sales increased 10% and segment profit increased $28 million. Segment loss decreased $2.4 million for our Corporate and Other segment.

[0001069202-25-000048:mdna:9]
[same as prior period, unchanged from 0001069202-25-000032:mdna:9]

[0001069202-25-000048:mdna:10]
•Net sales of $1,427 million in the third quarter of 2025 reflected a 5% decrease as compared to the same period in 2024.

[0001069202-25-000048:mdna:11]
•Operating income in the third quarter of 2025 increased $7 million to $310 million as favorable mix and price were partially offset by lower sales volumes, higher product costs, primarily related to inflationary pressures, including tariffs, and higher freight and distribution costs.

[0001069202-25-000048:mdna:12]
•Net income for the third quarter of 2025 was $246 million.

[0001069202-25-000048:mdna:13]
•Diluted earnings per share was $6.98 per share in the third quarter of 2025 as compared to $6.68 per share in the same period in 2024.

[0001069202-25-000048:mdna:14]
•For the nine months ended September 30, 2025, we returned $127 million to shareholders through dividend payments and repurchased $332 million of common stock through our share repurchase program.

[0001069202-25-000048:mdna:15]
[same as prior period, unchanged from 0001069202-25-000032:mdna:16]

[0001069202-25-000048:mdna:16]
On July 4, 2025, the “One Big Beautiful Bill Act” was signed into law, which includes significant changes to federal tax law and other regulatory provisions that may impact the Company. Based on an initial analysis of the relevant provisions, the impacts to our effective tax rate are immaterial, but several timing provisions are expected to result in material 2025 cash tax savings.

[0001069202-25-000048:mdna:17]
Three Months Ended September 30, 2025 Compared to Three Months Ended September 30, 2024 - Consolidated Results

[0001069202-25-000048:mdna:18]
[same as prior period, unchanged from 0001069202-25-000032:mdna:19]

[0001069202-25-000048:mdna:19]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 1,426.8 |  |  | $ | 1,498.1 |  |  | (4.8) | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 958.2 |  |  | 1,009.7 |  |  | 5.1 |  |  | 67.2 |  |  | 67.4 |  |
| Gross profit | 468.6 |  |  | 488.4 |  |  | (4.1) |  |  | 32.8 |  |  | 32.6 |  |
| Selling, general and administrative expenses | 161.6 |  |  | 184.4 |  |  | 12.4 |  |  | 11.3 |  |  | 12.3 |  |
| (Gains) losses and other expenses, net | (0.7) |  |  | 3.1 |  |  | 122.6 |  |  | — |  |  | 0.2 |  |
| Income from equity method investments | (2.5) |  |  | (2.4) |  |  | 4.2 |  |  | (0.2) |  |  | (0.2) |  |
| Operating income | $ | 310.2 |  |  | $ | 303.3 |  |  | 2.3 | % |  | 21.7 | % |  | 20.2 | % |

[0001069202-25-000048:mdna:20]
[same as prior period, unchanged from 0001069202-25-000032:mdna:21]

[0001069202-25-000048:mdna:21]
Net sales for the third quarter of 2025 decreased 5% as compared to the same period in 2024 primarily due to a 16% decrease in sales volumes, which was partially offset by an 11% increase in mix and pricing.

[0001069202-25-000048:mdna:22]
[same as prior period, unchanged from 0001069202-25-000032:mdna:23]

[0001069202-25-000048:mdna:23]
Gross profit margins in the third quarter of 2025 increased 20 basis points ("bps") to 32.8% as compared to 32.6% in the same period in 2024. Gross margins increased 350 bps from favorable mix and pricing, which were partially offset by 200 bps from higher product costs, primarily related to inflationary pressures, including tariffs, and 130 bps from higher freight and distribution costs.

[0001069202-25-000048:mdna:24]
[same as prior period, unchanged from 0001069202-25-000032:mdna:26]

[0001069202-25-000048:mdna:25]
Selling, general and administrative expenses ("SG&A") decreased $22 million to $162 million in the third quarter of 2025 as compared to $184 million in the same period in 2024, primarily due to lower incentive compensation related costs.

[0001069202-25-000048:mdna:26]
[same as prior period, unchanged from 0001069202-25-000032:mdna:28]

[0001069202-25-000048:mdna:27]
(Gains) losses and other expenses, net for the third quarter of 2025 and 2024 included the following (in millions):

[0001069202-25-000048:mdna:28]
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |  |
| Foreign currency exchange (gains) losses | $ | (3.2) |  |  | $ | 1.6 |  |  |  |  |  |  |  |
| Loss (gain) on disposal of fixed assets | 0.4 |  |  | (0.7) |  |  |  |  |  |  |  |
| Other operating income | — |  |  | (0.5) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | — |  |  | 0.1 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 2.1 |  |  | 2.6 |  |  |  |  |  |  |  |
| (Gains) losses and other expenses, net (pre-tax) | $ | (0.7) |  |  | $ | 3.1 |  |  |  |  |  |  |  |

[0001069202-25-000048:mdna:29]
[same as prior period, unchanged from 0001069202-25-000032:mdna:31]

[0001069202-25-000048:mdna:30]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments was $2 million in the third quarter of 2025, consistent with 2024.

[0001069202-25-000048:mdna:31]
[same as prior period, unchanged from 0001069202-25-000032:mdna:33]

[0001069202-25-000048:mdna:32]
Interest expense, net increased to $10 million in the third quarter of 2025 from $9 million in the same period in 2024 primarily due to increased borrowings on our commercial paper facility partially offset by the decrease in interest associated with the senior unsecured notes that were repaid on August 1, 2025.

[0001069202-25-000048:mdna:33]
[same as prior period, unchanged from 0001069202-25-000032:mdna:35]

[0001069202-25-000048:mdna:34]
Our effective tax rate was 17.7% for the third quarter of 2025 as compared to 18.7% in the same period in 2024.  The decrease in rate is primarily due to higher income in low tax jurisdictions.

[0001069202-25-000048:mdna:35]
Third Quarter of 2025 Compared to Third Quarter of 2024 - Results by Segment

[0001069202-25-000048:mdna:36]
[same as prior period, unchanged from 0001069202-25-000032:mdna:38]

[0001069202-25-000048:mdna:37]
The following table presents our Home Comfort Solutions segment's net sales and profit for the third quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000048:mdna:38]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 912.9 |  |  | $ | 1,032.8 |  |  | $ | (119.9) |  |  | (12) | % |
| Profit | $ | 202.9 |  |  | $ | 226.5 |  |  | $ | (23.6) |  |  | (10) | % |
| % of net sales | 22.2 | % |  | 21.9 | % |  |  |  |  |

[0001069202-25-000048:mdna:39]
Net sales decreased 12% in the third quarter of 2025 as compared to the same period in 2024 primarily due to a 23% decrease in sales volumes, which was partially offset by a 11% increase in mix and pricing.

[0001069202-25-000048:mdna:40]
Segment profit in the third quarter of 2025 decreased $24 million as compared to the same period in 2024, primarily due to an $86 million reduction in sales volumes, $26 million in higher product costs largely driven by inflationary pressures including tariffs, and $17 million in higher freight and distribution expenses. These impacts were partially offset by an $85 million benefit from favorable mix and pricing, a $15 million reduction in commission and other SG&A costs, and $5 million in miscellaneous cost savings.

[0001069202-25-000048:mdna:41]
[same as prior period, unchanged from 0001069202-25-000032:mdna:44]

[0001069202-25-000048:mdna:42]
The following table presents our Building Climate Solutions segment's net sales and profit for the third quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000048:mdna:43]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 513.9 |  |  | $ | 465.3 |  |  | $ | 48.6 |  |  | 10 | % |
| Profit | $ | 134.0 |  |  | $ | 105.9 |  |  | $ | 28.1 |  |  | 27 | % |
| % of net sales | 26.1 | % |  | 22.8 | % |  |  |  |  |

[0001069202-25-000048:mdna:44]
Net sales increased 10% in the third quarter of 2025 as compared to the same period in 2024 primarily due to a 10% increase in mix and price.

[0001069202-25-000048:mdna:45]
Segment profit in the third quarter of 2025 increased $28 million as compared to the same period in 2024 primarily due to $33 million in favorable mix and pricing and a $1 million increase in sales volumes, which were partially offset by $4 million in higher product costs, primarily related to inflationary pressures, including tariffs, and $2 million from investments in distribution and selling as well as other inflationary pressures.

[0001069202-25-000048:mdna:46]
[same as prior period, unchanged from 0001069202-25-000032:mdna:49]

[0001069202-25-000048:mdna:47]
The following table presents our Corporate and Other segment's net sales and loss for the third quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000048:mdna:48]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | — | % |
| Loss | $ | (26.7) |  |  | $ | (29.1) |  |  | $ | 2.4 |  |  | 8 | % |

[0001069202-25-000048:mdna:49]
Segment loss decreased $2 million to $27 million in the third quarter of 2025 as compared to the same period in 2024 primarily due to lower incentive compensation related costs.

[0001069202-25-000048:mdna:50]
Year-to-Date through September 30, 2025 Compared to Year-to-Date through September 30, 2024 - Consolidated Results

[0001069202-25-000048:mdna:51]
[same as prior period, unchanged from 0001069202-25-000032:mdna:54]

[0001069202-25-000048:mdna:52]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 4,000.3 |  |  | $ | 3,996.3 |  |  | 0.1 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 2,680.7 |  |  | 2,679.7 |  |  | — |  |  | 67.0 |  |  | 67.1 |  |
| Gross profit | 1,319.6 |  |  | 1,316.6 |  |  | 0.2 |  |  | 33.0 |  |  | 32.9 |  |
| Selling, general and administrative expenses | 506.2 |  |  | 523.6 |  |  | 3.3 |  |  | 12.7 |  |  | 13.1 |  |
| (Gains) losses and other expenses, net | (0.6) |  |  | 10.5 |  |  | 105.7 |  |  | — |  |  | 0.3 |  |
| Gain on sale from previous dispositions | — |  |  | (1.6) |  |  | 100.0 |  |  | — |  |  | — |  |
| Income from equity method investments | (5.8) |  |  | (6.1) |  |  | (4.9) |  |  | (0.1) |  |  | (0.2) |  |
| Operating income | $ | 819.8 |  |  | $ | 790.2 |  |  | 3.7 | % |  | 20.5 | % |  | 19.8 | % |

[0001069202-25-000048:mdna:53]
[same as prior period, unchanged from 0001069202-25-000032:mdna:56]

[0001069202-25-000048:mdna:54]
Net sales remained relatively flat for the nine months ended September 30, 2025 as compared to the same period in 2024, as a 9% increase in mix and pricing was offset by a 9% decrease in sales volumes.

[0001069202-25-000048:mdna:55]
[same as prior period, unchanged from 0001069202-25-000032:mdna:58]

[0001069202-25-000048:mdna:56]
Gross profit margins for the nine months ended September 30, 2025 increased 10 bps to 33.0% as compared to 32.9% in the same period in 2024. Gross margins increased 310 bps from favorable mix and pricing, which were partially offset by 180 bps from higher product costs, primarily related to inflationary pressures, including tariffs, and 120 bps from higher freight and distribution costs.

[0001069202-25-000048:mdna:57]
[same as prior period, unchanged from 0001069202-25-000032:mdna:60]

[0001069202-25-000048:mdna:58]
SG&A decreased $17 million to $506 million for the nine months ended September 30, 2025 as compared to $524 million in the same period in 2024 primarily due to lower incentive compensation related costs. As a percentage of net sales, SG&A decreased 40 bps to 12.7% from 13.1%.

[0001069202-25-000048:mdna:59]
(Gains) losses and Other Expenses, Net

[0001069202-25-000048:mdna:60]
(Gains) losses and other expenses, net for the nine months ended September 30, 2025 and 2024 included the following (in millions):

[0001069202-25-000048:mdna:61]
|  | For the Nine Months Ended September 30, |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |  |
| Foreign currency exchange (gains) losses | $ | (6.6) |  |  | $ | 4.4 |  |  |  |  |  |  |  |
| Loss (gain) on disposal of fixed assets | 0.1 |  |  | (1.7) |  |  |  |  |  |  |  |
| Other operating (income) loss | (0.2) |  |  | 0.4 |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | — |  |  | 0.1 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 6.1 |  |  | 7.3 |  |  |  |  |  |  |  |
| (Gains) losses and other expenses, net (pre-tax) | $ | (0.6) |  |  | $ | 10.5 |  |  |  |  |  |  |  |

[0001069202-25-000048:mdna:62]
[same as prior period, unchanged from 0001069202-25-000032:mdna:65]

[0001069202-25-000048:mdna:63]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments remained flat at $6 million for the nine months ended September 30, 2025 as compared to the same period in 2024.

[0001069202-25-000048:mdna:64]
[same as prior period, unchanged from 0001069202-25-000032:mdna:67]

[0001069202-25-000048:mdna:65]
Interest expense, net decreased $8 million for the nine months ended September 30, 2025 to $25 million as compared to $33 million in the same period in 2024 primarily due to a decrease in interest associated with the senior unsecured notes that were repaid on August 1, 2025 and increased interest earned on investment accounts, which were partially offset by increased borrowings on our commercial paper facility.

[0001069202-25-000048:mdna:66]
[same as prior period, unchanged from 0001069202-25-000032:mdna:69]

[0001069202-25-000048:mdna:67]
Our effective tax rate was 18.7% for the nine months ended September 30, 2025 as compared to 19.3% in the same period in 2024. The decrease in rate was primarily due to higher income in low tax jurisdictions.

[0001069202-25-000048:mdna:68]
Year-to-Date through September 30, 2025 Compared to Year-to-Date through September 30, 2024 - Results by Segment

[0001069202-25-000048:mdna:69]
[same as prior period, unchanged from 0001069202-25-000032:mdna:72]

[0001069202-25-000048:mdna:70]
The following table presents our Home Comfort Solutions segment's net sales and profit for the nine months ended September 30, 2025 and 2024 (dollars in millions):

[0001069202-25-000048:mdna:71]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 2,643.6 |  |  | $ | 2,689.7 |  |  | $ | (46.1) |  |  | (2) | % |
| Profit | $ | 574.9 |  |  | $ | 567.1 |  |  | $ | 7.8 |  |  | 1 | % |
| % of net sales | 21.7 | % |  | 21.1 | % |  |  |  |  |

[0001069202-25-000048:mdna:72]
Net sales decreased 2% for the nine months ended September 30, 2025 as compared to the same period in 2024 primarily due to a 12% decrease in sales volumes, which was partially offset by a 10% increase in mix and pricing.

[0001069202-25-000048:mdna:73]
Segment profit for the first nine months of 2025 increased by $8 million as compared to the same period in 2024, primarily driven by a $200 million benefit from favorable mix and pricing, $16 million from factory efficiencies, a $12 million reduction in SG&A expenses, and $10 million in lower miscellaneous costs. These gains were partially offset by a $122 million decline in sales volumes, $67 million in higher product costs largely attributable to inflationary pressures including tariffs, and a $41 million increase in freight and distribution expenses.

[0001069202-25-000048:mdna:74]
[same as prior period, unchanged from 0001069202-25-000032:mdna:77]

[0001069202-25-000048:mdna:75]
The following table presents our Building Climate Solutions segment's net sales and profit for the nine months ended September 30, 2025 and 2024 (dollars in millions):

[0001069202-25-000048:mdna:76]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 1,356.7 |  |  | $ | 1,306.6 |  |  | $ | 50.1 |  |  | 4 | % |
| Profit | $ | 310.0 |  |  | $ | 298.1 |  |  | $ | 11.9 |  |  | 4 | % |
| % of net sales | 22.8 | % |  | 22.8 | % |  |  |  |  |

[0001069202-25-000048:mdna:77]
Net sales increased 4% for the nine months ended September 30, 2025 as compared to the same period in 2024 primarily due to a 8% increase in mix and pricing, which was partially offset by a 4% decrease in sales volumes.

[0001069202-25-000048:mdna:78]
Segment profit for the first nine months of 2025 increased $12 million as compared to the same period in 2024 primarily due to $73 million from favorable mix and pricing, $5 million from factory efficiencies, and $1 million in lower miscellaneous costs, which were partially offset by $28 million from higher product costs, primarily related to inflationary pressures, including tariffs, $18 million from decreased sales volumes, $12 million in higher SG&A costs, and $9 million from investments in distribution and selling as well as other inflationary pressures.

[0001069202-25-000048:mdna:79]
[same as prior period, unchanged from 0001069202-25-000032:mdna:82]

[0001069202-25-000048:mdna:80]
The following table presents our Corporate and Other segment's net sales and loss for the nine months ended September 30, 2025 and 2024 (dollars in millions):

[0001069202-25-000048:mdna:81]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | — | % |
| Loss | $ | (65.1) |  |  | $ | (76.6) |  |  | $ | 11.5 |  |  | 15 | % |

[0001069202-25-000048:mdna:82]
Segment loss decreased $11 million for the nine months ended September 30, 2025 as compared to the same period in 2024 primarily due to lower incentive compensation related costs.

[0001069202-25-000048:mdna:83]
[same as prior period, unchanged from 0001069202-25-000032:mdna:86]

[0001069202-25-000048:mdna:84]
[same as prior period, unchanged from 0001069202-25-000032:mdna:87]

[0001069202-25-000048:mdna:85]
[same as prior period, unchanged from 0001069202-25-000032:mdna:88]

[0001069202-25-000048:mdna:86]
The following table summarizes our cash flow activity for the nine months ended September 30, 2025 and 2024 (in millions):

[0001069202-25-000048:mdna:87]
|  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |
| Net cash provided by operating activities | $ | 351.7 |  |  | $ | 613.3 |  |
| Net cash used in investing activities | (87.6) |  |  | (108.1) |  |
| Net cash used in financing activities | (627.4) |  |  | (327.4) |  |

[0001069202-25-000048:mdna:88]
Net Cash Provided By Operating Activities - The change in net cash provided by operating activities for the nine months ended September 30, 2025 compared to the net cash provided by operating activities for the same period in 2024 primarily reflects less favorable changes in working capital.

[0001069202-25-000048:mdna:89]
Net Cash Used In Investing Activities - Capital expenditures were $90 million for the nine months ended September 30, 2025 compared to $103 million in the same period of 2024.  The reduction in capital expenditures was primarily driven by the general expansion of manufacturing capacity and equipment of the Commercial factory in Mexico that was completed in 2024.

[0001069202-25-000048:mdna:90]
Net Cash Used In Financing Activities - Net cash used in financing activities for the nine months ended September 30, 2025 increased to $627 million as compared to $327 million provided by in the same period of 2024.  The change was primarily due to changes in net borrowings and repayments of long-term debt and repurchase of common stock through our share repurchase program.  We repurchased $332.3 million of shares for the nine months ended September 30, 2025 and returned $127 million to shareholders through dividend payments.

[0001069202-25-000048:mdna:91]
27

[0001069202-25-000048:mdna:92]
[same as prior period, unchanged from 0001069202-25-000032:mdna:94]

[0001069202-25-000048:mdna:93]
The following table details our lines of credit and financing arrangements as of September 30, 2025 (in millions):

[0001069202-25-000048:mdna:94]
|  | Outstanding Borrowings |
| Commercial paper: | $ | 157.0 |  |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 16.9 |  |
| Total current maturities of long-term debt | $ | 16.9 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 44.7 |  |
| Senior unsecured notes | 800.0 |  |
| Debt issuance costs | (6.5) |  |
| Total long-term debt | $ | 838.2 |  |
| Total debt | $ | 1,012.1 |  |

[0001069202-25-000048:mdna:95]
[same as prior period, unchanged from 0001069202-25-000032:mdna:97]

[0001069202-25-000048:mdna:96]
On October 25, 2023, we established a commercial paper program (the "Program"), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the "CP Notes") under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There are $157.0 million CP Notes outstanding under the Program as of September 30, 2025.

[0001069202-25-000048:mdna:97]
[same as prior period, unchanged from 0001069202-25-000032:mdna:99]

[0001069202-25-000048:mdna:98]
On May 9, 2025, we entered into an Amendment and Restatement Agreement ("Amended Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Amended Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Amended Credit Agreement. The Amended Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of September 30, 2025. Subject to covenant limitations, $841.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Amended Credit Agreement is reduced by borrowings under the Program. The Amended Credit Agreement includes a subfacility for swingline loans up to  $65.0 million. Maturity of the Amended Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Amended Credit Agreement.

[0001069202-25-000048:mdna:99]
[same as prior period, unchanged from 0001069202-25-000032:mdna:101]

[0001069202-25-000048:mdna:100]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%. In July 2020, we issued $300.0 million of senior unsecured notes, which will mature on August 1, 2027 (the "2027 Notes," and collectively with the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.70% per annum. On August 1, 2025, we repaid upon maturity $300.0 million of senior unsecured notes originally issued in 2020.

[0001069202-25-000048:mdna:101]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Amended Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our

[0001069202-25-000048:mdna:102]
ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.

[0001069202-25-000048:mdna:103]
[same as prior period, unchanged from 0001069202-25-000032:mdna:105]

[0001069202-25-000048:mdna:104]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 49% at September 30, 2025, as compared to 57% at December 31, 2024.

[0001069202-25-000048:mdna:105]
As of September 30, 2025, our senior credit ratings were Baa1 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-25-000048:mdna:106]
[same as prior period, unchanged from 0001069202-25-000032:mdna:108]

[0001069202-25-000048:mdna:107]
We believe our cash and cash equivalents of $52.9 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends, and other needs in the foreseeable future. In October 2025, we acquired Duro Dyne Buyer, Inc. and Sealed Unit Parts Buyer, Inc. for approximately $546.3 million and borrowed $300 million under a new term loan.  For more information, see Note 13 in the Notes to the Consolidated Financial Statements. Included in our cash and cash equivalents of $52.9 million as of September 30, 2025 was $31.1 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-25-000048:mdna:108]
Guarantees Related to Our Debt Obligations

[0001069202-25-000048:mdna:109]
Our senior unsecured notes were issued by Lennox International Inc. ("Parent") and are unconditionally guaranteed by the Guarantor Subsidiaries (and together with Lennox International Inc., the “Obligor Group”).  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001069202-25-000048:mdna:110]
Summarized financial information is presented below for the Obligor Group on a combined basis after elimination of intercompany transactions and balances within the Obligor Group and equity in the earnings from and investments in any non-Guarantor Subsidiary. The revenue amounts presented in the summarized financial information include substantially all of our condensed consolidated revenue, and there is no intercompany revenue from the non-Guarantor Subsidiaries. This summarized financial information has been prepared and presented pursuant to Regulation S-X Rule 13-01, “Financial Disclosures about Guarantors and Issuers of Guaranteed Securities” and is not intended to present the financial position or results of operations of the Obligor Group in accordance with U.S. GAAP.

[0001069202-25-000048:mdna:111]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of September 30, 2025 and December 31, 2024 and for the nine months ended September 30, 2025 (in millions):

[0001069202-25-000048:mdna:112]
|  | September 30, 2025 |  | December 31, 2024 |
| Current assets | $ | 1,666.7 |  |  | $ | 1,713.9 |  |
| Non-current assets(1) | 1,278.7 |  |  | 1,241.3 |  |
| Current liabilities | 905.7 |  |  | 1,084.9 |  |
| Non-current liabilities | 1,286.5 |  |  | 1,266.8 |  |
| Amounts due to non-Guarantor Subsidiaries | (369.3) |  |  | (536.8) |  |
|  | Nine months ended September 30, 2025 |  | For the Year Ended December 31, 2024 |
| Net sales | $ | 3,947.6 |  |  | $ | 5,265.6 |  |
| Gross profit | 1,058.4 |  |  | 1,363.9 |  |
| Net income(1) | 377.7 |  |  | 732.9 |  |

[0001069202-25-000048:mdna:113]
(1) Updates previously disclosed amounts to reflect elimination of intercompany assets and net income.

[0001069202-25-000048:mdna:114]
[same as prior period, unchanged from 0001069202-25-000032:mdna:110]

[0001069202-25-000048:mdna:115]
[same as prior period, unchanged from 0001069202-25-000032:mdna:111]

[0001069202-25-000048:mdna:116]
Commitments, Contingencies, and Guarantees

[0001069202-25-000048:mdna:117]
For information regarding our commitments, contingencies, and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-25-000048:mdna:118]
[same as prior period, unchanged from 0001069202-25-000032:mdna:114]

[0001069202-25-000048:mdna:119]
[same as prior period, unchanged from 0001069202-25-000032:mdna:115]
