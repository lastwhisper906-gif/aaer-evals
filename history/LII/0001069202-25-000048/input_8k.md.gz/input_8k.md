# LII 8-K — 0001069202-25-000046 filed 2025-10-22

## item codes, every 8-K on or before 2025-10-22

- 2025-10-22 0001069202-25-000046 — 2.02, 9.01
- 2025-07-23 0001069202-25-000029 — 2.02, 9.01
- 2025-05-27 0001069202-25-000024 — 5.02, 5.07, 9.01
- 2025-05-14 0001069202-25-000022 — 1.01, 2.03, 9.01
- 2025-04-23 0001069202-25-000015 — 2.02, 9.01
- 2025-03-13 0001069202-25-000005 — 4.01, 9.01
- 2025-01-29 0001628280-25-002910 — 2.02, 9.01
- 2024-12-06 0001628280-24-050201 — 5.02
- 2024-10-23 0001628280-24-043349 — 2.02, 5.02, 7.01, 9.01
- 2024-07-24 0001628280-24-032683 — 2.02, 9.01
- 2024-05-23 0001628280-24-024875 — 5.02, 9.01
- 2024-05-20 0001628280-24-024385 — 5.07
- 2024-04-24 0001628280-24-017515 — 2.02, 9.01
- 2024-03-18 0001628280-24-011594 — 5.02, 9.01
- 2024-01-31 0001628280-24-002634 — 2.02, 9.01
- 2023-12-11 0001628280-23-041239 — 5.02, 9.01 — amendment of 0001628280-23-035187
- 2023-12-08 0001628280-23-041128 — 5.02
- 2023-10-26 0001628280-23-035187 — 2.02, 5.02, 7.01, 9.01
- 2023-09-21 0001628280-23-032729 — 8.01, 9.01
- 2023-09-15 0001628280-23-032385 — 1.01, 2.03, 8.01, 9.01
- 2023-09-12 0001628280-23-032078 — 8.01, 9.01
- 2023-08-28 0001628280-23-030777 — 1.01, 2.03, 9.01
- 2023-08-25 0001628280-23-030602 — 8.01, 9.01
- 2023-07-27 0001628280-23-025808 — 2.02, 9.01
- 2023-05-19 0001628280-23-019040 — 5.07
- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2025-10-22

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-25-000046:8k_2_02:1]
EX-99.1
2
lii-2025930xexx991pressrel.htm
EX-99.1

[0001069202-25-000046:8k_2_02:2]
Document

[0001069202-25-000046:8k_2_02:3]
Exhibit 99.1

[0001069202-25-000046:8k_2_02:4]
Lennox Reports Third Quarter Results

[0001069202-25-000046:8k_2_02:5]
____________________________________________________________________________

[0001069202-25-000046:8k_2_02:6]
Q3 Highlights

[0001069202-25-000046:8k_2_02:7]
(All comparisons are year-over-year, unless otherwise noted)

[0001069202-25-000046:8k_2_02:8]
•Revenue $1.4 billion, down 5%

[0001069202-25-000046:8k_2_02:9]
•GAAP Operating Income $310 million  –  Segment profit up 2% to $310 million

[0001069202-25-000046:8k_2_02:10]
•GAAP diluted EPS $6.98  –  Adjusted diluted EPS up 4% to $6.98

[0001069202-25-000046:8k_2_02:11]
•FY 25 guidance updated–  Revenue down ~1% and revised adjusted EPS range of $22.75 to $23.25

[0001069202-25-000046:8k_2_02:12]
____________________________________________________________________________

[0001069202-25-000046:8k_2_02:13]
DALLAS, October 22, 2025 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported third quarter financial results with $1.4 billion of revenue, $310 million of operating income, and $6.98 GAAP diluted earnings per share.

[0001069202-25-000046:8k_2_02:14]
Revenue declined 5% to $1.4 billion. Segment profit increased 2% to $310 million. Segment margin was up 150 basis points to 21.7%. Adjusted diluted earnings per share increased 4% to $6.98.

[0001069202-25-000046:8k_2_02:15]
“As anticipated, 2025 is proving to be a transitional year, shaped by the impact of the refrigerant transition and difficult macroeconomic conditions. During these uncertain times, the Lennox team continues to respond with agility and discipline, delivering margin expansion in both segments,” said CEO, Alok Maskara. “The recent DuroDyne and Supco acquisition strengthens our parts and accessories portfolio, positioning us for greater success during the more normalized operating environment expected in 2026 and beyond. In light of ongoing industry volume pressures and consumer confidence trends, we believe it is prudent to update our full-year guidance to include an expected revenue decline of 1% and adjusted earnings per share from $22.75 to $23.25.”

[0001069202-25-000046:8k_2_02:16]
The Home Comfort Solutions segment revenue declined 12% in the third quarter, reflecting elevated channel destocking and a weak summer selling season. Recent regulatory transition and ongoing macroeconomic uncertainty continues to weigh on consumer and dealer sentiment, contributing to the shift toward repair over replacement. Despite these headwinds, segment profit margins expanded by 30 basis points, as cost reduction initiatives and favorable mix/price offset the impact of lower volumes and cost inflation.

[0001069202-25-000046:8k_2_02:17]
The Building Climate Solutions segment delivered 10% revenue growth in the third quarter, despite ongoing weakness in the light commercial industry, as higher manufacturing output and lower lead times supported emergency replacement demand. The segment also delivered double-digit revenue growth in commercial services and Heatcraft as investments in sales excellence started to generate results. Segment margins expanded by 330 basis points, as favorable mix, cost control initiatives, and pricing offset inflation. Margin improvements were also supported by increased factory efficiencies as production at our new Saltillo facility continued to scale.

[0001069202-25-000046:8k_2_02:18]
THIRD QUARTER 2025 FINANCIAL HIGHLIGHTS

[0001069202-25-000046:8k_2_02:19]
(All comparisons are year-over-year, unless otherwise noted)

[0001069202-25-000046:8k_2_02:20]
Revenue: $1.4 billion was down 5% driven by unfavorable sales volumes.

[0001069202-25-000046:8k_2_02:21]
Operating Income: $310 million, up 2%, with operating profit margin of 21.7%, up 150 basis points.

[0001069202-25-000046:8k_2_02:22]
Segment Profit: $310 million, up 2%, and segment profit margin of 21.7%, up 150 basis points. Profit improvement can be attributed to $118 million of mix/price benefits, driven primarily by new product mix, and a $4 million

[0001069202-25-000046:8k_2_02:23]
improvement of other costs, including selling expense net of freight and distribution expense. This was partially offset by $85 million decrease in sales volumes; and $30 million of product cost primarily related to recent inflationary impacts.

[0001069202-25-000046:8k_2_02:24]
Net Income: $246 million, or $6.98 per share, compared to $239 million, or $6.68 per share, in the prior-year quarter.

[0001069202-25-000046:8k_2_02:25]
Adjusted Net Income: $246 million, or $6.98 per share, compared to $239 million, or $6.68 per share, in the prior-year quarter.

[0001069202-25-000046:8k_2_02:26]
Cash Flow: Operating cash flow was $301 million compared to $452 million in the prior-year quarter as finished goods inventory levels are temporarily elevated. Net capital expenditures were $35 million compared to $40 million in the prior-year quarter. This quarter $37 million of shares were repurchased.

[0001069202-25-000046:8k_2_02:27]
Home Comfort Solutions: Business segment revenue was $913 million, down 12%. Segment profit was $203 million, down 10%, and segment margin was 22.2%, up 30 basis points. Segment profit decreased $24 million compared to the prior-year quarter. The decline was driven by a $86 million contraction in sales volumes and $26 million in product cost inflation net of factory productivity. This was partially offset by $85 million in mix/price benefits and $3 million improvement of other costs, including selling expense net of freight and distribution expense.

[0001069202-25-000046:8k_2_02:28]
Building Climate Solutions: Business segment revenue was $514 million, up 10%. Segment profit was $134 million, up $28 million or 27%, and segment margin improved 330 basis points to 26.1%. This increase was driven by $33 million in mix/price benefits and $1 million increase in sales volumes. This was partially offset by $4 million of product cost inflation net of factory productivity, and $2 million from investment in distribution and selling as well as other inflationary impacts.

[0001069202-25-000046:8k_2_02:29]
Corporate and Other: Corporate expenses were $27 million, down $2 million from the prior-year quarter.

[0001069202-25-000046:8k_2_02:30]
FULL YEAR 2025 GUIDANCE

[0001069202-25-000046:8k_2_02:31]
For full year 2025, adjusted earnings per share is now expected to be within the range of $22.75 to $23.25.

[0001069202-25-000046:8k_2_02:32]
Revenue is now anticipated to decrease by approximately 1%. We continue to expect pricing to offset the inflationary pressures.

[0001069202-25-000046:8k_2_02:33]
Free cash flow guidance is now approximately $550 million, driven by temporarily elevated inventory levels.

[0001069202-25-000046:8k_2_02:34]
CONFERENCE CALL INFORMATION

[0001069202-25-000046:8k_2_02:35]
A conference call to discuss the company’s third quarter results will be held this morning at 8:30 a.m. Central Time. To participate in the earnings conference, please call 800-267-6316 (U.S.) or +1 203-518-9783 (international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ325. The conference call also will be webcast live on the company’s investor relations web site at investor.lennox.com. A replay of the conference call will be available until October 29, 2025, by calling toll-free 800-839-0866 (U.S.) or +1 402-220-0662 (international). The call will also be archived on the company's investor relations website at investor.lennox.com.

[0001069202-25-000046:8k_2_02:36]
ABOUT LENNOX

[0001069202-25-000046:8k_2_02:37]
Lennox (NYSE: LII) is a leader in energy-efficient climate-control solutions. We are committed to sustainability and creating comfortable, healthier environments for residential and commercial customers. Our innovative portfolio includes cooling, heating, indoor air quality, and refrigeration systems, along with a comprehensive range of HVAC parts, supplies, and services that support the full lifecycle of customer needs. Additional information on Lennox is available at Lennox.com or by contacting investor@lennox.com.

[0001069202-25-000046:8k_2_02:38]
FORWARD-LOOKING STATEMENTS & NON-GAAP FINANCIAL MEASURES

[0001069202-25-000046:8k_2_02:39]
For information concerning these and other risks and uncertainties, see LII’s publicly available filings with the Securities and Exchange Commission. LII disclaims any intention or obligation to update or revise any forward-looking statements, whether as a result of new information, future events or otherwise, except as required by law.

[0001069202-25-000046:8k_2_02:40]
A reconciliation of non-GAAP financial measures appearing in this document to financial measures prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP) are included in the Annex to this document.

[0001069202-25-000046:8k_2_02:41]
This document includes forward-looking statements regarding segment profit, adjusted net income, adjusted diluted earnings per share, and free cash flow, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, changes in environmental liabilities, the impact

[0001069202-25-000046:8k_2_02:42]
and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on LII’s full year GAAP financial results.

[0001069202-25-000046:8k_2_02:43]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-25-000046:8k_2_02:44]
Consolidated Statements of Operations

[0001069202-25-000046:8k_2_02:45]
(Unaudited)

[0001069202-25-000046:8k_2_02:46]
| (Amounts in millions, except per share data) | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 1,426.8 |  |  | $ | 1,498.1 |  |  | $ | 4,000.3 |  |  | $ | 3,996.3 |  |
| Cost of goods sold | 958.2 |  |  | 1,009.7 |  |  | 2,680.7 |  |  | 2,679.7 |  |
| Gross profit | 468.6 |  |  | 488.4 |  |  | 1,319.6 |  |  | 1,316.6 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 161.6 |  |  | 184.4 |  |  | 506.2 |  |  | 523.6 |  |
| (Gains) losses and other expenses, net | (0.7) |  |  | 3.1 |  |  | (0.6) |  |  | 10.5 |  |
| Gain on sale from previous dispositions | — |  |  | — |  |  | — |  |  | (1.6) |  |
| Income from equity method investments | (2.5) |  |  | (2.4) |  |  | (5.8) |  |  | (6.1) |  |
| Operating income | 310.2 |  |  | 303.3 |  |  | 819.8 |  |  | 790.2 |  |
| Pension settlements | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.4 |  |
| Interest expense, net | 10.5 |  |  | 8.9 |  |  | 25.0 |  |  | 33.2 |  |
| Other expense, net | 0.8 |  |  | 0.4 |  |  | 2.3 |  |  | 1.5 |  |
| Net income before income taxes | 298.8 |  |  | 293.9 |  |  | 792.2 |  |  | 755.1 |  |
| Provision for income taxes | 53.0 |  |  | 54.9 |  |  | 148.5 |  |  | 145.9 |  |
| Net income | $ | 245.8 |  |  | $ | 239.0 |  |  | $ | 643.7 |  |  | $ | 609.2 |  |
| Earnings per share – Basic(1): | $ | 7.01 |  |  | $ | 6.71 |  |  | $ | 18.23 |  |  | $ | 17.11 |  |
| Earnings per share – Diluted(1): | $ | 6.98 |  |  | $ | 6.68 |  |  | $ | 18.15 |  |  | $ | 17.02 |  |
| Weighted Average Number of Shares Outstanding - Basic | 35.1 |  |  | 35.6 |  |  | 35.3 |  |  | 35.6 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 35.2 |  |  | 35.8 |  |  | 35.5 |  |  | 35.8 |  |

[0001069202-25-000046:8k_2_02:47]
(1)  Amounts may not recalculate due to rounding.

[0001069202-25-000046:8k_2_02:48]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |
| Segment Net Sales and Profit (Loss) |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |

[0001069202-25-000046:8k_2_02:49]
| (Amounts in millions) | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net Sales |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 912.9 |  |  | $ | 1,032.8 |  |  | $ | 2,643.6 |  |  | $ | 2,689.7 |  |
| Building Climate Solutions | 513.9 |  |  | 465.3 |  |  | 1,356.7 |  |  | 1,306.6 |  |
| Corporate and other | — |  |  | — |  |  | — |  |  | — |  |
| Total net sales | $ | 1,426.8 |  |  | $ | 1,498.1 |  |  | $ | 4,000.3 |  |  | $ | 3,996.3 |  |
| Segment Profit (Loss)(1) |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 202.9 |  |  | $ | 226.5 |  |  | $ | 574.9 |  |  | $ | 567.1 |  |
| Building Climate Solutions | 134.0 |  |  | 105.9 |  |  | 310.0 |  |  | 298.1 |  |
| Corporate and other | (26.7) |  |  | (29.1) |  |  | (65.1) |  |  | (76.6) |  |
| Total segment profit | 310.2 |  |  | 303.3 |  |  | 819.8 |  |  | 788.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Restructuring charges | — |  |  | — |  |  | — |  |  | — |  |
| Loss (gain) on sale from previous dispositions | — |  |  | — |  |  | — |  |  | (1.6) |  |
| Operating income | $ | 310.2 |  |  | $ | 303.3 |  |  | $ | 819.8 |  |  | $ | 790.2 |  |

[0001069202-25-000046:8k_2_02:50]
(1) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-25-000046:8k_2_02:51]
•Restructuring charges, and;

[0001069202-25-000046:8k_2_02:52]
•Loss (gain) on sale of previous dispositions

[0001069202-25-000046:8k_2_02:53]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-25-000046:8k_2_02:54]
Consolidated Balance Sheets

[0001069202-25-000046:8k_2_02:55]
| (Amounts in millions, except shares and par values) | As of September 30, 2025 |  | As of December 31, 2024 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 52.9 |  |  | $ | 415.1 |  |
| Short-term investments | 6.3 |  |  | 7.2 |  |
| Accounts and notes receivable, net of allowances of $8.7 and $17.8 in 2025 and 2024, respectively | 758.6 |  |  | 661.1 |  |
| Inventories, net | 991.5 |  |  | 704.8 |  |
| Other current assets | 88.7 |  |  | 96.0 |  |
| Total current assets | 1,898.0 |  |  | 1,884.2 |  |
| Property, plant and equipment, net of accumulated depreciation of $1,022.3 and $956.8 in 2025 and 2024, respectively | 847.5 |  |  | 800.1 |  |
| Right-of-use assets from operating leases | 339.0 |  |  | 327.2 |  |
| Goodwill | 220.0 |  |  | 220.0 |  |
| Deferred income taxes | 49.3 |  |  | 75.1 |  |
| Other assets, net | 170.8 |  |  | 165.2 |  |
| Total assets | $ | 3,524.6 |  |  | $ | 3,471.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current Liabilities: |  |  |  |
| Accounts payable | $ | 478.2 |  |  | $ | 490.0 |  |
| Accrued expenses | 398.9 |  |  | 435.4 |  |
| Commercial paper | 157.0 |  |  | — |  |
| Current maturities of long-term debt | 16.9 |  |  | 314.5 |  |
| Current operating lease liabilities | 78.8 |  |  | 73.4 |  |
| Total current liabilities | 1,129.8 |  |  | 1,313.3 |  |
| Long-term debt | 838.2 |  |  | 833.1 |  |
| Long-term operating lease liabilities | 279.2 |  |  | 267.6 |  |
| Pensions | 16.0 |  |  | 18.9 |  |
| Other liabilities | 191.3 |  |  | 188.7 |  |
| Total liabilities | 2,454.5 |  |  | 2,621.6 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' equity: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,236.1 |  |  | 1,213.3 |  |
| Retained earnings | 4,662.5 |  |  | 4,150.8 |  |
| Accumulated other comprehensive loss | (62.0) |  |  | (93.7) |  |
| Treasury stock, at cost, 52,096,681 shares and 51,573,986 shares for 2025 and 2024, respectively | (4,767.4) |  |  | (4,421.1) |  |
| Total stockholders' equity | 1,070.1 |  |  | 850.2 |  |
| Total liabilities and stockholders' equity | $ | 3,524.6 |  |  | $ | 3,471.8 |  |

[0001069202-25-000046:8k_2_02:56]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-25-000046:8k_2_02:57]
Consolidated Statements of Cash Flows

[0001069202-25-000046:8k_2_02:58]
(Unaudited)

[0001069202-25-000046:8k_2_02:59]
| (Amounts in millions) | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 643.7 |  |  | $ | 609.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Gain on sale from previous dispositions | — |  |  | (1.6) |  |
| Income from equity method investments | (5.8) |  |  | (6.1) |  |
| Dividends from affiliates | 6.1 |  |  | 2.5 |  |
| Provision for credit (gains) losses | (1.8) |  |  | 4.6 |  |
| Unrealized losses (gains), net on derivative contracts | 2.3 |  |  | (6.7) |  |
| Stock-based compensation expense | 20.8 |  |  | 20.1 |  |
| Employee stock purchase plan discount | 0.4 |  |  | — |  |
| Depreciation and amortization | 79.4 |  |  | 69.6 |  |
| Deferred income taxes | 22.2 |  |  | (21.5) |  |
| Pension expense | 3.2 |  |  | 3.5 |  |
| Pension contributions | (6.1) |  |  | (9.1) |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |
| Accounts and notes receivable | (94.7) |  |  | (229.1) |  |
| Inventories | (284.2) |  |  | 9.1 |  |
| Other current assets | (7.0) |  |  | — |  |
| Accounts payable | (16.7) |  |  | 104.6 |  |
| Accrued expenses | (37.3) |  |  | 31.3 |  |
| Income taxes payable and receivable, net | 27.7 |  |  | 20.4 |  |
| Leases, net | 5.2 |  |  | 3.8 |  |
| Other, net | (5.7) |  |  | 8.7 |  |
| Net cash provided by operating activities | 351.7 |  |  | 613.3 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 1.1 |  |  | 1.9 |  |
| Purchases of property, plant and equipment | (89.6) |  |  | (103.4) |  |
| Net proceeds from previous disposition | — |  |  | 4.1 |  |
| Acquisitions, net of cash | — |  |  | 1.8 |  |
| Proceeds from (purchases of) investments and other | 0.9 |  |  | (12.5) |  |
| Net cash used in investing activities | (87.6) |  |  | (108.1) |  |
| Cash flows from financing activities: |  |  |  |
| Commercial paper borrowings | 677.1 |  |  | 424.1 |  |
| Commercial paper payments | (520.1) |  |  | (574.1) |  |
| Borrowings from debt arrangements | — |  |  | 156.7 |  |
| Payments on debt arrangements | (14.2) |  |  | (190.2) |  |
| Payment of senior unsecured notes | (300.0) |  |  | — |  |
| Payments of deferred financing costs | (1.7) |  |  | — |  |
| Proceeds from employee stock purchases | 4.0 |  |  | 3.3 |  |
| Repurchases of common stock | (331.8) |  |  | (12.9) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (13.3) |  |  | (15.0) |  |
| Cash dividends paid | (127.4) |  |  | (119.3) |  |
| Net cash used in financing activities | (627.4) |  |  | (327.4) |  |
| (Decrease) increase in cash and cash equivalents | (363.3) |  |  | 177.8 |  |
| Effect of exchange rates on cash and cash equivalents | 1.1 |  |  | 4.6 |  |
| Cash and cash equivalents, beginning of period | 415.1 |  |  | 60.7 |  |
| Cash and cash equivalents, end of period | $ | 52.9 |  |  | $ | 243.1 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 39.7 |  |  | $ | 44.7 |  |
| Income taxes paid (net of refunds) | $ | 91.5 |  |  | $ | 145.5 |  |

[0001069202-25-000046:8k_2_02:60]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit (loss) presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company's business trends and operating performance. |
| Reconciliation of Net income, a GAAP measure, to Adjusted net income, a Non-GAAP measure |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |
|  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  |  |
| Net income, a GAAP measure | $ | 245.8 |  | $ | 6.98 |  |  | $ | 239.0 |  | $ | 6.68 |  |  | $ | 643.7 |  | $ | 18.15 |  |  | $ | 609.2 |  | $ | 17.02 |  |  |  |
| Gain on sale from previous dispositions | — |  | — |  |  | — |  | — |  |  | — |  | — |  |  | (1.6) |  | (0.04) |  |  |  |
| Adjusted net income, a non-GAAP measure | $ | 245.8 |  | $ | 6.98 |  |  | $ | 239.0 |  | $ | 6.68 |  |  | $ | 643.7 |  | $ | 18.15 |  |  | $ | 607.6 |  | $ | 16.98 |  |  |  |

[0001069202-25-000046:8k_2_02:61]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net cash provided by operating activities | $ | 300.7 |  |  | $ | 452.1 |  |  | $ | 351.7 |  |  | $ | 613.3 |  |
| Purchases of property, plant and equipment | $ | (35.6) |  |  | (41.2) |  |  | (89.6) |  |  | (103.4) |  |
| Proceeds from the disposal of property, plant and equipment | $ | 0.2 |  |  | 0.8 |  |  | 1.1 |  |  | 1.9 |  |
| Free cash flow, a Non-GAAP measure | $ | 265.3 |  |  | $ | 411.7 |  |  | $ | 263.2 |  |  | $ | 511.8 |  |
