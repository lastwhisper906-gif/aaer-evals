# LII notes — 0001069202-16-000020


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-16-000020:notes:1]
[same as prior period, unchanged from 0001069202-16-000017:notes:1]

[0001069202-16-000020:notes:2]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 220.0 |  |  | 200.0 |  |
| Remaining amount available | $ | — |  |  | $ | 20.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-16-000020:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-16-000020:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-16-000020:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-16-000020:notes:6]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.95 | % |  | 1.90 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-16-000020:notes:7]
[same as prior period, unchanged from 0001069202-16-000017:notes:7]

[0001069202-16-000020:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2016, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2016 and 2015, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six  months ended June 30, 2016 and 2015, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2016 and 2015 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2015. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-16-000020:notes:9]
[same as prior period, unchanged from 0001069202-16-000017:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-16-000020:notes:10]
Commitments and Contingencies:

[0001069202-16-000020:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-16-000020:notes:12]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-16-000020:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000020:notes:14]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Accrued expenses | $ | 29.2 |  |  | $ | 26.7 |  |
| Other liabilities | 69.6 |  |  | 65.6 |  |
| Total warranty liability | $ | 98.8 |  |  | $ | 92.3 |  |

[0001069202-16-000020:notes:15]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2016 were as follows (in millions):

[0001069202-16-000020:notes:16]
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |
| Warranty claims paid | (11.7 | ) |
| Changes resulting from issuance of new warranties | 20.0 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | 0.8 |  |
| Total warranty liability as of June 30, 2016 | $ | 98.8 |  |

[0001069202-16-000020:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a certain supplier quality issue within a range of $2.0 million and $9.4 million with all amounts in that range equally likely.  We have accrued a $2.0 million liability in Accrued expenses on the Consolidated Balance Sheet at June 30, 2016. The supplier is reimbursing the majority of costs related to this liability.

[0001069202-16-000020:notes:18]
Litigation

[0001069202-16-000020:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-16-000020:notes:20]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and is subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2016, and 2015, expense for asbestos-related litigation was $1.9 million, and $0.6 million, net of insurance recoveries, respectively.

[0001069202-16-000020:notes:21]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-16-000020:notes:22]
[same as prior period, unchanged from 0001069202-16-000017:notes:22]

[0001069202-16-000020:notes:23]
[same as prior period, unchanged from 0001069202-16-000017:notes:23]

[0001069202-16-000020:notes:24]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (3.4 | ) |  | $ | (2.8 | ) |  | $ | (8.2 | ) |  | $ | (6.2 | ) |  | Cost of goods sold |
| Income tax benefit |  | 1.2 |  |  | 1.0 |  |  | 2.9 |  |  | 2.3 |  |  | Provision for income taxes |
| Net of tax |  | $ | (2.2 | ) |  | $ | (1.8 | ) |  | $ | (5.3 | ) |  | $ | (3.9 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.4 | ) |  | $ | (2.0 | ) |  | $ | (3.1 | ) |  | $ | (4.2 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.5 |  |  | 0.8 |  |  | 1.0 |  |  | 1.5 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.9 | ) |  | $ | (1.2 | ) |  | $ | (2.1 | ) |  | $ | (2.7 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (3.1 | ) |  | $ | (3.0 | ) |  | $ | (7.4 | ) |  | $ | (6.6 | ) |  |  |

[0001069202-16-000020:notes:25]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2016 (in millions):

[0001069202-16-000020:notes:26]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2015 |  | $ | (8.4 | ) |  | $ | 4.4 |  |  | $ | (139.3 | ) |  | $ | (61.4 | ) |  | $ | (204.7 | ) |
| Other comprehensive (loss) income before reclassifications |  | (0.4 | ) |  | (0.6 | ) |  | (2.7 | ) |  | 14.4 |  |  | 10.7 |  |
| Amounts reclassified from AOCI |  | 5.3 |  |  | — |  |  | 2.1 |  |  | — |  |  | 7.4 |  |
| Net other comprehensive (loss) income |  | 4.9 |  |  | (0.6 | ) |  | (0.6 | ) |  | 14.4 |  |  | 18.1 |  |
| Balance as of June 30, 2016 |  | $ | (3.5 | ) |  | $ | 3.8 |  |  | $ | (139.9 | ) |  | $ | (47.0 | ) |  | $ | (186.6 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-16-000020:notes:27]
[same as prior period, unchanged from 0001069202-16-000017:notes:27]

[0001069202-16-000020:notes:28]
[same as prior period, unchanged from 0001069202-16-000017:notes:28]

[0001069202-16-000020:notes:29]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of June 30, 2016 and December 31, 2015 and for the three and six months ended June 30, 2016 and 2015 are shown on the following pages.

[0001069202-16-000020:notes:30]
Lennox International Inc. and Subsidiaries

[0001069202-16-000020:notes:31]
Condensed Consolidating Balance Sheets

[0001069202-16-000020:notes:32]
As of June 30, 2016

[0001069202-16-000020:notes:33]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.6 |  |  | $ | 24.0 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 54.7 |  |
| Accounts and notes receivable, net | — |  |  | 43.3 |  |  | 600.2 |  |  | — |  |  | 643.5 |  |
| Inventories, net | — |  |  | 392.9 |  |  | 119.5 |  |  | (6.7 | ) |  | 505.7 |  |
| Other assets | 4.3 |  |  | 52.3 |  |  | 70.9 |  |  | (61.2 | ) |  | 66.3 |  |
| Total current assets | 5.9 |  |  | 512.5 |  |  | 819.7 |  |  | (67.9 | ) |  | 1,270.2 |  |
| Property, plant and equipment, net | — |  |  | 266.0 |  |  | 79.2 |  |  | — |  |  | 345.2 |  |
| Goodwill | — |  |  | 134.9 |  |  | 63.6 |  |  | — |  |  | 198.5 |  |
| Investment in subsidiaries | 1,035.8 |  |  | 488.2 |  |  | (0.6 | ) |  | (1,523.4 | ) |  | — |  |
| Deferred income taxes | 5.3 |  |  | 125.5 |  |  | 28.9 |  |  | (14.7 | ) |  | 145.0 |  |
| Other assets, net | 1.8 |  |  | 38.9 |  |  | 26.1 |  |  | (1.5 | ) |  | 65.3 |  |
| Intercompany receivables (payables), net | (156.4 | ) |  | 148.4 |  |  | 8.0 |  |  | — |  |  | — |  |
| Total assets | $ | 892.4 |  |  | $ | 1,714.4 |  |  | $ | 1,024.9 |  |  | $ | (1,607.5 | ) |  | $ | 2,024.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 225.4 |  |  | $ | — |  |  | $ | 225.4 |  |
| Current maturities of long-term debt | 229.8 |  |  | 0.7 |  |  | 0.3 |  |  | — |  |  | 230.8 |  |
| Accounts payable | 18.7 |  |  | 310.0 |  |  | 71.1 |  |  | — |  |  | 399.8 |  |
| Accrued expenses | 8.0 |  |  | 191.9 |  |  | 56.6 |  |  | — |  |  | 256.5 |  |
| Income taxes payable | 0.3 |  |  | 42.7 |  |  | 44.7 |  |  | (77.5 | ) |  | 10.2 |  |
| Total current liabilities | 256.8 |  |  | 545.3 |  |  | 398.1 |  |  | (77.5 | ) |  | 1,122.7 |  |
| Long-term debt | 603.9 |  |  | 14.7 |  |  | 0.4 |  |  | — |  |  | 619.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.9 |  |  | — |  |  | — |  |  | 2.9 |  |
| Pensions | — |  |  | 113.8 |  |  | 8.4 |  |  | — |  |  | 122.2 |  |
| Other liabilities | 0.3 |  |  | 118.7 |  |  | 11.4 |  |  | (4.4 | ) |  | 126.0 |  |
| Total liabilities | 861.0 |  |  | 795.4 |  |  | 418.3 |  |  | (81.9 | ) |  | 1,992.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 31.4 |  |  | 919.0 |  |  | 606.6 |  |  | (1,525.6 | ) |  | 31.4 |  |
| Total liabilities and stockholders' equity | $ | 892.4 |  |  | $ | 1,714.4 |  |  | $ | 1,024.9 |  |  | $ | (1,607.5 | ) |  | $ | 2,024.2 |  |

[0001069202-16-000020:notes:34]
As of December 31, 2015

[0001069202-16-000020:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.5 |  |  | $ | 7.8 |  |  | $ | 30.6 |  |  | $ | — |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net | — |  |  | 25.9 |  |  | 396.9 |  |  | — |  |  | 422.8 |  |
| Inventories, net | — |  |  | 324.3 |  |  | 98.9 |  |  | (4.4 | ) |  | 418.8 |  |
| Other assets | 3.3 |  |  | 46.9 |  |  | 67.4 |  |  | (59.9 | ) |  | 57.7 |  |
| Total current assets | 3.8 |  |  | 404.9 |  |  | 593.8 |  |  | (64.3 | ) |  | 938.2 |  |
| Property, plant and equipment, net | — |  |  | 261.8 |  |  | 77.8 |  |  | — |  |  | 339.6 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 879.0 |  |  | 337.6 |  |  | (0.6 | ) |  | (1,216.0 | ) |  | — |  |
| Deferred income taxes | 5.4 |  |  | 126.6 |  |  | 28.4 |  |  | (14.7 | ) |  | 145.7 |  |
| Other assets, net | 1.5 |  |  | 38.2 |  |  | 20.6 |  |  | (1.5 | ) |  | 58.8 |  |
| Intercompany receivables (payables), net | (278.6 | ) |  | 253.3 |  |  | 25.3 |  |  | — |  |  | — |  |
| Total assets | $ | 611.1 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,677.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 204.1 |  |  | $ | — |  |  | $ | 204.1 |  |
| Current maturities of long-term debt | 29.8 |  |  | 0.8 |  |  | 0.4 |  |  | — |  |  | 31.0 |  |
| Accounts payable | 16.1 |  |  | 237.9 |  |  | 66.1 |  |  | — |  |  | 320.1 |  |
| Accrued expenses | 15.8 |  |  | 176.7 |  |  | 50.1 |  |  | — |  |  | 242.6 |  |
| Income taxes payable | (43.0 | ) |  | 106.6 |  |  | 37.9 |  |  | (75.5 | ) |  | 26.0 |  |
| Total current liabilities | 18.7 |  |  | 522.0 |  |  | 358.6 |  |  | (75.5 | ) |  | 823.8 |  |
| Long-term debt | 490.4 |  |  | 15.1 |  |  | 0.5 |  |  | — |  |  | 506.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.1 |  |  | — |  |  | — |  |  | 4.1 |  |
| Pensions | — |  |  | 111.9 |  |  | 8.9 |  |  | — |  |  | 120.8 |  |
| Other liabilities | 0.4 |  |  | 114.4 |  |  | 10.5 |  |  | (4.2 | ) |  | 121.1 |  |
| Total liabilities | 509.5 |  |  | 767.5 |  |  | 378.5 |  |  | (79.7 | ) |  | 1,575.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 101.6 |  |  | 789.8 |  |  | 427.0 |  |  | (1,216.8 | ) |  | 101.6 |  |
| Total liabilities and stockholders' equity | $ | 611.1 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,677.4 |  |

[0001069202-16-000020:notes:36]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-16-000020:notes:37]
For the Three Months Ended June 30, 2016

[0001069202-16-000020:notes:38]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 884.5 |  |  | $ | 183.4 |  |  | $ | (48.7 | ) |  | $ | 1,019.2 |  |
| Cost of goods sold | — |  |  | 611.7 |  |  | 141.2 |  |  | (48.7 | ) |  | 704.2 |  |
| Gross profit | — |  |  | 272.8 |  |  | 42.2 |  |  | — |  |  | 315.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 139.9 |  |  | 19.5 |  |  | — |  |  | 159.4 |  |
| Losses (gains) and other expenses, net | — |  |  | 0.7 |  |  | (0.2 | ) |  | (0.1 | ) |  | 0.4 |  |
| Restructuring charges | — |  |  | 1.0 |  |  | (0.2 | ) |  | — |  |  | 0.8 |  |
| Income from equity method investments | (115.5 | ) |  | (9.5 | ) |  | (5.2 | ) |  | 123.9 |  |  | (6.3 | ) |
| Operating income | 115.5 |  |  | 140.7 |  |  | 28.3 |  |  | (123.8 | ) |  | 160.7 |  |
| Interest expense, net | 6.3 |  |  | (0.5 | ) |  | 1.0 |  |  | — |  |  | 6.8 |  |
| Other expense, net | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Income from continuing operations before income taxes | 109.2 |  |  | 141.2 |  |  | 27.5 |  |  | (123.8 | ) |  | 154.1 |  |
| Provision for income taxes | (1.5 | ) |  | 34.8 |  |  | 9.5 |  |  | 0.1 |  |  | 42.9 |  |
| Income from continuing operations | 110.7 |  |  | 106.4 |  |  | 18.0 |  |  | (123.9 | ) |  | 111.2 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Net income | $ | 110.7 |  |  | $ | 106.4 |  |  | $ | 17.5 |  |  | $ | (123.9 | ) |  | $ | 110.7 |  |
| Other comprehensive income (loss), net of tax | 0.3 |  |  | 0.3 |  |  | 2.7 |  |  | 0.8 |  |  | 4.1 |  |
| Comprehensive income | $ | 111.0 |  |  | $ | 106.7 |  |  | $ | 20.2 |  |  | $ | (123.1 | ) |  | $ | 114.8 |  |

[0001069202-16-000020:notes:39]
For the Six Months Ended June 30, 2016

[0001069202-16-000020:notes:40]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,498.3 |  |  | $ | 327.2 |  |  | $ | (91.1 | ) |  | $ | 1,734.4 |  |
| Cost of goods sold | — |  |  | 1,072.4 |  |  | 252.5 |  |  | (89.1 | ) |  | 1,235.8 |  |
| Gross profit | — |  |  | 425.9 |  |  | 74.7 |  |  | (2.0 | ) |  | 498.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 258.6 |  |  | 41.1 |  |  | — |  |  | 299.7 |  |
| Losses (gains) and other expenses, net | (0.6 | ) |  | 3.1 |  |  | 2.2 |  |  | — |  |  | 4.7 |  |
| Restructuring charges | — |  |  | 1.0 |  |  | (0.4 | ) |  | — |  |  | 0.6 |  |
| Income from equity method investments | (143.5 | ) |  | (9.5 | ) |  | (9.2 | ) |  | 151.4 |  |  | (10.8 | ) |
| Operating income | 144.1 |  |  | 172.7 |  |  | 41.0 |  |  | (153.4 | ) |  | 204.4 |  |
| Interest expense, net | 11.7 |  |  | (1.0 | ) |  | 2.0 |  |  | — |  |  | 12.7 |  |
| Other expense, net | — |  |  | — |  |  | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Income from continuing operations before income taxes | 132.4 |  |  | 173.7 |  |  | 39.3 |  |  | (153.4 | ) |  | 192.0 |  |
| Provision for income taxes | (3.1 | ) |  | 46.8 |  |  | 12.9 |  |  | (0.7 | ) |  | 55.9 |  |
| Income from continuing operations | 135.5 |  |  | 126.9 |  |  | 26.4 |  |  | (152.7 | ) |  | 136.1 |  |
| Loss from discontinued operations | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Net income | $ | 135.5 |  |  | $ | 126.9 |  |  | $ | 25.9 |  |  | $ | (152.7 | ) |  | $ | 135.6 |  |
| Other comprehensive income (loss), net of tax | 4.9 |  |  | 2.4 |  |  | 9.0 |  |  | 1.8 |  |  | 18.1 |  |
| Comprehensive income | $ | 140.4 |  |  | $ | 129.3 |  |  | $ | 34.9 |  |  | $ | (150.9 | ) |  | $ | 153.7 |  |

[0001069202-16-000020:notes:41]
For the Three Months Ended June 30, 2015

[0001069202-16-000020:notes:42]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 864.6 |  |  | $ | 181.7 |  |  | $ | (53.8 | ) |  | $ | 992.5 |  |
| Cost of goods sold | — |  |  | 617.2 |  |  | 145.1 |  |  | (53.2 | ) |  | 709.1 |  |
| Gross profit | — |  |  | 247.4 |  |  | 36.6 |  |  | (0.6 | ) |  | 283.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 130.1 |  |  | 22.8 |  |  | — |  |  | 152.9 |  |
| Losses (gains) and other expenses, net | 0.4 |  |  | 1.1 |  |  | 1.8 |  |  | — |  |  | 3.3 |  |
| Restructuring charges | — |  |  | (0.5 | ) |  | 2.3 |  |  | — |  |  | 1.8 |  |
| Income from equity method investments | (85.6 | ) |  | 0.2 |  |  | (4.5 | ) |  | 84.4 |  |  | (5.5 | ) |
| Operating income | 85.2 |  |  | 116.5 |  |  | 14.2 |  |  | (85.0 | ) |  | 130.9 |  |
| Interest expense, net | 6.2 |  |  | (0.6 | ) |  | 0.8 |  |  | — |  |  | 6.4 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 79.0 |  |  | 117.1 |  |  | 13.4 |  |  | (85.0 | ) |  | 124.5 |  |
| Provision for income taxes | (2.2 | ) |  | 40.4 |  |  | 5.0 |  |  | (0.3 | ) |  | 42.9 |  |
| Income from continuing operations | 81.2 |  |  | 76.7 |  |  | 8.4 |  |  | (84.7 | ) |  | 81.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Net income | $ | 81.2 |  |  | $ | 76.7 |  |  | $ | 8.0 |  |  | $ | (84.7 | ) |  | $ | 81.2 |  |
| Other comprehensive income, net of tax | 0.3 |  |  | (1.3 | ) |  | 0.5 |  |  | 0.3 |  |  | (0.2 | ) |
| Comprehensive income | $ | 81.5 |  |  | $ | 75.4 |  |  | $ | 8.5 |  |  | $ | (84.4 | ) |  | $ | 81.0 |  |

[0001069202-16-000020:notes:43]
For the Six Months Ended June 30, 2015

[0001069202-16-000020:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,440.7 |  |  | $ | 335.5 |  |  | $ | (97.9 | ) |  | $ | 1,678.3 |  |
| Cost of goods sold | — |  |  | 1,060.8 |  |  | 268.0 |  |  | (96.9 | ) |  | 1,231.9 |  |
| Gross profit | — |  |  | 379.9 |  |  | 67.5 |  |  | (1.0 | ) |  | 446.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 238.0 |  |  | 48.2 |  |  | — |  |  | 286.2 |  |
| Losses and other expenses, net | 0.5 |  |  | 5.0 |  |  | 3.5 |  |  | (0.1 | ) |  | 8.9 |  |
| Restructuring charges | — |  |  | (0.4 | ) |  | 2.5 |  |  | — |  |  | 2.1 |  |
| Income from equity method investments | (103.1 | ) |  | 2.6 |  |  | (7.3 | ) |  | 99.0 |  |  | (8.8 | ) |
| Operating income | 102.6 |  |  | 134.7 |  |  | 20.6 |  |  | (99.9 | ) |  | 158.0 |  |
| Interest expense, net | 11.7 |  |  | (1.1 | ) |  | 1.6 |  |  | — |  |  | 12.2 |  |
| Income from continuing operations before income taxes | 90.9 |  |  | 135.8 |  |  | 19.0 |  |  | (99.9 | ) |  | 145.8 |  |
| Provision for income taxes | (4.2 | ) |  | 48.2 |  |  | 6.6 |  |  | (0.4 | ) |  | 50.2 |  |
| Income from continuing operations | 95.1 |  |  | 87.6 |  |  | 12.4 |  |  | (99.5 | ) |  | 95.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Net income | $ | 95.1 |  |  | $ | 87.6 |  |  | $ | 11.9 |  |  | $ | (99.5 | ) |  | $ | 95.1 |  |
| Other comprehensive income (loss), net of tax | 1.3 |  |  | (5.2 | ) |  | (20.1 | ) |  | (1.4 | ) |  | (25.4 | ) |
| Comprehensive income | $ | 96.4 |  |  | $ | 82.4 |  |  | $ | (8.2 | ) |  | $ | (100.9 | ) |  | $ | 69.7 |  |

[0001069202-16-000020:notes:45]
Condensed Consolidating Statements of Cash Flows

[0001069202-16-000020:notes:46]
For the Six Months Ended June 30, 2016

[0001069202-16-000020:notes:47]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 46.4 |  |  | $ | (51.3 | ) |  | $ | (36.1 | ) |  | $ | — |  |  | $ | (41.0 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (36.8 | ) |  | (4.9 | ) |  | — |  |  | (41.7 | ) |
| Net cash used in investing activities | — |  |  | (36.8 | ) |  | (4.9 | ) |  | — |  |  | (41.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (20.0 | ) |  | — |  |  | (20.0 | ) |
| Long-term debt payments | (7.5 | ) |  | (0.5 | ) |  | (0.2 | ) |  | — |  |  | (8.2 | ) |
| Borrowings from credit facility | 1,184.5 |  |  | — |  |  | — |  |  | — |  |  | 1,184.5 |  |
| Payments on credit facility | (864.0 | ) |  | — |  |  | — |  |  | — |  |  | (864.0 | ) |
| Proceeds from employee stock purchases | 1.3 |  |  | — |  |  | — |  |  | — |  |  | 1.3 |  |
| Repurchases of common stock | (200.0 | ) |  | — |  |  | — |  |  | — |  |  | (200.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (21.4 | ) |  | — |  |  | — |  |  | — |  |  | (21.4 | ) |
| Excess tax benefits related to share-based payments | 15.7 |  |  | — |  |  | — |  |  | — |  |  | 15.7 |  |
| Intercompany debt | (11.9 | ) |  | (4.3 | ) |  | 16.2 |  |  | — |  |  | — |  |
| Intercompany financing activity | (110.2 | ) |  | 109.1 |  |  | 1.1 |  |  | — |  |  | — |  |
| Cash dividends paid | (31.8 | ) |  | — |  |  | — |  |  | — |  |  | (31.8 | ) |
| Net cash provided by financing activities | (45.3 | ) |  | 104.3 |  |  | 37.6 |  |  | — |  |  | 96.6 |  |
| Increase in cash and cash equivalents | 1.1 |  |  | 16.2 |  |  | (3.4 | ) |  | — |  |  | 13.9 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Cash and cash equivalents, beginning of period | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of period | $ | 1.6 |  |  | $ | 24.0 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 54.7 |  |

[0001069202-16-000020:notes:48]
For the Six Months Ended June 30, 2015

[0001069202-16-000020:notes:49]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 2.1 |  |  | $ | (45.0 | ) |  | $ | (9.4 | ) |  | $ | — |  |  | $ | (52.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (27.8 | ) |  | (5.2 | ) |  | — |  |  | (33.0 | ) |
| Net cash used in investing activities | — |  |  | (27.8 | ) |  | (5.2 | ) |  | — |  |  | (33.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Long-term debt payments | (22.5 | ) |  | (0.3 | ) |  | (0.2 | ) |  | — |  |  | (23.0 | ) |
| Borrowings from revolving credit facility | 999.0 |  |  | — |  |  | — |  |  | — |  |  | 999.0 |  |
| Payments on revolving credit facility | (845.5 | ) |  | — |  |  | — |  |  | — |  |  | (845.5 | ) |
| Proceeds from employee stock purchases | 1.1 |  |  | — |  |  | — |  |  | — |  |  | 1.1 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (21.8 | ) |  | — |  |  | — |  |  | — |  |  | (21.8 | ) |
| Excess tax benefits related to share-based payments | 17.3 |  |  | — |  |  | — |  |  | — |  |  | 17.3 |  |
| Intercompany financing activity | (24.3 | ) |  | 3.4 |  |  | 20.9 |  |  | — |  |  | — |  |
| Intercompany investments | (77.8 | ) |  | 79.9 |  |  | (2.1 | ) |  | — |  |  | — |  |
| Cash dividends paid | (26.9 | ) |  | — |  |  | — |  |  | — |  |  | (26.9 | ) |
| Net cash provided by financing activities | (1.4 | ) |  | 83.0 |  |  | 19.0 |  |  | — |  |  | 100.6 |  |
| Increase in cash and cash equivalents | 0.7 |  |  | 10.2 |  |  | 4.4 |  |  | — |  |  | 15.3 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (5.3 | ) |  | — |  |  | (5.3 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of period | $ | 1.7 |  |  | $ | 21.7 |  |  | $ | 24.1 |  |  | $ | — |  |  | $ | 47.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-16-000020:notes:50]
Lines of Credit and Financing Arrangements:

[0001069202-16-000020:notes:51]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000020:notes:52]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 5.4 |  |  | 4.1 |  |
| Total short-term debt | $ | 225.4 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.0 |  |  | $ | 1.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Senior unsecured notes | 200.0 |  |  | — |  |
| Debt issuance costs | (0.2 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 230.8 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.2 |  |  | $ | 15.6 |  |
| Domestic credit facility | 606.0 |  |  | 293.0 |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (2.2 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 619.0 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,075.2 |  |  | $ | 741.1 |  |

[0001069202-16-000020:notes:53]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. We adopted this guidance in the prior quarter and have reclassified the unamortized debt issuance costs into the debt liability as shown in the table above.

[0001069202-16-000020:notes:54]
Short-Term Debt

[0001069202-16-000020:notes:55]
Foreign Obligations

[0001069202-16-000020:notes:56]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $5.4 million and $4.1 million of foreign obligations as of June 30, 2016 and December 31, 2015, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $20.4 million  and $32.4 million during the six months ended June 30, 2016 and 2015, respectively. Repayments on the facilities were $20.0 million and $32.1 million during the six months ended June 30, 2016 and 2015, respectively.

[0001069202-16-000020:notes:57]
Asset Securitization Program

[0001069202-16-000020:notes:58]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-16-000020:notes:59]
The ASP provided (before consideration of the amendment discussed in the next sentence) for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The ASP was amended effective as of July 5, 2016 to increase the maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-16-000020:notes:60]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rate for June 30, 2016 and December 31, 2015 was 1.20% and 1.06% respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-16-000020:notes:61]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2016, we were in compliance with all covenant requirements.

[0001069202-16-000020:notes:62]
Long-Term Debt

[0001069202-16-000020:notes:63]
Domestic Credit Facility

[0001069202-16-000020:notes:64]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consisted of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $636.0 million, of which $270.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of June 30, 2016. Subject to covenant limitations, $279.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million.  The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-16-000020:notes:65]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-16-000020:notes:66]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-16-000020:notes:67]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-16-000020:notes:68]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-16-000020:notes:69]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2016, we were in compliance with all covenant requirements.

[0001069202-16-000020:notes:70]
Senior Unsecured Notes

[0001069202-16-000020:notes:71]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2016, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-16-000020:notes:72]
[same as prior period, unchanged from 0001069202-16-000017:notes:52]

[0001069202-16-000020:notes:73]
[same as prior period, unchanged from 0001069202-16-000017:notes:53]

[0001069202-16-000020:notes:74]
[same as prior period, unchanged from 0001069202-16-000017:notes:54]

[0001069202-16-000020:notes:75]
[same as prior period, unchanged from 0001069202-16-000017:notes:55]

[0001069202-16-000020:notes:76]
[same as prior period, unchanged from 0001069202-16-000017:notes:56]

[0001069202-16-000020:notes:77]
[same as prior period, unchanged from 0001069202-16-000017:notes:57]

[0001069202-16-000020:notes:78]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flow hedges that are scheduled to mature through December 2017.  Unrealized gains or losses from our cash flow hedges are included in Accumulated Other Comprehensive Loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-16-000020:notes:79]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Unrealized losses on unsettled futures contracts | $ | 5.5 |  |  | $ | 13.2 |  |
| Income tax benefit | (2.0 | ) |  | (4.8 | ) |
| Losses included in AOCL, net of tax (1) | $ | 3.5 |  |  | $ | 8.4 |  |

[0001069202-16-000020:notes:80]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $3.7 million of derivative losses into earnings within the next 12 months.

[0001069202-16-000020:notes:81]
[same as prior period, unchanged from 0001069202-16-000017:notes:61]

[0001069202-16-000020:notes:82]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Copper | 33.8 |  |  | 34.7 |  |

[0001069202-16-000020:notes:83]
[same as prior period, unchanged from 0001069202-16-000017:notes:63]

[0001069202-16-000020:notes:84]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 101.5 |  |  | 201.4 |  |
| Canadian Dollar | 37.4 |  |  | — |  |

[0001069202-16-000020:notes:85]
[same as prior period, unchanged from 0001069202-16-000017:notes:65]

[0001069202-16-000020:notes:86]
[same as prior period, unchanged from 0001069202-16-000017:notes:66]

[0001069202-16-000020:notes:87]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Copper | 2.8 |  |  | 3.3 |  |
| Aluminum | 2.6 |  |  | 3.2 |  |

[0001069202-16-000020:notes:88]
[same as prior period, unchanged from 0001069202-16-000017:notes:68]

[0001069202-16-000020:notes:89]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 38.4 |  |  | 53.0 |  |
| Indian Rupee | 375.1 |  |  | 30.8 |  |
| Euro | 31.0 |  |  | 3.2 |  |
| Polish Zloty | — |  |  | 25.4 |  |
| Canadian Dollar | 7.0 |  |  | — |  |
| New Zealand Dollar | 4.0 |  |  | — |  |
| Australian Dollar | 29.0 |  |  | — |  |

[0001069202-16-000020:notes:90]
[same as prior period, unchanged from 0001069202-16-000017:notes:70]

[0001069202-16-000020:notes:91]
[same as prior period, unchanged from 0001069202-16-000017:notes:71]

[0001069202-16-000020:notes:92]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of June 30, 2016 |  | As of December 31, 2015 |  | As of June 30, 2016 |  | As of December 31, 2015 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 1.1 |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.3 |  |  | — |  |  | — |  |  | — |  |
| Total Assets | $ | 0.3 |  |  | $ | — |  |  | $ | 1.1 |  |  | $ | 0.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 5.4 |  |  | $ | 12.5 |  |  | $ | 0.6 |  |  | $ | 1.5 |  |
| Foreign currency forward contracts | 0.5 |  |  | 0.4 |  |  | (0.1 | ) |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.2 |  |  | 0.4 |  |  | — |  |  | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 6.1 |  |  | $ | 13.3 |  |  | $ | 0.5 |  |  | $ | 1.5 |  |

[0001069202-16-000020:notes:93]
[same as prior period, unchanged from 0001069202-16-000017:notes:73]

[0001069202-16-000020:notes:94]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amount of Loss reclassified from AOCL into Income (effective portion) (1) |  | $ | 3.4 |  |  | $ | 2.8 |  |  | $ | 8.2 |  |  | $ | 6.2 |  |
| Amount of Loss recognized in Net income (ineffective portion) (2) |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |

[0001069202-16-000020:notes:95]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | 0.8 |  |
| Foreign currency forward contracts (2) |  | (0.5 | ) |  | — |  |  | (0.1 | ) |  | 0.2 |  |
|  |  | $ | (0.4 | ) |  | $ | 0.4 |  |  | $ | — |  |  | $ | 1.0 |  |

[0001069202-16-000020:notes:96]
[same as prior period, unchanged from 0001069202-16-000017:notes:76]

[0001069202-16-000020:notes:97]
[same as prior period, unchanged from 0001069202-16-000017:notes:77]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-16-000020:notes:98]
[same as prior period, unchanged from 0001069202-16-000017:notes:78]

[0001069202-16-000020:notes:99]
[same as prior period, unchanged from 0001069202-16-000017:notes:79]

[0001069202-16-000020:notes:100]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Stock-based compensation expense (1) | $ | 8.6 |  |  | $ | 7.3 |  |  | $ | 14.8 |  |  | $ | 10.8 |  |

[0001069202-16-000020:notes:101]
[same as prior period, unchanged from 0001069202-16-000017:notes:81]


## us-gaap:EarningsPerShareTextBlock

[0001069202-16-000020:notes:102]
[same as prior period, unchanged from 0001069202-16-000017:notes:82]

[0001069202-16-000020:notes:103]
[same as prior period, unchanged from 0001069202-16-000017:notes:83]

[0001069202-16-000020:notes:104]
[same as prior period, unchanged from 0001069202-16-000017:notes:84]

[0001069202-16-000020:notes:105]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net income | $ | 110.7 |  |  | $ | 81.2 |  |  | $ | 135.6 |  |  | $ | 95.1 |  |
| Add: Loss from discontinued operations | 0.5 |  |  | 0.4 |  |  | 0.5 |  |  | 0.5 |  |
| Income from continuing operations | $ | 111.2 |  |  | $ | 81.6 |  |  | $ | 136.1 |  |  | $ | 95.6 |  |
| Weighted-average shares outstanding – basic | 43.6 |  |  | 45.0 |  |  | 43.8 |  |  | 44.9 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.5 |  |  | 0.6 |  |  | 0.6 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 44.1 |  |  | 45.6 |  |  | 44.4 |  |  | 45.6 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.55 |  |  | $ | 1.81 |  |  | $ | 3.11 |  |  | $ | 2.13 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Net income | $ | 2.54 |  |  | $ | 1.80 |  |  | $ | 3.10 |  |  | $ | 2.12 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.52 |  |  | $ | 1.79 |  |  | $ | 3.07 |  |  | $ | 2.10 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Net income | $2.51 |  | $ | 1.78 |  |  | $ | 3.06 |  |  | $ | 2.09 |  |

[0001069202-16-000020:notes:106]
[same as prior period, unchanged from 0001069202-16-000017:notes:86]

[0001069202-16-000020:notes:107]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Weighted-average number of shares | 0.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Price range per share | $124.97-$131.94 |  |  | $ | 92.64 |  |  | $124.97-$131.94 |  |  | $ | 92.64 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-16-000020:notes:108]
[same as prior period, unchanged from 0001069202-16-000017:notes:88]

[0001069202-16-000020:notes:109]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Senior unsecured notes | $ | 206.2 |  |  | $ | 207.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-16-000020:notes:110]
[same as prior period, unchanged from 0001069202-16-000017:notes:90]

[0001069202-16-000020:notes:111]
[same as prior period, unchanged from 0001069202-16-000017:notes:91]

[0001069202-16-000020:notes:112]
The methodologies used to determine the fair value of our financial assets and liabilities at June 30, 2016 were the same as those used at December 31, 2015.

[0001069202-16-000020:notes:113]
[same as prior period, unchanged from 0001069202-16-000017:notes:93]

[0001069202-16-000020:notes:114]
[same as prior period, unchanged from 0001069202-16-000017:notes:94]

[0001069202-16-000020:notes:115]
[same as prior period, unchanged from 0001069202-16-000017:notes:95]

[0001069202-16-000020:notes:116]
[same as prior period, unchanged from 0001069202-16-000017:notes:96]

[0001069202-16-000020:notes:117]
[same as prior period, unchanged from 0001069202-16-000017:notes:97]

[0001069202-16-000020:notes:118]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Investment in marketable equity securities | $ | 5.8 |  |  | $ | 6.5 |  |

[0001069202-16-000020:notes:119]
[same as prior period, unchanged from 0001069202-16-000017:notes:99]

[0001069202-16-000020:notes:120]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-16-000020:notes:121]
[same as prior period, unchanged from 0001069202-16-000017:notes:101]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-16-000020:notes:122]
[same as prior period, unchanged from 0001069202-16-000017:notes:102]

[0001069202-16-000020:notes:123]
The changes in the carrying amount of goodwill for the first six months of 2016, in total and by segment, are summarized in the table below (in millions):

[0001069202-16-000020:notes:124]
|  | Balance at December 31, 2015 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at June 30, 2016 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 60.6 |  |  | — |  |  | 0.7 |  |  | 61.3 |  |
| Refrigeration | 108.4 |  |  | — |  |  | 2.7 |  |  | 111.1 |  |
| Total Goodwill | $ | 195.1 |  |  | $ | — |  |  | $ | 3.4 |  |  | $ | 198.5 |  |

[0001069202-16-000020:notes:125]
[same as prior period, unchanged from 0001069202-16-000017:notes:105]

[0001069202-16-000020:notes:126]
We performed our annual goodwill impairment test in the fourth quarter of  2015 and recorded a $5.5 million goodwill impairment charge.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-16-000020:notes:127]
[same as prior period, unchanged from 0001069202-16-000017:notes:107]

[0001069202-16-000020:notes:128]
As of June 30, 2016, we had no unrecognized tax benefits.

[0001069202-16-000020:notes:129]
[same as prior period, unchanged from 0001069202-16-000017:notes:109]

[0001069202-16-000020:notes:130]
Since January 1, 2016, numerous states, including Delaware and the District of Columbia, have enacted legislation effective for tax years beginning on or after January 1, 2016, including changes to apportionment methodologies and tax rates.  The impact of these changes is immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-16-000020:notes:131]
[same as prior period, unchanged from 0001069202-16-000017:notes:111]

[0001069202-16-000020:notes:132]
[same as prior period, unchanged from 0001069202-16-000017:notes:112]

[0001069202-16-000020:notes:133]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Finished goods | $ | 360.4 |  |  | $ | 300.0 |  |
| Work in process | 6.8 |  |  | 4.2 |  |
| Raw materials and parts | 201.9 |  |  | 178.3 |  |
| Subtotal | 569.1 |  |  | 482.5 |  |
| Excess of current cost over last-in, first-out cost | (63.4 | ) |  | (63.7 | ) |
| Total inventories, net | $ | 505.7 |  |  | $ | 418.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-16-000020:notes:134]
[same as prior period, unchanged from 0001069202-16-000017:notes:114]

[0001069202-16-000020:notes:135]
[same as prior period, unchanged from 0001069202-16-000017:notes:115]

[0001069202-16-000020:notes:136]
[same as prior period, unchanged from 0001069202-16-000017:notes:116]

[0001069202-16-000020:notes:137]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-16-000020:notes:138]
[same as prior period, unchanged from 0001069202-16-000017:notes:118]

[0001069202-16-000020:notes:139]
[same as prior period, unchanged from 0001069202-16-000017:notes:119]

[0001069202-16-000020:notes:140]
[same as prior period, unchanged from 0001069202-16-000017:notes:120]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-16-000020:notes:141]
[same as prior period, unchanged from 0001069202-16-000017:notes:121]

[0001069202-16-000020:notes:142]
[same as prior period, unchanged from 0001069202-16-000017:notes:122]

[0001069202-16-000020:notes:143]
|  | For the Three Months Ended June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.1 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.9 |  |  | 4.3 |  |  | — |  |  | 0.1 |  |
| Expected return on plan assets | (5.7 | ) |  | (5.4 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | — |  |  | (0.8 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 1.7 |  |  | 2.4 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.1 |  |  | $ | 2.6 |  |  | $ | (0.4 | ) |  | $ | (0.3 | ) |

[0001069202-16-000020:notes:144]
|  | For the Six Months Ended June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 2.2 |  |  | $ | 2.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 7.7 |  |  | 8.6 |  |  | — |  |  | 0.1 |  |
| Expected return on plan assets | (10.8 | ) |  | (10.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (1.5 | ) |  | (1.5 | ) |
| Recognized actuarial loss | 3.8 |  |  | 4.8 |  |  | 0.7 |  |  | 0.8 |  |
| Settlements and curtailments | — |  |  | 0.4 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 3.0 |  |  | $ | 5.5 |  |  | $ | (0.8 | ) |  | $ | (0.6 | ) |

[0001069202-16-000020:notes:145]
(1) All net periodic benefit cost for the three and six months ended June 30, 2016 and 2015 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-16-000020:notes:146]
Net sales and segment profit (loss) for each segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001069202-16-000020:notes:147]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 574.5 |  |  | $ | 555.1 |  |  | $ | 951.8 |  |  | $ | 917.7 |  |
| Commercial Heating & Cooling | 252.9 |  |  | 253.6 |  |  | 423.3 |  |  | 413.5 |  |
| Refrigeration | 191.8 |  |  | 183.8 |  |  | 359.3 |  |  | 347.1 |  |
|  | $ | 1,019.2 |  |  | $ | 992.5 |  |  | $ | 1,734.4 |  |  | $ | 1,678.3 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 115.9 |  |  | $ | 99.9 |  |  | $ | 154.1 |  |  | $ | 131.2 |  |
| Commercial Heating & Cooling | 47.4 |  |  | 43.0 |  |  | 61.7 |  |  | 50.7 |  |
| Refrigeration | 21.3 |  |  | 13.3 |  |  | 30.3 |  |  | 17.2 |  |
| Corporate and other | (23.5 | ) |  | (22.0 | ) |  | (38.4 | ) |  | (33.7 | ) |
| Total segment profit | 161.1 |  |  | 134.2 |  |  | 207.7 |  |  | 165.4 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Special product quality adjustments | — |  |  | (1.1 | ) |  | (0.4 | ) |  | (1.4 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | (0.4 | ) |  | 2.6 |  |  | 3.1 |  |  | 6.7 |  |
| Restructuring charges | 0.8 |  |  | 1.8 |  |  | 0.6 |  |  | 2.1 |  |
| Operating income | $ | 160.7 |  |  | $ | 130.9 |  |  | $ | 204.4 |  |  | $ | 158.0 |  |

[0001069202-16-000020:notes:148]
(1)  The Company defines segment profit and loss as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-16-000020:notes:149]
[same as prior period, unchanged from 0001069202-16-000017:notes:128]

[0001069202-16-000020:notes:150]
[same as prior period, unchanged from 0001069202-16-000017:notes:129]

[0001069202-16-000020:notes:151]
[same as prior period, unchanged from 0001069202-16-000017:notes:130]

[0001069202-16-000020:notes:152]
| ◦ | Special legal contingency charges, |

[0001069202-16-000020:notes:153]
| ◦ | Asbestos-related litigation, |

[0001069202-16-000020:notes:154]
[same as prior period, unchanged from 0001069202-16-000017:notes:133]

[0001069202-16-000020:notes:155]
[same as prior period, unchanged from 0001069202-16-000017:notes:134]

[0001069202-16-000020:notes:156]
[same as prior period, unchanged from 0001069202-16-000017:notes:135]

[0001069202-16-000020:notes:157]
| • | Restructuring charges; and |

[0001069202-16-000020:notes:158]
| • | Goodwill, long-lived asset, and equity method investment impairments. |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-16-000020:notes:159]
[same as prior period, unchanged from 0001069202-16-000017:notes:141]

[0001069202-16-000020:notes:160]
[same as prior period, unchanged from 0001069202-16-000017:notes:142]

[0001069202-16-000020:notes:161]
[same as prior period, unchanged from 0001069202-16-000017:notes:143]

[0001069202-16-000020:notes:162]
[same as prior period, unchanged from 0001069202-16-000017:notes:144]

[0001069202-16-000020:notes:163]
|  | Charges Incurred in 2016 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | (0.3 | ) |  | $ | 9.2 |  |  | $ | 9.2 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 2.2 |  |  | 2.2 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | 0.2 |  |  | 0.2 |  |
| Other | 0.8 |  |  | 2.8 |  |  | 4.1 |  |
| Total restructuring charges | $ | 0.6 |  |  | $ | 14.4 |  |  | $ | 15.7 |  |

[0001069202-16-000020:notes:164]
[same as prior period, unchanged from 0001069202-16-000017:notes:146]

[0001069202-16-000020:notes:165]
|  | Charges Incurred in 2016 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | (0.3 | ) |  | 11.7 |  |  | 11.7 |  |
| Corporate & Other | 0.9 |  |  | 0.9 |  |  | 2.2 |  |
| Total restructuring charges | $ | 0.6 |  |  | $ | 14.4 |  |  | $ | 15.7 |  |

[0001069202-16-000020:notes:166]
[same as prior period, unchanged from 0001069202-16-000017:notes:148]

[0001069202-16-000020:notes:167]
|  | Balance as ofDecember 31, 2015 |  | Charged to Earnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of June 30, 2016 |
| Severance and related expense | $ | 0.7 |  |  | $ | (0.3 | ) |  | $ | (0.4 | ) |  | $ | 0.3 |  |  | $ | 0.3 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | 0.2 |  |  | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Other | — |  |  | 0.8 |  |  | (1.0 | ) |  | — |  |  | (0.2 | ) |
| Total restructuring accruals | $ | 0.9 |  |  | $ | 0.6 |  |  | $ | (1.5 | ) |  | $ | 0.3 |  |  | $ | 0.3 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001069202-16-000020:notes:168]
We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions of pounds):


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-16-000020:notes:169]
[same as prior period, unchanged from 0001069202-16-000017:notes:166]

[0001069202-16-000020:notes:170]
[same as prior period, unchanged from 0001069202-16-000017:notes:167]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-16-000020:notes:171]
[same as prior period, unchanged from 0001069202-16-000017:notes:168]

[0001069202-16-000020:notes:172]
[same as prior period, unchanged from 0001069202-16-000017:notes:169]

[0001069202-16-000020:notes:173]
[same as prior period, unchanged from 0001069202-16-000017:notes:170]

[0001069202-16-000020:notes:174]
[same as prior period, unchanged from 0001069202-16-000017:notes:171]

[0001069202-16-000020:notes:175]
[same as prior period, unchanged from 0001069202-16-000017:notes:172]

[0001069202-16-000020:notes:176]
[same as prior period, unchanged from 0001069202-16-000017:notes:173]

[0001069202-16-000020:notes:177]
[same as prior period, unchanged from 0001069202-16-000017:notes:174]

[0001069202-16-000020:notes:178]
[same as prior period, unchanged from 0001069202-16-000017:notes:175]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-16-000020:notes:179]
[same as prior period, unchanged from 0001069202-16-000017:notes:176]

[0001069202-16-000020:notes:180]
Our Board of Directors has authorized a total of $1.4 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first six months of 2016. As of June 30, 2016, $196.2 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-16-000020:notes:181]
[same as prior period, unchanged from 0001069202-16-000017:notes:178]

[0001069202-16-000020:notes:182]
Under the ASR Agreement, on February 10, 2016, the Company paid Merrill Lynch an initial purchase price of $200 million, and Merrill Lynch delivered to the Company a total of 1.3 million shares of Common Stock, representing approximately 75% of the shares expected to be purchased under the ASR Agreement. The ASR Agreement was completed subsequent to quarter end and Merrill Lynch delivered an additional 0.2 million shares of Common Stock to the Company.

[0001069202-16-000020:notes:183]
We also repurchased 0.2 million shares for $21.4 million for the six months ended June 30, 2016 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.


## us-gaap:SubsequentEventsTextBlock

[0001069202-16-000020:notes:184]
Subsequent Events:

[0001069202-16-000020:notes:185]
On July 16, 2016, our Board of Directors authorized our plans to complete another $100 million stock repurchase program in 2016 and to contribute $50 million  to our pension plans in 2016, as more fully discussed in the Liquidity section of our Management’s Discussion and Analysis of Financial Condition and Results of Operations.
