# LII note change history — 0001069202-16-000017 → 0001069202-16-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-07-18):
[0001069202-16-000020:note_history:1]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Accrued expenses | $ | 29.2 |  |  | $ | 26.7 |  |
| Other liabilities | 69.6 |  |  | 65.6 |  |
| Total warranty liability | $ | 98.8 |  |  | $ | 92.3 |  |
  (was, 2016-04-18, similarity 0.9741):
[0001069202-16-000017:note_history:1]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Accrued expenses | $ | 27.6 |  |  | $ | 26.7 |  |
| Other liabilities | 65.8 |  |  | 65.6 |  |
| Total warranty liability | $ | 93.4 |  |  | $ | 92.3 |  |

- changed (2016-07-18):
[0001069202-16-000020:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2016 were as follows (in millions):
  (was, 2016-04-18, similarity 0.9404):
[0001069202-16-000017:note_history:2]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2016 were as follows (in millions):

- changed (2016-07-18):
[0001069202-16-000020:note_history:3]
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |
| Warranty claims paid | (11.7 | ) |
| Changes resulting from issuance of new warranties | 20.0 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | 0.8 |  |
| Total warranty liability as of June 30, 2016 | $ | 98.8 |  |
  (was, 2016-04-18, similarity 0.987):
[0001069202-16-000017:note_history:3]
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |
| Warranty claims paid | (5.6 | ) |
| Changes resulting from issuance of new warranties | 8.1 |  |
| Changes in estimates associated with pre-existing liabilities | (1.9 | ) |
| Changes in foreign currency translation rates and other | 0.5 |  |
| Total warranty liability as of March 31, 2016 | $ | 93.4 |  |

- changed (2016-07-18):
[0001069202-16-000020:note_history:4]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a certain supplier quality issue within a range of $2.0 million and $9.4 million with all amounts in that range equally likely.  We have accrued a $2.0 million liability in Accrued expenses on the Consolidated Balance Sheet at June 30, 2016. The supplier is reimbursing the majority of costs related to this liability.
  (was, 2016-04-18, similarity 0.9426):
[0001069202-16-000017:note_history:4]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a certain supplier quality issue within a range of $2.0 million and $9.5 million with all amounts in that range equally likely.  We have accrued a $2.0 million liability in Accrued expenses on the Consolidated Balance Sheet at March 31, 2016. The supplier is reimbursing the majority of costs related to this liability.

- changed (2016-07-18):
[0001069202-16-000020:note_history:5]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.
  (was, 2016-04-18, similarity 0.6335):
[0001069202-16-000017:note_history:5]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known. We increased our reserves by $1.0 million during the quarter for claims administration costs in a settled class action lawsuit which alleged that evaporator coils in our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks.  We also incurred an additional $0.7 million of legal charges related to other matters.

- changed (2016-07-18):
[0001069202-16-000020:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and is subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2016, and 2015, expense for asbestos-related litigation was $1.9 million, and $0.6 million, net of insurance recoveries, respectively.
  (was, 2016-04-18, similarity 0.9786):
[0001069202-16-000017:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and is subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2016, and 2015, expense for asbestos-related litigation was $0.8 million, and $0.1 million, net of insurance recoveries, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-07-18):
[0001069202-16-000020:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2016, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2016 and 2015, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six  months ended June 30, 2016 and 2015, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2016 and 2015 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2015. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2016-04-18, similarity 0.9537):
[0001069202-16-000017:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2016, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2016 and 2015, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2016 and 2015, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2016 and 2015 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2015. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-18):
[0001069202-16-000020:note_history:8]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.95 | % |  | 1.90 | % |
  (was, 2016-04-18, similarity 0.9538):
[0001069202-16-000017:note_history:8]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.67 | % |  | 1.90 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-18):
[0001069202-16-000020:note_history:9]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 5.4 |  |  | 4.1 |  |
| Total short-term debt | $ | 225.4 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.0 |  |  | $ | 1.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Senior unsecured notes | 200.0 |  |  | — |  |
| Debt issuance costs | (0.2 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 230.8 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.2 |  |  | $ | 15.6 |  |
| Domestic credit facility | 606.0 |  |  | 293.0 |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (2.2 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 619.0 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,075.2 |  |  | $ | 741.1 |  |
  (was, 2016-04-18, similarity 0.9666):
[0001069202-16-000017:note_history:9]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 4.0 |  |  | 4.1 |  |
| Total short-term debt | $ | 184.0 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.1 |  |  | $ | 1.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.2 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 30.9 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.4 |  |  | $ | 15.6 |  |
| Domestic credit facility | 671.5 |  |  | 293.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Debt issuance costs | (2.4 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 884.5 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,099.4 |  |  | $ | 741.1 |  |

- changed (2016-07-18):
[0001069202-16-000020:note_history:10]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. We adopted this guidance in the prior quarter and have reclassified the unamortized debt issuance costs into the debt liability as shown in the table above.
  (was, 2016-04-18, similarity 0.934):
[0001069202-16-000017:note_history:10]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. We are adopting this guidance in the current quarter and have reclassified the unamortized debt issuance costs into the debt liability as shown in the table above.

- changed (2016-07-18):
[0001069202-16-000020:note_history:11]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $5.4 million and $4.1 million of foreign obligations as of June 30, 2016 and December 31, 2015, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $20.4 million  and $32.4 million during the six months ended June 30, 2016 and 2015, respectively. Repayments on the facilities were $20.0 million and $32.1 million during the six months ended June 30, 2016 and 2015, respectively.
  (was, 2016-04-18, similarity 0.8946):
[0001069202-16-000017:note_history:11]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $4.0 million and $4.1 million of foreign obligations as of March 31, 2016 and December 31, 2015, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $1.2 million  and $11.0 million during the three months ended March 31, 2016 and 2015, respectively. Repayments on the facilities were $1.6 million and $11.2 million during the three months ended three months ended March 31, 2016 and 2015, respectively.

- changed (2016-07-18):
[0001069202-16-000020:note_history:12]
The ASP provided (before consideration of the amendment discussed in the next sentence) for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The ASP was amended effective as of July 5, 2016 to increase the maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):
  (was, 2016-04-18, similarity 0.8209):
[0001069202-16-000017:note_history:12]
The ASP provides for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- changed (2016-07-18):
[0001069202-16-000020:note_history:13]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 220.0 |  |  | 200.0 |  |
| Remaining amount available | $ | — |  |  | $ | 20.0 |  |
  (was, 2016-04-18, similarity 0.9811):
[0001069202-16-000017:note_history:13]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 180.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 180.0 |  |  | 200.0 |  |
| Remaining amount available | $ | — |  |  | $ | 20.0 |  |

- changed (2016-07-18):
[0001069202-16-000020:note_history:14]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rate for June 30, 2016 and December 31, 2015 was 1.20% and 1.06% respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2016-04-18, similarity 0.9864):
[0001069202-16-000017:note_history:14]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rate for March 31, 2016 and December 31, 2015 was 1.20% and 1.06% respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2016-07-18):
[0001069202-16-000020:note_history:15]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2016, we were in compliance with all covenant requirements.
  (was, 2016-04-18, similarity 0.9932):
[0001069202-16-000017:note_history:15]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2016, we were in compliance with all covenant requirements.

- added (2016-07-18):
[0001069202-16-000020:note_history:16]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consisted of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $636.0 million, of which $270.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of June 30, 2016. Subject to covenant limitations, $279.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million.  The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2016-07-18):
[0001069202-16-000020:note_history:17]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.95 | % |  | 1.90 | % |
  (was, 2016-04-18, similarity 0.9538):
[0001069202-16-000017:note_history:17]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.67 | % |  | 1.90 | % |

- changed (2016-07-18):
[0001069202-16-000020:note_history:18]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2016, we were in compliance with all covenant requirements.
  (was, 2016-04-18, similarity 0.9953):
[0001069202-16-000017:note_history:18]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2016, we were in compliance with all covenant requirements.

- changed (2016-07-18):
[0001069202-16-000020:note_history:19]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2016, we were in compliance with all covenant requirements.
  (was, 2016-04-18, similarity 0.9957):
[0001069202-16-000017:note_history:19]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2016, we were in compliance with all covenant requirements.

- removed (2016-07-18):
[0001069202-16-000017:note_history:20]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consisted of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $701.5 million, of which $277.5 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of March 31, 2016. Subject to covenant limitations, $221.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million.  The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-18):
[0001069202-16-000020:note_history:21]
|  | As of June 30, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 5.4 |  |  | 4.1 |  |
| Total short-term debt | $ | 225.4 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.0 |  |  | $ | 1.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Senior unsecured notes | 200.0 |  |  | — |  |
| Debt issuance costs | (0.2 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 230.8 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.2 |  |  | $ | 15.6 |  |
| Domestic credit facility | 606.0 |  |  | 293.0 |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (2.2 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 619.0 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,075.2 |  |  | $ | 741.1 |  |
  (was, 2016-04-18, similarity 0.9666):
[0001069202-16-000017:note_history:21]
|  | As of March 31, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 4.0 |  |  | 4.1 |  |
| Total short-term debt | $ | 184.0 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.1 |  |  | $ | 1.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.2 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 30.9 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.4 |  |  | $ | 15.6 |  |
| Domestic credit facility | 671.5 |  |  | 293.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Debt issuance costs | (2.4 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 884.5 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,099.4 |  |  | $ | 741.1 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-07-18):
[0001069202-16-000020:note_history:22]
Subsequent Events:

- added (2016-07-18):
[0001069202-16-000020:note_history:23]
On July 16, 2016, our Board of Directors authorized our plans to complete another $100 million stock repurchase program in 2016 and to contribute $50 million  to our pension plans in 2016, as more fully discussed in the Liquidity section of our Management’s Discussion and Analysis of Financial Condition and Results of Operations.
