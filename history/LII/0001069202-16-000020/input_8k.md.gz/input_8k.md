# LII 8-K — 0001193125-16-649843 filed 2016-07-18

## item codes, every 8-K on or before 2016-07-18

- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2016-07-18

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-649843:8k_2_02:1]
EX-99.1
2
d214298dex991.htm
EX-99.1

[0001193125-16-649843:8k_2_02:2]
EX-99.1

[0001193125-16-649843:8k_2_02:3]
Exhibit 99.1

[0001193125-16-649843:8k_2_02:4]
Lennox International Reports Record Profit in Second Quarter

[0001193125-16-649843:8k_2_02:5]
|  | • |  | GAAP EPS from continuing operations up 41% to record $2.52; adjusted EPS from continuing operations up 38% to record $2.53 |

[0001193125-16-649843:8k_2_02:6]
|  | • |  | GAAP operating income margin up 260 basis points to record 15.8%; total segment profit margin up 230 basis points to record 15.8% on 3% revenue growth |

[0001193125-16-649843:8k_2_02:7]
|  | • |  | Reiterating 2016 revenue growth guidance of 3-7%, with foreign exchange impact now expected to be neutral |

[0001193125-16-649843:8k_2_02:8]
|  | • |  | Raising 2016 GAAP EPS from continuing operations guidance from $6.26-$6.76 to $6.45-$6.85 |

[0001193125-16-649843:8k_2_02:9]
|  | • |  | Raising 2016 adjusted EPS from continuing operations guidance from $6.30-$6.80 to $6.50-$6.90 |

[0001193125-16-649843:8k_2_02:10]
|  | • |  | Announcing new $100 million stock repurchase program |

[0001193125-16-649843:8k_2_02:11]
DALLAS, July 18, 2016 – Lennox
International Inc. (NYSE: LII) today reported financial results for the second quarter of 2016.

[0001193125-16-649843:8k_2_02:12]
Revenue for the second quarter was $1.019 billion, up 3%
from the prior-year quarter. Foreign exchange was neutral to revenue in the quarter. GAAP operating income increased 23% to a record $161 million. GAAP earnings per share from continuing operations was a record $2.52, up 41% from the second quarter
a year ago. Adjusted earnings per share from continuing operations was a record $2.53, up 38% from the prior-year quarter.

[0001193125-16-649843:8k_2_02:13]
“Lennox International set
a new high for total segment profit margin at 15.8% in the second quarter, up 230 basis points from the prior-year quarter,” said Chairman and CEO Todd Bluedorn. “Total segment profit rose 20% to a record $161 million on 3% revenue growth,
which was negatively impacted by the cooler start to the summer than a year ago.

[0001193125-16-649843:8k_2_02:14]
“In our Residential business, we set new records for sales, margin
and profit in the quarter. Residential profit was up 16% on 4% revenue growth, with segment margin up 220 basis points to 20.2%. Our Commercial business hit new records for margin and profit, with revenue flat compared to the second quarter last
year. Commercial profit rose 10%, and segment margin expanded 170 basis points to 18.7%. In Refrigeration, segment profit was up 60% as margin expanded 390 basis points to 11.1%. Refrigeration revenue was up 6% at constant currency, with growth
across North America, Europe, and Asia Pacific.

[0001193125-16-649843:8k_2_02:15]
“Looking ahead for the company overall, we are raising EPS guidance for 2016 based on the
company’s strong operational performance and outlook, as well as further improvement in our effective tax rate to approximately 31% for 2016 from the prior guidance of 32%. The company raised its dividend 19% in May and completed a $200 million
accelerated share repurchase program in June. With our strong balance sheet and cash generation, today we are announcing an additional $100 million stock repurchase program for the second half of the year. The third quarter is off to a good start
for all three of our businesses, and we continue to expect another record year with strong margin expansion and profit growth.”

[0001193125-16-649843:8k_2_02:16]
FINANCIAL HIGHLIGHTS

[0001193125-16-649843:8k_2_02:17]
Revenue: Revenue for the second quarter was $1.019 billion, up 3% from the prior-year quarter. Foreign exchange was neutral to revenue. Volume and
price/mix were up on a revenue basis from the prior-year quarter.

[0001193125-16-649843:8k_2_02:18]
Gross Profit: Gross profit in the second quarter was $315 million, up 11% from
the prior-year quarter. Gross margin was 30.9%, up 230 basis points from the prior-year quarter. Gross profit was positively impacted by higher volume and lower material costs, with partial offsets from unfavorable foreign exchange and investments
in distribution expansion.

[0001193125-16-649843:8k_2_02:19]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the second quarter was $111.2
million, or $2.52 per share, compared to $81.6 million, or $1.79 per share, in the prior-year quarter.

[0001193125-16-649843:8k_2_02:20]
Adjusted income from continuing operations in the
second quarter was $111.5 million, or $2.53 per share, compared to $83.9 million, or $1.84 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the second quarter of 2016 excludes $0.3 million in after-tax charges:
$1.4 million for restructuring and other items, net, and a $1.1 million special legal contingency gain.

[0001193125-16-649843:8k_2_02:21]
Free Cash Flow and Total Debt: In the
second quarter, net cash from operations was $72 million, capital expenditures totaled $18 million, and free cash flow was $54 million. In the prior-year quarter, net cash from operations was $70 million, capital expenditures totaled $15 million,
and free cash flow was $55 million. Total debt at the end of the second quarter was $1.075 billion. Total cash and cash equivalents were $55 million at the end of the quarter. The company paid $16 million in dividends in the second quarter.

[0001193125-16-649843:8k_2_02:22]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-16-649843:8k_2_02:23]
Residential Heating & Cooling

[0001193125-16-649843:8k_2_02:24]
Revenue in the
Residential Heating & Cooling business segment was a record $575 million, up 4% from the prior-year quarter. Foreign exchange was neutral to revenue. Segment profit was a record $116 million, up 16% from the prior-year quarter. Segment
profit margin was a record 20.2%, up 220 basis points from the prior-year quarter. Results were impacted by higher volume and lower material costs, with partial offsets from unfavorable foreign exchange and investments in SG&A and distribution
expansion.

[0001193125-16-649843:8k_2_02:25]
Commercial Heating & Cooling

[0001193125-16-649843:8k_2_02:26]
Revenue in the Commercial Heating & Cooling business segment was $253 million in the second quarter, flat with the prior-year quarter. Foreign
exchange was neutral to revenue. Segment profit was a record $47 million, up 10% from the prior-year quarter. Segment profit margin was a record 18.7%, up 170 basis points from the prior-year quarter. Results were impacted by lower material costs
and favorable price/mix, with partial offsets from lower volume, unfavorable foreign exchange, and investments to support growth in the commercial services business.

[0001193125-16-649843:8k_2_02:27]
Refrigeration

[0001193125-16-649843:8k_2_02:28]
Revenue in the Refrigeration business
segment was $192 million in the second quarter, up 4%. At constant currency, revenue was up 6%. Segment profit was $21 million, up 60% from the prior-year quarter. Segment profit margin was 11.1%, up 390 basis points from the prior-year quarter.
Results were impacted by higher volume, lower material costs, lower factory costs and higher productivity, with partial offsets from unfavorable price/mix and foreign exchange.

[0001193125-16-649843:8k_2_02:29]
FULL-YEAR OUTLOOK

[0001193125-16-649843:8k_2_02:30]
For 2016, the company is reiterating
guidance for reported revenue growth and raising guidance for EPS from continuing operations.

[0001193125-16-649843:8k_2_02:31]
|  | • |  | Reiterating guidance for revenue growth of 3-7%. At constant currency, updating revenue growth guidance from 4-8% to 3-7%. |

[0001193125-16-649843:8k_2_02:32]
|  | • |  | Raising guidance for GAAP EPS from continuing operations from $6.26-$6.76 to a range of $6.45-$6.85. |

[0001193125-16-649843:8k_2_02:33]
|  | • |  | Raising guidance for adjusted EPS from continuing operations from $6.30-$6.80 to a range of $6.50-$6.90. |

[0001193125-16-649843:8k_2_02:34]
|  | • |  | Updating effective tax rate guidance from approximately 32% to approximately 31% on a full-year basis. |

[0001193125-16-649843:8k_2_02:35]
|  | • |  | Reiterating fully diluted share count guidance of approximately 44 million shares on a full-year basis. |

[0001193125-16-649843:8k_2_02:36]
|  | • |  | Reiterating capital expenditure guidance of approximately $95 million. |

[0001193125-16-649843:8k_2_02:37]
CONFERENCE CALL INFORMATION

[0001193125-16-649843:8k_2_02:38]
A conference call to discuss the company’s second quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call
line at 612-234-9960 at least 10 minutes prior to the scheduled start time and use reservation number 397031. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available
from 11:00 a.m. Central time on July 18 through midnight August 1, 2016 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 397031. The call also will be archived on the company’s web site.

[0001193125-16-649843:8k_2_02:39]
About Lennox International

[0001193125-16-649843:8k_2_02:40]
Lennox International Inc. is
a global leader in the heating, air conditioning, and refrigeration markets. Lennox International is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at:
www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-16-649843:8k_2_02:41]
Forward-Looking Statements

[0001193125-16-649843:8k_2_02:42]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-649843:8k_2_02:43]
Consolidated Statements of Operations

[0001193125-16-649843:8k_2_02:44]
(Unaudited)

[0001193125-16-649843:8k_2_02:45]
| (Amounts in millions, except per share data) |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 1,019.2 |  |  | $ | 992.5 |  |  | $ | 1,734.4 |  |  | $ | 1,678.3 |  |
| Cost of goods sold |  |  | 704.2 |  |  |  | 709.1 |  |  |  | 1,235.8 |  |  |  | 1,231.9 |  |
| Gross profit |  |  | 315.0 |  |  |  | 283.4 |  |  |  | 498.6 |  |  |  | 446.4 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 159.4 |  |  |  | 152.9 |  |  |  | 299.7 |  |  |  | 286.2 |  |
| Losses and other expenses, net |  |  | 0.4 |  |  |  | 3.3 |  |  |  | 4.7 |  |  |  | 8.9 |  |
| Restructuring charges |  |  | 0.8 |  |  |  | 1.8 |  |  |  | 0.6 |  |  |  | 2.1 |  |
| Income from equity method investments |  |  | (6.3 | ) |  |  | (5.5 | ) |  |  | (10.8 | ) |  |  | (8.8 | ) |
| Operating income |  |  | 160.7 |  |  |  | 130.9 |  |  |  | 204.4 |  |  |  | 158.0 |  |
| Interest expense, net |  |  | 6.8 |  |  |  | 6.4 |  |  |  | 12.7 |  |  |  | 12.2 |  |
| Other income, net |  |  | (0.2 | ) |  |  | — |  |  |  | (0.3 | ) |  |  | — |  |
| Income from continuing operations before income taxes |  |  | 154.1 |  |  |  | 124.5 |  |  |  | 192.0 |  |  |  | 145.8 |  |
| Provision for income taxes |  |  | 42.9 |  |  |  | 42.9 |  |  |  | 55.9 |  |  |  | 50.2 |  |
| Income from continuing operations |  |  | 111.2 |  |  |  | 81.6 |  |  |  | 136.1 |  |  |  | 95.6 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | (0.8 | ) |  |  | (0.7 | ) |  |  | (0.8 | ) |  |  | (0.8 | ) |
| Benefit from income taxes |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Loss from discontinued operations |  |  | (0.5 | ) |  |  | (0.4 | ) |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Net income |  | $ | 110.7 |  |  | $ | 81.2 |  |  | $ | 135.6 |  |  | $ | 95.1 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.55 |  |  | $ | 1.81 |  |  | $ | 3.11 |  |  | $ | 2.13 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 2.54 |  |  | $ | 1.80 |  |  | $ | 3.10 |  |  | $ | 2.12 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.52 |  |  | $ | 1.79 |  |  | $ | 3.07 |  |  | $ | 2.10 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 2.51 |  |  | $ | 1.78 |  |  | $ | 3.06 |  |  | $ | 2.09 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 43.6 |  |  |  | 45.0 |  |  |  | 43.8 |  |  |  | 44.9 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 44.1 |  |  |  | 45.6 |  |  |  | 44.4 |  |  |  | 45.6 |  |
| Cash dividends declared per share |  | $ | 0.43 |  |  | $ | 0.36 |  |  | $ | 0.79 |  |  | $ | 0.66 |  |

[0001193125-16-649843:8k_2_02:46]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-649843:8k_2_02:47]
Segment Net Sales and Profit (Loss)

[0001193125-16-649843:8k_2_02:48]
(Unaudited)

[0001193125-16-649843:8k_2_02:49]
| (Amounts in millions) |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 574.5 |  |  | $ | 555.1 |  |  | $ | 951.8 |  |  | $ | 917.7 |  |
| Commercial Heating & Cooling |  |  | 252.9 |  |  |  | 253.6 |  |  |  | 423.3 |  |  |  | 413.5 |  |
| Refrigeration |  |  | 191.8 |  |  |  | 183.8 |  |  |  | 359.3 |  |  |  | 347.1 |  |
|  |  | $ | 1,019.2 |  |  | $ | 992.5 |  |  | $ | 1,734.4 |  |  | $ | 1,678.3 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 115.9 |  |  | $ | 99.9 |  |  | $ | 154.1 |  |  | $ | 131.2 |  |
| Commercial Heating & Cooling |  |  | 47.4 |  |  |  | 43.0 |  |  |  | 61.7 |  |  |  | 50.7 |  |
| Refrigeration |  |  | 21.3 |  |  |  | 13.3 |  |  |  | 30.3 |  |  |  | 17.2 |  |
| Corporate and other |  |  | (23.5 | ) |  |  | (22.0 | ) |  |  | (38.4 | ) |  |  | (33.7 | ) |
| Total segment profit |  |  | 161.1 |  |  |  | 134.2 |  |  |  | 207.7 |  |  |  | 165.4 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | — |  |  |  | (1.1 | ) |  |  | (0.4 | ) |  |  | (1.4 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) |  |  | (0.4 | ) |  |  | 2.6 |  |  |  | 3.1 |  |  |  | 6.7 |  |
| Restructuring charges |  |  | 0.8 |  |  |  | 1.8 |  |  |  | 0.6 |  |  |  | 2.1 |  |
| Operating income |  | $ | 160.7 |  |  | $ | 130.9 |  |  | $ | 204.4 |  |  | $ | 158.0 |  |

[0001193125-16-649843:8k_2_02:50]
| (1) | The Company defines segment profit and loss as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-16-649843:8k_2_02:51]
|  | • |  | Special product quality adjustments; |

[0001193125-16-649843:8k_2_02:52]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-16-649843:8k_2_02:53]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-16-649843:8k_2_02:54]
|  | • |  | Special legal contingency charges, |

[0001193125-16-649843:8k_2_02:55]
|  | • |  | Asbestos-related litigation, |

[0001193125-16-649843:8k_2_02:56]
|  | • |  | Contractor tax payments, |

[0001193125-16-649843:8k_2_02:57]
|  | • |  | Environmental liabilities, and |

[0001193125-16-649843:8k_2_02:58]
|  | • |  | Other items, net; |

[0001193125-16-649843:8k_2_02:59]
|  | • |  | Restructuring charges; and |

[0001193125-16-649843:8k_2_02:60]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments. |

[0001193125-16-649843:8k_2_02:61]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-649843:8k_2_02:62]
Consolidated Balance Sheets

[0001193125-16-649843:8k_2_02:63]
| (Amounts in millions, except shares and par values) |  | As of June 30,2016 |  |  | As of December 31,2015 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 54.7 |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net of allowances of $7.4 and $6.3 in 2016 and 2015, respectively |  |  | 643.5 |  |  |  | 422.8 |  |
| Inventories, net |  |  | 505.7 |  |  |  | 418.8 |  |
| Other assets |  |  | 66.3 |  |  |  | 57.7 |  |
| Total current assets |  |  | 1,270.2 |  |  |  | 938.2 |  |
| Property, plant and equipment, net of accumulated depreciation of $707.5 and $706.2 in 2016 and 2015, respectively |  |  | 345.2 |  |  |  | 339.6 |  |
| Goodwill |  |  | 198.5 |  |  |  | 195.1 |  |
| Deferred income taxes |  |  | 145.0 |  |  |  | 145.7 |  |
| Other assets, net |  |  | 65.3 |  |  |  | 58.8 |  |
| Total assets |  | $ | 2,024.2 |  |  | $ | 1,677.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 225.4 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt |  |  | 230.8 |  |  |  | 31.0 |  |
| Accounts payable |  |  | 399.8 |  |  |  | 320.1 |  |
| Accrued expenses |  |  | 256.5 |  |  |  | 242.6 |  |
| Income taxes payable |  |  | 10.2 |  |  |  | 26.0 |  |
| Total current liabilities |  |  | 1,122.7 |  |  |  | 823.8 |  |
| Long-term debt |  |  | 619.0 |  |  |  | 506.0 |  |
| Post-retirement benefits, other than pensions |  |  | 2.9 |  |  |  | 4.1 |  |
| Pensions |  |  | 122.2 |  |  |  | 120.8 |  |
| Other liabilities |  |  | 126.0 |  |  |  | 121.1 |  |
| Total liabilities |  |  | 1,992.8 |  |  |  | 1,575.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 979.1 |  |  |  | 1,002.4 |  |
| Retained earnings |  |  | 1,247.9 |  |  |  | 1,146.7 |  |
| Accumulated other comprehensive loss |  |  | (186.6 | ) |  |  | (204.7 | ) |
| Treasury stock, at cost, 43,508,910 shares and 42,491,910 shares as of June 30, 2016 and December 31, 2015, respectively |  |  | (2,010.3 | ) |  |  | (1,844.1 | ) |
| Noncontrolling interests |  |  | 0.4 |  |  |  | 0.4 |  |
| Total stockholders’ equity |  |  | 31.4 |  |  |  | 101.6 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,024.2 |  |  | $ | 1,677.4 |  |

[0001193125-16-649843:8k_2_02:64]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-649843:8k_2_02:65]
Consolidated Statements of Cash
Flows

[0001193125-16-649843:8k_2_02:66]
(Unaudited)

[0001193125-16-649843:8k_2_02:67]
| (Amounts in millions) |  | For the Six Months EndedJune 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 135.6 |  |  | $ | 95.1 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (10.8 | ) |  |  | (8.8 | ) |
| Dividends from affiliates |  |  | 3.9 |  |  |  | 3.4 |  |
| Restructuring (gains) expenses, net of cash paid |  |  | (1.0 | ) |  |  | 1.2 |  |
| Provision for bad debts |  |  | 2.7 |  |  |  | 1.6 |  |
| Unrealized (gains) losses on derivative contracts |  |  | (1.9 | ) |  |  | 0.3 |  |
| Stock-based compensation expense |  |  | 14.8 |  |  |  | 10.8 |  |
| Depreciation and amortization |  |  | 28.5 |  |  |  | 30.6 |  |
| Deferred income taxes |  |  | (1.9 | ) |  |  | (0.9 | ) |
| Other items, net |  |  | 0.3 |  |  |  | 0.2 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (216.2 | ) |  |  | (199.2 | ) |
| Inventories |  |  | (80.6 | ) |  |  | (85.3 | ) |
| Other current assets |  |  | (6.7 | ) |  |  | (0.1 | ) |
| Accounts payable |  |  | 82.6 |  |  |  | 87.3 |  |
| Accrued expenses |  |  | 20.1 |  |  |  | 6.7 |  |
| Income taxes payable and receivable |  |  | (14.2 | ) |  |  | (1.4 | ) |
| Other |  |  | 3.8 |  |  |  | 6.2 |  |
| Net cash used in operating activities |  |  | (41.0 | ) |  |  | (52.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (41.7 | ) |  |  | (33.0 | ) |
| Net cash used in investing activities |  |  | (41.7 | ) |  |  | (33.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 0.5 |  |  |  | 0.4 |  |
| Asset securitization borrowings |  |  | 40.0 |  |  |  | 40.0 |  |
| Asset securitization payments |  |  | (20.0 | ) |  |  | (40.0 | ) |
| Long-term debt payments |  |  | (8.2 | ) |  |  | (23.0 | ) |
| Borrowings from credit facility |  |  | 1,184.5 |  |  |  | 999.0 |  |
| Payments on credit facility |  |  | (864.0 | ) |  |  | (845.5 | ) |
| Proceeds from employee stock purchases |  |  | 1.3 |  |  |  | 1.1 |  |
| Repurchases of common stock |  |  | (200.0 | ) |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (21.4 | ) |  |  | (21.8 | ) |
| Excess tax benefits related to share-based payments |  |  | 15.7 |  |  |  | 17.3 |  |
| Cash dividends paid |  |  | (31.8 | ) |  |  | (26.9 | ) |
| Net cash provided by financing activities |  |  | 96.6 |  |  |  | 100.6 |  |
| Increase in cash and cash equivalents |  |  | 13.9 |  |  |  | 15.3 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | 1.9 |  |  |  | (5.3 | ) |
| Cash and cash equivalents, beginning of period |  |  | 38.9 |  |  |  | 37.5 |  |
| Cash and cash equivalents, end of period |  | $ | 54.7 |  |  | $ | 47.5 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 12.4 |  |  | $ | 12.3 |  |
| Income taxes paid (net of refunds) |  | $ | 55.8 |  |  | $ | 34.4 |  |

[0001193125-16-649843:8k_2_02:68]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-649843:8k_2_02:69]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-16-649843:8k_2_02:70]
(Unaudited, in millions, except per share and ratio data)

[0001193125-16-649843:8k_2_02:71]
Use of Non-GAAP Financial Measures

[0001193125-16-649843:8k_2_02:72]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with
the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the
Company’s business trends and operating performance.

[0001193125-16-649843:8k_2_02:73]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from
Continuing Operations, a Non-GAAP measure

[0001193125-16-649843:8k_2_02:74]
|  |  | For the Three Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 154.1 |  |  | $ | (42.9 | ) |  | $ | 111.2 |  |  | $ | 124.5 |  |  | $ | (42.9 | ) |  | $ | 81.6 |  |
| Restructuring charges |  |  | 0.8 |  |  |  | (0.3 | ) |  |  | 0.5 |  |  |  | 1.9 |  |  |  | (0.6 | ) |  |  | 1.3 |  |
| Special product quality adjustments (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.2 | ) |  |  | 0.4 |  |  |  | (0.8 | ) |
| Special legal contingency charges (a) |  |  | (1.7 | ) |  |  | 0.6 |  |  |  | (1.1 | ) |  |  | 0.8 |  |  |  | (0.3 | ) |  |  | 0.5 |  |
| Asbestos-related litigation (a) |  |  | 1.1 |  |  |  | (0.4 | ) |  |  | 0.7 |  |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 0.3 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (b) |  |  | (0.3 | ) |  |  | 0.1 |  |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Environmental liabilities(a) |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 0.4 |  |  |  | (0.2 | ) |  |  | — |  |  |  | (0.2 | ) |
| Contractor tax payments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.6 |  |  |  | (0.5 | ) |  |  | 1.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 154.5 |  |  | $ | (43.0 | ) |  | $ | 111.5 |  |  | $ | 127.9 |  |  | $ | (44.0 | ) |  | $ | 83.9 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.52 |  |  |  |  |  |  |  |  |  |  | $ | 1.79 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |
| Special legal contingency charges(a) |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Asbestos-related litigation(a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.53 |  |  |  |  |  |  |  |  |  |  | $ | 1.84 |  |

[0001193125-16-649843:8k_2_02:75]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-16-649843:8k_2_02:76]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-16-649843:8k_2_02:77]
| (c) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-16-649843:8k_2_02:78]
|  |  | For the Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (c) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 192.0 |  |  | $ | (55.9 | ) |  | $ | 136.1 |  |  | $ | 145.8 |  |  | $ | (50.2 | ) |  | $ | 95.6 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | 0.4 |  |  |  | 2.2 |  |  |  | (0.7 | ) |  |  | 1.5 |  |
| Special product quality adjustments (b) |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |  |  | (1.4 | ) |  |  | 0.5 |  |  |  | (0.9 | ) |
| Special legal contingency charges (a) |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 4.2 |  |  |  | (1.6 | ) |  |  | 2.6 |  |
| Asbestos-related litigation (a) |  |  | 1.9 |  |  |  | (0.7 | ) |  |  | 1.2 |  |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.3 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (b) |  |  | (0.7 | ) |  |  | 0.2 |  |  |  | (0.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Environmental liabilities (a) |  |  | 1.1 |  |  |  | (0.2 | ) |  |  | 0.9 |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.4 |  |
| Contractor tax payments (a) |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.3 |  |  |  | 1.6 |  |  |  | (0.5 | ) |  |  | 1.1 |  |
| Other items (a) |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 0.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 195.4 |  |  | $ | (56.9 | ) |  | $ | 138.5 |  |  | $ | 153.3 |  |  | $ | (52.7 | ) |  | $ | 100.6 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 3.07 |  |  |  |  |  |  |  |  |  |  | $ | 2.10 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |
| Special legal contingency charges (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.06 |  |
| Asbestos-related litigation (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 3.12 |  |  |  |  |  |  |  |  |  |  | $ | 2.21 |  |

[0001193125-16-649843:8k_2_02:79]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-16-649843:8k_2_02:80]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-16-649843:8k_2_02:81]
| (c) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-16-649843:8k_2_02:82]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.9 |  |  | $ | 0.7 |  |
| Foreign currency exchange losses (a) |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 0.5 |  |  |  | 1.5 |  |
| Loss on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |
| Net change in unrealized (gains) losses on unsettled futures contracts (b) |  |  | (0.3 | ) |  |  | 0.1 |  |  |  | (0.7 | ) |  |  | — |  |
| Special legal contingency (gains) charges (b) |  |  | (1.7 | ) |  |  | 0.7 |  |  |  | — |  |  |  | 4.1 |  |
| Asbestos-related litigation (b) |  |  | 1.1 |  |  |  | 0.4 |  |  |  | 1.9 |  |  |  | 0.6 |  |
| Environmental liabilities (benefits) (b) |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 1.1 |  |  |  | 0.4 |  |
| Contractor tax payments (b) |  |  | — |  |  |  | 1.6 |  |  |  | 0.5 |  |  |  | 1.6 |  |
| Acquisition costs (b) |  |  | — |  |  |  | — |  |  |  | 0.4 |  |  |  | — |  |
| Losses and other expenses, net (pre-tax) |  | $ | 0.4 |  |  | $ | 3.3 |  |  | $ | 4.7 |  |  | $ | 8.9 |  |

[0001193125-16-649843:8k_2_02:83]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-16-649843:8k_2_02:84]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-16-649843:8k_2_02:85]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-16-649843:8k_2_02:86]
|  |  | For the YearEndedDecember 31,2016ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 6.50 - $6.90 |  |
| Special loss contingencies and other items |  |  | (0.05 | ) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 6.45-$6.85 |  |

[0001193125-16-649843:8k_2_02:87]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars
in millions)

[0001193125-16-649843:8k_2_02:88]
|  |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 72.4 |  |  | $ | 69.9 |  |  | $ | (41.0 | ) |  | $ | (52.3 | ) |
| Purchases of property, plant and equipment |  |  | (17.9 | ) |  |  | (15.0 | ) |  |  | (41.7 | ) |  |  | (33.0 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | 54.5 |  |  | $ | 54.9 |  |  | $ | (82.7 | ) |  | $ | (85.3 | ) |

[0001193125-16-649843:8k_2_02:89]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelveMonths toJune 30, 2016 |  |
| Adjusted EBIT (a) |  | $ | 420.0 |  |
| Depreciation and amortization expense (b) |  |  | 60.7 |  |
| EBITDA (a + b) |  | $ | 480.7 |  |
| Total debt at June 30, 2016 (c) |  |  | 1,075.1 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.2 |  |

[0001193125-16-649843:8k_2_02:90]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP
measure (dollars in millions)

[0001193125-16-649843:8k_2_02:91]
|  |  | TrailingTwelveMonths toJune 30, 2016 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 420.0 |  |
| Special product quality adjustments |  |  | (1.1 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 12.1 |  |
| Restructuring charges |  |  | 1.6 |  |
| Interest expense, net |  |  | 24.1 |  |
| Special inventory write down |  |  | 5.6 |  |
| Goodwill impairment |  |  | 5.5 |  |
| Asset impairment |  |  | 44.5 |  |
| Other expenses, net |  |  | (1.1 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 328.8 |  |
