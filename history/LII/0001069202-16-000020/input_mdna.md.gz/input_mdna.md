# LII MD&A — 0001069202-16-000020


## mdna

[0001069202-16-000020:mdna:1]
[same as prior period, unchanged from 0001069202-16-000017:mdna:1]

[0001069202-16-000020:mdna:2]
[same as prior period, unchanged from 0001069202-16-000017:mdna:2]

[0001069202-16-000020:mdna:3]
[same as prior period, unchanged from 0001069202-16-000017:mdna:3]

[0001069202-16-000020:mdna:4]
Our fiscal year ends on December 31 and our interim fiscal quarters are each comprised of 13 weeks.  For convenience, throughout this Management’s Discussion and Analysis of Financial Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.

[0001069202-16-000020:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned parts and supplies stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions, and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-16-000020:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated warranty costs, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components have impacted us and the HVACR industry in general.  We seek to mitigate the impact of volatility in commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-16-000020:mdna:7]
[same as prior period, unchanged from 0001069202-16-000017:mdna:7]

[0001069202-16-000020:mdna:8]
In the second quarter of 2016, the Residential Heating & Cooling segment continued to lead our overall operational performance with a 4% increase in net sales and a $16 million increase in segment profit compared to the second quarter of 2015.  The primary growth drivers for this segment were volume gains.  Our Refrigeration segment also performed well in the second quarter of 2016 with a 4% increase in net sales and $8 million in increased segment profit compared to the second quarter of 2015.  This segment's profits were up largely due to volume increases partially offset by unfavorable foreign currency exchange rates.  While sales in

[0001069202-16-000020:mdna:9]
our Commercial Heating & Cooling segment were relatively flat, the segment profit increased $4 million compared to the second quarter of 2015.  For this segment, lower sales volume was offset by higher price and mix.

[0001069202-16-000020:mdna:10]
[same as prior period, unchanged from 0001069202-16-000017:mdna:9]

[0001069202-16-000020:mdna:11]
[same as prior period, unchanged from 0001069202-16-000017:mdna:10]

[0001069202-16-000020:mdna:12]
| • | Net sales increased $26 million, or 3%, to $1,019 million in the second quarter of 2016 compared to $993 million in the second quarter of 2015. |

[0001069202-16-000020:mdna:13]
| • | Operating income in the second quarter of 2016 increased $30 million to $161 million from $131 million in the second quarter of 2015. |

[0001069202-16-000020:mdna:14]
| • | Net income for the second quarter of 2016 increased $30 million to $111 million from $81 million in the second quarter of 2015. |

[0001069202-16-000020:mdna:15]
| • | Diluted earnings per share from continuing operations were $2.52 per share in the second quarter of 2016 compared to $1.79 per share in the second quarter of 2015. |

[0001069202-16-000020:mdna:16]
| • | During the second quarter of 2016, we returned $16 million to shareholders through dividend payments. |

[0001069202-16-000020:mdna:17]
| • | Cash used in operating activities was $41 million in the first six months of 2016 compared to $52 million in the first six months of 2015. |

[0001069202-16-000020:mdna:18]
Second Quarter of 2016 Compared to Second Quarter of 2015 - Consolidated Results

[0001069202-16-000020:mdna:19]
[same as prior period, unchanged from 0001069202-16-000017:mdna:18]

[0001069202-16-000020:mdna:20]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales | $ | 1,019.2 |  |  | $ | 992.5 |  |  | 2.7 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 704.2 |  |  | 709.1 |  |  | 0.7 |  |  | 69.1 |  |  | 71.4 |  |
| Gross profit | 315.0 |  |  | 283.4 |  |  | 11.2 |  |  | 30.9 |  |  | 28.6 |  |
| Selling, general and administrative expenses | 159.4 |  |  | 152.9 |  |  | (4.3 | ) |  | 15.6 |  |  | 15.4 |  |
| Losses and other expenses, net | 0.4 |  |  | 3.3 |  |  | 87.9 |  |  | — |  |  | 0.3 |  |
| Restructuring charges | 0.8 |  |  | 1.8 |  |  | 55.6 |  |  | 0.1 |  |  | 0.2 |  |
| Income from equity method investments | (6.3 | ) |  | (5.5 | ) |  | 14.5 |  |  | (0.6 | ) |  | (0.6 | ) |
| Operating income | $ | 160.7 |  |  | $ | 130.9 |  |  | 22.8 | % |  | 15.8 | % |  | 13.2 | % |

[0001069202-16-000020:mdna:21]
[same as prior period, unchanged from 0001069202-16-000017:mdna:20]

[0001069202-16-000020:mdna:22]
Net sales increased 3% in the second quarter of 2016 compared to the second quarter of 2015, primarily from 2% higher sales volumes and 1% from price.  The Residential Heating & Cooling and Refrigeration segments delivered higher volume by capturing additional replacement and new construction business.

[0001069202-16-000020:mdna:23]
[same as prior period, unchanged from 0001069202-16-000017:mdna:22]

[0001069202-16-000020:mdna:24]
Gross profit margin in the second quarter of 2016 increased 230 basis points ("bps") to 30.9% compared to the second quarter of 2015.  Our profit margin increased 300 bps from lower material costs and 40 bps from factory productivity.  Offsetting this increase were decreases of 20 bps for unfavorable mix and price, 20 bps from unfavorable foreign currency exchange rates, 20 bps from combined freight and distribution, 10 bps for warranties, and 40 bps from other product costs.

[0001069202-16-000020:mdna:25]
[same as prior period, unchanged from 0001069202-16-000017:mdna:24]

[0001069202-16-000020:mdna:26]
Selling, general and administrative expenses, or SG&A, was $159 million in the second quarter of 2016 compared to $153 million in the second quarter of 2015, and as a percentage of net sales increased 20 bps to 15.6%.  SG&A expenses increased due to higher long-term incentive compensation costs and increased investment in information technology and research and

[0001069202-16-000020:mdna:27]
development.

[0001069202-16-000020:mdna:28]
[same as prior period, unchanged from 0001069202-16-000017:mdna:26]

[0001069202-16-000020:mdna:29]
Losses and other expenses, net for the second quarter of 2016 and 2015 included the following (in millions):

[0001069202-16-000020:mdna:30]
|  | For the Three Months Ended June 30, |
|  | 2016 |  | 2015 |
| Realized losses on settled future contracts | $ | 0.4 |  |  | $ | 0.3 |  |
| Foreign currency exchange losses | 0.3 |  |  | 0.4 |  |
| Loss on disposal of fixed assets | 0.1 |  |  | — |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.3 | ) |  | 0.1 |  |
| Special legal contingency (gains) charges | (1.7 | ) |  | 0.7 |  |
| Asbestos-related litigation | 1.1 |  |  | 0.4 |  |
| Contractor tax payments | — |  |  | 1.6 |  |
| Environmental liabilities (benefits) | 0.5 |  |  | (0.2 | ) |
| Losses and other expenses, net (pre-tax) | $ | 0.4 |  |  | $ | 3.3 |  |

[0001069202-16-000020:mdna:31]
The net change in unrealized (gains) losses on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements. The change in the special legal contingency charges resulted from lower estimated liabilities related to settled claims.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.  Contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.

[0001069202-16-000020:mdna:32]
[same as prior period, unchanged from 0001069202-16-000017:mdna:30]

[0001069202-16-000020:mdna:33]
Restructuring charges during the second quarter of 2016 relate to the demolition of a facility relating to a previous restructuring activity.  The restructuring charges in the second quarter of 2015 relate to the restructuring of our Australian operations in the Refrigeration segment.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000020:mdna:34]
[same as prior period, unchanged from 0001069202-16-000017:mdna:32]

[0001069202-16-000020:mdna:35]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $6 million in the second quarter of 2016 increased slightly from the second quarter of 2015.

[0001069202-16-000020:mdna:36]
[same as prior period, unchanged from 0001069202-16-000017:mdna:34]

[0001069202-16-000020:mdna:37]
Interest expense, net of $7 million in the second quarter of 2016 was up from $6 million as compared to the second quarter of 2015.

[0001069202-16-000020:mdna:38]
[same as prior period, unchanged from 0001069202-16-000017:mdna:36]

[0001069202-16-000020:mdna:39]
We expect our annual effective tax rate to be 31% in 2016 and subsequent years to be approximately 32% due to sustainable benefits from restructuring of our international subsidiaries that will enable us to utilize foreign tax credits and other benefits that drives our effective tax rate down by approximately 250 basis points.

[0001069202-16-000020:mdna:40]
The tax benefit resulting from a planned repatriation of earnings in 2016 was recognized in Q2 resulting in a quarterly effective rate of 27.8% and a year to date effective tax rate of 29.1%.

[0001069202-16-000020:mdna:41]
Second Quarter of 2016 Compared to Second Quarter of 2015 - Results by Segment

[0001069202-16-000020:mdna:42]
[same as prior period, unchanged from 0001069202-16-000017:mdna:39]

[0001069202-16-000020:mdna:43]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the second quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000020:mdna:44]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 574.5 |  |  | $ | 555.1 |  |  | $ | 19.4 |  |  | 3.5 | % |
| Profit | $ | 115.9 |  |  | $ | 99.9 |  |  | $ | 16.0 |  |  | 16.0 | % |
| % of net sales | 20.2 | % |  | 18.0 | % |  |  |  |  |

[0001069202-16-000020:mdna:45]
Net sales increased by 4% in the second quarter of 2016 compared to the second quarter of 2015.  Sales volumes increased by 3% and price and mix combined increased sales by 1%.

[0001069202-16-000020:mdna:46]
Segment profit for the second quarter of 2016 increased $16 million due to $4 million in higher sales volumes, $18 million in lower commodities and material cost and $3 million from factory productivity, which includes the addition of a second factory in Mexico.  Partially offsetting these increases was $3 million of SG&A expenses primarily for information technology and research and development investments, $2 million from unfavorable foreign currency exchange rates, $2 million in distribution investments, and $2 million from increases in other product costs.

[0001069202-16-000020:mdna:47]
[same as prior period, unchanged from 0001069202-16-000017:mdna:44]

[0001069202-16-000020:mdna:48]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000020:mdna:49]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 252.9 |  |  | $ | 253.6 |  |  | $ | (0.7 | ) |  | (0.3 | )% |
| Profit | $ | 47.4 |  |  | $ | 43.0 |  |  | $ | 4.4 |  |  | 10.2 | % |
| % of net sales | 18.7 | % |  | 17.0 | % |  |  |  |  |

[0001069202-16-000020:mdna:50]
Net sales were flat in the second quarter of 2016 compared to the second quarter of 2015.  Sales volumes decreased by 1%  and this volume decline was offset by a 1% increase in price and mix.

[0001069202-16-000020:mdna:51]
Segment profit in the second quarter of 2016 increased $4 million compared to the second quarter of 2015 due to $6 million in lower commodities and material cost and $3 million from combined price and mix.  Partially offsetting these increases was $1 million in lower sales volumes, $1 million from unfavorable foreign currency exchange rates, $1 million for investments in infrastructure for the North American Service business, $1 million in lower factory productivity and $1 million from increases in other product costs.

[0001069202-16-000020:mdna:52]
[same as prior period, unchanged from 0001069202-16-000017:mdna:49]

[0001069202-16-000020:mdna:53]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2016 and 2015 (dollars in millions):

[0001069202-16-000020:mdna:54]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 191.8 |  |  | $ | 183.8 |  |  | $ | 8.0 |  |  | 4.4 | % |
| Profit | $ | 21.3 |  |  | $ | 13.3 |  |  | $ | 8.0 |  |  | 60.2 | % |
| % of net sales | 11.1 | % |  | 7.2 | % |  |  |  |  |

[0001069202-16-000020:mdna:55]
Net sales increased 4% in the second quarter of 2016 compared to the second quarter of 2015.  Volume increased by 7%

[0001069202-16-000020:mdna:56]
primarily due to strong performance in North America industry growth and market share gains. Partially offsetting this volume growth was a 1% decline from price and mix and 2% reduction from unfavorable foreign currency exchange rates.

[0001069202-16-000020:mdna:57]
Segment profit for the second quarter of 2016 increased $8 million compared to the second quarter of 2015 due to $4 million in higher sales volumes, $6 million from lower commodities and material costs, $2 million from lower depreciation and amortization due to the impairment of our Kysor Warren business recorded in 2015 and $1 million in factory productivity and lower other product costs. Partially offsetting these increases was $3 million of unfavorable combined price and mix, $1 million in higher SG&A expenses and $1 million from unfavorable foreign currency exchange rates.

[0001069202-16-000020:mdna:58]
[same as prior period, unchanged from 0001069202-16-000017:mdna:54]

[0001069202-16-000020:mdna:59]
Corporate and other expenses increased $2 million to $24 million in the second quarter of 2016 from $22 million in the second quarter of 2015 due to $5 million of higher incentive compensation and general wage inflation.  Partially offsetting these increases was $3 million in lower health care expenses.

[0001069202-16-000020:mdna:60]
Year-to-Date through June 30, 2016 Compared to Year-to-Date through June 30, 2015 - Consolidated Results

[0001069202-16-000020:mdna:61]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-16-000020:mdna:62]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales | $ | 1,734.4 |  |  | $ | 1,678.3 |  |  | 3.3 |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,235.8 |  |  | 1,231.9 |  |  | (0.3 | ) |  | 71.3 |  |  | 73.4 |  |
| Gross profit | 498.6 |  |  | 446.4 |  |  | 11.7 |  |  | 28.7 |  |  | 26.6 |  |
| Selling, general and administrative expenses | 299.7 |  |  | 286.2 |  |  | (4.7 | ) |  | 17.3 |  |  | 17.1 |  |
| Losses and other expenses, net | 4.7 |  |  | 8.9 |  |  | 47.2 |  |  | 0.2 |  |  | 0.5 |  |
| Restructuring charges | 0.6 |  |  | 2.1 |  |  | 71.4 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (10.8 | ) |  | (8.8 | ) |  | 22.7 |  |  | (0.6 | ) |  | (0.5 | ) |
| Operating income | $ | 204.4 |  |  | $ | 158.0 |  |  | 29.4 |  |  | 11.8 | % |  | 9.4 | % |

[0001069202-16-000020:mdna:63]
Net Sales

[0001069202-16-000020:mdna:64]
Net sales increased 3% in the first six months of 2016 compared to the first six months of 2015, with sales volumes up 4%.  The volume increases were driven by our Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments all capturing additional replacement and new construction business.  Partially offsetting these increases was a 1% decrease from unfavorable foreign currency exchange rates.

[0001069202-16-000020:mdna:65]
Gross Profit

[0001069202-16-000020:mdna:66]
Gross profit margins in the first six months of 2016 increased 210 bps to 28.7% compared to the first six months of 2015.  Our profit margin increased 300 bps from material cost savings and 40 bps from factory productivity.   Offsetting these  increases were decreases of 60 bps for unfavorable mix and price, 40 bps from unfavorable foreign currency exchange rates, 10 bps for warranties, and 20 bps from other product costs.

[0001069202-16-000020:mdna:67]
Selling, General and Administrative Expenses

[0001069202-16-000020:mdna:68]
SG&A was $300 million for the first six months of 2016 compared to $286 million for the first six months of 2015, and as a percentage of net sales, increased 20 bps from 17.3% to 17.1%.  SG&A expenses have increased due to higher long-term incentive compensation costs.

[0001069202-16-000020:mdna:69]
Losses and Other Expenses, Net

[0001069202-16-000020:mdna:70]
Losses and other expenses, net for the first six months of 2016 and 2015 included the following (in millions):

[0001069202-16-000020:mdna:71]
|  | For the Six Months Ended June 30, |
|  | 2016 |  | 2015 |
| Realized losses on settled future contracts | $ | 0.9 |  |  | $ | 0.7 |  |
| Foreign currency exchange losses | 0.5 |  |  | 1.5 |  |
| Loss on disposal of fixed assets | 0.1 |  |  | — |  |
| Net change in unrealized gains on unsettled futures contracts | (0.7 | ) |  | — |  |
| Special legal contingency charges | — |  |  | 4.1 |  |
| Asbestos-related litigation | 1.9 |  |  | 0.6 |  |
| Environmental liabilities | 1.1 |  |  | 0.4 |  |
| Contractor tax payments | 0.5 |  |  | 1.6 |  |
| Acquisition costs | 0.4 |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 4.7 |  |  | $ | 8.9 |  |

[0001069202-16-000020:mdna:72]
The net change in unrealized losses (gains) on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.  Contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.

[0001069202-16-000020:mdna:73]
Restructuring Charges

[0001069202-16-000020:mdna:74]
Restructuring charges during the first six months of 2016 relate to the demolition of a facility relating to a previous restructuring activity.  The restructuring charges in the first six months of 2015 relate to the restructuring of our Australian operations in the Refrigeration segment.    For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000020:mdna:75]
Income from Equity Method Investments

[0001069202-16-000020:mdna:76]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments increased to $11 million in the first six months of 2016 as compared to $9 million in the first six months of 2015.

[0001069202-16-000020:mdna:77]
Interest Expense, net

[0001069202-16-000020:mdna:78]
Interest expense, net of $13 million in the first six months of 2016 increased from $12 million in the first six months of 2015 due to an increase in our average net borrowings.

[0001069202-16-000020:mdna:79]
Income Taxes

[0001069202-16-000020:mdna:80]
We expect our annual effective tax rate to be 31% in 2016 and subsequent years to be approximately 32% due to sustainable benefits from restructuring of our international subsidiaries that will enable us to utilize foreign tax credits and other benefits that drives our effective tax rate down by approximately 250 basis points.

[0001069202-16-000020:mdna:81]
The tax benefit resulting from a planned repatriation of earnings in 2016 was recognized in Q2 resulting in a quarterly effective rate of 27.8% and a year to date effective tax rate of 29.1%.

[0001069202-16-000020:mdna:82]
Year-to-Date through June 30, 2016 Compared to Year-to-Date through June 30, 2015 - Results by Segment

[0001069202-16-000020:mdna:83]
Residential Heating & Cooling

[0001069202-16-000020:mdna:84]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first six months of 2016 and 2015 (dollars in millions):

[0001069202-16-000020:mdna:85]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 951.8 |  |  | $ | 917.7 |  |  | $ | 34.1 |  |  | 3.7 | % |
| Profit | $ | 154.1 |  |  | $ | 131.2 |  |  | $ | 22.9 |  |  | 17.5 | % |
| % of net sales | 16.2 | % |  | 14.3 | % |  |  |  |  |

[0001069202-16-000020:mdna:86]
Net sales increased by 4%  in the first six months of 2016 compared to the first six months of 2015.  Sales volumes increased net sales by 3% due to industry growth and market share gains and the benefits of favorable price and mix contributed 1%.

[0001069202-16-000020:mdna:87]
Segment profit for the first six months of 2016 increased $23 million due to $32 million in lower commodities and material costs, $9 million from higher sales volume and $5 million from favorable factory productivity which includes the addition of a second factory in Mexico.  Partially offsetting these increases was $11 million from unfavorable price and mix combined, $4 million of unfavorable foreign currency exchange rates, $2 million in distribution investments and $6 million of SG&A expenses to support wage inflation and investments in information technology and research and development.

[0001069202-16-000020:mdna:88]
Commercial Heating & Cooling

[0001069202-16-000020:mdna:89]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first six months of 2016 and 2015 (dollars in millions):

[0001069202-16-000020:mdna:90]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 423.3 |  |  | $ | 413.5 |  |  | $ | 9.8 |  |  | 2.4 | % |
| Profit | $ | 61.7 |  |  | $ | 50.7 |  |  | $ | 11.0 |  |  | 21.7 | % |
| % of net sales | 14.6 | % |  | 12.3 | % |  |  |  |  |

[0001069202-16-000020:mdna:91]
Commercial Heating & Cooling net sales increased by 2% in the first six months of 2016 compared to the first six months of 2015. Sales volumes increased net sales by 2%, price and mix increased sales by 1% and changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-16-000020:mdna:92]
Segment profit in the first six months of 2016 increased $11 million compared to the first six months of 2015.  The benefits of $3 million from incremental volume, $9 million from lower commodities and material costs, $4 million from price and mix and $1 million from lower freight and distribution expenses were partially offset by $3 million in lower factory productivity and other product costs, $1 million of higher SG&A expenses, $1 million for investments in infrastructure for the North American Service business and $1 million from changes in foreign currency exchange rates.

[0001069202-16-000020:mdna:93]
Refrigeration

[0001069202-16-000020:mdna:94]
The following table presents our Refrigeration segment's net sales and profit for the first six months of 2016 and 2015 (dollars in millions):

[0001069202-16-000020:mdna:95]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 359.3 |  |  | $ | 347.1 |  |  | $ | 12.2 |  |  | 3.5 | % |
| Profit | $ | 30.3 |  |  | $ | 17.2 |  |  | $ | 13.1 |  |  | 76.2 | % |
| % of net sales | 8.4 | % |  | 5.0 | % |  |  |  |  |

[0001069202-16-000020:mdna:96]
Refrigeration net sales increased 4% in the first six months of 2016 compared to the first six months of 2015 primarily due 7% volume growth led by our North American supermarket businesses.  This volume increase was partially offset by a 2% impact from unfavorable foreign exchange rates and a 1% impact from price and mix reductions.

[0001069202-16-000020:mdna:97]
Segment profit for the first six months of 2015 increased $13 million compared to the first six months of 2015 primarily due to $7 million from increased sales volumes, $9 million in lower commodities and material costs, $3 million from lower depreciation and amortization due to the impairment of our Kysor Warren business recorded in 2015 and $2 million in factory productivity and other product costs.  Partially offsetting these increases were $6 million from unfavorable price and mix combined, $1 million from higher SG&A expenses and $1 million from changes in foreign currency exchange rates.

[0001069202-16-000020:mdna:98]
Corporate and Other

[0001069202-16-000020:mdna:99]
Corporate and other expenses increased $4 million to $38 million in the first six months of 2016 from $34 million in the first six months of 2015 due primarily to incentive compensation and general wage inflation with partial offsets from lower health care costs.

[0001069202-16-000020:mdna:100]
[same as prior period, unchanged from 0001069202-16-000017:mdna:56]

[0001069202-16-000020:mdna:101]
[same as prior period, unchanged from 0001069202-16-000017:mdna:57]

[0001069202-16-000020:mdna:102]
[same as prior period, unchanged from 0001069202-16-000017:mdna:58]

[0001069202-16-000020:mdna:103]
The following table summarizes our cash flow activity for the six months ended June 30, 2016 and 2015 (in millions):

[0001069202-16-000020:mdna:104]
|  | For the Six Months Ended June 30, |
|  | 2016 |  | 2015 |
| Net cash used in operating activities | $ | (41.0 | ) |  | $ | (52.3 | ) |
| Net cash used in investing activities | (41.7 | ) |  | (33.0 | ) |
| Net cash provided by financing activities | 96.6 |  |  | 100.6 |  |

[0001069202-16-000020:mdna:105]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first six months of 2016 and 2015 reflects the seasonal increase in working capital requirements.  The $11 million decrease in net cash used in operating activities is primarily attributable to the seasonal increase in working capital requirements in 2016 being smaller than the increase in 2015.

[0001069202-16-000020:mdna:106]
Net Cash Used in Investing Activities - Capital expenditures were $42 million and $33 million in the first six months of 2016 and 2015, respectively.  Capital expenditures in 2016 were primarily related to investments in systems and software to support the overall enterprise and continued investments in our distribution network.

[0001069202-16-000020:mdna:107]
Net Cash Provided by Financing Activities - Net cash provided by financing activities decreased to $97 million in the first six months of 2016 primarily due to an increase in stock repurchases partially offset by increases in borrowings.   Net borrowings were higher in 2016 to support the increased stock repurchases and dividend payments.  Final settlement of the $200 million Accelerated Share Repurchase Plan (ASR) executed in the first quarter of 2016 was in the third quarter of 2016.

[0001069202-16-000020:mdna:108]
[same as prior period, unchanged from 0001069202-16-000017:mdna:64]

[0001069202-16-000020:mdna:109]
The following table details our lines of credit and financing arrangements as of June 30, 2016 (in millions):

[0001069202-16-000020:mdna:110]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 5.4 |  |
| Asset Securitization Program (1) | 220.0 |  |
| Total short-term debt | $ | 225.4 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 1.0 |  |
| Domestic credit facility (2) | 30.0 |  |
| Senior unsecured notes | 200.0 |  |
| Debt issuance costs | (0.2 | ) |
| Total current maturities of long-term debt | $ | 230.8 |  |
| Long-term debt: |  |
| Capital lease obligations | 15.2 |  |
| Domestic credit facility (2) | 606.0 |  |
| Debt issuance costs | (2.2 | ) |
| Total long-term debt | 619.0 |  |
| Total debt | $ | 1,075.2 |  |

[0001069202-16-000020:mdna:111]
(1) The maximum securitization amount ranges from $180.0 million to $220.0 million, depending on the period, before consideration of the July 5, 2016 amendment.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.

[0001069202-16-000020:mdna:112]
(2) The available future borrowings on our domestic credit facility are $279.6 million after being reduced by the outstanding borrowings and $4.4 million in outstanding standby letters of credit.  We also had $40.8 million in outstanding standby letters of credit outside of the domestic credit facility as of June 30, 2016.

[0001069202-16-000020:mdna:113]
[same as prior period, unchanged from 0001069202-16-000017:mdna:69]

[0001069202-16-000020:mdna:114]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 97.2% at June 30, 2016 from 87.9% at December 31, 2015.

[0001069202-16-000020:mdna:115]
As of June 30, 2016, our senior credit ratings were Baa3 with a stable outlook, after a June 23, 2016 upgrade by Moody's, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-16-000020:mdna:116]
[same as prior period, unchanged from 0001069202-16-000017:mdna:72]

[0001069202-16-000020:mdna:117]
We believe our cash and cash equivalents of $55 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $55 million as of June 30, 2016 was $29.1 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States. If we were to repatriate foreign earnings, we would be required to accrue and pay taxes in the United States, less foreign tax credits, for the amounts that were repatriated.  However, an additional benefit of the tax reorganization discussed previously is our ability to repatriate cash generated in prior periods in a tax efficient manner. We plan to repatriate $50 million in cash from foreign subsidiaries and contribute the $50 million to our pension plans in 2016.

[0001069202-16-000020:mdna:118]
Our expected capital expenditures for 2016 are $95 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with the completion of our $200 million accelerated share repurchase program in 2016, the plan to complete another $100 million stock repurchase program in 2016, and a target of between $65 million and $75 million of dividend payments in 2016.

[0001069202-16-000020:mdna:119]
[same as prior period, unchanged from 0001069202-16-000017:mdna:75]

[0001069202-16-000020:mdna:120]
[same as prior period, unchanged from 0001069202-16-000017:mdna:76]

[0001069202-16-000020:mdna:121]
Commitments, Contingencies and Guarantees

[0001069202-16-000020:mdna:122]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000020:mdna:123]
[same as prior period, unchanged from 0001069202-16-000017:mdna:79]

[0001069202-16-000020:mdna:124]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We will adopt the new standard using the modified retrospective approach and are still determining the effect of the standard on our ongoing financial reporting.

[0001069202-16-000020:mdna:125]
In January 2015, the FASB issued ASU No. 2015-01, Income Statement - Extraordinary and Unusual Items (Subtopic 225-20): Simplifying Income Statement Presentation by Eliminating the Concept of Extraordinary Items. ASU No. 2015-01 eliminates the concept of an extraordinary item from GAAP. As a result, an entity will no longer be required to separately present an extraordinary item on its statement of operations, net of tax, after income from continuing operations or to disclose income taxes and net income per share data applicable to an extraordinary item. However, ASU No. 2015-01 will still retain the presentation and disclosure guidance for items that are unusual in nature and occur infrequently. ASU No. 2015-01 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period, although early adoption is permitted. The adoption of this standard did not materially impact our consolidated financial statements.

[0001069202-16-000020:mdna:126]
In February 2015, the FASB issued ASU 2015-02, Consolidation: Amendments to the Consolidation Analysis, or ASU 2015-02, which amends the criteria for determining which entities are considered variable interest entities (“VIEs”), amends the criteria for determining if a service provider possesses a variable interest in a VIE and ends the deferral granted to investment companies for application of the VIE consolidation model. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015 and early adoption is permitted. The adoption of this standard did not materially impact our consolidated financial statements.

[0001069202-16-000020:mdna:127]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015, and early adoption is permitted. The adoption of this standard did not materially impact our consolidated financial statements.

[0001069202-16-000020:mdna:128]
In November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes (Topic 740) that simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. We adopted this standard retrospectively as of December 31, 2015.

[0001069202-16-000020:mdna:129]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001069202-16-000020:mdna:130]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. The ASU includes multiple provisions intended to simplify various aspects of the accounting for share-based payments. Excess tax benefits for share-based payments will be recorded as a reduction of income taxes and reflected in operating cash flows upon the adoption of this ASU.  Excess tax benefits are currently recorded in equity and as financing activity under the current rules. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2016.
