# LII MD&A — 0001069202-21-000007


## mdna

[0001069202-21-000007:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-21-000007:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the Consolidated Financial Statements and related Notes to the Consolidated Financial Statements in Item 8, “Other Financial Statement Details,” of this Annual Report on Form 10-K.

[0001069202-21-000007:mdna:3]
Business Overview

[0001069202-21-000007:mdna:4]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 3 in the Notes to the Consolidated Financial Statements.

[0001069202-21-000007:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-21-000007:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-21-000007:mdna:7]
Impact of COVID-19 Pandemic and the Resulting Changes to our 2020 Financial Performance

[0001069202-21-000007:mdna:8]
A novel strain of coronavirus or, COVID-19, surfaced in late 2019 and has spread around the world. In 2020, the spread of COVID-19 and the developments surrounding the global pandemic disrupted our business operations and affected our results of operations. For example, in response to the COVID-19 pandemic, various national, state, and local governments where we, our suppliers, and our customers operate issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work. Those decrees resulted in supply chain disruption, higher absenteeism in our factories, and negatively impacted net sales for our Commercial and Refrigeration segments. Additionally, certain of our manufacturing facilities experienced short-term suspensions of operations for COVID-19 employee health concerns. We implemented several cost reduction actions in the second quarter of 2020, including employee terminations, temporary facility closures and cancellations of certain sales and marketing activities, and revised our financial outlook downward to account for COVID-19’s expected economic impact on our Company and future uncertainty.

[0001069202-21-000007:mdna:9]
As the COVID-19 pandemic continues, health concern risks remain, and we cannot predict whether any of our manufacturing, operational or distribution facilities will experience disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected.

[0001069202-21-000007:mdna:10]
If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 would continue to impact our results of operations, financial position and cash flows.

[0001069202-21-000007:mdna:11]
Financial Highlights

[0001069202-21-000007:mdna:12]
•Net sales decreased $173 million, or 5%, to $3,634 million in 2020 from $3,807 million in 2019.

[0001069202-21-000007:mdna:13]
•Operating income in 2020 was $479 million compared to $657 million in 2019, which included $179 million net gain from insurance recoveries.

[0001069202-21-000007:mdna:14]
•Net income in 2020 decreased to $356 million from $409 million in 2019.

[0001069202-21-000007:mdna:15]
•Diluted earnings per share from continuing operations were $9.26 per share in 2020 compared to $10.38 per share in 2019.

[0001069202-21-000007:mdna:16]
•We generated $612 million of cash flow from operating activities in 2020 compared to $396 million in 2019.  The

[0001069202-21-000007:mdna:17]
increase was primarily due to a decrease in working capital.

[0001069202-21-000007:mdna:18]
•In 2020, we returned $118 million to shareholders through dividend payments and we used $100 million to purchase 0.4 million shares of stock under our Share Repurchase Plans.

[0001069202-21-000007:mdna:19]
Overview of Results

[0001069202-21-000007:mdna:20]
Results for the year were mixed and adversely impacted by the economic downturn caused by the COVID-19 pandemic.  The Residential Heating & Cooling segment performed well in 2020, with a 3% increase in net sales and a $36 million decrease in segment profit compared to 2019 primarily due to the insurance proceeds received for lost profits in 2019.  Our Commercial Heating & Cooling segment saw a decrease in net sales of 15% and a $29 million decrease in segment profit compared to 2019 primarily due to lower sales volumes.  Sales in our Refrigeration segment decreased 17% and segment profit decreased $29 million compared to 2019 primarily due to lower sales volume and the loss of sales volume from our divested Kysor Warren business.

[0001069202-21-000007:mdna:21]
Results of Operations

[0001069202-21-000007:mdna:22]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-21-000007:mdna:23]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 3,634.1 |  |  | 100.0 | % |  | $ | 3,807.2 |  |  | 100.0 | % |  | $ | 3,883.9 |  |  | 100.0 | % |
| Cost of goods sold | 2,594.0 |  |  | 71.4 | % |  | 2,727.4 |  |  | 71.6 | % |  | 2,772.7 |  |  | 71.4 | % |
| Gross profit | 1,040.1 |  |  | 28.6 | % |  | 1,079.8 |  |  | 28.4 | % |  | 1,111.2 |  |  | 28.6 | % |
| Selling, general and administrative expenses | 555.9 |  |  | 15.3 | % |  | 585.9 |  |  | 15.4 | % |  | 608.2 |  | 15.7 | % |
| Losses (gains) and other expenses, net | 7.4 |  |  | 0.2 | % |  | 8.3 |  |  | 0.2 | % |  | 13.4 |  | 0.3 | % |
| Restructuring charges | 10.8 |  |  | 0.3 | % |  | 10.3 |  |  | 0.3 | % |  | 3.0 |  | 0.1 | % |
| Loss (gain), net on sale of businesses and related property | — |  |  | — | % |  | 10.6 |  |  | 0.3 | % |  | 27.0 |  |  | 0.7 | % |
| Loss (gain) from natural disasters, net of insurance recoveries | 3.1 |  |  | 0.1 | % |  | (178.8) |  |  | (4.7) | % |  | (38.3) |  |  | (1.0) | % |
| Income from equity method investments | (15.6) |  |  | (0.4) | % |  | (13.4) |  |  | (0.4) | % |  | (12.0) |  |  | (0.3) | % |
| Operating income | $ | 478.5 |  |  | 13.2 | % |  | $ | 656.9 |  |  | 17.3 | % |  | $ | 509.9 |  |  | 13.1 | % |
| Loss from discontinued operations | (0.8) |  |  | — | % |  | (0.1) |  |  | — | % |  | (1.3) |  |  | — | % |
| Net income | $ | 356.3 |  |  | 9.8 | % |  | $ | 408.7 |  |  | 10.7 | % |  | $ | 359.0 |  |  | 9.2 | % |

[0001069202-21-000007:mdna:24]
Year Ended December 31, 2020 Compared to Year Ended December 31, 2019 - Consolidated Results

[0001069202-21-000007:mdna:25]
Net Sales

[0001069202-21-000007:mdna:26]
Net sales decreased 5% in 2020 compared to 2019, driven by lower sales volumes of 5% and a 1% decline related to the sale of our Kysor Warren business in the first quarter of 2019, partially offset by improved combined price and mix of 1%.   The decrease in sales volume was primarily due to the impact of the COVID-19 pandemic on our Commercial and Refrigeration segments.

[0001069202-21-000007:mdna:27]
Gross Profit

[0001069202-21-000007:mdna:28]
Gross profit margins for 2020 increased 20 basis points (“bps”) to 28.6% compared to 28.4% in 2019.  We saw margin increases of 90 bps from engineering and sourcing led cost reductions, 70 bps from lower commodity costs, and 20 bps from lower freight and distribution costs.  These were partially offset by 120 bps from unfavorable combined price and mix, 30 bps from higher product warranties, and 10 bps from other product costs.

[0001069202-21-000007:mdna:29]
Selling, General and Administrative Expenses

[0001069202-21-000007:mdna:30]
SG&A expenses decreased by $30 million in 2020 compared to 2019.  As a percentage of net sales, SG&A expenses decreased 10 bps from 15.4% to 15.3% in the same periods primarily due to lower discretionary expenditures.

[0001069202-21-000007:mdna:31]
Losses (Gains) and Other Expenses, Net

[0001069202-21-000007:mdna:32]
Losses (gains) and other expenses, net for 2020 and 2019 included the following (in millions):

[0001069202-21-000007:mdna:33]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |
| Realized losses on settled futures contracts | $ | 0.1 |  |  | $ | 0.4 |  |
| Foreign currency exchange losses | (3.6) |  |  | (1.5) |  |
| Loss on disposal of fixed assets | (0.2) |  |  | (0.2) |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.3) |  |  | (0.5) |  |
| Other operating (gains) losses, net | (2.2) |  |  | (1.7) |  |
| Special legal contingency charges | 1.1 |  |  | 1.2 |  |
| Asbestos charges | 5.6 |  |  | 3.1 |  |
| Environmental liabilities | (1.4) |  |  | 5.7 |  |
| Losses from pandemic | 8.3 |  |  | — |  |
| Other items, net | — |  |  | 1.8 |  |
| Losses (gains) and other expenses, net | $ | 7.4 |  |  | $ | 8.3 |  |

[0001069202-21-000007:mdna:34]
The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and sanitization supplies to ensure the health and safety of our employees.  The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-21-000007:mdna:35]
Foreign currency exchange gains increased in 2020 primarily due to strengthening in foreign exchange rates in our primary markets.  The special legal contingency charges in 2020 relate to outstanding legal settlements.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001069202-21-000007:mdna:36]
Restructuring Charges

[0001069202-21-000007:mdna:37]
Restructuring charges were $10.8 million in 2020 compared to $10.3 million in 2019. The charges in 2020 related primarily to several cost reduction actions taken in response to the economic impact of the COVID-19 pandemic on our business.  These actions consisted of employee terminations for positions that were no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities.  For more information on our restructuring activities, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-21-000007:mdna:38]
Goodwill

[0001069202-21-000007:mdna:39]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2020.  We did not record any goodwill impairments in 2019 or 2020.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-21-000007:mdna:40]
Asset Impairments

[0001069202-21-000007:mdna:41]
We did not have any impairments of assets related to continuing operations in 2020 or 2019.

[0001069202-21-000007:mdna:42]
Pension Settlement

[0001069202-21-000007:mdna:43]
In the second and fourth quarters of 2019, we entered into agreements to purchase group annuity contracts and transfer certain pension assets and related pension benefit obligations to Pacific Life Insurance Company.  We recognized $99.2 million of pension settlement charges related to these transactions.  We did not have significant pension buyout activity in 2020.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001069202-21-000007:mdna:44]
Income from Equity Method Investments

[0001069202-21-000007:mdna:45]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $16 million in 2020 compared to $13 million in 2019.  The increase is due to improved operating performance at the joint ventures.

[0001069202-21-000007:mdna:46]
Interest Expense, net

[0001069202-21-000007:mdna:47]
Net interest expense of $28 million in 2020 decreased from $48 million in 2019 primarily due to lower borrowing and lower borrowing costs.

[0001069202-21-000007:mdna:48]
Income Taxes

[0001069202-21-000007:mdna:49]
The income tax provision was $88 million in 2020 compared to $99 million in 2019, and the effective tax rate was 19.8% in 2020 compared to 19.5% in 2019.  The 2020 and 2019 effective tax rates differ from the statutory rate of 21% primarily due to state and foreign taxes. Refer to Note 13 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001069202-21-000007:mdna:50]
Loss from Discontinued Operations

[0001069202-21-000007:mdna:51]
Losses from discontinued operations were $1 million in 2020 which primarily relate to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001069202-21-000007:mdna:52]
Year Ended December 31, 2020 Compared to Year Ended December 31, 2019 - Results by Segment

[0001069202-21-000007:mdna:53]
Residential Heating & Cooling

[0001069202-21-000007:mdna:54]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2020 and 2019 (dollars in millions):

[0001069202-21-000007:mdna:55]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 2,361.5 |  |  | $ | 2,291.1 |  |  | $ | 70.4 |  |  | 3% |
| Profit | $ | 428.5 |  |  | $ | 464.6 |  |  | $ | (36.1) |  |  | (8)% |
| % of net sales | 18.1 | % |  | 20.3 | % |  |  |  |  |

[0001069202-21-000007:mdna:56]
Residential Heating & Cooling net sales increased 3% in 2020 compared to 2019. Sales volume increased 2% and price and mix combined increased 1%.

[0001069202-21-000007:mdna:57]
Segment profit in 2020 declined $36 million compared to 2019 due to $99 million of non-recurring insurance proceeds for lost profits related to the Marshalltown tornado, $10 million of higher warranty and other product costs, $5 million of higher tariffs on Chinese imports, $3 million of combined price and mix, and $1 million of factory inefficiency. Partially offsetting these declines was $25 million of lower SG&A, $25 million of engineering and sourcing led cost reductions, $17 million from lower commodity costs, $8 million of lower freight and distribution expense, $5 million of higher sales volume, and $2 million of higher income from equity method investments.

[0001069202-21-000007:mdna:58]
Commercial Heating & Cooling

[0001069202-21-000007:mdna:59]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2020 and 2019 (dollars in millions):

[0001069202-21-000007:mdna:60]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 800.9 |  |  | $ | 947.4 |  |  | $ | (146.5) |  |  | (15) | % |
| Profit | $ | 136.9 |  |  | $ | 165.4 |  |  | $ | (28.5) |  |  | (17) | % |
| % of net sales | 17.1 | % |  | 17.5 | % |  |  |  |  |

[0001069202-21-000007:mdna:61]
Commercial Heating & Cooling net sales decreased 15% in 2020 compared to 2019.  Sales volume was 14% lower and price and mix combined decreased 1%.

[0001069202-21-000007:mdna:62]
Segment profit in 2020 decreased $29 million compared to 2019 due to $47 million of lower sales volume and $10 million of unfavorable mix.  Partially offsetting these declines was $9 million of lower SG&A, $7 million of engineering and sourcing led cost reductions, $6 million from lower commodity costs, $2 million of factory productivity, $2 million of other product costs, $1 million of lower tariffs on Chinese imports, and $1 million of favorable foreign currency exchange rates.

[0001069202-21-000007:mdna:63]
Refrigeration

[0001069202-21-000007:mdna:64]
The following table presents our Refrigeration segment’s net sales and profit for 2020 and 2019 (dollars in millions):

[0001069202-21-000007:mdna:65]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 471.7 |  |  | $ | 568.7 |  |  | $ | (97.0) |  |  | (17) | % |
| Profit | $ | 32.8 |  |  | $ | 61.3 |  |  | $ | (28.5) |  |  | (46) | % |
| % of net sales | 7.0 | % |  | 10.8 | % |  |  |  |  |

[0001069202-21-000007:mdna:66]
Net sales decreased 17% in 2020 compared to 2019.  Sales volume was 13% lower and the loss of sales from our divested Kysor Warren business contributed 6% which was partially offset by 1% of favorable combined price and mix and 1% from favorable foreign currency exchange rates.

[0001069202-21-000007:mdna:67]
Segment profit in 2020 decreased $29 million compared to 2019 due to $26 million of lower sales volumes, $10 million of factory inefficiency, $5 million of other product costs and warranty, $2 million from non-recurring European refrigerant quota sales, $1 million of combined price and mix, and $1 million from lower income from equity method investments.  Partially offsetting these declines was $5 million from lower commodity costs, $4 million of engineering and sourcing led cost reductions, $4 million lower SG&A, $1 million lower freight and distribution expense, $1 million of higher profit due to the divestiture of the Kysor Warren business, and $1 million of favorable foreign currency exchange rates.

[0001069202-21-000007:mdna:68]
Corporate and Other

[0001069202-21-000007:mdna:69]
Corporate and other expenses increased by $9 million in 2020 compared to 2019 primarily due to short-term and long-term stock-based incentive compensation.

[0001069202-21-000007:mdna:70]
Year Ended December 31, 2019 Compared to Year Ended December 31, 2018 - Consolidated Results

[0001069202-21-000007:mdna:71]
Net Sales

[0001069202-21-000007:mdna:72]
Net sales decreased 2.0% in 2019 compared to 2018, driven by a 5% decline related to the divestitures of our Australia, Asia, South America, and Kysor Warren businesses, partially offset by 1% volume growth and 2% from favorable price and mix combined. The increase in volume was primarily due to market growth in our Residential Heating & Cooling and Commercial Heating & Cooling segments, and the favorable price and mix combined was attributable to all three of our business segments.

[0001069202-21-000007:mdna:73]
Gross Profit

[0001069202-21-000007:mdna:74]
Gross profit margins for 2019 decreased 20 basis points (“bps”) to 28.4% compared to 28.6% in 2018.  We saw margin decreases of 30 bps from higher commodity costs, 80 bps from higher freight and distribution costs, 70 bps from lower factory productivity, and 50 bps from other product costs.  These decreases were offset by increases of 100 bps from favorable price and mix, 50 bps from sourcing and engineering-led cost reductions, and 60 bps from our divested Australia, Asia, South America, and Kysor Warren businesses which collectively had lower margins.

[0001069202-21-000007:mdna:75]
Selling, General and Administrative Expenses

[0001069202-21-000007:mdna:76]
SG&A expenses decreased by $22 million in 2019 compared to 2018.  As a percentage of net sales, SG&A expenses decreased 30 bps from 15.7% to 15.4% in the same periods.  SG&A decreased primarily due to the sale of our divested Australia, Asia, South America, and Kysor Warren businesses.

[0001069202-21-000007:mdna:77]
Losses (Gains) and Other Expenses, Net

[0001069202-21-000007:mdna:78]
Losses (gains) and other expenses, net for 2019 and 2018 included the following (in millions):

[0001069202-21-000007:mdna:79]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |
| Realized losses (gains), net on settled futures contracts | $ | 0.4 |  |  | $ | (0.4) |  |
| Foreign currency exchange (gains) losses, net | (1.5) |  |  | 1.7 |  |
| (Gains) losses on disposal of fixed assets | (0.2) |  |  | 0.7 |  |
| Other operating (gains) losses | (1.7) |  |  | — |  |
| Change in unrealized (gains) losses, net of unsettled futures contracts | (0.5) |  |  | 1.5 |  |
| Asbestos-related litigation | 3.1 |  |  | 4.0 |  |
| Special legal contingency charges | 1.2 |  |  | 1.9 |  |
| Environmental liabilities | 5.7 |  |  | 2.2 |  |
| Other items, net | 1.8 |  |  | 1.8 |  |
| Losses (gains) and other expenses, net | $ | 8.3 |  |  | $ | 13.4 |  |

[0001069202-21-000007:mdna:80]
The realized gains on settled futures contracts in 2018 were attributable to changes in commodity prices relative to our settled futures contract prices, as commodity prices have increased in 2018 relative to 2017.  Additionally, the change in unrealized losses, net on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-21-000007:mdna:81]
Foreign currency exchange losses increased in 2018 primarily due to weakening in foreign exchange rates in our primary markets.  The special legal contingency charges decreased primarily due to lower legal costs associated with outstanding legal settlements.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001069202-21-000007:mdna:82]
Restructuring Charges

[0001069202-21-000007:mdna:83]
Restructuring charges were $10.3 million in 2019 compared to $3.0 million in 2018. The charges in 2019 related primarily to activities in the Residential Heating & Cooling segment to close certain Lennox Stores and reduce management and support staff, and activities in the Commercial Heating & Cooling segments to re-align resources and its product portfolio.  The charges in 2018 were primarily for projects to realign resources and enhance manufacturing and distribution capabilities.  For more information on our restructuring activities, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-21-000007:mdna:84]
Goodwill

[0001069202-21-000007:mdna:85]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended

[0001069202-21-000007:mdna:86]
December 31, 2019.  We did not record any goodwill impairments in 2018 or 2019.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-21-000007:mdna:87]
Asset Impairment

[0001069202-21-000007:mdna:88]
We did not have any impairments of assets related to continuing operations in 2019 or 2018.

[0001069202-21-000007:mdna:89]
Pension Settlement

[0001069202-21-000007:mdna:90]
In the second and fourth quarters of 2019, we entered into agreements to purchase group annuity contracts and transfer certain pension assets and related pension benefit obligations to Pacific Life Insurance Company.  We recognized $99.2 million of pension settlement charges related to these transactions.  We did not have significant pension buyout activity in 2018. Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001069202-21-000007:mdna:91]
Income from Equity Method Investments

[0001069202-21-000007:mdna:92]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $13 million in 2019 compared to $12 million in 2018.  The increase is due to improved operating performance at the joint ventures.

[0001069202-21-000007:mdna:93]
Interest Expense, net

[0001069202-21-000007:mdna:94]
Net interest expense of $48 million in 2019 increased from $38 million in 2018 primarily due to an increase in our average borrowings.

[0001069202-21-000007:mdna:95]
Income Taxes

[0001069202-21-000007:mdna:96]
The income tax provision was $99 million in 2019 compared to $108 million in 2018, and the effective tax rate was 19.5% in 2019 compared to 23.0% in 2018.  The 2019 and 2018 effective tax rates differ from the statutory rate of 21% primarily due to state and foreign taxes. Refer to Note 13 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.  We expect our effective tax rate will be between 21% and 22% in future years, excluding the impact of excess tax benefits. Refer to Note 13 in the Notes to the Consolidated Financial Statements for more information on the impact of recent changes in tax legislation.

[0001069202-21-000007:mdna:97]
Loss from Discontinued Operations

[0001069202-21-000007:mdna:98]
There were no significant losses from discontinued operations in 2019.  The $1 million of pre-tax income in 2018 primarily related to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001069202-21-000007:mdna:99]
Year Ended December 31, 2019 Compared to Year Ended December 31, 2018 - Results by Segment

[0001069202-21-000007:mdna:100]
Residential Heating & Cooling

[0001069202-21-000007:mdna:101]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2019 and 2018 (dollars in millions):

[0001069202-21-000007:mdna:102]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 2,291.1 |  |  | $ | 2,225.0 |  |  | $ | 66.1 |  |  | 3% |
| Profit | $ | 464.6 |  |  | $ | 399.4 |  |  | $ | 65.2 |  |  | 16% |
| % of net sales | 20.3 | % |  | 18.0 | % |  |  |  |  |

[0001069202-21-000007:mdna:103]
Residential Heating & Cooling net sales increased 3% in 2019 compared to 2018. Sales volume increased 1% and price and mix combined increased 2%.

[0001069202-21-000007:mdna:104]
Segment profit in 2019 increased $65 million compared to 2018 due to an incremental $72 million of insurance proceeds for lost profits related to the Marshalltown tornado, $53 million of favorable price, $14 million of sourcing and engineer-led cost reductions, $8 million of lower warranty costs, and $2 million of higher sales volume.  Partially offsetting these increases is $28 million of higher freight and distribution expense, $16 million from lower factory efficiency, $12 million of higher SG&A, $11 million of unfavorable mix, $10 million of higher other product costs, $6 million of higher commodities, and $1 million of unfavorable foreign exchange rates.

[0001069202-21-000007:mdna:105]
Commercial Heating & Cooling

[0001069202-21-000007:mdna:106]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2019 and 2018 (dollars in millions):

[0001069202-21-000007:mdna:107]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 947.4 |  |  | $ | 900.7 |  |  | $ | 46.7 |  |  | 5% |
| Profit | $ | 165.4 |  |  | $ | 157.5 |  |  | $ | 7.9 |  |  | 5% |
| % of net sales | 17.5 | % |  | 17.5 | % |  |  |  |  |

[0001069202-21-000007:mdna:108]
Commercial Heating & Cooling net sales increased 5% in 2019 compared to 2018.  Sales volume increased 2% and price and mix combined increased 3%.

[0001069202-21-000007:mdna:109]
Segment profit in 2019 increased $8 million compared to 2018 due to $23 million of higher price and mix combined, $7 million of higher sales volume, and $6 million from sourcing and engineering-led cost reductions.  Partially offsetting these increases was $7 million of lower factory efficiency, $6 million of higher warranty and other product costs, $5 million of higher commodities, $4 million of higher freight and distribution expense, $3 million of higher SG&A expense, and $3 million of higher tariffs on Chinese imports.

[0001069202-21-000007:mdna:110]
Refrigeration

[0001069202-21-000007:mdna:111]
The following table presents our Refrigeration segment’s net sales and profit for 2019 and 2018 (dollars in millions):

[0001069202-21-000007:mdna:112]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | 568.7 |  | 758.2 |  | $ | (189.5) |  |  | (25) | % |
| Profit | 61.3 |  | 68.1 |  | $ | (6.8) |  |  | (10) | % |
| % of net sales | 10.8 | % |  | 9.0 | % |  |  |  |  |

[0001069202-21-000007:mdna:113]
Net sales decreased 25% in 2019 compared to 2018.  The loss of sales from the divested Australia, Asia, South America and Kysor Warren businesses contributed 24% and unfavorable foreign currency exchange rates contributed 2%, partially offset by 1% favorable price and mix combined.

[0001069202-21-000007:mdna:114]
Segment profit in 2019 decreased $7 million compared to 2018 due to $5 million of lower factory efficiency, $2 million of higher commodities, $3 million of lower sales of refrigerant allocations in Europe, $3 million of higher warranty and other product costs, $3 million of higher SG&A expenses, $1 million unfavorable foreign currency exchange rates, and $1 million of higher tariffs on Chinese imports.  Partially offsetting these decreases was $4 million from higher price and mix combined, $5 million of sourcing and engineering-led cost reductions, and $2 million of higher profit due to the divestiture of Kysor Warren.

[0001069202-21-000007:mdna:115]
Corporate and Other

[0001069202-21-000007:mdna:116]
Corporate and other expenses decreased by $2 million in 2019 compared to 2018 primarily due to lower short-term and long-term incentive compensation.

[0001069202-21-000007:mdna:117]
Accounting for Futures Contracts

[0001069202-21-000007:mdna:118]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 10 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 3 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to operating income.

[0001069202-21-000007:mdna:119]
Liquidity and Capital Resources

[0001069202-21-000007:mdna:120]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-21-000007:mdna:121]
Statement of Cash Flows

[0001069202-21-000007:mdna:122]
The following table summarizes our cash flow activity for the years ended December 31, 2020, 2019 and 2018 (in millions):

[0001069202-21-000007:mdna:123]
|  | 2020 |  | 2019 |  | 2018 |
| Net cash provided by operating activities | $ | 612.4 |  |  | $ | 396.1 |  |  | $ | 495.5 |  |
| Net cash (used in) provided by investing activities | (79.7) |  |  | 15.9 |  |  | 30.5 |  |
| Net cash used in financing activities | $ | (441.8) |  |  | $ | (423.4) |  |  | $ | (537.8) |  |

[0001069202-21-000007:mdna:124]
Net Cash Provided by Operating Activities - Net cash provided by operating activities increased $216 million to $612 million in 2020 compared to $396 million in 2019.  The increase was primarily attributable to a decrease in working capital partially offset by a decrease in net income.

[0001069202-21-000007:mdna:125]
Net Cash (Used in) Provided by Investing Activities -  The net change in investing activities of $96 million were attributable to absence of cash inflows from insurance proceeds of $80 million to fund capital expenditures for the reconstruction of our Marshalltown facility and $44 million of proceeds for the sales of our Kysor Warren business in 2019. Capital expenditures were $79 million, $106 million and $95 million in 2020, 2019 and 2018, respectively.  Capital expenditures in 2020 were primarily related to the expansion of our manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.

[0001069202-21-000007:mdna:126]
Net Cash Used in Financing Activities - Net cash used in financing activities increased to $442 million in 2020 from $423 million in 2019.  The increase is due to a decrease in borrowings and an increase in payments on our debt facilities, partially offset by lower share repurchases in 2020.  During 2020 we repurchased $100 million of shares compared to $400 million of shares in 2019.  We also returned $118 million to shareholders through dividend payments in 2020.  For additional information on share repurchases, refer to Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-21-000007:mdna:127]
Debt Position

[0001069202-21-000007:mdna:128]
The following table details our lines of credit and financing arrangements as of December 31, 2020 (in millions):

[0001069202-21-000007:mdna:129]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset Securitization Program (1) | $ | — |  |
| Capital lease obligations | 10.1 |  |
| Domestic credit facility (2) | — |  |
| Debt issuance costs | (0.2) |  |
| Total current maturities of long-term debt | $ | 9.9 |  |
| Long-term debt: |  |
| Capital lease obligations | $ | 29.3 |  |
| Domestic credit facility (2) | — |  |
| Senior unsecured notes | 950.0 |  |
| Debt issuance costs | (8.6) |  |
| Total long-term debt | 970.7 |  |
| Total debt | $ | 980.6 |  |

[0001069202-21-000007:mdna:130]
(1)The maximum securitization amount ranges from $250.0 million to $400.0 million, depending on the period. The maximum capacity of the Asset Securitization Program (“ASP”) is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 14 in the Notes to the Consolidated Financial Statements for more details.

[0001069202-21-000007:mdna:131]
(2)The total capacity on the facility is $750.0 million.  The amount available future borrowings on our domestic credit facility are $748 million after being reduced by the outstanding borrowings and $2 million in outstanding standby letters of credit as of December 31, 2020.

[0001069202-21-000007:mdna:132]
Financial Leverage

[0001069202-21-000007:mdna:133]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001069202-21-000007:mdna:134]
We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our Share Repurchase Plans.  Our debt-to-total-capital ratio increased to 102% at December 31, 2020 compared to 117% at December 31, 2019.  The decrease in the ratio in 2020 is primarily due to the decrease in total debt.

[0001069202-21-000007:mdna:135]
As of December 31, 2020, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody’s Investors Service, Inc. (“Moody’s”) and Standard & Poor’s Rating Group (“S&P”), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody’s and S&P to help ensure the capital markets remain available to us.

[0001069202-21-000007:mdna:136]
Liquidity

[0001069202-21-000007:mdna:137]
We believe our cash and cash equivalents of $124 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents as of December 31, 2020 was $59 million of cash held in foreign locations, although that amount can fluctuate significantly depending on the timing of cash receipts and payments.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-21-000007:mdna:138]
No contributions are required to be made to our U.S. defined benefit plans in 2021. We made $3 million in total contributions to pension plans in 2020.

[0001069202-21-000007:mdna:139]
Dividend payments were $118 million in 2020 compared to $111 million in 2019. On May 22, 2019, our Board of Directors approved a 20% increase in our quarterly dividend on common stock from $0.64 to $0.77 per share effective with the July 2019 dividend payment.  The quarterly dividend on common stock was $0.77 for all payments during 2020.

[0001069202-21-000007:mdna:140]
We also continued to increase shareholder value through our Share Repurchase Plans.  We returned $100 million to our investors through share repurchases in 2020.  Our Board of Directors authorized an incremental $500 million of share repurchases in December 2019, and we had $446 million of repurchases available under the Share Repurchase Plans at December 31, 2020. We expect to repurchase $400 million of shares in 2021.

[0001069202-21-000007:mdna:141]
We expect capital expenditures of approximately $135 million in 2021.

[0001069202-21-000007:mdna:142]
Financial Covenants related to our Debt

[0001069202-21-000007:mdna:143]
Our domestic credit facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage.  Other covenants contained in the domestic credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Interest Expense Ratio.  The required ratios under our domestic credit facility are detailed below:

[0001069202-21-000007:mdna:144]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-21-000007:mdna:145]
Our domestic credit facility contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001069202-21-000007:mdna:146]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001069202-21-000007:mdna:147]
•We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-21-000007:mdna:148]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our domestic credit facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-21-000007:mdna:149]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our domestic credit facility and accelerate amounts due under our domestic credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-21-000007:mdna:150]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee payment by us of any indebtedness under our domestic credit facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001069202-21-000007:mdna:151]
As of December 31, 2020, we believe we were in compliance with all covenant requirements. Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared

[0001069202-21-000007:mdna:152]
and/or the preceding fiscal year.  In addition, stock repurchases can only be made out of surplus and only if our capital would not be impaired.

[0001069202-21-000007:mdna:153]
Leasing Commitments

[0001069202-21-000007:mdna:154]
Refer to Note 5 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001069202-21-000007:mdna:155]
Guarantees related to our Debt Obligations

[0001069202-21-000007:mdna:156]
Our senior unsecured notes were issued by Lennox International Inc. (the “Parent”) and are unconditionally guaranteed by certain of our subsidiaries (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries.  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001069202-21-000007:mdna:157]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of and for the years ended December 31, 2020 and 2019 (in millions):

[0001069202-21-000007:mdna:158]
|  | As of December 31, 2020 |  | As of December 31, 2019 |
| Current assets | $ | 538.1 |  |  | $ | 594.5 |  |
| Non-current assets | $ | 2,975.5 |  |  | $ | 2,297.8 |  |
| Current liabilities | $ | 588.0 |  |  | $ | 619.7 |  |
| Non-current liabilities | $ | 1,318.7 |  |  | $ | 1,169.4 |  |
| Amounts due to non-guarantor subsidiaries | $ | (303.8) |  |  | $ | (339.2) |  |

[0001069202-21-000007:mdna:159]
|  |  |  | For the Year Ended December 31, 2020 |  | For the Year Ended December 31, 2019 |
| Net sales |  |  | $ | 3,358.0 |  |  | $ | 3,479.8 |  |
| Gross profit |  |  | $ | 981.5 |  |  | $ | 966.6 |  |
| Income from continuing operations |  |  | $ | 721.7 |  |  | $ | 828.4 |  |
| Net income |  |  | $ | 721.7 |  |  | $ | 828.4 |  |
| Net sales to non-guarantor subsidiaries |  |  | $ | 245.5 |  |  | $ | 228.3 |  |

[0001069202-21-000007:mdna:160]
Off Balance Sheet Arrangements

[0001069202-21-000007:mdna:161]
An off-balance sheet arrangement is any transaction, agreement or other contractual arrangement involving an unconsolidated entity under which the company has: (1) made guarantees, (2) a retained or a contingent interest in transferred assets, (3) an obligation under derivative instruments classified as equity or (4) any obligation arising out of a material variable interest in an unconsolidated entity that provides financing, liquidity, market risk or credit risk support to us, or that engages in leasing, hedging or research and development arrangements with us.  We have no off-balance sheet arrangements that we believe may have a material current or future effect on our financial condition, liquidity or results of operations.

[0001069202-21-000007:mdna:162]
Contractual Obligations

[0001069202-21-000007:mdna:163]
Summarized below are our contractual obligations as of December 31, 2020 and their expected impact on our liquidity and cash flows in future periods (in millions):

[0001069202-21-000007:mdna:164]
|  | Payments Due by Period |
|  | Total |  | 1 Year or Less |  | 1 - 3 Years |  | 3 - 5 Years |  | More than 5 Years |
| Total long-term debt obligations (1) | $ | 989.4 |  |  | $ | 10.1 |  |  | $ | 364.2 |  |  | $ | 303.4 |  |  | $ | 311.7 |  |
| Estimated interest payments on existing debt obligations (2) | 83.1 |  |  | 20.1 |  |  | 38.3 |  |  | 16.6 |  |  | 8.1 |  |
| Operating leases | 210.4 |  |  | 59.8 |  |  | 94.1 |  |  | 39.7 |  |  | 16.8 |  |
| Purchase obligations (3) | 37.8 |  |  | 37.8 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 1,320.7 |  |  | $ | 127.8 |  |  | $ | 496.6 |  |  | $ | 359.7 |  |  | $ | 336.6 |  |

[0001069202-21-000007:mdna:165]
(1) Contractual obligations related to finance leases are included as part of long-term debt.  See Note 14 for more

[0001069202-21-000007:mdna:166]
information related to our long-term debt.

[0001069202-21-000007:mdna:167]
(2) Estimated interest payments are based on current contractual requirements and do not reflect seasonal changes in the

[0001069202-21-000007:mdna:168]
balance of our domestic credit facility.

[0001069202-21-000007:mdna:169]
(3) Purchase obligations consist of inventory that is part of our third party logistics programs.

[0001069202-21-000007:mdna:170]
The table above does not include pension, post-retirement benefit and warranty liabilities because it is not certain when these liabilities will be funded. For additional information regarding our contractual obligations, see Note 5 of the Notes to the Consolidated Financial Statements.  See Note 11 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.

[0001069202-21-000007:mdna:171]
Fair Value Measurements

[0001069202-21-000007:mdna:172]
Fair value is the price that would be received to sell an asset or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001069202-21-000007:mdna:173]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-21-000007:mdna:174]
Level 1 -          Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-21-000007:mdna:175]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001069202-21-000007:mdna:176]
Level 3 -     Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001069202-21-000007:mdna:177]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2020 and 2019, the measurement dates.  See Note 17 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001069202-21-000007:mdna:178]
Market Risk

[0001069202-21-000007:mdna:179]
Commodity Price Risk

[0001069202-21-000007:mdna:180]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001069202-21-000007:mdna:181]
| Notional amount (pounds of aluminum and copper) | 56.9 |  |
| Carrying amount and fair value of net asset | $ | 10.5 |  |
| Change in fair value from 10% change in forward prices | $ | 9.2 |  |

[0001069202-21-000007:mdna:182]
Refer to Note 10 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001069202-21-000007:mdna:183]
Interest Rate Risk

[0001069202-21-000007:mdna:184]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $1.3 million, $3.9 million and $2.7 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001069202-21-000007:mdna:185]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2020 and 2019, no interest rate swaps were in effect.

[0001069202-21-000007:mdna:186]
Foreign Currency Exchange Rate Risk

[0001069202-21-000007:mdna:187]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  During 2020, 2019 and 2018, net sales from outside the U.S. represented 13.0%, 13.2% and 18.5% , respectively, of our total net sales.  For the years ended December 31, 2020,  2019, and 2018, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $0.6 million, $4.2 million and $2.1 million impact to net income for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001069202-21-000007:mdna:188]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 10 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001069202-21-000007:mdna:189]
Critical Accounting Estimates

[0001069202-21-000007:mdna:190]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following describes our critical accounting estimate related to product warranties and product-related contingencies and how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements. This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001069202-21-000007:mdna:191]
Product Warranties and Product-Related Contingencies

[0001069202-21-000007:mdna:192]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.

[0001069202-21-000007:mdna:193]
From time to time, we may also incur costs to repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.  These product-related costs may not be covered under our warranties and are not covered by insurance.

[0001069202-21-000007:mdna:194]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 5 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001069202-21-000007:mdna:195]
Recent Accounting Pronouncements

[0001069202-21-000007:mdna:196]
See Note 2 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
