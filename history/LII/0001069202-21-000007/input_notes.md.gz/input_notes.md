# LII notes — 0001069202-21-000007


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001069202-21-000007:notes:1]
DOCUMENTS INCORPORATED BY REFERENCEPortions of the registrant’s 2020 Definitive Proxy Statement to be filed with the Securities and Exchange Commission in connection with the registrant’s 2020 Annual Meeting of Stockholders to be held on May 20, 2021 are incorporated by reference into Part III of this report.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-21-000007:notes:2]
Principles of Consolidation

[0001069202-21-000007:notes:3]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.

[0001069202-21-000007:notes:4]
Cash and Cash Equivalents

[0001069202-21-000007:notes:5]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.

[0001069202-21-000007:notes:6]
Short term Investments

[0001069202-21-000007:notes:7]
Short-term investments include all investments, exclusive of cash equivalents, with a stated maturity date of one year or less from the balance sheet date and are expected to be used in current operations.

[0001069202-21-000007:notes:8]
Accounts and Notes Receivable

[0001069202-21-000007:notes:9]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheet, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management’s judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management’s review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.

[0001069202-21-000007:notes:10]
Inventories

[0001069202-21-000007:notes:11]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $280.5 million and $360.7 million as of December 31, 2020 and 2019, respectively, were valued at the lower of cost or net realizable value using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or net realizable value with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001069202-21-000007:notes:12]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 10 for more information on our inventories.

[0001069202-21-000007:notes:13]
Property, Plant and Equipment

[0001069202-21-000007:notes:14]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001069202-21-000007:notes:15]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-21-000007:notes:16]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 40 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 5 years |
| Vehicles | 3 to 10 years |

[0001069202-21-000007:notes:17]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 10 for additional information on our property, plant and equipment.

[0001069202-21-000007:notes:18]
Goodwill

[0001069202-21-000007:notes:19]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually and whenever events or changes in circumstances indicate the asset may be impaired.  See Note 10 for additional information on our goodwill.

[0001069202-21-000007:notes:20]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-21-000007:notes:21]
If a quantitative goodwill impairment test is determined to be necessary, we estimate reporting unit fair values using a combination of the discounted cash flow approach and a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. The market approach is based on objective evidence of market values.

[0001069202-21-000007:notes:22]
Intangible Assets

[0001069202-21-000007:notes:23]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-21-000007:notes:24]
| Asset | Useful Life |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |

[0001069202-21-000007:notes:25]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In

[0001069202-21-000007:notes:26]
assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-21-000007:notes:27]
We review our indefinite-lived intangible assets for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets.

[0001069202-21-000007:notes:28]
Product Warranties

[0001069202-21-000007:notes:29]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined by product category. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. In most cases, the estimated units to be repaired under warranty are multiplied by the estimated cost of replacement parts to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 5 for more information on our estimated future warranty costs.

[0001069202-21-000007:notes:30]
Pensions and Post-retirement Benefits

[0001069202-21-000007:notes:31]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheet.  Changes in the funded status are recognized in the year in which the changes occur through Accumulated other comprehensive loss (“AOCL”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-21-000007:notes:32]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management’s estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 11 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-21-000007:notes:33]
Self-Insurance

[0001069202-21-000007:notes:34]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information, industry factors, and trends.  The self-insurance liabilities as of December 31, 2020 represent the best estimate of the future payments to be made on reported and unreported losses for 2020 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 5 for additional information on our self-insured risks and liabilities.

[0001069202-21-000007:notes:35]
Derivatives

[0001069202-21-000007:notes:36]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheet at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 10 for more information on our derivatives.

[0001069202-21-000007:notes:37]
Income Taxes

[0001069202-21-000007:notes:38]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 13 for more information related to income taxes.

[0001069202-21-000007:notes:39]
Revenue Recognition

[0001069202-21-000007:notes:40]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.  See Note 9 for more information on our revenue recognition practices.

[0001069202-21-000007:notes:41]
Cost of Goods Sold

[0001069202-21-000007:notes:42]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense, and freight and distribution costs.

[0001069202-21-000007:notes:43]
Selling, General and Administrative Expenses

[0001069202-21-000007:notes:44]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation, and rent.

[0001069202-21-000007:notes:45]
Stock-Based Compensation

[0001069202-21-000007:notes:46]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs based on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 16 for more information.

[0001069202-21-000007:notes:47]
Translation of Foreign Currencies

[0001069202-21-000007:notes:48]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCL in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.

[0001069202-21-000007:notes:49]
Use of Estimates

[0001069202-21-000007:notes:50]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-21-000007:notes:51]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-21-000007:notes:52]
Impact of COVID-19 Pandemic

[0001069202-21-000007:notes:53]
COVID-19 surfaced in late 2019 and has spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic has disrupted our business operations and caused a significant unfavorable impact on our results of operations.

[0001069202-21-000007:notes:54]
In response to the COVID-19 pandemic, various national, state, and local governments where we, our suppliers, and our customers operate issued decrees prohibiting certain businesses from continuing to operate and certain classes of workers from reporting to work.  Those decrees have resulted in supply chain disruption and higher employee absenteeism in our factories.  Additionally, certain of our manufacturing facilities experienced short-term suspensions of operations for COVID-19 employee health concerns.

[0001069202-21-000007:notes:55]
As the COVID-19 pandemic continues, health concern risks remain, and we cannot predict whether any of our manufacturing, operational or distribution facilities will experience disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 would continue to impact our results of operations, financial position and cash flows.

[0001069202-21-000007:notes:56]
Recently Adopted Accounting Pronouncements

[0001069202-21-000007:notes:57]
In February 2016, the FASB issued ASU No. 2016-02, Leases (“ASC 842”). This accounting standard requires lessees to recognize a lease liability and a right-of-use (“ROU”) asset on the balance sheet for operating leases. Accounting for finance leases is substantially unchanged. ASC 842 is effective for fiscal years beginning after December 15, 2018 and we adopted the standard effective January 1, 2019.

[0001069202-21-000007:notes:58]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to estimate credit losses. ASU 2016-13 is effective for SEC filers for interim and annual periods beginning after December 15, 2019.  We adopted ASU 2016-13 using the modified retrospective method for all financial assets measured at amortized cost.  Results for periods after January 1, 2020 are presented under ASU 2016-13 while prior period amounts continue to be reported under previously applicable accounting standards.  We recorded a $1.3 million net decrease to retained earnings as of January 1, 2020 for the cumulative effect of adopting ASU 2016-13.

[0001069202-21-000007:notes:59]
In January 2017, the FASB issued ASU No. 2017-04, Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates step two of the goodwill impairment test and specifies that goodwill impairment should be measured by comparing the fair value of a reporting unit with its carrying amount. Additionally, the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount of net assets should be disclosed. ASU 2017-04 is effective for annual or interim goodwill impairment tests performed in fiscal years beginning after December 15, 2019.  The adoption of ASU 2017-04 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.

[0001069202-21-000007:notes:60]
In August 2018, the FASB issued ASU No. 2018-15, Intangibles – Internal-Use Software (Topic 350-40): Customer’s Accounting for Implementation Costs incurred in a Cloud Computing Arrangement That is a Service Contract.  ASU 2018-15 provides guidance to determine how implementation costs associated with cloud computing arrangements that are incurred to develop or obtain internal-use software should be capitalized or expensed as incurred. ASU 2018-15 is effective for fiscal years beginning after December 15, 2019.  The adoption of ASU 2018-15 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.

[0001069202-21-000007:notes:61]
Changes in Accounting Standards Effective for Future Reporting Periods

[0001069202-21-000007:notes:62]
In December 2019, the FASB issued ASU No. 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.  ASU 2019-02, in an effort to reduce complexity in accounting for income taxes, removes certain exceptions for measuring intraperiod tax allocations,  foreign subsidiary equity method investments and interim period tax losses.  ASU 2019-12 is effective for calendar year-end public business entities on January 1, 2021.  We are currently assessing the impact of ASU 2019-12, but do not expect it to have a material impact on our financial statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001069202-21-000007:notes:63]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-21-000007:notes:64]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Land | $ | 24.0 |  |  | $ | 23.7 |  |
| Buildings and improvements | 266.1 |  |  | 242.9 |  |
| Machinery and equipment | 928.0 |  |  | 883.4 |  |
| Finance leases | 57.1 |  |  | 47.2 |  |
| Construction in progress and equipment not yet in service | 69.7 |  |  | 72.5 |  |
| Total | 1,344.9 |  |  | 1,269.7 |  |
| Less accumulated depreciation | (880.6) |  |  | (824.3) |  |
| Property, plant and equipment, net | $ | 464.3 |  |  | $ | 445.4 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-21-000007:notes:65]
scription of Segments
We operate in three reportable business segments of the HVACR industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-21-000007:notes:66]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products |  | Light Commercial |  | United StatesCanada |
| Refrigeration(2) |  | Condensing units, unit coolers, fluid coolers, air- cooled condensers, air handlers, process chillers, controls, and compressorized racks |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEurope(1) |

[0001069202-21-000007:notes:67]
(1) Effective January 1, 2019, we realigned our segment structure. We shifted financial reporting of the European Commercial HVAC business from our Commercial Heating & Cooling segment to our Refrigeration segment as we manage both our commercial HVAC and refrigeration operations in Europe together. We have revised our historical segment results to present them on a comparable basis.

[0001069202-21-000007:notes:68]
(2) Descriptions of the products, services, markets and geographic areas of divested businesses were excluded from this table.   Refer to Note 7 for details regarding the divestitures of our Australia, Asia, South America and Kysor Warren businesses.

[0001069202-21-000007:notes:69]
Segment Data

[0001069202-21-000007:notes:70]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001069202-21-000007:notes:71]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term, share-based incentive awards provided to employees throughout our business.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-21-000007:notes:72]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-21-000007:notes:73]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001069202-21-000007:notes:74]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 2,361.5 |  |  | $ | 2,291.1 |  |  | $ | 2,225.0 |  |
| Commercial Heating & Cooling | 800.9 |  |  | 947.4 |  |  | 900.7 |  |
| Refrigeration | 471.7 |  |  | 568.7 |  |  | 758.2 |  |
|  | $ | 3,634.1 |  |  | $ | 3,807.2 |  |  | $ | 3,883.9 |  |
| Segment profit (loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 428.5 |  |  | $ | 464.6 |  |  | $ | 399.4 |  |
| Commercial Heating & Cooling | 136.9 |  |  | 165.4 |  |  | 157.5 |  |
| Refrigeration | 32.8 |  |  | 61.3 |  |  | 68.1 |  |
| Corporate and other | (91.5) |  |  | (82.4) |  |  | (84.4) |  |
| Total segment profit | 506.7 |  |  | 608.9 |  |  | 540.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| Special product quality adjustments | 1.0 |  |  | (0.6) |  |  | — |  |
| Special inventory write down | — |  |  | — |  |  | 0.2 |  |
| Loss (gain), net on sale of businesses and related property | — |  |  | 10.6 |  |  | 27.0 |  |
| Loss (gain) from natural disasters, net of insurance recoveries | 3.1 |  |  | (79.6) |  |  | (10.9) |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 13.3 |  |  | 11.3 |  |  | 11.4 |  |
| Restructuring charges | 10.8 |  |  | 10.3 |  |  | 3.0 |  |
| Operating income | $ | 478.5 |  |  | $ | 656.9 |  |  | $ | 509.9 |  |

[0001069202-21-000007:notes:75]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-21-000007:notes:76]
(2) We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-21-000007:notes:77]
•The following items in Losses (gains) and other expenses, net:

[0001069202-21-000007:notes:78]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001069202-21-000007:notes:79]
◦Special legal contingency charges,

[0001069202-21-000007:notes:80]
◦Asbestos-related litigation,

[0001069202-21-000007:notes:81]
◦Environmental liabilities,

[0001069202-21-000007:notes:82]
◦Charges incurred related to COVID-19 pandemic,

[0001069202-21-000007:notes:83]
◦Other items, net,

[0001069202-21-000007:notes:84]
•Special inventory write down,

[0001069202-21-000007:notes:85]
•Special product quality adjustments

[0001069202-21-000007:notes:86]
•Loss (gain), net on sale of businesses and related property,

[0001069202-21-000007:notes:87]
•Loss (gain) from natural disasters, net of insurance recoveries, and

[0001069202-21-000007:notes:88]
•Restructuring charges.

[0001069202-21-000007:notes:89]
Total assets by segment are shown below (in millions):

[0001069202-21-000007:notes:90]
|  | As of December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 1,034.6 |  |  | $ | 1,055.7 |  |  | $ | 837.4 |  |
| Commercial Heating & Cooling | 366.5 |  |  | 409.0 |  |  | 349.5 |  |
| Refrigeration | 387.9 |  |  | 393.3 |  |  | 462.9 |  |
| Corporate and other | 243.5 |  |  | 176.9 |  |  | 167.4 |  |
| Total assets | $ | 2,032.5 |  |  | $ | 2,034.9 |  |  | $ | 1,817.2 |  |

[0001069202-21-000007:notes:91]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-21-000007:notes:92]
Total capital expenditures by segment are shown below (in millions):

[0001069202-21-000007:notes:93]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 44.0 |  |  | $ | 59.2 |  |  | $ | 45.2 |  |
| Commercial Heating & Cooling | 5.9 |  |  | 11.3 |  |  | 12.5 |  |
| Refrigeration | 9.2 |  |  | 9.4 |  |  | 9.3 |  |
| Corporate and other | 19.4 |  |  | 25.7 |  |  | 28.2 |  |
| Total capital expenditures | $ | 78.5 |  |  | $ | 105.6 |  |  | $ | 95.2 |  |

[0001069202-21-000007:notes:94]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-21-000007:notes:95]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 28.5 |  |  | $ | 30.0 |  |  | $ | 26.6 |  |
| Commercial Heating & Cooling | 13.5 |  |  | 12.5 |  |  | 8.6 |  |
| Refrigeration | 7.8 |  |  | 7.9 |  |  | 8.9 |  |
| Corporate and other | 22.8 |  |  | 20.7 |  |  | 21.9 |  |
| Total depreciation and amortization | $ | 72.6 |  |  | $ | 71.1 |  |  | $ | 66.0 |  |

[0001069202-21-000007:notes:96]
The equity method investments are shown below (in millions):

[0001069202-21-000007:notes:97]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 11.4 |  |  | $ | 8.8 |  |  | $ | 8.5 |  |
| Commercial Heating & Cooling | 2.3 |  |  | 1.7 |  |  | 1.4 |  |
| Refrigeration | 1.9 |  |  | 2.9 |  |  | 2.1 |  |
| Total income from equity method investments | $ | 15.6 |  |  | $ | 13.4 |  |  | $ | 12.0 |  |

[0001069202-21-000007:notes:98]
Geographic Information

[0001069202-21-000007:notes:99]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-21-000007:notes:100]
|  | As of December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 352.9 |  |  | $ | 333.6 |  |  | $ | 293.3 |  |
| Mexico | 79.2 |  |  | 82.0 |  |  | 86.7 |  |
| Canada | 2.2 |  |  | 2.2 |  |  | 1.7 |  |
| Other international | 30.0 |  |  | 27.6 |  |  | 26.6 |  |
| Total Property, plant and equipment, net | $ | 464.3 |  |  | $ | 445.4 |  |  | $ | 408.3 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-21-000007:notes:101]
We operate in three reportable business segments of the HVACR industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-21-000007:notes:102]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-21-000007:notes:103]
|  | Incurred in 2020 |  | Aggregate Incurred Through 12/31/2020 |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 6.5 |  |  | $ | 9.4 |  |  | $ | 9.4 |  |
| Commercial Heating & Cooling | 1.6 |  |  | 3.3 |  |  | 3.8 |  |
| Refrigeration | 1.5 |  |  | 1.5 |  |  | 2.2 |  |
| Corporate & Other | 1.2 |  |  | 1.2 |  |  | 1.2 |  |
| Total | $ | 10.8 |  |  | $ | 15.4 |  |  | $ | 16.6 |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-21-000007:notes:104]
sic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-21-000007:notes:105]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Net income | $ | 356.3 |  |  | $ | 408.7 |  |  | $ | 359.0 |  |
| Add: Loss from discontinued operations | 0.8 |  |  | 0.1 |  |  | 1.3 |  |
| Income from continuing operations | $ | 357.1 |  |  | $ | 408.8 |  |  | $ | 360.3 |  |
| Weighted-average shares outstanding – basic | 38.3 |  |  | 39.0 |  |  | 40.6 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.3 |  |  | 0.4 |  |  | 0.5 |  |
| Weighted-average shares outstanding – diluted | 38.6 |  |  | 39.4 |  |  | 41.1 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 9.32 |  |  | $ | 10.49 |  |  | $ | 8.87 |  |
| Loss from discontinued operations | (0.02) |  |  | — |  |  | (0.03) |  |
| Net income | $ | 9.30 |  |  | $ | 10.49 |  |  | $ | 8.84 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 9.26 |  |  | $ | 10.38 |  |  | $ | 8.77 |  |
| Loss from discontinued operations | (0.02) |  |  | — |  |  | (0.03) |  |
| Net income | $ | 9.24 |  |  | $ | 10.38 |  |  | $ | 8.74 |  |

[0001069202-21-000007:notes:106]
An insignificant number of stock appreciation rights and Restricted Stock Units were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-21-000007:notes:107]
Leases

[0001069202-21-000007:notes:108]
We lease certain real and personal property under non-cancelable operating leases.  Approximately 73% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-21-000007:notes:109]
The components of lease expense were as follows (in millions):

[0001069202-21-000007:notes:110]
|  | For the Year Ended December 31, 2020 |  | For the Year Ended December 31, 2019 |
| Finance lease cost: |  |  |  |
| Amortization of right-of-use assets | $ | 10.3 |  |  | $ | 7.6 |  |
| Interest on lease liabilities | 0.7 |  |  | 0.9 |  |
| Operating lease cost | 62.7 |  |  | 59.7 |  |
| Short-term lease cost | 4.0 |  |  | 4.3 |  |
| Variable lease cost | 20.3 |  |  | 19.9 |  |
| Total lease cost | $ | 98.0 |  |  | $ | 92.4 |  |
| Other information |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 61.6 |  |  | $ | 58.1 |  |
| Financing cash flows from finance leases | $ | 10.8 |  |  | $ | 6.4 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 15.4 |  |  | $ | 13.4 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 67.6 |  |  | $ | 51.5 |  |

[0001069202-21-000007:notes:111]
|  | As of December 31, 2020 |  | As of December 31, 2019 |
| Finance lease right-of-use assets(1) | $ | 33.6 |  |  | $ | 28.4 |  |
| Operating lease right-of-use assets | $ | 194.4 |  |  | $ | 181.6 |  |
| Finance lease liability, current(2) | $ | 10.1 |  |  | $ | 7.8 |  |
| Finance lease liability, non-current(3) | $ | 29.3 |  |  | $ | 25.9 |  |
| Operating lease liability, current | $ | 55.0 |  |  | $ | 52.7 |  |
| Operating lease liability, non-current | $ | 142.8 |  |  | $ | 131.0 |  |
| Weighted-average remaining lease term - finance leases | 4.3 years |  | 4.9 years |
| Weighted-average remaining lease term - operating leases | 4.4 years |  | 4.5 years |
| Weighted-average discount rate - finance leases | 1.91 | % |  | 2.71 | % |
| Weighted-average discount rate – operating leases | 2.81 | % |  | 3.69 | % |
| (1) Recorded in Property, plant and equipments in Consolidated Balance Sheet |
| (2) Recorded in Current maturities of long-term debt in Consolidated Balance Sheet |
| (3) Recorded in Long-term debt in Consolidated Balance Sheet |

[0001069202-21-000007:notes:112]
Future annual minimum lease payments and finance lease commitments as of December 31, 2020 were as follows (in millions):

[0001069202-21-000007:notes:113]
|  | Operating Leases |  | Finance Leases |
| 2021 | $ | 59.8 |  |  | $ | 10.5 |  |
| 2022 | 50.8 |  |  | 8.7 |  |
| 2023 | 43.3 |  |  | 5.8 |  |
| 2024 | 26.3 |  |  | 2.6 |  |
| 2025 | 13.4 |  |  | 0.8 |  |
| Thereafter | 16.8 |  |  | 11.8 |  |
| Total minimum lease payments | $ | 210.4 |  |  | $ | 40.2 |  |
| Less imputed interest | (12.6) |  |  | (0.8) |  |
| Present value of minimum payments | $ | 197.8 |  |  | $ | 39.4 |  |

[0001069202-21-000007:notes:114]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024 (the “Lake Park Renewal”). The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, we are obligated to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance of $41.2 million, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 87% of the lease balance.  The headquarters lease is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-21-000007:notes:115]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of December 31, 2020.

[0001069202-21-000007:notes:116]
Environmental

[0001069202-21-000007:notes:117]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities; however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included Accrued expenses and Other liabilities on the accompanying Consolidated Balance Sheets. Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-21-000007:notes:118]
Product Warranties and Product Related Contingencies

[0001069202-21-000007:notes:119]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-21-000007:notes:120]
Total product warranty liabilities related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-21-000007:notes:121]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Accrued expenses | $ | 37.7 |  |  | $ | 38.2 |  |
| Other liabilities | 82.1 |  |  | 74.6 |  |
| Total product warranty liabilities | $ | 119.8 |  |  | $ | 112.8 |  |

[0001069202-21-000007:notes:122]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2020 and 2019 were as follows (in millions):

[0001069202-21-000007:notes:123]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Payments made in 2019 | (34.9) |  |
| Changes resulting from issuance of new warranties | 44.1 |  |
| Changes in estimates associated with pre-existing liabilities | (7.6) |  |
| Changes in foreign currency translation rates and other | — |  |
| Warranty liability from divestitures | (0.4) |  |
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Payments made in 2020 | (35.5) |  |
| Changes resulting from issuance of new warranties | 41.7 |  |
| Changes in estimates associated with pre-existing liabilities | 0.2 |  |
| Changes in foreign currency translation rates and other | 0.6 |  |
| Total warranty liability as of December 31, 2020 | $ | 119.8 |  |

[0001069202-21-000007:notes:124]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the table above.  Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.

[0001069202-21-000007:notes:125]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures. We use large deductible insurance plans, written through third-party insurance providers, for workers’ compensation/employers’ liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors’ and officers’ liability, property damage and certain other insurance programs.    For directors’ and officers’ liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-21-000007:notes:126]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001069202-21-000007:notes:127]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-21-000007:notes:128]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Accrued expenses | $ | 3.6 |  |  | $ | 5.2 |  |
| Other liabilities | 16.0 |  |  | 19.4 |  |
| Total self-insurance liabilities | $ | 19.6 |  |  | $ | 24.6 |  |

[0001069202-21-000007:notes:129]
Litigation

[0001069202-21-000007:notes:130]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-21-000007:notes:131]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by

[0001069202-21-000007:notes:132]
insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.

[0001069202-21-000007:notes:133]
Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors, and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the years ended December 31, 2020 and 2019, we estimated our probable liability for known cases at $10.1 million and $10.2 million, respectively, and these amounts were recorded in Accrued expenses in the Consolidated Balance Sheets. For the years ended December 31, 2020 and 2019, we estimated future asbestos-related litigation cases to be $27.9 million and $22.1 million, respectively, before consideration of probable insurance recoveries and these amounts were recorded in Other liabilities in the Consolidated Balance Sheets.  For the years ended December 31, 2020, 2019 and 2018, we recorded expense of $5.6 million, $3.1 million and $4.0 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

[0001069202-21-000007:notes:134]
It is management’s opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.

[0001069202-21-000007:notes:135]
Natural Disasters and Recovery

[0001069202-21-000007:notes:136]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  On August 10, 2020, the Marshalltown facility was partially damaged by a derecho wind storm. The costs and losses incurred as well as any insurance recoveries for both of these natural disasters are shown in Loss (gain) from natural disasters, net of insurance recoveries in the Consolidated Statements of Operations.

[0001069202-21-000007:notes:137]
The following table summarizes the components of Loss (gain) from natural disasters, net of insurance recoveries (in millions):

[0001069202-21-000007:notes:138]
|  |  |  |  |  |  | For the Year Ended December 31, |  |
|  |  |  |  |  |  |  |  | 2020 |  | 2019 |  | 2018 |  |
| Marshalltown tornado | $ | (3.0) |  |  | $ | 178.8 |  |  | $ | 38.3 |  |  |
| Marshalltown wind storm | (0.1) |  |  | — |  |  | — |  |  |
| (Loss) gain from natural disasters, net of insurance recoveries | $ | (3.1) |  |  | $ | 178.8 |  |  | $ | 38.3 |  |  |

[0001069202-21-000007:notes:139]
Marshalltown Tornado

[0001069202-21-000007:notes:140]
Insurance covered the repair or replacement of our assets that suffered damage or loss, and business interruption costs, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.  In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million, for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019. The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the tornado (in millions):

[0001069202-21-000007:notes:141]
| (Amounts in millions) |  |  | For the Year Ended December 31, |
|  |  |  |  |  | 2020 |  | 2019 |  | 2018 |
| Insurance recoveries received |  |  |  |  | $ | — |  |  | $ | 243.2 |  |  | $ | 124.3 |  |
| Less losses and expenses incurred: |  |  |  |  |  |  |  |  |  |
| Site clean-up and remediation |  |  |  |  | — |  |  | 20.4 |  |  | 50.9 |  |
| Factory inefficiencies due to lower productivity |  |  |  |  | — |  |  | 9.3 |  |  | 7.4 |  |
| Write-off of property, plant and equipment |  |  |  |  | — |  |  | — |  |  | 4.2 |  |
| Write-off of inventory |  |  |  |  | — |  |  | — |  |  | 5.8 |  |
| Other |  |  |  |  | 3.0 |  |  | 34.7 |  |  | 17.7 |  |
| Total losses and expenses |  |  |  |  | $ | 3.0 |  |  | $ | 64.4 |  |  | $ | 86.0 |  |
| (Loss) gain from natural disasters, net of insurance recoveries |  |  |  |  | $ | (3.0) |  |  | $ | 178.8 |  |  | $ | 38.3 |  |
| Components of (Loss) gain from natural disasters, net of insurance recoveries: |  |  |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits |  |  |  |  | — |  |  | 99.2 |  |  | 27.4 |  |
| (Loss) gain from property damage, net of insurance recoveries |  |  |  |  | (3.0) |  |  | 79.6 |  |  | 10.9 |  |


## us-gaap:ScheduleOfUnusualOrInfrequentItemsTextBlock

[0001069202-21-000007:notes:142]
The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the tornado (in millions):

[0001069202-21-000007:notes:143]
The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the wind storm (in millions):

[0001069202-21-000007:notes:144]
|  |  |  | For the Year Ended December 31, |
|  |  |  |  |  | 2020 |  |  |
| Insurance recoveries receivable |  |  |  |  | 6.6 |  |  |  |
| Inventory write-offs |  |  |  |  | $ | 0.1 |  |  |  |
| Site clean-up and remediation |  |  |  |  | 1.7 |  |  |  |
| Building repairs |  |  |  |  | 3.0 |  |  |  |
| Factory inefficiencies due to lower productivity |  |  |  |  | 0.2 |  |  |  |
| Other |  |  |  |  | 1.7 |  |  |  |
| Total losses and expenses |  |  |  |  | $ | 6.7 |  |  |  |
| Components of Marshalltown wind storm in Loss (gain) from natural disasters, net of insurance recoveries: |  |  |  |  |  |  |  |
| Loss from natural disaster, net of insurance recoveries |  |  |  |  | $ | (0.1) |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-21-000007:notes:145]
Our Board of Directors have authorized a total of $3 billion to repurchase shares of our common stock, including an incremental $500 million share repurchase authorization in December 2019, under our Share Repurchase Plans. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of December 31, 2020, $446 million of shares is available to repurchase shares under the Share Repurchase Plans.

[0001069202-21-000007:notes:146]
On February 13, 2020, we entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the "ASR Agreement") with Bank of America, to effect an accelerated stock buyback of the Company's common stock.  Under the ASR Agreement, we

[0001069202-21-000007:notes:147]
paid Bank of America $100.0 million and Bank of America delivered to us common stock representing approximately 85% of the shares expected to be purchased under the ASR Agreement.  The ASR was completed in March 2020 and Bank of America delivered a total of 0.4 million shares of common stock repurchased under this ASR Agreement.

[0001069202-21-000007:notes:148]
We also repurchased 0.1 million shares for $17.9 million,  0.1 million shares for $24.0 million, and 0.1 million shares for $26.9 million for the years ended December 31, 2020,  2019, and 2018, respectively, from employees who tendered their shares to satisfy minimum tax withholding obligation upon the vesting of stock-based compensation awards.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-21-000007:notes:149]
2019 Divestiture:

[0001069202-21-000007:notes:150]
During the first quarter of 2019, we obtained Board of Directors' approval and signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. The sale was completed on March 29, 2019 and the following table summarizes the net loss recognized in connection with this divestiture.  There were no gains or losses on the sale of this business for the year ended December 31, 2020.

[0001069202-21-000007:notes:151]
| (Amounts in millions) | For the Year Ended December 31, 2019 |
| Cash received from the buyer | $ | 49.0 |  |
| Net assets sold | (52.0) |  |
| AOCI reclassification adjustments, primarily foreign currency translation | (2.1) |  |
| Direct costs to sell | (5.5) |  |
| Loss on sale of business | $ | (10.6) |  |

[0001069202-21-000007:notes:152]
2018 Divestitures:

[0001069202-21-000007:notes:153]
Australia and Asia Divestiture

[0001069202-21-000007:notes:154]
During the first quarter of 2018, we obtained Board of Directors’ approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia and Asia business except for the Milperra property.  The Milperra property was sold to another purchaser during the second quarter of 2018. We completed the sale to Beijer Ref AB in the second quarter of 2018 with the final post-completion adjustment being recorded in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-21-000007:notes:155]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Cash received from the buyer | $ | 82.9 |  |
| Net assets sold (1) | (87.2) |  |
| AOCL reclassification adjustments, primarily foreign currency translation | (3.2) |  |
| Direct costs to sell | (5.8) |  |
| Loss on sale of business | $ | (13.3) |  |

[0001069202-21-000007:notes:156]
(1) Includes $10.3 million of net assets that were written down during the quarter ended March 31, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Australia and Asia business.

[0001069202-21-000007:notes:157]
The Milperra property was sold during the quarter ended June 30, 2018. We received net cash proceeds of $37.2 million net of direct costs to sell of $1.5 million. The net gain recognized in connection with this sale was $23.8 million.

[0001069202-21-000007:notes:158]
South America Divestiture

[0001069202-21-000007:notes:159]
During the second quarter of 2018, we obtained Board of Directors’ approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale was subject to Brazilian antitrust approval.  We obtained antitrust approval and completed the sale to Elgin SA in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-21-000007:notes:160]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Cash received from the buyer | $ | 4.2 |  |
| Net assets sold (2) | (14.1) |  |
| AOCL reclassification adjustments, primarily foreign currency translation | (24.7) |  |
| Direct costs to sell | (2.9) |  |
| Loss on sale of business | $ | (37.5) |  |

[0001069202-21-000007:notes:161]
(2) Includes $1.2 of net assets that were written down during the quarter ended June 30, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our South America business.

[0001069202-21-000007:notes:162]
The total Loss (gain), net on sale of businesses and related property in our Consolidated Statements of Operations of $10.6 million for the year ended December 31, 2019 is comprised of the loss on the sale of the Kysor Warren business.  The total Loss (gain), net on sale of businesses and related property for the year ended December 31, 2018 of $27.0 million is comprised of the $13.3 million loss on the sale of our Australia and Asia business, the $23.8 million gain on the sale of our Milperra property, and the $37.5 million loss on the sale of our South America business.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-21-000007:notes:163]
record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 3.
Restructuring Activities in 2020

[0001069202-21-000007:notes:164]
Due to the economic impact of COVID-19 on our business, we implemented several cost reduction actions in the second quarter of 2020.  We recorded $10.1 million of restructuring charges for the year ended December 31, 2020 for these actions, which consisted of employee terminations for positions that were no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities.

[0001069202-21-000007:notes:165]
Information regarding the restructuring charges for all ongoing activities, including actions initiated in 2019, is presented in the following table (in millions):

[0001069202-21-000007:notes:166]
|  | Incurred in 2020 |  | Aggregate Incurred Through 12/31/2020 |  | Total Expected to be Incurred |
| Severance and related expense | $ | 4.9 |  |  | $ | 6.2 |  |  | $ | 6.9 |  |
| Asset write-offs and accelerated depreciation | 2.0 |  |  | 3.6 |  |  | 3.6 |  |
| Accelerated depreciation on right-of-use assets from operating leases | (0.1) |  |  | 1.0 |  |  | 1.0 |  |
| Other | 4.0 |  |  | 4.6 |  |  | 5.1 |  |
| Total | $ | 10.8 |  |  | $ | 15.4 |  |  | $ | 16.6 |  |

[0001069202-21-000007:notes:167]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-21-000007:notes:168]
The following table disaggregates our revenue by business segment by geography which provides information as to the major sources of revenue.  See Note 3 for additional description of our reportable business segments and the products and services being sold in each segment.

[0001069202-21-000007:notes:169]
|  | For the Year Ended December 31, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,181.8 |  |  | $ | 721.1 |  |  | $ | 257.9 |  |  | $ | 3,160.8 |  |
| Canada | 179.7 |  |  | 77.6 |  |  | — |  |  | 257.3 |  |
| International | — |  |  | 2.2 |  |  | 213.8 |  |  | 216.0 |  |
| Total | $ | 2,361.5 |  |  | $ | 800.9 |  |  | $ | 471.7 |  |  | $ | 3,634.1 |  |

[0001069202-21-000007:notes:170]
|  | For the Year Ended December 31, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,135.6 |  |  | $ | 847.1 |  |  | $ | 321.9 |  |  | $ | 3,304.6 |  |
| Canada | 155.5 |  |  | 98.5 |  |  | 0.7 |  |  | 254.7 |  |
| International | — |  |  | 1.8 |  |  | 246.1 |  |  | 247.9 |  |
| Total | $ | 2,291.1 |  |  | $ | 947.4 |  |  | $ | 568.7 |  |  | $ | 3,807.2 |  |

[0001069202-21-000007:notes:171]
|  |  | For the Year Ended December 31, 2018 |
|  | Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
|  | United States | $ | 2,066.7 |  |  | $ | 805.4 |  |  | $ | 403.2 |  |  | $ | 3,275.3 |  |
|  | Canada | 158.3 |  |  | 92.7 |  |  | 4.5 |  |  | 255.5 |  |
|  | International | — |  |  | 2.6 |  |  | 350.5 |  |  | 353.1 |  |
|  | Total | $ | 2,225.0 |  |  | $ | 900.7 |  |  | $ | 758.2 |  |  | $ | 3,883.9 |  |

[0001069202-21-000007:notes:172]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales

[0001069202-21-000007:notes:173]
taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.

[0001069202-21-000007:notes:174]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  Revenue from extended warranties is insignificant. See Note 5 for more information on product warranties.

[0001069202-21-000007:notes:175]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the years ended December 31, 2020, 2019 and 2018, direct sales represented 75%, 75% and 76% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-21-000007:notes:176]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the years ended December 31, 2020,  2019 and 2018, equipment sales represented 85%, 86% and 86% of revenues, respectively, and the remainder of our revenue was generated from our service business.

[0001069202-21-000007:notes:177]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Approximately 1% of segment revenue relates to services for start-up and commissioning activities.

[0001069202-21-000007:notes:178]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to SG&A expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001069202-21-000007:notes:179]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001069202-21-000007:notes:180]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheets.

[0001069202-21-000007:notes:181]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.

[0001069202-21-000007:notes:182]
Net contract assets (liabilities) consisted of the following:

[0001069202-21-000007:notes:183]
|  | December 31, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | (5.5) |  |  | (8.4) |  |  | 2.9 |  |  | (35.2) | % |
| Contract liabilities - noncurrent | (5.6) |  |  | (5.9) |  |  | 0.3 |  |  | (5.1) | % |
| Total | $ | (11.1) |  |  | $ | (14.3) |  |  | $ | 3.2 |  |  |  |

[0001069202-21-000007:notes:184]
For the years ended December 31, 2020,  2019, and 2018 we recognized revenue of $7.2 million, $3.3 million and $4.8 million related to our contract liabilities at January 1, 2020, 2019 and 2018, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020, 2019 and 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-21-000007:notes:185]
The components of inventories are as follows (in millions):

[0001069202-21-000007:notes:186]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Finished goods | $ | 280.1 |  |  | $ | 402.9 |  |
| Work in process | 6.5 |  |  | 6.0 |  |
| Raw materials and parts | 207.8 |  |  | 198.8 |  |
| Total | 494.4 |  |  | 607.7 |  |
| Excess of current cost over last-in, first-out cost | (55.0) |  |  | (63.6) |  |
| Total inventories, net | $ | 439.4 |  |  | $ | 544.1 |  |

[0001069202-21-000007:notes:187]
The Company recorded a pre-tax gain of $0.7 million and  $0.2 million in 2020 and 2019, respectively, and no pre-tax gains or losses in 2018 from LIFO inventory liquidations.  Reserves for obsolete and slow-moving inventories were $24.6 million and $19.2 million at December 31, 2020 and December 31, 2019, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-21-000007:notes:188]
The changes in the carrying amount of goodwill in 2020 and 2019, in total and by segment, are summarized in the table below (in millions):

[0001069202-21-000007:notes:189]
| Segment: | Balance at December 31, 2018 (1) |  | Goodwill Reallocation (2) |  | Changes in foreign currency translation rates |  | Balance at December 31, 2019 |  |  |  | Changes in foreign currency translation rates |  | Balance at December 31, 2020 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.4 |  |  | (0.3) |  |  | — |  |  | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.1 |  |  | 0.3 |  |  | (0.1) |  |  | 99.3 |  |  |  |  | 0.4 |  |  | 99.7 |  |
|  | $ | 186.6 |  |  | $ | — |  |  | $ | (0.1) |  |  | $ | 186.5 |  |  |  |  | $ | 0.4 |  |  | $ | 186.9 |  |

[0001069202-21-000007:notes:190]
(1) The goodwill balances in the table above are presented net of accumulated impairment charges of $32.7 million, all of which relate to impairments in periods prior to 2018.

[0001069202-21-000007:notes:191]
(2) In 2019, we reorganized our external financial reporting structure by moving our European Commercial HVAC business from our Commercial segment to our Refrigeration segment as we manage both our commercial HVAC and refrigeration operations in Europe together. See Note 3 for additional information.
A qualitative review of impairment indicators was performed in 2020 for the Residential Heating & Cooling, the Commercial Heating & Cooling, and the Refrigeration segments.  We did not record any goodwill impairments in 2020 or 2019.   In 2018, we de-recognized $11.5 million of goodwill as a part of the completed sales of our Australia, Asia, and South America businesses as discussed further in Note 7.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-21-000007:notes:192]
No impairment charges were recorded in 2020 or 2019. In 2018, we impaired $4 million of property, plant and equipment at our Marshalltown facility that was damaged by a tornado.  Refer to Note 5 for more information on the damage to our Marshalltown facility.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-21-000007:notes:193]
Accrued Expenses

[0001069202-21-000007:notes:194]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-21-000007:notes:195]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Accrued compensation and benefits | $ | 96.6 |  |  | $ | 70.4 |  |
| Accrued rebates and promotions | 81.9 |  |  | 70.1 |  |
| Accrued warranties | 37.7 |  |  | 38.2 |  |
| Accrued sales, use, property and VAT taxes | 20.3 |  |  | 18.6 |  |
| Accrued asbestos reserves | 10.1 |  |  | 10.2 |  |
| Deferred income | 5.5 |  |  | 8.4 |  |
| Self insurance reserves | 3.6 |  |  | 5.2 |  |
| Derivative contracts | 2.2 |  |  | 2.9 |  |
| Other | 38.2 |  |  | 31.7 |  |
| Total Accrued expenses | $ | 296.1 |  |  | $ | 255.7 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-21-000007:notes:196]
Objectives and Strategies for Using Derivative Instruments

[0001069202-21-000007:notes:197]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-21-000007:notes:198]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001069202-21-000007:notes:199]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001069202-21-000007:notes:200]
Cash Flow Hedges

[0001069202-21-000007:notes:201]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through May 2022 and January 2022, respectively.  Unrealized gains or losses from our cash flow hedges are included in AOCL and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.

[0001069202-21-000007:notes:202]
We recorded the following amounts related to our cash flow hedges in AOCL (in millions):

[0001069202-21-000007:notes:203]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Unrealized (losses) gains, net on unsettled contracts | $ | (10.5) |  |  | $ | 0.2 |  |
| Income tax benefit (expense) | 2.3 |  |  | (0.2) |  |
| Losses included in AOCL, net of tax (1) | $ | (8.2) |  |  | $ | — |  |

[0001069202-21-000007:notes:204]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $7.7 million of derivative 
     losses into earnings within the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-21-000007:notes:205]
Expenses included in our Consolidated Statements of Operations

[0001069202-21-000007:notes:206]
Below is information about expenses included in Selling, general and administrative expenses in our Consolidated Statements of Operations (in millions):

[0001069202-21-000007:notes:207]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Research and development | $ | 66.8 |  |  | $ | 69.9 |  |  | $ | 72.2 |  |
| Advertising, promotions and marketing (1) | 26.5 |  |  | 43.7 |  |  | 42.5 |  |
| Cooperative advertising expenditures | 22.2 |  |  | 21.3 |  |  | 16.8 |  |

[0001069202-21-000007:notes:208]
(1) Cooperative advertising expenditures were not included in these amounts.

[0001069202-21-000007:notes:209]
Interest Expense, net

[0001069202-21-000007:notes:210]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-21-000007:notes:211]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest | $ | 29.7 |  |  | $ | 48.6 |  |  | $ | 39.1 |  |
| Less: Interest income | 1.4 |  |  | 1.1 |  |  | 0.8 |  |
| Interest expense, net | $ | 28.3 |  |  | $ | 47.5 |  |  | $ | 38.3 |  |


## us-gaap:ScheduleOfOtherOperatingCostAndExpenseByComponentTextBlock

[0001069202-21-000007:notes:212]
Losses (gains) and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-21-000007:notes:213]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Realized losses (gains) on settled futures contracts | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | (0.4) |  |
| Foreign currency exchange (gains) losses | (3.6) |  |  | (1.5) |  |  | 1.7 |  |
| (Gains) losses on disposal of fixed assets | (0.2) |  |  | (0.2) |  |  | 0.7 |  |
| Other operating (gains) losses, net | (2.2) |  |  | (1.7) |  |  | — |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.3) |  |  | (0.5) |  |  | 1.5 |  |
| Asbestos-related litigation | 5.6 |  |  | 3.1 |  |  | 4.0 |  |
| Special legal contingency charges | 1.1 |  |  | 1.2 |  |  | 1.9 |  |
| Environmental liabilities | (1.4) |  |  | 5.7 |  |  | 2.2 |  |
| Losses from pandemic | 8.3 |  |  | — |  |  | — |  |
| Other items, net | — |  |  | 1.8 |  |  | 1.8 |  |
| Losses (gains) and other expenses, net | $ | 7.4 |  |  | $ | 8.3 |  |  | $ | 13.4 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001069202-21-000007:notes:214]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-21-000007:notes:215]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Current: |  |  |  |  |  |
| Federal | $ | 61.7 |  |  | $ | 55.9 |  |  | $ | 59.5 |  |
| State | 14.1 |  |  | 14.2 |  |  | 17.8 |  |
| Foreign | 4.8 |  |  | 9.3 |  |  | 4.6 |  |
| Total current | 80.6 |  |  | 79.4 |  |  | 81.9 |  |
| Deferred: |  |  |  |  |  |
| Federal | (0.7) |  |  | 15.0 |  |  | 23.2 |  |
| State | 1.1 |  |  | 3.9 |  |  | 1.0 |  |
| Foreign | 7.1 |  |  | 0.8 |  |  | 1.5 |  |
| Total deferred | 7.5 |  |  | 19.7 |  |  | 25.7 |  |
| Total provision for income taxes | $ | 88.1 |  |  | $ | 99.1 |  |  | $ | 107.6 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-21-000007:notes:216]
Losses (Gains) and Other Expenses, net


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-21-000007:notes:217]
Many of our defined benefit pension and profit sharing plans have been frozen and replaced with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen. We also have several active defined benefit plans that provide benefits based on years of service. Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.

[0001069202-21-000007:notes:218]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.

[0001069202-21-000007:notes:219]
Defined Contribution Plans

[0001069202-21-000007:notes:220]
We recorded the following contributions to the defined contribution plans (in millions):

[0001069202-21-000007:notes:221]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Contributions to defined contribution plans | $ | 17.8 |  |  | $ | 19.1 |  |  | $ | 18.8 |  |

[0001069202-21-000007:notes:222]
Pension and Post-retirement Benefit Plans

[0001069202-21-000007:notes:223]
Pension Settlement Activity in 2019

[0001069202-21-000007:notes:224]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100 million of our pension plan assets and $105.6 million of related pension benefit obligations.  In the second quarter of 2019, we recognized a $60.6 million pension settlement charge in the Statement of Operations and reclassified $5.6 million of pension benefit obligations to AOCL as a result of this transaction.

[0001069202-21-000007:notes:225]
On October 15, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $73.5 million of our pension plan assets and $77.9 million of related benefit obligations.  In the fourth quarter of 2019, we recognized a $38.6 million pension settlement charge in the Statement of Operations and reclassified $4.4 million of pension benefit obligations to AOCL as a result of this transaction.

[0001069202-21-000007:notes:226]
Benefit Obligations, Fair Value of Plan Assets, Funded Status, and Balance Sheet Position

[0001069202-21-000007:notes:227]
The following tables set forth amounts recognized in our financial statements and the plans’ funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-21-000007:notes:228]
|  | Pension Benefits |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Accumulated benefit obligation | $ | 273.2 |  |  | $ | 237.3 |  |  |  |  |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 241.5 |  |  | $ | 371.9 |  |  |  |  |  |
| Service cost | 5.5 |  |  | 4.9 |  |  |  |  |  |
| Interest cost | 6.6 |  |  | 10.2 |  |  |  |  |  |
| Amendments | 0.1 |  |  | — |  |  |  |  |  |
| Actuarial (gain) loss | 27.2 |  |  | 38.9 |  |  |  |  |  |
| Effect of exchange rates | 2.2 |  |  | 1.1 |  |  |  |  |  |
| Settlements | (1.3) |  |  | (173.5) |  |  |  |  |  |
| Benefits paid | (5.6) |  |  | (12.0) |  |  |  |  |  |
| Benefit obligation at end of year | $ | 276.2 |  |  | $ | 241.5 |  |  |  |  |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 154.3 |  |  | $ | 291.0 |  |  |  |  |  |
| Actual gain (loss) return on plan assets | 27.3 |  |  | 45.7 |  |  |  |  |  |
| Employer contributions | 3.4 |  |  | 1.8 |  |  |  |  |  |
| Effect of exchange rates | 1.6 |  |  | 1.3 |  |  |  |  |  |
| Plan settlements | (1.3) |  |  | (173.5) |  |  |  |  |  |
| Benefits paid | (5.6) |  |  | (12.0) |  |  |  |  |  |
| Fair value of plan assets at end of year | 179.7 |  |  | 154.3 |  |  |  |  |  |
| Funded status / net amount recognized | $ | (96.5) |  |  | $ | (87.2) |  |  |  |  |  |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Non-current assets | $ | 5.0 |  |  | $ | 3.5 |  |  |  |  |  |
| Current liability | (9.0) |  |  | (3.3) |  |  |  |  |  |
| Non-current liability | (92.5) |  |  | (87.4) |  |  |  |  |  |
| Net amount recognized | $ | (96.5) |  |  | $ | (87.2) |  |  |  |  |  |

[0001069202-21-000007:notes:229]
Plans with Benefit Obligations in Excess of Plan Assets

[0001069202-21-000007:notes:230]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 236.6 |  |  | $ | 204.5 |  |
| Accumulated benefit obligation | 233.3 |  |  | 200.5 |  |
| Fair value of plan assets | 135.2 |  |  | 113.9 |  |

[0001069202-21-000007:notes:231]
Net Periodic Benefit Cost

[0001069202-21-000007:notes:232]
Our U.S.-based pension plans comprised approximately 82%  of the projected benefit obligation and 75% of plan assets as of December 31, 2020.

[0001069202-21-000007:notes:233]
|  | Pension Benefits |  |  |
|  | 2020 |  | 2019 |  | 2018 |  |  |  |  |  |  |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 5.5 |  |  | $ | 4.9 |  |  | $ | 5.3 |  |  |  |  |  |  |  |
| Interest cost | 6.6 |  |  | 10.2 |  |  | 12.3 |  |  |  |  |  |  |  |
| Expected return on plan assets | (8.2) |  |  | (13.4) |  |  | (18.8) |  |  |  |  |  |  |  |
| Amortization of prior service costs | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  |  |  |  |  |  |
| Recognized actuarial loss | 5.8 |  |  | 5.6 |  |  | 9.2 |  |  |  |  |  |  |  |
| Settlements | 0.6 |  |  | 99.2 |  |  | 0.4 |  |  |  |  |  |  |  |
| Other | — |  |  | (0.5) |  |  | 0.3 |  |  |  |  |  |  |  |
| Net periodic benefit cost | $ | 10.5 |  |  | $ | 106.1 |  |  | $ | 8.8 |  |  |  |  |  |  |  |

[0001069202-21-000007:notes:234]
Amounts recognized in AOCL and Other Comprehensive Income

[0001069202-21-000007:notes:235]
The following table sets forth amounts recognized in AOCL and Other comprehensive income (loss) in our financial statements for 2020 and 2019 (in millions):

[0001069202-21-000007:notes:236]
|  | Pension Benefits |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Amounts recognized in AOCL: |  |  |  |  |  |  |  |
| Prior service costs | $ | (0.7) |  |  | $ | (0.8) |  |  |  |  |  |
| Actuarial loss | (103.8) |  |  | (101.6) |  |  |  |  |  |
| Subtotal | (104.5) |  |  | (102.4) |  |  |  |  |  |
| Deferred taxes | 25.6 |  |  | 24.7 |  |  |  |  |  |
| Net amount recognized | $ | (78.9) |  |  | $ | (77.7) |  |  |  |  |  |
| Changes recognized in other comprehensive loss: |  |  |  |  |  |  |  |
| Current year actuarial loss (gain) | 8.1 |  |  | (5.1) |  |  |  |  |  |
| Effect of exchange rates | 0.5 |  |  | 0.5 |  |  |  |  |  |
| Amortization of prior service costs | (0.2) |  |  | (0.1) |  |  |  |  |  |
| Amortization of actuarial loss, including settlements | (6.4) |  |  | (93.1) |  |  |  |  |  |
| Total recognized in other comprehensive income (loss) | $ | 2.0 |  |  | $ | (97.8) |  |  |  |  |  |
| Total recognized in net periodic benefit cost and other comprehensive income | $ | 12.5 |  |  | $ | 8.3 |  |  |  |  |  |

[0001069202-21-000007:notes:237]
The estimated prior service costs and actuarial losses for pension benefits that will be amortized from AOCL in 2021 are $0.2 million and $6.9 million, respectively.

[0001069202-21-000007:notes:238]
Assumptions

[0001069202-21-000007:notes:239]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2020 and 2019:

[0001069202-21-000007:notes:240]
|  |  | Pension Benefits |  |  |
|  |  | 2020 |  | 2019 |  |  |  |  |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |
| Discount rate |  | 2.40 | % |  | 3.19 | % |  |  |  |  |
| Rate of compensation increase |  | 4.13 | % |  | 4.23 | % |  |  |  |  |

[0001069202-21-000007:notes:241]
|  | Pension Benefits |  |  |
|  | 2020 |  | 2019 |  | 2018 |  |  |  |  |  |  |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate - service cost | 2.89 | % |  | 3.96 | % |  | 3.48 | % |  |  |  |  |  |  |
| Discount rate - interest cost | 2.99 | % |  | 3.67 | % |  | 3.22 | % |  |  |  |  |  |  |
| Expected long-term return on plan assets | 6.50 | % |  | 6.50 | % |  | 6.50 | % |  |  |  |  |  |  |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |  |  |  |  |  |  |

[0001069202-21-000007:notes:242]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the non-U.S.-based plans in 2020 and 2019:

[0001069202-21-000007:notes:243]
|  | Pension Benefits |
|  | 2020 |  | 2019 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 1.48 | % |  | 2.15 | % |
| Rate of compensation increase | 3.17 | % |  | 3.20 | % |

[0001069202-21-000007:notes:244]
|  | Pension Benefits |
|  | 2020 |  | 2019 |  | 2018 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 0.73 | % |  | 1.60 | % |  | 1.32 | % |
| Discount rate - interest cost | 2.30 | % |  | 2.98 | % |  | 2.67 | % |
| Expected long-term return on plan assets | 3.31 | % |  | 3.92 | % |  | 4.19 | % |
| Rate of compensation increase | 3.20 | % |  | 3.77 | % |  | 3.62 | % |

[0001069202-21-000007:notes:245]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 6.50% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-21-000007:notes:246]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis to select the discount rate for each plan. The analysis was completed separately for each U.S. pension and OPEB plan. A similar process was followed for the non-U.S.-based plans with sufficient corporate bond information. In other countries, the discount rate was selected based on the approximate duration of plan obligations.

[0001069202-21-000007:notes:247]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-21-000007:notes:248]
|  | 2020 |  | 2019 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 6.00 | % |  | 6.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2023 |  | 2022 |

[0001069202-21-000007:notes:249]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-21-000007:notes:250]
|  | For the Years Ended December 31, |
|  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026-2030 |
| Pension benefits | $ | 12.0 |  |  | $ | 5.8 |  |  | $ | 6.8 |  |  | $ | 11.9 |  |  | $ | 33.1 |  |  | $ | 75.1 |  |

[0001069202-21-000007:notes:251]
Composition of Pension Plan Assets

[0001069202-21-000007:notes:252]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets between equity and fixed income.  In the fourth quarter of 2019, we changed the targeted allocations for our plan assets. The targeted allocation for fixed income and cash investments was changed to 50%, and the targeted allocation for equity investments was changed to 50%. Our targeted exposure to International equity including emerging markets was changed to 6.0% of total assets and our exposure to domestic equity was changed to 44.0%. Our U.S. pension plan represents 75%, our Canadian pension plan 11%, and our United Kingdom (“U.K.”) pension plan 14% of the total fair value of our plan assets as of December 31, 2020.

[0001069202-21-000007:notes:253]
Our U.S. pension plans’ weighted-average asset allocations as of December 31, 2020 and 2019, by asset category, were as follows:

[0001069202-21-000007:notes:254]
|  | Plan Assets as of December 31, |
| Asset Category: | 2020 |  | 2019 |
| U.S. equity | 34.8 | % |  | 44.6 | % |
| International equity | 17.0 | % |  | 7.3 | % |
| Fixed income | 48.0 | % |  | 48.0 | % |
| Money market/cash | 0.2 | % |  | 0.1 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-21-000007:notes:255]
Our U.S. pension plans’ assets were invested according to the following targets:

[0001069202-21-000007:notes:256]
| Asset Category: | Target |
| U.S. equity | 44.0 | % |
| International equity | 6.0 | % |
| Fixed income | 50.0 | % |

[0001069202-21-000007:notes:257]
Our Canadian pension plans were invested approximately 82% in Canadian bonds and 18% in international equities. Our U.K. pension plan was invested in fixed income securities, including corporate and government bonds.

[0001069202-21-000007:notes:258]
The fair values of our pension plan assets, by asset category, were as follows (in millions):

[0001069202-21-000007:notes:259]
|  | Fair Value Measurements as of December 31, 2020 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.4 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 47.0 |  |  | — |  |  | 47.0 |  |
| International equity (2) | — |  |  | 23.0 |  |  | — |  |  | 23.0 |  |
| Fixed income (3) | — |  |  | 64.9 |  |  | — |  |  | 64.9 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Fixed income | — |  |  | 14.1 |  |  | — |  |  | 14.1 |  |
| Pension fund: |  |  |  |  |  |  |  |
| Fixed income (6) | — |  |  | 25.2 |  |  | — |  |  | 25.2 |  |
| Total | $ | 0.4 |  |  | $ | 179.3 |  |  | $ | — |  |  | $ | 179.7 |  |

[0001069202-21-000007:notes:260]
|  | Fair Value Measurements as of December 31, 2019 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 50.8 |  |  | — |  |  | 50.8 |  |
| International equity (2) | — |  |  | 8.3 |  |  | — |  |  | 8.3 |  |
| Fixed income (3) | — |  |  | 54.6 |  |  | — |  |  | 54.6 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.8 |  |  | — |  |  | 4.8 |  |
| Fixed income | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Pension fund: |  |  |  |  |  |  |  |
| Fixed income (5) | — |  |  | 22.0 |  |  | — |  |  | 22.0 |  |
| Total | $ | 0.2 |  |  | $ | 154.1 |  |  | $ | — |  |  | $ | 154.3 |  |

[0001069202-21-000007:notes:261]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-21-000007:notes:262]
|  | As of December 31, 2020 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 47.0 |  |  | Daily |  | 5 days |
| International equity (2) | 23.0 |  |  | Daily |  | 5 days |
| Fixed income (3) | 64.9 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 5.1 |  |  | Daily |  | 3-5 days |
| Fixed income | 14.1 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (5) | 25.2 |  |  | Daily |  | 3 days |
| Total | $ | 179.3 |  |  |  |  |  |

[0001069202-21-000007:notes:263]
|  | As of December 31, 2019 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 50.8 |  |  | Daily |  | 5 days |
| International equity (2) | 8.3 |  |  | Daily |  | 5 days |
| Fixed income (3) | 54.6 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.8 |  |  | Daily |  | 3-5 days |
| Fixed income | 13.6 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (5) | 22.0 |  |  | Daily |  | 1-3 days |
| Total | $ | 154.1 |  |  |  |  |  |

[0001069202-21-000007:notes:264]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the plan are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The plan also holds a portion of its assets in international equities, a portion of which may be invested in U.S. securities. |
| (5) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer with a derivatives overlay and investment grade corporate bonds denominated in sterling. |

[0001069202-21-000007:notes:265]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund’s NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the number of units owned.  See Note 17 for information about our fair value hierarchies and valuation techniques.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-21-000007:notes:266]
participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001069202-21-000007:notes:267]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Equity method investments | $ | 37.0 |  |  | $ | 38.6 |  |

[0001069202-21-000007:notes:268]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-21-000007:notes:269]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Purchases of compressors from joint venture | $ | 123.1 |  |  | $ | 123.1 |  |  | $ | 103.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-21-000007:notes:270]
r Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-21-000007:notes:271]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-21-000007:notes:272]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Domestic | $ | 268.4 |  |  | $ | 383.2 |  |  | $ | 428.7 |  |
| Foreign | 176.8 |  |  | 124.7 |  |  | 39.2 |  |
| Total | $ | 445.2 |  |  | $ | 507.9 |  |  | $ | 467.9 |  |

[0001069202-21-000007:notes:273]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-21-000007:notes:274]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Provision at the U.S. statutory rate of 21% | $ | 93.5 |  |  | $ | 106.7 |  |  | $ | 98.3 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 10.8 |  |  | 13.2 |  |  | 15.5 |  |
| Tax credits, net of unrecognized tax benefits | (7.8) |  |  | (13.8) |  |  | (2.5) |  |
| Change in unrecognized tax benefits | 0.2 |  |  | 3.1 |  |  | 0.4 |  |
| Change in valuation allowance | 7.8 |  |  | 1.9 |  |  | 5.0 |  |
| Foreign taxes at rates other than U.S. statutory rate | (33.6) |  |  | (20.7) |  |  | (3.2) |  |
| Deemed inclusions | 9.2 |  |  | 8.3 |  |  | 3.9 |  |
| Global intangible low-taxed income | 10.3 |  |  | 9.5 |  |  | 0.7 |  |
| Change in rates from the Tax Act & other law changes | 0.7 |  |  | (0.8) |  |  | 1.9 |  |
| Excess tax benefits from stock-based compensation | (4.2) |  |  | (10.9) |  |  | (10.5) |  |
| Miscellaneous other | 1.2 |  |  | 2.6 |  |  | (1.9) |  |
| Total provision for income taxes | $ | 88.1 |  |  | $ | 99.1 |  |  | $ | 107.6 |  |

[0001069202-21-000007:notes:275]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-21-000007:notes:276]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-21-000007:notes:277]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 29.2 |  |  | $ | 27.8 |  |
| Loss carryforwards (foreign, U.S. and state) | 26.8 |  |  | 23.2 |  |
| Post-retirement and pension benefits | 24.8 |  |  | 22.4 |  |
| Inventory reserves | 7.3 |  |  | 5.6 |  |
| Receivables allowance | 3.8 |  |  | 3.1 |  |
| Compensation liabilities | 10.2 |  |  | 6.2 |  |
| Insurance liabilities | — |  |  | 1.6 |  |
| Legal reserves | 10.1 |  |  | 8.5 |  |
| Tax credits, net of federal effect | 11.1 |  |  | 11.4 |  |
| Other | 8.0 |  |  | 7.1 |  |
| Total deferred tax assets | 131.3 |  |  | 116.9 |  |
| Valuation allowance | (37.0) |  |  | (24.9) |  |
| Total deferred tax assets, net of valuation allowance | 94.3 |  |  | 92.0 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (58.7) |  |  | (52.5) |  |
| Intangibles | (15.2) |  |  | (15.1) |  |
| Insurance liabilities | (1.0) |  |  | — |  |
| Other | (6.2) |  |  | (2.9) |  |
| Total deferred tax liabilities | (81.1) |  |  | (70.5) |  |
| Net deferred tax assets | $ | 13.2 |  |  | $ | 21.5 |  |

[0001069202-21-000007:notes:278]
As of December 31, 2020 and 2019, we had zero and $0.1 million in tax-effected state net operating loss carryforwards, respectively, and $18.6 million and $14.9 million in tax-effected foreign net operating loss carryforwards, respectively. The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards in European tax jurisdictions.  The remainder of the valuation allowance relates to state tax credits.

[0001069202-21-000007:notes:279]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of  December 31, 2020.

[0001069202-21-000007:notes:280]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries’ earnings. An actual repatriation in the future from our non-U.S. subsidiaries could still be subject to foreign withholding taxes and U.S. state taxes, but we expect any amounts to be immaterial.

[0001069202-21-000007:notes:281]
We are currently under examination for our U.S. federal income taxes for 2020 and 2019 and are subject to examination by numerous other taxing authorities in the U.S. and foreign jurisdictions.  We are generally no longer subject to U.S., state and local or non-U.S. income tax examinations by taxing authorities for years before 2013.


## us-gaap:DebtDisclosureTextBlock

[0001069202-21-000007:notes:282]
The following tables summarize our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-21-000007:notes:283]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 285.0 |  |
| Finance lease obligations | 10.1 |  |  | 7.8 |  |
| Domestic credit facility | — |  |  | 30.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 9.9 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 29.3 |  |  | 25.9 |  |
| Domestic credit facility | — |  |  | 475.5 |  |
| Senior unsecured notes | 950.0 |  |  | 350.0 |  |
| Debt issuance costs | (8.6) |  |  | (2.1) |  |
| Total long-term debt | $ | 970.7 |  |  | $ | 849.3 |  |
| Total debt | $ | 980.6 |  |  | $ | 1,171.2 |  |

[0001069202-21-000007:notes:284]
As of December 31, 2020, the aggregate amounts of required principal payments on total debt excluding finance lease obligations (see Note 5) were as follows (in millions):

[0001069202-21-000007:notes:285]
| 2021 | $ | — |  |
| 2022 | — |  |
| 2023 | 350.0 |  |
| 2024 | — |  |
| 2025 | 300.0 |  |
| Thereafter | 300.0 |  |

[0001069202-21-000007:notes:286]
Short-Term Debt

[0001069202-21-000007:notes:287]
Foreign Obligations

[0001069202-21-000007:notes:288]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. As of December 31, 2020 or 2019, we did not have any outstanding short-term foreign obligations.  Proceeds and repayments from these facilities were $4.6 million, $5.3 million and $40.3 million during the years ended December 31, 2020, 2019 and 2018, respectively.

[0001069202-21-000007:notes:289]
Asset Securitization Program

[0001069202-21-000007:notes:290]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheet and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001069202-21-000007:notes:291]
We renewed the ASP in November 2019, extending its term to November 2021 and increasing the maximum securitization amount to a range from $250.0 million to $400.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-21-000007:notes:292]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 279.1 |  |  | $ | 320.0 |  |
| Less: Beneficial interest transferred | — |  |  | (285.0) |  |
| Remaining amount available | $ | 279.1 |  |  | $ | 35.0 |  |

[0001069202-21-000007:notes:293]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of December 31, 2020 and 2019 were 0.00% as there were no outstanding borrowings and 2.51%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at rate ranging between 0.25% and 0.35%, depending on available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-21-000007:notes:294]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Seventh Amended and Restated Credit Facility Agreement (“Domestic Credit Facility”), senior unsecured notes and any other indebtedness we may have over  $75.0 million.  The administrative agent under the ASP is also a participant in our Domestic Credit Facility.  The participating financial institutions have investment grade credit ratings.  As of December 31, 2020, we believe we were in compliance with all covenant requirements.

[0001069202-21-000007:notes:295]
Long-Term Debt

[0001069202-21-000007:notes:296]
Domestic Credit Facility

[0001069202-21-000007:notes:297]
On July 30, 2020, we amended our Domestic Credit Facility to extend the term of our revolving credit facility by one year and to provide for a $250.0 million decrease in revolving commitments. The amended Domestic Credit Facility currently consists of a $750.0 million unsecured revolving credit facility that matures in August 2022 (the “Maturity Date”).  The previously outstanding unsecured term loan was fully repaid in September 2020.

[0001069202-21-000007:notes:298]
Under our Domestic Credit Facility, we had outstanding borrowings of $0.0 million as well as $2.2 million committed to standby letters of credit as of December 31, 2020. Subject to covenant limitations, $747.8 million was available for future borrowings. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

[0001069202-21-000007:notes:299]
Our weighted average borrowing rate on the facility was 0% as of December 31, 2020 as there were no outstanding borrowings.  Below is a summary of the weighted average interest rate for both December 31, 2020 and 2019:

[0001069202-21-000007:notes:300]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Weighted average borrowing rate | — | % |  | 2.93 | % |

[0001069202-21-000007:notes:301]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-21-000007:notes:302]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-21-000007:notes:303]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-21-000007:notes:304]
•    We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001069202-21-000007:notes:305]
•    We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-21-000007:notes:306]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-21-000007:notes:307]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2020, we believe we were in compliance with all covenant requirements.

[0001069202-21-000007:notes:308]
Senior Unsecured Notes

[0001069202-21-000007:notes:309]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.

[0001069202-21-000007:notes:310]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of December 31, 2020, we believe we were in compliance with all covenant requirements.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001069202-21-000007:notes:311]
The following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-21-000007:notes:312]
|  |  | For the Years Ended December 31, |  |  |
| AOCL Component |  | 2020 |  | 2019 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Derivative contracts |  | $ | (3.7) |  |  | $ | (6.9) |  |  | Cost of goods sold and Losses (gains) and other expenses, net. |
| Income tax benefit |  | 0.9 |  |  | 1.6 |  |  | Provision for income taxes |
| Net of tax |  | $ | (2.8) |  |  | $ | (5.3) |  |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and post-retirement benefits costs |  | $ | (5.9) |  |  | $ | (5.7) |  |  | Cost of goods sold; Selling, general, administrative expenses and Other (income) expense, net |
| Pension settlements |  | (0.6) |  |  | (99.2) |  |  | Pension settlements |
| Income tax benefit |  | 1.6 |  |  | 26.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (4.9) |  |  | $ | (78.7) |  |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Foreign currency adjustments on sale of business |  | $ | — |  |  | $ | (2.1) |  |  | Loss (gain), net on sale of businesses and related property |
| Income tax benefit |  | — |  |  | — |  |  | Provision for income taxes |
| Net of tax |  | $ | — |  |  | $ | (2.1) |  |  |  |
| Total reclassifications from AOCL |  | $ | (7.7) |  |  | $ | (86.1) |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-21-000007:notes:313]
following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-21-000007:notes:314]
The following tables provide information on changes in AOCL, by component (net of tax), for the years ended December 31, 2020 and 2019 (in millions):

[0001069202-21-000007:notes:315]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2019 |  | $ | — |  |  | $ | — |  |  | $ | (81.5) |  |  | $ | (22.3) |  |  | $ | (103.8) |  |
| Other comprehensive income (loss) before reclassifications |  | 5.4 |  |  | (1.2) |  |  | (6.1) |  |  | 0.8 |  |  | (1.1) |  |
| Amounts reclassified from AOCL |  | 2.8 |  |  | — |  |  | 4.9 |  |  | — |  |  | 7.7 |  |
| Net other comprehensive income (loss) |  | 8.2 |  |  | (1.2) |  |  | (1.2) |  |  | 0.8 |  |  | 6.6 |  |
| Balance as of December 31, 2020 |  | $ | 8.2 |  |  | $ | (1.2) |  |  | $ | (82.7) |  |  | $ | (21.5) |  |  | $ | (97.2) |  |

[0001069202-21-000007:notes:316]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2018 |  | $ | (6.2) |  |  | $ | — |  |  | $ | (154.5) |  |  | $ | (28.1) |  |  | $ | (188.8) |  |
| Other comprehensive income (loss) before reclassifications |  | 0.9 |  |  | — |  |  | (5.7) |  |  | 3.7 |  |  | (1.1) |  |
| Amounts reclassified from AOCI |  | 5.3 |  |  | — |  |  | 78.7 |  |  | 2.1 |  |  | 86.1 |  |
| Net other comprehensive income (loss) |  | 6.2 |  |  | — |  |  | 73.0 |  |  | 5.8 |  |  | 85.0 |  |
| Balance as of December 31, 2019 |  | $ | — |  |  | $ | — |  |  | $ | (81.5) |  |  | $ | (22.3) |  |  | $ | (103.8) |  |


## us-gaap:ScheduleOfCompensationCostForShareBasedPaymentArrangementsAllocationOfShareBasedCompensationCostsByPlanTableTextBlock

[0001069202-21-000007:notes:317]
Stock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-21-000007:notes:318]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Compensation expense(1) | $ | 24.3 |  |  | $ | 21.3 |  |  | $ | 26.3 |  |

[0001069202-21-000007:notes:319]
(1) Stock-based compensation expense was recorded in our Corporate and other business segment.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-21-000007:notes:320]
ock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-21-000007:notes:321]
Incentive Plan

[0001069202-21-000007:notes:322]
Under the Lennox International Inc. 2019 Equity and Incentive Plan Compensation Plan, we are authorized to issue awards for 1.5 million shares of common stock. The plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-21-000007:notes:323]
As of December 31, 2020, awards for 0.1 million shares of common stock had been granted, net of cancellations and repurchases, and there were 1.4 million shares available for future issuance.

[0001069202-21-000007:notes:324]
Performance Share Units

[0001069202-21-000007:notes:325]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII’s performance over the three-year performance period.

[0001069202-21-000007:notes:326]
Performance share units are classified as equity awards. Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded. Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-21-000007:notes:327]
The following table provides information on our performance share units:

[0001069202-21-000007:notes:328]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Compensation expense for performance share units (in millions) | $ | 8.9 |  |  | $ | 6.8 |  |  | $ | 12.3 |  |
| Weighted-average fair value of grants, per share | $ | 265.96 |  |  | $ | 245.06 |  |  | $ | 204.64 |  |
| Payout ratio for shares paid | 132.7 | % |  | 157.2 | % |  | 173.2 | % |

[0001069202-21-000007:notes:329]
A summary of the status of our undistributed performance share units as of December 31, 2020, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001069202-21-000007:notes:330]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2019 | 202.3 |  |  | $ | 191.14 |  |
| Granted | 33.6 |  |  | $ | 265.96 |  |
| Distributed | (72.0) |  |  | $ | 150.21 |  |
| Forfeited | (4.5) |  |  | $ | 205.99 |  |
| Undistributed performance share units as of December 31, 2020 (1) | 159.4 |  |  | $ | 224.95 |  |

[0001069202-21-000007:notes:331]
(1) Undistributed performance share units include approximately 114.5 thousand units with a weighted-average grant date fair value of $235.71 per share that had not yet vested and 44.9 thousand units that have vested but were not yet distributed.

[0001069202-21-000007:notes:332]
As of December 31, 2020, we had $16.6 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.3 years. Our weighted-average estimated forfeiture rate for these performance share units was 9.4% as of December 31, 2020.

[0001069202-21-000007:notes:333]
The total fair value of performance share units distributed and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001069202-21-000007:notes:334]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Fair value of performance share units distributed | $ | 15.1 |  |  | $ | 20.2 |  |  | $ | 21.1 |  |
| Realized tax benefits from tax deductions | $ | 0.7 |  |  | $ | 5.1 |  |  | $ | 5.3 |  |

[0001069202-21-000007:notes:335]
Restricted Stock Units

[0001069202-21-000007:notes:336]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-21-000007:notes:337]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-21-000007:notes:338]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Compensation expense for restricted stock units | $ | 10.4 |  |  | $ | 9.7 |  |  | $ | 9.2 |  |
| Weighted-average fair value of grants, per share | $ | 265.96 |  |  | $ | 247.02 |  |  | $ | 204.64 |  |

[0001069202-21-000007:notes:339]
A summary of our non-vested restricted stock units as of December 31, 2020 and changes during the year then ended is presented below (in thousands, except per share data):

[0001069202-21-000007:notes:340]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2019 | 157.0 |  |  | $ | 216.07 |  |
| Granted | 40.9 |  |  | $ | 265.96 |  |
| Vested | (54.0) |  |  | $ | 200.27 |  |
| Forfeited | (7.9) |  |  | $ | 213.40 |  |
| Non-vested restricted stock units as of December 31, 2020 (1) | 136.0 |  |  | $ | 237.45 |  |

[0001069202-21-000007:notes:341]
(1) As of December 31, 2020, we had $19.2 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.3 years.  Our estimated forfeiture rate for restricted stock units was 14.3% as of December 31, 2020.

[0001069202-21-000007:notes:342]
The total fair value of restricted stock units vested and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001069202-21-000007:notes:343]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Fair value of restricted stock units vested | $ | 15.0 |  |  | $ | 10.9 |  |  | $ | 9.7 |  |
| Realized tax benefits from tax deductions | 2.7 |  |  | 2.7 |  |  | 2.4 |  |

[0001069202-21-000007:notes:344]
Stock Appreciation Rights

[0001069202-21-000007:notes:345]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive compensation, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years .  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-21-000007:notes:346]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-21-000007:notes:347]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Compensation expense for stock appreciation rights | $ | 5.0 |  |  | $ | 4.8 |  |  | $ | 4.8 |  |
| Weighted-average fair value of grants, per share | $ | 55.21 |  |  | $ | 39.40 |  |  | $ | 35.57 |  |

[0001069202-21-000007:notes:348]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-21-000007:notes:349]
The fair value of the stock appreciation rights granted in 2020, 2019 and 2018 were estimated on the date of grant using the following assumptions:

[0001069202-21-000007:notes:350]
|  | 2020 |  | 2019 |  | 2018 |
| Expected dividend yield | 1.64 | % |  | 1.77 | % |  | 1.76 | % |
| Risk-free interest rate | 0.27 | % |  | 1.59 | % |  | 2.71 | % |
| Expected volatility | 29.70 | % |  | 21.23 | % |  | 20.60 | % |
| Expected life (in years) | 3.95 |  | 3.96 |  | 3.93 |

[0001069202-21-000007:notes:351]
A summary of our stock appreciation rights as of December 31, 2020, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001069202-21-000007:notes:352]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2019 | 796.7 |  |  | $ | 181.15 |  |
| Granted | 92.4 |  |  | $ | 278.00 |  |
| Exercised | (191.0) |  |  | $ | 130.35 |  |
| Forfeited | (18.6) |  |  | $ | 225.82 |  |
| Outstanding stock appreciation rights as of December 31, 2020 | 679.5 |  |  | $ | 205.41 |  |
| Exercisable stock appreciation rights as of December 31, 2020 | 458.0 |  |  | $ | 182.99 |  |

[0001069202-21-000007:notes:353]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2020 (in millions, except per share data and years; shares in thousands):

[0001069202-21-000007:notes:354]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares (1) |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $99.64 to $156.94 |  | 200.3 |  |  | 2.39 |  | $ | 28.4 |  |  | 200.3 |  |  | 1.28 |  | $ | 27.0 |  |
| $205.53 to $214.63 |  | 256.0 |  |  | 4.49 |  | $ | 16.4 |  |  | 214.0 |  |  | 4.39 |  | $ | 13.9 |  |
| $257.08 to $278.00 |  | 223.2 |  |  | 6.41 |  | $ | 2.2 |  |  | 43.7 |  |  | 6.00 |  | $ | 0.7 |  |

[0001069202-21-000007:notes:355]
(1) Share amounts are rounded but the balance accurately reflects the actual amount of exercisable stock appreciation rights as of December 31, 2020.

[0001069202-21-000007:notes:356]
As of December 31, 2020, we had $9.2 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for stock appreciation rights was 11.8% as of December 31, 2020.

[0001069202-21-000007:notes:357]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-21-000007:notes:358]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Intrinsic value of stock appreciation rights exercised | $ | 26.7 |  |  | $ | 37.1 |  |  | $ | 35.9 |  |
| Realized tax benefits from tax deductions | $ | 6.7 |  |  | $ | 9.3 |  |  | $ | 8.9 |  |

[0001069202-21-000007:notes:359]
Employee Stock Purchase Plan

[0001069202-21-000007:notes:360]
Under the 2012 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 12,700 shares under the ESPP during the year ended December 31, 2020.  Approximately 2.4 million shares remain available for purchase under the ESPP as of December 31, 2020.


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-21-000007:notes:361]
ir value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities. Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:
Level 1 -      Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-21-000007:notes:362]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001069202-21-000007:notes:363]
Level 3 -     Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001069202-21-000007:notes:364]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2020 and 2019, the measurement dates.

[0001069202-21-000007:notes:365]
The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2020 were the same as those used as of December 31, 2019.

[0001069202-21-000007:notes:366]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-21-000007:notes:367]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-21-000007:notes:368]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty’s creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 10 for more information related to our derivative instruments.

[0001069202-21-000007:notes:369]
Other Fair Value Disclosures

[0001069202-21-000007:notes:370]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-21-000007:notes:371]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-21-000007:notes:372]
|  | As of December 31, |
|  | 2020 |  | 2019 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 971.6 |  |  | $ | 356.8 |  |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001069202-21-000007:notes:373]
The following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-21-000007:notes:374]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (1) |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| First Quarter | $ | 723.8 |  |  | $ | 790.3 |  |  | $ | 165.7 |  |  | $ | 201.6 |  |  | $ | 12.9 |  |  | $ | 69.3 |  |
| Second Quarter | $ | 941.3 |  |  | $ | 1,099.1 |  |  | $ | 275.7 |  |  | $ | 332.1 |  |  | $ | 100.0 |  |  | $ | 110.7 |  |
| Third Quarter | $ | 1,055.0 |  |  | $ | 1,032.9 |  |  | $ | 323.3 |  |  | $ | 298.3 |  |  | $ | 131.7 |  |  | $ | 114.7 |  |
| Fourth Quarter | $ | 914.0 |  |  | $ | 885.0 |  |  | $ | 275.3 |  |  | $ | 247.8 |  |  | $ | 111.7 |  |  | $ | 114.0 |  |

[0001069202-21-000007:notes:375]
|  | Basic Earnings per Share (2) |  | Diluted Earnings per Share (2) |  | Cash Dividends per Common Share |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| First Quarter | $ | 0.34 |  |  | $ | 1.75 |  |  | $ | 0.33 |  |  | $ | 1.73 |  |  | $ | 0.77 |  |  | $ | 0.64 |  |
| Second Quarter | $ | 2.62 |  |  | $ | 2.83 |  |  | $ | 2.60 |  |  | $ | 2.80 |  |  | $ | 0.77 |  |  | $ | 0.77 |  |
| Third Quarter | $ | 3.44 |  |  | $ | 2.97 |  |  | $ | 3.42 |  |  | $ | 2.94 |  |  | $ | 0.77 |  |  | $ | 0.77 |  |
| Fourth Quarter | $ | 2.92 |  |  | $ | 2.96 |  |  | $ | 2.89 |  |  | $ | 2.93 |  |  | $ | 0.77 |  |  | $ | 0.77 |  |

[0001069202-21-000007:notes:376]
(1)  The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-21-000007:notes:377]
(2)  EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-21-000007:notes:378]
following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-21-000007:notes:379]
Summary of 2020 Quarterly Results

[0001069202-21-000007:notes:380]
The following unusual or infrequent pre-tax items were included in the 2020 quarterly results:

[0001069202-21-000007:notes:381]
1st Quarter.  The worldwide outbreak of COVID-19 , which was declared a pandemic by the World Health Organization on March 11, 2020, had impacted and may continue to impact our business operations.

[0001069202-21-000007:notes:382]
2nd Quarter.   Due to the economic impact of the COVID-19 pandemic on our business, we implemented cost reduction actions in April 2020 to realize SG&A savings for the balance of the year. Refer to Note 8 for details related to restructuring.

[0001069202-21-000007:notes:383]
3rd Quarter. Our manufacturing facility in Marshalltown, Iowa was damaged by a wind storm. Refer to Note 5 for details related to the wind storm damage.

[0001069202-21-000007:notes:384]
4th Quarter. We recognized a $6.6 million receivable from insurance recoveries related to our Marshalltown facility, refer to Note 5 for further details.

[0001069202-21-000007:notes:385]
Summary of 2019 Quarterly Results

[0001069202-21-000007:notes:386]
The following unusual or infrequent pre-tax items were included in the 2019 quarterly results:

[0001069202-21-000007:notes:387]
1st Quarter.  We signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. Refer to Note 7 for details regarding the divestiture.  We also recorded gains of $46.4 million from insurance recoveries related to our Marshalltown facility; refer to Note 5 for details.

[0001069202-21-000007:notes:388]
2nd Quarter.   We entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer our pension plan assets and related pension benefit obligations. Refer to Note 11 for details regarding the transaction.  We also recorded gains of $31.9 million from insurance recoveries related to our Marshalltown facility; refer to Note 5 for details.

[0001069202-21-000007:notes:389]
3rd Quarter.  We recorded gains of $7.1 million from insurance recoveries related to our Marshalltown facility; refer to Note 5 for details.

[0001069202-21-000007:notes:390]
4th Quarter.  We entered into a second agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer our pension plan assets and related pension benefit obligations. Refer to Note 11 for details regarding the transaction.  We also reached a final settlement with our insurance carriers for the losses incurred from tornado damage at our Marshalltown  facility.  We recorded gains of $93.4 million for the settlement and receipt of insurance recoveries; refer to Note 5 for further details.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-21-000007:notes:391]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-21-000007:notes:392]
For the Years Ended December 31, 2020, 2019 and 2018

[0001069202-21-000007:notes:393]
(In millions)

[0001069202-21-000007:notes:394]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 5.9 |  |  | $ | 4.8 |  |  | $ | (3.7) |  |  | $ | 0.6 |  |  | $ | (1.3) |  |  | $ | 6.3 |  |
| 2019 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.3 |  |  | $ | 4.5 |  |  | $ | (4.9) |  |  | $ | 1.6 |  |  | $ | (1.4) |  |  | $ | 6.1 |  |
| 2020 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.1 |  |  | $ | 8.1 |  |  | $ | (4.2) |  |  | $ | 1.2 |  |  | $ | (1.6) |  |  | $ | 9.6 |  |
