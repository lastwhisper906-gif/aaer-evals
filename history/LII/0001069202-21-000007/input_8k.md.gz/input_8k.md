# LII 8-K — 0001069202-21-000004 filed 2021-02-02

## item codes, every 8-K on or before 2021-02-16

- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2021-02-16

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-21-000004:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetables20.htm
EX-99.1

[0001069202-21-000004:8k_2_02:2]
Document

[0001069202-21-000004:8k_2_02:3]
Exhibit-99.1

[0001069202-21-000004:8k_2_02:4]
Lennox International Reports Record Fourth Quarter Revenue and Record Cash Flow for the Year

[0001069202-21-000004:8k_2_02:5]
•Fourth-quarter record company revenue of $914 million, up 3%

[0001069202-21-000004:8k_2_02:6]
•Fourth-quarter GAAP EPS from continuing operations of $2.91 compared to $2.92 in the prior-year quarter; adjusted EPS from continuing operations up 18% to a fourth-quarter record of $2.89

[0001069202-21-000004:8k_2_02:7]
•Generated record $612 million of cash from operations and record $535 million of free cash flow, paid $118 million in dividends and repurchased $100 million of stock in 2020

[0001069202-21-000004:8k_2_02:8]
•Reiterating 2021 guidance for adjusted revenue growth of 4-8%

[0001069202-21-000004:8k_2_02:9]
•Reiterating 2021 guidance for GAAP and adjusted EPS from continuing operations of $10.55-$11.15

[0001069202-21-000004:8k_2_02:10]
•Reiterating 2021 guidance for $400 million of stock repurchases

[0001069202-21-000004:8k_2_02:11]
DALLAS, February 2, 2021 – Lennox International Inc. (NYSE: LII), a global leader in energy-efficient climate-control solutions, today reported fourth-quarter and full-year 2020 results. All comparisons are to the prior-year period. The company’s insurance references relate to damage at a Residential manufacturing facility in Iowa. Adjusted revenue and profit for the full-year of 2019 exclude non-core Refrigeration businesses divested in the first half of that year.

[0001069202-21-000004:8k_2_02:12]
For the fourth quarter of 2020, revenue was a fourth-quarter record $914 million, up 3%. Foreign exchange was neutral to revenue. GAAP operating income was $139 million compared to $192 million in the prior-year quarter that included a $93 million net gain from insurance recoveries. Fourth-quarter GAAP earnings per share from continuing operations was $2.91 compared to $2.92 in the prior-year quarter that included the insurance benefit and a $39 million pre-tax pension settlement.

[0001069202-21-000004:8k_2_02:13]
Total segment profit was a fourth-quarter record $139 million, up 5% from the prior-year quarter $133 million that included $25 million in insurance recovery. Total segment margin was a fourth-quarter record 15.2%, up 10 basis points. Adjusted earnings per share from continuing operations rose 18% to a fourth-quarter record $2.89.

[0001069202-21-000004:8k_2_02:14]
For the full year, revenue was $3.63 billion, down 5% on a GAAP basis and down 4% on an adjusted basis excluding the impact from divestitures in the prior year. Foreign exchange was neutral to revenue. GAAP operating income was $479 million compared to $657 million in the prior year that included a $179 million net gain from insurance recoveries. GAAP earnings per share from continuing operations was $9.26 compared to $10.38 in the prior year that included the insurance benefit and $99 million pre-tax in pension settlements.

[0001069202-21-000004:8k_2_02:15]
Total adjusted segment profit for the full year was $507 million compared to $610 million in the prior year that included $99 million of insurance recovery. Total adjusted segment margin was 13.9% for the year compared to 16.2% in the prior year with the insurance benefit. Adjusted earnings per share from continuing operations was $9.94 compared to $11.19 in the prior year with the insurance benefit and pension settlements.

[0001069202-21-000004:8k_2_02:16]
“Lennox International posted new fourth-quarter highs for revenue, total segment profit and margin, and adjusted EPS from continuing operations in the fourth quarter, led by the continued strength in our Residential business,” said Chairman and CEO Todd Bluedorn. “Residential posted new fourth-quarter records for revenue and segment profit and margin. Residential revenue rose 11% on double-digit growth in both replacement and new construction business. Segment profit rose 18% and margin expanded 130 basis points to 20.9%. From an operational perspective, adjusted for the $25 million of insurance benefit in the prior-year quarter, Residential profit rose 58% and margin expanded 630 basis points.

[0001069202-21-000004:8k_2_02:17]
“In the fourth quarter for Commercial, revenue was down 13%, and segment profit was down 11%. Segment margin expanded 40 basis points to a fourth-quarter record 19.4%. Both replacement and new construction business reflected year-over-year improvement from the prior quarter this year, as did national account and regional and local business. In Refrigeration, revenue was up 3% at constant currency. Segment profit declined 28% and margin contracted 360 basis points to 7.5% on the timing of expenses in the quarter and unfavorable mix with Europe HVAC growing high-single digits at constant currency. For both our Refrigeration and Commercial businesses, backlog is up double-digits.

[0001069202-21-000004:8k_2_02:18]
“Looking ahead, there is economic and market uncertainty, but momentum continues for the company, and we are well-positioned for a year of strong growth and profitability. We reiterate guidance for 2021, including $400 million of stock repurchases.”

[0001069202-21-000004:8k_2_02:19]
FOURTH QUARTER 2020 FINANCIAL HIGHLIGHTS

[0001069202-21-000004:8k_2_02:20]
Revenue: Revenue for the fourth quarter was $914 million, up 3%. Foreign exchange was neutral to revenue. Volume was up, price was favorable, and mix was unfavorable from the prior-year quarter.

[0001069202-21-000004:8k_2_02:21]
Gross Profit: On a GAAP basis for the fourth quarter, gross profit was $275 million, up 11%, and gross margin was 30.1%, up 210 basis points. On an adjusted basis for the fourth quarter, gross profit was $277 million, up 12%, and gross margin was 30.3%, up 230 basis points. Gross profit was favorably impacted by higher volume, favorable price, lower material and other product costs, and higher factory productivity. Partial offsets included negative impact from the COVID-19 pandemic, unfavorable mix, and higher freight, distribution, warranty and tariff costs.

[0001069202-21-000004:8k_2_02:22]
Income from Continuing Operations: On a GAAP basis, fourth quarter income from continuing operations was $112.2 million, or $2.91 diluted earnings per share, compared to $113.8 million, or $2.92 diluted earnings per share, in the prior-year quarter.

[0001069202-21-000004:8k_2_02:23]
On an adjusted basis, fourth quarter income from continuing operations was $111.4 million, or $2.89 diluted earnings per share, compared to $95.1 million, or $2.45 diluted earnings per share, in the prior-year quarter. Adjusted income from continuing operations for the fourth quarter of 2020 excludes a net after-tax gain of $0.8 million, consisting of: a charge of $2.7 million for asbestos-related litigation, $1.5 million for special product quality adjustments, $1.4 million for personal protective equipment and facility deep cleaning expenses incurred due to the COVID-19 pandemic, a net gain of $3.4 million for insurance recoveries related to damage at the company’s manufacturing facility in Iowa, a benefit of $2.3 million related to environmental liabilities, a benefit of $1.5 million for excess tax benefits from share-based compensation, and a net charge of $0.8 million in total for various other items.

[0001069202-21-000004:8k_2_02:24]
FULL YEAR 2020 FINANCIAL HIGHLIGHTS

[0001069202-21-000004:8k_2_02:25]
Revenue: For the full year, revenue was $3.63 billion, down 5% on a GAAP basis and down 4% on an adjusted basis excluding the impact from divestitures in the prior year. Foreign exchange was neutral to revenue. Volume was down, and price and mix were favorable.

[0001069202-21-000004:8k_2_02:26]
Gross Profit: Gross profit for the full year was $1.04 billion, down 4% on a GAAP basis and down 3% on an adjusted basis excluding the impact from divestitures. Gross margin was 28.6%, up 20 basis points on a GAAP basis and up 10 basis points on an adjusted basis. Gross profit was negatively impacted by the COVID-19 pandemic, lower volume, factory inefficiencies, unfavorable mix, higher tariffs, and higher warranty. On a GAAP basis, divestitures had a negative impact on gross profit. Partial offsets included favorable price, lower material and other product costs, and lower freight and distribution costs.

[0001069202-21-000004:8k_2_02:27]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for 2020 was $357.1 million, or $9.26 diluted earnings per share, compared to $408.8 million, or $10.38 diluted earnings per share, in the prior year.

[0001069202-21-000004:8k_2_02:28]
On an adjusted basis, income from continuing operations for 2020 was $383.1 million, or $9.94 diluted earnings per share, compared to $439.9 million, or $11.19 diluted earnings per share, in the prior year. Adjusted income from continuing operations for 2020 excludes net after-tax charges of $26.0 million, consisting of: a charge of $8.5 million for other tax items, $8.4 million for restructuring activities, $6.2 million for personal protective equipment and facility deep cleaning expenses incurred due to the COVID-19 pandemic, $4.2 million for asbestos-related litigation, a net loss of $2.3 million related to damage at the company’s manufacturing facility in Iowa, a benefit of $4.2 million for excess tax benefits from share-based compensation, and a net charge of $0.6 million in total for various other items.

[0001069202-21-000004:8k_2_02:29]
Free Cash Flow and Total Debt: For the full year, cash from operations was $612 million compared to $396 million in the prior year. Capital expenditures were approximately $78 million compared to $106 million in the prior year. Proceeds for damage to property and disposal of property were $1 million for the year compared to $81 million in the prior year. Free cash flow was $535 million for the full year compared to $371 million in the prior year. In 2020, the company paid $118 million in dividends and repurchased $100 million of company stock. Ending the year, total debt was $981 million, and the company’s debt-to-EBITDA ratio stood at 1.7. Total cash and cash equivalents were $124 million at the end of the year.

[0001069202-21-000004:8k_2_02:30]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001069202-21-000004:8k_2_02:31]
Residential Heating and Cooling

[0001069202-21-000004:8k_2_02:32]
•4Q20 revenue a fourth-quarter record $553 million, up 11%; neutral foreign exchange

[0001069202-21-000004:8k_2_02:33]
•4Q20 segment profit a fourth-quarter record $116 million, up 18%; operationally, excluding $25 million of insurance benefit in the prior-year quarter, segment profit rose 58%

[0001069202-21-000004:8k_2_02:34]
•4Q20 segment margin a fourth-quarter record 20.9%, up 130 basis points; operationally, excluding $25 million of insurance benefit in the prior-year quarter, segment margin expanded 630 basis points

[0001069202-21-000004:8k_2_02:35]
•2020 revenue a record $2.36 billion, up 3%; neutral foreign exchange

[0001069202-21-000004:8k_2_02:36]
•2020 segment profit of $429 million, down 8%; operationally, excluding $99 million of insurance benefit in the prior year, segment profit rose 17%

[0001069202-21-000004:8k_2_02:37]
•2020 segment margin of 18.1%, down 220 basis points; operationally, excluding $99 million of insurance benefit in the prior year, segment margin expanded 210 basis points

[0001069202-21-000004:8k_2_02:38]
Fourth-quarter results were primarily impacted by higher volume, favorable price, lower material and other product costs, higher factory productivity, and lower SG&A. Partial offsets included $25 million of non-recurring insurance proceeds in the prior-year quarter, the COVID-19 pandemic, and higher tariffs, freight, distribution and warranty.

[0001069202-21-000004:8k_2_02:39]
Full-year results were primarily impacted by $99 million of non-recurring insurance proceeds in the prior year, the COVID-19 pandemic, factory inefficiencies, unfavorable mix, higher tariffs, warranty and other product costs. Partial offsets included higher volume, favorable price, lower material costs, freight, and distribution, and lower SG&A.

[0001069202-21-000004:8k_2_02:40]
Commercial Heating and Cooling

[0001069202-21-000004:8k_2_02:41]
•4Q20 revenue of $226 million, down 13%; neutral foreign exchange

[0001069202-21-000004:8k_2_02:42]
•4Q20 segment profit of $44 million, down 11%

[0001069202-21-000004:8k_2_02:43]
•4Q20 segment margin a fourth-quarter record 19.4%, up 40 basis points

[0001069202-21-000004:8k_2_02:44]
•2020 revenue of $801 million, down 15%; neutral foreign exchange

[0001069202-21-000004:8k_2_02:45]
•2020 segment profit of $137 million, down 17%

[0001069202-21-000004:8k_2_02:46]
•2020 segment margin of 17.1%, down 40 basis points

[0001069202-21-000004:8k_2_02:47]
Fourth-quarter results were primarily impacted by the COVID-19 pandemic, lower volume, unfavorable mix, and higher freight, distribution and SG&A. Partial offsets included lower material and other product costs, higher factory productivity, lower warranty, and tariff exclusions and refunds due to exclusions.

[0001069202-21-000004:8k_2_02:48]
Full-year results were primarily impacted by the COVID-19 pandemic, lower volume, unfavorable mix, and higher warranty. Partial offsets included lower material and other product costs, higher factory productivity, lower freight and distribution costs, lower SG&A, and tariff exclusions and related refunds.

[0001069202-21-000004:8k_2_02:49]
Refrigeration

[0001069202-21-000004:8k_2_02:50]
•4Q20 revenue of $135 million, up 7%; up 3% at constant currency

[0001069202-21-000004:8k_2_02:51]
•4Q20 segment profit of $10 million, down 28%

[0001069202-21-000004:8k_2_02:52]
•4Q20 segment margin of 7.5%, down 360 basis points

[0001069202-21-000004:8k_2_02:53]
•2020 revenue of $472 million, down 12%; down 13% at constant currency

[0001069202-21-000004:8k_2_02:54]
•2020 segment profit of $33 million, down 47%

[0001069202-21-000004:8k_2_02:55]
•2020 segment margin of 7.0%, down 470 basis points

[0001069202-21-000004:8k_2_02:56]
Fourth-quarter results were primarily impacted by the COVID-19 pandemic, unfavorable mix, higher distribution, warranty and other product costs, and the timing of SG&A expenses. Partial offsets included higher volume, favorable price, and lower material costs.

[0001069202-21-000004:8k_2_02:57]
Full-year results were primarily impacted by the COVID-19 pandemic, lower volume, unfavorable mix, factory inefficiencies and other product costs, and higher warranty. Partial offsets included favorable price, lower material and distribution costs, lower SG&A, tariff exclusions and related refunds, and favorable foreign exchange.

[0001069202-21-000004:8k_2_02:58]
2021 FULL-YEAR OUTLOOK

[0001069202-21-000004:8k_2_02:59]
The company reiterates its financial guidance for 2021:

[0001069202-21-000004:8k_2_02:60]
•Revenue growth of 4-8%

[0001069202-21-000004:8k_2_02:61]
•GAAP and adjusted EPS from continuing operations of $10.55-$11.15

[0001069202-21-000004:8k_2_02:62]
•Corporate expenses of approximately $90 million

[0001069202-21-000004:8k_2_02:63]
•Effective tax rate of approximately 21% on an adjusted basis for the full year

[0001069202-21-000004:8k_2_02:64]
•Capital expenditures of approximately $135 million, including $25 million funded by insurance proceeds previously received

[0001069202-21-000004:8k_2_02:65]
•Stock repurchases of $400 million

[0001069202-21-000004:8k_2_02:66]
CONFERENCE CALL INFORMATION

[0001069202-21-000004:8k_2_02:67]
A conference call to discuss the company’s fourth-quarter and full-year 2020 results and 2021 outlook will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 877-336-4440 (U.S.) or 409-207-6984 (international) at least 10 minutes prior to the scheduled start time and use participant code 2314288. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from approximately 11:00 a.m.

[0001069202-21-000004:8k_2_02:68]
Central time on February 2 through February 16, 2021 by dialing 866-207-1041 (U.S.) or 402-970-0847 (international) and using access code 1578399. The call also will be archived on the company’s website.

[0001069202-21-000004:8k_2_02:69]
About Lennox International

[0001069202-21-000004:8k_2_02:70]
Lennox International Inc. is a global leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our air conditioning, heating, indoor air quality, and refrigeration systems. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol "LII". Additional information on Lennox International is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-21-000004:8k_2_02:71]
FORWARD-LOOKING STATEMENTS

[0001069202-21-000004:8k_2_02:72]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-21-000004:8k_2_02:73]
Consolidated Statements of Operations

[0001069202-21-000004:8k_2_02:74]
| (Amounts in millions, except per share data) | For the Three Months Ended December 31,(Unaudited) |  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales | $ | 914.0 |  |  | $ | 885.0 |  |  | $ | 3,634.1 |  |  | $ | 3,807.2 |  |
| Cost of goods sold | 638.7 |  |  | 637.2 |  |  | 2,594.0 |  |  | 2,727.4 |  |
| Gross profit | 275.3 |  |  | 247.8 |  |  | 1,040.1 |  |  | 1,079.8 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 143.3 |  |  | 144.2 |  |  | 555.9 |  |  | 585.9 |  |
| Losses (gains) and other expenses, net | 1.7 |  |  | 3.0 |  |  | 7.4 |  |  | 8.3 |  |
| Restructuring charges | 0.2 |  |  | 3.8 |  |  | 10.8 |  |  | 10.3 |  |
| Loss on sale of business | — |  |  | 1.5 |  |  | — |  |  | 10.6 |  |
| (Gain) loss from natural disasters, net of insurance recoveries | (4.5) |  |  | (93.4) |  |  | 3.1 |  |  | (178.8) |  |
| Income from equity method investments | (4.4) |  |  | (2.9) |  |  | (15.6) |  |  | (13.4) |  |
| Operating income | 139.0 |  |  | 191.6 |  |  | 478.5 |  |  | 656.9 |  |
| Pension settlements | 0.3 |  |  | 38.6 |  |  | 0.6 |  |  | 99.2 |  |
| Interest expense, net | 6.3 |  |  | 11.0 |  |  | 28.3 |  |  | 47.5 |  |
| Other expense (income), net | 1.0 |  |  | 0.6 |  |  | 4.4 |  |  | 2.3 |  |
| Income from continuing operations before income taxes | 131.4 |  |  | 141.4 |  |  | 445.2 |  |  | 507.9 |  |
| Provision for income taxes | 19.2 |  |  | 27.6 |  |  | 88.1 |  |  | 99.1 |  |
| Income from continuing operations | 112.2 |  |  | 113.8 |  |  | 357.1 |  |  | 408.8 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| (Loss) income from discontinued operations before income taxes | (0.6) |  |  | 0.3 |  |  | (1.5) |  |  | (0.1) |  |
| Income tax (benefit) expenses | (0.1) |  |  | 0.1 |  |  | (0.7) |  |  | — |  |
| (Loss) income from discontinued operations | (0.5) |  |  | 0.2 |  |  | (0.8) |  |  | (0.1) |  |
| Net income | $ | 111.7 |  |  | $ | 114.0 |  |  | $ | 356.3 |  |  | $ | 408.7 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.93 |  |  | $ | 2.95 |  |  | $ | 9.32 |  |  | $ | 10.49 |  |
| (Loss) income from discontinued operations | (0.01) |  |  | 0.01 |  |  | (0.02) |  |  | — |  |
| Net income | $ | 2.92 |  |  | $ | 2.96 |  |  | $ | 9.30 |  |  | $ | 10.49 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.91 |  |  | $ | 2.92 |  |  | $ | 9.26 |  |  | $ | 10.38 |  |
| (Loss) income from discontinued operations | (0.02) |  |  | 0.01 |  |  | (0.02) |  |  | — |  |
| Net income | $ | 2.89 |  |  | $ | 2.93 |  |  | $ | 9.24 |  |  | $ | 10.38 |  |
| Weighted Average Number of Shares Outstanding - Basic | 38.3 |  |  | 38.6 |  |  | 38.3 |  |  | 39.0 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 38.6 |  |  | 38.9 |  |  | 38.6 |  |  | 39.4 |  |

[0001069202-21-000004:8k_2_02:75]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Adjusted Segment Net Sales and Profit (Loss) |

[0001069202-21-000004:8k_2_02:76]
| (Amounts in millions) | For the Three Months Ended December 31,(Unaudited) |  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 552.7 |  |  | $ | 498.9 |  |  | $ | 2,361.5 |  |  | $ | 2,291.1 |  |
| Commercial Heating & Cooling | 226.2 |  |  | 259.5 |  |  | 800.9 |  |  | 947.4 |  |
| Refrigeration (1) | 135.1 |  |  | 126.6 |  |  | 471.7 |  |  | 534.4 |  |
|  | $ | 914.0 |  |  | $ | 885.0 |  |  | $ | 3,634.1 |  |  | $ | 3,772.9 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 115.6 |  |  | $ | 98.0 |  |  | $ | 428.5 |  |  | $ | 464.6 |  |
| Commercial Heating & Cooling | 43.8 |  |  | 49.4 |  |  | 136.9 |  |  | 165.4 |  |
| Refrigeration (1) | 10.2 |  |  | 14.1 |  |  | 32.8 |  |  | 62.3 |  |
| Corporate and other | (30.3) |  |  | (28.2) |  |  | (91.5) |  |  | (82.4) |  |
| Total adjusted segment profit | 139.3 |  |  | 133.3 |  |  | 506.7 |  |  | 609.9 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Special product quality adjustments | 2.0 |  |  | 0.4 |  |  | 1.0 |  |  | (0.6) |  |
| Loss on sale of business | — |  |  | 1.5 |  |  | — |  |  | 10.6 |  |
| (Gain) loss from natural disasters, net of insurance recoveries | (4.5) |  |  | (68.0) |  |  | 3.1 |  |  | (79.6) |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 2.6 |  |  | 4.0 |  |  | 13.3 |  |  | 11.3 |  |
| Restructuring charges | 0.2 |  |  | 3.8 |  |  | 10.8 |  |  | 10.3 |  |
| Operating loss from non-core business (1) | — |  |  | — |  |  | — |  |  | 1.0 |  |
| Operating income | $ | 139.0 |  |  | $ | 191.6 |  |  | $ | 478.5 |  |  | $ | 656.9 |  |

[0001069202-21-000004:8k_2_02:77]
(1) Excludes the non-core business results related to Kysor Warren, which was sold in March 2019.

[0001069202-21-000004:8k_2_02:78]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-21-000004:8k_2_02:79]
•The following items in Losses (gains) and other expenses, net:

[0001069202-21-000004:8k_2_02:80]
◦Net change in unrealized gains on unsettled futures contracts,

[0001069202-21-000004:8k_2_02:81]
◦Special legal contingency charges,

[0001069202-21-000004:8k_2_02:82]
◦Asbestos-related litigation,

[0001069202-21-000004:8k_2_02:83]
◦Environmental liabilities,

[0001069202-21-000004:8k_2_02:84]
◦Charges incurred related to COVID-19 pandemic,

[0001069202-21-000004:8k_2_02:85]
◦Other items, net,

[0001069202-21-000004:8k_2_02:86]
•Loss on sale of business,

[0001069202-21-000004:8k_2_02:87]
•Special product quality adjustments,

[0001069202-21-000004:8k_2_02:88]
•(Gain) loss from natural disasters, net of insurance recoveries,

[0001069202-21-000004:8k_2_02:89]
•Operating loss from non-core business; and

[0001069202-21-000004:8k_2_02:90]
•Restructuring charges.

[0001069202-21-000004:8k_2_02:91]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-21-000004:8k_2_02:92]
Consolidated Balance Sheets

[0001069202-21-000004:8k_2_02:93]
| (Amounts in millions, except shares and par values) | As of December 31, 2020 |  | As of December 31, 2019 |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 123.9 |  |  | $ | 37.3 |  |
| Short-term investments | 5.1 |  |  | 2.9 |  |
| Accounts and notes receivable, net of allowances of $9.6 and $6.1 in 2020 and 2019, respectively | 448.3 |  |  | 477.8 |  |
| Inventories, net | 439.4 |  |  | 544.1 |  |
| Other assets | 70.9 |  |  | 58.8 |  |
| Total current assets | 1,087.6 |  |  | 1,120.9 |  |
| Property, plant and equipment, net of accumulated depreciation of $880.6 and $824.3 in 2020 and 2019, respectively | 464.3 |  |  | 445.4 |  |
| Right-of-use assets from operating leases | 194.4 |  |  | 181.6 |  |
| Goodwill | 186.9 |  |  | 186.5 |  |
| Deferred income taxes | 13.2 |  |  | 21.5 |  |
| Other assets, net | 86.1 |  |  | 79.0 |  |
| Total assets | $ | 2,032.5 |  |  | $ | 2,034.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 9.9 |  |  | 321.9 |  |
| Current operating lease liabilities | 55.0 |  |  | 52.7 |  |
| Accounts payable | 340.3 |  |  | 372.4 |  |
| Accrued expenses | 296.1 |  |  | 255.7 |  |
| Total current liabilities | 701.3 |  |  | 1,002.7 |  |
| Long-term debt | 970.7 |  |  | 849.3 |  |
| Long-term operating lease liabilities | 142.8 |  |  | 131.0 |  |
| Pensions | 92.5 |  |  | 87.4 |  |
| Other liabilities | 142.3 |  |  | 134.7 |  |
| Total liabilities | 2,049.6 |  |  | 2,205.1 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,113.2 |  |  | 1,093.5 |  |
| Retained earnings | 2,385.8 |  |  | 2,148.7 |  |
| Accumulated other comprehensive loss | (97.2) |  |  | (103.8) |  |
| Treasury stock, at cost, 48,820,969 shares and 48,575,901 shares for 2020 and 2019, respectively | (3,419.8) |  |  | (3,309.5) |  |
| Total stockholders' deficit | (17.1) |  |  | (170.2) |  |
| Total liabilities and stockholders' deficit | $ | 2,032.5 |  |  | $ | 2,034.9 |  |

[0001069202-21-000004:8k_2_02:94]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-21-000004:8k_2_02:95]
Consolidated Statements of Cash Flows

[0001069202-21-000004:8k_2_02:96]
| (Amounts in millions) | For the Years Ended December 31, |
|  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 356.3 |  |  | $ | 408.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Loss on sale of business | — |  |  | 10.6 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | (79.6) |  |
| Income from equity method investments | (15.6) |  |  | (13.4) |  |
| Dividends from affiliates | 12.3 |  |  | 12.3 |  |
| Restructuring charges, net of cash paid | 3.4 |  |  | 6.8 |  |
| Provision for credit losses | 8.1 |  |  | 4.5 |  |
| Unrealized losses (gains), net on derivative contracts | 0.3 |  |  | (0.5) |  |
| Stock-based compensation expense | 24.3 |  |  | 21.3 |  |
| Depreciation and amortization | 72.6 |  |  | 71.1 |  |
| Deferred income taxes | 7.2 |  |  | 16.6 |  |
| Pension expense | 10.5 |  |  | 106.1 |  |
| Pension contributions | (3.3) |  |  | (1.8) |  |
| Other items, net | 0.2 |  |  | (0.4) |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | 26.5 |  |  | (33.1) |  |
| Inventories | 110.3 |  |  | (63.9) |  |
| Other current assets | 5.3 |  |  | 2.8 |  |
| Accounts payable | (31.7) |  |  | (56.1) |  |
| Accrued expenses | 35.4 |  |  | (5.6) |  |
| Income taxes payable / receivable | (5.7) |  |  | (1.9) |  |
| Leases, net | 2.1 |  |  | 2.1 |  |
| Other, net | (6.1) |  |  | (10.5) |  |
| Net cash provided by operating activities | 612.4 |  |  | 396.1 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 1.0 |  |  | 1.3 |  |
| Purchases of property, plant and equipment | (78.5) |  |  | (105.6) |  |
| Net proceeds from sale of business | — |  |  | 43.5 |  |
| Purchases of short-term investments | (2.2) |  |  | (2.9) |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 79.6 |  |
| Net cash (used in) provided by investing activities | (79.7) |  |  | 15.9 |  |
| Cash flows from financing activities: |  |  |  |
| Short-term debt payments | (4.6) |  |  | (5.3) |  |
| Short-term debt borrowings | 4.6 |  |  | 5.3 |  |
| Asset securitization borrowings | 91.0 |  |  | 184.5 |  |
| Asset securitization payments | (376.0) |  |  | (167.5) |  |
| Long-term debt payments | (10.8) |  |  | (6.4) |  |
| Long-term debt borrowings | 600.0 |  |  | — |  |
| Borrowings from credit facility | 1,576.0 |  |  | 2,367.0 |  |
| Payments on credit facility | (2,081.5) |  |  | (2,269.5) |  |
| Payments of deferred financing costs | (7.5) |  |  | (0.3) |  |
| Proceeds from employee stock purchases | 3.0 |  |  | 3.3 |  |
| Repurchases of common stock | (100.0) |  |  | (400.0) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (17.9) |  |  | (24.0) |  |
| Cash dividends paid | (118.1) |  |  | (110.5) |  |
| Net cash used in financing activities | (441.8) |  |  | (423.4) |  |
| Increase (decrease) in cash and cash equivalents | 90.9 |  |  | (11.4) |  |
| Effect of exchange rates on cash and cash equivalents | (4.3) |  |  | 2.4 |  |
| Cash and cash equivalents, beginning of period | 37.3 |  |  | 46.3 |  |
| Cash and cash equivalents, end of period | $ | 123.9 |  |  | $ | 37.3 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 25.3 |  |  | $ | 46.8 |  |
| Income taxes paid (net of refunds) | $ | 90.3 |  |  | $ | 83.0 |  |
| Insurance recoveries received | $ | — |  |  | $ | 243.2 |  |

[0001069202-21-000004:8k_2_02:97]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. During the first quarter of 2019, the Company completed the sale of its Kysor Warren business. The results from operations for this business have been shown in the tables below as “Non-core business results”. |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |  |  |
|  | (Unaudited) |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |  |  |  |  |
| Income from continuing operations, a GAAP measure | $ | 131.4 |  | $ | (19.2) |  | $ | 112.2 |  |  | $ | 141.4 |  | $ | (27.6) |  | $ | 113.8 |  |  |  |  |  |
| Restructuring charges | 0.2 |  | — |  | 0.2 |  |  | 3.8 |  | (1.2) |  | 2.6 |  |  |  |  |  |
| Pension settlement | 0.3 |  | (0.1) |  | 0.2 |  |  | 38.6 |  | (9.7) |  | 28.9 |  |  |  |  |  |
| Special product quality adjustments (b) | 2.0 |  | (0.5) |  | 1.5 |  |  | 0.4 |  | (0.1) |  | 0.3 |  |  |  |  |  |
| Special legal contingency charges (a) | 0.2 |  | (0.1) |  | 0.1 |  |  | 0.8 |  | (0.2) |  | 0.6 |  |  |  |  |  |
| Asbestos-related litigation (a) | 3.7 |  | (1.0) |  | 2.7 |  |  | (0.2) |  | (0.1) |  | (0.3) |  |  |  |  |  |
| Net change in unrealized gain on unsettled futures contracts (a) | (0.4) |  | 0.1 |  | (0.3) |  |  | (0.2) |  | 0.1 |  | (0.1) |  |  |  |  |  |
| Environmental liabilities (a) | (2.9) |  | 0.6 |  | (2.3) |  |  | 3.3 |  | (0.6) |  | 2.7 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) | — |  | (1.5) |  | (1.5) |  |  | — |  | (4.0) |  | (4.0) |  |  |  |  |  |
| Other tax items, net (c) | — |  | 0.4 |  | 0.4 |  |  | — |  | 0.7 |  | 0.7 |  |  |  |  |  |
| Loss on sale of business | — |  | — |  | — |  |  | 1.5 |  | (0.6) |  | 0.9 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) | 1.8 |  | (0.4) |  | 1.4 |  |  | — |  | — |  | — |  |  |  |  |  |
| Gain from natural disasters, net of insurance recoveries (f) | (4.5) |  | 1.1 |  | (3.4) |  |  | (68.0) |  | 17.0 |  | (51.0) |  |  |  |  |  |
| Other items, net (a) | 0.2 |  | — |  | 0.2 |  |  | 0.3 |  | (0.3) |  | — |  |  |  |  |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 132.0 |  | $ | (20.6) |  | $ | 111.4 |  |  | $ | 121.7 |  | $ | (26.6) |  | $ | 95.1 |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  | $ | 2.91 |  |  |  |  | $ | 2.92 |  |  |  |  |  |
| Restructuring charges |  |  | 0.01 |  |  |  |  | 0.07 |  |  |  |  |  |
| Pension settlement |  |  | 0.01 |  |  |  |  | 0.74 |  |  |  |  |  |
| Special product quality adjustments (b) |  |  | 0.04 |  |  |  |  | 0.01 |  |  |  |  |  |
| Special legal contingency charges (a) |  |  | — |  |  |  |  | 0.02 |  |  |  |  |  |
| Asbestos-related litigation (a) |  |  | 0.07 |  |  |  |  | (0.01) |  |  |  |  |  |
| Net change in unrealized gain on unsettled futures contracts (a) |  |  | (0.01) |  |  |  |  | — |  |  |  |  |  |
| Environmental liabilities (a) |  |  | (0.06) |  |  |  |  | 0.07 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) |  |  | (0.04) |  |  |  |  | (0.10) |  |  |  |  |  |
| Other tax items, net (c) |  |  | 0.01 |  |  |  |  | 0.02 |  |  |  |  |  |
| Loss on sale of business |  |  | — |  |  |  |  | 0.02 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) |  |  | 0.04 |  |  |  |  | — |  |  |  |  |  |

[0001069202-21-000004:8k_2_02:98]
| Gain from natural disasters, net of insurance recoveries (f) |  |  | (0.10) |  |  |  |  | (1.31) |  |  |  |  |  |
| Other items, net (a) |  |  | 0.01 |  |  |  |  | — |  |  |  |  |  |
| Change in share counts from share-based compensation (d) |  |  | — |  |  |  |  | — |  |  |  |  |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 2.89 |  |  |  |  | $ | 2.45 |  |  |  |  |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |  |  |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount.. |  |  |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |  |  |
| (f) Recorded in (Gain) loss from natural disasters, net of insurance recoveries in the Consolidated Statement of Operations. |  |  |  |  |
|  | For the Years Ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |  |  |  |  |
| Income from continuing operations, a GAAP measure | $ | 445.2 |  | $ | (88.1) |  | $ | 357.1 |  |  | $ | 507.9 |  | $ | (99.1) |  | $ | 408.8 |  |  |  |  |  |
| Restructuring charges | 10.8 |  | (2.4) |  | 8.4 |  |  | 10.3 |  | (2.6) |  | 7.7 |  |  |  |  |  |
| Pension settlements | 0.6 |  | (0.2) |  | 0.4 |  |  | 99.2 |  | (24.8) |  | 74.4 |  |  |  |  |  |
| Special product quality adjustments (b) | 1.0 |  | (0.2) |  | 0.8 |  |  | (0.6) |  | 0.1 |  | (0.5) |  |  |  |  |  |
| Special legal contingency charges (a) | 1.1 |  | (0.3) |  | 0.8 |  |  | 1.2 |  | (0.3) |  | 0.9 |  |  |  |  |  |
| Asbestos-related litigation (a) | 5.6 |  | (1.4) |  | 4.2 |  |  | 3.1 |  | (0.8) |  | 2.3 |  |  |  |  |  |
| Net change in unrealized gains on unsettled futures contracts (a) | (0.3) |  | — |  | (0.3) |  |  | (0.5) |  | 0.2 |  | (0.3) |  |  |  |  |  |
| Environmental liabilities (a) | (1.4) |  | 0.3 |  | (1.1) |  |  | 5.7 |  | (1.1) |  | 4.6 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) | — |  | (4.2) |  | (4.2) |  |  | — |  | (10.9) |  | (10.9) |  |  |  |  |  |
| Other tax items, net (c) | — |  | 8.5 |  | 8.5 |  |  | — |  | 3.9 |  | 3.9 |  |  |  |  |  |
| Loss on sale of business | — |  | — |  | — |  |  | 10.6 |  | (4.1) |  | 6.5 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) | 8.3 |  | (2.1) |  | 6.2 |  |  | — |  | — |  | — |  |  |  |  |  |
| Loss (gain) from natural disasters, net of insurance recoveries (g) | 3.1 |  | (0.8) |  | 2.3 |  |  | (79.6) |  | 19.8 |  | (59.8) |  |  |  |  |  |
| Other items, net (a) | — |  | — |  | — |  |  | 1.8 |  | (0.5) |  | 1.3 |  |  |  |  |  |
| Non-core business results (f) | — |  | — |  | — |  |  | 1.3 |  | (0.3) |  | 1.0 |  |  |  |  |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 474.0 |  | $ | (90.9) |  | $ | 383.1 |  |  | $ | 560.4 |  | $ | (120.5) |  | $ | 439.9 |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  | $ | 9.26 |  |  |  |  | $ | 10.38 |  |  |  |  |  |
| Restructuring charges |  |  | 0.22 |  |  |  |  | 0.20 |  |  |  |  |  |
| Pension settlements |  |  | 0.01 |  |  |  |  | 1.89 |  |  |  |  |  |
| Special product quality adjustments (b) |  |  | 0.02 |  |  |  |  | (0.01) |  |  |  |  |  |
| Special legal contingency charges (a) |  |  | 0.02 |  |  |  |  | 0.02 |  |  |  |  |  |
| Asbestos-related litigation (a) |  |  | 0.11 |  |  |  |  | 0.06 |  |  |  |  |  |
| Net change in unrealized gains on unsettled futures contracts (a) |  |  | (0.01) |  |  |  |  | (0.01) |  |  |  |  |  |
| Environmental liabilities (a) |  |  | (0.03) |  |  |  |  | 0.12 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) |  |  | (0.11) |  |  |  |  | (0.28) |  |  |  |  |  |
| Other tax items, net (c) |  |  | 0.23 |  |  |  |  | 0.10 |  |  |  |  |  |
| Loss on sale of business |  |  | — |  |  |  |  | 0.17 |  |  |  |  |  |

[0001069202-21-000004:8k_2_02:99]
| Charges incurred related to COVID-19 pandemic (a) |  |  | 0.16 |  |  |  |  | — |  |  |  |  |  |
| Loss (gain) from natural disasters, net of insurance recoveries (g) |  |  | 0.06 |  |  |  |  | (1.52) |  |  |  |  |  |
| Other items, net (a) |  |  | — |  |  |  |  | 0.03 |  |  |  |  |  |
| Non-core business results (f) |  |  | — |  |  |  |  | 0.03 |  |  |  |  |  |
| Change in share counts from share-based compensation (d) |  |  | — |  |  |  |  | 0.01 |  |  |  |  |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 9.94 |  |  |  |  | $ | 11.19 |  |  |  |  |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |  |  |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |  |  |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |  |  |
| (f) Non-core business results represent the Kysor Warren business, not included elsewhere in the reconciliation. |  |  |
| (g) Recorded in (Gain) loss from natural disasters, net of insurance recoveries in the Consolidated Statement of Operations. |  |  |  |  |

[0001069202-21-000004:8k_2_02:100]
|  | For the Three Months Ended December 31, |  | For the Years EndedDecember 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized (gain) losses on settled future contracts (a) | $ | (0.1) |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.4 |  |
| Foreign currency exchange gains (a) | (0.5) |  |  | (0.5) |  |  | (3.6) |  |  | (1.5) |  |
| Loss (gain) on disposal of fixed assets (a) | 0.2 |  |  | — |  |  | (0.2) |  |  | (0.2) |  |
| Other operating income (a) | (0.5) |  |  | (0.5) |  |  | (2.2) |  |  | (1.7) |  |
| Net change in unrealized gains on unsettled futures contracts (b) | (0.4) |  |  | (0.2) |  |  | (0.3) |  |  | (0.5) |  |
| Special legal contingency charges (b) | 0.2 |  |  | 0.8 |  |  | 1.1 |  |  | 1.2 |  |
| Asbestos-related litigation (b) | 3.7 |  |  | (0.2) |  |  | 5.6 |  |  | 3.1 |  |
| Environmental liabilities (b) | (2.9) |  |  | 3.3 |  |  | (1.4) |  |  | 5.7 |  |
| Charges incurred related to COVID-19 pandemic (b) | 1.8 |  |  | — |  |  | 8.3 |  |  | — |  |
| Other items, net (b) | 0.2 |  |  | 0.3 |  |  | — |  |  | 1.8 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 1.7 |  |  | $ | 3.0 |  |  | $ | 7.4 |  |  | $ | 8.3 |  |

[0001069202-21-000004:8k_2_02:101]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |  |  |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |  |  |

[0001069202-21-000004:8k_2_02:102]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |
|  |  |  |  |  | For the Year Ended December 31, 2021ESTIMATED |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $10.55-$11.15 |
| Other non-core EBIT charges and other non-core tax items |  | — |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $10.55-$11.15 |

[0001069202-21-000004:8k_2_02:103]
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Average shares outstanding - diluted, a GAAP measure | 38.6 |  | 38.9 |  |  | 38.6 |  | 39.4 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | — |  |  | — |  |  | (0.1) |  |  | (0.1) |  |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 38.6 |  | 38.9 |  |  | 38.5 |  | 39.3 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales, a GAAP measure | $ | 135.1 |  |  | $ | 126.6 |  |  | $ | 914.0 |  |  | $ | 885.0 |  |
| Net sales from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted net sales, a Non-GAAP measure | $ | 135.1 |  |  | $ | 126.6 |  |  | $ | 914.0 |  |  | $ | 885.0 |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales, a GAAP measure | $ | 471.7 |  |  | $ | 568.7 |  |  | $ | 3,634.1 |  |  | $ | 3,807.2 |  |
| Net sales from non-core business (a) | — |  |  | 34.3 |  |  | — |  |  | 34.3 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 471.7 |  |  | $ | 534.4 |  |  | $ | 3,634.1 |  |  | $ | 3,772.9 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit, a GAAP measure | $ | 39.4 |  |  | $ | 39.0 |  |  | $ | 275.3 |  |  | $ | 247.8 |  |
| Non-GAAP adjustments to gross profit | (2.0) |  |  | (1.3) |  |  | (2.0) |  |  | (0.4) |  |
| Gross profit from non-core businesses (a) | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 41.4 |  |  | $ | 40.3 |  |  | $ | 277.3 |  |  | $ | 248.2 |  |

[0001069202-21-000004:8k_2_02:104]
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit, a GAAP measure | $ | 137.6 |  |  | $ | 174.6 |  |  | $ | 1,040.1 |  |  | $ | 1,079.8 |  |
| Non-GAAP adjustments to gross profit | (2.0) |  |  | (1.3) |  |  | (1.0) |  |  | 0.6 |  |
| Gross profit from non-core business (a) | — |  |  | 3.6 |  |  | — |  |  | 3.6 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 139.6 |  |  | $ | 172.3 |  |  | $ | 1,041.1 |  |  | $ | 1,075.6 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |
| Reconciliation of Segment Profit, a Non-GAAP measure, to Adjusted Segment profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment profit, a Non-GAAP measure | $ | 10.2 |  |  | $ | 14.1 |  |  | $ | 139.3 |  |  | $ | 133.3 |  |
| (Loss) profit from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 10.2 |  |  | $ | 14.1 |  |  | $ | 139.3 |  |  | $ | 133.3 |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment profit, a Non-GAAP measure | $ | 32.8 |  |  | $ | 61.3 |  |  | $ | 506.7 |  |  | $ | 608.9 |  |
| (Loss) profit from non-core business (a) | — |  |  | (1.0) |  |  | — |  |  | (1.0) |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 32.8 |  |  | $ | 62.3 |  |  | $ | 506.7 |  |  | $ | 609.9 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Selling, general and administrative expenses, a GAAP measure | $ | 33.6 |  |  | $ | 27.0 |  |  | $ | 143.3 |  |  | $ | 144.2 |  |
| Selling, general and administrative expenses from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 33.6 |  |  | $ | 27.0 |  |  | $ | 143.3 |  |  | $ | 144.2 |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Selling, general and administrative expenses, a GAAP measure | $ | 114.6 |  |  | $ | 117.1 |  |  | $ | 555.9 |  |  | $ | 585.9 |  |
| Selling, general and administrative expenses from non-core business (a) | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 114.6 |  |  | $ | 112.5 |  |  | $ | 555.9 |  |  | $ | 581.3 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |

[0001069202-21-000004:8k_2_02:105]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net cash provided by operating activities | $ | 166.1 |  |  | $ | 271.6 |  |  | $ | 612.4 |  |  | $ | 396.1 |  |
| Purchases of property, plant and equipment | (22.6) |  |  | (28.6) |  |  | (78.5) |  |  | (105.6) |  |
| Proceeds from the disposal of property, plant and equipment | 0.3 |  |  | 0.1 |  |  | 1.0 |  |  | 1.3 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 68.0 |  |  | — |  |  | 79.6 |  |
| Free cash flow, a Non-GAAP measure | $ | 143.8 |  |  | $ | 311.1 |  |  | $ | 534.9 |  |  | $ | 371.4 |  |

[0001069202-21-000004:8k_2_02:106]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to December 31, 2020 |
| Adjusted EBIT (a) |  |  |  |  |  |  | $ | 506.7 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  | 71.0 |  |
| EBITDA (a + b) |  |  |  |  |  |  | $ | 577.7 |  |
| Total debt at December 31, 2020 (c) |  |  |  |  |  |  | $ | 980.6 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  | 1.7 |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |
|  |  |  |  |  |  |  | Trailing Twelve Months to December 31, 2020 |
| Income from continuing operations before income taxes, a GAAP measure | $ | 445.2 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit | 13.3 |  |
| Special product quality adjustments | 1.0 |  |
| Restructuring charges | 10.8 |  |
| Interest expense, net | 28.3 |  |
| Pension settlements | 0.6 |  |
| Insurance recoveries received for property damage incurred from natural disaster | 3.1 |  |
| Other expense (income), net | 4.4 |  |
| Adjusted EBIT per above, a Non-GAAP measure | $ | 506.7 |  |
