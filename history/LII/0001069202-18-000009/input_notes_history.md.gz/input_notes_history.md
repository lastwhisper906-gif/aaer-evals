# LII note change history — 0001069202-17-000013 → 0001069202-18-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-04-23):
[0001069202-18-000009:note_history:1]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.
  (was, 2017-10-24, similarity 0.9838):
[0001069202-17-000013:note_history:1]
We offer warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

- changed (2018-04-23):
[0001069202-18-000009:note_history:2]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 34.5 |  |  | $ | 34.8 |  |
| Other liabilities | 74.3 |  |  | 75.1 |  |
| Total warranty liability | $ | 108.8 |  |  | $ | 109.9 |  |
  (was, 2017-10-24, similarity 0.9716):
[0001069202-17-000013:note_history:2]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 34.9 |  |  | $ | 30.0 |  |
| Other liabilities | 72.7 |  |  | 71.1 |  |
| Total warranty liability | $ | 107.6 |  |  | $ | 101.1 |  |

- changed (2018-04-23):
[0001069202-18-000009:note_history:3]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2018 were as follows (in millions):
  (was, 2017-10-24, similarity 0.9416):
[0001069202-17-000013:note_history:3]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2017 were as follows (in millions):

- changed (2018-04-23):
[0001069202-18-000009:note_history:4]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (5.0 | ) |
| Changes resulting from issuance of new warranties | 7.4 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | — |  |
| Warranty liability from assets held for sale | (0.9 | ) |
| Total warranty liability as of March 31, 2018 | $ | 108.8 |  |
  (was, 2017-10-24, similarity 0.8016):
[0001069202-17-000013:note_history:4]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (21.6 | ) |
| Changes resulting from issuance of new warranties | 32.2 |  |
| Changes in estimates associated with pre-existing liabilities | (4.7 | ) |
| Changes in foreign currency translation rates and other | 0.6 |  |
| Total warranty liability as of September 30, 2017 | $ | 107.6 |  |

- changed (2018-04-23):
[0001069202-18-000009:note_history:5]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities, for such quality related issues, are not material.
  (was, 2017-10-24, similarity 0.921):
[0001069202-17-000013:note_history:5]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.

- changed (2018-04-23):
[0001069202-18-000009:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2018 and 2017, expense for asbestos-related litigation was $2.1 million and $1.7 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.
  (was, 2017-10-24, similarity 0.9143):
[0001069202-17-000013:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2017 and 2016, expense for asbestos-related litigation was $3.9 million and $2.3 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.  For the three months ended  September 30, 2017 and 2016, expense for asbestos-related litigation was $1.5 million and $0.4 million, respectively, net of probable insurance recoveries.

- changed (2018-04-23):
[0001069202-18-000009:note_history:7]
In October 2016, we self-reported to the Securities and Exchange Commission ("SEC") and the Department of Justice ("DOJ") an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We concluded our investigation and communicated our findings to the SEC and the DOJ. We fully cooperated with the SEC and the DOJ regarding this matter. The  DOJ has declined to prosecute this matter.
  (was, 2017-10-24, similarity 0.7755):
[0001069202-17-000013:note_history:7]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.

- removed (2018-04-23):
[0001069202-17-000013:note_history:8]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect has been isolated, the vendor is supplying corrected components, and we are manufacturing product with the corrected components.  We have also implemented a program for our dealers to install corrected components in the field. We recorded an expense of $0.5 million and $5.7 million for the three and nine months ended September 30, 2017, respectively, relating to estimated repair costs. The expense related to this product quality issue has been classified in Cost of goods sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses on the Consolidated Balance Sheet.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-04-23):
[0001069202-18-000009:note_history:9]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2018, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2017-10-24, similarity 0.9465):
[0001069202-17-000013:note_history:9]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2017, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- added (2018-04-23):
[0001069202-18-000009:note_history:10]
In August 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees.  For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017.  This standard did not have a material impact on our consolidated financial statements.

- added (2018-04-23):
[0001069202-18-000009:note_history:11]
We also adopted other new accounting standards during the first quarter of 2018.  The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.

- added (2018-04-23):
[0001069202-18-000009:note_history:12]
Recent Accounting Pronouncements

- added (2018-04-23):
[0001069202-18-000009:note_history:13]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We will adopt the standard using the prospective approach and are still determining the effect of the standard on our ongoing financial reporting.  As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.

- removed (2018-04-23):
[0001069202-17-000013:note_history:14]
On March 30, 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations.  This is in comparison to the prior requirement that these excess tax benefits be recognized in additional paid-in capital. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity.

- removed (2018-04-23):
[0001069202-17-000013:note_history:15]
We have adopted ASU 2016-09 effective January 1, 2017 on a prospective basis where permitted by the new standard. As a result of this adoption:

- removed (2018-04-23):
[0001069202-17-000013:note_history:16]
| • | We recognized discrete tax benefits of $1.5 million and $9.6 million in the income taxes line item of our consolidated statements of operations for the three and nine months ended September 30, 2017 respectively, related to excess tax benefits upon vesting or settlement in that period. |

- removed (2018-04-23):
[0001069202-17-000013:note_history:17]
| • | We elected to adopt the cash flow presentation of the excess tax benefits retrospectively where these benefits are classified along with other income tax cash flows as operating cash flows. |

- removed (2018-04-23):
[0001069202-17-000013:note_history:18]
| • | We have elected to continue to estimate the number of stock-based awards expected to vest, rather than electing to account for forfeitures as they occur to determine the amount of compensation cost to be recognized in each period. |

- removed (2018-04-23):
[0001069202-17-000013:note_history:19]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three and nine months ended September 30, 2017. |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-04-23):
[0001069202-18-000009:note_history:20]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.03 | % |  | 2.76 | % |
  (was, 2017-10-24, similarity 0.95):
[0001069202-17-000013:note_history:20]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.47 | % |  | 2.00 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-04-23):
[0001069202-18-000009:note_history:21]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 0.9 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 0.9 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.9 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 225.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 675.5 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.1 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,258.3 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,289.1 |  |  | $ | 1,004.0 |  |
  (was, 2017-10-24, similarity 0.7636):
[0001069202-17-000013:note_history:21]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 325.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.0 |  |  | 2.4 |  |
| Total short-term debt | $ | 326.0 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 0.8 |  |
| Domestic credit facility | 22.5 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 22.4 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.7 |  |  | $ | 15.0 |  |
| Domestic credit facility | 415.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.5 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 775.7 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,124.1 |  |  | $ | 868.2 |  |

- changed (2018-04-23):
[0001069202-18-000009:note_history:22]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $0.9 million and $0.9 million of foreign obligations outstanding as of March 31, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.3 million  and $0.3 million during the three months ended March 31, 2018 and 2017, respectively. Repayments on the facilities were $0.4 million and $1.1 million during the three months ended March 31, 2018 and 2017, respectively.
  (was, 2017-10-24, similarity 0.8984):
[0001069202-17-000013:note_history:22]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.0 million and $2.4 million of foreign obligations outstanding as of September 30, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $19.1 million  and $28.2 million during the nine months ended September 30, 2017 and 2016, respectively. Repayments on the facilities were $20.5 million and $30.3 million during the nine months ended September 30, 2017 and 2016, respectively.

- changed (2018-04-23):
[0001069202-18-000009:note_history:23]
The ASP provides for a maximum securitization amount ranging from $225.0 million to $380.0 million, depending on the period. The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):
  (was, 2017-10-24, similarity 0.989):
[0001069202-17-000013:note_history:23]
The ASP provides for a maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- added (2018-04-23):
[0001069202-18-000009:note_history:24]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 225.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest sold | (225.0 | ) |  | (276.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 14.0 |  |

- changed (2018-04-23):
[0001069202-18-000009:note_history:25]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2018 and December 31, 2017 were 2.63% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2017-10-24, similarity 0.8324):
[0001069202-17-000013:note_history:25]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The rates as of September 30, 2017 and December 31, 2016 were 1.99% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2018-04-23):
[0001069202-18-000009:note_history:26]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2018, we believe we were in compliance with all covenant requirements.
  (was, 2017-10-24, similarity 0.9895):
[0001069202-17-000013:note_history:26]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2017, we believe we were in compliance with all covenant requirements.

- added (2018-04-23):
[0001069202-18-000009:note_history:27]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $705.5 million, of which $212.5 million was the term loan balance, as well as $2.9 million committed to standby letters of credit as of March 31, 2018. Subject to covenant limitations, $154.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2018-04-23):
[0001069202-18-000009:note_history:28]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.03 | % |  | 2.76 | % |
  (was, 2017-10-24, similarity 0.95):
[0001069202-17-000013:note_history:28]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.47 | % |  | 2.00 | % |

- changed (2018-04-23):
[0001069202-18-000009:note_history:29]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.
  (was, 2017-10-24, similarity 0.648):
[0001069202-17-000013:note_history:29]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2017, we believe we were in compliance with all covenant requirements.

- added (2018-04-23):
[0001069202-18-000009:note_history:30]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2018, we believe we were in compliance with all covenant requirements.

- changed (2018-04-23):
[0001069202-18-000009:note_history:31]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2018, we believe we were in compliance with all covenant requirements.
  (was, 2017-10-24, similarity 0.9506):
[0001069202-17-000013:note_history:31]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also repaid $200.0 million of senior unsecured notes issued in 2010 that matured on May 15, 2017.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2017, we believe we were in compliance with all covenant requirements.

- removed (2018-04-23):
[0001069202-17-000013:note_history:32]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 325.0 |  |  | $ | 250.0 |  |
| Less: Beneficial interest sold | 325.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |

- removed (2018-04-23):
[0001069202-17-000013:note_history:33]
On August 30, 2016, we replaced an earlier credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $438.0 million, of which $220.0 million was the term loan balance, as well as $3.0 million committed to standby letters of credit as of September 30, 2017. Subject to covenant limitations, $429.0 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-04-23):
[0001069202-18-000009:note_history:34]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 0.9 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 0.9 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.9 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 225.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 675.5 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.1 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,258.3 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,289.1 |  |  | $ | 1,004.0 |  |
  (was, 2017-10-24, similarity 0.7636):
[0001069202-17-000013:note_history:34]
|  | As of September 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 325.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.0 |  |  | 2.4 |  |
| Total short-term debt | $ | 326.0 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 0.8 |  |
| Domestic credit facility | 22.5 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 22.4 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.7 |  |  | $ | 15.0 |  |
| Domestic credit facility | 415.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.5 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 775.7 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,124.1 |  |  | $ | 868.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-04-23):
[0001069202-18-000009:note_history:35]
Revenue Recognition:

- added (2018-04-23):
[0001069202-18-000009:note_history:36]
On January 1, 2018, we adopted the new accounting standard Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers and all the related amendments (“the new revenue standard”) and applied it to all contracts using the modified retrospective method.  We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings.  The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.  We expect the impact of the adoption of the new standard to be immaterial to our net income on an ongoing basis.

- added (2018-04-23):
[0001069202-18-000009:note_history:37]
The cumulative effect of the changes made to our consolidated January 1, 2018 balance sheet for the adoption of the new revenue standard was as follows (in millions):

- added (2018-04-23):
[0001069202-18-000009:note_history:38]
| BALANCE SHEET | Balance at December 31, 2017 |  | Adjustments Due to ASC 606 |  | Balance at January 1, 2018 |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 506.5 |  |  | $ | 8.3 |  |  | $ | 514.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 348.6 |  |  | 9.3 |  |  | 357.9 |  |
| Retained earnings | 1,575.9 |  |  | (1.0 | ) |  | 1,574.9 |  |

- added (2018-04-23):
[0001069202-18-000009:note_history:39]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption on our Consolidated Balance Sheet and Consolidated Statement of Operations was as follows (in millions):

- added (2018-04-23):
[0001069202-18-000009:note_history:40]
|  | March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 528.5 |  |  | $ | 521.8 |  |  | $ | 6.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 405.6 |  |  | 397.3 |  |  | 8.3 |  |
| Retained earnings | 1,609.6 |  |  | 1,611.2 |  |  | (1.6 | ) |
|  | For the Three Months Ended March 31, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 834.8 |  |  | $ | 834.9 |  |  | $ | (0.1 | ) |
| Net income | 37.9 |  |  | 37.9 |  |  | — |  |

- added (2018-04-23):
[0001069202-18-000009:note_history:41]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue.  See Note 16 for additional description of our reportable business segments and the products and services being sold in each segment.

- added (2018-04-23):
[0001069202-18-000009:note_history:42]
|  | For the Three Months Ended March 31, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 453.7 |  |  | $ | 179.1 |  |  | $ | 109.8 |  |  | $ | 742.6 |  |
| Europe | — |  |  | 26.4 |  |  | 26.8 |  |  | 53.2 |  |
| Asia Pacific | — |  |  | — |  |  | 39.0 |  |  | 39.0 |  |
| Total | $ | 453.7 |  |  | $ | 205.5 |  |  | $ | 175.6 |  |  | $ | 834.8 |  |

- added (2018-04-23):
[0001069202-18-000009:note_history:43]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.

- added (2018-04-23):
[0001069202-18-000009:note_history:44]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  See Note 7 for more information on product warranties.

- added (2018-04-23):
[0001069202-18-000009:note_history:45]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment for the three months ended March 31, 2018, direct sales represent approximately $339.5 million of revenues and sales to independent distributors represent approximately $114.2 million of revenues.  Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- added (2018-04-23):
[0001069202-18-000009:note_history:46]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, equipment sales represent approximately $177.9 million of revenues while $27.6 million of our revenue is generated from our service business.

- added (2018-04-23):
[0001069202-18-000009:note_history:47]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $173.6 million and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

- added (2018-04-23):
[0001069202-18-000009:note_history:48]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

- added (2018-04-23):
[0001069202-18-000009:note_history:49]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

- added (2018-04-23):
[0001069202-18-000009:note_history:50]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods are transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheet.

- added (2018-04-23):
[0001069202-18-000009:note_history:51]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accounts payable in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheet.

- added (2018-04-23):
[0001069202-18-000009:note_history:52]
Net contract assets (liabilities) consisted of the following:

- added (2018-04-23):
[0001069202-18-000009:note_history:53]
|  | March 31, 2018 |  | December 31, 2017 |  | $ change |  | % change |
| Contract assets | $ | 2.1 |  |  | $ | 2.1 |  |  | $ | — |  |  | — | % |
| Contract liabilities - current | (6.5 | ) |  | (7.3 | ) |  | 0.8 |  |  | (11.0 | )% |
| Contract liabilities - noncurrent | (5.4 | ) |  | (5.5 | ) |  | 0.1 |  |  | (1.8 | )% |
| Total | $ | (9.8 | ) |  | $ | (10.7 | ) |  | $ | 0.9 |  |  |  |

- added (2018-04-23):
[0001069202-18-000009:note_history:54]
For the three months ended March, 31, 2018, we recognized revenue of $1.6 million related to our contract liabilities at January 1, 2018.   Impairment losses recognized in our receivables and contract assets were de minimis in the first quarter of 2018.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2018-04-23):
[0001069202-18-000009:note_history:55]
Subsequent Event:

- added (2018-04-23):
[0001069202-18-000009:note_history:56]
During the second quarter of 2018, we obtained board approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale is subject to Brazilian antitrust approval and is expected to close later this year.  We expect to take a non-cash charge of approximately $30 million during the second quarter of 2018 related to the sale of this business.
