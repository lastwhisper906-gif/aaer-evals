# LII notes — 0001069202-18-000009


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-18-000009:notes:1]
mount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for s


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-18-000009:notes:2]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-18-000009:notes:3]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-18-000009:notes:4]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-18-000009:notes:5]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.03 | % |  | 2.76 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-18-000009:notes:6]
[same as prior period, unchanged from 0001069202-17-000013:notes:7]

[0001069202-18-000009:notes:7]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2018, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-18-000009:notes:8]
[same as prior period, unchanged from 0001069202-17-000013:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-18-000009:notes:9]
Commitments and Contingencies:

[0001069202-18-000009:notes:10]
Product Warranties and Product Related Contingencies

[0001069202-18-000009:notes:11]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-18-000009:notes:12]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000009:notes:13]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 34.5 |  |  | $ | 34.8 |  |
| Other liabilities | 74.3 |  |  | 75.1 |  |
| Total warranty liability | $ | 108.8 |  |  | $ | 109.9 |  |

[0001069202-18-000009:notes:14]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2018 were as follows (in millions):

[0001069202-18-000009:notes:15]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (5.0 | ) |
| Changes resulting from issuance of new warranties | 7.4 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | — |  |
| Warranty liability from assets held for sale | (0.9 | ) |
| Total warranty liability as of March 31, 2018 | $ | 108.8 |  |

[0001069202-18-000009:notes:16]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities, for such quality related issues, are not material.

[0001069202-18-000009:notes:17]
Litigation

[0001069202-18-000009:notes:18]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-18-000009:notes:19]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2018 and 2017, expense for asbestos-related litigation was $2.1 million and $1.7 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.

[0001069202-18-000009:notes:20]
In October 2016, we self-reported to the Securities and Exchange Commission ("SEC") and the Department of Justice ("DOJ") an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We concluded our investigation and communicated our findings to the SEC and the DOJ. We fully cooperated with the SEC and the DOJ regarding this matter. The  DOJ has declined to prosecute this matter.

[0001069202-18-000009:notes:21]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-18-000009:notes:22]
[same as prior period, unchanged from 0001069202-17-000013:notes:24]

[0001069202-18-000009:notes:23]
[same as prior period, unchanged from 0001069202-17-000013:notes:25]

[0001069202-18-000009:notes:24]
|  |  | For the Three Months Ended March 31, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2018 |  | 2017 |  |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 4.6 |  |  | $ | 3.0 |  |  | Cost of goods sold |
| Income tax expense |  | (1.1 | ) |  | (1.0 | ) |  | Provision for income taxes |
| Net of tax |  | $ | 3.5 |  |  | $ | 2.0 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (2.3 | ) |  | $ | (1.9 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.6 |  |  | 0.6 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.7 | ) |  | $ | (1.3 | ) |  |  |
| Total reclassifications from AOCL |  | $ | 1.8 |  |  | $ | 0.7 |  |  |  |

[0001069202-18-000009:notes:25]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2018 (in millions):

[0001069202-18-000009:notes:26]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2017 |  | $ | 7.4 |  |  | $ | 1.8 |  |  | $ | (127.5 | ) |  | $ | (39.1 | ) |  | $ | (157.4 | ) |
| Other comprehensive (loss) income before reclassifications |  | (2.1 | ) |  | (1.8 | ) |  | (26.1 | ) |  | 7.9 |  |  | (22.1 | ) |
| Amounts reclassified from AOCL |  | (3.5 | ) |  | — |  |  | 1.7 |  |  | — |  |  | (1.8 | ) |
| Net other comprehensive (loss) income |  | (5.6 | ) |  | (1.8 | ) |  | (24.4 | ) |  | 7.9 |  |  | (23.9 | ) |
| Balance as of March 31, 2018 |  | $ | 1.8 |  |  | $ | — |  |  | $ | (151.9 | ) |  | $ | (31.2 | ) |  | $ | (181.3 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-18-000009:notes:27]
[same as prior period, unchanged from 0001069202-17-000013:notes:29]

[0001069202-18-000009:notes:28]
[same as prior period, unchanged from 0001069202-17-000013:notes:30]

[0001069202-18-000009:notes:29]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of March 31, 2018 and December 31, 2017 and for the three months ended March 31, 2018 and 2017 are shown on the following pages.

[0001069202-18-000009:notes:30]
[same as prior period, unchanged from 0001069202-17-000013:notes:32]

[0001069202-18-000009:notes:31]
[same as prior period, unchanged from 0001069202-17-000013:notes:33]

[0001069202-18-000009:notes:32]
As of March 31, 2018

[0001069202-18-000009:notes:33]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.4 |  |  | $ | 15.0 |  |  | $ | 40.7 |  |  | $ | — |  |  | $ | 57.1 |  |
| Accounts and notes receivable, net | — |  |  | 49.4 |  |  | 479.1 |  |  | — |  |  | 528.5 |  |
| Inventories, net | — |  |  | 469.2 |  |  | 97.8 |  |  | (5.5 | ) |  | 561.5 |  |
| Assets held for sale | — |  |  | — |  |  | 93.3 |  |  | — |  |  | 93.3 |  |
| Other assets | 7.3 |  |  | 69.8 |  |  | 63.1 |  |  | (33.8 | ) |  | 106.4 |  |
| Total current assets | 8.7 |  |  | 603.4 |  |  | 774.0 |  |  | (39.3 | ) |  | 1,346.8 |  |
| Property, plant and equipment, net | — |  |  | 259.0 |  |  | 135.1 |  |  | (4.0 | ) |  | 390.1 |  |
| Goodwill | — |  |  | 134.9 |  |  | 55.4 |  |  | — |  |  | 190.3 |  |
| Investment in subsidiaries | 1,524.7 |  |  | 472.6 |  |  | (12.5 | ) |  | (1,984.8 | ) |  | — |  |
| Deferred income taxes | 4.7 |  |  | 71.5 |  |  | 30.0 |  |  | (12.2 | ) |  | 94.0 |  |
| Other assets, net | 3.1 |  |  | 45.0 |  |  | 18.3 |  |  | (1.5 | ) |  | 64.9 |  |
| Intercompany (payables) receivables, net | (555.5 | ) |  | 576.1 |  |  | 82.2 |  |  | (102.8 | ) |  | — |  |
| Total assets | $ | 985.7 |  |  | $ | 2,162.5 |  |  | $ | 1,082.5 |  |  | $ | (2,144.6 | ) |  | $ | 2,086.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt | 29.4 |  |  | 0.2 |  |  | 0.3 |  |  | — |  |  | 29.9 |  |
| Accounts payable | 21.1 |  |  | 278.5 |  |  | 106.0 |  |  | — |  |  | 405.6 |  |
| Accrued expenses | 6.0 |  |  | 179.1 |  |  | 40.9 |  |  | — |  |  | 226.0 |  |
| Liabilities held for sale | — |  |  | — |  |  | 28.7 |  |  | — |  |  | 28.7 |  |
| Income taxes payable (receivable) | 11.4 |  |  | 20.7 |  |  | 40.4 |  |  | (50.8 | ) |  | 21.7 |  |
| Total current liabilities | 67.9 |  |  | 478.5 |  |  | 217.2 |  |  | (50.8 | ) |  | 712.8 |  |
| Long-term debt | 1,021.6 |  |  | 11.7 |  |  | 225.0 |  |  | — |  |  | 1,258.3 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Pensions | — |  |  | 76.3 |  |  | 9.6 |  |  | — |  |  | 85.9 |  |
| Other liabilities | (1.2 | ) |  | 122.1 |  |  | 8.3 |  |  | — |  |  | 129.2 |  |
| Total liabilities | 1,088.3 |  |  | 691.1 |  |  | 460.1 |  |  | (50.8 | ) |  | 2,188.7 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | (102.6 | ) |  | 1,471.4 |  |  | 622.4 |  |  | (2,093.8 | ) |  | (102.6 | ) |
| Total liabilities and stockholders' equity | $ | 985.7 |  |  | $ | 2,162.5 |  |  | $ | 1,082.5 |  |  | $ | (2,144.6 | ) |  | $ | 2,086.1 |  |

[0001069202-18-000009:notes:34]
As of December 31, 2017

[0001069202-18-000009:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.6 |  |  | $ | 28.0 |  |  | $ | 38.6 |  |  | $ | — |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net | — |  |  | 35.3 |  |  | 471.2 |  |  | — |  |  | 506.5 |  |
| Inventories, net | — |  |  | 355.7 |  |  | 131.9 |  |  | (3.4 | ) |  | 484.2 |  |
| Other assets | 16.2 |  |  | 23.1 |  |  | 67.5 |  |  | (28.4 | ) |  | 78.4 |  |
| Total current assets | 17.8 |  |  | 442.1 |  |  | 709.2 |  |  | (31.8 | ) |  | 1,137.3 |  |
| Property, plant and equipment, net | — |  |  | 257.6 |  |  | 144.4 |  |  | (4.2 | ) |  | 397.8 |  |
| Goodwill | — |  |  | 134.9 |  |  | 65.6 |  |  | — |  |  | 200.5 |  |
| Investment in subsidiaries | 1,257.7 |  |  | 365.8 |  |  | (0.6 | ) |  | (1,622.9 | ) |  | — |  |
| Deferred income taxes | 3.9 |  |  | 69.1 |  |  | 33.6 |  |  | (12.2 | ) |  | 94.4 |  |
| Other assets, net | 2.1 |  |  | 41.3 |  |  | 19.6 |  |  | (1.5 | ) |  | 61.5 |  |
| Intercompany (payables) receivables, net | (559.3 | ) |  | 554.7 |  |  | 107.4 |  |  | (102.8 | ) |  | — |  |
| Total assets | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.9 |  |  | 0.3 |  |  | — |  |  | 32.6 |  |
| Accounts payable | 21.3 |  |  | 228.0 |  |  | 99.3 |  |  | — |  |  | 348.6 |  |
| Accrued expenses | 3.1 |  |  | 209.4 |  |  | 57.8 |  |  | — |  |  | 270.3 |  |
| Income taxes (receivable) payable | (64.5 | ) |  | 56.5 |  |  | 60.9 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | (10.7 | ) |  | 496.8 |  |  | 219.2 |  |  | (50.8 | ) |  | 654.5 |  |
| Long-term debt | 682.8 |  |  | 11.7 |  |  | 276.0 |  |  | — |  |  | 970.5 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.6 |  |  | — |  |  | — |  |  | 2.6 |  |
| Pensions | — |  |  | 74.7 |  |  | 9.8 |  |  | — |  |  | 84.5 |  |
| Other liabilities | — |  |  | 120.6 |  |  | 8.7 |  |  | — |  |  | 129.3 |  |
| Total liabilities | 672.1 |  |  | 706.4 |  |  | 513.7 |  |  | (50.8 | ) |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 50.1 |  |  | 1,159.1 |  |  | 565.5 |  |  | (1,724.6 | ) |  | 50.1 |  |
| Total liabilities and stockholders' equity | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |

[0001069202-18-000009:notes:36]
[same as prior period, unchanged from 0001069202-17-000013:notes:38]

[0001069202-18-000009:notes:37]
For the Three Months Ended March 31, 2018

[0001069202-18-000009:notes:38]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 716.3 |  |  | $ | 279.0 |  |  | $ | (160.5 | ) |  | $ | 834.8 |  |
| Cost of goods sold | — |  |  | 533.4 |  |  | 236.5 |  |  | (158.3 | ) |  | 611.6 |  |
| Gross profit | — |  |  | 182.9 |  |  | 42.5 |  |  | (2.2 | ) |  | 223.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 133.7 |  |  | 21.7 |  |  | (0.2 | ) |  | 155.2 |  |
| Losses (gains) and other expenses, net | 1.2 |  |  | 4.0 |  |  | 2.2 |  |  | (0.1 | ) |  | 7.3 |  |
| Restructuring charges | — |  |  | 0.7 |  |  | 0.2 |  |  | — |  |  | 0.9 |  |
| Loss on assets held for sale | — |  |  | — |  |  | 10.3 |  |  | — |  |  | 10.3 |  |
| Income from equity method investments | (40.6 | ) |  | (4.6 | ) |  | (3.0 | ) |  | 44.7 |  |  | (3.5 | ) |
| Operating income | 39.4 |  |  | 49.1 |  |  | 11.1 |  |  | (46.6 | ) |  | 53.0 |  |
| Interest expense, net | 2.4 |  |  | 4.1 |  |  | 1.9 |  |  | — |  |  | 8.4 |  |
| Other expense, net | — |  |  | 0.6 |  |  | — |  |  | — |  |  | 0.6 |  |
| Income from continuing operations before income taxes | 37.0 |  |  | 44.4 |  |  | 9.2 |  |  | (46.6 | ) |  | 44.0 |  |
| Provision for income tax (benefit) expense | (0.9 | ) |  | 5.5 |  |  | 1.3 |  |  | 0.2 |  |  | 6.1 |  |
| Income from continuing operations | 37.9 |  |  | 38.9 |  |  | 7.9 |  |  | (46.8 | ) |  | 37.9 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 37.9 |  |  | $ | 38.9 |  |  | $ | 7.9 |  |  | $ | (46.8 | ) |  | $ | 37.9 |  |
| Other comprehensive income, net of tax | (7.1 | ) |  | (20.7 | ) |  | 3.9 |  |  | — |  |  | (23.9 | ) |
| Comprehensive income (loss) | $ | 30.8 |  |  | $ | 18.2 |  |  | $ | 11.8 |  |  | $ | (46.8 | ) |  | $ | 14.0 |  |

[0001069202-18-000009:notes:39]
For the Three Months Ended March 31, 2017

[0001069202-18-000009:notes:40]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 686.3 |  |  | $ | 258.8 |  |  | $ | (151.7 | ) |  | $ | 793.4 |  |
| Cost of goods sold | — |  |  | 513.3 |  |  | 217.7 |  |  | (148.5 | ) |  | 582.5 |  |
| Gross profit | — |  |  | 173.0 |  |  | 41.1 |  |  | (3.2 | ) |  | 210.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 130.5 |  |  | 22.1 |  |  | (0.2 | ) |  | 152.4 |  |
| Losses (gains) and other expenses, net | 0.6 |  |  | 2.0 |  |  | 0.6 |  |  | (0.1 | ) |  | 3.1 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (48.6 | ) |  | (12.7 | ) |  | (4.9 | ) |  | 60.7 |  |  | (5.5 | ) |
| Operating income | 48.0 |  |  | 53.2 |  |  | 23.2 |  |  | (63.6 | ) |  | 60.8 |  |
| Interest expense, net | 7.2 |  |  | (0.8 | ) |  | 1.0 |  |  | — |  |  | 7.4 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 40.8 |  |  | 54.0 |  |  | 22.2 |  |  | (63.6 | ) |  | 53.4 |  |
| Provision for income tax (benefit) expense | (2.7 | ) |  | 7.1 |  |  | 6.3 |  |  | (0.8 | ) |  | 9.9 |  |
| Income from continuing operations | 43.5 |  |  | 46.9 |  |  | 15.9 |  |  | (62.8 | ) |  | 43.5 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 43.5 |  |  | $ | 46.9 |  |  | $ | 15.9 |  |  | $ | (62.8 | ) |  | $ | 43.5 |  |
| Other comprehensive (loss) income, net of tax | (71.2 | ) |  | (29.4 | ) |  | 10.8 |  |  | 108.4 |  |  | 18.6 |  |
| Comprehensive (loss) income | $ | (27.7 | ) |  | $ | 17.5 |  |  | $ | 26.7 |  |  | $ | 45.6 |  |  | $ | 62.1 |  |

[0001069202-18-000009:notes:41]
[same as prior period, unchanged from 0001069202-17-000013:notes:47]

[0001069202-18-000009:notes:42]
For the Three Months Ended March 31, 2018

[0001069202-18-000009:notes:43]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 104.4 |  |  | $ | (158.6 | ) |  | $ | (29.3 | ) |  | $ | — |  |  | $ | (83.5 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (17.3 | ) |  | (5.4 | ) |  | — |  |  | (22.7 | ) |
| Net cash used in investing activities | — |  |  | (17.3 | ) |  | (5.3 | ) |  | — |  |  | (22.6 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset securitization payments | — |  |  | — |  |  | (51.0 | ) |  | — |  |  | (51.0 | ) |
| Long-term debt payments | (7.5 | ) |  | (2.7 | ) |  | — |  |  | — |  |  | (10.2 | ) |
| Long-term borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Borrowings from credit facility | 790.0 |  |  | — |  |  | — |  |  | — |  |  | 790.0 |  |
| Payments on credit facility | (444.1 | ) |  | — |  |  | — |  |  | — |  |  | (444.1 | ) |
| Proceeds from employee stock purchases | 0.8 |  |  | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Repurchases of common stock | (150.0 | ) |  | — |  |  | — |  |  | — |  |  | (150.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (18.1 | ) |  | — |  |  | — |  |  | — |  |  | (18.1 | ) |
| Intercompany debt | (47.5 | ) |  | 37.9 |  |  | 9.6 |  |  | — |  |  | — |  |
| Intercompany financing activity | (206.9 | ) |  | 127.7 |  |  | 79.2 |  |  | — |  |  | — |  |
| Cash dividends paid | (21.3 | ) |  | — |  |  | — |  |  | — |  |  | (21.3 | ) |
| Net cash (used in) provided by financing activities | (104.6 | ) |  | 162.9 |  |  | 37.7 |  |  | — |  |  | 96.0 |  |
| Increase (decrease) in cash and cash equivalents | (0.2 | ) |  | (13.0 | ) |  | 3.1 |  |  | — |  |  | (10.1 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (1.0 | ) |  | — |  |  | (1.0 | ) |
| Cash and cash equivalents, beginning of period | 1.6 |  |  | 28.0 |  |  | 38.6 |  |  | — |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 1.4 |  |  | $ | 15.0 |  |  | $ | 40.7 |  |  | $ | — |  |  | $ | 57.1 |  |

[0001069202-18-000009:notes:44]
For the Three Months Ended March 31, 2017

[0001069202-18-000009:notes:45]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 341.2 |  |  | $ | (308.6 | ) |  | $ | (140.2 | ) |  | $ | — |  |  | $ | (107.6 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (22.0 | ) |  | (2.9 | ) |  | — |  |  | (24.9 | ) |
| Net cash used in investing activities | — |  |  | (22.0 | ) |  | (2.8 | ) |  | — |  |  | (24.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 150.0 |  |  | — |  |  | 150.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | — |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |  | (0.2 | ) |
| Borrowings from credit facility | 583.0 |  |  | — |  |  | — |  |  | — |  |  | 583.0 |  |
| Payments on credit facility | (497.5 | ) |  | — |  |  | — |  |  | — |  |  | (497.5 | ) |
| Proceeds from employee stock purchases | 0.7 |  |  | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Repurchases of common stock | (75.0 | ) |  | — |  |  | — |  |  | — |  |  | (75.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (13.3 | ) |  | — |  |  | — |  |  | — |  |  | (13.3 | ) |
| Intercompany debt | (29.3 | ) |  | 7.6 |  |  | 21.7 |  |  | — |  |  | — |  |
| Intercompany financing activity | (291.0 | ) |  | 320.0 |  |  | (29.0 | ) |  | — |  |  | — |  |
| Cash dividends paid | (18.5 | ) |  | — |  |  | — |  |  | — |  |  | (18.5 | ) |
| Net cash (used in) provided by financing activities | (340.9 | ) |  | 327.5 |  |  | 141.8 |  |  | — |  |  | 128.4 |  |
| Increase (decrease) in cash and cash equivalents | 0.3 |  |  | (3.1 | ) |  | (1.2 | ) |  | — |  |  | (4.0 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 2.6 |  |  | — |  |  | 2.6 |  |
| Cash and cash equivalents, beginning of period | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of period | $ | 1.5 |  |  | $ | 14.0 |  |  | $ | 33.3 |  |  | $ | — |  |  | $ | 48.8 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001069202-18-000009:notes:46]
Net contract assets (liabilities) consisted of the following:

[0001069202-18-000009:notes:47]
|  | March 31, 2018 |  | December 31, 2017 |  | $ change |  | % change |
| Contract assets | $ | 2.1 |  |  | $ | 2.1 |  |  | $ | — |  |  | — | % |
| Contract liabilities - current | (6.5 | ) |  | (7.3 | ) |  | 0.8 |  |  | (11.0 | )% |
| Contract liabilities - noncurrent | (5.4 | ) |  | (5.5 | ) |  | 0.1 |  |  | (1.8 | )% |
| Total | $ | (9.8 | ) |  | $ | (10.7 | ) |  | $ | 0.9 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-18-000009:notes:48]
Lines of Credit and Financing Arrangements:

[0001069202-18-000009:notes:49]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000009:notes:50]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 0.9 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 0.9 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.9 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 225.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 675.5 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.1 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,258.3 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,289.1 |  |  | $ | 1,004.0 |  |

[0001069202-18-000009:notes:51]
Short-Term Debt

[0001069202-18-000009:notes:52]
Foreign Obligations

[0001069202-18-000009:notes:53]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $0.9 million and $0.9 million of foreign obligations outstanding as of March 31, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.3 million  and $0.3 million during the three months ended March 31, 2018 and 2017, respectively. Repayments on the facilities were $0.4 million and $1.1 million during the three months ended March 31, 2018 and 2017, respectively.

[0001069202-18-000009:notes:54]
Asset Securitization Program

[0001069202-18-000009:notes:55]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-18-000009:notes:56]
The ASP provides for a maximum securitization amount ranging from $225.0 million to $380.0 million, depending on the period. The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-18-000009:notes:57]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 225.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest sold | (225.0 | ) |  | (276.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 14.0 |  |

[0001069202-18-000009:notes:58]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2018 and December 31, 2017 were 2.63% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-18-000009:notes:59]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2018, we believe we were in compliance with all covenant requirements.

[0001069202-18-000009:notes:60]
Long-Term Debt

[0001069202-18-000009:notes:61]
Domestic Credit Facility

[0001069202-18-000009:notes:62]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $705.5 million, of which $212.5 million was the term loan balance, as well as $2.9 million committed to standby letters of credit as of March 31, 2018. Subject to covenant limitations, $154.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-18-000009:notes:63]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-18-000009:notes:64]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-18-000009:notes:65]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-18-000009:notes:66]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-18-000009:notes:67]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-18-000009:notes:68]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2018, we believe we were in compliance with all covenant requirements.

[0001069202-18-000009:notes:69]
Senior Unsecured Notes

[0001069202-18-000009:notes:70]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2018, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-18-000009:notes:71]
[same as prior period, unchanged from 0001069202-17-000013:notes:73]

[0001069202-18-000009:notes:72]
[same as prior period, unchanged from 0001069202-17-000013:notes:74]

[0001069202-18-000009:notes:73]
[same as prior period, unchanged from 0001069202-17-000013:notes:75]

[0001069202-18-000009:notes:74]
[same as prior period, unchanged from 0001069202-17-000013:notes:76]

[0001069202-18-000009:notes:75]
[same as prior period, unchanged from 0001069202-17-000013:notes:77]

[0001069202-18-000009:notes:76]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 intends to simplify the application of hedge accounting guidance  and better align an entity's risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results. The amendments expand and refine hedge accounting for both nonfinancial and financial risk components and align the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. The Company early adopted ASU No. 2017-12 during the first quarter of 2018. The adoption of ASU No. 2017-12 did not have a material impact on our consolidated results of operations, cash flows, and statement of financial position. With the early adoption of ASU No. 2017-12 we began entering into commodity futures contracts designated as cash flow hedges related to aluminum purchases.

[0001069202-18-000009:notes:77]
[same as prior period, unchanged from 0001069202-17-000013:notes:78]

[0001069202-18-000009:notes:78]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through December 2018 and August 2019, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-18-000009:notes:79]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Unrealized gains on unsettled contracts | $ | (2.5 | ) |  | $ | (11.3 | ) |
| Income tax expense | 0.7 |  |  | 3.9 |  |
| Gains included in AOCL, net of tax (1) | $ | (1.8 | ) |  | $ | (7.4 | ) |

[0001069202-18-000009:notes:80]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $2.3 million of derivative gains into earnings within the next 12 months.

[0001069202-18-000009:notes:81]
[same as prior period, unchanged from 0001069202-17-000013:notes:82]

[0001069202-18-000009:notes:82]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Copper | 20.2 |  |  | 20.6 |  |
| Aluminum | 16.6 |  |  | — |  |

[0001069202-18-000009:notes:83]
[same as prior period, unchanged from 0001069202-17-000013:notes:84]

[0001069202-18-000009:notes:84]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 152.2 |  |  | 207.3 |  |
| Canadian Dollar | 51.0 |  |  | 68.6 |  |

[0001069202-18-000009:notes:85]
[same as prior period, unchanged from 0001069202-17-000013:notes:86]

[0001069202-18-000009:notes:86]
[same as prior period, unchanged from 0001069202-17-000013:notes:87]

[0001069202-18-000009:notes:87]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Copper | 1.6 |  |  | 1.8 |  |
| Aluminum | 1.7 |  |  | 1.8 |  |

[0001069202-18-000009:notes:88]
[same as prior period, unchanged from 0001069202-17-000013:notes:89]

[0001069202-18-000009:notes:89]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Notional Amounts (in local currency): |  |  |  |
| Chinese Yuan | 97.5 |  |  | 73.8 |  |
| Mexican Peso | — |  |  | 136.6 |  |
| Euro | 99.9 |  |  | 64.4 |  |
| Canadian Dollar | 20.0 |  |  | 27.3 |  |
| British Pound | 4.2 |  |  | 4.5 |  |
| Singapore Dollar | 6.4 |  |  | 7.0 |  |
| Australian Dollar | 177.0 |  |  | 107.0 |  |
| New Zealand Dollar | 9.6 |  |  | 5.0 |  |
| Indian Rupee | — |  |  | 39.8 |  |

[0001069202-18-000009:notes:90]
[same as prior period, unchanged from 0001069202-17-000013:notes:91]

[0001069202-18-000009:notes:91]
[same as prior period, unchanged from 0001069202-17-000013:notes:92]

[0001069202-18-000009:notes:92]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of March 31, 2018 |  | As of December 31, 2017 |  | As of March 31, 2018 |  | As of December 31, 2017 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 2.7 |  |  | $ | 11.0 |  |  | $ | 0.1 |  |  | $ | 1.2 |  |
| Foreign currency forward contracts | 1.7 |  |  | 0.1 |  |  | 1.3 |  |  | 0.9 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.6 |  |  | — |  |  | 0.1 |  |
| Total Assets | $ | 4.4 |  |  | $ | 11.7 |  |  | $ | 1.4 |  |  | $ | 2.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 1.4 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | 0.3 |  |  | 0.2 |  |  | 1.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.6 |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 2.0 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 1.1 |  |

[0001069202-18-000009:notes:93]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 17 for more information.

[0001069202-18-000009:notes:94]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| Amount of Gain reclassified from AOCL into Income (effective portion) (1) |  | $ | (4.6 | ) |  | $ | (3.0 | ) |
| Amount of Loss recognized in Net income (ineffective portion) (2)(3) |  | — |  |  | 1.1 |  |

[0001069202-18-000009:notes:95]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| Amount of (Gain)/Loss Recognized in Net Income: |  |  |  |  |
| Commodity futures contracts (2) |  | $ | 0.6 |  |  | $ | (0.8 | ) |
| Foreign currency forward contracts (2) |  | (0.7 | ) |  | (0.7 | ) |
|  |  | $ | (0.1 | ) |  | $ | (1.5 | ) |

[0001069202-18-000009:notes:96]
(1) The gain was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-18-000009:notes:97]
[same as prior period, unchanged from 0001069202-17-000013:notes:98]

[0001069202-18-000009:notes:98]
(3) The ASU 2017-12 eliminates the requirement to disclose the amount of hedge ineffectiveness prospectively because this        amount is no longer separately measured and reported.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-18-000009:notes:99]
[same as prior period, unchanged from 0001069202-17-000013:notes:99]

[0001069202-18-000009:notes:100]
[same as prior period, unchanged from 0001069202-17-000013:notes:100]

[0001069202-18-000009:notes:101]
|  | For the Three Months Ended March 31, |
|  | 2018 |  | 2017 |
| Stock-based compensation expense (1) | $ | 4.8 |  |  | $ | 4.9 |  |

[0001069202-18-000009:notes:102]
[same as prior period, unchanged from 0001069202-17-000013:notes:102]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-18-000009:notes:103]
Assets Held for Sale:

[0001069202-18-000009:notes:104]
We have assets held for sale as it relates to our Australia, New Zealand and Asia businesses. During the first quarter of 2018, we obtained board approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia, New Zealand and Asia businesses. The sale is expected to close in the second quarter of 2018.

[0001069202-18-000009:notes:105]
The following table presents the assets and liabilities associated with our Australia, New Zealand and Asia businesses classified as held for sale as of March 31, 2018.

[0001069202-18-000009:notes:106]
| (Amounts in millions) | As of March 31, 2018 |
| Assets held for sale |  |
| Accounts and notes receivable, net of allowances | $ | 22.1 |  |
| Inventories, net | 46.9 |  |
| Other assets | 3.6 |  |
| Property, plant and equipment, net of accumulated depreciation | 12.2 |  |
| Deferred income taxes | 4.5 |  |
| Other assets, net | 4.0 |  |
| Goodwill | 10.3 |  |
| Loss on assets held for sale | (10.3 | ) |
| Total assets held for sale | $ | 93.3 |  |
| Liabilities held for sale |  |
| Accounts payable | $ | 17.0 |  |
| Accrued expenses | 10.7 |  |
| Income taxes payable | 0.5 |  |
| Other liabilities | 0.5 |  |
| Total liabilities held for sale | $ | 28.7 |  |

[0001069202-18-000009:notes:107]
Based on the expected proceeds from the sale, net of selling costs, we recorded a loss on the assets held for sale of $10.3 million during the quarter ended March 31, 2018.


## us-gaap:EarningsPerShareTextBlock

[0001069202-18-000009:notes:108]
[same as prior period, unchanged from 0001069202-17-000013:notes:103]

[0001069202-18-000009:notes:109]
[same as prior period, unchanged from 0001069202-17-000013:notes:104]

[0001069202-18-000009:notes:110]
[same as prior period, unchanged from 0001069202-17-000013:notes:105]

[0001069202-18-000009:notes:111]
|  | For the Three Months Ended March 31, |
|  | 2018 |  | 2017 |
| Net income | $ | 37.9 |  |  | $ | 43.5 |  |
| Add: Loss from discontinued operations | — |  |  | — |  |
| Income from continuing operations | $ | 37.9 |  |  | $ | 43.5 |  |
| Weighted-average shares outstanding – basic | 41.5 |  |  | 42.8 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.6 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 42.1 |  |  | 43.5 |  |
| Earnings per share – Basic: |  |  |  |
| Income from continuing operations | $ | 0.91 |  |  | $ | 1.02 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 0.91 |  |  | $ | 1.02 |  |
| Earnings per share – Diluted: |  |  |  |
| Income from continuing operations | $ | 0.90 |  |  | $ | 1.00 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 0.90 |  |  | $ | 1.00 |  |

[0001069202-18-000009:notes:112]
[same as prior period, unchanged from 0001069202-17-000013:notes:107]

[0001069202-18-000009:notes:113]
|  | For the Three Months Ended March 31, |
|  | 2018 |  | 2017 |
| Weighted-average number of shares | 0.2 |  |  | 0.2 |  |
| Price per share | $ | 205.53 |  |  | $ | 156.94 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-18-000009:notes:114]
[same as prior period, unchanged from 0001069202-17-000013:notes:109]

[0001069202-18-000009:notes:115]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Senior unsecured notes | $ | 300.0 |  |  | $ | 308.1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-18-000009:notes:116]
[same as prior period, unchanged from 0001069202-17-000013:notes:111]

[0001069202-18-000009:notes:117]
[same as prior period, unchanged from 0001069202-17-000013:notes:112]

[0001069202-18-000009:notes:118]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2018 were the same as those used at December 31, 2017.

[0001069202-18-000009:notes:119]
[same as prior period, unchanged from 0001069202-17-000013:notes:114]

[0001069202-18-000009:notes:120]
[same as prior period, unchanged from 0001069202-17-000013:notes:115]

[0001069202-18-000009:notes:121]
Derivatives were classified as Level 2 and primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, however, they were insignificant to the overall value of the derivatives.  Refer to Note 5 for more information related to our derivative instruments.

[0001069202-18-000009:notes:122]
[same as prior period, unchanged from 0001069202-17-000013:notes:117]

[0001069202-18-000009:notes:123]
[same as prior period, unchanged from 0001069202-17-000013:notes:118]

[0001069202-18-000009:notes:124]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Investment in marketable equity securities | $ | 3.9 |  |  | $ | 4.1 |  |

[0001069202-18-000009:notes:125]
[same as prior period, unchanged from 0001069202-17-000013:notes:120]

[0001069202-18-000009:notes:126]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-18-000009:notes:127]
[same as prior period, unchanged from 0001069202-17-000013:notes:122]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-18-000009:notes:128]
[same as prior period, unchanged from 0001069202-17-000013:notes:123]

[0001069202-18-000009:notes:129]
The changes in the carrying amount of goodwill for the first three months of 2018, in total and by segment, are summarized in the table below (in millions):

[0001069202-18-000009:notes:130]
|  | Balance at December 31, 2017 |  | Transfer to assets held for sale |  | Changes in foreign currency translation rates |  | Balance at March 31, 2018 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 62.2 |  |  | — |  |  | 0.4 |  |  | 62.6 |  |
| Refrigeration | 112.2 |  |  | (10.3 | ) |  | (0.3 | ) |  | 101.6 |  |
| Total Goodwill | $ | 200.5 |  |  | $ | (10.3 | ) |  | $ | 0.1 |  |  | $ | 190.3 |  |

[0001069202-18-000009:notes:131]
We perform our annual goodwill impairment test in the fourth quarter of each year.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  In the current year, as a part of the planned sale of our Australia, New Zealand and Asia businesses (discussed further in Note 14 of the Notes to the Consolidated Financial Statements) we transferred $10.3 million of goodwill to assets held for sale.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-18-000009:notes:132]
[same as prior period, unchanged from 0001069202-17-000013:notes:127]

[0001069202-18-000009:notes:133]
As of March 31, 2018, we had no unrecognized tax benefits.

[0001069202-18-000009:notes:134]
[same as prior period, unchanged from 0001069202-17-000013:notes:129]

[0001069202-18-000009:notes:135]
Since January 1, 2018, several states have enacted legislation effective for tax years beginning on or after January 1, 2018, including changes to tax rates and apportionment methods.  The impact of these changes is immaterial.

[0001069202-18-000009:notes:136]
On October 24, 2016, the FASB issued ASU No. 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory, which requires companies to recognize the income tax effects of intercompany sales and transfers of assets other than inventory in the period in which the transfer occurs.  Prior to ASU 2016-16, companies were required to defer the income tax effects of intercompany transfers of assets until the asset had been sold to an outside party or otherwise recognized.  The new guidance is effective for public business entities for annual periods beginning after December 15, 2017 and interim periods within those annual periods.  The guidance requires companies to apply a modified retrospective approach with a cumulative catch-up adjustment to opening retained earnings in the period of adoption.  Accordingly, we recorded a $5.1 million decrease to opening retained earnings in the period ending March 31, 2018.

[0001069202-18-000009:notes:137]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”).  The Tax Act makes broad and complex changes to the U.S. tax code, including, but not limited to, the new global intangible low-taxed income ("GILTI") tax rules.  Because of the complexity of the new GILTI tax rules, we are continuing to evaluate this provision of the Tax Act and the application of ASC 740.  Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”).  Our selection of an accounting policy with respect to the new GILTI tax rules will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in taxable income related to GILTI and, if so, what the impact is expected to be.  We are not currently able to reasonably estimate the effect of the new GILTI tax rules on future U.S. inclusions in taxable income as the expected future impact of this provision of the Tax Act depends on our current structure and business.  Therefore, although we have considered the current effects of GILTI when estimating our annual effective tax rate, we have not made any adjustments related to potential GILTI tax in our deferred taxes and have not made a policy decision regarding whether to record deferred taxes on GILTI.

[0001069202-18-000009:notes:138]
On February 14, 2018, the FASB issued ASU No. 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits companies to reclassify stranded tax effects caused by 2017 tax reform between accumulated other comprehensive income (“AOCI”) and retained earnings.  We have elected to adopt ASU 2018-02 to reclassify the income tax effects of the 2017 Act from AOCI to retained earnings for the period ending March 31, 2018.  Accordingly, we recorded a $22.7 million increase to opening retained earnings in the period ending March 31, 2018 to reclassify the effect of the change in the U.S. federal corporate income tax rate, including the reduction in the federal benefit associated with state taxes, on the gross deferred tax amounts and related valuation allowances at the date of enactment of the Tax Cuts and Jobs Act related to items remaining in AOCI.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-18-000009:notes:139]
[same as prior period, unchanged from 0001069202-17-000013:notes:132]

[0001069202-18-000009:notes:140]
[same as prior period, unchanged from 0001069202-17-000013:notes:133]

[0001069202-18-000009:notes:141]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Finished goods | $ | 397.0 |  |  | $ | 331.9 |  |
| Work in process | 6.2 |  |  | 5.5 |  |
| Raw materials and parts | 210.9 |  |  | 199.2 |  |
| Subtotal | 614.1 |  |  | 536.6 |  |
| Excess of current cost over last-in, first-out cost | (52.6 | ) |  | (52.4 | ) |
| Total inventories, net | $ | 561.5 |  |  | $ | 484.2 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001069202-18-000009:notes:142]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We will adopt the standard using the prospective approach and are still determining the effect of the standard on our ongoing financial reporting.  As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-18-000009:notes:143]
[same as prior period, unchanged from 0001069202-17-000013:notes:135]

[0001069202-18-000009:notes:144]
[same as prior period, unchanged from 0001069202-17-000013:notes:136]

[0001069202-18-000009:notes:145]
[same as prior period, unchanged from 0001069202-17-000013:notes:137]

[0001069202-18-000009:notes:146]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-18-000009:notes:147]
[same as prior period, unchanged from 0001069202-17-000013:notes:139]

[0001069202-18-000009:notes:148]
[same as prior period, unchanged from 0001069202-17-000013:notes:147]

[0001069202-18-000009:notes:149]
[same as prior period, unchanged from 0001069202-17-000013:notes:148]

[0001069202-18-000009:notes:150]
Recently Adopted Accounting Guidance

[0001069202-18-000009:notes:151]
In August 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees.  For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017.  This standard did not have a material impact on our consolidated financial statements.

[0001069202-18-000009:notes:152]
We also adopted other new accounting standards during the first quarter of 2018.  The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.

[0001069202-18-000009:notes:153]
Recent Accounting Pronouncements


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-18-000009:notes:154]
[same as prior period, unchanged from 0001069202-17-000013:notes:149]

[0001069202-18-000009:notes:155]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other expense, net in the Statement of Operations. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We elected the practical expedient to use the prior year's disclosure as a basis for the retroactive adoption of the ASU.  The ASU did not have a material impact on our financial results.

[0001069202-18-000009:notes:156]
[same as prior period, unchanged from 0001069202-17-000013:notes:150]

[0001069202-18-000009:notes:157]
|  | For the Three Months Ended March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.4 |  |  | $ | 1.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.1 |  |  | 3.2 |  |  | — |  |  | — |  |
| Expected return on plan assets | (4.7 | ) |  | (5.4 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  | (0.3 | ) |  | (0.6 | ) |
| Recognized actuarial loss | 2.3 |  |  | 2.1 |  |  | 0.3 |  |  | 0.3 |  |
| Settlements and curtailments | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 2.1 |  |  | $ | 1.6 |  |  | $ | — |  |  | $ | (0.3 | ) |

[0001069202-18-000009:notes:158]
In January 2018, we reduced our estimated long-term rate of return on plan assets for U.S. pension plans from 7.5% to 6.5%.  A 25 basis point decrease in the long-term rate of return will result in a $0.7 million increase in net periodic benefit cost for U.S. pension plans.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-18-000009:notes:159]
[same as prior period, unchanged from 0001069202-17-000013:notes:154]

[0001069202-18-000009:notes:160]
|  | For the Three Months Ended March 31, |
|  | 2018 |  | 2017 |
| Net sales |  |  |  |
| Residential Heating & Cooling | $ | 453.7 |  |  | $ | 419.8 |  |
| Commercial Heating & Cooling | 205.5 |  |  | 195.5 |  |
| Refrigeration | 175.6 |  |  | 178.1 |  |
|  | $ | 834.8 |  |  | $ | 793.4 |  |
| Segment profit (loss) (1) |  |  |  |
| Residential Heating & Cooling | $ | 51.3 |  |  | $ | 42.5 |  |
| Commercial Heating & Cooling | 19.5 |  |  | 19.1 |  |
| Refrigeration | 11.2 |  |  | 14.1 |  |
| Corporate and other | (11.2 | ) |  | (11.0 | ) |
| Total segment profit | 70.8 |  |  | 64.7 |  |
| Reconciliation to Operating income: |  |  |  |
| One time inventory write down | 0.1 |  |  | — |  |
| Loss on assets held for sale | 10.3 |  |  | — |  |
| Items in Losses (Gains) and other expenses, net that are excluded from segment profit (loss) (1) | 6.5 |  |  | 3.8 |  |
| Restructuring charges | 0.9 |  |  | 0.1 |  |
| Operating income | $ | 53.0 |  |  | $ | 60.8 |  |

[0001069202-18-000009:notes:161]
[same as prior period, unchanged from 0001069202-17-000013:notes:156]

[0001069202-18-000009:notes:162]
[same as prior period, unchanged from 0001069202-17-000013:notes:158]

[0001069202-18-000009:notes:163]
[same as prior period, unchanged from 0001069202-17-000013:notes:159]

[0001069202-18-000009:notes:164]
| ◦ | Special legal contingency charges, |

[0001069202-18-000009:notes:165]
| ◦ | Asbestos-related litigation, |

[0001069202-18-000009:notes:166]
[same as prior period, unchanged from 0001069202-17-000013:notes:162]

[0001069202-18-000009:notes:167]
[same as prior period, unchanged from 0001069202-17-000013:notes:163]

[0001069202-18-000009:notes:168]
[same as prior period, unchanged from 0001069202-17-000013:notes:164]

[0001069202-18-000009:notes:169]
| ◦ | Other items, net, |

[0001069202-18-000009:notes:170]
| • | One time inventory write down, |

[0001069202-18-000009:notes:171]
| • | Loss on assets held for sale; and, |

[0001069202-18-000009:notes:172]
| • | Restructuring charges |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-18-000009:notes:173]
[same as prior period, unchanged from 0001069202-17-000013:notes:167]

[0001069202-18-000009:notes:174]
We record restructuring charges associated with management-approved restructuring plans when we reorganize or remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 16.

[0001069202-18-000009:notes:175]
Restructuring Activities in 2018

[0001069202-18-000009:notes:176]
[same as prior period, unchanged from 0001069202-17-000013:notes:170]

[0001069202-18-000009:notes:177]
|  | Charges Incurred in 2018 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 0.1 |  |  | $ | 11.4 |  |  | $ | 11.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 3.2 |  |  | 3.2 |  |
| Lease termination | 0.7 |  |  | 0.9 |  |  | 0.9 |  |
| Other | 0.1 |  |  | 4.2 |  |  | 5.5 |  |
| Total restructuring charges | $ | 0.9 |  |  | $ | 19.7 |  |  | $ | 21.0 |  |

[0001069202-18-000009:notes:178]
[same as prior period, unchanged from 0001069202-17-000013:notes:172]

[0001069202-18-000009:notes:179]
|  | Charges Incurred in 2018 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.1 |  |  | $ | 1.5 |  |  | $ | 2.8 |  |
| Commercial Heating & Cooling | 0.7 |  |  | 2.7 |  |  | 2.7 |  |
| Refrigeration | 0.1 |  |  | 13.2 |  |  | 13.2 |  |
| Corporate & Other | — |  |  | 2.3 |  |  | 2.3 |  |
| Total restructuring charges | $ | 0.9 |  |  | $ | 19.7 |  |  | $ | 21.0 |  |

[0001069202-18-000009:notes:180]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below details the activity in 2018 within the restructuring accruals (in millions):

[0001069202-18-000009:notes:181]
|  | Balance as ofDecember 31, 2017 |  | Included inEarnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of March 31,2018 |
| Severance and related expense | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | (0.2 | ) |  | $ | — |  |  | $ | 0.1 |  |
| Asset write-offs and accelerated depreciation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | 0.7 |  |  | — |  |  | (0.1 | ) |  | 0.6 |  |
| Other | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Total restructuring accruals | $ | 0.2 |  |  | $ | 0.9 |  |  | $ | (0.3 | ) |  | $ | (0.1 | ) |  | $ | 0.7 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-18-000009:notes:182]
Revenue Recognition:

[0001069202-18-000009:notes:183]
On January 1, 2018, we adopted the new accounting standard Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers and all the related amendments (“the new revenue standard”) and applied it to all contracts using the modified retrospective method.  We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings.  The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.  We expect the impact of the adoption of the new standard to be immaterial to our net income on an ongoing basis.

[0001069202-18-000009:notes:184]
The cumulative effect of the changes made to our consolidated January 1, 2018 balance sheet for the adoption of the new revenue standard was as follows (in millions):

[0001069202-18-000009:notes:185]
| BALANCE SHEET | Balance at December 31, 2017 |  | Adjustments Due to ASC 606 |  | Balance at January 1, 2018 |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 506.5 |  |  | $ | 8.3 |  |  | $ | 514.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 348.6 |  |  | 9.3 |  |  | 357.9 |  |
| Retained earnings | 1,575.9 |  |  | (1.0 | ) |  | 1,574.9 |  |

[0001069202-18-000009:notes:186]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption on our Consolidated Balance Sheet and Consolidated Statement of Operations was as follows (in millions):

[0001069202-18-000009:notes:187]
|  | March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 528.5 |  |  | $ | 521.8 |  |  | $ | 6.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 405.6 |  |  | 397.3 |  |  | 8.3 |  |
| Retained earnings | 1,609.6 |  |  | 1,611.2 |  |  | (1.6 | ) |
|  | For the Three Months Ended March 31, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 834.8 |  |  | $ | 834.9 |  |  | $ | (0.1 | ) |
| Net income | 37.9 |  |  | 37.9 |  |  | — |  |

[0001069202-18-000009:notes:188]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue.  See Note 16 for additional description of our reportable business segments and the products and services being sold in each segment.

[0001069202-18-000009:notes:189]
|  | For the Three Months Ended March 31, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 453.7 |  |  | $ | 179.1 |  |  | $ | 109.8 |  |  | $ | 742.6 |  |
| Europe | — |  |  | 26.4 |  |  | 26.8 |  |  | 53.2 |  |
| Asia Pacific | — |  |  | — |  |  | 39.0 |  |  | 39.0 |  |
| Total | $ | 453.7 |  |  | $ | 205.5 |  |  | $ | 175.6 |  |  | $ | 834.8 |  |

[0001069202-18-000009:notes:190]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.

[0001069202-18-000009:notes:191]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  See Note 7 for more information on product warranties.

[0001069202-18-000009:notes:192]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment for the three months ended March 31, 2018, direct sales represent approximately $339.5 million of revenues and sales to independent distributors represent approximately $114.2 million of revenues.  Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-18-000009:notes:193]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, equipment sales represent approximately $177.9 million of revenues while $27.6 million of our revenue is generated from our service business.

[0001069202-18-000009:notes:194]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $173.6 million and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

[0001069202-18-000009:notes:195]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001069202-18-000009:notes:196]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001069202-18-000009:notes:197]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods are transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheet.

[0001069202-18-000009:notes:198]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accounts payable in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheet.

[0001069202-18-000009:notes:199]
For the three months ended March, 31, 2018, we recognized revenue of $1.6 million related to our contract liabilities at January 1, 2018.   Impairment losses recognized in our receivables and contract assets were de minimis in the first quarter of 2018.


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001069202-18-000009:notes:200]
[same as prior period, unchanged from 0001069202-17-000013:notes:176]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-18-000009:notes:201]
[same as prior period, unchanged from 0001069202-17-000013:notes:177]

[0001069202-18-000009:notes:202]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEuropeCentral AmericaSouth America |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth AmericaCentral America |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-18-000009:notes:203]
[same as prior period, unchanged from 0001069202-17-000013:notes:179]

[0001069202-18-000009:notes:204]
[same as prior period, unchanged from 0001069202-17-000013:notes:180]

[0001069202-18-000009:notes:205]
[same as prior period, unchanged from 0001069202-17-000013:notes:181]

[0001069202-18-000009:notes:206]
[same as prior period, unchanged from 0001069202-17-000013:notes:182]

[0001069202-18-000009:notes:207]
[same as prior period, unchanged from 0001069202-17-000013:notes:183]

[0001069202-18-000009:notes:208]
[same as prior period, unchanged from 0001069202-17-000013:notes:184]

[0001069202-18-000009:notes:209]
| • | Restructuring charges. |

[0001069202-18-000009:notes:210]
[same as prior period, unchanged from 0001069202-17-000013:notes:185]

[0001069202-18-000009:notes:211]
Except for the seasonal increase in total assets across all reportable segments, there have not been any material changes in the composition of total assets by segment since December 31, 2017; however, during the quarter we have reclassified assets and liabilities related to our Australia, New Zealand and Asia businesses as Assets held for sale in our Consolidated Balance Sheet. Refer to Note 14 for details regarding assets held for sale.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-18-000009:notes:212]
[same as prior period, unchanged from 0001069202-17-000013:notes:187]

[0001069202-18-000009:notes:213]
Our Board of Directors has authorized a total of $2.5 billion  to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in  March 2018. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date. As of March 31, 2018, $746 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-18-000009:notes:214]
On February 8, 2018, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “ASR Agreement”) with MUFG Securities EMEA plc ("MUFG"), to effect an accelerated stock buyback of our common stock. Under the ASR Agreement, on February 8, 2018, we paid MUFG an initial purchase price of $150 million, and MUFG delivered to us common stock, representing approximately 85% of the shares expected to be purchased under the ASR Agreement. The ASR was completed in April of 2018 and MUFG delivered additional shares for a total of 0.7 million shares of common stock repurchased as part of this ASR Agreement.

[0001069202-18-000009:notes:215]
We also repurchased 0.1 million shares for $18.1 million during the three months ended March 31, 2018 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.


## us-gaap:SubsequentEventsTextBlock

[0001069202-18-000009:notes:216]
Subsequent Event:

[0001069202-18-000009:notes:217]
During the second quarter of 2018, we obtained board approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale is subject to Brazilian antitrust approval and is expected to close later this year.  We expect to take a non-cash charge of approximately $30 million during the second quarter of 2018 related to the sale of this business.
