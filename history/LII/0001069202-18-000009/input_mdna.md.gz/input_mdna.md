# LII MD&A — 0001069202-18-000009


## mdna

[0001069202-18-000009:mdna:1]
[same as prior period, unchanged from 0001069202-17-000013:mdna:1]

[0001069202-18-000009:mdna:2]
[same as prior period, unchanged from 0001069202-17-000013:mdna:2]

[0001069202-18-000009:mdna:3]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For  additional information regarding our reportable segments, see Note 16 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000009:mdna:4]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls.  For convenience, throughout this Management’s Discussion and Analysis of Financial Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.

[0001069202-18-000009:mdna:5]
[same as prior period, unchanged from 0001069202-17-000013:mdna:5]

[0001069202-18-000009:mdna:6]
[same as prior period, unchanged from 0001069202-17-000013:mdna:6]

[0001069202-18-000009:mdna:7]
[same as prior period, unchanged from 0001069202-17-000013:mdna:7]

[0001069202-18-000009:mdna:8]
In the first quarter of 2018, the Residential Heating & Cooling segment led our overall operational performance in the first quarter of 2018 with a 8% increase in net sales and had $9 million in increased segment profit compared to the first quarter of 2017.  This segment's profits were up largely due to higher volumes and favorable price and mix.  Our Commercial Heating &

[0001069202-18-000009:mdna:9]
Cooling segment had a 5% increase in net sales and relatively flat segment profit compared to the first quarter of 2017.  The primary growth driver for this segment was volume gains.  Sales in our Refrigeration segment decreased by 1% and segment profit was down $3 million compared to the the first quarter of 2017 due primarily to lower volumes, unfavorable mix, and factory inefficiencies.

[0001069202-18-000009:mdna:10]
[same as prior period, unchanged from 0001069202-17-000013:mdna:9]

[0001069202-18-000009:mdna:11]
| • | Net sales increased $41 million, or 5%, to $835 million in the the first quarter of 2018 compared to the the first quarter of 2017. |

[0001069202-18-000009:mdna:12]
| • | Operating income in the the first quarter of 2018 decreased $8 million to $53 million. |

[0001069202-18-000009:mdna:13]
| • | Net income for the the first quarter of 2018 decreased $6 million to $38 million, including the $10 million loss on assets held for sale in the the first quarter of 2018 partially offset by the benefit of $4 million of discrete tax benefits related to excess tax benefits from share-based compensation. |

[0001069202-18-000009:mdna:14]
| • | Diluted earnings per share from continuing operations were $0.90 per share in the the first quarter of 2018 compared to $1.00 per share in the the first quarter of 2017. |

[0001069202-18-000009:mdna:15]
| • | During the three months ended March 31, 2018, we returned $21 million to shareholders through dividend payments and entered into an agreement to repurchase $150 million of common stock that was completed in April 2018. |

[0001069202-18-000009:mdna:16]
First Quarter of 2018 Compared to First Quarter of 2017 - Consolidated Results

[0001069202-18-000009:mdna:17]
[same as prior period, unchanged from 0001069202-17-000013:mdna:16]

[0001069202-18-000009:mdna:18]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 834.8 |  |  | $ | 793.4 |  |  | 5.2 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 611.6 |  |  | 582.5 |  |  | (5.0 | ) |  | 73.3 |  |  | 73.4 |  |
| Gross profit | 223.2 |  |  | 210.9 |  |  | 5.8 |  |  | 26.7 |  |  | 26.6 |  |
| Selling, general and administrative expenses | 155.2 |  |  | 152.4 |  |  | (1.8 | ) |  | 18.6 |  |  | 19.2 |  |
| Losses and other expenses, net | 7.3 |  |  | 3.1 |  |  | (135.5 | ) |  | 0.9 |  |  | 0.4 |  |
| Restructuring charges | 0.9 |  |  | 0.1 |  |  | (800.0 | ) |  | 0.1 |  |  | — |  |
| Loss on assets held for sale | 10.3 |  |  | — |  |  | N/A |  | 1.2 |  |  | — |  |
| Income from equity method investments | (3.5 | ) |  | (5.5 | ) |  | (36.4 | ) |  | (0.4 | ) |  | (0.7 | ) |
| Operating income | $ | 53.0 |  |  | $ | 60.8 |  |  | (12.8 | )% |  | 6.3 | % |  | 7.7 | % |

[0001069202-18-000009:mdna:19]
[same as prior period, unchanged from 0001069202-17-000013:mdna:18]

[0001069202-18-000009:mdna:20]
Net sales increased 5% in the the first quarter of 2018 compared to the the first quarter of 2017, primarily from 3% higher sales volumes, 1% from favorable price and 1% from favorable foreign currency exchange rates.  The Residential Heating & Cooling segment delivered higher volume from increased replacement equipment and increased parts and supplies sales.  The Commercial Heating & Cooling segment delivered higher volume from our North American equipment business.

[0001069202-18-000009:mdna:21]
[same as prior period, unchanged from 0001069202-17-000013:mdna:20]

[0001069202-18-000009:mdna:22]
Gross profit margin in the the first quarter of 2018 increased to 26.7% compared to 26.6% in the the first quarter of 2017.  We saw positive margin increases of 100 basis points ("bps") from favorable price, 100 bps from lower material costs, 40 bps from total other product costs, 20 bps from product warranties, and 10 bps from favorable foreign currency exchange rates. Partially offsetting these increases were decreases of 120 bps from higher freight and distribution costs, 110 bps from higher commodity prices, and 30 bps from other costs.

[0001069202-18-000009:mdna:23]
[same as prior period, unchanged from 0001069202-17-000013:mdna:22]

[0001069202-18-000009:mdna:24]
Selling, general and administrative expenses, or SG&A, was $155 million in the the first quarter of 2018 compared to $152 million in the the first quarter of 2017, and as a percentage of net sales decreased 60 bps to 18.6%.  SG&A increased primarily due to wage inflation.

[0001069202-18-000009:mdna:25]
[same as prior period, unchanged from 0001069202-17-000013:mdna:24]

[0001069202-18-000009:mdna:26]
Losses and other expenses, net for the the first quarter of 2018 and 2017 included the following (in millions):

[0001069202-18-000009:mdna:27]
|  | For the Three Months Ended March 31, |
|  | 2018 |  | 2017 |
| Realized gains on settled future contracts | $ | (0.5 | ) |  | $ | (0.4 | ) |
| Foreign currency exchange losses (gains) | 1.3 |  |  | (0.2 | ) |
| Loss on disposal of fixed assets | — |  |  | (0.1 | ) |
| Net change in unrealized losses on unsettled futures contracts | 1.1 |  |  | 0.7 |  |
| Special legal contingency charges | 0.2 |  |  | 0.9 |  |
| Asbestos-related litigation | 2.1 |  |  | 1.7 |  |
| Environmental liabilities | 0.3 |  |  | 0.5 |  |
| Divestiture costs | 2.5 |  |  | — |  |
| Other items, net | 0.3 |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 7.3 |  |  | $ | 3.1 |  |

[0001069202-18-000009:mdna:28]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.

[0001069202-18-000009:mdna:29]
[same as prior period, unchanged from 0001069202-17-000013:mdna:28]

[0001069202-18-000009:mdna:30]
Restructuring charges were $1 million in the the first quarter of 2018. The charges in 2018 were primarily for projects to realign resources and enhance distribution capabilities.  For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000009:mdna:31]
[same as prior period, unchanged from 0001069202-17-000013:mdna:30]

[0001069202-18-000009:mdna:32]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $4 million in the the first quarter of 2018 was down $2 million when compared to the the first quarter of 2017.

[0001069202-18-000009:mdna:33]
[same as prior period, unchanged from 0001069202-17-000013:mdna:32]

[0001069202-18-000009:mdna:34]
Interest expense, net of $8 million in the the first quarter of 2018 was up from $7 million in the first quarter of 2017 due to an increase in our average net borrowings and increasing interest rates.

[0001069202-18-000009:mdna:35]
[same as prior period, unchanged from 0001069202-17-000013:mdna:34]

[0001069202-18-000009:mdna:36]
We expect our annual effective tax rate to be between 22% and 24%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001069202-18-000009:mdna:37]
Our effective tax rate was 13.9% for the first quarter of 2018, after the impact of excess tax benefits, compared to 18.5% for the first quarter of 2017, after the impact of excess tax benefits.  The rate for the first quarter of 2018 is lower as compared to the first quarter of 2017 primarily due to the reduced U.S. federal corporate tax rate from enactment of the Tax Cuts and Jobs Act on December 22, 2017.

[0001069202-18-000009:mdna:38]
First Quarter of 2018 Compared to First Quarter of 2017 - Results by Segment

[0001069202-18-000009:mdna:39]
[same as prior period, unchanged from 0001069202-17-000013:mdna:38]

[0001069202-18-000009:mdna:40]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the the first quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000009:mdna:41]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 453.7 |  |  | $ | 419.8 |  |  | $ | 33.9 |  |  | 8.1 | % |
| Profit | $ | 51.3 |  |  | $ | 42.5 |  |  | $ | 8.8 |  |  | 20.7 | % |
| % of net sales | 11.3 | % |  | 10.1 | % |  |  |  |  |

[0001069202-18-000009:mdna:42]
Net sales increased by 8% in the the first quarter of 2018 compared to the the first quarter of 2017.  Sales volume increased 5%, price and mix combined increased sales by 3%.

[0001069202-18-000009:mdna:43]
Segment profit in the the first quarter of 2018 increased $9 million compared to the the first quarter of 2017 due to $13 million from favorable price and mix, $6 million in higher sales volume, $5 million from sourcing and engineering-led cost reductions, $4 million from lower other product costs, and $1 million from improved factory productivity.  Partially offsetting these increases was $9 million from higher freight and distribution costs, $6 million from higher commodity costs, $3 million from higher SG&A expense, and $2 million lower income from equity method investments.

[0001069202-18-000009:mdna:44]
[same as prior period, unchanged from 0001069202-17-000013:mdna:43]

[0001069202-18-000009:mdna:45]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000009:mdna:46]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 205.5 |  |  | $ | 195.5 |  |  | $ | 10.0 |  |  | 5.1 | % |
| Profit | $ | 19.5 |  |  | $ | 19.1 |  |  | $ | 0.4 |  |  | 2.1 | % |
| % of net sales | 9.5 | % |  | 9.8 | % |  |  |  |  |

[0001069202-18-000009:mdna:47]
Net sales increased by 5% in the first quarter of 2018 compared to the first quarter of 2017.  Sales volume increased by 3%, favorable foreign currency exchange rates contributed 2% and price and mix combined were flat.

[0001069202-18-000009:mdna:48]
Segment profit in the first quarter of 2018 was flat compared to the first quarter of 2017 due to $2 million from favorable price, $2 million from lower SG&A, $1 million from higher sales volume, $1 million from sourcing and engineering-led cost reductions, and $1 million from lower other product costs.  Offsetting these increases was $4 million from unfavorable mix, $2 million from higher commodity costs, and $1 million from higher freight and distribution costs.

[0001069202-18-000009:mdna:49]
[same as prior period, unchanged from 0001069202-17-000013:mdna:48]

[0001069202-18-000009:mdna:50]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000009:mdna:51]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 175.6 |  |  | $ | 178.1 |  |  | $ | (2.5 | ) |  | (1.4 | )% |
| Profit | $ | 11.2 |  |  | $ | 14.1 |  |  | $ | (2.9 | ) |  | (20.6 | )% |
| % of net sales | 6.4 | % |  | 7.9 | % |  |  |  |  |

[0001069202-18-000009:mdna:52]
Net sales decreased 1% in the first quarter of 2018 compared to the first quarter of 2017.  Sales volume was lower by 4%, partially offset by 3% favorable foreign currency exchange rates.

[0001069202-18-000009:mdna:53]
Segment profit for the first quarter of 2018 decreased $3 million compared to the first quarter of 2017. The decrease was driven by $3 million of factory inefficiencies, $2 million from lower sales volume, $1 million from unfavorable mix, $1 million from higher commodity costs, and $1 million from lower equity method investments.  Partially offsetting these decreases was $2 million from sourcing and engineering-led cost reductions, $1 million of favorable price, $1 million of lower other product costs, and $1 million of lower SG&A.

[0001069202-18-000009:mdna:54]
[same as prior period, unchanged from 0001069202-17-000013:mdna:53]

[0001069202-18-000009:mdna:55]
Corporate and other expenses in the first quarter of 2018 were flat compared to the first quarter of 2017.

[0001069202-18-000009:mdna:56]
[same as prior period, unchanged from 0001069202-17-000013:mdna:95]

[0001069202-18-000009:mdna:57]
[same as prior period, unchanged from 0001069202-17-000013:mdna:96]

[0001069202-18-000009:mdna:58]
[same as prior period, unchanged from 0001069202-17-000013:mdna:97]

[0001069202-18-000009:mdna:59]
The following table summarizes our cash flow activity for the three months ended March 31, 2018 and 2017 (in millions):

[0001069202-18-000009:mdna:60]
|  | For the Three Months Ended March 31, |
|  | 2018 |  | 2017 |
| Net cash used in operating activities | $ | (83.5 | ) |  | $ | (107.6 | ) |
| Net cash used in investing activities | (22.6 | ) |  | (24.8 | ) |
| Net cash provided by financing activities | 96.0 |  |  | 128.4 |  |

[0001069202-18-000009:mdna:61]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first three months of 2018 and 2017 reflects the seasonal increase in working capital requirements. The decrease in cash used in operating activities in the first three months of 2018 as compared to 2017 was mainly due to the timing of working capital payments.

[0001069202-18-000009:mdna:62]
Net Cash Used in Investing Activities - Capital expenditures were $23 million and $25 million in the first three months of 2018 and 2017, respectively.  Capital expenditures in 2018 were primarily related to expansion of our manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.

[0001069202-18-000009:mdna:63]
Net Cash Provided by Financing Activities - Net cash provided by financing activities decreased in the first three months of 2018 to $96 million as compared to $128 million in the first three months of 2017.  Cash continues to be provided by an increase in net borrowings and we continue to make share repurchases and dividend payments.  During the first quarter of 2018, we entered into a $150 million accelerated share repurchase agreement that was settled in April 2018.  For additional information on share repurchases, refer to Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000009:mdna:64]
[same as prior period, unchanged from 0001069202-17-000013:mdna:103]

[0001069202-18-000009:mdna:65]
The following table details our lines of credit and financing arrangements as of March 31, 2018 (in millions):

[0001069202-18-000009:mdna:66]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 0.9 |  |
| Total short-term debt | $ | 0.9 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 0.5 |  |
| Domestic credit facility (1) | 30.0 |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.9 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | 225.0 |  |
| Capital lease obligations | 11.9 |  |
| Domestic credit facility (1) | 675.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (4.1 | ) |
| Total long-term debt | 1,258.3 |  |
| Total debt | $ | 1,289.1 |  |

[0001069202-18-000009:mdna:67]
(1) The available future borrowings on our domestic credit facility are $154.1 million after being reduced by the outstanding borrowings and $2.9 million in outstanding standby letters of credit.  We also had $32.1 million in outstanding standby letters of credit outside of the domestic credit facility as of March 31, 2018.

[0001069202-18-000009:mdna:68]
(2) The maximum securitization amount ranges from $225.0 million to $380.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.

[0001069202-18-000009:mdna:69]
[same as prior period, unchanged from 0001069202-17-000013:mdna:108]

[0001069202-18-000009:mdna:70]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 108.6% at March 31, 2018 from 95.2% at December 31, 2017.

[0001069202-18-000009:mdna:71]
As of March 31, 2018, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-18-000009:mdna:72]
[same as prior period, unchanged from 0001069202-17-000013:mdna:111]

[0001069202-18-000009:mdna:73]
We believe our cash and cash equivalents of $57 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, potential dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $57 million as of March 31, 2018 was $40.7 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States. An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-18-000009:mdna:74]
Our expected capital expenditures for 2018 are $100 million.  We also continue to increase shareholder value through our share repurchase programs and dividend payments, with the completion of a $150 million accelerated share repurchase program initiated in the first three months of 2018 and the declaration of $21 million of cash dividends in the first three months of 2018.

[0001069202-18-000009:mdna:75]
[same as prior period, unchanged from 0001069202-17-000013:mdna:114]

[0001069202-18-000009:mdna:76]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Our operating lease commitments have not materially changed since December 31, 2017.

[0001069202-18-000009:mdna:77]
Commitments, Contingencies and Guarantees

[0001069202-18-000009:mdna:78]
For information regarding our commitments, contingencies and guarantees, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000009:mdna:79]
[same as prior period, unchanged from 0001069202-17-000013:mdna:118]

[0001069202-18-000009:mdna:80]
See Note 1 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
