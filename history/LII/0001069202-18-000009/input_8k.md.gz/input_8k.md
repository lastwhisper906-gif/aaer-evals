# LII 8-K — 0001193125-18-125935 filed 2018-04-23

## item codes, every 8-K on or before 2018-04-23

- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2018-04-23

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-125935:8k_2_02:1]
EX-99.1
2
d572143dex991.htm
EX-99.1

[0001193125-18-125935:8k_2_02:2]
EX-99.1

[0001193125-18-125935:8k_2_02:3]
Exhibit 99.1

[0001193125-18-125935:8k_2_02:4]
Lennox International Reports Record First-Quarter Revenue and Profit

[0001193125-18-125935:8k_2_02:5]
|  | • |  | GAAP revenue up 5%; adjusted revenue up 6% excluding non-core Refrigeration businesses being divested as previously announced |

[0001193125-18-125935:8k_2_02:6]
|  | • |  | GAAP EPS from continuing operations of $0.90, including $0.30 of charges related to non-core businesses in Australia and Asia being divested |

[0001193125-18-125935:8k_2_02:7]
|  | • |  | Adjusted EPS from continuing operations up 33% to first-quarter record $1.13 |

[0001193125-18-125935:8k_2_02:8]
|  | • |  | Updating 2018 GAAP and adjusted revenue growth guidance from 3-7% with minimal foreign exchange impact to 4-8% with 1% positive impact |

[0001193125-18-125935:8k_2_02:9]
|  | • |  | Updating 2018 GAAP EPS from continuing operations guidance from $9.75-$10.35 to $8.79-$9.39, incorporating first-quarter results and expected second-quarter charges associated with the divestiture of South American business |

[0001193125-18-125935:8k_2_02:10]
|  | • |  | Reiterating 2018 adjusted EPS from continuing operations guidance of $9.75-$10.35 |

[0001193125-18-125935:8k_2_02:11]
|  | • |  | $150 million directed to stock repurchases in first quarter of the $350 million announced for 2018 |

[0001193125-18-125935:8k_2_02:12]
DALLAS, April 23, 2018 – Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2018. All comparisons are
to the prior-year period. Adjusted revenue and profit exclude the non-core Refrigeration businesses in Australia, Asia and South America that are in the process of being divested, as previously announced.
These businesses totaled $47 million of revenue and $2 million of profit in the first quarter of 2018.

[0001193125-18-125935:8k_2_02:13]
For the company overall, GAAP revenue
was up 5% to a first-quarter record $835 million. Adjusted revenue was up 6% to a first-quarter record $788 million. At constant currency, both GAAP and adjusted revenue were up 4%.

[0001193125-18-125935:8k_2_02:14]
GAAP operating income was $53 million in the first quarter, including $13 million in pre-tax charges for the
write-down of assets and divestiture costs associated with the Australia and Asia transaction. GAAP earnings per share from continuing operations was $0.90, including $0.30 in charges for the write-down of assets and divestiture costs associated
with the Australia and Asia transaction. On an adjusted basis, total segment profit increased 12% to a first-quarter record $69 million. Total segment margin expanded 50 basis points to a first-quarter record 8.8%. Adjusted EPS from continuing
operations rose 33% to a first-quarter record $1.13.

[0001193125-18-125935:8k_2_02:15]
“Lennox International posted another record first quarter on the strength of our Residential
business, which hit new first-quarter highs for revenue, margin and profit,” said Chairman and CEO Todd Bluedorn. “Residential revenue was up 8% led by growth in replacement business. Residential profit rose 21%, and segment margin
expanded 120 basis points to 11.3%. Our Commercial business set new first-quarter records for revenue and profit. Commercial revenue was up 3% at constant currency, led by growth in regional and local replacement business, and profit rose 2%.
Segment margin of 9.5% was off 30 basis points from the record first-quarter level a year ago.

[0001193125-18-125935:8k_2_02:16]
In Refrigeration, revenue was down 5% at constant currency, segment margin was down 100 basis points to 7.4%, and profit declined 14%. In North America, refrigeration systems revenue was
relatively flat while display case revenue was down from a year ago. Europe saw strong mid-teens growth in the quarter.

[0001193125-18-125935:8k_2_02:17]
“Overall for the company, the first quarter was a record start to the year. As we enter our largest seasonal period, we continue to expect another record
year with strong growth and profitability. With a strong balance sheet, and as we close on the sale of our non-core Refrigeration properties, the company will remain focused on driving shareholder value with
continued investments in the business, growing the dividend, and repurchasing company stock.”

[0001193125-18-125935:8k_2_02:18]
FINANCIAL HIGHLIGHTS

[0001193125-18-125935:8k_2_02:19]
Revenue: On a GAAP basis, revenue was a first-quarter record $835 million, up 5%. Foreign exchange was a 1% benefit to revenue growth. On an
adjusted basis, revenue was a first-quarter record $788 million, up 6%. Foreign exchange was a 2% benefit to adjusted revenue growth. Volume and price were up, and mix was neutral.

[0001193125-18-125935:8k_2_02:20]
Gross Profit: On a GAAP basis, gross profit was $223 million, up 6%. Gross margin was 26.7%, up 10 basis points. On an adjusted basis, gross
profit was $210 million, up 7%. Adjusted gross margin was 26.6%, up 30 basis points. GAAP and adjusted gross profit were positively impacted by higher volume, favorable price, sourcing and engineering-led
cost reductions, favorable foreign exchange, and lower warranty and other product costs. Partial offsets included unfavorable mix, higher commodity and freight costs, lower factory absorption, and distribution investments.

[0001193125-18-125935:8k_2_02:21]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the first quarter was $37.9 million, or $0.90 per share,
compared to $43.5 million, or $1.00 per share, in the prior-year quarter.

[0001193125-18-125935:8k_2_02:22]
Adjusted income from continuing operations in the first quarter was
$47.3 million, or $1.13 per share, compared to $36.8 million, or $0.85 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the first quarter of 2018 excludes net
after-tax charges of $9.4 million: a $10.3 million asset write-down and a charge of $1.9 million for divestiture costs associated with the Australia and Asia transaction, $1.5 million for
asbestos-related litigation, $1.3 million for various other items, net, a benefit of $4.3 million for excess tax benefits from share-based compensation, and a profit of $1.3 million for non-core
business results.

[0001193125-18-125935:8k_2_02:23]
Cash from Operations, Free Cash Flow and Total Debt: Net cash used in operations in the first quarter was
$83 million compared to $108 million in the prior-year quarter. Capital expenditures were $23 million compared to $25 million in the prior-year quarter. Free cash flow was approximately ($106) million compared to approximately
($132) million in the first quarter a year ago. Total debt at the end of the first quarter was $1.289 billion. Total cash and cash equivalents were $57 million at the end of March. In the first quarter, the company paid approximately
$21 million in dividends and $150 million for stock repurchases.

[0001193125-18-125935:8k_2_02:24]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-18-125935:8k_2_02:25]
Residential Heating & Cooling

[0001193125-18-125935:8k_2_02:26]
Revenue in the
Residential Heating & Cooling business segment rose 8% to a first-quarter record $454 million. Foreign exchange was neutral on a revenue basis. Segment profit was a first-quarter record $51 million, up 21%. Segment margin was a
first-quarter record 11.3%, up 120 basis points. Results were positively impacted by higher volume and factory productivity, favorable price and mix, and sourcing and engineering-led cost reductions. Partial
offsets included higher commodity and freight costs, higher SG&A, and distribution investments.

[0001193125-18-125935:8k_2_02:27]
Commercial Heating & Cooling

[0001193125-18-125935:8k_2_02:28]
Revenue in the Commercial Heating & Cooling business segment was a first-quarter record $206 million, up 5%. At constant currency, revenue was up
3%. Segment profit was a first-quarter record $20 million, up 2%. Segment margin was 9.5%, down 30 basis points from the first-quarter record a year ago. Results were positively impacted by higher volume, higher price, sourcing and engineering-led cost reductions, lower other product costs, and lower SG&A. Partial offsets included unfavorable mix, higher commodity and freight costs, and distribution investments.

[0001193125-18-125935:8k_2_02:29]
Refrigeration

[0001193125-18-125935:8k_2_02:30]
On an adjusted basis for the Refrigeration
business segment, revenue was $129 million, down 2%. At constant currency, revenue was down 5%. Segment profit was down 14% to $10 million. Segment margin was down 100 basis points to 7.4%. Results were negatively impacted by lower volume
and factory absorption, and higher commodity costs. Partial offsets included higher price, sourcing and engineering-led cost reductions, lower other products costs, and lower SG&A.

[0001193125-18-125935:8k_2_02:31]
FULL-YEAR OUTLOOK

[0001193125-18-125935:8k_2_02:32]
|  | • |  | Updating 2018 guidance for GAAP and adjusted revenue growth from 3-7% with a minimal impact from foreign exchange to 4-8% with a positive 1% impact from foreign exchange. |

[0001193125-18-125935:8k_2_02:33]
|  | • |  | Updating 2018 guidance for GAAP EPS from continuing operations from $9.75-$10.35 to $8.79-$9.39, incorporating first-quarter results that included $0.30 in charges for the write-down of assets and divestiture costs associated with the Australia and Asia transaction, as well as expected second-quarter non-cash charges totaling approximately $0.73, or approximately $30 million, associated with the divestiture of the South American business. In the second quarter, the company obtained board approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South American business, subject to Brazilian anti-trust approval, and expects the transaction to close later this year. |

[0001193125-18-125935:8k_2_02:34]
|  | • |  | Reiterating 2018 adjusted EPS from continuing operations guidance of $9.75-$10.35. |

[0001193125-18-125935:8k_2_02:35]
|  | • |  | Reiterating corporate expense guidance of approximately $85 million. |

[0001193125-18-125935:8k_2_02:36]
|  | • |  | Reiterating guidance for an effective tax rate of 22-24% on an adjusted basis for the full year. |

[0001193125-18-125935:8k_2_02:37]
|  | • |  | Reiterating capital expenditures of approximately $100 million. |

[0001193125-18-125935:8k_2_02:38]
|  | • |  | Reiterating guidance for $350 million of stock repurchases in 2018 and a weighted average diluted share count of 41-42 million shares on a full-year basis. |

[0001193125-18-125935:8k_2_02:39]
CONFERENCE CALL INFORMATION

[0001193125-18-125935:8k_2_02:40]
A
conference call to discuss the company’s first-quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at
612-332-0630 at least 10 minutes prior to the scheduled start time and use reservation number 447169. The conference call also will be webcast on Lennox
International’s web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on April 23 through May 7, 2018 by dialing
800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 447169. The
call also will be archived on the company’s website.

[0001193125-18-125935:8k_2_02:41]
About Lennox International

[0001193125-18-125935:8k_2_02:42]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York
Stock Exchange and traded under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-18-125935:8k_2_02:43]
FORWARD-LOOKING STATEMENTS

[0001193125-18-125935:8k_2_02:44]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-125935:8k_2_02:45]
Consolidated Statements of Operations

[0001193125-18-125935:8k_2_02:46]
(Unaudited)

[0001193125-18-125935:8k_2_02:47]
| (Amounts in millions, except per share data) |  | For the Three Months EndedMarch 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Net sales |  | $ | 834.8 |  |  | $ | 793.4 |  |
| Cost of goods sold |  |  | 611.6 |  |  |  | 582.5 |  |
| Gross profit |  |  | 223.2 |  |  |  | 210.9 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 155.2 |  |  |  | 152.4 |  |
| Losses and other expenses, net |  |  | 7.3 |  |  |  | 3.1 |  |
| Restructuring charges |  |  | 0.9 |  |  |  | 0.1 |  |
| Loss on assets held for sale |  |  | 10.3 |  |  |  | — |  |
| Income from equity method investments |  |  | (3.5 | ) |  |  | (5.5 | ) |
| Operating income |  |  | 53.0 |  |  |  | 60.8 |  |
| Interest expense, net |  |  | 8.4 |  |  |  | 7.4 |  |
| Other expense, net |  |  | 0.6 |  |  |  | — |  |
| Income from continuing operations before income taxes |  |  | 44.0 |  |  |  | 53.4 |  |
| Provision for income taxes |  |  | 6.1 |  |  |  | 9.9 |  |
| Income from continuing operations |  |  | 37.9 |  |  |  | 43.5 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | — |  |  |  | — |  |
| Benefit from income taxes |  |  | — |  |  |  | — |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 37.9 |  |  | $ | 43.5 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.91 |  |  | $ | 1.02 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 0.91 |  |  | $ | 1.02 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.90 |  |  | $ | 1.00 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 0.90 |  |  | $ | 1.00 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 41.5 |  |  |  | 42.8 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 42.1 |  |  |  | 43.5 |  |
| Cash dividends declared per share |  | $ | 0.51 |  |  | $ | 0.43 |  |

[0001193125-18-125935:8k_2_02:48]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-125935:8k_2_02:49]
Adjusted Segment Net Sales and Profit (Loss)

[0001193125-18-125935:8k_2_02:50]
(Unaudited)

[0001193125-18-125935:8k_2_02:51]
| (Amounts in millions) |  | For the Three Months EndedMarch 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Adjusted Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 453.7 |  |  | $ | 419.8 |  |
| Commercial Heating & Cooling |  |  | 205.5 |  |  |  | 195.5 |  |
| Refrigeration (1) |  |  | 128.6 |  |  |  | 131.0 |  |
|  |  | $ | 787.8 |  |  | $ | 746.3 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 51.3 |  |  | $ | 42.5 |  |
| Commercial Heating & Cooling |  |  | 19.5 |  |  |  | 19.1 |  |
| Refrigeration (1) |  |  | 9.5 |  |  |  | 11.0 |  |
| Corporate and other |  |  | (11.2 | ) |  |  | (11.0 | ) |
| Total adjusted segment profit |  |  | 69.1 |  |  |  | 61.6 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |  |
| One time inventory write down |  |  | 0.1 |  |  |  | — |  |
| Loss on assets held for sale |  |  | 10.3 |  |  |  | — |  |
| Items in Losses (Gains) and other expenses, net that are excluded from segment profit (loss) (2) |  |  | 6.5 |  |  |  | 3.8 |  |
| Restructuring charges |  |  | 0.9 |  |  |  | 0.1 |  |
| Operating income from non-core businesses |  |  | (1.7 | ) |  |  | (3.1 | ) |
| Operating income |  | $ | 53.0 |  |  | $ | 60.8 |  |

[0001193125-18-125935:8k_2_02:52]
| (1) | Excludes the non-core business results related to our business operations in Australia, Asia, and South America for 2018 and 2017. |

[0001193125-18-125935:8k_2_02:53]
| (2) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-18-125935:8k_2_02:54]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-18-125935:8k_2_02:55]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-18-125935:8k_2_02:56]
|  | • |  | Special legal contingency charges, |

[0001193125-18-125935:8k_2_02:57]
|  | • |  | Asbestos-related litigation, |

[0001193125-18-125935:8k_2_02:58]
|  | • |  | Contractor tax payments, |

[0001193125-18-125935:8k_2_02:59]
|  | • |  | Environmental liabilities, |

[0001193125-18-125935:8k_2_02:60]
|  | • |  | Divestiture costs, |

[0001193125-18-125935:8k_2_02:61]
|  | • |  | Other items, net, |

[0001193125-18-125935:8k_2_02:62]
|  | • |  | One time inventory write down, |

[0001193125-18-125935:8k_2_02:63]
|  | • |  | Loss on assets held for sale, |

[0001193125-18-125935:8k_2_02:64]
|  | • |  | Operating income from non-core businesses; and, |

[0001193125-18-125935:8k_2_02:65]
|  | • |  | Restructuring charges. |

[0001193125-18-125935:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-125935:8k_2_02:67]
Consolidated Balance Sheets

[0001193125-18-125935:8k_2_02:68]
| (Amounts in millions, except shares and par values) |  | As of March 31,2018 |  |  | As of December 31,2017 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 57.1 |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net of allowances of $6.0 and $5.9 in 2018 and 2017, respectively |  |  | 528.5 |  |  |  | 506.5 |  |
| Inventories, net |  |  | 561.5 |  |  |  | 484.2 |  |
| Assets held for sale |  |  | 93.3 |  |  |  | — |  |
| Other assets |  |  | 106.4 |  |  |  | 78.4 |  |
| Total current assets |  |  | 1,346.8 |  |  |  | 1,137.3 |  |
| Property, plant and equipment, net of accumulated depreciation of $763.9 and $774.2 in 2018 and 2017, respectively |  |  | 390.1 |  |  |  | 397.8 |  |
| Goodwill |  |  | 190.3 |  |  |  | 200.5 |  |
| Deferred income taxes |  |  | 94.0 |  |  |  | 94.4 |  |
| Other assets, net |  |  | 64.9 |  |  |  | 61.5 |  |
| Total assets |  | $ | 2,086.1 |  |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt |  |  | 29.9 |  |  |  | 32.6 |  |
| Accounts payable |  |  | 405.6 |  |  |  | 348.6 |  |
| Accrued expenses |  |  | 226.0 |  |  |  | 270.3 |  |
| Liabilities held for sale |  |  | 28.7 |  |  |  | — |  |
| Income taxes payable |  |  | 21.7 |  |  |  | 2.1 |  |
| Total current liabilities |  |  | 712.8 |  |  |  | 654.5 |  |
| Long-term debt |  |  | 1,258.3 |  |  |  | 970.5 |  |
| Post-retirement benefits, other than pensions |  |  | 2.5 |  |  |  | 2.6 |  |
| Pensions |  |  | 85.9 |  |  |  | 84.5 |  |
| Other liabilities |  |  | 129.2 |  |  |  | 129.3 |  |
| Total liabilities |  |  | 2,188.7 |  |  |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,036.7 |  |  |  | 1,061.5 |  |
| Retained earnings |  |  | 1,609.6 |  |  |  | 1,575.9 |  |
| Accumulated other comprehensive loss |  |  | (181.3 | ) |  |  | (157.4 | ) |
| Treasury stock, at cost, 45,852,186 shares and 45,361,145 shares as of March 31, 2018 and December 31, 2017, respectively |  |  | (2,568.5 | ) |  |  | (2,430.8 | ) |
| Total stockholders’ equity |  |  | (102.6 | ) |  |  | 50.1 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,086.1 |  |  | $ | 1,891.5 |  |

[0001193125-18-125935:8k_2_02:69]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-125935:8k_2_02:70]
Consolidated Statements of Cash Flows

[0001193125-18-125935:8k_2_02:71]
(Unaudited)

[0001193125-18-125935:8k_2_02:72]
| (Amounts in millions) |  | For the Three Months EndedMarch 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 37.9 |  |  | $ | 43.5 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (3.5 | ) |  |  | (5.5 | ) |
| Loss on assets held for sale |  |  | 10.3 |  |  |  | — |  |
| Restructuring charges, net of cash paid |  |  | 0.6 |  |  |  | — |  |
| Provision for bad debts |  |  | 1.9 |  |  |  | 1.1 |  |
| Unrealized gains on derivative contracts |  |  | (0.1 | ) |  |  | (0.5 | ) |
| Stock-based compensation expense |  |  | 4.8 |  |  |  | 4.9 |  |
| Depreciation and amortization |  |  | 16.6 |  |  |  | 15.7 |  |
| Deferred income taxes |  |  | (2.1 | ) |  |  | (1.1 | ) |
| Pension expense |  |  | 2.1 |  |  |  | 1.9 |  |
| Pension contributions |  |  | (0.7 | ) |  |  | (1.1 | ) |
| Other items, net |  |  | 0.1 |  |  |  | 0.1 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (44.5 | ) |  |  | (40.9 | ) |
| Inventories |  |  | (124.3 | ) |  |  | (101.2 | ) |
| Other current assets |  |  | (0.7 | ) |  |  | (4.3 | ) |
| Accounts payable |  |  | 77.5 |  |  |  | 47.3 |  |
| Accrued expenses |  |  | (35.2 | ) |  |  | (41.7 | ) |
| Income taxes payable and receivable |  |  | (22.3 | ) |  |  | (28.0 | ) |
| Other |  |  | (1.9 | ) |  |  | 2.2 |  |
| Net cash used in operating activities |  |  | (83.5 | ) |  |  | (107.6 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | (22.7 | ) |  |  | (24.9 | ) |
| Net cash used in investing activities |  |  | (22.6 | ) |  |  | (24.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (0.1 | ) |  |  | (0.8 | ) |
| Asset securitization borrowings |  |  | — |  |  |  | 150.0 |  |
| Asset securitization payments |  |  | (51.0 | ) |  |  | — |  |
| Long-term debt payments |  |  | (10.2 | ) |  |  | (0.2 | ) |
| Borrowings from credit facility |  |  | 790.0 |  |  |  | 583.0 |  |
| Payments on credit facility |  |  | (444.1 | ) |  |  | (497.5 | ) |
| Proceeds from employee stock purchases |  |  | 0.8 |  |  |  | 0.7 |  |
| Repurchases of common stock |  |  | (150.0 | ) |  |  | (75.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (18.1 | ) |  |  | (13.3 | ) |
| Cash dividends paid |  |  | (21.3 | ) |  |  | (18.5 | ) |
| Net cash provided by financing activities |  |  | 96.0 |  |  |  | 128.4 |  |
| Increase in cash and cash equivalents |  |  | (10.1 | ) |  |  | (4.0 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (1.0 | ) |  |  | 2.6 |  |
| Cash and cash equivalents, beginning of period |  |  | 68.2 |  |  |  | 50.2 |  |
| Cash and cash equivalents, end of period |  | $ | 57.1 |  |  | $ | 48.8 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 6.0 |  |  | $ | 2.4 |  |
| Income taxes paid (net of refunds) |  | $ | 32.7 |  |  | $ | 36.7 |  |

[0001193125-18-125935:8k_2_02:73]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-125935:8k_2_02:74]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-18-125935:8k_2_02:75]
(Unaudited, in millions, except per share and ratio data)

[0001193125-18-125935:8k_2_02:76]
Use of Non-GAAP Financial Measures

[0001193125-18-125935:8k_2_02:77]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance. In the first quarter of 2018, the Company announced the planned sales of its businesses in Australia, Asia, and South America. The results from operations for these businesses
have been shown in the tables below as “Non-core business results”. The prior period results have been updated to provide period-over-period comparability.

[0001193125-18-125935:8k_2_02:78]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a
Non-GAAP measure

[0001193125-18-125935:8k_2_02:79]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 44.0 |  |  | $ | (6.1 | ) |  | $ | 37.9 |  |  | $ | 53.4 |  |  | $ | (9.9 | ) |  | $ | 43.5 |  |
| Restructuring charges |  |  | 0.9 |  |  |  | (0.3 | ) |  |  | 0.6 |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Loss on assets held for sale |  |  | 10.3 |  |  |  | — |  |  |  | 10.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Special legal contingency charges (a) |  |  | 0.2 |  |  |  | (0.1 | ) |  |  | 0.1 |  |  |  | 0.9 |  |  |  | — |  |  |  | 0.9 |  |
| Asbestos-related litigation (a) |  |  | 2.1 |  |  |  | (0.6 | ) |  |  | 1.5 |  |  |  | 1.7 |  |  |  | (0.6 | ) |  |  | 1.1 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 1.1 |  |  |  | (0.2 | ) |  |  | 0.9 |  |  |  | 0.7 |  |  |  | (0.3 | ) |  |  | 0.4 |  |
| Inventory write down,(b) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Environmental liabilities(a) |  |  | 0.3 |  |  |  | — |  |  |  | 0.3 |  |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.3 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (4.3 | ) |  |  | (4.3 | ) |  |  | — |  |  |  | (7.4 | ) |  |  | (7.4 | ) |
| Other tax items, net(c) |  |  | — |  |  |  | (0.9 | ) |  |  | (0.9 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Divestiture costs (a) |  |  | 2.5 |  |  |  | (0.6 | ) |  |  | 1.9 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other items, net (a) |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-core business results(f) |  |  | (1.7 | ) |  |  | 0.4 |  |  |  | (1.3 | ) |  |  | (2.8 | ) |  |  | 0.7 |  |  |  | (2.1 | ) |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 60.1 |  |  | $ | (12.8 | ) |  | $ | 47.3 |  |  | $ | 54.5 |  |  | $ | (17.7 | ) |  | $ | 36.8 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 0.90 |  |  |  |  |  |  |  |  |  |  | $ | 1.00 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Loss on assets held for sale |  |  |  |  |  |  |  |  |  |  | 0.25 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Special legal contingency charges(a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Asbestos-related litigation(a) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Inventory write down(b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.10 | ) |  |  |  |  |  |  |  |  |  |  | (0.17 | ) |
| Other tax items, net(c) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Divestiture costs (a) |  |  |  |  |  |  |  |  |  |  | 0.05 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Non-core business results(f) |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |  |  |  |  |  |  |  |  |  |  | (0.05 | ) |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 1.13 |  |  |  |  |  |  |  |  |  |  | $ | 0.85 |  |

[0001193125-18-125935:8k_2_02:80]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-18-125935:8k_2_02:81]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-18-125935:8k_2_02:82]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-18-125935:8k_2_02:83]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-18-125935:8k_2_02:84]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-18-125935:8k_2_02:85]
| (f) | Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |

[0001193125-18-125935:8k_2_02:86]
|  |  | For the Three Months EndedMarch 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Components of (Gains) Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |
| Realized gains on settled future contracts (a) |  | $ | (0.5 | ) |  | $ | (0.4 | ) |
| Foreign currency exchange losses (gains) (a) |  |  | 1.3 |  |  |  | (0.2 | ) |
| Loss on disposal of fixed assets (a) |  |  | — |  |  |  | (0.1 | ) |
| Net change in unrealized losses on unsettled futures contracts (b) |  |  | 1.1 |  |  |  | 0.7 |  |
| Special legal contingency charges (b) |  |  | 0.2 |  |  |  | 0.9 |  |
| Asbestos-related litigation (b) |  |  | 2.1 |  |  |  | 1.7 |  |
| Environmental liabilities (b) |  |  | 0.3 |  |  |  | 0.5 |  |
| Divestiture costs (b) |  |  | 2.5 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.3 |  |  |  | — |  |
| Losses and other expenses, net (pre-tax) |  | $ | 7.3 |  |  | $ | 3.1 |  |

[0001193125-18-125935:8k_2_02:87]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-18-125935:8k_2_02:88]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-18-125935:8k_2_02:89]
Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated
Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure

[0001193125-18-125935:8k_2_02:90]
|  |  | For the Year EndedDecember 31, 2018ESTIMATED |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $ | 8.79 - $9.39 |  |
| Loss on assets held for sale, charges associated with the divestiture of the South American business and other items partially offset by excess tax benefits from share-based compensation |  |  | 0.96 |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 9.75 - $10.35 |  |

[0001193125-18-125935:8k_2_02:91]
Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a
Non-GAAP measure (shares in millions):

[0001193125-18-125935:8k_2_02:92]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Average shares outstanding - diluted, a GAAP measure |  |  | 42.1 |  |  |  | 43.5 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Adjusted average shares outstanding - diluted, a Non- GAAP measure |  |  | 41.9 |  |  |  | 43.3 |  |

[0001193125-18-125935:8k_2_02:93]
Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP
measure

[0001193125-18-125935:8k_2_02:94]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Three MonthsEnded March 31, |  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net sales, a GAAP measure |  | $ | 175.6 |  |  | $ | 178.1 |  |  | $ | 834.8 |  |  | $ | 793.4 |  |
| Net sales from non-core businesses (a) |  |  | 47.0 |  |  |  | 47.1 |  |  |  | 47.0 |  |  |  | 47.1 |  |
| Adjusted net sales, a Non- GAAP measure |  | $ | 128.6 |  |  | $ | 131.0 |  |  | $ | 787.8 |  |  | $ | 746.3 |  |

[0001193125-18-125935:8k_2_02:95]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-125935:8k_2_02:96]
Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure

[0001193125-18-125935:8k_2_02:97]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Three MonthsEnded March 31, |  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross profit, a GAAP measure |  | $ | 48.3 |  |  | $ | 51.8 |  |  | $ | 223.2 |  |  | $ | 210.9 |  |
| Gross profit from non-core businesses (a) |  |  | 13.5 |  |  |  | 14.9 |  |  |  | 13.5 |  |  |  | 14.9 |  |
| Adjusted Gross profit, a Non- GAAP measure |  | $ | 34.8 |  |  | $ | 36.9 |  |  | $ | 209.7 |  |  | $ | 196.0 |  |

[0001193125-18-125935:8k_2_02:98]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-125935:8k_2_02:99]
Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure

[0001193125-18-125935:8k_2_02:100]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Three MonthsEnded March 31, |  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Segment profit, a GAAP measure |  | $ | 11.2 |  |  | $ | 14.1 |  |  | $ | 70.8 |  |  | $ | 64.7 |  |
| Gross profit from non-core businesses (a) |  |  | 1.7 |  |  |  | 3.1 |  |  |  | 1.7 |  |  |  | 3.1 |  |
| Adjusted Segment profit, a Non- GAAP measure |  | $ | 9.5 |  |  | $ | 11.0 |  |  | $ | 69.1 |  |  | $ | 61.6 |  |

[0001193125-18-125935:8k_2_02:101]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-125935:8k_2_02:102]
Reconciliation of Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-18-125935:8k_2_02:103]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Net cash used in operating activities, a GAAP measure |  | $ | (83.5 | ) |  | $ | (107.6 | ) |
| Purchases of property, plant and equipment |  |  | (22.7 | ) |  |  | (24.9 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 0.1 |  |
| Free cash flow, a Non-GAAP measure |  |  | (106.1 | ) |  |  | (132.4 | ) |

[0001193125-18-125935:8k_2_02:104]
| (a) | Non-core businesses represent our business operations in Australia, Asia, and South America |

[0001193125-18-125935:8k_2_02:105]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelve Months to March 31, 2018 |  |
| Adjusted EBIT(a) (a) |  | $ | 515.7 |  |
| Depreciation and amortization expense (b) |  |  | 65.6 |  |
| EBITDA (a + b) |  | $ | 581.3 |  |
| Total debt at March 31, 2018 (c) |  | $ | 1,289.1 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.2 |  |

[0001193125-18-125935:8k_2_02:106]
| (a) | Adjusted EBIT excludes the non-core business results related to our business operations in Australia, Asia, and South America. |

[0001193125-18-125935:8k_2_02:107]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a
GAAP measure (dollars in millions)

[0001193125-18-125935:8k_2_02:108]
|  |  | TrailingTwelve Months toMarch 31, 2018 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 515.7 |  |
| Special product quality adjustments |  |  | 5.4 |  |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 14.3 |  |
| Inventory write down |  |  | 0.2 |  |
| Restructuring charges |  |  | 4.0 |  |
| Interest expense, net |  |  | 31.5 |  |
| Loss on assets held for sale |  |  | 10.3 |  |
| Non-core business results (a) |  |  | (5.1 | ) |
| Other expenses, net |  |  | 0.5 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 454.6 |  |

[0001193125-18-125935:8k_2_02:109]
| (a) | Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |
