# LII 8-K — 0001193125-23-019706 filed 2023-01-31

## item codes, every 8-K on or before 2023-02-21

- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2023-02-21

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-23-019706:8k_2_02:1]
EX-99.1
2
d457144dex991.htm
EX-99.1

[0001193125-23-019706:8k_2_02:2]
EX-99.1

[0001193125-23-019706:8k_2_02:3]
Exhibit 99.1

[0001193125-23-019706:8k_2_02:4]
Lennox Reports Record Revenue and EPS for Full Year 2022

[0001193125-23-019706:8k_2_02:5]
Highlights

[0001193125-23-019706:8k_2_02:6]
(All comparisons are year-over-year, unless otherwise noted)

[0001193125-23-019706:8k_2_02:7]
|  | • |  | Fourth quarter 2022 revenue up 13% to record $1.1 billion, GAAP EPS up 17% to $2.65, adjusted EPS up 12% to $2.63 |

[0001193125-23-019706:8k_2_02:8]
|  | • |  | Full year 2022 revenue up 13% to record $4.7 billion, GAAP EPS up 12% to record $13.88, and adjusted EPS up 12% to record $14.07 |

[0001193125-23-019706:8k_2_02:9]
|  | • |  | Reiterating 2023 outlook with core revenue flat to up 4% and EPS of $14.25-$15.25 |

[0001193125-23-019706:8k_2_02:10]
DALLAS, January 31, 2023 –
Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported fourth quarter record revenue of $1.09 billion in the quarter, up 13%. GAAP operating income was $132 million, up 35%. GAAP earnings per share
from continuing operations was $2.65, up 17%.

[0001193125-23-019706:8k_2_02:11]
Total segment profit rose 30% to $132 million. Total segment margin was 12.1%, up 150 basis points.
Adjusted earnings per share from continuing operations rose 12% to $2.63.

[0001193125-23-019706:8k_2_02:12]
“Lennox once again delivered record revenue and profits fueled by growth
across all three segments and solid execution on Commercial business profit recovery. Our Q4 margins expanded as pricing gains continued to outpace inflation” said CEO Alok Maskara. “We exit the year with positive margin momentum which
positions us well for another record profit year in 2023.”

[0001193125-23-019706:8k_2_02:13]
In Residential, revenue and profit set new fourth quarter highs as revenue was up 13% and
segment profit rose 8%. Segment margin was 16.9%, down 90 basis points, as pricing gains were partially offset by higher material costs and inefficiencies related to the regulatory SEER transition.

[0001193125-23-019706:8k_2_02:14]
In Commercial, revenue was up 19% due to improved factory output and pricing gains. Segment profit rose 79%, and segment margin expanded 390 basis points to
11.6%.

[0001193125-23-019706:8k_2_02:15]
In Refrigeration, revenue was up 5% as reported and up 10% at constant currency, led by growth in North America. Segment profit rose 42%, and
segment margin expanded 330 basis points to 12.5%.

[0001193125-23-019706:8k_2_02:16]
FOURTH QUARTER 2022 FINANCIAL HIGHLIGHTS

[0001193125-23-019706:8k_2_02:17]
Revenue: Revenue was a fourth quarter record $1.09 billion, up 13% driven by volume and 9% price. Foreign exchange had a negative
1% impact on revenue.

[0001193125-23-019706:8k_2_02:18]
Gross Profit: Gross profit was $285 million, up 12%. Gross margin was 26.1%, down 20 basis points, due
primarily to higher material and factory costs which were primarily offset with price gains.

[0001193125-23-019706:8k_2_02:19]
Net Income: On a GAAP basis, net income from continuing operations for the fourth
quarter was $94.4 million, or $2.65 per share, compared to $83.5 million, or $2.27 per share, in the prior year quarter.

[0001193125-23-019706:8k_2_02:20]
Adjusted income from continuing operations in the fourth quarter was $93.6 million, or $2.63 per share, compared to $86.7 million, or
$2.35 per share, in the prior year quarter.

[0001193125-23-019706:8k_2_02:21]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from operations in the
fourth quarter was $132 million compared to $119 million in the prior-year quarter. Capital expenditures were approximately $34 million in the fourth quarter compared to $38 million in the prior year quarter. Free cash flow was
$98 million compared to $81 million in the fourth quarter a year ago. Total debt at the end of the fourth quarter was $1.52 billion. Total cash, cash equivalents and short-term investments were $61 million at the end of the
quarter.

[0001193125-23-019706:8k_2_02:22]
Residential: Revenue in the Residential Heating & Cooling business segment was a fourth quarter record
$703 million, up 13%. Segment profit was a fourth quarter record $119 million, up 8%. Segment margin was 16.9%, down 90 basis points with pricing and volume gains more than offset by unfavorable mix, material, and SG&A cost inflation.

[0001193125-23-019706:8k_2_02:23]
Commercial: Revenue in the Commercial Heating & Cooling business segment was $241 million, up 19%. Segment profit was
$28 million, up 79%. Segment margin expanded 390 basis points to 11.6% primarily driven by higher manufacturing output and price.

[0001193125-23-019706:8k_2_02:24]
Refrigeration: Revenue in the Refrigeration business segment was $150 million, up 5%. Foreign exchange had a negative 5% impact on
revenue growth. Segment profit rose 42% to $19 million. Segment margin expanded 330 basis points to 12.5% primarily driven by price.

[0001193125-23-019706:8k_2_02:25]
FULL YEAR
2022 FINANCIAL HIGHLIGHTS

[0001193125-23-019706:8k_2_02:26]
Revenue: Revenue for the year was a record $4.72 billion, up 13%. Foreign exchange had a
negative 1% impact on revenue.

[0001193125-23-019706:8k_2_02:27]
Gross Profit: Gross profit was $1.28 billion, up 8%. Gross margin was 27.2%, down 110 basis
points, primarily impacted by residential mix and inefficiencies related to global supply chain disruptions.

[0001193125-23-019706:8k_2_02:28]
Net Income: On a GAAP
basis, net income from continuing operations for the year was $497 million, or $13.88 per share, compared to $464 million, or $12.39 per share, in the prior year.

[0001193125-23-019706:8k_2_02:29]
Adjusted net income from continuing operations in 2022 was $504 million, or $14.07 per share, compared to $471 million, or $12.60 per
share, in the prior year.

[0001193125-23-019706:8k_2_02:30]
Cash from Operations and Free Cash Flow: Net cash from operations in 2022 was $302 million compared
to $516 million in the prior year as the company replenished finished goods inventory ahead of the minimum-efficiency regulatory changes and in raw material to increase supply chain resiliency. Capital expenditures were approximately
$101 million in 2022 compared to $107 million in the prior year. Free cash flow was $203 million compared to $410 million a year ago.

[0001193125-23-019706:8k_2_02:31]
Residential: Revenue in the Residential Heating & Cooling business segment
was a record $3.20 billion, up 15%. Segment profit was a record $597 million, up 10%. Segment margin was 18.7%, down 80 basis points, impacted by lower mix as manufacturing output of higher-end
products remained constrained and supply chain challenges drove manufacturing inefficiencies.

[0001193125-23-019706:8k_2_02:32]
Commercial: Revenue in the Commercial
Heating & Cooling business segment was $901 million, up 4%. Segment profit was $81 million, down 27%. Segment margin contracted 380 basis points to 9.0% primarily driven by factory inefficiencies and lower sales volume.

[0001193125-23-019706:8k_2_02:33]
Refrigeration: Revenue in the Refrigeration business segment was $619 million, up 12%. Foreign exchange had a negative 5% impact to
revenue growth. Segment profit rose 60% to $79 million. Segment margin expanded 380 basis points to 12.7% primarily driven by price.

[0001193125-23-019706:8k_2_02:34]
As previously announced, beginning in 2023 North American Refrigeration operations will be reported in the Commercial Segment and European
operations will be classified as non-core and included in the Corporate and Other Segment until disposition.

[0001193125-23-019706:8k_2_02:35]
FULL-YEAR 2023 GUIDANCE

[0001193125-23-019706:8k_2_02:36]
For the full year of 2023, the
company expects:

[0001193125-23-019706:8k_2_02:37]
|  | • |  | Reiterating Core revenue growth of flat to up 4%, excluding the impact of the planned divestiture of the European operations |

[0001193125-23-019706:8k_2_02:38]
|  | • |  | Reiterating GAAP and adjusted EPS of $14.25-$15.25 |

[0001193125-23-019706:8k_2_02:39]
|  | • |  | Reiterating Corporate expenses of approximately $80 million |

[0001193125-23-019706:8k_2_02:40]
|  | • |  | Reiterating Interest expense of $55-$60 million |

[0001193125-23-019706:8k_2_02:41]
|  | • |  | Reiterating an Effective tax rate of 19-21% on an adjusted basis |

[0001193125-23-019706:8k_2_02:42]
|  | • |  | Capital expenditures of approximately $250 million, including investments in the new Commercial manufacturing facility and investments for the upcoming 2025 refrigerant regulatory transition |

[0001193125-23-019706:8k_2_02:43]
|  | • |  | Reiterating Cash from operations of $500-$600 million and free cash flow of $250-$350 million |

[0001193125-23-019706:8k_2_02:44]
|  | • |  | A weighted average diluted share count of 35-36 million shares |

[0001193125-23-019706:8k_2_02:45]
CONFERENCE CALL INFORMATION

[0001193125-23-019706:8k_2_02:46]
A conference call to discuss the company’s fourth-quarter results and 2023 outlook will be held this morning at 8:30 a.m. Central Time. To participate in
the earnings conference, please call 800-343-4136 (U.S.) or +1 203-518-9843
(international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ422. The conference call also will be webcast live on the company’s web site at www.lennoxinternational.com. A replay of the conference call will be
available until February 14, 2023, by calling toll-free 800-343-4136 (U.S.) or +1
203-518-9843 (international). The call also will be archived on the company’s web site.

[0001193125-23-019706:8k_2_02:47]
ABOUT LENNOX

[0001193125-23-019706:8k_2_02:48]
Lennox (NYSE: LII) is a leader in
energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our
cooling, heating, indoor air quality, and refrigeration systems. Additional information on Lennox is available at www.lennoxinternational.com or by contacting investor@lennoxintl.com.

[0001193125-23-019706:8k_2_02:49]
FORWARD-LOOKING STATEMENTS

[0001193125-23-019706:8k_2_02:50]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-019706:8k_2_02:51]
Consolidated Statements of Operations

[0001193125-23-019706:8k_2_02:52]
(Unaudited)

[0001193125-23-019706:8k_2_02:53]
| (Amounts in millions, except per share data) |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net sales |  | $ | 1,093.8 |  |  | $ | 964.8 |  |  | $ | 4,718.4 |  |  | $ | 4,194.1 |  |
| Cost of goods sold |  |  | 808.6 |  |  |  | 711.2 |  |  |  | 3,433.7 |  |  |  | 3,005.7 |  |
| Gross profit |  |  | 285.2 |  |  |  | 253.6 |  |  |  | 1,284.7 |  |  |  | 1,188.4 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 155.0 |  |  |  | 151.5 |  |  |  | 627.2 |  |  |  | 598.9 |  |
| (Gains) losses and other expenses, net |  |  | (0.6 | ) |  |  | 4.5 |  |  |  | 4.9 |  |  |  | 9.2 |  |
| Restructuring charges |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 1.5 |  |  |  | 1.8 |  |
| Income from equity method investments |  |  | (1.3 | ) |  |  | (0.2 | ) |  |  | (5.1 | ) |  |  | (11.8 | ) |
| Operating income |  |  | 131.8 |  |  |  | 97.6 |  |  |  | 656.2 |  |  |  | 590.3 |  |
| Pension settlements |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.2 | ) |  |  | 1.2 |  |
| Interest expense, net |  |  | 12.7 |  |  |  | 6.2 |  |  |  | 38.7 |  |  |  | 25.0 |  |
| Other expense (income), net |  |  | — |  |  |  | 1.1 |  |  |  | 1.9 |  |  |  | 4.0 |  |
| Income from continuing operations before income taxes |  |  | 119.5 |  |  |  | 90.2 |  |  |  | 615.8 |  |  |  | 560.1 |  |
| Provision for income taxes |  |  | 25.1 |  |  |  | 6.7 |  |  |  | 118.7 |  |  |  | 96.1 |  |
| Income from continuing operations |  |  | 94.4 |  |  |  | 83.5 |  |  |  | 497.1 |  |  |  | 464.0 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from discontinued operations before income taxes |  |  | — |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |
| Income tax expense |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |
| Income from discontinued operations |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |
| Net income |  | $ | 94.4 |  |  | $ | 83.6 |  |  | $ | 497.1 |  |  | $ | 464.0 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.66 |  |  | $ | 2.28 |  |  | $ | 13.92 |  |  | $ | 12.47 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income |  | $ | 2.66 |  |  | $ | 2.28 |  |  | $ | 13.92 |  |  | $ | 12.47 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.65 |  |  | $ | 2.27 |  |  | $ | 13.88 |  |  | $ | 12.39 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income |  | $ | 2.65 |  |  | $ | 2.27 |  |  | $ | 13.88 |  |  | $ | 12.39 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 35.4 |  |  |  | 36.6 |  |  |  | 35.7 |  |  |  | 37.2 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 35.6 |  |  |  | 36.8 |  |  |  | 35.8 |  |  |  | 37.5 |  |

[0001193125-23-019706:8k_2_02:54]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-019706:8k_2_02:55]
Segment Net Sales and Profit (Loss)

[0001193125-23-019706:8k_2_02:56]
(Unaudited)

[0001193125-23-019706:8k_2_02:57]
| (Amounts in millions) |  | For the Three MonthsEnded December 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 703.4 |  |  | $ | 620.3 |  |  | $ | 3,198.3 |  |  | $ | 2,775.6 |  |
| Commercial Heating & Cooling |  |  | 240.5 |  |  |  | 201.4 |  |  |  | 900.7 |  |  |  | 864.8 |  |
| Refrigeration |  |  | 149.9 |  |  |  | 143.1 |  |  |  | 619.4 |  |  |  | 553.7 |  |
|  |  | $ | 1,093.8 |  |  | $ | 964.8 |  |  | $ | 4,718.4 |  |  | $ | 4,194.1 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 119.2 |  |  | $ | 110.3 |  |  | $ | 596.9 |  |  | $ | 540.3 |  |
| Commercial Heating & Cooling |  |  | 27.9 |  |  |  | 15.6 |  |  |  | 80.9 |  |  |  | 110.9 |  |
| Refrigeration |  |  | 18.8 |  |  |  | 13.2 |  |  |  | 78.8 |  |  |  | 49.1 |  |
| Corporate and other |  |  | (33.7 | ) |  |  | (37.2 | ) |  |  | (90.8 | ) |  |  | (96.4 | ) |
| Total segment profit |  |  | 132.2 |  |  |  | 101.9 |  |  |  | 665.8 |  |  |  | 603.9 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | — |  |  |  | (1.4 | ) |  |  | — |  |  |  | (2.5 | ) |
| Items in (Gains) losses and other expenses, net which are excluded from segment profit (loss) (1) |  |  | 0.1 |  |  | $ | 5.5 |  |  |  | 8.1 |  |  |  | 14.3 |  |
| Restructuring charges |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 1.5 |  |  |  | 1.8 |  |
| Operating income |  | $ | 131.8 |  |  | $ | 97.6 |  |  | $ | 656.2 |  |  | $ | 590.3 |  |

[0001193125-23-019706:8k_2_02:58]
| (1) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-23-019706:8k_2_02:59]
|  | • |  | The following items in (Gains) losses and other expenses, net: |

[0001193125-23-019706:8k_2_02:60]
|  | • |  | Net change in unrealized (gains) losses on unsettled futures contracts, |

[0001193125-23-019706:8k_2_02:61]
|  | • |  | Environmental liabilities and special litigation charges, |

[0001193125-23-019706:8k_2_02:62]
|  | • |  | Charges incurred related to COVID-19 pandemic; and |

[0001193125-23-019706:8k_2_02:63]
|  | • |  | Other items, net, |

[0001193125-23-019706:8k_2_02:64]
|  | • |  | Special product quality adjustments; and |

[0001193125-23-019706:8k_2_02:65]
|  | • |  | Restructuring charges. |

[0001193125-23-019706:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-019706:8k_2_02:67]
Consolidated Balance Sheets

[0001193125-23-019706:8k_2_02:68]
(Unaudited)

[0001193125-23-019706:8k_2_02:69]
| (Amounts in millions, except shares and par values) |  | As of December 31, 2022 |  |  | As of December 31, 2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 52.6 |  |  | $ | 31.0 |  |
| Short-term investments |  |  | 8.5 |  |  |  | 5.5 |  |
| Accounts and notes receivable, net of allowances of $15.5 and $10.7 in 2022 and 2021, respectively |  |  | 608.5 |  |  |  | 508.3 |  |
| Inventories, net |  |  | 753.0 |  |  |  | 510.9 |  |
| Other assets |  |  | 73.9 |  |  |  | 119.7 |  |
| Total current assets |  |  | 1,496.5 |  |  |  | 1,175.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $920.8 and $888.8 in 2022 and 2021, respectively |  |  | 548.9 |  |  |  | 515.1 |  |
| Right-of-use assets from operating leases |  |  | 219.9 |  |  |  | 196.1 |  |
| Goodwill |  |  | 186.3 |  |  |  | 186.6 |  |
| Deferred income taxes |  |  | 27.5 |  |  |  | 11.3 |  |
| Other assets, net |  |  | 88.5 |  |  |  | 87.4 |  |
| Total assets |  | $ | 2,567.6 |  |  | $ | 2,171.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 710.6 |  |  | $ | 11.3 |  |
| Current operating lease liabilities |  |  | 63.3 |  |  |  | 54.8 |  |
| Accounts payable |  |  | 427.3 |  |  |  | 402.1 |  |
| Accrued expenses |  |  | 376.9 |  |  |  | 358.9 |  |
| Income taxes payable |  |  | 17.6 |  |  |  | — |  |
| Total current liabilities |  |  | 1,595.7 |  |  |  | 827.1 |  |
| Long-term debt |  |  | 814.2 |  |  |  | 1,226.5 |  |
| Long-term operating lease liabilities |  |  | 161.8 |  |  |  | 145.0 |  |
| Pensions |  |  | 40.1 |  |  |  | 83.3 |  |
| Other liabilities |  |  | 158.9 |  |  |  | 159.0 |  |
| Total liabilities |  |  | 2,770.7 |  |  |  | 2,440.9 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ deficit: |  |  |  |  |  |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,155.2 |  |  |  | 1,133.7 |  |
| Retained earnings |  |  | 3,070.6 |  |  |  | 2,719.3 |  |
| Accumulated other comprehensive loss |  |  | (90.6 | ) |  |  | (88.1 | ) |
| Treasury stock, at cost, 51,700,260 shares and 50,536,125 shares for 2022 and 2021, respectively |  |  | (4,339.2 | ) |  |  | (4,034.8 | ) |
| Total stockholders’ deficit |  |  | (203.1 | ) |  |  | (269.0 | ) |
| Total liabilities and stockholders’ deficit |  | $ | 2,567.6 |  |  | $ | 2,171.9 |  |

[0001193125-23-019706:8k_2_02:70]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-019706:8k_2_02:71]
Consolidated Statements of Cash Flows

[0001193125-23-019706:8k_2_02:72]
(Unaudited)

[0001193125-23-019706:8k_2_02:73]
| (Amounts in millions) |  | For the Years EndedDecember 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 497.1 |  |  | $ | 464.0 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (5.1 | ) |  |  | (11.8 | ) |
| Dividends from affiliates |  |  | 1.7 |  |  |  | 9.1 |  |
| Restructuring charges, net of cash paid |  |  | 1.0 |  |  |  | 1.1 |  |
| Provision for credit losses |  |  | 6.9 |  |  |  | 4.9 |  |
| Unrealized losses (gains), net on derivative contracts |  |  | 1.7 |  |  |  | (0.6 | ) |
| Stock-based compensation expense |  |  | 21.8 |  |  |  | 24.3 |  |
| Depreciation and amortization |  |  | 77.9 |  |  |  | 72.4 |  |
| Deferred income taxes |  |  | (15.2 | ) |  |  | (5.4 | ) |
| Pension expense |  |  | 6.0 |  |  |  | 11.3 |  |
| Pension contributions |  |  | (22.5 | ) |  |  | (1.5 | ) |
| Other items, net |  |  | (1.1 | ) |  |  | 0.3 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (112.4 | ) |  |  | (68.8 | ) |
| Inventories |  |  | (249.3 | ) |  |  | (71.0 | ) |
| Other current assets |  |  | (7.3 | ) |  |  | (19.2 | ) |
| Accounts payable |  |  | 28.2 |  |  |  | 55.2 |  |
| Accrued expenses |  |  | 13.7 |  |  |  | 64.2 |  |
| Income taxes payable and receivable, net |  |  | 56.4 |  |  |  | (26.5 | ) |
| Leases, net |  |  | 1.7 |  |  |  | 0.2 |  |
| Other, net |  |  | 1.1 |  |  |  | 13.3 |  |
| Net cash provided by operating activities |  |  | 302.3 |  |  |  | 515.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 1.6 |  |  |  | 0.9 |  |
| Purchases of property, plant and equipment |  |  | (101.1 | ) |  |  | (106.8 | ) |
| Purchases of short-term investments, net |  |  | (3.5 | ) |  |  | (0.5 | ) |
| Net cash used in investing activities |  |  | (103.0 | ) |  |  | (106.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Asset securitization borrowings |  |  | 407.0 |  |  |  | 627.0 |  |
| Asset securitization payments |  |  | (307.0 | ) |  |  | (377.0 | ) |
| Long-term debt payments |  |  | (12.9 | ) |  |  | (12.3 | ) |
| Borrowings from credit facility |  |  | 2,537.5 |  |  |  | 1,162.5 |  |
| Payments on credit facility |  |  | (2,352.0 | ) |  |  | (1,156.0 | ) |
| Payments of deferred financing costs |  |  | — |  |  |  | 2.4 |  |
| Proceeds from employee stock purchases |  |  | 3.6 |  |  |  | 3.3 |  |
| Repurchases of common stock |  |  | (300.0 | ) |  |  | (600.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (8.3 | ) |  |  | (22.1 | ) |
| Cash dividends paid |  |  | (142.0 | ) |  |  | (126.5 | ) |
| Net cash used in financing activities |  |  | (174.1 | ) |  |  | (498.7 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 25.2 |  |  |  | (89.6 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (3.6 | ) |  |  | (3.3 | ) |
| Cash and cash equivalents, beginning of period |  |  | 31.0 |  |  |  | 123.9 |  |
| Cash and cash equivalents, end of period |  | $ | 52.6 |  |  | $ | 31.0 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 35.4 |  |  | $ | 23.8 |  |
| Income taxes paid (net of refunds) |  | $ | 77.2 |  |  | $ | 128.5 |  |
| Insurance recoveries received |  | $ | — |  |  | $ | 6.6 |  |

[0001193125-23-019706:8k_2_02:74]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-23-019706:8k_2_02:75]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-23-019706:8k_2_02:76]
(Unaudited, in millions, except per share and ratio data)

[0001193125-23-019706:8k_2_02:77]
Use of Non-GAAP Financial Measures

[0001193125-23-019706:8k_2_02:78]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance.

[0001193125-23-019706:8k_2_02:79]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted
Income from Continuing Operations, a Non-GAAP measure

[0001193125-23-019706:8k_2_02:80]
|  |  | For the Three Months Ended December 31,(Unaudited) |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | Pre-Tax |  |  | Tax Impact (d) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (d) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 119.5 |  |  | $ | (25.1 | ) |  | $ | 94.4 |  |  | $ | 90.2 |  |  | $ | (6.7 | ) |  | $ | 83.5 |  |
| Restructuring charges |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Pension settlements |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | — |  |
| Special product quality adjustments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.4 | ) |  |  | 0.4 |  |  |  | (1.0 | ) |
| Items in (Gains) losses and other expenses, net which are excluded from segment profit (loss) (b) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | — |  |  |  | 5.5 |  |  |  | (2.2 | ) |  |  | 3.3 |  |
| Excess tax (benefit) expense from share-based compensation (c) |  |  | — |  |  |  | (0.9 | ) |  |  | (0.9 | ) |  |  | — |  |  |  | 0.7 |  |  |  | 0.7 |  |
| Other tax items, net (c) |  |  | — |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 119.5 |  |  | $ | (25.9 | ) |  | $ | 93.6 |  |  | $ | 94.6 |  |  | $ | (7.9 | ) |  | $ | 86.7 |  |
| Earnings per share - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.65 |  |  |  |  |  |  |  |  |  |  | $ | 2.27 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Special product quality adjustments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |
| Items in (Gains) losses and other expenses, net which are excluded from segment profit (loss) (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.09 |  |
| Excess tax (benefit) expense from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Other tax items, net (c) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.63 |  |  |  |  |  |  |  |  |  |  | $ | 2.35 |  |

[0001193125-23-019706:8k_2_02:81]
| (a) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-23-019706:8k_2_02:82]
| (b) | Recorded in (Gains) losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-23-019706:8k_2_02:83]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-23-019706:8k_2_02:84]
| (d) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-23-019706:8k_2_02:85]
|  |  | For the Years Ended December 31,(Unaudited) |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | Pre-Tax |  |  | Tax Impact (d) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (d) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 615.8 |  |  | $ | (118.7 | ) |  | $ | 497.1 |  |  | $ | 560.1 |  |  | $ | (96.1 | ) |  | $ | 464.0 |  |
| Restructuring charges |  |  | 1.5 |  |  |  | (0.3 | ) |  |  | 1.2 |  |  |  | 1.8 |  |  |  | (0.4 | ) |  |  | 1.4 |  |
| Pension settlements |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | 1.2 |  |  |  | (0.3 | ) |  |  | 0.9 |  |
| Special product quality adjustments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2.5 | ) |  |  | 0.7 |  |  |  | (1.8 | ) |
| Items in (Gains) losses and other expenses, net which are excluded from segment profit (loss) (b) |  |  | 8.1 |  |  |  | (1.5 | ) |  |  | 6.6 |  |  |  | 14.3 |  |  |  | (3.8 | ) |  |  | 10.5 |  |
| Excess tax benefit from share-based compensation (c) |  |  | — |  |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | — |  |  |  | (5.7 | ) |  |  | (5.7 | ) |
| Other tax items, net (c) |  |  | — |  |  |  | (0.5 | ) |  |  | (0.5 | ) |  |  | — |  |  |  | 2.1 |  |  |  | 2.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 625.2 |  |  | $ | (121.5 | ) |  | $ | 503.7 |  |  | $ | 574.9 |  |  | $ | (103.5 | ) |  | $ | 471.4 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 13.88 |  |  |  |  |  |  |  |  |  |  | $ | 12.39 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.04 |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Special product quality adjustments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.05 | ) |
| Items in (Gains) losses and other expenses, net which are excluded from segment profit (loss) (b) |  |  |  |  |  |  |  |  |  |  | 0.19 |  |  |  |  |  |  |  |  |  |  |  | 0.29 |  |
| Excess tax benefit from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |  |  |  |  |  |  |  |  |  |  | (0.15 | ) |
| Other tax items, net (c) |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | 0.06 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 14.07 |  |  |  |  |  |  |  |  |  |  | $ | 12.60 |  |

[0001193125-23-019706:8k_2_02:86]
| (a) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-23-019706:8k_2_02:87]
| (b) | Recorded in (Gains) losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-23-019706:8k_2_02:88]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-23-019706:8k_2_02:89]
| (d) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-23-019706:8k_2_02:90]
|  |  | For the Three MonthsEnded December 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
|  |  | (Unaudited) |  |
| Components of (Gains) losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts (a) |  | $ | 0.2 |  |  | $ | (0.3 | ) |  | $ | 0.1 |  |  | $ | (1.2 | ) |
| Foreign currency exchange gains (a) |  |  | (0.8 | ) |  |  | (0.6 | ) |  |  | (1.3 | ) |  |  | (2.2 | ) |
| Loss (gain) on disposal of fixed assets (a) |  |  | 0.4 |  |  |  | 0.4 |  |  |  | (1.0 | ) |  |  | (0.2 | ) |
| Other operating income (a) |  |  | (0.5 | ) |  |  | (0.5 | ) |  |  | (1.0 | ) |  |  | (1.5 | ) |
| Net change in unrealized (gains) losses on unsettled futures contracts (b) |  |  | (0.7 | ) |  |  | — |  |  |  | 0.4 |  |  |  | — |  |
| Environmental liabilities and special litigation charges (b) |  |  | 1.3 |  |  |  | 2.5 |  |  |  | 7.5 |  |  |  | 9.6 |  |
| Charges incurred related to COVID-19 pandemic (b) |  |  | 0.1 |  |  |  | 0.3 |  |  |  | 0.8 |  |  |  | 2.2 |  |
| Other items, net (b) |  |  | (0.6 | ) |  |  | 2.7 |  |  |  | (0.6 | ) |  |  | 2.5 |  |
| (Gains) losses and other expenses, net (pre-tax) |  | $ | (0.6 | ) |  | $ | 4.5 |  |  | $ | 4.9 |  |  | $ | 9.2 |  |

[0001193125-23-019706:8k_2_02:91]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-23-019706:8k_2_02:92]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-23-019706:8k_2_02:93]
Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares
Outstanding - Diluted, a Non-GAAP measure (shares in millions):

[0001193125-23-019706:8k_2_02:94]
|  |  | For the Three MonthsEnded December 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Average shares outstanding - diluted, a GAAP measure |  |  | 35.6 |  |  |  | 36.8 |  |  |  | 35.8 |  |  |  | 37.5 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure |  |  | 35.6 |  |  |  | 36.8 |  |  |  | 35.8 |  |  |  | 37.4 |  |

[0001193125-23-019706:8k_2_02:95]
Reconciliation of Net Cash Provided By Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-23-019706:8k_2_02:96]
|  |  | For the Three MonthsEnded December 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net cash provided by operating activities |  | $ | 132.2 |  |  | $ | 119.2 |  |  | $ | 302.3 |  |  | $ | 515.5 |  |
| Purchases of property, plant and equipment |  |  | (34.1 | ) |  |  | (38.3 | ) |  |  | (101.1 | ) |  |  | (106.8 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.4 |  |  |  | 0.2 |  |  |  | 1.6 |  |  |  | 0.9 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 98.5 |  |  | $ | 81.1 |  |  | $ | 202.8 |  |  | $ | 409.6 |  |

[0001193125-23-019706:8k_2_02:97]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | Trailing TwelveMonths toDecember 31,2022 |  |
| Adjusted EBIT (a) |  | $ | 665.8 |  |
| Depreciation and amortization expense (b) |  |  | 75.7 |  |
| EBITDA (a + b) |  | $ | 741.5 |  |
| Total debt at December 31, 2022 (c) |  | $ | 1,524.8 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.1 |  |

[0001193125-23-019706:8k_2_02:98]
Reconciliation of Income from Continuing Operations Before Income Taxes, a GAAP measure to Adjusted EBIT, a Non-GAAP measure

[0001193125-23-019706:8k_2_02:99]
|  |  | Trailing TwelveMonths toDecember 31,2022 |  |
| Income from continuing operations before income taxes, a GAAP measure |  |  | 615.8 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit |  |  | 8.1 |  |
| Restructuring charges |  |  | 1.5 |  |
| Interest expense, net |  |  | 38.7 |  |
| Pension settlements |  |  | (0.2 | ) |
| Other expense (income), net |  |  | 1.9 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  | 665.8 |  |
