# LII MD&A — 0001628280-23-004257


## mdna

[0001628280-23-004257:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-23-004257:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the Consolidated Financial Statements and related Notes to the Consolidated Financial Statements in Item 8, “Other Financial Statement Details,” of this Annual Report on Form 10-K.

[0001628280-23-004257:mdna:3]
17

[0001628280-23-004257:mdna:4]
Business Overview

[0001628280-23-004257:mdna:5]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 3 in the Notes to the Consolidated Financial Statements.

[0001628280-23-004257:mdna:6]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001628280-23-004257:mdna:7]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001628280-23-004257:mdna:8]
Impact of COVID-19 Pandemic

[0001628280-23-004257:mdna:9]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world.  The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations since 2020.  We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows.

[0001628280-23-004257:mdna:10]
Executive Leadership Transition

[0001628280-23-004257:mdna:11]
On March 23, 2022, the Board of Directors appointed Alok Maskara as Chief Executive Officer (“CEO”) effective May 9, 2022.  Mr. Maskara succeeded Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and served as interim CEO until Mr. Maskara assumed the role on May 9, 2022.

[0001628280-23-004257:mdna:12]
Financial Highlights

[0001628280-23-004257:mdna:13]
•Net sales increased $524 million, or 13%, to $4,718 million in 2022 from $4,194 million in 2021.

[0001628280-23-004257:mdna:14]
•Operating income in 2022 was $656 million compared to $590 million in 2021.

[0001628280-23-004257:mdna:15]
•Net income in 2022 increased to $497 million from $464 million in 2021.

[0001628280-23-004257:mdna:16]
•Diluted earnings per share from continuing operations were $13.88 per share in 2022 compared to $12.39 per share in 2021.

[0001628280-23-004257:mdna:17]
•We generated $302 million of cash flow from operating activities in 2022 compared to $516 million in 2021.

[0001628280-23-004257:mdna:18]
•In 2022, we returned $142 million to shareholders through dividend payments and we used $300 million to purchase 1.3 million shares of stock under our Share Repurchase Plans.

[0001628280-23-004257:mdna:19]
Overview of Results

[0001628280-23-004257:mdna:20]
The Residential Heating & Cooling segment performed well in 2022, with a 15% increase in net sales and a $57 million increase in segment profit compared to 2021 primarily due to higher price and sales volumes.  Our Commercial Heating & Cooling segment saw an increase in net sales of 4% and a $30 million decrease in segment profit compared to 2021 primarily

[0001628280-23-004257:mdna:21]
due to increased product costs.  Sales in our Refrigeration segment increased 12% and segment profit increased $30 million compared to 2021 primarily due to higher price and sales volumes.

[0001628280-23-004257:mdna:22]
Results of Operations

[0001628280-23-004257:mdna:23]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001628280-23-004257:mdna:24]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 4,718.4 |  |  | 100.0 | % |  | $ | 4,194.1 |  |  | 100.0 | % |  | $ | 3,634.1 |  |  | 100.0 | % |
| Cost of goods sold | 3,433.7 |  |  | 72.8 | % |  | 3,005.7 |  |  | 71.7 | % |  | 2,594.0 |  |  | 71.4 | % |
| Gross profit | 1,284.7 |  |  | 27.2 | % |  | 1,188.4 |  |  | 28.3 | % |  | 1,040.1 |  |  | 28.6 | % |
| Selling, general and administrative expenses | 627.2 |  |  | 13.3 | % |  | 598.9 |  |  | 14.3 | % |  | 555.9 |  |  | 15.3 | % |
| Losses (gains) and other expenses, net | 4.9 |  |  | 0.1 | % |  | 9.2 |  |  | 0.2 | % |  | 7.4 |  |  | 0.2 | % |
| Restructuring charges | 1.5 |  |  | — | % |  | 1.8 |  |  | — | % |  | 10.8 |  | 0.3 | % |
| Loss from natural disasters, net of insurance recoveries | — |  |  | — | % |  | — |  |  | — | % |  | 3.1 |  |  | 0.1 | % |
| Income from equity method investments | (5.1) |  |  | (0.1) | % |  | (11.8) |  |  | (0.3) | % |  | (15.6) |  |  | (0.4) | % |
| Operating income | $ | 656.2 |  |  | 13.9 | % |  | $ | 590.3 |  |  | 14.1 | % |  | $ | 478.5 |  |  | 13.2 | % |
| Loss from discontinued operations | — |  |  | — | % |  | — |  |  | — | % |  | (0.8) |  |  | — | % |
| Net income | $ | 497.1 |  |  | 10.5 | % |  | $ | 464.0 |  |  | 11.1 | % |  | $ | 356.3 |  |  | 9.8 | % |

[0001628280-23-004257:mdna:25]
Year Ended December 31, 2022 Compared to Year Ended December 31, 2021 - Consolidated Results

[0001628280-23-004257:mdna:26]
Net Sales

[0001628280-23-004257:mdna:27]
Net sales increased 13% in 2022 compared to 2021, driven by higher price of 10%, product mix of 2%, and 2% higher sales volume.  Partially offsetting these increases was 1% due to unfavorable foreign currency.

[0001628280-23-004257:mdna:28]
Gross Profit

[0001628280-23-004257:mdna:29]
Gross profit margins for 2022 declined 110 basis points (“bps”) to 27.2% compared to 28.3% in 2021.  Gross profit margin decreased 240 bps from higher commodity costs, 170 bps from higher component costs, 140 bps from other product costs including LIFO, 90 bps from factory inefficiencies, 80 bps from higher freight and distribution costs, and 60 bps from product mix.  Partially offsetting these margin decreases were 650 bps from favorable price and 20 bps from lower product warranty costs.

[0001628280-23-004257:mdna:30]
Selling, General and Administrative Expenses

[0001628280-23-004257:mdna:31]
SG&A expenses increased by $28 million in 2022 compared to 2021.  As a percentage of net sales, SG&A expenses decreased 100 bps from 14.3% to 13.3% in the same periods primarily due to lower discretionary expenditures.

[0001628280-23-004257:mdna:32]
Losses (Gains) and Other Expenses, Net

[0001628280-23-004257:mdna:33]
Losses (gains) and other expenses, net for 2022 and 2021 included the following (in millions):

[0001628280-23-004257:mdna:34]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | (1.2) |  |
| Foreign currency exchange gains | (1.3) |  |  | (2.2) |  |
| Loss (gain) on disposal of fixed assets | (1.0) |  |  | (0.2) |  |
| Other operating income | (1.0) |  |  | (1.5) |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | 0.4 |  |  | — |  |
| Environmental liabilities and special litigation charges | 7.5 |  |  | 9.6 |  |
| Charges incurred related to COVID-19 pandemic | 0.8 |  |  | 2.2 |  |
| Other items, net | (0.6) |  |  | 2.5 |  |
| (Gains) losses and other expenses, net (pre-tax) | $ | 4.9 |  |  | $ | 9.2 |  |

[0001628280-23-004257:mdna:35]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 9 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange gains decreased in 2022 primarily due to changes in foreign exchange rates in our primary markets.  Environmental liabilities and special legal contingency charges in 2022 relate to estimated remediation costs at some of our facilities and outstanding legal settlements including asbestos.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.  The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and sanitization supplies to ensure the health and safety of our employees.

[0001628280-23-004257:mdna:36]
Restructuring Charges

[0001628280-23-004257:mdna:37]
Restructuring charges were $1.5 million in 2022 compared to $1.8 million in 2021. Charges in 2022 were related to ongoing cost reduction actions taken in prior years.   For more information on our restructuring activities, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001628280-23-004257:mdna:38]
Goodwill

[0001628280-23-004257:mdna:39]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2022.  We did not record any goodwill impairments in 2022 or 2021.  Refer to Note 9 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001628280-23-004257:mdna:40]
Asset Impairments

[0001628280-23-004257:mdna:41]
We did not have any impairments of assets in 2022 or 2021.

[0001628280-23-004257:mdna:42]
Pension Settlement

[0001628280-23-004257:mdna:43]
We did not have significant pension buyout activity in 2022 and 2021.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001628280-23-004257:mdna:44]
Income from Equity Method Investments

[0001628280-23-004257:mdna:45]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $5 million in 2022 compared to $12 million in 2021.  The decrease is due to lower operating results at the investees due to higher material costs.

[0001628280-23-004257:mdna:46]
Interest Expense, net

[0001628280-23-004257:mdna:47]
Net interest expense of $39 million in 2022 increased from $25 million in 2021 primarily due to higher borrowing costs.

[0001628280-23-004257:mdna:48]
Income Taxes

[0001628280-23-004257:mdna:49]
The income tax provision was $119 million in 2022 compared to $96 million in 2021, and the effective tax rate was 19.3% in 2022 compared to 17.2% in 2021.  The 2022 and 2021 effective tax rates differ from the statutory rate of 21% primarily due to foreign taxes. Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001628280-23-004257:mdna:50]
Year Ended December 31, 2022 Compared to Year Ended December 31, 2021 - Results by Segment

[0001628280-23-004257:mdna:51]
Residential Heating & Cooling

[0001628280-23-004257:mdna:52]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2022 and 2021 (dollars in millions):

[0001628280-23-004257:mdna:53]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 3,198.3 |  |  | $ | 2,775.6 |  |  | $ | 422.7 |  |  | 15% |
| Profit | $ | 596.9 |  |  | $ | 540.3 |  |  | $ | 56.6 |  |  | 10% |
| % of net sales | 18.7 | % |  | 19.5 | % |  |  |  |  |

[0001628280-23-004257:mdna:54]
Residential Heating & Cooling net sales increased 15% in 2022 compared to 2021 due to an increase in price of 11%, an increase in sales volume of 4%, and 1% from product mix.  Partially offsetting these increases was 1% from unfavorable foreign currency.

[0001628280-23-004257:mdna:55]
Segment profit in 2022 increased $57 million compared to 2021 due to $297 million from higher price, $33 million from higher sales volume, and $9 million from lower product warranty costs.  Partially offsetting these increases were $85 million from higher commodity costs, $49 million from higher component costs, $47 million higher other product costs including LIFO, unfavorable product mix of $34 million, $33 million from higher freight and distribution charges, $20 million from higher SG&A costs, $7 million from factory inefficiencies, $5 million from unfavorable foreign currency, and $2 million from miscellaneous other items.

[0001628280-23-004257:mdna:56]
Commercial Heating & Cooling

[0001628280-23-004257:mdna:57]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2022 and 2021 (dollars in millions):

[0001628280-23-004257:mdna:58]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 900.7 |  |  | $ | 864.8 |  |  | $ | 35.9 |  |  | 4 | % |
| Profit | $ | 80.9 |  |  | $ | 110.9 |  |  | $ | (30.0) |  |  | (27) | % |
| % of net sales | 9.0 | % |  | 12.8 | % |  |  |  |  |

[0001628280-23-004257:mdna:59]
Commercial Heating & Cooling net sales increased 4% in 2022 compared to 2021 due to an increase in price of 7% and 7% from product mix. Partially offsetting these increases were lower sales volume of 9% and unfavorable foreign currency of 1%.

[0001628280-23-004257:mdna:60]
Segment profit in 2022 decreased $30 million compared to 2021 due to $28 million from factory inefficiencies, $25 million from lower sales volume, $21 million from higher component costs, $20 million from higher other product costs including LIFO, $13 million from higher commodity costs, $8 million from higher SG&A costs, and $2 million from higher freight and distribution charges.  Partially offsetting these decreases were $61 million from higher price, $24 million from favorable product mix, and $2 million from lower product warranty costs.

[0001628280-23-004257:mdna:61]
Refrigeration

[0001628280-23-004257:mdna:62]
The following table presents our Refrigeration segment’s net sales and profit for 2022 and 2021 (dollars in millions):

[0001628280-23-004257:mdna:63]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 619.4 |  |  | $ | 553.7 |  |  | $ | 65.7 |  |  | 12 | % |
| Profit | $ | 78.8 |  |  | $ | 49.1 |  |  | $ | 29.7 |  |  | 60 | % |
| % of net sales | 12.7 | % |  | 8.9 | % |  |  |  |  |

[0001628280-23-004257:mdna:64]
Net sales increased 12% in 2022 compared to 2021 due to a 13% increase in price, 3% increase in sales volume, and 1% from product mix.  Partially offsetting these increases was unfavorable foreign currency of 5%.

[0001628280-23-004257:mdna:65]
Segment profit in 2022 increased $30 million compared to 2021 due to $70 million from higher price, $7 million from favorable product mix, and $7 million from higher sales volume.  Partially offsetting these increases were $17 million from higher commodity costs, $12 million from higher component costs, $12 million from higher SG&A, $7 million from factory inefficiencies, $4 million from higher freight and distribution costs, and $2 million from higher other product costs.

[0001628280-23-004257:mdna:66]
In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses.  We will continue to invest in our Heatcraft Worldwide Refrigeration business which will become part of the Commercial Heating & Cooling segment beginning in 2023. The European portfolio will be presented with Corporate and Other beginning in 2023 until disposition.  As we will manage the businesses in this manner beginning in 2023, we will present the financial results of the revised segments beginning in 2023. The European portfolio realized net sales of $234 million in 2022 and $230 million in 2021 and generated losses of $3 million and $5 million for 2022 and 2021, respectively.

[0001628280-23-004257:mdna:67]
Corporate and Other

[0001628280-23-004257:mdna:68]
Corporate and other expenses decreased by $6 million in 2022 compared to 2021 primarily due to lower incentive compensation costs.

[0001628280-23-004257:mdna:69]
Year Ended December 31, 2021 Compared to Year Ended December 31, 2020 - Consolidated Results

[0001628280-23-004257:mdna:70]
Net Sales

[0001628280-23-004257:mdna:71]
Net sales increased 15% in 2021 compared to 2020, driven by higher sales volumes of 11% and an improved combined price and mix of 4%. The increases in volume, price and mix were due to strong demand across all three of our business segments.

[0001628280-23-004257:mdna:72]
Gross Profit

[0001628280-23-004257:mdna:73]
Gross profit margins for 2021 decreased 30 basis points (“bps”) to 28.3% compared to 28.6% in 2020.  Gross profit margin decreased 180 bps from higher commodity costs, 90 bps from other product costs, 20 bps from higher freight and distribution costs, and 10 bps for lower factory efficiency.  Partially offsetting these cost increases was 270 bps from favorable combined price and mix.

[0001628280-23-004257:mdna:74]
Selling, General and Administrative Expenses

[0001628280-23-004257:mdna:75]
SG&A expenses increased by $43 million in 2021 compared to 2020.  As a percentage of net sales, SG&A expenses decreased 100 bps from 15.3% to 14.3% in the same periods primarily due to lower discretionary expenditures.

[0001628280-23-004257:mdna:76]
Losses (Gains) and Other Expenses, Net

[0001628280-23-004257:mdna:77]
Losses (gains) and other expenses, net for 2021 and 2020 included the following (in millions):

[0001628280-23-004257:mdna:78]
|  | For the Years Ended December 31, |
|  | 2021 |  | 2020 |
| Realized (gains) losses on settled futures contracts | $ | (1.2) |  |  | $ | 0.1 |  |
| Foreign currency exchange gains | (2.2) |  |  | (3.6) |  |
| Gain on disposal of fixed assets | (0.2) |  |  | (0.2) |  |
| Other operating income | (1.5) |  |  | (2.2) |  |
| Net change in unrealized gains on unsettled futures contracts | — |  |  | (0.3) |  |
| Environmental liabilities and special litigation charges | 9.6 |  |  | 5.3 |  |
| Charges incurred related to COVID-19 pandemic | 2.2 |  |  | 8.3 |  |
| Other items, net | 2.5 |  |  | — |  |
| Losses (gains) and other expenses, net | $ | 9.2 |  |  | $ | 7.4 |  |

[0001628280-23-004257:mdna:79]
The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and sanitization supplies to ensure the health and safety of our employees.  The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001628280-23-004257:mdna:80]
Foreign currency exchange gains decreased in 2021 primarily due to weakening in foreign exchange rates in our primary markets.  The special legal contingency charges in 2021 relate to outstanding legal settlements.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001628280-23-004257:mdna:81]
Restructuring Charges

[0001628280-23-004257:mdna:82]
Restructuring charges were $1.8 million in 2021 compared to $10.8 million in 2020. Charges in 2021 were related to ongoing cost reduction actions taken in prior years.  The charges in 2020 related primarily to several cost reduction actions taken in response to the economic impact of the COVID-19 pandemic on our business.  These actions consisted of employee terminations for positions that were no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities.  For more information on our restructuring activities, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001628280-23-004257:mdna:83]
Goodwill

[0001628280-23-004257:mdna:84]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2021.  We did not record any goodwill impairments in 2021 or 2020.  Refer to Note 9 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001628280-23-004257:mdna:85]
Asset Impairments

[0001628280-23-004257:mdna:86]
We did not have any impairments of assets in 2021 or 2020.

[0001628280-23-004257:mdna:87]
Pension Settlement

[0001628280-23-004257:mdna:88]
We did not have significant pension buyout activity in 2021 and 2020.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001628280-23-004257:mdna:89]
Income from Equity Method Investments

[0001628280-23-004257:mdna:90]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $12 million in 2021 compared to $16 million in 2020.  The decrease is due to rising production costs at the joint ventures.

[0001628280-23-004257:mdna:91]
Interest Expense, net

[0001628280-23-004257:mdna:92]
Net interest expense of $25 million in 2021 decreased from $28 million in 2020 primarily due to lower borrowing and lower borrowing costs.

[0001628280-23-004257:mdna:93]
Income Taxes

[0001628280-23-004257:mdna:94]
The income tax provision was $96 million in 2021 compared to $88 million in 2020, and the effective tax rate was 17.2% in 2021 compared to 19.8% in 2020.  The 2021 and 2020 effective tax rates differ from the statutory rate of 21% primarily due to state and foreign taxes. Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001628280-23-004257:mdna:95]
Year Ended December 31, 2021 Compared to Year Ended December 31, 2020 - Results by Segment

[0001628280-23-004257:mdna:96]
Residential Heating & Cooling

[0001628280-23-004257:mdna:97]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2021 and 2020 (dollars in millions):

[0001628280-23-004257:mdna:98]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 2,775.6 |  |  | $ | 2,361.5 |  |  | $ | 414.1 |  |  | 18% |
| Profit | $ | 540.3 |  |  | $ | 428.5 |  |  | $ | 111.8 |  |  | 26% |
| % of net sales | 19.5 | % |  | 18.1 | % |  |  |  |  |

[0001628280-23-004257:mdna:99]
Residential Heating & Cooling net sales increased 18% in 2021 compared to 2020. Sales volume increased 13%, price increased 5% and favorable foreign currency exchange rates caused an increase of 1%.  Partially offsetting these increases was a 1% reduction due to unfavorable product mix.

[0001628280-23-004257:mdna:100]
Segment profit in 2021 increased $112 million compared to 2020 due to $108 million from favorable pricing, $91 million from higher sales volume, $9 million from favorable foreign currency exchange, $5 million from higher factory productivity, and $2 million from sourcing and engineering-led cost reductions.  Partially offsetting these increases were $59 million from commodity costs, $20 million from higher warranty and other product costs, $14 million from higher SG&A, $5 million from unfavorable product mix, and $5 million from lower income from equity method investments.

[0001628280-23-004257:mdna:101]
Commercial Heating & Cooling

[0001628280-23-004257:mdna:102]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2021 and 2020 (dollars in millions):

[0001628280-23-004257:mdna:103]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 864.8 |  |  | $ | 800.9 |  |  | $ | 63.9 |  |  | 8 | % |
| Profit | $ | 110.9 |  |  | $ | 136.9 |  |  | $ | (26.0) |  |  | (19) | % |
| % of net sales | 12.8 | % |  | 17.1 | % |  |  |  |  |

[0001628280-23-004257:mdna:104]
Commercial Heating & Cooling net sales increased 8% in 2021 compared to 2020.  Price and mix combined increased 4%, sales volume was 3% higher, and foreign currency improved 1%.

[0001628280-23-004257:mdna:105]
Segment profit in 2021 decreased $26 million compared to 2020 due to $17 million from higher other product costs, $14 million from factory inefficiencies, $6 million from sourcing and engineering-led cost increases, $6 million from higher commodity costs, $6 million from higher freight and distribution costs, $4 million from higher SG&A costs, and $1 million from unfavorable foreign currency. Partially offsetting these declines was a favorable increase in combined price and mix of $19 million and $9 million from higher sales volume.

[0001628280-23-004257:mdna:106]
Refrigeration

[0001628280-23-004257:mdna:107]
The following table presents our Refrigeration segment’s net sales and profit for 2021 and 2020 (dollars in millions):

[0001628280-23-004257:mdna:108]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 553.7 |  |  | $ | 471.7 |  |  | $ | 82.0 |  |  | 17 | % |
| Profit | $ | 49.1 |  |  | $ | 32.8 |  |  | $ | 16.3 |  |  | 50 | % |
| % of net sales | 8.9 | % |  | 7.0 | % |  |  |  |  |

[0001628280-23-004257:mdna:109]
Net sales increased 17% in 2021 compared to 2020. Sales volume increased 14%, price increased 3%, and foreign currency improved 1%.  Partially offsetting these increases was a 1% reduction due to unfavorable mix.

[0001628280-23-004257:mdna:110]
Segment profit in 2021 increased $16 million compared to 2020 due to $23 million from higher sales volume, $13 million from higher price, $3 million from higher factory productivity, and $1 million from higher income from equity method investments. Partially offsetting these increases were $10 million from higher SG&A, $8 million from higher commodity costs, $2 million from higher other product costs, $2 million from unfavorable product mix, and $2 million from higher freight and distribution costs.

[0001628280-23-004257:mdna:111]
In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses.  We will continue to invest in our Heatcraft Worldwide Refrigeration business which will become part of the Commercial Heating & Cooling segment beginning in 2023 and the European portfolio will be presented with Corporate and Other beginning in 2023 until disposition.  As we will manage the businesses in this manner beginning in 2023, we will present the financial results of the revised segments beginning in 2023.  The European portfolio realized net sales of $230 million in 2021 and $214 million in 2020 and generated losses of $5 million for both 2021 and 2020.

[0001628280-23-004257:mdna:112]
Corporate and Other

[0001628280-23-004257:mdna:113]
Corporate and other expenses increased by $5 million in 2021 compared to 2020 primarily due to increased headcount and increases in incentive compensation costs.

[0001628280-23-004257:mdna:114]
Accounting for Futures Contracts

[0001628280-23-004257:mdna:115]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 9 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 3 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to operating income.

[0001628280-23-004257:mdna:116]
Liquidity and Capital Resources

[0001628280-23-004257:mdna:117]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001628280-23-004257:mdna:118]
Statement of Cash Flows

[0001628280-23-004257:mdna:119]
The following table summarizes our cash flow activity for the years ended December 31, 2022, 2021 and 2020 (in millions):

[0001628280-23-004257:mdna:120]
|  | 2022 |  | 2021 |  | 2020 |
| Net cash provided by operating activities | $ | 302.3 |  |  | $ | 515.5 |  |  | $ | 612.4 |  |
| Net cash used in investing activities | (103.0) |  |  | (106.4) |  |  | (79.7) |  |
| Net cash used in financing activities | $ | (174.1) |  |  | $ | (498.7) |  |  | $ | (441.8) |  |

[0001628280-23-004257:mdna:121]
Net Cash Provided By Operating Activities - Net cash provided by operating activities activities decreased $214 million to $302 million in 2022 compared to $516 million in 2021.  The decrease was primarily attributable to increases in working capital including a $249 million increase in inventory due to investments to replenish  finished goods ahead of the minimum-

[0001628280-23-004257:mdna:122]
efficiency regulatory changes and in raw material to increase supply chain resiliency and a $112 million increase in accounts and notes receivable due to higher sales volume.  Partially offsetting the increased working capital was an increase in net income.

[0001628280-23-004257:mdna:123]
Net Cash Used In Investing Activities -  Net cash used in investing activities decreased $3 million from 2021 to 2022 primarily due to lower capital expenditures. Capital expenditures were $101 million, $107 million and $79 million in 2022, 2021 and 2020, respectively.  Capital expenditures in 2022 were primarily related to the expansion of our manufacturing capacity including investments in our Commercial factory in Mexico, equipment, and investments in systems and software to support the overall enterprise.

[0001628280-23-004257:mdna:124]
Net Cash Used In Financing Activities - Net cash used in financing activities was $174 million in 2022 and $499 million in 2021.  The decrease is primarily due to a decrease in share repurchases in 2022 which was partially offset by an increase in net borrowings and repayments on debt.  During 2022 we repurchased $300 million of shares compared to $600 million of shares in 2021.  We also returned $142 million to shareholders through dividend payments in 2022.  For additional information on share repurchases, refer to Note 6 in the Notes to the Consolidated Financial Statements.

[0001628280-23-004257:mdna:125]
Debt Position

[0001628280-23-004257:mdna:126]
The following table details our lines of credit and financing arrangements as of December 31, 2022 (in millions):

[0001628280-23-004257:mdna:127]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (1) | $ | 350.0 |  |
| Finance lease obligations | 11.2 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (0.6) |  |
| Total current maturities of long-term debt | $ | 710.6 |  |
| Long-term debt: |  |
| Finance lease obligations | 28.3 |  |
| Credit agreement (2) | 192.0 |  |
| Senior unsecured notes | 600.0 |  |
| Debt issuance costs | (6.1) |  |
| Total long-term debt | 814.2 |  |
| Total debt | $ | 1,524.8 |  |

[0001628280-23-004257:mdna:128]
(1)The maximum securitization amount ranges from $300.0 million to $450.0 million, depending on the period. The maximum capacity of the Asset Securitization Program (“ASP”) is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 13 in the Notes to the Consolidated Financial Statements for more details.

[0001628280-23-004257:mdna:129]
(2)The total capacity on the facility is $750.0 million.  The amount available future borrowings on our Credit Agreement is $556 million after being reduced by the outstanding borrowings and $2 million in outstanding standby letters of credit as of December 31, 2022.

[0001628280-23-004257:mdna:130]
Both our Asset Securitization Program as well as our $350.0 million 2023 Notes will mature in 2023. We are currently evaluating our options related to these obligations including refinancing and other alternatives. We do not believe that our options or alternatives will have any material impact on our results of operations or liquidity.

[0001628280-23-004257:mdna:131]
Credit Agreement

[0001628280-23-004257:mdna:132]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-23-004257:mdna:133]
The Credit Agreement provides for revolving credit commitments of $750 million with sublimits for swingline loans of up to $65 million, letters of credit up to $100 million and revolving loans in certain non-U.S. currencies up to the U.S. dollar equivalent of $40 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement. At our request and subject to certain conditions, the revolving credit commitments under the Credit Agreement may be increased by up to a total of $350 million to the extent that existing or new lenders agree to provide additional commitments.

[0001628280-23-004257:mdna:134]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of its assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control.  As of December 31, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-23-004257:mdna:135]
Financial Leverage

[0001628280-23-004257:mdna:136]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001628280-23-004257:mdna:137]
We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our Share Repurchase Plans.  Our book value of debt-to-total-capital ratio decreased to 115% at December 31, 2022 compared to 128% at December 31, 2021.

[0001628280-23-004257:mdna:138]
As of December 31, 2022, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody’s Investors Service, Inc. (“Moody’s”) and Standard & Poor’s Rating Group (“S&P”), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody’s and S&P to help ensure the capital markets remain available to us.

[0001628280-23-004257:mdna:139]
Liquidity

[0001628280-23-004257:mdna:140]
We believe our cash and cash equivalents of $53 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents as of December 31, 2022 was $23 million of cash held in foreign locations, although that amount can fluctuate significantly depending on the timing of cash receipts and payments.  Our cash and cash equivalents held in foreign locations is generally available for use in our U.S. operations and could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-23-004257:mdna:141]
No contributions are required to be made to our U.S. defined benefit plans in 2023. We made $22.5 million in total contributions to pension plans in 2022.

[0001628280-23-004257:mdna:142]
Dividend payments were $142 million in 2022 compared to $127 million in 2021. On May 19, 2022, our Board of Directors approved a 15% increase in our quarterly dividend on common stock from $0.92 to $1.06 per share effective with the July 2022 dividend payment.

[0001628280-23-004257:mdna:143]
We also continued to increase shareholder value through our Share Repurchase Plans.  We returned $300 million to our investors through share repurchases in 2022. Our Board of Directors authorized an incremental $1.0 billion of share repurchases in July 2021, and we had $546 million of repurchases available under the Share Repurchase Plans at December 31, 2022. We expect to repurchase $200 million of shares in 2023.

[0001628280-23-004257:mdna:144]
We expect capital expenditures of approximately $250 million in 2023.

[0001628280-23-004257:mdna:145]
Financial Covenants related to our Debt

[0001628280-23-004257:mdna:146]
Our Credit Agreement is guaranteed by certain of our subsidiaries and contains a financial covenant relating to leverage.  Other covenants contained in the our Credit Agreement restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenant requires us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio of no greater than 3.5 : 1.0.

[0001628280-23-004257:mdna:147]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001628280-23-004257:mdna:148]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-23-004257:mdna:149]
•We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-23-004257:mdna:150]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-23-004257:mdna:151]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001628280-23-004257:mdna:152]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee payment by us of any indebtedness under our Credit Agreement.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001628280-23-004257:mdna:153]
As of December 31, 2022, we believe we were in compliance with all covenant requirements. Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared and/or the preceding fiscal year.  In addition, stock repurchases can only be made out of surplus and only if our capital would not be impaired.

[0001628280-23-004257:mdna:154]
Leasing Commitments

[0001628280-23-004257:mdna:155]
Refer to Note 5 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001628280-23-004257:mdna:156]
Guarantees related to our Debt Obligations

[0001628280-23-004257:mdna:157]
Our senior unsecured notes were issued by Lennox International Inc. (the “Parent”) and are unconditionally guaranteed by certain of our subsidiaries (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries.  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001628280-23-004257:mdna:158]
Off Balance Sheet Arrangements

[0001628280-23-004257:mdna:159]
We have no off-balance sheet arrangements that we believe may have a material current or future effect on our financial condition, liquidity or results of operations.

[0001628280-23-004257:mdna:160]
Contractual Obligations

[0001628280-23-004257:mdna:161]
Contractual obligations arise in the normal course of business and include debt and related interest payments, leases, purchase obligations, pension and post-retirement benefits and warranty liabilities.  For additional information regarding our contractual obligations, see Note 5 of the Notes to the Consolidated Financial Statements.  See Note 10 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.  See Note 13 of the Notes to the Consolidated Financial Statements for more information on our debt obligations.

[0001628280-23-004257:mdna:162]
Fair Value Measurements

[0001628280-23-004257:mdna:163]
Fair value is the price that would be received to sell an asset or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001628280-23-004257:mdna:164]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001628280-23-004257:mdna:165]
Level 1 -          Quoted prices for identical instruments in active markets at the measurement date.

[0001628280-23-004257:mdna:166]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001628280-23-004257:mdna:167]
Level 3 -     Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001628280-23-004257:mdna:168]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2022 and 2021, the measurement dates.  See Note 16 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001628280-23-004257:mdna:169]
Market Risk

[0001628280-23-004257:mdna:170]
Commodity Price Risk

[0001628280-23-004257:mdna:171]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001628280-23-004257:mdna:172]
| Notional amount (pounds of aluminum and copper) | 56.6 |  |
| Carrying amount and fair value of net asset | $ | (7.5) |  |
| Change in fair value from 10% change in forward prices | $ | 10.1 |  |

[0001628280-23-004257:mdna:173]
Refer to Note 9 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001628280-23-004257:mdna:174]
Interest Rate Risk

[0001628280-23-004257:mdna:175]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $1.7 million, $0.4 million and $1.3 million for the years ended December 31, 2022, 2021 and 2020, respectively.

[0001628280-23-004257:mdna:176]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2022 and 2021, no interest rate swaps were in effect.

[0001628280-23-004257:mdna:177]
Foreign Currency Exchange Rate Risk

[0001628280-23-004257:mdna:178]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  Our primary exposure to foreign currencies are the Canadian dollar, Mexican Peso, and the Euro.  During 2022, 2021 and 2020, net sales from outside the U.S. represented 11.4%, 13.1% and 13.0%, respectively, of our total net sales.  For the years ended December 31, 2022,  2021, and 2020, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $3.5 million, $2.7 million and $0.6 million impact to net income for the years ended December 31, 2022, 2021 and 2020, respectively.

[0001628280-23-004257:mdna:179]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 9 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001628280-23-004257:mdna:180]
Critical Accounting Estimates

[0001628280-23-004257:mdna:181]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following describes our critical accounting estimate related to product warranties and product-related contingencies and how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements. This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001628280-23-004257:mdna:182]
Product Warranties and Product-Related Contingencies

[0001628280-23-004257:mdna:183]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.

[0001628280-23-004257:mdna:184]
From time to time, we may also incur costs to repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.  These product-related costs may not be covered under our warranties and are not covered by insurance.

[0001628280-23-004257:mdna:185]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 5 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001628280-23-004257:mdna:186]
Recent Accounting Pronouncements

[0001628280-23-004257:mdna:187]
See Note 2 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
