# LII notes — 0001628280-23-004257


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-23-004257:notes:1]
DOCUMENTS INCORPORATED BY REFERENCEPortions of the registrant’s 2022 Definitive Proxy Statement to be filed with the Securities and Exchange Commission in connection with the registrant’s 2022 Annual Meeting of Stockholders to be held on May 18, 2023 are incorporated by reference into Part III of this report.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-23-004257:notes:2]
Principles of Consolidation

[0001628280-23-004257:notes:3]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.

[0001628280-23-004257:notes:4]
Cash and Cash Equivalents

[0001628280-23-004257:notes:5]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.

[0001628280-23-004257:notes:6]
Short term Investments

[0001628280-23-004257:notes:7]
Short-term investments include all investments, exclusive of cash equivalents, with a stated maturity date of one year or less from the balance sheet date and are expected to be used in current operations.

[0001628280-23-004257:notes:8]
Accounts and Notes Receivable

[0001628280-23-004257:notes:9]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheet, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management’s judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management’s review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.

[0001628280-23-004257:notes:10]
Inventories

[0001628280-23-004257:notes:11]
Inventory costs include material, labor, and capitalized overhead.  Inventories of $465.5 million and $302.2 million as of December 31, 2022 and 2021, respectively, were valued at the lower of cost or net realizable value using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or net realizable value with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001628280-23-004257:notes:12]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 9 for more information on our inventories.

[0001628280-23-004257:notes:13]
Property, Plant and Equipment

[0001628280-23-004257:notes:14]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001628280-23-004257:notes:15]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001628280-23-004257:notes:16]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 40 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 5 years |
| Vehicles | 3 to 10 years |

[0001628280-23-004257:notes:17]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 9 for additional information on our property, plant and equipment.

[0001628280-23-004257:notes:18]
Goodwill

[0001628280-23-004257:notes:19]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually during the third quarter and whenever events or changes in circumstances indicate the asset may be impaired.  See Note 9 for additional information on our goodwill.

[0001628280-23-004257:notes:20]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001628280-23-004257:notes:21]
If a quantitative goodwill impairment test is determined to be necessary, we estimate reporting unit fair values using a combination of the discounted cash flow approach and a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. The market approach is based on objective evidence of market values.

[0001628280-23-004257:notes:22]
Product Warranties

[0001628280-23-004257:notes:23]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded in cost of goods sold on the date that revenue is recognized. Our estimates of future warranty costs are determined by product category. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. In most cases, the estimated units to be repaired under warranty are multiplied by the estimated cost of replacement parts to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 5 for more information on our estimated future warranty costs.

[0001628280-23-004257:notes:24]
Pensions and Post-retirement Benefits

[0001628280-23-004257:notes:25]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheet.  Changes in the funded status are recognized in the year in which the changes occur through Accumulated other comprehensive loss (“AOCL”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001628280-23-004257:notes:26]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management’s estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 10 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001628280-23-004257:notes:27]
Self-Insurance

[0001628280-23-004257:notes:28]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information, industry factors, and trends.  The self-insurance liabilities as of December 31, 2022 represent the best estimate of the future payments to be made on reported and unreported losses for 2022 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 5 for additional information on our self-insured risks and liabilities.

[0001628280-23-004257:notes:29]
Derivatives

[0001628280-23-004257:notes:30]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheet at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 9 for more information on our derivatives.

[0001628280-23-004257:notes:31]
Leases

[0001628280-23-004257:notes:32]
We lease certain real and personal property under non-cancelable leases including real estate, IT equipment, fleet vehicles and manufacturing and distribution equipment.  At inception of the lease, we determine a lease exists if the contract conveys the right to control an identified asset for a period of time in exchange for consideration.  Control is considered to exist when the lessee has the right to obtain substantially all the economic benefits from the use of an identified asset as well as the right to direct the use of the asset.  If a contract is considered to be a lease, we recognize a lease liability based on the present value of the future minimum lease payments and a right-of-use asset.  For contracts that are 12 months or less, we do not to recognize a right-of-use asset or liability.  We do not separate non-lease components from the lease components to which they relate and account for the combined lease and non-lease components as a single lease component.

[0001628280-23-004257:notes:33]
Income Taxes

[0001628280-23-004257:notes:34]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 12 for more information related to income taxes.

[0001628280-23-004257:notes:35]
Revenue Recognition

[0001628280-23-004257:notes:36]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience

[0001628280-23-004257:notes:37]
returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.  See Note 8 for more information on our revenue recognition practices.

[0001628280-23-004257:notes:38]
Cost of Goods Sold

[0001628280-23-004257:notes:39]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense, and freight and distribution costs.

[0001628280-23-004257:notes:40]
Selling, General and Administrative Expenses

[0001628280-23-004257:notes:41]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation, and rent.

[0001628280-23-004257:notes:42]
Stock-Based Compensation

[0001628280-23-004257:notes:43]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs based on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 15 for more information.

[0001628280-23-004257:notes:44]
Translation of Foreign Currencies

[0001628280-23-004257:notes:45]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCL in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.

[0001628280-23-004257:notes:46]
Use of Estimates

[0001628280-23-004257:notes:47]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001628280-23-004257:notes:48]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001628280-23-004257:notes:49]
Impact of COVID-19 Pandemic

[0001628280-23-004257:notes:50]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world.  The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations since 2020.  We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-23-004257:notes:51]
Components of Property, plant and equipment, net were as follows (in millions):

[0001628280-23-004257:notes:52]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Land | $ | 24.1 |  |  | $ | 24.0 |  |
| Buildings and improvements | 321.6 |  |  | 285.9 |  |
| Machinery and equipment | 964.7 |  |  | 946.5 |  |
| Finance leases | 66.5 |  |  | 63.5 |  |
| Construction in progress and equipment not yet in service | 92.8 |  |  | 84.0 |  |
| Total | 1,469.7 |  |  | 1,403.9 |  |
| Less accumulated depreciation | (920.8) |  |  | (888.8) |  |
| Property, plant and equipment, net | $ | 548.9 |  |  | $ | 515.1 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-23-004257:notes:53]
scription of Segments
We operate in three reportable business segments of the HVACR industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001628280-23-004257:notes:54]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products |  | Light Commercial |  | United StatesCanada |
| Refrigeration(1) |  | Condensing units, unit coolers, fluid coolers, air- cooled condensers, air handlers, process chillers, controls, and compressorized racks |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEurope |

[0001628280-23-004257:notes:55]
(1) In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses.  We will continue to invest in our Heatcraft Worldwide Refrigeration business which will become part of the Commercial Heating & Cooling segment beginning in 2023 and the European portfolio will be presented with Corporate and Other beginning in 2023 until disposition.  As we will manage the businesses in this manner beginning in 2023, we will present the financial results of the revised segments beginning in 2023.

[0001628280-23-004257:notes:56]
Segment Data

[0001628280-23-004257:notes:57]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001628280-23-004257:notes:58]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term, share-based incentive awards provided to employees throughout our business.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001628280-23-004257:notes:59]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001628280-23-004257:notes:60]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001628280-23-004257:notes:61]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 3,198.3 |  |  | $ | 2,775.6 |  |  | $ | 2,361.5 |  |
| Commercial Heating & Cooling | 900.7 |  |  | 864.8 |  |  | 800.9 |  |
| Refrigeration | 619.4 |  |  | 553.7 |  |  | 471.7 |  |
|  | $ | 4,718.4 |  |  | $ | 4,194.1 |  |  | $ | 3,634.1 |  |
| Segment profit (loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 596.9 |  |  | $ | 540.3 |  |  | $ | 428.5 |  |
| Commercial Heating & Cooling | 80.9 |  |  | 110.9 |  |  | 136.9 |  |
| Refrigeration | 78.8 |  |  | 49.1 |  |  | 32.8 |  |
| Corporate and other | (90.8) |  |  | (96.4) |  |  | (91.5) |  |
| Total segment profit | 665.8 |  |  | 603.9 |  |  | 506.7 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| Special product quality adjustments | — |  |  | (2.5) |  |  | 1.0 |  |
| Loss from natural disasters, net of insurance recoveries | — |  |  | — |  |  | 3.1 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 8.1 |  |  | 14.3 |  |  | 13.3 |  |
| Restructuring charges | 1.5 |  |  | 1.8 |  |  | 10.8 |  |
| Operating income | $ | 656.2 |  |  | $ | 590.3 |  |  | $ | 478.5 |  |

[0001628280-23-004257:notes:62]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001628280-23-004257:notes:63]
(2) We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-23-004257:notes:64]
•The following items in (Gains) losses and other expenses, net:

[0001628280-23-004257:notes:65]
◦Net change in unrealized (gains) losses on unsettled futures contracts,

[0001628280-23-004257:notes:66]
◦Environmental liabilities and special litigation charges,

[0001628280-23-004257:notes:67]
◦Charges incurred related to COVID-19 pandemic, and

[0001628280-23-004257:notes:68]
◦Other items, net,

[0001628280-23-004257:notes:69]
•Special product quality adjustments

[0001628280-23-004257:notes:70]
•Loss from natural disasters, net of insurance recoveries

[0001628280-23-004257:notes:71]
•Restructuring charges, and

[0001628280-23-004257:notes:72]
Total assets by segment are shown below (in millions):

[0001628280-23-004257:notes:73]
|  | As of December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 1,456.4 |  |  | $ | 1,149.7 |  |  | $ | 1,034.6 |  |
| Commercial Heating & Cooling | 456.4 |  |  | 366.2 |  |  | 366.5 |  |
| Refrigeration | 443.6 |  |  | 426.6 |  |  | 387.9 |  |
| Corporate and other | 211.2 |  |  | 229.4 |  |  | 243.5 |  |
| Total assets | $ | 2,567.6 |  |  | $ | 2,171.9 |  |  | $ | 2,032.5 |  |

[0001628280-23-004257:notes:74]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001628280-23-004257:notes:75]
Total capital expenditures by segment are shown below (in millions):

[0001628280-23-004257:notes:76]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 42.4 |  |  | $ | 70.0 |  |  | $ | 44.0 |  |
| Commercial Heating & Cooling | 21.5 |  |  | 4.3 |  |  | 5.9 |  |
| Refrigeration | 11.2 |  |  | 11.5 |  |  | 9.2 |  |
| Corporate and other | 26.0 |  |  | 21.0 |  |  | 19.4 |  |
| Total capital expenditures | $ | 101.1 |  |  | $ | 106.8 |  |  | $ | 78.5 |  |

[0001628280-23-004257:notes:77]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001628280-23-004257:notes:78]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 31.5 |  |  | $ | 27.6 |  |  | $ | 28.5 |  |
| Commercial Heating & Cooling | 12.9 |  |  | 13.2 |  |  | 13.5 |  |
| Refrigeration | 9.1 |  |  | 7.8 |  |  | 7.8 |  |
| Corporate and other | 24.4 |  |  | 23.8 |  |  | 22.8 |  |
| Total depreciation and amortization | $ | 77.9 |  |  | $ | 72.4 |  |  | $ | 72.6 |  |

[0001628280-23-004257:notes:79]
The equity method investments are shown below (in millions):

[0001628280-23-004257:notes:80]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 0.9 |  |  | $ | 6.9 |  |  | $ | 11.4 |  |
| Commercial Heating & Cooling | 0.2 |  |  | 1.2 |  |  | 2.3 |  |
| Refrigeration | 4.0 |  |  | 3.7 |  |  | 1.9 |  |
| Total income from equity method investments | $ | 5.1 |  |  | $ | 11.8 |  |  | $ | 15.6 |  |

[0001628280-23-004257:notes:81]
Geographic Information

[0001628280-23-004257:notes:82]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001628280-23-004257:notes:83]
|  | As of December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 408.8 |  |  | $ | 381.0 |  |  | $ | 352.9 |  |
| Mexico | 110.9 |  |  | 102.7 |  |  | 79.2 |  |
| Canada | 2.1 |  |  | 2.1 |  |  | 2.2 |  |
| Other international | 27.1 |  |  | 29.3 |  |  | 30.0 |  |
| Total Property, plant and equipment, net | $ | 548.9 |  |  | $ | 515.1 |  |  | $ | 464.3 |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-004257:notes:84]
sic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001628280-23-004257:notes:85]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Net income | $ | 497.1 |  |  | $ | 464.0 |  |  | $ | 356.3 |  |
| Add: Loss from discontinued operations | — |  |  | — |  |  | 0.8 |  |
| Income from continuing operations | $ | 497.1 |  |  | $ | 464.0 |  |  | $ | 357.1 |  |
| Weighted-average shares outstanding – basic | 35.7 |  |  | 37.2 |  |  | 38.3 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Weighted-average shares outstanding – diluted | 35.8 |  |  | 37.5 |  |  | 38.6 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 13.92 |  |  | $ | 12.47 |  |  | $ | 9.32 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.02) |  |
| Net income | $ | 13.92 |  |  | $ | 12.47 |  |  | $ | 9.30 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 13.88 |  |  | $ | 12.39 |  |  | $ | 9.26 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.02) |  |
| Net income | $ | 13.88 |  |  | $ | 12.39 |  |  | $ | 9.24 |  |

[0001628280-23-004257:notes:86]
There were 0.3 million securities in 2022 that were outstanding but not included in the diluted earnings per share calculation as the assumed exercise of such rights would have been anti-dilutive.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-23-004257:notes:87]
We lease certain real and personal property under non-cancelable leases.  Approximately 81% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001628280-23-004257:notes:88]
The components of lease expense were as follows (in millions):

[0001628280-23-004257:notes:89]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Finance lease cost: |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 13.2 |  |  | $ | 11.9 |  |  | $ | 10.3 |  |
| Interest on lease liabilities | 0.7 |  |  | 0.5 |  |  | 0.7 |  |
| Operating lease cost | 67.7 |  |  | 62.2 |  |  | 62.7 |  |
| Short-term lease cost | 5.0 |  |  | 3.8 |  |  | 4.0 |  |
| Variable lease cost | 24.5 |  |  | 21.6 |  |  | 20.3 |  |
| Total lease cost | $ | 111.1 |  |  | $ | 100.0 |  |  | $ | 98.0 |  |
| Other information |  |  |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 66.0 |  |  | $ | 61.8 |  |  | $ | 61.6 |  |
| Financing cash flows from finance leases | $ | 13.6 |  |  | $ | 12.3 |  |  | $ | 10.8 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 14.4 |  |  | $ | 14.6 |  |  | $ | 15.4 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 98.8 |  |  | $ | 61.8 |  |  | $ | 67.6 |  |

[0001628280-23-004257:notes:90]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Finance lease right-of-use assets(1) | $ | 33.3 |  |  | $ | 34.5 |  |
| Operating lease right-of-use assets | $ | 219.9 |  |  | $ | 196.1 |  |
| Finance lease liability, current(2) | $ | 11.2 |  |  | $ | 11.3 |  |
| Finance lease liability, non-current(3) | $ | 28.3 |  |  | $ | 29.0 |  |
| Operating lease liability, current | $ | 63.3 |  |  | $ | 54.8 |  |
| Operating lease liability, non-current | $ | 161.8 |  |  | $ | 145.0 |  |
| Weighted-average remaining lease term - finance leases | 3.6 years |  | 3.9 years |
| Weighted-average remaining lease term - operating leases | 5.1 years |  | 4.5 years |
| Weighted-average discount rate - finance leases | 1.92 | % |  | 1.14 | % |
| Weighted-average discount rate – operating leases | 3.44 | % |  | 2.62 | % |
| (1) Recorded in Property, plant and equipments in Consolidated Balance Sheet |
| (2) Recorded in Current maturities of long-term debt in Consolidated Balance Sheet |
| (3) Recorded in Long-term debt in Consolidated Balance Sheet |

[0001628280-23-004257:notes:91]
Future annual minimum lease payments and finance lease commitments as of December 31, 2022 were as follows (in millions):

[0001628280-23-004257:notes:92]
|  | Operating Leases |  | Finance Leases |
| 2023 | $ | 70.0 |  |  | $ | 11.6 |  |
| 2024 | 53.2 |  |  | 8.4 |  |
| 2025 | 36.9 |  |  | 5.8 |  |
| 2026 | 29.0 |  |  | 2.5 |  |
| 2027 | 18.9 |  |  | 0.3 |  |
| Thereafter | 40.1 |  |  | 11.7 |  |
| Total minimum lease payments | $ | 248.1 |  |  | $ | 40.3 |  |
| Less imputed interest | (23.0) |  |  | (0.8) |  |
| Present value of minimum payments | $ | 225.1 |  |  | $ | 39.5 |  |

[0001628280-23-004257:notes:93]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024 (the “Lake Park Renewal”). The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, we are obligated to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance of $41.2 million, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 87% of the lease balance.  The headquarters lease is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001628280-23-004257:notes:94]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing Credit Agreement.  We believe we were in compliance with these financial covenants as of December 31, 2022.

[0001628280-23-004257:notes:95]
Environmental

[0001628280-23-004257:notes:96]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities; however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included Accrued expenses and Other liabilities on the accompanying Consolidated Balance Sheets. Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001628280-23-004257:notes:97]
Product Warranties and Product Related Contingencies

[0001628280-23-004257:notes:98]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001628280-23-004257:notes:99]
Total product warranty liabilities are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-23-004257:notes:100]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Accrued expenses | $ | 41.3 |  |  | $ | 37.2 |  |
| Other liabilities | 101.4 |  |  | 97.0 |  |
| Total product warranty liabilities | $ | 142.7 |  |  | $ | 134.2 |  |

[0001628280-23-004257:notes:101]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2022 and 2021 were as follows (in millions):

[0001628280-23-004257:notes:102]
| Total warranty liability as of December 31, 2020 | $ | 119.8 |  |
| Payments made in 2021 | (31.6) |  |
| Changes resulting from issuance of new warranties | 43.6 |  |
| Changes in estimates associated with pre-existing liabilities | 2.7 |  |
| Changes in foreign currency translation rates and other | (0.3) |  |
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Payments made in 2022 | (36.3) |  |
| Changes resulting from issuance of new warranties | 50.5 |  |
| Changes in estimates associated with pre-existing liabilities | (4.7) |  |
| Changes in foreign currency translation rates and other | (1.0) |  |
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |

[0001628280-23-004257:notes:103]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the table above.  Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.

[0001628280-23-004257:notes:104]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures. We use large deductible insurance plans, written through third-party insurance providers, for workers’ compensation/employers’ liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors’ and officers’ liability, property damage and certain other insurance programs.    For directors’ and officers’ liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001628280-23-004257:notes:105]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001628280-23-004257:notes:106]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-23-004257:notes:107]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Accrued expenses | $ | 3.0 |  |  | $ | 3.2 |  |
| Other liabilities | 14.6 |  |  | 15.7 |  |
| Total self-insurance liabilities | $ | 17.6 |  |  | $ | 18.9 |  |

[0001628280-23-004257:notes:108]
Litigation

[0001628280-23-004257:notes:109]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-23-004257:notes:110]
It is management’s opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-23-004257:notes:111]
Our Board of Directors have authorized a total of $4 billion to repurchase shares of our common stock (collectively referred to as the “Share Repurchase Plans”), including a $1.0 billion share repurchase authorization in July 2021. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of December 31, 2022, $546 million of shares is available to repurchase shares under the Share Repurchase Plans.

[0001628280-23-004257:notes:112]
We entered into multiple Fixed Dollar Accelerated Share Repurchase Transactions (the "ASR Agreements") to effect an accelerated stock buybacks of the Company's common stock in 2022. Under the ASR Agreements, we paid banks $300.0 million and the banks delivered to us common stock representing approximately 86% of the shares expected to be purchased under the ASR Agreement. After the ASR Agreements were completed, the banks delivered the remaining shares under the arrangement.  The banks delivered a total of 1.3 million shares of common stock repurchased under this ASR Agreement.

[0001628280-23-004257:notes:113]
We also repurchased less than 0.1 million shares for $8.3 million, 0.1 million shares for $22.1 million, and 0.1 million shares for $17.9 million for the years ended December 31, 2022,  2021, and 2020, respectively, from employees who tendered their shares to satisfy minimum tax withholding obligation upon the vesting of stock-based compensation awards.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-23-004257:notes:114]
record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 3.We recorded $1.5 million of restructuring charges in 2022, $1.8 million 2021, and $10.8 million in 2020 from actions initiated in prior years including the economic impact of COVID-19.  There is not expected to be a material amount of costs expected to be incurred from existing restructuring actions in future periods.  Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-004257:notes:115]
The following table disaggregates our revenue by business segment by geography to provide information as to the major sources of revenue.  See Note 3 for additional description of our reportable business segments and the products and services being sold in each segment.

[0001628280-23-004257:notes:116]
|  | For the Year Ended December 31, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,957.1 |  |  | $ | 837.7 |  |  | $ | 385.7 |  |  | $ | 4,180.5 |  |
| Canada | 241.2 |  |  | 62.4 |  |  | — |  |  | 303.6 |  |
| International | — |  |  | 0.6 |  |  | 233.7 |  |  | 234.3 |  |
| Total | $ | 3,198.3 |  |  | $ | 900.7 |  |  | $ | 619.4 |  |  | $ | 4,718.4 |  |

[0001628280-23-004257:notes:117]
|  | For the Year Ended December 31, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,532.4 |  |  | $ | 790.1 |  |  | $ | 324.0 |  |  | $ | 3,646.5 |  |
| Canada | 243.2 |  |  | 73.1 |  |  | — |  |  | 316.3 |  |
| International | — |  |  | 1.6 |  |  | 229.7 |  |  | 231.3 |  |
| Total | $ | 2,775.6 |  |  | $ | 864.8 |  |  | $ | 553.7 |  |  | $ | 4,194.1 |  |

[0001628280-23-004257:notes:118]
|  |  | For the Year Ended December 31, 2020 |
|  | Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
|  | United States | $ | 2,181.8 |  |  | $ | 721.1 |  |  | $ | 257.9 |  |  | $ | 3,160.8 |  |
|  | Canada | 179.7 |  |  | 77.6 |  |  | — |  |  | 257.3 |  |
|  | International | — |  |  | 2.2 |  |  | 213.8 |  |  | 216.0 |  |
|  | Total | $ | 2,361.5 |  |  | $ | 800.9 |  |  | $ | 471.7 |  |  | $ | 3,634.1 |  |

[0001628280-23-004257:notes:119]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.

[0001628280-23-004257:notes:120]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  Revenue from extended warranties is insignificant. See Note 5 for more information on product warranties.

[0001628280-23-004257:notes:121]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the years ended December 31, 2022, 2021 and 2020, direct sales represented 70%, 73% and 75% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001628280-23-004257:notes:122]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the years ended December 31, 2022,  2021 and 2020, equipment sales represented 82%, 82% and 85% of revenues, respectively, and the remainder of our revenue was generated from our service business.

[0001628280-23-004257:notes:123]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Approximately 1% of segment revenue relates to services for start-up and commissioning activities.

[0001628280-23-004257:notes:124]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit

[0001628280-23-004257:notes:125]
(goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to SG&A expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001628280-23-004257:notes:126]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001628280-23-004257:notes:127]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheets.

[0001628280-23-004257:notes:128]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.

[0001628280-23-004257:notes:129]
Net contract assets (liabilities) consisted of the following:

[0001628280-23-004257:notes:130]
|  | December 31, 2022 |  | December 31, 2021 |  |  |  |  |
| Contract liabilities - current | (9.6) |  |  | (10.2) |  |  |  |  |  |
| Contract liabilities - noncurrent | (6.4) |  |  | (5.5) |  |  |  |  |  |
| Total | $ | (16.0) |  |  | $ | (15.7) |  |  |  |  |  |

[0001628280-23-004257:notes:131]
For the years ended December 31, 2022,  2021, and 2020 we recognized revenue of $10.1 million, $3.6 million and $7.2 million related to our contract liabilities at January 1, 2022, 2021 and 2020, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2022, 2021 and 2020.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-23-004257:notes:132]
The components of inventories are as follows (in millions):

[0001628280-23-004257:notes:133]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Finished goods | $ | 534.6 |  |  | $ | 310.8 |  |
| Work in process | 8.9 |  |  | 12.4 |  |
| Raw materials and parts | 328.7 |  |  | 262.1 |  |
| Total | 872.2 |  |  | 585.3 |  |
| Excess of current cost over last-in, first-out cost | (119.2) |  |  | (74.4) |  |
| Total inventories, net | $ | 753.0 |  |  | $ | 510.9 |  |

[0001628280-23-004257:notes:134]
The Company recorded a pre-tax gain of $0.7 million in 2020 from LIFO inventory liquidations.  There were no pre-tax gains or losses in 2022 or 2021 from LIFO inventory liquidations.  Reserves for obsolete and slow-moving inventories were $34.9 million and $26.5 million at December 31, 2022 and December 31, 2021, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-23-004257:notes:135]
The changes in the carrying amount of goodwill in 2022 and 2021, in total and by segment, are summarized in the table below (in millions):

[0001628280-23-004257:notes:136]
| Segment: | Balance at December 31, 2020 (1) |  |  |  | Changes in foreign currency translation rates |  | Balance at December 31, 2021 |  |  |  | Changes in foreign currency translation rates |  | Balance at December 31, 2022 |
| Residential Heating & Cooling | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.1 |  |  |  |  | — |  |  | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.7 |  |  |  |  | (0.3) |  |  | 99.4 |  |  |  |  | (0.3) |  |  | 99.1 |  |
|  | $ | 186.9 |  |  |  |  | $ | (0.3) |  |  | $ | 186.6 |  |  |  |  | $ | (0.3) |  |  | $ | 186.3 |  |

[0001628280-23-004257:notes:137]
(1) The goodwill balances in the table above are presented net of accumulated impairment charges of $32.7 million, all of which relate to impairments in periods prior to 2020.  
A qualitative review of impairment indicators was performed in 2022 for the Residential Heating & Cooling, the Commercial Heating & Cooling, and the Refrigeration segments.  We did not record any goodwill impairments in 2022, 2021, or 2020.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-23-004257:notes:138]
No impairment charges were recorded in 2022 or 2021.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-23-004257:notes:139]
Accrued Expenses

[0001628280-23-004257:notes:140]
The significant components of Accrued expenses are presented below (in millions):

[0001628280-23-004257:notes:141]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Accrued rebates and promotions | 123.3 |  |  | 102.9 |  |
| Accrued compensation and benefits | $ | 90.7 |  |  | $ | 114.9 |  |
| Accrued warranties | 41.3 |  |  | 37.2 |  |
| Other | 33.8 |  |  | 32.0 |  |
| Accrued sales, use, property and VAT taxes | 26.8 |  |  | 26.9 |  |
| Accrued Freight | 19.0 |  |  | 12.0 |  |
| Accrued asbestos reserves | 14.3 |  |  | 13.1 |  |
| Deferred income | 9.6 |  |  | 10.2 |  |
| Derivative contracts | 9.0 |  |  | 1.0 |  |
| Accrued interest | 6.1 |  |  | 5.5 |  |
| Self insurance reserves | 3.0 |  |  | 3.2 |  |
| Total Accrued expenses | $ | 376.9 |  |  | $ | 358.9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-23-004257:notes:142]
Objectives and Strategies for Using Derivative Instruments

[0001628280-23-004257:notes:143]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001628280-23-004257:notes:144]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001628280-23-004257:notes:145]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001628280-23-004257:notes:146]
Cash Flow Hedges

[0001628280-23-004257:notes:147]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through May 2024 and January 2024, respectively. We currently have cash flow hedge contracts with a notional amount of 54.5 million pounds of aluminum and copper. Unrealized gains or losses from our cash flow hedges are included in AOCL and are expected to be reclassified into earnings within the next 17 months based on the prices of the commodities and foreign currencies at the settlement dates.

[0001628280-23-004257:notes:148]
We recorded the following amounts related to our cash flow hedges in AOCL (in millions):

[0001628280-23-004257:notes:149]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Unrealized losses (gains), net on unsettled contracts | $ | 6.3 |  |  | $ | (13.4) |  |
| Income tax (benefit) expense | (1.4) |  |  | 2.7 |  |
| Unrealized losses (gains) included in AOCL, net of tax (1) | $ | 4.9 |  |  | $ | (10.7) |  |

[0001628280-23-004257:notes:150]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $5.0 million of derivative losses into earnings within the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-23-004257:notes:151]
Expenses included in our Consolidated Statements of Operations

[0001628280-23-004257:notes:152]
Below is information about expenses included in Selling, general and administrative expenses in our Consolidated Statements of Operations (in millions):

[0001628280-23-004257:notes:153]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Research and development | $ | 80.3 |  |  | $ | 76.1 |  |  | $ | 66.8 |  |
| Advertising, promotions and marketing (1) | 32.4 |  |  | 26.9 |  |  | 26.5 |  |
| Cooperative advertising expenditures | 28.1 |  |  | 27.6 |  |  | 22.2 |  |

[0001628280-23-004257:notes:154]
(1) Cooperative advertising expenditures were not included in these amounts.


## us-gaap:ScheduleOfOtherOperatingCostAndExpenseByComponentTextBlock

[0001628280-23-004257:notes:155]
(1) Cooperative advertising expenditures were not included in these amounts.
Losses (gains) and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001628280-23-004257:notes:156]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | (1.2) |  |  | $ | 0.1 |  |
| Foreign currency exchange gains | (1.3) |  |  | (2.2) |  |  | (3.6) |  |
| Loss (gain) on disposal of fixed assets | (1.0) |  |  | (0.2) |  |  | (0.2) |  |
| Other operating income | (1.0) |  |  | (1.5) |  |  | (2.2) |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | 0.4 |  |  | — |  |  | (0.3) |  |
| Environmental liabilities and special litigation charges | 7.5 |  |  | 9.6 |  |  | 5.3 |  |
| Charges incurred related to COVID-19 pandemic | 0.8 |  |  | 2.2 |  |  | 8.3 |  |
| Other items, net | (0.6) |  |  | 2.5 |  |  | — |  |
| (Gains) losses and other expenses, net (pre-tax) | $ | 4.9 |  |  | $ | 9.2 |  |  | $ | 7.4 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001628280-23-004257:notes:157]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001628280-23-004257:notes:158]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Interest expense, net of capitalized interest | $ | 39.8 |  |  | $ | 26.0 |  |  | $ | 29.7 |  |
| Less: Interest income | 1.1 |  |  | 1.0 |  |  | 1.4 |  |
| Interest expense, net | $ | 38.7 |  |  | $ | 25.0 |  |  | $ | 28.3 |  |

[0001628280-23-004257:notes:159]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001628280-23-004257:notes:160]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Current: |  |  |  |  |  |
| Federal | $ | 104.0 |  |  | $ | 72.0 |  |  | $ | 61.7 |  |
| State | 21.6 |  |  | 17.0 |  |  | 14.1 |  |
| Foreign | 7.8 |  |  | 13.4 |  |  | 4.8 |  |
| Total current | 133.4 |  |  | 102.4 |  |  | 80.6 |  |
| Deferred: |  |  |  |  |  |
| Federal | (13.9) |  |  | (2.6) |  |  | (0.7) |  |
| State | (3.1) |  |  | (1.5) |  |  | 1.1 |  |
| Foreign | 2.3 |  |  | (2.2) |  |  | 7.1 |  |
| Total deferred | (14.7) |  |  | (6.3) |  |  | 7.5 |  |
| Total provision for income taxes | $ | 118.7 |  |  | $ | 96.1 |  |  | $ | 88.1 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001628280-23-004257:notes:161]
Losses (Gains) and Other Expenses, net

[0001628280-23-004257:notes:162]
Losses (gains) and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-23-004257:notes:163]
Many of our defined benefit pension and profit sharing plans have been frozen and replaced with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen. We also have several active defined benefit plans that provide benefits based on years of service. Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.

[0001628280-23-004257:notes:164]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.

[0001628280-23-004257:notes:165]
Defined Contribution Plans

[0001628280-23-004257:notes:166]
We recorded the following contributions to the defined contribution plans (in millions):

[0001628280-23-004257:notes:167]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Contributions to defined contribution plans | $ | 22.7 |  |  | $ | 19.9 |  |  | $ | 17.8 |  |

[0001628280-23-004257:notes:168]
Pension and Post-retirement Benefit Plans

[0001628280-23-004257:notes:169]
Benefit Obligations, Fair Value of Plan Assets, Funded Status, and Balance Sheet Position

[0001628280-23-004257:notes:170]
The following tables set forth amounts recognized in our financial statements and the plans’ funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001628280-23-004257:notes:171]
|  | Pension Benefits |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Accumulated benefit obligation | $ | 171.6 |  |  | $ | 266.1 |  |  |  |  |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 269.2 |  |  | $ | 276.2 |  |  |  |  |  |
| Service cost | 3.8 |  |  | 6.1 |  |  |  |  |  |
| Interest cost | 6.2 |  |  | 5.1 |  |  |  |  |  |
| Actuarial (gain) loss | (74.6) |  |  | (11.2) |  |  |  |  |  |
| Effect of exchange rates | (3.4) |  |  | (0.7) |  |  |  |  |  |
| Settlements | (21.7) |  |  | (2.1) |  |  |  |  |  |
| Benefits paid | (5.2) |  |  | (4.2) |  |  |  |  |  |
| Benefit obligation at end of year | $ | 174.3 |  |  | $ | 269.2 |  |  |  |  |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 184.3 |  |  | $ | 179.7 |  |  |  |  |  |
| Actual return on plan assets | (45.4) |  |  | 9.5 |  |  |  |  |  |
| Employer contributions | 22.5 |  |  | 1.5 |  |  |  |  |  |
| Effect of exchange rates | (3.4) |  |  | (0.1) |  |  |  |  |  |
| Plan settlements | (21.7) |  |  | (2.1) |  |  |  |  |  |
| Benefits paid | (5.2) |  |  | (4.2) |  |  |  |  |  |
| Fair value of plan assets at end of year | 131.1 |  |  | 184.3 |  |  |  |  |  |
| Funded status / net amount recognized | $ | (43.2) |  |  | $ | (84.9) |  |  |  |  |  |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Non-current assets | $ | 2.7 |  |  | $ | 6.5 |  |  |  |  |  |
| Current liability | (5.8) |  |  | (8.1) |  |  |  |  |  |
| Non-current liability | (40.1) |  |  | (83.3) |  |  |  |  |  |
| Net amount recognized | $ | (43.2) |  |  | $ | (84.9) |  |  |  |  |  |

[0001628280-23-004257:notes:172]
Plans with Benefit Obligations in Excess of Plan Assets

[0001628280-23-004257:notes:173]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 152.1 |  |  | $ | 234.8 |  |
| Accumulated benefit obligation | 149.6 |  |  | 231.4 |  |
| Fair value of plan assets | 106.2 |  |  | 143.7 |  |

[0001628280-23-004257:notes:174]
Net Periodic Benefit Cost

[0001628280-23-004257:notes:175]
Our U.S.-based pension plans comprised approximately 84% of the projected benefit obligation and 81% of plan assets as of December 31, 2022.

[0001628280-23-004257:notes:176]
|  | Pension Benefits |  |  |
|  | 2022 |  | 2021 |  | 2020 |  |  |  |  |  |  |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 3.8 |  |  | $ | 6.1 |  |  | $ | 5.5 |  |  |  |  |  |  |  |
| Interest cost | 6.2 |  |  | 5.1 |  |  | 6.6 |  |  |  |  |  |  |  |
| Expected return on plan assets | (9.1) |  |  | (8.6) |  |  | (8.2) |  |  |  |  |  |  |  |
| Amortization of prior service costs | 0.1 |  |  | 0.2 |  |  | 0.2 |  |  |  |  |  |  |  |
| Recognized actuarial loss | 5.3 |  |  | 7.7 |  |  | 5.8 |  |  |  |  |  |  |  |
| Settlements | (0.2) |  |  | 1.2 |  |  | 0.6 |  |  |  |  |  |  |  |
| Other | (0.1) |  |  | (0.4) |  |  | — |  |  |  |  |  |  |  |
| Net periodic benefit cost | $ | 6.0 |  |  | $ | 11.3 |  |  | $ | 10.5 |  |  |  |  |  |  |  |

[0001628280-23-004257:notes:177]
Amounts recognized in AOCL and Other Comprehensive Income

[0001628280-23-004257:notes:178]
The following table sets forth amounts recognized in AOCL and Other comprehensive income (loss) in our financial statements for 2022 and 2021 (in millions):

[0001628280-23-004257:notes:179]
|  | Pension Benefits |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Amounts recognized in AOCL: |  |  |  |  |  |  |  |
| Prior service costs | $ | (0.4) |  |  | $ | (0.5) |  |  |  |  |  |
| Actuarial loss | (57.7) |  |  | (83.1) |  |  |  |  |  |
| Subtotal | (58.1) |  |  | (83.6) |  |  |  |  |  |
| Deferred taxes | 15.8 |  |  | 18.6 |  |  |  |  |  |
| Net amount recognized | $ | (42.3) |  |  | $ | (65.0) |  |  |  |  |  |
| Changes recognized in other comprehensive loss: |  |  |  |  |  |  |  |
| Current year actuarial gain | (19.4) |  |  | (12.2) |  |  |  |  |  |
| Effect of exchange rates | (0.9) |  |  | — |  |  |  |  |  |
| Amortization of prior service costs | (0.1) |  |  | (0.2) |  |  |  |  |  |
| Amortization of actuarial loss, including settlements and other | (5.1) |  |  | (8.5) |  |  |  |  |  |
| Total recognized in other comprehensive income (loss) | $ | (25.5) |  |  | $ | (20.9) |  |  |  |  |  |
| Total recognized in net periodic benefit cost and other comprehensive income | $ | (19.5) |  |  | $ | (9.6) |  |  |  |  |  |

[0001628280-23-004257:notes:180]
The estimated prior service costs and actuarial losses for pension benefits that will be amortized from AOCL in 2023 are $0.1 million and $1.2 million, respectively.

[0001628280-23-004257:notes:181]
Assumptions

[0001628280-23-004257:notes:182]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2022 and 2021:

[0001628280-23-004257:notes:183]
|  |  | Pension Benefits |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |
| Discount rate |  | 5.50 | % |  | 2.69 | % |  |  |  |  |
| Rate of compensation increase |  | 4.02 | % |  | 4.1 | % |  |  |  |  |

[0001628280-23-004257:notes:184]
|  | Pension Benefits |  |  |
|  | 2022 |  | 2021 |  | 2020 |  |  |  |  |  |  |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate - service cost | 2.53 | % |  | 1.85 | % |  | 2.89 | % |  |  |  |  |  |  |
| Discount rate - interest cost | 2.48 | % |  | 2.16 | % |  | 2.99 | % |  |  |  |  |  |  |
| Expected long-term return on plan assets | 6.50 | % |  | 6.50 | % |  | 6.50 | % |  |  |  |  |  |  |
| Rate of compensation increase | 4.13 | % |  | 4.13 | % |  | 4.23 | % |  |  |  |  |  |  |

[0001628280-23-004257:notes:185]
The change in the discount rate for 2022 was the primary driver in the actuarial gain in the projected benefit obligation during the year.

[0001628280-23-004257:notes:186]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the non-U.S.-based plans in 2022 and 2021:

[0001628280-23-004257:notes:187]
|  | Pension Benefits |
|  | 2022 |  | 2021 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 4.72 | % |  | 1.99 | % |
| Rate of compensation increase | 3.11 | % |  | 3.14 | % |

[0001628280-23-004257:notes:188]
|  | Pension Benefits |
|  | 2022 |  | 2021 |  | 2020 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 0.86 | % |  | 0.42 | % |  | 0.73 | % |
| Discount rate - interest cost | 2.07 | % |  | 1.51 | % |  | 2.3 | % |
| Expected long-term return on plan assets | 2.75 | % |  | 2.10 | % |  | 3.31 | % |
| Rate of compensation increase | 3.14 | % |  | 3.17 | % |  | 3.20 | % |

[0001628280-23-004257:notes:189]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 6.50% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001628280-23-004257:notes:190]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis to select the discount rate for each plan. The analysis was completed separately for each U.S. pension and OPEB plan. A similar process was followed for the non-U.S.-based plans with sufficient corporate bond information. In other countries, the discount rate was selected based on the approximate duration of plan obligations.

[0001628280-23-004257:notes:191]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001628280-23-004257:notes:192]
|  | 2022 |  | 2021 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 6.50 | % |  | 6.00 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2029 |  | 2025 |

[0001628280-23-004257:notes:193]
Expected future benefit payments are shown in the table below (in millions):

[0001628280-23-004257:notes:194]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028-2032 |
| Pension benefits | $ | 11.1 |  |  | $ | 11.9 |  |  | $ | 7.6 |  |  | $ | 8.8 |  |  | $ | 22.9 |  |  | $ | 56.4 |  |

[0001628280-23-004257:notes:195]
Composition of Pension Plan Assets

[0001628280-23-004257:notes:196]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets between equity and fixed income.  The targeted allocation for fixed income and cash investments is 50% and the targeted allocation for equity investments is 50%. Our targeted exposure to International equity including emerging markets is 15% while our exposure to domestic equity is 35%. Our U.S. pension plan represents 81%, our Canadian pension plan 9%, and our United Kingdom (“U.K.”) pension plan 10% of the total fair value of our plan assets as of December 31, 2022.

[0001628280-23-004257:notes:197]
Our U.S. pension plans’ weighted-average asset allocations as of December 31, 2022 and 2021, by asset category, were as follows:

[0001628280-23-004257:notes:198]
|  | Plan Assets as of December 31, |
| Asset Category: | 2022 |  | 2021 |
| U.S. equity | 31.3 | % |  | 36.1 | % |
| International equity | 18.7 | % |  | 15.5 | % |
| Fixed income | 49.2 | % |  | 48.2 | % |
| Money market/cash | 0.8 | % |  | 0.2 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001628280-23-004257:notes:199]
Our U.S. pension plans’ assets were invested according to the following targets:

[0001628280-23-004257:notes:200]
| Asset Category: | Target |
| U.S. equity | 35.0 | % |
| International equity | 15.0 | % |
| Fixed income | 50.0 | % |

[0001628280-23-004257:notes:201]
Our Canadian pension plans were invested in fixed income securities and equities. Our U.K. pension plan was invested in fixed income securities, including corporate and government bonds.

[0001628280-23-004257:notes:202]
The fair values of our pension plan assets, by asset category, were as follows (in millions):

[0001628280-23-004257:notes:203]
|  | Fair Value Measurements as of December 31, 2022 |  |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |  |
| Asset Category: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.9 |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 33.3 |  |  | — |  |  | 33.3 |  |  |
| International equity (2) | — |  |  | 19.8 |  |  | — |  |  | 19.8 |  |  |
| Fixed income (3) | — |  |  | 52.5 |  |  | — |  |  | 52.5 |  |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |  |
| International equity | — |  |  | 3.3 |  |  | — |  |  | 3.3 |  |  |
| Fixed income | — |  |  | 8.3 |  |  | — |  |  | 8.3 |  |  |
| Pension fund: |  |  |  |  |  |  |  |  |
| Fixed income (6) | — |  |  | 13.0 |  |  | — |  |  | 13.0 |  |  |
| Total | $ | 0.9 |  |  | $ | 130.2 |  |  | $ | — |  |  | $ | 131.1 |  |  |

[0001628280-23-004257:notes:204]
|  | Fair Value Measurements as of December 31, 2021 |  |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |  |
| Asset Category: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.4 |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 51.8 |  |  | — |  |  | 51.8 |  |  |
| International equity (2) | — |  |  | 22.2 |  |  | — |  |  | 22.2 |  |  |
| Fixed income (3) | — |  |  | 69.3 |  |  | — |  |  | 69.3 |  |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.4 |  |  | — |  |  | 4.4 |  |  |
| Fixed income | — |  |  | 12.6 |  |  | — |  |  | 12.6 |  |  |
| Pension fund: |  |  |  |  |  |  |  |  |
| Fixed income (5) | — |  |  | 23.6 |  |  | — |  |  | 23.6 |  |  |
| Total | $ | 0.4 |  |  | $ | 183.9 |  |  | $ | — |  |  | $ | 184.3 |  |  |

[0001628280-23-004257:notes:205]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001628280-23-004257:notes:206]
|  | As of December 31, 2022 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 33.3 |  |  | Daily |  | 5 days |
| International equity (2) | 19.8 |  |  | Daily |  | 5 days |
| Fixed income (3) | 52.5 |  |  | Daily |  | 5 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 3.3 |  |  | Daily |  | 3-5 days |
| Fixed income | 8.3 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (5) | 13.0 |  |  | Daily |  | 1 - 3 days |
| Total | $ | 130.2 |  |  |  |  |  |

[0001628280-23-004257:notes:207]
|  | As of December 31, 2021 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 51.8 |  |  | Daily |  | 5 days |
| International equity (2) | 22.2 |  |  | Daily |  | 5 days |
| Fixed income (3) | 69.3 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.4 |  |  | Daily |  | 3-5 days |
| Fixed income | 12.6 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (5) | 23.6 |  |  | Daily |  | 1 - 3 days |
| Total | $ | 183.9 |  |  |  |  |  |

[0001628280-23-004257:notes:208]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the plan are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The plan also holds a portion of its assets in international equities, a portion of which may be invested in U.S. securities. |
| (5) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer with a derivatives overlay and investment grade corporate bonds denominated in sterling. The plan also holds a portion of its assets in international instruments, a portion of which may be invested in U.S. securities. |

[0001628280-23-004257:notes:209]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund’s NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the number of units owned.  See Note 16 for information about our fair value hierarchies and valuation techniques.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001628280-23-004257:notes:210]
participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001628280-23-004257:notes:211]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Equity method investments | $ | 44.4 |  |  | $ | 37.7 |  |

[0001628280-23-004257:notes:212]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001628280-23-004257:notes:213]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Purchases of compressors from joint venture | $ | 156.2 |  |  | $ | 141.7 |  |  | $ | 123.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-004257:notes:214]
r Provision for income taxes from continuing operations consisted of the following (in millions):

[0001628280-23-004257:notes:215]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001628280-23-004257:notes:216]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Domestic | $ | 340.2 |  |  | $ | 307.8 |  |  | $ | 268.4 |  |
| Foreign | 275.6 |  |  | 252.3 |  |  | 176.8 |  |
| Total | $ | 615.8 |  |  | $ | 560.1 |  |  | $ | 445.2 |  |

[0001628280-23-004257:notes:217]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001628280-23-004257:notes:218]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Provision at the U.S. statutory rate of 21% | $ | 129.3 |  |  | $ | 117.6 |  |  | $ | 93.5 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 14.6 |  |  | 12.1 |  |  | 10.8 |  |
| Tax credits, net of unrecognized tax benefits | (8.0) |  |  | (9.3) |  |  | (7.8) |  |
| Change in unrecognized tax benefits | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Change in valuation allowance | — |  |  | — |  |  | 7.8 |  |
| Foreign taxes at rates other than U.S. statutory rate | (47.4) |  |  | (43.6) |  |  | (33.6) |  |
| Deemed inclusions | 10.0 |  |  | 7.7 |  |  | 9.2 |  |
| Global intangible low-taxed income | 23.9 |  |  | 18.8 |  |  | 10.3 |  |
| Change in rates from the Tax Act & other law changes | 0.1 |  |  | 0.1 |  |  | 0.7 |  |
| Excess tax benefits from stock-based compensation | (0.6) |  |  | (5.7) |  |  | (4.2) |  |
| Miscellaneous other | (3.4) |  |  | (1.8) |  |  | 1.2 |  |
| Total provision for income taxes | $ | 118.7 |  |  | $ | 96.1 |  |  | $ | 88.1 |  |

[0001628280-23-004257:notes:219]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001628280-23-004257:notes:220]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001628280-23-004257:notes:221]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 34.9 |  |  | $ | 32.9 |  |
| Loss carryforwards (foreign, U.S. and state) | 29.6 |  |  | 28.5 |  |
| Post-retirement and pension benefits | 10.2 |  |  | 15.6 |  |
| Inventory reserves | 9.3 |  |  | 7.1 |  |
| Receivables allowance | 6.0 |  |  | 4.5 |  |
| Compensation liabilities | 5.9 |  |  | 9.5 |  |
| Legal reserves | 10.5 |  |  | 12.1 |  |
| Tax credits, net of federal effect | 11.9 |  |  | 11.5 |  |
| Research and development capitalization | 17.9 |  |  | — |  |
| Other | 7.1 |  |  | 9.6 |  |
| Total deferred tax assets | 143.3 |  |  | 131.3 |  |
| Valuation allowance | (37.9) |  |  | (37.3) |  |
| Total deferred tax assets, net of valuation allowance | 105.4 |  |  | 94.0 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (58.9) |  |  | (58.7) |  |
| Intangibles | (15.6) |  |  | (15.5) |  |
| Insurance liabilities | (1.4) |  |  | (1.4) |  |
| Other | (2.0) |  |  | (7.1) |  |
| Total deferred tax liabilities | (77.9) |  |  | (82.7) |  |
| Net deferred tax assets | $ | 27.5 |  |  | $ | 11.3 |  |

[0001628280-23-004257:notes:222]
As of December 31, 2022 and 2021, we had $21.5 million and $20.3 million in tax-effected foreign net operating loss carryforwards, respectively. The deferred tax asset valuation allowance relates primarily to loss carryforwards. The remainder of the valuation allowance relates to state tax credits.

[0001628280-23-004257:notes:223]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of  December 31, 2022.

[0001628280-23-004257:notes:224]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries’ earnings. An actual repatriation in the future from our non-U.S. subsidiaries could still be subject to foreign withholding taxes and U.S. state taxes, but we expect any amounts to be immaterial.

[0001628280-23-004257:notes:225]
We are currently in the Bridge program for our U.S. federal income taxes under the Internal Revenue Service’s Compliance Assurance Program for 2022 and 2021.  As a result, our returns for those years will not be examined.   However, we are subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We have no material uncertain tax provisions recorded as of December 31, 2022.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2015.


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-004257:notes:226]
The following tables summarize our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001628280-23-004257:notes:227]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 350.0 |  |  | $ | — |  |
| Finance lease obligations | 11.2 |  |  | 11.3 |  |
| Senior unsecured notes | 350.0 |  |  | — |  |
| Debt issuance costs | (0.6) |  |  | — |  |
| Total current maturities of long-term debt | $ | 710.6 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 250.0 |  |
| Finance lease obligations | 28.3 |  |  | 29.0 |  |
| Credit agreement | 192.0 |  |  | 6.5 |  |
| Senior unsecured notes | 600.0 |  |  | 950.0 |  |
| Debt issuance costs | (6.1) |  |  | (9.0) |  |
| Total long-term debt | $ | 814.2 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,524.8 |  |  | $ | 1,237.8 |  |

[0001628280-23-004257:notes:228]
As of December 31, 2022, the aggregate amounts of required principal payments on total debt excluding finance lease obligations (see Note 5) were as follows (in millions):

[0001628280-23-004257:notes:229]
| 2023 | $ | 700.0 |  |
| 2024 | — |  |
| 2025 | 300.0 |  |
| 2026 | 192.0 |  |
| 2027 | 300.0 |  |
| Thereafter | — |  |

[0001628280-23-004257:notes:230]
Short-Term Debt

[0001628280-23-004257:notes:231]
Foreign Obligations

[0001628280-23-004257:notes:232]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. As of December 31, 2022 or 2021, we did not have any outstanding short-term foreign obligations.  Proceeds and repayments from these facilities were $0.0 million, $0.0 million and $4.6 million during the years ended December 31, 2022, 2021 and 2020, respectively.

[0001628280-23-004257:notes:233]
Long-Term Debt

[0001628280-23-004257:notes:234]
Asset Securitization Program

[0001628280-23-004257:notes:235]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheet and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001628280-23-004257:notes:236]
We renewed the ASP in November 2021, extending its term to November 2023 and increasing the maximum securitization amount to a range from $300.0 million to $450.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001628280-23-004257:notes:237]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 350.0 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (350.0) |  |  | (250.0) |  |
| Remaining amount available | $ | — |  |  | $ | 85.6 |  |

[0001628280-23-004257:notes:238]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of December 31, 2022 and 2021 were 5.17% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at rate ranging between 0.25% and 0.35%, depending on available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001628280-23-004257:notes:239]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over  $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement.  The participating financial institutions have investment grade credit ratings. As of December 31, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-23-004257:notes:240]
Credit Agreement

[0001628280-23-004257:notes:241]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-23-004257:notes:242]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility that matures in July 2026. We had outstanding borrowings of $192.0 million as well as $2.0 million committed to standby letters of credit as of December 31, 2022. Subject to covenant limitations, $556.0 million was available for future borrowings. The revolving credit facility includes

[0001628280-23-004257:notes:243]
a subfacility for swingline loans of up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-23-004257:notes:244]
Below is a summary of the weighted average interest rate for both December 31, 2022 and 2021:

[0001628280-23-004257:notes:245]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Weighted average borrowing rate | 5.57 | % |  | 1.38 | % |

[0001628280-23-004257:notes:246]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and its subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of its assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-23-004257:notes:247]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Credit Agreement could occur if:

[0001628280-23-004257:notes:248]
•    We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-23-004257:notes:249]
•    We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-23-004257:notes:250]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Credit Agreement, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-23-004257:notes:251]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-23-004257:notes:252]
Senior Unsecured Notes

[0001628280-23-004257:notes:253]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.

[0001628280-23-004257:notes:254]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of December 31, 2022, we believe we were in compliance with all covenant requirements.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001628280-23-004257:notes:255]
The following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001628280-23-004257:notes:256]
|  |  | For the Years Ended December 31, |  |  |
| AOCL Component |  | 2022 |  | 2021 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Derivative contracts |  | $ | 9.7 |  |  | $ | 26.9 |  |  | Cost of goods sold and Losses (gains) and other expenses, net. |
| Income tax expense |  | (2.2) |  |  | (6.2) |  |  | Provision for income taxes |
| Net of tax |  | $ | 7.5 |  |  | $ | 20.7 |  |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and post-retirement benefits costs |  | $ | (5.4) |  |  | $ | (7.9) |  |  | Cost of goods sold; Selling, general, administrative expenses and Other (income) expense, net |
| Pension settlements |  | 0.2 |  |  | (1.2) |  |  | Pension settlements |
| Income tax benefit |  | 1.3 |  |  | 2.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (3.9) |  |  | $ | (6.9) |  |  |  |
| Total reclassifications from AOCL |  | $ | 3.6 |  |  | $ | 13.8 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-23-004257:notes:257]
following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001628280-23-004257:notes:258]
The following tables provide information on changes in AOCL, by component (net of tax), for the years ended December 31, 2022 and 2021 (in millions):

[0001628280-23-004257:notes:259]
|  |  | Gains (Loss) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2021 |  | $ | 10.7 |  |  | $ | (1.2) |  |  | $ | (68.8) |  |  | $ | (28.8) |  |  | $ | (88.1) |  |
| Other comprehensive (loss) income before reclassifications |  | (8.1) |  |  | 0.7 |  |  | 18.7 |  |  | (10.2) |  |  | 1.1 |  |
| Amounts reclassified from AOCL |  | (7.5) |  |  | — |  |  | 3.9 |  |  | — |  |  | (3.6) |  |
| Net other comprehensive (loss) income |  | (15.6) |  |  | 0.7 |  |  | 22.6 |  |  | (10.2) |  |  | (2.5) |  |
| Balance as of December 31, 2022 |  | $ | (4.9) |  |  | $ | (0.5) |  |  | $ | (46.2) |  |  | $ | (39.0) |  |  | $ | (90.6) |  |

[0001628280-23-004257:notes:260]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2020 |  | $ | 8.2 |  |  | $ | (1.2) |  |  | $ | (82.7) |  |  | $ | (21.5) |  |  | $ | (97.2) |  |
| Other comprehensive income (loss) before reclassifications |  | 23.2 |  |  | — |  |  | 7.0 |  |  | (7.3) |  |  | 22.9 |  |
| Amounts reclassified from AOCL |  | (20.7) |  |  | — |  |  | 6.9 |  |  | — |  |  | (13.8) |  |
| Other comprehensive income (loss) before reclassifications |  | 2.5 |  |  | — |  |  | 13.9 |  |  | (7.3) |  |  | 9.1 |  |
| Balance as of December 31, 2021 |  | $ | 10.7 |  |  | $ | (1.2) |  |  | $ | (68.8) |  |  | $ | (28.8) |  |  | $ | (88.1) |  |


## us-gaap:ScheduleOfCompensationCostForShareBasedPaymentArrangementsAllocationOfShareBasedCompensationCostsByPlanTableTextBlock

[0001628280-23-004257:notes:261]
Stock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001628280-23-004257:notes:262]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Compensation expense(1) | $ | 21.8 |  |  | $ | 24.3 |  |  | $ | 24.3 |  |

[0001628280-23-004257:notes:263]
(1) Stock-based compensation expense was recorded in our Corporate and other business segment.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-23-004257:notes:264]
ock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001628280-23-004257:notes:265]
Incentive Plan

[0001628280-23-004257:notes:266]
Under the Lennox International Inc. 2019 Equity and Incentive Compensation Plan, we are authorized to issue awards for 1.7 million shares of common stock. The plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.  As of December 31, 2022, there were 1.5 million shares available for future issuance.

[0001628280-23-004257:notes:267]
Performance Share Units

[0001628280-23-004257:notes:268]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII’s performance over the three-year performance period.

[0001628280-23-004257:notes:269]
Performance share units are classified as equity awards. Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded. Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001628280-23-004257:notes:270]
The following table provides information on our performance share units:

[0001628280-23-004257:notes:271]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Compensation expense for performance share units (in millions) | $ | 6.9 |  |  | $ | 10.8 |  |  | $ | 8.9 |  |
| Weighted-average fair value of grants, per share | $ | 237.68 |  |  | $ | 314.27 |  |  | $ | 265.96 |  |
| Payout ratio for shares paid | 126 | % |  | 100 | % |  | 133 | % |

[0001628280-23-004257:notes:272]
A summary of the status of our undistributed performance share units as of December 31, 2022, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001628280-23-004257:notes:273]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2021 | 149.2 |  |  | $ | 246.84 |  |
| Granted | 51.5 |  |  | $ | 237.68 |  |
| Adjustment to shares paid based on payout ratio | 7.4 |  |  | 245.06 |  |
| Distributed | (54.4) |  |  | $ | 204.64 |  |
| Forfeited | (29.0) |  |  | $ | 262.82 |  |
| Undistributed performance share units as of December 31, 2022 (1) | 124.7 |  |  | $ | 257.55 |  |

[0001628280-23-004257:notes:274]
(1) Undistributed performance share units include approximately 93.9 thousand units with a weighted-average grant date fair value of $261.65 per share that had not yet vested and 30.8 thousand units that have vested but were not yet distributed.

[0001628280-23-004257:notes:275]
As of December 31, 2022, we had $18.8 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.4 years years. Our weighted-average estimated forfeiture rate for these performance share units was 10.9% as of December 31, 2022.

[0001628280-23-004257:notes:276]
The total fair value of performance share units distributed and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001628280-23-004257:notes:277]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Fair value of performance share units distributed | $ | 6.1 |  |  | $ | 10.8 |  |  | $ | 15.1 |  |
| Realized tax benefits from tax deductions | $ | 1.5 |  |  | $ | 2.7 |  |  | $ | 0.7 |  |

[0001628280-23-004257:notes:278]
Restricted Stock Units

[0001628280-23-004257:notes:279]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001628280-23-004257:notes:280]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001628280-23-004257:notes:281]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Compensation expense for restricted stock units | $ | 11.0 |  |  | $ | 8.7 |  |  | $ | 10.4 |  |
| Weighted-average fair value of grants, per share | $ | 240.87 |  |  | $ | 315.70 |  |  | $ | 265.96 |  |

[0001628280-23-004257:notes:282]
A summary of our non-vested restricted stock units as of December 31, 2022 and changes during the year then ended is presented below (in thousands, except per share data):

[0001628280-23-004257:notes:283]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2021 | 135.1 |  |  | $ | 277.85 |  |
| Granted | 58.8 |  |  | $ | 240.87 |  |
| Vested | (37.3) |  |  | $ | 250.45 |  |
| Forfeited | (25.6) |  |  | $ | 268.59 |  |
| Non-vested restricted stock units as of December 31, 2022 (1) | 131.0 |  |  | $ | 270.86 |  |

[0001628280-23-004257:notes:284]
(1) As of December 31, 2022, we had $24.7 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.4 years.  Our estimated forfeiture rate for restricted stock units was 13.3% as of December 31, 2022.

[0001628280-23-004257:notes:285]
The total fair value of restricted stock units vested and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001628280-23-004257:notes:286]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Fair value of restricted stock units vested | $ | 9.7 |  |  | $ | 11.0 |  |  | $ | 15.0 |  |
| Realized tax benefits from tax deductions | 2.4 |  |  | 2.7 |  |  | 2.7 |  |

[0001628280-23-004257:notes:287]
Stock Appreciation Rights

[0001628280-23-004257:notes:288]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive compensation, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001628280-23-004257:notes:289]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001628280-23-004257:notes:290]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Compensation expense for stock appreciation rights | $ | 3.9 |  |  | $ | 4.8 |  |  | $ | 5.0 |  |
| Weighted-average fair value of grants, per share | $ | 64.54 |  |  | $ | 70.50 |  |  | $ | 55.21 |  |

[0001628280-23-004257:notes:291]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001628280-23-004257:notes:292]
The fair value of the stock appreciation rights granted in 2022, 2021 and 2020 were estimated on the date of grant using the following assumptions:

[0001628280-23-004257:notes:293]
|  | 2022 |  | 2021 |  | 2020 |
| Expected dividend yield | 2.01 | % |  | 1.69 | % |  | 1.64 | % |
| Risk-free interest rate | 3.88 | % |  | 0.88 | % |  | 0.27 | % |
| Expected volatility | 29.90 | % |  | 29.80 | % |  | 29.70 | % |
| Expected life (in years) | 4.18 |  | 4.35 |  | 3.95 |

[0001628280-23-004257:notes:294]
A summary of our stock appreciation rights as of December 31, 2022, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001628280-23-004257:notes:295]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2021 | 478.3 |  |  | $ | 241.61 |  |
| Granted | 98.1 |  |  | $ | 259.56 |  |
| Exercised | (42.7) |  |  | $ | 170.48 |  |
| Forfeited | (45.8) |  |  | $ | 280.78 |  |
| Outstanding stock appreciation rights as of December 31, 2022 | 487.9 |  |  | $ | 247.77 |  |
| Exercisable stock appreciation rights as of December 31, 2022 | 324.6 |  |  | $ | 231.24 |  |

[0001628280-23-004257:notes:296]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2022 (in millions, except per share data and years; shares in thousands):

[0001628280-23-004257:notes:297]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares (1) |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $124.97 to $214.63 |  | 175.7 |  |  | 2.12 |  | $ | 7.7 |  |  | 175.7 |  |  | 2.12 |  | $ | 7.7 |  |
| $257.08 to $278.00 |  | 147.9 |  |  | 4.42 |  | $ | — |  |  | 126.9 |  |  | 4.33 |  | $ | — |  |
| $259.56 to $328.65 |  | 164.3 |  |  | 6.59 |  | $ | — |  |  | 22.1 |  |  | 6.00 |  | $ | — |  |

[0001628280-23-004257:notes:298]
(1) Share amounts are rounded but the balance accurately reflects the actual amount of exercisable stock appreciation rights as of December 31, 2022.

[0001628280-23-004257:notes:299]
As of December 31, 2022, we had $10.6 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.8 years. Our estimated forfeiture rate for stock appreciation rights was 12.6% as of December 31, 2022.

[0001628280-23-004257:notes:300]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001628280-23-004257:notes:301]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Intrinsic value of stock appreciation rights exercised | $ | 3.5 |  |  | $ | 31.2 |  |  | $ | 26.7 |  |
| Realized tax benefits from tax deductions | $ | 0.9 |  |  | $ | 7.7 |  |  | $ | 6.7 |  |

[0001628280-23-004257:notes:302]
Employee Stock Purchase Plan

[0001628280-23-004257:notes:303]
On May 24, 2022, the Company commenced a new Employee Stock Purchase Plan to succeed the prior agreement from 2012. Under the 2022 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 1.0 million shares is authorized for purchase until issuance of all shares available under the plan, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 16,100 shares under the ESPP during the year ended December 31, 2022.  Approximately 0.8 million shares remain available for purchase under the ESPP as of December 31, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-004257:notes:304]
ir value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities. Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:
Level 1 -      Quoted prices for identical instruments in active markets at the measurement date.

[0001628280-23-004257:notes:305]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001628280-23-004257:notes:306]
Level 3 -   Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001628280-23-004257:notes:307]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2022 and 2021, the measurement dates.

[0001628280-23-004257:notes:308]
The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2022 were the same as those used as of December 31, 2021.

[0001628280-23-004257:notes:309]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001628280-23-004257:notes:310]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001628280-23-004257:notes:311]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty’s creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 9 for more information related to our derivative instruments.  Refer to Note 10 for more information related to the fair value assumptions related to our pension assets and liabilities.

[0001628280-23-004257:notes:312]
Other Fair Value Disclosures

[0001628280-23-004257:notes:313]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Credit Agreement in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001628280-23-004257:notes:314]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001628280-23-004257:notes:315]
|  | As of December 31, |
|  | 2022 |  | 2021 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 878.0 |  |  | $ | 959.2 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-23-004257:notes:316]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001628280-23-004257:notes:317]
For the Years Ended December 31, 2022, 2021 and 2020

[0001628280-23-004257:notes:318]
(In millions)

[0001628280-23-004257:notes:319]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2020 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.1 |  |  | $ | 8.1 |  |  | $ | (4.2) |  |  | $ | 1.2 |  |  | $ | (1.6) |  |  | $ | 9.6 |  |
| 2021 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 9.6 |  |  | $ | 0.3 |  |  | $ | (0.4) |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 10.7 |  |
| 2022 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 10.7 |  |  | $ | 6.9 |  |  | $ | (0.4) |  |  | $ | — |  |  | $ | (1.7) |  |  | $ | 15.5 |  |
