# LII MD&A — 0001069202-12-000005


## mdna

[0001069202-12-000005:mdna:1]
[same as prior period, unchanged from 0001193125-12-311640:mdna:1]

[0001069202-12-000005:mdna:2]
[same as prior period, unchanged from 0001193125-12-311640:mdna:2]

[0001069202-12-000005:mdna:3]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (‘HVACR’) industry. Our reportable segments consist of Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration. For more detailed information regarding our reportable segments, see Note 14 in the Notes to our Consolidated Financial Statements.

[0001069202-12-000005:mdna:4]
Our fiscal year ends on December 31 and our interim fiscal quarters are each comprised of 13 weeks. For convenience, throughout this Management’s Discussion and Analysis of Financial Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted by the last day of the calendar quarter.

[0001069202-12-000005:mdna:5]
Our products and services are sold through a combination of distributors, independent and company-owned dealer service centers, other installing contractors, wholesalers, manufacturers’ representatives, original equipment manufacturers and directly to national accounts. The demand for our products and services is seasonal and dependent on the weather. Warmer than normal summer temperatures generate strong demand for replacement air conditioning and refrigeration products and services and colder than normal winter temperatures have the same effect on heating products and services. Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services. In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.

[0001069202-12-000005:mdna:6]
The principal elements of cost of goods sold in our manufacturing operations are components, raw materials, factory overhead, labor and estimated costs of warranty expense. The principal raw materials used in our manufacturing processes are steel, copper and aluminum. In recent years, increased prices for these commodities and related components have challenged us and the HVACR industry in general. We seek to mitigate the impact of higher commodity prices through a combination of price increases for our products and services, commodity contracts, improved production efficiency and cost reduction initiatives. We also seek to mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-12-000005:mdna:7]
In the third quarter of 2012, our Residential Heating & Cooling segment led our overall operational improvement with a 9% increase in net sales and $6 million in increased profit compared to the third quarter of 2011. This segment’s improvement can be attributed to an increase in its new construction business and replacement business.  Sales in our Commercial Heating & Cooling segment were down 2% compared to the third quarter of the 2011.  Excluding a 3% unfavorable foreign currency impact, sales were up 1%.  This segment's profit in the third quarter of 2012 was $1 million higher when compared to the third quarter of 2011.  Sales in our Refrigeration segment were down 9% compared to the third quarter of 2011, or down 6% excluding a 3% unfavorable foreign currency impact.  However, this segment's profit increased $5 million compared to the third quarter of 2011, primarily as a result of improved product profit margins.

[0001069202-12-000005:mdna:8]
In September of 2012, the Company announced the planned sale of its Service Experts business.  The Service Experts business had previously been reported within the Service Experts business segment, and beginning in the third quarter of 2012, is reported as a discontinued operation. The company will retain the commercial service business called Lennox National Account Services (NAS), previously reported within the Service Experts business segment, and is now reported in the Commercial Heating & Cooling business segment.  Results for prior periods have been restated to conform with this new presentation.

[0001069202-12-000005:mdna:9]
We sold the Hearth business in the second quarter of 2012 for $10.1 millon in net proceeds, which includes a $2.9 million working capital adjustment received in the third quarter of 2012 and excludes the transaction costs and cash transferred with the business.  The net loss from the sale of the Hearth business was $0.9 million.

[0001069202-12-000005:mdna:10]
[same as prior period, unchanged from 0001193125-12-311640:mdna:10]

[0001069202-12-000005:mdna:11]
| • | Net sales for the third quarter of 2012 increased to $809.7 million compared to $801.2 million in 2011, or a 1% increase. Net sales increased 3% excluding a 2% unfavorable foreign currency exchange rate impact. |

[0001069202-12-000005:mdna:12]
| • | Operational income from continuing operations ("operational income") for the third quarter of 2012 increased to $80.9 million as compared to $56.6 million in 2011. The increase in operational income was primarily due to higher volume and higher margins from material cost savings and a reduction in restructuring costs as cost saving initiatives wind down. |

[0001069202-12-000005:mdna:13]
| • | Net income for the third quarter of 2012 was $29.4 million compared to $33.8 million in 2011. Diluted earnings per share from continuing operations were $0.97 in the third quarter of 2012 compared to diluted earnings per share from continuing operations of $0.66 in 2011. |

[0001069202-12-000005:mdna:14]
| • | Cash provided by operating activities was $64 million in the first nine months of 2012 compared to net cash used in operations of $2 million in the first nine months of 2011. The increase in cash provided by operating activities was due primarily to higher income from continuing operations and an increase in accrued expenses in 2012. The increase in accrued expenses was due to an increase in incentive compensation from our improved operating results. These increases were partially offset by unfavorable working capital requirements in the first nine months of 2012 compared to the same period of 2011. |

[0001069202-12-000005:mdna:15]
Third Quarter of 2012 Compared to Third Quarter of 2011 – Consolidated Results

[0001069202-12-000005:mdna:16]
[same as prior period, unchanged from 0001193125-12-311640:mdna:16]

[0001069202-12-000005:mdna:17]
[same as prior period, unchanged from 0001193125-12-311640:mdna:17]

[0001069202-12-000005:mdna:18]
|  | For the Three Months Ended September 30, |
|  | Dollars |  | PercentChangeFav/(Unfav) |  | Percent Sales |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Net sales | $ | 809.7 |  |  | $ | 801.2 |  |  | 1.1 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 604.8 |  |  | 614.6 |  |  | 1.6 |  |  | 74.7 |  |  | 76.7 |  |
| Gross profit | 204.9 |  |  | 186.6 |  |  | 9.8 |  |  | 25.3 |  |  | 23.3 |  |
| Selling, general and administrative expenses | 125.9 |  |  | 122.4 |  |  | (2.9 | ) |  | 15.5 |  |  | 15.3 |  |
| Losses and other expenses, net | 0.3 |  |  | 2.6 |  |  | 88.5 |  |  | — |  |  | 0.3 |  |
| Restructuring charges | 0.4 |  |  | 8.0 |  |  | 95.0 |  |  | — |  |  | 1.0 |  |
| Income from equity method investments | (2.6 | ) |  | (3.0 | ) |  | (13.3 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Operational income | $ | 80.9 |  |  | $ | 56.6 |  |  | 42.9 | % |  | 10.0 | % |  | 7.1 | % |

[0001069202-12-000005:mdna:19]
[same as prior period, unchanged from 0001193125-12-311640:mdna:19]

[0001069202-12-000005:mdna:20]
Net sales increased 1% in the third quarter of 2012 compared to the third quarter of 2011. Our sales volume was up 2%, and price and mix were up 1% from the comparable period. The increase in volume was largely driven by our Residential Heating & Cooling segment and the increase in price and mix was largely driven by our Commercial Heating & Cooling and Refrigeration segments. Changes in foreign currency exchange rates unfavorably impacted net sales by 2%. Excluding the impact from unfavorable foreign currency exchange rates, net sales in the third quarter of 2012 were up 3% from the third quarter of 2011.

[0001069202-12-000005:mdna:21]
[same as prior period, unchanged from 0001193125-12-311640:mdna:21]

[0001069202-12-000005:mdna:22]
Gross profit margins of 25.3% in the third quarter of 2012 increased 200 basis points from profit margins of 23.3% in the third quarter of 2011.  Material cost savings added approximately 160 basis points to profit margins and other product costs savings added an additional 70 basis points. Improved price and mix also added approximately 20 basis points to profit

[0001069202-12-000005:mdna:23]
margins.  Partially offsetting these increases to profit margins was an increase in freight and distribution costs of 50 basis points.

[0001069202-12-000005:mdna:24]
[same as prior period, unchanged from 0001193125-12-311640:mdna:23]

[0001069202-12-000005:mdna:25]
Selling, general and administrative (“SG&A”) expenses increased by $3.5 million in the third quarter of 2012 compared to 2011.  As a percentage of net sales, SG&A expense increased slightly to 15.5% in 2012 compared to 15.3% in 2011. The increase in SG&A expenses was principally due to higher incentive compensation due to overall improved operating results in the third quarter of 2012.

[0001069202-12-000005:mdna:26]
[same as prior period, unchanged from 0001193125-12-311640:mdna:25]

[0001069202-12-000005:mdna:27]
Losses and other expenses, net for the third quarters of 2012 and 2011 included the following (in millions):

[0001069202-12-000005:mdna:28]
|  | For the Three Months Ended September 30, |
|  | 2012 |  | 2011 |
| Realized losses (gains) on settled futures contracts | $ | 0.5 |  |  | $ | (0.1 | ) |
| Unrealized losses (gains) on unsettled futures contracts not designated as cash flow hedges | (1.4 | ) |  | 3.5 |  |
| Foreign currency exchange losses (gains) | 1.0 |  |  | (0.6 | ) |
| Other items, net | 0.2 |  |  | (0.2 | ) |
| Losses and other expenses, net | $ | 0.3 |  |  | $ | 2.6 |  |

[0001069202-12-000005:mdna:29]
The change in unrealized gains and losses on settled futures contracts was primarily due to decreases in commodity prices relative to our futures contract prices during 2012 as compared to 2011. Conversely, the change in unrealized losses related to unsettled futures contracts not designated as cash flow hedges was primarily due to higher commodity prices relative to the futures contract prices. For more information, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-12-000005:mdna:30]
[same as prior period, unchanged from 0001193125-12-311640:mdna:29]

[0001069202-12-000005:mdna:31]
Restructuring charges declined from $8.0 million in the third quarter of 2011 to $0.4 million in the third quarter of 2012. We did not initiate any new large projects in the third quarter of 2012 and the charges in this period related to minor activity from various open projects initiated in prior years.  The restructuring charges from the third quarter of 2011 were primarily related to the exit of the corporate airplane lease, closure of the aviation department and reorganization of certain support functions. For more information, see Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-12-000005:mdna:32]
[same as prior period, unchanged from 0001193125-12-311640:mdna:31]

[0001069202-12-000005:mdna:33]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments declined slightly from $3.0 million in 2011 to $2.6 million in the third quarter of 2012 primarily due to reduced performance from our joint ventures.

[0001069202-12-000005:mdna:34]
[same as prior period, unchanged from 0001193125-12-311640:mdna:81]

[0001069202-12-000005:mdna:35]
Interest expense, net, was flat at $4 million in the third quarters of 2012 and 2011, as both our weighted average borrowings and weighted average interest rate were relatively comparable.

[0001069202-12-000005:mdna:36]
[same as prior period, unchanged from 0001193125-12-311640:mdna:35]

[0001069202-12-000005:mdna:37]
Income tax expense was $27 million in the third quarter of 2012 compared to $18 million in 2011. The effective tax rate was 35.0% for the third quarter of 2012 and 33.5% for the third quarter of 2011. Our effective rates differ from the statutory federal rate of 35% for certain items, such as state and local taxes, non-deductible expenses, foreign operating losses for which no tax benefits have been recognized and foreign taxes at rates other than 35%.

[0001069202-12-000005:mdna:38]
[same as prior period, unchanged from 0001193125-12-311640:mdna:37]

[0001069202-12-000005:mdna:39]
In the third quarter of 2012, we announced plans to sell the Service Experts business.  We had a pre-tax loss of $26.8 million in discontinued operations in the third quarter of 2012 for the Service Experts reporting unit compared to pre-tax income of $0.1 million in the third quarter of 2011.  The pre-tax loss from discontinued operations in the third quarter of 2012

[0001069202-12-000005:mdna:40]
included operating losses of $5.9 million and a goodwill impairment loss of $20.5 million.

[0001069202-12-000005:mdna:41]
In the fourth quarter of 2011, we began to pursue strategic alternatives for our Hearth reporting unit and subsequently sold this business in the second quarter of 2012. We had pre-tax income of $2 million in discontinued operations in the third quarter of 2012 for the Hearth reporting unit compared to a pre-tax loss of $2 million in the third quarter of 2011. The pre-tax income from discontinued operations in the third quarter of 2012 included a $3 million gain related to a working capital adjustment of sales proceeds offset by $1 million of other divestiture-related expenses.

[0001069202-12-000005:mdna:42]
Third Quarter of 2012 Compared to Third Quarter of 2011 – Results by Segment

[0001069202-12-000005:mdna:43]
Segment profit excludes restructuring expense and certain losses and other expenses. Refer to Note 14 in the Notes to the Consolidated Financial Statements for a reconciliation of segment profit (loss) to Income from continuing operations before income taxes.

[0001069202-12-000005:mdna:44]
[same as prior period, unchanged from 0001193125-12-311640:mdna:41]

[0001069202-12-000005:mdna:45]
The following table summarizes our Residential Heating & Cooling segment’s net sales and profit for the third quarters of 2012 and 2011 (dollars in millions):

[0001069202-12-000005:mdna:46]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 386.3 |  |  | $ | 353.8 |  |  | $ | 32.5 |  |  | 9.2 | % |
| Profit | 37.7 |  |  | 31.3 |  |  | 6.4 |  |  | 20.4 | % |
| % of net sales | 9.8 | % |  | 8.8 | % |  |  |  |  |

[0001069202-12-000005:mdna:47]
Residential Heating & Cooling’s net sales increased by 9% in the third quarter of 2012 compared to the third quarter of 2011. Sales volumes increased by 12%, partially offset by a 3% decline in price and mix in 2012 compared to 2011.

[0001069202-12-000005:mdna:48]
Segment profit for the third quarter increased $6 million compared to the third quarter of 2011 primarily due to a $9 million increase in volume, $8 million in material cost savings and $3 million in other product cost savings.  Segment profit was adversely affected by a $7 million decrease in price and mix, a $3 million increase in freight and distribution costs and a $4 million increase in SG&A costs due primarily to higher incentive compensation costs from improved overall operating results.

[0001069202-12-000005:mdna:49]
[same as prior period, unchanged from 0001193125-12-311640:mdna:46]

[0001069202-12-000005:mdna:50]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit for the third quarters of 2012 and 2011 (dollars in millions):

[0001069202-12-000005:mdna:51]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 219.7 |  |  | $ | 223.6 |  |  | $ | (3.9 | ) |  | (1.7 | )% |
| Profit | 32.5 |  |  | 31.1 |  |  | 1.4 |  |  | 4.5 | % |
| % of net sales | 14.8 | % |  | 13.9 | % |  |  |  |  |

[0001069202-12-000005:mdna:52]
Our Commercial Heating & Cooling business experienced a 2% decrease in net sales in the third quarter of 2012 compared to 2011. Excluding the 3% unfavorable impact from foreign currency exchange rates, our net sales increased by 1%. Sales volume was flat while pricing and mix were favorable by 1% compared to the third quarter of 2011.

[0001069202-12-000005:mdna:53]
Segment profit for the third quarter of 2012 increased $1 million compared to the third quarter of 2011 primarily as the result of $2 million in improved profit margins from favorable pricing and mix, offset by $1 million in increased SG&A costs.

[0001069202-12-000005:mdna:54]
[same as prior period, unchanged from 0001193125-12-311640:mdna:56]

[0001069202-12-000005:mdna:55]
The following table summarizes our Refrigeration segment’s net sales and profit for the third quarters of 2012 and 2011 (dollars in millions):

[0001069202-12-000005:mdna:56]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 203.7 |  |  | $ | 223.8 |  |  | $ | (20.1 | ) |  | (9.0 | )% |
| Profit | 25.1 |  |  | 20.5 |  |  | 4.6 |  |  | 22.4 | % |
| % of net sales | 12.3 | % |  | 9.2 | % |  |  |  |  |

[0001069202-12-000005:mdna:57]
Net sales decreased 9% in the third quarter of 2012 when compared to 2011. Sales volumes declined 12% and foreign currency exchange rates were unfavorable by 3%. Improved pricing and mix of 6% primarily for our refrigerant products partially offset these sales declines.

[0001069202-12-000005:mdna:58]
Segment profit for the third quarter increased by $5 million compared to the third quarter of 2012 primarily from a $6 million improvement in price and mix, $5 million of material cost savings and $2 million of other product cost savings.  These savings were partially offset by a $6 million decrease in volume and a $2 million increase in SG&A expense.

[0001069202-12-000005:mdna:59]
[same as prior period, unchanged from 0001193125-12-311640:mdna:61]

[0001069202-12-000005:mdna:60]
Corporate and other expenses, excluding restructuring, were $14 million in the third quarter of 2012, down $1 million from $15 million in 2011. The decrease was driven by various cost and productivity initiatives.

[0001069202-12-000005:mdna:61]
Year-to-Date through September 30, 2012 Compared to Year-to-Date through September 30, 2011 – Consolidated Results

[0001069202-12-000005:mdna:62]
[same as prior period, unchanged from 0001193125-12-311640:mdna:64]

[0001069202-12-000005:mdna:63]
[same as prior period, unchanged from 0001193125-12-311640:mdna:65]

[0001069202-12-000005:mdna:64]
|  | For the Nine Months Ended September 30, |
|  | Dollars |  | PercentChangeFav/(Unfav) |  | Percent Sales |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Net sales | $ | 2,264.5 |  |  | $ | 2,192.4 |  |  | 3.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,710.6 |  |  | 1,675.9 |  |  | (2.1 | ) |  | 75.5 |  |  | 76.4 |  |
| Gross profit | 553.9 |  |  | 516.5 |  |  | 7.2 |  |  | 24.5 |  |  | 23.6 |  |
| Selling, general and administrative expenses | 379.8 |  |  | 372.9 |  |  | (1.9 | ) |  | 16.8 |  |  | 17.0 |  |
| Losses and other expenses, net | 0.2 |  |  | 3.6 |  |  | 94.4 |  |  | — |  |  | 0.2 |  |
| Restructuring charges | 3.1 |  |  | 11.3 |  |  | 72.6 |  |  | 0.1 |  |  | 0.5 |  |
| Income from equity method investments | (8.8 | ) |  | (9.0 | ) |  | (2.2 | ) |  | (0.4 | ) |  | (0.4 | ) |
| Operational income | $ | 179.6 |  |  | $ | 137.7 |  |  | 30.4 | % |  | 7.9 | % |  | 6.3 | % |

[0001069202-12-000005:mdna:65]
[same as prior period, unchanged from 0001193125-12-311640:mdna:67]

[0001069202-12-000005:mdna:66]
Net sales increased 3% in the first nine months of 2012 compared to the first nine months of 2011. Excluding the 2% unfavorable impact from changes in foreign currency exchange rates, our net sales increased by 5%. Our sales volumes were up 5% and our price and mix were flat in the comparable period. The increase in volume was predominantly in our Residential Heating & Cooling segment with modest volume increases in our Commercial Heating & Cooling segment.

[0001069202-12-000005:mdna:67]
[same as prior period, unchanged from 0001193125-12-311640:mdna:69]

[0001069202-12-000005:mdna:68]
Gross profit margins improved 90 basis points to 24.5% for the first nine months of 2012 compared to 23.6% for the first nine months of 2011. Improved price and mix added 40 basis points to profit margins and commodities and non-commodity material costs improved by a collective 70 basis points over the comparable period.  Partially offsetting these increases were 20 basis points of higher freight and distribution costs in the first nine months of 2012.

[0001069202-12-000005:mdna:69]
[same as prior period, unchanged from 0001193125-12-311640:mdna:71]

[0001069202-12-000005:mdna:70]
SG&A expenses increased by $7 million in the first nine months of 2012 compared to 2011, but as a percentage of net

[0001069202-12-000005:mdna:71]
sales declined to 16.8% in 2012 from 17.0% in 2011. The increase in SG&A expenses was principally due to higher incentive compensation due to overall improved operating results in the third quarter of 2012.  The decline in SG&A expenses as a percent of net sales is due to sales volumes increasing faster than SG&A expense.

[0001069202-12-000005:mdna:72]
[same as prior period, unchanged from 0001193125-12-311640:mdna:73]

[0001069202-12-000005:mdna:73]
[same as prior period, unchanged from 0001193125-12-311640:mdna:74]

[0001069202-12-000005:mdna:74]
|  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |
| Realized losses (gains) on settled futures contracts | $ | 1.4 |  |  | $ | (1.0 | ) |
| Unrealized losses (gains) on unsettled futures contracts not designated as cash flow hedges | (2.5 | ) |  | 4.9 |  |
| Foreign currency exchange losses (gains) | 0.7 |  |  | — |  |
| Other items, net | 0.6 |  |  | (0.3 | ) |
| Losses and other expenses, net | $ | 0.2 |  |  | $ | 3.6 |  |

[0001069202-12-000005:mdna:75]
The change in gains and losses on settled futures contracts was primarily due to decreases in commodity prices relative to our futures contract prices during 2012 as compared to 2011. Conversely, the change in unrealized gains on unsettled futures contracts not designated as cash flow hedges was primarily due to higher commodity prices relative to the futures contract prices. For more information, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-12-000005:mdna:76]
[same as prior period, unchanged from 0001193125-12-311640:mdna:77]

[0001069202-12-000005:mdna:77]
Restructuring charges were $3 million in first nine months of 2012 and $11 million in the first nine months of 2011. We did not initiate any new large projects in the first nine months of 2012 and the $3 million restructuring expense in the first nine months of 2012 relates to our Regional Distribution Network project. The restructuring charges from the first nine months of 2011 were from corporate restructuring charges that included the exit of the corporate airplane lease, closure of the aviation department, and the reorganization of certain support functions. For more information, see Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-12-000005:mdna:78]
Results from Equity Method and Other Equity Investments

[0001069202-12-000005:mdna:79]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments were approximately $9 million for the first nine months of 2012 and the first nine months of 2011.

[0001069202-12-000005:mdna:80]
Interest Expense, Net

[0001069202-12-000005:mdna:81]
Interest expense, net, for the first nine months of 2012 of $13 million increased by approximately $1 million compared to the same period in 2011.  Our weighted average interest rates were relatively flat while our weighted average borrowings increased in the comparable periods.

[0001069202-12-000005:mdna:82]
[same as prior period, unchanged from 0001193125-12-311640:mdna:83]

[0001069202-12-000005:mdna:83]
The income tax expense was $58 million in the first nine months of 2012 compared to $42 million in 2011. The effective tax rate was 34.7% for 2012 and 33.8% in 2011. Our effective rates differ from the statutory federal rate of 35% for certain items, such as state and local taxes, non-deductible expenses, foreign operating losses for which no tax benefits have been recognized and foreign taxes at rates other than 35%.

[0001069202-12-000005:mdna:84]
[same as prior period, unchanged from 0001193125-12-311640:mdna:85]

[0001069202-12-000005:mdna:85]
In the third quarter of 2012, we announced plans to sell the Service Experts business.  We had a pre-tax loss of $43 million in discontinued operations for the first nine months of 2012 for the Service Experts reporting unit compared to a pre-tax loss of $8 million in the first nine months of 2011. The pre-tax loss from discontinued operations in 2012 included operating losses of $21 million, a goodwill impairment loss of $20.5 million, and restructuring costs of $1 million.

[0001069202-12-000005:mdna:86]
In the fourth quarter of 2011, we began to pursue strategic alternatives for our Hearth reporting unit and subsequently sold this business in the second quarter of 2012. We had a pre-tax loss of $14 million in discontinued operations in the first nine

[0001069202-12-000005:mdna:87]
months of 2012 for the Hearth reporting unit compared to a pre-tax loss of $10 million in the first nine months of 2011. The pre-tax loss in 2012 included $3 million in operating losses, a $6 million charge to write down the related assets to their fair value, a $6 million pension settlement charge for the realization of pension losses related to the transfer of a pension to the buyer, a $1 million loss on the sale of the business, and a $4 million gain for the realization of foreign currency translation adjustments.

[0001069202-12-000005:mdna:88]
Year-to-Date Through September 30, 2012 Compared to Year-to-Date Through September 30, 2011 – Results by Segment

[0001069202-12-000005:mdna:89]
Segment profit excludes restructuring expense and certain losses and other expenses. Refer to Note 14 in the Notes to the Consolidated Financial Statements for a reconciliation of segment profit (loss) to Income from continuing operations before income taxes.

[0001069202-12-000005:mdna:90]
[same as prior period, unchanged from 0001193125-12-311640:mdna:89]

[0001069202-12-000005:mdna:91]
The following table summarizes our Residential Heating & Cooling segment’s net sales and profit for the first nine months of 2012 and 2011 (dollars in millions):

[0001069202-12-000005:mdna:92]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 1,070.7 |  |  | $ | 979.7 |  |  | $ | 91.0 |  |  | 9.3 | % |
| Profit | 90.7 |  |  | 70.9 |  |  | 19.8 |  |  | 27.9 | % |
| % of net sales | 8.5 | % |  | 7.2 | % |  |  |  |  |

[0001069202-12-000005:mdna:93]
Residential Heating & Cooling net sales increased by 9% in the first nine months of 2012 compared to the first nine months of 2011. Sales volumes increased by 12% in the first nine months of 2012 as compared to 2011 and were partially offset by lower price and mix of 3%.

[0001069202-12-000005:mdna:94]
Segment profit for the first nine months of 2012 increased $20 million due to $32 million in higher sales volumes and $8 million in material cost savings. Partially offsetting these increases in segment profit were $17 million in unfavorable price and mix, $2 million from a less favorable warranty adjustment and $1 million in higher SG&A costs.

[0001069202-12-000005:mdna:95]
[same as prior period, unchanged from 0001193125-12-311640:mdna:94]

[0001069202-12-000005:mdna:96]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit for the first nine months of 2012 and 2011 (dollars in millions):

[0001069202-12-000005:mdna:97]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 597.9 |  |  | $ | 596.4 |  |  | $ | 1.5 |  |  | 0.3 | % |
| Profit | 74.1 |  |  | 67.2 |  |  | 6.9 |  |  | 10.3 | % |
| % of net sales | 12.4 | % |  | 11.3 | % |  |  |  |  |

[0001069202-12-000005:mdna:98]
Commercial Heating & Cooling net sales were relatively flat in the first nine months of 2012 compared to 2011. Excluding the 3% unfavorable impact from foreign currency exchange rates, our net sales increased by 3%. Our sales volume increased by 2% and price and mix also increased by 1%.

[0001069202-12-000005:mdna:99]
Segment profit for the first nine months of 2012 increased $7 million from the first nine months of 2011. Segment profit increased from the impact of higher sales volume by $3 million, favorable price and mix by $6 million and other product cost savings by $4 million. Partially offsetting these increases to segment profit were higher material costs of $1 million, higher freight and distribution charges of $2 million, and increased SG&A expenses of $3 million.  The increased SG&A expenses were primarily due to increased incentive compensation from improved overall operating results in 2012.

[0001069202-12-000005:mdna:100]
[same as prior period, unchanged from 0001193125-12-311640:mdna:104]

[0001069202-12-000005:mdna:101]
The following table summarizes our Refrigeration segment’s net sales and profit for the first nine months of 2012 and 2011 (dollars in millions):

[0001069202-12-000005:mdna:102]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2012 |  | 2011 |  | Difference |  | % Change |
| Net sales | $ | 595.9 |  |  | $ | 616.3 |  |  | $ | (20.4 | ) |  | (3.3 | )% |
| Profit | 60.6 |  |  | 55.5 |  |  | 5.1 |  |  | 9.2 | % |
| % of net sales | 10.2 | % |  | 9.0 | % |  |  |  |  |

[0001069202-12-000005:mdna:103]
Net sales decreased by 3% in the first nine months of 2012 compared to the first nine months of 2011. Excluding the 3% unfavorable impact from foreign currency exchange rates, our net sales were flat in 2012.   Price and mix improvements of approximately 3% were offset by a volume decline of 3% in comparable periods.

[0001069202-12-000005:mdna:104]
Segment profit for the first nine months of 2012 increased by $5 million compared to the first nine months of 2011. Segment profit increased $12 million from the impact of higher price and mix in net sales and $9 million due to material cost savings. Partially offsetting these increases were $4 million in increased SG&A expense, $5 million from lower volumes, $3 million in higher other product costs, and $4 million from unfavorable foreign currency exchange rates.

[0001069202-12-000005:mdna:105]
[same as prior period, unchanged from 0001193125-12-311640:mdna:109]

[0001069202-12-000005:mdna:106]
Corporate and other expenses, excluding restructuring, were $44 million in the first nine months of 2012, up from $42 million in 2011. The increase was primarily driven by higher incentive compensation expense in 2012 due to the overall increase in operating performance in the first nine months of 2012.

[0001069202-12-000005:mdna:107]
[same as prior period, unchanged from 0001193125-12-311640:mdna:111]

[0001069202-12-000005:mdna:108]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and a revolving period asset securitization arrangement. Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-12-000005:mdna:109]
[same as prior period, unchanged from 0001193125-12-311640:mdna:113]

[0001069202-12-000005:mdna:110]
The following table summarizes our cash activity for the nine months ended September 30, 2012 and 2011 (in millions):

[0001069202-12-000005:mdna:111]
|  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |
| Net cash provided by (used in) operating activities | $ | 64.4 |  |  | $ | (2.2 | ) |
| Net cash used in investing activities | (18.1 | ) |  | (161.7 | ) |
| Net cash provided by (used in) financing activities | (48.5 | ) |  | 65.2 |  |

[0001069202-12-000005:mdna:112]
Net Cash Provided by (Used in) Operating Activities

[0001069202-12-000005:mdna:113]
Operating activities resulted in positive cash generation in 2012 compared to cash usage in 2011.  The increase was primarily due to higher income from continuing operations and an increase in accrued expenses in 2012, offset by lower accounts payable.  Our working capital requirements resulted in a $123 million use of cash in the first nine months of 2012 compared to an $88 million use of cash in 2011. The increase in working capital requirements was primarily related to lower accounts payable due to the timing of payments. The increase in accrued expenses in the first nine months of 2012 compared to the same period of 2011 is due primarily to increased incentive compensation as a result of improved overall operating results.

[0001069202-12-000005:mdna:114]
[same as prior period, unchanged from 0001193125-12-311640:mdna:118]

[0001069202-12-000005:mdna:115]
Net cash used in investing activities for the first nine months of 2012 included $10.1 million in net proceeds from the sale of the Hearth business. For the first nine months of 2011, net cash used in investing activities included $143.3 million for the acquisition of the Kysor/Warren business from The Manitowoc Company and $4.4 million for the acquisition of a commercial services business in our Commercial Heating & Cooling segment.

[0001069202-12-000005:mdna:116]
Capital expenditures in the first nine months of 2012 were $28.0 million, which was slightly higher than the $25.8 million in the first nine months of 2011. Capital expenditures in the first nine months of 2012 were primarily related to investments in our distribution network, investments in systems and software to support the overall enterprise and maintenance

[0001069202-12-000005:mdna:117]
capital expenditures.

[0001069202-12-000005:mdna:118]
Net Cash Provided by (Used in) Financing Activities

[0001069202-12-000005:mdna:119]
Net cash used in financing activities was $48.5 million in the first nine months of 2012 compared to net cash provided by financing activities of $65.2 million in the first nine months of 2011. This decrease was primarily related to fewer net borrowings and a reduction in share repurchases in 2012. The net borrowings were higher in the first nine months of 2011 to support the Kysor/Warren acquisition.

[0001069202-12-000005:mdna:120]
[same as prior period, unchanged from 0001193125-12-311640:mdna:123]

[0001069202-12-000005:mdna:121]
The following table details our lines of credit and financing arrangements as of September 30, 2012 (in millions):

[0001069202-12-000005:mdna:122]
|  | MaximumCapacity |  | OutstandingBorrowings |  | Available forFutureBorrowings |
| Short-Term Debt: |  |  |  |  |  |
| Foreign Obligations | $ | 6.1 |  |  | $ | 6.1 |  |  | $ | — |  |
| Asset Securitization (1) | 150.0 |  |  | 25.0 |  |  | 125.0 |  |
| Total short-term debt | $ | 156.1 |  |  | $ | 31.1 |  |  | $ | 125.0 |  |
| Current Maturities of Long-Term Debt: | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | — |  |
| Long-Term Debt: |  |  |  |  |  |
| Capital lease obligations | $ | 16.6 |  |  | $ | 16.6 |  |  | $ | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 233.0 |  |  | 367.1 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | $ | 866.6 |  |  | $ | 449.6 |  |  | $ | 367.1 |  |
| Total | $ | 1,023.0 |  |  | $ | 481.0 |  |  | $ | 492.1 |  |

[0001069202-12-000005:mdna:123]
[same as prior period, unchanged from 0001193125-12-311640:mdna:126]

[0001069202-12-000005:mdna:124]
| (2) | The available future borrowings on our domestic revolving credit facility exclude $49.9 million in standby letters of credit. We had an additional $20.0 million in stand-by letters of credit with other banks. |

[0001069202-12-000005:mdna:125]
As our peak season arrives, we typically pay down debt. We believe our available future borrowings combined with our cash of $48.8 million and future cash from operations are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, dividends and other needs in the foreseeable future. Included in our cash and cash equivalents of $48.8 million at September 30, 2012, we had $26.2 million of cash held in foreign locations. Our cash in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States. If we were to repatriate this cash, we would be required to accrue and to pay taxes in the United States for the amounts that were repatriated.

[0001069202-12-000005:mdna:126]
Our debt-to-total-capital ratio decreased to 48.6% at September 30, 2012 compared to 49.9% at December 31, 2011. The decrease in the ratio is due to an increase in retained earnings at September 30, 2012 primarily related to higher net income and reduced share repurchase activity.

[0001069202-12-000005:mdna:127]
Covenants on our outstanding debt did not change in the third quarter of 2012 and we were in compliance with all of our debt covenants as of September 30, 2012. For a more detailed discussion of our debt, see Note 7 in the Notes to the Consolidated Financial Statements set forth in Part I, Item I of this Quarterly Report on Form 10-Q.

[0001069202-12-000005:mdna:128]
We periodically review our capital structure, including our primary bank facility, to ensure that it has adequate liquidity. We also periodically consider various other financing alternatives and may, from time to time, seek to take advantage of favorable interest rate environments or other market conditions, which may include accessing the capital markets.

[0001069202-12-000005:mdna:129]
On March 30, 2012, the parties involved with the Asset Securitization Program (“ASP”) agreed to remove Lennox Hearth Products LLC from the ASP. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. We do not believe the removal of Lennox Hearth Products LLC from the ASP will have a significant impact on the available borrowings under the

[0001069202-12-000005:mdna:130]
ASP. The eligible amount to borrow under the program as of September 30, 2012 was $125.0 million.

[0001069202-12-000005:mdna:131]
Dividend payments are expected to be approximately $37.5 million in 2012. We also continue to increase shareholder value through our share repurchase program. We are planning a minimum of $50 million in share repurchases in 2012.

[0001069202-12-000005:mdna:132]
Off-Balance Sheet Arrangements

[0001069202-12-000005:mdna:133]
In addition to the credit facilities and promissory notes described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.

[0001069202-12-000005:mdna:134]
Commitments, Contingencies and Guarantees

[0001069202-12-000005:mdna:135]
For a detailed discussion of commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-12-000005:mdna:136]
The estimate of our liability for future warranty costs requires us to make significant assumptions about the amount, timing and nature of the costs we will incur in the future. We periodically review the assumptions used to determine the liability and adjust our assumptions based upon factors such as actual failure rates and cost experience. Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, and changes in manufacturing techniques or locations, components or suppliers used. In recent years, changes in the warranty liability as the result of the issuance of new warranties and the payments made have remained relatively stable. Should actual warranty costs differ from our estimates, we may be required to record adjustments to accruals and expense in the future. At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year, we perform a complete re-evaluation of our warranty liabilities.

[0001069202-12-000005:mdna:137]
We also may incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications. We identified product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in the second quarter of 2012. We recorded $1.0 million for these matters in the third quarter of 2012, and as of September 30, 2012, we had $7.1 million accrued for these matters. We may incur additional charges in the future as more information becomes available.

[0001069202-12-000005:mdna:138]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts known. We do not believe that any current, pending or threatened litigation will have a material adverse effect on our financial position. Litigation, however, involves uncertainties and it is possible that the eventual outcome of litigation could adversely affect our results of operations for a particular period.
