# LII note change history — 0001193125-12-311640 → 0001069202-12-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-10-22):
[0001069202-12-000005:note_history:1]
Commitments and Contingencies:
  (was, 2012-07-24, similarity 0.9677):
[0001193125-12-311640:note_history:1]
6. Commitments and Contingencies:

- changed (2012-10-22):
[0001069202-12-000005:note_history:2]
We are subject to contingencies that arise in the normal course of business, including pending litigation, product warranties and other product related contingencies, environmental matters and other guarantees or claims.
  (was, 2012-07-24, similarity 0.6636):
[0001193125-12-311640:note_history:2]
We are subject to contingencies that arise in the normal course of business, including product warranties and other
   product related contingencies, pending litigation, environmental matters and other guarantees or claims.

- changed (2012-10-22):
[0001069202-12-000005:note_history:3]
We use a combination of third-party insurance and large deductible self-insurance plans to provide protection against claims relating to contingencies such as workers’ compensation, general liability, product liability, property damage, aviation liability, directors’ and officers’ liability, auto liability, physical damage and other exposures. Self-insurance expense and liabilities are actuarially determined based on our historical claims information, as well as industry factors and trends. The majority of our self-insured risks (excluding auto liability and physical damage) will be paid over an extended period of time. There have been no material changes in our insurance liability since our latest fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our large deductible plans. The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were $64.0 million and $63.1 million as of September 30, 2012 and December 31, 2011, respectively.
  (was, 2012-07-24, similarity 0.8953):
[0001193125-12-311640:note_history:3]
We use a combination
   of third-party insurance and self-insurance plans (large deductible or captive) to provide protection against claims relating to contingencies such as workers’ compensation, general liability, product liability, property damage, aviation
   liability, directors’ and officers’ liability, auto liability, physical damage and other exposures. Self-insurance expense and liabilities are actuarially determined based on our historical claims information, as well as industry factors
   and trends. Because we have a captive insurance company, we are required to maintain specified levels of liquid assets from which we must pay claims. The majority of our self-insured risks (excluding auto liability and physical damage) will be paid
   over an extended period of time. There have been no material changes in our insurance liability since our latest fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our large deductible or captive insurance
   plans. The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were $62.8 million and $63.3 million as of June 30, 2012 and December 31, 2011, respectively.

- changed (2012-10-22):
[0001069202-12-000005:note_history:4]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic Revolving Credit Facility. We were in compliance with these financial covenants as of September 30, 2012.
  (was, 2012-07-24, similarity 0.9827):
[0001193125-12-311640:note_history:4]
Our obligations under the Lake
   Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic
   Revolving Credit Facility. We were in compliance with these financial covenants as of June 30, 2012.

- changed (2012-10-22):
[0001069202-12-000005:note_history:5]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Accrued expenses | $ | 25.5 |  |  | $ | 26.7 |  |
| Other liabilities | 45.1 |  |  | 41.6 |  |
|  | $ | 70.6 |  |  | $ | 68.3 |  |
  (was, 2012-07-24, similarity 0.836):
[0001193125-12-311640:note_history:5]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
| Accrued expenses |  | $ | 27.7 |  |  | $ | 29.4 |  |
| Other liabilities |  |  | 44.2 |  |  |  | 41.8 |  |
|  |  | $ | 71.9 |  |  | $ | 71.2 |  |

- changed (2012-10-22):
[0001069202-12-000005:note_history:6]
The changes in total product warranty liabilities for the first nine months of 2012 were as follows (in millions):
  (was, 2012-07-24, similarity 0.9395):
[0001193125-12-311640:note_history:6]
The changes in total product warranty liabilities for the first half of 2012 were as follows (in millions):

- changed (2012-10-22):
[0001069202-12-000005:note_history:7]
| Total warranty liability as of December 31, 2011 | $ | 68.3 |  |
| Payments made in 2012 | (18.2 | ) |
| Changes resulting from issuance of new warranties | 20.0 |  |
| Changes in estimates associated with pre-existing liabilities | 0.2 |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of September 30, 2012 | $ | 70.6 |  |
  (was, 2012-07-24, similarity 0.9173):
[0001193125-12-311640:note_history:7]
| Total warranty liability as of December 31, 2011 |  | $ | 71.2 |  |
| Payments made in 2012 |  |  | (12.5 | ) |
| Changes resulting from issuance of new warranties |  |  | 14.1 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (0.6 | ) |
| Changes in foreign currency translation rates and other |  |  | (0.3 | ) |
| Total warranty liability as of June 30, 2012 |  | $ | 71.9 |  |

- changed (2012-10-22):
[0001069202-12-000005:note_history:8]
At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year, we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities. As a result of the second quarter re-evaluation, we decreased our warranty liability by $0.4 million.
  (was, 2012-07-24, similarity 0.9725):
[0001193125-12-311640:note_history:8]
At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year,
   we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities. As a result of this re-evaluation, we decreased our warranty liability by $0.4 million.

- added (2012-10-22):
[0001069202-12-000005:note_history:9]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in the second quarter of 2012. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the first nine months of 2012 were as follows (in millions):

- changed (2012-10-22):
[0001069202-12-000005:note_history:10]
| Total accrued product quality issue as of December 31, 2011 | $ | 7.5 |  |
| Estimated expense for expected product quality claims | 1.7 |  |
| Product quality claims | (2.1 | ) |
| Total accrued product quality issue as of September 30, 2012 | $ | 7.1 |  |
  (was, 2012-07-24, similarity 0.8075):
[0001193125-12-311640:note_history:10]
| Total accrued product quality issue as of December 31, 2011 |  | $ | 7.5 |  |
| Estimated expense for expected product quality claims |  |  | 0.7 |  |
| Product quality claims |  |  | (1.7 | ) |
| Total accrued product quality issue as of June 30, 2012 |  | $ | 6.5 |  |

- removed (2012-10-22):
[0001193125-12-311640:note_history:11]
In addition to normal product warranty, we identified product quality issues we believe resulted from vendor supplied materials: a
   heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in the second quarter of 2012. The expense for these product quality issues, and the related liabilities, are not included in the above tables related
   to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the
   Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the first half of 2012 were as follows (in millions):


## us-gaap:ProductLiabilityContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2012-10-22):
[0001069202-12-000005:note_history:12]
The changes in the accrued product quality issues for the first nine months of 2012 were as follows (in millions):

- changed (2012-10-22):
[0001069202-12-000005:note_history:13]
| Total accrued product quality issue as of December 31, 2011 | $ | 7.5 |  |
| Estimated expense for expected product quality claims | 1.7 |  |
| Product quality claims | (2.1 | ) |
| Total accrued product quality issue as of September 30, 2012 | $ | 7.1 |  |
  (was, 2012-07-24, similarity 0.8075):
[0001193125-12-311640:note_history:13]
| Total accrued product quality issue as of December 31, 2011 |  | $ | 7.5 |  |
| Estimated expense for expected product quality claims |  |  | 0.7 |  |
| Product quality claims |  |  | (1.7 | ) |
| Total accrued product quality issue as of June 30, 2012 |  | $ | 6.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-10-22):
[0001069202-12-000005:note_history:14]
General:
  (was, 2012-07-24, similarity 0.8889):
[0001193125-12-311640:note_history:14]
1. General:

- changed (2012-10-22):
[0001069202-12-000005:note_history:15]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2012, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2012 and 2011, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2011. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2012-07-24, similarity 0.9482):
[0001193125-12-311640:note_history:15]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2012, the accompanying unaudited Consolidated Statements of
   Operations for the three and six months ended June 30, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2012 and 2011, and the accompanying unaudited Consolidated
   Statements of Cash Flows for the six months ended June 30, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended
   December 31, 2011. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to
   Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position,
   results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we
   believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2012-10-22):
[0001069202-12-000005:note_history:16]
Our weighted average borrowing rate on the facility was as follows:

- changed (2012-10-22):
[0001069202-12-000005:note_history:17]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Weighted average borrowing rate | 1.47 | % |  | 1.53 | % |
  (was, 2012-07-24, similarity 0.8889):
[0001193125-12-311640:note_history:17]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Weighted average borrowing rate |  |  | 1.49 | % |  |  | 1.53 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-10-22):
[0001069202-12-000005:note_history:18]
Lines of Credit and Financing Arrangements:
  (was, 2012-07-24, similarity 0.9773):
[0001193125-12-311640:note_history:18]
7. Lines of Credit and Financing Arrangements:

- added (2012-10-22):
[0001069202-12-000005:note_history:19]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 25.0 |  |  | $ | — |  |
| Foreign obligations | 6.1 |  |  | 4.7 |  |
| Total short-term debt | $ | 31.1 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: | $ | 0.3 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.6 |  |  | $ | 16.6 |  |
| Domestic revolving credit facility | 233.0 |  |  | 243.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 449.6 |  |  | $ | 459.6 |  |
| Total debt | $ | 481.0 |  |  | $ | 465.1 |  |

- changed (2012-10-22):
[0001069202-12-000005:note_history:20]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $6.1 million and $4.7 million of foreign obligations as of September 30, 2012 and December 31, 2011, respectively.
  (was, 2012-07-24, similarity 0.9756):
[0001193125-12-311640:note_history:20]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs
   for our foreign locations. We had $14.2 million and $4.7 million of foreign obligations as of June 30, 2012 and December 31, 2011, respectively.

- changed (2012-10-22):
[0001069202-12-000005:note_history:21]
Under the Receivables Purchase Agreement, or Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. The ASP provides for a maximum securitization amount of the lesser of $150.0 million or 100% of the net pool balance as defined by the ASP. However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. On March 30, 2012, the parties involved with this securitization program agreed to remove Lennox Hearth Products LLC from the program. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. The eligible amounts available and beneficial interests sold were as follows (in millions):
  (was, 2012-07-24, similarity 0.9977):
[0001193125-12-311640:note_history:21]
Under the Receivables Purchase Agreement, or
   Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to renewal and contains a provision
   whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. The
   sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying
   Consolidated Statements of Cash Flows. The ASP provides for a maximum securitization amount of the lesser of $150.0 million or 100% of the net pool balance as defined by the ASP. However, eligibility for securitization is limited based on the amount
   and quality of the qualifying accounts receivable and is calculated monthly. On March 30, 2012, the parties involved with this securitization program agreed to remove Lennox Hearth Products LLC from the program. Any receivables originated by
   Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. The eligible amounts available and beneficial interests sold were as follows (in
   millions):

- added (2012-10-22):
[0001069202-12-000005:note_history:22]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 150.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold | 25.0 |  |  | — |  |
| Remaining amount available | $ | 125.0 |  |  | $ | 150.0 |  |

- changed (2012-10-22):
[0001069202-12-000005:note_history:23]
Under the ASP, we pay certain discount fees to use the program and have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for September 30, 2012 was 0.87% and the average rate at December 31, 2011 was 0.91%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):
  (was, 2012-07-24, similarity 0.9868):
[0001193125-12-311640:note_history:23]
Under the ASP, we pay certain discount fees to use the program and have the facility available to us. These fees relate
   to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee
   of 0.60%. The average rate for June 30, 2012 was 0.86% and the average rate at December 31, 2011 was 0.91%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed
   rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP recorded was as follows (in millions):

- added (2012-10-22):
[0001069202-12-000005:note_history:24]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.9 |  |  | $ | 0.5 |  |

- changed (2012-10-22):
[0001069202-12-000005:note_history:25]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Domestic Revolving Credit Facility and senior unsecured notes. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the ASP. As of September 30, 2012, we were in compliance with all covenant requirements.
  (was, 2012-07-24, similarity 0.9885):
[0001193125-12-311640:note_history:25]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default
   provisions with our Domestic Revolving Credit Facility and senior unsecured notes. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade
   credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the ASP. As of June 30, 2012, we were in compliance with all covenant requirements.

- added (2012-10-22):
[0001069202-12-000005:note_history:26]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $233.0 million and $49.9 million committed to standby letters of credit as of September 30, 2012. Subject to covenant limitations, $367.1 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2012-10-22):
[0001069202-12-000005:note_history:27]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Weighted average borrowing rate | 1.47 | % |  | 1.53 | % |
  (was, 2012-07-24, similarity 0.8889):
[0001193125-12-311640:note_history:27]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Weighted average borrowing rate |  |  | 1.49 | % |  |  | 1.53 | % |

- changed (2012-10-22):
[0001069202-12-000005:note_history:28]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |
  (was, 2012-07-24, similarity 0.9597):
[0001193125-12-311640:note_history:28]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |

- changed (2012-10-22):
[0001069202-12-000005:note_history:29]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |
  (was, 2012-07-24, similarity 0.9859):
[0001193125-12-311640:note_history:29]
|  | • |  | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

- changed (2012-10-22):
[0001069202-12-000005:note_history:30]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |
  (was, 2012-07-24, similarity 0.9925):
[0001193125-12-311640:note_history:30]
|  | • |  | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

- changed (2012-10-22):
[0001069202-12-000005:note_history:31]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2012, we were in compliance with all covenant requirements.
  (was, 2012-07-24, similarity 0.9521):
[0001193125-12-311640:note_history:31]
If any event of
   default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic
   Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of June 30, 2012, we were in
   compliance with all covenant requirements.

- changed (2012-10-22):
[0001069202-12-000005:note_history:32]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2012, we were in compliance with all covenant requirements.
  (was, 2012-07-24, similarity 0.9923):
[0001193125-12-311640:note_history:32]
The notes are
   guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other
   things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our
   assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded
   within 30 days of the notice date. As of June 30, 2012, we were in compliance with all covenant requirements.

- removed (2012-10-22):
[0001193125-12-311640:note_history:33]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Total short-term debt |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: |  | $ | 0.5 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.7 |  |  |  | 16.6 |  |
| Domestic revolving credit facility |  |  | 297.5 |  |  |  | 243.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 514.2 |  |  | $ | 459.6 |  |
| Total debt |  | $ | 528.9 |  |  | $ | 465.1 |  |

- removed (2012-10-22):
[0001193125-12-311640:note_history:34]
|  |  | As ofJune 30,2012 |  |  | As ofDecember 31,2011 |  |
| Eligible amount available under the ASP on qualified accounts receivable |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 150.0 |  |  | $ | 150.0 |  |

- removed (2012-10-22):
[0001193125-12-311640:note_history:35]
|  |  | For the Three Months Ended June 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Interest expense (including fees) |  | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.6 |  |  | $ | 0.2 |  |

- removed (2012-10-22):
[0001193125-12-311640:note_history:36]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of
   $297.5 million and $58.5 million committed to standby letters of credit as of June 30, 2012. Subject to covenant limitations, $294.0 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of
   letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of
   $100 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2012-10-22):
[0001069202-12-000005:note_history:37]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

- added (2012-10-22):
[0001069202-12-000005:note_history:38]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 25.0 |  |  | $ | — |  |
| Foreign obligations | 6.1 |  |  | 4.7 |  |
| Total short-term debt | $ | 31.1 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: | $ | 0.3 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.6 |  |  | $ | 16.6 |  |
| Domestic revolving credit facility | 233.0 |  |  | 243.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 449.6 |  |  | $ | 459.6 |  |
| Total debt | $ | 481.0 |  |  | $ | 465.1 |  |

- removed (2012-10-22):
[0001193125-12-311640:note_history:39]
|  |  | As of June 30,2012 |  |  | As of December 31,2011 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Total short-term debt |  | $ | 14.2 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: |  | $ | 0.5 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 16.7 |  |  |  | 16.6 |  |
| Domestic revolving credit facility |  |  | 297.5 |  |  |  | 243.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 514.2 |  |  | $ | 459.6 |  |
| Total debt |  | $ | 528.9 |  |  | $ | 465.1 |  |
