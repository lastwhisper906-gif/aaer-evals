# LII 8-K — 0001193125-12-429395 filed 2012-10-22

## item codes, every 8-K on or before 2012-10-22

- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2012-10-22

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-12-429395:8k_2_02:1]
EX-99.1
2
d428121dex991.htm
PRESS RELEASE DATED OCTOBER 22, 2012

[0001193125-12-429395:8k_2_02:2]
Press Release dated October 22, 2012

[0001193125-12-429395:8k_2_02:3]
Exhibit 99.1

[0001193125-12-429395:8k_2_02:4]
Lennox International Reports Third Quarter Results

[0001193125-12-429395:8k_2_02:5]
| • |  | Revenue up 3% at constant currency, led by 9% Residential growth |

[0001193125-12-429395:8k_2_02:6]
| • |  | Adjusted EPS from continuing operations of $0.97, up 23% |

[0001193125-12-429395:8k_2_02:7]
| • |  | GAAP EPS from continuing operations of $0.97, up 47% |

[0001193125-12-429395:8k_2_02:8]
| • |  | 2012 guidance for adjusted EPS from continuing operations increased from $2.35-$2.65 to a range of $2.60-$2.80 adjusted for the Service Experts move to discontinued operations |

[0001193125-12-429395:8k_2_02:9]
| • |  | Repurchased $35 million of stock in the quarter and raised dividend 11% |

[0001193125-12-429395:8k_2_02:10]
DALLAS, October 22, 2012 – Lennox International Inc. (NYSE: LII) today reported financial results for the third quarter of 2012. Financial
results presented have been adjusted for discontinued operations related to the company’s previously announced plans to divest the Service Experts business.

[0001193125-12-429395:8k_2_02:11]
Revenue for the third quarter was $810 million, up 1% from the prior-year quarter. At constant currency, revenue was up 3%. Adjusted earnings per share from continuing operations was $0.97, up 23% from
$0.79 in the prior-year quarter. On a GAAP basis, earnings per share from continuing operations was $0.97, up 47% from $0.66 in the prior-year quarter.

[0001193125-12-429395:8k_2_02:12]
“Our Residential business continued its strong growth in both replacement and new construction markets in the third quarter, with revenue up 9% and profit up 20%,” said Chairman and CEO Todd
Bluedorn. “In our Commercial business, profit was up 5% on 1% revenue growth at constant currency – with North America down low single digits on the timing of national account business and Europe up high single digits. In Refrigeration,
revenue was down 6% at constant currency, also impacted by the timing of national account business in North America as well as some slowing in Europe – our other regions saw nice growth. Strong execution on operational initiatives drove 22%
profit growth in Refrigeration. Overall for the company, revenue was up 3% at constant currency in the quarter, with total segment profit up 19%. Looking ahead, we expect our momentum in Residential to continue. Backlog and order rates in our
Commercial and Refrigeration businesses look solid overall, and we expect an improved national account environment in the fourth quarter. For the full year, our guidance for adjusted EPS from continuing operations is now $2.60-$2.80, with the
midpoint up 20% from $2.25 last year.”

[0001193125-12-429395:8k_2_02:13]
FINANCIAL HIGHLIGHTS

[0001193125-12-429395:8k_2_02:14]
Revenue: Revenue for the third quarter was $810 million, up 1% from the prior-year quarter. At constant currency, revenue was up 3%. Volume and price were up, and mix was down from the prior-year
quarter.

[0001193125-12-429395:8k_2_02:15]
Gross Profit: Gross profit for the third quarter was $205 million, up 10% from the prior-year quarter. Gross margin was
25.3%, up 200 basis points from 23.3% in the prior-year quarter. For gross margin, lower material costs and productivity initiatives were favorable, price/mix was neutral, and currency was unfavorable.

[0001193125-12-429395:8k_2_02:16]
Income from Continuing Operations: Adjusted income from continuing operations in the third quarter was $49.7 million, or $0.97 earnings per share,
compared to $41.9 million, or $0.79 earnings per share, in the prior-year quarter. Adjusted income from continuing operations for the third quarter of 2012 excludes an after-tax charge of $0.3 million for restructuring activities, $0.9 million
after-tax for the net change in unrealized gains on open future contracts, and an after-tax charge of $0.6 million for a special product quality adjustment and other items, net.

[0001193125-12-429395:8k_2_02:17]
On a GAAP basis, income from continuing operations for the third quarter was $49.7 million, or $0.97 earnings per share, compared to $34.9 million, or $0.66 earnings per share, in the prior-year quarter.

[0001193125-12-429395:8k_2_02:18]
Loss from Discontinued Operations: The loss from discontinued operations in the third quarter of 2012 was $20.3 million after-tax, or
$0.40 loss per share, compared to a loss of $1.1 million after-tax, or $0.02 loss per share, in the third quarter of 2011. The Service Experts business was placed in discontinued operations in the third quarter of 2012 due to the previously
announced plans to divest the business. On an operating basis, Service Experts lost $5.9 million pre-tax, or $0.08 loss per share, in the third quarter of 2012, compared to a profit of $3.0 million pre-tax, or $0.04 earnings per share, in the
prior-year quarter.

[0001193125-12-429395:8k_2_02:19]
(Revised 2011-2012 quarterly and 2007-2011 annual earnings statements that show the effect of the move of the Service
Experts business to discontinued operations and the move of the Lennox National Account Services business to the Commercial Heating & Cooling segment are available at www.lennoxinternational.com.)

[0001193125-12-429395:8k_2_02:20]
Free Cash Flow and Total Debt: Cash from operations in the third quarter was $75 million compared to $140 million in the prior-year quarter. The
company invested $12 million in capital assets in the third quarter. Free cash flow was $63 million, compared to $132 million in the prior-year quarter. Year-to-date through September, free cash flow was $36 million compared to ($28) million in the
prior-year period. Total debt at the end of the third quarter was $481 million. Total cash and cash equivalents were $49 million at the end of the quarter. The company repurchased $35 million of stock in the third quarter and paid $9 million in
dividends. In the quarter, the company announced an 11% increase in its quarterly dividend to $0.20 per share.

[0001193125-12-429395:8k_2_02:21]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-12-429395:8k_2_02:22]
Residential Heating & Cooling

[0001193125-12-429395:8k_2_02:23]
Third quarter 2012 revenue in the Residential
Heating & Cooling business segment was $386 million, up 9% from the prior-year quarter. Currency was neutral to revenue growth. Segment profit was $38 million, up 20% from the prior-year quarter. Segment profit margin was 9.8%, up 100 basis
points. Results were primarily impacted by higher volume, lower material costs, and productivity initiatives, with offsets from lower price/mix, higher SG&A expenses, and investments in distribution.

[0001193125-12-429395:8k_2_02:24]
Commercial Heating & Cooling

[0001193125-12-429395:8k_2_02:25]
Revenue in the Commercial Heating & Cooling business segment was $220 million in the third quarter, down 2% from the prior-year quarter. At
constant currency, revenue was up 1%. Segment profit was $33 million, up 5% from the prior-year quarter. Segment profit margin was 14.8%, up 90 basis points. Results were primarily impacted by favorable price/mix, lower material costs, and
productivity initiatives, with an offset from higher SG&A expenses.

[0001193125-12-429395:8k_2_02:26]
Refrigeration

[0001193125-12-429395:8k_2_02:27]
Revenue in the Refrigeration business segment was $204 million in the third quarter, down 9% from the prior-year quarter. At constant currency, revenue
was down 6%. Segment profit was $25 million, up 22% from the prior-year quarter. Segment profit margin was 12.3%, up 310 basis points from the prior-year quarter. Results were primarily impacted by favorable price/mix, lower material costs, and
productivity initiatives, with offsets from lower volume and higher SG&A expenses.

[0001193125-12-429395:8k_2_02:28]
FULL-YEAR OUTLOOK

[0001193125-12-429395:8k_2_02:29]
The company is updating its 2012 guidance ranges for revenue and EPS from continuing operations based on year-to-date performance and market view, and to
incorporate the impact of Service Experts moving to discontinued operations.

[0001193125-12-429395:8k_2_02:30]
|  | • |  | Raising guidance for revenue growth at constant currency from 3-6% to a range of 5-7%. The company continues to assume a negative 1 point impact from foreign exchange on a full-year basis, resulting in revenue growth guidance of 4-6% at actual currency. |

[0001193125-12-429395:8k_2_02:31]
|  | • |  | Raising adjusted EPS from continuing operations guidance from $2.35-$2.65 to a range of $2.60-$2.80. |

[0001193125-12-429395:8k_2_02:32]
|  | • |  | Raising GAAP EPS from continuing operations guidance from $2.30-$2.60 to a range of $2.55-$2.75. |

[0001193125-12-429395:8k_2_02:33]
|  | • |  | Reiterating tax rate guidance of 33-34% for the full year. |

[0001193125-12-429395:8k_2_02:34]
|  | • |  | Reiterating average diluted share count guidance of approximately 51 million shares for the full year, including a minimum of $50 million of stock repurchases in 2012. |

[0001193125-12-429395:8k_2_02:35]
|  | • |  | 2012 capital expenditure guidance remains approximately $55 million. |

[0001193125-12-429395:8k_2_02:36]
CONFERENCE CALL INFORMATION

[0001193125-12-429395:8k_2_02:37]
A conference call to discuss the company’s third quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-332-0634 at least 10 minutes
prior to the scheduled start time and use reservation number 265737. This conference call will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0001193125-12-429395:8k_2_02:38]
A replay will be available from 11:00 a.m. Central time on October 22 through October 29, 2012 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 265737. This
call will also be archived on the company’s web site.

[0001193125-12-429395:8k_2_02:39]
Lennox International Inc. is a global leader in the heating, air conditioning, and
refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under the symbol “LII.” Additional information is available at: http://www.lennoxinternational.com or by contacting Steve Harrison, Vice President,
Investor Relations, at 972-497-6670.

[0001193125-12-429395:8k_2_02:40]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-429395:8k_2_02:41]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-12-429395:8k_2_02:42]
(Unaudited, in millions, except per share data)

[0001193125-12-429395:8k_2_02:43]
|  |  | For the Three Months Ended September 30, |  |  | For the Nine Months Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| NET SALES |  | $ | 809.7 |  |  | $ | 801.2 |  |  | $ | 2,264.5 |  |  | $ | 2,192.4 |  |
| COST OF GOODS SOLD |  |  | 604.8 |  |  |  | 614.6 |  |  |  | 1,710.6 |  |  |  | 1,675.9 |  |
| Gross profit |  |  | 204.9 |  |  |  | 186.6 |  |  |  | 553.9 |  |  |  | 516.5 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 125.9 |  |  |  | 122.4 |  |  |  | 379.8 |  |  |  | 372.9 |  |
| Losses and other expenses, net |  |  | 0.3 |  |  |  | 2.6 |  |  |  | 0.2 |  |  |  | 3.6 |  |
| Restructuring charges |  |  | 0.4 |  |  |  | 8.0 |  |  |  | 3.1 |  |  |  | 11.3 |  |
| Income from equity method investments |  |  | (2.6 | ) |  |  | (3.0 | ) |  |  | (8.8 | ) |  |  | (9.0 | ) |
| Operational income from continuing operations |  |  | 80.9 |  |  |  | 56.6 |  |  |  | 179.6 |  |  |  | 137.7 |  |
| INTEREST EXPENSE, net |  |  | 4.4 |  |  |  | 4.1 |  |  |  | 13.4 |  |  |  | 12.5 |  |
| OTHER EXPENSE |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 76.5 |  |  |  | 52.5 |  |  |  | 166.1 |  |  |  | 125.1 |  |
| PROVISION FOR INCOME TAXES |  |  | 26.8 |  |  |  | 17.6 |  |  |  | 57.6 |  |  |  | 42.4 |  |
| Income from continuing operations |  |  | 49.7 |  |  |  | 34.9 |  |  |  | 108.5 |  |  |  | 82.7 |  |
| DISCONTINUED OPERATIONS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations |  |  | (24.6 | ) |  |  | (2.1 | ) |  |  | (57.2 | ) |  |  | (17.7 | ) |
| Benefit from income taxes |  |  | (4.3 | ) |  |  | (1.0 | ) |  |  | (16.7 | ) |  |  | (6.6 | ) |
| Loss from discontinued operations |  |  | (20.3 | ) |  |  | (1.1 | ) |  |  | (40.5 | ) |  |  | (11.1 | ) |
| Net income |  | $ | 29.4 |  |  | $ | 33.8 |  |  | $ | 68.0 |  |  | $ | 71.6 |  |
| INCOME PER SHARE—BASIC: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.98 |  |  | $ | 0.67 |  |  | $ | 2.13 |  |  | $ | 1.56 |  |
| Loss from discontinued operations |  |  | (0.40 | ) |  |  | (0.02 | ) |  |  | (0.79 | ) |  |  | (0.21 | ) |
| Net income |  | $ | 0.58 |  |  | $ | 0.65 |  |  | $ | 1.34 |  |  | $ | 1.35 |  |
| INCOME PER SHARE—DILUTED: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.97 |  |  | $ | 0.66 |  |  | $ | 2.11 |  |  | $ | 1.53 |  |
| Loss from discontinued operations |  |  | (0.40 | ) |  |  | (0.02 | ) |  |  | (0.79 | ) |  |  | (0.20 | ) |
| Net income |  | $ | 0.57 |  |  | $ | 0.64 |  |  | $ | 1.32 |  |  | $ | 1.33 |  |
| AVERAGE SHARES OUTSTANDING: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 50.6 |  |  |  | 52.2 |  |  |  | 50.8 |  |  |  | 53.0 |  |
| Diluted |  |  | 51.3 |  |  |  | 52.8 |  |  |  | 51.5 |  |  |  | 53.9 |  |
| CASH DIVIDENDS DECLARED PER SHARE |  | $ | 0.20 |  |  | $ | 0.18 |  |  | $ | 0.56 |  |  | $ | 0.54 |  |

[0001193125-12-429395:8k_2_02:44]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-429395:8k_2_02:45]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001193125-12-429395:8k_2_02:46]
(Unaudited, in millions)

[0001193125-12-429395:8k_2_02:47]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 386.3 |  |  | $ | 353.8 |  |  | $ | 1,070.7 |  |  | $ | 979.7 |  |
| Commercial Heating & Cooling |  |  | 219.7 |  |  |  | 223.6 |  |  |  | 597.9 |  |  |  | 596.4 |  |
| Refrigeration |  |  | 203.7 |  |  |  | 223.8 |  |  |  | 595.9 |  |  |  | 616.3 |  |
|  |  | $ | 809.7 |  |  | $ | 801.2 |  |  | $ | 2,264.5 |  |  | $ | 2,192.4 |  |
| Segment Profit (Loss) (A) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 37.7 |  |  | $ | 31.3 |  |  | $ | 90.7 |  |  | $ | 70.9 |  |
| Commercial Heating & Cooling |  |  | 32.5 |  |  |  | 31.1 |  |  |  | 74.1 |  |  |  | 67.2 |  |
| Refrigeration |  |  | 25.1 |  |  |  | 20.5 |  |  |  | 60.6 |  |  |  | 55.5 |  |
| Corporate and other |  |  | (14.3 | ) |  |  | (15.1 | ) |  |  | (43.7 | ) |  |  | (41.5 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 81.0 |  |  |  | 67.8 |  |  |  | 181.7 |  |  |  | 152.1 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | 0.9 |  |  |  | — |  |  |  | 1.0 |  |  |  | (2.4 | ) |
| Items in losses and other expenses, net that are excluded from segment profit (loss) (B) |  |  | (1.2 | ) |  |  | 3.2 |  |  |  | (2.0 | ) |  |  | 5.5 |  |
| Restructuring charges |  |  | 0.4 |  |  |  | 8.0 |  |  |  | 3.1 |  |  |  | 11.3 |  |
| Interest expense, net |  |  | 4.4 |  |  |  | 4.1 |  |  |  | 13.4 |  |  |  | 12.5 |  |
| Other Expense, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 76.5 |  |  | $ | 52.5 |  |  | $ | 166.1 |  |  | $ | 125.1 |  |

[0001193125-12-429395:8k_2_02:48]
(A) The Company defines segment profit and loss as a segment’s Income or Loss from continuing operations
before income taxes included in the accompanying Consolidated Statements of Operations:

[0001193125-12-429395:8k_2_02:49]
Excluding:

[0001193125-12-429395:8k_2_02:50]
|  | • |  | Special product quality adjustment. |

[0001193125-12-429395:8k_2_02:51]
|  | • |  | Items within losses and other expenses, net that are noted in (B) . |

[0001193125-12-429395:8k_2_02:52]
|  | • |  | Restructuring charges. |

[0001193125-12-429395:8k_2_02:53]
|  | • |  | Goodwill and equity method investment impairments. |

[0001193125-12-429395:8k_2_02:54]
|  | • |  | Interest expense, net. |

[0001193125-12-429395:8k_2_02:55]
|  | • |  | Other expense, net. |

[0001193125-12-429395:8k_2_02:56]
(B)
Items in losses and other expenses, net that are excluded from segment profit or loss are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, and realized gains and/or losses on marketable
securities.

[0001193125-12-429395:8k_2_02:57]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-429395:8k_2_02:58]
CONSOLIDATED BALANCE SHEETS

[0001193125-12-429395:8k_2_02:59]
(In millions, except share and per share data)

[0001193125-12-429395:8k_2_02:60]
|  |  | As ofSeptember 30,2012 |  |  | As ofDecember 31,2011 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 48.8 |  |  | $ | 45.0 |  |
| Accounts and notes receivable, net of allowances of $9.5 and $11.3 in 2012 and 2011, respectively |  |  | 450.3 |  |  |  | 387.0 |  |
| Inventories, net |  |  | 398.4 |  |  |  | 317.9 |  |
| Deferred income taxes |  |  | 32.8 |  |  |  | 33.8 |  |
| Other assets |  |  | 72.6 |  |  |  | 68.5 |  |
| Assets of discontinued operations |  |  | 108.7 |  |  |  | 160.5 |  |
| Total current assets |  |  | 1,111.6 |  |  |  | 1,012.7 |  |
| PROPERTY, PLANT AND EQUIPMENT, net of accumulated depreciation of $580.3 and $554.0 in 2012 and 2011, respectively |  |  | 289.4 |  |  |  | 300.7 |  |
| GOODWILL |  |  | 223.7 |  |  |  | 223.2 |  |
| DEFERRED INCOME TAXES |  |  | 87.3 |  |  |  | 90.7 |  |
| OTHER ASSETS, net |  |  | 81.5 |  |  |  | 78.4 |  |
| TOTAL ASSETS |  | $ | 1,793.5 |  |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 31.1 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt |  |  | 0.3 |  |  |  | 0.8 |  |
| Accounts payable |  |  | 277.6 |  |  |  | 254.9 |  |
| Accrued expenses |  |  | 258.7 |  |  |  | 239.4 |  |
| Income taxes payable |  |  | 8.5 |  |  |  | 5.7 |  |
| Liabilities of discontinued operations |  |  | 62.2 |  |  |  | 71.6 |  |
| Total current liabilities |  |  | 638.4 |  |  |  | 577.1 |  |
| LONG-TERM DEBT |  |  | 449.6 |  |  |  | 459.6 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | 17.1 |  |  |  | 18.6 |  |
| PENSIONS |  |  | 116.2 |  |  |  | 124.7 |  |
| OTHER LIABILITIES |  |  | 62.8 |  |  |  | 57.9 |  |
| Total liabilities |  |  | 1,284.1 |  |  |  | 1,237.9 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares and 86,938,004 shares issued for 2012 and 2011, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 894.0 |  |  |  | 881.2 |  |
| Retained earnings |  |  | 732.6 |  |  |  | 692.9 |  |
| Accumulated other comprehensive income |  |  | (10.2 | ) |  |  | (37.1 | ) |
| Treasury stock, at cost, 36,885,101 shares and 36,093,966 shares for 2012 and 2011, respectively |  |  | (1,107.9 | ) |  |  | (1,070.1 | ) |
| Total stockholders’ equity |  |  | 509.4 |  |  |  | 467.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,793.5 |  |  | $ | 1,705.7 |  |

[0001193125-12-429395:8k_2_02:61]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-429395:8k_2_02:62]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-12-429395:8k_2_02:63]
(Unaudited, in millions)

[0001193125-12-429395:8k_2_02:64]
|  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 68.0 |  |  | $ | 71.6 |  |
| Net loss from discontinued operations |  |  | 40.5 |  |  |  | 11.1 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (8.8 | ) |  |  | (9.0 | ) |
| Dividends from affiliates |  |  | 6.9 |  |  |  | 8.6 |  |
| Restructuring expenses, net of cash paid |  |  | — |  |  |  | 5.0 |  |
| Provision for bad debts |  |  | 2.0 |  |  |  | 4.4 |  |
| Unrealized (gain) loss on derivative contracts |  |  | (1.4 | ) |  |  | 4.7 |  |
| Stock-based compensation expense |  |  | 10.4 |  |  |  | 12.6 |  |
| Depreciation and amortization |  |  | 41.1 |  |  |  | 42.3 |  |
| Deferred income taxes |  |  | 0.5 |  |  |  | 4.0 |  |
| Other items, net |  |  | 3.3 |  |  |  | (3.1 | ) |
| Changes in assets and liabilities, net of effects of acquisitions and divestures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (62.4 | ) |  |  | (66.6 | ) |
| Inventories |  |  | (81.3 | ) |  |  | (82.6 | ) |
| Other current assets |  |  | (5.0 | ) |  |  | (2.3 | ) |
| Accounts payable |  |  | 20.8 |  |  |  | 61.6 |  |
| Accrued expenses |  |  | 32.1 |  |  |  | (27.9 | ) |
| Income taxes payable and receivable |  |  | 13.7 |  |  |  | 1.3 |  |
| Other |  |  | (3.6 | ) |  |  | (2.7 | ) |
| Net cash used in discontinued operations |  |  | (12.4 | ) |  |  | (35.2 | ) |
| Net cash provided by (used in) operating activities |  |  | 64.4 |  |  |  | (2.2 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 0.2 |  |
| Purchases of property, plant and equipment |  |  | (28.0 | ) |  |  | (25.8 | ) |
| Net proceeds from sale of businesses |  |  | 10.1 |  |  |  | 0.6 |  |
| Acquisition of business |  |  | — |  |  |  | (147.7 | ) |
| Change in restricted cash |  |  | — |  |  |  | 12.2 |  |
| Net cash used in discontinued operations |  |  | (0.3 | ) |  |  | (1.2 | ) |
| Net cash used in investing activities |  |  | (18.1 | ) |  |  | (161.7 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 1.3 |  |  |  | 2.5 |  |
| Asset securitization borrowings |  |  | 480.0 |  |  |  | 220.0 |  |
| Asset securitization payments |  |  | (455.0 | ) |  |  | (220.0 | ) |
| Long-term payments |  |  | (0.9 | ) |  |  | (0.7 | ) |
| Borrowings from revolving credit facility |  |  | 696.0 |  |  |  | 1,090.0 |  |
| Payments on revolving credit facility |  |  | (706.0 | ) |  |  | (911.5 | ) |
| Proceeds from stock option exercises |  |  | 0.3 |  |  |  | 1.5 |  |
| Repurchases of common stock |  |  | (38.4 | ) |  |  | (90.9 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.7 |  |  |  | 1.5 |  |
| Cash dividends paid |  |  | (27.5 | ) |  |  | (27.2 | ) |
| Net cash provided by (used in) financing activities |  |  | (48.5 | ) |  |  | 65.2 |  |
| DECREASE IN CASH AND CASH EQUIVALENTS |  |  | (2.2 | ) |  |  | (98.7 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | 6.0 |  |  |  | (3.4 | ) |
| CASH AND CASH EQUIVALENTS, beginning of period |  |  | 45.0 |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of period |  | $ | 48.8 |  |  | $ | 57.9 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the period for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 11.8 |  |  |  | 10.7 |  |
| Income taxes (net of refunds) |  | $ | 27.8 |  |  |  | 28.9 |  |

[0001193125-12-429395:8k_2_02:65]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-12-429395:8k_2_02:66]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-12-429395:8k_2_02:67]
(Unaudited, in millions, except per share, ratio, sales growth rate and margin data)

[0001193125-12-429395:8k_2_02:68]
Use of Non-GAAP Financial Measures

[0001193125-12-429395:8k_2_02:69]
To
supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that
these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial
measures enhance the ability of investors to analyze the Company's business trends and operating performance.

[0001193125-12-429395:8k_2_02:70]
Reconciliation of Income
From Continuing Operations, a GAAP measure, to Adjusted Income From Continuing Operations,     a Non-GAAP measure

[0001193125-12-429395:8k_2_02:71]
|  |  | For The Three MonthsEnded September 30, |  |  | For The Nine MonthsEnded September 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Income from continuing operations, a GAAP measure |  | $ | 49.7 |  |  | $ | 34.9 |  |  | $ | 108.5 |  |  | $ | 82.7 |  |
| Restructuring charges, after tax |  |  | 0.3 |  |  |  | 5.0 |  |  |  | 2.1 |  |  |  | 7.1 |  |
| Net change in unrealized losses (gains) on open future contracts, after tax (a) |  |  | (0.9 | ) |  |  | 2.3 |  |  |  | (1.7 | ) |  |  | 3.1 |  |
| Special product quality adjustment, after-tax (b) |  |  | 0.6 |  |  |  | — |  |  |  | 0.9 |  |  |  | (1.5 | ) |
| Other items, net, after tax (a) |  |  | — |  |  |  | (0.3 | ) |  |  | 0.3 |  |  |  | 0.2 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 49.7 |  |  | $ | 41.9 |  |  | $ | 110.1 |  |  | $ | 91.6 |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 0.97 |  |  | $ | 0.66 |  |  | $ | 2.11 |  |  | $ | 1.53 |  |
| Restructuring charges |  |  | 0.01 |  |  |  | 0.10 |  |  |  | 0.04 |  |  |  | 0.15 |  |
| Special product quality adjustment, after-tax (b) |  |  | 0.01 |  |  |  | — |  |  |  | 0.02 |  |  |  | (0.03 | ) |
| Net change in unrealized losses (gains) on open future contracts and other items, net (a) |  |  | (0.02 | ) |  |  | 0.03 |  |  |  | (0.03 | ) |  |  | 0.05 |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  | $ | 0.97 |  |  | $ | 0.79 |  |  | $ | 2.14 |  |  | $ | 1.70 |  |

[0001193125-12-429395:8k_2_02:72]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-12-429395:8k_2_02:73]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-12-429395:8k_2_02:74]
|  |  | For The Three MonthsEnded September 30, |  |  | For The Nine MonthsEnded September 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized loss (gains) on settled future contracts (a) |  | $ | 0.5 |  |  |  | (0.1 | ) |  | $ | 1.4 |  |  |  | (1.0 | ) |
| Foreign currency exchange loss (gain) (a) |  |  | 1.0 |  |  |  | (0.6 | ) |  |  | 0.7 |  |  |  | — |  |
| Loss (gain) on disposal of fixed assets (a) |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | (0.8 | ) |
| Net change in unrealized losses (gains) on open futures contracts (b) |  |  | (1.4 | ) |  |  | 3.5 |  |  |  | (2.5 | ) |  |  | 4.9 |  |
| Gain on sale of entity (b) |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |  | (0.3 | ) |
| Other items, net (b) |  |  | 0.2 |  |  |  | — |  |  |  | 0.5 |  |  |  | 0.8 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 0.3 |  |  | $ | 2.6 |  |  | $ | 0.2 |  |  | $ | 3.6 |  |

[0001193125-12-429395:8k_2_02:75]
| (a) | Included in segment profit (loss) and adjusted income from continuing operations |

[0001193125-12-429395:8k_2_02:76]
| (b) | Excluded from segment profit (loss) and adjusted income from continuing operations |

[0001193125-12-429395:8k_2_02:77]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations—Diluted, a Non-GAAP
Measure, to

[0001193125-12-429395:8k_2_02:78]
Income per Share from Continuing Operations—Diluted, a GAAP Measure

[0001193125-12-429395:8k_2_02:79]
|  |  | For theYear EndedDecember 31,2012ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 2.60 - $2.80 |  |
| Restructuring charges |  |  | (0.05 | ) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 2.55 - $2.75 |  |

[0001193125-12-429395:8k_2_02:80]
Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP Measure, to Free Cash Flow, a Non-GAAP
        Measure

[0001193125-12-429395:8k_2_02:81]
|  |  | For the Three Months |  |  | For the Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 75.0 |  |  | $ | 140.2 |  |  | $ | 64.4 |  |  | $ | (2.2 | ) |
| Purchases of property, plant and equipment |  |  | (11.6 | ) |  |  | (8.0 | ) |  |  | (28.0 | ) |  |  | (25.8 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | 63.4 |  |  | $ | 132.2 |  |  | $ | 36.4 |  |  | $ | (28.0 | ) |

[0001193125-12-429395:8k_2_02:82]
Calculation of Debt to EBITDA Ratio:

[0001193125-12-429395:8k_2_02:83]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | September 30, |  |
|  |  | 2012 |  |
| EBIT (a) |  | $ | 227.4 |  |
| Depreciation and amortization expense (b) |  |  | 55.4 |  |
| EBITDA (a + b) |  | $ | 282.8 |  |
| Total debt at September 30, 2012 (c) |  | $ | 481.0 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 1.7 |  |

[0001193125-12-429395:8k_2_02:84]
Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income Taxes, a GAAP

[0001193125-12-429395:8k_2_02:85]
measure

[0001193125-12-429395:8k_2_02:86]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | September 30, |  |
|  |  | 2012 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 227.4 |  |
| Special product quality adjustment |  |  | (0.9 | ) |
| Items in gains and other expenses, net that are excluded from segment profit |  |  | (2.5 | ) |
| Restructuring charges |  |  | 4.3 |  |
| Other expenses, net |  |  | 0.5 |  |
| Interest expense, net |  |  | 17.7 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 208.3 |  |
