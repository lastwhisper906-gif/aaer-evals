# LII notes — 0001069202-12-000005


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-12-000005:notes:1]
Basis of Presentation

[0001069202-12-000005:notes:2]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2012, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2012 and 2011, the unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2012 and 2011, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2012 and 2011 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2011. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-12-000005:notes:3]
Our fiscal year ends on December 31 and each of our quarters are comprised of 13 weeks. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-12-000005:notes:4]
Commitments and Contingencies:

[0001069202-12-000005:notes:5]
We are subject to contingencies that arise in the normal course of business, including pending litigation, product warranties and other product related contingencies, environmental matters and other guarantees or claims.

[0001069202-12-000005:notes:6]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts known. We do not believe that any current or pending or threatened litigation will have a material adverse effect on our financial position. Litigation and arbitration, however, involve uncertainties and it is possible that the eventual outcome of litigation could adversely affect our results of operations for a particular period.

[0001069202-12-000005:notes:7]
We use a combination of third-party insurance and large deductible self-insurance plans to provide protection against claims relating to contingencies such as workers’ compensation, general liability, product liability, property damage, aviation liability, directors’ and officers’ liability, auto liability, physical damage and other exposures. Self-insurance expense and liabilities are actuarially determined based on our historical claims information, as well as industry factors and trends. The majority of our self-insured risks (excluding auto liability and physical damage) will be paid over an extended period of time. There have been no material changes in our insurance liability since our latest fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our large deductible plans. The self-insurance liabilities recorded in Accrued expenses in the accompanying Consolidated Balance Sheets were $64.0 million and $63.1 million as of September 30, 2012 and December 31, 2011, respectively.

[0001069202-12-000005:notes:8]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease, as amended, contains restrictive covenants that are consistent with those of our Domestic Revolving Credit Facility. We were in compliance with these financial covenants as of September 30, 2012.

[0001069202-12-000005:notes:9]
Product Warranties and Product Related Contingencies

[0001069202-12-000005:notes:10]
Total liabilities for estimated product warranty are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-12-000005:notes:11]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Accrued expenses | $ | 25.5 |  |  | $ | 26.7 |  |
| Other liabilities | 45.1 |  |  | 41.6 |  |
|  | $ | 70.6 |  |  | $ | 68.3 |  |

[0001069202-12-000005:notes:12]
The changes in total product warranty liabilities for the first nine months of 2012 were as follows (in millions):

[0001069202-12-000005:notes:13]
| Total warranty liability as of December 31, 2011 | $ | 68.3 |  |
| Payments made in 2012 | (18.2 | ) |
| Changes resulting from issuance of new warranties | 20.0 |  |
| Changes in estimates associated with pre-existing liabilities | 0.2 |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of September 30, 2012 | $ | 70.6 |  |

[0001069202-12-000005:notes:14]
At the end of each accounting period, we evaluate our warranty liabilities and during the second quarter of each year, we perform a complete re-evaluation of our heating, ventilation and air conditioning (“HVAC”) warranty liabilities. As a result of the second quarter re-evaluation, we decreased our warranty liability by $0.4 million.

[0001069202-12-000005:notes:15]
We incur the risk of liability claims for the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material changes in the circumstances that affect our product warranties since our latest fiscal year-end.

[0001069202-12-000005:notes:16]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001069202-12-000005:notes:17]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in the second quarter of 2012. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the first nine months of 2012 were as follows (in millions):

[0001069202-12-000005:notes:18]
| Total accrued product quality issue as of December 31, 2011 | $ | 7.5 |  |
| Estimated expense for expected product quality claims | 1.7 |  |
| Product quality claims | (2.1 | ) |
| Total accrued product quality issue as of September 30, 2012 | $ | 7.1 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-12-000005:notes:19]
Lines of Credit and Financing Arrangements:

[0001069202-12-000005:notes:20]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-12-000005:notes:21]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 25.0 |  |  | $ | — |  |
| Foreign obligations | 6.1 |  |  | 4.7 |  |
| Total short-term debt | $ | 31.1 |  |  | $ | 4.7 |  |
| Current maturities of long-term debt: | $ | 0.3 |  |  | $ | 0.8 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.6 |  |  | $ | 16.6 |  |
| Domestic revolving credit facility | 233.0 |  |  | 243.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 449.6 |  |  | $ | 459.6 |  |
| Total debt | $ | 481.0 |  |  | $ | 465.1 |  |

[0001069202-12-000005:notes:22]
Short-Term Debt

[0001069202-12-000005:notes:23]
Foreign Obligations

[0001069202-12-000005:notes:24]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $6.1 million and $4.7 million of foreign obligations as of September 30, 2012 and December 31, 2011, respectively.

[0001069202-12-000005:notes:25]
Asset Securitization Program

[0001069202-12-000005:notes:26]
Under the Receivables Purchase Agreement, or Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests. The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. The ASP provides for a maximum securitization amount of the lesser of $150.0 million or 100% of the net pool balance as defined by the ASP. However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. On March 30, 2012, the parties involved with this securitization program agreed to remove Lennox Hearth Products LLC from the program. Any receivables originated by Lennox Hearth Products LLC that remained outstanding as of that date were repurchased by us. The maximum securitization amount of $150.0 million was not modified. The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-12-000005:notes:27]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 150.0 |  |  | $ | 150.0 |  |
| Beneficial interest sold | 25.0 |  |  | — |  |
| Remaining amount available | $ | 125.0 |  |  | $ | 150.0 |  |

[0001069202-12-000005:notes:28]
Under the ASP, we pay certain discount fees to use the program and have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for September 30, 2012 was 0.87% and the average rate at December 31, 2011 was 0.91%. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):

[0001069202-12-000005:notes:29]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.9 |  |  | $ | 0.5 |  |

[0001069202-12-000005:notes:30]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Domestic Revolving Credit Facility and senior unsecured notes. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit rating and have no reason to believe they will not perform under the ASP. As of September 30, 2012, we were in compliance with all covenant requirements.

[0001069202-12-000005:notes:31]
Long-Term Debt

[0001069202-12-000005:notes:32]
Domestic Revolving Credit Facility

[0001069202-12-000005:notes:33]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $233.0 million and $49.9 million committed to standby letters of credit as of September 30, 2012. Subject to covenant limitations, $367.1 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-12-000005:notes:34]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-12-000005:notes:35]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Weighted average borrowing rate | 1.47 | % |  | 1.53 | % |

[0001069202-12-000005:notes:36]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-12-000005:notes:37]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-12-000005:notes:38]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our revolving credit facility could occur if:

[0001069202-12-000005:notes:39]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-12-000005:notes:40]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-12-000005:notes:41]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-12-000005:notes:42]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2012, we were in compliance with all covenant requirements.

[0001069202-12-000005:notes:43]
Senior Unsecured Notes

[0001069202-12-000005:notes:44]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

[0001069202-12-000005:notes:45]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2012, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-12-000005:notes:46]
Derivatives:

[0001069202-12-000005:notes:47]
[same as prior period, unchanged from 0001193125-12-311640:notes:21]

[0001069202-12-000005:notes:48]
[same as prior period, unchanged from 0001193125-12-311640:notes:22]

[0001069202-12-000005:notes:49]
We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities we use in our production processes. The hedging program includes the use of futures contracts. We enter into these contracts based on our hedging strategy, a dollar cost averaging strategy. As part of this strategy, a higher percentage of commodity price exposures are hedged near term with lower percentages hedged at future dates. This strategy provides us with protection against near-term price volatility while allowing us to adjust to market price movements over time. Upon entering into futures contracts, we lock in prices and are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.

[0001069202-12-000005:notes:50]
[same as prior period, unchanged from 0001193125-12-311640:notes:24]

[0001069202-12-000005:notes:51]
A portion of our debt bears interest at variable interest rates, and therefore, we are subject to variability in the cash paid for interest. In order to mitigate a portion of the risk, we used a hedging strategy to eliminate the variability of cash flows in the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the benchmark interest rate. This strategy allowed us to fix a portion of our variable interest payments.

[0001069202-12-000005:notes:52]
On October 12, 2012, our $100 million pay-fixed, receive-variable interest rate swap with a large financial institution at a fixed interest rate of 2.66% expired.  The interest rate swap was accounted for as a cash flow hedge.  The variable portion of the interest rate swap was tied to the 1-Month LIBOR (the benchmark interest rate). The interest rates under both the interest rate swap and the underlying debt were reset, the swap was settled with the counterparty, and the interest was paid, on a monthly basis.

[0001069202-12-000005:notes:53]
[same as prior period, unchanged from 0001193125-12-311640:notes:27]

[0001069202-12-000005:notes:54]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. Our objective for entering into foreign currency forward contracts is to mitigate the impact of short-term currency exchange rate movements on certain short-term intercompany transactions. In order to meet that objective, we periodically enter into foreign currency forward contracts that act as economic hedges against changes in foreign currency exchange rates. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them. By entering into these forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-12-000005:notes:55]
[same as prior period, unchanged from 0001193125-12-311640:notes:29]

[0001069202-12-000005:notes:56]
We include gains or losses in accumulated other comprehensive income (“AOCI”) in connection with our commodity cash flow hedges. The gains or losses related to commodity price hedges are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates. Assuming that commodity prices remain constant, $1.9 million of derivative gains are expected to be reclassified into earnings within the next 12 months. Commodity futures contracts that are designated as cash flow hedges and that are in place as of September 30, 2012 are scheduled to mature through February 2014.

[0001069202-12-000005:notes:57]
We also include gains or losses in AOCI from our $100 million pay-fixed, receive-variable interest rate swap.  As of September 30, 2012, $0.1 million of derivative losses related to the interest rate swap were included in AOCI.  Upon expiration of the swap, these losses were  reclassified into earnings.

[0001069202-12-000005:notes:58]
[same as prior period, unchanged from 0001193125-12-311640:notes:32]

[0001069202-12-000005:notes:59]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Commodity Price Hedges: |  |  |  |
| (Gains) losses included in AOCI, net of tax | $ | (2.3 | ) |  | $ | 6.1 |  |
| Expense for (benefit from) income taxes | 1.3 |  |  | (3.5 | ) |
| Interest Rate Swap: |  |  |  |
| Losses included in AOCI, net of tax | $ | 0.1 |  |  | $ | 1.1 |  |
| Benefit from income taxes | — |  |  | (0.6 | ) |

[0001069202-12-000005:notes:60]
[same as prior period, unchanged from 0001193125-12-311640:notes:34]

[0001069202-12-000005:notes:61]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
|  | (pounds) |  | (pounds) |
| Copper | 21.4 |  |  | 23.3 |  |

[0001069202-12-000005:notes:62]
[same as prior period, unchanged from 0001193125-12-311640:notes:36]

[0001069202-12-000005:notes:63]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges. We elect not to designate these derivatives as cash flow hedges at the inception of the arrangement. We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions):

[0001069202-12-000005:notes:64]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
|  | (pounds) |  | (pounds) |
| Copper | 2.3 |  |  | 2.8 |  |
| Aluminum | 2.6 |  |  | 3.0 |  |

[0001069202-12-000005:notes:65]
We had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001069202-12-000005:notes:66]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Notional amounts: |  |  |  |
| Brazilian Real | 14.3 |  |  | 4.5 |  |
| Mexican Peso | 143.7 |  |  | 199.0 |  |
| Euro | 10.0 |  |  | 7.8 |  |
| British Pound | 4.4 |  |  | 6.5 |  |
| Indian Rupee | 78.0 |  |  | — |  |

[0001069202-12-000005:notes:67]
[same as prior period, unchanged from 0001193125-12-311640:notes:41]

[0001069202-12-000005:notes:68]
The following table provides the location and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of Operations (in millions):

[0001069202-12-000005:notes:69]
|  | Fair Values of Derivative Instruments(1) |
|  | Derivatives Designated asHedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | As of September 30, 2012 |  | As of December 31, 2011 |  | As of September 30, 2012 |  | As of December 31, 2011 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 3.2 |  |  | $ | — |  |  | $ | 0.4 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | 1.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.7 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
| Total Assets | $ | 3.9 |  |  | $ | 0.1 |  |  | $ | 0.5 |  |  | $ | 1.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 9.4 |  |  | $ | 0.1 |  |  | $ | 1.8 |  |
| Interest rate swap | 0.1 |  |  | 1.8 |  |  | — |  |  | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.3 |  |  | — |  |  | 0.2 |  |
| Interest rate swap | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 0.1 |  |  | $ | 11.5 |  |  | $ | 0.1 |  |  | $ | 2.1 |  |

[0001069202-12-000005:notes:70]
| (1) | All derivative instruments are classified as Level 2 within the fair value hierarchy. For more information on other fair value measurements, see Note 15. |

[0001069202-12-000005:notes:71]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Amount of Loss or (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |
| Commodity futures contracts(1) | $ | 2.2 |  |  | $ | (2.9 | ) |  | $ | 5.8 |  |  | $ | (12.8 | ) |
| Interest rate swap(2) | 0.6 |  |  | 0.6 |  |  | 1.8 |  |  | 1.9 |  |
|  | $ | 2.8 |  |  | $ | (2.3 | ) |  | $ | 7.6 |  |  | $ | (10.9 | ) |
| Amount of (Gain) or Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |  |  |
| Commodity futures contracts(3) | $ | (0.1 | ) |  | $ | 0.1 |  |  | $ | (0.2 | ) |  | $ | 0.1 |  |

[0001069202-12-000005:notes:72]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Amount of (Gain) or Loss Recognized in Income on Derivatives: |  |  |  |  |  |  |  |
| Commodity futures contracts(3) | $ | (0.8 | ) |  | $ | 3.3 |  |  | $ | (0.9 | ) |  | $ | 3.8 |  |
| Foreign currency forward contracts(3) | 0.6 |  |  | (0.4 | ) |  | 0.3 |  |  | 0.9 |  |
|  | $ | (0.2 | ) |  | $ | 2.9 |  |  | $ | (0.6 | ) |  | $ | 4.7 |  |

[0001069202-12-000005:notes:73]
[same as prior period, unchanged from 0001193125-12-311640:notes:47]

[0001069202-12-000005:notes:74]
[same as prior period, unchanged from 0001193125-12-311640:notes:48]

[0001069202-12-000005:notes:75]
| (3) | The (gain) loss is recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-12-000005:notes:76]
Stock-Based Compensation:

[0001069202-12-000005:notes:77]
The Lennox International Inc. 2010 Incentive Plan, as amended and restated, provides for various long-term incentive awards, which include performance share units, restricted stock units and stock appreciation rights. Net stock-based compensation expense recognized was as follows (in millions):

[0001069202-12-000005:notes:78]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Net stock-based compensation expense | $ | 2.1 |  |  | $ | 3.5 |  |  | $ | 10.4 |  |  | $ | 12.6 |  |

[0001069202-12-000005:notes:79]
Net stock-based compensation for the three months ended September 30, 2012 includes expense of $2.7 million in Selling, general and administrative expenses and a benefit of $0.6 million in Loss from discontinued operations.  Net stock-based compensation for the nine months ended September 30, 2012 includes expense of $10.5 million in Selling, general and administrative expenses and a benefit of $0.1 million in Loss from discontinued operations. The benefit in Loss from discontinued operations resulted from the forfeiture of shares due to the sale of the Hearth business in the second quarter of 2012 and the expected forfeiture of shares due to the planned sale of the Service Experts business.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-12-000005:notes:80]
Discontinued Operations:

[0001069202-12-000005:notes:81]
In September 2012, the Company announced the planned sale of its Service Experts business. The Service Experts business had historically been included in the Company’s Service Experts segment.  The planned sale of the Service Experts business qualified as a discontinued operation for the third quarter of 2012 and was reported as assets and liabilities held for sale for all periods presented.

[0001069202-12-000005:notes:82]
A summary of net trade sales and pre-tax operating income (losses) for our Service Experts business is detailed below (in millions):

[0001069202-12-000005:notes:83]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Net trade sales(1) | $ | 98.3 |  |  | $ | 120.4 |  |  | $ | 292.6 |  |  | $ | 346.6 |  |
| Pre-tax operating (loss) income(1)(2) | (26.8 | ) |  | 0.1 |  |  | (42.7 | ) |  | (8.3 | ) |

[0001069202-12-000005:notes:84]
| (1) | Excludes eliminations of intercompany sales and any associated profit. |

[0001069202-12-000005:notes:85]
| (2) | Pre-tax operating loss for the three and nine months ended September, 30 2012 includes a $20.5 million goodwill impairment loss (see Note 3). |

[0001069202-12-000005:notes:86]
The assets and liabilities of the Service Experts business are presented as follows in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-12-000005:notes:87]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Assets of discontinued operations: |  |  |  |
| Accounts receivable, net | $ | 14.5 |  |  | $ | 14.4 |  |
| Inventories, net | 6.3 |  |  | 6.3 |  |
| Deferred income taxes | 9.7 |  |  | 10.1 |  |
| Property, Plant and Equipment | 3.7 |  |  | 3.8 |  |
| Goodwill and intangible assets, net | 67.1 |  |  | 83.2 |  |
| Other assets | 7.4 |  |  | 7.7 |  |
| Liabilities of discontinued operations: |  |  |  |
| Accounts payable | 17.4 |  |  | 16.0 |  |
| Accrued expenses | 41.0 |  |  | 40.1 |  |
| Deferred income taxes | 3.7 |  |  | 3.7 |  |
| Other Liabilities | 0.1 |  |  | 0.2 |  |

[0001069202-12-000005:notes:88]
In April 2012, the Company announced the sale of its Hearth business to Comvest Investment Partners IV in an all cash transaction. The Hearth business had historically been included in the Company’s Residential Heating & Cooling Segment. We sold the Hearth business for net proceeds of $10.1 million, which includes a $2.9 million working capital adjustment received in the third quarter of 2012 and excludes the transaction costs and cash transferred with the business.  The net loss from the sale of the Hearth business was $0.9 million

[0001069202-12-000005:notes:89]
A summary of net trade sales and pre-tax operating losses for our Hearth business is detailed below (in millions):

[0001069202-12-000005:notes:90]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Net trade sales | $ | — |  |  | $ | 19.8 |  |  | $ | 23.5 |  |  | $ | 61.1 |  |
| Pre-tax operating loss (3) | (1.2 | ) |  | (2.3 | ) |  | (13.1 | ) |  | (9.7 | ) |
| Gain (loss) on sale | 2.9 |  |  | — |  |  | (0.9 | ) |  | — |  |

[0001069202-12-000005:notes:91]
| (3) | Pre-tax operating loss includes a $6.3 million first quarter 2012 pre-tax charge for the write-down of net assets to their estimated fair value and a $6.3 million settlement charge in the second quarter of 2012 related to actuarial losses recognized upon transition of a pension obligation to the acquirer of the Hearth business (See Note 8). Offsetting these charges was a $3.5 million gain in the second quarter of 2012 related to realized foreign currency translation adjustments. |

[0001069202-12-000005:notes:92]
The assets and liabilities of the Hearth business are presented as follows in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-12-000005:notes:93]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Assets of discontinued operations: |  |  |  |
| Accounts receivable, net | $ | — |  |  | $ | 7.3 |  |
| Inventories, net | — |  |  | 12.4 |  |
| Deferred income taxes | — |  |  | 9.1 |  |
| Property, Plant and Equipment | — |  |  | 5.4 |  |
| Other assets | — |  |  | 0.8 |  |
| Liabilities of discontinued operations: |  |  |  |
| Accounts payable | — |  |  | 6.0 |  |
| Accrued expenses | — |  |  | 5.2 |  |
| Other Liabilities | — |  |  | 0.4 |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-12-000005:notes:94]
Earnings Per Share:

[0001069202-12-000005:notes:95]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period. Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-12-000005:notes:96]
The computations of basic and diluted earnings per share for Income from Continuing Operations were as follows (in millions, except per share data):

[0001069202-12-000005:notes:97]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Net income | $ | 29.4 |  |  | $ | 33.8 |  |  | $ | 68.0 |  |  | $ | 71.6 |  |
| Loss from discontinued operations | (20.3 | ) |  | (1.1 | ) |  | (40.5 | ) |  | (11.1 | ) |
| Income from continuing operations | $ | 49.7 |  |  | $ | 34.9 |  |  | $ | 108.5 |  |  | $ | 82.7 |  |
| Weighted-average shares outstanding – basic | 50.6 |  |  | 52.2 |  |  | 50.8 |  |  | 53.0 |  |
| Effect of diluted securities attributable to stock-based payments | 0.7 |  |  | 0.6 |  |  | 0.7 |  |  | 0.9 |  |
| Weighted-average shares outstanding – diluted | 51.3 |  |  | 52.8 |  |  | 51.5 |  |  | 53.9 |  |
| Earnings per share from continuing operations: |  |  |  |  |  |  |  |
| Basic | $ | 0.98 |  |  | $ | 0.67 |  |  | $ | 2.13 |  |  | $ | 1.56 |  |
| Diluted | $ | 0.97 |  |  | $ | 0.66 |  |  | $ | 2.11 |  |  | $ | 1.53 |  |

[0001069202-12-000005:notes:98]
Stock appreciation rights were outstanding, but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive. The details are as follows:

[0001069202-12-000005:notes:99]
|  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |
| Weighted-average number of shares | 386,759 |  |  | 2,275,894 |  |
| Price ranges per share | $ | 46.78 |  |  | $28.24 - $46.78 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-12-000005:notes:100]
The estimated fair value of our debt was as follows (in millions):

[0001069202-12-000005:notes:101]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Senior unsecured notes | $ | 219.4 |  |  | $ | 207.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-12-000005:notes:102]
Fair Value Measurements:

[0001069202-12-000005:notes:103]
[same as prior period, unchanged from 0001193125-12-311640:notes:149]

[0001069202-12-000005:notes:104]
The following table presents the fair value hierarchy for those assets and liabilities measured at fair value on a recurring basis (in millions):

[0001069202-12-000005:notes:105]
|  | Quoted Prices in Active Markets forIdentical Assets (Level 1) |
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Assets: |  |  |  |
| Investment in marketable equity securities (1) | $ | 10.1 |  |  | $ | 8.4 |  |

[0001069202-12-000005:notes:106]
[same as prior period, unchanged from 0001193125-12-311640:notes:152]

[0001069202-12-000005:notes:107]
[same as prior period, unchanged from 0001193125-12-311640:notes:153]

[0001069202-12-000005:notes:108]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net, accounts payable, other current liabilities, and short-term debt approximate fair value due to the short maturities of these instruments. The fair values of each of our long-term debt instruments are based on the quoted market prices for the same issues or on the amount of future cash flows associated with each instrument using current market rates for debt instruments of similar maturities and credit risk. The fair values presented are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently or indicative of our intent or ability to dispose of or liquidate them. The estimated fair value of our debt was as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-12-000005:notes:109]
Goodwill:

[0001069202-12-000005:notes:110]
The changes in the carrying amount of goodwill for the first nine months of 2012, in total and by segment, are as follows (in millions):

[0001069202-12-000005:notes:111]
|  | Balance at December 31, 2011 |  |  |  |  |  | Balance at September 30, 2012 |
| Segment: | Goodwill |  | Acquisitions/(Dispositions) |  | Other(1) |  | Goodwill |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 63.5 |  |  | — |  |  | (0.1 | ) |  | 63.4 |  |
| Refrigeration | 133.6 |  |  | — |  |  | 0.6 |  |  | 134.2 |  |
|  | $ | 223.2 |  |  | $ | — |  |  | $ | 0.5 |  |  | $ | 223.7 |  |

[0001069202-12-000005:notes:112]
| (1) | Other consists primarily of changes in foreign currency translation rates. |

[0001069202-12-000005:notes:113]
Goodwill and Impairment related to Discontinued Operations

[0001069202-12-000005:notes:114]
Goodwill of $66.9 million and $82.4 million is included in Assets of discontinued operations as of September 30, 2012 and December 31, 2011, respectively.  The Goodwill balance included in Assets of discontinued operations as of September 30, 2012 includes accumulated impairment charges of $228.5 million, of which $208.0 million is from prior periods and $20.5 million is from the third quarter of 2012.

[0001069202-12-000005:notes:115]
In the third quarter of 2012, we announced our plan to sell the Service Experts business, as we do not consider it strategically necessary to own Service Experts dealer-contractors.  As a result of this decision, we determined that our long-lived assets and goodwill should be tested for impairment in the third quarter of 2012.

[0001069202-12-000005:notes:116]
For our long−lived assets, we performed an asset recoverability test at the lowest level of cash flows, or asset group. Based on this test, we determined that the asset groups’ carrying value was fully recoverable.

[0001069202-12-000005:notes:117]
For goodwill, we performed an impairment test and determined that the carrying value of our Service Experts reporting unit exceeded its fair value. The fair value of the reporting unit was based on indications of market value through our pursuit of strategic alternatives of the business. Accordingly, an impairment loss of $20.5 million was recorded in the third quarter of 2012 in the results from Discontinued operations. This impairment is an estimate that will be finalized once we complete our analysis of strategic alternatives for the business. Adjustments to the estimate will be made in future periods as necessary.

[0001069202-12-000005:notes:118]
We will continue to monitor our reporting units throughout the year to determine if a change in facts and circumstances warrants a re-evaluation of our goodwill.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-12-000005:notes:119]
Income Taxes:

[0001069202-12-000005:notes:120]
As of September 30, 2012, we had approximately $6.0 million in total gross unrecognized tax benefits. Of this amount, $5.9 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations. As of September 30, 2012, we recognized $0.1 million (net of federal tax benefits) in interest and penalties in income tax expense in accordance with FASB Accounting Standards Codification (“ASC”) Topic 740.

[0001069202-12-000005:notes:121]
We are currently under examination for our U.S. federal income taxes for 2011 and 2012 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years before 2007.

[0001069202-12-000005:notes:122]
Since January 1, 2012, numerous states, including Pennsylvania, Idaho and West Virginia, enacted legislation effective for tax years beginning on or after January 1, 2012, including changes to rates and apportionment methods. We believe any adjustments related to these changes will be immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-12-000005:notes:123]
Inventories:

[0001069202-12-000005:notes:124]
The components of inventories are as follows (in millions):

[0001069202-12-000005:notes:125]
|  | As of September 30, 2012 |  | As of December 31, 2011 |
| Finished goods | $ | 290.1 |  |  | $ | 222.3 |  |
| Work in process | 14.8 |  |  | 13.2 |  |
| Raw materials and repair parts | 167.4 |  |  | 156.3 |  |
|  | 472.3 |  |  | 391.8 |  |
| Excess of current cost over last-in, first-out cost and other items | (73.9 | ) |  | (73.9 | ) |
| Total inventories, net | $ | 398.4 |  |  | $ | 317.9 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-12-000005:notes:126]
General:

[0001069202-12-000005:notes:127]
References in this Quarterly Report on Form 10-Q to “we,” “our,” “us,” “LII” or the “Company” refer to Lennox International Inc. and its subsidiaries, unless the context requires otherwise.

[0001069202-12-000005:notes:128]
[same as prior period, unchanged from 0001193125-12-311640:notes:6]

[0001069202-12-000005:notes:129]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, and pension and postretirement medical benefits, among others. These estimates and assumptions are based on management’s best estimates and judgment.

[0001069202-12-000005:notes:130]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when facts and circumstances dictate.

[0001069202-12-000005:notes:131]
[same as prior period, unchanged from 0001193125-12-311640:notes:9]

[0001069202-12-000005:notes:132]
[same as prior period, unchanged from 0001193125-12-311640:notes:10]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-12-000005:notes:133]
Pension and Postretirement Benefit Plans:

[0001069202-12-000005:notes:134]
[same as prior period, unchanged from 0001193125-12-311640:notes:97]

[0001069202-12-000005:notes:135]
|  | For the Three Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.4 |  |  | $ | 1.3 |  |  | $ | — |  |  | $ | 0.2 |  |
| Interest cost | 4.3 |  |  | 4.5 |  |  | 0.1 |  |  | 0.2 |  |
| Expected return on plan assets | (4.7 | ) |  | (4.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.8 | ) |  | (0.4 | ) |
| Amortization of net loss | 2.1 |  |  | 1.7 |  |  | 0.4 |  |  | 0.3 |  |
| Settlements or curtailments | 1.0 |  |  | 0.1 |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 4.2 |  |  | $ | 3.0 |  |  | $ | (0.3 | ) |  | $ | 0.3 |  |

[0001069202-12-000005:notes:136]
|  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 4.1 |  |  | $ | 4.0 |  |  | $ | 0.2 |  |  | $ | 0.6 |  |
| Interest cost | 12.9 |  |  | 13.5 |  |  | 0.4 |  |  | 0.7 |  |
| Expected return on plan assets | (14.1 | ) |  | (14.2 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.3 |  |  | 0.3 |  |  | (2.0 | ) |  | (1.4 | ) |
| Amortization of net loss | 6.5 |  |  | 5.2 |  |  | 1.0 |  |  | 0.9 |  |
| Settlements or curtailments (1) | 7.3 |  |  | 1.7 |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 17.0 |  |  | $ | 10.5 |  |  | $ | (0.4 | ) |  | $ | 0.8 |  |

[0001069202-12-000005:notes:137]
| (1) | Settlements and curtailments in the nine months ended September 30, 2012 include a $6.3 million settlement charge related to actuarial losses recognized upon transition of a pension obligation to the acquirer of the Lennox Hearth Products business (“Hearth business”). |

[0001069202-12-000005:notes:138]
Pension expense of $3.6 million and $10.0 million is included in Income from continuing operations for the three and nine months ended September 30, 2012, respectively, and $2.9 million and $9.9 million in Income from continuing operations for the three and nine months ended September 30, 2011, respectively. Pension expense of $0.6 million and $7.0 million is included in Loss from discontinued operations for the three and nine months ended September 30, 2012, respectively, and $0.1 million and $0.6 million in Loss from discontinued operations for the three and nine months ended September 30, 2011, respectively.

[0001069202-12-000005:notes:139]
The pension expense for other benefits is included in Income from continuing operations for the three and nine months ended September 30, 2012 and 2011.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-12-000005:notes:140]
Restructuring Charges:

[0001069202-12-000005:notes:141]
As part of our strategic priorities of manufacturing and sourcing excellence and expense reduction, we initiated various manufacturing rationalization actions designed to lower our cost structure. We expanded these expense reductions across the company by initiating a number of activities to rationalize and reorganize various support and administrative functions. Restructuring charges are not included in our calculation of segment profit (loss). See Note 14 for further discussion on our reportable business segments. Detailed below are descriptions of the ongoing restructuring actions and their related activity in 2012.

[0001069202-12-000005:notes:142]
[same as prior period, unchanged from 0001193125-12-311640:notes:109]

[0001069202-12-000005:notes:143]
[same as prior period, unchanged from 0001193125-12-311640:notes:110]

[0001069202-12-000005:notes:144]
We began to exit certain Refrigeration manufacturing operations in Milperra, Australia in 2010, specifically our OEM coil manufacturing and contract coil manufacturing. The exit of our OEM coil manufacturing was substantially complete in 2010. We initiated restructuring activities related to exiting contract coil manufacturing in the third quarter of 2010. The remaining costs related to this restructuring activity primarily relate to plant closure costs. In the first nine months of 2012, we recognized $0.5 million in plant closure costs. We reversed $0.3 million in severance charges in the first nine months of 2012 to adjust estimated charges for our OEM coil manufacturing restructuring to actual.

[0001069202-12-000005:notes:145]
[same as prior period, unchanged from 0001193125-12-311640:notes:114]

[0001069202-12-000005:notes:146]
[same as prior period, unchanged from 0001193125-12-311640:notes:115]

[0001069202-12-000005:notes:147]
In the fourth quarter of 2008, we commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa to other locations, including our North American Distribution Center in Marshalltown, Iowa. In the first nine months of 2012, we recognized $2.7 million primarily in lease termination charges. The total expected restructuring charges for the regional distribution network is $6.7 million of which $6.3 million were incurred to date.

[0001069202-12-000005:notes:148]
[same as prior period, unchanged from 0001193125-12-311640:notes:117]

[0001069202-12-000005:notes:149]
[same as prior period, unchanged from 0001193125-12-311640:notes:118]

[0001069202-12-000005:notes:150]
|  | ChargesIncurred in2012 |  | ChargesIncurred toDate |  | TotalChargesExpected tobe Incurred |
| Severance and related expense | $ | 0.2 |  |  | $ | 23.3 |  |  | $ | 26.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 10.1 |  |  | 10.1 |  |
| Equipment moves | 0.1 |  |  | 1.5 |  |  | 1.7 |  |
| Lease termination | 2.4 |  |  | 7.2 |  |  | 7.2 |  |
| Other | 0.4 |  |  | 12.2 |  |  | 13.1 |  |
| Total | $ | 3.1 |  |  | $ | 54.3 |  |  | $ | 58.5 |  |

[0001069202-12-000005:notes:151]
[same as prior period, unchanged from 0001193125-12-311640:notes:120]

[0001069202-12-000005:notes:152]
|  | ChargesIncurred in2012 |  | ChargesIncurred toDate |  | TotalChargesExpected tobe Incurred |
| Residential Heating & Cooling | $ | 2.7 |  |  | $ | 17.9 |  |  | $ | 21.6 |  |
| Commercial Heating & Cooling | — |  |  | 7.8 |  |  | 7.8 |  |
| Refrigeration | 0.5 |  |  | 22.9 |  |  | 23.4 |  |
| Corporate & Other | (0.1 | ) |  | 5.7 |  |  | 5.7 |  |
| Total | $ | 3.1 |  |  | $ | 54.3 |  |  | $ | 58.5 |  |

[0001069202-12-000005:notes:153]
Restructuring reserves are included in Accrued Expenses in the accompanying Consolidated Balance Sheets. The table below details activity within the restructuring reserves for the first nine months of 2012 (in millions):

[0001069202-12-000005:notes:154]
| Description of Reserves | Balance as ofDecember 31, 2011 |  | ChargedtoEarnings |  | CashUtilization |  | Non-CashUtilizationand Other |  | Balance as ofSeptember 30, 2012 |
| Severance and related expense | $ | 2.3 |  |  | $ | 0.2 |  |  | $ | (1.0 | ) |  | $ | — |  |  | $ | 1.5 |  |
| Asset write-offs and accelerated depreciation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Equipment moves | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Lease termination | — |  |  | 2.4 |  |  | (1.9 | ) |  | — |  |  | 0.5 |  |
| Other | 0.1 |  |  | 0.4 |  |  | (0.2 | ) |  | — |  |  | 0.3 |  |
| Total restructuring reserves | $ | 2.4 |  |  | $ | 3.1 |  |  | $ | (3.1 | ) |  | $ | — |  |  | $ | 2.4 |  |

[0001069202-12-000005:notes:155]
Plans related to Discontinued Operations

[0001069202-12-000005:notes:156]
We began to reorganize certain administrative functions and the management structure of our Service Experts business in the fourth quarter of 2010.  We recognized $1.1 million of severance and other costs in Loss from discontinued operations in the first nine months of 2012.  Restructuring reserves of $0.2 million are included in Liabilities of discontinued operations as of September 30, 2012.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-12-000005:notes:157]
Net sales and segment profit (loss) by business segment, along with a reconciliation of segment profit (loss) to Income from continuing operations before income taxes are shown below (in millions):

[0001069202-12-000005:notes:158]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 386.3 |  |  | $ | 353.8 |  |  | $ | 1,070.7 |  |  | $ | 979.7 |  |
| Commercial Heating & Cooling | 219.7 |  |  | 223.6 |  |  | 597.9 |  |  | 596.4 |  |
| Refrigeration | 203.7 |  |  | 223.8 |  |  | 595.9 |  |  | 616.3 |  |
|  | $ | 809.7 |  |  | $ | 801.2 |  |  | $ | 2,264.5 |  |  | $ | 2,192.4 |  |
| Segment Profit (Loss) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 37.7 |  |  | $ | 31.3 |  |  | $ | 90.7 |  |  | $ | 70.9 |  |
| Commercial Heating & Cooling | 32.5 |  |  | 31.1 |  |  | 74.1 |  |  | 67.2 |  |
| Refrigeration | 25.1 |  |  | 20.5 |  |  | 60.6 |  |  | 55.5 |  |
| Corporate and other | (14.3 | ) |  | (15.1 | ) |  | (43.7 | ) |  | (41.5 | ) |
| Subtotal that includes segment profit and eliminations | 81.0 |  |  | 67.8 |  |  | 181.7 |  |  | 152.1 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Special product quality adjustment | 0.9 |  |  | — |  |  | 1.0 |  |  | (2.4 | ) |
| Items in (Gains) losses and other expenses, net that are excluded from segment profit (1) | (1.2 | ) |  | 3.2 |  |  | (2.0 | ) |  | 5.5 |  |
| Restructuring charges | 0.4 |  |  | 8.0 |  |  | 3.1 |  |  | 11.3 |  |
| Interest expense, net | 4.4 |  |  | 4.1 |  |  | 13.4 |  |  | 12.5 |  |
| Other expense, net | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Income from continuing operations before income taxes | $ | 76.5 |  |  | $ | 52.5 |  |  | $ | 166.1 |  |  | $ | 125.1 |  |

[0001069202-12-000005:notes:159]
| (1) | Items in (Gains) losses and other expenses, net that are excluded from segment profit are net change in unrealized gains and/or losses on open futures contracts, discount fees on accounts sold, and realized gains and/or losses on marketable securities. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-12-000005:notes:160]
Reportable Business Segments:

[0001069202-12-000005:notes:161]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our segments are organized primarily by the nature of the products and services provided.  In September 2012, the Company announced the planned sale of its Service Experts business. The Service Experts business had previously been reported within the Company’s Service Experts segment along with its commercial service business called Lennox National Account Services (NAS).  Beginning in the third quarter of 2012, Service Experts is included in discontinued operations and NAS is included in the Company's Commercial Heating & Cooling segment. Segment results for prior periods have been restated to conform with this new presentation.

[0001069202-12-000005:notes:162]
The table below details the nature of the operations for each reportable segment:

[0001069202-12-000005:notes:163]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | HeatingAir Conditioning |  | Residential ReplacementResidential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Rooftop ProductsChillersAir Handlers Equipment SalesInstallationMaintenanceRepair |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Unit CoolersCondensing UnitsOther Commercial Refrigeration ProductsDisplay Cases and Systems |  | Light CommercialFood Preservation andNon-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |

[0001069202-12-000005:notes:164]
Transactions between segments are recorded on an arm’s-length basis using the relevant market prices. The eliminations of any intercompany sales and associated profit or any other items are noted in the reconciliation of segment results to the income from continuing operations before income taxes below.

[0001069202-12-000005:notes:165]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources. We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations excluding certain items. The reconciliation below details the items excluded.

[0001069202-12-000005:notes:166]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII. We recorded these share-based awards as Corporate costs as they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-12-000005:notes:167]
Stock Repurchases:

[0001069202-12-000005:notes:168]
In 2008, our Board of Directors approved a $300.0 million share repurchase plan authorizing the repurchase of shares of our common stock through open market purchases (the “2008 Share Repurchase Plan”).  In December 2011, our Board of Directors increased the 2008 Share Repurchase Plan by $100 million.  For the three and nine months ended September 30, 2012, we repurchased 0.8 million shares of our common stock under the 2008 Share Repurchase Plan. These repurchased and surrendered shares are included in Treasury Stock.  The approximate dollar value of shares that may yet be repurchased under the 2008 Share Repurchase Program is $86.3 million.


## lii:CondensedConsolidatingFinancialStatementsTableTextBlock

[0001069202-12-000005:notes:169]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of September 30, 2012 and December 31, 2011 and for the three and nine months ended September 30, 2012 and 2011 are shown below:

[0001069202-12-000005:notes:170]
Condensed Consolidating Balance Sheets

[0001069202-12-000005:notes:171]
As of September 30, 2012

[0001069202-12-000005:notes:172]
(In millions)

[0001069202-12-000005:notes:173]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 21.6 |  |  | $ | 26.2 |  |  | $ | — |  |  | $ | 48.8 |  |
| Accounts and notes receivable, net | (1,049.7 | ) |  | 998.2 |  |  | 465.9 |  |  | 35.9 |  |  | 450.3 |  |
| Inventories, net | — |  |  | 278.6 |  |  | 126.2 |  |  | (6.4 | ) |  | 398.4 |  |
| Deferred income taxes, net | 6.5 |  |  | 21.9 |  |  | 5.7 |  |  | (1.3 | ) |  | 32.8 |  |
| Other assets | (4.5 | ) |  | 26.3 |  |  | 114.0 |  |  | (63.2 | ) |  | 72.6 |  |
| Assets of discontinued operations | — |  |  | (10.7 | ) |  | 119.4 |  |  | — |  |  | 108.7 |  |
| Total current assets | (1,046.7 | ) |  | 1,335.9 |  |  | 857.4 |  |  | (35.0 | ) |  | 1,111.6 |  |
| PROPERTY, PLANT AND EQUIPMENT, net | — |  |  | 235.2 |  |  | 54.2 |  |  | — |  |  | 289.4 |  |
| GOODWILL | — |  |  | 131.8 |  |  | 91.9 |  |  | — |  |  | 223.7 |  |
| DEFERRED INCOME TAXES | (1.7 | ) |  | 81.9 |  |  | 16.8 |  |  | (9.7 | ) |  | 87.3 |  |
| OTHER ASSETS, net(1) | 2,151.5 |  |  | 547.8 |  |  | 24.2 |  |  | (2,642.0 | ) |  | 81.5 |  |
| TOTAL ASSETS | $ | 1,103.1 |  |  | $ | 2,332.6 |  |  | $ | 1,044.5 |  |  | $ | (2,686.7 | ) |  | $ | 1,793.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 97.3 |  |  | $ | — |  |  | $ | (50.2 | ) |  | $ | (16.0 | ) |  | $ | 31.1 |  |
| Current maturities of long-term debt | — |  |  | 0.2 |  |  | 0.1 |  |  | — |  |  | 0.3 |  |
| Accounts payable | 10.1 |  |  | 133.5 |  |  | 87.3 |  |  | 46.7 |  |  | 277.6 |  |
| Accrued expenses | 4.8 |  |  | 191.8 |  |  | 62.2 |  |  | (0.1 | ) |  | 258.7 |  |
| Income taxes payable | (20.9 | ) |  | 36.1 |  |  | 41.8 |  |  | (48.5 | ) |  | 8.5 |  |
| Liabilities of discontinued operations | — |  |  | 49.7 |  |  | 12.5 |  |  | — |  |  | 62.2 |  |
| Total current liabilities | 91.3 |  |  | 411.3 |  |  | 153.7 |  |  | (17.9 | ) |  | 638.4 |  |
| LONG-TERM DEBT | 433.0 |  |  | 16.2 |  |  | 100.2 |  |  | (99.8 | ) |  | 449.6 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS | — |  |  | 17.1 |  |  | — |  |  | — |  |  | 17.1 |  |
| PENSIONS | — |  |  | 104.4 |  |  | 11.8 |  |  | — |  |  | 116.2 |  |
| OTHER LIABILITIES | 0.7 |  |  | 58.9 |  |  | 14.2 |  |  | (11.0 | ) |  | 62.8 |  |
| Total liabilities | 525.0 |  |  | 607.9 |  |  | 279.9 |  |  | (128.7 | ) |  | 1,284.1 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY | 578.1 |  |  | 1,724.7 |  |  | 764.6 |  |  | (2,558.0 | ) |  | 509.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,103.1 |  |  | $ | 2,332.6 |  |  | $ | 1,044.5 |  |  | $ | (2,686.7 | ) |  | $ | 1,793.5 |  |

[0001069202-12-000005:notes:174]
| (1) | OTHER ASSETS, net consists primarily of Investments in Subsidiaries which eliminate upon consolidation. |

[0001069202-12-000005:notes:175]
Condensed Consolidating Statements of Operations

[0001069202-12-000005:notes:176]
For the Three Months Ended September 30, 2012

[0001069202-12-000005:notes:177]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| NET SALES | $ | — |  |  | $ | 654.5 |  |  | $ | 214.3 |  |  | $ | (59.1 | ) |  | $ | 809.7 |  |
| COST OF GOODS SOLD | — |  |  | 499.7 |  |  | 163.9 |  |  | (58.8 | ) |  | 604.8 |  |
| Gross profit | — |  |  | 154.8 |  |  | 50.4 |  |  | (0.3 | ) |  | 204.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 99.2 |  |  | 26.8 |  |  | (0.1 | ) |  | 125.9 |  |
| (Gains) losses and other expenses, net | 0.1 |  |  | (1.0 | ) |  | 1.2 |  |  | — |  |  | 0.3 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.3 |  |  | — |  |  | 0.4 |  |
| (Income) loss from equity method investments | (38.4 | ) |  | (6.5 | ) |  | (1.9 | ) |  | 44.2 |  |  | (2.6 | ) |
| Operational income (loss) from continuing operations | 38.3 |  |  | 63.0 |  |  | 24.0 |  |  | (44.4 | ) |  | 80.9 |  |
| INTEREST EXPENSE (INCOME), net | 4.3 |  |  | (0.6 | ) |  | 0.7 |  |  | — |  |  | 4.4 |  |
| OTHER EXPENSE, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 34.0 |  |  | 63.6 |  |  | 23.3 |  |  | (44.4 | ) |  | 76.5 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES | (1.6 | ) |  | 20.1 |  |  | 10.0 |  |  | (1.7 | ) |  | 26.8 |  |
| Income (loss) from continuing operations | 35.6 |  |  | 43.5 |  |  | 13.3 |  |  | (42.7 | ) |  | 49.7 |  |
| Loss from discontinued operations | — |  |  | (12.6 | ) |  | (7.7 | ) |  | — |  |  | (20.3 | ) |
| Net income (loss) | $ | 35.6 |  |  | $ | 30.9 |  |  | $ | 5.6 |  |  | $ | (42.7 | ) |  | $ | 29.4 |  |
| OTHER COMPREHENSIVE INCOME | $ | 5.6 |  |  | $ | 4.6 |  |  | $ | 17.4 |  |  | $ | 1.9 |  |  | $ | 29.5 |  |

[0001069202-12-000005:notes:178]
For the Nine Months Ended September 30, 2012

[0001069202-12-000005:notes:179]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| NET SALES | $ | — |  |  | $ | 1,814.5 |  |  | $ | 610.2 |  |  | $ | (160.2 | ) |  | $ | 2,264.5 |  |
| COST OF GOODS SOLD | 0.1 |  |  | 1,401.7 |  |  | 468.4 |  |  | (159.6 | ) |  | 1,710.6 |  |
| Gross profit | (0.1 | ) |  | 412.8 |  |  | 141.8 |  |  | (0.6 | ) |  | 553.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 286.5 |  |  | 93.3 |  |  | — |  |  | 379.8 |  |
| (Gains) losses and other expenses, net | (2.1 | ) |  | (0.4 | ) |  | 2.7 |  |  | — |  |  | 0.2 |  |
| Restructuring charges | — |  |  | 2.6 |  |  | 0.5 |  |  | — |  |  | 3.1 |  |
| (Income) loss from equity method investments | (81.9 | ) |  | (8.1 | ) |  | (6.9 | ) |  | 88.1 |  |  | (8.8 | ) |
| Operational income (loss) from continuing operations | 83.9 |  |  | 132.2 |  |  | 52.2 |  |  | (88.7 | ) |  | 179.6 |  |
| INTEREST EXPENSE (INCOME), net | 13.1 |  |  | (1.8 | ) |  | 2.1 |  |  | — |  |  | 13.4 |  |
| OTHER EXPENSE, net | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes | 70.8 |  |  | 134.0 |  |  | 50.0 |  |  | (88.7 | ) |  | 166.1 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES | (4.0 | ) |  | 45.1 |  |  | 16.7 |  |  | (0.2 | ) |  | 57.6 |  |
| Income (loss) from continuing operations | 74.8 |  |  | 88.9 |  |  | 33.3 |  |  | (88.5 | ) |  | 108.5 |  |
| Loss from discontinued operations | — |  |  | (27.9 | ) |  | (12.6 | ) |  | — |  |  | (40.5 | ) |
| Net income (loss) | $ | 74.8 |  |  | $ | 61.0 |  |  | $ | 20.7 |  |  | $ | (88.5 | ) |  | $ | 68.0 |  |
| OTHER COMPREHENSIVE INCOME | $ | 7.9 |  |  | $ | 4.4 |  |  | $ | 8.4 |  |  | $ | 6.2 |  |  | $ | 26.9 |  |

[0001069202-12-000005:notes:180]
As of December 31, 2011

[0001069202-12-000005:notes:181]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 9.7 |  |  | $ | 34.4 |  |  | $ | (0.1 | ) |  | $ | 45.0 |  |
| Accounts and notes receivable, net | (991.9 | ) |  | 944.5 |  |  | 413.8 |  |  | 20.6 |  |  | 387.0 |  |
| Inventories, net | — |  |  | 217.1 |  |  | 105.5 |  |  | (4.7 | ) |  | 317.9 |  |
| Deferred income taxes, net | 4.7 |  |  | 22.0 |  |  | 8.4 |  |  | (1.3 | ) |  | 33.8 |  |
| Other assets | 1.6 |  |  | 16.5 |  |  | 106.9 |  |  | (56.5 | ) |  | 68.5 |  |
| Assets of discontinued operations | — |  |  | 55.7 |  |  | 104.8 |  |  | — |  |  | 160.5 |  |
| Total current assets | (984.6 | ) |  | 1,265.5 |  |  | 773.8 |  |  | (42.0 | ) |  | 1,012.7 |  |
| PROPERTY, PLANT AND EQUIPMENT, net | — |  |  | 248.2 |  |  | 52.5 |  |  | — |  |  | 300.7 |  |
| GOODWILL | — |  |  | 104.1 |  |  | 119.1 |  |  | — |  |  | 223.2 |  |
| DEFERRED INCOME TAXES | 0.2 |  |  | 82.0 |  |  | 18.2 |  |  | (9.7 | ) |  | 90.7 |  |
| OTHER ASSETS, net(1) | 2,174.1 |  |  | 531.2 |  |  | 22.1 |  |  | (2,649.0 | ) |  | 78.4 |  |
| TOTAL ASSETS | $ | 1,189.7 |  |  | $ | 2,231.0 |  |  | $ | 985.7 |  |  | $ | (2,700.7 | ) |  | $ | 1,705.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 112.1 |  |  | $ | — |  |  | $ | (67.3 | ) |  | $ | (40.1 | ) |  | $ | 4.7 |  |
| Current maturities of long-term debt | — |  |  | 0.6 |  |  | 0.2 |  |  | — |  |  | 0.8 |  |
| Accounts payable | 9.2 |  |  | 120.9 |  |  | 93.4 |  |  | 31.4 |  |  | 254.9 |  |
| Accrued expenses | 15.2 |  |  | 146.7 |  |  | 77.5 |  |  | — |  |  | 239.4 |  |
| Income taxes payable | (29.9 | ) |  | 28.0 |  |  | 24.7 |  |  | (17.1 | ) |  | 5.7 |  |
| Liabilities of discontinued operations | — |  |  | 54.9 |  |  | 16.7 |  |  | — |  |  | 71.6 |  |
| Total current liabilities | 106.6 |  |  | 351.1 |  |  | 145.2 |  |  | (25.8 | ) |  | 577.1 |  |
| LONG-TERM DEBT | 443.0 |  |  | 16.2 |  |  | 97.3 |  |  | (96.9 | ) |  | 459.6 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS | — |  |  | 18.6 |  |  | — |  |  | — |  |  | 18.6 |  |
| PENSIONS | — |  |  | 111.9 |  |  | 12.8 |  |  | — |  |  | 124.7 |  |
| OTHER LIABILITIES | 0.8 |  |  | 54.8 |  |  | 13.3 |  |  | (11.0 | ) |  | 57.9 |  |
| Total liabilities | 550.4 |  |  | 552.6 |  |  | 268.6 |  |  | (133.7 | ) |  | 1,237.9 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY | 639.3 |  |  | 1,678.4 |  |  | 717.1 |  |  | (2,567.0 | ) |  | 467.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,189.7 |  |  | $ | 2,231.0 |  |  | $ | 985.7 |  |  | $ | (2,700.7 | ) |  | $ | 1,705.7 |  |

[0001069202-12-000005:notes:182]
For the Three Months Ended September 30, 2011

[0001069202-12-000005:notes:183]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| NET SALES | $ | — |  |  | $ | 629.0 |  |  | $ | 226.9 |  |  | $ | (54.7 | ) |  | $ | 801.2 |  |
| COST OF GOODS SOLD | — |  |  | 496.4 |  |  | 173.6 |  |  | (55.4 | ) |  | 614.6 |  |
| Gross profit | — |  |  | 132.6 |  |  | 53.3 |  |  | 0.7 |  |  | 186.6 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 87.9 |  |  | 34.5 |  |  | — |  |  | 122.4 |  |
| Losses (gains) and other expenses, net | 2.3 |  |  | 0.8 |  |  | (0.5 | ) |  | — |  |  | 2.6 |  |
| Restructuring charges | — |  |  | 7.1 |  |  | 0.9 |  |  | — |  |  | 8.0 |  |
| (Income) loss from equity method investments | (47.6 | ) |  | (11.1 | ) |  | (2.1 | ) |  | 57.8 |  |  | (3.0 | ) |
| Operational income (loss) from continuing operations | 45.3 |  |  | 47.9 |  |  | 20.5 |  |  | (57.1 | ) |  | 56.6 |  |
| INTEREST EXPENSE (INCOME), net | 4.0 |  |  | (0.9 | ) |  | 1.0 |  |  | — |  |  | 4.1 |  |
| OTHER EXPENSE, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 41.3 |  |  | 48.8 |  |  | 19.5 |  |  | (57.1 | ) |  | 52.5 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES | (2.3 | ) |  | 13.6 |  |  | 5.7 |  |  | 0.6 |  |  | 17.6 |  |
| Income (loss) from continuing operations | 43.6 |  |  | 35.2 |  |  | 13.8 |  |  | (57.7 | ) |  | 34.9 |  |
| (Loss) income from discontinued operations | — |  |  | (2.4 | ) |  | 1.3 |  |  | — |  |  | (1.1 | ) |
| Net income (loss) | $ | 43.6 |  |  | $ | 32.8 |  |  | $ | 15.1 |  |  | $ | (57.7 | ) |  | $ | 33.8 |  |
| OTHER COMPREHENSIVE LOSS | $ | (14.5 | ) |  | $ | (12.5 | ) |  | $ | (46.4 | ) |  | $ | (2.7 | ) |  | $ | (76.1 | ) |

[0001069202-12-000005:notes:184]
For the Nine Months Ended September 30, 2011

[0001069202-12-000005:notes:185]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| NET SALES | $ | — |  |  | $ | 1,710.3 |  |  | $ | 633.3 |  |  | $ | (151.2 | ) |  | $ | 2,192.4 |  |
| COST OF GOODS SOLD | 0.1 |  |  | 1,341.2 |  |  | 487.1 |  |  | (152.5 | ) |  | 1,675.9 |  |
| Gross profit | (0.1 | ) |  | 369.1 |  |  | 146.2 |  |  | 1.3 |  |  | 516.5 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 264.1 |  |  | 108.8 |  |  | — |  |  | 372.9 |  |
| Losses (gains) and other expenses, net | 4.5 |  |  | (0.4 | ) |  | (0.5 | ) |  | — |  |  | 3.6 |  |
| Restructuring charges | — |  |  | 10.0 |  |  | 1.3 |  |  | — |  |  | 11.3 |  |
| (Income) loss from equity method investments | (96.5 | ) |  | (16.8 | ) |  | (7.0 | ) |  | 111.3 |  |  | (9.0 | ) |
| Operational income (loss) from continuing operations | 91.9 |  |  | 112.2 |  |  | 43.6 |  |  | (110.0 | ) |  | 137.7 |  |
| INTEREST EXPENSE (INCOME), net | 12.0 |  |  | (2.7 | ) |  | 3.2 |  |  | — |  |  | 12.5 |  |
| OTHER EXPENSE, net | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes | 79.9 |  |  | 114.9 |  |  | 40.3 |  |  | (110.0 | ) |  | 125.1 |  |
| (BENEFIT FROM) PROVISION FOR INCOME TAXES | (5.8 | ) |  | 35.9 |  |  | 11.2 |  |  | 1.1 |  |  | 42.4 |  |
| Income (loss) from continuing operations | 85.7 |  |  | 79.0 |  |  | 29.1 |  |  | (111.1 | ) |  | 82.7 |  |
| (Loss) income from discontinued operations | — |  |  | (11.9 | ) |  | 0.8 |  |  | — |  |  | (11.1 | ) |
| Net income (loss) | $ | 85.7 |  |  | $ | 67.1 |  |  | $ | 29.9 |  |  | $ | (111.1 | ) |  | $ | 71.6 |  |
| OTHER COMPREHENSIVE LOSS | $ | (21.2 | ) |  | $ | (6.8 | ) |  | $ | (29.6 | ) |  | $ | (1.4 | ) |  | $ | (59.0 | ) |

[0001069202-12-000005:notes:186]
Condensed Consolidating Statements of Cash Flows

[0001069202-12-000005:notes:187]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net cash provided by (used in) operating activities | $ | 21.4 |  |  | $ | 83.4 |  |  | $ | (40.4 | ) |  | $ | — |  |  | $ | 64.4 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (21.5 | ) |  | (6.5 | ) |  | — |  |  | (28.0 | ) |
| Net proceeds from sale of business | — |  |  | 10.1 |  |  | — |  |  | — |  |  | 10.1 |  |
| Net cash (used in) provided by discontinued operations | — |  |  | (0.4 | ) |  | 0.1 |  |  | — |  |  | (0.3 | ) |
| Net cash used in investing activities | — |  |  | (11.7 | ) |  | (6.4 | ) |  | — |  |  | (18.1 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 480.0 |  |  | — |  |  | 480.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (455.0 | ) |  | — |  |  | (455.0 | ) |
| Long-term payments | — |  |  | (0.6 | ) |  | (0.3 | ) |  | — |  |  | (0.9 | ) |
| Borrowings from revolving credit facility | 696.0 |  |  | — |  |  | — |  |  | — |  |  | 696.0 |  |
| Payments on revolving credit facility | (706.0 | ) |  | — |  |  | — |  |  | — |  |  | (706.0 | ) |
| Proceeds from stock option exercises | 0.3 |  |  | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Repurchases of common stock | (38.4 | ) |  | — |  |  | — |  |  | — |  |  | (38.4 | ) |
| Excess tax benefits related to share-based payments | 1.7 |  |  | — |  |  | — |  |  | — |  |  | 1.7 |  |
| Intercompany debt | (5.3 | ) |  | (3.9 | ) |  | 9.2 |  |  | — |  |  | — |  |
| Intercompany financing activity | 57.8 |  |  | (55.3 | ) |  | (2.5 | ) |  | — |  |  | — |  |
| Cash dividends paid | (27.5 | ) |  | — |  |  | — |  |  | — |  |  | (27.5 | ) |
| Net cash (used in) provided by financing activities | (21.4 | ) |  | (59.8 | ) |  | 32.7 |  |  | — |  |  | (48.5 | ) |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | — |  |  | 11.9 |  |  | (14.1 | ) |  | — |  |  | (2.2 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | — |  |  | — |  |  | 6.0 |  |  | — |  |  | 6.0 |  |
| CASH AND CASH EQUIVALENTS, beginning of period | 1.0 |  |  | 9.7 |  |  | 34.3 |  |  | — |  |  | 45.0 |  |
| CASH AND CASH EQUIVALENTS, end of period | $ | 1.0 |  |  | $ | 21.6 |  |  | $ | 26.2 |  |  | $ | — |  |  | $ | 48.8 |  |

[0001069202-12-000005:notes:188]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net cash provided by (used in) operating activities | $ | 31.8 |  |  | $ | (64.2 | ) |  | $ | 30.2 |  |  | $ | — |  |  | $ | (2.2 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (22.4 | ) |  | (3.4 | ) |  | — |  |  | (25.8 | ) |
| Net proceeds from sale of business | — |  |  | — |  |  | 0.6 |  |  | — |  |  | 0.6 |  |
| Acquisition of business | — |  |  | (147.7 | ) |  | — |  |  | — |  |  | (147.7 | ) |
| Change in restricted cash | — |  |  | — |  |  | 12.2 |  |  | — |  |  | 12.2 |  |
| Net cash used in discontinued operations | — |  |  | (1.1 | ) |  | (0.1 | ) |  | — |  |  | (1.2 | ) |
| Net cash (used in) provided by investing activities | — |  |  | (171.1 | ) |  | 9.4 |  |  | — |  |  | (161.7 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 220.0 |  |  | — |  |  | 220.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (220.0 | ) |  | — |  |  | (220.0 | ) |
| Long-term payments | — |  |  | (0.7 | ) |  | — |  |  | — |  |  | (0.7 | ) |
| Borrowings from revolving credit facility | 1,090.0 |  |  | — |  |  | — |  |  | — |  |  | 1,090.0 |  |
| Payments on revolving credit facility | (911.5 | ) |  | — |  |  | — |  |  | — |  |  | (911.5 | ) |
| Proceeds from stock option exercises | 1.5 |  |  | — |  |  | — |  |  | — |  |  | 1.5 |  |
| Repurchases of common stock | (90.9 | ) |  | — |  |  | — |  |  | — |  |  | (90.9 | ) |
| Excess tax benefits related to share-based payments | 1.5 |  |  | — |  |  | — |  |  | — |  |  | 1.5 |  |
| Intercompany debt | 76.7 |  |  | (2.3 | ) |  | (74.4 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (252.7 | ) |  | 242.7 |  |  | 10.0 |  |  | — |  |  | — |  |
| Cash dividends paid | (27.2 | ) |  | — |  |  | — |  |  | — |  |  | (27.2 | ) |
| Net cash (used in) provided by financing activities | (112.6 | ) |  | 239.7 |  |  | (61.9 | ) |  | — |  |  | 65.2 |  |
| (DECREASE) INCREASE IN CASH AND CASH EQUIVALENTS | (80.8 | ) |  | 4.4 |  |  | (22.3 | ) |  | — |  |  | (98.7 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | — |  |  | — |  |  | (3.4 | ) |  | — |  |  | (3.4 | ) |
| CASH AND CASH EQUIVALENTS, beginning of period | 81.1 |  |  | 14.7 |  |  | 64.2 |  |  | — |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of period | $ | 0.3 |  |  | $ | 19.1 |  |  | $ | 38.5 |  |  | $ | — |  |  | $ | 57.9 |  |


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0001069202-12-000005:notes:189]
Condensed Consolidating Financial Statements:

[0001069202-12-000005:notes:190]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned; all guarantees are full and unconditional; and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001069202-12-000005:notes:191]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting. Intercompany account balances have been included in Accounts and notes receivable, Other assets (Current), Other assets, net, Short-term debt, Accounts payable, and Long-term debt line items of the Parent, Guarantor and Non-Guarantor balance sheets. The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.
