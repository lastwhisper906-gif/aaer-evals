# LII notes — 0001628280-24-043392


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-24-043392:notes:1]
[same as prior period, unchanged from 0001628280-24-032782:notes:1]

[0001628280-24-043392:notes:2]
[same as prior period, unchanged from 0001628280-24-032782:notes:2]

[0001628280-24-043392:notes:3]
[same as prior period, unchanged from 0001628280-24-032782:notes:3]

[0001628280-24-043392:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2024, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2024 and 2023, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three and nine months ended September 30, 2024 and 2023, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2024 and 2023 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2023.

[0001628280-24-043392:notes:5]
[same as prior period, unchanged from 0001628280-24-032782:notes:5]

[0001628280-24-043392:notes:6]
[same as prior period, unchanged from 0001628280-24-032782:notes:6]

[0001628280-24-043392:notes:7]
[same as prior period, unchanged from 0001628280-24-032782:notes:7]

[0001628280-24-043392:notes:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-24-043392:notes:9]
[same as prior period, unchanged from 0001628280-24-032782:notes:9]

[0001628280-24-043392:notes:10]
[same as prior period, unchanged from 0001628280-24-032782:notes:10]

[0001628280-24-043392:notes:11]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Home Comfort Solutions |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Building Climate Solutions |  | Commercial heating, air conditioning and refrigeration systems. Products include rooftop packaged units, variable refrigerant flow systems, heat pumps, air cooled condensing units, air handlers, unit coolers, and process chillers. Services include installation, energy monitoring, service and maintenance, and HVAC recycling. |  | Light Commercial;Food Preservation; Non-Food Industry |  | United StatesCanada |

[0001628280-24-043392:notes:12]
[same as prior period, unchanged from 0001628280-24-032782:notes:12]

[0001628280-24-043392:notes:13]
[same as prior period, unchanged from 0001628280-24-032782:notes:13]

[0001628280-24-043392:notes:14]
[same as prior period, unchanged from 0001628280-24-032782:notes:14]

[0001628280-24-043392:notes:15]
[same as prior period, unchanged from 0001628280-24-032782:notes:15]

[0001628280-24-043392:notes:16]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 1,032.8 |  |  | $ | 896.3 |  |  | $ | 2,689.7 |  |  | $ | 2,513.6 |  |
| Business Climate Solutions | 465.3 |  |  | 405.5 |  |  | 1,306.6 |  |  | 1,121.5 |  |
| Corporate and Other (1) | — |  |  | 64.5 |  |  | — |  |  | 192.0 |  |
| Total segment net sales | $ | 1,498.1 |  |  | $ | 1,366.3 |  |  | $ | 3,996.3 |  |  | $ | 3,827.1 |  |
| Segment profit (loss) (2) |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 226.5 |  |  | $ | 181.4 |  |  | $ | 567.1 |  |  | $ | 495.2 |  |
| Business Climate Solutions | 105.9 |  |  | 97.3 |  |  | 298.1 |  |  | 250.3 |  |
| Corporate and Other | (29.1) |  |  | (23.4) |  |  | (76.6) |  |  | (65.2) |  |
| Total segment profit | 303.3 |  |  | 255.3 |  |  | 788.6 |  |  | 680.3 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Impairment on assets held for sale | — |  |  | 63.2 |  |  | — |  |  | 63.2 |  |
| Gain on sale from previous dispositions | — |  |  | — |  |  | (1.6) |  |  | — |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | — |  |  | 5.0 |  |  | — |  |  | 12.1 |  |
| Restructuring charges | — |  |  | 0.3 |  |  | — |  |  | 0.2 |  |
| Operating income | $ | 303.3 |  |  | $ | 186.8 |  |  | $ | 790.2 |  |  | $ | 604.8 |  |

[0001628280-24-043392:notes:17]
[same as prior period, unchanged from 0001628280-24-032782:notes:17]

[0001628280-24-043392:notes:18]
[same as prior period, unchanged from 0001628280-24-032782:notes:18]

[0001628280-24-043392:notes:19]
[same as prior period, unchanged from 0001628280-24-032782:notes:19]

[0001628280-24-043392:notes:20]
[same as prior period, unchanged from 0001628280-24-032782:notes:20]

[0001628280-24-043392:notes:21]
▪Environmental liabilities and special litigation charges, and

[0001628280-24-043392:notes:22]
▪Other items, net
◦R


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-043392:notes:23]
[same as prior period, unchanged from 0001628280-24-032782:notes:24]

[0001628280-24-043392:notes:24]
[same as prior period, unchanged from 0001628280-24-032782:notes:25]

[0001628280-24-043392:notes:25]
[same as prior period, unchanged from 0001628280-24-032782:notes:26]

[0001628280-24-043392:notes:26]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income | $ | 239.0 |  |  | $ | 130.4 |  |  | $ | 609.2 |  |  | $ | 445.6 |  |
| Weighted-average shares outstanding – basic | 35.6 |  |  | 35.5 |  |  | 35.6 |  |  | 35.5 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |
| Weighted-average shares outstanding – diluted | 35.8 |  |  | 35.7 |  |  | 35.8 |  |  | 35.6 |  |
| Earnings per share – Basic: | $ | 6.71 |  |  | $ | 3.67 |  |  | $ | 17.11 |  |  | $ | 12.55 |  |
| Earnings per share – Diluted: | $ | 6.68 |  |  | $ | 3.65 |  |  | $ | 17.02 |  |  | $ | 12.51 |  |

[0001628280-24-043392:notes:27]
[same as prior period, unchanged from 0001628280-24-032782:notes:28]

[0001628280-24-043392:notes:28]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Weighted-average number of shares | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-24-043392:notes:29]
4. Commitments and Contingencies:

[0001628280-24-043392:notes:30]
Leases

[0001628280-24-043392:notes:31]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001628280-24-043392:notes:32]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering

[0001628280-24-043392:notes:33]
event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001628280-24-043392:notes:34]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001628280-24-043392:notes:35]
We lease certain real and personal property under non-cancelable operating leases. Approximately 79% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001628280-24-043392:notes:36]
Product Warranties and Product Related Contingencies

[0001628280-24-043392:notes:37]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001628280-24-043392:notes:38]
Liabilities for estimated product warranty costs are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:

[0001628280-24-043392:notes:39]
|  | September 30, 2024 |  | December 31, 2023 |
| Accrued expenses | $ | 47.8 |  |  | $ | 45.4 |  |
| Other liabilities | 109.1 |  |  | 97.4 |  |
| Total warranty liability | $ | 156.9 |  |  | $ | 142.8 |  |

[0001628280-24-043392:notes:40]
The changes in product warranty liabilities for the nine months ended September 30, 2024 were as follows (in millions):

[0001628280-24-043392:notes:41]
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Warranty claims paid | (32.4) |  |
| Changes resulting from issuance of new warranties | 46.5 |  |
| Changes in estimates associated with pre-existing liabilities | 0.2 |  |
| Changes in foreign currency translation rates and other | (0.2) |  |
| Total warranty liability as of September 30, 2024 | $ | 156.9 |  |

[0001628280-24-043392:notes:42]
Litigation

[0001628280-24-043392:notes:43]
We are involved in a number of claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-24-043392:notes:44]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-24-043392:notes:45]
5. Stock Repurchases:

[0001628280-24-043392:notes:46]
Our Board of Directors has authorized a total of $4.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in July 2021. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. Such repurchases may also be made in compliance with Rule 10b5-1 trading plans entered into by us, which would permit common stock to be repurchased when the Company might otherwise be precluded from doing so under insider trading laws or self-imposed trading restrictions. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of September 30, 2024, $532.5 million was available for repurchase under the Share Repurchase Plans.

[0001628280-24-043392:notes:47]
For the three and nine months ended September 30, 2024, we repurchased 23,000 shares at an aggregate cost, inclusive of fees, of $13.5 million.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-043392:notes:48]
[same as prior period, unchanged from 0001628280-24-032782:notes:47]

[0001628280-24-043392:notes:49]
[same as prior period, unchanged from 0001628280-24-032782:notes:48]

[0001628280-24-043392:notes:50]
|  | For the Three Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 971.1 |  |  | $ | 441.9 |  |  | $ | — |  |  | $ | 1,413.0 |  |
| Canada | 61.7 |  |  | 23.4 |  |  | — |  |  | 85.1 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,032.8 |  |  | $ | 465.3 |  |  | $ | — |  |  | $ | 1,498.1 |  |

[0001628280-24-043392:notes:51]
|  | For the Three Months Ended September 30, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 842.1 |  |  | $ | 376.8 |  |  | $ | — |  |  | $ | 1,218.9 |  |
| Canada | 54.2 |  |  | 28.7 |  |  | — |  |  | 82.9 |  |
| Other international | — |  |  | — |  |  | 64.5 |  |  | 64.5 |  |
| Total | $ | 896.3 |  |  | $ | 405.5 |  |  | $ | 64.5 |  |  | $ | 1,366.3 |  |

[0001628280-24-043392:notes:52]
|  | For the Nine Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,520.7 |  |  | $ | 1,244.2 |  |  | $ | — |  |  | $ | 3,764.9 |  |
| Canada | 169.0 |  |  | 62.4 |  |  | — |  |  | 231.4 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 2,689.7 |  |  | $ | 1,306.6 |  |  | $ | — |  |  | $ | 3,996.3 |  |

[0001628280-24-043392:notes:53]
|  | For the Nine Months Ended September 30, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,350.0 |  |  | $ | 1,053.5 |  |  | $ | — |  |  | $ | 3,403.5 |  |
| Canada | 163.6 |  |  | 68.0 |  |  | — |  |  | 231.6 |  |
| Other international | — |  |  | — |  |  | 192.0 |  |  | 192.0 |  |
| Total | $ | 2,513.6 |  |  | $ | 1,121.5 |  |  | $ | 192.0 |  |  | $ | 3,827.1 |  |

[0001628280-24-043392:notes:54]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2024 and 2023, direct sales represented 73% and 77% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2024 and 2023, direct sales represented 74% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001628280-24-043392:notes:55]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2024 and 2023, equipment sales represented 80% and 88% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2024 and 2023, equipment sales represented 81% and 87% of revenues and the remainder of our revenue was generated from our services business.

[0001628280-24-043392:notes:56]
[same as prior period, unchanged from 0001628280-24-032782:notes:56]

[0001628280-24-043392:notes:57]
[same as prior period, unchanged from 0001628280-24-032782:notes:57]

[0001628280-24-043392:notes:58]
|  | September 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Contract assets | $ | 2.0 |  |  | $ | 2.2 |  |  |  |  |  |
| Contract liabilities - current | (4.2) |  |  | (4.7) |  |  |  |  |  |
| Contract liabilities - noncurrent | (8.1) |  |  | (7.5) |  |  |  |  |  |
| Total | $ | (10.3) |  |  | $ | (10.0) |  |  |  |  |  |

[0001628280-24-043392:notes:59]
For the three months ended September 30, 2024 and 2023, we recognized revenue of $0.7 million and $2.8 million and for the nine months ended September 30, 2024 and 2023, we recognized revenue of $6.8 million and $7.0 million related to our contract liabilities at January 1, 2024 and 2023, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2024 and 2023.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-24-043392:notes:60]
[same as prior period, unchanged from 0001628280-24-032782:notes:60]

[0001628280-24-043392:notes:61]
[same as prior period, unchanged from 0001628280-24-032782:notes:61]

[0001628280-24-043392:notes:62]
|  | September 30, 2024 |  | December 31, 2023 |
| Finished goods | $ | 443.2 |  |  | $ | 509.4 |  |
| Work in process | 13.7 |  |  | 9.6 |  |
| Raw materials and parts | 369.3 |  |  | 314.2 |  |
| Subtotal | 826.2 |  |  | 833.2 |  |
| Excess of current cost over last-in, first-out cost | (137.0) |  |  | (134.1) |  |
| Total inventories, net | $ | 689.2 |  |  | $ | 699.1 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-24-043392:notes:63]
[same as prior period, unchanged from 0001628280-24-032782:notes:63]

[0001628280-24-043392:notes:64]
[same as prior period, unchanged from 0001628280-24-032782:notes:64]

[0001628280-24-043392:notes:65]
|  | Balance as of December 31, 2023 |  | Goodwill Adjustment (1) |  |  |  | Balance as of September 30, 2024 |
| Home Comfort Solutions | $ | 26.1 |  |  | $ | — |  |  |  |  | $ | 26.1 |  |
| Building Climate Solutions (1) | 196.0 |  |  | (2.2) |  |  |  |  | 193.8 |  |
| Total Goodwill | $ | 222.1 |  |  | $ | (2.2) |  |  |  |  | $ | 219.9 |  |

[0001628280-24-043392:notes:66]
[same as prior period, unchanged from 0001628280-24-032782:notes:66]

[0001628280-24-043392:notes:67]
We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We have not recorded any goodwill impairments for the nine months ended September 30, 2024 or in any periods presented for our continuing businesses.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-24-043392:notes:68]
[same as prior period, unchanged from 0001628280-24-032782:notes:68]

[0001628280-24-043392:notes:69]
[same as prior period, unchanged from 0001628280-24-032782:notes:69]

[0001628280-24-043392:notes:70]
[same as prior period, unchanged from 0001628280-24-032782:notes:70]

[0001628280-24-043392:notes:71]
[same as prior period, unchanged from 0001628280-24-032782:notes:71]

[0001628280-24-043392:notes:72]
[same as prior period, unchanged from 0001628280-24-032782:notes:72]

[0001628280-24-043392:notes:73]
[same as prior period, unchanged from 0001628280-24-032782:notes:73]

[0001628280-24-043392:notes:74]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through February 2026.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 17 months

[0001628280-24-043392:notes:75]
based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions) as of:

[0001628280-24-043392:notes:76]
|  | September 30, 2024 |  | December 31, 2023 |
| Unrealized losses (gains), net on unsettled contracts | $ | (5.5) |  |  | $ | 2.6 |  |
| Income tax (benefit) expense | 1.3 |  |  | (0.6) |  |
| Unrealized losses (gains), net included in AOCL, net of tax (1) | $ | (4.2) |  |  | $ | 2.0 |  |

[0001628280-24-043392:notes:77]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $4.0 million of derivative gain as of September 30, 2024 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-24-043392:notes:78]
[same as prior period, unchanged from 0001628280-24-032782:notes:77]

[0001628280-24-043392:notes:79]
[same as prior period, unchanged from 0001628280-24-032782:notes:78]

[0001628280-24-043392:notes:80]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Stock-based compensation expense | $ | 6.8 |  |  | $ | 9.7 |  |  | $ | 20.1 |  |  | $ | 23.5 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-24-043392:notes:81]
[same as prior period, unchanged from 0001628280-24-032782:notes:80]

[0001628280-24-043392:notes:82]
[same as prior period, unchanged from 0001628280-24-032782:notes:81]

[0001628280-24-043392:notes:83]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Service cost | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Interest cost | 2.2 |  |  | 2.2 |  |  | 6.5 |  |  | 6.7 |  |
| Expected return on plan assets | (1.9) |  |  | (2.4) |  |  | (5.7) |  |  | (7.1) |  |
| Recognized actuarial loss | 0.3 |  |  | — |  |  | 0.7 |  |  | 0.6 |  |
| Other | — |  |  | 0.3 |  |  | — |  |  | (0.1) |  |
| Settlements and curtailments | 0.1 |  |  | 0.3 |  |  | 0.4 |  |  | 0.4 |  |
| Net periodic benefit cost | $ | 1.1 |  |  | $ | 0.9 |  |  | $ | 3.1 |  |  | $ | 2.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-043392:notes:84]
[same as prior period, unchanged from 0001628280-24-032782:notes:83]

[0001628280-24-043392:notes:85]
As of September 30, 2024, we had approximately $4.5 million in total gross unrecognized tax benefits. If recognized, $4.5 million would be recorded through the Consolidated Statements of Operations.

[0001628280-24-043392:notes:86]
Our effective tax rate was 19.3% for the nine months ended September 30, 2024 compared to 21.0% for the nine months ended September 30, 2023. The decrease in rate is primarily due to a discrete adjustment in the third quarter of 2023 related to the 2023 European divestiture.

[0001628280-24-043392:notes:87]
[same as prior period, unchanged from 0001628280-24-032782:notes:86]


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-043392:notes:88]
10. Lines of Credit and Financing Arrangements:

[0001628280-24-043392:notes:89]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:

[0001628280-24-043392:notes:90]
|  | September 30, 2024 |  | December 31, 2023 |
| Commercial paper | $ | — |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 13.2 |  |  | $ | 12.1 |  |
| Senior unsecured notes | 300.0 |  |  | — |  |
| Debt issuance costs | (0.5) |  |  | — |  |
| Total current maturities of long-term debt | $ | 312.7 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 34.6 |  |  | $ | 32.7 |  |
| Credit agreement | — |  |  | 20.0 |  |
| Senior unsecured notes | 800.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (7.0) |  |  | (9.6) |  |
| Total long-term debt | $ | 827.6 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,140.3 |  |  | $ | 1,305.2 |  |

[0001628280-24-043392:notes:91]
Foreign Obligations

[0001628280-24-043392:notes:92]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2024 or December 31, 2023 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2024.

[0001628280-24-043392:notes:93]
Commercial Paper Program

[0001628280-24-043392:notes:94]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were no CP Notes currently outstanding under the Program as of September 30, 2024.

[0001628280-24-043392:notes:95]
Our weighted average borrowing rate on the Program was as follows as of:

[0001628280-24-043392:notes:96]
|  | September 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 5.66 | % |

[0001628280-24-043392:notes:97]
Credit Agreement

[0001628280-24-043392:notes:98]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of September 30, 2024. Subject to covenant limitations, $1,098.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-24-043392:notes:99]
Our weighted average borrowing rate on the facility was as follows as of:

[0001628280-24-043392:notes:100]
|  | September 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 6.67 | % |

[0001628280-24-043392:notes:101]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-24-043392:notes:102]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001628280-24-043392:notes:103]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-24-043392:notes:104]
• We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-24-043392:notes:105]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-24-043392:notes:106]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001628280-24-043392:notes:107]
We are currently in compliance with all covenant requirements.

[0001628280-24-043392:notes:108]
Senior Unsecured Notes

[0001628280-24-043392:notes:109]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-24-043392:notes:110]
[same as prior period, unchanged from 0001628280-24-032782:notes:109]

[0001628280-24-043392:notes:111]
[same as prior period, unchanged from 0001628280-24-032782:notes:110]

[0001628280-24-043392:notes:112]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |
| (Losses) Gains on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | (0.8) |  |  | $ | (0.8) |  |  | $ | (1.2) |  |  | $ | (1.2) |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax (expense) benefit |  | (0.2) |  |  | 0.2 |  |  | (0.3) |  |  | 0.3 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.6) |  |  | $ | (0.6) |  |  | $ | (0.9) |  |  | $ | (0.9) |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (0.3) |  |  | $ | — |  |  | $ | (0.7) |  |  | $ | (0.6) |  |  | Other expense (income), net |
| Pension settlements |  | (0.1) |  |  | (0.3) |  |  | (0.4) |  |  | (0.4) |  |  | Pension settlements |
| Income tax (expense) benefit |  | (0.1) |  |  | 0.1 |  |  | (0.3) |  |  | 0.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.3) |  |  | $ | (0.2) |  |  | $ | (0.8) |  |  | $ | (0.8) |  |  |  |
| Total reclassifications from AOCL |  | $ | (0.9) |  |  | $ | (0.8) |  |  | $ | (1.7) |  |  | $ | (1.7) |  |  |  |

[0001628280-24-043392:notes:113]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2024 (in millions):

[0001628280-24-043392:notes:114]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2023 |  | $ | (2.0) |  |  | $ | 0.6 |  |  | $ | (44.2) |  |  | $ | (11.3) |  |  | $ | (56.9) |  |
| Other comprehensive income (loss) before reclassifications |  | 5.3 |  |  | (0.2) |  |  | (1.2) |  |  | (19.4) |  |  | (15.5) |  |
| Amounts reclassified from AOCL |  | 0.9 |  |  | — |  |  | 0.8 |  |  | — |  |  | 1.7 |  |
| Net other comprehensive income (loss) |  | 6.2 |  |  | (0.2) |  |  | (0.4) |  |  | (19.4) |  |  | (13.8) |  |
| Balance as of September 30, 2024 |  | $ | 4.2 |  |  | $ | 0.4 |  |  | $ | (44.6) |  |  | $ | (30.7) |  |  | $ | (70.7) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-043392:notes:115]
[same as prior period, unchanged from 0001628280-24-032782:notes:114]

[0001628280-24-043392:notes:116]
[same as prior period, unchanged from 0001628280-24-032782:notes:115]

[0001628280-24-043392:notes:117]
The methodologies used to determine the fair value of our financial assets and liabilities as of September 30, 2024 were the same as those used as of December 31, 2023.

[0001628280-24-043392:notes:118]
[same as prior period, unchanged from 0001628280-24-032782:notes:117]

[0001628280-24-043392:notes:119]
[same as prior period, unchanged from 0001628280-24-032782:notes:118]

[0001628280-24-043392:notes:120]
[same as prior period, unchanged from 0001628280-24-032782:notes:119]

[0001628280-24-043392:notes:121]
[same as prior period, unchanged from 0001628280-24-032782:notes:120]

[0001628280-24-043392:notes:122]
[same as prior period, unchanged from 0001628280-24-032782:notes:121]

[0001628280-24-043392:notes:123]
|  | September 30, 2024 |  | December 31, 2023 |
| Senior unsecured notes | $ | 1,098.0 |  |  | $ | 1,079.3 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-24-043392:notes:124]
[same as prior period, unchanged from 0001628280-24-032782:notes:123]

[0001628280-24-043392:notes:125]
[same as prior period, unchanged from 0001628280-24-032782:notes:124]

[0001628280-24-043392:notes:126]
|  | December 31, 2023 |  | Adjustment |  | September 30, 2024 |
| Net tangible assets acquired | $ | 17.6 |  |  | $ | (1.7) |  |  | $ | 15.9 |  |
| Intangible assets acquired | 36.9 |  |  | 2.1 |  |  | 39.0 |  |
| Goodwill | 40.4 |  |  | (2.2) |  |  | 38.2 |  |
| Total investment | $ | 94.9 |  |  | $ | (1.8) |  |  | $ | 93.1 |  |
