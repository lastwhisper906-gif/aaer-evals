# LII note change history — 0001628280-24-032782 → 0001628280-24-043392


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-23):
[0001628280-24-043392:note_history:1]
|  | September 30, 2024 |  | December 31, 2023 |
| Accrued expenses | $ | 47.8 |  |  | $ | 45.4 |  |
| Other liabilities | 109.1 |  |  | 97.4 |  |
| Total warranty liability | $ | 156.9 |  |  | $ | 142.8 |  |
  (was, 2024-07-24, similarity 0.9664):
[0001628280-24-032782:note_history:1]
|  | June 30, 2024 |  | December 31, 2023 |
| Accrued expenses | $ | 46.3 |  |  | $ | 45.4 |  |
| Other liabilities | 106.5 |  |  | 97.4 |  |
| Total warranty liability | $ | 152.8 |  |  | $ | 142.8 |  |

- changed (2024-10-23):
[0001628280-24-043392:note_history:2]
The changes in product warranty liabilities for the nine months ended September 30, 2024 were as follows (in millions):
  (was, 2024-07-24, similarity 0.9279):
[0001628280-24-032782:note_history:2]
The changes in product warranty liabilities for the six months ended June 30, 2024 were as follows (in millions):

- changed (2024-10-23):
[0001628280-24-043392:note_history:3]
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Warranty claims paid | (32.4) |  |
| Changes resulting from issuance of new warranties | 46.5 |  |
| Changes in estimates associated with pre-existing liabilities | 0.2 |  |
| Changes in foreign currency translation rates and other | (0.2) |  |
| Total warranty liability as of September 30, 2024 | $ | 156.9 |  |
  (was, 2024-07-24, similarity 0.9755):
[0001628280-24-032782:note_history:3]
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Warranty claims paid | (18.0) |  |
| Changes resulting from issuance of new warranties | 28.5 |  |
| Changes in estimates associated with pre-existing liabilities | (0.2) |  |
| Changes in foreign currency translation rates and other | (0.3) |  |
| Total warranty liability as of June 30, 2024 | $ | 152.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-10-23):
[0001628280-24-043392:note_history:4]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2024, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2024 and 2023, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three and nine months ended September 30, 2024 and 2023, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2024 and 2023 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2023.

- removed (2024-10-23):
[0001628280-24-032782:note_history:5]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2024, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2024 and 2023, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three and six months ended June 30, 2024 and 2023, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2024 and 2023 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2023.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-23):
[0001628280-24-043392:note_history:6]
|  | September 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 5.66 | % |
  (was, 2024-07-24, similarity 0.9371):
[0001628280-24-032782:note_history:6]
|  | June 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 6.67 | % |

- changed (2024-10-23):
[0001628280-24-043392:note_history:7]
|  | September 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 6.67 | % |
  (was, 2024-07-24, similarity 0.9257):
[0001628280-24-032782:note_history:7]
|  | June 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-10-23):
[0001628280-24-043392:note_history:8]
|  | September 30, 2024 |  | December 31, 2023 |
| Commercial paper | $ | — |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 13.2 |  |  | $ | 12.1 |  |
| Senior unsecured notes | 300.0 |  |  | — |  |
| Debt issuance costs | (0.5) |  |  | — |  |
| Total current maturities of long-term debt | $ | 312.7 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 34.6 |  |  | $ | 32.7 |  |
| Credit agreement | — |  |  | 20.0 |  |
| Senior unsecured notes | 800.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (7.0) |  |  | (9.6) |  |
| Total long-term debt | $ | 827.6 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,140.3 |  |  | $ | 1,305.2 |  |

- changed (2024-10-23):
[0001628280-24-043392:note_history:9]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2024 or December 31, 2023 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2024.
  (was, 2024-07-24, similarity 0.9378):
[0001628280-24-032782:note_history:9]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2024 or December 31, 2023 and there were no borrowings or repayments on these facilities during the six months ended June 30, 2024.

- changed (2024-10-23):
[0001628280-24-043392:note_history:10]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were no CP Notes currently outstanding under the Program as of September 30, 2024.
  (was, 2024-07-24, similarity 0.971):
[0001628280-24-032782:note_history:10]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. CP Notes currently outstanding under the Program totaled $147.0 million as of June 30, 2024.

- changed (2024-10-23):
[0001628280-24-043392:note_history:11]
|  | September 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 5.66 | % |
  (was, 2024-07-24, similarity 0.9371):
[0001628280-24-032782:note_history:11]
|  | June 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 6.67 | % |

- changed (2024-10-23):
[0001628280-24-043392:note_history:12]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of September 30, 2024. Subject to covenant limitations, $1,098.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.
  (was, 2024-07-24, similarity 0.8865):
[0001628280-24-032782:note_history:12]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had $0 outstanding borrowings and $1.7 million committed to standby letters of credit as of June 30, 2024. Subject to covenant limitations, $951.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

- changed (2024-10-23):
[0001628280-24-043392:note_history:13]
|  | September 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | — | % |  | 6.67 | % |
  (was, 2024-07-24, similarity 0.9257):
[0001628280-24-032782:note_history:13]
|  | June 30, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |

- changed (2024-10-23):
[0001628280-24-043392:note_history:14]
We are currently in compliance with all covenant requirements.
  (was, 2024-07-24, similarity 0.7234):
[0001628280-24-032782:note_history:14]
As of June 30, 2024, we believe we were in compliance with all covenant requirements.

- changed (2024-10-23):
[0001628280-24-043392:note_history:15]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.
  (was, 2024-07-24, similarity 0.9696):
[0001628280-24-032782:note_history:15]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2024, we believe we were in compliance with all covenant requirements.

- removed (2024-10-23):
[0001628280-24-032782:note_history:16]
|  | June 30, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 147.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 14.0 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 14.0 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 35.0 |  |  | $ | 32.7 |  |
| Credit agreement | — |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.2) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,126.8 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,287.8 |  |  | $ | 1,305.2 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-10-23):
[0001628280-24-043392:note_history:17]
|  | September 30, 2024 |  | December 31, 2023 |
| Commercial paper | $ | — |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 13.2 |  |  | $ | 12.1 |  |
| Senior unsecured notes | 300.0 |  |  | — |  |
| Debt issuance costs | (0.5) |  |  | — |  |
| Total current maturities of long-term debt | $ | 312.7 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 34.6 |  |  | $ | 32.7 |  |
| Credit agreement | — |  |  | 20.0 |  |
| Senior unsecured notes | 800.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (7.0) |  |  | (9.6) |  |
| Total long-term debt | $ | 827.6 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,140.3 |  |  | $ | 1,305.2 |  |

- removed (2024-10-23):
[0001628280-24-032782:note_history:18]
|  | June 30, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 147.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 14.0 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 14.0 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 35.0 |  |  | $ | 32.7 |  |
| Credit agreement | — |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.2) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,126.8 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,287.8 |  |  | $ | 1,305.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-10-23):
[0001628280-24-043392:note_history:19]
|  | For the Three Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 971.1 |  |  | $ | 441.9 |  |  | $ | — |  |  | $ | 1,413.0 |  |
| Canada | 61.7 |  |  | 23.4 |  |  | — |  |  | 85.1 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,032.8 |  |  | $ | 465.3 |  |  | $ | — |  |  | $ | 1,498.1 |  |

- changed (2024-10-23):
[0001628280-24-043392:note_history:20]
|  | For the Three Months Ended September 30, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 842.1 |  |  | $ | 376.8 |  |  | $ | — |  |  | $ | 1,218.9 |  |
| Canada | 54.2 |  |  | 28.7 |  |  | — |  |  | 82.9 |  |
| Other international | — |  |  | — |  |  | 64.5 |  |  | 64.5 |  |
| Total | $ | 896.3 |  |  | $ | 405.5 |  |  | $ | 64.5 |  |  | $ | 1,366.3 |  |
  (was, 2024-07-24, similarity 0.7322):
[0001628280-24-032782:note_history:20]
|  | For the Three Months Ended June 30, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 868.5 |  |  | $ | 382.2 |  |  | $ | — |  |  | $ | 1,250.7 |  |
| Canada | 67.7 |  |  | 25.3 |  |  | — |  |  | 93.0 |  |
| Other international | — |  |  | — |  |  | 67.7 |  |  | 67.7 |  |
| Total | $ | 936.2 |  |  | $ | 407.5 |  |  | $ | 67.7 |  |  | $ | 1,411.4 |  |

- added (2024-10-23):
[0001628280-24-043392:note_history:21]
|  | For the Nine Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,520.7 |  |  | $ | 1,244.2 |  |  | $ | — |  |  | $ | 3,764.9 |  |
| Canada | 169.0 |  |  | 62.4 |  |  | — |  |  | 231.4 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 2,689.7 |  |  | $ | 1,306.6 |  |  | $ | — |  |  | $ | 3,996.3 |  |

- changed (2024-10-23):
[0001628280-24-043392:note_history:22]
|  | For the Nine Months Ended September 30, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,350.0 |  |  | $ | 1,053.5 |  |  | $ | — |  |  | $ | 3,403.5 |  |
| Canada | 163.6 |  |  | 68.0 |  |  | — |  |  | 231.6 |  |
| Other international | — |  |  | — |  |  | 192.0 |  |  | 192.0 |  |
| Total | $ | 2,513.6 |  |  | $ | 1,121.5 |  |  | $ | 192.0 |  |  | $ | 3,827.1 |  |
  (was, 2024-07-24, similarity 0.6857):
[0001628280-24-032782:note_history:22]
|  | For the Six Months Ended June 30, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,507.8 |  |  | $ | 676.7 |  |  | $ | — |  |  | $ | 2,184.5 |  |
| Canada | 109.4 |  |  | 39.4 |  |  | — |  |  | 148.8 |  |
| Other international | — |  |  | — |  |  | 127.4 |  |  | 127.4 |  |
| Total | $ | 1,617.2 |  |  | $ | 716.1 |  |  | $ | 127.4 |  |  | $ | 2,460.7 |  |

- changed (2024-10-23):
[0001628280-24-043392:note_history:23]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2024 and 2023, direct sales represented 73% and 77% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2024 and 2023, direct sales represented 74% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2024-07-24, similarity 0.6414):
[0001628280-24-032782:note_history:23]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent

- changed (2024-10-23):
[0001628280-24-043392:note_history:24]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2024 and 2023, equipment sales represented 80% and 88% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2024 and 2023, equipment sales represented 81% and 87% of revenues and the remainder of our revenue was generated from our services business.
  (was, 2024-07-24, similarity 0.9814):
[0001628280-24-032782:note_history:24]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended June 30, 2024 and 2023, equipment sales represented 82% and 87% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2024 and 2023, equipment sales represented 81% and 86% of revenues and the remainder of our revenue was generated from our services business.

- added (2024-10-23):
[0001628280-24-043392:note_history:25]
|  | September 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Contract assets | $ | 2.0 |  |  | $ | 2.2 |  |  |  |  |  |
| Contract liabilities - current | (4.2) |  |  | (4.7) |  |  |  |  |  |
| Contract liabilities - noncurrent | (8.1) |  |  | (7.5) |  |  |  |  |  |
| Total | $ | (10.3) |  |  | $ | (10.0) |  |  |  |  |  |

- changed (2024-10-23):
[0001628280-24-043392:note_history:26]
For the three months ended September 30, 2024 and 2023, we recognized revenue of $0.7 million and $2.8 million and for the nine months ended September 30, 2024 and 2023, we recognized revenue of $6.8 million and $7.0 million related to our contract liabilities at January 1, 2024 and 2023, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2024 and 2023.
  (was, 2024-07-24, similarity 0.9149):
[0001628280-24-032782:note_history:26]
For the three months ended June 30, 2024 and 2023, we recognized revenue of $0.4 million and $1.2 million and for the six months ended June 30, 2024 and 2023, we recognized revenue of $6.1 million and $4.2 million related to our contract liabilities at January 1, 2024 and 2023, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2024 and 2023.

- removed (2024-10-23):
[0001628280-24-032782:note_history:27]
|  | For the Three Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 923.5 |  |  | $ | 445.0 |  |  | $ | — |  |  | $ | 1,368.5 |  |
| Canada | 58.8 |  |  | 23.8 |  |  | — |  |  | 82.6 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 982.3 |  |  | $ | 468.8 |  |  | $ | — |  |  | $ | 1,451.1 |  |

- removed (2024-10-23):
[0001628280-24-032782:note_history:28]
|  | For the Six Months Ended June 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,549.6 |  |  | $ | 802.3 |  |  | $ | — |  |  | $ | 2,351.9 |  |
| Canada | 107.3 |  |  | 39.0 |  |  | — |  |  | 146.3 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,656.9 |  |  | $ | 841.3 |  |  | $ | — |  |  | $ | 2,498.2 |  |

- removed (2024-10-23):
[0001628280-24-032782:note_history:29]
installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2024 and 2023, direct sales represented 76% and 76% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2024 and 2023, direct sales represented 75% and 73% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- removed (2024-10-23):
[0001628280-24-032782:note_history:30]
|  | June 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Contract assets | $ | 2.0 |  |  | $ | 2.2 |  |  |  |  |  |
| Contract liabilities - current | (5.0) |  |  | (4.7) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.8) |  |  | (7.5) |  |  |  |  |  |
| Total | $ | (10.8) |  |  | $ | (10.0) |  |  |  |  |  |
