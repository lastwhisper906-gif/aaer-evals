# LII MD&A — 0001628280-24-043392


## mdna

[0001628280-24-043392:mdna:1]
[same as prior period, unchanged from 0001628280-24-032782:mdna:1]

[0001628280-24-043392:mdna:2]
[same as prior period, unchanged from 0001628280-24-032782:mdna:2]

[0001628280-24-043392:mdna:3]
[same as prior period, unchanged from 0001628280-24-032782:mdna:3]

[0001628280-24-043392:mdna:4]
[same as prior period, unchanged from 0001628280-24-032782:mdna:4]

[0001628280-24-043392:mdna:5]
[same as prior period, unchanged from 0001628280-24-032782:mdna:5]

[0001628280-24-043392:mdna:6]
[same as prior period, unchanged from 0001628280-24-032782:mdna:6]

[0001628280-24-043392:mdna:7]
[same as prior period, unchanged from 0001628280-24-032782:mdna:7]

[0001628280-24-043392:mdna:8]
Results for the third quarter of 2024 were driven by overall year-over-year sales and profit increases. Net sales increased 15% and segment profit increased $45 million for our Home Comfort Solutions segment. Net sales increased 15% and segment profit increased $9 million for our Building Climate Solutions segment. Net sales decreased $65 million and segment loss increased $6 million for our Corporate and Other segment.  Our European businesses were sold in the fourth quarter of 2023 and generated $65 million in net sales with segment profit of $4 million in the third quarter of 2023.

[0001628280-24-043392:mdna:9]
19

[0001628280-24-043392:mdna:10]
[same as prior period, unchanged from 0001628280-24-032782:mdna:9]

[0001628280-24-043392:mdna:11]
•Net sales of $1,498 million in the third quarter of 2024 reflected a 10% increase as compared to the same period in 2023.

[0001628280-24-043392:mdna:12]
•Operating income in the third quarter of 2024 increased $117 million to $303 million primarily driven by favorable price and mix and higher sales volumes.

[0001628280-24-043392:mdna:13]
•Net income for the third quarter of 2024 was $239 million.

[0001628280-24-043392:mdna:14]
•Diluted earnings per share was $6.68 per share in the third quarter of 2024 as compared to $3.65 per share in the same period in 2023.

[0001628280-24-043392:mdna:15]
•For the nine months ended September 30, 2024, we returned $119 million to shareholders through dividend payments.

[0001628280-24-043392:mdna:16]
Three Months Ended September 30, 2024 Compared to Three Months Ended September 30, 2023 - Consolidated Results

[0001628280-24-043392:mdna:17]
[same as prior period, unchanged from 0001628280-24-032782:mdna:16]

[0001628280-24-043392:mdna:18]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 1,498.1 |  |  | $ | 1,366.3 |  |  | 9.6 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,009.7 |  |  | 937.8 |  |  | (7.7) |  |  | 67.4 |  |  | 68.6 |  |
| Gross profit | 488.4 |  |  | 428.5 |  |  | 14.0 |  |  | 32.6 |  |  | 31.4 |  |
| Selling, general and administrative expenses | 184.4 |  |  | 178.9 |  |  | (3.1) |  |  | 12.3 |  |  | 13.1 |  |
| Losses and other expenses, net | 3.1 |  |  | 3.5 |  |  | 11.4 |  |  | 0.2 |  |  | 0.3 |  |
| Restructuring charges | — |  |  | 0.3 |  |  | 100.0 |  |  | — |  |  | — |  |
| Impairment on assets held for sale | — |  |  | 63.2 |  |  | 100.0 |  |  | — |  |  | 4.6 |  |
| Income from equity method investments | (2.4) |  |  | (4.2) |  |  | (42.9) |  |  | (0.2) |  |  | (0.3) |  |
| Operating income | $ | 303.3 |  |  | $ | 186.8 |  |  | 62.4 | % |  | 20.2 | % |  | 13.7 | % |

[0001628280-24-043392:mdna:19]
[same as prior period, unchanged from 0001628280-24-032782:mdna:18]

[0001628280-24-043392:mdna:20]
Net sales for the third quarter of 2024 increased 10% as compared to the same period in 2023.  This was primarily due to higher sales volumes of 9%, favorable price and mix of 4%, and an increase in sales volumes of 2% from our AES acquisition, which were partially offset by a 5% reduction in sales due to the fourth quarter 2023 sale of our European businesses.

[0001628280-24-043392:mdna:21]
[same as prior period, unchanged from 0001628280-24-032782:mdna:20]

[0001628280-24-043392:mdna:22]
Gross profit margins in the third quarter of 2024 increased 120 basis points ("bps") to 32.6% as compared to 31.4% in the same period in 2023. Gross margins increased 250 bps from favorable price and mix, which was partially offset by 70 bps from higher material and product costs, including LIFO, 40 bps from higher freight and distribution costs, and 20 bps from  miscellaneous other items.

[0001628280-24-043392:mdna:23]
[same as prior period, unchanged from 0001628280-24-032782:mdna:22]

[0001628280-24-043392:mdna:24]
Selling, general and administrative expenses ("SG&A") increased $6 million to $184 million in the third quarter of 2024 as compared to $179 million in the same period in 2023 primarily due to higher employee related costs including increased incentive compensation, which was partially offset by a $14 million reduction in SG&A expenses from our 2023 divestiture of our European businesses. SG&A decreased 80 bps to 12.3%.

[0001628280-24-043392:mdna:25]
[same as prior period, unchanged from 0001628280-24-032782:mdna:24]

[0001628280-24-043392:mdna:26]
Losses (gains) and other expenses, net for the third quarter of 2024 and 2023 included the following (in millions):

[0001628280-24-043392:mdna:27]
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |  |  |
| Foreign currency exchange losses (gains) | 1.6 |  |  | (1.2) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.7) |  |  | (0.2) |  |  |  |  |  |  |  |
| Other operating income | (0.5) |  |  | (0.1) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | — |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 2.6 |  |  | 3.9 |  |  |  |  |  |  |  |
| Other items, net | — |  |  | 1.1 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.1 |  |  | $ | 3.5 |  |  |  |  |  |  |  |

[0001628280-24-043392:mdna:28]
[same as prior period, unchanged from 0001628280-24-032782:mdna:27]

[0001628280-24-043392:mdna:29]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers, and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation. Accordingly, these joint ventures are accounted for under the equity method and their financial position and results of operations are not consolidated. We recognized income from equity method investments of $2 million in the third quarter of 2024 and $4 million in the third quarter of 2023.

[0001628280-24-043392:mdna:30]
[same as prior period, unchanged from 0001628280-24-032782:mdna:29]

[0001628280-24-043392:mdna:31]
Interest expense, net decreased to $9 million in the third quarter of 2024 from $11 million in the same period in 2023 due to lower borrowings.

[0001628280-24-043392:mdna:32]
[same as prior period, unchanged from 0001628280-24-032782:mdna:31]

[0001628280-24-043392:mdna:33]
Our effective tax rate was 18.7% for the third quarter of 2024 as compared to 25.6% in the same period in 2023.  The decrease in rate is primarily due to a discrete adjustment in the third quarter of 2023 related to the 2023 European divestiture.

[0001628280-24-043392:mdna:34]
Third Quarter of 2024 Compared to Third Quarter of 2023 - Results by Segment

[0001628280-24-043392:mdna:35]
[same as prior period, unchanged from 0001628280-24-032782:mdna:34]

[0001628280-24-043392:mdna:36]
The following table presents our Home Comfort Solutions segment's net sales and profit for the third quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-043392:mdna:37]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 1,032.8 |  |  | $ | 896.3 |  |  | $ | 136.5 |  |  | 15 | % |
| Profit | $ | 226.5 |  |  | $ | 181.4 |  |  | $ | 45.1 |  |  | 25 | % |
| % of net sales | 21.9 | % |  | 20.2 | % |  |  |  |  |

[0001628280-24-043392:mdna:38]
Net sales increased 15% in the third quarter of 2024 as compared to the same period in 2023 primarily due to higher sales volumes of 11% and favorable price and mix of 4%.

[0001628280-24-043392:mdna:39]
Segment profit in the third quarter of 2024 increased by $45 million as compared to the same period in 2023, primarily due to $35 million from higher sales volumes, and $33 million from favorable price and mix, which were partially offset by $8 million from higher SG&A costs, $7 million in higher costs primarily driven by the upcoming regulatory transition and rising commodity prices, and $8 million from miscellaneous other items.

[0001628280-24-043392:mdna:40]
[same as prior period, unchanged from 0001628280-24-032782:mdna:39]

[0001628280-24-043392:mdna:41]
The following table presents our Building Climate Solutions segment's net sales and profit for the third quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-043392:mdna:42]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 465.3 |  |  | $ | 405.5 |  |  | $ | 59.8 |  |  | 15 | % |
| Profit | $ | 105.9 |  |  | $ | 97.3 |  |  | $ | 8.6 |  |  | 9 | % |
| % of net sales | 22.8 | % |  | 24.0 | % |  |  |  |  |

[0001628280-24-043392:mdna:43]
Net sales increased 15% in the third quarter of 2024 as compared to the same period in 2023 primarily due to higher sales volumes of 7%, favorable price and mix of 2%, and a 6% increase in sales volumes from our AES acquisition.

[0001628280-24-043392:mdna:44]
Segment profit in the third quarter of 2024 increased $9 million as compared to the same period in 2023 primarily due to $10 million from favorable price and mix, $8 million from higher sales volumes, $4 million from our acquisition of AES, and $3 million from miscellaneous other items, which were partially offset by $10 million in higher factory inefficiencies, including costs related to the ramp up of our new factory in Mexico, and $6 million in increased SG&A expenses.

[0001628280-24-043392:mdna:45]
[same as prior period, unchanged from 0001628280-24-032782:mdna:44]

[0001628280-24-043392:mdna:46]
The following table presents our Corporate and Other segment's net sales and loss for the third quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-043392:mdna:47]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | 64.5 |  |  | $ | (64.5) |  |  | (100) | % |
| Loss | $ | (29.1) |  |  | $ | (23.4) |  |  | $ | (5.7) |  |  | (24) | % |

[0001628280-24-043392:mdna:48]
Net sales decreased $65 million and segment loss increased $6 million in the third quarter of 2024 as compared to the same period in 2023.  Our European businesses, which were sold in 2023, generated $65 million in net sales and $4 million in segment profit in the third quarter of 2023.  Excluding our European businesses, Corporate and Other costs increased $2 million in the third quarter of 2024 as compared to the same period in 2023 primarily due to higher employee related costs.

[0001628280-24-043392:mdna:49]
Year-to-Date through September 30, 2024 Compared to Year-to-Date through September 30, 2023 - Consolidated Results

[0001628280-24-043392:mdna:50]
[same as prior period, unchanged from 0001628280-24-032782:mdna:49]

[0001628280-24-043392:mdna:51]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 3,996.3 |  |  | $ | 3,827.1 |  |  | 4.4 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 2,679.7 |  |  | 2,634.1 |  |  | (1.7) |  |  | 67.1 |  |  | 68.8 |  |
| Gross profit | 1,316.6 |  |  | 1,193.0 |  |  | 10.4 |  |  | 32.9 |  |  | 31.2 |  |
| Selling, general and administrative expenses | 523.6 |  |  | 527.6 |  |  | 0.8 |  |  | 13.1 |  |  | 13.8 |  |
| Losses (gains) and other expenses, net | 10.5 |  |  | 5.2 |  |  | (101.9) |  |  | 0.3 |  |  | 0.1 |  |
| Restructuring charges | — |  |  | 0.2 |  |  | 100.0 |  |  | — |  |  | — |  |
| Impairment on assets held for sale | — |  |  | 63.2 |  |  | 100.0 |  |  | — |  |  | 1.7 |  |
| Gain on sale from previous dispositions | (1.6) |  |  | — |  |  | (100.0) |  |  | — |  |  | — |  |
| Income from equity method investments | (6.1) |  |  | (8.0) |  |  | (23.8) |  |  | (0.2) |  |  | (0.2) |  |
| Operating income | $ | 790.2 |  |  | $ | 604.8 |  |  | 30.7 | % |  | 19.8 | % |  | 15.8 | % |

[0001628280-24-043392:mdna:52]
[same as prior period, unchanged from 0001628280-24-032782:mdna:51]

[0001628280-24-043392:mdna:53]
Net sales increased 4% for the nine months ended September 30, 2024 as compared to the same period in 2023. This was primarily due to higher sales volumes of 5%, favorable price and mix of 3%, and an increase in sales volumes of 1% from our AES acquisition, which were partially offset by a 5% reduction in sales due to the fourth quarter 2023 sale of our European businesses.

[0001628280-24-043392:mdna:54]
[same as prior period, unchanged from 0001628280-24-032782:mdna:53]

[0001628280-24-043392:mdna:55]
Gross profit margins for the nine months ended September 30, 2024 increased 170 bps to 32.9% as compared to 31.2% in the same period in 2023. Gross margins increased 270 bps from higher price and favorable mix, which was partially offset by 50 bps from higher material and product costs, including LIFO, and 50 bps from higher freight and distribution costs.

[0001628280-24-043392:mdna:56]
[same as prior period, unchanged from 0001628280-24-032782:mdna:55]

[0001628280-24-043392:mdna:57]
SG&A decreased $4 million to $524 million for the nine months ended September 30, 2024 as compared to $528 million in the same period in 2023 primarily due to a $45 million reduction in SG&A expenses from our 2023 divestiture of our European businesses, which was partially offset by higher employee-related costs including increased incentive compensation. As a percentage of net sales, SG&A decreased 70 bps to 13.1% from 13.8%.

[0001628280-24-043392:mdna:58]
[same as prior period, unchanged from 0001628280-24-032782:mdna:57]

[0001628280-24-043392:mdna:59]
Losses (gains) and other expenses, net for the nine months ended September 30, 2024 and 2023 included the following (in millions):

[0001628280-24-043392:mdna:60]
|  | For the Nine Months Ended September 30, |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |  |  |
| Realized losses on settled future contracts | $ | — |  |  | $ | 0.1 |  |  |  |  |  |  |  |
| Foreign currency exchange losses (gains) | 4.4 |  |  | (4.2) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (1.7) |  |  | (1.4) |  |  |  |  |  |  |  |
| Other operating loss (income) | 0.4 |  |  | (1.4) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | (0.1) |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 7.3 |  |  | 11.1 |  |  |  |  |  |  |  |
| Other items, net | — |  |  | 1.1 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 10.5 |  |  | $ | 5.2 |  |  |  |  |  |  |  |

[0001628280-24-043392:mdna:61]
[same as prior period, unchanged from 0001628280-24-032782:mdna:60]

[0001628280-24-043392:mdna:62]
Income from equity method investments decreased slightly to $6 million for the nine months ended September 30, 2024 as compared to $8 million in the same period in 2023.

[0001628280-24-043392:mdna:63]
[same as prior period, unchanged from 0001628280-24-032782:mdna:62]

[0001628280-24-043392:mdna:64]
Interest expense, net decreased $7 million for the nine months ended September 30, 2024 to $33 million as compared to $40 million in the same period in 2023 primarily due to lower borrowings.

[0001628280-24-043392:mdna:65]
[same as prior period, unchanged from 0001628280-24-032782:mdna:64]

[0001628280-24-043392:mdna:66]
Our effective tax rate was 19.3% for the nine months ended September 30, 2024 as compared to 21.0% in the same period in 2023. The decrease in rate was primarily due to a discrete adjustment in the third quarter of 2023 related to the 2023 European divestiture.

[0001628280-24-043392:mdna:67]
Year-to-Date through September 30, 2024 Compared to Year-to-Date through September 30, 2023 - Results by Segment

[0001628280-24-043392:mdna:68]
[same as prior period, unchanged from 0001628280-24-032782:mdna:67]

[0001628280-24-043392:mdna:69]
The following table presents our Home Comfort Solutions segment's net sales and profit for the nine months ended September 30, 2024 and 2023 (dollars in millions):

[0001628280-24-043392:mdna:70]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 2,689.7 |  |  | $ | 2,513.6 |  |  | $ | 176.1 |  |  | 7 | % |
| Profit | $ | 567.1 |  |  | $ | 495.2 |  |  | $ | 71.9 |  |  | 15 | % |
| % of net sales | 21.1 | % |  | 19.7 | % |  |  |  |  |

[0001628280-24-043392:mdna:71]
Net sales increased 7% for the nine months ended September 30, 2024 as compared to the same period in 2023. This was primarily due to higher sales volumes of 4% and favorable price and mix of 3%.

[0001628280-24-043392:mdna:72]
Segment profit for the first nine months of 2024 increased $72 million as compared to the same period in 2023 primarily due to $95 million from favorable price and mix, and $33 million from higher sales volumes, which were partially offset by $23 million from higher SG&A costs, $19 million from higher freight and distribution costs, $5 million in higher costs primarily driven by the upcoming regulatory transition and rising commodity prices, and $9 million from miscellaneous other items.

[0001628280-24-043392:mdna:73]
[same as prior period, unchanged from 0001628280-24-032782:mdna:72]

[0001628280-24-043392:mdna:74]
The following table presents our Building Climate Solutions segment's net sales and profit for the nine months ended September 30, 2024 and 2023 (dollars in millions):

[0001628280-24-043392:mdna:75]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 1,306.6 |  |  | $ | 1,121.5 |  |  | $ | 185.1 |  |  | 17 | % |
| Profit | $ | 298.1 |  |  | $ | 250.3 |  |  | $ | 47.8 |  |  | 19 | % |
| % of net sales | 22.8 | % |  | 22.3 | % |  |  |  |  |

[0001628280-24-043392:mdna:76]
Net sales increased 17% for the nine months ended September 30, 2024 as compared to the same period in 2023. This was primarily due to higher sales volumes of 8%, favorable price and mix of 3%, and a 6% increase in sales volumes from our AES acquisition.

[0001628280-24-043392:mdna:77]
Segment profit for the first nine months of 2024 increased $48 million as compared to the same period in 2023 primarily due to $32 million from higher price and mix, $28 million from higher sales volumes, $13 million from our acquisition of AES, and $2 million from miscellaneous other items, which were partially offset by $17 million from higher factory inefficiencies, which includes costs related to the ramp up of our new facility in Mexico, and $10 million from higher SG&A costs.

[0001628280-24-043392:mdna:78]
[same as prior period, unchanged from 0001628280-24-032782:mdna:77]

[0001628280-24-043392:mdna:79]
The following table presents our Corporate and Other segment's net sales and loss for the nine months ended September 30, 2024 and 2023 (dollars in millions):

[0001628280-24-043392:mdna:80]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | 192.0 |  |  | $ | (192.0) |  |  | (100) | % |
| Loss | $ | (76.6) |  |  | $ | (65.2) |  |  | $ | (11.4) |  |  | (17) | % |

[0001628280-24-043392:mdna:81]
Net sales decreased $192 million and segment loss increased $11 million during the nine months ended September 30, 2024 as compared to the same period in 2023.  Our European businesses, which were sold in 2023, generated net sales of $192 million and a profit of $6 million in the nine months ended September 30, 2023.  Excluding our European businesses, Corporate and Other costs increased $5 million in the first nine months of 2024 as compared to the same period in 2023 primarily due to higher incentive compensation and other employee costs and wage inflation.

[0001628280-24-043392:mdna:82]
[same as prior period, unchanged from 0001628280-24-032782:mdna:82]

[0001628280-24-043392:mdna:83]
[same as prior period, unchanged from 0001628280-24-032782:mdna:83]

[0001628280-24-043392:mdna:84]
[same as prior period, unchanged from 0001628280-24-032782:mdna:84]

[0001628280-24-043392:mdna:85]
The following table summarizes our cash flow activity for the nine months ended September 30, 2024 and 2023 (in millions):

[0001628280-24-043392:mdna:86]
|  | For the Nine Months Ended September 30, |
|  | 2024 |  | 2023 |
| Net cash provided by operating activities | $ | 613.3 |  |  | $ | 429.9 |  |
| Net cash used in investing activities | (108.1) |  |  | (124.5) |  |
| Net cash used in financing activities | (327.4) |  |  | (215.6) |  |

[0001628280-24-043392:mdna:87]
25

[0001628280-24-043392:mdna:88]
Net Cash Provided By Operating Activities - The change in net cash provided by operating activities for the nine months ended September 30, 2024 compared to the net cash provided by operating activities for the same period in 2023 primarily reflects changes in working capital and an increase in net income.

[0001628280-24-043392:mdna:89]
Net Cash Used In Investing Activities - Capital expenditures were $103 million for the nine months ended September 30, 2024 compared to $125 million in the same period of 2023.  Capital expenditures in 2024 were related to our Commercial factory in Mexico, the general expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-24-043392:mdna:90]
Net Cash Used In Financing Activities - Net cash used in financing activities for the nine months ended September 30, 2024 increased to $327 million as compared to $216 million in the same period of 2023.  The change was primarily due to changes in net borrowings and repayments of long-term debt and repurchase of common stock through our share repurchase program.  We returned $119 million to shareholders through dividend payments for the nine months ended September 30, 2024 and $153 million in the same period of 2023.

[0001628280-24-043392:mdna:91]
[same as prior period, unchanged from 0001628280-24-032782:mdna:90]

[0001628280-24-043392:mdna:92]
The following table details our lines of credit and financing arrangements as of September 30, 2024 (in millions):

[0001628280-24-043392:mdna:93]
|  | Outstanding Borrowings |
| Commercial paper: | $ | — |  |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 13.2 |  |
| Senior unsecured notes | 300.0 |  |
| Debt issuance costs | (0.5) |  |
| Total current maturities of long-term debt | $ | 312.7 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 34.6 |  |
| Credit agreement | — |  |
| Senior unsecured notes | 800.0 |  |
| Debt issuance costs | (7.0) |  |
| Total long-term debt | $ | 827.6 |  |
| Total debt | $ | 1,140.3 |  |

[0001628280-24-043392:mdna:94]
[same as prior period, unchanged from 0001628280-24-032782:mdna:93]

[0001628280-24-043392:mdna:95]
On October 25, 2023, we established a commercial paper program, as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There are no CP Notes currently outstanding under the Program as of September 30, 2024.

[0001628280-24-043392:mdna:96]
[same as prior period, unchanged from 0001628280-24-032782:mdna:95]

[0001628280-24-043392:mdna:97]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of September 30, 2024. Subject to covenant

[0001628280-24-043392:mdna:98]
limitations, $1,098.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-24-043392:mdna:99]
[same as prior period, unchanged from 0001628280-24-032782:mdna:97]

[0001628280-24-043392:mdna:100]
[same as prior period, unchanged from 0001628280-24-032782:mdna:98]

[0001628280-24-043392:mdna:101]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2024, we believe we were in compliance with all covenant requirements.

[0001628280-24-043392:mdna:102]
[same as prior period, unchanged from 0001628280-24-032782:mdna:100]

[0001628280-24-043392:mdna:103]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 60% as of September 30, 2024 from 82% as of December 31, 2023.

[0001628280-24-043392:mdna:104]
As of September 30, 2024, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-24-043392:mdna:105]
[same as prior period, unchanged from 0001628280-24-032782:mdna:103]

[0001628280-24-043392:mdna:106]
We believe our cash and cash equivalents of $243.1 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends, and other needs in the foreseeable future.  Included in our cash and cash equivalents of $243.1 million as of September 30, 2024 was $25 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-24-043392:mdna:107]
[same as prior period, unchanged from 0001628280-24-032782:mdna:107]

[0001628280-24-043392:mdna:108]
[same as prior period, unchanged from 0001628280-24-032782:mdna:108]

[0001628280-24-043392:mdna:109]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of September 30, 2024 and December 31, 2023 and for the three and nine months ended September 30, 2024 (in millions):

[0001628280-24-043392:mdna:110]
|  | September 30, 2024 |  | December 31, 2023 |
| Current assets | $ | 1,646.7 |  |  | $ | 1,291.0 |  |
| Non-current assets | 6,734.9 |  |  | 5,737.1 |  |
| Current liabilities | 1,082.7 |  |  | 843.3 |  |
| Non-current liabilities | 1,216.8 |  |  | 1,477.3 |  |
| Amounts due to non-guarantor subsidiaries | (581.7) |  |  | (472.3) |  |
|  | For the Three Months Ended September 30, 2024 |  | For the Nine Months Ended September 30, 2024 |
| Net Sales | $ | 1,470.4 |  |  | $ | 3,936.3 |  |
| Gross Profit | 403.4 |  |  | 1,065.2 |  |
| Net Income | 521.1 |  |  | 1,366.9 |  |

[0001628280-24-043392:mdna:111]
[same as prior period, unchanged from 0001628280-24-032782:mdna:111]

[0001628280-24-043392:mdna:112]
[same as prior period, unchanged from 0001628280-24-032782:mdna:112]

[0001628280-24-043392:mdna:113]
Commitments, Contingencies, and Guarantees

[0001628280-24-043392:mdna:114]
For information regarding our commitments, contingencies, and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-24-043392:mdna:115]
[same as prior period, unchanged from 0001628280-24-032782:mdna:115]

[0001628280-24-043392:mdna:116]
[same as prior period, unchanged from 0001628280-24-032782:mdna:116]
