# LII notes — 0001069202-26-000054


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-26-000054:notes:1]
[same as prior period, unchanged from 0001069202-25-000048:notes:1]

[0001069202-26-000054:notes:2]
[same as prior period, unchanged from 0001069202-25-000048:notes:2]

[0001069202-26-000054:notes:3]
[same as prior period, unchanged from 0001069202-25-000048:notes:3]

[0001069202-26-000054:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2026 and the accompanying unaudited Consolidated Statements of Operations, Comprehensive Income, Stockholders' Equity, and Cash Flows for the three months ended March 31, 2026 and 2025 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2025.

[0001069202-26-000054:notes:5]
The unaudited consolidated financial statements for all comparable prior periods presented have been retrospectively adjusted to reflect the prior-year change in method of accounting for certain inventories from last-in-first-out ("LIFO") to first-in, first-out ("FIFO").

[0001069202-26-000054:notes:6]
[same as prior period, unchanged from 0001069202-25-000048:notes:5]

[0001069202-26-000054:notes:7]
[same as prior period, unchanged from 0001069202-25-000048:notes:6]

[0001069202-26-000054:notes:8]
[same as prior period, unchanged from 0001069202-25-000048:notes:7]

[0001069202-26-000054:notes:9]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-26-000054:notes:10]
[same as prior period, unchanged from 0001069202-25-000048:notes:9]

[0001069202-26-000054:notes:11]
[same as prior period, unchanged from 0001069202-25-000048:notes:10]

[0001069202-26-000054:notes:12]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Home Comfort Solutions |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential Parts and Supplies;Residential New Construction |  | United StatesCanada |
| Building Climate Solutions |  | Commercial heating, air conditioning and refrigeration systems. Products include rooftop packaged units, variable refrigerant flow systems, heat pumps, air cooled condensing units, air handlers, unit coolers, and process chillers. Services include installation, energy monitoring, service and maintenance, and HVAC recycling. |  | Light Commercial;Commercial Parts and Supplies;Food Preservation |  | United StatesCanada |

[0001069202-26-000054:notes:13]
[same as prior period, unchanged from 0001069202-25-000048:notes:12]

[0001069202-26-000054:notes:14]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results. There were no significant intercompany eliminations for the periods presented.

[0001069202-26-000054:notes:15]
The chief operating decision maker uses segment profit or loss from operations, excluding certain items, to allocate resources (including employees, financial, or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances in segment profit or loss on a monthly basis when evaluating segment performance and making decisions about allocating resources to the segments.

[0001069202-26-000054:notes:16]
[same as prior period, unchanged from 0001069202-25-000048:notes:15]

[0001069202-26-000054:notes:17]
[same as prior period, unchanged from 0001069202-25-000048:notes:16]

[0001069202-26-000054:notes:18]
|  | Home Comfort Solutions |  | Business Climate Solutions |  |  |  | Total |
| Three months ended March 31, 2026 |  |  |  |  |  |  |  |
| Net sales(1) | $ | 650.0 |  |  | $ | 485.1 |  |  |  |  | $ | 1,135.1 |  |
| Cost of goods sold | 467.8 |  |  | 316.2 |  |  |  |  | 784.0 |  |
| Selling, general and administrative | 97.2 |  |  | 74.0 |  |  |  |  | 171.2 |  |
| Other income(2) | (1.5) |  |  | (0.7) |  |  |  |  | (2.2) |  |
| Segment profit(3) | $ | 86.5 |  |  | $ | 95.6 |  |  |  |  | $ | 182.1 |  |
| Three months ended March 31, 2025 |  |  |  |  |  |  |  |
| Net sales(1) | $ | 721.4 |  |  | $ | 351.2 |  |  |  |  | $ | 1,072.6 |  |
| Cost of goods sold | 500.1 |  |  | 231.8 |  |  |  |  | 731.9 |  |
| Selling, general and administrative | 98.4 |  |  | 60.4 |  |  |  |  | 158.8 |  |
| Other (income) expense(2) | (1.0) |  |  | 0.2 |  |  |  |  | (0.8) |  |
| Segment profit(3) | $ | 123.9 |  |  | $ | 58.8 |  |  |  |  | $ | 182.7 |  |

[0001069202-26-000054:notes:19]
[same as prior period, unchanged from 0001069202-25-000048:notes:19]

[0001069202-26-000054:notes:20]
[same as prior period, unchanged from 0001069202-25-000048:notes:20]

[0001069202-26-000054:notes:21]
[same as prior period, unchanged from 0001069202-25-000048:notes:21]

[0001069202-26-000054:notes:22]
[same as prior period, unchanged from 0001069202-25-000048:notes:22]

[0001069202-26-000054:notes:23]
[same as prior period, unchanged from 0001069202-25-000048:notes:23]

[0001069202-26-000054:notes:24]
[same as prior period, unchanged from 0001069202-25-000048:notes:24]

[0001069202-26-000054:notes:25]
|  | For the Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Total segment profit(1) | $ | 182.1 |  |  | $ | 182.7 |  |  |  |  |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Restructuring charges | — |  |  | — |  |  |  |  |  |
| Gain on sale from previous dispositions | — |  |  | — |  |  |  |  |  |
| Corporate and other expenses(2) | (18.6) |  |  | (14.7) |  |  |  |  |  |
| Operating income | 163.5 |  |  | 168.0 |  |  |  |  |  |
| Reconciliation to income before income taxes: |  |  |  |  |  |  |  |
| Pension settlements | 0.5 |  |  | 0.1 |  |  |  |  |  |
| Interest expense, net | 15.2 |  |  | 6.2 |  |  |  |  |  |
| Other expense, net | 0.9 |  |  | 0.9 |  |  |  |  |  |
| Net income before income taxes | $ | 146.9 |  |  | $ | 160.8 |  |  |  |  |  |

[0001069202-26-000054:notes:26]
(1) We define segment profit as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-26-000054:notes:27]
(2) Corporate and other expenses include unallocated corporate costs related to corporate administrative functions such as tax, treasury, accounting, internal audit, legal and human resources.

[0001069202-26-000054:notes:28]
[same as prior period, unchanged from 0001069202-25-000048:notes:27]

[0001069202-26-000054:notes:29]
|  | March 31, 2026 |  | December 31, 2025 |
| Total Assets: |  |  |  |
| Home Comfort Solutions | $ | 2,078.1 |  |  | $ | 1,971.0 |  |
| Building Climate Solutions | 1,795.8 |  |  | 1,746.4 |  |
| Total assets from reportable segments | $ | 3,873.9 |  |  | $ | 3,717.4 |  |
| Corporate and Other | 418.8 |  |  | 364.4 |  |
| Total assets | $ | 4,292.7 |  |  | $ | 4,081.8 |  |

[0001069202-26-000054:notes:30]
The assets in the Corporate and Other primarily consist of cash, property, plant and equipment, short-term investments, and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-26-000054:notes:31]
[same as prior period, unchanged from 0001069202-25-000048:notes:30]

[0001069202-26-000054:notes:32]
|  | For the Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Capital Expenditures: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 15.1 |  |  | $ | 11.4 |  |  |  |  |  |
| Building Climate Solutions | 7.5 |  |  | 6.3 |  |  |  |  |  |
| Total capital expenditures from reportable segments | $ | 22.6 |  |  | $ | 17.7 |  |  |  |  |  |
| Corporate and Other | 32.9 |  |  | 7.8 |  |  |  |  |  |
| Total capital expenditures | $ | 55.5 |  |  | $ | 25.5 |  |  |  |  |  |

[0001069202-26-000054:notes:33]
[same as prior period, unchanged from 0001069202-25-000048:notes:32]

[0001069202-26-000054:notes:34]
|  | For the Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Depreciation and Amortization: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 10.7 |  |  | $ | 10.4 |  |  |  |  |  |
| Building Climate Solutions | 11.7 |  |  | 7.9 |  |  |  |  |  |
| Total depreciation and amortization from reportable segments | $ | 22.4 |  |  | $ | 18.3 |  |  |  |  |  |
| Corporate and Other | 6.8 |  |  | 7.3 |  |  |  |  |  |
| Total depreciation and amortization | $ | 29.2 |  |  | $ | 25.6 |  |  |  |  |  |

[0001069202-26-000054:notes:35]
[same as prior period, unchanged from 0001069202-25-000048:notes:34]

[0001069202-26-000054:notes:36]
|  | For the Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Income from Equity Method Investments: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 1.1 |  |  | $ | 0.7 |  |  |  |  |  |
| Building Climate Solutions | 0.1 |  |  | 0.4 |  |  |  |  |  |
| Total income from equity method investments from reportable segments | $ | 1.2 |  |  | $ | 1.1 |  |  |  |  |  |
| Corporate and Other | (1.6) |  |  | 0.1 |  |  |  |  |  |
| Total (loss) income from equity method investments | $ | (0.4) |  |  | $ | 1.2 |  |  |  |  |  |

[0001069202-26-000054:notes:37]
[same as prior period, unchanged from 0001069202-25-000048:notes:36]

[0001069202-26-000054:notes:38]
[same as prior period, unchanged from 0001069202-25-000048:notes:37]

[0001069202-26-000054:notes:39]
|  | March 31, 2026 |  | December 31, 2025 |  |  |  |  |
| Property, Plant and Equipment, net: |  |  |  |  |  |  |  |
| United States | $ | 639.9 |  |  | $ | 607.4 |  |  |  |  |  |
| Mexico | 267.7 |  |  | 269.2 |  |  |  |  |  |
| Canada | 4.1 |  |  | 4.2 |  |  |  |  |  |
| Other international | 5.9 |  |  | 6.4 |  |  |  |  |  |
| Total Property, plant and equipment, net | $ | 917.6 |  |  | $ | 887.2 |  |  |  |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-26-000054:notes:40]
[same as prior period, unchanged from 0001069202-25-000048:notes:39]

[0001069202-26-000054:notes:41]
[same as prior period, unchanged from 0001069202-25-000048:notes:40]

[0001069202-26-000054:notes:42]
[same as prior period, unchanged from 0001069202-25-000048:notes:41]

[0001069202-26-000054:notes:43]
|  | For the Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Net income | $ | 117.2 |  |  | $ | 129.6 |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 34.8 |  |  | 35.5 |  |  |  |  |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.2 |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 35.0 |  |  | 35.7 |  |  |  |  |  |
| Earnings per share – Basic(1): | $ | 3.37 |  |  | $ | 3.65 |  |  |  |  |  |
| Earnings per share – Diluted(1): | $ | 3.35 |  |  | $ | 3.63 |  |  |  |  |  |

[0001069202-26-000054:notes:44]
[same as prior period, unchanged from 0001069202-25-000048:notes:43]

[0001069202-26-000054:notes:45]
For the three months ended March 31, 2026 and 2025, there were no material stock appreciation rights or restricted stock units outstanding that were not included in the diluted earnings per share calculation as the assumed exercise of such rights would have been anti-dilutive.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-26-000054:notes:46]
4. Commitments and Contingencies:

[0001069202-26-000054:notes:47]
Leases

[0001069202-26-000054:notes:48]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001069202-26-000054:notes:49]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition of a lease under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-26-000054:notes:50]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To

[0001069202-26-000054:notes:51]
estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-26-000054:notes:52]
We lease certain real and personal property under non-cancelable operating leases. Approximately 84% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-26-000054:notes:53]
Product Warranties and Product Related Contingencies

[0001069202-26-000054:notes:54]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001069202-26-000054:notes:55]
Liabilities for estimated product warranty costs are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:

[0001069202-26-000054:notes:56]
|  | March 31, 2026 |  | December 31, 2025 |
| Accrued expenses | $ | 56.2 |  |  | $ | 53.1 |  |
| Other liabilities | 113.1 |  |  | 114.1 |  |
| Total warranty liability | $ | 169.3 |  |  | $ | 167.2 |  |

[0001069202-26-000054:notes:57]
The changes in product warranty liabilities for the three months ended March 31, 2026 were as follows (in millions):

[0001069202-26-000054:notes:58]
| Total warranty liability as of December 31, 2025 | $ | 167.2 |  |
| Warranty claims paid | (10.5) |  |
| Changes resulting from issuance of new warranties | 12.4 |  |
| Changes in estimates associated with pre-existing liabilities | 0.4 |  |
| Changes in foreign currency translation rates and other | (0.2) |  |
| Total warranty liability as of March 31, 2026 | $ | 169.3 |  |

[0001069202-26-000054:notes:59]
Litigation

[0001069202-26-000054:notes:60]
Antitrust Class Action

[0001069202-26-000054:notes:61]
On March 20, 2026, seven HVAC equipment manufacturers (and certain of their affiliated companies), including the Company, were named as defendants in a complaint filed in the U.S. District Court for the Eastern District of Michigan on behalf of a putative class that alleges violations of Section 1 of the Sherman Antitrust Act of 1890, as amended, and certain state laws. Additional class action complaints were filed in April 2026 in the same court, based on similar allegations. The cases were consolidated under the caption In re HVAC Equipment Antitrust Litigation, No. 2:26-cv-10949 (E.D. Mich.).

[0001069202-26-000054:notes:62]
The complaints allege that the defendants conspired to fix, raise, maintain, and/or stabilize prices of HVAC equipment. The alleged class is defined as including all persons who purchased HVAC equipment in the U.S. during the period from January 1, 2020 to the present which was manufactured by one or more defendants for end use in a residential or commercial building. The complaints seek to recover an unspecified amount of damages, injunctive relief, and attorneys’ fees on behalf of the putative class.

[0001069202-26-000054:notes:63]
The Company disputes these allegations and plans to vigorously defend itself.  At this stage of the antitrust litigation, the Company cannot reasonably estimate the range of possible loss, if any, or the timing, outcome, or consequence of this litigation. An adverse outcome in this litigation could have a material adverse impact on the Company’s business, financial position, results of operations, or cash flows.

[0001069202-26-000054:notes:64]
Other Litigation

[0001069202-26-000054:notes:65]
We are involved in a number of other claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle other claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-26-000054:notes:66]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-26-000054:notes:67]
[same as prior period, unchanged from 0001069202-25-000048:notes:62]

[0001069202-26-000054:notes:68]
Our Board of Directors has authorized a total of $5.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in May 2025. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. Such repurchases may also be made in compliance with Rule 10b5-1 trading plans entered into by us, which would permit common stock to be repurchased when we might otherwise be precluded from doing so under insider trading laws or self-imposed trading restrictions. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of March 31, 2026, $989.5 million was available for repurchase under the Share Repurchase Plans.

[0001069202-26-000054:notes:69]
For the three months ended March 31, 2026, we repurchased 39,000 shares, at an aggregate cost, inclusive of fees, of $20.0 million.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-26-000054:notes:70]
[same as prior period, unchanged from 0001069202-25-000048:notes:65]

[0001069202-26-000054:notes:71]
[same as prior period, unchanged from 0001069202-25-000048:notes:66]

[0001069202-26-000054:notes:72]
| (Amounts in millions) | For the Three Months Ended March 31, 2026 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  |  |  | Consolidated |
| United States | $ | 604.0 |  |  | $ | 446.4 |  |  |  |  | $ | 1,050.4 |  |
| Canada | 46.0 |  |  | 38.7 |  |  |  |  | 84.7 |  |
| Total | $ | 650.0 |  |  | $ | 485.1 |  |  |  |  | $ | 1,135.1 |  |

[0001069202-26-000054:notes:73]
|  | For the Three Months Ended March 31, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  |  |  | Consolidated |
| United States | $ | 667.8 |  |  | $ | 332.6 |  |  |  |  | $ | 1,000.4 |  |
| Canada | 53.6 |  |  | 18.6 |  |  |  |  | 72.2 |  |
| Total | $ | 721.4 |  |  | $ | 351.2 |  |  |  |  | $ | 1,072.6 |  |

[0001069202-26-000054:notes:74]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2026 and 2025, direct sales represented 75% and 73% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-26-000054:notes:75]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada; manufacture curb, curb adapters, drop box diffusers;

[0001069202-26-000054:notes:76]
offer HVAC recycling and salvage services; and focus on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2026 and 2025, equipment sales represented 83% and 79% of revenues, respectively, and the remainder of our revenue was generated from our service business.

[0001069202-26-000054:notes:77]
[same as prior period, unchanged from 0001069202-25-000048:notes:74]

[0001069202-26-000054:notes:78]
|  | March 31, 2026 |  | December 31, 2025 |  |  |  |  |
| Contract assets | $ | 2.1 |  |  | $ | 1.7 |  |  |  |  |  |
| Contract liabilities - current | (10.0) |  |  | (10.5) |  |  |  |  |  |
| Contract liabilities - noncurrent | (10.4) |  |  | (10.3) |  |  |  |  |  |
| Total | $ | (18.3) |  |  | $ | (19.1) |  |  |  |  |  |

[0001069202-26-000054:notes:79]
For the three months ended March 31, 2026 and 2025, we recognized revenue of $0.6 million and $2.3 million related to our contract liabilities at January 1, 2026 and 2025, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2026 and 2025.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-26-000054:notes:80]
[same as prior period, unchanged from 0001069202-25-000048:notes:77]

[0001069202-26-000054:notes:81]
[same as prior period, unchanged from 0001069202-25-000048:notes:78]

[0001069202-26-000054:notes:82]
|  | March 31, 2026 |  | December 31, 2025 |
| Finished goods | $ | 742.3 |  |  | $ | 719.1 |  |
| Work in process | 7.2 |  |  | 7.5 |  |
| Raw materials and parts(1) | 460.2 |  |  | 426.0 |  |
| Total inventories, net | $ | 1,209.7 |  |  | $ | 1,152.6 |  |

[0001069202-26-000054:notes:83]
(1) Raw materials and parts includes materials for production and finished goods parts held for sale.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-26-000054:notes:84]
[same as prior period, unchanged from 0001069202-25-000048:notes:80]

[0001069202-26-000054:notes:85]
The changes in the carrying amount of goodwill in 2026, in total and by segment, are summarized in the table below (in millions):

[0001069202-26-000054:notes:86]
|  | Balance as of December 31, 2025 |  | Goodwill Adjustment(1) |  |  |  | Balance as of March 31, 2026 |
| Home Comfort Solutions | $ | 87.0 |  |  | $ | 1.6 |  |  |  |  | $ | 88.6 |  |
| Building Climate Solutions | 410.2 |  |  | 4.9 |  |  |  |  | 415.1 |  |
| Total Goodwill | $ | 497.2 |  |  | $ | 6.5 |  |  |  |  | $ | 503.7 |  |

[0001069202-26-000054:notes:87]
(1) As discussed in Note 13, an update to our purchase price allocation of Duro Dyne and Supco resulted in a $6.5 million increase in goodwill.

[0001069202-26-000054:notes:88]
We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We have not recorded any goodwill impairments for the three months ended March 31, 2026 or in any periods presented.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-26-000054:notes:89]
[same as prior period, unchanged from 0001069202-25-000048:notes:84]

[0001069202-26-000054:notes:90]
[same as prior period, unchanged from 0001069202-25-000048:notes:85]

[0001069202-26-000054:notes:91]
Commodity Price Risk - We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term and

[0001069202-26-000054:notes:92]
lower percentages are hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-26-000054:notes:93]
[same as prior period, unchanged from 0001069202-25-000048:notes:87]

[0001069202-26-000054:notes:94]
[same as prior period, unchanged from 0001069202-25-000048:notes:88]

[0001069202-26-000054:notes:95]
[same as prior period, unchanged from 0001069202-25-000048:notes:89]

[0001069202-26-000054:notes:96]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through September 2027.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions) as of:

[0001069202-26-000054:notes:97]
|  | March 31, 2026 |  | December 31, 2025 |
| Unrealized (gains) losses, net on unsettled contracts | $ | (25.4) |  |  | $ | (23.3) |  |
| Income tax expense (benefit) | 6.3 |  |  | 5.4 |  |
| Unrealized (gains) losses, net included in AOCL, net of tax (1) | $ | (19.1) |  |  | $ | (17.9) |  |

[0001069202-26-000054:notes:98]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $17.8 million of derivative gain as of March 31, 2026 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-26-000054:notes:99]
[same as prior period, unchanged from 0001069202-25-000048:notes:93]

[0001069202-26-000054:notes:100]
[same as prior period, unchanged from 0001069202-25-000048:notes:94]

[0001069202-26-000054:notes:101]
|  | For the Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Stock-based compensation expense | $ | 5.8 |  |  | $ | 6.3 |  |  |  |  |  |

[0001069202-26-000054:notes:102]
Equity awards granted in February 2026 were as follows:

[0001069202-26-000054:notes:103]
|  | Shares |  | Weighted-Average Grant Date Fair Value Per Share |  |  |  |  |
| Performance Share Units | 22,119 |  |  | $ | 474.95 |  |  |  |  |  |
| Restricted Stock Units | 24,969 |  |  | $ | 474.95 |  |  |  |  |  |
| Stock Appreciation Rights | 48,576 |  |  | $ | 133.13 |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-26-000054:notes:104]
[same as prior period, unchanged from 0001069202-25-000048:notes:96]

[0001069202-26-000054:notes:105]
[same as prior period, unchanged from 0001069202-25-000048:notes:97]

[0001069202-26-000054:notes:106]
|  | For the Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Service cost | $ | 0.2 |  |  | $ | 0.3 |  |  |  |  |  |
| Interest cost | 2.0 |  |  | 2.1 |  |  |  |  |  |
| Expected return on plan assets | (1.7) |  |  | (1.8) |  |  |  |  |  |
| Recognized actuarial loss | 0.5 |  |  | 0.4 |  |  |  |  |  |
| Settlements and curtailments | 0.5 |  |  | 0.1 |  |  |  |  |  |
| Net periodic benefit cost | $ | 1.5 |  |  | $ | 1.1 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-26-000054:notes:107]
[same as prior period, unchanged from 0001069202-25-000048:notes:99]

[0001069202-26-000054:notes:108]
As of March 31, 2026, we had approximately $5.2 million in total gross unrecognized tax benefits. If recognized, $5.2 million would be recorded through the Consolidated Statements of Operations.

[0001069202-26-000054:notes:109]
Our effective tax rate was 20.2% for the three months ended March 31, 2026 compared to 19.4% for the three months ended March 31, 2025. The increase in rate is primarily due to income in higher tax jurisdictions.

[0001069202-26-000054:notes:110]
We are currently under a limited scope audit by the Internal Revenue Service for our 2021 and 2022 tax years. There are also ongoing U.S. state and local audits and other foreign audits covering fiscal years 2019 through 2024. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2019.


## us-gaap:DebtDisclosureTextBlock

[0001069202-26-000054:notes:111]
10. Lines of Credit and Financing Arrangements:

[0001069202-26-000054:notes:112]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:

[0001069202-26-000054:notes:113]
|  | March 31, 2026 |  | December 31, 2025 |
| Commercial paper | $ | 361.0 |  |  | $ | 226.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 18.2 |  |  | $ | 18.3 |  |
| Total current maturities of long-term debt | $ | 18.2 |  |  | $ | 18.3 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 50.1 |  |  | $ | 50.6 |  |
| Term Loan | 300.0 |  |  | 300.0 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.0) |  |  | (6.5) |  |
| Total long-term debt | $ | 1,144.1 |  |  | $ | 1,144.1 |  |
| Total debt | $ | 1,523.3 |  |  | $ | 1,388.4 |  |

[0001069202-26-000054:notes:114]
Commercial Paper Program

[0001069202-26-000054:notes:115]
We utilize a commercial paper program (the “Program”) pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate

[0001069202-26-000054:notes:116]
purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $361.0 million CP Notes outstanding under the Program as of March 31, 2026.

[0001069202-26-000054:notes:117]
Our weighted average borrowing rate on the Program was as follows as of:

[0001069202-26-000054:notes:118]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | 4.20 | % |  | 3.98 | % |

[0001069202-26-000054:notes:119]
Long-Term Debt

[0001069202-26-000054:notes:120]
Term Loan

[0001069202-26-000054:notes:121]
On October 16, 2025, we entered into a Term Credit Agreement (the “Term Credit Agreement”) with Wells Fargo Bank, National Association, as administrative agent, and the other lenders party thereto. We borrowed $300.0 million pursuant to the Term Credit Agreement and used the net proceeds to repay existing borrowings under the Credit Agreement (as defined below). The Term Credit Agreement matures on October 16, 2027. Loans under the Term Credit Agreement bear interest at our election at a rate per annum equal to (i) a forward-looking term rate based on the secured overnight financing rate for the applicable interest period ("Term SOFR"), plus an applicable margin ranging between 0.90% and 1.025% per annum depending on our long-term unsecured debt rating, or (ii) the highest of the Wells Fargo Bank, National Association prime rate, the Federal Funds rate plus 0.50%, and Term SOFR for a one month tenor in effect on such day plus 1.00%, plus an applicable margin ranging between 0.00% and 0.025% per annum depending on our long-term unsecured debt rating.

[0001069202-26-000054:notes:122]
The Term Credit Agreement contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Credit Agreement.

[0001069202-26-000054:notes:123]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | 4.60 | % |  | 4.90 | % |

[0001069202-26-000054:notes:124]
Credit Agreement

[0001069202-26-000054:notes:125]
On May 9, 2025, we entered into an Amendment and Restatement Agreement (the "Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Credit Agreement. The Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and no amounts committed to standby letters of credit as of March 31, 2026. Subject to covenant limitations, $639.0 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Credit Agreement is reduced by borrowings under the Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001069202-26-000054:notes:126]
Our weighted average borrowing rate on the Credit Agreement was as follows as of:

[0001069202-26-000054:notes:127]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | — | % |  | — | % |

[0001069202-26-000054:notes:128]
The Credit Agreement and the Term Credit Agreement (the "Credit Facilities") are guaranteed by certain of our subsidiaries (the "Guarantor Subsidiaries") and contain customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Credit Facilities each contain a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001069202-26-000054:notes:129]
Our Credit Facilities contain customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our Credit Facilities could occur if:

[0001069202-26-000054:notes:130]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding      $75.0 million; or

[0001069202-26-000054:notes:131]
•We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-26-000054:notes:132]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Facilities or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-26-000054:notes:133]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Facilities (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-26-000054:notes:134]
We are currently in compliance with all covenant requirements.

[0001069202-26-000054:notes:135]
Senior Unsecured Notes

[0001069202-26-000054:notes:136]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  In July 2020, we issued $300.0 million of senior unsecured notes, which will mature on August 1, 2027 (the "2027 Notes," and collectively with the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.70% per annum. On August 1, 2025, we repaid upon maturity $300.0 million of senior unsecured notes originally issued in 2020. 
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The Notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries. The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-26-000054:notes:137]
[same as prior period, unchanged from 0001069202-25-000048:notes:123]

[0001069202-26-000054:notes:138]
[same as prior period, unchanged from 0001069202-25-000048:notes:124]

[0001069202-26-000054:notes:139]
|  |  | For the Three Months Ended March 31, |  |  |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2026 |  | 2025 |  |  |  |  |  |
| Gains (Losses) on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | 10.8 |  |  | $ | 2.6 |  |  |  |  |  |  | Cost of goods sold; Losses and other expenses, net |
| Income tax (expense) benefit |  | (2.5) |  |  | (0.6) |  |  |  |  |  |  | Provision for income taxes |
| Net of tax |  | $ | 8.3 |  |  | $ | 2.0 |  |  |  |  |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (0.5) |  |  | $ | (0.4) |  |  |  |  |  |  | Other expense, net |
| Pension settlements |  | (0.5) |  |  | (0.1) |  |  |  |  |  |  | Pension settlements |
| Income tax benefit |  | 0.2 |  |  | 0.1 |  |  |  |  |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.7) |  |  | $ | (0.4) |  |  |  |  |  |  |  |
| Total reclassifications from AOCL |  | $ | 7.6 |  |  | $ | 1.6 |  |  |  |  |  |  |  |

[0001069202-26-000054:notes:140]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2026 (in millions):

[0001069202-26-000054:notes:141]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2025 |  | $ | 17.9 |  |  | $ | 0.2 |  |  | $ | (46.8) |  |  | $ | (19.8) |  |  | $ | (48.5) |  |
| Other comprehensive income (loss) before reclassifications |  | 9.5 |  |  | — |  |  | (0.7) |  |  | (0.7) |  |  | 8.1 |  |
| Amounts reclassified from AOCL |  | (8.3) |  |  | — |  |  | 0.7 |  |  | — |  |  | (7.6) |  |
| Net other comprehensive income (loss) |  | 1.2 |  |  | — |  |  | — |  |  | (0.7) |  |  | 0.5 |  |
| Balance as of March 31, 2026 |  | $ | 19.1 |  |  | $ | 0.2 |  |  | $ | (46.8) |  |  | $ | (20.5) |  |  | $ | (48.0) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-26-000054:notes:142]
[same as prior period, unchanged from 0001069202-25-000048:notes:128]

[0001069202-26-000054:notes:143]
[same as prior period, unchanged from 0001069202-25-000048:notes:129]

[0001069202-26-000054:notes:144]
The methodologies used to determine the fair value of our financial assets and liabilities as of March 31, 2026 were the same as those used as of December 31, 2025.

[0001069202-26-000054:notes:145]
[same as prior period, unchanged from 0001069202-25-000048:notes:131]

[0001069202-26-000054:notes:146]
[same as prior period, unchanged from 0001069202-25-000048:notes:132]

[0001069202-26-000054:notes:147]
[same as prior period, unchanged from 0001069202-25-000048:notes:133]

[0001069202-26-000054:notes:148]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Credit Facilities and CP Notes in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-26-000054:notes:149]
[same as prior period, unchanged from 0001069202-25-000048:notes:135]

[0001069202-26-000054:notes:150]
|  | March 31, 2026 |  | December 31, 2025 |
| Senior unsecured notes | $ | 804.3 |  |  | $ | 817.4 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001069202-26-000054:notes:151]
13. Prior Year Acquisition:

[0001069202-26-000054:notes:152]
In October 2025, we completed the acquisition of Duro Dyne and Supco, a robust portfolio of HVAC parts and supplies that complement our existing residential and commercial offerings. Under the terms of the purchase agreement, a final working capital adjustment was completed in the first quarter of 2026.  This working capital adjustment resulted in a $2.3 million increase in the purchase price.  Additionally, during the first quarter of 2026 we made certain purchase price adjustments.  The following table details the purchase price adjustments that were made during the first quarter of 2026 (in millions):

[0001069202-26-000054:notes:153]
|  | December 31, 2025 |  | Adjustment |  | March 31, 2026 |
| Net tangible assets acquired | $ | 39.1 |  |  | $ | (4.2) |  |  | $ | 34.9 |  |
| Intangible assets acquired(1) | 235.0 |  |  | — |  |  | 235.0 |  |
| Goodwill | 277.2 |  |  | 6.5 |  |  | 283.7 |  |
| Total investment | $ | 551.3 |  |  | $ | 2.3 |  |  | $ | 553.6 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001069202-26-000054:notes:154]
Sivasankaran Somasundaram, a director, adopted a non-Rule 10b5-1 trading arrangement on February 11, 2026, pursuant to which he elected to receive all of his director retainer to be paid between July 1, 2026 and June 30, 2027 in shares of the Company's common stock.  The amount of shares to be awarded will be determined based on the closing price of the Company's common stock on the second Friday of each quarter during the payment period.  This trading plan was entered into during an open insider trading window and is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act and the Company's policies regarding transactions in the Company's securities.
