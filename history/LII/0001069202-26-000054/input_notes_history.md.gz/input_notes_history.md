# LII note change history — 0001069202-25-000048 → 0001069202-26-000054


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0001069202-26-000054:note_history:1]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.
  (was, 2025-10-22, similarity 0.8434):
[0001069202-25-000048:note_history:1]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or

- changed (2026-04-29):
[0001069202-26-000054:note_history:2]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To
  (was, 2025-10-22, similarity 0.802):
[0001069202-25-000048:note_history:2]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

- added (2026-04-29):
[0001069202-26-000054:note_history:3]
estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

- changed (2026-04-29):
[0001069202-26-000054:note_history:4]
|  | March 31, 2026 |  | December 31, 2025 |
| Accrued expenses | $ | 56.2 |  |  | $ | 53.1 |  |
| Other liabilities | 113.1 |  |  | 114.1 |  |
| Total warranty liability | $ | 169.3 |  |  | $ | 167.2 |  |
  (was, 2025-10-22, similarity 0.9695):
[0001069202-25-000048:note_history:4]
|  | September 30, 2025 |  | December 31, 2024 |
| Accrued expenses | $ | 50.7 |  |  | $ | 49.1 |  |
| Other liabilities | 114.3 |  |  | 109.4 |  |
| Total warranty liability | $ | 165.0 |  |  | $ | 158.4 |  |

- changed (2026-04-29):
[0001069202-26-000054:note_history:5]
The changes in product warranty liabilities for the three months ended March 31, 2026 were as follows (in millions):
  (was, 2025-10-22, similarity 0.9244):
[0001069202-25-000048:note_history:5]
The changes in product warranty liabilities for the nine months ended September 30, 2025 were as follows (in millions):

- changed (2026-04-29):
[0001069202-26-000054:note_history:6]
| Total warranty liability as of December 31, 2025 | $ | 167.2 |  |
| Warranty claims paid | (10.5) |  |
| Changes resulting from issuance of new warranties | 12.4 |  |
| Changes in estimates associated with pre-existing liabilities | 0.4 |  |
| Changes in foreign currency translation rates and other | (0.2) |  |
| Total warranty liability as of March 31, 2026 | $ | 169.3 |  |
  (was, 2025-10-22, similarity 0.8642):
[0001069202-25-000048:note_history:6]
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Warranty claims paid | (36.3) |  |
| Changes resulting from issuance of new warranties | 39.9 |  |
| Changes in estimates associated with pre-existing liabilities | 2.7 |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of September 30, 2025 | $ | 165.0 |  |

- added (2026-04-29):
[0001069202-26-000054:note_history:7]
Antitrust Class Action

- added (2026-04-29):
[0001069202-26-000054:note_history:8]
On March 20, 2026, seven HVAC equipment manufacturers (and certain of their affiliated companies), including the Company, were named as defendants in a complaint filed in the U.S. District Court for the Eastern District of Michigan on behalf of a putative class that alleges violations of Section 1 of the Sherman Antitrust Act of 1890, as amended, and certain state laws. Additional class action complaints were filed in April 2026 in the same court, based on similar allegations. The cases were consolidated under the caption In re HVAC Equipment Antitrust Litigation, No. 2:26-cv-10949 (E.D. Mich.).

- added (2026-04-29):
[0001069202-26-000054:note_history:9]
The complaints allege that the defendants conspired to fix, raise, maintain, and/or stabilize prices of HVAC equipment. The alleged class is defined as including all persons who purchased HVAC equipment in the U.S. during the period from January 1, 2020 to the present which was manufactured by one or more defendants for end use in a residential or commercial building. The complaints seek to recover an unspecified amount of damages, injunctive relief, and attorneys’ fees on behalf of the putative class.

- added (2026-04-29):
[0001069202-26-000054:note_history:10]
The Company disputes these allegations and plans to vigorously defend itself.  At this stage of the antitrust litigation, the Company cannot reasonably estimate the range of possible loss, if any, or the timing, outcome, or consequence of this litigation. An adverse outcome in this litigation could have a material adverse impact on the Company’s business, financial position, results of operations, or cash flows.

- added (2026-04-29):
[0001069202-26-000054:note_history:11]
Other Litigation

- added (2026-04-29):
[0001069202-26-000054:note_history:12]
We are involved in a number of other claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle other claims and lawsuits, based on experience involving similar matters and specific facts known.

- removed (2026-04-29):
[0001069202-25-000048:note_history:13]
less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

- removed (2026-04-29):
[0001069202-25-000048:note_history:14]
We are involved in a number of claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0001069202-26-000054:note_history:15]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2026 and the accompanying unaudited Consolidated Statements of Operations, Comprehensive Income, Stockholders' Equity, and Cash Flows for the three months ended March 31, 2026 and 2025 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2025.
  (was, 2025-10-22, similarity 0.6365):
[0001069202-25-000048:note_history:15]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2025, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2025 and 2024, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three and nine months ended September 30, 2025 and 2024, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2025 and 2024 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2024.

- added (2026-04-29):
[0001069202-26-000054:note_history:16]
The unaudited consolidated financial statements for all comparable prior periods presented have been retrospectively adjusted to reflect the prior-year change in method of accounting for certain inventories from last-in-first-out ("LIFO") to first-in, first-out ("FIFO").


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0001069202-26-000054:note_history:17]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | 4.20 | % |  | 3.98 | % |
  (was, 2025-10-22, similarity 0.9318):
[0001069202-25-000048:note_history:17]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.30 | % |  | — | % |

- added (2026-04-29):
[0001069202-26-000054:note_history:18]
The Term Credit Agreement contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Credit Agreement.

- changed (2026-04-29):
[0001069202-26-000054:note_history:19]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | 4.60 | % |  | 4.90 | % |
  (was, 2025-10-22, similarity 0.9205):
[0001069202-25-000048:note_history:19]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |

- changed (2026-04-29):
[0001069202-26-000054:note_history:20]
Our weighted average borrowing rate on the Credit Agreement was as follows as of:
  (was, 2025-10-22, similarity 0.9529):
[0001069202-25-000048:note_history:20]
Our weighted average borrowing rate on the Amended Credit Agreement was as follows as of:

- added (2026-04-29):
[0001069202-26-000054:note_history:21]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | — | % |  | — | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0001069202-26-000054:note_history:22]
|  | March 31, 2026 |  | December 31, 2025 |
| Commercial paper | $ | 361.0 |  |  | $ | 226.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 18.2 |  |  | $ | 18.3 |  |
| Total current maturities of long-term debt | $ | 18.2 |  |  | $ | 18.3 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 50.1 |  |  | $ | 50.6 |  |
| Term Loan | 300.0 |  |  | 300.0 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.0) |  |  | (6.5) |  |
| Total long-term debt | $ | 1,144.1 |  |  | $ | 1,144.1 |  |
| Total debt | $ | 1,523.3 |  |  | $ | 1,388.4 |  |
  (was, 2025-10-22, similarity 0.7773):
[0001069202-25-000048:note_history:22]
|  | September 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 157.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.9 |  |  | $ | 14.9 |  |
| Senior unsecured notes | — |  |  | 300.0 |  |
| Debt issuance costs | — |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 16.9 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 44.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.5) |  |  | (6.4) |  |
| Total long-term debt | $ | 838.2 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,012.1 |  |  | $ | 1,147.6 |  |

- changed (2026-04-29):
[0001069202-26-000054:note_history:23]
We utilize a commercial paper program (the “Program”) pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate
  (was, 2025-10-22, similarity 0.8126):
[0001069202-25-000048:note_history:23]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $157.0 million CP Notes outstanding under the Program as of September 30, 2025.

- added (2026-04-29):
[0001069202-26-000054:note_history:24]
purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were $361.0 million CP Notes outstanding under the Program as of March 31, 2026.

- changed (2026-04-29):
[0001069202-26-000054:note_history:25]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | 4.20 | % |  | 3.98 | % |
  (was, 2025-10-22, similarity 0.9318):
[0001069202-25-000048:note_history:25]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | 4.30 | % |  | — | % |

- added (2026-04-29):
[0001069202-26-000054:note_history:26]
Long-Term Debt

- added (2026-04-29):
[0001069202-26-000054:note_history:27]
Term Loan

- added (2026-04-29):
[0001069202-26-000054:note_history:28]
On October 16, 2025, we entered into a Term Credit Agreement (the “Term Credit Agreement”) with Wells Fargo Bank, National Association, as administrative agent, and the other lenders party thereto. We borrowed $300.0 million pursuant to the Term Credit Agreement and used the net proceeds to repay existing borrowings under the Credit Agreement (as defined below). The Term Credit Agreement matures on October 16, 2027. Loans under the Term Credit Agreement bear interest at our election at a rate per annum equal to (i) a forward-looking term rate based on the secured overnight financing rate for the applicable interest period ("Term SOFR"), plus an applicable margin ranging between 0.90% and 1.025% per annum depending on our long-term unsecured debt rating, or (ii) the highest of the Wells Fargo Bank, National Association prime rate, the Federal Funds rate plus 0.50%, and Term SOFR for a one month tenor in effect on such day plus 1.00%, plus an applicable margin ranging between 0.00% and 0.025% per annum depending on our long-term unsecured debt rating.

- added (2026-04-29):
[0001069202-26-000054:note_history:29]
The Term Credit Agreement contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Credit Agreement.

- changed (2026-04-29):
[0001069202-26-000054:note_history:30]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | 4.60 | % |  | 4.90 | % |
  (was, 2025-10-22, similarity 0.9205):
[0001069202-25-000048:note_history:30]
|  | September 30, 2025 |  | December 31, 2024 |
| Weighted average borrowing rate | — | % |  | — | % |

- changed (2026-04-29):
[0001069202-26-000054:note_history:31]
On May 9, 2025, we entered into an Amendment and Restatement Agreement (the "Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Credit Agreement. The Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and no amounts committed to standby letters of credit as of March 31, 2026. Subject to covenant limitations, $639.0 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Credit Agreement is reduced by borrowings under the Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.
  (was, 2025-10-22, similarity 0.6552):
[0001069202-25-000048:note_history:31]
On May 9, 2025, we entered into an Amendment and Restatement Agreement ("Amended Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Amended Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Amended Credit Agreement. The Amended Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of September 30, 2025. Subject to covenant limitations, $841.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Amended Credit Agreement is reduced by borrowings under the Program. The Amended Credit Agreement includes a subfacility for swingline loans up to $65.0 million. Maturity of the Amended Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Amended Credit Agreement.

- changed (2026-04-29):
[0001069202-26-000054:note_history:32]
Our weighted average borrowing rate on the Credit Agreement was as follows as of:
  (was, 2025-10-22, similarity 0.9529):
[0001069202-25-000048:note_history:32]
Our weighted average borrowing rate on the Amended Credit Agreement was as follows as of:

- added (2026-04-29):
[0001069202-26-000054:note_history:33]
|  | March 31, 2026 |  | December 31, 2025 |
| Weighted average borrowing rate | — | % |  | — | % |

- changed (2026-04-29):
[0001069202-26-000054:note_history:34]
The Credit Agreement and the Term Credit Agreement (the "Credit Facilities") are guaranteed by certain of our subsidiaries (the "Guarantor Subsidiaries") and contain customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Credit Facilities each contain a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).
  (was, 2025-10-22, similarity 0.8265):
[0001069202-25-000048:note_history:34]
The Amended Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Amended Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

- changed (2026-04-29):
[0001069202-26-000054:note_history:35]
Our Credit Facilities contain customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our Credit Facilities could occur if:
  (was, 2025-10-22, similarity 0.9316):
[0001069202-25-000048:note_history:35]
Our Amended Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our credit facility could occur if:

- changed (2026-04-29):
[0001069202-26-000054:note_history:36]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Facilities or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.
  (was, 2025-10-22, similarity 0.9453):
[0001069202-25-000048:note_history:36]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Amended Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

- changed (2026-04-29):
[0001069202-26-000054:note_history:37]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Facilities (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).
  (was, 2025-10-22, similarity 0.8294):
[0001069202-25-000048:note_history:37]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Amended Credit Agreement and accelerate amounts due under our Amended Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

- changed (2026-04-29):
[0001069202-26-000054:note_history:38]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  In July 2020, we issued $300.0 million of senior unsecured notes, which will mature on August 1, 2027 (the "2027 Notes," and collectively with the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.70% per annum. On August 1, 2025, we repaid upon maturity $300.0 million of senior unsecured notes originally issued in 2020. 
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The Notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries. The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.
  (was, 2025-10-22, similarity 0.9534):
[0001069202-25-000048:note_history:38]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  In July 2020, we issued $300.0 million of senior unsecured notes, which will mature on August 1, 2027 (the "2027 Notes," and collectively with the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.70% per annum. On August 1, 2025, we repaid upon maturity $300.0 million of senior unsecured notes originally issued in 2020. 
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Amended Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0001069202-26-000054:note_history:39]
|  | March 31, 2026 |  | December 31, 2025 |
| Commercial paper | $ | 361.0 |  |  | $ | 226.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 18.2 |  |  | $ | 18.3 |  |
| Total current maturities of long-term debt | $ | 18.2 |  |  | $ | 18.3 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 50.1 |  |  | $ | 50.6 |  |
| Term Loan | 300.0 |  |  | 300.0 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.0) |  |  | (6.5) |  |
| Total long-term debt | $ | 1,144.1 |  |  | $ | 1,144.1 |  |
| Total debt | $ | 1,523.3 |  |  | $ | 1,388.4 |  |
  (was, 2025-10-22, similarity 0.7773):
[0001069202-25-000048:note_history:39]
|  | September 30, 2025 |  | December 31, 2024 |
| Commercial paper | $ | 157.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 16.9 |  |  | $ | 14.9 |  |
| Senior unsecured notes | — |  |  | 300.0 |  |
| Debt issuance costs | — |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 16.9 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 44.7 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (6.5) |  |  | (6.4) |  |
| Total long-term debt | $ | 838.2 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,012.1 |  |  | $ | 1,147.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-04-29):
[0001069202-26-000054:note_history:40]
| (Amounts in millions) | For the Three Months Ended March 31, 2026 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  |  |  | Consolidated |
| United States | $ | 604.0 |  |  | $ | 446.4 |  |  |  |  | $ | 1,050.4 |  |
| Canada | 46.0 |  |  | 38.7 |  |  |  |  | 84.7 |  |
| Total | $ | 650.0 |  |  | $ | 485.1 |  |  |  |  | $ | 1,135.1 |  |

- changed (2026-04-29):
[0001069202-26-000054:note_history:41]
|  | For the Three Months Ended March 31, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  |  |  | Consolidated |
| United States | $ | 667.8 |  |  | $ | 332.6 |  |  |  |  | $ | 1,000.4 |  |
| Canada | 53.6 |  |  | 18.6 |  |  |  |  | 72.2 |  |
| Total | $ | 721.4 |  |  | $ | 351.2 |  |  |  |  | $ | 1,072.6 |  |
  (was, 2025-10-22, similarity 0.6006):
[0001069202-25-000048:note_history:41]
|  | For the Three Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 971.1 |  |  | $ | 441.9 |  |  | $ | — |  |  | $ | 1,413.0 |  |
| Canada | 61.7 |  |  | 23.4 |  |  | — |  |  | 85.1 |  |
| Total | $ | 1,032.8 |  |  | $ | 465.3 |  |  | $ | — |  |  | $ | 1,498.1 |  |

- changed (2026-04-29):
[0001069202-26-000054:note_history:42]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2026 and 2025, direct sales represented 75% and 73% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2025-10-22, similarity 0.7119):
[0001069202-25-000048:note_history:42]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent

- changed (2026-04-29):
[0001069202-26-000054:note_history:43]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada; manufacture curb, curb adapters, drop box diffusers;
  (was, 2025-10-22, similarity 0.7628):
[0001069202-25-000048:note_history:43]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada; manufacture curb, curb adapters, drop box diffusers; offer HVAC recycling and salvage services; and focus on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2025 and 2024, equipment sales represented 80% and 80% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2025 and 2024, equipment sales represented 80% and 81% of revenues and the remainder of our revenue was generated from our service business.

- added (2026-04-29):
[0001069202-26-000054:note_history:44]
offer HVAC recycling and salvage services; and focus on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2026 and 2025, equipment sales represented 83% and 79% of revenues, respectively, and the remainder of our revenue was generated from our service business.

- changed (2026-04-29):
[0001069202-26-000054:note_history:45]
|  | March 31, 2026 |  | December 31, 2025 |  |  |  |  |
| Contract assets | $ | 2.1 |  |  | $ | 1.7 |  |  |  |  |  |
| Contract liabilities - current | (10.0) |  |  | (10.5) |  |  |  |  |  |
| Contract liabilities - noncurrent | (10.4) |  |  | (10.3) |  |  |  |  |  |
| Total | $ | (18.3) |  |  | $ | (19.1) |  |  |  |  |  |
  (was, 2025-10-22, similarity 0.977):
[0001069202-25-000048:note_history:45]
|  | September 30, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 3.1 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (11.1) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (10.1) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (18.1) |  |  | $ | (12.2) |  |  |  |  |  |

- changed (2026-04-29):
[0001069202-26-000054:note_history:46]
For the three months ended March 31, 2026 and 2025, we recognized revenue of $0.6 million and $2.3 million related to our contract liabilities at January 1, 2026 and 2025, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2026 and 2025.
  (was, 2025-10-22, similarity 0.8154):
[0001069202-25-000048:note_history:46]
For the three months ended September 30, 2025 and 2024, we recognized revenue of $5.4 million and $0.7 million and for the nine months ended September 30, 2025 and 2024, we recognized revenue of $8.5 million and $6.8 million related to our contract liabilities at January 1, 2025 and 2024, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025 and 2024.

- removed (2026-04-29):
[0001069202-25-000048:note_history:47]
| (Amounts in millions) | For the Three Months Ended September 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 850.1 |  |  | $ | 478.3 |  |  | $ | — |  |  | $ | 1,328.4 |  |
| Canada | 62.8 |  |  | 35.6 |  |  | — |  |  | 98.4 |  |
| Total | $ | 912.9 |  |  | $ | 513.9 |  |  | $ | — |  |  | $ | 1,426.8 |  |

- removed (2026-04-29):
[0001069202-25-000048:note_history:48]
|  | For the Nine Months Ended September 30, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,458.9 |  |  | $ | 1,266.6 |  |  | $ | — |  |  | $ | 3,725.5 |  |
| Canada | 184.7 |  |  | 90.1 |  |  | — |  |  | 274.8 |  |
| Total | $ | 2,643.6 |  |  | $ | 1,356.7 |  |  | $ | — |  |  | $ | 4,000.3 |  |

- removed (2026-04-29):
[0001069202-25-000048:note_history:49]
|  | For the Nine Months Ended September 30, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,520.7 |  |  | $ | 1,244.2 |  |  | $ | — |  |  | $ | 3,764.9 |  |
| Canada | 169.0 |  |  | 62.4 |  |  | — |  |  | 231.4 |  |
| Total | $ | 2,689.7 |  |  | $ | 1,306.6 |  |  | $ | — |  |  | $ | 3,996.3 |  |

- removed (2026-04-29):
[0001069202-25-000048:note_history:50]
installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2025 and 2024, direct sales represented 75% and 73% of revenues, respectively, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2025 and 2024, direct sales represented 74% and 74% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2026-04-29):
[0001069202-25-000048:note_history:51]
13. Subsequent Events:

- removed (2026-04-29):
[0001069202-25-000048:note_history:52]
Acquisition – Duro Dyne and Supco

- removed (2026-04-29):
[0001069202-25-000048:note_history:53]
On October 15, 2025, the Company completed the previously announced acquisition of Duro Dyne Buyer, Inc. and Sealed Unit Parts Buyer, Inc. (“Duro Dyne and Supco”). Duro Dyne and Supco offer a robust portfolio of HVAC parts and supplies that complement our existing residential and commercial offerings. Excluding cash received at the closing, the net purchase price for the acquisition was $546.3 million. We used cash on hand and available borrowing capacity to fund the purchase price.  The purchase price is subject to final adjustments for net working capital. The financial results of Duro Dyne and Supco will be included beginning in the fourth quarter of 2025.

- removed (2026-04-29):
[0001069202-25-000048:note_history:54]
Due to the timing of this transaction, the allocation of the purchase price has not yet been finalized.

- removed (2026-04-29):
[0001069202-25-000048:note_history:55]
Term Credit Agreement

- removed (2026-04-29):
[0001069202-25-000048:note_history:56]
On October 16, 2025, we entered into a Term Credit Agreement (the “Term Credit Agreement”) with Wells Fargo Bank, National Association, as administrative agent, and the other lenders party thereto. We borrowed $300.0 million pursuant to the Term Credit Agreement and used the net proceeds to repay existing borrowings under the Amended Credit Agreement. The Term Credit Agreement matures on October 16, 2027. Loans under the Term Credit Agreement bear interest at our election at a rate per annum equal to (i) a forward-looking term rate based on the secured overnight financing rate for the applicable interest period ("Term SOFR"), plus an applicable margin ranging between 0.90% and 1.025% per annum depending on our long-term unsecured debt rating, or (ii) the highest of the Wells Fargo Bank, National Association prime rate, the Federal Funds rate plus 0.50%, and Term SOFR for a one month tenor in effect on such day plus 1.00%, plus an applicable margin ranging between 0.00% and 0.025% per annum depending on our long-term unsecured debt rating.

- removed (2026-04-29):
[0001069202-25-000048:note_history:57]
The Term Credit Agreement is guaranteed by the Guarantor Subsidiaries and contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Amended Credit Agreement.
