# LII MD&A — 0001069202-26-000054


## mdna

[0001069202-26-000054:mdna:1]
[same as prior period, unchanged from 0001069202-25-000048:mdna:1]

[0001069202-26-000054:mdna:2]
[same as prior period, unchanged from 0001069202-25-000048:mdna:2]

[0001069202-26-000054:mdna:3]
We operate in two reportable business segments of the HVACR industry, Home Comfort Solutions and Building Climate Solutions. For more detailed information regarding our reportable segments, see Note 2 in the Notes to the Consolidated Financial Statements.

[0001069202-26-000054:mdna:4]
[same as prior period, unchanged from 0001069202-25-000048:mdna:4]

[0001069202-26-000054:mdna:5]
[same as prior period, unchanged from 0001069202-25-000048:mdna:5]

[0001069202-26-000054:mdna:6]
[same as prior period, unchanged from 0001069202-25-000048:mdna:6]

[0001069202-26-000054:mdna:7]
[same as prior period, unchanged from 0001069202-25-000048:mdna:7]

[0001069202-26-000054:mdna:8]
Results for the first quarter of 2026 were mixed as our Home Comfort Solutions segment faced volume headwinds driven by market softness. Overall our net sales increased 6% and our segment profit was relatively flat as compared to prior year. For our Home Comfort Solutions segment, net sales decreased 10% and segment profit decreased $37 million. For our Building Climate Solutions segment, net sales increased 38% and segment profit increased $37 million.

[0001069202-26-000054:mdna:9]
[same as prior period, unchanged from 0001069202-25-000048:mdna:9]

[0001069202-26-000054:mdna:10]
•Net sales of $1,135 million in the first quarter of 2026 reflected a 6% increase as compared to the same period in 2025.

[0001069202-26-000054:mdna:11]
•Operating income in the first quarter of 2026 decreased $5 million to $163 million as lower sales volumes and higher product costs were partially offset by favorable mix and price.

[0001069202-26-000054:mdna:12]
•Net income for the first quarter of 2026 was $117 million.

[0001069202-26-000054:mdna:13]
•Diluted earnings per share was $3.35 per share in the first quarter of 2026 as compared to $3.63 per share in the same period in 2025.

[0001069202-26-000054:mdna:14]
•For the three months ended March 31, 2026, we returned $45 million to shareholders through dividend payments and repurchased $20 million of common stock through our share repurchase program.

[0001069202-26-000054:mdna:15]
[same as prior period, unchanged from 0001069202-25-000048:mdna:15]

[0001069202-26-000054:mdna:16]
Throughout 2025, the U.S. government implemented new tariff measures under various authorities, including the International Emergency Economic Powers Act ("IEEPA") and Section 232 of the Trade Expansion Act of 1962 (“Section 232”).

[0001069202-26-000054:mdna:17]
In February 2026, the U.S. Supreme Court ruled against tariffs imposed under IEEPA. The ruling did not address refunds of tariffs paid, nor did it repeal Section 232 tariffs on steel and aluminum. Following this ruling, the U.S. presidential administration imposed a temporary surcharge, known as Section 122, which applies a 10 percent global tariff on most imported products. These tariffs apply broadly to manufactured goods and component parts. Section 232 tariffs on steel and aluminum also continued to evolve, with modifications implemented in April 2026. The Company is evaluating the potential impact of all tariff actions on future material costs and sourcing decisions.

[0001069202-26-000054:mdna:18]
Three Months Ended March 31, 2026 Compared to Three Months Ended March 31, 2025 - Consolidated Results

[0001069202-26-000054:mdna:19]
[same as prior period, unchanged from 0001069202-25-000048:mdna:18]

[0001069202-26-000054:mdna:20]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net sales | $ | 1,135.1 |  |  | $ | 1,072.6 |  |  | 5.8 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 783.8 |  |  | 731.7 |  |  | (7.1) |  |  | 69.1 |  |  | 68.2 |  |
| Gross profit | 351.3 |  |  | 340.9 |  |  | 3.1 |  |  | 30.9 |  |  | 31.8 |  |
| Selling, general and administrative expenses | 185.2 |  |  | 171.3 |  |  | (8.1) |  |  | 16.3 |  |  | 16.0 |  |
| Losses and other expenses, net | 2.2 |  |  | 2.8 |  |  | 21.4 |  |  | 0.2 |  |  | 0.3 |  |
| Loss (income) from equity method investments | 0.4 |  |  | (1.2) |  |  | (133.3) |  |  | — |  |  | (0.1) |  |
| Operating income | $ | 163.5 |  |  | $ | 168.0 |  |  | (2.7) | % |  | 14.4 | % |  | 15.7 | % |

[0001069202-26-000054:mdna:21]
[same as prior period, unchanged from 0001069202-25-000048:mdna:20]

[0001069202-26-000054:mdna:22]
Net sales for the first quarter of 2026 increased 6% as compared to the same period in 2025 primarily due to a 9% increase from favorable mix and price and a 5% increase in sales volumes from completed acquisitions, which were partially offset by an 8% decrease in sales volumes.

[0001069202-26-000054:mdna:23]
[same as prior period, unchanged from 0001069202-25-000048:mdna:22]

[0001069202-26-000054:mdna:24]
Gross profit margins in the first quarter of 2026 decreased 90 basis points ("bps") to 30.9% as compared to 31.8% in the same period in 2025. Gross margins decreased 300 bps from higher product costs, primarily related to inflationary impacts and

[0001069202-26-000054:mdna:25]
factory under absorption, and 40 bps from higher freight and distribution inflation and investments, which were partially offset by 250 bps from favorable mix and price.

[0001069202-26-000054:mdna:26]
[same as prior period, unchanged from 0001069202-25-000048:mdna:24]

[0001069202-26-000054:mdna:27]
Selling, general and administrative expenses ("SG&A") increased $14 million to $185 million in the first quarter of 2026 as compared to $171 million in the same period in 2025, primarily attributable to higher discretionary and employee-related costs and the acquisition of Duro Dyne and Supco in the fourth quarter of 2025.

[0001069202-26-000054:mdna:28]
[same as prior period, unchanged from 0001069202-25-000048:mdna:26]

[0001069202-26-000054:mdna:29]
Losses (gains) and other expenses, net for the first quarter of 2026 and 2025 included the following (in millions):

[0001069202-26-000054:mdna:30]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2026 |  | 2025 |  |  |  |  |  |  |
| Foreign currency exchange (gains) losses | $ | (0.3) |  |  | $ | 0.8 |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.6) |  |  | (0.1) |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 3.1 |  |  | 2.1 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.2 |  |  | $ | 2.8 |  |  |  |  |  |  |  |

[0001069202-26-000054:mdna:31]
[same as prior period, unchanged from 0001069202-25-000048:mdna:29]

[0001069202-26-000054:mdna:32]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments was de minimis in the first quarter of 2026, consistent with 2025.

[0001069202-26-000054:mdna:33]
[same as prior period, unchanged from 0001069202-25-000048:mdna:31]

[0001069202-26-000054:mdna:34]
Interest expense, net increased to $15 million in the first quarter of 2026 from $6 million in the same period in 2025 primarily due to increased borrowings on our commercial paper facility and our term loan agreement entered into in October of 2025.

[0001069202-26-000054:mdna:35]
[same as prior period, unchanged from 0001069202-25-000048:mdna:33]

[0001069202-26-000054:mdna:36]
Our effective tax rate was 20.2% for the first quarter of 2026 as compared to 19.4% in the same period in 2025. The increase in rate is primarily due to income in higher tax jurisdictions.

[0001069202-26-000054:mdna:37]
First Quarter of 2026 Compared to First Quarter of 2025 - Results by Segment

[0001069202-26-000054:mdna:38]
[same as prior period, unchanged from 0001069202-25-000048:mdna:36]

[0001069202-26-000054:mdna:39]
The following table presents our Home Comfort Solutions segment's net sales and profit for the first quarter of 2026 and 2025 (dollars in millions):

[0001069202-26-000054:mdna:40]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Difference |  | % Change |
| Net sales | $ | 650.0 |  |  | $ | 721.4 |  |  | $ | (71.4) |  |  | (10) | % |
| Profit | $ | 86.5 |  |  | $ | 123.9 |  |  | $ | (37.4) |  |  | (30) | % |
| % of net sales | 13.3 | % |  | 17.2 | % |  |  |  |  |

[0001069202-26-000054:mdna:41]
Net sales decreased 10% in the first quarter of 2026 as compared to the same period in 2025 primarily due to a 21% decrease in sales volumes, which was partially offset by a 9% increase from favorable mix and price and a 2% increase in sales volumes from completed acquisitions.

[0001069202-26-000054:mdna:42]
Segment profit in the first quarter of 2026 decreased $37 million as compared to the same period in 2025, primarily due to lower sales volumes, resulting in a $56 million profit headwind, $23 million in product cost inflation and lower factory absorption, and $1 million in other costs. These impacts were partially offset by a $41 million benefit from favorable mix and price and $2 million from completed acquisitions.

[0001069202-26-000054:mdna:43]
[same as prior period, unchanged from 0001069202-25-000048:mdna:41]

[0001069202-26-000054:mdna:44]
The following table presents our Building Climate Solutions segment's net sales and profit for the first quarter of 2026 and 2025 (dollars in millions):

[0001069202-26-000054:mdna:45]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | Difference |  | % Change |
| Net sales | $ | 485.1 |  |  | $ | 351.2 |  |  | $ | 133.9 |  |  | 38 | % |
| Profit | $ | 95.6 |  |  | $ | 58.8 |  |  | $ | 36.8 |  |  | 63 | % |
| % of net sales | 19.7 | % |  | 16.7 | % |  |  |  |  |

[0001069202-26-000054:mdna:46]
Net sales increased 38% in the first quarter of 2026 as compared to the same period in 2025 primarily due to a 17% increase in sales volumes, a 12% increase in sales volumes from completed acquisitions, and 9% from favorable mix and price.

[0001069202-26-000054:mdna:47]
Segment profit in the first quarter of 2026 increased $37 million as compared to the same period in 2025 primarily due to $24 million profit benefit from higher sales volumes and $22 million increase in favorable mix and price, and $7 million profit benefit from sales volumes from completed acquisitions, which were partially offset by $8 million in product cost inflation and lower factory absorption, and $8 million from other costs.

[0001069202-26-000054:mdna:48]
[same as prior period, unchanged from 0001069202-25-000048:mdna:83]

[0001069202-26-000054:mdna:49]
[same as prior period, unchanged from 0001069202-25-000048:mdna:84]

[0001069202-26-000054:mdna:50]
[same as prior period, unchanged from 0001069202-25-000048:mdna:85]

[0001069202-26-000054:mdna:51]
The following table summarizes our cash flow activity for the three months ended March 31, 2026 and 2025 (in millions):

[0001069202-26-000054:mdna:52]
|  | For the Three Months Ended March 31, |
|  | 2026 |  | 2025 |
| Net cash provided by (used in) operating activities | $ | 16.1 |  |  | $ | (35.8) |  |
| Net cash used in investing activities | (56.6) |  |  | (23.5) |  |
| Net cash provided by (used in) financing activities | 57.1 |  |  | (141.2) |  |

[0001069202-26-000054:mdna:53]
Net Cash Provided By (Used In) Operating Activities - The change in net cash provided by operating activities for the three months ended March 31, 2026 compared to the net cash used in operating activities for the same period in 2025 is primarily due to favorable working capital changes.

[0001069202-26-000054:mdna:54]
Net Cash Used In Investing Activities - Capital expenditures were $56 million for the three months ended March 31, 2026 compared to $26 million in the same period of 2025.  The increase in capital expenditures was primarily related to land and building purchases.

[0001069202-26-000054:mdna:55]
Net Cash Provided By (Used In) Financing Activities - Net cash provided by financing activities for the three months ended March 31, 2026 increased to $57 million as compared to $141 million used in during the same period of 2025.  The change was primarily due to changes in net borrowings and repayments of long-term debt and repurchases of common stock through our share repurchase program.  We repurchased $20 million of shares for the three months ended March 31, 2026 and returned $45 million to shareholders through dividend payments.

[0001069202-26-000054:mdna:56]
[same as prior period, unchanged from 0001069202-25-000048:mdna:92]

[0001069202-26-000054:mdna:57]
The following table details our lines of credit and financing arrangements as of March 31, 2026 (in millions):

[0001069202-26-000054:mdna:58]
|  | Outstanding Borrowings |
| Commercial paper: | $ | 361.0 |  |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 18.2 |  |
| Total current maturities of long-term debt | $ | 18.2 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 50.1 |  |
| Term Loan | 300.0 |  |
| Senior unsecured notes | 800.0 |  |
| Debt issuance costs | (6.0) |  |
| Total long-term debt | $ | 1,144.1 |  |
| Total debt | $ | 1,523.3 |  |

[0001069202-26-000054:mdna:59]
[same as prior period, unchanged from 0001069202-25-000048:mdna:95]

[0001069202-26-000054:mdna:60]
We utilize a commercial paper program (the "Program") pursuant to which we may issue short-term, unsecured commercial paper notes (the "CP Notes") under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There are $361.0 million CP Notes outstanding under the Program as of March 31, 2026.

[0001069202-26-000054:mdna:61]
[same as prior period, unchanged from 0001069202-25-000048:mdna:97]

[0001069202-26-000054:mdna:62]
On May 9, 2025, we entered into an Amendment and Restatement Agreement (the "Credit Agreement") to our existing unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. The Credit Agreement decreased our total revolving commitments from $1.1 billion to $1.0 billion with an option to increase the revolving commitments by up to $350 million at our request, subject to the terms and conditions of the Credit Agreement. The Credit Agreement also extended the maturity date of the revolving commitments from July 2026 to May 2030. We had no outstanding borrowings and no amounts committed to standby letters of credit as of March 31, 2026. Subject to covenant limitations, $639.0 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. Availability under the Credit Agreement is reduced by borrowings under the Program. The Credit Agreement includes a subfacility for swingline loans up to  $65.0 million. Maturity of the Credit Agreement may be extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001069202-26-000054:mdna:63]
Term Loan

[0001069202-26-000054:mdna:64]
On October 16, 2025, we entered into a Term Credit Agreement (the “Term Credit Agreement”) with Wells Fargo Bank, National Association, as administrative agent, and the other lenders party thereto. We borrowed $300.0 million pursuant to the Term Credit Agreement and used the net proceeds to repay existing borrowings under the Credit Agreement. The Term Credit Agreement matures on October 16, 2027. Loans under the Term Credit Agreement bear interest at our election at a rate per annum equal to (i) a forward-looking term rate based on the secured overnight financing rate for the applicable interest period ("Term SOFR"), plus an applicable margin ranging between 0.90% and 1.025% per annum depending on our long-term unsecured debt rating, or (ii) the highest of the Wells Fargo Bank, National Association prime rate, the Federal Funds rate plus 0.50%, and Term SOFR for a one month tenor in effect on such day plus 1.00%, plus an applicable margin ranging between 0.00% and 0.025% per annum depending on our long-term unsecured debt rating.

[0001069202-26-000054:mdna:65]
The Term Credit Agreement contains customary covenants and events of default that are substantially similar to the existing covenants and events of default in our Credit Agreement.

[0001069202-26-000054:mdna:66]
[same as prior period, unchanged from 0001069202-25-000048:mdna:99]

[0001069202-26-000054:mdna:67]
[same as prior period, unchanged from 0001069202-25-000048:mdna:100]

[0001069202-26-000054:mdna:68]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.

[0001069202-26-000054:mdna:69]
[same as prior period, unchanged from 0001069202-25-000048:mdna:103]

[0001069202-26-000054:mdna:70]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 56% at March 31, 2026, as compared to 54% at December 31, 2025.

[0001069202-26-000054:mdna:71]
As of March 31, 2026, our senior credit ratings were Baa1 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-26-000054:mdna:72]
[same as prior period, unchanged from 0001069202-25-000048:mdna:106]

[0001069202-26-000054:mdna:73]
We believe our cash and cash equivalents of $48.2 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends, and other needs in the foreseeable future. Included in our cash and cash equivalents of $48.2 million as of March 31, 2026 was $19.3 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-26-000054:mdna:74]
[same as prior period, unchanged from 0001069202-25-000048:mdna:108]

[0001069202-26-000054:mdna:75]
[same as prior period, unchanged from 0001069202-25-000048:mdna:109]

[0001069202-26-000054:mdna:76]
[same as prior period, unchanged from 0001069202-25-000048:mdna:110]

[0001069202-26-000054:mdna:77]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of March 31, 2026 and December 31, 2025 and for the three months ended March 31, 2026 (in millions):

[0001069202-26-000054:mdna:78]
|  | March 31, 2026 |  | December 31, 2025 |
| Current assets | $ | 1,853.5 |  |  | $ | 1,676.4 |  |
| Non-current assets | 1,912.0 |  |  | 1,824.9 |  |
| Current liabilities | 1,111.6 |  |  | 1,000.7 |  |
| Non-current liabilities | 1,751.1 |  |  | 1,689.4 |  |
| Amounts due to non-Guarantor Subsidiaries | (522.1) |  |  | (463.7) |  |
|  | Three months ended March 31, 2026 |  | For the Year Ended December 31, 2025 |
| Net sales | $ | 1,050.5 |  |  | $ | 5,113.8 |  |
| Gross profit | 326.3 |  |  | 1,324.4 |  |
| Net income | 53.6 |  |  | 406.3 |  |

[0001069202-26-000054:mdna:79]
[same as prior period, unchanged from 0001069202-25-000048:mdna:114]

[0001069202-26-000054:mdna:80]
[same as prior period, unchanged from 0001069202-25-000048:mdna:115]

[0001069202-26-000054:mdna:81]
Commitments, Contingencies, and Guarantees

[0001069202-26-000054:mdna:82]
For information regarding our commitments, contingencies, and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-26-000054:mdna:83]
[same as prior period, unchanged from 0001069202-25-000048:mdna:118]

[0001069202-26-000054:mdna:84]
[same as prior period, unchanged from 0001069202-25-000048:mdna:119]
