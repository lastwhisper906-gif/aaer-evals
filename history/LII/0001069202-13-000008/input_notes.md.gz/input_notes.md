# LII notes — 0001069202-13-000008


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-13-000008:notes:1]
[same as prior period, unchanged from 0001069202-13-000005:notes:1]

[0001069202-13-000008:notes:2]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2013, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2013 and 2012, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2013 and 2012, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2013 and 2012 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2012. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-13-000008:notes:3]
[same as prior period, unchanged from 0001069202-13-000005:notes:3]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-13-000008:notes:4]
Commitments and Contingencies:

[0001069202-13-000008:notes:5]
Leases

[0001069202-13-000008:notes:6]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas (the "Lake Park Renewal") for a term of approximately six years through March 1, 2019.  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease.

[0001069202-13-000008:notes:7]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Domestic Credit Facility.  We were in compliance with those covenants as of June 30, 2013.

[0001069202-13-000008:notes:8]
Product Warranties and Product Related Contingencies

[0001069202-13-000008:notes:9]
Total liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000008:notes:10]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Accrued expenses | $ | 23.5 |  |  | $ | 25.1 |  |
| Other liabilities | 50.2 |  |  | 46.8 |  |
|  | $ | 73.7 |  |  | $ | 71.9 |  |

[0001069202-13-000008:notes:11]
The changes in total product warranty liabilities related to continuing operations for the six months ended June 30, 2013 were as follows (in millions):

[0001069202-13-000008:notes:12]
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (9.2 | ) |
| Changes resulting from issuance of new warranties | 14.7 |  |
| Changes in estimates associated with pre-existing liabilities | (3.2 | ) |
| Changes in foreign currency translation rates and other | (0.5 | ) |
| Total warranty liability as of June 30, 2013 | $ | 73.7 |  |

[0001069202-13-000008:notes:13]
We evaluate our heating, ventilation and air conditioning ("HVAC") warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.  As a result of the second quarter 2013 re-evaluation, we decreased our warranty liability by $3.2 million and recorded the related expense in Cost of Goods Sold in the Consolidated Statements of Operations.  The adjustment from the second quarter re-evaluation is the principal change in the estimate associated with pre-existing liabilities shown in the table above.

[0001069202-13-000008:notes:14]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material changes in the circumstances that affect our product warranties since our latest fiscal year-end.

[0001069202-13-000008:notes:15]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001069202-13-000008:notes:16]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the six months ended June 30, 2013 were as follows (in millions):

[0001069202-13-000008:notes:17]
| Total accrued product quality issue as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid in 2013 | (0.7 | ) |
| Total accrued product quality issue as of June 30, 2013 | $ | 6.0 |  |

[0001069202-13-000008:notes:18]
Litigation

[0001069202-13-000008:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-13-000008:notes:20]
Some of these claims and lawsuits allege health problems resulting from exposure to asbestos.  For the three months ended June 30, 2013, we recorded income, net of insurance recoveries, of $0.1 million and for the six months ended June 30, 2013, we recorded charges, net of insurance recoveries, of $0.5 million related to asbestos matters.  These charges were recorded in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operation.  We also expect that additional claims will be brought against us in the future.  However, the Company believes our liability exposure from those additional future claims cannot currently be estimated because of numerous uncertainties, including the number of such claims and lawsuits and the costs of defending and settling them, possible adverse judgments in amounts greater than previously experienced, and possible changes in the laws and process governing the compensation of asbestos claimants.

[0001069202-13-000008:notes:21]
We are also involved in patent litigation claims related to products from an acquired business.  The Company believes it has indemnification protection (with certain limitations) for these claims.

[0001069202-13-000008:notes:22]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-13-000008:notes:23]
[same as prior period, unchanged from 0001069202-13-000005:notes:23]

[0001069202-13-000008:notes:24]
[same as prior period, unchanged from 0001069202-13-000005:notes:24]

[0001069202-13-000008:notes:25]
| AOCI Component |  | For the Three Months Ended June 30, 2013 |  | For the Six Months Ended June 30, 2013 |  | Affected Line Item in the Consolidated Statements of Operations |
| Losses on cash flow hedges: |  |  |  |  |  |  |
| Commodity derivative contracts |  | $ | (1.6 | ) |  | $ | (1.2 | ) |  | Cost of goods sold |
| Interest rate derivative contracts |  | — |  |  | — |  |  | Interest expense, net |
|  |  | (1.6 | ) |  | (1.2 | ) |  | Total before income taxes |
|  |  | — |  |  | — |  |  | Provision for income taxes |
|  |  | $ | (1.6 | ) |  | $ | (1.2 | ) |  | Net of tax |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Sale of foreign business (1) |  | $ | — |  |  | $ | 41.1 |  |  | Loss from discontinued operations |
| Total reclassifications from AOCI |  | $ | (1.6 | ) |  | $ | 39.9 |  |  |  |

[0001069202-13-000008:notes:26]
(1) The reclassification of foreign currency translation adjustments relates to the sale of the Service Experts business in the first quarter of 2013.  Refer to Note 13 for details.

[0001069202-13-000008:notes:27]
The following table provides information on changes in AOCI by component (net of tax) for the six months ended June 30, 2013 (in millions):

[0001069202-13-000008:notes:28]
|  |  | Gains / (Losses) on Cash Flow Hedges |  | Unrealized Gains / (Losses) on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2012 |  | $ | 1.1 |  |  | $ | 9.3 |  |  | $ | (147.5 | ) |  | $ | 114.8 |  |  | $ | (22.3 | ) |
| Other comprehensive income/(loss) before reclassifications |  | (8.8 | ) |  | (4.7 | ) |  | 1.0 |  |  | (28.4 | ) |  | (40.9 | ) |
| Amounts reclassified from AOCI |  | 1.2 |  |  | — |  |  | — |  |  | (41.1 | ) |  | (39.9 | ) |
| Net other comprehensive income/(loss) |  | (7.6 | ) |  | (4.7 | ) |  | 1.0 |  |  | (69.5 | ) |  | (80.8 | ) |
| Balance as of June 30, 2013 |  | $ | (6.5 | ) |  | $ | 4.6 |  |  | $ | (146.5 | ) |  | $ | 45.3 |  |  | $ | (103.1 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001069202-13-000008:notes:29]
Lines of Credit and Financing Arrangements:

[0001069202-13-000008:notes:30]
The following table summarizes our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-13-000008:notes:31]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 120.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 5.9 |  |  | 4.9 |  |
| Total short-term debt | $ | 125.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.4 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 195.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 410.8 |  |  | $ | 351.0 |  |
| Total debt | $ | 537.1 |  |  | $ | 386.6 |  |

[0001069202-13-000008:notes:32]
Short-Term Debt

[0001069202-13-000008:notes:33]
Foreign Obligations

[0001069202-13-000008:notes:34]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $5.9 million and $4.9 million of foreign obligations as of June 30, 2013 and December 31, 2012, respectively, that are primarily borrowings under non-committed facilities.

[0001069202-13-000008:notes:35]
Asset Securitization Program

[0001069202-13-000008:notes:36]
Under the Receivables Purchase Agreement, or Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.

[0001069202-13-000008:notes:37]
The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-13-000008:notes:38]
The ASP provides for a maximum securitization amount of the lesser of $160.0 million or 100% of the net pool balance as defined by the ASP.  However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-13-000008:notes:39]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 120.0 |  |  | 30.0 |  |
| Remaining amount available | $ | 40.0 |  |  | $ | 130.0 |  |

[0001069202-13-000008:notes:40]
Under the ASP, we pay certain discount fees to use the program and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates for June 30, 2013 and December 31, 2012 were 0.82% and 0.85%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):

[0001069202-13-000008:notes:41]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.6 |  |

[0001069202-13-000008:notes:42]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2013, we were in compliance with all covenant requirements.

[0001069202-13-000008:notes:43]
Long-Term Debt

[0001069202-13-000008:notes:44]
Domestic Revolving Credit Facility

[0001069202-13-000008:notes:45]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $195.0 million and $50.0 million committed to standby letters of credit as of June 30, 2013. Subject to covenant limitations, $405.0 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-13-000008:notes:46]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-13-000008:notes:47]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.48 | % |  | 1.46 | % |

[0001069202-13-000008:notes:48]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-13-000008:notes:49]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-13-000008:notes:50]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our revolving credit facility could occur if:

[0001069202-13-000008:notes:51]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-13-000008:notes:52]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-13-000008:notes:53]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-13-000008:notes:54]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2013, we were in compliance with all covenant requirements.

[0001069202-13-000008:notes:55]
Senior Unsecured Notes

[0001069202-13-000008:notes:56]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

[0001069202-13-000008:notes:57]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2013, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-13-000008:notes:58]
[same as prior period, unchanged from 0001069202-13-000005:notes:58]

[0001069202-13-000008:notes:59]
[same as prior period, unchanged from 0001069202-13-000005:notes:59]

[0001069202-13-000008:notes:60]
[same as prior period, unchanged from 0001069202-13-000005:notes:60]

[0001069202-13-000008:notes:61]
We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts, which we enter into using a dollar cost averaging strategy, to lock in prices.  As a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  A higher percentage of commodity price exposures are hedged near term with lower percentages hedged at future dates, providing us with protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-13-000008:notes:62]
[same as prior period, unchanged from 0001069202-13-000005:notes:62]

[0001069202-13-000008:notes:63]
A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest. In order to mitigate a portion of that risk, we may choose from time to time to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows.

[0001069202-13-000008:notes:64]
Prior to 2013, we used an interest rate swap hedge to fix the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the benchmark interest rate.  The variable portion of the interest rate swap was tied to the 1-Month LIBOR (the benchmark interest rate). On a monthly basis, the interest rates for both the interest rate swap and the underlying debt were reset, the swap was settled with the counterparty, and the interest was paid.  The interest rate swap was classified as a cash flow hedge.  That interest rate swap expired on October 12, 2012, and, subsequently, we were no longer hedged against interest rate risk.

[0001069202-13-000008:notes:65]
[same as prior period, unchanged from 0001069202-13-000005:notes:65]

[0001069202-13-000008:notes:66]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. We seek to mitigate the impact of short-term currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them. By entering into these forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-13-000008:notes:67]
[same as prior period, unchanged from 0001069202-13-000005:notes:67]

[0001069202-13-000008:notes:68]
We include unrealized gains or losses from our commodity cash flow hedges in accumulated other comprehensive income (“AOCI”). The gains or losses in AOCI related to commodity price hedges are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.  Assuming that commodity prices remain constant, we expect to reclassify $5.8 million of derivative losses into earnings within the next 12 months. Commodity futures contracts that are designated as cash flow hedges and that are in place as of June 30, 2013 are scheduled to mature through December 2014.

[0001069202-13-000008:notes:69]
[same as prior period, unchanged from 0001069202-13-000005:notes:69]

[0001069202-13-000008:notes:70]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Commodity Price Hedges: |  |  |  |
| Losses (gains) included in AOCI, net of tax | $ | 6.5 |  |  | $ | (1.1 | ) |
| Expense for (benefit from) income taxes | (3.7 | ) |  | 0.7 |  |

[0001069202-13-000008:notes:71]
[same as prior period, unchanged from 0001069202-13-000005:notes:71]

[0001069202-13-000008:notes:72]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
|  | (pounds) |  | (pounds) |
| Copper | 22.6 |  |  | 22.8 |  |

[0001069202-13-000008:notes:73]
[same as prior period, unchanged from 0001069202-13-000005:notes:73]

[0001069202-13-000008:notes:74]
[same as prior period, unchanged from 0001069202-13-000005:notes:74]

[0001069202-13-000008:notes:75]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
|  | (pounds) |  | (pounds) |
| Copper | 2.3 |  |  | 2.1 |  |
| Aluminum | 2.6 |  |  | 2.8 |  |

[0001069202-13-000008:notes:76]
We also had the following outstanding foreign currency forward contracts not designated as cash flow hedges (local currency, in millions):

[0001069202-13-000008:notes:77]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Notional Amounts: |  |  |  |
| Brazilian Real | 3.9 |  |  | 10.8 |  |
| Mexican Peso | 255.0 |  |  | 220.2 |  |
| Euro | 4.0 |  |  | 1.3 |  |
| British Pound | 2.2 |  |  | 5.4 |  |
| Indian Rupee | 192.0 |  |  | 19.5 |  |
| Polish Zloty | 24.8 |  |  | 12.4 |  |

[0001069202-13-000008:notes:78]
[same as prior period, unchanged from 0001069202-13-000005:notes:78]

[0001069202-13-000008:notes:79]
[same as prior period, unchanged from 0001069202-13-000005:notes:79]

[0001069202-13-000008:notes:80]
|  | Fair Values of Derivative Instruments(1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | As of June 30, 2013 |  | As of December 31, 2012 |  | As of June 30, 2013 |  | As of December 31, 2012 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 1.6 |  |  | $ | — |  |  | $ | 0.2 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Total Assets | $ | — |  |  | $ | 1.9 |  |  | $ | — |  |  | $ | 0.3 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 9.2 |  |  | $ | — |  |  | $ | 1.3 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.8 |  |  | 0.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 1.2 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total Liabilities | $ | 10.4 |  |  | $ | — |  |  | $ | 2.2 |  |  | $ | 0.1 |  |

[0001069202-13-000008:notes:81]
[same as prior period, unchanged from 0001069202-13-000005:notes:81]

[0001069202-13-000008:notes:82]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Amount of Loss Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |
| Commodity futures contracts(1) | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 1.2 |  |  | $ | 3.5 |  |
| Interest rate swap(2) | — |  |  | 0.6 |  |  | — |  |  | 1.2 |  |
|  | $ | 1.6 |  |  | $ | 2.2 |  |  | $ | 1.2 |  |  | $ | 4.7 |  |
| Amount of Loss (Gain) Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |  |  |
| Commodity futures contracts(3) | $ | — |  |  | $ | — |  |  | $ | 0.3 |  |  | $ | (0.1 | ) |

[0001069202-13-000008:notes:83]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Amount of Loss (Gain) Recognized in Income on Derivatives: |  |  |  |  |  |  |  |
| Commodity futures contracts(3) | $ | 1.0 |  |  | $ | 1.2 |  |  | $ | 1.8 |  |  | $ | (0.1 | ) |
| Foreign currency forward contracts(3) | 1.3 |  |  | (0.3 | ) |  | 0.8 |  |  | (0.3 | ) |
|  | $ | 2.3 |  |  | $ | 0.9 |  |  | $ | 2.6 |  |  | $ | (0.4 | ) |

[0001069202-13-000008:notes:84]
(1) The loss was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-13-000008:notes:85]
[same as prior period, unchanged from 0001069202-13-000005:notes:85]

[0001069202-13-000008:notes:86]
(3) The loss (gain) was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-13-000008:notes:87]
[same as prior period, unchanged from 0001069202-13-000005:notes:87]

[0001069202-13-000008:notes:88]
[same as prior period, unchanged from 0001069202-13-000005:notes:88]

[0001069202-13-000008:notes:89]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Compensation expense(1) | $ | 7.5 |  |  | $ | 4.0 |  |  | $ | 15.2 |  |  | $ | 7.8 |  |

[0001069202-13-000008:notes:90]
[same as prior period, unchanged from 0001069202-13-000005:notes:90]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-13-000008:notes:91]
[same as prior period, unchanged from 0001069202-13-000005:notes:91]

[0001069202-13-000008:notes:92]
[same as prior period, unchanged from 0001069202-13-000005:notes:92]

[0001069202-13-000008:notes:93]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd. in an all cash transaction for proceeds, excluding transaction costs, of $10.4 million.  The proceeds include a determinable working capital adjustment of $3.8 million that we expect to receive in the third quarter of 2013.

[0001069202-13-000008:notes:94]
[same as prior period, unchanged from 0001069202-13-000005:notes:94]

[0001069202-13-000008:notes:95]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net trade sales(1) | $ | — |  |  | $ | 112.4 |  |  | $ | 73.5 |  |  | $ | 194.3 |  |
| Pre-tax operating loss (1)(2) | (0.4 | ) |  | (1.6 | ) |  | (15.5 | ) |  | (15.9 | ) |
| Gain on sale of business | — |  |  | — |  |  | 1.7 |  |  | — |  |

[0001069202-13-000008:notes:96]
[same as prior period, unchanged from 0001069202-13-000005:notes:96]

[0001069202-13-000008:notes:97]
(2) Pre-tax operating loss for the six months ended June 30, 2013 includes $2.3 million in retention bonus and severance costs and $0.2 million in stock-based compensation expense.

[0001069202-13-000008:notes:98]
[same as prior period, unchanged from 0001069202-13-000005:notes:98]

[0001069202-13-000008:notes:99]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Assets of discontinued operations: |  |  |  |
| Accounts receivable, net | $ | — |  |  | $ | 11.2 |  |
| Inventories, net | — |  |  | 4.8 |  |
| Property, plant and equipment, net | — |  |  | 3.6 |  |
| Goodwill and intangible assets, net (1) | — |  |  | 66.2 |  |
| Deferred income taxes | — |  |  | 5.5 |  |
| Other assets | — |  |  | 7.3 |  |
| Liabilities of discontinued operations: |  |  |  |
| Accounts payable | $ | — |  |  | $ | 16.7 |  |
| Accrued expenses | — |  |  | 38.5 |  |

[0001069202-13-000008:notes:100]
(1) Includes goodwill of $66.0 million as of December 31, 2012.  No goodwill impairments were recorded in 2013, and all goodwill was eliminated on March 22, 2013 as a result of the sale of the business.

[0001069202-13-000008:notes:101]
[same as prior period, unchanged from 0001069202-13-000005:notes:101]

[0001069202-13-000008:notes:102]
In April 2012, the Company sold its Hearth business to Comvest Investment Partners IV in an all cash transaction for net proceeds of $10.1 million, excluding the transaction costs and cash transferred with the business.

[0001069202-13-000008:notes:103]
[same as prior period, unchanged from 0001069202-13-000005:notes:103]

[0001069202-13-000008:notes:104]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net trade sales(1) | $ | — |  |  | $ | 4.9 |  |  | $ | — |  |  | $ | 23.5 |  |
| Pre-tax operating income (loss)(1) | 0.4 |  |  | (3.4 | ) |  | 0.5 |  |  | (11.9 | ) |
| Loss on sale of business | — |  |  | (3.8 | ) |  | — |  |  | (3.8 | ) |

[0001069202-13-000008:notes:105]
| (1) | Excludes eliminations of intercompany sales and any associated profit. |

[0001069202-13-000008:notes:106]
There were no assets and liabilities related to the Hearth business included in the accompanying Consolidated Balance Sheets as of June 30, 2013 or December 31, 2012.


## us-gaap:EarningsPerShareTextBlock

[0001069202-13-000008:notes:107]
Earnings Per Share:

[0001069202-13-000008:notes:108]
[same as prior period, unchanged from 0001069202-13-000005:notes:108]

[0001069202-13-000008:notes:109]
The computations of basic and diluted earnings per share for Net income were as follows (in millions, except per share data):

[0001069202-13-000008:notes:110]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net income | $ | 64.3 |  |  | $ | 44.7 |  |  | $ | 72.3 |  |  | $ | 38.6 |  |
| Add: Loss from discontinued operations | — |  |  | 4.8 |  |  | 7.8 |  |  | 20.2 |  |
| Income from continuing operations | $ | 64.3 |  |  | $ | 49.5 |  |  | $ | 80.1 |  |  | $ | 58.8 |  |
| Weighted-average shares outstanding – basic | 50.2 |  |  | 51.0 |  |  | 50.2 |  |  | 50.9 |  |
| Effect of diluted securities attributable to stock-based payments | 0.7 |  |  | 0.6 |  |  | 0.8 |  |  | 0.6 |  |
| Weighted-average shares outstanding – diluted | 50.9 |  |  | 51.6 |  |  | 51.0 |  |  | 51.5 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.28 |  |  | $ | 0.97 |  |  | $ | 1.60 |  |  | $ | 1.15 |  |
| Loss from discontinued operations | — |  |  | (0.09 | ) |  | (0.16 | ) |  | (0.39 | ) |
| Net income | $ | 1.28 |  |  | $ | 0.88 |  |  | $ | 1.44 |  |  | $ | 0.76 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.26 |  |  | $ | 0.96 |  |  | $ | 1.57 |  |  | $ | 1.14 |  |
| Loss from discontinued operations | — |  |  | (0.09 | ) |  | (0.15 | ) |  | (0.39 | ) |
| Net income | $ | 1.26 |  |  | $ | 0.87 |  |  | $ | 1.42 |  |  | $ | 0.75 |  |

[0001069202-13-000008:notes:111]
The following stock appreciation rights were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive (in millions, except for per share data):

[0001069202-13-000008:notes:112]
|  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |
| Weighted-average number of shares | 0.1 |  |  | 1.1 |  |
| Price ranges per share | $ | 51.40 |  |  | $34.06 - $46.78 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-13-000008:notes:113]
[same as prior period, unchanged from 0001069202-13-000005:notes:113]

[0001069202-13-000008:notes:114]
|  | Quoted Prices in Active Markets forSimilar Instruments (Level 2) |
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Senior unsecured notes | $ | 202.1 |  |  | $ | 212.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-13-000008:notes:115]
[same as prior period, unchanged from 0001069202-13-000005:notes:115]

[0001069202-13-000008:notes:116]
[same as prior period, unchanged from 0001069202-13-000005:notes:116]

[0001069202-13-000008:notes:117]
[same as prior period, unchanged from 0001069202-13-000005:notes:117]

[0001069202-13-000008:notes:118]
|  | Quoted Prices in Active Markets forIdentical Assets (Level 1) |
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Investment in marketable equity securities (1) | $ | 6.7 |  |  | $ | 10.6 |  |

[0001069202-13-000008:notes:119]
[same as prior period, unchanged from 0001069202-13-000005:notes:119]

[0001069202-13-000008:notes:120]
[same as prior period, unchanged from 0001069202-13-000005:notes:120]

[0001069202-13-000008:notes:121]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net, accounts payable, other current liabilities, and short-term debt approximate fair value due to the short maturities of these instruments. The carrying amount of our Domestic Revolving Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-13-000008:notes:122]
The fair values of our Senior unsecured notes in Long-term debt are based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk. The fair values presented in the table below are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently or indicative of our intent or ability to dispose of or liquidate them.  The estimated fair values of our Senior unsecured notes were as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-13-000008:notes:123]
[same as prior period, unchanged from 0001069202-13-000005:notes:122]

[0001069202-13-000008:notes:124]
The changes in the carrying amount of goodwill for the first six months of 2013, in total and by segment, are summarized in the table below (in millions):

[0001069202-13-000008:notes:125]
|  | Balance at December 31, 2012 |  | Acquisitions / (Dispositions) |  | Other(1) |  | Balance at June 30, 2013 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 63.8 |  |  | — |  |  | (0.2 | ) |  | 63.6 |  |
| Refrigeration | 133.9 |  |  | — |  |  | (6.0 | ) |  | 127.9 |  |
|  | $ | 223.8 |  |  | $ | — |  |  | $ | (6.2 | ) |  | $ | 217.6 |  |

[0001069202-13-000008:notes:126]
(1)  Other consists of changes in foreign currency translation rates.

[0001069202-13-000008:notes:127]
We performed our annual goodwill impairment test in the first quarter of 2013 and did not recognize any impairments for our reporting units.  We will continue to monitor our reporting units throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill for impairment.  Refer to Note 13 for information on goodwill related to discontinued operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-13-000008:notes:128]
[same as prior period, unchanged from 0001069202-13-000005:notes:129]

[0001069202-13-000008:notes:129]
As of June 30, 2013, we had approximately $1.9 million in total gross unrecognized tax benefits. Of this amount, $1.5 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of June 30, 2013, we had approximately $0.2 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-13-000008:notes:130]
[same as prior period, unchanged from 0001069202-13-000005:notes:131]

[0001069202-13-000008:notes:131]
[same as prior period, unchanged from 0001069202-13-000005:notes:132]

[0001069202-13-000008:notes:132]
On January 2, 2013, the American Taxpayer Relief Act of 2012 was enacted which retroactively reinstated and extended the Federal Research and Development Tax Credit (Federal R&D Tax Credit) from January 1, 2012 to December 31, 2013, in addition to other extenders.  As a result, the Company's income tax provision for the first six months of calendar year 2013 includes a discrete tax benefit that will reduce the annual effective income tax rate.  On a full year basis, the impact to the annual effective income tax rate is not expected to be material.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-13-000008:notes:133]
[same as prior period, unchanged from 0001069202-13-000005:notes:134]

[0001069202-13-000008:notes:134]
[same as prior period, unchanged from 0001069202-13-000005:notes:135]

[0001069202-13-000008:notes:135]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Finished goods | $ | 331.4 |  |  | $ | 258.0 |  |
| Work in process | 14.5 |  |  | 12.0 |  |
| Raw materials and parts | 199.1 |  |  | 180.1 |  |
|  | 545.0 |  |  | 450.1 |  |
| Excess of current cost over last-in, first-out cost | (75.8 | ) |  | (75.3 | ) |
| Total inventories, net | $ | 469.2 |  |  | $ | 374.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-13-000008:notes:136]
[same as prior period, unchanged from 0001069202-13-000005:notes:137]

[0001069202-13-000008:notes:137]
[same as prior period, unchanged from 0001069202-13-000005:notes:138]

[0001069202-13-000008:notes:138]
[same as prior period, unchanged from 0001069202-13-000005:notes:139]

[0001069202-13-000008:notes:139]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-13-000008:notes:140]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-13-000008:notes:141]
[same as prior period, unchanged from 0001069202-13-000005:notes:142]

[0001069202-13-000008:notes:142]
[same as prior period, unchanged from 0001069202-13-000005:notes:143]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-13-000008:notes:143]
[same as prior period, unchanged from 0001069202-13-000005:notes:144]

[0001069202-13-000008:notes:144]
[same as prior period, unchanged from 0001069202-13-000005:notes:145]

[0001069202-13-000008:notes:145]
|  | For the Three Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.2 |  |  | 4.3 |  |  | — |  |  | 0.1 |  |
| Expected return on plan assets | (5.4 | ) |  | (4.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.7 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.3 |  |  | 2.1 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | 0.7 |  |  | 6.3 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 3.1 |  |  | $ | 9.4 |  |  | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0001069202-13-000008:notes:146]
|  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 2.6 |  |  | $ | 2.7 |  |  | $ | — |  |  | $ | 0.3 |  |
| Interest cost | 8.3 |  |  | 8.6 |  |  | 0.1 |  |  | 0.3 |  |
| Expected return on plan assets | (10.6 | ) |  | (9.4 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.2 |  |  | 0.2 |  |  | (1.5 | ) |  | (1.3 | ) |
| Recognized actuarial loss | 4.6 |  |  | 4.3 |  |  | 0.7 |  |  | 0.7 |  |
| Settlements and curtailments | 1.2 |  |  | 6.3 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 6.3 |  |  | $ | 12.7 |  |  | $ | (0.7 | ) |  | $ | — |  |

[0001069202-13-000008:notes:147]
(1) Pension Expense of $0.1 million was included in Loss from discontinued operations for the three and six months ended June 30,  2013.  Pension expense of $6.3 million was included in Loss from discontinued operations for the three and six months ended June 30, 2012.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-13-000008:notes:148]
[same as prior period, unchanged from 0001069202-13-000005:notes:148]

[0001069202-13-000008:notes:149]
As part of the efforts to achieve our strategic priorities of manufacturing and sourcing excellence and expense reduction, we initiated various rationalization actions designed to lower our cost structure.  As more fully explained in Note 15, restructuring charges are not included in our calculation of segment profit (loss).  Below are details of the significant ongoing restructuring action in 2013.

[0001069202-13-000008:notes:150]
[same as prior period, unchanged from 0001069202-13-000005:notes:151]

[0001069202-13-000008:notes:151]
In the fourth quarter of 2008, our Residential Heating & Cooling segment commenced the transition of activities performed at our North American Parts Center in Des Moines, Iowa to other locations, including our North American Distribution Center in Marshalltown, Iowa.  In the first six months of 2013, we recorded expense of $1.4 million with an expected $0.1 million of costs remaining for this restructuring activity.  As of June 30, 2013, we have incurred $7.6 million in costs related to this restructuring activity.

[0001069202-13-000008:notes:152]
[same as prior period, unchanged from 0001069202-13-000005:notes:153]

[0001069202-13-000008:notes:153]
[same as prior period, unchanged from 0001069202-13-000005:notes:154]

[0001069202-13-000008:notes:154]
[same as prior period, unchanged from 0001069202-13-000005:notes:155]

[0001069202-13-000008:notes:155]
|  | Incurred in 2013 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 0.7 |  |  | $ | 11.9 |  |  | $ | 12.2 |  |
| Asset write-offs and accelerated depreciation | 0.4 |  |  | 1.4 |  |  | 1.4 |  |
| Equipment moves | — |  |  | 0.3 |  |  | 0.3 |  |
| Lease termination | — |  |  | 2.6 |  |  | 2.6 |  |
| Other | 1.8 |  |  | 7.3 |  |  | 7.4 |  |
| Total restructuring charges | $ | 2.9 |  |  | $ | 23.5 |  |  | $ | 23.9 |  |

[0001069202-13-000008:notes:156]
[same as prior period, unchanged from 0001069202-13-000005:notes:157]

[0001069202-13-000008:notes:157]
|  | Incurred in 2013 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 1.4 |  |  | $ | 7.6 |  |  | $ | 7.7 |  |
| Commercial Heating & Cooling | 0.5 |  |  | 7.5 |  |  | 7.6 |  |
| Refrigeration | 1.0 |  |  | 8.4 |  |  | 8.6 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total restructuring charges | $ | 2.9 |  |  | $ | 23.5 |  |  | $ | 23.9 |  |

[0001069202-13-000008:notes:158]
[same as prior period, unchanged from 0001069202-13-000005:notes:159]

[0001069202-13-000008:notes:159]
| Description of Reserves | Balance as ofDecember 31, 2012 |  | ChargedtoEarnings |  | CashUtilization |  | Non-CashUtilizationand Other |  | Balance as ofJune 30, 2013 |
| Severance and related expense | $ | 0.7 |  |  | $ | 0.7 |  |  | $ | (0.8 | ) |  | $ | — |  |  | $ | 0.6 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.4 |  |  | — |  |  | (0.4 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | 1.2 |  |  | — |  |  | (1.2 | ) |  | — |  |  | — |  |
| Other | 0.5 |  |  | 1.8 |  |  | (1.4 | ) |  | (0.1 | ) |  | 0.8 |  |
| Total restructuring reserves | $ | 2.4 |  |  | $ | 2.9 |  |  | $ | (3.4 | ) |  | $ | (0.5 | ) |  | $ | 1.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-13-000008:notes:160]
[same as prior period, unchanged from 0001069202-13-000005:notes:161]

[0001069202-13-000008:notes:161]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 476.2 |  |  | $ | 411.9 |  |  | $ | 790.7 |  |  | $ | 684.5 |  |
| Commercial Heating & Cooling | 229.6 |  |  | 221.4 |  |  | 392.6 |  |  | 378.1 |  |
| Refrigeration | 207.3 |  |  | 207.1 |  |  | 398.2 |  |  | 392.2 |  |
|  | $ | 913.1 |  |  | $ | 840.4 |  |  | $ | 1,581.5 |  |  | $ | 1,454.8 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 66.2 |  |  | $ | 42.0 |  |  | $ | 86.7 |  |  | $ | 53.0 |  |
| Commercial Heating & Cooling | 34.6 |  |  | 33.2 |  |  | 45.7 |  |  | 41.5 |  |
| Refrigeration | 25.8 |  |  | 21.2 |  |  | 42.5 |  |  | 35.5 |  |
| Corporate and other | (20.9 | ) |  | (15.4 | ) |  | (39.6 | ) |  | (29.4 | ) |
| Subtotal that includes segment profit and eliminations | 105.7 |  |  | 81.0 |  |  | 135.3 |  |  | 100.6 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Special product quality adjustment | 0.1 |  |  | 0.5 |  |  | (0.1 | ) |  | 0.1 |  |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (2) | 0.8 |  |  | 0.6 |  |  | 2.2 |  |  | (0.9 | ) |
| Restructuring charges | 2.4 |  |  | 0.1 |  |  | 2.9 |  |  | 2.7 |  |
| Interest expense, net | 3.6 |  |  | 4.3 |  |  | 7.0 |  |  | 9.0 |  |
| Other expense (income), net | (0.2 | ) |  | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |
| Income from continuing operations before income taxes | $ | 99.0 |  |  | $ | 75.4 |  |  | $ | 123.4 |  |  | $ | 89.6 |  |

[0001069202-13-000008:notes:162]
[same as prior period, unchanged from 0001069202-13-000005:notes:163]

[0001069202-13-000008:notes:163]
[same as prior period, unchanged from 0001069202-13-000005:notes:164]

[0001069202-13-000008:notes:164]
| • | Items in Losses and other expenses, net (see table note 2 below); |

[0001069202-13-000008:notes:165]
[same as prior period, unchanged from 0001069202-13-000005:notes:166]

[0001069202-13-000008:notes:166]
[same as prior period, unchanged from 0001069202-13-000005:notes:167]

[0001069202-13-000008:notes:167]
[same as prior period, unchanged from 0001069202-13-000005:notes:168]

[0001069202-13-000008:notes:168]
| • | Other expense (income), net |

[0001069202-13-000008:notes:169]
(2) Items in Losses and other expenses, net that are excluded from segment profit include the following:  asset impairment, net change in unrealized gains and/or losses on unsettled futures contracts, special legal contingency charge, and other items


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-13-000008:notes:170]
[same as prior period, unchanged from 0001069202-13-000005:notes:171]

[0001069202-13-000008:notes:171]
[same as prior period, unchanged from 0001069202-13-000005:notes:172]

[0001069202-13-000008:notes:172]
[same as prior period, unchanged from 0001069202-13-000005:notes:173]

[0001069202-13-000008:notes:173]
[same as prior period, unchanged from 0001069202-13-000005:notes:174]

[0001069202-13-000008:notes:174]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | North AmericaSouth America EuropeAsia Pacific |

[0001069202-13-000008:notes:175]
[same as prior period, unchanged from 0001069202-13-000005:notes:176]

[0001069202-13-000008:notes:176]
[same as prior period, unchanged from 0001069202-13-000005:notes:177]

[0001069202-13-000008:notes:177]
[same as prior period, unchanged from 0001069202-13-000005:notes:178]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-13-000008:notes:178]
[same as prior period, unchanged from 0001069202-13-000005:notes:179]

[0001069202-13-000008:notes:179]
Our Board of Directors has authorized a total of $700.0 million towards the repurchase of shares of our common stock (the "Share Repurchase Plans"), including a $300.0 million share repurchase authorization approved in December 2012.  The Share Repurchase Plans do not have an expiration date.  For the six months ended June 30, 2013, we repurchased 0.5 million shares for $33.0 million under the Share Repurchase Plans.  As of June 30, 2013, $338.2 million of share repurchases remain authorized.

[0001069202-13-000008:notes:180]
We also repurchased 0.1 million shares for $5.8 million for the six months ended June 30, 2013 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the vesting of stock-based compensation awards.


## lii:CondensedConsolidatingFinancialStatementsTableTextBlock

[0001069202-13-000008:notes:181]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of June 30, 2013 and December 31, 2012 and for the three and six months ended June 30, 2013 and 2012 are shown on the following pages.

[0001069202-13-000008:notes:182]
[same as prior period, unchanged from 0001069202-13-000005:notes:183]

[0001069202-13-000008:notes:183]
[same as prior period, unchanged from 0001069202-13-000005:notes:184]

[0001069202-13-000008:notes:184]
As of June 30, 2013

[0001069202-13-000008:notes:185]
[same as prior period, unchanged from 0001069202-13-000005:notes:186]

[0001069202-13-000008:notes:186]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.3 |  |  | $ | 20.3 |  |  | $ | 23.7 |  |  | $ | — |  |  | $ | 45.3 |  |
| Accounts and notes receivable, net | — |  |  | 1,082.8 |  |  | 561.5 |  |  | (1,102.0 | ) |  | 542.3 |  |
| Inventories, net | — |  |  | 342.2 |  |  | 137.2 |  |  | (10.2 | ) |  | 469.2 |  |
| Deferred income taxes, net | 4.7 |  |  | 23.0 |  |  | 5.7 |  |  | (1.7 | ) |  | 31.7 |  |
| Other assets | — |  |  | 36.7 |  |  | 82.1 |  |  | (77.4 | ) |  | 41.4 |  |
| Assets of discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total current assets | 6.0 |  |  | 1,505.0 |  |  | 810.2 |  |  | (1,191.3 | ) |  | 1,129.9 |  |
| Property, plant and equipment, net | — |  |  | 231.9 |  |  | 76.8 |  |  | — |  |  | 308.7 |  |
| Goodwill | — |  |  | 131.8 |  |  | 85.8 |  |  | — |  |  | 217.6 |  |
| Deferred income taxes | 0.3 |  |  | 99.8 |  |  | 19.6 |  |  | (5.8 | ) |  | 113.9 |  |
| Other assets, net(1) | 2,293.5 |  |  | 529.6 |  |  | 24.0 |  |  | (2,767.6 | ) |  | 79.5 |  |
| Total assets | $ | 2,299.8 |  |  | $ | 2,498.1 |  |  | $ | 1,016.4 |  |  | $ | (3,964.7 | ) |  | $ | 1,849.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 87.0 |  |  | $ | — |  |  | $ | 53.6 |  |  | $ | (14.7 | ) |  | $ | 125.9 |  |
| Current maturities of long-term debt | — |  |  | 0.3 |  |  | 0.1 |  |  | — |  |  | 0.4 |  |
| Accounts payable | 1,216.1 |  |  | 161.9 |  |  | 86.8 |  |  | (1,091.2 | ) |  | 373.6 |  |
| Accrued expenses | 13.5 |  |  | 183.3 |  |  | 60.6 |  |  | (0.3 | ) |  | 257.1 |  |
| Income taxes payable | (4.1 | ) |  | 49.6 |  |  | 41.0 |  |  | (63.8 | ) |  | 22.7 |  |
| Liabilities of discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total current liabilities | 1,312.5 |  |  | 395.1 |  |  | 242.1 |  |  | (1,170.0 | ) |  | 779.7 |  |
| Long-term debt | 395.0 |  |  | 15.7 |  |  | 91.5 |  |  | (91.4 | ) |  | 410.8 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.9 |  |  | — |  |  | — |  |  | 4.9 |  |
| Pensions | — |  |  | 119.0 |  |  | 18.5 |  |  | — |  |  | 137.5 |  |
| Other liabilities | 1.7 |  |  | 64.2 |  |  | 10.8 |  |  | (7.2 | ) |  | 69.5 |  |
| Total liabilities | 1,709.2 |  |  | 598.9 |  |  | 362.9 |  |  | (1,268.6 | ) |  | 1,402.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 590.6 |  |  | 1,899.2 |  |  | 653.5 |  |  | (2,696.1 | ) |  | 447.2 |  |
| Total liabilities and stockholders' equity | $ | 2,299.8 |  |  | $ | 2,498.1 |  |  | $ | 1,016.4 |  |  | $ | (3,964.7 | ) |  | $ | 1,849.6 |  |

[0001069202-13-000008:notes:187]
[same as prior period, unchanged from 0001069202-13-000005:notes:188]

[0001069202-13-000008:notes:188]
[same as prior period, unchanged from 0001069202-13-000005:notes:189]

[0001069202-13-000008:notes:189]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 13.4 |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net | — |  |  | 1,076.0 |  |  | 427.2 |  |  | (1,129.8 | ) |  | 373.4 |  |
| Inventories, net | — |  |  | 257.3 |  |  | 121.5 |  |  | (4.0 | ) |  | 374.8 |  |
| Deferred income taxes, net | — |  |  | 22.9 |  |  | 6.3 |  |  | (1.7 | ) |  | 27.5 |  |
| Other assets | (0.6 | ) |  | 23.8 |  |  | 97.5 |  |  | (59.7 | ) |  | 61.0 |  |
| Assets of discontinued operations | — |  |  | 21.2 |  |  | 77.4 |  |  | — |  |  | 98.6 |  |
| Total current assets | 0.4 |  |  | 1,414.6 |  |  | 767.3 |  |  | (1,195.2 | ) |  | 987.1 |  |
| Property, plant and equipment, net | — |  |  | 239.7 |  |  | 58.5 |  |  | — |  |  | 298.2 |  |
| Goodwill | — |  |  | 131.8 |  |  | 92.0 |  |  | — |  |  | 223.8 |  |
| Deferred income taxes | — |  |  | 87.8 |  |  | 20.8 |  |  | (5.8 | ) |  | 102.8 |  |
| Other assets, net(1) | 2,176.3 |  |  | 488.5 |  |  | 30.3 |  |  | (2,615.1 | ) |  | 80.0 |  |
| Total assets | $ | 2,176.7 |  |  | $ | 2,362.4 |  |  | $ | 968.9 |  |  | $ | (3,816.1 | ) |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 101.9 |  |  | $ | — |  |  | $ | (51.0 | ) |  | $ | (16.0 | ) |  | $ | 34.9 |  |
| Current maturities of long-term debt | — |  |  | 0.5 |  |  | 0.2 |  |  | — |  |  | 0.7 |  |
| Accounts payable | 1,178.0 |  |  | 133.7 |  |  | 92.0 |  |  | (1,119.0 | ) |  | 284.7 |  |
| Accrued expenses | 2.5 |  |  | 196.6 |  |  | 60.8 |  |  | (0.3 | ) |  | 259.6 |  |
| Income taxes payable | (27.3 | ) |  | 35.1 |  |  | 38.5 |  |  | (41.8 | ) |  | 4.5 |  |
| Liabilities of discontinued operations | — |  |  | 42.3 |  |  | 12.9 |  |  | — |  |  | 55.2 |  |
| Total current liabilities | 1,255.1 |  |  | 408.2 |  |  | 153.4 |  |  | (1,177.1 | ) |  | 639.6 |  |
| Long-term debt | 335.0 |  |  | 15.6 |  |  | 98.7 |  |  | (98.3 | ) |  | 351.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 6.1 |  |  | — |  |  | — |  |  | 6.1 |  |
| Pensions | — |  |  | 114.7 |  |  | 19.7 |  |  | — |  |  | 134.4 |  |
| Other liabilities | 0.5 |  |  | 60.1 |  |  | 10.6 |  |  | (7.2 | ) |  | 64.0 |  |
| Total liabilities | 1,590.6 |  |  | 604.7 |  |  | 282.4 |  |  | (1,282.6 | ) |  | 1,195.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 586.1 |  |  | 1,757.7 |  |  | 686.5 |  |  | (2,533.5 | ) |  | 496.8 |  |
| Total liabilities and stockholders' equity | $ | 2,176.7 |  |  | $ | 2,362.4 |  |  | $ | 968.9 |  |  | $ | (3,816.1 | ) |  | $ | 1,691.9 |  |

[0001069202-13-000008:notes:190]
[same as prior period, unchanged from 0001069202-13-000005:notes:191]

[0001069202-13-000008:notes:191]
For the Three Months Ended June 30, 2013

[0001069202-13-000008:notes:192]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 795.4 |  |  | $ | 208.2 |  |  | $ | (90.5 | ) |  | $ | 913.1 |  |
| Cost of goods sold | 0.1 |  |  | 575.0 |  |  | 169.9 |  |  | (85.9 | ) |  | 659.1 |  |
| Gross profit | (0.1 | ) |  | 220.4 |  |  | 38.3 |  |  | (4.6 | ) |  | 254.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 117.6 |  |  | 33.7 |  |  | — |  |  | 151.3 |  |
| Losses and other expenses, net | 2.0 |  |  | (0.3 | ) |  | 0.4 |  |  | — |  |  | 2.1 |  |
| Restructuring charges | — |  |  | 1.2 |  |  | 1.2 |  |  | — |  |  | 2.4 |  |
| Income from equity method investments | (63.7 | ) |  | 6.5 |  |  | (3.4 | ) |  | 56.4 |  |  | (4.2 | ) |
| Operational income from continuing operations | 61.6 |  |  | 95.4 |  |  | 6.4 |  |  | (61.0 | ) |  | 102.4 |  |
| Interest expense, net | 3.7 |  |  | (0.6 | ) |  | 0.5 |  |  | — |  |  | 3.6 |  |
| Other expense, net | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Income from continuing operations before income taxes | 57.9 |  |  | 96.0 |  |  | 6.1 |  |  | (61.0 | ) |  | 99.0 |  |
| Provision for income taxes | (2.0 | ) |  | 35.3 |  |  | 3.1 |  |  | (1.7 | ) |  | 34.7 |  |
| Income from continuing operations | 59.9 |  |  | 60.7 |  |  | 3.0 |  |  | (59.3 | ) |  | 64.3 |  |
| Loss from discontinued operations | — |  |  | 25.4 |  |  | (25.4 | ) |  | — |  |  | — |  |
| Net income | $ | 59.9 |  |  | $ | 86.1 |  |  | $ | (22.4 | ) |  | $ | (59.3 | ) |  | $ | 64.3 |  |
| Other comprehensive loss | $ | (4.2 | ) |  | $ | 0.3 |  |  | $ | 38.7 |  |  | $ | (66.3 | ) |  | $ | (31.5 | ) |

[0001069202-13-000008:notes:193]
For the Six Months Ended June 30, 2013

[0001069202-13-000008:notes:194]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,316.1 |  |  | $ | 397.7 |  |  | $ | (132.3 | ) |  | $ | 1,581.5 |  |
| Cost of goods sold | 0.1 |  |  | 979.4 |  |  | 313.2 |  |  | (127.2 | ) |  | 1,165.5 |  |
| Gross profit | (0.1 | ) |  | 336.7 |  |  | 84.5 |  |  | (5.1 | ) |  | 416.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 220.3 |  |  | 66.7 |  |  | — |  |  | 287.0 |  |
| Losses and other expenses, net | 2.4 |  |  | 0.1 |  |  | 0.7 |  |  | — |  |  | 3.2 |  |
| Restructuring charges | — |  |  | 1.5 |  |  | 1.4 |  |  | — |  |  | 2.9 |  |
| Income from equity method investments | (71.6 | ) |  | 8.9 |  |  | (6.2 | ) |  | 61.5 |  |  | (7.4 | ) |
| Operational income from continuing operations | 69.1 |  |  | 105.9 |  |  | 21.9 |  |  | (66.6 | ) |  | 130.3 |  |
| Interest expense, net | 7.0 |  |  | (1.1 | ) |  | 1.1 |  |  | — |  |  | 7.0 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 62.1 |  |  | 107.0 |  |  | 20.9 |  |  | (66.6 | ) |  | 123.4 |  |
| Provision for income taxes | (3.3 | ) |  | 40.1 |  |  | 8.4 |  |  | (1.9 | ) |  | 43.3 |  |
| Income from continuing operations | 65.4 |  |  | 66.9 |  |  | 12.5 |  |  | (64.7 | ) |  | 80.1 |  |
| Loss from discontinued operations | — |  |  | 17.6 |  |  | (25.4 | ) |  | — |  |  | (7.8 | ) |
| Net income | $ | 65.4 |  |  | $ | 84.5 |  |  | $ | (12.9 | ) |  | $ | (64.7 | ) |  | $ | 72.3 |  |
| Other comprehensive loss | $ | (7.6 | ) |  | $ | 1.1 |  |  | $ | (7.3 | ) |  | $ | (67.0 | ) |  | $ | (80.8 | ) |

[0001069202-13-000008:notes:195]
For the Three Months Ended June 30, 2012

[0001069202-13-000008:notes:196]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 688.0 |  |  | $ | 206.4 |  |  | $ | (54.0 | ) |  | $ | 840.4 |  |
| Cost of goods sold | 0.1 |  |  | 526.1 |  |  | 160.0 |  |  | (53.9 | ) |  | 632.3 |  |
| Gross profit | (0.1 | ) |  | 161.9 |  |  | 46.4 |  |  | (0.1 | ) |  | 208.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 98.9 |  |  | 31.7 |  |  | 0.1 |  |  | 130.7 |  |
| Losses and other expenses, net | (0.6 | ) |  | 1.3 |  |  | 0.6 |  |  | 0.1 |  |  | 1.4 |  |
| Restructuring charges | — |  |  | (0.1 | ) |  | 0.2 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (50.3 | ) |  | (3.7 | ) |  | (3.1 | ) |  | 53.2 |  |  | (3.9 | ) |
| Operational income from continuing operations | 50.8 |  |  | 65.5 |  |  | 17.0 |  |  | (53.5 | ) |  | 79.8 |  |
| Interest expense, net | 4.4 |  |  | (0.7 | ) |  | 0.6 |  |  | — |  |  | 4.3 |  |
| Other expense, net | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from continuing operations before income taxes | 46.4 |  |  | 66.2 |  |  | 16.3 |  |  | (53.5 | ) |  | 75.4 |  |
| Provision for income taxes | (1.4 | ) |  | 22.4 |  |  | 3.9 |  |  | 1.0 |  |  | 25.9 |  |
| Income from continuing operations | 47.8 |  |  | 43.8 |  |  | 12.4 |  |  | (54.5 | ) |  | 49.5 |  |
| Loss from discontinued operations | — |  |  | (2.9 | ) |  | (1.9 | ) |  | — |  |  | (4.8 | ) |
| Net income | $ | 47.8 |  |  | $ | 40.9 |  |  | $ | 10.5 |  |  | $ | (54.5 | ) |  | $ | 44.7 |  |
| Other comprehensive loss | $ | (4.5 | ) |  | $ | (2.9 | ) |  | $ | (21.1 | ) |  | $ | 3.5 |  |  | $ | (25.0 | ) |

[0001069202-13-000008:notes:197]
For the Six Months Ended June 30, 2012

[0001069202-13-000008:notes:198]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,160.0 |  |  | $ | 395.9 |  |  | $ | (101.1 | ) |  | $ | 1,454.8 |  |
| Cost of goods sold | 0.1 |  |  | 902.0 |  |  | 304.5 |  |  | (100.8 | ) |  | 1,105.8 |  |
| Gross profit | (0.1 | ) |  | 258.0 |  |  | 91.4 |  |  | (0.3 | ) |  | 349.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 187.3 |  |  | 66.5 |  |  | 0.1 |  |  | 253.9 |  |
| Losses and other expenses, net | (2.2 | ) |  | 0.6 |  |  | 1.5 |  |  | 0.1 |  |  | — |  |
| Restructuring charges | — |  |  | 2.5 |  |  | 0.2 |  |  | — |  |  | 2.7 |  |
| Income from equity method investments | (43.5 | ) |  | (1.6 | ) |  | (5.0 | ) |  | 43.8 |  |  | (6.3 | ) |
| Operational income from continuing operations | 45.6 |  |  | 69.2 |  |  | 28.2 |  |  | (44.3 | ) |  | 98.7 |  |
| Interest expense, net | 8.8 |  |  | (1.2 | ) |  | 1.4 |  |  | — |  |  | 9.0 |  |
| Other expense, net | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from continuing operations before income taxes | 36.8 |  |  | 70.4 |  |  | 26.7 |  |  | (44.3 | ) |  | 89.6 |  |
| Provision for income taxes | (2.4 | ) |  | 25.0 |  |  | 6.7 |  |  | 1.5 |  |  | 30.8 |  |
| Income from continuing operations | 39.2 |  |  | 45.4 |  |  | 20.0 |  |  | (45.8 | ) |  | 58.8 |  |
| Loss from discontinued operations | — |  |  | (13.7 | ) |  | (6.5 | ) |  | — |  |  | (20.2 | ) |
| Net income | $ | 39.2 |  |  | $ | 31.7 |  |  | $ | 13.5 |  |  | $ | (45.8 | ) |  | $ | 38.6 |  |
| Other comprehensive loss | $ | 2.3 |  |  | $ | (0.2 | ) |  | $ | (9.0 | ) |  | $ | 4.4 |  |  | $ | (2.5 | ) |

[0001069202-13-000008:notes:199]
[same as prior period, unchanged from 0001069202-13-000005:notes:196]

[0001069202-13-000008:notes:200]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (15.8 | ) |  | $ | 70.3 |  |  | $ | (142.8 | ) |  | $ | — |  |  | $ | (88.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Purchases of property, plant and equipment | — |  |  | (17.5 | ) |  | (5.9 | ) |  | — |  |  | (23.4 | ) |
| Net proceeds from sale of businesses | 1.5 |  |  | — |  |  | 3.3 |  |  | — |  |  | 4.8 |  |
| Net cash used in discontinued operations | — |  |  | (0.1 | ) |  | — |  |  | — |  |  | (0.1 | ) |
| Net cash used in investing activities | 1.5 |  |  | (17.6 | ) |  | (2.6 | ) |  | — |  |  | (18.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 270.0 |  |  | — |  |  | 270.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (180.0 | ) |  | — |  |  | (180.0 | ) |
| Long-term debt payments | — |  |  | (0.3 | ) |  | (0.2 | ) |  | — |  |  | (0.5 | ) |
| Borrowings from revolving credit facility | 700.5 |  |  | — |  |  | — |  |  | — |  |  | 700.5 |  |
| Payments on revolving credit facility | (640.5 | ) |  | — |  |  | — |  |  | — |  |  | (640.5 | ) |
| Proceeds from employee stock purchases | 1.0 |  |  | — |  |  | — |  |  | — |  |  | 1.0 |  |
| Repurchases of common stock | (33.0 | ) |  | — |  |  | — |  |  | — |  |  | (33.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (5.8 | ) |  | — |  |  | — |  |  | — |  |  | (5.8 | ) |
| Excess tax benefits related to share-based payments | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |
| Intercompany debt | (27.0 | ) |  | 9.7 |  |  | 17.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | 26.1 |  |  | (55.2 | ) |  | 29.1 |  |  | — |  |  | — |  |
| Cash dividends paid | (10.1 | ) |  | — |  |  | — |  |  | — |  |  | (10.1 | ) |
| Net cash provided by financing activities | 14.6 |  |  | (45.8 | ) |  | 137.8 |  |  | — |  |  | 106.6 |  |
| Decrease in cash and cash equivalents | 0.3 |  |  | 6.9 |  |  | (7.6 | ) |  | — |  |  | (0.4 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (6.1 | ) |  | — |  |  | (6.1 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of period | $ | 1.3 |  |  | $ | 20.3 |  |  | $ | 23.7 |  |  | $ | — |  |  | $ | 45.3 |  |

[0001069202-13-000008:notes:201]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 34.6 |  |  | $ | (51.6 | ) |  | $ | 6.4 |  |  | $ | — |  |  | $ | (10.6 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (13.9 | ) |  | (2.5 | ) |  | — |  |  | (16.4 | ) |
| Net proceeds from sale of businesses | — |  |  | 7.2 |  |  | — |  |  | — |  |  | 7.2 |  |
| Net cash used in discontinued operations | — |  |  | (0.4 | ) |  | — |  |  | — |  |  | (0.4 | ) |
| Net cash used in investing activities | — |  |  | (7.0 | ) |  | (2.5 | ) |  | — |  |  | (9.5 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 9.9 |  |  | — |  |  | 9.9 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 310.0 |  |  | — |  |  | 310.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (310.0 | ) |  | — |  |  | (310.0 | ) |
| Long-term debt payments | — |  |  | (0.4 | ) |  | (0.2 | ) |  | — |  |  | (0.6 | ) |
| Borrowings from revolving credit facility | 526.0 |  |  | — |  |  | — |  |  | — |  |  | 526.0 |  |
| Payments on revolving credit facility | (471.5 | ) |  | — |  |  | — |  |  | — |  |  | (471.5 | ) |
| Proceeds from employee stock purchases | 0.2 |  |  | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Payments of deferred financing costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (2.6 | ) |  | — |  |  | — |  |  | — |  |  | (2.6 | ) |
| Excess tax benefits related to share-based payments | 1.2 |  |  | — |  |  | — |  |  | — |  |  | 1.2 |  |
| Intercompany debt | 0.8 |  |  | 0.4 |  |  | (1.2 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (70.4 | ) |  | 73.1 |  |  | (2.7 | ) |  | — |  |  | — |  |
| Cash dividends paid | (18.3 | ) |  | — |  |  | — |  |  | — |  |  | (18.3 | ) |
| Net cash provided by financing activities | (34.6 | ) |  | 73.1 |  |  | 5.8 |  |  | — |  |  | 44.3 |  |
| Increase in cash and cash equivalents | — |  |  | 14.5 |  |  | 9.7 |  |  | — |  |  | 24.2 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 9.7 |  |  | 34.3 |  |  | — |  |  | 45.0 |  |
| Cash and cash equivalents, end of period | $ | 1.0 |  |  | $ | 24.2 |  |  | $ | 43.9 |  |  | $ | — |  |  | $ | 69.1 |  |


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0001069202-13-000008:notes:202]
[same as prior period, unchanged from 0001069202-13-000005:notes:199]

[0001069202-13-000008:notes:203]
[same as prior period, unchanged from 0001069202-13-000005:notes:200]

[0001069202-13-000008:notes:204]
[same as prior period, unchanged from 0001069202-13-000005:notes:201]

[0001069202-13-000008:notes:205]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd.  The primary subsidiary for the U.S. Service Experts business had previously been included as a "Guarantor Subsidiary" and the Canada Service Experts subsidiary had previously been included as a "Non-Guarantor Subsidiary."  As of June 30, 2013, the U.S. and Canada Service Experts businesses are included in discontinued operations of the condensed consolidating financial statements.

[0001069202-13-000008:notes:206]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  Intercompany account balances have been included in Accounts and notes receivable, Other assets (Current), Other assets, net, Short-term debt, Accounts payable, and Long-term debt line items of the Parent, Guarantor and Non-Guarantor balance sheets.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.
