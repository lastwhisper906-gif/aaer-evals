# LII note change history — 0001069202-13-000005 → 0001069202-13-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-07-22):
[0001069202-13-000008:note_history:1]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas (the "Lake Park Renewal") for a term of approximately six years through March 1, 2019.  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease.
  (was, 2013-04-22, similarity 0.9942):
[0001069202-13-000005:note_history:1]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas (the "Lake Park Renewal") for a term of approximately six years through March 1, 2019.  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease.

- changed (2013-07-22):
[0001069202-13-000008:note_history:2]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Domestic Credit Facility.  We were in compliance with those covenants as of June 30, 2013.
  (was, 2013-04-22, similarity 0.9904):
[0001069202-13-000005:note_history:2]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Domestic Credit Facility.  We were in compliance with those covenants as of March 31, 2013.

- changed (2013-07-22):
[0001069202-13-000008:note_history:3]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Accrued expenses | $ | 23.5 |  |  | $ | 25.1 |  |
| Other liabilities | 50.2 |  |  | 46.8 |  |
|  | $ | 73.7 |  |  | $ | 71.9 |  |
  (was, 2013-04-22, similarity 0.9697):
[0001069202-13-000005:note_history:3]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Accrued expenses | $ | 24.2 |  |  | $ | 25.1 |  |
| Other liabilities | 49.6 |  |  | 46.8 |  |
|  | $ | 73.8 |  |  | $ | 71.9 |  |

- changed (2013-07-22):
[0001069202-13-000008:note_history:4]
The changes in total product warranty liabilities related to continuing operations for the six months ended June 30, 2013 were as follows (in millions):
  (was, 2013-04-22, similarity 0.9428):
[0001069202-13-000005:note_history:4]
The changes in total product warranty liabilities related to continuing operations for the three months ended March 31, 2013 were as follows (in millions):

- changed (2013-07-22):
[0001069202-13-000008:note_history:5]
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (9.2 | ) |
| Changes resulting from issuance of new warranties | 14.7 |  |
| Changes in estimates associated with pre-existing liabilities | (3.2 | ) |
| Changes in foreign currency translation rates and other | (0.5 | ) |
| Total warranty liability as of June 30, 2013 | $ | 73.7 |  |
  (was, 2013-04-22, similarity 0.7919):
[0001069202-13-000005:note_history:5]
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (3.9 | ) |
| Changes resulting from issuance of new warranties | 6.1 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Changes in foreign currency translation rates and other | (0.3 | ) |
| Total warranty liability as of March 31, 2013 | $ | 73.8 |  |

- added (2013-07-22):
[0001069202-13-000008:note_history:6]
We evaluate our heating, ventilation and air conditioning ("HVAC") warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.  As a result of the second quarter 2013 re-evaluation, we decreased our warranty liability by $3.2 million and recorded the related expense in Cost of Goods Sold in the Consolidated Statements of Operations.  The adjustment from the second quarter re-evaluation is the principal change in the estimate associated with pre-existing liabilities shown in the table above.

- changed (2013-07-22):
[0001069202-13-000008:note_history:7]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material changes in the circumstances that affect our product warranties since our latest fiscal year-end.
  (was, 2013-04-22, similarity 0.9787):
[0001069202-13-000005:note_history:7]
We incur the risk of liability claims for the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material changes in the circumstances that affect our product warranties since our latest fiscal year-end.

- changed (2013-07-22):
[0001069202-13-000008:note_history:8]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the six months ended June 30, 2013 were as follows (in millions):
  (was, 2013-04-22, similarity 0.9719):
[0001069202-13-000005:note_history:8]
We identified non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the three months ended March 31, 2013 were as follows (in millions):

- changed (2013-07-22):
[0001069202-13-000008:note_history:9]
| Total accrued product quality issue as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid in 2013 | (0.7 | ) |
| Total accrued product quality issue as of June 30, 2013 | $ | 6.0 |  |
  (was, 2013-04-22, similarity 0.9615):
[0001069202-13-000005:note_history:9]
| Total accrued product quality issue as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims | (0.6 | ) |
| Total accrued product quality issue as of March 31, 2013 | $ | 6.1 |  |

- added (2013-07-22):
[0001069202-13-000008:note_history:10]
Some of these claims and lawsuits allege health problems resulting from exposure to asbestos.  For the three months ended June 30, 2013, we recorded income, net of insurance recoveries, of $0.1 million and for the six months ended June 30, 2013, we recorded charges, net of insurance recoveries, of $0.5 million related to asbestos matters.  These charges were recorded in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operation.  We also expect that additional claims will be brought against us in the future.  However, the Company believes our liability exposure from those additional future claims cannot currently be estimated because of numerous uncertainties, including the number of such claims and lawsuits and the costs of defending and settling them, possible adverse judgments in amounts greater than previously experienced, and possible changes in the laws and process governing the compensation of asbestos claimants.

- removed (2013-07-22):
[0001069202-13-000005:note_history:11]
We evaluate our heating, ventilation and air conditioning ("HVAC") warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.

- removed (2013-07-22):
[0001069202-13-000005:note_history:12]
Some of these claims and lawsuits allege health problems resulting from exposure to asbestos and we expect that additional claims will be brought against us in the future. However, our liability exposure from those additional future claims cannot be estimated because of numerous uncertainties, including the number of such claims and lawsuits and the costs of defending and settling them, possible adverse judgments in amounts greater than previously experienced, and possible changes in the laws and process governing the compensation of asbestos claimants.  In the first quarter of 2013, we recorded charges of $0.6 million, net of insurance recoveries, related to asbestos matters in Selling, general and administrative expenses in the accompanying Consolidated Statement of Operation.


## us-gaap:ProductLiabilityContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-07-22):
[0001069202-13-000008:note_history:13]
The changes in the accrued product quality issues for the six months ended June 30, 2013 were as follows (in millions):
  (was, 2013-04-22, similarity 0.9264):
[0001069202-13-000005:note_history:13]
The changes in the accrued product quality issues for the three months ended March 31, 2013 were as follows (in millions):

- changed (2013-07-22):
[0001069202-13-000008:note_history:14]
| Total accrued product quality issue as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid in 2013 | (0.7 | ) |
| Total accrued product quality issue as of June 30, 2013 | $ | 6.0 |  |
  (was, 2013-04-22, similarity 0.9615):
[0001069202-13-000005:note_history:14]
| Total accrued product quality issue as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims | (0.6 | ) |
| Total accrued product quality issue as of March 31, 2013 | $ | 6.1 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-07-22):
[0001069202-13-000008:note_history:15]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2013, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2013 and 2012, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2013 and 2012, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2013 and 2012 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2012. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2013-04-22, similarity 0.8822):
[0001069202-13-000005:note_history:15]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2013, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2013 and 2012, the unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2013 and 2012, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2013 and 2012 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2012. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2013-07-22):
[0001069202-13-000008:note_history:16]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.
  (was, 2013-04-22, similarity 0.9993):
[0001069202-13-000005:note_history:16]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

- changed (2013-07-22):
[0001069202-13-000008:note_history:17]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.
  (was, 2013-04-22, similarity 0.9886):
[0001069202-13-000005:note_history:17]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency, and commodity markets combined to increase the uncertainty inherent in such estimates and assumptions.  As future events and their effects cannot be determined with precision, actual results could differ significantly from these estimates.  Changes in those estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-07-22):
[0001069202-13-000008:note_history:18]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.48 | % |  | 1.46 | % |
  (was, 2013-04-22, similarity 0.9538):
[0001069202-13-000005:note_history:18]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.20 | % |  | 1.46 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-07-22):
[0001069202-13-000008:note_history:19]
The following table summarizes our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):
  (was, 2013-04-22, similarity 0.9933):
[0001069202-13-000005:note_history:19]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

- added (2013-07-22):
[0001069202-13-000008:note_history:20]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 120.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 5.9 |  |  | 4.9 |  |
| Total short-term debt | $ | 125.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.4 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 195.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 410.8 |  |  | $ | 351.0 |  |
| Total debt | $ | 537.1 |  |  | $ | 386.6 |  |

- changed (2013-07-22):
[0001069202-13-000008:note_history:21]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $5.9 million and $4.9 million of foreign obligations as of June 30, 2013 and December 31, 2012, respectively, that are primarily borrowings under non-committed facilities.
  (was, 2013-04-22, similarity 0.9736):
[0001069202-13-000005:note_history:21]
Through several of our foreign subsidiaries, we have available to us foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $6.0 million and $4.9 million of foreign obligations as of March 31, 2013 and December 31, 2012, respectively, that are primarily borrowings under non-committed facilities.

- changed (2013-07-22):
[0001069202-13-000008:note_history:22]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 120.0 |  |  | 30.0 |  |
| Remaining amount available | $ | 40.0 |  |  | $ | 130.0 |  |
  (was, 2013-04-22, similarity 0.9811):
[0001069202-13-000005:note_history:22]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 20.0 |  |  | 30.0 |  |
| Remaining amount available | $ | 140.0 |  |  | $ | 130.0 |  |

- changed (2013-07-22):
[0001069202-13-000008:note_history:23]
Under the ASP, we pay certain discount fees to use the program and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates for June 30, 2013 and December 31, 2012 were 0.82% and 0.85%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):
  (was, 2013-04-22, similarity 0.9921):
[0001069202-13-000005:note_history:23]
Under the ASP, we pay certain discount fees to use the program and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates for March 31, 2013 and for December 31, 2012 were 0.84% and 0.85%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest Expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):

- changed (2013-07-22):
[0001069202-13-000008:note_history:24]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.6 |  |
  (was, 2013-04-22, similarity 0.7291):
[0001069202-13-000005:note_history:24]
|  | For the Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.3 |  |

- changed (2013-07-22):
[0001069202-13-000008:note_history:25]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2013, we were in compliance with all covenant requirements.
  (was, 2013-04-22, similarity 0.9935):
[0001069202-13-000005:note_history:25]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2013, we were in compliance with all covenant requirements.

- added (2013-07-22):
[0001069202-13-000008:note_history:26]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $195.0 million and $50.0 million committed to standby letters of credit as of June 30, 2013. Subject to covenant limitations, $405.0 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2013-07-22):
[0001069202-13-000008:note_history:27]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.48 | % |  | 1.46 | % |
  (was, 2013-04-22, similarity 0.9538):
[0001069202-13-000005:note_history:27]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.20 | % |  | 1.46 | % |

- changed (2013-07-22):
[0001069202-13-000008:note_history:28]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2013, we were in compliance with all covenant requirements.
  (was, 2013-04-22, similarity 0.9915):
[0001069202-13-000005:note_history:28]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2013, we were in compliance with all covenant requirements.

- changed (2013-07-22):
[0001069202-13-000008:note_history:29]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2013, we were in compliance with all covenant requirements.
  (was, 2013-04-22, similarity 0.9947):
[0001069202-13-000005:note_history:29]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.   As of March 31, 2013, we were in compliance with all covenant requirements.

- removed (2013-07-22):
[0001069202-13-000005:note_history:30]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 20.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 6.0 |  |  | 4.9 |  |
| Total short-term debt | $ | 26.0 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.6 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 274.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 489.8 |  |  | $ | 351.0 |  |
| Total debt | $ | 516.4 |  |  | $ | 386.6 |  |

- removed (2013-07-22):
[0001069202-13-000005:note_history:31]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $274.0 million and $49.9 million committed to standby letters of credit as of March 31, 2013. Subject to covenant limitations, $326.1 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-07-22):
[0001069202-13-000008:note_history:32]
The following table summarizes our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):
  (was, 2013-04-22, similarity 0.9933):
[0001069202-13-000005:note_history:32]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

- added (2013-07-22):
[0001069202-13-000008:note_history:33]
|  | As of June 30, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 120.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 5.9 |  |  | 4.9 |  |
| Total short-term debt | $ | 125.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.4 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 195.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 410.8 |  |  | $ | 351.0 |  |
| Total debt | $ | 537.1 |  |  | $ | 386.6 |  |

- removed (2013-07-22):
[0001069202-13-000005:note_history:34]
|  | As of March 31, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 20.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 6.0 |  |  | 4.9 |  |
| Total short-term debt | $ | 26.0 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.6 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 274.0 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 489.8 |  |  | $ | 351.0 |  |
| Total debt | $ | 516.4 |  |  | $ | 386.6 |  |
