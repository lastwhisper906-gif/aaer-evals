# LII MD&A — 0001069202-13-000008


## mdna

[0001069202-13-000008:mdna:1]
[same as prior period, unchanged from 0001069202-13-000005:mdna:1]

[0001069202-13-000008:mdna:2]
[same as prior period, unchanged from 0001069202-13-000005:mdna:2]

[0001069202-13-000008:mdna:3]
[same as prior period, unchanged from 0001069202-13-000005:mdna:3]

[0001069202-13-000008:mdna:4]
[same as prior period, unchanged from 0001069202-13-000005:mdna:4]

[0001069202-13-000008:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned parts and supplies stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  Also, a substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-13-000008:mdna:6]
[same as prior period, unchanged from 0001069202-13-000005:mdna:6]

[0001069202-13-000008:mdna:7]
[same as prior period, unchanged from 0001069202-13-000005:mdna:7]

[0001069202-13-000008:mdna:8]
In the second quarter of 2013, the Residential Heating & Cooling segment continued to lead our overall operational performance with a 16% increase in net sales and a $24 million increase in segment profit compared to the second quarter of 2012.  The primary growth driver for this segment was industry growth in our new construction and replacement businesses.  Our Commercial Heating & Cooling segment also performed well in the second quarter of 2013 with a 4% increase in net sales and $1 million in increased segment profit compared to the second quarter of 2012.  This segment's profits were up largely due to modest volume increases and material cost savings.  Sales in our Refrigeration segment were flat while segment profit increased $5 million compared to the second quarter of 2012 primarily due to growth in our Australia refrigerant distribution business.

[0001069202-13-000008:mdna:9]
On a consolidated basis, our product profit margins improved quarter over quarter due to volume increases primarily in our Residential Heating & Cooling segment, favorable price and mix across all of our segments and overall favorable commodity pricing on raw materials.  We continue to manage our cost structure by utilizing a combination of commodity hedging and controllable product cost management initiatives.

[0001069202-13-000008:mdna:10]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer") in an all cash transaction for proceeds, excluding transaction costs, of $10.4 million.  The proceeds include a determinable working capital adjustment of $3.8 million expected to be received in the third quarter of 2013.  The $1.7 million gain on sale of the business and the operating results for the business through March 22, 2013 are presented in discontinued operations.  The Company also entered into a two-year equipment and parts supply agreement with the Buyer.

[0001069202-13-000008:mdna:11]
[same as prior period, unchanged from 0001069202-13-000005:mdna:12]

[0001069202-13-000008:mdna:12]
| • | Net sales in the second quarter increased $73 million, or 9%, from $840 million in 2012 to $913 million in 2013. Foreign currency exchange rates were neutral to net sales quarter over quarter. |

[0001069202-13-000008:mdna:13]
| • | Operational income from continuing operations for the second quarter of 2013 was $102 million compared to $80 million for the same quarter of 2012. The increase was primarily due to higher volumes, higher gross profit margins from favorable price and mix and product cost savings, partially offset by higher freight and distribution costs and higher incentive compensation due to overall improved operating results in 2013. |

[0001069202-13-000008:mdna:14]
| • | Net income for the second quarter of 2013 was $64 million compared to $45 million in the second quarter of 2012. |

[0001069202-13-000008:mdna:15]
| • | Diluted earnings per share from continuing operations were $1.26 per share in the second quarter of 2013 compared to $0.96 per share in the second quarter of 2012. |

[0001069202-13-000008:mdna:16]
| • | We used $88 million of cash for operating activities in the first half of 2013 compared to $11 million in the first half of 2012. |

[0001069202-13-000008:mdna:17]
Second Quarter of 2013 Compared to Second Quarter of 2012 - Consolidated Results

[0001069202-13-000008:mdna:18]
[same as prior period, unchanged from 0001069202-13-000005:mdna:19]

[0001069202-13-000008:mdna:19]
|  | For the Three Months Ended June 30, |
|  | Dollars |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net sales | $ | 913.1 |  |  | $ | 840.4 |  |  | 8.7 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 659.1 |  |  | 632.3 |  |  | (4.2 | ) |  | 72.2 |  |  | 75.2 |  |
| Gross profit | 254.0 |  |  | 208.1 |  |  | 22.1 |  |  | 27.8 |  |  | 24.8 |  |
| Selling, general and administrative expenses | 151.3 |  |  | 130.7 |  |  | (15.8 | ) |  | 16.6 |  |  | 15.6 |  |
| Losses and other expenses, net | 2.1 |  |  | 1.4 |  |  | 50.0 |  |  | 0.2 |  |  | 0.2 |  |
| Restructuring charges | 2.4 |  |  | 0.1 |  |  | (2,300.0 | ) |  | 0.3 |  |  | — |  |
| Income from equity method investments | (4.2 | ) |  | (3.9 | ) |  | 7.7 |  |  | (0.5 | ) |  | (0.5 | ) |
| Operational income from continuing operations | $ | 102.4 |  |  | $ | 79.8 |  |  | 28.3 | % |  | 11.2 | % |  | 9.5 | % |

[0001069202-13-000008:mdna:20]
[same as prior period, unchanged from 0001069202-13-000005:mdna:22]

[0001069202-13-000008:mdna:21]
Net sales increased 9% in the second quarter of 2013 compared to the second quarter of 2012.  Our sales volume was up 7% and price and mix were up 2% from the comparable period.  The increase in volume was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.

[0001069202-13-000008:mdna:22]
[same as prior period, unchanged from 0001069202-13-000005:mdna:24]

[0001069202-13-000008:mdna:23]
Gross profit margins improved 300 basis points to 27.8% in the second quarter of 2013 compared to 24.8% in the second quarter of 2012.  Improved price and mix contributed 180 basis points to profit margin, improved commodity and non-commodity product costs contributed a collective 200 basis points and a favorable warranty accrual adjustment contributed 20 basis points.  Partially offsetting these increases were approximately 100 basis points of higher freight and distribution costs.

[0001069202-13-000008:mdna:24]
[same as prior period, unchanged from 0001069202-13-000005:mdna:27]

[0001069202-13-000008:mdna:25]
Selling, General & Administrative (“SG&A”) expenses increased by $21 million in the second quarter of 2013 compared to the second quarter of 2012.  As a percentage of net sales, SG&A expenses increased 100 basis points from 15.6% to 16.6% in the

[0001069202-13-000008:mdna:26]
same periods.  The largest driver of the increase in SG&A expenses was higher incentive compensation due to overall improved operating results in the second quarter of 2013.

[0001069202-13-000008:mdna:27]
Losses and Other Expenses, Net

[0001069202-13-000008:mdna:28]
Losses and other expenses, net for second quarters of 2013 and 2012 included the following (in millions):

[0001069202-13-000008:mdna:29]
|  | For the Three Months Ended June 30, |
|  | 2013 |  | 2012 |
| Realized loss on settled future contracts | $ | 0.4 |  |  | $ | 0.7 |  |
| Foreign currency exchange loss (gain) | 0.9 |  |  | (0.1 | ) |
| Loss on disposal of fixed assets | — |  |  | 0.2 |  |
| Net change in unrealized losses on unsettled futures contracts | 0.7 |  |  | 0.5 |  |
| Other items, net | 0.1 |  |  | 0.1 |  |
| Losses and other expenses, net | $ | 2.1 |  |  | $ | 1.4 |  |

[0001069202-13-000008:mdna:30]
The decrease in realized losses on settled futures contracts in the second quarter of 2013 was attributable to increases in commodity prices relative to our futures contract prices.  Conversely, the increase in unrealized losses on unsettled futures contracts was due to lower commodity prices relative to the futures contract prices.  For more information on our derivatives, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000008:mdna:31]
[same as prior period, unchanged from 0001069202-13-000005:mdna:33]

[0001069202-13-000008:mdna:32]
Restructuring charges were $2 million in the second quarter of 2013 compared to minimal charges in the second quarter of 2012.  We have not initiated any significant new projects in 2013 and charges during the year related primarily to our Regional Distribution Network project.  Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on our restructuring activity.

[0001069202-13-000008:mdna:33]
[same as prior period, unchanged from 0001069202-13-000005:mdna:35]

[0001069202-13-000008:mdna:34]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments of $4 million in the second quarter of 2013 was comparable to the second quarter of 2012.

[0001069202-13-000008:mdna:35]
[same as prior period, unchanged from 0001069202-13-000005:mdna:37]

[0001069202-13-000008:mdna:36]
Interest expense, net of $4 million in the second quarter of 2013 was comparable to the second quarter of 2012.  Our weighted average borrowings and interest rates were relatively flat.

[0001069202-13-000008:mdna:37]
[same as prior period, unchanged from 0001069202-13-000005:mdna:39]

[0001069202-13-000008:mdna:38]
The income tax provision was $35 million in the second quarter of 2013 compared to $26 million in the second quarter of 2012.  The effective tax rate was 35.1% for the second quarter of 2013 compared to 34.4% for the second quarter of 2012.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, such as tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-13-000008:mdna:39]
[same as prior period, unchanged from 0001069202-13-000005:mdna:41]

[0001069202-13-000008:mdna:40]
The loss from discontinued operations related to the Service Experts business sold in March 2013 and the Hearth business sold in April 2012.  There were no significant gains or losses from discontinued operations in the second quarter of 2013 compared to pre-tax losses of $9 million in the second quarter of 2012.

[0001069202-13-000008:mdna:41]
The Service Experts business had a pre-tax loss in the second quarter of 2012 consisting of operating losses of $2 million.  The Hearth business had a pre-tax loss of $7 million in the second quarter of 2012 that included $1 million of operating losses and a $6 million pension settlement charge for the realization of pension losses related to the transfer of a pension to the buyer.

[0001069202-13-000008:mdna:42]
Second Quarter of 2013 Compared to Second Quarter of 2012 - Results by Segment

[0001069202-13-000008:mdna:43]
[same as prior period, unchanged from 0001069202-13-000005:mdna:46]

[0001069202-13-000008:mdna:44]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the second quarter of 2013 and 2012 (dollars in millions):

[0001069202-13-000008:mdna:45]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 476.2 |  |  | $ | 411.9 |  |  | $ | 64.3 |  |  | 15.6 | % |
| Profit | $ | 66.2 |  |  | $ | 42.0 |  |  | $ | 24.2 |  |  | 57.6 | % |
| % of net sales | 13.9 | % |  | 10.2 | % |  |  |  |  |

[0001069202-13-000008:mdna:46]
Residential Heating & Cooling net sales increased by 16% in the second quarter of 2013 compared to the second quarter of 2012 primarily due to increases in sales volumes.  The increase in volumes was attributable primarily to industry growth in new construction and replacement markets quarter over quarter.  Sales price and mix improvements also contributed approximately 3% due to price increases and a moderation of downward mix pressures from lower efficiency product sales.

[0001069202-13-000008:mdna:47]
Segment profit for the second quarter of 2013 increased $24 million due to $16 million in higher sales volumes, $11 million in commodity and non-commodity material cost savings, $6 million in favorable price and mix, $2 million from a favorable warranty accrual adjustment and $5 million from the realization of factory productivity initiatives.  Partially offsetting these increases were $9 million in higher SG&A costs due primarily to higher advertising and employee compensation costs and $7 million of higher freight and distribution expenses due to continued investment in distribution initiatives.

[0001069202-13-000008:mdna:48]
[same as prior period, unchanged from 0001069202-13-000005:mdna:51]

[0001069202-13-000008:mdna:49]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2013 and 2012 (dollars in millions):

[0001069202-13-000008:mdna:50]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 229.6 |  |  | $ | 221.4 |  |  | $ | 8.2 |  |  | 3.7 | % |
| Profit | $ | 34.6 |  |  | $ | 33.2 |  |  | $ | 1.4 |  |  | 4.2 | % |
| % of net sales | 15.1 | % |  | 15.0 | % |  |  |  |  |

[0001069202-13-000008:mdna:51]
Commercial Heating & Cooling net sales increased 4% in the second quarter of 2013 compared to the second quarter of 2012 due primarily to increased sales volumes.  Sales volume growth was primarily attributable to modest broad-based volume increases in North America partially offset by continued weakness in European markets.

[0001069202-13-000008:mdna:52]
Segment profit in the second quarter of 2013 increased $1 million compared to the second quarter of 2012 due to $3 million in higher sales volumes, $1 million in product cost savings and $1 million from a favorable warranty accrual adjustment.  Partially offsetting these increases were $3 million of higher SG&A costs and $1 million in higher freight and distribution expenses.

[0001069202-13-000008:mdna:53]
[same as prior period, unchanged from 0001069202-13-000005:mdna:56]

[0001069202-13-000008:mdna:54]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2013 and 2012 (dollars in millions):

[0001069202-13-000008:mdna:55]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 207.3 |  |  | $ | 207.1 |  |  | $ | 0.2 |  |  | 0.1 | % |
| Profit | $ | 25.8 |  |  | $ | 21.2 |  |  | $ | 4.6 |  |  | 21.7 | % |
| % of net sales | 12.4 | % |  | 10.2 | % |  |  |  |  |

[0001069202-13-000008:mdna:56]
Refrigeration net sales were flat in the second quarter of 2013 compared to the second quarter of 2012.  Foreign currency exchange rates had a neutral impact on net sales over the same periods.  Volume declines of 2% were offset by favorable price and mix of 1% and growth in our Australia wholesale refrigerant business of 1%.  Sales volumes declined in second quarter of 2013 because of continued weakness with certain supermarket customers.

[0001069202-13-000008:mdna:57]
Segment profit for the second quarter of 2013 increased $5 million over the second quarter of 2012, with increases of $4 million for favorable price and mix, and $3 million from growth in the Australia wholesale refrigerant business which continued to benefit from one-time purchases of lower cost inventory and investments in related operations.  Partially offsetting this benefit was $2 million of higher SG&A expenses.

[0001069202-13-000008:mdna:58]
[same as prior period, unchanged from 0001069202-13-000005:mdna:61]

[0001069202-13-000008:mdna:59]
Corporate and other expenses increased $6 million to $21 million in the second quarter of 2013 from $15 million in the second quarter of 2012.  The increase was primarily driven by an increase in incentive compensation due to improved overall operating results.

[0001069202-13-000008:mdna:60]
Year-to-Date through June 30, 2013 Compared to Year-to-Date through June 30, 2012 - Consolidated Results

[0001069202-13-000008:mdna:61]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-13-000008:mdna:62]
|  | For the Six Months Ended June 30, |
|  | Dollars |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net sales | $ | 1,581.5 |  |  | $ | 1,454.8 |  |  | 8.7 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,165.5 |  |  | 1,105.8 |  |  | (5.4 | ) |  | 73.7 |  |  | 76.0 |  |
| Gross profit | 416.0 |  |  | 349.0 |  |  | 19.2 |  |  | 26.3 |  |  | 24.0 |  |
| Selling, general and administrative expenses | 287.0 |  |  | 253.9 |  |  | (13.0 | ) |  | 18.1 |  |  | 17.5 |  |
| Losses and other expenses, net | 3.2 |  |  | — |  |  | (100.0 | ) |  | 0.2 |  |  | — |  |
| Restructuring charges | 2.9 |  |  | 2.7 |  |  | (7.4 | ) |  | 0.2 |  |  | 0.2 |  |
| Income from equity method investments | (7.4 | ) |  | (6.3 | ) |  | 17.5 |  |  | (0.5 | ) |  | (0.4 | ) |
| Operational income from continuing operations | $ | 130.3 |  |  | $ | 98.7 |  |  | 32.0 | % |  | 8.2 | % |  | 6.8 | % |

[0001069202-13-000008:mdna:63]
Net Sales

[0001069202-13-000008:mdna:64]
Net sales increased 9% in the first half of 2013 compared to the first half of 2012.  Sales volumes were up 7% and price and mix were up 2% from the comparable period.  The increase in volume was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  The increase in price and mix was driven by a combination of price increases and a moderation of downward mix pressures from lower efficiency product sales in our Residential Heating & Cooling segment as well as improvements in the Refrigeration segment's Australia refrigerant distribution business.

[0001069202-13-000008:mdna:65]
Gross Profit

[0001069202-13-000008:mdna:66]
Gross profit margins improved 230 basis points to 26.3% in the first half of 2013 compared to 24.0% in the first half of 2012.  Improved price and mix contributed 200 basis points to profit margin, improved commodity and non-commodity material costs contributed a collective 130 basis points and a favorable warranty accrual adjustment contributed 10 basis points.  Partially offsetting

[0001069202-13-000008:mdna:67]
these increases were approximately 110 basis points of higher freight and distribution costs.

[0001069202-13-000008:mdna:68]
Selling, General and Administrative Expenses

[0001069202-13-000008:mdna:69]
Selling, General & Administrative (“SG&A”) expenses increased by $33 million in the first half of 2013 compared to the first half of 2012.  As a percentage of net sales, SG&A expenses increased 60 basis points from 17.5% to 18.1% in the same periods.  The increase in SG&A expenses was principally due to higher employee compensation due to overall improved operating results in the first half of 2013.

[0001069202-13-000008:mdna:70]
Losses and Other Expenses, Net

[0001069202-13-000008:mdna:71]
Losses and other expenses, net for first half of 2013 and 2012 included the following (in millions):

[0001069202-13-000008:mdna:72]
|  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |
| Realized loss on settled future contracts | $ | 0.4 |  |  | $ | 1.0 |  |
| Foreign currency exchange loss (gain) | 0.6 |  |  | (0.3 | ) |
| Loss on disposal of fixed assets | — |  |  | 0.2 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 1.8 |  |  | (1.2 | ) |
| Special legal contingency charge | 0.2 |  |  | — |  |
| Other items, net | 0.2 |  |  | 0.3 |  |
| Losses and other expenses, net | $ | 3.2 |  |  | $ | — |  |

[0001069202-13-000008:mdna:73]
The decline in realized losses on settled futures contracts in the first half of 2013 was attributable to increases in commodity prices relative to our futures contract prices.  Conversely, the change in unrealized losses (gains) on unsettled futures contracts was primarily due to lower commodity prices relative to the futures contract prices.  For more information on our derivatives, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000008:mdna:74]
The special legal contingency charge in the first half of 2013 relates to ongoing patent litigation.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for more information on this litigation.

[0001069202-13-000008:mdna:75]
Restructuring Charges

[0001069202-13-000008:mdna:76]
Restructuring charges were $3 million in the first half of 2013 and $3 million in the first half of 2012.  We have not initiated any significant new projects in 2013 and the charges in both years related primarily to our Regional Distribution Network project.  Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on our restructuring activity.

[0001069202-13-000008:mdna:77]
Income from Equity Method Investments

[0001069202-13-000008:mdna:78]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments increased slightly to $7 million in the first half of 2013 compared to $6 million in the first half of 2012 primarily due to improved operational performance from our joint ventures.

[0001069202-13-000008:mdna:79]
Interest Expense, net

[0001069202-13-000008:mdna:80]
Interest expense, net of $7 million in the first half of 2013 declined from $9 million in the first half of 2012 due to a decrease in our weighted average borrowings in the comparable periods.  Our weighted average interest rates were relatively flat.

[0001069202-13-000008:mdna:81]
Income Taxes

[0001069202-13-000008:mdna:82]
The income tax provision was $43 million in the first half of 2013 compared to $31 million in the first half of 2012.  The effective tax rate was 35.1% for the first half of 2013 compared to 34.4% for the first half of 2012.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, such as tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-13-000008:mdna:83]
Loss from Discontinued Operations

[0001069202-13-000008:mdna:84]
The loss from discontinued operations relates to the Service Experts business sold in March 2013 and the Hearth business sold in April 2012.  The pre-tax loss from discontinued operations was $13 million in the first half of 2013 compared to $33 million in the first half quarter of 2012.

[0001069202-13-000008:mdna:85]
The Service Experts business had pre-tax losses of $14 million in the first half of 2013 compared to pre-tax losses of $16 million in the first half of 2012.  The pre-tax loss from discontinued operations in the first half of 2013 included operating losses of $14 million and $2 million for certain retention bonuses and severance costs, partially offset by a $2 million gain on the sale of the business.  The pre-tax loss in the first half of 2012 consisted of operating losses of $16 million.

[0001069202-13-000008:mdna:86]
The Hearth business had no significant gains, losses or other activity in the first half of 2013.  The business had a pre-tax loss of $16 million in the first half of 2012 that included approximately $4 million of operating losses, a $6 million charge to write down certain long-lived assets to their fair value and a $6 million pension settlement charge for the realization of pension losses related to the transfer of a pension to the buyer.

[0001069202-13-000008:mdna:87]
Year-to-Date through June 30, 2013 Compared to Year-to-Date through June 30, 2012 - Results by Segment

[0001069202-13-000008:mdna:88]
Residential Heating & Cooling

[0001069202-13-000008:mdna:89]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first half of 2013 and 2012 (dollars in millions):

[0001069202-13-000008:mdna:90]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 790.7 |  |  | $ | 684.5 |  |  | $ | 106.2 |  |  | 15.5 | % |
| Profit | $ | 86.7 |  |  | $ | 53.0 |  |  | $ | 33.7 |  |  | 63.6 | % |
| % of net sales | 11.0 | % |  | 7.7 | % |  |  |  |  |

[0001069202-13-000008:mdna:91]
Residential Heating & Cooling net sales increased by 16% in the first half of 2013 compared to the first half of 2012.  An increase in sales volumes contributed 14% and was attributable primarily to industry growth in new construction and replacement markets.  Sales price and mix improvements also contributed 2% due to price increases and a moderation of downward mix pressures from lower efficiency product sales.

[0001069202-13-000008:mdna:92]
Segment profit for the first half of 2013 increased $34 million due to $28 million in higher sales volumes, $7 million from favorable price and mix, $12 million in commodity and non-commodity material product costs, $2 million from a favorable warranty accrual adjustment in the second quarter of 2013, and $7 million from the realization of factory productivity initiatives.  Partially offsetting these increases were $10 million in higher SG&A costs due primarily to higher advertising and employee compensation costs and $12 million of higher freight and distribution expenses due to continued investment in distribution initiatives.

[0001069202-13-000008:mdna:93]
Commercial Heating & Cooling

[0001069202-13-000008:mdna:94]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first half of 2013 and 2012 (dollars in millions):

[0001069202-13-000008:mdna:95]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 392.6 |  |  | $ | 378.1 |  |  | $ | 14.5 |  |  | 3.8 | % |
| Profit | $ | 45.7 |  |  | $ | 41.5 |  |  | $ | 4.2 |  |  | 10.1 | % |
| % of net sales | 11.6 | % |  | 11.0 | % |  |  |  |  |

[0001069202-13-000008:mdna:96]
Commercial Heating & Cooling net sales increased 4% in the first half of 2013 compared to the first half of 2012.  The increase was due to higher sales volumes in our national accounts business and modest broad-based volume increases in North America, partially offset by weakness in European markets.

[0001069202-13-000008:mdna:97]
Segment profit in the first half of 2013 increased $4 million compared to the first half of 2012 due to increases of $5 million for higher sales volumes, $5 million for favorable commodity and non-commodity product costs and $3 million for favorable price and mix.  Partially offsetting these increases were $2 million of higher freight and distribution expenses due to continued investment in distribution initiatives, $3 million of higher SG&A costs and $4 million of additional costs from various productivity initiatives.

[0001069202-13-000008:mdna:98]
Refrigeration

[0001069202-13-000008:mdna:99]
The following table presents our Refrigeration segment's net sales and profit for the first half of 2013 and 2012 (dollars in millions):

[0001069202-13-000008:mdna:100]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2013 |  | 2012 |  | Difference |  | % Change |
| Net sales | $ | 398.2 |  |  | $ | 392.2 |  |  | $ | 6.0 |  |  | 1.5 | % |
| Profit | $ | 42.5 |  |  | $ | 35.5 |  |  | $ | 7.0 |  |  | 19.7 | % |
| % of net sales | 10.7 | % |  | 9.1 | % |  |  |  |  |

[0001069202-13-000008:mdna:101]
Refrigeration net sales increased 2% in the first half of 2013 compared to the first half of 2012.  Foreign currency exchange rates had a neutral impact on net sales over the same periods.  The increase in the first half of 2013 was attributable to growth of 3% in the Australia wholesale refrigerant business offset by volume declines of 2%.  Sales volumes declined because of continued weakness with certain supermarket customers.

[0001069202-13-000008:mdna:102]
Segment profit for the first half of 2013 increased $7 million over the first half of 2012, with increases of $10 million from growth in the Australia wholesale refrigerant business which benefited from one-time purchases of lower cost inventory and investments in related operations, increases of $4 million from favorable price and mix and increases of $2 million from favorable commodity and non-commodity material product costs.  Partially offsetting this benefit was $6 million of higher SG&A expenses and $3 million of additional costs from various productivity initiatives.

[0001069202-13-000008:mdna:103]
Corporate and Other

[0001069202-13-000008:mdna:104]
Corporate and other expenses increased to $40 million in the first half of 2013 from $29 million in the first half of 2012 driven  primarily by an $8 million increase in incentive compensation due to improved overall operating results.

[0001069202-13-000008:mdna:105]
[same as prior period, unchanged from 0001069202-13-000005:mdna:63]

[0001069202-13-000008:mdna:106]
[same as prior period, unchanged from 0001069202-13-000005:mdna:64]

[0001069202-13-000008:mdna:107]
[same as prior period, unchanged from 0001069202-13-000005:mdna:65]

[0001069202-13-000008:mdna:108]
The following table summarizes our cash flow activity for the six months ended June 30, 2013 and 2012 (in millions):

[0001069202-13-000008:mdna:109]
|  | For the Six Months Ended June 30, |
|  | 2013 |  | 2012 |
| Net cash used in operating activities | $ | (88.3 | ) |  | $ | (10.6 | ) |
| Net cash used in investing activities | (18.7 | ) |  | (9.5 | ) |
| Net cash provided by financing activities | 106.6 |  |  | 44.3 |  |

[0001069202-13-000008:mdna:110]
Net Cash Used in Operating Activities.  Net cash used in operating activities increased $78 million to $88 million in the first

[0001069202-13-000008:mdna:111]
half of 2013 compared to $11 million in the first half of 2012.  This increase in use of cash was primarily attributable to higher working capital requirements and a decrease in accrued expenses, partially offset by an increase in net income.  Working capital was higher in the first six months of 2013 because of increases in accounts receivable due to higher sales volumes period over period and decreases in accounts payable due to the timing of vendor payments.  The reduction in accrued expenses was primarily due to payments in 2013 of employee incentive compensation earned in 2012.

[0001069202-13-000008:mdna:112]
Net Cash Used in Investing Activities.  Capital expenditures were $23 million and $16 million in the first half of 2013 and 2012, respectively.  Capital expenditures in 2013 were primarily investments in our distribution network, investments in systems and software to support the overall enterprise, and investments for manufacturing and sourcing excellence.  Net cash used in investing activities also included net proceeds of $5 million from the sale of the Service Experts business in the first quarter of 2013.

[0001069202-13-000008:mdna:113]
Net Cash Provided by Financing Activities.  Net cash provided by financing activities increased to $107 million in the first half of 2013 primarily due to an increase in net borrowings.  The net borrowings were higher in 2013 to support the increasing sales and the rise in working capital requirements.

[0001069202-13-000008:mdna:114]
[same as prior period, unchanged from 0001069202-13-000005:mdna:72]

[0001069202-13-000008:mdna:115]
The following table details our lines of credit and financing arrangements as of June 30, 2013 (in millions):

[0001069202-13-000008:mdna:116]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-Term Debt: |  |  |  |  |  |
| Foreign obligations | $ | 30.8 |  |  | $ | 5.9 |  |  | $ | 24.9 |  |
| Asset Securitization Program (1) | 160.0 |  |  | 120.0 |  |  | 40.0 |  |
| Total short-term debt | $ | 190.8 |  |  | $ | 125.9 |  |  | $ | 64.9 |  |
| Current Maturities: |  |  |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | — |  |
| Long-Term Debt: |  |  |  |  |  |
| Capital lease obligations | $ | 15.8 |  |  | $ | 15.8 |  |  | $ | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 195.0 |  |  | 405.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 865.8 |  |  | 410.8 |  |  | 405.0 |  |
| Total debt | $ | 1,057.0 |  |  | $ | 537.1 |  |  | $ | 469.9 |  |

[0001069202-13-000008:mdna:117]
(1) The maximum capacity under the Asset Securitization Program (“ASP”) is the lesser of $160.0 million or 100% of the net pool balance less reserves, as defined under the ASP.

[0001069202-13-000008:mdna:118]
(2) The available future borrowings on our domestic revolving credit facility were reduced by $50.0 million in outstanding standby letters of credit.  We had an additional $26.0 million in outstanding standby letters of credit with other banks.

[0001069202-13-000008:mdna:119]
[same as prior period, unchanged from 0001069202-13-000005:mdna:77]

[0001069202-13-000008:mdna:120]
[same as prior period, unchanged from 0001069202-13-000005:mdna:78]

[0001069202-13-000008:mdna:121]
Our debt-to-total-capital ratio increased to 54.6% at June 30, 2013 compared to 43.8% at December 31, 2012.  The increase in the ratio in the first half of 2013 is due to the increase in our net borrowings, as noted above, as well as a decrease in equity primarily related to changes in foreign currency translation adjustments within accumulated other comprehensive income into net income.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on these changes in foreign currency translation adjustments.  We evaluate our debt-to-capital ratio as well as our debt-to-EBITDA ratio in order to determine the appropriate targets for share repurchases under our share repurchase programs.  Our senior credit ratings were investment grade as of June 30, 2013 and our goal is to retain investment grade ratings.

[0001069202-13-000008:mdna:122]
[same as prior period, unchanged from 0001069202-13-000005:mdna:80]

[0001069202-13-000008:mdna:123]
We believe our available future borrowings, our cash of $45 million and future cash generated from operations are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $45 million as of June 30, 2013 was $24 million of cash held in foreign locations.  Our cash in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and to pay taxes in the United States for the amounts that were repatriated.

[0001069202-13-000008:mdna:124]
Our expected capital expenditures for 2013 are $60 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs.  In 2013, we are targeting approximately $100 million in share repurchases under the existing share repurchase programs and over $30 million of dividend payments.

[0001069202-13-000008:mdna:125]
[same as prior period, unchanged from 0001069202-13-000005:mdna:84]

[0001069202-13-000008:mdna:126]
In addition to the credit facilities described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.

[0001069202-13-000008:mdna:127]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019.  The agreement provides for financial covenants consistent with our credit agreement and we were in compliance with those covenants as of June 30, 2013.  The lease is classified as an operating lease and we expect to realize annual savings of approximately $2 million in net rent costs from this renewal compared to our previous leasing arrangement.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for more details.

[0001069202-13-000008:mdna:128]
Commitments, Contingencies and Guarantees

[0001069202-13-000008:mdna:129]
For more information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-13-000008:mdna:130]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure. We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance.  The estimate of our liability for future warranty costs requires us to make significant assumptions about the amount, timing and nature of the costs we will incur in the future. We periodically review the assumptions used to determine the liability and adjust our assumptions based upon factors such as actual failure rates and cost experience. Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, and changes in manufacturing techniques or locations, components or suppliers used. In recent years, changes in the warranty liability as the result of the issuance of new warranties and the payments made have remained relatively stable. Should actual warranty costs differ from our estimates, we may be required to record adjustments to accruals and expense in the future.  We evaluate our heating, ventilation and air conditioning warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.  As a result of the second quarter 2013 re-evaluation, we decreased our warranty liability by $3.2 million.

[0001069202-13-000008:mdna:131]
We also may incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications. We identified product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue in 2012.  As of June 30, 2013, we have $6.0 million accrued for these matters. We may incur additional charges in the future as more information becomes available.

[0001069202-13-000008:mdna:132]
We estimate the costs to settle pending litigation based on experience involving similar claims and specific facts known and do not believe that any current, pending or threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Litigation, however, involves uncertainties and it is possible that the eventual outcome of litigation could adversely affect our results of operations for a particular period.

[0001069202-13-000008:mdna:133]
[same as prior period, unchanged from 0001069202-13-000005:mdna:92]

[0001069202-13-000008:mdna:134]
In February 2013, the FASB updated its guidance related to the presentation of comprehensive income and accumulated other comprehensive income ("AOCI").  The updated guidance requires additional footnote disclosure of items reclassified out of AOCI and into net income as well as the effect of the reclassifications on each affected Statement of Operations line item.  This updated guidance was applicable beginning in the first quarter of 2013 on a prospective basis.  The required disclosures can be found in Note 11 of the Notes to the Consolidated Financial Statements.
