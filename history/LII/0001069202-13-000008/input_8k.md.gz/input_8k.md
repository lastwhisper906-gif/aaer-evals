# LII 8-K — 0001193125-13-296557 filed 2013-07-22

## item codes, every 8-K on or before 2013-07-22

- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2013-07-22

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-13-296557:8k_2_02:1]
EX-99.1
2
d570200dex991.htm
EX-99.1

[0001193125-13-296557:8k_2_02:2]
EX-99.1

[0001193125-13-296557:8k_2_02:3]
Exhibit 99.1

[0001193125-13-296557:8k_2_02:4]
Lennox International Reports Record Quarterly Profit in Second Quarter

[0001193125-13-296557:8k_2_02:5]
|  | • |  | Revenue up 9%, led by 16% growth in Residential |

[0001193125-13-296557:8k_2_02:6]
|  | • |  | Adjusted EPS from continuing operations of $1.31, up 34% |

[0001193125-13-296557:8k_2_02:7]
|  | • |  | GAAP EPS from continuing operations of $1.26, up 31% |

[0001193125-13-296557:8k_2_02:8]
|  | • |  | Raising 2013 revenue growth guidance range from 3-6% to 6-8% |

[0001193125-13-296557:8k_2_02:9]
|  | • |  | Raising 2013 adjusted EPS from continuing operations guidance range from $3.25-$3.55 to $3.45-$3.75 |

[0001193125-13-296557:8k_2_02:10]
DALLAS, July 22, 2013 – Lennox International Inc. (NYSE: LII) today reported financial results for the second quarter of 2013. Financial
results in prior periods have been revised to reflect sold businesses in discontinued operations.

[0001193125-13-296557:8k_2_02:11]
Revenue for the second quarter was $913
million, up 9% from the prior-year quarter. Adjusted earnings per share from continuing operations was a record $1.31, up 34% from $0.98 in the prior-year quarter. On a GAAP basis, earnings per share from continuing operations was a record $1.26, up
31% from $0.96 in the prior-year quarter.

[0001193125-13-296557:8k_2_02:12]
“The company’s strong business momentum continued in the second quarter, with revenue up
9% and total segment profit margin up 200 basis points to a record level of 11.6%,” said Todd Bluedorn, Chairman and CEO of Lennox International. “In our Residential business, revenue was up 16% on strong double-digit growth in both new
construction and replacement business, and margin expanded 370 basis points to 13.9%. Residential profit was up 58%. In our Commercial business, revenue and profit were up 4%, led by growth in the emergency replacement market and commercial
services. Commercial margin increased 10 basis points to 15.1%. In Refrigeration, revenue was flat on the timing of national account business and soft economic conditions in Europe, but growth was strong in South America and Asia Pacific.
Refrigeration profit was up 22% as margin expanded 220 basis points to 12.4%. Looking at 2013 for the company overall, we are raising our revenue and earnings guidance for the year. As markets continue to recover, the company is strategically
well-positioned to drive our financial performance to new levels as we continue to execute on achieving our longer-term financial targets.”

[0001193125-13-296557:8k_2_02:13]
FINANCIAL HIGHLIGHTS

[0001193125-13-296557:8k_2_02:14]
Revenue: Revenue for the second quarter was $913 million, up 9% from the prior-year quarter. Foreign exchange was neutral to revenue. Volume and price/mix were up from the prior-year quarter.

[0001193125-13-296557:8k_2_02:15]
Gross Profit: Gross profit for the second quarter was $254 million, up 22% from the prior-year quarter. Gross margin was 27.8%, up 300
basis points from 24.8% in the prior-year quarter. Gross profit was primarily impacted by higher volume, favorable price/mix and lower material costs, partially offset by investments in distribution. The annual adjustment for warranty reserves was
favorable by $3 million in the second quarter of 2013 compared to the prior-year quarter.

[0001193125-13-296557:8k_2_02:16]
Income from Continuing Operations: Adjusted
income from continuing operations in the second quarter was $66.5 million, or $1.31 per share, compared to $50.6 million, or $0.98 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the second quarter of 2013
excludes an after-tax charge of $1.6 million for restructuring activities, $0.5 million after-tax for the net change in unrealized losses on open future contracts, and an after-tax charge of $0.1 million for other items.

[0001193125-13-296557:8k_2_02:17]
On a GAAP basis, income from continuing operations for the second quarter was $64.3 million, or $1.26 per share, compared to $49.5 million, or $0.96 per
share, in the prior-year quarter.

[0001193125-13-296557:8k_2_02:18]
Free Cash Flow and Total Debt: Net cash from operations in the second quarter was $49 million,
compared to $24 million in the prior-year quarter. The company invested $11 million in capital assets in the second quarter. Free cash flow was $38 million, compared to $14 million in the prior-year quarter. Total debt at the end of the second
quarter was $537 million, and total cash and cash equivalents were $45 million. The company increased its dividend 20% and repurchased $33 million of stock in the second quarter.

[0001193125-13-296557:8k_2_02:19]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-13-296557:8k_2_02:20]
Residential Heating & Cooling

[0001193125-13-296557:8k_2_02:21]
Second quarter 2013 revenue in the Residential
Heating & Cooling business segment was $476 million, up 16% from the prior-year quarter. Currency was neutral to revenue growth. Segment profit was $66 million, up 58% from the prior-year quarter. Segment profit margin was 13.9%, up 370
basis points. Results were primarily impacted by higher volume, favorable price and mix, and lower material costs, with partial offsets from higher SG&A and investments in distribution expansion.

[0001193125-13-296557:8k_2_02:22]
Commercial Heating & Cooling

[0001193125-13-296557:8k_2_02:23]
Revenue in the Commercial Heating & Cooling business segment was $230 million, up 4% from the prior-year quarter. Currency was neutral to revenue
growth. Segment profit was $35 million, up 4% from the prior-year quarter. Segment profit margin was 15.1%, up 10 basis points. Results were primarily impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets
from higher SG&A and investments in distribution expansion.

[0001193125-13-296557:8k_2_02:24]
Refrigeration

[0001193125-13-296557:8k_2_02:25]
Revenue in the Refrigeration business segment was $207 million in the second quarter, flat with the prior-year quarter. Currency was neutral to revenue. Segment profit was $26 million, up 22% from the
prior-year quarter. Segment profit margin was 12.4%, up 220 basis points. Results were primarily impacted by favorable price/mix and lower material costs, with a partial offset from lower volume and higher SG&A.

[0001193125-13-296557:8k_2_02:26]
FULL-YEAR OUTLOOK

[0001193125-13-296557:8k_2_02:27]
The company is
raising its revenue and EPS from continuing operations guidance ranges for 2013.

[0001193125-13-296557:8k_2_02:28]
|  | • |  | Raising revenue growth guidance from 3-6% to a range of 6-8%; foreign exchange is still expected to have a neutral impact on revenue. |

[0001193125-13-296557:8k_2_02:29]
|  | • |  | Raising adjusted EPS from continuing operations guidance from $3.25-$3.55 to a range of $3.45-$3.75. |

[0001193125-13-296557:8k_2_02:30]
|  | • |  | Raising GAAP EPS from continuing operations guidance from $3.23-$3.53 to a range of $3.38-$3.68. |

[0001193125-13-296557:8k_2_02:31]
|  | • |  | Reiterating tax rate guidance of 34-35% on a full-year basis. |

[0001193125-13-296557:8k_2_02:32]
|  | • |  | Reiterating capital expenditure guidance of approximately $60 million in 2013. |

[0001193125-13-296557:8k_2_02:33]
|  | • |  | Reiterating plans to repurchase $100 million of stock in 2013. |

[0001193125-13-296557:8k_2_02:34]
|  | • |  | Raising average diluted share count guidance for the full year from approximately 50 million shares to approximately 51 million shares. |

[0001193125-13-296557:8k_2_02:35]
CONFERENCE CALL INFORMATION

[0001193125-13-296557:8k_2_02:36]
A conference call to discuss the company’s second quarter results will be held this morning at 8:30 a.m. Central time. To listen, please call the conference call line at 612-332-0226 at least 10
minutes prior to the scheduled start time and use reservation number 297408. The conference call will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0001193125-13-296557:8k_2_02:37]
A replay will be available from 11:00 a.m. Central time on July 22 through July 29, 2013 by dialing 800-475-6701 (U.S.) or 320-365-3844
(international) and using access code 297408. The call will also be archived on the company’s web site.

[0001193125-13-296557:8k_2_02:38]
Lennox International Inc. is a
global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New York Stock Exchange under the symbol “LII.” Additional information is available at:
http://www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-13-296557:8k_2_02:39]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-296557:8k_2_02:40]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-13-296557:8k_2_02:41]
(Unaudited, in millions, except per share data)

[0001193125-13-296557:8k_2_02:42]
|  |  | For the ThreeMonths EndedJune 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net sales |  | $ | 913.1 |  |  | $ | 840.4 |  |  | $ | 1,581.5 |  |  | $ | 1,454.8 |  |
| Cost of goods sold |  |  | 659.1 |  |  |  | 632.3 |  |  |  | 1,165.5 |  |  |  | 1,105.8 |  |
| Gross profit |  |  | 254.0 |  |  |  | 208.1 |  |  |  | 416.0 |  |  |  | 349.0 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 151.3 |  |  |  | 130.7 |  |  |  | 287.0 |  |  |  | 253.9 |  |
| Losses and other expenses, net |  |  | 2.1 |  |  |  | 1.4 |  |  |  | 3.2 |  |  |  | — |  |
| Restructuring charges |  |  | 2.4 |  |  |  | 0.1 |  |  |  | 2.9 |  |  |  | 2.7 |  |
| Income from equity method investments |  |  | (4.2 | ) |  |  | (3.9 | ) |  |  | (7.4 | ) |  |  | (6.3 | ) |
| Operational income from continuing operations |  |  | 102.4 |  |  |  | 79.8 |  |  |  | 130.3 |  |  |  | 98.7 |  |
| Interest expense, net |  |  | 3.6 |  |  |  | 4.3 |  |  |  | 7.0 |  |  |  | 9.0 |  |
| Other expense (income), net |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 99.0 |  |  |  | 75.4 |  |  |  | 123.4 |  |  |  | 89.6 |  |
| Provision for income taxes |  |  | 34.7 |  |  |  | 25.9 |  |  |  | 43.3 |  |  |  | 30.8 |  |
| Income from continuing operations |  |  | 64.3 |  |  |  | 49.5 |  |  |  | 80.1 |  |  |  | 58.8 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | — |  |  |  | (9.2 | ) |  |  | (13.4 | ) |  |  | (32.7 | ) |
| Benefit from income taxes |  |  | — |  |  |  | (4.4 | ) |  |  | (5.6 | ) |  |  | (12.5 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | (4.8 | ) |  |  | (7.8 | ) |  |  | (20.2 | ) |
| Net income |  | $ | 64.3 |  |  | $ | 44.7 |  |  | $ | 72.3 |  |  | $ | 38.6 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.28 |  |  | $ | 0.97 |  |  | $ | 1.60 |  |  | $ | 1.15 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.09 | ) |  |  | (0.16 | ) |  |  | (0.39 | ) |
| Net income |  | $ | 1.28 |  |  | $ | 0.88 |  |  | $ | 1.44 |  |  | $ | 0.76 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.26 |  |  | $ | 0.96 |  |  | $ | 1.57 |  |  | $ | 1.14 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.09 | ) |  |  | (0.15 | ) |  |  | (0.39 | ) |
| Net income |  | $ | 1.26 |  |  | $ | 0.87 |  |  | $ | 1.42 |  |  | $ | 0.75 |  |
| Average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 50.2 |  |  |  | 51.0 |  |  |  | 50.2 |  |  |  | 50.9 |  |
| Diluted |  |  | 50.9 |  |  |  | 51.6 |  |  |  | 51.0 |  |  |  | 51.5 |  |
| Cash dividends declared per share |  | $ | 0.24 |  |  | $ | 0.18 |  |  | $ | 0.44 |  |  | $ | 0.36 |  |

[0001193125-13-296557:8k_2_02:43]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-296557:8k_2_02:44]
SEGMENT NET SALES AND PROFIT (LOSS)

[0001193125-13-296557:8k_2_02:45]
(Unaudited, in millions)

[0001193125-13-296557:8k_2_02:46]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 476.2 |  |  | $ | 411.9 |  |  | $ | 790.7 |  |  | $ | 684.5 |  |
| Commercial Heating & Cooling |  |  | 229.6 |  |  |  | 221.4 |  |  |  | 392.6 |  |  |  | 378.1 |  |
| Refrigeration |  |  | 207.3 |  |  |  | 207.1 |  |  |  | 398.2 |  |  |  | 392.2 |  |
|  |  | $ | 913.1 |  |  | $ | 840.4 |  |  | $ | 1,581.5 |  |  | $ | 1,454.8 |  |
| Segment Profit (Loss) (A) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 66.2 |  |  | $ | 42.0 |  |  | $ | 86.7 |  |  | $ | 53.0 |  |
| Commercial Heating & Cooling |  |  | 34.6 |  |  |  | 33.2 |  |  |  | 45.7 |  |  |  | 41.5 |  |
| Refrigeration |  |  | 25.8 |  |  |  | 21.2 |  |  |  | 42.5 |  |  |  | 35.5 |  |
| Corporate and other |  |  | (20.9 | ) |  |  | (15.4 | ) |  |  | (39.6 | ) |  |  | (29.4 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 105.7 |  |  |  | 81.0 |  |  |  | 135.3 |  |  |  | 100.6 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | 0.1 |  |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 0.1 |  |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (B) |  |  | 0.8 |  |  |  | 0.6 |  |  |  | 2.2 |  |  |  | (0.9 | ) |
| Restructuring charges |  |  | 2.4 |  |  |  | 0.1 |  |  |  | 2.9 |  |  |  | 2.7 |  |
| Interest expense, net |  |  | 3.6 |  |  |  | 4.3 |  |  |  | 7.0 |  |  |  | 9.0 |  |
| Other expense (income), net |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 99.0 |  |  | $ | 75.4 |  |  | $ | 123.4 |  |  | $ | 89.6 |  |

[0001193125-13-296557:8k_2_02:47]
| (A) | The Company defines segment profit and loss as a segment’s Income or Loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-13-296557:8k_2_02:48]
|  | • |  | Special product quality adjustments; |

[0001193125-13-296557:8k_2_02:49]
|  | • |  | Items in Losses and other expenses, net that are noted in (B); |

[0001193125-13-296557:8k_2_02:50]
|  | • |  | Restructuring charges; |

[0001193125-13-296557:8k_2_02:51]
|  | • |  | Goodwill, long-lived assets and equity method investment impairments; |

[0001193125-13-296557:8k_2_02:52]
|  | • |  | Interest expense, net; |

[0001193125-13-296557:8k_2_02:53]
|  | • |  | Other expense (income), net. |

[0001193125-13-296557:8k_2_02:54]
| (B) | Items in Losses and other expenses, net that are excluded from segment profit or loss are asset impairments, net change in unrealized gains and/or losses on unsettled future contracts, special legal contingency charges and other items. |

[0001193125-13-296557:8k_2_02:55]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-296557:8k_2_02:56]
CONSOLIDATED BALANCE SHEETS

[0001193125-13-296557:8k_2_02:57]
(In millions, except shares and par value)

[0001193125-13-296557:8k_2_02:58]
|  |  | As of June30, 2013 |  |  | As of December31, 2012 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 45.3 |  |  | $ | 51.8 |  |
| Accounts and notes receivable, net of allowances of $9.5 in 2013 and 2012 |  |  | 542.3 |  |  |  | 373.4 |  |
| Inventories, net |  |  | 469.2 |  |  |  | 374.8 |  |
| Deferred income taxes, net |  |  | 31.7 |  |  |  | 27.5 |  |
| Other assets |  |  | 41.4 |  |  |  | 61.0 |  |
| Assets of discontinued operations |  |  | — |  |  |  | 98.6 |  |
| Total current assets |  |  | 1,129.9 |  |  |  | 987.1 |  |
| Property, plant and equipment, net of accumulated depreciation of $600.4 and $584.8 in 2013 and 2012, respectively |  |  | 308.7 |  |  |  | 298.2 |  |
| Goodwill |  |  | 217.6 |  |  |  | 223.8 |  |
| Deferred income taxes |  |  | 113.9 |  |  |  | 102.8 |  |
| Other assets, net |  |  | 79.5 |  |  |  | 80.0 |  |
| Total assets |  | $ | 1,849.6 |  |  | $ | 1,691.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 125.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt |  |  | 0.4 |  |  |  | 0.7 |  |
| Accounts payable |  |  | 373.6 |  |  |  | 284.7 |  |
| Accrued expenses |  |  | 257.1 |  |  |  | 259.6 |  |
| Income taxes payable |  |  | 22.7 |  |  |  | 4.5 |  |
| Liabilities of discontinued operations |  |  | — |  |  |  | 55.2 |  |
| Total current liabilities |  |  | 779.7 |  |  |  | 639.6 |  |
| Long-term debt |  |  | 410.8 |  |  |  | 351.0 |  |
| Post-retirement benefits, other than pensions |  |  | 4.9 |  |  |  | 6.1 |  |
| Pensions |  |  | 137.5 |  |  |  | 134.4 |  |
| Other liabilities |  |  | 69.5 |  |  |  | 64.0 |  |
| Total liabilities |  |  | 1,402.4 |  |  |  | 1,195.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 914.9 |  |  |  | 898.3 |  |
| Retained earnings |  |  | 794.7 |  |  |  | 744.4 |  |
| Accumulated other comprehensive loss |  |  | (103.1 | ) |  |  | (22.3 | ) |
| Treasury stock, at cost, 37,250,915 shares and 36,937,632 shares in 2013 and 2012, respectively |  |  | (1,160.2 | ) |  |  | (1,124.5 | ) |
| Total stockholders’ equity |  |  | 447.2 |  |  |  | 496.8 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,849.6 |  |  | $ | 1,691.9 |  |

[0001193125-13-296557:8k_2_02:59]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-296557:8k_2_02:60]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-13-296557:8k_2_02:61]
For the Six Months Ended June 30, 2013 and 2012

[0001193125-13-296557:8k_2_02:62]
(Unaudited, in
millions)

[0001193125-13-296557:8k_2_02:63]
|  |  | 2013 |  |  | 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 72.3 |  |  | $ | 38.6 |  |
| Net loss from discontinued operations |  |  | 7.8 |  |  |  | 20.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (7.4 | ) |  |  | (6.3 | ) |
| Dividends from affiliates |  |  | 1.7 |  |  |  | 2.0 |  |
| Restructuring expenses, net of cash paid |  |  | (0.5 | ) |  |  | 1.5 |  |
| Provision for bad debts |  |  | 1.9 |  |  |  | 1.3 |  |
| Unrealized loss (gain) on derivative contracts |  |  | 2.3 |  |  |  | (0.3 | ) |
| Stock-based compensation expense |  |  | 15.2 |  |  |  | 7.8 |  |
| Depreciation and amortization |  |  | 28.5 |  |  |  | 27.4 |  |
| Deferred income taxes |  |  | (1.0 | ) |  |  | 3.9 |  |
| Other items, net |  |  | 13.8 |  |  |  | 4.2 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (177.1 | ) |  |  | (119.9 | ) |
| Inventories |  |  | (118.3 | ) |  |  | (113.4 | ) |
| Other current assets |  |  | (3.6 | ) |  |  | — |  |
| Accounts payable |  |  | 80.0 |  |  |  | 100.4 |  |
| Accrued expenses |  |  | (13.3 | ) |  |  | 14.7 |  |
| Income taxes payable and receivable |  |  | 12.9 |  |  |  | 7.7 |  |
| Other |  |  | 8.5 |  |  |  | 1.9 |  |
| Net cash used in discontinued operations |  |  | (12.0 | ) |  |  | (2.3 | ) |
| Net cash used in operating activities |  |  | (88.3 | ) |  |  | (10.6 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | (23.4 | ) |  |  | (16.4 | ) |
| Net proceeds from sale of businesses |  |  | 4.8 |  |  |  | 7.2 |  |
| Acquisition of businesses |  |  | — |  |  |  | — |  |
| Change in restricted cash |  |  | — |  |  |  | — |  |
| Net cash used in discontinued operations |  |  | (0.1 | ) |  |  | (0.4 | ) |
| Net cash used in investing activities |  |  | (18.7 | ) |  |  | (9.5 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 1.6 |  |  |  | 9.9 |  |
| Asset securitization borrowings |  |  | 270.0 |  |  |  | 310.0 |  |
| Asset securitization payments |  |  | (180.0 | ) |  |  | (310.0 | ) |
| Long-term debt payments |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Borrowings from revolving credit facility |  |  | 700.5 |  |  |  | 526.0 |  |
| Payments on revolving credit facility |  |  | (640.5 | ) |  |  | (471.5 | ) |
| Proceeds from employee stock purchases |  |  | 1.0 |  |  |  | 0.2 |  |
| Repurchases of common stock |  |  | (33.0 | ) |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (5.8 | ) |  |  | (2.6 | ) |
| Excess tax benefits related to share-based payments |  |  | 3.4 |  |  |  | 1.2 |  |
| Cash dividends paid |  |  | (10.1 | ) |  |  | (18.3 | ) |
| Net cash provided by financing activities |  |  | 106.6 |  |  |  | 44.3 |  |
| Increase (decrease) in cash and cash equivalents |  |  | (0.4 | ) |  |  | 24.2 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (6.1 | ) |  |  | (0.1 | ) |
| Cash and cash equivalents, beginning of period |  |  | 51.8 |  |  |  | 45.0 |  |
| Cash and cash equivalents, end of period |  | $ | 45.3 |  |  | $ | 69.1 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the period for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 7.7 |  |  | $ | 9.5 |  |
| Income taxes (net of refunds) |  | $ | 22.3 |  |  | $ | 8.0 |  |

[0001193125-13-296557:8k_2_02:64]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-13-296557:8k_2_02:65]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-13-296557:8k_2_02:66]
(Unaudited, in millions, except per share and ratio data)

[0001193125-13-296557:8k_2_02:67]
Use of Non-GAAP Financial Measures

[0001193125-13-296557:8k_2_02:68]
To supplement the Company’s consolidated financial
statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when
considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors
to analyze the Company’s business trends and operating performance.

[0001193125-13-296557:8k_2_02:69]
Reconciliation of Income from Continuing Operations, a GAAP
measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-13-296557:8k_2_02:70]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Income from continuing operations, a GAAP measure |  | $ | 64.3 |  |  | $ | 49.5 |  |  | $ | 80.1 |  |  | $ | 58.8 |  |
| Restructuring charges, after tax |  |  | 1.6 |  |  |  | 0.1 |  |  |  | 1.9 |  |  |  | 1.8 |  |
| Special product quality adjustments, after tax (b) |  |  | 0.1 |  |  |  | 0.6 |  |  |  | (0.1 | ) |  |  | 0.3 |  |
| Special legal contingency charges, after tax (a) |  |  | — |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax (a) |  |  | 0.5 |  |  |  | 0.3 |  |  |  | 1.2 |  |  |  | (0.8 | ) |
| Other items, net, after tax (a) |  |  | — |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 66.5 |  |  | $ | 50.6 |  |  | $ | 83.5 |  |  | $ | 60.4 |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 1.26 |  |  | $ | 0.96 |  |  | $ | 1.57 |  |  | $ | 1.14 |  |
| Restructuring charges, after tax |  |  | 0.03 |  |  |  | — |  |  |  | 0.04 |  |  |  | 0.03 |  |
| Special product quality adjustments, after tax (b) |  |  | — |  |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |
| Special legal contingency charges, after tax (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax (a) |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | (0.02 | ) |
| Other items, net, after tax (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  | $ | 1.31 |  |  | $ | 0.98 |  |  | $ | 1.64 |  |  | $ | 1.17 |  |

[0001193125-13-296557:8k_2_02:71]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-13-296557:8k_2_02:72]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-13-296557:8k_2_02:73]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized loss on settled future contracts (a) |  | $ | 0.4 |  |  | $ | 0.7 |  |  | $ | 0.4 |  |  | $ | 1.0 |  |
| Foreign currency exchange loss (gain) (a) |  |  | 0.9 |  |  |  | (0.1 | ) |  |  | 0.6 |  |  |  | (0.3 | ) |
| Loss on disposal of fixed assets (a) |  |  | — |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | 0.7 |  |  |  | 0.5 |  |  |  | 1.8 |  |  |  | (1.2 | ) |
| Special legal contingency charge (b) |  |  | — |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 2.1 |  |  | $ | 1.4 |  |  | $ | 3.2 |  |  | $ | — |  |

[0001193125-13-296557:8k_2_02:74]
| (a) | Included in segment profit (loss) and adjusted income from continuing operations |

[0001193125-13-296557:8k_2_02:75]
| (b) | Excluded from segment profit (loss) and adjusted income from continuing operations |

[0001193125-13-296557:8k_2_02:76]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations—Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations—Diluted, a GAAP measure

[0001193125-13-296557:8k_2_02:77]
|  |  | For the YearEndedDecember 31,2013ESTIMATED |  |
| Adjusted income per share from continuing operations—diluted, a Non-GAAP measure |  | $ | 3.45—$3.75 |  |
| Restructuring charges and net change in unrealized losses on open future contracts |  |  | (0.07 | ) |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 3.38—$3.68 |  |

[0001193125-13-296557:8k_2_02:78]
Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP
measure

[0001193125-13-296557:8k_2_02:79]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 49.0 |  |  | $ | 23.7 |  |  | $ | (88.3 | ) |  | $ | (10.6 | ) |
| Purchases of property, plant and equipment |  |  | (11.3 | ) |  |  | (9.8 | ) |  |  | (23.4 | ) |  |  | (16.4 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.1 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 37.7 |  |  | $ | 13.9 |  |  | $ | (111.7 | ) |  | $ | (26.9 | ) |

[0001193125-13-296557:8k_2_02:80]
Calculation of Debt to EBITDA Ratio:

[0001193125-13-296557:8k_2_02:81]
|  |  | TrailingTwelveMonths toJune 30, 2013 |  |
| EBIT (a) |  | $ | 258.9 |  |
| Depreciation and amortization expense (b) |  | $ | 56.5 |  |
| EBITDA (a + b) |  | $ | 315.4 |  |
| Total debt at June 30, 2013 (c) |  | $ | 537.1 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 1.7 |  |

[0001193125-13-296557:8k_2_02:82]
Reconciliation of EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure

[0001193125-13-296557:8k_2_02:83]
|  |  | TrailingTwelveMonths toJune 30, 2013 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 258.9 |  |
| Special product quality adjustments |  |  | 0.9 |  |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 2.9 |  |
| Restructuring charges |  |  | 4.4 |  |
| Interest expense, net |  |  | 15.1 |  |
| Other expenses, net |  |  | 0.1 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 235.5 |  |
