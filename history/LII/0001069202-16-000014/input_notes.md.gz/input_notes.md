# LII notes — 0001069202-16-000014


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-16-000014:notes:1]
The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-16-000014:notes:2]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 200.0 |  |  | 220.0 |  |
| Remaining amount available | $ | 20.0 |  |  | $ | — |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-16-000014:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-16-000014:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:ScheduleOfFairValueOfPerformanceShareUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-16-000014:notes:5]
The total fair value of performance share units distributed and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-16-000014:notes:6]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Fair value of performance share units distributed | $ | 44.9 |  |  | $ | 19.6 |  |  | $ | 9.9 |  |
| Realized tax benefits from tax deductions | $ | 17.1 |  |  | $ | 7.5 |  |  | $ | 3.8 |  |


## lii:ScheduleOfFairValueOfRestrictedStockUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-16-000014:notes:7]
The total fair value of restricted stock units vested and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-16-000014:notes:8]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Fair value of restricted stock units vested | $ | 19.7 |  |  | $ | 19.5 |  |  | $ | 11.1 |  |
| Realized tax benefits from tax deductions | 7.5 |  |  | 7.4 |  |  | 4.3 |  |


## lii:ScheduleOfIntrinsicValueAndTaxBenefitsRelatedToStockAppreciationRightsTableTextBlock

[0001069202-16-000014:notes:9]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-16-000014:notes:10]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Intrinsic value of stock appreciation rights exercised | $ | 27.3 |  |  | $ | 27.3 |  |  | $ | 16.7 |  |
| Realized tax benefits from tax deductions | $ | 10.4 |  |  | $ | 10.4 |  |  | $ | 6.4 |  |


## lii:ScheduleOfShareBasedCompensationSharesAuthorizedUnderEquityInstrumentOtherThanOptionPlansByExercisePriceRangeTableTextBlock

[0001069202-16-000014:notes:11]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2015 (in millions, except per share data and years):

[0001069202-16-000014:notes:12]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $34.06 to $46.78 |  | 0.4 |  |  | 2.33 |  | $ | 35.2 |  |  | 0.4 |  |  | 2.3 |  | $ | 35.2 |  |
| $51.11 to $81.14 |  | 0.5 |  |  | 4.5 |  | $ | 28.3 |  |  | 0.4 |  |  | 4.4 |  | $ | 25.1 |  |
| $92.64 to $126.31 |  | 0.4 |  |  | 6.0 |  | $ | 7.6 |  |  | 0.1 |  |  | 6.0 |  | $ | 2.5 |  |


## lii:SummaryOfTargetAllocationPercentageOfAssetsTableTextBlock

[0001069202-16-000014:notes:13]
U.S. pension plan assets are invested within the following range targets:

[0001069202-16-000014:notes:14]
| Asset Category: | Target |
| U.S. equity | 25.0 | % |
| International equity | 17.0 | % |
| Fixed income | 56.0 | % |
| Money market/cash/guaranteed investment contracts | 2.0 | % |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-16-000014:notes:15]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-16-000014:notes:16]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Weighted average borrowing rate | 1.90 | % |  | 1.88 | % |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-16-000014:notes:17]
Accrued Expenses:

[0001069202-16-000014:notes:18]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-16-000014:notes:19]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Accrued compensation and benefits | $ | 67.6 |  |  | $ | 73.3 |  |
| Self insurance reserves | 9.2 |  |  | 13.0 |  |
| Deferred income | 6.8 |  |  | 11.6 |  |
| Accrued warranties | 26.7 |  |  | 27.3 |  |
| Accrued product quality reserves | 3.5 |  |  | 4.2 |  |
| Accrued Sales, Use and VAT taxes | 11.0 |  |  | 8.7 |  |
| Accrued rebates and promotions | 53.6 |  |  | 45.4 |  |
| Derivative contracts | 14.4 |  |  | 7.4 |  |
| Other | 49.8 |  |  | 48.1 |  |
| Total Accrued expenses | $ | 242.6 |  |  | $ | 239.0 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-16-000014:notes:20]
Supplemental Information:

[0001069202-16-000014:notes:21]
Below is information about expenses included in our Consolidated Statements of Operations (in millions):

[0001069202-16-000014:notes:22]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Research and development | $ | 62.3 |  |  | $ | 60.7 |  |  | $ | 53.7 |  |
| Advertising, promotions and marketing (1) | 42.5 |  |  | 41.9 |  |  | 45.2 |  |
| Cooperative advertising expenditures (2) | 13.7 |  |  | 13.1 |  |  | 10.9 |  |
| Rent expense (3) | 53.5 |  |  | 50.5 |  |  | 53.5 |  |

[0001069202-16-000014:notes:23]
(1) Includes advertising, promotions and marketing costs related to discontinued operations of $4.1 million for the year ended December 31, 2013.  No advertising costs related to discontinued operations were recorded for the years ended December 31, 2015 and 2014.  Cooperative advertising expenditures were not included in these amounts.

[0001069202-16-000014:notes:24]
(2) Cooperative advertising expenditures were included in Selling, general and administrative expenses in the Consolidated Statements of Operations.

[0001069202-16-000014:notes:25]
(3) Includes rent expense related to discontinued operations of $4.5 million for the year ended December 31, 2013.  No rent costs related to discontinued operations were recorded for the year ended December 31, 2015 and 2014.

[0001069202-16-000014:notes:26]
Interest Expense, net

[0001069202-16-000014:notes:27]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-16-000014:notes:28]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Interest expense, net of capitalized interest | $ | 25.2 |  |  | $ | 18.9 |  |  | $ | 16.5 |  |
| Interest income | 1.6 |  |  | 1.7 |  |  | 2.0 |  |
| Interest expense, net | $ | 23.6 |  |  | $ | 17.2 |  |  | $ | 14.5 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001069202-16-000014:notes:29]
Cash and Cash Equivalents

[0001069202-16-000014:notes:30]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-16-000014:notes:31]
Commitments and Contingencies:

[0001069202-16-000014:notes:32]
Leases

[0001069202-16-000014:notes:33]
We lease certain real and personal property under non-cancelable operating leases.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions.  We recognize our minimum rental expense on a straight-line basis.  We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use.

[0001069202-16-000014:notes:34]
Future annual minimum lease payments and capital lease commitments as of December 31, 2015 were as follows (in millions):

[0001069202-16-000014:notes:35]
|  | Operating Leases |  | Capital Leases |
| 2016 | $ | 42.8 |  |  | $ | 1.2 |  |
| 2017 | 32.8 |  |  | 0.8 |  |
| 2018 | 24.9 |  |  | 0.5 |  |
| 2019 | 15.6 |  |  | 0.2 |  |
| 2020 | 7.7 |  |  | — |  |
| Thereafter | 14.5 |  |  | 14.6 |  |
| Total minimum lease payments | $ | 138.3 |  |  | $ | 17.3 |  |
| Less amount representing interest |  |  | 0.4 |  |
| Present value of minimum payments |  |  | $ | 16.9 |  |

[0001069202-16-000014:notes:36]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the “Lake Park Renewal”).  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-16-000014:notes:37]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Fifth Amended and Restated Credit Facility Agreement.  We were in compliance with these financial covenants as of December 31, 2015.

[0001069202-16-000014:notes:38]
Environmental

[0001069202-16-000014:notes:39]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities, however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000014:notes:40]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Accrued expenses | $ | 1.3 |  |  | $ | 1.7 |  |
| Other liabilities | 4.0 |  |  | 4.5 |  |
| Total environmental accruals | $ | 5.3 |  |  | $ | 6.2 |  |

[0001069202-16-000014:notes:41]
Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-16-000014:notes:42]
Product Warranties and Product Related Contingencies

[0001069202-16-000014:notes:43]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-16-000014:notes:44]
Total product warranty liabilities related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000014:notes:45]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Accrued expenses | $ | 26.7 |  |  | $ | 27.3 |  |
| Other liabilities | 65.6 |  |  | 59.9 |  |
| Total product warranty liabilities | $ | 92.3 |  |  | $ | 87.2 |  |

[0001069202-16-000014:notes:46]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2015 and 2014 were as follows (in millions):

[0001069202-16-000014:notes:47]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Payments made in 2014 | (23.1 | ) |
| Changes resulting from issuance of new warranties | 33.4 |  |
| Changes in estimates associated with pre-existing liabilities | (3.5 | ) |
| Changes in foreign currency translation rates and other | (1.2 | ) |
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |
| Payments made in 2015 | (27.2 | ) |
| Changes resulting from issuance of new warranties | 37.1 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | (2.2 | ) |
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |

[0001069202-16-000014:notes:48]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands,  we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a certain supplier quality issue within a range of $2.5 million and $9.9 million with all amounts in that range equally likely.  We have accrued a $2.5 million liability in Accrued expenses on the Consolidated Balance Sheet at December 31, 2015. The supplier is reimbursing the majority of costs related to this liability.

[0001069202-16-000014:notes:49]
Self Insurance

[0001069202-16-000014:notes:50]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability, auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers' compensation/employers' liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors' and officers' liability, property damage and certain other insurance programs.    For directors' and officers' liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-16-000014:notes:51]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001069202-16-000014:notes:52]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000014:notes:53]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Accrued expenses | $ | 9.2 |  |  | $ | 13.0 |  |
| Other liabilities | 23.9 |  |  | 25.8 |  |
| Total self-insurance liabilities | $ | 33.1 |  |  | $ | 38.8 |  |

[0001069202-16-000014:notes:54]
Litigation

[0001069202-16-000014:notes:55]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-16-000014:notes:56]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors, and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the years ended December 31, 2015 and 2014, we recorded expense of $3.0 million and $0.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation.

[0001069202-16-000014:notes:57]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-16-000014:notes:58]
Comprehensive Income:

[0001069202-16-000014:notes:59]
The following table provides information on items not reclassified in their entirety from AOCI to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-16-000014:notes:60]
|  |  | For the Years Ended December 31, |  |  |
| AOCI Component |  | 2015 |  | 2014 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Losses on cash flow hedges: |  |  |  |  |  |  |
| Commodity derivative contracts |  | $ | (12.5 | ) |  | $ | (5.8 | ) |  | Cost of goods sold |
| Income tax benefit |  | 4.4 |  |  | 2.0 |  |  | Provision for income taxes |
| Net of tax |  | $ | (8.1 | ) |  | $ | (3.8 | ) |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and Post-Retirement Benefits costs |  | $ | (9.7 | ) |  | $ | (6.9 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 3.4 |  |  | 2.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (6.3 | ) |  | $ | (4.5 | ) |  |  |
| Total reclassifications from AOCI |  | $ | (14.4 | ) |  | $ | (8.3 | ) |  |  |

[0001069202-16-000014:notes:61]
The following tables provide information on changes in AOCI, by component (net of tax), for the years ended December 31, 2015 and 2014 (in millions):

[0001069202-16-000014:notes:62]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2014 |  | $ | (4.6 | ) |  | $ | 3.2 |  |  | $ | (149.4 | ) |  | $ | (2.7 | ) |  | $ | (153.5 | ) |
| Other comprehensive income (loss) before reclassifications |  | (11.9 | ) |  | 1.2 |  |  | 3.8 |  |  | (58.7 | ) |  | (65.6 | ) |
| Amounts reclassified from AOCI |  | 8.1 |  |  | — |  |  | 6.3 |  |  | — |  |  | 14.4 |  |
| Net other comprehensive income (loss) |  | (3.8 | ) |  | 1.2 |  |  | 10.1 |  |  | (58.7 | ) |  | (51.2 | ) |
| Balance as of December 31, 2015 |  | $ | (8.4 | ) |  | $ | 4.4 |  |  | $ | (139.3 | ) |  | $ | (61.4 | ) |  | $ | (204.7 | ) |

[0001069202-16-000014:notes:63]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2013 |  | $ | (0.6 | ) |  | $ | 2.5 |  |  | $ | (106.0 | ) |  | $ | 43.0 |  |  | $ | (61.1 | ) |
| Other comprehensive income (loss) before reclassifications |  | (7.8 | ) |  | 0.7 |  |  | (47.9 | ) |  | (45.7 | ) |  | (100.7 | ) |
| Amounts reclassified from AOCI |  | 3.8 |  |  | — |  |  | 4.5 |  |  | — |  |  | 8.3 |  |
| Net other comprehensive income (loss) |  | (4.0 | ) |  | 0.7 |  |  | (43.4 | ) |  | (45.7 | ) |  | (92.4 | ) |
| Balance as of December 31, 2014 |  | $ | (4.6 | ) |  | $ | 3.2 |  |  | $ | (149.4 | ) |  | $ | (2.7 | ) |  | $ | (153.5 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-16-000014:notes:64]
Condensed Consolidating Financial Statements:

[0001069202-16-000014:notes:65]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-16-000014:notes:66]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present condensed consolidating financial statements.

[0001069202-16-000014:notes:67]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd.  The primary subsidiary for the U.S. Service Experts business had previously been included as a "Guarantor Subsidiary" and the Canada Service Experts subsidiary had previously been included as a "Non-Guarantor Subsidiary."  As of December 31, 2014, the U.S. and Canada Service Experts businesses were included in discontinued operations of the condensed consolidating financial statements.

[0001069202-16-000014:notes:68]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001069202-16-000014:notes:69]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2015 and December 31, 2014 and for the years ended December 31, 2015, 2014 and 2013 are shown on the following pages.

[0001069202-16-000014:notes:70]
Condensed Consolidating Balance Sheets

[0001069202-16-000014:notes:71]
As of December 31, 2015

[0001069202-16-000014:notes:72]
(In millions)

[0001069202-16-000014:notes:73]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.5 |  |  | $ | 7.8 |  |  | $ | 30.6 |  |  | $ | — |  |  | $ | 38.9 |  |
| Accounts and notes receivable, net | — |  |  | 25.9 |  |  | 396.9 |  |  | — |  |  | 422.8 |  |
| Inventories, net | — |  |  | 324.3 |  |  | 98.9 |  |  | (4.4 | ) |  | 418.8 |  |
| Other assets | 3.3 |  |  | 46.9 |  |  | 67.4 |  |  | (59.9 | ) |  | 57.7 |  |
| Total current assets | 3.8 |  |  | 404.9 |  |  | 593.8 |  |  | (64.3 | ) |  | 938.2 |  |
| Property, plant and equipment, net | — |  |  | 261.8 |  |  | 77.8 |  |  | — |  |  | 339.6 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 879.0 |  |  | 337.6 |  |  | (0.6 | ) |  | (1,216.0 | ) |  | — |  |
| Deferred income taxes | 5.4 |  |  | 126.6 |  |  | 28.4 |  |  | (14.7 | ) |  | 145.7 |  |
| Other assets, net | 4.3 |  |  | 38.2 |  |  | 20.6 |  |  | (1.5 | ) |  | 61.6 |  |
| Intercompany receivables (payables), net | (278.6 | ) |  | 253.3 |  |  | 25.3 |  |  | — |  |  | — |  |
| Total assets | $ | 613.9 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,680.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 204.1 |  |  | $ | — |  |  | $ | 204.1 |  |
| Current maturities of long-term debt | 30.0 |  |  | 0.8 |  |  | 0.4 |  |  | — |  |  | 31.2 |  |
| Accounts payable | 16.1 |  |  | 237.9 |  |  | 66.1 |  |  | — |  |  | 320.1 |  |
| Accrued expenses | 15.8 |  |  | 176.7 |  |  | 50.1 |  |  | — |  |  | 242.6 |  |
| Income taxes payable | (43.0 | ) |  | 106.6 |  |  | 37.9 |  |  | (75.5 | ) |  | 26.0 |  |
| Total current liabilities | 18.9 |  |  | 522.0 |  |  | 358.6 |  |  | (75.5 | ) |  | 824.0 |  |
| Long-term debt | 493.0 |  |  | 15.1 |  |  | 0.5 |  |  | — |  |  | 508.6 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.1 |  |  | — |  |  | — |  |  | 4.1 |  |
| Pensions | — |  |  | 111.9 |  |  | 8.9 |  |  | — |  |  | 120.8 |  |
| Other liabilities | 0.4 |  |  | 114.4 |  |  | 10.5 |  |  | (4.2 | ) |  | 121.1 |  |
| Total liabilities | 512.3 |  |  | 767.5 |  |  | 378.5 |  |  | (79.7 | ) |  | 1,578.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 101.6 |  |  | 789.8 |  |  | 427.0 |  |  | (1,216.8 | ) |  | 101.6 |  |
| Total liabilities and stockholders' equity | $ | 613.9 |  |  | $ | 1,557.3 |  |  | $ | 805.5 |  |  | $ | (1,296.5 | ) |  | $ | 1,680.2 |  |

[0001069202-16-000014:notes:74]
As of December 31, 2014

[0001069202-16-000014:notes:75]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 11.5 |  |  | $ | 25.0 |  |  | $ | — |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net | — |  |  | 12.3 |  |  | 409.1 |  |  | — |  |  | 421.4 |  |
| Inventories, net | — |  |  | 350.6 |  |  | 119.7 |  |  | (7.0 | ) |  | 463.3 |  |
| Other assets | 3.6 |  |  | 45.7 |  |  | 67.2 |  |  | (57.2 | ) |  | 59.3 |  |
| Total current assets | 4.6 |  |  | 420.1 |  |  | 621.0 |  |  | (64.2 | ) |  | 981.5 |  |
| Property, plant and equipment, net | — |  |  | 269.0 |  |  | 89.6 |  |  | — |  |  | 358.6 |  |
| Goodwill | — |  |  | 140.4 |  |  | 69.0 |  |  | — |  |  | 209.4 |  |
| Investment in subsidiaries | 978.1 |  |  | 263.5 |  |  | (0.6 | ) |  | (1,241.0 | ) |  | — |  |
| Deferred income taxes | 3.3 |  |  | 118.1 |  |  | 23.2 |  |  | (14.6 | ) |  | 130.0 |  |
| Other assets, net | 5.2 |  |  | 61.0 |  |  | 20.1 |  |  | (1.5 | ) |  | 84.8 |  |
| Intercompany receivables (payables), net | (280.4 | ) |  | 302.4 |  |  | (22.0 | ) |  | — |  |  | — |  |
| Total assets | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 226.6 |  |  | $ | — |  |  | $ | 226.6 |  |
| Current maturities of long-term debt | 22.5 |  |  | 1.2 |  |  | 0.3 |  |  | — |  |  | 24.0 |  |
| Accounts payable | 13.4 |  |  | 237.8 |  |  | 73.1 |  |  | — |  |  | 324.3 |  |
| Accrued expenses | 9.0 |  |  | 175.5 |  |  | 54.5 |  |  | — |  |  | 239.0 |  |
| Income taxes payable | (3.7 | ) |  | 34.7 |  |  | 47.5 |  |  | (65.1 | ) |  | 13.4 |  |
| Total current liabilities | 41.2 |  |  | 449.2 |  |  | 402.0 |  |  | (65.1 | ) |  | 827.3 |  |
| Long-term debt | 659.5 |  |  | 15.3 |  |  | 0.2 |  |  | — |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| Pensions | — |  |  | 117.6 |  |  | 12.3 |  |  | — |  |  | 129.9 |  |
| Other liabilities | 1.1 |  |  | 118.7 |  |  | 11.7 |  |  | (12.9 | ) |  | 118.6 |  |
| Total liabilities | 701.8 |  |  | 705.3 |  |  | 426.2 |  |  | (78.0 | ) |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 9.0 |  |  | 869.2 |  |  | 374.1 |  |  | (1,243.3 | ) |  | 9.0 |  |
| Total liabilities and stockholders' equity | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |

[0001069202-16-000014:notes:76]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-16-000014:notes:77]
For the Year Ended December 31, 2015

[0001069202-16-000014:notes:78]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,950.6 |  |  | $ | 701.8 |  |  | $ | (185.0 | ) |  | $ | 3,467.4 |  |
| Cost of goods sold | — |  |  | 2,150.9 |  |  | 556.4 |  |  | (187.3 | ) |  | 2,520.0 |  |
| Gross profit | — |  |  | 799.7 |  |  | 145.4 |  |  | 2.3 |  |  | 947.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 485.6 |  |  | 94.9 |  |  | — |  |  | 580.5 |  |
| Losses and other expenses, net | 0.7 |  |  | 13.7 |  |  | 7.5 |  |  | (0.2 | ) |  | 21.7 |  |
| Restructuring charges | — |  |  | (0.5 | ) |  | 3.7 |  |  | — |  |  | 3.2 |  |
| Goodwill impairment | — |  |  | 5.5 |  |  | — |  |  | — |  |  | 5.5 |  |
| Asset impairment | — |  |  | 44.5 |  |  | — |  |  | — |  |  | 44.5 |  |
| Income from equity method investments | (201.8 | ) |  | (5.9 | ) |  | (10.5 | ) |  | 204.8 |  |  | (13.4 | ) |
| Operational income from continuing operations | 201.1 |  |  | 256.8 |  |  | 49.8 |  |  | (202.3 | ) |  | 305.4 |  |
| Interest expense, net | 22.4 |  |  | (2.0 | ) |  | 3.2 |  |  | — |  |  | 23.6 |  |
| Other expense, net | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Income from continuing operations before income taxes | 178.7 |  |  | 258.8 |  |  | 47.4 |  |  | (202.3 | ) |  | 282.6 |  |
| Provision for income taxes | (7.8 | ) |  | 87.9 |  |  | 14.3 |  |  | 1.0 |  |  | 95.4 |  |
| Income from continuing operations | 186.5 |  |  | 170.9 |  |  | 33.1 |  |  | (203.3 | ) |  | 187.2 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.6 | ) |  | — |  |  | (0.6 | ) |
| Net income | $ | 186.5 |  |  | $ | 170.9 |  |  | $ | 32.5 |  |  | $ | (203.3 | ) |  | $ | 186.6 |  |
| Other comprehensive income (loss) | $ | (3.5 | ) |  | $ | (3.3 | ) |  | $ | (40.4 | ) |  | $ | (4.0 | ) |  | $ | (51.2 | ) |
| Comprehensive Income | $ | 183.0 |  |  | $ | 167.6 |  |  | $ | (7.9 | ) |  | $ | (207.3 | ) |  | $ | 135.4 |  |

[0001069202-16-000014:notes:79]
For the Year Ended December 31, 2014

[0001069202-16-000014:notes:80]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net sales | $ | — |  |  | $ | 2,775.7 |  |  | $ | 818.0 |  |  | $ | (226.3 | ) |  | $ | 3,367.4 |  |
| Cost of goods sold | — |  |  | 2,057.8 |  |  | 628.3 |  |  | (222.0 | ) |  | 2,464.1 |  |
| Gross profit | — |  |  | 717.9 |  |  | 189.7 |  |  | (4.3 | ) |  | 903.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 454.5 |  |  | 119.2 |  |  | — |  |  | 573.7 |  |
| Losses and other expenses, net | — |  |  | 3.2 |  |  | 3.6 |  |  | — |  |  | 6.8 |  |
| Restructuring charges | — |  |  | 0.4 |  |  | 1.5 |  |  | — |  |  | 1.9 |  |
| Income from equity method investments | (216.4 | ) |  | (25.4 | ) |  | (11.3 | ) |  | 239.3 |  |  | (13.8 | ) |
| Operational income from continuing operations | 216.4 |  |  | 285.2 |  |  | 76.7 |  |  | (243.6 | ) |  | 334.7 |  |
| Interest expense, net | 16.0 |  |  | (3.0 | ) |  | 4.2 |  |  | — |  |  | 17.2 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 200.4 |  |  | 288.2 |  |  | 72.6 |  |  | (243.6 | ) |  | 317.6 |  |
| Provision for income taxes | (5.6 | ) |  | 91.7 |  |  | 24.9 |  |  | (1.5 | ) |  | 109.5 |  |
| Income from continuing operations | 206.0 |  |  | 196.5 |  |  | 47.7 |  |  | (242.1 | ) |  | 208.1 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (2.3 | ) |  | — |  |  | (2.3 | ) |
| Net income | $ | 206.0 |  |  | $ | 196.5 |  |  | $ | 45.4 |  |  | $ | (242.1 | ) |  | $ | 205.8 |  |
| Other comprehensive income (loss) | $ | (4.1 | ) |  | $ | (51.2 | ) |  | $ | (34.8 | ) |  | $ | (2.3 | ) |  | $ | (92.4 | ) |
| Comprehensive income | $ | 201.9 |  |  | $ | 145.3 |  |  | $ | 10.6 |  |  | $ | (244.4 | ) |  | $ | 113.4 |  |

[0001069202-16-000014:notes:81]
For the Year Ended December 31, 2013

[0001069202-16-000014:notes:82]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,557.9 |  |  | $ | 837.0 |  |  | $ | (195.8 | ) |  | $ | 3,199.1 |  |
| Cost of goods sold | — |  |  | 1,900.9 |  |  | 632.8 |  |  | (195.8 | ) |  | 2,337.9 |  |
| Gross profit | — |  |  | 657.0 |  |  | 204.2 |  |  | — |  |  | 861.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 437.1 |  |  | 133.0 |  |  | — |  |  | 570.1 |  |
| Losses and other expenses, net | 1.1 |  |  | 7.9 |  |  | 0.3 |  |  | — |  |  | 9.3 |  |
| Restructuring charges | — |  |  | 2.9 |  |  | 2.1 |  |  | — |  |  | 5.0 |  |
| Income from equity method investments | (181.7 | ) |  | (26.4 | ) |  | (9.7 | ) |  | 205.6 |  |  | (12.2 | ) |
| Operational income from continuing operations | 180.6 |  |  | 235.5 |  |  | 78.5 |  |  | (205.6 | ) |  | 289.0 |  |
| Interest expense, net | 14.0 |  |  | (2.1 | ) |  | 2.6 |  |  | — |  |  | 14.5 |  |
| Other expense, net | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Income from continuing operations before income taxes | 166.6 |  |  | 237.6 |  |  | 75.7 |  |  | (205.6 | ) |  | 274.3 |  |
| Provision for income taxes | (5.2 | ) |  | 73.7 |  |  | 25.9 |  |  | — |  |  | 94.4 |  |
| Income from continuing operations | 171.8 |  |  | 163.9 |  |  | 49.8 |  |  | (205.6 | ) |  | 179.9 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (8.1 | ) |  | — |  |  | (8.1 | ) |
| Net income | $ | 171.8 |  |  | $ | 163.9 |  |  | $ | 41.7 |  |  | $ | (205.6 | ) |  | $ | 171.8 |  |
| Other comprehensive income (loss) | $ | (38.8 | ) |  | $ | 36.3 |  |  | $ | (6.1 | ) |  | $ | (30.2 | ) |  | $ | (38.8 | ) |
| Comprehensive Income | $ | 133.0 |  |  | $ | 200.2 |  |  | $ | 35.6 |  |  | $ | (235.8 | ) |  | $ | 133.0 |  |

[0001069202-16-000014:notes:83]
Condensed Consolidating Statements of Cash Flows

[0001069202-16-000014:notes:84]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 226.9 |  |  | $ | 49.3 |  |  | $ | 55.0 |  |  | $ | — |  |  | $ | 331.2 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (60.2 | ) |  | (9.7 | ) |  | — |  |  | (69.9 | ) |
| Net cash used in investing activities | — |  |  | (60.1 | ) |  | (9.7 | ) |  | — |  |  | (69.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.7 | ) |  | — |  |  | (1.7 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (60.0 | ) |  | — |  |  | (60.0 | ) |
| Borrowings from credit facility | 1,671.0 |  |  | — |  |  | — |  |  | — |  |  | 1,671.0 |  |
| Long-term debt payments | (22.5 | ) |  | (1.2 | ) |  | (0.3 | ) |  | — |  |  | (24.0 | ) |
| Payments on credit facility | (1,807.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,807.5 | ) |
| Proceeds from employee stock purchases | 2.4 |  |  | — |  |  | — |  |  | — |  |  | 2.4 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (32.0 | ) |  | — |  |  | — |  |  | — |  |  | (32.0 | ) |
| Excess tax benefits related to share-based payments | 22.4 |  |  | — |  |  | — |  |  | — |  |  | 22.4 |  |
| Intercompany debt | (9.4 | ) |  | 7.1 |  |  | 2.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | 7.5 |  |  | 1.2 |  |  | (8.7 | ) |  | — |  |  | — |  |
| Cash dividends paid | (59.3 | ) |  |  |  |  |  |  |  |  |  |  | (59.3 | ) |
| Net cash provided by (used in) financing activities | (227.4 | ) |  | 7.1 |  |  | (28.4 | ) |  | — |  |  | (248.7 | ) |
| Increase (decrease) in cash and cash equivalents | (0.5 | ) |  | (3.7 | ) |  | 16.9 |  |  | — |  |  | 12.7 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (11.3 | ) |  | — |  |  | (11.3 | ) |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of year | $ | 0.5 |  |  | $ | 7.8 |  |  | $ | 30.6 |  |  | $ | — |  |  | $ | 38.9 |  |

[0001069202-16-000014:notes:85]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 328.8 |  |  | $ | (97.2 | ) |  | $ | (46.8 | ) |  | $ | — |  |  | $ | 184.8 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 1.0 |  |  | 0.1 |  |  | — |  |  | 1.1 |  |
| Purchases of property, plant and equipment | — |  |  | (70.5 | ) |  | (17.9 | ) |  | — |  |  | (88.4 | ) |
| Net cash used in investing activities | — |  |  | (69.5 | ) |  | (17.8 | ) |  | — |  |  | (87.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.5 |  |  | — |  |  | 1.5 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 100.0 |  |  | — |  |  | 100.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Term loan borrowings from credit facility | 300.0 |  |  | — |  |  | — |  |  | — |  |  | 300.0 |  |
| Long-term debt payments | — |  |  | (1.9 | ) |  | (0.4 | ) |  | — |  |  | (2.3 | ) |
| Borrowings from credit facility | 2,073.5 |  |  | — |  |  | — |  |  | — |  |  | 2,073.5 |  |
| Payments on credit facility | (1,908.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,908.5 | ) |
| Payments of deferred financing costs | (2.2 | ) |  | — |  |  | — |  |  | — |  |  | (2.2 | ) |
| Proceeds from employee stock purchases | 2.0 |  |  | — |  |  | — |  |  | — |  |  | 2.0 |  |
| Repurchases of common stock | (550.3 | ) |  | — |  |  | — |  |  | — |  |  | (550.3 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (22.4 | ) |  | — |  |  | — |  |  | — |  |  | (22.4 | ) |
| Excess tax benefits related to share-based payments | 11.8 |  |  | — |  |  | — |  |  | — |  |  | 11.8 |  |
| Intercompany debt | (0.1 | ) |  | 4.7 |  |  | (4.6 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (180.1 | ) |  | 164.9 |  |  | 15.2 |  |  | — |  |  | — |  |
| Cash dividends paid | (52.6 | ) |  | — |  |  | — |  |  | — |  |  | (52.6 | ) |
| Net cash provided by (used in) financing activities | (328.9 | ) |  | 167.7 |  |  | 71.7 |  |  | — |  |  | (89.5 | ) |
| Increase (decrease) in cash and cash equivalents | (0.1 | ) |  | 1.0 |  |  | 7.1 |  |  | — |  |  | 8.0 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (8.5 | ) |  | — |  |  | (8.5 | ) |
| Cash and cash equivalents, beginning of year | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of year | $ | 1.0 |  |  | $ | 11.5 |  |  | $ | 25.0 |  |  | $ | — |  |  | $ | 37.5 |  |

[0001069202-16-000014:notes:86]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (30.4 | ) |  | $ | 328.4 |  |  | $ | (87.7 | ) |  | $ | — |  |  | $ | 210.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 2.4 |  |  | — |  |  | — |  |  | 2.4 |  |
| Purchases of property, plant and equipment | — |  |  | (55.8 | ) |  | (22.5 | ) |  | — |  |  | (78.3 | ) |
| Net Proceeds from sale of business | 5.3 |  |  | — |  |  | 3.3 |  |  | — |  |  | 8.6 |  |
| Net cash used in investing activities | 5.3 |  |  | (53.4 | ) |  | (19.2 | ) |  | — |  |  | (67.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 330.0 |  |  | — |  |  | 330.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (200.0 | ) |  | — |  |  | (200.0 | ) |
| Long-term debt payments | — |  |  | (0.7 | ) |  | (0.3 | ) |  | — |  |  | (1.0 | ) |
| Borrowings from revolving credit facility | 1,425.5 |  |  | — |  |  | — |  |  | — |  |  | 1,425.5 |  |
| Payments on revolving credit facility | (1,543.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,543.5 | ) |
| Proceeds from employee stock purchases | 1.8 |  |  | — |  |  | — |  |  | — |  |  | 1.8 |  |
| Additional investment in subsidiary | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Repurchases of common stock | (125.0 | ) |  | — |  |  | — |  |  | — |  |  | (125.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (12.0 | ) |  | — |  |  | — |  |  | — |  |  | (12.0 | ) |
| Excess tax benefits related to share-based payments | 6.5 |  |  | — |  |  | — |  |  | — |  |  | 6.5 |  |
| Intercompany debt | (26.8 | ) |  | 12.3 |  |  | 14.5 |  |  | — |  |  | — |  |
| Intercompany financing activity | 332.7 |  |  | (289.5 | ) |  | (43.2 | ) |  | — |  |  | — |  |
| Cash dividends paid | (34.0 | ) |  | — |  |  | — |  |  | — |  |  | (34.0 | ) |
| Net cash provided by (used in) financing activities | 25.2 |  |  | (277.9 | ) |  | 102.5 |  |  | — |  |  | (150.2 | ) |
| Decrease in cash and cash equivalents | 0.1 |  |  | (2.9 | ) |  | (4.4 | ) |  | — |  |  | (7.2 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (6.6 | ) |  | — |  |  | (6.6 | ) |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of year | $ | 1.1 |  |  | $ | 10.5 |  |  | $ | 26.4 |  |  | $ | — |  |  | $ | 38.0 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001069202-16-000014:notes:87]
Principles of Consolidation

[0001069202-16-000014:notes:88]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.


## us-gaap:CostOfSalesPolicyTextBlock

[0001069202-16-000014:notes:89]
Cost of Goods Sold

[0001069202-16-000014:notes:90]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.


## us-gaap:DebtDisclosureTextBlock

[0001069202-16-000014:notes:91]
Lines of Credit and Financing Arrangements:

[0001069202-16-000014:notes:92]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000014:notes:93]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 200.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 4.1 |  |  | 6.6 |  |
| Total short-term debt | $ | 204.1 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.2 |  |  | $ | 1.5 |  |
| Domestic credit facility | 30.0 |  |  | 22.5 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.6 |  |  | $ | 15.5 |  |
| Domestic credit facility | 293.0 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 508.6 |  |  | $ | 675.0 |  |
| Total debt | $ | 743.9 |  |  | $ | 925.6 |  |

[0001069202-16-000014:notes:94]
As of December 31, 2015, the aggregate amounts of required principal payments on total debt were as follows (in millions):

[0001069202-16-000014:notes:95]
| 2016 | $ | 235.3 |  |
| 2017 | 231.3 |  |
| 2018 | 32.6 |  |
| 2019 | 233.0 |  |
| 2020 | — |  |
| Thereafter | 11.7 |  |

[0001069202-16-000014:notes:96]
Short-Term Debt

[0001069202-16-000014:notes:97]
Short Term Facility

[0001069202-16-000014:notes:98]
On October 20, 2014, Lennox International Inc. (the “Company”) entered into a short term loan agreement (the “Short-Term Facility”) with JPMorgan Chase Bank, N.A., as administrative agent, and Morgan Stanley Bank, N.A. and the other lenders named therein, to borrow $250.0 million. The Short-Term Facility had a maturity date of March 31, 2015, but was prepaid in full without penalty in November 2014. The term loan bore interest at a variable base rate or a variable rate based on the London interbank offered rate, at the Company’s election, plus a spread.

[0001069202-16-000014:notes:99]
Foreign Obligations

[0001069202-16-000014:notes:100]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $4.1 million and $6.6 million of foreign obligations as of December 31, 2015 and 2014, respectively, that were primarily borrowings under non-committed facilities.  Proceeds on these facilities were $79.0 million, $85.3 million and $18.3 million during the years ended December 31, 2015, 2014 and 2013, respectively. Repayments on the facilities were $85.4 million, $87.8 million and $16.3 million during the years ended December 31, 2015, 2014 and 2013, respectively.

[0001069202-16-000014:notes:101]
Asset Securitization Program

[0001069202-16-000014:notes:102]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-16-000014:notes:103]
In November 2015, we amended the ASP, extending its term to November 13, 2017 and maintaining the maximum securitization amount range of $180.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-16-000014:notes:104]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rates as of December 31, 2015 and 2014 were 1.06% and 0.79%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180.0 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-16-000014:notes:105]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over  $75.0 million.  The administrative agent under the ASP is also a participant in our Domestic Credit Facility.  The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of December 31, 2015, we were in compliance with all covenant requirements.

[0001069202-16-000014:notes:106]
Long-Term Debt

[0001069202-16-000014:notes:107]
Domestic Credit Facility

[0001069202-16-000014:notes:108]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consists of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019.  Under our Domestic Credit Facility, we had outstanding borrowings of $323.0 million, of which $277.5 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of December 31, 2015.  Subject to covenant limitations, $600.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-16-000014:notes:109]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-16-000014:notes:110]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our Domestic Credit Facility could occur if:

[0001069202-16-000014:notes:111]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-16-000014:notes:112]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-16-000014:notes:113]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-16-000014:notes:114]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2015, we were in compliance with all covenant requirements.

[0001069202-16-000014:notes:115]
Senior Unsecured Notes

[0001069202-16-000014:notes:116]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.   As of December 31, 2015, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-16-000014:notes:117]
Derivatives:

[0001069202-16-000014:notes:118]
Objectives and Strategies for Using Derivative Instruments

[0001069202-16-000014:notes:119]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-16-000014:notes:120]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001069202-16-000014:notes:121]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. Our forward contracts are primarily not designated as hedges, but on occasion we have entered into forward contracts that are designated as cash flow hedges.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-16-000014:notes:122]
Cash Flow Hedges

[0001069202-16-000014:notes:123]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through June 30, 2017 and December 31, 2016, respectively.  Unrealized gains or losses from our cash flow hedges are included in AOCI and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.

[0001069202-16-000014:notes:124]
We recorded the following amounts related to our cash flow hedges in AOCI (in millions):

[0001069202-16-000014:notes:125]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Unrealized losses on unsettled contracts | $ | 13.2 |  |  | $ | 7.2 |  |
| Income tax expense (benefit) | (4.8 | ) |  | (2.6 | ) |
| Losses included in AOCI, net of tax (1) | $ | 8.4 |  |  | $ | 4.6 |  |

[0001069202-16-000014:notes:126]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $8.2 million of derivative losses into earnings within the next 12 months.

[0001069202-16-000014:notes:127]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions of pounds):

[0001069202-16-000014:notes:128]
|  | As of December 31, |
| Notional Amounts | 2015 |  | 2014 |
| Copper | 34.7 |  |  | 29.4 |  |

[0001069202-16-000014:notes:129]
We had the following outstanding foreign exchange forward contracts designated as cash flow hedges (in millions):

[0001069202-16-000014:notes:130]
|  | As of December 31, |
| Notional Amounts (in local currency): | 2015 |  | 2014 |
| Mexican Peso | 201.4 |  |  | — |  |

[0001069202-16-000014:notes:131]
Derivatives not Designated as Cash Flow Hedges

[0001069202-16-000014:notes:132]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges, except that we elect not to designate them as cash flow hedges at the inception of the arrangement. We had

[0001069202-16-000014:notes:133]
the following outstanding commodity futures contracts not designated as cash flow hedges (in millions of pounds):

[0001069202-16-000014:notes:134]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Copper | 3.3 |  |  | 2.9 |  |
| Aluminum | 3.2 |  |  | 2.2 |  |

[0001069202-16-000014:notes:135]
We had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001069202-16-000014:notes:136]
|  | As of December 31, |
| Notional amounts (in local currency): | 2015 |  | 2014 |
| Brazilian Real | — |  |  | 8.7 |  |
| Mexican Peso | 53.0 |  |  | 229.7 |  |
| Indian Rupee | 30.8 |  |  | — |  |
| Euro | 3.2 |  |  | 3.6 |  |
| Russian Ruble | — |  |  | 80.8 |  |
| Polish Zloty | 25.4 |  |  | 30.6 |  |

[0001069202-16-000014:notes:137]
Information About the Locations and Amounts of Derivative Instruments

[0001069202-16-000014:notes:138]
The following tables provide the locations and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of Operations (in millions):

[0001069202-16-000014:notes:139]
|  | Fair Values of Derivative Instruments as of December 31 (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Current Assets: |  |  |  |  |  |  |  |
| Other assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.2 |  |  | 0.3 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency forward contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total Assets | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | 0.3 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 12.5 |  |  | $ | 6.7 |  |  | $ | 1.5 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts | 0.4 |  |  | — |  |  | — |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.4 |  |  | 0.5 |  |  | — |  |  | 0.1 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 13.3 |  |  | $ | 7.2 |  |  | $ | 1.5 |  |  | $ | 0.8 |  |

[0001069202-16-000014:notes:140]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 20 for more information on fair value measurements.

[0001069202-16-000014:notes:141]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Amount of Loss (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |
| Commodity futures contracts (1) | $ | 12.5 |  |  | $ | 5.8 |  |  | $ | 4.2 |  |
|  | $ | 12.5 |  |  | $ | 5.8 |  |  | $ | 4.2 |  |
| Amount of Loss (Gain) Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |
| Commodity futures contracts (2) | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |

[0001069202-16-000014:notes:142]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Amount of Loss (Gain) Recognized in Income on Derivatives: |  |  |  |  |  |
| Commodity futures contracts (2) | $ | 2.5 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |
| Foreign currency forward contracts (2) | 0.3 |  |  | (0.8 | ) |  | 0.1 |  |
|  | $ | 2.8 |  |  | $ | 0.4 |  |  | $ | 1.3 |  |

[0001069202-16-000014:notes:143]
(1) The loss (gain) was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-16-000014:notes:144]
(2) The loss (gain) was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DerivativesPolicyTextBlock

[0001069202-16-000014:notes:145]
Derivatives

[0001069202-16-000014:notes:146]
We use futures contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 8 for more information on our derivatives.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-16-000014:notes:147]
Stock-Based Compensation:

[0001069202-16-000014:notes:148]
Stock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-16-000014:notes:149]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Compensation expense(1) | $ | 26.6 |  |  | $ | 23.3 |  |  | $ | 29.3 |  |

[0001069202-16-000014:notes:150]
(1) Stock-based compensation expense was recorded in our Corporate and other business segment.

[0001069202-16-000014:notes:151]
Incentive Plan

[0001069202-16-000014:notes:152]
Under the Lennox International Inc. 2010 Incentive Plan, as amended and restated (the “2010 Incentive Plan”), we are authorized to issue awards for 24.3 million shares of common stock.  The 2010 Incentive Plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-16-000014:notes:153]
As of December 31, 2015, awards for 20.5 million shares of common stock had been granted, net of cancellations and repurchases, and there were 3.8 million shares available for future issuance.

[0001069202-16-000014:notes:154]
Performance Share Units

[0001069202-16-000014:notes:155]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII's performance over the three-year performance period.

[0001069202-16-000014:notes:156]
Performance share units are classified as equity awards.  Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-16-000014:notes:157]
The following table provides information on our performance share units:

[0001069202-16-000014:notes:158]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Compensation expense for performance share units (in millions) | $ | 13.6 |  |  | $ | 11.5 |  |  | $ | 17.1 |  |
| Weighted-average fair value of grants, per share | $ | 126.31 |  |  | $ | 88.26 |  |  | $ | 78.00 |  |
| Payout ratio for shares paid | 200.0 | % |  | 153.2 | % |  | 86.9 | % |

[0001069202-16-000014:notes:159]
A summary of the status of our undistributed performance share units as of December 31, 2015, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-16-000014:notes:160]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2014 | 0.8 |  |  | $ | 49.47 |  |
| Granted | 0.1 |  |  | 126.31 |  |
| Adjustments to shares paid based on payout ratio | 0.1 |  |  | 48.64 |  |
| Distributed | (0.4 | ) |  | 31.78 |  |
| Forfeited | — |  |  | — |  |
| Undistributed performance share units as of December 31, 2015 (1) | 0.6 |  |  | $ | 67.91 |  |

[0001069202-16-000014:notes:161]
(1) Undistributed performance share units include approximately 0.3 million units with a weighted-average grant date fair value of $94.23 per share that had not yet vested and 0.3 million units that have vested but were not yet distributed.

[0001069202-16-000014:notes:162]
As of December 31, 2015, we had $16.0 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.2 years. Our estimated forfeiture rate for these performance share units was 16.5% as of December 31, 2015.

[0001069202-16-000014:notes:163]
Restricted Stock Units

[0001069202-16-000014:notes:164]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-16-000014:notes:165]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-16-000014:notes:166]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Compensation expense for restricted stock units | $ | 8.3 |  |  | $ | 7.0 |  |  | $ | 6.8 |  |
| Weighted-average fair value of grants, per share | $ | 126.15 |  |  | $ | 88.26 |  |  | $ | 77.26 |  |

[0001069202-16-000014:notes:167]
A summary of our non-vested restricted stock units as of December 31, 2015 and changes during the year then ended is presented below (in millions, except per share data):

[0001069202-16-000014:notes:168]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2014 | 0.4 |  |  | $ | 69.09 |  |
| Granted | 0.1 |  |  | 126.15 |  |
| Distributed | (0.2 | ) |  | 49.11 |  |
| Forfeited | — |  |  | — |  |
| Non-vested restricted stock units as of December 31, 2015 | 0.3 |  |  | $ | 94.23 |  |

[0001069202-16-000014:notes:169]
As of December 31, 2015, we had $16.0 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.4 years.  Our estimated forfeiture rate for restricted stock units was 17.6% as of December 31, 2015.

[0001069202-16-000014:notes:170]
Stock Appreciation Rights

[0001069202-16-000014:notes:171]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive a value, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-16-000014:notes:172]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-16-000014:notes:173]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Compensation expense for stock appreciation rights | $ | 4.7 |  |  | $ | 4.8 |  |  | $ | 5.4 |  |
| Weighted-average fair value of grants, per share | 22.74 |  |  | 19.55 |  |  | 18.76 |  |

[0001069202-16-000014:notes:174]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-16-000014:notes:175]
The fair value of the stock appreciation rights granted in 2015, 2014 and 2013 were estimated on the date of grant using the following assumptions:

[0001069202-16-000014:notes:176]
|  | 2015 |  | 2014 |  | 2013 |
| Expected dividend yield | 1.61 | % |  | 1.75 | % |  | 1.36 | % |
| Risk-free interest rate | 1.36 | % |  | 1.27 | % |  | 1.12 | % |
| Expected volatility | 23.78 | % |  | 29.60 | % |  | 31.50 | % |
| Expected life (in years) | 4.00 |  |  | 4.04 |  |  | 4.02 |  |

[0001069202-16-000014:notes:177]
A summary of our stock appreciation rights as of December 31, 2015, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-16-000014:notes:178]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2014 | 1.5 |  |  | $ | 56.20 |  |
| Granted | 0.2 |  |  | 131.87 |  |
| Exercised | (0.4 | ) |  | 40.09 |  |
| Forfeited | — |  |  | — |  |
| Outstanding stock appreciation rights as of December 31, 2015 | 1.3 |  |  | $ | 72.54 |  |
| Exercisable stock appreciation rights as of December 31, 2015 | 0.9 |  |  | $ | 53.91 |  |

[0001069202-16-000014:notes:179]
As of December 31, 2015, we had $8.2 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for stock appreciation rights was 15.0% as of December 31, 2015.

[0001069202-16-000014:notes:180]
Employee Stock Purchase Plan

[0001069202-16-000014:notes:181]
Under the 2012 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 18,000 shares under the ESPP during the year ended December 31, 2015.  Approximately 2.4 million shares remain available for purchase under the ESPP as of December 31, 2015.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-16-000014:notes:182]
Discontinued Operations:

[0001069202-16-000014:notes:183]
On March 22, 2013, we sold our Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer") in an all-cash transaction for net proceeds of $10.4 million, excluding transaction costs.  We also entered into a two-year equipment and parts supply agreement with the Buyer.  In April 2012, we sold our Hearth business to Comvest Investment Partners IV in an all-cash transaction for net proceeds of $10.1 million, excluding the transaction costs and cash transferred with the business.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in discontinued operations.

[0001069202-16-000014:notes:184]
Service Experts

[0001069202-16-000014:notes:185]
A summary of net sales and pre-tax gains and losses for the Service Experts business is detailed below (in millions):

[0001069202-16-000014:notes:186]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Net sales (1) | $ | — |  |  | $ | — |  |  | $ | 73.5 |  |
| Pre-tax operating income (loss) (1) | (0.4 | ) |  | 2.6 |  |  | (15.1 | ) |
| Gain on sale of business | — |  |  | — |  |  | 1.4 |  |

[0001069202-16-000014:notes:187]
(1) Excludes eliminations of intercompany sales and any associated profit.

[0001069202-16-000014:notes:188]
There were no assets or liabilities related to the Service Experts business included in the accompanying Consolidated Balance Sheets as of December 31, 2015, 2014 or 2013.

[0001069202-16-000014:notes:189]
Hearth

[0001069202-16-000014:notes:190]
A summary of net sales and pre-tax gains and losses for the Hearth business is detailed below (in millions):

[0001069202-16-000014:notes:191]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Net sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | (0.3 | ) |  | (6.3 | ) |  | 0.5 |  |
| Loss on sale of business | — |  |  | — |  |  | — |  |

[0001069202-16-000014:notes:192]
There were no assets or liabilities related to the Hearth business included in the accompanying Consolidated Balance Sheets as of December 31, 2015, 2014 or 2013.


## us-gaap:EarningsPerShareTextBlock

[0001069202-16-000014:notes:193]
Earnings Per Share:

[0001069202-16-000014:notes:194]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-16-000014:notes:195]
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-16-000014:notes:196]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Net income | $ | 186.6 |  |  | $ | 205.8 |  |  | $ | 171.8 |  |
| Add: Loss from discontinued operations | 0.6 |  |  | 2.3 |  |  | 8.1 |  |
| Income from continuing operations | $ | 187.2 |  |  | $ | 208.1 |  |  | $ | 179.9 |  |
| Weighted-average shares outstanding – basic | 44.9 |  |  | 47.9 |  |  | 49.8 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.7 |  |  | 0.7 |  |  | 0.8 |  |
| Weighted-average shares outstanding – diluted | 45.6 |  |  | 48.6 |  |  | 50.6 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 4.17 |  |  | $ | 4.35 |  |  | $ | 3.61 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.05 | ) |  | (0.16 | ) |
| Net income | $ | 4.16 |  |  | $ | 4.30 |  |  | $ | 3.45 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 4.11 |  |  | $ | 4.28 |  |  | $ | 3.55 |  |
| Loss from discontinued operations | (0.02 | ) |  | (0.05 | ) |  | (0.16 | ) |
| Net income | $ | 4.09 |  |  | $ | 4.23 |  |  | $ | 3.39 |  |

[0001069202-16-000014:notes:197]
The following stock appreciation rights were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive (in millions, except for per share data):

[0001069202-16-000014:notes:198]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Weighted-average number of shares | — |  |  | 0.3 |  |  | 0.1 |  |
| Price ranges per share | $ | — |  |  | $81.11 - $92.64 |  |  | $81.11 - $81.14 |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-16-000014:notes:199]
Joint Ventures and Other Equity Investments:

[0001069202-16-000014:notes:200]
We participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001069202-16-000014:notes:201]
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001069202-16-000014:notes:202]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Equity method investments | $ | 30.3 |  |  | $ | 30.9 |  |

[0001069202-16-000014:notes:203]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-16-000014:notes:204]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Purchases of compressors from joint venture | $ | 103.5 |  |  | $ | 114.7 |  |  | $ | 96.7 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001069202-16-000014:notes:205]
The fair values of our pension plan assets, by asset category, are as follows (in millions):

[0001069202-16-000014:notes:206]
|  | Fair Value Measurements as of December 31, 2015 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 3.8 |  |  | — |  |  | — |  |  | 3.8 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 69.7 |  |  | — |  |  | 69.7 |  |
| International equity (2) | — |  |  | 45.5 |  |  | — |  |  | 45.5 |  |
| Fixed income (3) | — |  |  | 138.1 |  |  | — |  |  | 138.1 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |
| Fixed income | — |  |  | 12.1 |  |  | — |  |  | 12.1 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 11.0 |  |  | — |  |  | 11.0 |  |
| Fixed income (6) | — |  |  | 8.1 |  |  | — |  |  | 8.1 |  |
| Total | 3.8 |  |  | 289.2 |  |  | — |  |  | 293.0 |  |

[0001069202-16-000014:notes:207]
|  | Fair Value Measurements as of December 31, 2014 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 5.8 |  |  | — |  |  | — |  |  | 5.8 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 78.0 |  |  | — |  |  | 78.0 |  |
| International equity (2) | — |  |  | 47.3 |  |  | — |  |  | 47.3 |  |
| Fixed income (3) | — |  |  | 145.4 |  |  | — |  |  | 145.4 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |
| Fixed income | — |  |  | 14.2 |  |  | — |  |  | 14.2 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 11.4 |  |  | — |  |  | 11.4 |  |
| Fixed income (6) | — |  |  | 8.2 |  |  | — |  |  | 8.2 |  |
| Total | 5.8 |  |  | 309.2 |  |  | — |  |  | 315.0 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-16-000014:notes:208]
The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-16-000014:notes:209]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 207.3 |  |  | $ | 210.6 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-16-000014:notes:210]
Fair Value Measurements:

[0001069202-16-000014:notes:211]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001069202-16-000014:notes:212]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-16-000014:notes:213]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-16-000014:notes:214]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-16-000014:notes:215]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party's creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2015 and 2014, the measurement dates.  The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2015 were the same as those used as of December 31, 2014.

[0001069202-16-000014:notes:216]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-16-000014:notes:217]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-16-000014:notes:218]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 8 for more information related to our derivative instruments.

[0001069202-16-000014:notes:219]
Marketable Equity Securities

[0001069202-16-000014:notes:220]
The following table presents the fair values of an investment in marketable equity securities, related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-16-000014:notes:221]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Quoted Prices in Active Markets for Identical Assets (Level 1): |  |  |  |
| Investment in marketable equity securities | $ | 6.5 |  |  | $ | 5.3 |  |

[0001069202-16-000014:notes:222]
Other Fair Value Disclosures

[0001069202-16-000014:notes:223]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-16-000014:notes:224]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):


## us-gaap:FairValueInvestmentsEntitiesThatCalculateNetAssetValuePerShareTableTextBlock

[0001069202-16-000014:notes:225]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-16-000014:notes:226]
|  | As of December 31, 2015 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 69.7 |  |  | Daily |  | 5 days |
| International equity (2) | 45.5 |  |  | Daily |  | 5 days |
| Fixed income (3) | 138.1 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.7 |  |  | Daily |  | 3-5 days |
| Fixed income | 12.1 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 11.0 |  |  | Daily |  | 1-7 days |
| Fixed income (6) | 8.1 |  |  | Daily |  | 1-7 days |
| Total | $ | 289.2 |  |  |  |  |  |

[0001069202-16-000014:notes:227]
|  | As of December 31, 2014 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 78.0 |  |  | Daily |  | 5 days |
| International equity (2) | 47.3 |  |  | Daily |  | 5 days |
| Fixed income (3) | 145.4 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.7 |  |  | Daily |  | 3-5 days |
| Fixed income | 14.2 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 11.4 |  |  | Daily |  | 1-7 days |
| Fixed income (6) | 8.2 |  |  | Daily |  | 1-7 days |
| Total | $ | 309.2 |  |  |  |  |  |

[0001069202-16-000014:notes:228]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the fund are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The fund also holds a portion of its assets in international equities. |
| (5) | This category includes investments in international equity securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (6) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer and investment grade corporate bonds denominated in sterling. |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001069202-16-000014:notes:229]
Amortization expense related to these intangible and other assets was as follows (in millions):

[0001069202-16-000014:notes:230]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Amortization expense (1) | $ | 3.7 |  |  | $ | 3.9 |  |  | $ | 3.9 |  |

[0001069202-16-000014:notes:231]
(1) The impairment related to customer relationships has been removed from the gross amount as well as the accumulated amortization, but is included in amortization expense for the year.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001069202-16-000014:notes:232]
Translation of Foreign Currencies

[0001069202-16-000014:notes:233]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCI in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-16-000014:notes:234]
Goodwill and Intangible Assets:

[0001069202-16-000014:notes:235]
Goodwill

[0001069202-16-000014:notes:236]
The changes in the carrying amount of goodwill in 2014 and 2013, in total and by segment, are summarized in the table below (in millions):

[0001069202-16-000014:notes:237]
| Segment: | Balance at December 31, 2013 (2) |  | Impairment |  | Other(1) |  | Balance at December 31, 2014 |  | Impairment |  | Other(1) |  | Balance at December 31, 2015 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 64.6 |  |  | — |  |  | (2.3 | ) |  | 62.3 |  |  | — |  |  | (1.7 | ) |  | 60.6 |  |
| Refrigeration | 126.1 |  |  | — |  |  | (5.1 | ) |  | 121.0 |  |  | (5.5 | ) |  | (7.1 | ) |  | 108.4 |  |
|  | $ | 216.8 |  |  | $ | — |  |  | $ | (7.4 | ) |  | $ | 209.4 |  |  | $ | (5.5 | ) |  | $ | (8.8 | ) |  | $ | 195.1 |  |

[0001069202-16-000014:notes:238]
(1) Other consists of changes in foreign currency translation rates.

[0001069202-16-000014:notes:239]
(2) The goodwill balances in the table above are presented net of accumulated impairment charges of $15.7 million, all of which relate to impairments in periods prior to 2013.

[0001069202-16-000014:notes:240]
We reviewed our reporting unit structure as part of our annual goodwill impairment testing.  We identified several components one level below our operating segments which were determined to be reporting units.  We then performed our analysis to determine the proper aggregation of our reporting units, which considered similar economic and other characteristics, including product types, gross profits, production processes, customer types, distribution processes, and regulatory environments.  Our analysis incorporated qualitative and quantitative measures to evaluate economic similarity  and concluded that our reporting units continue to be equivalent to our operating segments.

[0001069202-16-000014:notes:241]
A qualitative review of impairment indicators was performed in 2015 for the Residential Heating & Cooling, the Commercial Heating & Cooling segments, and the Refrigeration segments we determined that it was not more likely than not the fair values of our reporting units, individually or collectively, were less than their carrying values.  Accordingly, a quantitative impairment analysis was not performed for these segments.  During the fourth quarter we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed a quantitative impairment analysis for this business unit using the market approach.  Based on the results of the quantitative impairment test, we recorded impairment of $5.5 million in "Goodwill impairment" in the Consolidated Statement of Operations.  No other indicators of goodwill impairment were identified from the date of our annual impairment test through December 31, 2015.  Also, we did not record any goodwill impairments related to continuing operations in 2013 or 2014.  Refer to Note 17 for information on goodwill related to discontinued operations.

[0001069202-16-000014:notes:242]
Intangible Assets

[0001069202-16-000014:notes:243]
As of December 31, 2015 and 2014, there were $4.3 million and $9.4 million, respectively, of indefinite-lived intangible assets recorded in Other assets, net in the accompanying Consolidated Balance Sheets.  These intangible assets consisted primarily of trademarks and are not subject to amortization.

[0001069202-16-000014:notes:244]
Identifiable intangible and other assets subject to amortization were recorded in Other assets, net in the accompanying Consolidated Balance Sheets and were comprised of the following (in millions):

[0001069202-16-000014:notes:245]
|  | As of December 31, |
|  | 2015 |  | 2014 |
|  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Deferred financing costs | $ | 5.4 |  |  | $ | (2.4 | ) |  | $ | 3.0 |  |  | $ | 5.4 |  |  | $ | (1.5 | ) |  | $ | 3.9 |  |
| Customer relationships (1) | 15.9 |  |  | (14.6 | ) |  | 1.3 |  |  | 42.6 |  |  | (23.1 | ) |  | 19.5 |  |
| Patents and others | 11.2 |  |  | (6.3 | ) |  | 4.9 |  |  | 12.0 |  |  | (7.6 | ) |  | 4.4 |  |
| Total | $ | 32.5 |  |  | $ | (23.3 | ) |  | $ | 9.2 |  |  | $ | 60.0 |  |  | $ | (32.2 | ) |  | $ | 27.8 |  |

[0001069202-16-000014:notes:246]
Estimated amortization expense for the next five years and thereafter is as follows (in millions):

[0001069202-16-000014:notes:247]
| Estimated Future Amortization Expense: |  |
| 2016 | $ | 1.3 |  |
| 2017 | 1.1 |  |
| 2018 | 1.0 |  |
| 2019 | 0.9 |  |
| 2020 | 0.4 |  |
| Thereafter | 4.2 |  |

[0001069202-16-000014:notes:248]
During the fourth quarter we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed an impairment analysis using a market approach and determined that intangible assets relating to the North American supermarket display case business trade name and its customer relationships were impaired and we recorded a charge of $21.2 million in "Asset impairment" in the Consolidated Statement of Operations. We did not have any impairments of intangible assets related to continuing operations in 2013 or 2014.  See Note 17 for information on impairments of intangible assets related to discontinued operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-16-000014:notes:249]
Income Taxes:

[0001069202-16-000014:notes:250]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-16-000014:notes:251]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Current: |  |  |  |  |  |
| Federal | $ | 101.0 |  |  | $ | 84.3 |  |  | $ | 71.9 |  |
| State | 13.1 |  |  | 10.1 |  |  | 8.5 |  |
| Foreign | 3.6 |  |  | 9.6 |  |  | 16.2 |  |
| Total current | 117.7 |  |  | 104.0 |  |  | 96.6 |  |
| Deferred: |  |  |  |  |  |
| Federal | (21.4 | ) |  | 2.3 |  |  | (4.0 | ) |
| State | (0.6 | ) |  | 1.0 |  |  | 2.5 |  |
| Foreign | (0.3 | ) |  | 2.2 |  |  | (0.7 | ) |
| Total deferred | (22.3 | ) |  | 5.5 |  |  | (2.2 | ) |
| Total provision for income taxes | $ | 95.4 |  |  | $ | 109.5 |  |  | $ | 94.4 |  |

[0001069202-16-000014:notes:252]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-16-000014:notes:253]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Domestic | $ | 276.7 |  |  | $ | 283.7 |  |  | $ | 231.1 |  |
| Foreign | 5.9 |  |  | 33.9 |  |  | 43.2 |  |
| Total | $ | 282.6 |  |  | $ | 317.6 |  |  | $ | 274.3 |  |

[0001069202-16-000014:notes:254]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-16-000014:notes:255]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Provision at the U.S. statutory rate of 35% | $ | 98.9 |  |  | $ | 111.2 |  |  | $ | 96.0 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 8.0 |  |  | 8.8 |  |  | 7.1 |  |
| Other permanent items | (9.1 | ) |  | (8.2 | ) |  | (6.4 | ) |
| Research tax credit | (0.7 | ) |  | — |  |  | (0.5 | ) |
| Change in unrecognized tax benefits | (0.9 | ) |  | 0.2 |  |  | 0.7 |  |
| Change in valuation allowance | (0.6 | ) |  | 0.2 |  |  | 0.7 |  |
| Foreign taxes at rates other than 35% and miscellaneous other | (0.2 | ) |  | (2.7 | ) |  | (3.2 | ) |
| Total provision for income taxes | $ | 95.4 |  |  | $ | 109.5 |  |  | $ | 94.4 |  |

[0001069202-16-000014:notes:256]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and are reflected as current or non-current depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-16-000014:notes:257]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-16-000014:notes:258]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 33.7 |  |  | $ | 30.9 |  |
| Loss carryforwards (foreign, U.S. and state) | 20.0 |  |  | 23.6 |  |
| Post-retirement and pension benefits | 47.7 |  |  | 50.7 |  |
| Inventory reserves | 9.0 |  |  | 4.4 |  |
| Receivables allowance | 4.1 |  |  | 4.9 |  |
| Compensation liabilities | 19.3 |  |  | 19.6 |  |
| Deferred income | 1.6 |  |  | 1.0 |  |
| Insurance liabilities | 6.3 |  |  | 15.8 |  |
| Legal reserves | 10.9 |  |  | 11.1 |  |
| Hedges | 5.3 |  |  | 2.8 |  |
| State credits, net of federal effect | 8.3 |  |  | 8.8 |  |
| Other | 7.1 |  |  | 9.3 |  |
| Total deferred tax assets | 173.3 |  |  | 182.9 |  |
| Valuation allowance | (19.9 | ) |  | (21.2 | ) |
| Total deferred tax assets, net of valuation allowance | 153.4 |  |  | 161.7 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (2.5 | ) |  | (10.8 | ) |
| Intangibles | (2.2 | ) |  | (11.0 | ) |
| Other | (3.0 | ) |  | (9.9 | ) |
| Total deferred tax liabilities | (7.7 | ) |  | (31.7 | ) |
| Net deferred tax assets | $ | 145.7 |  |  | $ | 130.0 |  |

[0001069202-16-000014:notes:259]
As of December 31, 2015 and 2014, we had $2.6 million and $3.8 million in tax-effected state net operating loss carryforwards, respectively, and $16.1 million and $18.5 million in tax-effected foreign net operating loss carryforwards, respectively.  The state and foreign net operating loss carryforwards began expiring in 2014.  The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards in various states in the U.S., European and Asian tax jurisdictions.  The remainder of the valuation allowance relates to state tax credits which began to expire in 2014.

[0001069202-16-000014:notes:260]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of December 31, 2015.

[0001069202-16-000014:notes:261]
To realize the net deferred tax asset, we will need to generate future foreign taxable income of approximately $60.4 million during the periods in which those temporary differences become deductible.  We do not need to generate additional U.S. federal income as we have sufficient carryback capacity to fully realize the federal deferred tax asset.  U.S. taxable income for the years ended December 31, 2015 and 2014 was $223.3 million and $214.3 million, respectively.

[0001069202-16-000014:notes:262]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries' earnings.  These earnings were approximately $111.2 million  as of December 31, 2015.  It is not practicable to estimate the amount of tax that might be payable because our intent is to permanently reinvest these earnings or to repatriate earnings when it is tax effective to do so.

[0001069202-16-000014:notes:263]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001069202-16-000014:notes:264]
| Balance as of December 31, 2013 | $ | 1.7 |  |
| Increases related to prior year tax positions | 0.7 |  |
| Decreases related to prior year tax positions | (0.7 | ) |
| Increases related to current year tax positions | — |  |
| Settlement | (0.1 | ) |
| Balance as of December 31, 2014 | 1.6 |  |
| Increases related to prior year tax positions | 0.5 |  |
| Decreases related to prior year tax positions | (1.2 | ) |
| Increases related to current year tax positions | — |  |
| Settlement | $ | (0.4 | ) |
| Balance as of December 31, 2015 | $ | 0.5 |  |

[0001069202-16-000014:notes:265]
Included in the balance of unrecognized tax benefits as of December 31, 2015 are potential benefits of $0.3 million that, if recognized, would affect the effective tax rate on income from continuing operations.  As of December 31, 2015, we recognized $0.1 million (net of federal tax benefits) in interest and penalties in income tax expense.

[0001069202-16-000014:notes:266]
We are currently under examination for our U.S. federal income taxes for 2015 and 2014 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years before 2010.

[0001069202-16-000014:notes:267]
Since January 1, 2015, numerous states, including New Mexico, North Carolina, North Dakota, Minnesota, Oregon, Texas and West Virginia enacted legislation effective for tax years beginning on or after January 1, 2015, including changes to rates and apportionment methods.  The impact of these changes is immaterial.

[0001069202-16-000014:notes:268]
In November 2015, the Financial Accounting Standards Board issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (Topic 740).  The Board issued this Update as part of its initiative to reduce complexity in accounting standards.  To simplify the presentation of deferred income taxes, the Update requires that all deferred tax assets and liabilities be classified as noncurrent in a classified statement of financial position.  The Update is effective for financial statements issued for annual periods beginning after December 15, 2016, but earlier application is permitted.  We are adopting this Update retrospectively in the 2015 financial statements and have reclassified the 2014 “Current Asset: Deferred income taxes, net” of $32.5M as part of the non-current asset “Deferred income taxes”.


## us-gaap:IncomeTaxPolicyTextBlock

[0001069202-16-000014:notes:269]
Income Taxes

[0001069202-16-000014:notes:270]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 9 for more information related to income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-16-000014:notes:271]
Inventories:

[0001069202-16-000014:notes:272]
The components of inventories are as follows (in millions):

[0001069202-16-000014:notes:273]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Finished goods | $ | 300.0 |  |  | $ | 338.2 |  |
| Work in process | 4.2 |  |  | 8.1 |  |
| Raw materials and parts | 178.3 |  |  | 182.6 |  |
| Total | 482.5 |  |  | 528.9 |  |
| Excess of current cost over last-in, first-out cost | (63.7 | ) |  | (65.6 | ) |
| Total inventories, net | $ | 418.8 |  |  | $ | 463.3 |  |

[0001069202-16-000014:notes:274]
The Company recorded pre-tax loss of $0.2 million in 2015, pre-tax loss of 0.9 million in 2014 and pre-tax income of $0.3 million in 2013 from LIFO inventory liquidations.


## us-gaap:InventoryPolicyTextBlock

[0001069202-16-000014:notes:275]
Inventories

[0001069202-16-000014:notes:276]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $212.4 million and $212.9 million as of December 31, 2015 and 2014, respectively, were valued at the lower of cost or market using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or market with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001069202-16-000014:notes:277]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 3 for more information on our inventories.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-16-000014:notes:278]
Losses and Other Expenses, net:

[0001069202-16-000014:notes:279]
Losses and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-16-000014:notes:280]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Realized losses on settled futures contracts | $ | 1.9 |  |  | $ | 0.8 |  |  | $ | 1.0 |  |
| Foreign currency exchange losses | 3.6 |  |  | 1.6 |  |  | 0.5 |  |
| Losses (gains) on disposal of fixed assets | 0.6 |  |  | (0.3 | ) |  | (1.0 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.6 |  |  | 0.6 |  |  | 0.4 |  |
| Asbestos-related litigation | 3.0 |  |  | 0.9 |  |  | 6.3 |  |
| Acquisition expenses | 1.0 |  |  | — |  |  | 0.2 |  |
| Special legal contingency charges | 7.4 |  |  | 0.9 |  |  | 1.2 |  |
| Environmental liabilities | 1.0 |  |  | 2.0 |  |  | — |  |
| Contractor tax payments | 2.6 |  |  | — |  |  | — |  |
| Other items, net | — |  |  | 0.3 |  |  | 0.7 |  |
| Losses and other expenses, net | $ | 21.7 |  |  | $ | 6.8 |  |  | $ | 9.3 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-16-000014:notes:281]
Employee Benefit Plans:

[0001069202-16-000014:notes:282]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.  We also have several active defined benefit plans that provide benefits based on years of service.

[0001069202-16-000014:notes:283]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.  In 2012, we amended the post-retirement benefit plan to shift pre-65 medical coverage for the employees of our largest manufacturing plant so that by 2015, retirees would pay 100% of the cost of post-retirement medical coverage.  This change resulted in a significant reduction in the projected benefit obligation for post-retirement medical benefits in 2012.

[0001069202-16-000014:notes:284]
Defined Contribution Plans

[0001069202-16-000014:notes:285]
We recorded the following expenses related to our contributions to the defined contribution plans (in millions):

[0001069202-16-000014:notes:286]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Contributions to defined contribution plans (1) | $ | 16.1 |  |  | $ | 14.8 |  |  | $ | 13.7 |  |

[0001069202-16-000014:notes:287]
(1)  A contribution of $0.4 million was included in Loss from discontinued operations for the year ended December 31, 2013.  No contributions were included in Loss from discontinued operations in 2015 and 2014.

[0001069202-16-000014:notes:288]
Pension and Post-retirement Benefit Plans

[0001069202-16-000014:notes:289]
The following tables set forth amounts recognized in our financial statements and the plans' funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-16-000014:notes:290]
|  | Pension Benefits |  | Other Benefits |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Accumulated benefit obligation | $ | 409.2 |  |  | $ | 439.6 |  |  | N/A |  |  | N/A |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 446.5 |  |  | $ | 374.6 |  |  | $ | 5.4 |  |  | $ | 6.0 |  |
| Service cost | 4.8 |  |  | 4.2 |  |  | — |  |  | — |  |
| Interest cost | 17.2 |  |  | 17.7 |  |  | 0.2 |  |  | 0.2 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.5 |  |  | 0.6 |  |
| Amendments | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial (gain) loss | (29.6 | ) |  | 77.0 |  |  | 0.1 |  |  | 0.6 |  |
| Effect of exchange rates | (5.2 | ) |  | (4.3 | ) |  | — |  |  | — |  |
| Divestiture | — |  |  | — |  |  | — |  |  | — |  |
| Settlements and curtailments | (0.8 | ) |  | (0.8 | ) |  | — |  |  | — |  |
| Benefits paid | (17.6 | ) |  | (21.9 | ) |  | (1.3 | ) |  | (2.0 | ) |
| Benefit obligation at end of year | $ | 415.4 |  |  | $ | 446.5 |  |  | $ | 4.9 |  |  | $ | 5.4 |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 315.0 |  |  | $ | 302.8 |  |  | $ | — |  |  | $ | — |  |
| Actual gain (loss) return on plan assets | (3.2 | ) |  | 23.3 |  |  | — |  |  | — |  |
| Employer contribution | 3.8 |  |  | 14.5 |  |  | 0.8 |  |  | 1.4 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.5 |  |  | 0.6 |  |
| Effect of exchange rates | (4.2 | ) |  | (2.9 | ) |  | — |  |  | — |  |
| Divestiture | — |  |  | — |  |  | — |  |  | — |  |
| Plan settlements | (0.8 | ) |  | (0.8 | ) |  | — |  |  | — |  |
| Benefits paid | (17.6 | ) |  | (21.9 | ) |  | (1.3 | ) |  | (2.0 | ) |
| Fair value of plan assets at end of year | 293.0 |  |  | 315.0 |  |  | — |  |  | — |  |
| Funded status / net amount recognized | $ | (122.4 | ) |  | $ | (131.5 | ) |  | $ | (4.9 | ) |  | $ | (5.4 | ) |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Current liability | $ | (1.6 | ) |  | $ | (1.6 | ) |  | $ | (0.8 | ) |  | $ | (0.9 | ) |
| Non-current liability | (120.8 | ) |  | (129.9 | ) |  | (4.1 | ) |  | (4.5 | ) |
| Net amount recognized | $ | (122.4 | ) |  | $ | (131.5 | ) |  | $ | (4.9 | ) |  | $ | (5.4 | ) |

[0001069202-16-000014:notes:291]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 404.5 |  |  | $ | 446.5 |  |
| Accumulated benefit obligation | 398.4 |  |  | 439.6 |  |
| Fair value of plan assets | 281.8 |  |  | 315.0 |  |

[0001069202-16-000014:notes:292]
Our U.S.-based pension plans comprised approximately 89% of the projected benefit obligation and 88% of plan assets as of December 31, 2015.

[0001069202-16-000014:notes:293]
|  | Pension Benefits |  | Other Benefits |
|  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 4.8 |  |  | $ | 4.2 |  |  | $ | 5.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 17.2 |  |  | 17.7 |  |  | 16.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on plan assets | (21.4 | ) |  | (22.7 | ) |  | (20.7 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.2 |  |  | 0.3 |  |  | 0.4 |  |  | (3.1 | ) |  | (3.1 | ) |  | (3.1 | ) |
| Recognized actuarial loss | 9.5 |  |  | 6.6 |  |  | 9.2 |  |  | 1.5 |  |  | 1.5 |  |  | 1.5 |  |
| Settlements and curtailments | 0.4 |  |  | 0.4 |  |  | 1.5 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 10.7 |  |  | $ | 6.5 |  |  | $ | 11.8 |  |  | $ | (1.4 | ) |  | $ | (1.4 | ) |  | $ | (1.4 | ) |

[0001069202-16-000014:notes:294]
(1)  Pension expense of $0.2 million was included in Loss for discontinued operations for the year ended December 31, 2013.   No pension expense was included in Loss from discontinued operations in 2014 or 2015.

[0001069202-16-000014:notes:295]
The following table sets forth amounts recognized in AOCI and Other comprehensive income (loss) in our financial statements for 2015 and 2014 (in millions):

[0001069202-16-000014:notes:296]
|  | Pension Benefits |  | Other Benefits |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Amounts recognized in AOCI: |  |  |  |  |  |  |  |
| Prior service costs | $ | (1.2 | ) |  | $ | (1.3 | ) |  | $ | 15.0 |  |  | $ | 18.1 |  |
| Actuarial loss | (214.7 | ) |  | (231.8 | ) |  | (18.4 | ) |  | (19.8 | ) |
| Subtotal | (215.9 | ) |  | (233.1 | ) |  | (3.4 | ) |  | (1.7 | ) |
| Deferred taxes | 78.7 |  |  | 84.7 |  |  | 1.3 |  |  | 0.6 |  |
| Net amount recognized | $ | (137.2 | ) |  | $ | (148.4 | ) |  | $ | (2.1 | ) |  | $ | (1.1 | ) |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Adjustment to OCI due to reclassification | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Current year prior service costs | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Current year actuarial (gain) loss | (5.0 | ) |  | 75.9 |  |  | 0.1 |  |  | 0.6 |  |
| Effect of exchange rates | (2.2 | ) |  | (1.8 | ) |  | — |  |  | — |  |
| Amortization of prior service (costs) credits | (0.3 | ) |  | (0.3 | ) |  | 3.1 |  |  | 3.1 |  |
| Amortization of actuarial loss | (9.9 | ) |  | (7.0 | ) |  | (1.5 | ) |  | (1.5 | ) |
| Total recognized in other comprehensive income (loss) | $ | (17.3 | ) |  | $ | 66.8 |  |  | $ | 1.7 |  |  | $ | 2.2 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) | $ | (6.6 | ) |  | $ | 73.3 |  |  | $ | 0.3 |  |  | $ | 0.8 |  |

[0001069202-16-000014:notes:297]
The estimated prior service (costs) credits and actuarial losses that will be amortized from AOCI in 2015 are $(0.3) million and $(8.6) million, respectively, for pension benefits and $3.1 million and $(1.4) million, respectively, for other benefits.

[0001069202-16-000014:notes:298]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the U.S.-based plans in 2015 and 2014:

[0001069202-16-000014:notes:299]
|  | Pension Benefits |  | Other Benefits |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |
| Discount rate | 4.51 | % |  | 4.04 | % |  | 3.55 | % |  | 3.23 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |

[0001069202-16-000014:notes:300]
|  | Pension Benefits |  | Other Benefits |
|  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 3.97 | % |  | 4.88 | % |  | 3.97 | % |  | 3.23 | % |  | 3.57 | % |  | 2.72 | % |
| Expected long-term return on plan assets | 7.50 | % |  | 8.00 | % |  | 8.00 | % |  | — |  |  | — |  |  | — |  |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |  | — |  |

[0001069202-16-000014:notes:301]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the non-U.S.-based plans in 2015 and 2014:

[0001069202-16-000014:notes:302]
|  | Pension Benefits |
|  | 2015 |  | 2014 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 3.59 | % |  | 3.45 | % |
| Rate of compensation increase | 3.7 | % |  | 3.66 | % |

[0001069202-16-000014:notes:303]
|  | Pension Benefits |
|  | 2015 |  | 2014 |  | 2013 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate | 4.12 | % |  | 4.38 | % |  | 4.12 | % |
| Expected long-term return on plan assets | 5.22 | % |  | 6.32 | % |  | 6.05 | % |
| Rate of compensation increase | 3.48 | % |  | 3.31 | % |  | 3.48 | % |

[0001069202-16-000014:notes:304]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns and the future expectations for returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 7.5% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-16-000014:notes:305]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the duration of projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available.  We used the results of the yield curve analysis to select the discount rate that matched the duration and payment stream of the benefits in each plan.  This resulted in the selection of the 4.58% discount rate assumption for the U.S. qualified pension plans, 3.92% for the U.S. non-qualified pension plans, and 3.55% for the other benefits.  A similar process was followed for the non-U.S.-based plans.

[0001069202-16-000014:notes:306]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-16-000014:notes:307]
|  | 2015 |  | 2014 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 7.00 | % |  | 7.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2020 |  |  | 2020 |  |

[0001069202-16-000014:notes:308]
A one percentage-point change in assumed healthcare cost trend rates would have the following effects (in millions):

[0001069202-16-000014:notes:309]
|  | 1-Percentage-Point Increase |  | 1-Percentage-Point Decrease |
| Effect on total of service and interest cost | $ | — |  |  | $ | — |  |
| Effect on the post-retirement benefit obligation | 0.2 |  |  | (0.2 | ) |

[0001069202-16-000014:notes:310]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-16-000014:notes:311]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021-2025 |
| Pension benefits | $ | 18.4 |  |  | $ | 18.8 |  |  | $ | 19.3 |  |  | $ | 19.8 |  |  | $ | 20.5 |  |  | $ | 145.8 |  |
| Other benefits | 0.8 |  |  | 0.7 |  |  | 0.6 |  |  | 0.6 |  |  | 0.5 |  |  | 1.5 |  |

[0001069202-16-000014:notes:312]
Pension Plan Assets

[0001069202-16-000014:notes:313]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets between equity and fixed income.  In the first quarter of 2014, in order to increase diversification, we changed the targeted allocations for our plan assets. The target allocations for fixed income, money market, cash and guaranteed investment contracts investments remained unchanged at 58%, targeted equity investment allocations remained unchanged at 42%. Our exposure to International equity remained unchanged at 17% of total assets and our exposure to domestic equity remained unchanged at 25%. These categories are further diversified among various asset classes including high yield and emerging markets debt, and international and emerging markets equities in order to avoid significant concentrations of risk. Our U.S. pension plan represents 88%, our Canadian pension plan 6%, and our United Kingdom (“U.K.”) pension plan 6% of the total fair value of our plan assets as of December 31, 2015.

[0001069202-16-000014:notes:314]
Our U.S. pension plans' weighted-average asset allocations as of December 31, 2015 and 2014, by asset category, are as follows:

[0001069202-16-000014:notes:315]
|  | Plan Assets as of December 31, |
| Asset Category: | 2015 |  | 2014 |
| U.S. equity | 27.1 | % |  | 28.3 | % |
| International equity | 17.7 | % |  | 17.1 | % |
| Fixed income | 53.8 | % |  | 52.6 | % |
| Money market/cash | 1.4 | % |  | 2.0 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-16-000014:notes:316]
Our Canadian pension plan was invested solely in a balanced fund that maintains diversification among various asset classes, including Canadian common stocks, bonds and money market securities, international equities and fixed income investments. Our U.K. pension plan was invested in a broad mix of assets consisting of U.K., international equities, and U.K. fixed income securities, including corporate and government bonds.

[0001069202-16-000014:notes:317]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund's NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust's underlying assets divided by the number of units owned.  See Note 20 for information about our fair value hierarchies and valuation techniques.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-16-000014:notes:318]
Property, Plant and Equipment:

[0001069202-16-000014:notes:319]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-16-000014:notes:320]
|  | As of December 31, |
|  | 2015 |  | 2014 |
| Land | $ | 33.9 |  |  | $ | 38.3 |  |
| Buildings and improvements | 211.8 |  |  | 215.0 |  |
| Machinery and equipment | 699.4 |  |  | 681.8 |  |
| Capital leases | 27.1 |  |  | 27.0 |  |
| Construction in progress and equipment not yet in service | 50.3 |  |  | 50.6 |  |
| Total | 1,022.5 |  |  | 1,012.7 |  |
| Less accumulated depreciation | (682.9 | ) |  | (654.1 | ) |
| Property, plant and equipment, net | $ | 339.6 |  |  | $ | 358.6 |  |

[0001069202-16-000014:notes:321]
During the fourth quarter we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed an impairment analysis using a market approach and determined that property, plant and equipment relating to the North American supermarket display case  business unit were impaired and we recorded a charge of $23.3 million in "Asset impairment" in the Consolidated Statement of Operations. No impairment charges were recorded in 2014 or 2013.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001069202-16-000014:notes:322]
Property, Plant and Equipment

[0001069202-16-000014:notes:323]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001069202-16-000014:notes:324]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-16-000014:notes:325]
| Buildings and improvements: |  |
| Buildings and improvements | 3 to 33 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 15 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 30 years |
| Research and development equipment | 5 to 10 years |
| Vehicles | 3 to 8 years |

[0001069202-16-000014:notes:326]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 5 for additional information on our property, plant and equipment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-16-000014:notes:327]
Selected Quarterly Financial Information (unaudited):

[0001069202-16-000014:notes:328]
The following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-16-000014:notes:329]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (Loss) (1) |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| First Quarter | $ | 685.8 |  |  | $ | 695.4 |  |  | $ | 163.0 |  |  | $ | 168.1 |  |  | $ | 13.9 |  |  | $ | 19.9 |  |
| Second Quarter | 992.5 |  |  | 960.7 |  |  | 283.4 |  |  | 262.6 |  |  | 81.2 |  |  | 73.9 |  |
| Third Quarter | 955.0 |  |  | 898.4 |  |  | 273.4 |  |  | 247.1 |  |  | 80.3 |  |  | 67.4 |  |
| Fourth Quarter | 834.1 |  |  | 812.8 |  |  | 227.6 |  |  | 225.4 |  |  | 11.2 |  |  | 44.6 |  |

[0001069202-16-000014:notes:330]
|  | Basic Earnings (Loss) per Share (2) |  | Diluted Earnings (Loss) per Share (2) |  | Cash Dividends per Common Share |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| First Quarter | $ | 0.31 |  |  | $ | 0.41 |  |  | $ | 0.31 |  |  | $ | 0.40 |  |  | $ | 0.30 |  |  | $ | 0.24 |  |
| Second Quarter | 1.80 |  |  | 1.51 |  |  | 1.78 |  |  | 1.49 |  |  | 0.36 |  |  | 0.30 |  |
| Third Quarter | 1.78 |  |  | 1.40 |  |  | 1.76 |  |  | 1.38 |  |  | 0.36 |  |  | 0.30 |  |
| Fourth Quarter | 0.25 |  |  | 0.98 |  |  | 0.25 |  |  | 0.96 |  |  | 0.36 |  |  | 0.30 |  |

[0001069202-16-000014:notes:331]
(1)  The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-16-000014:notes:332]
(2)  EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.

[0001069202-16-000014:notes:333]
Summary of 2015 Quarterly Results

[0001069202-16-000014:notes:334]
The following unusual or infrequent pre-tax items were included in the 2015 quarterly results:

[0001069202-16-000014:notes:335]
1st Quarter.  No significant unusual or infrequent items.

[0001069202-16-000014:notes:336]
2nd Quarter.  No significant unusual or infrequent items.

[0001069202-16-000014:notes:337]
3rd Quarter.  No significant unusual or infrequent items.

[0001069202-16-000014:notes:338]
4th Quarter.  We recorded goodwill impairment and asset impairment charges of $5.5 million and $44.5 million, respectively,  to our North American supermarket display case business. Refer to Notes 4 and 5 for more information related to our impairment charges.

[0001069202-16-000014:notes:339]
Summary of 2014 Quarterly Results

[0001069202-16-000014:notes:340]
The following unusual or infrequent pre-tax items were 2014  included in the  quarterly results:

[0001069202-16-000014:notes:341]
3rd Quarter.  We recorded restructuring charges of $1 million for a new project to realign resources and enhance distribution capabilities.  Refer to Note 16 for more information related to our restructuring activities.

[0001069202-16-000014:notes:342]
4th Quarter.  We recorded restructuring charges of $.6 million for our project to realign resources and enhance distribution capabilities.


## us-gaap:ReceivablesPolicyTextBlock

[0001069202-16-000014:notes:343]
Accounts and Notes Receivable

[0001069202-16-000014:notes:344]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management's judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management's review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001069202-16-000014:notes:345]
Total assets by segment are shown below (in millions):

[0001069202-16-000014:notes:346]
|  | As of December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 628.3 |  |  | $ | 632.3 |  |  | $ | 500.0 |  |
| Commercial Heating & Cooling | 363.6 |  |  | 353.4 |  |  | 346.3 |  |
| Refrigeration | 444.9 |  |  | 551.5 |  |  | 572.0 |  |
| Corporate and other | 243.4 |  |  | 227.1 |  |  | 208.4 |  |
| Assets for continuing operations | 1,680.2 |  |  | 1,764.3 |  |  | 1,626.7 |  |
| Discontinued operations (See Note 17) | — |  |  | — |  |  | — |  |
| Total assets | $ | 1,680.2 |  |  | $ | 1,764.3 |  |  | $ | 1,626.7 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-16-000014:notes:347]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Income from continuing operations before income taxes, are shown below (in millions):

[0001069202-16-000014:notes:348]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 1,866.9 |  |  | $ | 1,736.5 |  |  | $ | 1,583.2 |  |
| Commercial Heating & Cooling | 887.2 |  |  | 878.5 |  |  | 844.4 |  |
| Refrigeration | 713.3 |  |  | 752.4 |  |  | 771.5 |  |
|  | $ | 3,467.4 |  |  | $ | 3,367.4 |  |  | $ | 3,199.1 |  |
| Segment Profit (Loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 278.4 |  |  | $ | 235.8 |  |  | $ | 180.1 |  |
| Commercial Heating & Cooling | 130.4 |  |  | 124.0 |  |  | 118.1 |  |
| Refrigeration | 52.9 |  |  | 55.4 |  |  | 90.2 |  |
| Corporate and other | (84.1 | ) |  | (74.3 | ) |  | (87.9 | ) |
| Subtotal that includes segment profit and eliminations | 377.6 |  |  | 340.9 |  |  | 300.5 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |
| Special product quality adjustments | (2.2 | ) |  | (1.4 | ) |  | (2.3 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (2) | 15.6 |  |  | 4.7 |  |  | 8.8 |  |
| Restructuring charges | 3.2 |  |  | 1.9 |  |  | 5.0 |  |
| Interest expense, net | 23.6 |  |  | 17.2 |  |  | 14.5 |  |
| Goodwill impairment | 5.5 |  |  | — |  |  | — |  |
| Asset impairment | 44.5 |  |  | — |  |  | — |  |
| One time inventory write down | 5.6 |  |  | 1.0 |  |  | — |  |
| Other expense, net | (0.8 | ) |  | (0.1 | ) |  | 0.2 |  |
| Income from continuing operations before income taxes | $ | 282.6 |  |  | $ | 317.6 |  |  | $ | 274.3 |  |

[0001069202-16-000014:notes:349]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-16-000014:notes:350]
(2) The Company defines segment profit and loss as a segment's income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-16-000014:notes:351]
| • | Special product quality adjustments; |

[0001069202-16-000014:notes:352]
| • | The following items in Losses and other expenses, net: |

[0001069202-16-000014:notes:353]
| ◦ | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001069202-16-000014:notes:354]
| ◦ | Special legal contingency charges, |

[0001069202-16-000014:notes:355]
| ◦ | Asbestos-related litigation, |

[0001069202-16-000014:notes:356]
| ◦ | Environmental liabilities, and |

[0001069202-16-000014:notes:357]
| ◦ | Other items, net; |

[0001069202-16-000014:notes:358]
| • | Restructuring charges; |

[0001069202-16-000014:notes:359]
| • | Goodwill, long-lived asset, and equity method investment impairments; |

[0001069202-16-000014:notes:360]
| • | Interest expense, net; |

[0001069202-16-000014:notes:361]
| • | One time inventory write down; and |

[0001069202-16-000014:notes:362]
| • | Other expense, net. |


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001069202-16-000014:notes:363]
Total capital expenditures by segment are shown below (in millions):

[0001069202-16-000014:notes:364]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 28.1 |  |  | $ | 39.4 |  |  | $ | 34.2 |  |
| Commercial Heating & Cooling | 8.6 |  |  | 14.1 |  |  | 11.2 |  |
| Refrigeration | 11.4 |  |  | 15.8 |  |  | 16.5 |  |
| Corporate and other | 21.8 |  |  | 19.1 |  |  | 16.4 |  |
| Total capital expenditures (1) | $ | 69.9 |  |  | $ | 88.4 |  |  | $ | 78.3 |  |

[0001069202-16-000014:notes:365]
(1) Includes amounts recorded under capital leases. There were no significant new capital leases in 2015, 2014 or 2013.

[0001069202-16-000014:notes:366]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-16-000014:notes:367]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 20.7 |  |  | $ | 20.7 |  |  | $ | 20.5 |  |
| Commercial Heating & Cooling | 9.7 |  |  | 9.3 |  |  | 9.0 |  |
| Refrigeration | 15.5 |  |  | 16.3 |  |  | 15.3 |  |
| Corporate and other | 16.9 |  |  | 14.5 |  |  | 14.1 |  |
| Total depreciation and amortization | $ | 62.8 |  |  | $ | 60.8 |  |  | $ | 58.9 |  |

[0001069202-16-000014:notes:368]
The equity method investments are shown below (in millions):

[0001069202-16-000014:notes:369]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Refrigeration | $ | 2.8 |  |  | $ | 2.5 |  |  | $ | 2.5 |  |
| Residential | 10.6 |  |  | 11.3 |  |  | 9.7 |  |
| Total income from equity method investments | $ | 13.4 |  |  | $ | 13.8 |  |  | $ | 12.2 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-16-000014:notes:370]
Restructuring Charges:

[0001069202-16-000014:notes:371]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 19.

[0001069202-16-000014:notes:372]
Restructuring Activities in 2015

[0001069202-16-000014:notes:373]
Information regarding the restructuring charges for all ongoing activities are presented in the table below (in millions):

[0001069202-16-000014:notes:374]
|  | Incurred in 2015 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 2.6 |  |  | $ | 9.5 |  |  | $ | 9.5 |  |
| Asset write-offs and accelerated depreciation | 0.3 |  |  | 2.1 |  |  | 2.1 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Other | 0.1 |  |  | 2.0 |  |  | 2.0 |  |
| Total | $ | 3.2 |  |  | $ | 13.8 |  |  | $ | 13.8 |  |

[0001069202-16-000014:notes:375]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-16-000014:notes:376]
|  | Incurred in 2015 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | (0.6 | ) |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | 3.8 |  |  | 12.0 |  |  | 12.0 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total | $ | 3.2 |  |  | $ | 13.8 |  |  | $ | 13.8 |  |

[0001069202-16-000014:notes:377]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.  The activity within the restructuring accruals is summarized in the tables below (in millions):

[0001069202-16-000014:notes:378]
| Description of Reserves: | Balance as of December 31, 2014 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2015 |
| Severance and related expense | $ | 1.5 |  |  | $ | 2.6 |  |  | $ | (2.9 | ) |  | $ | (0.5 | ) |  | $ | 0.7 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 0.3 |  |  | (0.2 | ) |  | (0.2 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Other | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Total restructuring reserves | $ | 1.6 |  |  | $ | 3.2 |  |  | $ | (3.2 | ) |  | $ | (0.7 | ) |  | $ | 0.9 |  |

[0001069202-16-000014:notes:379]
| Description of Reserves: | Balance as of December 31, 2013 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2014 |
| Severance and related expense | $ | 1.6 |  |  | $ | 1.4 |  |  | $ | (1.5 | ) |  | $ | — |  |  | $ | 1.5 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.3 |  |  | — |  |  | (0.2 | ) |  | 0.1 |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.2 |  |  | (0.2 | ) |  | — |  |  | — |  |
| Total restructuring reserves | $ | 1.6 |  |  | $ | 1.9 |  |  | $ | (1.7 | ) |  | $ | (0.2 | ) |  | $ | 1.6 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001069202-16-000014:notes:380]
Revenue Recognition

[0001069202-16-000014:notes:381]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where title and risk of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.

[0001069202-16-000014:notes:382]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for these services is recognized over the life of the contract.

[0001069202-16-000014:notes:383]
We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.  See Note 23 for more information on these costs.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001069202-16-000014:notes:384]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-16-000014:notes:385]
|  | As of December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 224.8 |  |  | $ | 243.4 |  |  | $ | 230.3 |  |
| Mexico | 60.0 |  |  | 52.4 |  |  | 39.7 |  |
| Canada | 1.2 |  |  | 0.6 |  |  | 0.6 |  |
| International | 53.6 |  |  | 62.2 |  |  | 64.9 |  |
| Total Property, plant and equipment, net | $ | 339.6 |  |  | $ | 358.6 |  |  | $ | 335.5 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001069202-16-000014:notes:386]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-16-000014:notes:387]
| Asset | Useful Life |
| Deferred financing costs | Effective interest method |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001069202-16-000014:notes:388]
Net sales for each major geographic area in which we operate are shown below (in millions):

[0001069202-16-000014:notes:389]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Net Sales to External Customers by Point of Shipment: |  |  |  |  |  |
| United States | $ | 2,793.4 |  |  | $ | 2,576.4 |  |  | $ | 2,382.0 |  |
| Canada | 217.7 |  |  | 236.3 |  |  | 232.3 |  |
| International | 456.3 |  |  | 554.7 |  |  | 584.8 |  |
| Total net sales to external customers | $ | 3,467.4 |  |  | $ | 3,367.4 |  |  | $ | 3,199.1 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-16-000014:notes:390]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-16-000014:notes:391]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air- cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-16-000014:notes:392]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-16-000014:notes:393]
For the Years Ended December 31, 2015, 2014 and 2013

[0001069202-16-000014:notes:394]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2013: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 9.5 |  |  | $ | 3.6 |  |  | $ | (4.6 | ) |  | $ | 1.6 |  |  | $ | (0.3 | ) |  | $ | 9.8 |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 9.8 |  |  | $ | 2.6 |  |  | $ | (4.6 | ) |  | $ | 1.1 |  |  | $ | (1.0 | ) |  | $ | 7.9 |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 7.9 |  |  | $ | 2.8 |  |  | $ | (4.9 | ) |  | $ | 1.1 |  |  | $ | (0.6 | ) |  | $ | 6.3 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-16-000014:notes:395]
Reportable Business Segments:

[0001069202-16-000014:notes:396]
Description of Segments

[0001069202-16-000014:notes:397]
In September 2012, we announced the planned sale of our Service Experts business. The Service Experts business had previously been reported within the Service Experts reportable segment along with the Lennox National Account Services ("NAS") business.  Beginning in the third quarter of 2012, the Service Experts business was included in discontinued operations, NAS was included in our Commercial Heating & Cooling segment, and the Service Experts segment was eliminated. Results for all periods have been revised to reflect this new presentation.

[0001069202-16-000014:notes:398]
Segment Data

[0001069202-16-000014:notes:399]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001069202-16-000014:notes:400]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-16-000014:notes:401]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-16-000014:notes:402]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-16-000014:notes:403]
Geographic Information


## us-gaap:SelfInsuranceReservePolicyTextBlock

[0001069202-16-000014:notes:404]
Self-Insurance

[0001069202-16-000014:notes:405]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information and industry factors and trends.  The self-insurance liabilities as of December 31, 2015 represent the best estimate of the future payments to be made on reported and unreported losses for 2015 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 10 for additional information on our self-insured risks and liabilities.


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001069202-16-000014:notes:406]
Selling, General and Administrative Expenses

[0001069202-16-000014:notes:407]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-16-000014:notes:408]
Summary of Significant Accounting Policies:

[0001069202-16-000014:notes:409]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually and whenever events or changes in circumstances indicate the asset may be impaired (See Note 4 for additional information on our goodwill).  The annual goodwill impairment test was performed during the fourth quarter of 2015.

[0001069202-16-000014:notes:410]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-16-000014:notes:411]
For those reporting units which are evaluated using the two-step quantitative goodwill impairment test, we estimate reporting unit fair values using either the discounted cash flow approach or a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. If market approach is used, it is based on objective evidence of market values.

[0001069202-16-000014:notes:412]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-16-000014:notes:413]
We review our indefinite-lived intangible assets for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets. For those intangible assets which are evaluated using the two-step quantitative impairment test, we compare the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets. If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 4 for additional information on our intangible assets.

[0001069202-16-000014:notes:414]
Product Warranties

[0001069202-16-000014:notes:415]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined by product line. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. The estimated units to be repaired under warranty are multiplied by the average cost to repair or replace such products to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 10 for more information on our estimated future warranty costs.

[0001069202-16-000014:notes:416]
Pensions and Post-retirement Benefits

[0001069202-16-000014:notes:417]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheets.  Changes in the funded status are recognized in the year in which the changes occur through accumulated other comprehensive income (“AOCI”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-16-000014:notes:418]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management's estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 12 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-16-000014:notes:419]
Stock-Based Compensation

[0001069202-16-000014:notes:420]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 14 for more information.

[0001069202-16-000014:notes:421]
Use of Estimates

[0001069202-16-000014:notes:422]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-16-000014:notes:423]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-16-000014:notes:424]
Reclassifications

[0001069202-16-000014:notes:425]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:SubsequentEventsTextBlock

[0001069202-16-000014:notes:426]
Subsequent Events:

[0001069202-16-000014:notes:427]
On February 10, 2016, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “ASR Agreement”) with Merrill Lynch International (“Merrill Lynch”), acting through its agent, Merrill Lynch, Pierce, Fenner and Smith Incorporated to effect an accelerated stock buyback of the Company’s common stock (the “Common Stock”).

[0001069202-16-000014:notes:428]
Under the ASR Agreement, on February 10, 2016, the Company will pay Merrill Lynch an initial purchase price of $200 million, and Merrill Lynch will deliver to the Company a total of approximately 1.3 million shares of Common Stock, representing approximately 75% of the shares expected to be purchased under the ASR Agreement.


## us-gaap:TreasuryStockTextBlock

[0001069202-16-000014:notes:429]
Stock Repurchases:

[0001069202-16-000014:notes:430]
Our Board of Directors has authorized a total of $1.4 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $700.0 million share repurchase authorization in October 2014, and a $300.0 million share repurchase authorization in December 2012. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date.  As of December 31, 2015, $396.2 million of shares may still be repurchased under the Share Repurchase Plans.

[0001069202-16-000014:notes:431]
On October 20, 2014, we announced our plans for a new $450.0 million accelerated share repurchase program (the "ASR").  For the years ended December 31, 2015 and 2014,  the final number of shares repurchased under the Share Repurchase Plans, including repurchases under the ASR, was 0.5 million shares in 2015 and 5.2 million in 2014 for a total of $550.3 million.

[0001069202-16-000014:notes:432]
We also repurchased 0.3 million shares for $32.0 million and 0.2 million shares for $22.4 million for the years ended December 31, 2015 and 2014, respectively, from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the vesting of stock-based compensation awards.
