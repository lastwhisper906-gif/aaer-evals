# LII MD&A — 0001069202-16-000014


## mdna

[0001069202-16-000014:mdna:1]
Item 7.  Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-16-000014:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the consolidated financial statements and related notes contained in Item 8 of this Annual Report on Form 10-K.

[0001069202-16-000014:mdna:3]
Business Overview

[0001069202-16-000014:mdna:4]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 19 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000014:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned parts and supplies stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-16-000014:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of higher commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-16-000014:mdna:7]
Financial Highlights

[0001069202-16-000014:mdna:8]
| • | Net sales increased $100.0 million, or 3%, to $3,467 million in 2015 from $3,367 million in 2014. |

[0001069202-16-000014:mdna:9]
| • | Operational income from continuing operations in 2015 was $305 million compared to $335 million in 2014. The decrease was primarily due to goodwill and asset impairment charges. |

[0001069202-16-000014:mdna:10]
| • | Net income in 2015 decreased to $187 million from $206 million in 2014. |

[0001069202-16-000014:mdna:11]
| • | Diluted earnings per share from continuing operations were $4.11 per share in 2015 compared to $4.28 per share in 2014, including non-cash impairment charges in our refrigerated display case business in 2015. |

[0001069202-16-000014:mdna:12]
| • | We generated $331 million of cash flow from operating activities in 2015 compared to $185 million in 2014. |

[0001069202-16-000014:mdna:13]
| • | In 2015, we returned $59 million through dividend payments. |

[0001069202-16-000014:mdna:14]
Overview of Results

[0001069202-16-000014:mdna:15]
The Residential Heating & Cooling segment led our overall financial performance in 2015, with a 8% increase in net sales and a $43 million increase in segment profit compared to 2014.  This segment's results benefited from industry growth in the replacement and new construction markets as well as market share gains.  Our Commercial Heating & Cooling segment also performed well in 2015 with a 1% increase in net sales and a $6 million increase in segment profit compared to 2014.  This segment's results benefited from market share gains, market growth in North America and material cost savings.  Sales in our Refrigeration segment were down 5% and segment profit decreased $3 million compared to 2014.  This segment's results were impacted by unfavorable mix, unfavorable Australian dollar exchange rates, and decreased profitability of our refrigerant business in Australia due to the repeal of the carbon tax.

[0001069202-16-000014:mdna:16]
On a consolidated basis, our gross profit margins increased to 27.3% in 2015 due primarily to favorable price and material cost savings across all of our segments.  These improvements were partially offset by unfavorable foreign exchange rates, continued investment in distribution expansion across all segments, unfavorable mix in all segments, and reduced profitability in our Australian wholesale business due to the repeal of the carbon tax.

[0001069202-16-000014:mdna:17]
Results of Operations

[0001069202-16-000014:mdna:18]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-16-000014:mdna:19]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 3,467.4 |  |  | 100.0 | % |  | $ | 3,367.4 |  |  | 100.0 | % |  | $ | 3,199.1 |  |  | 100.0 | % |
| Cost of goods sold | 2,520.0 |  |  | 72.7 | % |  | 2,464.1 |  |  | 73.2 | % |  | 2,337.9 |  |  | 73.1 | % |
| Gross profit | 947.4 |  |  | 27.3 | % |  | 903.3 |  |  | 26.8 | % |  | 861.2 |  |  | 26.9 | % |
| Selling, general and administrative expenses | 580.5 |  |  | 16.7 | % |  | 573.7 |  |  | 17.0 | % |  | 570.1 |  |  | 17.8 | % |
| Losses and other expenses, net | 21.7 |  |  | 0.6 | % |  | 6.8 |  |  | 0.2 | % |  | 9.3 |  |  | 0.3 | % |
| Restructuring charges | 3.2 |  |  | 0.1 | % |  | 1.9 |  |  | 0.1 | % |  | 5.0 |  |  | 0.2 | % |
| Goodwill Impairment | 5.5 |  |  | 0.2 | % |  | — |  |  | — | % |  | — |  |  | — | % |
| Impairment of assets | 44.5 |  |  | 1.3 | % |  | — |  |  | — | % |  | — |  |  | — | % |
| Income from equity method investments | (13.4 | ) |  | (0.4 | )% |  | (13.8 | ) |  | (0.4 | )% |  | (12.2 | ) |  | (0.4 | )% |
| Operational income from continuing operations | $ | 305.4 |  |  | 8.8 | % |  | $ | 334.7 |  |  | 9.9 | % |  | $ | 289.0 |  |  | 9.0 | % |
| Loss from discontinued operations | (0.6 | ) |  | — | % |  | (2.3 | ) |  | (0.1 | )% |  | (8.1 | ) |  | (0.3 | )% |
| Net income | $ | 186.6 |  |  | 5.4 | % |  | $ | 205.8 |  |  | 6.1 | % |  | $ | 171.8 |  |  | 5.4 | % |

[0001069202-16-000014:mdna:20]
The following table provides net sales by geographic market (dollars in millions):

[0001069202-16-000014:mdna:21]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net Sales by Geographic Market: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. | $ | 2,793.4 |  |  | 80.6 | % |  | $ | 2,576.4 |  |  | 76.5 | % |  | $ | 2,382.0 |  |  | 74.4 | % |
| Canada | 217.7 |  |  | 6.3 |  |  | 236.3 |  |  | 7.0 |  |  | 232.3 |  |  | 7.3 |  |
| International | 456.3 |  |  | 13.1 |  |  | 554.7 |  |  | 16.5 |  |  | 584.8 |  |  | 18.3 |  |
| Total net sales | $ | 3,467.4 |  |  | 100.0 | % |  | $ | 3,367.4 |  |  | 100.0 | % |  | $ | 3,199.1 |  |  | 100.0 | % |

[0001069202-16-000014:mdna:22]
Year Ended December 31, 2015 Compared to Year Ended December 31, 2014 - Consolidated Results

[0001069202-16-000014:mdna:23]
Net Sales

[0001069202-16-000014:mdna:24]
Net sales increased 3% in 2015 compared to 2014, with sales volumes up approximately 6% and price and mix up approximately 1%.  The increase in volume was driven by our Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments.  The benefit of price and mix was a combination of price increases across all segments and favorable product mix predominantly in our Residential Heating & Cooling segment.  Partially offsetting these increases was a 4% decrease from foreign currency exchange rates.

[0001069202-16-000014:mdna:25]
Gross Profit

[0001069202-16-000014:mdna:26]
Gross profit margins for 2015 increased 50 basis points ("bps") to 27.3% compared to 26.8% in 2014.  Lower material costs increased our profit margin by 200 bps, increased factory productivity increased our profit margin by 20 bps and reduced product warranty costs increased our profit margin by 10 bps. Offsetting these increases were decreases of 70 bps from unfavorable mix, 50 bps from unfavorable foreign currency adjustments, 20 bps from lower refrigerant pricing on our Australia wholesale business when compared to the prior year, 30 bps for investments in distribution and other growth initiatives, and 10 bps from one-time inventory write down costs.

[0001069202-16-000014:mdna:27]
Selling, General and Administrative Expenses

[0001069202-16-000014:mdna:28]
SG&A expenses increased by $7 million in 2015 compared to 2014.  As a percentage of net sales, SG&A expenses decreased 30 bps from 17.0% to 16.7% in the same periods.  The dollar increase in SG&A expenses was principally due to increased incentive compensation, general wage inflation, and health care costs.

[0001069202-16-000014:mdna:29]
Losses and Other Expenses, Net

[0001069202-16-000014:mdna:30]
Losses and other expenses, net for 2015 and 2014 included the following (in millions):

[0001069202-16-000014:mdna:31]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2014 |
| Realized losses on settled futures contracts | $ | 1.9 |  |  | $ | 0.8 |  |
| Foreign currency exchange losses | 3.6 |  |  | 1.6 |  |
| (Gain) loss on disposal of fixed assets | 0.6 |  |  | (0.3 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.6 |  |  | 0.6 |  |
| Asbestos charge | 3.0 |  |  | 0.9 |  |
| Acquisition expenses | 1.0 |  |  | — |  |
| Special legal contingency charge | 7.4 |  |  | 0.9 |  |
| Environmental liabilities | 1.0 |  |  | 2.0 |  |
| Contractor tax payments | 2.6 |  |  | — |  |
| Other items, net | — |  |  | 0.3 |  |
| Losses and other expenses, net | $ | 21.7 |  |  | $ | 6.8 |  |

[0001069202-16-000014:mdna:32]
The increase in realized losses on settled futures contracts in 2015 was attributable to decreases in commodity prices relative to our settled futures contract prices.  Additionally, the change in unrealized losses on unsettled futures contracts was primarily due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000014:mdna:33]
Foreign currency exchange losses increased in 2015 primarily due to the Canadian dollar exchange rates.  The special legal contingency charges primarily increased for our estimate of costs expected to be incurred for an attempted class action lawsuit.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  The contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos charges, and the environmental liabilities.

[0001069202-16-000014:mdna:34]
Restructuring Charges

[0001069202-16-000014:mdna:35]
Restructuring charges were $3 million in 2015 compared to $2 million in 2014.  The charges in 2015 and 2014 charges were primarily for projects to realign resources and enhance distribution capabilities in our Refrigeration segment.  For more information on our restructuring activities, see Note 16 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000014:mdna:36]
Goodwill

[0001069202-16-000014:mdna:37]
During the fourth quarter we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed a quantitative impairment analysis for this business unit using the market approach.  Based on the results of the quantitative impairment test, we recorded goodwill impairment of $5.5 million. No other indicators of goodwill impairment were identified through December 31, 2015.  Also, we did not record any goodwill impairments related to continuing operations in 2014.  Refer to Note 4 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-16-000014:mdna:38]
Income from Equity Method Investments

[0001069202-16-000014:mdna:39]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments decreased to $13 million in 2015 compared to $14 million in 2014 due to decreases in earnings from our joint ventures.

[0001069202-16-000014:mdna:40]
Asset Impairment

[0001069202-16-000014:mdna:41]
During the fourth quarter we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed an impairment analysis using a market approach and determined that intangible and certain long-lived assets relating to our North American supermarket business were impaired and we recorded a charge of $45 million in "Asset Impairment" in the Consolidated Statement of Operations. We did not have any impairments of intangible assets related to continuing operations in 2014.

[0001069202-16-000014:mdna:42]
Interest Expense, net

[0001069202-16-000014:mdna:43]
Net interest expense of $24 million in 2015 increased from $17 million in 2014 primarily due to an increase in our average borrowings.

[0001069202-16-000014:mdna:44]
Income Taxes

[0001069202-16-000014:mdna:45]
The income tax provision was $95 million in 2015 compared to $110 million in 2014, and the effective tax rate was 33.8% in 2015 compared to 34.5% in 2014.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-16-000014:mdna:46]
Loss from Discontinued Operations

[0001069202-16-000014:mdna:47]
The Loss from discontinued operations related to the Service Experts business sold in March 2013 and the Hearth business sold in April 2012.  The $1 million of pre-tax losses incurred in 2015 primarily relate to changes in retained product liabilities and general liabilities for Service Experts and Hearth. In 2014, there were $4 million of pre-tax losses incurred primarily related to  changes in retained product liabilities and general liabilities for Service Experts and Hearth.

[0001069202-16-000014:mdna:48]
Year Ended December 31, 2015 Compared to Year Ended December 31, 2014 - Results by Segment

[0001069202-16-000014:mdna:49]
Residential Heating & Cooling

[0001069202-16-000014:mdna:50]
The following table presents our Residential Heating & Cooling segment's net sales and profit for 2015 and 2014 (dollars in millions):

[0001069202-16-000014:mdna:51]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 1,866.9 |  |  | $ | 1,736.5 |  |  | $ | 130.4 |  |  | 7.5 | % |
| Profit | $ | 278.4 |  |  | $ | 235.8 |  |  | $ | 42.6 |  |  | 18.1 | % |
| % of net sales | 14.9 | % |  | 13.6 | % |  |  |  |  |

[0001069202-16-000014:mdna:52]
Residential Heating & Cooling net sales increased 8% in 2015 compared to 2014 driven by strong volume increases and favorable price and mix.  Sales volume increases contributed 7% and were attributable to industry growth in new construction and replacement markets and market share gains.  Benefits of price increases and favorable product mix contributed 2%. Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-16-000014:mdna:53]
Segment profit in 2015 increased $43 million due to $39 million from material cost savings, $29 million from higher sales volume, and $10 million from favorable price and mix. Partially offsetting these increases were $12 million of unfavorable foreign exchange rates, $10 million in higher distribution expenses related to continued investment in distribution expansion, $10 million of SG&A inflation, and $3 million due to lower factory absorption and higher warranty expenses.

[0001069202-16-000014:mdna:54]
Commercial Heating & Cooling

[0001069202-16-000014:mdna:55]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for 2015 and 2014 (dollars in millions):

[0001069202-16-000014:mdna:56]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 887.2 |  |  | $ | 878.5 |  |  | $ | 8.7 |  |  | 1.0 | % |
| Profit | $ | 130.4 |  |  | $ | 124.0 |  |  | $ | 6.4 |  |  | 5.2 | % |
| % of net sales | 14.7 | % |  | 14.1 | % |  |  |  |  |

[0001069202-16-000014:mdna:57]
Commercial Heating & Cooling net sales increased 1% in 2015 compared to 2014 driven by higher volumes.  Net sales increased by 6% due to higher volumes while changes in foreign currency exchange rates unfavorably impacted net sales by 5%.

[0001069202-16-000014:mdna:58]
Segment profit in 2015 increased $6 million compared to 2014.  The benefits of $15 million from incremental volume, $14 million from lower material costs and $2 million from higher prices were partially offset by $9 million in unfavorable mix, $4 million for information technology and distribution investments and start-up costs to enter the VRF market, $6 million for unfavorable foreign exchange rates, $5 million of higher SG&A expenses and $1 million from increases in other product costs.

[0001069202-16-000014:mdna:59]
Refrigeration

[0001069202-16-000014:mdna:60]
The following table presents our Refrigeration segment's net sales and profit for 2015 and 2014 (dollars in millions):

[0001069202-16-000014:mdna:61]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 713.3 |  |  | $ | 752.4 |  |  | $ | (39.1 | ) |  | (5.2 | )% |
| Profit | $ | 52.9 |  |  | $ | 55.4 |  |  | $ | (2.5 | ) |  | (4.5 | )% |
| % of net sales | 7.4 | % |  | 7.4 | % |  |  |  |  |

[0001069202-16-000014:mdna:62]
Refrigeration net sales declined 5% in 2015 compared to 2014 primarily due to an 8% impact from unfavorable foreign exchange rates and a 2% impact from the Australian carbon levy repeal that was effective July 1, 2014.  These decreases were partially offset by 4% volume growth, led by our North American supermarket businesses, and price and mix combined contributed 1%.

[0001069202-16-000014:mdna:63]
Segment profit in 2015 compared to 2014 decreased $3 million compared to 2014 primarily due to $14 million from unfavorable mix, predominantly in the North American supermarket business, $9 million lower profitability in our Australia refrigerant business, $1 million of costs related to investments for future growth, $5 million from unfavorable foreign currency exchange rates, and $3 million for higher SG&A expenses.  Partially offsetting these decreases were $14 million from material cost savings, $2 million from higher sales volumes, and $13 million from improved factory productivity and lower warranty and other product costs.

[0001069202-16-000014:mdna:64]
Corporate and Other

[0001069202-16-000014:mdna:65]
Corporate and other expenses increased $10 million in 2015 to $84 million from $74 million in 2014  due primarily to higher incentive compensation, general wage inflation, health care costs and currency losses.

[0001069202-16-000014:mdna:66]
Year Ended December 31, 2014 Compared to Year Ended December 31, 2013 - Consolidated Results

[0001069202-16-000014:mdna:67]
Net Sales

[0001069202-16-000014:mdna:68]
Net sales increased 5% in 2014 compared to 2013, with sales volumes up approximately 5% and price and mix up approximately 1%.  The increase in volume was driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  The benefit of price and mix was a combination of price increases across all segments and favorable product mix predominantly in our Residential Heating & Cooling segment.  Partially offsetting these increases was a 1% decrease from foreign currency exchange rates.

[0001069202-16-000014:mdna:69]
Gross Profit

[0001069202-16-000014:mdna:70]
Gross profit margins were relatively flat at 26.8% in 2014 compared to 26.9% in 2013. Profit margin increased by 140 bps due to lower material costs and 10 bps for reductions in product warranty costs. Offsetting these increases were decreases of 20 bps from unfavorable mix, 10 bps from lower refrigerant pricing on our Australia wholesale business when compared to the prior year, and 60 bps for investments in distribution and other growth initiatives with the balance from other cost changes.

[0001069202-16-000014:mdna:71]
Selling, General and Administrative Expenses

[0001069202-16-000014:mdna:72]
SG&A expenses increased by $4 million in 2014 compared to 2013.  As a percentage of net sales, SG&A expenses decreased 80 bps from 17.8% to 17.0% in the same periods.  The percentage decrease in SG&A expenses was principally due to lower employee incentive compensation.

[0001069202-16-000014:mdna:73]
Losses and Other Expenses, Net

[0001069202-16-000014:mdna:74]
Losses and other expenses, net for 2014 and 2013 included the following (in millions):

[0001069202-16-000014:mdna:75]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |
| Realized losses on settled futures contracts | $ | 0.8 |  |  | $ | 1.0 |  |
| Foreign currency exchange losses | 1.6 |  |  | 0.5 |  |
| Gains on disposal of fixed assets | (0.3 | ) |  | (1.0 | ) |
| Net change in unrealized losses on unsettled futures contracts | 0.6 |  |  | 0.4 |  |
| Special legal contingency charges | 0.9 |  |  | 1.2 |  |
| Asbestos-related litigation | 0.9 |  |  | 6.3 |  |
| Environmental liabilities | 2.0 |  |  | — |  |
| Other items, net | 0.3 |  |  | 0.9 |  |
| Losses and other expenses, net | $ | 6.8 |  |  | $ | 9.3 |  |

[0001069202-16-000014:mdna:76]
The decline in realized losses on settled futures contracts in 2014 was attributable to increases in commodity prices relative to our settled futures contract prices.  Conversely, the change in unrealized losses on unsettled futures contracts was primarily due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000014:mdna:77]
The special legal contingency charges relate to patent litigation which was settled in early 2014.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos charges, and the environmental liabilities.

[0001069202-16-000014:mdna:78]
Restructuring Charges

[0001069202-16-000014:mdna:79]
Restructuring charges were $2 million in 2014 compared to $5 million in 2013.  2014 charges were primarily for a new project to realign resources and enhance distribution capabilities in our Refrigeration segment.  The charges in 2013 related to our Regional Distribution Network project as well as anticipated severance charges associated with a relocation of certain Residential Heating & Cooling manufacturing operations to lower cost facilities.  For more information on our restructuring activities, see Note 16 in the Notes to the Consolidated Financial Statements.

[0001069202-16-000014:mdna:80]
Income from Equity Method Investments

[0001069202-16-000014:mdna:81]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments increased to $14 million in 2014 compared to $12 million in 2013 due to increases in earnings from our joint ventures.

[0001069202-16-000014:mdna:82]
Interest Expense, net

[0001069202-16-000014:mdna:83]
Net interest expense of $17 million in 2014 increased from $15 million in 2013 due to an increase in our weighted-average interest rates in the comparable periods as well as an increase in our average borrowings.

[0001069202-16-000014:mdna:84]
Income Taxes

[0001069202-16-000014:mdna:85]
The income tax provision was $110 million in 2014 compared to $94 million in 2013, and the effective tax rate was 34.5% in 2014 compared to 34.4% in 2013.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-16-000014:mdna:86]
Loss from Discontinued Operations

[0001069202-16-000014:mdna:87]
The Loss from discontinued operations relates to the Service Experts business sold in March 2013 and the Hearth business sold in April 2012.  The $4 million of pre-tax losses incurred in 2014 primary relate to changes in retained product liabilities and general liabilities for Service Experts and Hearth. In 2013, there were $13 million of pre-tax losses from discontinued operations consisting primarily of operating losses in the Service Experts business.  The Hearth business had no significant gains or losses in 2013.

[0001069202-16-000014:mdna:88]
Year Ended December 31, 2014 Compared to Year Ended December 31, 2013 - Results by Segment

[0001069202-16-000014:mdna:89]
Residential Heating & Cooling

[0001069202-16-000014:mdna:90]
The following table presents our Residential Heating & Cooling segment's net sales and profit for 2014 and 2013 (dollars in millions):

[0001069202-16-000014:mdna:91]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 1,736.5 |  |  | $ | 1,583.2 |  |  | $ | 153.3 |  |  | 9.7 | % |
| Profit | $ | 235.8 |  |  | $ | 180.1 |  |  | $ | 55.7 |  |  | 30.9 | % |
| % of net sales | 13.6 | % |  | 11.4 | % |  |  |  |  |

[0001069202-16-000014:mdna:92]
Residential Heating & Cooling net sales increased 10% in 2014 compared to 2013 driven by strong volume increases and favorable price and mix.  Sales volume increases contributed 9% and were attributable to industry growth in new construction and replacement markets and market share gains.  Benefits of price increases and favorable product mix contributed 2%. Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-16-000014:mdna:93]
Segment profit in 2014 increased $56 million due to $27 million contributed by incremental volume, $30 million from commodity and non-commodity material cost savings, $12 million from favorable price, $5 million from favorable mix, $4 million from lower warranty costs, and $1 million from favorable other product costs. Partially offsetting these increases was $7 million in distribution expenses related to continued investment in distribution expansion, unfavorable foreign exchange rates of $9 million, and a $7 million increase in SG&A expenses primarily due to higher wages and other administrative expenses.

[0001069202-16-000014:mdna:94]
Commercial Heating & Cooling

[0001069202-16-000014:mdna:95]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for 2014 and 2013 (dollars in millions):

[0001069202-16-000014:mdna:96]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 878.5 |  |  | $ | 844.4 |  |  | $ | 34.1 |  |  | 4.0 | % |
| Profit | $ | 124.0 |  |  | $ | 118.1 |  |  | $ | 5.9 |  |  | 5.0 | % |
| % of net sales | 14.1 | % |  | 14.0 | % |  |  |  |  |

[0001069202-16-000014:mdna:97]
Commercial Heating & Cooling net sales increased 4% in 2014 compared to 2013 driven by higher volumes.  Sales volume increases contributed 5% and were attributable to market share gains and industry growth in the North American markets. Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-16-000014:mdna:98]
Segment profit in 2014 increased $6 million compared to 2013 due to $12 million from incremental volume, $11 million from material cost savings,  $2 million from favorable price, and $4 million from increased factory productivity.  These increases were

[0001069202-16-000014:mdna:99]
offset by $7 million higher SG&A expenses primarily for start-up costs to enter the VRF market and to support product development, $3 million from unfavorable mix, $6 million from unfavorable foreign exchange rates, with the $7 million balance associated with other costs including investments in distribution expansion.

[0001069202-16-000014:mdna:100]
Refrigeration

[0001069202-16-000014:mdna:101]
The following table presents our Refrigeration segment's net sales and profit for 2014 and 2013 (dollars in millions):

[0001069202-16-000014:mdna:102]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 752.4 |  |  | $ | 771.5 |  |  | $ | (19.1 | ) |  | (2.5 | )% |
| Profit | $ | 55.4 |  |  | $ | 90.2 |  |  | $ | (34.8 | ) |  | (38.6 | )% |
| % of net sales | 7.4 | % |  | 11.7 | % |  |  |  |  |

[0001069202-16-000014:mdna:103]
Refrigeration net sales declined 3% in 2014 compared to 2013 primarily due to a 2% impact from unfavorable Australian and Brazilian foreign currency exchange rates and a 1% negative impact to our refrigerant business in Australia due to the repeal of the carbon tax. The North American supermarket and Australian wholesale businesses have been soft. We continue to expect

[0001069202-16-000014:mdna:104]
the North American supermarket business to improve in 2015 based on national account business won in 2014. In Australia,

[0001069202-16-000014:mdna:105]
with the repeal of the carbon tax, we expect a negative impact to the profitability of our refrigerant business as compared to

[0001069202-16-000014:mdna:106]
prior year periods through the second quarter of 2015.

[0001069202-16-000014:mdna:107]
Segment profit decreased $35 million in 2014 compared to 2013 primarily due to unfavorable price and mix of $13 million, unfavorable foreign exchange rates of $6 million, and $6 million of lower profitability in our Australia refrigerant business caused by the carbon tax repeal.  Also contributing to the decrease in profit was $7 million of investments in growth initiatives, $7 million of higher distribution and other costs, and $5 million of increased SG&A expenses primarily related to wages.  Partially offsetting the cost increases was $9 million of commodity and non-commodity material cost savings.

[0001069202-16-000014:mdna:108]
Corporate and Other

[0001069202-16-000014:mdna:109]
Corporate and other expenses decreased $14 million in 2014 to $74 million from $88 million in 2013 driven primarily by lower incentive compensation.

[0001069202-16-000014:mdna:110]
Accounting for Futures Contracts

[0001069202-16-000014:mdna:111]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 8 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 19 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to income from continuing operations before income taxes.

[0001069202-16-000014:mdna:112]
Liquidity and Capital Resources

[0001069202-16-000014:mdna:113]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-16-000014:mdna:114]
Statement of Cash Flows

[0001069202-16-000014:mdna:115]
The following table summarizes our cash flow activity for the years ended December 31, 2015, 2014 and 2013 (in millions):

[0001069202-16-000014:mdna:116]
|  | 2015 |  | 2014 |  | 2013 |
| Net cash provided by operating activities | $ | 331.2 |  |  | $ | 184.8 |  |  | $ | 210.3 |  |
| Net cash used in investing activities | (69.8 | ) |  | (87.3 | ) |  | (67.3 | ) |
| Net cash used in financing activities | (248.7 | ) |  | (89.5 | ) |  | (150.2 | ) |

[0001069202-16-000014:mdna:117]
Net Cash Provided by Operating Activities - Net cash provided by operating activities increased $146 million to $331 million in 2015 compared to $185 million in 2014.  This increase was primarily attributable to a decrease in working capital requirements and lower income tax payments in 2015 due to timing of payments, partially offset by lower net income.  The majority of the

[0001069202-16-000014:mdna:118]
decrease in working capital in 2015 was related to the 2014 increase in working capital requirement related to inventory to support customers in the minimum-efficiency regulatory transition.

[0001069202-16-000014:mdna:119]
Net Cash Used in Investing Activities - Capital expenditures were $70 million, $88 million and $78 million in 2015, 2014 and 2013, respectively.  Capital expenditures in 2015 were primarily related to an expansion of manufacturing capacity in Mexico for our Residential Heating & Cooling segment, investments in our North America distribution networks and other investments in systems and software to support the overall enterprise.  Net cash used in investing activities for 2013 also included $9 million in net proceeds from the sale of the Service Experts business.

[0001069202-16-000014:mdna:120]
Net Cash Used in Financing Activities - Net cash used in financing activities increased to $249 million in 2015 from $90 million in 2014 primarily due to a decrease in net borrowings and more dividend payments, partially offset by decreased share repurchases.  Net borrowings decreased as we repaid debt in 2015 that was used to support the increased stock repurchases and tax payments in 2014.  We also used $550 million in 2014 to purchase 5.2 million shares of stock in 2014 and 0.5 million shares of stock in 2015 under our share repurchase plans.

[0001069202-16-000014:mdna:121]
Debt Position

[0001069202-16-000014:mdna:122]
The following table details our lines of credit and financing arrangements as of December 31, 2015 (in millions):

[0001069202-16-000014:mdna:123]
|  | Outstanding Borrowings |
| Short-Term Debt: |  |
| Foreign Obligations | $ | 4.1 |  |
| Asset Securitization Program (1) | 200.0 |  |
| Total short-term debt | 204.1 |  |
| Current Maturities: |  |
| Capital lease obligations | 1.2 |  |
| Domestic credit facility (2) | 30.0 |  |
| Long-Term Debt: |  |
| Capital lease obligations | 15.6 |  |
| Domestic credit facility (2) | 293.0 |  |
| Senior unsecured notes | 200.0 |  |
| Total long-term debt | 508.6 |  |
| Total debt | $ | 743.9 |  |

[0001069202-16-000014:mdna:124]
| (1) | In November 2015, we amended the Asset Securitization Program ("ASP"), extending its term to November 13, 2017 and maintaining the maximum securitization amount range of $180.0 million to $220.0 million, depending on the period. The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP. |

[0001069202-16-000014:mdna:125]
| (2) | The available future borrowings on our domestic credit facility are $600.1 million after being reduced by the outstanding borrowings and $4.4 million in outstanding standby letters of credit. We also had $40.8 million in outstanding standby letters of credit outside of the domestic credit facility as of December 31, 2015. |

[0001069202-16-000014:mdna:126]
Financial Leverage

[0001069202-16-000014:mdna:127]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001069202-16-000014:mdna:128]
As of December 31, 2015, our senior credit ratings were Baa3 with a negative outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The credit ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to ensure the capital markets remain available to us.

[0001069202-16-000014:mdna:129]
Our debt-to-total-capital ratio decreased to 88.0% at December 31, 2015 compared to 99.0% at December 31, 2014.  The decrease in the ratio in 2015 is primarily due to the decrease in our net borrowings.  We evaluate our debt-to-EBITDA ratio in order to determine the appropriate targets for share repurchases under our share repurchase programs.

[0001069202-16-000014:mdna:130]
Liquidity

[0001069202-16-000014:mdna:131]
We believe our cash of $39 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $39 million as of December 31, 2015 was $31 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and to pay taxes in the United States for the amounts that were repatriated.

[0001069202-16-000014:mdna:132]
No contributions are required to be made to our U.S. defined benefit plans in 2016. We made $3.8 million in contributions to pension plans in 2015.

[0001069202-16-000014:mdna:133]
On May 15, 2015, our Board of Directors approved a 20% increase in our quarterly dividend on common stock from $0.30 to $0.36 per share effective with the July 2015 dividend payment.  Dividend payments were $59 million in 2015 compared to $53 million in 2014, with the increase due primarily to the increase in dividends approved by the Board of Directors.

[0001069202-16-000014:mdna:134]
We also continued to increase shareholder value through our share repurchase programs.  In 2014, we returned $550 million to our investors through share repurchases.  An additional $396 million of repurchases are still available under the programs.

[0001069202-16-000014:mdna:135]
Financial Covenants related to our Debt

[0001069202-16-000014:mdna:136]
Our domestic credit facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage.  Other covenants contained in the domestic credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio.  The required ratios under our domestic credit facility are detailed below:

[0001069202-16-000014:mdna:137]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-16-000014:mdna:138]
Our domestic credit facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our credit facility could occur if:

[0001069202-16-000014:mdna:139]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-16-000014:mdna:140]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-16-000014:mdna:141]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the domestic credit facility, our senior unsecured notes, the Lake Park Renewal (as described below), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-16-000014:mdna:142]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our domestic credit facility and accelerate amounts due under our domestic credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders' commitments will automatically terminate).

[0001069202-16-000014:mdna:143]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior

[0001069202-16-000014:mdna:144]
unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our domestic credit facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001069202-16-000014:mdna:145]
As of December 31, 2015, we were in compliance with all covenant requirements. Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared and/or the preceding fiscal year.  In addition, stock repurchases can only be made out of surplus.

[0001069202-16-000014:mdna:146]
Leasing Commitments

[0001069202-16-000014:mdna:147]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the "Lake Park Renewal").  The agreement contains customary lease covenants and events of default as well as financial covenants consistent with our credit agreement and we were in compliance with those covenants as of December 31, 2015.  The lease is classified as an operating lease and we realize annualized savings of approximately $2 million in net rent costs from this renewal compared to our previous leasing arrangement.

[0001069202-16-000014:mdna:148]
In 2008, we expanded our Tifton, Georgia manufacturing facility using the proceeds from Industrial Development Bonds (“IDBs”). We entered into a lease agreement with the owner of the property and the issuer of the IDBs, and through our lease payments fund the interest payments to investors in the IDBs. We also guaranteed the repayment of the IDBs and have oustanding letters of credit totaling $14.3 million to fund a potential repurchase of the IDBs in the event investors exercised their right to tender the IDBs to the Trustee.  As of December 31, 2015 and 2014, we had a long-term capital lease obligation of $14.3 million related to these transactions.

[0001069202-16-000014:mdna:149]
Refer to Note 10 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001069202-16-000014:mdna:150]
Off Balance Sheet Arrangements

[0001069202-16-000014:mdna:151]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Rent expense for these leases was $54 million, $51 million, and $54 million in 2015, 2014, and 2013, respectively.  Refer to Notes 10 and 23 of the Notes to the Consolidated Financial Statements for more information on our lease commitments and rent expense, respectively.

[0001069202-16-000014:mdna:152]
Contractual Obligations

[0001069202-16-000014:mdna:153]
Summarized below are our contractual obligations as of December 31, 2015 and their expected impact on our liquidity and cash flows in future periods (in millions):

[0001069202-16-000014:mdna:154]
|  | Payments Due by Period |
|  | Total |  | 1 Year or Less |  | 1 - 3 Years |  | 3 - 5 Years |  | More than 5 Years |
| Total long-term debt obligations (1) | $ | 743.9 |  |  | $ | 235.3 |  |  | $ | 263.9 |  |  | $ | 233.0 |  |  | $ | 11.7 |  |
| Estimated interest payments on debt obligations | 40.9 |  |  | 18.3 |  |  | 14.4 |  |  | 7.7 |  |  | 0.5 |  |
| Operating leases | 138.3 |  |  | 42.8 |  |  | 57.7 |  |  | 23.3 |  |  | 14.5 |  |
| Uncertain tax positions (2) | 0.4 |  |  | 0.4 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 32.5 |  |  | 32.5 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 956.0 |  |  | $ | 329.3 |  |  | $ | 336.0 |  |  | $ | 264.0 |  |  | $ | 26.7 |  |

[0001069202-16-000014:mdna:155]
(1) Contractual obligations related to capital leases are included as part of long-term debt.

[0001069202-16-000014:mdna:156]
(2) The liability for uncertain tax positions includes interest and penalties.

[0001069202-16-000014:mdna:157]
(3) Purchase obligations consist of inventory that is part of our third party logistics programs.

[0001069202-16-000014:mdna:158]
The table above does not include pension, post-retirement benefit and warranty liabilities because it is not certain when these liabilities will be funded.  For additional information regarding our contractual obligations, see Notes 10 and 11 of the Notes to

[0001069202-16-000014:mdna:159]
the Consolidated Financial Statements.  See Note 12 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.

[0001069202-16-000014:mdna:160]
Fair Value Measurements

[0001069202-16-000014:mdna:161]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001069202-16-000014:mdna:162]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-16-000014:mdna:163]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-16-000014:mdna:164]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-16-000014:mdna:165]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-16-000014:mdna:166]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.

[0001069202-16-000014:mdna:167]
27

[0001069202-16-000014:mdna:168]
Valuation adjustments to reflect either party's creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2015 and 2014, the measurement dates.

[0001069202-16-000014:mdna:169]
See Note 20 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001069202-16-000014:mdna:170]
Market Risk

[0001069202-16-000014:mdna:171]
Commodity Price Risk

[0001069202-16-000014:mdna:172]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001069202-16-000014:mdna:173]
| Notional amount (pounds of aluminum and copper) | 39.9 |  |
| Carrying amount and fair value of net liability | $ | 13.7 |  |
| Change in fair value from 10% change in forward prices | $ | 8.4 |  |

[0001069202-16-000014:mdna:174]
Refer to Note 8 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001069202-16-000014:mdna:175]
Interest Rate Risk

[0001069202-16-000014:mdna:176]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $2.1 million and $0.9 million for the years ended December 31, 2015 and 2014, respectively.

[0001069202-16-000014:mdna:177]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2015 and 2014, no interest rate swaps were in effect.

[0001069202-16-000014:mdna:178]
Foreign Currency Exchange Rate Risk

[0001069202-16-000014:mdna:179]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  During 2015, 2014 and 2013, net sales from outside the U.S. represented 19.4%, 23.5% and 25.5%, respectively, of our total net sales.  For the years ended December 31, 2015 and 2014, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $2.5 million and $4.1 million impact to net income for the years ended December 31, 2015 and 2014, respectively.

[0001069202-16-000014:mdna:180]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 8 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001069202-16-000014:mdna:181]
Critical Accounting Estimates

[0001069202-16-000014:mdna:182]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following are our critical accounting estimates and describe how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements:

[0001069202-16-000014:mdna:183]
| • | Product warranties and product-related contingencies; |

[0001069202-16-000014:mdna:184]
| • | Self-insurance expense; |

[0001069202-16-000014:mdna:185]
| • | Pension benefits; |

[0001069202-16-000014:mdna:186]
| • | Derivative accounting; and |

[0001069202-16-000014:mdna:187]
| • | Goodwill and intangible assets. |

[0001069202-16-000014:mdna:188]
This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001069202-16-000014:mdna:189]
Product Warranties and Product-Related Contingencies

[0001069202-16-000014:mdna:190]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.  We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and, from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.

[0001069202-16-000014:mdna:191]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 10 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001069202-16-000014:mdna:192]
Self-Insurance Expense

[0001069202-16-000014:mdna:193]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability, auto liability, auto physical damage and other exposures.  Many of these plans have large deductibles and may also include per occurrence and annual aggregate limits.  As a result, we expect to incur costs related to these types of claims in future periods.

[0001069202-16-000014:mdna:194]
The estimates for self-insurance expense and liabilities involve assumptions about the amount, timing and nature of future claim costs.  The amounts and timing of payments for future claims may vary depending on numerous factors, including the development and ultimate settlement of reported and unreported claims.  We estimate these amounts actuarially based primarily on our historical claims information, as well as industry factors and trends.  To the extent actuarial assumptions change and claims experience differ from historical rates, our liabilities may change.  The self-insurance liabilities as of December 31, 2015 represent the best estimate of the future payments to be made on reported and unreported losses.  See Note 10 in the Notes to the Consolidated Financial Statements for additional information on our self-insurance expense and liabilities.

[0001069202-16-000014:mdna:195]
Pension Benefits

[0001069202-16-000014:mdna:196]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  We also have several active defined benefit plans that provide benefits based on years of service.  In the years ended December 31, 2015 and December 31, 2014, we contributed $3.8 million and $10 million to our pension plans, respectively.

[0001069202-16-000014:mdna:197]
We make several assumptions to calculate our liability and the expense for these benefit plans, including the discount rate and expected return on assets.  We used an assumed discount rate of 4.51% for pension benefits of our U.S.-based plans as of December 31, 2015.  Our discount rates were selected using the yield curve for high-quality corporate bonds, which is dependent upon risk-free interest rates and current credit market conditions.  In 2015 and 2014, we utilized an assumed long-term rate of return on assets of 7.50% and 8.00%, respectively.  These are long-term estimates of equity values and are not dependent on short-term variations of the equity markets.  Differences between actual experience and our assumptions are quantified as actuarial gains and losses.  These actuarial gains and losses do not immediately impact our earnings as they are deferred in accumulated other comprehensive income (“AOCI”) and are amortized into net periodic benefit cost over the estimated service period.  During the fourth quarter of 2014, we adopted the new mortality tables, MP-2014, from the Society of Actuaries, which reflects increasing life expectancies in the United States. In 2015, we adopted the additional revisions to the mortality tables included in MP-2015.

[0001069202-16-000014:mdna:198]
The assumed long-term rate of return on assets and the discount rate have significant effects on the amounts reported for our defined benefit plans.  A 25 bps decrease in the long-term rate of return on assets or discount rate would have the following effects (in millions):

[0001069202-16-000014:mdna:199]
|  | 25 Basis Point Decrease in Long-Term Rate of Return |  | 25 Basis Point Decrease in Discount Rate |
| Increase to net periodic benefit cost for U.S. pension plans | $ | 0.6 |  |  | $ | 0.6 |  |
| Increase to the pension benefit obligations for U.S. pension plans | n/a |  |  | 13.0 |  |

[0001069202-16-000014:mdna:200]
Should actual results differ from our estimates and assumptions, revisions to the benefit plan liabilities and the related expenses would be required.  Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on our pension benefits.

[0001069202-16-000014:mdna:201]
Derivative Accounting

[0001069202-16-000014:mdna:202]
We use futures contracts and fixed forward contracts to mitigate our exposure to volatility in commodity prices in the ordinary course of business.  Fluctuations in metal commodity prices impact the value of the derivative instruments that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases and conversely, when commodity prices fall, the fair value of our futures contracts decreases.  We are required to prepare and maintain contemporaneous documentation for futures contracts that are formally designated as cash flow hedges.  Our failure to comply with the strict documentation requirements could result in the de-designation of cash flow hedges, which may significantly impact our consolidated financial statements.  Refer to "Market Risk" above and to Note 8 in the Notes to the Consolidated Financial Statements for more information on our derivatives.

[0001069202-16-000014:mdna:203]
Goodwill and Intangible Assets

[0001069202-16-000014:mdna:204]
Goodwill is calculated as the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  We assign goodwill to the reporting units that benefit from the synergies of our acquisitions.  If we reorganize our management structure, the related goodwill is allocated to the affected reporting units based upon the relative fair values of those reporting units.  Assets and liabilities, including deferred income taxes, are generally directly assigned to the reporting units.  However, certain assets and liabilities, including intellectual property assets, information technology assets and pension, self-insurance and environmental liabilities, are centrally managed and are not allocated to the segments in the normal course of our financial reporting process, and therefore must be assigned to the reporting units based upon appropriate methods.  Reporting units that we test are generally equivalent to our business segments, or in some cases one level below.  Components that are determined to be reporting units are aggregated when those reporting units share similar economic characteristics.  We review our reporting unit structure each year as part of our annual goodwill impairment testing.

[0001069202-16-000014:mdna:205]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-16-000014:mdna:206]
For those reporting units which require the two-step quantitative goodwill impairment test, we estimate reporting unit fair values using the discounted cash flow approach or the market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. Refer to Note 4 of the Notes to the Consolidated Financial Statements for further details.

[0001069202-16-000014:mdna:207]
We review our indefinite-lived intangible assets for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets.

[0001069202-16-000014:mdna:208]
We also periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.

[0001069202-16-000014:mdna:209]
Refer to Note 4 of the Notes to the Consolidated Financial Statements for more information on our goodwill and intangible assets.

[0001069202-16-000014:mdna:210]
Recent Accounting Pronouncements

[0001069202-16-000014:mdna:211]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001069202-16-000014:mdna:212]
In January 2015, the FASB issued ASU No. 2015-01, Income Statement - Extraordinary and Unusual Items (Subtopic 225-20): Simplifying Income Statement Presentation by Eliminating the Concept of Extraordinary Items. ASU No. 2015-01 eliminates the concept of an extraordinary item from GAAP. As a result, an entity will no longer be required to separately present an extraordinary item on its statement of operations, net of tax, after income from continuing operations or to disclose income taxes and net income per share data applicable to an extraordinary item. However, ASU No. 2015-01 will still retain the presentation and disclosure guidance for items that are unusual in nature and occur infrequently. ASU No. 2015-01 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period, although early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements, absent any material transactions in future periods that would have qualified for extraordinary item presentation under the prior guidance.

[0001069202-16-000014:mdna:213]
In February 2015, the FASB issued ASU 2015-02, Consolidation: Amendments to the Consolidation Analysis, or ASU 2015-02, which amends the criteria for determining which entities are considered variable interest entities (“VIEs”), amends the criteria for determining if a service provider possesses a variable interest in a VIE and ends the deferral granted to investment companies for application of the VIE consolidation model. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015 and early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements.

[0001069202-16-000014:mdna:214]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): which simplifies the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015, and early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements.

[0001069202-16-000014:mdna:215]
In November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes (Topic 740) that simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. The guidance may be adopted prospectively or retrospectively and early adoption is permitted. We have chosen early adoption of this standard and have adopted the standard retrospectively.  Refer to Note 9 of the Notes to the Consolidated Financial Statements for details of the impact of adoption of this standard.
