# LII 8-K — 0001193125-16-453117 filed 2016-02-08

## item codes, every 8-K on or before 2016-02-16

- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2016-02-16

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-453117:8k_2_02:1]
EX-99.1
2
d124230dex991.htm
EX-99.1

[0001193125-16-453117:8k_2_02:2]
EX-99.1

[0001193125-16-453117:8k_2_02:3]
Exhibit 99.1

[0001193125-16-453117:8k_2_02:4]
Lennox International Reports Fourth Quarter and Full Year 2015 Results

[0001193125-16-453117:8k_2_02:5]
|  | • |  | Fourth quarter and full year revenue both up 3%; up 7% at constant currency |

[0001193125-16-453117:8k_2_02:6]
|  | • |  | 4Q15 adjusted EPS from continuing operations of $1.11; GAAP EPS from continuing operations of $0.25, including previously announced non-cash impairment charges in the company’s refrigerated display case business |

[0001193125-16-453117:8k_2_02:7]
|  | • |  | 2015 adjusted EPS from continuing operations of $5.14 and GAAP EPS from continuing operations of $4.11 |

[0001193125-16-453117:8k_2_02:8]
|  | • |  | Record cash from operations of $331 million and free cash flow of $261 million in 2015 |

[0001193125-16-453117:8k_2_02:9]
|  | • |  | Reiterate 2016 revenue growth guidance of 4-8% at constant currency and EPS from continuing operations guidance of $6.10-$6.60 |

[0001193125-16-453117:8k_2_02:10]
DALLAS, February 8, 2016 – Lennox International Inc. (NYSE: LII) today reported fourth quarter and full year 2015 results.

[0001193125-16-453117:8k_2_02:11]
For the fourth quarter, revenue was $834 million, up 3% from the prior-year quarter. At constant currency, revenue was up 7%. Total segment profit margin was
a fourth-quarter record 9.7%, up 30 basis points from the prior-year quarter. Diluted earnings per share from continuing operations on an adjusted basis was a fourth-quarter record $1.11, up 9% from $1.02 in the prior-year quarter. On a GAAP basis,
diluted earnings per share from continuing operations was $0.25, compared to $1.00 in the prior-year quarter, including previously announced non-cash impairment charges in the company’s Kysor/Warren refrigerated display case business.

[0001193125-16-453117:8k_2_02:12]
For the full year, revenue was $3.5 billion, up 3%. At constant currency, revenue was up 7%. Total segment profit margin was a record 10.9%, up 80 basis
points from the prior year. Diluted earnings per share from continuing operations on an adjusted basis was a record $5.14 compared to $4.38 in the prior year. On a GAAP basis, diluted earnings per share from continuing operations was $4.11 compared
to $4.28 in the prior year.

[0001193125-16-453117:8k_2_02:13]
“2015 was a year of strong growth for Lennox International, led by our Residential business with revenue up 9% at
constant currency and segment profit up 18%,” said Chairman and CEO Todd Bluedorn. “Our Residential and Commercial businesses set new records for revenue, margin and profit for the year. In Refrigeration, we saw strong growth and margin
expansion in the second half of the year, and momentum continues.

[0001193125-16-453117:8k_2_02:14]
“In the fourth quarter, Residential volume and mix were negatively impacted by record warm weather in the
U.S. Residential revenue was up 8% over the prior-year quarter at constant currency. Residential profit was flat, and margin was down due to negative Canadian foreign exchange, lower factory absorption than a year ago, and unfavorable mix –
driven by a lower mix of furnace products and replacement business, and a higher mix of residential national accounts and new construction. In our Commercial business, we set new fourth-quarter records for revenue and profit. Commercial revenue was
up 7% at constant currency, and margin expanded 70 basis points to 15.3%. In Refrigeration, revenue was up 3% at constant currency, and margin expanded 180 basis points to 8.8%.

[0001193125-16-453117:8k_2_02:15]
“Looking ahead at 2016 overall, Lennox International is well positioned for another year of strong growth and profitability. The company reiterates its
guidance for revenue growth of 4-8% at constant currency and EPS from continuing operations of $6.10-$6.60. With a strong balance sheet and cash generation, the company will continue to invest in the business to drive organic growth, raise the
dividend with earnings growth, and repurchase stock.”

[0001193125-16-453117:8k_2_02:16]
FOURTH QUARTER 2015 FINANCIAL HIGHLIGHTS

[0001193125-16-453117:8k_2_02:17]
Revenue: Revenue for the fourth quarter was $834 million, up 3% from the prior-year quarter. At constant currency, revenue was up 7%. Volume was up and
price/mix was flat from the fourth quarter a year ago.

[0001193125-16-453117:8k_2_02:18]
Gross Profit: Gross profit in the fourth quarter was $228 million, up 1% from $225 million
in the prior-year quarter. Gross margin was 27.3% compared to 27.7% in the fourth quarter a year ago. Gross profit was positively impacted by higher volume and lower material costs, with partial offsets from unfavorable price/mix, negative foreign
exchange, lower factory absorption, and investments in distribution expansion.

[0001193125-16-453117:8k_2_02:19]
Income from Continuing Operations: For the fourth quarter, adjusted
income from continuing operations was $50 million, or $1.11 diluted earnings per share, compared to $47 million, or $1.02 diluted earnings per share, in the prior-year quarter. On a GAAP basis, fourth quarter income from continuing operations was
$11 million, or $0.25 diluted earnings per share, compared to $46 million, or $1.00 diluted earnings per share, in the prior-year quarter.

[0001193125-16-453117:8k_2_02:20]
Adjusted
income from continuing operations for the fourth quarter of 2015 excludes net after-tax charges of $39.1 million, which are derived from $32.6 million of impairment charges related to the Kysor/Warren refrigerated display case business, a $3.8
million one-time inventory write-down, and $2.7 million of other items, net.

[0001193125-16-453117:8k_2_02:21]
FULL YEAR 2015 FINANCIAL HIGHLIGHTS

[0001193125-16-453117:8k_2_02:22]
Revenue: For the full year, revenue was $3.5 billion, up 3%. At constant currency, revenue was up 7%. Volume and price/mix were up from the prior year.

[0001193125-16-453117:8k_2_02:23]
Gross Profit: Gross profit for the full year was $947 million, up 5% from $903 million in the prior year. Gross margin was 27.3%, up 50 basis
points from 26.8% in the prior year. Gross profit was positively impacted by higher volume, favorable price, lower material costs, and higher productivity, with partial offsets from negative foreign exchange, unfavorable mix, the repeal of the
carbon tax on refrigerant in Australia, lower factory absorption, and investments in distribution expansion.

[0001193125-16-453117:8k_2_02:24]
Income from Continuing Operations:
Adjusted income from continuing operations for 2015 was $234 million, or $5.14 diluted earnings per share, compared to $213 million, or $4.38 diluted earnings per share, in the prior year. On a GAAP basis, income from continuing operations for 2015
was $187 million, or $4.11 diluted earnings per share, compared to $208 million, or $4.28 diluted earnings per share, in the prior year.

[0001193125-16-453117:8k_2_02:25]
Adjusted income
from continuing operations for 2015 excludes net after-tax charges of $47.0 million, which are derived from $32.6 million of impairment charges related to the Kysor/Warren refrigerated display case business, $4.0 million in special legal contingency
charges, $3.8 million for a one-time inventory write down, and $6.6 million of other items, net.

[0001193125-16-453117:8k_2_02:26]
Free Cash Flow and Total Debt: Cash from
operations for the fourth quarter was a record $224 million, compared to $161 million in the prior-year quarter. Capital expenditures were $23 million in the fourth quarter, compared to $28 million in the prior-year quarter. Free cash flow was also
a record at approximately $202 million, compared to approximately $134 million in the prior-year quarter. For the full year, cash from operations was a record $331 million, compared to $185 million in the prior year. Capital expenditures were $70
million in 2015 compared to $87 million in 2014. Free cash flow was a record $261 million for the full year compared to $98 million in the prior year. The company paid $59 million in dividends for the year. Total debt at the end of 2015 was $744
million. Total cash and cash equivalents were $39 million ending the year.

[0001193125-16-453117:8k_2_02:27]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001193125-16-453117:8k_2_02:28]
Residential Heating and Cooling

[0001193125-16-453117:8k_2_02:29]
|  | • |  | 4Q15 revenue of $431 million, up 7% from 4Q14; up 8% at constant currency |

[0001193125-16-453117:8k_2_02:30]
|  | • |  | 4Q15 segment profit a fourth-quarter record $57 million, relatively flat with 4Q14 |

[0001193125-16-453117:8k_2_02:31]
|  | • |  | 4Q15 segment profit margin 13.2%, down 90 basis points from 4Q14 |

[0001193125-16-453117:8k_2_02:32]
|  | • |  | 2015 revenue a record $1,867 million, up 8% from 2014; up 9% at constant currency |

[0001193125-16-453117:8k_2_02:33]
|  | • |  | 2015 segment profit a record $278 million, up 18% from 2014 |

[0001193125-16-453117:8k_2_02:34]
|  | • |  | 2015 segment profit margin a record 14.9%, up 130 basis points from 2014 |

[0001193125-16-453117:8k_2_02:35]
Fourth quarter results were
positively impacted by higher volume and lower material costs, with offsets from foreign exchange, unfavorable mix, strategic investments in distribution expansion, and lower factory absorption than in the prior-year quarter, which included an
inventory prebuild to support a product efficiency regulatory transition. Full year results were positively impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from negative foreign exchange, higher
SG&A, lower factory absorption, and strategic investments in distribution expansion.

[0001193125-16-453117:8k_2_02:36]
Commercial Heating and Cooling

[0001193125-16-453117:8k_2_02:37]
|  | • |  | 4Q15 revenue a fourth-quarter record $227 million, up 2% from 4Q14; up 7% at constant currency |

[0001193125-16-453117:8k_2_02:38]
|  | • |  | 4Q15 segment profit a fourth-quarter record $35 million, up 7% from 4Q14 |

[0001193125-16-453117:8k_2_02:39]
|  | • |  | 4Q15 segment profit margin of 15.3%, up 70 basis points from 4Q14 |

[0001193125-16-453117:8k_2_02:40]
|  | • |  | 2015 revenue a record $887 million, up 1% from 2014; up 6% at constant currency |

[0001193125-16-453117:8k_2_02:41]
|  | • |  | 2015 segment profit a record $130 million, up 5% from 2014 |

[0001193125-16-453117:8k_2_02:42]
|  | • |  | 2015 segment profit margin a record 14.7%, up 60 basis points from 2014 |

[0001193125-16-453117:8k_2_02:43]
Fourth quarter results were
positively impacted by higher volume and lower material costs, with a partial offset from negative foreign exchange. Full year results were positively impacted by higher volume, favorable price, and lower material costs, with partial offsets from
negative foreign exchange, unfavorable mix, higher SG&A, and strategic investments for growth in the VRF equipment market in North America.

[0001193125-16-453117:8k_2_02:44]
Refrigeration

[0001193125-16-453117:8k_2_02:45]
|  | • |  | 4Q15 revenue of $176 million, down 5% from 4Q14; up 3% at constant currency |

[0001193125-16-453117:8k_2_02:46]
|  | • |  | 4Q15 segment profit of $15 million, up 18% from 4Q14 |

[0001193125-16-453117:8k_2_02:47]
|  | • |  | 4Q15 segment profit margin of 8.8%, up 180 basis points from 4Q14 |

[0001193125-16-453117:8k_2_02:48]
|  | • |  | 2015 revenue of $713 million, down 5% from 2014; up 3% at constant currency |

[0001193125-16-453117:8k_2_02:49]
|  | • |  | 2015 segment profit of $53 million, down 5% from 2014 |

[0001193125-16-453117:8k_2_02:50]
|  | • |  | 2015 segment profit margin of 7.4%, flat with 2014 |

[0001193125-16-453117:8k_2_02:51]
Fourth quarter results were positively impacted by lower
material costs and higher productivity, with partial offsets from negative foreign exchange, unfavorable mix, and higher SG&A. Full year results were positively impacted by higher volume, favorable price, lower material costs, and higher
productivity, with offsets from negative foreign exchange, unfavorable mix, higher SG&A, and the repeal of the carbon tax on refrigerant in Australia.

[0001193125-16-453117:8k_2_02:52]
2016 FULL-YEAR OUTLOOK

[0001193125-16-453117:8k_2_02:53]
|  | • |  | Reiterating guidance for revenue growth of 4-8% at constant currency; the company now expects a negative 1 point impact from foreign exchange for revenue growth of 3-7% at actual currency |

[0001193125-16-453117:8k_2_02:54]
|  | • |  | Reiterating adjusted and GAAP EPS from continuing operations of $6.10-$6.60 |

[0001193125-16-453117:8k_2_02:55]
|  | • |  | Reiterating an effective tax rate of 34-35% on a full-year basis |

[0001193125-16-453117:8k_2_02:56]
|  | • |  | Reiterating capital expenditures of approximately $95 million |

[0001193125-16-453117:8k_2_02:57]
|  | • |  | Reiterating plans for $200 million of stock repurchases |

[0001193125-16-453117:8k_2_02:58]
CONFERENCE CALL INFORMATION

[0001193125-16-453117:8k_2_02:59]
A conference call to discuss the company’s fourth quarter and full year 2015 results will be held this morning at 8:30 a.m. Central time. To listen, call
the conference call line at 612-332-0107 at least 10 minutes prior to the scheduled start time and use reservation number 383549. The conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com. A
replay will be available from 11:00 a.m. Central time on February 8 through February 22, 2016, by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 383549. The call also will be archived on the
company’s web site.

[0001193125-16-453117:8k_2_02:60]
About Lennox International

[0001193125-16-453117:8k_2_02:61]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York
Stock Exchange and traded under the symbol “LII”. The company’s 2016 annual meeting of stockholders is to be held on May 12, 2016, and the record date for that meeting is March 18, 2016. Additional information on Lennox
International is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-16-453117:8k_2_02:62]
Forward-Looking Statements

[0001193125-16-453117:8k_2_02:63]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-453117:8k_2_02:64]
Consolidated Statements of Operations

[0001193125-16-453117:8k_2_02:65]
| (Amounts in millions, except per share data) |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 834.1 |  |  | $ | 812.8 |  |  | $ | 3,467.4 |  |  | $ | 3,367.4 |  |
| Cost of goods sold |  |  | 606.5 |  |  |  | 587.4 |  |  |  | 2,520.0 |  |  |  | 2,464.1 |  |
| Gross profit |  |  | 227.6 |  |  |  | 225.4 |  |  |  | 947.4 |  |  |  | 903.3 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 150.6 |  |  |  | 148.2 |  |  |  | 580.5 |  |  |  | 573.7 |  |
| Losses and other expenses, net |  |  | 6.8 |  |  |  | 3.3 |  |  |  | 21.7 |  |  |  | 6.8 |  |
| Restructuring charges |  |  | 1.4 |  |  |  | 0.6 |  |  |  | 3.2 |  |  |  | 1.9 |  |
| Goodwill impairment |  |  | 5.5 |  |  |  | — |  |  |  | 5.5 |  |  |  | — |  |
| Asset impairment |  |  | 44.5 |  |  |  | — |  |  |  | 44.5 |  |  |  | — |  |
| Income from equity method investments |  |  | (1.6 | ) |  |  | (1.8 | ) |  |  | (13.4 | ) |  |  | (13.8 | ) |
| Operational income from continuing operations |  |  | 20.4 |  |  |  | 75.1 |  |  |  | 305.4 |  |  |  | 334.7 |  |
| Interest expense, net |  |  | 5.8 |  |  |  | 6.2 |  |  |  | 23.6 |  |  |  | 17.2 |  |
| Other expense (income), net |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.8 | ) |  |  | (0.1 | ) |
| Income from continuing operations before income taxes |  |  | 14.7 |  |  |  | 69.0 |  |  |  | 282.6 |  |  |  | 317.6 |  |
| Provision for income taxes |  |  | 3.5 |  |  |  | 22.9 |  |  |  | 95.4 |  |  |  | 109.5 |  |
| Income from continuing operations |  |  | 11.2 |  |  |  | 46.1 |  |  |  | 187.2 |  |  |  | 208.1 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from discontinued operations before income taxes |  |  | — |  |  |  | (2.4 | ) |  |  | (1.0 | ) |  |  | (3.7 | ) |
| Provision for (benefit from) income taxes |  |  | — |  |  |  | (0.9 | ) |  |  | (0.4 | ) |  |  | (1.4 | ) |
| Income (loss) from discontinued operations |  |  | — |  |  |  | (1.5 | ) |  |  | (0.6 | ) |  |  | (2.3 | ) |
| Net income |  | $ | 11.2 |  |  | $ | 44.6 |  |  | $ | 186.6 |  |  | $ | 205.8 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.25 |  |  | $ | 1.01 |  |  | $ | 4.17 |  |  | $ | 4.35 |  |
| Income (loss) from discontinued operations |  |  | — |  |  |  | (0.03 | ) |  |  | (0.01 | ) |  |  | (0.05 | ) |
| Net income |  | $ | 0.25 |  |  | $ | 0.98 |  |  | $ | 4.16 |  |  | $ | 4.30 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.25 |  |  | $ | 1.00 |  |  | $ | 4.11 |  |  | $ | 4.28 |  |
| Income (loss) from discontinued operations |  |  | — |  |  |  | (0.04 | ) |  |  | (0.02 | ) |  |  | (0.05 | ) |
| Net income |  | $ | 0.25 |  |  | $ | 0.96 |  |  | $ | 4.09 |  |  | $ | 4.23 |  |
| Weighted Average Number of Shares Outstanding—Basic |  |  | 44.9 |  |  |  | 45.5 |  |  |  | 44.9 |  |  |  | 47.9 |  |
| Weighted Average Number of Shares Outstanding—Diluted |  |  | 45.5 |  |  |  | 46.2 |  |  |  | 45.6 |  |  |  | 48.6 |  |
| Cash dividends declared per share |  | $ | 0.36 |  |  | $ | 0.30 |  |  | $ | 1.38 |  |  | $ | 1.14 |  |

[0001193125-16-453117:8k_2_02:66]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES Segment Net Sales and Profit (Loss) |

[0001193125-16-453117:8k_2_02:67]
| (Amounts in millions) |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 431.2 |  |  | $ | 404.0 |  |  | $ | 1,866.9 |  |  | $ | 1,736.5 |  |
| Commercial Heating & Cooling |  |  | 226.9 |  |  |  | 222.9 |  |  |  | 887.2 |  |  |  | 878.5 |  |
| Refrigeration |  |  | 176.0 |  |  |  | 185.9 |  |  |  | 713.3 |  |  |  | 752.4 |  |
|  |  | $ | 834.1 |  |  | $ | 812.8 |  |  | $ | 3,467.4 |  |  | $ | 3,367.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 57.1 |  |  | $ | 57.0 |  |  | $ | 278.4 |  |  | $ | 235.8 |  |
| Commercial Heating & Cooling |  |  | 34.8 |  |  |  | 32.6 |  |  |  | 130.4 |  |  |  | 124.0 |  |
| Refrigeration |  |  | 15.4 |  |  |  | 13.1 |  |  |  | 52.9 |  |  |  | 55.4 |  |
| Corporate and other |  |  | (26.5 | ) |  |  | (26.4 | ) |  |  | (84.1 | ) |  |  | (74.3 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 80.8 |  |  |  | 76.3 |  |  |  | 377.6 |  |  |  | 340.9 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (1.5 | ) |  |  | (1.4 | ) |  |  | (2.2 | ) |  |  | (1.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 4.9 |  |  |  | 2.0 |  |  |  | 15.6 |  |  |  | 4.7 |  |
| Restructuring charges |  |  | 1.4 |  |  |  | 0.6 |  |  |  | 3.2 |  |  |  | 1.9 |  |
| Interest expense, net |  |  | 5.8 |  |  |  | 6.2 |  |  |  | 23.6 |  |  |  | 17.2 |  |
| Goodwill impairment |  |  | 5.5 |  |  |  | — |  |  |  | 5.5 |  |  |  | — |  |
| Asset impairment |  |  | 44.5 |  |  |  | — |  |  |  | 44.5 |  |  |  | — |  |
| One time inventory write down |  |  | 5.6 |  |  |  | — |  |  |  | 5.6 |  |  |  | 1.0 |  |
| Other expense (income), net |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.8 | ) |  |  | (0.1 | ) |
| Income from continuing operations before income taxes |  | $ | 14.7 |  |  | $ | 69.0 |  |  | $ | 282.6 |  |  | $ | 317.6 |  |

[0001193125-16-453117:8k_2_02:68]
| (1) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-16-453117:8k_2_02:69]
|  | • |  | Special product quality adjustments; |

[0001193125-16-453117:8k_2_02:70]
|  | • |  | The following items in Losses and other expenses, net: |

[0001193125-16-453117:8k_2_02:71]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-16-453117:8k_2_02:72]
|  | • |  | Special legal contingency charges, |

[0001193125-16-453117:8k_2_02:73]
|  | • |  | Asbestos-related litigation, |

[0001193125-16-453117:8k_2_02:74]
|  | • |  | Environmental liabilities, and |

[0001193125-16-453117:8k_2_02:75]
|  | • |  | Other items, net; |

[0001193125-16-453117:8k_2_02:76]
|  | • |  | Restructuring charges; |

[0001193125-16-453117:8k_2_02:77]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments; |

[0001193125-16-453117:8k_2_02:78]
|  | • |  | Interest expense, net; |

[0001193125-16-453117:8k_2_02:79]
|  | • |  | One time inventory write down; and |

[0001193125-16-453117:8k_2_02:80]
|  | • |  | Other expense, net. |

[0001193125-16-453117:8k_2_02:81]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-453117:8k_2_02:82]
Consolidated Balance Sheets

[0001193125-16-453117:8k_2_02:83]
| (Amounts in millions, except shares and par values) |  | As of December 31,2015 |  |  | As of December 31,2014 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 38.9 |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net of allowances of $6.3 and $7.9 in 2015 and 2014, respectively |  |  | 422.8 |  |  |  | 421.4 |  |
| Inventories, net |  |  | 418.8 |  |  |  | 463.3 |  |
| Other assets |  |  | 57.7 |  |  |  | 59.3 |  |
| Total current assets |  |  | 938.2 |  |  |  | 981.5 |  |
| Property, plant and equipment, net |  |  | 339.6 |  |  |  | 358.6 |  |
| Goodwill |  |  | 195.1 |  |  |  | 209.4 |  |
| Deferred income taxes |  |  | 145.7 |  |  |  | 130.0 |  |
| Other assets, net |  |  | 61.6 |  |  |  | 84.8 |  |
| Total assets |  | $ | 1,680.2 |  |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 204.1 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt |  |  | 31.2 |  |  |  | 24.0 |  |
| Accounts payable |  |  | 320.1 |  |  |  | 324.3 |  |
| Accrued expenses |  |  | 242.6 |  |  |  | 239.0 |  |
| Income taxes payable |  |  | 26.0 |  |  |  | 13.4 |  |
| Total current liabilities |  |  | 824.0 |  |  |  | 827.3 |  |
| Long-term debt |  |  | 508.6 |  |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions |  |  | 4.1 |  |  |  | 4.5 |  |
| Pensions |  |  | 120.8 |  |  |  | 129.9 |  |
| Other liabilities |  |  | 121.1 |  |  |  | 118.6 |  |
| Total liabilities |  |  | 1,578.6 |  |  |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,002.4 |  |  |  | 824.9 |  |
| Retained earnings |  |  | 1,146.7 |  |  |  | 1,022.1 |  |
| Accumulated other comprehensive loss |  |  | (204.7 | ) |  |  | (153.5 | ) |
| Treasury stock, at cost, 42,491,910 shares and 42,535,126 shares for 2015 and 2014, respectively |  |  | (1,844.1 | ) |  |  | (1,686.0 | ) |
| Noncontrolling interests |  |  | 0.4 |  |  |  | 0.6 |  |
| Total stockholders’ equity |  |  | 101.6 |  |  |  | 9.0 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,680.2 |  |  | $ | 1,764.3 |  |

[0001193125-16-453117:8k_2_02:84]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-453117:8k_2_02:85]
Consolidated Statements of Cash Flow

[0001193125-16-453117:8k_2_02:86]
| (Amounts in millions) |  | For the Years Ended December 31, |  |
|  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 186.6 |  |  | $ | 205.8 |  |
| Net loss from discontinued operations |  |  | 0.6 |  |  |  | 2.3 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (13.4 | ) |  |  | (13.8 | ) |
| Dividends from affiliates |  |  | 11.0 |  |  |  | 9.1 |  |
| Restructuring expenses, net of cash paid |  |  | — |  |  |  | 0.2 |  |
| Goodwill impairment |  |  | 5.5 |  |  |  | — |  |
| Impairment of assets |  |  | 44.5 |  |  |  | — |  |
| Provision for bad debts |  |  | 2.8 |  |  |  | 2.6 |  |
| Unrealized losses on derivative contracts |  |  | 0.8 |  |  |  | 0.3 |  |
| Stock-based compensation expense |  |  | 26.6 |  |  |  | 23.3 |  |
| Depreciation and amortization |  |  | 62.8 |  |  |  | 60.8 |  |
| Deferred income taxes |  |  | (21.3 | ) |  |  | 6.1 |  |
| Pension costs in excess of (less than) contributions |  |  | 6.7 |  |  |  | (8.0 | ) |
| Other items, net |  |  | 1.0 |  |  |  | 0.1 |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (23.5 | ) |  |  | (32.6 | ) |
| Inventories |  |  | 28.8 |  |  |  | (96.7 | ) |
| Other current assets |  |  | (1.6 | ) |  |  | (8.3 | ) |
| Accounts payable |  |  | (2.9 | ) |  |  | 46.1 |  |
| Accrued expenses |  |  | 4.2 |  |  |  | 6.7 |  |
| Income taxes payable and receivable |  |  | 10.9 |  |  |  | (15.9 | ) |
| Other, net |  |  | 1.7 |  |  |  | (1.0 | ) |
| Net cash used in discontinued operations |  |  | (0.6 | ) |  |  | (2.3 | ) |
| Net cash provided by operating activities |  |  | 331.2 |  |  |  | 184.8 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 1.1 |  |
| Purchases of property, plant and equipment |  |  | (69.9 | ) |  |  | (88.4 | ) |
| Net proceeds from sale of businesses |  |  | — |  |  |  | — |  |
| Net cash used in investing activities |  |  | (69.8 | ) |  |  | (87.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (1.7 | ) |  |  | 1.5 |  |
| Asset securitization borrowings |  |  | 40.0 |  |  |  | 100.0 |  |
| Asset securitization payments |  |  | (60.0 | ) |  |  | (40.0 | ) |
| Term loan borrowings from credit facility |  |  | — |  |  |  | 300.0 |  |
| Long-term debt payments |  |  | (24.0 | ) |  |  | (2.3 | ) |
| Borrowings from credit facility |  |  | 1,671.0 |  |  |  | 2,073.5 |  |
| Payments on credit facility |  |  | (1,807.5 | ) |  |  | (1,908.5 | ) |
| Payments of deferred financing costs |  |  | — |  |  |  | (2.2 | ) |
| Additional investment in subsidiary |  |  | — |  |  |  | — |  |
| Proceeds from employee stock purchases |  |  | 2.4 |  |  |  | 2.0 |  |
| Repurchases of common stock |  |  | — |  |  |  | (550.3 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (32.0 | ) |  |  | (22.4 | ) |
| Excess tax benefits related to share-based payments |  |  | 22.4 |  |  |  | 11.8 |  |
| Cash dividends paid |  |  | (59.3 | ) |  |  | (52.6 | ) |
| Net cash used in financing activities |  |  | (248.7 | ) |  |  | (89.5 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 12.7 |  |  |  | 8.0 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (11.3 | ) |  |  | (8.5 | ) |
| Cash and cash equivalents, beginning of year |  |  | 37.5 |  |  |  | 38.0 |  |
| Cash and cash equivalents, end of year |  | $ | 38.9 |  |  | $ | 37.5 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the year for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 23.7 |  |  | $ | 17.6 |  |
| Income taxes (net of refunds) |  | $ | 83.2 |  |  | $ | 105.3 |  |

[0001193125-16-453117:8k_2_02:87]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-16-453117:8k_2_02:88]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-16-453117:8k_2_02:89]
(Unaudited, in millions, except per share and ratio data)

[0001193125-16-453117:8k_2_02:90]
Use of Non-GAAP Financial Measures

[0001193125-16-453117:8k_2_02:91]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide
information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating
performance.

[0001193125-16-453117:8k_2_02:92]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-16-453117:8k_2_02:93]
|  |  | For the Three MonthsEnded December 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Income from continuing operations, a GAAP measure |  | $ | 11.2 |  |  | $ | 46.1 |  |  | $ | 187.2 |  |  | $ | 208.1 |  |
| Restructuring charges, after tax |  |  | 1.0 |  |  |  | 0.4 |  |  |  | 2.3 |  |  |  | 1.8 |  |
| Asset impairment, after tax |  |  | 29.0 |  |  |  | — |  |  |  | 29.0 |  |  |  | — |  |
| Goodwill impairment, after tax |  |  | 3.6 |  |  |  | — |  |  |  | 3.6 |  |  |  | — |  |
| Special product quality adjustments, after tax (b) |  |  | (0.9 | ) |  |  | (0.8 | ) |  |  | (1.3 | ) |  |  | (0.9 | ) |
| Special legal contingency charges, after tax (a) |  |  | 0.6 |  |  |  | 0.2 |  |  |  | 4.0 |  |  |  | 0.6 |  |
| Asbestos-related litigation, after tax (a) |  |  | 1.3 |  |  |  | — |  |  |  | 1.9 |  |  |  | 0.6 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | (0.2 | ) |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 0.4 |  |
| One time inventory write down, after tax (b) |  |  | 3.8 |  |  |  | — |  |  |  | 3.8 |  |  |  | 0.8 |  |
| Environmental liabilities, after tax (a) |  |  | 0.3 |  |  |  | 0.7 |  |  |  | 1.0 |  |  |  | 1.2 |  |
| Contractor tax payments, after tax (a) |  |  | 0.2 |  |  |  | — |  |  |  | 1.7 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |  |  | 0.5 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 50.3 |  |  | $ | 46.9 |  |  | $ | 234.2 |  |  | $ | 213.1 |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 0.25 |  |  | $ | 1.00 |  |  | $ | 4.11 |  |  | $ | 4.28 |  |
| Restructuring charges, after tax |  |  | 0.02 |  |  |  | 0.01 |  |  |  | 0.05 |  |  |  | 0.03 |  |
| Asset impairment, after tax |  |  | 0.64 |  |  |  | — |  |  |  | 0.64 |  |  |  | — |  |
| Goodwill impairment, after tax |  |  | 0.08 |  |  |  | — |  |  |  | 0.08 |  |  |  | — |  |
| Special product quality adjustments, after tax (b) |  |  | (0.02 | ) |  |  | (0.02 | ) |  |  | (0.03 | ) |  |  | (0.02 | ) |
| Special legal contingency charges, after tax (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.09 |  |  |  | 0.01 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.03 |  |  |  | — |  |  |  | 0.04 |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | — |  |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.01 |  |
| One time inventory write down, after tax (b) |  |  | 0.08 |  |  |  | — |  |  |  | 0.08 |  |  |  | 0.02 |  |
| Environmental liabilities, after tax (a) |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.03 |  |
| Contractor tax payments, after tax (a) |  |  | — |  |  |  | — |  |  |  | 0.04 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  | $ | 1.11 |  |  | $ | 1.02 |  |  | $ | 5.14 |  |  | $ | 4.38 |  |

[0001193125-16-453117:8k_2_02:94]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-16-453117:8k_2_02:95]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-16-453117:8k_2_02:96]
|  |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.6 |  |  | $ | 0.1 |  |  | $ | 1.9 |  |  | $ | 0.8 |  |
| Foreign currency exchange losses (a) |  |  | 0.8 |  |  |  | 1.5 |  |  |  | 3.6 |  |  |  | 1.6 |  |
| Gain on disposal of fixed assets (a) |  |  | 0.5 |  |  |  | (0.3 | ) |  |  | 0.6 |  |  |  | (0.3 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | (0.2 | ) |  |  | 0.5 |  |  |  | 0.6 |  |  |  | 0.6 |  |
| Special legal contingency charges (b) |  |  | 1.9 |  |  |  | 0.3 |  |  |  | 7.4 |  |  |  | 0.9 |  |
| Asbestos-related litigation (b) |  |  | 2.0 |  |  |  | — |  |  |  | 3.0 |  |  |  | 0.9 |  |
| Environmental liabilities (b) |  |  | 0.3 |  |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 2.0 |  |
| Contractor tax payments (b) |  |  | 0.2 |  |  |  | — |  |  |  | 2.6 |  |  |  | — |  |
| Acquisition costs (b) |  |  | 0.7 |  |  |  | — |  |  |  | 1.0 |  |  |  | — |  |
| Other items, net (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 6.8 |  |  | $ | 3.3 |  |  | $ | 21.7 |  |  | $ | 6.8 |  |

[0001193125-16-453117:8k_2_02:97]
| (a) | Included in segment profit (loss) and Adjusted income from continuing operations |

[0001193125-16-453117:8k_2_02:98]
| (b) | Excluded from segment profit (loss) and Adjusted income from continuing operations |

[0001193125-16-453117:8k_2_02:99]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations—Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations—Diluted, a GAAP measure

[0001193125-16-453117:8k_2_02:100]
|  |  | For the YearEndedDecember 31,2016ESTIMATED |  |
| Adjusted income per share from continuing operations—diluted, a Non-GAAP measure |  | $ | 6.10-$6.60 |  |
| Restructuring and other items |  |  | 0.00 |  |
| Income per share from continuing operations—diluted, a GAAP measure |  | $ | 6.10-$6.60 |  |

[0001193125-16-453117:8k_2_02:101]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to
Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-16-453117:8k_2_02:102]
|  |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 224.3 |  |  | $ | 161.3 |  |  | $ | 331.2 |  |  | $ | 184.8 |  |
| Purchases of property, plant and equipment |  |  | (22.9 | ) |  |  | (28.5 | ) |  |  | (69.9 | ) |  |  | (88.4 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 0.9 |  |  |  | 0.1 |  |  |  | 1.1 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 201.5 |  |  | $ | 133.7 |  |  | $ | 261.4 |  |  | $ | 97.5 |  |

[0001193125-16-453117:8k_2_02:103]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelve Months toDecember 31,2015 |  |
| Adjusted EBIT (a) |  | $ | 377.6 |  |
| Depreciation and amortization expense (b) |  |  | 62.8 |  |
| EBITDA (a + b) |  | $ | 440.4 |  |
| Total debt at December 31, 2015 (c) |  | $ | 743.9 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 1.7 |  |

[0001193125-16-453117:8k_2_02:104]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing
Operations Before Income Taxes, a GAAP measure (dollars in millions)

[0001193125-16-453117:8k_2_02:105]
|  |  | TrailingTwelve Months toDecember 31,2015 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 377.6 |  |
| Special product quality adjustments |  |  | (2.2 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 15.6 |  |
| Restructuring charges |  |  | 3.2 |  |
| Interest expense, net |  |  | 23.6 |  |
| One time inventory write down |  |  | 5.6 |  |
| Goodwill impairment |  |  | 5.5 |  |
| Asset impairment |  |  | 44.5 |  |
| Other expenses, net |  |  | (0.8 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 282.6 |  |
