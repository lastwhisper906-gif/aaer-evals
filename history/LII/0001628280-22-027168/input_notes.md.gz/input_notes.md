# LII notes — 0001628280-22-027168


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-22-027168:notes:1]
[same as prior period, unchanged from 0001628280-22-019665:notes:1]

[0001628280-22-027168:notes:2]
[same as prior period, unchanged from 0001628280-22-019665:notes:2]

[0001628280-22-027168:notes:3]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2022, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2022 and 2021, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2022 and 2021 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2021.

[0001628280-22-027168:notes:4]
[same as prior period, unchanged from 0001628280-22-019665:notes:4]

[0001628280-22-027168:notes:5]
[same as prior period, unchanged from 0001628280-22-019665:notes:5]

[0001628280-22-027168:notes:6]
[same as prior period, unchanged from 0001628280-22-019665:notes:6]

[0001628280-22-027168:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001628280-22-027168:notes:8]
[same as prior period, unchanged from 0001628280-22-019665:notes:8]

[0001628280-22-027168:notes:9]
[same as prior period, unchanged from 0001628280-22-019665:notes:9]

[0001628280-22-027168:notes:10]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations since 2020. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows. 
Executive Leadership TransitionOn March 23, 2022, the Board of Directors appointed Alok Maskara as Chief Executive Officer ("CEO") effective May 9, 2022.  Mr. Maskara succeeded Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and served as interim CEO until Mr. Maskara assumed the role on May 9, 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-22-027168:notes:11]
[same as prior period, unchanged from 0001628280-22-019665:notes:11]

[0001628280-22-027168:notes:12]
[same as prior period, unchanged from 0001628280-22-019665:notes:12]

[0001628280-22-027168:notes:13]
[same as prior period, unchanged from 0001628280-22-019665:notes:13]

[0001628280-22-027168:notes:14]
[same as prior period, unchanged from 0001628280-22-019665:notes:14]

[0001628280-22-027168:notes:15]
[same as prior period, unchanged from 0001628280-22-019665:notes:15]

[0001628280-22-027168:notes:16]
[same as prior period, unchanged from 0001628280-22-019665:notes:16]

[0001628280-22-027168:notes:17]
[same as prior period, unchanged from 0001628280-22-019665:notes:17]

[0001628280-22-027168:notes:18]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 835.3 |  |  | $ | 711.0 |  |  | $ | 2,494.9 |  |  | $ | 2,155.3 |  |
| Commercial Heating & Cooling | 252.9 |  |  | 211.5 |  |  | 660.2 |  |  | 663.4 |  |
| Refrigeration | 156.7 |  |  | 137.4 |  |  | 469.5 |  |  | 410.6 |  |
|  | $ | 1,244.9 |  |  | $ | 1,059.9 |  |  | $ | 3,624.6 |  |  | $ | 3,229.3 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 153.8 |  |  | $ | 144.0 |  |  | $ | 477.7 |  |  | $ | 430.1 |  |
| Commercial Heating & Cooling | 29.6 |  |  | 22.6 |  |  | 53.1 |  |  | 95.3 |  |
| Refrigeration | 22.4 |  |  | 14.5 |  |  | 60.0 |  |  | 35.8 |  |
| Corporate and other | (16.5) |  |  | (16.3) |  |  | (57.1) |  |  | (59.2) |  |
| Total segment profit | 189.3 |  |  | 164.8 |  |  | 533.7 |  |  | 502.0 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special product quality adjustments | — |  |  | (1.1) |  |  | — |  |  | (1.0) |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 3.3 |  |  | 2.9 |  |  | 7.9 |  |  | 8.7 |  |
| Restructuring charges | 0.2 |  |  | 0.3 |  |  | 1.2 |  |  | 1.6 |  |
| Operating income | $ | 185.8 |  |  | $ | 162.7 |  |  | $ | 524.6 |  |  | $ | 492.7 |  |

[0001628280-22-027168:notes:19]
[same as prior period, unchanged from 0001628280-22-019665:notes:19]

[0001628280-22-027168:notes:20]
[same as prior period, unchanged from 0001628280-22-019665:notes:20]

[0001628280-22-027168:notes:21]
[same as prior period, unchanged from 0001628280-22-019665:notes:21]

[0001628280-22-027168:notes:22]
▪Environmental liabilities and special litigation charges,

[0001628280-22-027168:notes:23]
[same as prior period, unchanged from 0001628280-22-019665:notes:23]

[0001628280-22-027168:notes:24]
[same as prior period, unchanged from 0001628280-22-019665:notes:24]

[0001628280-22-027168:notes:25]
[same as prior period, unchanged from 0001628280-22-019665:notes:25]

[0001628280-22-027168:notes:26]
[same as prior period, unchanged from 0001628280-22-019665:notes:26]


## us-gaap:EarningsPerShareTextBlock

[0001628280-22-027168:notes:27]
[same as prior period, unchanged from 0001628280-22-019665:notes:27]

[0001628280-22-027168:notes:28]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income | $ | 141.9 |  |  | $ | 126.3 |  |  | $ | 402.7 |  |  | $ | 380.4 |  |
| Exclude: Income from discontinued operations | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Income from continuing operations | $ | 141.9 |  |  | $ | 126.3 |  |  | $ | 402.7 |  |  | $ | 380.5 |  |
| Weighted-average shares outstanding – basic | 35.4 |  |  | 36.8 |  |  | 35.8 |  |  | 37.4 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 0.3 |  |
| Weighted-average shares outstanding – diluted | 35.5 |  |  | 37.0 |  |  | 35.9 |  |  | 37.7 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 4.00 |  |  | $ | 3.43 |  |  | $ | 11.25 |  |  | $ | 10.17 |  |
| Income from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 4.00 |  |  | $ | 3.43 |  |  | $ | 11.25 |  |  | $ | 10.17 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.99 |  |  | $ | 3.41 |  |  | $ | 11.22 |  |  | $ | 10.10 |  |
| Income from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 3.99 |  |  | $ | 3.41 |  |  | $ | 11.22 |  |  | $ | 10.10 |  |

[0001628280-22-027168:notes:29]
[same as prior period, unchanged from 0001628280-22-019665:notes:29]

[0001628280-22-027168:notes:30]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Weighted-average number of shares | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |


## us-gaap:LesseeLeasesPolicyTextBlock

[0001628280-22-027168:notes:31]
Leases

[0001628280-22-027168:notes:32]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001628280-22-027168:notes:33]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.  
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.We lease certain real and personal property under non-cancelable operating leases. Approximately 79% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-22-027168:notes:34]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001628280-22-027168:notes:35]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001628280-22-027168:notes:36]
We lease certain real and personal property under non-cancelable operating leases. Approximately 79% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001628280-22-027168:notes:37]
Product Warranties and Product Related Contingencies

[0001628280-22-027168:notes:38]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001628280-22-027168:notes:39]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-22-027168:notes:40]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Accrued expenses | $ | 39.8 |  |  | $ | 37.2 |  |
| Other liabilities | 110.4 |  |  | 97.0 |  |
| Total warranty liability | $ | 150.2 |  |  | $ | 134.2 |  |

[0001628280-22-027168:notes:41]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2022 were as follows (in millions):

[0001628280-22-027168:notes:42]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Warranty claims paid | (27.1) |  |
| Changes resulting from issuance of new warranties | 41.8 |  |
| Changes in estimates associated with pre-existing liabilities | 2.7 |  |
| Changes in foreign currency translation rates and other | (1.4) |  |
| Total warranty liability as of September 30, 2022 | $ | 150.2 |  |

[0001628280-22-027168:notes:43]
Litigation

[0001628280-22-027168:notes:44]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-22-027168:notes:45]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-22-027168:notes:46]
In July 2021, our Board of Directors authorized an additional $1.0 billion, for a total of $4.0 billion, to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"). Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of September 30, 2022, $546 million was available for repurchase under the Share Repurchase Plans.

[0001628280-22-027168:notes:47]
[same as prior period, unchanged from 0001628280-22-019665:notes:46]

[0001628280-22-027168:notes:48]
[same as prior period, unchanged from 0001628280-22-019665:notes:47]

[0001628280-22-027168:notes:49]
We also repurchased shares for $5.5 million during the nine months ended September 30, 2022 from employees who tendered their shares to satisfy minimum tax withholding obligations upon the vesting and exercise of stock-based compensation awards.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001628280-22-027168:notes:50]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.

[0001628280-22-027168:notes:51]
|  | For the Three Months Ended September 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 779.8 |  |  | $ | 232.5 |  |  | $ | 99.4 |  |  | $ | 1,111.7 |  |
| Canada | 55.5 |  |  | 20.3 |  |  | — |  |  | 75.8 |  |
| Other international | — |  |  | 0.1 |  |  | 57.3 |  |  | 57.4 |  |
| Total | $ | 835.3 |  |  | $ | 252.9 |  |  | $ | 156.7 |  |  | $ | 1,244.9 |  |

[0001628280-22-027168:notes:52]
|  | For the Three Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 655.0 |  |  | $ | 194.0 |  |  | $ | 81.2 |  |  | $ | 930.2 |  |
| Canada | 56.0 |  |  | 16.8 |  |  | — |  |  | 72.8 |  |
| Other international | — |  |  | 0.7 |  |  | 56.2 |  |  | 56.9 |  |
| Total | $ | 711.0 |  |  | $ | 211.5 |  |  | $ | 137.4 |  |  | $ | 1,059.9 |  |

[0001628280-22-027168:notes:53]
|  | For the Nine Months Ended September 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,311.2 |  |  | $ | 616.4 |  |  | $ | 299.0 |  |  | $ | 3,226.6 |  |
| Canada | 183.7 |  |  | 43.2 |  |  | — |  |  | 226.9 |  |
| Other international | — |  |  | 0.6 |  |  | 170.5 |  |  | 171.1 |  |
| Total | $ | 2,494.9 |  |  | $ | 660.2 |  |  | $ | 469.5 |  |  | $ | 3,624.6 |  |

[0001628280-22-027168:notes:54]
|  | For the Nine Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,976.8 |  |  | $ | 605.0 |  |  | $ | 239.1 |  |  | $ | 2,820.9 |  |
| Canada | 178.5 |  |  | 57.6 |  |  | — |  |  | 236.1 |  |
| Other international | — |  |  | 0.8 |  |  | 171.5 |  |  | 172.3 |  |
| Total | $ | 2,155.3 |  |  | $ | 663.4 |  |  | $ | 410.6 |  |  | $ | 3,229.3 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-22-027168:notes:55]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2022 and 2021, direct sales represented 72% and 73% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2022 and 2021, direct sales represented 70% and 72% of revenues, and sales to independent distributors represented the remainder.

[0001628280-22-027168:notes:56]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.   Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended September 30, 2022 and 2021, equipment sales represented 83% and 81% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2022 and 2021, equipment sales represented 82% and 83% of revenues and the remainder of our revenue was generated from our service business.

[0001628280-22-027168:notes:57]
[same as prior period, unchanged from 0001628280-22-019665:notes:57]

[0001628280-22-027168:notes:58]
[same as prior period, unchanged from 0001628280-22-019665:notes:58]

[0001628280-22-027168:notes:59]
|  | September 30, 2022 |  | December 31, 2021 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (11.8) |  |  | $ | (10.2) |  |  | $ | (1.6) |  |  | 15.7 | % |
| Contract liabilities - noncurrent | (6.0) |  |  | (5.5) |  |  | (0.5) |  |  | 9.1 | % |
| Total | $ | (17.8) |  |  | $ | (15.7) |  |  | $ | (2.1) |  |  |  |

[0001628280-22-027168:notes:60]
For the three months ended September 30, 2022 and 2021, we recognized revenue of $3.6 million and $0.6 million and for the nine months ended September 30, 2022 and 2021 we recognized revenue of $9.5 million and $2.9 million related to our contract liabilities at January 1, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2022 and 2021.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-22-027168:notes:61]
[same as prior period, unchanged from 0001628280-22-019665:notes:61]

[0001628280-22-027168:notes:62]
[same as prior period, unchanged from 0001628280-22-019665:notes:62]

[0001628280-22-027168:notes:63]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Finished goods | $ | 498.1 |  |  | $ | 310.8 |  |
| Work in process | 12.8 |  |  | 12.4 |  |
| Raw materials and parts | 332.1 |  |  | 262.1 |  |
| Subtotal | 843.0 |  |  | 585.3 |  |
| Excess of current cost over last-in, first-out cost | (99.6) |  |  | (74.4) |  |
| Total inventories, net | $ | 743.4 |  |  | $ | 510.9 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-22-027168:notes:64]
[same as prior period, unchanged from 0001628280-22-019665:notes:64]

[0001628280-22-027168:notes:65]
[same as prior period, unchanged from 0001628280-22-019665:notes:65]

[0001628280-22-027168:notes:66]
|  | Balance at December 31, 2021 |  |  |  | Changes in foreign currency translation rates |  | Balance at September 30, 2022 |
| Residential Heating & Cooling | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.4 |  |  |  |  | (0.7) |  |  | 98.7 |  |
| Total Goodwill | $ | 186.6 |  |  |  |  | $ | (0.7) |  |  | $ | 185.9 |  |

[0001628280-22-027168:notes:67]
[same as prior period, unchanged from 0001628280-22-019665:notes:67]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-22-027168:notes:68]
[same as prior period, unchanged from 0001628280-22-019665:notes:68]

[0001628280-22-027168:notes:69]
[same as prior period, unchanged from 0001628280-22-019665:notes:69]

[0001628280-22-027168:notes:70]
[same as prior period, unchanged from 0001628280-22-019665:notes:70]

[0001628280-22-027168:notes:71]
[same as prior period, unchanged from 0001628280-22-019665:notes:71]

[0001628280-22-027168:notes:72]
[same as prior period, unchanged from 0001628280-22-019665:notes:72]

[0001628280-22-027168:notes:73]
[same as prior period, unchanged from 0001628280-22-019665:notes:73]

[0001628280-22-027168:notes:74]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through February 2024.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months

[0001628280-22-027168:notes:75]
based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001628280-22-027168:notes:76]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Unrealized losses (gains), net on unsettled contracts | $ | 18.7 |  |  | $ | (13.4) |  |
| Income tax (benefit) expense | (4.5) |  |  | 2.7 |  |
| Unrealized losses (gains), net included in AOCL, net of tax (1) | $ | 14.2 |  |  | $ | (10.7) |  |

[0001628280-22-027168:notes:77]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $13.6 million of derivative losses as of September 30, 2022 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-22-027168:notes:78]
[same as prior period, unchanged from 0001628280-22-019665:notes:77]

[0001628280-22-027168:notes:79]
[same as prior period, unchanged from 0001628280-22-019665:notes:78]

[0001628280-22-027168:notes:80]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Stock-based compensation expense (1) | $ | 5.8 |  |  | $ | (0.6) |  |  | $ | 16.4 |  |  | $ | 16.8 |  |

[0001628280-22-027168:notes:81]
[same as prior period, unchanged from 0001628280-22-019665:notes:80]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-22-027168:notes:82]
The components of net periodic benefit cost for pension benefits were as follows (in millions):

[0001628280-22-027168:notes:83]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Service cost | $ | 1.1 |  |  | $ | 1.5 |  |  | $ | 3.2 |  |  | $ | 4.6 |  |
| Interest cost | 1.5 |  |  | 1.0 |  |  | 4.5 |  |  | 4.1 |  |
| Expected return on plan assets | (2.3) |  |  | (1.7) |  |  | (7.0) |  |  | (7.1) |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Recognized actuarial loss | 1.5 |  |  | 1.8 |  |  | 4.4 |  |  | 6.0 |  |
| Other | 0.2 |  |  | — |  |  | 0.2 |  |  | (0.4) |  |
| Settlements and curtailments | — |  |  | 0.3 |  |  | 0.3 |  |  | 1.1 |  |
| Net periodic benefit cost | $ | 2.0 |  |  | $ | 3.0 |  |  | $ | 5.6 |  |  | $ | 8.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-22-027168:notes:84]
, we had approximately $3.7 million in total gross unrecognized tax benefits which, if recognized, would be recorded through the Consolidated Statements of Operations.We are currently in the Bridge program for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2022 and 2021.  As a result, our returns for those years will not be examined.  However, we are subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2015.


## us-gaap:DebtDisclosureTextBlock

[0001628280-22-027168:notes:85]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001628280-22-027168:notes:86]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.1 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 28.6 |  |  | 29.0 |  |
| Credit agreement | 222.0 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.2) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,593.4 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,604.5 |  |  | $ | 1,237.8 |  |

[0001628280-22-027168:notes:87]
Short-Term Debt

[0001628280-22-027168:notes:88]
Foreign Obligations

[0001628280-22-027168:notes:89]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2022 or December 31, 2021 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2022.

[0001628280-22-027168:notes:90]
Long-Term Debt

[0001628280-22-027168:notes:91]
Asset Securitization Program

[0001628280-22-027168:notes:92]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale. Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001628280-22-027168:notes:93]
We renewed the ASP in November 2021, extending its term to November 2023 and increasing the maximum securitization amount to a range from $300.0 million to $450.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001628280-22-027168:notes:94]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 443.3 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (400.0) |  |  | (250.0) |  |
| Remaining amount available | $ | 43.3 |  |  | $ | 85.6 |  |

[0001628280-22-027168:notes:95]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2022 and December 31, 2021 were 3.85% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001628280-22-027168:notes:96]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of September 30, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-22-027168:notes:97]
Credit Agreement

[0001628280-22-027168:notes:98]
In July 2021, we entered into a new domestic credit facility (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-22-027168:notes:99]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $222.0 million as well as $2.0 million committed to standby letters of credit as of September 30, 2022. Subject to covenant limitations, $526.0 million was available for future borrowings.  The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-22-027168:notes:100]
Our weighted average borrowing rate on the facility was as follows:

[0001628280-22-027168:notes:101]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 4.21 | % |  | 1.38 | % |

[0001628280-22-027168:notes:102]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-22-027168:notes:103]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitization (cross default), and bankruptcy. A cross default under our Credit Agreement could occur if:

[0001628280-22-027168:notes:104]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-22-027168:notes:105]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-22-027168:notes:106]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Credit Agreement, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-22-027168:notes:107]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-22-027168:notes:108]
Senior Unsecured Notes

[0001628280-22-027168:notes:109]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2022, we believe we were in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-22-027168:notes:110]
[same as prior period, unchanged from 0001628280-22-019665:notes:109]

[0001628280-22-027168:notes:111]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |
| (Losses) Gains on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | (3.7) |  |  | $ | 7.8 |  |  | $ | 12.5 |  |  | $ | 21.3 |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax benefit (expense) |  | 0.8 |  |  | (1.8) |  |  | (2.9) |  |  | (4.9) |  |  | Provision for income taxes |
| Net of tax |  | $ | (2.9) |  |  | $ | 6.0 |  |  | $ | 9.6 |  |  | $ | 16.4 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.5) |  |  | $ | (1.8) |  |  | $ | (4.4) |  |  | $ | (6.0) |  |  | Other expense (income), net |
| Pension settlements |  | — |  |  | (0.3) |  |  | (0.3) |  |  | (1.1) |  |  | Pension settlements |
| Income tax benefit |  | 0.4 |  |  | 0.6 |  |  | 1.2 |  |  | 1.8 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.1) |  |  | $ | (1.5) |  |  | $ | (3.5) |  |  | $ | (5.3) |  |  |  |
| Total reclassifications from AOCL |  | $ | (4.0) |  |  | $ | 4.5 |  |  | $ | 6.1 |  |  | $ | 11.1 |  |  |  |

[0001628280-22-027168:notes:112]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2022 (in millions):

[0001628280-22-027168:notes:113]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2021 |  | $ | 10.7 |  |  | $ | (1.2) |  |  | $ | (68.8) |  |  | $ | (28.8) |  |  | $ | (88.1) |  |
| Other comprehensive (loss) income before reclassifications |  | (15.3) |  |  | 0.7 |  |  | (3.0) |  |  | (20.7) |  |  | (38.3) |  |
| Amounts reclassified from AOCL |  | (9.6) |  |  | — |  |  | 3.5 |  |  | — |  |  | (6.1) |  |
| Net other comprehensive (loss) income |  | (24.9) |  |  | 0.7 |  |  | 0.5 |  |  | (20.7) |  |  | (44.4) |  |
| Balance as of September 30, 2022 |  | $ | (14.2) |  |  | $ | (0.5) |  |  | $ | (68.3) |  |  | $ | (49.5) |  |  | $ | (132.5) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-22-027168:notes:114]
[same as prior period, unchanged from 0001628280-22-019665:notes:113]

[0001628280-22-027168:notes:115]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2022 were the same as those used at December 31, 2021.

[0001628280-22-027168:notes:116]
[same as prior period, unchanged from 0001628280-22-019665:notes:115]

[0001628280-22-027168:notes:117]
[same as prior period, unchanged from 0001628280-22-019665:notes:116]

[0001628280-22-027168:notes:118]
[same as prior period, unchanged from 0001628280-22-019665:notes:117]

[0001628280-22-027168:notes:119]
[same as prior period, unchanged from 0001628280-22-019665:notes:118]

[0001628280-22-027168:notes:120]
[same as prior period, unchanged from 0001628280-22-019665:notes:119]

[0001628280-22-027168:notes:121]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Senior unsecured notes | $ | 870.1 |  |  | $ | 959.2 |  |
