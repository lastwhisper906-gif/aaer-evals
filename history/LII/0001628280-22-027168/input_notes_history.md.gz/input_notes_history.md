# LII note change history — 0001628280-22-019665 → 0001628280-22-027168


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001628280-22-027168:note_history:1]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.
  (was, 2022-07-28, similarity 0.9924):
[0001628280-22-019665:note_history:1]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

- changed (2022-10-27):
[0001628280-22-027168:note_history:2]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Accrued expenses | $ | 39.8 |  |  | $ | 37.2 |  |
| Other liabilities | 110.4 |  |  | 97.0 |  |
| Total warranty liability | $ | 150.2 |  |  | $ | 134.2 |  |
  (was, 2022-07-28, similarity 0.9687):
[0001628280-22-019665:note_history:2]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Accrued expenses | $ | 39.5 |  |  | $ | 37.2 |  |
| Other liabilities | 109.4 |  |  | 97.0 |  |
| Total warranty liability | $ | 148.9 |  |  | $ | 134.2 |  |

- changed (2022-10-27):
[0001628280-22-027168:note_history:3]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2022 were as follows (in millions):
  (was, 2022-07-28, similarity 0.9444):
[0001628280-22-019665:note_history:3]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2022 were as follows (in millions):

- changed (2022-10-27):
[0001628280-22-027168:note_history:4]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Warranty claims paid | (27.1) |  |
| Changes resulting from issuance of new warranties | 41.8 |  |
| Changes in estimates associated with pre-existing liabilities | 2.7 |  |
| Changes in foreign currency translation rates and other | (1.4) |  |
| Total warranty liability as of September 30, 2022 | $ | 150.2 |  |
  (was, 2022-07-28, similarity 0.9812):
[0001628280-22-019665:note_history:4]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Warranty claims paid | (16.5) |  |
| Changes resulting from issuance of new warranties | 27.6 |  |
| Changes in estimates associated with pre-existing liabilities | 4.3 |  |
| Changes in foreign currency translation rates and other | (0.7) |  |
| Total warranty liability as of June 30, 2022 | $ | 148.9 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-10-27):
[0001628280-22-027168:note_history:5]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2022, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2022 and 2021, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2022 and 2021 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2021.

- changed (2022-10-27):
[0001628280-22-027168:note_history:6]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations since 2020. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows. 
Executive Leadership TransitionOn March 23, 2022, the Board of Directors appointed Alok Maskara as Chief Executive Officer ("CEO") effective May 9, 2022.  Mr. Maskara succeeded Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and served as interim CEO until Mr. Maskara assumed the role on May 9, 2022.
  (was, 2022-07-28, similarity 0.9698):
[0001628280-22-019665:note_history:6]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations. As the pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows. 
Executive Leadership TransitionOn March 23, 2022, the Board of Directors appointed Alok Maskara as Chief Executive Officer ("CEO") effective May 9, 2022.  Mr. Maskara succeeded Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and served as interim CEO until Mr. Maskara assumed the role on May 9, 2022.

- removed (2022-10-27):
[0001628280-22-019665:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2022, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2022 and 2021, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and six months ended June 30, 2022 and 2021, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2022 and 2021 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2021.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001628280-22-027168:note_history:8]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 4.21 | % |  | 1.38 | % |
  (was, 2022-07-28, similarity 0.9447):
[0001628280-22-019665:note_history:8]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 2.53 | % |  | 1.38 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-10-27):
[0001628280-22-027168:note_history:9]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.1 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 28.6 |  |  | 29.0 |  |
| Credit agreement | 222.0 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.2) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,593.4 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,604.5 |  |  | $ | 1,237.8 |  |

- changed (2022-10-27):
[0001628280-22-027168:note_history:10]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2022 or December 31, 2021 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2022.
  (was, 2022-07-28, similarity 0.9378):
[0001628280-22-019665:note_history:10]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2022 or December 31, 2021 and there were no borrowings or repayments on these facilities during the six months ended June 30, 2022.

- added (2022-10-27):
[0001628280-22-027168:note_history:11]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 443.3 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (400.0) |  |  | (250.0) |  |
| Remaining amount available | $ | 43.3 |  |  | $ | 85.6 |  |

- changed (2022-10-27):
[0001628280-22-027168:note_history:12]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2022 and December 31, 2021 were 3.85% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2022-07-28, similarity 0.9919):
[0001628280-22-019665:note_history:12]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2022 and December 31, 2021 were 2.37% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2022-10-27):
[0001628280-22-027168:note_history:13]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of September 30, 2022, we believe we were in compliance with all covenant requirements.
  (was, 2022-07-28, similarity 0.9719):
[0001628280-22-019665:note_history:13]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of June 30, 2022, we believe we were in compliance with all covenant requirements.

- added (2022-10-27):
[0001628280-22-027168:note_history:14]
Credit Agreement

- changed (2022-10-27):
[0001628280-22-027168:note_history:15]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $222.0 million as well as $2.0 million committed to standby letters of credit as of September 30, 2022. Subject to covenant limitations, $526.0 million was available for future borrowings.  The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.
  (was, 2022-07-28, similarity 0.9874):
[0001628280-22-019665:note_history:15]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $308.5 million as well as $2.0 million committed to standby letters of credit as of June 30, 2022. Subject to covenant limitations, $439.5 million was available for future borrowings.  The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

- changed (2022-10-27):
[0001628280-22-027168:note_history:16]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 4.21 | % |  | 1.38 | % |
  (was, 2022-07-28, similarity 0.9447):
[0001628280-22-019665:note_history:16]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 2.53 | % |  | 1.38 | % |

- changed (2022-10-27):
[0001628280-22-027168:note_history:17]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2022, we believe we were in compliance with all covenant requirements.
  (was, 2022-07-28, similarity 0.8986):
[0001628280-22-019665:note_history:17]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of June 30, 2022, we believe we were in compliance with all covenant requirements.

- changed (2022-10-27):
[0001628280-22-027168:note_history:18]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2022, we believe we were in compliance with all covenant requirements.
  (was, 2022-07-28, similarity 0.9583):
[0001628280-22-019665:note_history:18]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2022, we believe we were in compliance with all covenant requirements.

- removed (2022-10-27):
[0001628280-22-019665:note_history:19]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 30.8 |  |  | 29.0 |  |
| Credit Agreement | 308.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.8) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,681.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,693.3 |  |  | $ | 1,237.8 |  |

- removed (2022-10-27):
[0001628280-22-019665:note_history:20]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 400.0 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (400.0) |  |  | (250.0) |  |
| Remaining amount available | $ | — |  |  | $ | 85.6 |  |

- removed (2022-10-27):
[0001628280-22-019665:note_history:21]
Domestic Credit Facility


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-10-27):
[0001628280-22-027168:note_history:22]
|  | As of September 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.1 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 28.6 |  |  | 29.0 |  |
| Credit agreement | 222.0 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.2) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,593.4 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,604.5 |  |  | $ | 1,237.8 |  |

- removed (2022-10-27):
[0001628280-22-019665:note_history:23]
|  | As of June 30, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 30.8 |  |  | 29.0 |  |
| Credit Agreement | 308.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (7.8) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,681.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,693.3 |  |  | $ | 1,237.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001628280-22-027168:note_history:24]
|  | For the Three Months Ended September 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 779.8 |  |  | $ | 232.5 |  |  | $ | 99.4 |  |  | $ | 1,111.7 |  |
| Canada | 55.5 |  |  | 20.3 |  |  | — |  |  | 75.8 |  |
| Other international | — |  |  | 0.1 |  |  | 57.3 |  |  | 57.4 |  |
| Total | $ | 835.3 |  |  | $ | 252.9 |  |  | $ | 156.7 |  |  | $ | 1,244.9 |  |
  (was, 2022-07-28, similarity 0.9268):
[0001628280-22-019665:note_history:24]
|  | For the Three Months Ended June 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 763.0 |  |  | $ | 228.7 |  |  | $ | 82.2 |  |  | $ | 1,073.9 |  |
| Canada | 75.0 |  |  | 23.9 |  |  | — |  |  | 98.9 |  |
| Other international | — |  |  | 0.2 |  |  | 66.0 |  |  | 66.2 |  |
| Total | $ | 838.0 |  |  | $ | 252.8 |  |  | $ | 148.2 |  |  | $ | 1,239.0 |  |

- changed (2022-10-27):
[0001628280-22-027168:note_history:25]
|  | For the Three Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 655.0 |  |  | $ | 194.0 |  |  | $ | 81.2 |  |  | $ | 930.2 |  |
| Canada | 56.0 |  |  | 16.8 |  |  | — |  |  | 72.8 |  |
| Other international | — |  |  | 0.7 |  |  | 56.2 |  |  | 56.9 |  |
| Total | $ | 711.0 |  |  | $ | 211.5 |  |  | $ | 137.4 |  |  | $ | 1,059.9 |  |
  (was, 2022-07-28, similarity 0.8803):
[0001628280-22-019665:note_history:25]
|  | For the Six Months Ended June 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,531.4 |  |  | $ | 384.0 |  |  | $ | 199.6 |  |  | $ | 2,115.0 |  |
| Canada | 128.2 |  |  | 22.8 |  |  | — |  |  | 151.0 |  |
| Other international | — |  |  | 0.5 |  |  | 113.2 |  |  | 113.7 |  |
| Total | $ | 1,659.6 |  |  | $ | 407.3 |  |  | $ | 312.8 |  |  | $ | 2,379.7 |  |

- changed (2022-10-27):
[0001628280-22-027168:note_history:26]
|  | For the Nine Months Ended September 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,311.2 |  |  | $ | 616.4 |  |  | $ | 299.0 |  |  | $ | 3,226.6 |  |
| Canada | 183.7 |  |  | 43.2 |  |  | — |  |  | 226.9 |  |
| Other international | — |  |  | 0.6 |  |  | 170.5 |  |  | 171.1 |  |
| Total | $ | 2,494.9 |  |  | $ | 660.2 |  |  | $ | 469.5 |  |  | $ | 3,624.6 |  |
  (was, 2022-07-28, similarity 0.8814):
[0001628280-22-019665:note_history:26]
|  | For the Six Months Ended June 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,321.8 |  |  | $ | 411.0 |  |  | $ | 157.9 |  |  | $ | 1,890.7 |  |
| Canada | 122.4 |  |  | 40.8 |  |  | — |  |  | 163.2 |  |
| Other international | — |  |  | 0.2 |  |  | 115.3 |  |  | 115.5 |  |
| Total | $ | 1,444.2 |  |  | $ | 452.0 |  |  | $ | 273.2 |  |  | $ | 2,169.4 |  |

- changed (2022-10-27):
[0001628280-22-027168:note_history:27]
|  | For the Nine Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,976.8 |  |  | $ | 605.0 |  |  | $ | 239.1 |  |  | $ | 2,820.9 |  |
| Canada | 178.5 |  |  | 57.6 |  |  | — |  |  | 236.1 |  |
| Other international | — |  |  | 0.8 |  |  | 171.5 |  |  | 172.3 |  |
| Total | $ | 2,155.3 |  |  | $ | 663.4 |  |  | $ | 410.6 |  |  | $ | 3,229.3 |  |
  (was, 2022-07-28, similarity 0.6812):
[0001628280-22-019665:note_history:27]
|  | For the Three Months Ended June 30, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 901.8 |  |  | $ | 207.2 |  |  | $ | 107.7 |  |  | $ | 1,216.7 |  |
| Canada | 75.7 |  |  | 12.4 |  |  | — |  |  | 88.1 |  |
| Other international | — |  |  | — |  |  | 61.5 |  |  | 61.5 |  |
| Total | $ | 977.5 |  |  | $ | 219.6 |  |  | $ | 169.2 |  |  | $ | 1,366.3 |  |

- changed (2022-10-27):
[0001628280-22-027168:note_history:28]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2022 and 2021, direct sales represented 72% and 73% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2022 and 2021, direct sales represented 70% and 72% of revenues, and sales to independent distributors represented the remainder.
  (was, 2022-07-28, similarity 0.8211):
[0001628280-22-019665:note_history:28]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2022 and 2021, direct sales represented 70% and 76% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2022 and 2021, direct sales represented 69% and 72% of revenues, and sales to independent distributors represented the remainder.

- changed (2022-10-27):
[0001628280-22-027168:note_history:29]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.   Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended September 30, 2022 and 2021, equipment sales represented 83% and 81% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2022 and 2021, equipment sales represented 82% and 83% of revenues and the remainder of our revenue was generated from our service business.
  (was, 2022-07-28, similarity 0.686):
[0001628280-22-019665:note_history:29]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.   Lennox National Account Services provides installation,

- added (2022-10-27):
[0001628280-22-027168:note_history:30]
|  | September 30, 2022 |  | December 31, 2021 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (11.8) |  |  | $ | (10.2) |  |  | $ | (1.6) |  |  | 15.7 | % |
| Contract liabilities - noncurrent | (6.0) |  |  | (5.5) |  |  | (0.5) |  |  | 9.1 | % |
| Total | $ | (17.8) |  |  | $ | (15.7) |  |  | $ | (2.1) |  |  |  |

- changed (2022-10-27):
[0001628280-22-027168:note_history:31]
For the three months ended September 30, 2022 and 2021, we recognized revenue of $3.6 million and $0.6 million and for the nine months ended September 30, 2022 and 2021 we recognized revenue of $9.5 million and $2.9 million related to our contract liabilities at January 1, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2022 and 2021.
  (was, 2022-07-28, similarity 0.9149):
[0001628280-22-019665:note_history:31]
For the three months ended June 30, 2022 and 2021, we recognized revenue of $2.1 million and $0.8 million and for the six months ended June 30, 2022 and 2021 we recognized revenue of $5.9 million and $2.4 million related to our contract liabilities at January 1, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2022 and 2021.

- removed (2022-10-27):
[0001628280-22-019665:note_history:32]
service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended June 30, 2022 and 2021, equipment sales represented 81% and 85% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2022 and 2021, equipment sales represented 81% and 84% of revenues and the remainder of our revenue was generated from our service business.

- removed (2022-10-27):
[0001628280-22-019665:note_history:33]
|  | June 30, 2022 |  | December 31, 2021 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (11.6) |  |  | $ | (10.2) |  |  | $ | (1.4) |  |  | 13.9 | % |
| Contract liabilities - noncurrent | (5.8) |  |  | (5.5) |  |  | (0.3) |  |  | 6.0 | % |
| Total | $ | (17.4) |  |  | $ | (15.7) |  |  | $ | (1.7) |  |  |  |
