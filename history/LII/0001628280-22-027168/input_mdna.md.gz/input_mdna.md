# LII MD&A — 0001628280-22-027168


## mdna

[0001628280-22-027168:mdna:1]
[same as prior period, unchanged from 0001628280-22-019665:mdna:1]

[0001628280-22-027168:mdna:2]
[same as prior period, unchanged from 0001628280-22-019665:mdna:2]

[0001628280-22-027168:mdna:3]
[same as prior period, unchanged from 0001628280-22-019665:mdna:3]

[0001628280-22-027168:mdna:4]
[same as prior period, unchanged from 0001628280-22-019665:mdna:4]

[0001628280-22-027168:mdna:5]
[same as prior period, unchanged from 0001628280-22-019665:mdna:5]

[0001628280-22-027168:mdna:6]
[same as prior period, unchanged from 0001628280-22-019665:mdna:6]

[0001628280-22-027168:mdna:7]
[same as prior period, unchanged from 0001628280-22-019665:mdna:7]

[0001628280-22-027168:mdna:8]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus spread.  If the pandemic worsens or continues longer than presently expected, COVID-19 could impact our results of operations, financial position and cash flows.

[0001628280-22-027168:mdna:9]
[same as prior period, unchanged from 0001628280-22-019665:mdna:9]

[0001628280-22-027168:mdna:10]
[same as prior period, unchanged from 0001628280-22-019665:mdna:10]

[0001628280-22-027168:mdna:11]
[same as prior period, unchanged from 0001628280-22-019665:mdna:11]

[0001628280-22-027168:mdna:12]
Results for the third quarter of 2022 were driven by overall year-over-year sales and profit increases.  Net sales increased 17% and segment profit increased $10 million for the Residential Heating & Cooling segment. Net sales increased 20% and segment profit increased $7 million for the Commercial Heating & Cooling segment. Net sales increased 14% and segment profit increased $8 million for the Refrigeration segment.

[0001628280-22-027168:mdna:13]
[same as prior period, unchanged from 0001628280-22-019665:mdna:13]

[0001628280-22-027168:mdna:14]
•Net sales increased $185 million to $1,245 million in the third quarter of 2022 driven by favorable price, volume, and mix partially offset by unfavorable foreign currency.

[0001628280-22-027168:mdna:15]
•Operating income in the third quarter of 2022 increased $23 million to $186 million primarily driven by higher net sales partially offset by rising costs.

[0001628280-22-027168:mdna:16]
•Net income for the third quarter of 2022 was $142 million.

[0001628280-22-027168:mdna:17]
•Diluted earnings per share was $3.99 per share in the third quarter of 2022 compared to $3.41 per share in the third quarter of 2021.

[0001628280-22-027168:mdna:18]
•For the nine months ended September 30, 2022, we returned $142 million to shareholders through dividend payments and repurchased $300 million of common stock through our share repurchase program.

[0001628280-22-027168:mdna:19]
Three Months Ended September 30, 2022 Compared to Three Months Ended September 30, 2021 - Consolidated Results

[0001628280-22-027168:mdna:20]
[same as prior period, unchanged from 0001628280-22-019665:mdna:20]

[0001628280-22-027168:mdna:21]
|  | For the Three Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | $ | 1,244.9 |  |  | $ | 1,059.9 |  |  | 17.5 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 910.7 |  |  | 764.7 |  |  | (19.1) |  |  | 73.2 |  |  | 72.1 |  |
| Gross profit | 334.2 |  |  | 295.2 |  |  | 13.2 |  |  | 26.8 |  |  | 27.9 |  |
| Selling, general and administrative expenses | 147.3 |  |  | 134.2 |  |  | (9.8) |  |  | 11.8 |  |  | 12.7 |  |
| Losses (gains) and other expenses, net | 3.3 |  |  | 2.1 |  |  | (57.1) |  |  | 0.3 |  |  | 0.2 |  |
| Restructuring charges | 0.2 |  |  | 0.3 |  |  | 33.3 |  |  | — |  |  | — |  |
| Income from equity method investments | (2.4) |  |  | (4.1) |  |  | (41.5) |  |  | (0.2) |  |  | (0.4) |  |
| Operating income | $ | 185.8 |  |  | $ | 162.7 |  |  | 14.2 | % |  | 14.9 | % |  | 15.4 | % |

[0001628280-22-027168:mdna:22]
[same as prior period, unchanged from 0001628280-22-019665:mdna:22]

[0001628280-22-027168:mdna:23]
Net sales for the third quarter of 2022 compared to the third quarter of 2021 increased as a result of favorable price of 11%, an increase in sales volume of 5%, and favorable product mix of 2% which was partially offset by unfavorable foreign currency of 1%.

[0001628280-22-027168:mdna:24]
[same as prior period, unchanged from 0001628280-22-019665:mdna:24]

[0001628280-22-027168:mdna:25]
Gross profit margins in the third quarter of 2022 decreased 110 basis points ("bps") to 26.8% compared to 27.9% in the third quarter of 2021. Gross margins decreased 220 bps from higher commodity costs, 200 bps from other product costs including adjustments for LIFO, 190 bps from higher component costs, 120 bps from factory inefficiencies, 50 bps from higher freight and distribution costs, and 10 bps from unfavorable mix.  Partially offsetting these decreases was 680 bps from favorable price.

[0001628280-22-027168:mdna:26]
[same as prior period, unchanged from 0001628280-22-019665:mdna:26]

[0001628280-22-027168:mdna:27]
Selling, general and administrative expenses ("SG&A") increased $13 million to $147 million in the third quarter of 2022 compared to $134 million in the third quarter of 2021 due to higher employee related costs. As a percentage of net sales, SG&A decreased 90 bps to 11.8%.

[0001628280-22-027168:mdna:28]
[same as prior period, unchanged from 0001628280-22-019665:mdna:28]

[0001628280-22-027168:mdna:29]
Losses (gains) and other expenses, net for the third quarter of 2022 and 2021 included the following (in millions):

[0001628280-22-027168:mdna:30]
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts | $ | 0.3 |  |  | $ | (0.2) |  |  |  |  |  |  |  |
| Foreign currency exchange losses | 0.3 |  |  | — |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.4) |  |  | (0.1) |  |  |  |  |  |  |  |
| Other operating income | (0.2) |  |  | (0.5) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | — |  |  | 0.2 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 3.1 |  |  | 2.2 |  |  |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic | 0.2 |  |  | 0.8 |  |  |  |  |  |  |  |
| Other items, net | — |  |  | (0.3) |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.3 |  |  | $ | 2.1 |  |  |  |  |  |  |  |

[0001628280-22-027168:mdna:31]
[same as prior period, unchanged from 0001628280-22-019665:mdna:32]

[0001628280-22-027168:mdna:32]
Restructuring charges were immaterial in the third quarter of 2022 and 2021.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-22-027168:mdna:33]
[same as prior period, unchanged from 0001628280-22-019665:mdna:34]

[0001628280-22-027168:mdna:34]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  We recognized income from equity method investments of $2 million in the third quarter of 2022 and $4 million in the third quarter of 2021.  The decline was due to lower operating results at the equity method investees due to higher material costs.

[0001628280-22-027168:mdna:35]
[same as prior period, unchanged from 0001628280-22-019665:mdna:36]

[0001628280-22-027168:mdna:36]
Interest expense, net increased to $11 million in the third quarter of 2022 from $7 million in the third quarter of 2021 due to higher borrowings and higher borrowing costs during the period.

[0001628280-22-027168:mdna:37]
[same as prior period, unchanged from 0001628280-22-019665:mdna:38]

[0001628280-22-027168:mdna:38]
Our effective tax rate was 18.7% for the third quarter of 2022 compared to 18.4% for the third quarter of 2021.  The increase in rate is primarily due to a decrease in excess tax benefits.   We expect our annual effective tax rate in 2022 to be 18-20%.

[0001628280-22-027168:mdna:39]
Third Quarter of 2022 Compared to Third Quarter of 2021 - Results by Segment

[0001628280-22-027168:mdna:40]
[same as prior period, unchanged from 0001628280-22-019665:mdna:41]

[0001628280-22-027168:mdna:41]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-027168:mdna:42]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 835.3 |  |  | $ | 711.0 |  |  | $ | 124.3 |  |  | 17.5 | % |
| Profit | $ | 153.8 |  |  | $ | 144.0 |  |  | $ | 9.8 |  |  | 6.8 | % |
| % of net sales | 18.4 | % |  | 20.3 | % |  |  |  |  |

[0001628280-22-027168:mdna:43]
Net sales increased 17% in the third quarter of 2022 compared to 2021, as price increased 10% and sales volume increased by 7%. Product mix was neutral for the quarter.

[0001628280-22-027168:mdna:44]
Segment profit in the third quarter of 2022 compared to 2021 increased by $10 million, driven by $77 million from higher price, $15 million from higher sales volume, and $2 million from lower product warranty costs. Partially offsetting these increases were $21 million from higher other product costs including adjustments for LIFO, $20 million from higher commodity costs, $14 million from higher component costs, $11 million from unfavorable product mix, $7 million from higher distribution and freight charges, $6 million from higher SG&A costs, $3 million from factory inefficiencies, $1 million from unfavorable foreign currency, and $1 million from lower earnings from our equity method investments.

[0001628280-22-027168:mdna:45]
[same as prior period, unchanged from 0001628280-22-019665:mdna:46]

[0001628280-22-027168:mdna:46]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-027168:mdna:47]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 252.9 |  |  | $ | 211.5 |  |  | $ | 41.4 |  |  | 19.6 | % |
| Profit | $ | 29.6 |  |  | $ | 22.6 |  |  | $ | 7.0 |  |  | 31.0 | % |
| % of net sales | 11.7 | % |  | 10.7 | % |  |  |  |  |

[0001628280-22-027168:mdna:48]
Net sales increased 20% in the third quarter of 2022 compared to 2021 as higher factory output enabled us to convert more order backlog into sales.  Product mix was 11% favorable and price increased by 9%. Sales volume was neutral for the quarter.

[0001628280-22-027168:mdna:49]
Segment profit in the third quarter of 2022 compared to 2021 increased $7 million due to $20 million from favorable price and $13 million from favorable product mix.  Partially offsetting these increases was $9 million from factory inefficiencies, $5 million from higher component costs, $4 million from higher commodity costs, $3 million from higher other product costs including adjustments for LIFO, $2 million from higher SG&A costs, $2 million from lower sales volume, and $1 million from lower miscellaneous other costs.

[0001628280-22-027168:mdna:50]
[same as prior period, unchanged from 0001628280-22-019665:mdna:51]

[0001628280-22-027168:mdna:51]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-027168:mdna:52]
|  | For the Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 156.7 |  |  | $ | 137.4 |  |  | $ | 19.3 |  |  | 14.0 | % |
| Profit | $ | 22.4 |  |  | $ | 14.5 |  |  | $ | 7.9 |  |  | 54.5 | % |
| % of net sales | 14.3 | % |  | 10.6 | % |  |  |  |  |

[0001628280-22-027168:mdna:53]
Net sales increased 14% in the third quarter of 2022 compared to 2021, as price increased 16% and sales volume increased by 5%. Partially offsetting these increases were unfavorable foreign currency of 7%.  Product mix was neutral for the quarter.

[0001628280-22-027168:mdna:54]
Segment profit in the third quarter of 2022 compared to 2021 increased by $8 million driven by $22 million from higher price, $3 million from higher sales volume, and $1 million from favorable product mix. Partially offsetting these increases were $5 million from higher SG&A, $4 million from commodity costs, $4 million from higher component costs, $3 million from factory inefficiencies, $1 million from freight and distribution costs, and $1 million from unfavorable foreign currency.

[0001628280-22-027168:mdna:55]
[same as prior period, unchanged from 0001628280-22-019665:mdna:56]

[0001628280-22-027168:mdna:56]
There were no material changes in Corporate and Other costs during the third quarter of 2022 as compared to the third quarter of 2021.

[0001628280-22-027168:mdna:57]
Year-to-Date through September 30, 2022 Compared to Year-to-Date through September 30, 2021 - Consolidated Results

[0001628280-22-027168:mdna:58]
[same as prior period, unchanged from 0001628280-22-019665:mdna:59]

[0001628280-22-027168:mdna:59]
|  | For the Nine Months Ended September 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | $ | 3,624.6 |  |  | $ | 3,229.3 |  |  | 12.2 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 2,625.1 |  |  | 2,294.5 |  |  | (14.4) |  |  | 72.4 |  |  | 71.1 |  |
| Gross profit | 999.5 |  |  | 934.8 |  |  | 6.9 |  |  | 27.6 |  |  | 28.9 |  |
| Selling, general and administrative expenses | 472.2 |  |  | 447.4 |  |  | (5.5) |  |  | 13.0 |  |  | 13.9 |  |
| Losses (gains) and other expenses, net | 5.4 |  |  | 4.7 |  |  | (14.9) |  |  | 0.1 |  |  | 0.1 |  |
| Restructuring charges | 1.2 |  |  | 1.6 |  |  | 25.0 |  |  | — |  |  | — |  |
| Income from equity method investments | (3.9) |  |  | (11.6) |  |  | (66.4) |  |  | (0.1) |  |  | (0.4) |  |
| Operating income | $ | 524.6 |  |  | $ | 492.7 |  |  | 6.5 | % |  | 14.5 | % |  | 15.3 | % |

[0001628280-22-027168:mdna:60]
[same as prior period, unchanged from 0001628280-22-019665:mdna:61]

[0001628280-22-027168:mdna:61]
Net sales increased 12% for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021 due to higher price of 11%, higher sales volume of 1%, and favorable mix of 1%.  Partially offsetting these increases was unfavorable foreign currency of 1%.

[0001628280-22-027168:mdna:62]
[same as prior period, unchanged from 0001628280-22-019665:mdna:63]

[0001628280-22-027168:mdna:63]
Gross profit margins for the nine months ended September 30, 2022 decreased 130 bps to 27.6% compared to 28.9% for the nine months ended September 30, 2021. Gross margins decreased 250 bps from higher commodity costs, 180 bps from higher component costs, 150 bps from higher other product costs including adjustments for LIFO, 100 bps from factory inefficiencies, 90 bps from higher freight and distribution costs, and 50 bps from unfavorable mix.  Partially offsetting these decreases were 670 bps from higher price and 20 bps from miscellaneous other costs.

[0001628280-22-027168:mdna:64]
[same as prior period, unchanged from 0001628280-22-019665:mdna:65]

[0001628280-22-027168:mdna:65]
SG&A increased $25 million to $472 million for the nine months ended September 30, 2022 compared to $447 million for the nine months ended September 30, 2021 primarily due to higher employee related costs.  As a percentage of net sales, SG&A decreased 90 bps to 13.0% from 13.9%.

[0001628280-22-027168:mdna:66]
[same as prior period, unchanged from 0001628280-22-019665:mdna:67]

[0001628280-22-027168:mdna:67]
Losses (gains) and other expenses, net for the nine months ended September 30, 2022 and 2021 included the following (in millions):

[0001628280-22-027168:mdna:68]
|  | For the Nine Months Ended September 30, |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |  |  |
| Realized gains on settled future contracts | $ | (0.1) |  |  | $ | (0.9) |  |  |  |  |  |  |  |
| Foreign currency exchange gains | (0.5) |  |  | (1.6) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (1.3) |  |  | (0.6) |  |  |  |  |  |  |  |
| Other operating income | (0.6) |  |  | (0.9) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 1.2 |  |  | 0.1 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 6.2 |  |  | 7.3 |  |  |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic | 0.8 |  |  | 1.9 |  |  |  |  |  |  |  |
| Other items, net | (0.3) |  |  | (0.6) |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 5.4 |  |  | $ | 4.7 |  |  |  |  |  |  |  |

[0001628280-22-027168:mdna:69]
[same as prior period, unchanged from 0001628280-22-019665:mdna:71]

[0001628280-22-027168:mdna:70]
Restructuring charges were $1 million for the nine months ended September 30, 2022 and $2 million for the nine months ended September 30, 2021.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-22-027168:mdna:71]
[same as prior period, unchanged from 0001628280-22-019665:mdna:73]

[0001628280-22-027168:mdna:72]
Income from equity method investments decreased $8 million to $4 million for the nine months ended September 30, 2022 as compared to $12 million for the nine months ended September 30, 2021.  The decline was due to lower operating results at the equity method investees due to higher material costs.

[0001628280-22-027168:mdna:73]
[same as prior period, unchanged from 0001628280-22-019665:mdna:75]

[0001628280-22-027168:mdna:74]
Interest expense, net increased $7 million for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021 primarily due to higher borrowings and higher borrowing costs.

[0001628280-22-027168:mdna:75]
[same as prior period, unchanged from 0001628280-22-019665:mdna:77]

[0001628280-22-027168:mdna:76]
Our effective tax rate decreased to 18.9% for the nine months ended September 30, 2022 compared to 19.0% for the nine months ended September 30, 2021 primarily due to a favorable mix of income to low tax jurisdictions.

[0001628280-22-027168:mdna:77]
Year-to-Date through September 30, 2022 Compared to Year-to-Date through September 30, 2021 - Results by Segment

[0001628280-22-027168:mdna:78]
[same as prior period, unchanged from 0001628280-22-019665:mdna:80]

[0001628280-22-027168:mdna:79]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the nine months ended September 30, 2022 and 2021 (dollars in millions):

[0001628280-22-027168:mdna:80]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 2,494.9 |  |  | $ | 2,155.3 |  |  | $ | 339.6 |  |  | 15.8 | % |
| Profit | $ | 477.7 |  |  | $ | 430.1 |  |  | $ | 47.6 |  |  | 11.1 | % |
| % of net sales | 19.1 | % |  | 20.0 | % |  |  |  |  |

[0001628280-22-027168:mdna:81]
Net sales increased 16% for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021 as price increased by 12% and sales volume increased by 4%.  Product mix was neutral.

[0001628280-22-027168:mdna:82]
Segment profit for the first nine months of 2022 compared to 2021 increased $48 million primarily due to $256 million from favorable price, $31 million from higher sales volume, and $2 million from miscellaneous income. Partially offsetting these increases were $70 million from higher commodity costs, $40 million from increased component costs, $40 million from higher other product costs including adjustments for LIFO, $30 million from unfavorable mix, $24 million from higher freight and distribution costs, $12 million from factory inefficiencies, $12 million from higher SG&A costs, $7 million from lower income from equity method investments, and $6 million from unfavorable foreign currency.

[0001628280-22-027168:mdna:83]
[same as prior period, unchanged from 0001628280-22-019665:mdna:85]

[0001628280-22-027168:mdna:84]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the nine months ended September 30, 2022 and 2021 (dollars in millions):

[0001628280-22-027168:mdna:85]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 660.2 |  |  | $ | 663.4 |  |  | $ | (3.2) |  |  | (0.5) | % |
| Profit | $ | 53.1 |  |  | $ | 95.3 |  |  | $ | (42.2) |  |  | (44.3) | % |
| % of net sales | 8.0 | % |  | 14.4 | % |  |  |  |  |

[0001628280-22-027168:mdna:86]
Net sales decreased  0.5% for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021 as sales volume decreased by 13%. Partially offsetting the decrease was favorable mix of 7% and favorable price of 6%.

[0001628280-22-027168:mdna:87]
Segment profit for the first nine months of 2022 compared to 2021 decreased $42 million primarily due to $34 million from lower sales volume primarily due to supply chain constraints, $20 million from factory inefficiencies, $17 million from higher component costs, $12 million from higher other product costs including adjustments for LIFO, $9 million from increased SG&A costs, $9 million from higher commodity costs, and $5 million from higher freight and distribution costs.  Partially offsetting these decreases were $37 million from higher price, $25 million from favorable product mix, $1 million from foreign currency, and $1 million from lower product warranty costs.

[0001628280-22-027168:mdna:88]
[same as prior period, unchanged from 0001628280-22-019665:mdna:90]

[0001628280-22-027168:mdna:89]
The following table presents our Refrigeration segment's net sales and profit for the nine months ended September 30, 2022 and 2021 (dollars in millions):

[0001628280-22-027168:mdna:90]
|  | For the Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 469.5 |  |  | $ | 410.6 |  |  | $ | 58.9 |  |  | 14.3 | % |
| Profit | $ | 60.0 |  |  | $ | 35.8 |  |  | $ | 24.2 |  |  | 67.6 | % |
| % of net sales | 12.8 | % |  | 8.7 | % |  |  |  |  |

[0001628280-22-027168:mdna:91]
Net sales increased 14% for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021 as price increased by 12% and sales volume increased by 8%. Partially offsetting these increases was unfavorable foreign currency of 5% and unfavorable mix of 1%.

[0001628280-22-027168:mdna:92]
Segment profit for the first nine months of 2022 compared to 2021 increased $24 million primarily due to $50 million from favorable price, $13 million from higher sales volume, $1 million from favorable mix, and $1 million from lower tariff costs. Partially offsetting these increases were $14 million from higher commodity costs, $10 million from higher SG&A costs, $8 million from higher component costs, $4 million from factory inefficiencies, $3 million from higher freight and distribution costs, and $2 million from higher other product costs.

[0001628280-22-027168:mdna:93]
[same as prior period, unchanged from 0001628280-22-019665:mdna:95]

[0001628280-22-027168:mdna:94]
Corporate and other expenses decreased $2 million in the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021 primarily due to lower employee related costs.

[0001628280-22-027168:mdna:95]
[same as prior period, unchanged from 0001628280-22-019665:mdna:97]

[0001628280-22-027168:mdna:96]
[same as prior period, unchanged from 0001628280-22-019665:mdna:98]

[0001628280-22-027168:mdna:97]
[same as prior period, unchanged from 0001628280-22-019665:mdna:99]

[0001628280-22-027168:mdna:98]
The following table summarizes our cash flow activity for the nine months ended September 30, 2022 and 2021 (in millions):

[0001628280-22-027168:mdna:99]
|  | For the Nine Months Ended September 30, |
|  | 2022 |  | 2021 |
| Net cash provided by operating activities | $ | 170.1 |  |  | $ | 396.3 |  |
| Net cash used in investing activities | (68.2) |  |  | (67.6) |  |
| Net cash used in financing activities | (89.1) |  |  | (410.5) |  |

[0001628280-22-027168:mdna:100]
Net Cash Provided By Operating Activities -  The change in net cash provided by operating activities for the nine months ended September 30, 2022 compared to the net cash provided by operating activities for the same period in 2021 reflects less favorable changes in working capital.

[0001628280-22-027168:mdna:101]
Net Cash Used In Investing Activities - Capital expenditures were $67 million for the nine months ended September 30, 2022 compared to $69 million in the same period of 2021.  Capital expenditures in 2022 were primarily related to the expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-22-027168:mdna:102]
Net Cash Used In Financing Activities - Net cash used in financing activities for the nine months ended September 30, 2022 decreased to $89 million compared to $411 million used in the same period of 2021.  The change was primarily due to increased net borrowings in the current year as compared to the prior year and less spent on share repurchases.  We repurchased $300 million of shares for the nine months ended September 30, 2022 and returned $142 million to shareholders through

[0001628280-22-027168:mdna:103]
dividend payments. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001628280-22-027168:mdna:104]
[same as prior period, unchanged from 0001628280-22-019665:mdna:105]

[0001628280-22-027168:mdna:105]
The following table details our lines of credit and financing arrangements as of September 30, 2022 (in millions):

[0001628280-22-027168:mdna:106]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 11.1 |  |
| Total current maturities of long-term debt | $ | 11.1 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | 400.0 |  |
| Finance lease obligations | 28.6 |  |
| Credit agreement (1) | 222.0 |  |
| Senior unsecured notes | 950.0 |  |
| Debt issuance costs | (7.2) |  |
| Total long-term debt | 1,593.4 |  |
| Total debt | $ | 1,604.5 |  |

[0001628280-22-027168:mdna:107]
(1)   The available future borrowings on our Credit Agreement (as defined below) are $526.0 million, after being reduced by the outstanding borrowings and $2.0 million in outstanding standby letters of credit.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-22-027168:mdna:108]
[same as prior period, unchanged from 0001628280-22-019665:mdna:109]

[0001628280-22-027168:mdna:109]
Both our Asset Securitization Program as well as our $350.0 million 2023 Notes will mature in 2023.  We are currently evaluating our options related to these obligations including refinancing and other alternatives.  We do not believe that our options or alternatives will have any material impact on our results of operations or liquidity.

[0001628280-22-027168:mdna:110]
[same as prior period, unchanged from 0001628280-22-019665:mdna:110]

[0001628280-22-027168:mdna:111]
In July 2021, we entered into a domestic credit facility (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-22-027168:mdna:112]
[same as prior period, unchanged from 0001628280-22-019665:mdna:112]

[0001628280-22-027168:mdna:113]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control. As of September 30, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-22-027168:mdna:114]
[same as prior period, unchanged from 0001628280-22-019665:mdna:114]

[0001628280-22-027168:mdna:115]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 123% at September 30, 2022 from 128% at December 31, 2021.

[0001628280-22-027168:mdna:116]
As of September 30, 2022, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-22-027168:mdna:117]
[same as prior period, unchanged from 0001628280-22-019665:mdna:117]

[0001628280-22-027168:mdna:118]
We believe our cash and cash equivalents of $41 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $41 million as of September 30, 2022 was $19 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-22-027168:mdna:119]
[same as prior period, unchanged from 0001628280-22-019665:mdna:119]

[0001628280-22-027168:mdna:120]
[same as prior period, unchanged from 0001628280-22-019665:mdna:120]

[0001628280-22-027168:mdna:121]
[same as prior period, unchanged from 0001628280-22-019665:mdna:121]

[0001628280-22-027168:mdna:122]
[same as prior period, unchanged from 0001628280-22-019665:mdna:122]

[0001628280-22-027168:mdna:123]
Commitments, Contingencies and Guarantees

[0001628280-22-027168:mdna:124]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-22-027168:mdna:125]
[same as prior period, unchanged from 0001628280-22-019665:mdna:125]

[0001628280-22-027168:mdna:126]
[same as prior period, unchanged from 0001628280-22-019665:mdna:126]
