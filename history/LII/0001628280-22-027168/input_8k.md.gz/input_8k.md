# LII 8-K — 0001193125-22-270358 filed 2022-10-27

## item codes, every 8-K on or before 2022-10-27

- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2022-10-27

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-270358:8k_2_02:1]
EX-99.1
2
d390826dex991.htm
EX-99.1

[0001193125-22-270358:8k_2_02:2]
EX-99.1

[0001193125-22-270358:8k_2_02:3]
Exhibit 99.1

[0001193125-22-270358:8k_2_02:4]
Lennox International Reports Record Third Quarter Results

[0001193125-22-270358:8k_2_02:5]
Third Quarter 2022 Highlights (all historical
comparisons are year-over-year)

[0001193125-22-270358:8k_2_02:6]
| • |  | Revenue up 17% to third-quarter record $1.24 billion |

[0001193125-22-270358:8k_2_02:7]
| • |  | GAAP EPS up 17% to $3.99; Adjusted EPS up 21% to third-quarter record $4.10 |

[0001193125-22-270358:8k_2_02:8]
| • |  | Updating 2022 EPS guidance from $13.80-$14.50 to $13.80-$14.20 |

[0001193125-22-270358:8k_2_02:9]
DALLAS, October 27, 2022 – Lennox International Inc. (NYSE: LII), a leader in energy-efficient climate-control solutions, today
reported record financial results for the third quarter of 2022.

[0001193125-22-270358:8k_2_02:10]
Lennox International reported third-quarter record revenue of $1.24 billion in the
quarter, up 17%. GAAP operating income was a third-quarter record $186 million, up 14%. GAAP earnings per share was a third-quarter record $3.99, up 17%.

[0001193125-22-270358:8k_2_02:11]
Total segment profit rose 15% to a third-quarter record $189 million. Total segment margin was 15.2%, down 30 basis points. Adjusted earnings per share
rose 21% to a third-quarter record $4.10.

[0001193125-22-270358:8k_2_02:12]
“Lennox International posted new third-quarter highs for revenue, profit and EPS driven by strong price
execution and increased manufacturing output. We delivered strong operating performance in the face of continued supply chain constraints and manufacturing inefficiencies,” said CEO Alok Maskara. “We are building turnaround momentum in our
Commercial business and are going to invest in a new commercial factory to help alleviate ongoing manufacturing capacity constraints.”

[0001193125-22-270358:8k_2_02:13]
Business
Segment Performance

[0001193125-22-270358:8k_2_02:14]
In Residential, revenue and profit set new third-quarter highs as revenue was up 17% and segment profit rose 7%. Segment margin
was 18.4%, down 190 basis points, impacted by unfavorable mix as manufacturing output of higher-end products remained constrained and supply chain challenges negatively impacted manufacturing efficiency. In Commercial, revenue was up 20% as higher
factory output enabled us to convert more order backlog into sales. Segment profit rose 31%, and segment margin expanded 100 basis points to 11.7%. In Refrigeration, revenue was up 14% as reported and up 21% at constant currency, led by growth in
North America. Segment profit rose 54%, and segment margin expanded 370 basis points to 14.3%.

[0001193125-22-270358:8k_2_02:15]
Maskara added, “Demand and backlog remain strong in
Commercial and Refrigeration segments. In Residential, we are fully prepared for the upcoming regulatory SEER efficiency standards and are investing in inventory to support our customers during this transition. For the company overall, we are
narrowing full-year 2022 EPS guidance from $13.80-$14.50 to a range of $13.80-$14.20 given ongoing supply chain inefficiencies.”

[0001193125-22-270358:8k_2_02:16]
FINANCIAL HIGHLIGHTS

[0001193125-22-270358:8k_2_02:17]
Revenue: Revenue was a third-quarter record $1.24 billion, up 17% driven by volume and price. Foreign exchange had a negative 1% impact on revenue.

[0001193125-22-270358:8k_2_02:18]
Gross Profit: Gross profit was $334 million, up 13%. Gross margin was 26.8%, down 110 basis points, primarily impacted by residential mix,
global supply chain disruptions and factory inefficiencies.

[0001193125-22-270358:8k_2_02:19]
Net Income: On a GAAP basis, net income for the third quarter was $141.9 million,
or $3.99 per share, compared to $126.3 million, or $3.41 per share, in the prior-year quarter.

[0001193125-22-270358:8k_2_02:20]
Adjusted net income in the third quarter was
$145.6 million, or $4.10 per share, compared to $125.8 million, or $3.40 per share, in the prior-year quarter. Adjusted net income for the third quarter of 2022 excludes net after-tax charges of
$3.7 million.

[0001193125-22-270358:8k_2_02:21]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from operations in the third quarter was $171 million
compared to $222 million in the prior-year quarter as the company invested in inventory in preparation for the minimum-efficiency regulatory changes. Capital expenditures were approximately $20 million in the third quarter compared to
$23 million in the prior-year quarter. Free cash flow was $151 million compared to $199 million in the third quarter a year ago. Total debt at the end of the third quarter was $1.60 billion. Total cash, cash equivalents and
short-term investments were $48 million at the end of the quarter. The company paid a total of $75 million in dividends in the third quarter with two quarterly pay dates within the period.

[0001193125-22-270358:8k_2_02:22]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-22-270358:8k_2_02:23]
Residential

[0001193125-22-270358:8k_2_02:24]
Revenue in the Residential Heating & Cooling business segment was a third-quarter record $835 million, up 17%. Segment profit was a third-quarter
record $154 million, up 7%. Segment margin was 18.4%, down 190 basis points, impacted by lower mix as manufacturing output of higher-end products remained constrained and supply chain challenges drove
manufacturing inefficiencies.

[0001193125-22-270358:8k_2_02:25]
Commercial

[0001193125-22-270358:8k_2_02:26]
Revenue in
the Commercial Heating & Cooling business segment was $253 million, up 20%. Segment profit was $30 million, up 31%. Segment margin expanded 100 basis points to 11.7% primarily driven by higher manufacturing output, price and mix.

[0001193125-22-270358:8k_2_02:27]
Refrigeration

[0001193125-22-270358:8k_2_02:28]
Revenue in the Refrigeration business
segment was $157 million, up 14%. Foreign exchange had a negative 7% impact to revenue growth. Segment profit rose 54% to $22 million. Segment margin expanded 370 basis points to 14.3% primarily driven by price.

[0001193125-22-270358:8k_2_02:29]
FULL-YEAR GUIDANCE

[0001193125-22-270358:8k_2_02:30]
| • |  | Updating 2022 guidance for revenue growth from 10-15% to 12-15% |

[0001193125-22-270358:8k_2_02:31]
| • |  | Updating 2022 guidance for GAAP and adjusted EPS from $13.80-$14.50 to $13.80-$14.20 |

[0001193125-22-270358:8k_2_02:32]
CONFERENCE CALL INFORMATION

[0001193125-22-270358:8k_2_02:33]
A conference call to discuss the company’s third-quarter results and outlook will be held this morning at 8:30 a.m. Central time. To listen, call the
conference call line at 800-343-4849 (U.S.) or 203-518-9848 (international) at least 10
minutes prior to the scheduled start time and use conference ID LIIQ322. The conference call also will be webcast and supplemental presentation materials available on Lennox International’s web site at www.lennoxinternational.com. A replay will
be available from approximately 11:30 a.m. Central time on October 27 through November 10, 2022 by dialing 800-938-2246 (U.S.) or 402-220-1123 (international). The call and supplemental presentation materials will be archived on the company’s website.

[0001193125-22-270358:8k_2_02:34]
ABOUT LENNOX INTERNATIONAL

[0001193125-22-270358:8k_2_02:35]
Lennox International Inc. is
a leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in
innovation with our cooling, heating, indoor air quality, and refrigeration systems. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol LII. Additional information on Lennox International is available at
www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-22-270358:8k_2_02:36]
FORWARD-LOOKING STATEMENTS

[0001193125-22-270358:8k_2_02:37]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-270358:8k_2_02:38]
Consolidated Statements of Operations

[0001193125-22-270358:8k_2_02:39]
(Unaudited)

[0001193125-22-270358:8k_2_02:40]
| (Amounts in millions, except per share data) |  | For the Three Months EndedSeptember 30, |  |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net sales |  | $ | 1,244.9 |  |  | $ | 1,059.9 |  |  | $ | 3,624.6 |  |  | $ | 3,229.3 |  |
| Cost of goods sold |  |  | 910.7 |  |  |  | 764.7 |  |  |  | 2,625.1 |  |  |  | 2,294.5 |  |
| Gross profit |  |  | 334.2 |  |  |  | 295.2 |  |  |  | 999.5 |  |  |  | 934.8 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 147.3 |  |  |  | 134.2 |  |  |  | 472.2 |  |  |  | 447.4 |  |
| Losses (gains) and other expenses, net |  |  | 3.3 |  |  |  | 2.1 |  |  |  | 5.4 |  |  |  | 4.7 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 1.2 |  |  |  | 1.6 |  |
| Income from equity method investments |  |  | (2.4 | ) |  |  | (4.1 | ) |  |  | (3.9 | ) |  |  | (11.6 | ) |
| Operating income |  |  | 185.8 |  |  |  | 162.7 |  |  |  | 524.6 |  |  |  | 492.7 |  |
| Pension settlements |  |  | — |  |  |  | 0.3 |  |  |  | 0.3 |  |  |  | 1.1 |  |
| Interest expense, net |  |  | 10.5 |  |  |  | 6.5 |  |  |  | 26.1 |  |  |  | 18.8 |  |
| Other expense (income), net |  |  | 0.7 |  |  |  | 1.1 |  |  |  | 1.9 |  |  |  | 2.9 |  |
| Income from continuing operations before income taxes |  |  | 174.6 |  |  |  | 154.8 |  |  |  | 496.3 |  |  |  | 469.9 |  |
| Provision for income taxes |  |  | 32.7 |  |  |  | 28.5 |  |  |  | 93.6 |  |  |  | 89.4 |  |
| Income from continuing operations |  |  | 141.9 |  |  |  | 126.3 |  |  |  | 402.7 |  |  |  | 380.5 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Income tax benefit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Net income |  | $ | 141.9 |  |  | $ | 126.3 |  |  | $ | 402.7 |  |  | $ | 380.4 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 4.00 |  |  | $ | 3.43 |  |  | $ | 11.25 |  |  | $ | 10.17 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income |  | $ | 4.00 |  |  | $ | 3.43 |  |  | $ | 11.25 |  |  | $ | 10.17 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 3.99 |  |  | $ | 3.41 |  |  | $ | 11.22 |  |  | $ | 10.10 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income |  | $ | 3.99 |  |  | $ | 3.41 |  |  | $ | 11.22 |  |  | $ | 10.10 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 35.4 |  |  |  | 36.8 |  |  |  | 35.8 |  |  |  | 37.4 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 35.5 |  |  |  | 37.0 |  |  |  | 35.9 |  |  |  | 37.7 |  |

[0001193125-22-270358:8k_2_02:41]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-270358:8k_2_02:42]
Segment Net Sales and Profit (Loss)

[0001193125-22-270358:8k_2_02:43]
(Unaudited)

[0001193125-22-270358:8k_2_02:44]
| (Amounts in millions) |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 835.3 |  |  | $ | 711.0 |  |  | $ | 2,494.9 |  |  | $ | 2,155.3 |  |
| Commercial Heating & Cooling |  |  | 252.9 |  |  |  | 211.5 |  |  |  | 660.2 |  |  |  | 663.4 |  |
| Refrigeration |  |  | 156.7 |  |  |  | 137.4 |  |  |  | 469.5 |  |  |  | 410.6 |  |
|  |  | $ | 1,244.9 |  |  | $ | 1,059.9 |  |  | $ | 3,624.6 |  |  | $ | 3,229.3 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 153.8 |  |  | $ | 144.0 |  |  | $ | 477.7 |  |  | $ | 430.1 |  |
| Commercial Heating & Cooling |  |  | 29.6 |  |  |  | 22.6 |  |  |  | 53.1 |  |  |  | 95.3 |  |
| Refrigeration |  |  | 22.4 |  |  |  | 14.5 |  |  |  | 60.0 |  |  |  | 35.8 |  |
| Corporate and other |  |  | (16.5 | ) |  |  | (16.3 | ) |  |  | (57.1 | ) |  |  | (59.2 | ) |
| Total segment profit |  |  | 189.3 |  |  |  | 164.8 |  |  |  | 533.7 |  |  |  | 502.0 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | — |  |  |  | (1.1 | ) |  |  | — |  |  |  | (1.0 | ) |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) |  |  | 3.3 |  |  |  | 2.9 |  |  |  | 7.9 |  |  |  | 8.7 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 1.2 |  |  |  | 1.6 |  |
| Operating income |  | $ | 185.8 |  |  | $ | 162.7 |  |  | $ | 524.6 |  |  | $ | 492.7 |  |

[0001193125-22-270358:8k_2_02:45]
| (1) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-22-270358:8k_2_02:46]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-22-270358:8k_2_02:47]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-22-270358:8k_2_02:48]
|  | • |  | Environmental liabilities and special litigation charges, |

[0001193125-22-270358:8k_2_02:49]
|  | • |  | Charges incurred related to COVID-19 pandemic; and |

[0001193125-22-270358:8k_2_02:50]
|  | • |  | Other items, net, |

[0001193125-22-270358:8k_2_02:51]
|  | • |  | Special product quality adjustments; and |

[0001193125-22-270358:8k_2_02:52]
|  | • |  | Restructuring charges. |

[0001193125-22-270358:8k_2_02:53]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-270358:8k_2_02:54]
Consolidated Balance Sheets

[0001193125-22-270358:8k_2_02:55]
| (Amounts in millions, except shares and par values) |  | As of September 30, 2022 |  |  | As of December 31, 2021 |  |
| ASSETS |  |  | (Unaudited) |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 40.7 |  |  | $ | 31.0 |  |
| Short-term investments |  |  | 7.5 |  |  |  | 5.5 |  |
| Accounts and notes receivable, net of allowances of $13.2 and $10.7 in 2022 and 2021, respectively |  |  | 708.4 |  |  |  | 508.3 |  |
| Inventories, net |  |  | 743.4 |  |  |  | 510.9 |  |
| Other assets |  |  | 94.1 |  |  |  | 119.7 |  |
| Total current assets |  |  | 1,594.1 |  |  |  | 1,175.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $905.7 and $888.8 in 2022 and 2021, respectively |  |  | 520.4 |  |  |  | 515.1 |  |
| Right-of-use assets from operating leases |  |  | 200.5 |  |  |  | 196.1 |  |
| Goodwill |  |  | 185.9 |  |  |  | 186.6 |  |
| Deferred income taxes |  |  | 34.2 |  |  |  | 11.3 |  |
| Other assets, net |  |  | 90.7 |  |  |  | 87.4 |  |
| Total assets |  | $ | 2,625.8 |  |  | $ | 2,171.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 11.1 |  |  | $ | 11.3 |  |
| Current operating lease liabilities |  |  | 61.3 |  |  |  | 54.8 |  |
| Accounts payable |  |  | 430.5 |  |  |  | 402.1 |  |
| Accrued expenses |  |  | 409.6 |  |  |  | 358.9 |  |
| Income taxes payable |  |  | 19.2 |  |  |  | — |  |
| Total current liabilities |  |  | 931.7 |  |  |  | 827.1 |  |
| Long-term debt |  |  | 1,593.4 |  |  |  | 1,226.5 |  |
| Long-term operating lease liabilities |  |  | 143.6 |  |  |  | 145.0 |  |
| Pensions |  |  | 86.5 |  |  |  | 83.3 |  |
| Other liabilities |  |  | 175.8 |  |  |  | 159.0 |  |
| Total liabilities |  |  | 2,931.0 |  |  |  | 2,440.9 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ deficit: |  |  |  |  |  |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,150.4 |  |  |  | 1,133.7 |  |
| Retained earnings |  |  | 3,013.9 |  |  |  | 2,719.3 |  |
| Accumulated other comprehensive loss |  |  | (132.5 | ) |  |  | (88.1 | ) |
| Treasury stock, at cost, 51,735,764 shares and 50,536,125 shares for 2022 and 2021, respectively |  |  | (4,337.9 | ) |  |  | (4,034.8 | ) |
| Total stockholders’ deficit |  |  | (305.2 | ) |  |  | (269.0 | ) |
| Total liabilities and stockholders’ deficit |  | $ | 2,625.8 |  |  | $ | 2,171.9 |  |

[0001193125-22-270358:8k_2_02:56]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-270358:8k_2_02:57]
Consolidated Statements of Cash Flows

[0001193125-22-270358:8k_2_02:58]
(Unaudited)

[0001193125-22-270358:8k_2_02:59]
| (Amounts in millions) |  | For the Nine Months EndedSeptember 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 402.7 |  |  | $ | 380.4 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (3.9 | ) |  |  | (11.6 | ) |
| Dividends from affiliates |  |  | 1.2 |  |  |  | 9.1 |  |
| Restructuring charges, net of cash paid |  |  | 0.7 |  |  |  | 1.1 |  |
| Provision for credit losses |  |  | 4.3 |  |  |  | 4.3 |  |
| Unrealized losses (gains), net on derivative contracts |  |  | 0.8 |  |  |  | (0.2 | ) |
| Stock-based compensation expense |  |  | 16.4 |  |  |  | 16.8 |  |
| Depreciation and amortization |  |  | 56.2 |  |  |  | 53.3 |  |
| Deferred income taxes |  |  | (16.6 | ) |  |  | (2.2 | ) |
| Pension expense |  |  | 5.1 |  |  |  | 8.4 |  |
| Pension contributions |  |  | (0.7 | ) |  |  | (1.1 | ) |
| Other items, net |  |  | (1.4 | ) |  |  | 0.1 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (214.9 | ) |  |  | (139.5 | ) |
| Inventories |  |  | (245.7 | ) |  |  | (21.1 | ) |
| Other current assets |  |  | (5.1 | ) |  |  | (13.1 | ) |
| Accounts payable |  |  | 78.7 |  |  |  | 65.0 |  |
| Accrued expenses |  |  | 36.0 |  |  |  | 49.4 |  |
| Income taxes payable and receivable, net |  |  | 35.5 |  |  |  | (10.3 | ) |
| Leases, net |  |  | 0.8 |  |  |  | — |  |
| Other, net |  |  | 20.0 |  |  |  | 7.5 |  |
| Net cash provided by operating activities |  |  | 170.1 |  |  |  | 396.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 1.2 |  |  |  | 0.7 |  |
| Purchases of property, plant and equipment |  |  | (67.0 | ) |  |  | (68.5 | ) |
| (Purchases of) proceeds from short-term investments, net |  |  | (2.4 | ) |  |  | 0.2 |  |
| Net cash used in investing activities |  |  | (68.2 | ) |  |  | (67.6 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Asset securitization borrowings |  |  | 382.0 |  |  |  | 504.0 |  |
| Asset securitization payments |  |  | (232.0 | ) |  |  | (214.0 | ) |
| Long-term debt payments |  |  | (9.8 | ) |  |  | (3.0 | ) |
| Borrowings from credit facility |  |  | 1,967.5 |  |  |  | 1,021.4 |  |
| Payments on credit facility |  |  | (1,752.0 | ) |  |  | (1,012.5 | ) |
| Proceeds from employee stock purchases |  |  | 2.7 |  |  |  | 2.5 |  |
| Repurchases of common stock |  |  | (300.0 | ) |  |  | (600.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (5.5 | ) |  |  | (16.1 | ) |
| Cash dividends paid |  |  | (142.0 | ) |  |  | (92.8 | ) |
| Net cash used in financing activities |  |  | (89.1 | ) |  |  | (410.5 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 12.8 |  |  |  | (81.8 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (3.1 | ) |  |  | (2.7 | ) |
| Cash and cash equivalents, beginning of period |  |  | 31.0 |  |  |  | 123.9 |  |
| Cash and cash equivalents, end of period |  | $ | 40.7 |  |  | $ | 39.4 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 23.2 |  |  | $ | 17.7 |  |
| Income taxes paid (net of refunds) |  | $ | 75.4 |  |  | $ | 101.6 |  |

[0001193125-22-270358:8k_2_02:60]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-270358:8k_2_02:61]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-22-270358:8k_2_02:62]
(Unaudited, in millions, except per share and ratio data)

[0001193125-22-270358:8k_2_02:63]
Use of Non-GAAP Financial Measures

[0001193125-22-270358:8k_2_02:64]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance.

[0001193125-22-270358:8k_2_02:65]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted
Income from Continuing Operations, a Non-GAAP measure

[0001193125-22-270358:8k_2_02:66]
|  |  | For the Three Months Ended September 30,(Unaudited) |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | Pre-Tax |  |  | Tax Impact (d) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (d) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 174.6 |  |  | $ | (32.7 | ) |  | $ | 141.9 |  |  | $ | 154.8 |  |  | $ | (28.5 | ) |  | $ | 126.3 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |
| Pension settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |
| Special product quality adjustments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.1 | ) |  |  | 0.2 |  |  |  | (0.9 | ) |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (b) |  |  | 3.3 |  |  |  | (0.3 | ) |  |  | 3.0 |  |  |  | 2.9 |  |  |  | (0.5 | ) |  |  | 2.4 |  |
| Excess tax benefit from share-based compensation (c) |  |  | — |  |  |  | (0.2 | ) |  |  | (0.2 | ) |  |  | — |  |  |  | (2.7 | ) |  |  | (2.7 | ) |
| Other tax items, net (c) |  |  | — |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | — |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 178.1 |  |  | $ | (32.5 | ) |  | $ | 145.6 |  |  | $ | 157.2 |  |  | $ | (31.4 | ) |  | $ | 125.8 |  |
| Earnings per share - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 3.99 |  |  |  |  |  |  |  |  |  |  | $ | 3.41 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Special product quality adjustments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (b) |  |  |  |  |  |  |  |  |  |  | 0.09 |  |  |  |  |  |  |  |  |  |  |  | 0.06 |  |
| Excess tax benefit from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.08 | ) |
| Other tax items, net (c) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Adjusted earnings per share - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 4.10 |  |  |  |  |  |  |  |  |  |  | $ | 3.40 |  |

[0001193125-22-270358:8k_2_02:67]
| (a) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-22-270358:8k_2_02:68]
| (b) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-22-270358:8k_2_02:69]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-22-270358:8k_2_02:70]
| (d) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-22-270358:8k_2_02:71]
|  |  | For the Nine Months Ended September 30,(Unaudited) |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 496.3 |  |  | $ | (93.6 | ) |  | $ | 402.7 |  |  | $ | 469.9 |  |  | $ | (89.4 | ) |  | $ | 380.5 |  |
| Restructuring charges |  |  | 1.2 |  |  |  | (0.2 | ) |  |  | 1.0 |  |  |  | 1.6 |  |  |  | (0.3 | ) |  |  | 1.3 |  |
| Pension settlements |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |  |  | 1.1 |  |  |  | (0.2 | ) |  |  | 0.9 |  |
| Special product quality adjustments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.0 | ) |  |  | 0.2 |  |  |  | (0.8 | ) |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (b) |  |  | 7.9 |  |  |  | (1.2 | ) |  |  | 6.7 |  |  |  | 8.7 |  |  |  | (1.7 | ) |  |  | 7.0 |  |
| Excess tax expense (benefit) from share-based compensation (c) |  |  | — |  |  |  | 0.3 |  |  |  | 0.3 |  |  |  | — |  |  |  | (6.4 | ) |  |  | (6.4 | ) |
| Other tax items, net (c) |  |  | — |  |  |  | (0.8 | ) |  |  | (0.8 | ) |  |  | — |  |  |  | 2.3 |  |  |  | 2.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 505.7 |  |  | $ | (95.6 | ) |  | $ | 410.1 |  |  | $ | 480.3 |  |  | $ | (95.5 | ) |  | $ | 384.8 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 11.22 |  |  |  |  |  |  |  |  |  |  | $ | 10.10 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Special product quality adjustments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (b) |  |  |  |  |  |  |  |  |  |  | 0.18 |  |  |  |  |  |  |  |  |  |  |  | 0.20 |  |
| Excess tax expense (benefit) from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | (0.17 | ) |
| Other tax items, net (c) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |  |  |  |  |  |  |  |  |  |  | 0.06 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 11.43 |  |  |  |  |  |  |  |  |  |  | $ | 10.23 |  |

[0001193125-22-270358:8k_2_02:72]
| (a) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-22-270358:8k_2_02:73]
| (b) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-22-270358:8k_2_02:74]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-22-270358:8k_2_02:75]
| (d) | The impact of excess tax expense (benefit) from the change in share-based compensation also impacts the Company’s diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount. |

[0001193125-22-270358:8k_2_02:76]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-22-270358:8k_2_02:77]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
|  |  | (Unaudited) |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts (a) |  | $ | 0.3 |  |  | $ | (0.2 | ) |  | $ | (0.1 | ) |  | $ | (0.9 | ) |
| Foreign currency exchange losses (gains) (a) |  |  | 0.3 |  |  |  | — |  |  |  | (0.5 | ) |  |  | (1.6 | ) |
| Gain on disposal of fixed assets (a) |  |  | (0.4 | ) |  |  | (0.1 | ) |  |  | (1.3 | ) |  |  | (0.6 | ) |
| Other operating income (a) |  |  | (0.2 | ) |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (0.9 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | — |  |  |  | 0.2 |  |  |  | 1.2 |  |  |  | 0.1 |  |
| Environmental liabilities and special litigation charges (b) |  |  | 3.1 |  |  |  | 2.2 |  |  |  | 6.2 |  |  |  | 7.3 |  |
| Charges incurred related to COVID-19 pandemic (b) |  |  | 0.2 |  |  |  | 0.8 |  |  |  | 0.8 |  |  |  | 1.9 |  |
| Other items, net (b) |  |  | — |  |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.6 | ) |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 3.3 |  |  | $ | 2.1 |  |  | $ | 5.4 |  |  | $ | 4.7 |  |

[0001193125-22-270358:8k_2_02:78]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-22-270358:8k_2_02:79]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-22-270358:8k_2_02:80]
Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares
Outstanding - Diluted, a Non-GAAP measure (shares in millions):

[0001193125-22-270358:8k_2_02:81]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Average shares outstanding - diluted, a GAAP measure |  |  | 35.5 |  |  |  | 37.0 |  |  |  | 35.9 |  |  |  | 37.7 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure |  |  | 35.5 |  |  |  | 37.0 |  |  |  | 35.9 |  |  |  | 37.6 |  |

[0001193125-22-270358:8k_2_02:82]
Reconciliation of Net Cash Provided By Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-22-270358:8k_2_02:83]
|  |  | For the Three MonthsEnded September 30, |  |  | For the Nine MonthsEnded September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net cash provided by operating activities |  | $ | 170.9 |  |  | $ | 221.8 |  |  | $ | 170.1 |  |  | $ | 396.3 |  |
| Purchases of property, plant and equipment |  |  | (20.3 | ) |  |  | (23.0 | ) |  |  | (67.0 | ) |  |  | (68.5 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.7 |  |  |  | 0.1 |  |  |  | 1.2 |  |  |  | 0.7 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 151.3 |  |  | $ | 198.9 |  |  | $ | 104.3 |  |  | $ | 328.5 |  |

[0001193125-22-270358:8k_2_02:84]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | Trailing TwelveMonths toSeptember 30,2022 |  |
| Adjusted EBIT (a) |  | $ | 635.6 |  |
| Depreciation and amortization expense (b) |  |  | 73.1 |  |
| EBITDA (a + b) |  | $ | 708.7 |  |
| Total debt at September 30, 2022 (c) |  | $ | 1,604.5 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.3 |  |

[0001193125-22-270358:8k_2_02:85]
Reconciliation of Income from Continuing Operations Before Income Taxes, a GAAP measure to Adjusted EBIT, a Non-GAAP measure

[0001193125-22-270358:8k_2_02:86]
|  |  | Trailing TwelveMonths toSeptember 30,2022 |  |
| Income from continuing operations before income taxes, a GAAP measure |  |  | 586.5 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit |  |  | 13.4 |  |
| Special product quality adjustments |  |  | (1.4 | ) |
| Restructuring charges |  |  | 1.4 |  |
| Interest expense, net |  |  | 32.3 |  |
| Pension settlements |  |  | 0.4 |  |
| Other expense (income), net |  |  | 3.0 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  | 635.6 |  |
