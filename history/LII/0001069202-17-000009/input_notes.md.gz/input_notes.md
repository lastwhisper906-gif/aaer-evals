# LII notes — 0001069202-17-000009


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-17-000009:notes:1]
[same as prior period, unchanged from 0001069202-17-000005:notes:1]

[0001069202-17-000009:notes:2]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 250.0 |  |  | $ | 250.0 |  |
| Less: Beneficial interest sold | 250.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-17-000009:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-17-000009:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-17-000009:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-17-000009:notes:6]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.45 | % |  | 2.00 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-17-000009:notes:7]
[same as prior period, unchanged from 0001069202-17-000005:notes:7]

[0001069202-17-000009:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2017, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-17-000009:notes:9]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-17-000009:notes:10]
Commitments and Contingencies:

[0001069202-17-000009:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-17-000009:notes:12]
We offer warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-17-000009:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000009:notes:14]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 32.5 |  |  | $ | 30.0 |  |
| Other liabilities | 73.1 |  |  | 71.1 |  |
| Total warranty liability | $ | 105.6 |  |  | $ | 101.1 |  |

[0001069202-17-000009:notes:15]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2017 were as follows (in millions):

[0001069202-17-000009:notes:16]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (11.6 | ) |
| Changes resulting from issuance of new warranties | 19.6 |  |
| Changes in estimates associated with pre-existing liabilities | (4.2 | ) |
| Changes in foreign currency translation rates and other | 0.7 |  |
| Total warranty liability as of June 30, 2017 | $ | 105.6 |  |

[0001069202-17-000009:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. We currently estimate our probable liability for a certain supplier quality issue within a range of $0.9 million and $9.1 million with all amounts in that range equally likely. We have accrued a $0.9 million liability in Accrued expenses on the Consolidated Balance Sheet at June 30, 2017. The supplier is reimbursing us for the majority of the costs related to this liability.

[0001069202-17-000009:notes:18]
We have identified a product quality issue in a residential heating and cooling product line in the Residential Heating & Cooling  segment that results from a defective vendor-supplied component.  This defect has been isolated, the vendor has begun supplying corrected components, and we have begun installing the corrected components.  For the quarter ended June 30, 2017, we recorded an expense of $5.2 million relating to total estimated repair costs.  The expense related to this product quality issue has been classified in Cost of goods sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses on the Consolidated Balance Sheet.

[0001069202-17-000009:notes:19]
Litigation

[0001069202-17-000009:notes:20]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-17-000009:notes:21]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2017 and 2016, expense for asbestos-related litigation was $2.4 million and $1.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.

[0001069202-17-000009:notes:22]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants. The alleged payment was purportedly made to release a shipment of goods being held by Russian customs officials due to inaccurate paperwork. The value of the shipment was approximately €62,000 (approximately US $68,500). The allegations are related to our subsidiary in Russia, which had 2016 annual sales of US $4 million. The scope of the investigation was later expanded to include our operations in Poland and Ukraine. To date, the investigation has not resulted in any evidence of other potentially improper payments. However, the investigation has raised questions regarding possible irregularities with respect to possible non-compliance with customs documents and procedures related to these operations.  The investigation is ongoing. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.

[0001069202-17-000009:notes:23]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-17-000009:notes:24]
[same as prior period, unchanged from 0001069202-17-000005:notes:23]

[0001069202-17-000009:notes:25]
[same as prior period, unchanged from 0001069202-17-000005:notes:24]

[0001069202-17-000009:notes:26]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 2.8 |  |  | $ | (3.4 | ) |  | $ | 5.9 |  |  | $ | (8.2 | ) |  | Cost of goods sold |
| Income tax (expense)/benefit |  | (1.0 | ) |  | 1.2 |  |  | (2.1 | ) |  | 2.9 |  |  | Provision for income taxes |
| Net of tax |  | $ | 1.8 |  |  | $ | (2.2 | ) |  | $ | 3.8 |  |  | $ | (5.3 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.9 | ) |  | $ | (1.4 | ) |  | $ | (3.6 | ) |  | $ | (3.1 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.6 |  |  | 0.5 |  |  | 1.1 |  |  | 1.0 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.3 | ) |  | $ | (0.9 | ) |  | $ | (2.5 | ) |  | $ | (2.1 | ) |  |  |
| Total reclassifications from AOCL |  | $ | 0.5 |  |  | $ | (3.1 | ) |  | $ | 1.3 |  |  | $ | (7.4 | ) |  |  |

[0001069202-17-000009:notes:27]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2017 (in millions):

[0001069202-17-000009:notes:28]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2016 |  | $ | 5.6 |  |  | $ | 2.3 |  |  | $ | (130.0 | ) |  | $ | (73.0 | ) |  | $ | (195.1 | ) |
| Other comprehensive income (loss) before reclassifications |  | 4.6 |  |  | 0.1 |  |  | (4.0 | ) |  | 29.2 |  |  | 29.9 |  |
| Amounts reclassified from AOCL |  | (3.8 | ) |  | — |  |  | 2.5 |  |  | — |  |  | (1.3 | ) |
| Net other comprehensive income (loss) |  | 0.8 |  |  | 0.1 |  |  | (1.5 | ) |  | 29.2 |  |  | 28.6 |  |
| Balance as of June 30, 2017 |  | $ | 6.4 |  |  | $ | 2.4 |  |  | $ | (131.5 | ) |  | $ | (43.8 | ) |  | $ | (166.5 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-17-000009:notes:29]
[same as prior period, unchanged from 0001069202-17-000005:notes:28]

[0001069202-17-000009:notes:30]
[same as prior period, unchanged from 0001069202-17-000005:notes:29]

[0001069202-17-000009:notes:31]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of June 30, 2017 and December 31, 2016 and for the three and six months ended June 30, 2017 and 2016 are shown on the following pages.

[0001069202-17-000009:notes:32]
[same as prior period, unchanged from 0001069202-17-000005:notes:31]

[0001069202-17-000009:notes:33]
[same as prior period, unchanged from 0001069202-17-000005:notes:32]

[0001069202-17-000009:notes:34]
As of June 30, 2017

[0001069202-17-000009:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 3.4 |  |  | $ | 24.9 |  |  | $ | 33.0 |  |  | $ | — |  |  | $ | 61.3 |  |
| Accounts and notes receivable, net | — |  |  | 49.0 |  |  | 640.9 |  |  | — |  |  | 689.9 |  |
| Inventories, net | — |  |  | 414.2 |  |  | 136.9 |  |  | (12.3 | ) |  | 538.8 |  |
| Other assets | 14.5 |  |  | 52.4 |  |  | 63.8 |  |  | (54.0 | ) |  | 76.7 |  |
| Total current assets | 17.9 |  |  | 540.5 |  |  | 874.6 |  |  | (66.3 | ) |  | 1,366.7 |  |
| Property, plant and equipment, net | — |  |  | 243.8 |  |  | 132.5 |  |  | (4.6 | ) |  | 371.7 |  |
| Goodwill | — |  |  | 134.9 |  |  | 64.1 |  |  | — |  |  | 199.0 |  |
| Investment in subsidiaries | 1,095.6 |  |  | 531.1 |  |  | (0.6 | ) |  | (1,626.1 | ) |  | — |  |
| Deferred income taxes | 11.9 |  |  | 112.3 |  |  | 31.8 |  |  | (14.7 | ) |  | 141.3 |  |
| Other assets, net | 1.7 |  |  | 40.4 |  |  | 27.1 |  |  | (2.1 | ) |  | 67.1 |  |
| Intercompany receivables (payables), net | (161.4 | ) |  | 153.6 |  |  | 81.0 |  |  | (73.2 | ) |  | — |  |
| Total assets | $ | 965.7 |  |  | $ | 1,756.6 |  |  | $ | 1,210.5 |  |  | $ | (1,787.0 | ) |  | $ | 2,145.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 251.3 |  |  | $ | — |  |  | $ | 251.3 |  |
| Current maturities of long-term debt | 14.4 |  |  | 0.3 |  |  | 0.3 |  |  | — |  |  | 15.0 |  |
| Accounts payable | 21.5 |  |  | 291.6 |  |  | 130.0 |  |  | (0.6 | ) |  | 442.5 |  |
| Accrued expenses | 2.0 |  |  | 201.2 |  |  | 54.0 |  |  | — |  |  | 257.2 |  |
| Income taxes payable | 9.2 |  |  | 51.1 |  |  | 42.4 |  |  | (79.2 | ) |  | 23.5 |  |
| Total current liabilities | 47.1 |  |  | 544.2 |  |  | 478.0 |  |  | (79.8 | ) |  | 989.5 |  |
| Long-term debt | 907.9 |  |  | 14.4 |  |  | 0.3 |  |  | — |  |  | 922.6 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.1 |  |  | — |  |  | — |  |  | 2.1 |  |
| Pensions | — |  |  | 76.5 |  |  | 13.0 |  |  | — |  |  | 89.5 |  |
| Other liabilities | — |  |  | 122.6 |  |  | 11.4 |  |  | (2.5 | ) |  | 131.5 |  |
| Total liabilities | 955.0 |  |  | 759.8 |  |  | 502.7 |  |  | (82.3 | ) |  | 2,135.2 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 10.7 |  |  | 996.8 |  |  | 707.8 |  |  | (1,704.7 | ) |  | 10.6 |  |
| Total liabilities and stockholders' equity | $ | 965.7 |  |  | $ | 1,756.6 |  |  | $ | 1,210.5 |  |  | $ | (1,787.0 | ) |  | $ | 2,145.8 |  |

[0001069202-17-000009:notes:36]
[same as prior period, unchanged from 0001069202-17-000005:notes:35]

[0001069202-17-000009:notes:37]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 17.1 |  |  | $ | 31.9 |  |  | $ | — |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net | — |  |  | 30.6 |  |  | 439.2 |  |  | — |  |  | 469.8 |  |
| Inventories, net | — |  |  | 314.7 |  |  | 108.9 |  |  | (5.1 | ) |  | 418.5 |  |
| Other assets | 12.8 |  |  | 48.8 |  |  | 67.5 |  |  | (61.7 | ) |  | 67.4 |  |
| Total current assets | 14.0 |  |  | 411.2 |  |  | 647.5 |  |  | (66.8 | ) |  | 1,005.9 |  |
| Property, plant and equipment, net | — |  |  | 237.6 |  |  | 123.8 |  |  | — |  |  | 361.4 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 1,166.9 |  |  | 524.7 |  |  | (0.5 | ) |  | (1,691.1 | ) |  | — |  |
| Deferred income taxes | 6.8 |  |  | 113.5 |  |  | 31.1 |  |  | (14.7 | ) |  | 136.7 |  |
| Other assets, net | 3.6 |  |  | 40.0 |  |  | 19.0 |  |  | (1.4 | ) |  | 61.2 |  |
| Intercompany (payables) receivables, net | (382.4 | ) |  | 375.2 |  |  | 80.4 |  |  | (73.2 | ) |  | — |  |
| Total assets | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | — |  |  | $ | 52.4 |  |
| Current maturities of long-term debt | 199.3 |  |  | 0.4 |  |  | 0.4 |  |  | — |  |  | 200.1 |  |
| Accounts payable | 18.5 |  |  | 248.5 |  |  | 94.2 |  |  | — |  |  | 361.2 |  |
| Accrued expenses | 6.3 |  |  | 206.3 |  |  | 53.3 |  |  | — |  |  | 265.9 |  |
| Income taxes (receivable) payable | (54.0 | ) |  | 89.8 |  |  | 52.5 |  |  | (79.3 | ) |  | 9.0 |  |
| Total current liabilities | 170.1 |  |  | 545.0 |  |  | 252.8 |  |  | (79.3 | ) |  | 888.6 |  |
| Long-term debt | 600.9 |  |  | 14.5 |  |  | 0.3 |  |  | — |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.8 |  |  | — |  |  | — |  |  | 2.8 |  |
| Pensions | — |  |  | 75.5 |  |  | 12.0 |  |  | — |  |  | 87.5 |  |
| Other liabilities | — |  |  | 119.1 |  |  | 11.1 |  |  | (2.5 | ) |  | 127.7 |  |
| Total liabilities | 771.0 |  |  | 756.9 |  |  | 276.2 |  |  | (81.8 | ) |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 37.9 |  |  | 1,080.2 |  |  | 685.3 |  |  | (1,765.4 | ) |  | 38.0 |  |
| Total liabilities and stockholders' equity | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |

[0001069202-17-000009:notes:38]
[same as prior period, unchanged from 0001069202-17-000005:notes:37]

[0001069202-17-000009:notes:39]
For the Three Months Ended June 30, 2017

[0001069202-17-000009:notes:40]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 968.7 |  |  | $ | 310.9 |  |  | $ | (177.5 | ) |  | $ | 1,102.1 |  |
| Cost of goods sold | — |  |  | 672.7 |  |  | 264.5 |  |  | (175.9 | ) |  | 761.3 |  |
| Gross profit | — |  |  | 296.0 |  |  | 46.4 |  |  | (1.6 | ) |  | 340.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 147.9 |  |  | 20.8 |  |  | (0.2 | ) |  | 168.5 |  |
| Losses (gains) and other expenses, net | 0.3 |  |  | 1.9 |  |  | 0.2 |  |  | (0.1 | ) |  | 2.3 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (120.6 | ) |  | (17.5 | ) |  | (4.5 | ) |  | 137.1 |  |  | (5.5 | ) |
| Operating income | 120.3 |  |  | 163.7 |  |  | 29.8 |  |  | (138.4 | ) |  | 175.4 |  |
| Interest expense, net | 7.4 |  |  | (0.8 | ) |  | 1.6 |  |  | — |  |  | 8.2 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 112.9 |  |  | 164.5 |  |  | 28.3 |  |  | (138.4 | ) |  | 167.3 |  |
| Provision for income taxes | (2.6 | ) |  | 47.2 |  |  | 6.5 |  |  | (0.2 | ) |  | 50.9 |  |
| Income from continuing operations | 115.5 |  |  | 117.3 |  |  | 21.8 |  |  | (138.2 | ) |  | 116.4 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (0.9 | ) |  | — |  |  | (0.9 | ) |
| Net income | $ | 115.5 |  |  | $ | 117.3 |  |  | $ | 20.9 |  |  | $ | (138.2 | ) |  | $ | 115.5 |  |
| Other comprehensive income (loss), net of tax | (1.5 | ) |  | 0.3 |  |  | 10.2 |  |  | 1.1 |  |  | 10.1 |  |
| Comprehensive income | $ | 114.0 |  |  | $ | 117.6 |  |  | $ | 31.1 |  |  | $ | (137.1 | ) |  | $ | 125.6 |  |

[0001069202-17-000009:notes:41]
For the Six Months Ended June 30, 2017

[0001069202-17-000009:notes:42]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,655.0 |  |  | $ | 569.7 |  |  | $ | (329.1 | ) |  | $ | 1,895.6 |  |
| Cost of goods sold | — |  |  | 1,186.0 |  |  | 482.1 |  |  | (324.3 | ) |  | 1,343.8 |  |
| Gross profit | — |  |  | 469.0 |  |  | 87.6 |  |  | (4.8 | ) |  | 551.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 278.5 |  |  | 42.8 |  |  | (0.4 | ) |  | 320.9 |  |
| Losses (gains) and other expenses, net | 0.9 |  |  | 3.8 |  |  | 0.8 |  |  | (0.1 | ) |  | 5.4 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Income from equity method investments | (169.3 | ) |  | (30.1 | ) |  | (9.3 | ) |  | 197.8 |  |  | (10.9 | ) |
| Operating income | 168.4 |  |  | 216.7 |  |  | 53.2 |  |  | (202.1 | ) |  | 236.2 |  |
| Interest expense, net | 14.7 |  |  | (1.7 | ) |  | 2.7 |  |  | — |  |  | 15.7 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 153.7 |  |  | 218.4 |  |  | 50.6 |  |  | (202.1 | ) |  | 220.6 |  |
| Provision for income taxes | (5.3 | ) |  | 54.3 |  |  | 12.7 |  |  | (1.0 | ) |  | 60.7 |  |
| Income from continuing operations | 159.0 |  |  | 164.1 |  |  | 37.9 |  |  | (201.1 | ) |  | 159.9 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (0.9 | ) |  | — |  |  | (0.9 | ) |
| Net income | $ | 159.0 |  |  | $ | 164.1 |  |  | $ | 37.0 |  |  | $ | (201.1 | ) |  | $ | 159.0 |  |
| Other comprehensive income (loss), net of tax | $ | (72.8 | ) |  | $ | (29.1 | ) |  | $ | 21.0 |  |  | $ | 109.5 |  |  | $ | 28.6 |  |
| Comprehensive income | $ | 86.2 |  |  | $ | 135.0 |  |  | $ | 58.0 |  |  | $ | (91.6 | ) |  | $ | 187.6 |  |

[0001069202-17-000009:notes:43]
For the Three Months Ended June 30, 2016

[0001069202-17-000009:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 884.5 |  |  | $ | 183.4 |  |  | $ | (48.7 | ) |  | $ | 1,019.2 |  |
| Cost of goods sold | — |  |  | 611.7 |  |  | 141.2 |  |  | (48.7 | ) |  | 704.2 |  |
| Gross profit | — |  |  | 272.8 |  |  | 42.2 |  |  | — |  |  | 315.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 139.9 |  |  | 19.5 |  |  | — |  |  | 159.4 |  |
| Losses and other expenses, net | — |  |  | 0.7 |  |  | (0.2 | ) |  | (0.1 | ) |  | 0.4 |  |
| Restructuring gains | — |  |  | 1.0 |  |  | (0.2 | ) |  | — |  |  | 0.8 |  |
| Income from equity method investments | (115.5 | ) |  | (9.5 | ) |  | (5.2 | ) |  | 123.9 |  |  | (6.3 | ) |
| Operating income | 115.5 |  |  | 140.7 |  |  | 28.3 |  |  | (123.8 | ) |  | 160.7 |  |
| Interest expense, net | 6.3 |  |  | (0.5 | ) |  | 1.0 |  |  | — |  |  | 6.8 |  |
| Other expense, net | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Income from continuing operations before income taxes | 109.2 |  |  | 141.2 |  |  | 27.5 |  |  | (123.8 | ) |  | 154.1 |  |
| Provision for income taxes | (1.5 | ) |  | 34.8 |  |  | 9.5 |  |  | 0.1 |  |  | 42.9 |  |
| Income from continuing operations | 110.7 |  |  | 106.4 |  |  | 18.0 |  |  | (123.9 | ) |  | 111.2 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Net income | $ | 110.7 |  |  | $ | 106.4 |  |  | $ | 17.5 |  |  | $ | (123.9 | ) |  | $ | 110.7 |  |
| Other comprehensive loss, net of tax | 0.3 |  |  | 0.3 |  |  | 2.7 |  |  | 0.8 |  |  | 4.1 |  |
| Comprehensive income (loss) | $ | 111.0 |  |  | $ | 106.7 |  |  | $ | 20.2 |  |  | $ | (123.1 | ) |  | $ | 114.8 |  |

[0001069202-17-000009:notes:45]
For the Six Months Ended June 30, 2016

[0001069202-17-000009:notes:46]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,498.3 |  |  | $ | 327.2 |  |  | $ | (91.1 | ) |  | $ | 1,734.4 |  |
| Cost of goods sold | — |  |  | 1,072.4 |  |  | 252.5 |  |  | (89.1 | ) |  | 1,235.8 |  |
| Gross profit | — |  |  | 425.9 |  |  | 74.7 |  |  | (2.0 | ) |  | 498.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 258.6 |  |  | 41.1 |  |  | — |  |  | 299.7 |  |
| Losses and other expenses, net | (0.6 | ) |  | 3.1 |  |  | 2.2 |  |  | — |  |  | 4.7 |  |
| Restructuring gains | — |  |  | 1.0 |  |  | (0.4 | ) |  | — |  |  | 0.6 |  |
| Income from equity method investments | (143.5 | ) |  | (9.5 | ) |  | (9.2 | ) |  | 151.4 |  |  | (10.8 | ) |
| Operating income | 144.1 |  |  | 172.7 |  |  | 41.0 |  |  | (153.4 | ) |  | 204.4 |  |
| Interest expense, net | 11.7 |  |  | (1.0 | ) |  | 2.0 |  |  | — |  |  | 12.7 |  |
| Other expense, net | — |  |  | — |  |  | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Income from continuing operations before income taxes | 132.4 |  |  | 173.7 |  |  | 39.3 |  |  | (153.4 | ) |  | 192.0 |  |
| Provision for income taxes | (3.1 | ) |  | 46.8 |  |  | 12.9 |  |  | (0.7 | ) |  | 55.9 |  |
| Income from continuing operations | 135.5 |  |  | 126.9 |  |  | 26.4 |  |  | (152.7 | ) |  | 136.1 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Net income | $ | 135.5 |  |  | $ | 126.9 |  |  | $ | 25.9 |  |  | $ | (152.7 | ) |  | $ | 135.6 |  |
| Other comprehensive loss, net of tax | 4.9 |  |  | 2.4 |  |  | 9.0 |  |  | 1.8 |  |  | 18.1 |  |
| Comprehensive income (loss) | $ | 140.4 |  |  | $ | 129.3 |  |  | $ | 34.9 |  |  | $ | (150.9 | ) |  | $ | 153.7 |  |

[0001069202-17-000009:notes:47]
[same as prior period, unchanged from 0001069202-17-000005:notes:42]

[0001069202-17-000009:notes:48]
For the Six Months Ended June 30, 2017

[0001069202-17-000009:notes:49]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 326.1 |  |  | $ | (191.4 | ) |  | $ | (183.0 | ) |  | $ | — |  |  | $ | (48.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (37.2 | ) |  | (6.2 | ) |  | — |  |  | (43.4 | ) |
| Net cash used in investing activities | — |  |  | (37.1 | ) |  | (6.1 | ) |  | — |  |  | (43.2 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.1 | ) |  | — |  |  | (1.1 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 200.0 |  |  | — |  |  | 200.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | (200.0 | ) |  | (0.2 | ) |  | (0.3 | ) |  | — |  |  | (200.5 | ) |
| Borrowings from credit facility | 1,352.5 |  |  | — |  |  | — |  |  | — |  |  | 1,352.5 |  |
| Payments on credit facility | (1,031.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,031.0 | ) |
| Proceeds from employee stock purchases | 1.5 |  |  | — |  |  | — |  |  | — |  |  | 1.5 |  |
| Repurchases of common stock | (175.0 | ) |  | — |  |  | — |  |  | — |  |  | (175.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (14.1 | ) |  | — |  |  | — |  |  | — |  |  | (14.1 | ) |
| Intercompany debt | (25.5 | ) |  | 6.4 |  |  | 19.1 |  |  | — |  |  | — |  |
| Intercompany financing activity | (195.4 | ) |  | 230.1 |  |  | (34.7 | ) |  | — |  |  | — |  |
| Cash dividends paid | (36.9 | ) |  | — |  |  | — |  |  | — |  |  | (36.9 | ) |
| Net cash provided by financing activities | (323.9 | ) |  | 236.3 |  |  | 183.0 |  |  | — |  |  | 95.4 |  |
| Increase in cash and cash equivalents | 2.2 |  |  | 7.8 |  |  | (6.1 | ) |  | — |  |  | 3.9 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 7.2 |  |  | — |  |  | 7.2 |  |
| Cash and cash equivalents, beginning of period | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of period | $ | 3.4 |  |  | $ | 24.9 |  |  | $ | 33.0 |  |  | $ | — |  |  | $ | 61.3 |  |

[0001069202-17-000009:notes:50]
For the Six Months Ended June 30, 2016

[0001069202-17-000009:notes:51]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 62.1 |  |  | $ | (51.3 | ) |  | $ | (36.1 | ) |  | $ | — |  |  | $ | (25.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (36.8 | ) |  | (4.9 | ) |  | — |  |  | (41.7 | ) |
| Net cash used in investing activities | — |  |  | (36.8 | ) |  | (4.9 | ) |  | — |  |  | (41.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (20.0 | ) |  | — |  |  | (20.0 | ) |
| Long-term debt payments | (7.5 | ) |  | (0.5 | ) |  | (0.2 | ) |  | — |  |  | (8.2 | ) |
| Borrowings from credit facility | 1,184.5 |  |  | — |  |  | — |  |  | — |  |  | 1,184.5 |  |
| Payments on credit facility | (864.0 | ) |  | — |  |  | — |  |  | — |  |  | (864.0 | ) |
| Proceeds from employee stock purchases | 1.3 |  |  | — |  |  | — |  |  | — |  |  | 1.3 |  |
| Repurchases of common stock | (200.0 | ) |  | — |  |  | — |  |  | — |  |  | (200.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (21.4 | ) |  | — |  |  | — |  |  | — |  |  | (21.4 | ) |
| Intercompany debt | (11.9 | ) |  | (4.3 | ) |  | 16.2 |  |  | — |  |  | — |  |
| Intercompany financing activity | (110.2 | ) |  | 109.1 |  |  | 1.1 |  |  | — |  |  | — |  |
| Intercompany investments | — |  | — |  | — |  |  | — |  |  | — |  |  | — |  |
| Cash dividends paid | (31.8 | ) |  | — |  |  | — |  |  | — |  |  | (31.8 | ) |
| Net cash provided by financing activities | (61.0 | ) |  | 104.3 |  |  | 37.6 |  |  | — |  |  | 80.9 |  |
| Increase in cash and cash equivalents | 1.1 |  |  | 16.2 |  |  | (3.4 | ) |  | — |  |  | 13.9 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Cash and cash equivalents, beginning of period | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of period | $ | 1.6 |  |  | $ | 24.0 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 54.7 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-17-000009:notes:52]
Lines of Credit and Financing Arrangements:

[0001069202-17-000009:notes:53]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000009:notes:54]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 250.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.3 |  |  | 2.4 |  |
| Total short-term debt | $ | 251.3 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.6 |  |  | $ | 0.8 |  |
| Domestic credit facility | 15.0 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 15.0 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.8 |  |  | $ | 15.0 |  |
| Domestic credit facility | 562.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.7 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 922.6 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,188.9 |  |  | $ | 868.2 |  |

[0001069202-17-000009:notes:55]
Short-Term Debt

[0001069202-17-000009:notes:56]
Foreign Obligations

[0001069202-17-000009:notes:57]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.3 million and $2.4 million of foreign obligations as of June 30, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.8 million  and $20.4 million during the six months ended June 30, 2017 and 2016, respectively. Repayments on the facilities were $1.8 million and $20.0 million during the six months ended June 30, 2017 and 2016, respectively.

[0001069202-17-000009:notes:58]
Asset Securitization Program

[0001069202-17-000009:notes:59]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-17-000009:notes:60]
The ASP provides for a maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-17-000009:notes:61]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The rates as of June 30, 2017 and December 31, 2016 were 1.90% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-17-000009:notes:62]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2017, we believe we were in compliance with all covenant requirements.

[0001069202-17-000009:notes:63]
Long-Term Debt

[0001069202-17-000009:notes:64]
Domestic Credit Facility

[0001069202-17-000009:notes:65]
On August 30, 2016, we replaced an earlier credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $577.5 million, of which $220.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of June 30, 2017. Subject to covenant limitations, $288.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-17-000009:notes:66]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-17-000009:notes:67]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-17-000009:notes:68]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-17-000009:notes:69]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-17-000009:notes:70]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2017, we believe we were in compliance with all covenant requirements.

[0001069202-17-000009:notes:71]
Senior Unsecured Notes

[0001069202-17-000009:notes:72]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also repaid $200.0 million of senior unsecured notes issued in 2010 that matured on May 15, 2017.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2017, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-17-000009:notes:73]
[same as prior period, unchanged from 0001069202-17-000005:notes:68]

[0001069202-17-000009:notes:74]
[same as prior period, unchanged from 0001069202-17-000005:notes:69]

[0001069202-17-000009:notes:75]
[same as prior period, unchanged from 0001069202-17-000005:notes:70]

[0001069202-17-000009:notes:76]
[same as prior period, unchanged from 0001069202-17-000005:notes:71]

[0001069202-17-000009:notes:77]
[same as prior period, unchanged from 0001069202-17-000005:notes:72]

[0001069202-17-000009:notes:78]
[same as prior period, unchanged from 0001069202-17-000005:notes:73]

[0001069202-17-000009:notes:79]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flow hedges that are scheduled to mature through November 2018 and December 2017, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-17-000009:notes:80]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Unrealized gains on unsettled contracts | $ | (10.0 | ) |  | $ | (8.9 | ) |
| Income tax expense | 3.6 |  |  | 3.3 |  |
| Gains included in AOCL, net of tax (1) | $ | (6.4 | ) |  | $ | (5.6 | ) |

[0001069202-17-000009:notes:81]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $6.3 million of derivative gains into earnings within the next 12 months.

[0001069202-17-000009:notes:82]
[same as prior period, unchanged from 0001069202-17-000005:notes:77]

[0001069202-17-000009:notes:83]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Copper | 21.5 |  |  | 30.4 |  |

[0001069202-17-000009:notes:84]
[same as prior period, unchanged from 0001069202-17-000005:notes:79]

[0001069202-17-000009:notes:85]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 146.7 |  |  | 310.1 |  |
| Canadian Dollar | — |  |  | 24.9 |  |

[0001069202-17-000009:notes:86]
[same as prior period, unchanged from 0001069202-17-000005:notes:81]

[0001069202-17-000009:notes:87]
[same as prior period, unchanged from 0001069202-17-000005:notes:82]

[0001069202-17-000009:notes:88]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Copper | 2.0 |  |  | 2.4 |  |
| Aluminum | 2.0 |  |  | 2.6 |  |

[0001069202-17-000009:notes:89]
[same as prior period, unchanged from 0001069202-17-000005:notes:84]

[0001069202-17-000009:notes:90]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Notional Amounts (in local currency): |  |  |  |
| Chinese Yuan | 65.4 |  |  | 10.5 |  |
| Mexican Peso | 141.5 |  |  | 64.5 |  |
| Euro | 57.0 |  |  | 46.9 |  |
| Canadian Dollar | 50.1 |  |  | — |  |
| British Pound | 4.3 |  |  | 1.3 |  |
| Australian Dollar | 43.0 |  |  | — |  |
| New Zealand Dollar | 6.0 |  |  | — |  |
| Indian Rupee | 398.5 |  |  | 584.6 |  |

[0001069202-17-000009:notes:91]
[same as prior period, unchanged from 0001069202-17-000005:notes:86]

[0001069202-17-000009:notes:92]
[same as prior period, unchanged from 0001069202-17-000005:notes:87]

[0001069202-17-000009:notes:93]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of June 30, 2017 |  | As of December 31, 2016 |  | As of June 30, 2017 |  | As of December 31, 2016 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 9.1 |  |  | $ | 8.7 |  |  | $ | 1.4 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts | 0.8 |  |  | 0.5 |  |  | 1.0 |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.2 |  |  | 1.9 |  |  | — |  |  | 0.2 |  |
| Total Assets | $ | 10.1 |  |  | $ | 11.1 |  |  | $ | 2.4 |  |  | $ | 1.1 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | 0.4 |  |  | 0.8 |  |  | 0.2 |  |  | 3.2 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 0.2 |  |  | $ | 3.2 |  |

[0001069202-17-000009:notes:94]
[same as prior period, unchanged from 0001069202-17-000005:notes:89]

[0001069202-17-000009:notes:95]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amount of (Gain)/Loss reclassified from AOCL into Income (effective portion) (1) |  | $ | (2.8 | ) |  | $ | 3.4 |  |  | $ | (5.9 | ) |  | $ | 8.2 |  |
| Amount of Loss recognized in Net income (ineffective portion) (2) |  | $ | — |  |  | $ | — |  |  | $ | 1.1 |  |  | $ | 0.1 |  |

[0001069202-17-000009:notes:96]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amount of (Gain)/Loss Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | (0.2 | ) |  | $ | 0.1 |  |  | $ | (1.1 | ) |  | $ | 0.1 |  |
| Foreign currency forward contracts (2) |  | (3.1 | ) |  | (0.5 | ) |  | (3.9 | ) |  | (0.1 | ) |
|  |  | $ | (3.3 | ) |  | $ | (0.4 | ) |  | $ | (5.0 | ) |  | $ | — |  |

[0001069202-17-000009:notes:97]
[same as prior period, unchanged from 0001069202-17-000005:notes:92]

[0001069202-17-000009:notes:98]
[same as prior period, unchanged from 0001069202-17-000005:notes:93]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-17-000009:notes:99]
[same as prior period, unchanged from 0001069202-17-000005:notes:94]

[0001069202-17-000009:notes:100]
[same as prior period, unchanged from 0001069202-17-000005:notes:95]

[0001069202-17-000009:notes:101]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Stock-based compensation expense (1) | $ | 7.6 |  |  | $ | 8.6 |  |  | $ | 12.5 |  |  | $ | 14.8 |  |

[0001069202-17-000009:notes:102]
[same as prior period, unchanged from 0001069202-17-000005:notes:97]


## us-gaap:EarningsPerShareTextBlock

[0001069202-17-000009:notes:103]
[same as prior period, unchanged from 0001069202-17-000005:notes:98]

[0001069202-17-000009:notes:104]
[same as prior period, unchanged from 0001069202-17-000005:notes:99]

[0001069202-17-000009:notes:105]
[same as prior period, unchanged from 0001069202-17-000005:notes:100]

[0001069202-17-000009:notes:106]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net income | $ | 115.5 |  |  | $ | 110.7 |  |  | $ | 159.0 |  |  | $ | 135.6 |  |
| Add: Loss from discontinued operations | 0.9 |  |  | 0.5 |  |  | 0.9 |  |  | 0.5 |  |
| Income from continuing operations | $ | 116.4 |  |  | $ | 111.2 |  |  | $ | 159.9 |  |  | $ | 136.1 |  |
| Weighted-average shares outstanding – basic | 42.3 |  |  | 43.6 |  |  | 42.6 |  |  | 43.8 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.6 |  |  | 0.5 |  |  | 0.6 |  |  | 0.6 |  |
| Weighted-average shares outstanding – diluted | 42.9 |  |  | 44.1 |  |  | 43.2 |  |  | 44.4 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.75 |  |  | $ | 2.55 |  |  | $ | 3.76 |  |  | $ | 3.11 |  |
| Loss from discontinued operations | (0.02 | ) |  | (0.01 | ) |  | (0.02 | ) |  | (0.01 | ) |
| Net income | $ | 2.73 |  |  | $ | 2.54 |  |  | $ | 3.74 |  |  | $ | 3.10 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.71 |  |  | $ | 2.52 |  |  | $ | 3.70 |  |  | $ | 3.07 |  |
| Loss from discontinued operations | (0.02 | ) |  | (0.01 | ) |  | (0.02 | ) |  | (0.01 | ) |
| Net income | $ | 2.69 |  |  | $ | 2.51 |  |  | $ | 3.68 |  |  | $ | 3.06 |  |

[0001069202-17-000009:notes:107]
[same as prior period, unchanged from 0001069202-17-000005:notes:102]

[0001069202-17-000009:notes:108]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Weighted-average number of shares | — |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Price range per share | $ | — |  |  | $124.97-$131.94 |  | $ | 156.94 |  |  | $124.97-$131.94 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-17-000009:notes:109]
[same as prior period, unchanged from 0001069202-17-000005:notes:104]

[0001069202-17-000009:notes:110]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Senior unsecured notes | $ | 305.5 |  |  | $ | 499.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-17-000009:notes:111]
[same as prior period, unchanged from 0001069202-17-000005:notes:106]

[0001069202-17-000009:notes:112]
[same as prior period, unchanged from 0001069202-17-000005:notes:107]

[0001069202-17-000009:notes:113]
The methodologies used to determine the fair value of our financial assets and liabilities at June 30, 2017 were the same as those used at December 31, 2016.

[0001069202-17-000009:notes:114]
[same as prior period, unchanged from 0001069202-17-000005:notes:109]

[0001069202-17-000009:notes:115]
[same as prior period, unchanged from 0001069202-17-000005:notes:110]

[0001069202-17-000009:notes:116]
[same as prior period, unchanged from 0001069202-17-000005:notes:111]

[0001069202-17-000009:notes:117]
[same as prior period, unchanged from 0001069202-17-000005:notes:112]

[0001069202-17-000009:notes:118]
The following table presents the fair value of an investment in marketable equity securities, classified as Level 1 and related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000009:notes:119]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Investment in marketable equity securities | $ | 4.5 |  |  | $ | 4.4 |  |

[0001069202-17-000009:notes:120]
[same as prior period, unchanged from 0001069202-17-000005:notes:115]

[0001069202-17-000009:notes:121]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-17-000009:notes:122]
[same as prior period, unchanged from 0001069202-17-000005:notes:117]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-17-000009:notes:123]
[same as prior period, unchanged from 0001069202-17-000005:notes:118]

[0001069202-17-000009:notes:124]
The changes in the carrying amount of goodwill for the first six months of 2017, in total and by segment, are summarized in the table below (in millions):

[0001069202-17-000009:notes:125]
|  | Balance at December 31, 2016 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at June 30, 2017 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 60.1 |  |  | — |  |  | 1.3 |  |  | 61.4 |  |
| Refrigeration | 108.9 |  |  | — |  |  | 2.6 |  |  | 111.5 |  |
| Total Goodwill | $ | 195.1 |  |  | $ | — |  |  | $ | 3.9 |  |  | $ | 199.0 |  |

[0001069202-17-000009:notes:126]
[same as prior period, unchanged from 0001069202-17-000005:notes:121]

[0001069202-17-000009:notes:127]
[same as prior period, unchanged from 0001069202-17-000005:notes:122]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-17-000009:notes:128]
[same as prior period, unchanged from 0001069202-17-000005:notes:123]

[0001069202-17-000009:notes:129]
As of June 30, 2017, we had approximately $1.1 million in total gross unrecognized tax benefits. Of this amount, $1.1 million, if recognized, would be recorded through the Consolidated Statement of Operations. As of June 30, 2017, we had approximately $0.1 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification (“ASC”) Topic 740, Income Taxes.

[0001069202-17-000009:notes:130]
[same as prior period, unchanged from 0001069202-17-000005:notes:125]

[0001069202-17-000009:notes:131]
[same as prior period, unchanged from 0001069202-17-000005:notes:126]

[0001069202-17-000009:notes:132]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity. We recognized discrete tax benefits of $0.7 million and $8.1 million in the income taxes line item of our consolidated statements of operations for the three and six months ended June 30, 2017, respectively, related to excess tax benefits upon vesting or settlement in that period.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-17-000009:notes:133]
[same as prior period, unchanged from 0001069202-17-000005:notes:128]

[0001069202-17-000009:notes:134]
[same as prior period, unchanged from 0001069202-17-000005:notes:129]

[0001069202-17-000009:notes:135]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Finished goods | $ | 381.5 |  |  | $ | 287.2 |  |
| Work in process | 7.3 |  |  | 5.1 |  |
| Raw materials and parts | 207.2 |  |  | 183.4 |  |
| Subtotal | 596.0 |  |  | 475.7 |  |
| Excess of current cost over last-in, first-out cost | (57.2 | ) |  | (57.2 | ) |
| Total inventories, net | $ | 538.8 |  |  | $ | 418.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-17-000009:notes:136]
[same as prior period, unchanged from 0001069202-17-000005:notes:131]

[0001069202-17-000009:notes:137]
[same as prior period, unchanged from 0001069202-17-000005:notes:132]

[0001069202-17-000009:notes:138]
[same as prior period, unchanged from 0001069202-17-000005:notes:133]

[0001069202-17-000009:notes:139]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-17-000009:notes:140]
[same as prior period, unchanged from 0001069202-17-000005:notes:135]

[0001069202-17-000009:notes:141]
Recently Adopted Accounting Guidance

[0001069202-17-000009:notes:142]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations.  This is in comparison to the prior requirement that these excess tax benefits be recognized in additional paid-in capital. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity.

[0001069202-17-000009:notes:143]
We have adopted ASU 2016-09 effective January 1, 2017 on a prospective basis where permitted by the new standard. As a result of this adoption:

[0001069202-17-000009:notes:144]
| • | We recognized discrete tax benefits of $0.7 million and $8.1 million in the income taxes line item of our consolidated statements of operations for the three and six months ended June 30, 2017 respectively, related to excess tax benefits upon vesting or settlement in that period. |

[0001069202-17-000009:notes:145]
[same as prior period, unchanged from 0001069202-17-000005:notes:140]

[0001069202-17-000009:notes:146]
[same as prior period, unchanged from 0001069202-17-000005:notes:141]

[0001069202-17-000009:notes:147]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three and six months ended June 30, 2017. |

[0001069202-17-000009:notes:148]
[same as prior period, unchanged from 0001069202-17-000005:notes:143]

[0001069202-17-000009:notes:149]
[same as prior period, unchanged from 0001069202-17-000005:notes:144]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-17-000009:notes:150]
Pension and Post-Retirement Benefit Plans:

[0001069202-17-000009:notes:151]
[same as prior period, unchanged from 0001069202-17-000005:notes:146]

[0001069202-17-000009:notes:152]
|  | For the Three Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.2 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.1 |  |  | 3.9 |  |  | — |  |  | — |  |
| Expected return on plan assets | (5.4 | ) |  | (5.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.6 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.0 |  |  | 1.7 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | 0.3 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.3 |  |  | $ | 1.1 |  |  | $ | (0.2 | ) |  | $ | (0.4 | ) |

[0001069202-17-000009:notes:153]
|  | For the Six Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 2.5 |  |  | $ | 2.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 6.4 |  |  | 7.7 |  |  | — |  |  | — |  |
| Expected return on plan assets | (10.7 | ) |  | (10.8 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (1.2 | ) |  | (1.5 | ) |
| Recognized actuarial loss | 4.0 |  |  | 3.8 |  |  | 0.7 |  |  | 0.7 |  |
| Settlements and curtailments | 0.6 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 2.9 |  |  | $ | 3.0 |  |  | $ | (0.5 | ) |  | $ | (0.8 | ) |

[0001069202-17-000009:notes:154]
(1) All net periodic benefit cost for the three and six months ended June 30, 2017 and 2016 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-17-000009:notes:155]
[same as prior period, unchanged from 0001069202-17-000005:notes:149]

[0001069202-17-000009:notes:156]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 653.5 |  |  | $ | 574.5 |  |  | $ | 1,073.3 |  |  | $ | 951.8 |  |
| Commercial Heating & Cooling | 258.6 |  |  | 252.9 |  |  | 454.1 |  |  | 423.3 |  |
| Refrigeration | 190.0 |  |  | 191.8 |  |  | 368.2 |  |  | 359.3 |  |
|  | $ | 1,102.1 |  |  | $ | 1,019.2 |  |  | $ | 1,895.6 |  |  | $ | 1,734.4 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 140.5 |  |  | $ | 115.9 |  |  | $ | 182.9 |  |  | $ | 154.1 |  |
| Commercial Heating & Cooling | 44.7 |  |  | 47.4 |  |  | 63.8 |  |  | 61.7 |  |
| Refrigeration | 21.6 |  |  | 21.3 |  |  | 35.7 |  |  | 30.3 |  |
| Corporate and other | (23.9 | ) |  | (23.5 | ) |  | (34.8 | ) |  | (38.4 | ) |
| Total segment profit | 182.9 |  |  | 161.1 |  |  | 247.6 |  |  | 207.7 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special product quality adjustments | 5.2 |  |  | — |  |  | 5.2 |  |  | (0.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) | 2.2 |  |  | (0.4 | ) |  | 6.0 |  |  | 3.1 |  |
| Restructuring charges | 0.1 |  |  | 0.8 |  |  | 0.2 |  |  | 0.6 |  |
| Operating income | $ | 175.4 |  |  | $ | 160.7 |  |  | $ | 236.2 |  |  | $ | 204.4 |  |

[0001069202-17-000009:notes:157]
(1)  We define segment profit and loss as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-17-000009:notes:158]
[same as prior period, unchanged from 0001069202-17-000005:notes:152]

[0001069202-17-000009:notes:159]
[same as prior period, unchanged from 0001069202-17-000005:notes:153]

[0001069202-17-000009:notes:160]
[same as prior period, unchanged from 0001069202-17-000005:notes:154]

[0001069202-17-000009:notes:161]
| ◦ | Special legal contingency charges, |

[0001069202-17-000009:notes:162]
| ◦ | Asbestos-related litigation, |

[0001069202-17-000009:notes:163]
[same as prior period, unchanged from 0001069202-17-000005:notes:157]

[0001069202-17-000009:notes:164]
[same as prior period, unchanged from 0001069202-17-000005:notes:158]

[0001069202-17-000009:notes:165]
[same as prior period, unchanged from 0001069202-17-000005:notes:159]

[0001069202-17-000009:notes:166]
[same as prior period, unchanged from 0001069202-17-000005:notes:160]

[0001069202-17-000009:notes:167]
[same as prior period, unchanged from 0001069202-17-000005:notes:161]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-17-000009:notes:168]
[same as prior period, unchanged from 0001069202-17-000005:notes:162]

[0001069202-17-000009:notes:169]
[same as prior period, unchanged from 0001069202-17-000005:notes:163]

[0001069202-17-000009:notes:170]
[same as prior period, unchanged from 0001069202-17-000005:notes:164]

[0001069202-17-000009:notes:171]
[same as prior period, unchanged from 0001069202-17-000005:notes:165]

[0001069202-17-000009:notes:172]
|  | Charges Incurred in 2017 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | — |  |  | $ | 9.3 |  |  | $ | 9.3 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 2.5 |  |  | 2.5 |  |
| Lease termination | — |  |  | 0.2 |  |  | 0.2 |  |
| Other | 0.1 |  |  | 3.8 |  |  | 4.2 |  |
| Total restructuring charges | $ | 0.2 |  |  | $ | 15.8 |  |  | $ | 16.2 |  |

[0001069202-17-000009:notes:173]
[same as prior period, unchanged from 0001069202-17-000005:notes:167]

[0001069202-17-000009:notes:174]
|  | Charges Incurred in 2017 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Commercial Heating & Cooling | — |  |  | 1.1 |  |  | 1.1 |  |
| Refrigeration | 0.2 |  |  | 12.1 |  |  | 12.1 |  |
| Corporate & Other | — |  |  | 1.7 |  |  | 2.1 |  |
| Total restructuring charges | $ | 0.2 |  |  | $ | 15.8 |  |  | $ | 16.2 |  |

[0001069202-17-000009:notes:175]
[same as prior period, unchanged from 0001069202-17-000005:notes:169]

[0001069202-17-000009:notes:176]
|  | Balance as ofDecember 31, 2016 |  | Included inEarnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of June 30, 2017 |
| Severance and related expense | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |  | 0.1 |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.1 |  |  | (0.2 | ) |  | — |  |  | (0.1 | ) |
| Total restructuring accruals | $ | — |  |  | $ | 0.2 |  |  | $ | (0.3 | ) |  | $ | 0.1 |  |  | $ | — |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001069202-17-000009:notes:177]
[same as prior period, unchanged from 0001069202-17-000005:notes:171]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-17-000009:notes:178]
[same as prior period, unchanged from 0001069202-17-000005:notes:172]

[0001069202-17-000009:notes:179]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEuropeCentral America |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth AmericaCentral America |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-17-000009:notes:180]
[same as prior period, unchanged from 0001069202-17-000005:notes:174]

[0001069202-17-000009:notes:181]
[same as prior period, unchanged from 0001069202-17-000005:notes:175]

[0001069202-17-000009:notes:182]
[same as prior period, unchanged from 0001069202-17-000005:notes:176]

[0001069202-17-000009:notes:183]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII. We record these share-based awards as corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-17-000009:notes:184]
[same as prior period, unchanged from 0001069202-17-000005:notes:178]

[0001069202-17-000009:notes:185]
[same as prior period, unchanged from 0001069202-17-000005:notes:179]

[0001069202-17-000009:notes:186]
[same as prior period, unchanged from 0001069202-17-000005:notes:180]

[0001069202-17-000009:notes:187]
[same as prior period, unchanged from 0001069202-17-000005:notes:181]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-17-000009:notes:188]
[same as prior period, unchanged from 0001069202-17-000005:notes:182]

[0001069202-17-000009:notes:189]
Our Board of Directors has authorized a total of $2 billion  towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $550 million share repurchase authorization in 2016. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date. As of June 30, 2017, $471 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-17-000009:notes:190]
On February 9, 2017, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “ASR Agreement”) with Morgan Stanley, to effect an accelerated stock buyback of our common stock (the “Common Stock”).

[0001069202-17-000009:notes:191]
Under the ASR Agreement, on February 9, 2017, we paid Morgan Stanley an initial purchase price of $75 million, and Morgan Stanley delivered to us Common Stock, representing approximately 85% of the shares expected to be purchased under the ASR Agreement. The ASR Agreement was completed in the second quarter and Morgan Stanley delivered additional shares for a total of 0.5 million shares of common stock repurchased as part of this ASR Agreement.

[0001069202-17-000009:notes:192]
On April 28, 2017, we entered into another Fixed Dollar ASR Agreement (the "Second ASR Agreement") with J.P. Morgan Chase Bank to effect an accelerated stock buyback of Common Stock.

[0001069202-17-000009:notes:193]
Under the Second ASR Agreement, on April 28, 2017, we paid J.P. Morgan Chase Bank an initial purchase price of $100 million, and J.P. Morgan Chase Bank delivered to us a total of 0.5 million shares of Common Stock, representing approximately 85% of the shares expected to be purchased under the Second ASR Agreement. The Second ASR Agreement will be completed in the third quarter.

[0001069202-17-000009:notes:194]
We also repurchased 0.1 million shares for $14.1 million during the six months ended June 30, 2017 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
