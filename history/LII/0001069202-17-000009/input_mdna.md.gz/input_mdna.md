# LII MD&A — 0001069202-17-000009


## mdna

[0001069202-17-000009:mdna:1]
[same as prior period, unchanged from 0001069202-17-000005:mdna:1]

[0001069202-17-000009:mdna:2]
[same as prior period, unchanged from 0001069202-17-000005:mdna:2]

[0001069202-17-000009:mdna:3]
[same as prior period, unchanged from 0001069202-17-000005:mdna:3]

[0001069202-17-000009:mdna:4]
[same as prior period, unchanged from 0001069202-17-000005:mdna:4]

[0001069202-17-000009:mdna:5]
[same as prior period, unchanged from 0001069202-17-000005:mdna:5]

[0001069202-17-000009:mdna:6]
[same as prior period, unchanged from 0001069202-17-000005:mdna:6]

[0001069202-17-000009:mdna:7]
[same as prior period, unchanged from 0001069202-17-000005:mdna:7]

[0001069202-17-000009:mdna:8]
In the second quarter of 2017, the Residential Heating & Cooling segment continued to lead our overall operational performance with a 14% increase in net sales and a $25 million increase in segment profit compared to the second quarter of 2016.  The primary growth driver for this segment was volume gains.  Our Commercial Heating & Cooling segment also grew sales in the second quarter of 2017 with a 2% increase in net sales but had $3 million in decreased segment profit compared to the second quarter of 2016.  This segment's profits were down largely due to higher commodity prices and unfavorable mix.  Sales in our Refrigeration segment decreased by 1% and segment profit was relatively flat compared to the second quarter of 2016 due primarily to lower sales volume.

[0001069202-17-000009:mdna:9]
[same as prior period, unchanged from 0001069202-17-000005:mdna:9]

[0001069202-17-000009:mdna:10]
| • | Net sales increased $83 million, or 8%, to $1,102 million in the second quarter of 2017 compared to the second quarter of 2016. |

[0001069202-17-000009:mdna:11]
| • | Operating income in the second quarter of 2017 increased $15 million to $175 million. |

[0001069202-17-000009:mdna:12]
| • | Net income for the second quarter of 2017 increased $5 million to $116 million, including the benefit of $0.7 million of discrete tax benefits in the second quarter of 2017 related to excess tax benefits from share-based compensation. |

[0001069202-17-000009:mdna:13]
| • | Diluted earnings per share from continuing operations were $2.71 per share in the second quarter of 2017 compared to $2.52 per share in the second quarter of 2016. |

[0001069202-17-000009:mdna:14]
| • | During the second quarter of 2017, we returned $37 million to shareholders through dividend payments and initiated a $100 million repurchase of common stock that will be completed in the third quarter of 2017. |

[0001069202-17-000009:mdna:15]
Second Quarter of 2017 Compared to Second Quarter of 2016 - Consolidated Results

[0001069202-17-000009:mdna:16]
[same as prior period, unchanged from 0001069202-17-000005:mdna:16]

[0001069202-17-000009:mdna:17]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 1,102.1 |  |  | $ | 1,019.2 |  |  | 8.1 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 761.3 |  |  | 704.2 |  |  | (8.1 | ) |  | 69.1 |  |  | 69.1 |  |
| Gross profit | 340.8 |  |  | 315.0 |  |  | 8.2 |  |  | 30.9 |  |  | 30.9 |  |
| Selling, general and administrative expenses | 168.5 |  |  | 159.4 |  |  | (5.7 | ) |  | 15.3 |  |  | 15.6 |  |
| Losses and other expenses, net | 2.3 |  |  | 0.4 |  |  | (475.0 | ) |  | 0.2 |  |  | — |  |
| Restructuring charges | 0.1 |  |  | 0.8 |  |  | (87.5 | ) |  | — |  |  | 0.1 |  |
| Income from equity method investments | (5.5 | ) |  | (6.3 | ) |  | (12.7 | ) |  | (0.5 | ) |  | (0.6 | ) |
| Operating income | $ | 175.4 |  |  | $ | 160.7 |  |  | 9.1 | % |  | 15.9 | % |  | 15.8 | % |

[0001069202-17-000009:mdna:18]
[same as prior period, unchanged from 0001069202-17-000005:mdna:18]

[0001069202-17-000009:mdna:19]
Net sales increased 8% in the second quarter of 2017 compared to the second quarter of 2016, primarily from 8% higher sales volumes.  The Residential Heating & Cooling segment delivered higher volume from additional replacement and new construction business.  The Commercial Heating & Cooling segment delivered higher volume from our North American Service business.

[0001069202-17-000009:mdna:20]
[same as prior period, unchanged from 0001069202-17-000005:mdna:20]

[0001069202-17-000009:mdna:21]
Gross profit margin in the second quarter of 2017 remained flat at 30.9% compared to the second quarter of 2016.  We saw positive margin increases of 70 basis points ("bps") from favorable mix and price, 70 bps from lower material costs and 10 bps from product warranties.  Offsetting these increases were decreases of 80 bps from higher commodity prices, 50 bps related to a  product quality issue disclosed in Note 6 in the Notes to the Consolidated Financial Statements and 20 bps from combined freight and distribution.

[0001069202-17-000009:mdna:22]
[same as prior period, unchanged from 0001069202-17-000005:mdna:22]

[0001069202-17-000009:mdna:23]
Selling, general and administrative expenses, or SG&A, was $169 million in the second quarter of 2017 compared to $159 million in the second quarter of 2016, and as a percentage of net sales decreased 30 bps to 15.3%.  SG&A increased due to wage inflation and increased investment in information technology and research and development partially offset by decreases in long-term incentive compensation and healthcare costs.

[0001069202-17-000009:mdna:24]
[same as prior period, unchanged from 0001069202-17-000005:mdna:24]

[0001069202-17-000009:mdna:25]
Losses and other expenses, net for the second quarter of 2017 and 2016 included the following (in millions):

[0001069202-17-000009:mdna:26]
|  | For the Three Months Ended June 30, |
|  | 2017 |  | 2016 |
| Realized (gains) losses on settled future contracts | $ | (0.4 | ) |  | $ | 0.4 |  |
| Foreign currency exchange losses | 0.5 |  |  | 0.3 |  |
| Gain on disposal of fixed assets | — |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | (0.3 | ) |
| Special legal contingency charges (gains) | 1.2 |  |  | (1.7 | ) |
| Asbestos-related litigation | 0.7 |  |  | 1.1 |  |
| Environmental liabilities | 0.2 |  |  | 0.5 |  |
| Losses and other expenses, net (pre-tax) | $ | 2.3 |  |  | $ | 0.4 |  |

[0001069202-17-000009:mdna:27]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000009:mdna:28]
[same as prior period, unchanged from 0001069202-17-000005:mdna:28]

[0001069202-17-000009:mdna:29]
There were minor restructuring charges in the second quarter of 2017.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000009:mdna:30]
[same as prior period, unchanged from 0001069202-17-000005:mdna:30]

[0001069202-17-000009:mdna:31]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $6 million in the second quarter of 2017 was relatively flat when compared to the second quarter of 2016.

[0001069202-17-000009:mdna:32]
[same as prior period, unchanged from 0001069202-17-000005:mdna:32]

[0001069202-17-000009:mdna:33]
Interest expense, net of $8 million in the second quarter of 2017 was up from $7 million as compared to the second quarter of 2016 due to an increase in our average net borrowings.

[0001069202-17-000009:mdna:34]
[same as prior period, unchanged from 0001069202-17-000005:mdna:34]

[0001069202-17-000009:mdna:35]
We expect our annual effective tax rate to be 32%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09, in 2017 and subsequent years.

[0001069202-17-000009:mdna:36]
The effective tax rate was 30% for the second quarter of 2017, after the impact of excess tax benefits, compared to 28% for the second quarter of 2016, which excluded the impact of excess tax benefits.  The rate for the second quarter of 2016 is lower as compared to the second quarter of 2017 primarily due to the recognition of tax benefits related to the repatriation of earnings in 2016.

[0001069202-17-000009:mdna:37]
Second Quarter of 2017 Compared to Second Quarter of 2016 - Results by Segment

[0001069202-17-000009:mdna:38]
[same as prior period, unchanged from 0001069202-17-000005:mdna:38]

[0001069202-17-000009:mdna:39]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the second quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000009:mdna:40]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 653.5 |  |  | $ | 574.5 |  |  | $ | 79 |  |  | 13.8 | % |
| Profit | $ | 140.5 |  |  | $ | 115.9 |  |  | $ | 24.6 |  |  | 21.2 | % |
| % of net sales | 21.5 | % |  | 20.2 | % |  |  |  |  |

[0001069202-17-000009:mdna:41]
Net sales increased by 14% in the second quarter of 2017 compared to the second quarter of 2016.  Sales volume increased by 13% and price and mix combined increased sales by 1%.

[0001069202-17-000009:mdna:42]
Segment profit in the second quarter of 2017 increased $25 million compared to the second quarter of 2016 due to $25 million in higher sales volume, $6 million in higher price and mix, $3 million in lower material costs, $2 million in lower warranty and other product costs, and $1 million in factory productivity.  Partially offsetting these increases was $6 million of higher SG&A expenses primarily for information technology and research and development investments, incremental headcount and higher personnel related costs, $5 million in higher commodity costs, and $1 million of freight and distribution investments.

[0001069202-17-000009:mdna:43]
[same as prior period, unchanged from 0001069202-17-000005:mdna:43]

[0001069202-17-000009:mdna:44]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000009:mdna:45]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 258.6 |  |  | $ | 252.9 |  |  | $ | 5.7 |  |  | 2.3 | % |
| Profit | $ | 44.7 |  |  | $ | 47.4 |  |  | $ | (2.7 | ) |  | (5.7 | )% |
| % of net sales | 17.3 | % |  | 18.7 | % |  |  |  |  |

[0001069202-17-000009:mdna:46]
Net sales increased by 2% in the second quarter of 2017 compared to the second quarter of 2016.  Sales volume increased 4% primarily from growth in our North American Service, VRF and European HVAC businesses offset by unfavorable mix and foreign currency combined by 2%.

[0001069202-17-000009:mdna:47]
Segment profit in the second quarter of 2017 decreased $3 million compared to the second quarter of 2016 primarily due to unfavorable mix of $2 million, $2 million of higher SG&A expenses, $2 million of higher commodity costs, $1 million of lower factory productivity, $1 million of freight and distribution investments, and $1 million of higher warranty and other product costs, partially offset by a $3 million increase from higher sales volume, $2 million of lower material costs, and $1 million of higher price.

[0001069202-17-000009:mdna:48]
[same as prior period, unchanged from 0001069202-17-000005:mdna:48]

[0001069202-17-000009:mdna:49]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000009:mdna:50]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 190.0 |  |  | $ | 191.8 |  |  | $ | (1.8 | ) |  | (0.9 | )% |
| Profit | $ | 21.6 |  |  | $ | 21.3 |  |  | $ | 0.3 |  |  | 1.4 | % |
| % of net sales | 11.4 | % |  | 11.1 | % |  |  |  |  |

[0001069202-17-000009:mdna:51]
Net sales decreased 1% in the second quarter of 2017 compared to the second quarter of 2016 due primarily to lower sales volumes.

[0001069202-17-000009:mdna:52]
Segment profit in the second quarter of 2017 was flat compared to the second quarter of 2016 due to $2 million of favorable price and mix, $2 million in lower material costs, and $1 million lower other product costs, offset by $3 million in higher SG&A expenses and $2 million in lower factory productivity.

[0001069202-17-000009:mdna:53]
[same as prior period, unchanged from 0001069202-17-000005:mdna:53]

[0001069202-17-000009:mdna:54]
Corporate and other expenses were flat in the second quarter of 2017 compared to the second quarter of 2016 due to $2 million of general wage inflation, offset by $2 million in lower health care expenses.

[0001069202-17-000009:mdna:55]
Year-to-Date through June 30, 2017 Compared to Year-to-Date through June 30, 2016 - Consolidated Results

[0001069202-17-000009:mdna:56]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-17-000009:mdna:57]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 1,895.6 |  |  | $ | 1,734.4 |  |  | 9.3 |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,343.8 |  |  | 1,235.8 |  |  | (8.7 | ) |  | 70.9 |  |  | 71.3 |  |
| Gross profit | 551.8 |  |  | 498.6 |  |  | 10.7 |  |  | 29.1 |  |  | 28.7 |  |
| Selling, general and administrative expenses | 320.9 |  |  | 299.7 |  |  | (7.1 | ) |  | 16.9 |  |  | 17.3 |  |
| Losses and other expenses, net | 5.4 |  |  | 4.7 |  |  | (14.9 | ) |  | 0.3 |  |  | 0.2 |  |
| Restructuring charges | 0.2 |  |  | 0.6 |  |  | 66.7 |  |  | — |  |  | — |  |
| Income from equity method investments | (10.9 | ) |  | (10.8 | ) |  | 0.9 |  |  | (0.6 | ) |  | (0.6 | ) |
| Operating income | $ | 236.2 |  |  | $ | 204.4 |  |  | 15.6 |  |  | 12.5 | % |  | 11.8 | % |

[0001069202-17-000009:mdna:58]
Net Sales

[0001069202-17-000009:mdna:59]
Net sales increased 9% in the first six months of 2017 compared to the first six months of 2016, with sales volumes up 9% and a 1% increase from price and mix combined.  The volume increases were driven by our Residential Heating & Cooling and Commercial Heating & Cooling and Refrigeration segments all capturing additional replacement and new construction business.  Partially offsetting these increases was a 1% decrease from unfavorable foreign currency exchange rates.

[0001069202-17-000009:mdna:60]
Gross Profit

[0001069202-17-000009:mdna:61]
Gross profit margins in the first six months of 2017 increased 40 bps to 29.1% compared to the first six months of 2016.  Our profit margin increased 90 bps from material cost savings and 70 bps from favorable price and mix combined.   Offsetting these  increases were decreases of 50 bps from higher commodity costs, 40 bps from freight and distribution and 30 bps from unfavorable factory productivity.

[0001069202-17-000009:mdna:62]
Selling, General and Administrative Expenses

[0001069202-17-000009:mdna:63]
SG&A was $321 million for the first six months of 2017 compared to $300 million for the first six months of 2016, and as a percentage of net sales, decreased 40 bps to 16.9% from 17.3%.  SG&A increased due to wage inflation and increased investment in information technology and research and development partially offset by decreases in long-term incentive compensation and healthcare costs.

[0001069202-17-000009:mdna:64]
Losses and Other Expenses, Net

[0001069202-17-000009:mdna:65]
Losses and other expenses, net for the first six months of 2017 and 2016 included the following (in millions):

[0001069202-17-000009:mdna:66]
|  | For the Six Months Ended June 30, |
|  | 2017 |  | 2016 |
| Realized (gains) losses on settled future contracts | $ | (0.8 | ) |  | $ | 0.9 |  |
| Foreign currency exchange losses | 0.2 |  |  | 0.5 |  |
| Loss on disposal of fixed assets | — |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.9 |  |  | (0.7 | ) |
| Special legal contingency charges | 2.0 |  |  | — |  |
| Asbestos-related litigation | 2.4 |  |  | 1.9 |  |
| Environmental liabilities | 0.7 |  |  | 1.1 |  |
| Contractor tax payments | — |  |  | 0.5 |  |
| Acquisition costs | — |  |  | 0.4 |  |
| Losses and other expenses, net (pre-tax) | $ | 5.4 |  |  | $ | 4.7 |  |

[0001069202-17-000009:mdna:67]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.  Contractor tax payments in the first six months of 2016 relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.

[0001069202-17-000009:mdna:68]
Restructuring Charges

[0001069202-17-000009:mdna:69]
There were minor restructuring charges in the first six months of 2017.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000009:mdna:70]
Income from Equity Method Investments

[0001069202-17-000009:mdna:71]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $11 million in the first six months of 2017 was relatively flat when compared to the first six months of 2016.

[0001069202-17-000009:mdna:72]
Interest Expense, net

[0001069202-17-000009:mdna:73]
Interest expense, net of $16 million in the first six months of 2017 increased from $13 million in the first six months of 2016 due to an increase in our average net borrowings.

[0001069202-17-000009:mdna:74]
Income Taxes

[0001069202-17-000009:mdna:75]
We expect our annual effective tax rate to be 32%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09, in 2017 and subsequent years.

[0001069202-17-000009:mdna:76]
The effective tax rate was 28% for the six months ended June 30, 2017, after the impact of excess tax benefits, compared to 29% for the six months ended June 30, 2016, which excluded the impact of excess tax benefits but included the benefits of a planned repatriation of earnings in the second quarter of 2016.

[0001069202-17-000009:mdna:77]
Year-to-Date through June 30, 2017 Compared to Year-to-Date through June 30, 2016 - Results by Segment

[0001069202-17-000009:mdna:78]
Residential Heating & Cooling

[0001069202-17-000009:mdna:79]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first six months of 2017 and 2016 (dollars in millions):

[0001069202-17-000009:mdna:80]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 1,073.3 |  |  | $ | 951.8 |  |  | $ | 121.5 |  |  | 12.8 | % |
| Profit | $ | 182.9 |  |  | $ | 154.1 |  |  | $ | 28.8 |  |  | 18.7 | % |
| % of net sales | 17.0 | % |  | 16.2 | % |  |  |  |  |

[0001069202-17-000009:mdna:81]
Net sales increased by 13%  in the first six months of 2017 compared to the first six months of 2016.  Sales volumes increased net sales by 12% due to industry growth and the benefits of favorable price and mix contributed 1%.

[0001069202-17-000009:mdna:82]
Segment profit for the first six months of 2017 increased $29 million compared to the first six months of 2016.  The benefits of $36 million in higher sales volume, $7 million from lower material costs, $6 million from favorable price and mix, $2 million from favorable warranty and other product costs, $1 million in higher factory productivity, and $1 million from favorable foreign currency exchange rates, were partially offset by $12 million in SG&A expenses to support investments in technology and research and development and incremental headcount and higher personnel costs, $6 million in higher commodity costs, and $6 million in freight and distribution investments.

[0001069202-17-000009:mdna:83]
Commercial Heating & Cooling

[0001069202-17-000009:mdna:84]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first six months of 2017 and 2016 (dollars in millions):

[0001069202-17-000009:mdna:85]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 454.1 |  |  | $ | 423.3 |  |  | $ | 30.8 |  |  | 7.3 | % |
| Profit | $ | 63.8 |  |  | $ | 61.7 |  |  | $ | 2.1 |  |  | 3.4 | % |
| % of net sales | 14.0 | % |  | 14.6 | % |  |  |  |  |

[0001069202-17-000009:mdna:86]
Commercial Heating & Cooling net sales increased by 7% in the first six months of 2017 compared to the first six months of 2016. Sales volumes increased net sales by 8%, and changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-17-000009:mdna:87]
Segment profit in the first six months of 2017 increased $2 million compared to the first six months of 2016. The benefits of $10 million from incremental volume and $3 million in lower material costs were offset by $5 million in higher SG&A expenses, $2 million due to unfavorable mix, $1 million of higher commodity costs, $1 million of lower factory productivity, $1 million of distribution investments, and $1 million from other product costs.

[0001069202-17-000009:mdna:88]
Refrigeration

[0001069202-17-000009:mdna:89]
The following table presents our Refrigeration segment's net sales and profit for the first six months of 2017 and 2016 (dollars in millions):

[0001069202-17-000009:mdna:90]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 368.2 |  |  | $ | 359.3 |  |  | $ | 8.9 |  |  | 2.5 | % |
| Profit | $ | 35.7 |  |  | $ | 30.3 |  |  | $ | 5.4 |  |  | 17.8 | % |
| % of net sales | 9.7 | % |  | 8.4 | % |  |  |  |  |

[0001069202-17-000009:mdna:91]
Refrigeration net sales increased 3% in the first six months of 2017 compared to the first six months of 2016 primarily due to 2% favorable price and mix and 1% volume growth.

[0001069202-17-000009:mdna:92]
Segment profit for the first six months of 2017 increased $5 million compared to the first six months of 2016 primarily due to $5 million favorable price and mix, $5 million lower material costs, $2 million from higher sales volume, $2 million of lower other product costs, and $1 million from favorable foreign currency exchange rates, partially offset by $8 million of higher SG&A expenses and $2 million in lower factory productivity.

[0001069202-17-000009:mdna:93]
Corporate and Other

[0001069202-17-000009:mdna:94]
Corporate and other expenses decreased $3 million to $35 million in the first six months of 2017 from $38 million in the first six months of 2016 due primarily to lower health care costs and lower incentive compensation, with a partial offset from general wage inflation.

[0001069202-17-000009:mdna:95]
[same as prior period, unchanged from 0001069202-17-000005:mdna:55]

[0001069202-17-000009:mdna:96]
[same as prior period, unchanged from 0001069202-17-000005:mdna:56]

[0001069202-17-000009:mdna:97]
[same as prior period, unchanged from 0001069202-17-000005:mdna:57]

[0001069202-17-000009:mdna:98]
The following table summarizes our cash flow activity for the six months ended June 30, 2017 and 2016 (in millions):

[0001069202-17-000009:mdna:99]
|  | For the Six Months Ended June 30, |
|  | 2017 |  | 2016 |
| Net cash used in operating activities | $ | (48.3 | ) |  | $ | (25.3 | ) |
| Net cash used in investing activities | (43.2 | ) |  | (41.7 | ) |
| Net cash provided by financing activities | 95.4 |  |  | 80.9 |  |

[0001069202-17-000009:mdna:100]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first six months of 2017 and 2016 reflects the seasonal increase in working capital requirements and the increase in sales in 2017 as compared to 2016. The increase in net income in the first six months of 2017 as compared to 2016 was offset by increases in working capital used to support higher sales.

[0001069202-17-000009:mdna:101]
Net Cash Used in Investing Activities - Capital expenditures were $43 million and $42 million in the first six months of 2017 and 2016, respectively.  Capital expenditures in 2017 were primarily related to investments in systems and software to support the overall enterprise, expansion of our manufacturing capacity and equipment, and continued investments in our distribution network.

[0001069202-17-000009:mdna:102]
Net Cash Provided by Financing Activities - Net cash provided by financing activities increased in the first six months of  2017 to $95 million as compared to $81 million in the first six months of 2016.  Cash continues to be provided by an increase in net borrowings and we continue to make share repurchases.  During the second quarter of 2017 we settled the $75 million Accelerated Share Repurchase Transaction executed in the first quarter and executed a $100 million Accelerated Repurchase Transaction that will be settled in the third quarter of 2017.  For additional information on share repurchases, refer to Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000009:mdna:103]
[same as prior period, unchanged from 0001069202-17-000005:mdna:63]

[0001069202-17-000009:mdna:104]
The following table details our lines of credit and financing arrangements as of June 30, 2017 (in millions):

[0001069202-17-000009:mdna:105]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 1.3 |  |
| Asset Securitization Program (1) | 250.0 |  |
| Total short-term debt | $ | 251.3 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 0.6 |  |
| Domestic credit facility (2) | 15.0 |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 15.0 |  |
| Long-term debt: |  |
| Capital lease obligations | 14.8 |  |
| Domestic credit facility (2) | 562.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (4.7 | ) |
| Total long-term debt | 922.6 |  |
| Total debt | $ | 1,188.9 |  |

[0001069202-17-000009:mdna:106]
[same as prior period, unchanged from 0001069202-17-000005:mdna:66]

[0001069202-17-000009:mdna:107]
(2) The available future borrowings on our domestic credit facility are $288.1 million after being reduced by the outstanding borrowings and $4.4 million in outstanding standby letters of credit.  We also had $38.3 million in outstanding standby letters of credit outside of the domestic credit facility as of June 30, 2017.

[0001069202-17-000009:mdna:108]
[same as prior period, unchanged from 0001069202-17-000005:mdna:68]

[0001069202-17-000009:mdna:109]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 99.1% at June 30, 2017 from 95.8% at December 31, 2016.

[0001069202-17-000009:mdna:110]
As of June 30, 2017, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-17-000009:mdna:111]
[same as prior period, unchanged from 0001069202-17-000005:mdna:71]

[0001069202-17-000009:mdna:112]
We believe our cash and cash equivalents of $61 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, potential dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $61 million as of June 30, 2017 was $33.0 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States. If we were to repatriate foreign earnings, we would be required to accrue and pay taxes in the United States, less foreign tax credits, for the amounts that were repatriated.

[0001069202-17-000009:mdna:113]
Our expected capital expenditures for 2017 are $100 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with the completion of a $75 million stock repurchase program, the initiation of a $100 million stock repurchase program, and the declaration of $40 million of cash dividends in the first six months of 2017.

[0001069202-17-000009:mdna:114]
[same as prior period, unchanged from 0001069202-17-000005:mdna:74]

[0001069202-17-000009:mdna:115]
[same as prior period, unchanged from 0001069202-17-000005:mdna:75]

[0001069202-17-000009:mdna:116]
Commitments, Contingencies and Guarantees

[0001069202-17-000009:mdna:117]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000009:mdna:118]
[same as prior period, unchanged from 0001069202-17-000005:mdna:78]

[0001069202-17-000009:mdna:119]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. We have substantially completed our evaluation of the effect that ASU 2014-09 will have on our Consolidated Financial Statements and related disclosures. We do not expect the ASU to have a material impact on the amount and timing of revenue recognition, but it will require us to enhance our disclosures to provide additional information relating to disaggregated revenue, contract assets and liabilities, and remaining performance obligations.  We are currently in the process of preparing these additional disclosures, including updating our internal controls related to the additional data and disclosures to be provided upon adoption of the new standard.  We will adopt the new standard using the modified retrospective approach.

[0001069202-17-000009:mdna:120]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.  As a result of the new standard, all of our leases greater than one year in duration will be recognized on our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.

[0001069202-17-000009:mdna:121]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees.  For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017.  This standard is not expected to have a material impact on our consolidated financial statements.

[0001069202-17-000009:mdna:122]
On October 24, 2016, the FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory. The new ASU eliminates the existing exception from recognition of the tax consequences of intercompany sales of assets other than inventory.  Under the new standard, when an asset (other than inventory) is sold from one consolidated entity to another, the tax consequences to the seller will be recognized currently as a component of the current tax provision.  The new guidance will be effective for public business entities in fiscal years beginning after December 15, 2017, including interim periods within those years.  In accordance with the ASU, our previously deferred tax costs and unrecognized deferred tax assets related to intra-entity asset transfers will need to be recognized at the date of transition through a cumulative effect adjustment to opening retained earnings upon adoption of the standard.

[0001069202-17-000009:mdna:123]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other Income, net. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We do not expect the ASU to have a material impact on our financial results.
