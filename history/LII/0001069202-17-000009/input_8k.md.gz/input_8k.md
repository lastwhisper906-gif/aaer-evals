# LII 8-K — 0001193125-17-233271 filed 2017-07-24

## item codes, every 8-K on or before 2017-07-24

- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2017-07-24

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-233271:8k_2_02:1]
EX-99.1
2
d418876dex991.htm
EX-99.1

[0001193125-17-233271:8k_2_02:2]
EX-99.1

[0001193125-17-233271:8k_2_02:3]
Exhibit 99.1

[0001193125-17-233271:8k_2_02:4]
Lennox International Reports Record Revenue and Profit in Second Quarter

[0001193125-17-233271:8k_2_02:5]
| • |  | Revenue up 8% to record $1.1 billion, led by 14% Residential growth |

[0001193125-17-233271:8k_2_02:6]
| • |  | Record GAAP EPS from continuing operations of $2.71, up 8% |

[0001193125-17-233271:8k_2_02:7]
| • |  | Record adjusted EPS from continuing operations of $2.83, up 12% |

[0001193125-17-233271:8k_2_02:8]
| • |  | Raising low end of 2017 revenue growth guidance from 3-7% to 4-7% |

[0001193125-17-233271:8k_2_02:9]
| • |  | Narrowing 2017 GAAP EPS from continuing operations guidance from $7.65-$8.25 to $7.73-$8.13 |

[0001193125-17-233271:8k_2_02:10]
| • |  | Raising low end of 2017 adjusted EPS from continuing operations guidance from $7.55-$8.15 to $7.75-$8.15 |

[0001193125-17-233271:8k_2_02:11]
| • |  | $175 million of stock repurchases year-to-date, and $75 million more planned for second half of 2017 |

[0001193125-17-233271:8k_2_02:12]
DALLAS, July 24, 2017 – Lennox International Inc. (NYSE: LII) today reported financial results for the second quarter of 2017. All comparisons are
to the prior-year period.

[0001193125-17-233271:8k_2_02:13]
For the second quarter, revenue was up 8% to a record $1.102 billion. Foreign exchange was neutral to revenue. GAAP operating
income was a record $175 million, up 9%. GAAP earnings per share from continuing operations was a record $2.71, up 8%.

[0001193125-17-233271:8k_2_02:14]
On an adjusted basis, total
segment profit increased 14% to a record $183 million, and total segment margin expanded 80 basis points to a record 16.6%. Adjusted EPS from continuing operations rose 12% to a record $2.83.

[0001193125-17-233271:8k_2_02:15]
“Lennox International posted strong revenue and profit growth in a record quarter for the company,” said Chairman and CEO Todd Bluedorn. “The
company hit new all-time highs for revenue, total segment margin and profit, and earnings per share.

[0001193125-17-233271:8k_2_02:16]
“In our Residential business, revenue was up
14% on strength in both replacement and new construction business. Segment margin expanded 130 basis points to 21.5%, and segment profit rose 21%. Our Residential business set new all-time highs for revenue, segment margin and profit. In our
Commercial business, we have seen lumpy customer demand and mix in the first half of the year. After a record first quarter with strong growth in revenue, margin, and profit, Commercial revenue was up 3% at constant currency in the second quarter,
with segment margin of 17.3% down 140 basis points and segment profit down 6% from the record second quarter a year ago. Looking ahead at the second half of the year, we expect Commercial revenue, margin and profit to be up from the prior-year
period. In Refrigeration, second-quarter revenue was down 1%, driven by a decline in Europe. Revenue was up in North America, South America, Australia, and Asia. Refrigeration margin expanded 30 basis points to 11.4%, and segment profit rose 1%.

[0001193125-17-233271:8k_2_02:17]
“Looking ahead for the company overall, we continue to expect strong growth for a year of record revenue and
profit, led by the strength in our Residential business. Given the company’s first-half performance and outlook for the second half, we are raising the low end of our 2017 guidance for revenue and adjusted EPS from continuing operations, and we
plan $75 million more of stock repurchases in the second half of the year.”

[0001193125-17-233271:8k_2_02:18]
FINANCIAL HIGHLIGHTS

[0001193125-17-233271:8k_2_02:19]
Revenue: Revenue for the second quarter was $1.102 billion, up 8%. Foreign exchange was neutral to revenue. Volume was up, and price/mix was flat on a
revenue basis.

[0001193125-17-233271:8k_2_02:20]
Gross Profit: Gross profit in the second quarter was $341 million, up 8%. Gross margin was flat at 30.9%. Gross profit was
positively impacted by higher volume, favorable price/mix, and sourcing and engineering-led cost reductions, with offsets from higher commodity costs, investments in distribution expansion, and foreign exchange.

[0001193125-17-233271:8k_2_02:21]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the second quarter was $116.4 million, or $2.71 per share,
compared to $111.2 million, or $2.52 per share, in the prior-year quarter.

[0001193125-17-233271:8k_2_02:22]
Adjusted income from continuing operations in the second quarter was $121.0
million, or $2.83 per share, compared to $111.5 million, or $2.53 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the second quarter of 2017 excludes net after-tax charges of $4.6 million: $3.4 million for
special product quality adjustments, $1.0 million of special legal contingency charges, a total of $0.9 million for other items, and a benefit of $0.7 million for excess tax benefits from share-based compensation.

[0001193125-17-233271:8k_2_02:23]
Free Cash Flow and Total Debt: Net cash from operations in the second quarter was $59 million compared to $76 million in the prior-year quarter.
Capital expenditures were $18 million in the second quarter of 2017, flat with the second quarter of 2016. Free cash flow was $41 million compared to $58 million in the prior-year quarter. Total debt at the end of the second quarter was $1.189
billion. Total cash and cash equivalents were $61 million at the end of June. In the second quarter, the company paid $18 million in dividends and $100 million for stock repurchases.

[0001193125-17-233271:8k_2_02:24]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-17-233271:8k_2_02:25]
Residential Heating & Cooling

[0001193125-17-233271:8k_2_02:26]
Revenue in the
Residential Heating & Cooling business segment rose 14% to a record $654 million. Foreign exchange was neutral on a revenue basis. Segment profit was up 21% to a record $141 million. Segment profit margin expanded 130 basis points to a
record 21.5%. Results were impacted by higher volume, favorable price/mix, sourcing and engineering-led cost reductions, and favorable warranty and other product costs. Partial offsets included investments in research and development, information
technology, and other SG&A, investments in distribution expansion, higher commodity costs, and unfavorable foreign exchange.

[0001193125-17-233271:8k_2_02:27]
Commercial
Heating & Cooling

[0001193125-17-233271:8k_2_02:28]
Revenue in the Commercial Heating & Cooling business segment was a record $259 million, up 2%. At constant
currency, revenue was up 3%. Segment margin was down 140 basis points to 17.3%, and segment profit declined 6% to $45 million. Results were impacted by unfavorable mix, higher commodity costs, investments in research and development, information
technology, and other SG&A. Partial offsets included higher volume, sourcing and engineering-led cost reductions, and favorable price.

[0001193125-17-233271:8k_2_02:29]
Refrigeration

[0001193125-17-233271:8k_2_02:30]
Revenue in the Refrigeration business
segment was $190 million, down 1%. Foreign exchange was neutral on a revenue basis. Segment margin expanded 30 basis points to 11.4%, and segment profit rose 1% to $22 million. Results were impacted by favorable price/mix and sourcing and
engineering-led cost reductions, with partial offsets from factory productivity, investments in research and development, information technology, and other SG&A.

[0001193125-17-233271:8k_2_02:31]
FULL-YEAR OUTLOOK

[0001193125-17-233271:8k_2_02:32]
For 2017, the company is raising the
low end of guidance for revenue and adjusted EPS from continuing operations.

[0001193125-17-233271:8k_2_02:33]
| • |  | Raising 2017 guidance for revenue growth from 3-7% to 4-7%; a minimal impact from foreign exchange is still expected. |

[0001193125-17-233271:8k_2_02:34]
| • |  | Narrowing guidance for GAAP EPS from continuing operations from $7.65-$8.25 to $7.73-$8.13. |

[0001193125-17-233271:8k_2_02:35]
| • |  | Raising the low end of adjusted EPS from continuing operations guidance from $7.55-$8.15 to $7.75-$8.15. |

[0001193125-17-233271:8k_2_02:36]
| • |  | Reiterating corporate expenses of approximately $85 million. |

[0001193125-17-233271:8k_2_02:37]
| • |  | Updating guidance for the 2017 effective tax rate from approximately 32% to a range of 31-32% on an adjusted basis for the full year. |

[0001193125-17-233271:8k_2_02:38]
| • |  | Reiterating capital expenditures of approximately $100 million. |

[0001193125-17-233271:8k_2_02:39]
| • |  | Reiterating guidance for a weighted average diluted share count of 42-43 million shares on a full-year basis, including plans for $250 million of stock repurchases in total for 2017. |

[0001193125-17-233271:8k_2_02:40]
CONFERENCE CALL INFORMATION

[0001193125-17-233271:8k_2_02:41]
A conference call to discuss the company’s second quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call
line at 612-332-1210 at least 10 minutes prior to the scheduled start time and use reservation number 426825. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available
from 11:00 a.m. Central time on July 24 through August 7, 2017 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 426825. The call also will be archived on the company’s website.

[0001193125-17-233271:8k_2_02:42]
About Lennox International

[0001193125-17-233271:8k_2_02:43]
Lennox International Inc. is
a global leader in the heating, air conditioning, and refrigeration markets. Lennox International is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at:
www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-17-233271:8k_2_02:44]
Forward-Looking Statements

[0001193125-17-233271:8k_2_02:45]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-233271:8k_2_02:46]
Consolidated Statements of Operations

[0001193125-17-233271:8k_2_02:47]
(Unaudited)

[0001193125-17-233271:8k_2_02:48]
| (Amounts in millions, except per share data) |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net sales |  | $ | 1,102.1 |  |  | $ | 1,019.2 |  |  | $ | 1,895.6 |  |  | $ | 1,734.4 |  |
| Cost of goods sold |  |  | 761.3 |  |  |  | 704.2 |  |  |  | 1,343.8 |  |  |  | 1,235.8 |  |
| Gross profit |  |  | 340.8 |  |  |  | 315.0 |  |  |  | 551.8 |  |  |  | 498.6 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 168.5 |  |  |  | 159.4 |  |  |  | 320.9 |  |  |  | 299.7 |  |
| Losses and other expenses, net |  |  | 2.3 |  |  |  | 0.4 |  |  |  | 5.4 |  |  |  | 4.7 |  |
| Restructuring charges |  |  | 0.1 |  |  |  | 0.8 |  |  |  | 0.2 |  |  |  | 0.6 |  |
| Income from equity method investments |  |  | (5.5 | ) |  |  | (6.3 | ) |  |  | (10.9 | ) |  |  | (10.8 | ) |
| Operating income |  |  | 175.4 |  |  |  | 160.7 |  |  |  | 236.2 |  |  |  | 204.4 |  |
| Interest expense, net |  |  | 8.2 |  |  |  | 6.8 |  |  |  | 15.7 |  |  |  | 12.7 |  |
| Other income, net |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | (0.3 | ) |
| Income from continuing operations before income taxes |  |  | 167.3 |  |  |  | 154.1 |  |  |  | 220.6 |  |  |  | 192.0 |  |
| Provision for income taxes |  |  | 50.9 |  |  |  | 42.9 |  |  |  | 60.7 |  |  |  | 55.9 |  |
| Income from continuing operations |  |  | 116.4 |  |  |  | 111.2 |  |  |  | 159.9 |  |  |  | 136.1 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | (1.5 | ) |  |  | (0.8 | ) |  |  | (1.5 | ) |  |  | (0.8 | ) |
| Benefit from income taxes |  |  | (0.6 | ) |  |  | (0.3 | ) |  |  | (0.6 | ) |  |  | (0.3 | ) |
| Loss from discontinued operations |  |  | (0.9 | ) |  |  | (0.5 | ) |  |  | (0.9 | ) |  |  | (0.5 | ) |
| Net income |  | $ | 115.5 |  |  | $ | 110.7 |  |  | $ | 159.0 |  |  | $ | 135.6 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.75 |  |  | $ | 2.55 |  |  | $ | 3.76 |  |  | $ | 3.11 |  |
| Loss from discontinued operations |  |  | (0.02 | ) |  |  | (0.01 | ) |  |  | (0.02 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 2.73 |  |  | $ | 2.54 |  |  | $ | 3.74 |  |  | $ | 3.10 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.71 |  |  | $ | 2.52 |  |  | $ | 3.70 |  |  | $ | 3.07 |  |
| Loss from discontinued operations |  |  | (0.02 | ) |  |  | (0.01 | ) |  |  | (0.02 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 2.69 |  |  | $ | 2.51 |  |  | $ | 3.68 |  |  | $ | 3.06 |  |
| Weighted Average Number of Shares Outstanding—Basic |  |  | 42.3 |  |  |  | 43.6 |  |  |  | 42.6 |  |  |  | 43.8 |  |
| Weighted Average Number of Shares Outstanding—Diluted |  |  | 42.9 |  |  |  | 44.1 |  |  |  | 43.2 |  |  |  | 44.4 |  |
| Cash dividends declared per share |  | $ | 0.51 |  |  | $ | 0.43 |  |  | $ | 0.94 |  |  | $ | 0.79 |  |

[0001193125-17-233271:8k_2_02:49]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-233271:8k_2_02:50]
Segment Net Sales and Profit (Loss)

[0001193125-17-233271:8k_2_02:51]
(Unaudited)

[0001193125-17-233271:8k_2_02:52]
| (Amounts in millions) |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 653.5 |  |  | $ | 574.5 |  |  | $ | 1,073.3 |  |  | $ | 951.8 |  |
| Commercial Heating & Cooling |  |  | 258.6 |  |  |  | 252.9 |  |  |  | 454.1 |  |  |  | 423.3 |  |
| Refrigeration |  |  | 190.0 |  |  |  | 191.8 |  |  |  | 368.2 |  |  |  | 359.3 |  |
|  |  | $ | 1,102.1 |  |  | $ | 1,019.2 |  |  | $ | 1,895.6 |  |  | $ | 1,734.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 140.5 |  |  | $ | 115.9 |  |  | $ | 182.9 |  |  | $ | 154.1 |  |
| Commercial Heating & Cooling |  |  | 44.7 |  |  |  | 47.4 |  |  |  | 63.8 |  |  |  | 61.7 |  |
| Refrigeration |  |  | 21.6 |  |  |  | 21.3 |  |  |  | 35.7 |  |  |  | 30.3 |  |
| Corporate and other |  |  | (23.9 | ) |  |  | (23.5 | ) |  |  | (34.8 | ) |  |  | (38.4 | ) |
| Total segment profit |  |  | 182.9 |  |  |  | 161.1 |  |  |  | 247.6 |  |  |  | 207.7 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | 5.2 |  |  |  | — |  |  |  | 5.2 |  |  |  | (0.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 2.2 |  |  |  | (0.4 | ) |  |  | 6.0 |  |  |  | 3.1 |  |
| Restructuring charges |  |  | 0.1 |  |  |  | 0.8 |  |  |  | 0.2 |  |  |  | 0.6 |  |
| Operating income |  | $ | 175.4 |  |  | $ | 160.7 |  |  | $ | 236.2 |  |  | $ | 204.4 |  |

[0001193125-17-233271:8k_2_02:53]
| (1) | We define segment profit and loss as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-17-233271:8k_2_02:54]
|  | • |  | Special product quality adjustments; |

[0001193125-17-233271:8k_2_02:55]
|  | • |  | The following items in Losses and other expenses, net: |

[0001193125-17-233271:8k_2_02:56]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-17-233271:8k_2_02:57]
|  | • |  | Special legal contingency charges, |

[0001193125-17-233271:8k_2_02:58]
|  | • |  | Asbestos-related litigation, |

[0001193125-17-233271:8k_2_02:59]
|  | • |  | Contractor tax payments, |

[0001193125-17-233271:8k_2_02:60]
|  | • |  | Environmental liabilities, |

[0001193125-17-233271:8k_2_02:61]
|  | • |  | Acquisition costs, |

[0001193125-17-233271:8k_2_02:62]
|  | • |  | Other items, net; and, |

[0001193125-17-233271:8k_2_02:63]
|  | • |  | Restructuring charges. |

[0001193125-17-233271:8k_2_02:64]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-233271:8k_2_02:65]
Consolidated Balance Sheets

[0001193125-17-233271:8k_2_02:66]
|  |  | As of June 30, |  |  | As of December 31, |  |
| (Amounts in millions, except shares and par values) |  | 2017 |  |  | 2016 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 61.3 |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net of allowances of $6.9 and $6.7 in 2017 and 2016, respectively |  |  | 689.9 |  |  |  | 469.8 |  |
| Inventories, net |  |  | 538.8 |  |  |  | 418.5 |  |
| Other assets |  |  | 76.7 |  |  |  | 67.4 |  |
| Total current assets |  |  | 1,366.7 |  |  |  | 1,005.9 |  |
| Property, plant and equipment, net of accumulated depreciation of $750.3 and $717.2 in 2017 and 2016, respectively |  |  | 371.7 |  |  |  | 361.4 |  |
| Goodwill |  |  | 199.0 |  |  |  | 195.1 |  |
| Deferred income taxes |  |  | 141.3 |  |  |  | 136.7 |  |
| Other assets, net |  |  | 67.1 |  |  |  | 61.2 |  |
| Total assets |  | $ | 2,145.8 |  |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 251.3 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt |  |  | 15.0 |  |  |  | 200.1 |  |
| Accounts payable |  |  | 442.5 |  |  |  | 361.2 |  |
| Accrued expenses |  |  | 257.2 |  |  |  | 265.9 |  |
| Income taxes payable |  |  | 23.5 |  |  |  | 9.0 |  |
| Total current liabilities |  |  | 989.5 |  |  |  | 888.6 |  |
| Long-term debt |  |  | 922.6 |  |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions |  |  | 2.1 |  |  |  | 2.8 |  |
| Pensions |  |  | 89.5 |  |  |  | 87.5 |  |
| Other liabilities |  |  | 131.5 |  |  |  | 127.7 |  |
| Total liabilities |  |  | 2,135.2 |  |  |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,038.1 |  |  |  | 1,046.2 |  |
| Retained earnings |  |  | 1,472.2 |  |  |  | 1,353.0 |  |
| Accumulated other comprehensive loss |  |  | (166.5 | ) |  |  | (195.1 | ) |
| Treasury stock, at cost, 44,992,520 shares and 44,195,250 shares as of June 30, 2017 and December 31, 2016, respectively |  |  | (2,334.5 | ) |  |  | (2,167.4 | ) |
| Noncontrolling interests |  |  | 0.4 |  |  |  | 0.4 |  |
| Total stockholders’ equity |  |  | 10.6 |  |  |  | 38.0 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,145.8 |  |  | $ | 1,760.3 |  |

[0001193125-17-233271:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-233271:8k_2_02:68]
Consolidated Statements of Cash Flows

[0001193125-17-233271:8k_2_02:69]
(Unaudited)

[0001193125-17-233271:8k_2_02:70]
| (Amounts in millions) |  | For the Six Months EndedJune 30, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 159.0 |  |  | $ | 135.6 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (10.9 | ) |  |  | (10.8 | ) |
| Dividends from affiliates |  |  | 2.5 |  |  |  | 3.9 |  |
| Restructuring gains, net of cash paid |  |  | — |  |  |  | (1.0 | ) |
| Provision for bad debts |  |  | 2.7 |  |  |  | 2.7 |  |
| Unrealized gains on derivative contracts |  |  | (3.0 | ) |  |  | (1.9 | ) |
| Stock-based compensation expense |  |  | 12.5 |  |  |  | 14.8 |  |
| Depreciation and amortization |  |  | 32.0 |  |  |  | 28.5 |  |
| Deferred income taxes |  |  | (4.9 | ) |  |  | (1.9 | ) |
| Other items, net |  |  | 0.2 |  |  |  | 0.3 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (213.8 | ) |  |  | (216.2 | ) |
| Inventories |  |  | (114.1 | ) |  |  | (80.6 | ) |
| Other current assets |  |  | (5.7 | ) |  |  | (6.7 | ) |
| Accounts payable |  |  | 81.3 |  |  |  | 82.6 |  |
| Accrued expenses |  |  | (9.9 | ) |  |  | 20.1 |  |
| Income taxes payable and receivable |  |  | 16.2 |  |  |  | 1.5 |  |
| Other |  |  | 7.6 |  |  |  | 3.8 |  |
| Net cash used in operating activities |  |  | (48.3 | ) |  |  | (25.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.2 |  |  |  | — |  |
| Purchases of property, plant and equipment |  |  | (43.4 | ) |  |  | (41.7 | ) |
| Net cash used in investing activities |  |  | (43.2 | ) |  |  | (41.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (1.1 | ) |  |  | 0.5 |  |
| Asset securitization borrowings |  |  | 200.0 |  |  |  | 40.0 |  |
| Asset securitization payments |  |  | — |  |  |  | (20.0 | ) |
| Long-term debt payments |  |  | (200.5 | ) |  |  | (8.2 | ) |
| Borrowings from credit facility |  |  | 1,352.5 |  |  |  | 1,184.5 |  |
| Payments on credit facility |  |  | (1,031.0 | ) |  |  | (864.0 | ) |
| Proceeds from employee stock purchases |  |  | 1.5 |  |  |  | 1.3 |  |
| Repurchases of common stock |  |  | (175.0 | ) |  |  | (200.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (14.1 | ) |  |  | (21.4 | ) |
| Cash dividends paid |  |  | (36.9 | ) |  |  | (31.8 | ) |
| Net cash provided by financing activities |  |  | 95.4 |  |  |  | 80.9 |  |
| Increase in cash and cash equivalents |  |  | 3.9 |  |  |  | 13.9 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | 7.2 |  |  |  | 1.9 |  |
| Cash and cash equivalents, beginning of period |  |  | 50.2 |  |  |  | 38.9 |  |
| Cash and cash equivalents, end of period |  | $ | 61.3 |  |  | $ | 54.7 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 17.1 |  |  | $ | 12.4 |  |
| Income taxes paid (net of refunds) |  | $ | 47.8 |  |  | $ | 55.8 |  |

[0001193125-17-233271:8k_2_02:71]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-233271:8k_2_02:72]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-17-233271:8k_2_02:73]
(Unaudited, in millions, except per share and ratio data)

[0001193125-17-233271:8k_2_02:74]
Use of Non-GAAP Financial Measures

[0001193125-17-233271:8k_2_02:75]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with
the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the
Company’s business trends and operating performance.

[0001193125-17-233271:8k_2_02:76]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from
Continuing Operations, a Non-GAAP measure

[0001193125-17-233271:8k_2_02:77]
|  |  | For the Three Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | Pre-Tax |  |  | TaxImpact (e) |  |  | AfterTax |  |  | Pre-Tax |  |  | TaxImpact (e) |  |  | AfterTax |  |
| Income from continuing operations, a GAAP measure |  | $ | 167.3 |  |  | $ | (50.9 | ) |  | $ | 116.4 |  |  | $ | 154.1 |  |  | $ | (42.9 | ) |  | $ | 111.2 |  |
| Restructuring charges |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.8 |  |  |  | (0.3 | ) |  |  | 0.5 |  |
| Special product quality adjustments (b) |  |  | 5.2 |  |  |  | (1.8 | ) |  |  | 3.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Special legal contingency charges (a) |  |  | 1.2 |  |  |  | (0.2 | ) |  |  | 1.0 |  |  |  | (1.7 | ) |  |  | 0.6 |  |  |  | (1.1 | ) |
| Asbestos-related litigation (a) |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 0.5 |  |  |  | 1.1 |  |  |  | (0.4 | ) |  |  | 0.7 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | (0.3 | ) |  |  | 0.1 |  |  |  | (0.2 | ) |
| Environmental liabilities(a) |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 0.4 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (0.7 | ) |  |  | (0.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractor tax payments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other items, net (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 174.8 |  |  | $ | (53.8 | ) |  | $ | 121.0 |  |  | $ | 154.5 |  |  | $ | (43.0 | ) |  | $ | 111.5 |  |
| Earnings per share from continuing operations—diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.71 |  |  |  |  |  |  |  |  |  |  | $ | 2.52 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | 0.08 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Special legal contingency charges(a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |
| Asbestos-related litigation(a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.83 |  |  |  |  |  |  |  |  |  |  | $ | 2.53 |  |

[0001193125-17-233271:8k_2_02:78]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-17-233271:8k_2_02:79]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-17-233271:8k_2_02:80]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-17-233271:8k_2_02:81]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-17-233271:8k_2_02:82]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-17-233271:8k_2_02:83]
|  |  | For the Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | Pre-Tax |  |  | TaxImpact (e) |  |  | AfterTax |  |  | Pre-Tax |  |  | TaxImpact (e) |  |  | AfterTax |  |
| Income from continuing operations, a GAAP measure |  | $ | 220.6 |  |  | $ | (60.7 | ) |  | $ | 159.9 |  |  | $ | 192.0 |  |  | $ | (55.9 | ) |  | $ | 136.1 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | 0.4 |  |
| Special product quality adjustments (b) |  |  | 5.2 |  |  |  | (1.8 | ) |  |  | 3.4 |  |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |
| Special legal contingency charges (a) |  |  | 2.0 |  |  |  | (0.1 | ) |  |  | 1.9 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Asbestos-related litigation (a) |  |  | 2.4 |  |  |  | (0.8 | ) |  |  | 1.6 |  |  |  | 1.9 |  |  |  | (0.7 | ) |  |  | 1.2 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 0.9 |  |  |  | (0.4 | ) |  |  | 0.5 |  |  |  | (0.7 | ) |  |  | 0.2 |  |  |  | (0.5 | ) |
| Inventory write down, after tax (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Environmental liabilities (a) |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 0.5 |  |  |  | 1.1 |  |  |  | (0.2 | ) |  |  | 0.9 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (8.1 | ) |  |  | (8.1 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractor tax payments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.3 |  |
| Other items (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 0.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 232.0 |  |  | $ | (72.1 | ) |  | $ | 159.9 |  |  | $ | 195.4 |  |  | $ | (56.9 | ) |  | $ | 138.5 |  |
| Earnings per share from continuing operations—diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 3.70 |  |  |  |  |  |  |  |  |  |  | $ | 3.07 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | 0.08 |  |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |
| Special legal contingency charges (a) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Asbestos-related litigation (a) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |
| Inventory write down, after tax (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.19 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 3.72 |  |  |  |  |  |  |  |  |  |  | $ | 3.12 |  |

[0001193125-17-233271:8k_2_02:84]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-17-233271:8k_2_02:85]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-17-233271:8k_2_02:86]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-17-233271:8k_2_02:87]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-17-233271:8k_2_02:88]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-17-233271:8k_2_02:89]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized (gains) losses on settled future contracts (a) |  | $ | (0.4 | ) |  | $ | 0.4 |  |  | $ | (0.8 | ) |  | $ | 0.9 |  |
| Foreign currency exchange (gains) losses (a) |  |  | 0.5 |  |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.5 |  |
| Gains on disposal of fixed assets (a) |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | 0.1 |  |  |  | (0.3 | ) |  |  | 0.9 |  |  |  | (0.7 | ) |
| Special legal contingency charges (b) |  |  | 1.2 |  |  |  | (1.7 | ) |  |  | 2.0 |  |  |  | — |  |
| Asbestos-related litigation (b) |  |  | 0.7 |  |  |  | 1.1 |  |  |  | 2.4 |  |  |  | 1.9 |  |
| Environmental liabilities (b) |  |  | 0.2 |  |  |  | 0.5 |  |  |  | 0.7 |  |  |  | 1.1 |  |
| Contractor tax payments (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.5 |  |
| Acquisition costs (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.4 |  |
| Other items, net (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Losses and other expenses, net (pre-tax) |  | $ | 2.3 |  |  | $ | 0.4 |  |  | $ | 5.4 |  |  | $ | 4.7 |  |

[0001193125-17-233271:8k_2_02:90]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-17-233271:8k_2_02:91]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-17-233271:8k_2_02:92]
Reconciliation of Earnings per Share from Continuing Operations—Diluted, a GAAP measure, to Estimated
Adjusted Earnings per Share from Continuing Operations—Diluted, a Non-GAAP measure

[0001193125-17-233271:8k_2_02:93]
|  |  | For the Year |  |
|  |  | Ended |  |
|  |  | December 31, |  |
|  |  | 2017 |  |
|  |  | ESTIMATED |  |
| Earnings per share from continuing operations—diluted, a GAAP measure |  | $ | 7.73 - $8.13 |  |
| Excess tax benefits from share-based compensation and other items |  |  | 0.02 |  |
| Adjusted Earnings per share from continuing operations—diluted, a Non-GAAP measure |  | $ | 7.75 - $8.15 |  |

[0001193125-17-233271:8k_2_02:94]
Reconciliation of Average Shares Outstanding—Diluted, a GAAP measure, to Adjusted Average Shares Outstanding -Diluted,
a Non-GAAP measure (shares in millions):

[0001193125-17-233271:8k_2_02:95]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Average shares outstanding—diluted, a GAAP measure |  |  | 42.9 |  |  |  | 44.1 |  |  |  | 43.2 |  |  |  | 44.4 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | (0.2 | ) |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |
| Adjusted average shares outstanding—diluted, a Non- GAAP measure |  |  | 42.7 |  |  |  | 44.1 |  |  |  | 43.0 |  |  |  | 44.4 |  |

[0001193125-17-233271:8k_2_02:96]
Reconciliation of Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in
millions)

[0001193125-17-233271:8k_2_02:97]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 59.3 |  |  | $ | 76.3 |  |  | $ | (48.3 | ) |  | $ | (25.3 | ) |
| Purchases of property, plant and equipment |  |  | (18.5 | ) |  |  | (17.9 | ) |  |  | (43.4 | ) |  |  | (41.7 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Free cash flow, a Non-GAAP measure |  | $ | 40.9 |  |  | $ | 58.4 |  |  | $ | (91.5 | ) |  | $ | (67.0 | ) |

[0001193125-17-233271:8k_2_02:98]
|  |  | Trailing |  |
|  |  | Twelve |  |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | Months toJune 30, 2017 |  |
| Adjusted EBIT (a) |  | $ | 509.4 |  |
| Depreciation and amortization expense (b) |  |  | 61.6 |  |
| EBITDA (a + b) |  | $ | 571.0 |  |
| Total debt at June 30, 2017 (c) |  | $ | 1,188.9 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.1 |  |

[0001193125-17-233271:8k_2_02:99]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes,
a GAAP measure (dollars in millions)

[0001193125-17-233271:8k_2_02:100]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | June 30, 2017 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 509.4 |  |
| Special product quality adjustments |  |  | 5.2 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 10.3 |  |
| Restructuring charges |  |  | 1.5 |  |
| Interest expense, net |  |  | 29.9 |  |
| Pension Settlement |  |  | 31.4 |  |
| Other expenses, net |  |  | (0.2 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 431.3 |  |
