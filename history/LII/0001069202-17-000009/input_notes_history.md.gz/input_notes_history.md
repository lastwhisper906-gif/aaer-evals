# LII note change history — 0001069202-17-000005 → 0001069202-17-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-07-24):
[0001069202-17-000009:note_history:1]
We offer warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.
  (was, 2017-04-24, similarity 0.9946):
[0001069202-17-000005:note_history:1]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

- changed (2017-07-24):
[0001069202-17-000009:note_history:2]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 32.5 |  |  | $ | 30.0 |  |
| Other liabilities | 73.1 |  |  | 71.1 |  |
| Total warranty liability | $ | 105.6 |  |  | $ | 101.1 |  |
  (was, 2017-04-24, similarity 0.9741):
[0001069202-17-000005:note_history:2]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 30.8 |  |  | $ | 30.0 |  |
| Other liabilities | 71.8 |  |  | 71.1 |  |
| Total warranty liability | $ | 102.6 |  |  | $ | 101.1 |  |

- changed (2017-07-24):
[0001069202-17-000009:note_history:3]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2017 were as follows (in millions):
  (was, 2017-04-24, similarity 0.9404):
[0001069202-17-000005:note_history:3]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2017 were as follows (in millions):

- changed (2017-07-24):
[0001069202-17-000009:note_history:4]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (11.6 | ) |
| Changes resulting from issuance of new warranties | 19.6 |  |
| Changes in estimates associated with pre-existing liabilities | (4.2 | ) |
| Changes in foreign currency translation rates and other | 0.7 |  |
| Total warranty liability as of June 30, 2017 | $ | 105.6 |  |
  (was, 2017-04-24, similarity 0.987):
[0001069202-17-000005:note_history:4]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (5.2 | ) |
| Changes resulting from issuance of new warranties | 8.2 |  |
| Changes in estimates associated with pre-existing liabilities | (1.7 | ) |
| Changes in foreign currency translation rates and other | 0.2 |  |
| Total warranty liability as of March 31, 2017 | $ | 102.6 |  |

- changed (2017-07-24):
[0001069202-17-000009:note_history:5]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. We currently estimate our probable liability for a certain supplier quality issue within a range of $0.9 million and $9.1 million with all amounts in that range equally likely. We have accrued a $0.9 million liability in Accrued expenses on the Consolidated Balance Sheet at June 30, 2017. The supplier is reimbursing us for the majority of the costs related to this liability.
  (was, 2017-04-24, similarity 0.8745):
[0001069202-17-000005:note_history:5]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. We currently estimate our probable liability for a certain supplier quality issue within a range of $0.9 million and $9.1 million with all amounts in that range equally likely. We have accrued a $0.9 million liability in Accrued expenses on the Consolidated Balance Sheet at March 31, 2017. The supplier is reimbursing the majority of costs related to this liability.

- added (2017-07-24):
[0001069202-17-000009:note_history:6]
We have identified a product quality issue in a residential heating and cooling product line in the Residential Heating & Cooling  segment that results from a defective vendor-supplied component.  This defect has been isolated, the vendor has begun supplying corrected components, and we have begun installing the corrected components.  For the quarter ended June 30, 2017, we recorded an expense of $5.2 million relating to total estimated repair costs.  The expense related to this product quality issue has been classified in Cost of goods sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses on the Consolidated Balance Sheet.

- changed (2017-07-24):
[0001069202-17-000009:note_history:7]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2017 and 2016, expense for asbestos-related litigation was $2.4 million and $1.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.
  (was, 2017-04-24, similarity 0.9366):
[0001069202-17-000005:note_history:7]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended  March 31, 2017 and 2016, expense for asbestos-related litigation was $1.7 million and $0.8 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation.

- changed (2017-07-24):
[0001069202-17-000009:note_history:8]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants. The alleged payment was purportedly made to release a shipment of goods being held by Russian customs officials due to inaccurate paperwork. The value of the shipment was approximately €62,000 (approximately US $68,500). The allegations are related to our subsidiary in Russia, which had 2016 annual sales of US $4 million. The scope of the investigation was later expanded to include our operations in Poland and Ukraine. To date, the investigation has not resulted in any evidence of other potentially improper payments. However, the investigation has raised questions regarding possible irregularities with respect to possible non-compliance with customs documents and procedures related to these operations.  The investigation is ongoing. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.
  (was, 2017-04-24, similarity 0.9996):
[0001069202-17-000005:note_history:8]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants. The alleged payment was purportedly made to release a shipment of goods being held by Russian customs officials due to inaccurate paperwork. The value of the shipment was approximately €62,000(approximately US $68,500). The allegations are related to our subsidiary in Russia, which had 2016 annual sales of US $4 million. The scope of the investigation was later expanded to include our operations in Poland and Ukraine. To date, the investigation has not resulted in any evidence of other potentially improper payments. However, the investigation has raised questions regarding possible irregularities with respect to possible non-compliance with customs documents and procedures related to these operations.  The investigation is ongoing. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-07-24):
[0001069202-17-000009:note_history:9]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2017, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2017-04-24, similarity 0.9537):
[0001069202-17-000005:note_history:9]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2017, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three  months ended March 31, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- added (2017-07-24):
[0001069202-17-000009:note_history:10]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls.

- added (2017-07-24):
[0001069202-17-000009:note_history:11]
| • | We recognized discrete tax benefits of $0.7 million and $8.1 million in the income taxes line item of our consolidated statements of operations for the three and six months ended June 30, 2017 respectively, related to excess tax benefits upon vesting or settlement in that period. |

- changed (2017-07-24):
[0001069202-17-000009:note_history:12]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three and six months ended June 30, 2017. |
  (was, 2017-04-24, similarity 0.9561):
[0001069202-17-000005:note_history:12]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three months ended March 31, 2017. |

- removed (2017-07-24):
[0001069202-17-000005:note_history:13]
Our fiscal year ends on December 31 and each quarter is comprised of approximately 13 weeks but the number of days per quarter may vary year-over-year. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.  The first quarter of 2017 included the benefit of five more days, or 6%, this year than in the first quarter last year.  This balances out on a full-year basis with the fourth quarter having 6% fewer days than a year ago.

- removed (2017-07-24):
[0001069202-17-000005:note_history:14]
| • | We recognized discrete tax benefits of $7.4 million in the income taxes line item of our consolidated statement of operations for the three months ended March 31, 2017 related to excess tax benefits upon vesting or settlement in that period. |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-07-24):
[0001069202-17-000009:note_history:15]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.45 | % |  | 2.00 | % |
  (was, 2017-04-24, similarity 0.9538):
[0001069202-17-000005:note_history:15]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.23 | % |  | 2.00 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-07-24):
[0001069202-17-000009:note_history:16]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 250.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.3 |  |  | 2.4 |  |
| Total short-term debt | $ | 251.3 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.6 |  |  | $ | 0.8 |  |
| Domestic credit facility | 15.0 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 15.0 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.8 |  |  | $ | 15.0 |  |
| Domestic credit facility | 562.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.7 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 922.6 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,188.9 |  |  | $ | 868.2 |  |
  (was, 2017-04-24, similarity 0.9931):
[0001069202-17-000005:note_history:16]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 200.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.6 |  |  | 2.4 |  |
| Total short-term debt | $ | 201.6 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.7 |  |  | $ | 0.8 |  |
| Domestic credit facility | 7.5 |  |  | — |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 207.6 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.9 |  |  | $ | 15.0 |  |
| Domestic credit facility | 334.0 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (5.0 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 693.9 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,103.1 |  |  | $ | 868.2 |  |

- changed (2017-07-24):
[0001069202-17-000009:note_history:17]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.3 million and $2.4 million of foreign obligations as of June 30, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.8 million  and $20.4 million during the six months ended June 30, 2017 and 2016, respectively. Repayments on the facilities were $1.8 million and $20.0 million during the six months ended June 30, 2017 and 2016, respectively.
  (was, 2017-04-24, similarity 0.9101):
[0001069202-17-000005:note_history:17]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.6 million and $2.4 million of foreign obligations as of March 31, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.3 million  and $1.2 million during the three months ended March 31, 2017 and 2016, respectively. Repayments on the facilities were $1.1 million and $1.6 million during the three months ended March 31, 2017 and 2016, respectively.

- changed (2017-07-24):
[0001069202-17-000009:note_history:18]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 250.0 |  |  | $ | 250.0 |  |
| Less: Beneficial interest sold | 250.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |
  (was, 2017-04-24, similarity 0.9689):
[0001069202-17-000005:note_history:18]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 200.0 |  |  | $ | 250.0 |  |
| Beneficial interest sold | 200.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |

- changed (2017-07-24):
[0001069202-17-000009:note_history:19]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The rates as of June 30, 2017 and December 31, 2016 were 1.90% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2017-04-24, similarity 0.9764):
[0001069202-17-000005:note_history:19]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rates for March 31, 2017 and December 31, 2016 were 1.70% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2017-07-24):
[0001069202-17-000009:note_history:20]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2017, we believe we were in compliance with all covenant requirements.
  (was, 2017-04-24, similarity 0.9932):
[0001069202-17-000005:note_history:20]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of  March 31, 2017, we believe we were in compliance with all covenant requirements.

- changed (2017-07-24):
[0001069202-17-000009:note_history:21]
On August 30, 2016, we replaced an earlier credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $577.5 million, of which $220.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of June 30, 2017. Subject to covenant limitations, $288.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.
  (was, 2017-04-24, similarity 0.9914):
[0001069202-17-000005:note_history:21]
On August 30, 2016, we replaced an earlier $950.0 million credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $341.5 million, of which $220.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of March 31, 2017. Subject to covenant limitations, $524.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2017-07-24):
[0001069202-17-000009:note_history:22]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.45 | % |  | 2.00 | % |
  (was, 2017-04-24, similarity 0.9538):
[0001069202-17-000005:note_history:22]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.23 | % |  | 2.00 | % |

- changed (2017-07-24):
[0001069202-17-000009:note_history:23]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2017, we believe we were in compliance with all covenant requirements.
  (was, 2017-04-24, similarity 0.9955):
[0001069202-17-000005:note_history:23]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2017, we believe we were in compliance with all covenant requirements.

- changed (2017-07-24):
[0001069202-17-000009:note_history:24]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also repaid $200.0 million of senior unsecured notes issued in 2010 that matured on May 15, 2017.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2017, we believe we were in compliance with all covenant requirements.
  (was, 2017-04-24, similarity 0.8573):
[0001069202-17-000005:note_history:24]
We issued $350.0 million of senior unsecured notes in November 2016 (the "2016 Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also have $200.0 million of senior unsecured notes issued in 2010 (the "2010 Notes") which will mature on  May 15, 2017  with interest being paid at 4.90%   per annum semiannually. Both Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and, in the case of the 2010 Notes, transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of  March 31, 2017, we believe we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-07-24):
[0001069202-17-000009:note_history:25]
|  | As of June 30, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 250.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.3 |  |  | 2.4 |  |
| Total short-term debt | $ | 251.3 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.6 |  |  | $ | 0.8 |  |
| Domestic credit facility | 15.0 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 15.0 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.8 |  |  | $ | 15.0 |  |
| Domestic credit facility | 562.5 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.7 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 922.6 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,188.9 |  |  | $ | 868.2 |  |
  (was, 2017-04-24, similarity 0.9931):
[0001069202-17-000005:note_history:25]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 200.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.6 |  |  | 2.4 |  |
| Total short-term debt | $ | 201.6 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.7 |  |  | $ | 0.8 |  |
| Domestic credit facility | 7.5 |  |  | — |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 207.6 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.9 |  |  | $ | 15.0 |  |
| Domestic credit facility | 334.0 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (5.0 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 693.9 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,103.1 |  |  | $ | 868.2 |  |
