# LII 8-K — 0001193125-15-256551 filed 2015-07-20

## item codes, every 8-K on or before 2015-07-20

- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2015-07-20

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-256551:8k_2_02:1]
EX-99.1
2
d86394dex991.htm
EX-99.1

[0001193125-15-256551:8k_2_02:2]
EX-99.1

[0001193125-15-256551:8k_2_02:3]
Exhibit 99.1

[0001193125-15-256551:8k_2_02:4]
Lennox International Reports Record Profit in Second Quarter

[0001193125-15-256551:8k_2_02:5]
| • |  | Revenue up 3% and up 6% at constant currency |

[0001193125-15-256551:8k_2_02:6]
| • |  | Adjusted EPS from continuing operations up 22% to record $1.84 |

[0001193125-15-256551:8k_2_02:7]
| • |  | GAAP EPS from continuing operations up 19% to record $1.79 |

[0001193125-15-256551:8k_2_02:8]
| • |  | Updating 2015 revenue growth at constant currency guidance range from 4-8% to 4-7% |

[0001193125-15-256551:8k_2_02:9]
| • |  | Narrowing 2015 adjusted EPS from continuing operations guidance range from $5.20-$5.60 to $5.25-$5.50 |

[0001193125-15-256551:8k_2_02:10]
DALLAS, July 20, 2015 – Lennox International Inc. (NYSE: LII) today reported financial results for the second quarter of 2015. Financial results
reflect sold businesses in discontinued operations.

[0001193125-15-256551:8k_2_02:11]
Revenue for the second quarter was $993 million, up 3% from the prior-year quarter including the
negative impact from foreign exchange. At constant currency, revenue was up 6% on growth across all three business segments. Adjusted earnings per share from continuing operations was a record $1.84, up 22% from the prior-year quarter. On a GAAP
basis, earnings per share from continuing operations was a record $1.79, up 19% from the prior-year quarter.

[0001193125-15-256551:8k_2_02:12]
“Lennox International posted record
profits in the second quarter with margin expansion across all three of our businesses,” said Chairman and CEO Todd Bluedorn. “Total segment profit margin for the company expanded 120 basis points from the prior-year quarter to a record
13.5%. In our Residential business, we hit record revenue, margin and profit levels. Residential revenue was up 6% at constant currency, and margin expanded 190 basis points to 18.0%. In Commercial, segment profit reached new highs while revenue and
margin set second-quarter records. Commercial revenue was up 10% at constant currency, and margin expanded 80 basis points to 17.0%. North America national account business resumed growth as expected, with revenue up high single-digits, and we
continued to see success in non-national account business with mid-teens revenue growth. In Refrigeration, revenue was up 4% at constant currency, driven by high single-digit growth in North America. Refrigeration margin ticked up 10 basis points to
7.2%, including headwinds from negative foreign exchange and the mid-2014 repeal of the carbon tax on refrigerant in Australia.

[0001193125-15-256551:8k_2_02:13]
“Looking ahead for
the company overall, we now expect revenue growth of 4-7% at constant currency and adjusted EPS from continuing operations of $5.25-$5.50 for the full year. The company remains focused on driving our operational initiatives for higher profitability
and is well-positioned to capitalize on end market growth and market share gains. With a strong balance sheet and cash generation, we will continue to invest in the business for future growth as well as return cash to shareholders through dividends
and stock repurchases.”

[0001193125-15-256551:8k_2_02:14]
FINANCIAL HIGHLIGHTS

[0001193125-15-256551:8k_2_02:15]
Revenue: Revenue for the second quarter was $993 million, up 3% from the prior-year quarter. At constant currency, revenue was up 6%. Volume and
price/mix were up on a revenue basis from the prior-year quarter.

[0001193125-15-256551:8k_2_02:16]
Gross Profit: Gross profit in the second quarter was $283 million, up 8% from
$263 million in the prior-year quarter. Gross margin was 28.6%, up 130 basis points from 27.3% in the prior-year quarter. Gross profit was positively impacted by higher volume, favorable price, and lower material costs, with partial offsets from
unfavorable foreign exchange, negative mix, lower Australian refrigerant profitability, and investments in distribution expansion.

[0001193125-15-256551:8k_2_02:17]
Income from
Continuing Operations: Adjusted income from continuing operations in the second quarter was $83.9 million, or $1.84 per share, compared to $74.9 million, or $1.51 per share, in the prior-year quarter. Adjusted earnings from continuing operations
for the second quarter of 2015 excludes $2.3 million in after-tax charges: $1.3 million for restructuring activities and $1.0 million, net, for other items.

[0001193125-15-256551:8k_2_02:18]
On a GAAP basis, income from continuing operations for the second quarter was $81.6 million, or $1.79 per share, compared to $74.6 million, or $1.50 per
share, in the prior-year quarter.

[0001193125-15-256551:8k_2_02:19]
Free Cash Flow and Total Debt: Net cash from operations in the second quarter was $70 million compared to $52
million in the prior-year quarter. The company invested $15 million in capital assets in the second quarter compared to $24 million in the second quarter a year ago. Free cash flow was $55 million compared to $28 million in the prior-year quarter.
Total debt at the end of the second quarter was $1,056 million. Total cash and cash equivalents were $48 million at the end of the quarter. The company paid $14 million in dividends in the second quarter. In May 2015, the company announced a 20%
increase in its dividend to $0.36 per share on a quarterly basis. The company’s previously announced $450 million accelerated stock repurchase program continues and is still expected to be completed in the second half of 2015.

[0001193125-15-256551:8k_2_02:20]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-15-256551:8k_2_02:21]
Residential Heating & Cooling

[0001193125-15-256551:8k_2_02:22]
Second quarter
2015 revenue in the Residential Heating & Cooling business segment was a record $555 million, up 5% from the prior-year quarter. At constant currency, revenue was up 6%. Segment profit was a record $100 million, up 18% from the prior-year
quarter. Segment profit margin was a record 18.0%, up 190 basis points from the prior-year quarter. Results were primarily impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from unfavorable foreign
exchange and investments in SG&A and distribution expansion.

[0001193125-15-256551:8k_2_02:23]
Commercial Heating & Cooling

[0001193125-15-256551:8k_2_02:24]
Revenue in the Commercial Heating & Cooling business segment was a second-quarter record $254 million, up 5% from the prior-year quarter. At constant
currency, revenue was up 10%. Segment profit was a record $43 million, up 10% from the prior-year quarter. Segment profit margin was a second-quarter record 17.0%, up 80 basis points from the prior-year quarter. Results were primarily impacted by
higher volume and lower material costs, with partial offsets from unfavorable mix, unfavorable foreign exchange, and higher SG&A, including investments to support distribution expansion and growth in the VRF market.

[0001193125-15-256551:8k_2_02:25]
Refrigeration

[0001193125-15-256551:8k_2_02:26]
Revenue in the Refrigeration business
segment was $184 million in the second quarter, down 4%. At constant currency, revenue was up 4%. Segment profit was $13 million compared to $14 million in the prior-year quarter. Segment profit margin was 7.2%, up 10 basis points from the
prior-year quarter. Results were primarily impacted by higher volume, higher factory productivity, and lower material costs, with partial offsets from lower Australian refrigerant profitability, unfavorable mix in North America supermarket business,
and unfavorable foreign exchange.

[0001193125-15-256551:8k_2_02:27]
FULL-YEAR OUTLOOK

[0001193125-15-256551:8k_2_02:28]
For 2015, the company is updating guidance for revenue and adjusted EPS from continuing operations.

[0001193125-15-256551:8k_2_02:29]
|  | • |  | Updating revenue growth guidance at constant currency from 4-8% to 4-7%. |

[0001193125-15-256551:8k_2_02:30]
|  | • |  | Still expecting a negative 3 point impact on revenue from foreign exchange on a full-year basis; updating revenue growth guidance at actual currency from 1-5% to 1-4%. |

[0001193125-15-256551:8k_2_02:31]
|  | • |  | Narrowing adjusted EPS from continuing operations guidance from $5.20-$5.60 to $5.25-$5.50. |

[0001193125-15-256551:8k_2_02:32]
|  | • |  | Updating GAAP EPS from continuing operations guidance from $5.14-$5.54 to $5.14-$5.39. |

[0001193125-15-256551:8k_2_02:33]
|  | • |  | Reiterating effective tax rate guidance of 34-35% on a full-year basis. |

[0001193125-15-256551:8k_2_02:34]
|  | • |  | Lowering capital expenditure guidance from approximately $85 million to $80 million. |

[0001193125-15-256551:8k_2_02:35]
CONFERENCE CALL INFORMATION

[0001193125-15-256551:8k_2_02:36]
A conference call to discuss the company’s second quarter results will be held this morning at 8:30 a.m. Central time. To listen, please call the
conference call line at 612-288-0329 at least 10 minutes prior to the scheduled start time and use reservation number 364132. The conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay
will be available from 11:00 a.m. Central time on July 20 through July 27, 2015 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 364132. The call will also be archived on the company’s web site.

[0001193125-15-256551:8k_2_02:37]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International is listed on the New York
Stock Exchange under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-15-256551:8k_2_02:38]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-256551:8k_2_02:39]
Consolidated Statements of Operations

[0001193125-15-256551:8k_2_02:40]
(Unaudited)

[0001193125-15-256551:8k_2_02:41]
| (Amounts in millions, except per share data) |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 992.5 |  |  | $ | 960.7 |  |  | $ | 1,678.3 |  |  | $ | 1,656.1 |  |
| Cost of goods sold |  |  | 709.1 |  |  |  | 698.1 |  |  |  | 1,231.9 |  |  |  | 1,225.4 |  |
| Gross profit |  |  | 283.4 |  |  |  | 262.6 |  |  |  | 446.4 |  |  |  | 430.7 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 152.9 |  |  |  | 148.9 |  |  |  | 286.2 |  |  |  | 284.5 |  |
| Losses (gains) and other expenses, net |  |  | 3.3 |  |  |  | (1.0 | ) |  |  | 8.9 |  |  |  | 1.4 |  |
| Restructuring charges |  |  | 1.8 |  |  |  | 0.2 |  |  |  | 2.1 |  |  |  | 0.3 |  |
| Income from equity method investments |  |  | (5.5 | ) |  |  | (4.6 | ) |  |  | (8.8 | ) |  |  | (8.5 | ) |
| Operational income from continuing operations |  |  | 130.9 |  |  |  | 119.1 |  |  |  | 158.0 |  |  |  | 153.0 |  |
| Interest expense, net |  |  | 6.4 |  |  |  | 3.7 |  |  |  | 12.2 |  |  |  | 7.0 |  |
| Other expense (income), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Income from continuing operations before income taxes |  |  | 124.5 |  |  |  | 115.4 |  |  |  | 145.8 |  |  |  | 146.0 |  |
| Provision for income taxes |  |  | 42.9 |  |  |  | 40.8 |  |  |  | 50.2 |  |  |  | 51.5 |  |
| Income from continuing operations |  |  | 81.6 |  |  |  | 74.6 |  |  |  | 95.6 |  |  |  | 94.5 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | (0.7 | ) |  |  | (1.1 | ) |  |  | (0.8 | ) |  |  | (1.1 | ) |
| Benefit from income taxes |  |  | (0.3 | ) |  |  | (0.4 | ) |  |  | (0.3 | ) |  |  | (0.4 | ) |
| Loss from discontinued operations |  |  | (0.4 | ) |  |  | (0.7 | ) |  |  | (0.5 | ) |  |  | (0.7 | ) |
| Net income |  | $ | 81.2 |  |  | $ | 73.9 |  |  | $ | 95.1 |  |  | $ | 93.8 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.81 |  |  | $ | 1.53 |  |  | $ | 2.13 |  |  | $ | 1.93 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | (0.02 | ) |  |  | (0.01 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 1.80 |  |  | $ | 1.51 |  |  | $ | 2.12 |  |  | $ | 1.92 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.79 |  |  | $ | 1.50 |  |  | $ | 2.10 |  |  | $ | 1.90 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | (0.01 | ) |
| Net income |  | $ | 1.78 |  |  | $ | 1.49 |  |  | $ | 2.09 |  |  | $ | 1.89 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 45.0 |  |  |  | 48.8 |  |  |  | 44.9 |  |  |  | 48.9 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 45.6 |  |  |  | 49.6 |  |  |  | 45.6 |  |  |  | 49.7 |  |
| Cash dividends declared per share |  | $ | 0.36 |  |  | $ | 0.30 |  |  | $ | 0.66 |  |  | $ | 0.54 |  |

[0001193125-15-256551:8k_2_02:42]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-256551:8k_2_02:43]
Segment Net Sales and Profit (Loss)

[0001193125-15-256551:8k_2_02:44]
(Unaudited)

[0001193125-15-256551:8k_2_02:45]
| (Amounts in millions) |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 555.1 |  |  | $ | 527.7 |  |  | $ | 917.7 |  |  | $ | 869.8 |  |
| Commercial Heating & Cooling |  |  | 253.6 |  |  |  | 241.0 |  |  |  | 413.5 |  |  |  | 414.0 |  |
| Refrigeration |  |  | 183.8 |  |  |  | 192.0 |  |  |  | 347.1 |  |  |  | 372.3 |  |
|  |  | $ | 992.5 |  |  | $ | 960.7 |  |  | $ | 1,678.3 |  |  | $ | 1,656.1 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 99.9 |  |  | $ | 85.0 |  |  | $ | 131.2 |  |  | $ | 109.4 |  |
| Commercial Heating & Cooling |  |  | 43.0 |  |  |  | 39.0 |  |  |  | 50.7 |  |  |  | 49.2 |  |
| Refrigeration |  |  | 13.3 |  |  |  | 13.7 |  |  |  | 17.2 |  |  |  | 25.8 |  |
| Corporate and other |  |  | (22.0 | ) |  |  | (19.2 | ) |  |  | (33.7 | ) |  |  | (30.6 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 134.2 |  |  |  | 118.5 |  |  |  | 165.4 |  |  |  | 153.8 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (1.1 | ) |  |  | (0.4 | ) |  |  | (1.4 | ) |  |  | (0.3 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 2.6 |  |  |  | (0.4 | ) |  |  | 6.7 |  |  |  | 0.8 |  |
| Restructuring charges |  |  | 1.8 |  |  |  | 0.2 |  |  |  | 2.1 |  |  |  | 0.3 |  |
| Interest expense, net |  |  | 6.4 |  |  |  | 3.7 |  |  |  | 12.2 |  |  |  | 7.0 |  |
| Other expense (income), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Income from continuing operations before income taxes |  | $ | 124.5 |  |  | $ | 115.4 |  |  | $ | 145.8 |  |  | $ | 146.0 |  |

[0001193125-15-256551:8k_2_02:46]
| (1) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-15-256551:8k_2_02:47]
|  | • |  | Special product quality adjustments; |

[0001193125-15-256551:8k_2_02:48]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-15-256551:8k_2_02:49]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-15-256551:8k_2_02:50]
|  | • |  | Special legal contingency charges, |

[0001193125-15-256551:8k_2_02:51]
|  | • |  | Asbestos-related litigation, |

[0001193125-15-256551:8k_2_02:52]
|  | • |  | Contractor tax payments, |

[0001193125-15-256551:8k_2_02:53]
|  | • |  | Environmental liabilities, and |

[0001193125-15-256551:8k_2_02:54]
|  | • |  | Other items, net; |

[0001193125-15-256551:8k_2_02:55]
|  | • |  | Restructuring charges; |

[0001193125-15-256551:8k_2_02:56]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments; |

[0001193125-15-256551:8k_2_02:57]
|  | • |  | Interest expense, net; and |

[0001193125-15-256551:8k_2_02:58]
|  | • |  | Other expense, net. |

[0001193125-15-256551:8k_2_02:59]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-256551:8k_2_02:60]
Consolidated Balance Sheets

[0001193125-15-256551:8k_2_02:61]
| (Amounts in millions, except shares and par values) |  | As of June 30, 2015 |  |  | As of December 31, 2014 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 47.5 |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net of allowances of $7.5 and $7.9 in 2015 and 2014, respectively |  |  | 609.3 |  |  |  | 421.4 |  |
| Inventories, net |  |  | 540.7 |  |  |  | 463.3 |  |
| Deferred income taxes, net |  |  | 31.6 |  |  |  | 32.5 |  |
| Other assets |  |  | 57.6 |  |  |  | 59.3 |  |
| Total current assets |  |  | 1,286.7 |  |  |  | 1,014.0 |  |
| Property, plant and equipment, net of accumulated depreciation of $668.7 and $654.1 in 2015 and 2014, respectively |  |  | 352.1 |  |  |  | 358.6 |  |
| Goodwill |  |  | 204.5 |  |  |  | 209.4 |  |
| Deferred income taxes |  |  | 95.0 |  |  |  | 97.5 |  |
| Other assets, net |  |  | 88.0 |  |  |  | 84.8 |  |
| Total assets |  | $ | 2,026.3 |  |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 226.1 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt |  |  | 16.3 |  |  |  | 24.0 |  |
| Accounts payable |  |  | 404.3 |  |  |  | 324.3 |  |
| Accrued expenses |  |  | 241.6 |  |  |  | 239.0 |  |
| Income taxes payable |  |  | 10.4 |  |  |  | 13.4 |  |
| Total current liabilities |  |  | 898.7 |  |  |  | 827.3 |  |
| Long-term debt |  |  | 813.2 |  |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions |  |  | 3.4 |  |  |  | 4.5 |  |
| Pensions |  |  | 133.2 |  |  |  | 129.9 |  |
| Other liabilities |  |  | 121.5 |  |  |  | 118.6 |  |
| Total liabilities |  |  | 1,970.0 |  |  |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 848.1 |  |  |  | 824.9 |  |
| Retained earnings |  |  | 1,087.3 |  |  |  | 1,022.1 |  |
| Accumulated other comprehensive loss |  |  | (178.9 | ) |  |  | (153.5 | ) |
| Treasury stock, at cost, 42,149,601 shares and 42,535,126 shares in 2015 and 2014, respectively |  |  | (1,701.7 | ) |  |  | (1,686.0 | ) |
| Noncontrolling interests |  |  | 0.6 |  |  |  | 0.6 |  |
| Total stockholders’ equity |  |  | 56.3 |  |  |  | 9.0 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,026.3 |  |  | $ | 1,764.3 |  |

[0001193125-15-256551:8k_2_02:62]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-256551:8k_2_02:63]
Consolidated Statements of Cash Flows

[0001193125-15-256551:8k_2_02:64]
(Unaudited)

[0001193125-15-256551:8k_2_02:65]
| (Amounts in millions) |  | For the Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 95.1 |  |  | $ | 93.8 |  |
| Net loss from discontinued operations |  |  | 0.5 |  |  |  | 0.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (8.8 | ) |  |  | (8.5 | ) |
| Dividends from affiliates |  |  | 3.4 |  |  |  | 1.7 |  |
| Restructuring expenses, net of cash paid |  |  | 1.2 |  |  |  | — |  |
| Provision for bad debts |  |  | 1.6 |  |  |  | 1.3 |  |
| Unrealized losses on derivative contracts |  |  | 0.3 |  |  |  | (0.1 | ) |
| Stock-based compensation expense |  |  | 10.8 |  |  |  | 10.7 |  |
| Depreciation and amortization |  |  | 30.6 |  |  |  | 30.0 |  |
| Deferred income taxes |  |  | (0.9 | ) |  |  | 0.6 |  |
| Other items, net |  |  | 0.2 |  |  |  | 0.3 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (199.2 | ) |  |  | (168.2 | ) |
| Inventories |  |  | (85.3 | ) |  |  | (133.0 | ) |
| Other current assets |  |  | (0.1 | ) |  |  | (4.2 | ) |
| Accounts payable |  |  | 87.3 |  |  |  | 114.3 |  |
| Accrued expenses |  |  | 6.7 |  |  |  | 3.4 |  |
| Income taxes payable and receivable |  |  | (1.4 | ) |  |  | (6.0 | ) |
| Other |  |  | 6.2 |  |  |  | (9.5 | ) |
| Net cash used in discontinued operations |  |  | (0.5 | ) |  |  | (0.7 | ) |
| Net cash used in operating activities |  |  | (52.3 | ) |  |  | (73.4 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (33.0 | ) |  |  | (41.2 | ) |
| Net cash used in investing activities |  |  | (33.0 | ) |  |  | (41.2 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 0.4 |  |  |  | (0.6 | ) |
| Asset securitization borrowings |  |  | 40.0 |  |  |  | 20.0 |  |
| Asset securitization payments |  |  | (40.0 | ) |  |  | — |  |
| Long-term debt payments |  |  | (23.0 | ) |  |  | (0.9 | ) |
| Borrowings from credit facility |  |  | 999.0 |  |  |  | 1,018.5 |  |
| Payments on credit facility |  |  | (845.5 | ) |  |  | (832.5 | ) |
| Proceeds from employee stock purchases |  |  | 1.1 |  |  |  | 1.0 |  |
| Repurchases of common stock |  |  | — |  |  |  | (50.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (21.8 | ) |  |  | (10.8 | ) |
| Excess tax benefits related to share-based payments |  |  | 17.3 |  |  |  | 4.0 |  |
| Cash dividends paid |  |  | (26.9 | ) |  |  | (23.6 | ) |
| Net cash provided by financing activities |  |  | 100.6 |  |  |  | 125.1 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 15.3 |  |  |  | 10.5 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (5.3 | ) |  |  | 1.1 |  |
| Cash and cash equivalents, beginning of period |  |  | 37.5 |  |  |  | 38.0 |  |
| Cash and cash equivalents, end of period |  | $ | 47.5 |  |  | $ | 49.6 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 12.3 |  |  | $ | 7.8 |  |
| Income taxes paid (net of refunds) |  | $ | 34.4 |  |  | $ | 52.3 |  |

[0001193125-15-256551:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-256551:8k_2_02:67]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-15-256551:8k_2_02:68]
(Unaudited, in millions, except per share and ratio data)

[0001193125-15-256551:8k_2_02:69]
Use of Non-GAAP Financial Measures

[0001193125-15-256551:8k_2_02:70]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide
information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating
performance.

[0001193125-15-256551:8k_2_02:71]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-15-256551:8k_2_02:72]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Income from continuing operations, a GAAP measure |  | $ | 81.6 |  |  | $ | 74.6 |  |  | $ | 95.6 |  |  | $ | 94.5 |  |
| Restructuring charges, after tax |  |  | 1.3 |  |  |  | 0.5 |  |  |  | 1.5 |  |  |  | 0.6 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.8 | ) |  |  | (0.2 | ) |  |  | (0.9 | ) |  |  | (0.2 | ) |
| Special legal contingency charges, after tax (a) |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 2.6 |  |  |  | 0.1 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.4 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | 0.1 |  |  |  | (0.5 | ) |  |  | — |  |  |  | (0.1 | ) |
| Environmental liabilities, after tax (a) |  |  | (0.2 | ) |  |  | — |  |  |  | 0.4 |  |  |  | — |  |
| Contractor Tax Payments (a) |  |  | 1.1 |  |  |  | — |  |  |  | 1.1 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.5 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 83.9 |  |  | $ | 74.9 |  |  | $ | 100.6 |  |  | $ | 95.8 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 1.79 |  |  | $ | 1.50 |  |  | $ | 2.10 |  |  | $ | 1.90 |  |
| Restructuring charges, after tax |  |  | 0.03 |  |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.01 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.02 | ) |  |  | — |  |  |  | (0.02 | ) |  |  | — |  |
| Special legal contingency charges, after tax (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.06 |  |  |  | — |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | — |  |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |
| Environmental liabilities, after tax (a) |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Contractor Tax Payments (a) |  |  | 0.02 |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  | $ | 1.84 |  |  | $ | 1.51 |  |  | $ | 2.21 |  |  | $ | 1.93 |  |

[0001193125-15-256551:8k_2_02:73]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-15-256551:8k_2_02:74]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-15-256551:8k_2_02:75]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.7 |  |  | $ | 0.6 |  |
| Foreign currency exchange losses (gains) (a) |  |  | 0.4 |  |  |  | (0.8 | ) |  |  | 1.5 |  |  |  | 0.1 |  |
| Loss on disposal of fixed assets (a) |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | 0.1 |  |  |  | (0.8 | ) |  |  | — |  |  |  | (0.2 | ) |
| Special legal contingency charges (b) |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 4.1 |  |  |  | 0.2 |  |
| Asbestos-related litigation (b) |  |  | 0.4 |  |  |  | 0.4 |  |  |  | 0.6 |  |  |  | 0.6 |  |
| Environmental liabilities (b) |  |  | (0.2 | ) |  |  | — |  |  |  | 0.4 |  |  |  | — |  |
| Contractor Tax Payments (b) |  |  | 1.6 |  |  |  | — |  |  |  | 1.6 |  |  |  | — |  |
| Other items, net (b) |  |  | — |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 3.3 |  |  | $ | (1.0 | ) |  | $ | 8.9 |  |  | $ | 1.4 |  |

[0001193125-15-256551:8k_2_02:76]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-15-256551:8k_2_02:77]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-15-256551:8k_2_02:78]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-15-256551:8k_2_02:79]
|  |  | For the YearEndedDecember 31,2015ESTIMATED |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $5.25 - $5.50 |
| Restructuring charges and other items |  | (0.11) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $5.14 - $5.39 |

[0001193125-15-256551:8k_2_02:80]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars
in millions)

[0001193125-15-256551:8k_2_02:81]
|  |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 69.9 |  |  | $ | 51.6 |  |  | $ | (52.3 | ) |  | $ | (73.4 | ) |
| Purchases of property, plant and equipment |  |  | (15.0 | ) |  |  | (23.9 | ) |  |  | (33.0 | ) |  |  | (41.2 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | 54.9 |  |  | $ | 27.7 |  |  | $ | (85.3 | ) |  | $ | (114.6 | ) |

[0001193125-15-256551:8k_2_02:82]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelveMonths toJune 30, 2015 |  |
| Adjusted EBIT (a) |  | $ | 352.4 |  |
| Depreciation and amortization expense (b) |  |  | 61.4 |  |
| EBITDA (a + b) |  | $ | 413.8 |  |
| Total debt at June 30, 2015 (c) |  | $ | 1,055.6 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.6 |  |

[0001193125-15-256551:8k_2_02:83]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP
measure (dollars in millions)

[0001193125-15-256551:8k_2_02:84]
|  |  | TrailingTwelveMonths toJune 30, 2015 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 352.4 |  |
| Special product quality adjustments |  |  | (2.5 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 10.6 |  |
| Restructuring charges |  |  | 3.7 |  |
| Interest expense, net |  |  | 22.3 |  |
| Special inventory write down |  |  | 1.0 |  |
| Other expenses, net |  |  | (0.1 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 317.4 |  |
