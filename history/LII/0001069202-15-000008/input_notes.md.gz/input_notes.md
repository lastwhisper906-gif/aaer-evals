# LII notes — 0001069202-15-000008


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-15-000008:notes:1]
[same as prior period, unchanged from 0001069202-15-000006:notes:1]

[0001069202-15-000008:notes:2]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 220.0 |  |  | 220.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-15-000008:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-15-000008:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-15-000008:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-15-000008:notes:6]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Weighted average borrowing rate | 1.92 | % |  | 1.88 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-15-000008:notes:7]
[same as prior period, unchanged from 0001069202-15-000006:notes:7]

[0001069202-15-000008:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2015, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2015 and 2014, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2015 and 2014, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2015 and 2014 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2014. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-15-000008:notes:9]
[same as prior period, unchanged from 0001069202-15-000006:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-15-000008:notes:10]
Commitments and Contingencies:

[0001069202-15-000008:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-15-000008:notes:12]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-15-000008:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000008:notes:14]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Accrued expenses | $ | 26.6 |  |  | $ | 27.3 |  |
| Other liabilities | 63.3 |  |  | 59.9 |  |
| Total warranty liability | $ | 89.9 |  |  | $ | 87.2 |  |

[0001069202-15-000008:notes:15]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2015 were as follows (in millions):

[0001069202-15-000008:notes:16]
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |
| Warranty claims paid | (11.0 | ) |
| Changes resulting from issuance of new warranties | 16.9 |  |
| Changes in estimates associated with pre-existing liabilities | (2.3 | ) |
| Changes in foreign currency translation rates and other | (0.9 | ) |
| Total warranty liability as of June 30, 2015 | $ | 89.9 |  |

[0001069202-15-000008:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable remaining liability for a supplier quality issue within a range of $1.7 million and $5 million; accordingly, we have accrued a $1.7 million liability in Accrued expenses on the Consolidated Balance Sheet because all amounts in that range were equally likely. The supplier has agreed to reimburse our costs related to this liability; accordingly, we have also recorded a receivable of $2.3 million in Other assets on the Consolidated Balance Sheet, which includes amounts incurred by the Company but not yet reimbursed by the supplier.  If additional costs are incurred, we expect the supplier will also reimburse those costs. The$1.7 million accrual is not included in the estimated warranty liabilities tables immediately above.

[0001069202-15-000008:notes:18]
Litigation

[0001069202-15-000008:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-15-000008:notes:20]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2015, and 2014, expense for asbestos-related litigation was $0.4 million, and $0.6 million, net of insurance recoveries, respectively.

[0001069202-15-000008:notes:21]
We are the defendant in an attempted class action lawsuit alleging evaporator coils in our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks.  We dispute the allegations in the lawsuit.  We have reached tentative settlement terms, preliminarily approved by the court, and recorded a liability of $2.4 million in Accrued expenses on the Consolidated Balance Sheet. Any additional liability resulting from the proposed settlement is not currently reasonably estimable, but we do not expect the proposed settlement to have a material adverse effect on our financial condition or results of operations.

[0001069202-15-000008:notes:22]
A lawsuit related to a vendor-supplied product quality issue settled for a lower amount than expected; accordingly, the Company reversed the $1.2 million excess portion of the loss contingency reserve.  The Company also discovered it underpaid contractor taxes at one of its non-U.S. subsidiaries; accordingly, the Company recorded a loss contingency reserve in the amount of $1.6 million which represents the current estimate of the amount owed. These items were recorded in "Losses (gains) and other expenses, net" on the Consolidated Statements of Operations.

[0001069202-15-000008:notes:23]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-15-000008:notes:24]
[same as prior period, unchanged from 0001069202-15-000006:notes:23]

[0001069202-15-000008:notes:25]
The following table provides information on items not reclassified in their entirety from AOCL to Net income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-15-000008:notes:26]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (2.8 | ) |  | $ | (2.8 | ) |  | $ | (6.2 | ) |  | $ | (3.9 | ) |  | Cost of goods sold |
| Income tax benefit |  | 1.0 |  |  | 1.0 |  |  | 2.3 |  |  | 1.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.8 | ) |  | $ | (1.8 | ) |  | $ | (3.9 | ) |  | $ | (2.5 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (2 | ) |  | $ | (1.3 | ) |  | $ | (4.2 | ) |  | $ | (2.6 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.8 |  |  | 0.5 |  |  | 1.5 |  |  | 1.0 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.2 | ) |  | $ | (0.8 | ) |  | $ | (2.7 | ) |  | $ | (1.6 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (3 | ) |  | $ | (2.6 | ) |  | $ | (6.6 | ) |  | $ | (4.1 | ) |  |  |

[0001069202-15-000008:notes:27]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2015 (in millions):

[0001069202-15-000008:notes:28]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| AOCL as of December 31, 2014 |  | $ | (4.6 | ) |  | $ | 3.2 |  |  | $ | (149.4 | ) |  | $ | (2.7 | ) |  | $ | (153.5 | ) |
| Other comprehensive (loss) income before reclassifications |  | (2.6 | ) |  | 0.4 |  |  | (2.3 | ) |  | (27.5 | ) |  | (32.0 | ) |
| Amounts reclassified from AOCL |  | 3.9 |  |  | — |  |  | 2.7 |  |  | — |  |  | 6.6 |  |
| Net other comprehensive (loss) income |  | 1.3 |  |  | 0.4 |  |  | 0.4 |  |  | (27.5 | ) |  | (25.4 | ) |
| AOCL as of June 30, 2015 |  | $ | (3.3 | ) |  | $ | 3.6 |  |  | $ | (149.0 | ) |  | $ | (30.2 | ) |  | $ | (178.9 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-15-000008:notes:29]
[same as prior period, unchanged from 0001069202-15-000006:notes:28]

[0001069202-15-000008:notes:30]
[same as prior period, unchanged from 0001069202-15-000006:notes:29]

[0001069202-15-000008:notes:31]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of June 30, 2015 and December 31, 2014 and for the three and six months ended June 30, 2015 and 2014 are shown on the following pages.

[0001069202-15-000008:notes:32]
[same as prior period, unchanged from 0001069202-15-000006:notes:31]

[0001069202-15-000008:notes:33]
[same as prior period, unchanged from 0001069202-15-000006:notes:32]

[0001069202-15-000008:notes:34]
As of June 30, 2015

[0001069202-15-000008:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.7 |  |  | $ | 21.7 |  |  | $ | 24.1 |  |  | $ | — |  |  | $ | 47.5 |  |
| Accounts and notes receivable, net | — |  |  | 39.8 |  |  | 569.5 |  |  | — |  |  | 609.3 |  |
| Inventories, net | — |  |  | 419.1 |  |  | 129.4 |  |  | (7.8 | ) |  | 540.7 |  |
| Deferred income taxes, net | 1.9 |  |  | 27.4 |  |  | 7.4 |  |  | (5.1 | ) |  | 31.6 |  |
| Other assets | 3.4 |  |  | 48.0 |  |  | 64.8 |  |  | (58.6 | ) |  | 57.6 |  |
| Total current assets | 7.0 |  |  | 556.0 |  |  | 795.2 |  |  | (71.5 | ) |  | 1,286.7 |  |
| Property, plant and equipment, net | — |  |  | 269.4 |  |  | 82.7 |  |  | — |  |  | 352.1 |  |
| Goodwill | — |  |  | 140.4 |  |  | 64.1 |  |  | — |  |  | 204.5 |  |
| Investment in subsidiaries | 1,054.6 |  |  | 473.9 |  |  | (0.6 | ) |  | (1,527.9 | ) |  | — |  |
| Deferred income taxes | 1.4 |  |  | 88.8 |  |  | 14.4 |  |  | (9.6 | ) |  | 95.0 |  |
| Other assets, net | 4.7 |  |  | 60.2 |  |  | 24.6 |  |  | (1.5 | ) |  | 88.0 |  |
| Intercompany receivables (payables), net | (178.3 | ) |  | 178.1 |  |  | 0.2 |  |  | — |  |  | — |  |
| Total assets | $ | 889.4 |  |  | $ | 1,766.8 |  |  | $ | 980.6 |  |  | $ | (1,610.5 | ) |  | $ | 2,026.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 226.1 |  |  | $ | — |  |  | $ | 226.1 |  |
| Current maturities of long-term debt | 15.0 |  |  | 1.1 |  |  | 0.2 |  |  | — |  |  | 16.3 |  |
| Accounts payable | 16.2 |  |  | 317.0 |  |  | 71.1 |  |  | — |  |  | 404.3 |  |
| Accrued expenses | 7.6 |  |  | 176.1 |  |  | 57.9 |  |  | — |  |  | 241.6 |  |
| Income taxes payable | (4.7 | ) |  | 57.9 |  |  | 23.9 |  |  | (66.7 | ) |  | 10.4 |  |
| Total current liabilities | 34.1 |  |  | 552.1 |  |  | 379.2 |  |  | (66.7 | ) |  | 898.7 |  |
| Long-term debt | 798.1 |  |  | 15.0 |  |  | 0.1 |  |  | — |  |  | 813.2 |  |
| Post-retirement benefits, other than pensions | — |  |  | 3.4 |  |  | — |  |  | — |  |  | 3.4 |  |
| Pensions | — |  |  | 121.6 |  |  | 11.6 |  |  | — |  |  | 133.2 |  |
| Other liabilities | 0.9 |  |  | 122.9 |  |  | 10.6 |  |  | (12.9 | ) |  | 121.5 |  |
| Total liabilities | 833.1 |  |  | 815.0 |  |  | 401.5 |  |  | (79.6 | ) |  | 1,970.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 56.3 |  |  | 951.8 |  |  | 579.1 |  |  | (1,530.9 | ) |  | 56.3 |  |
| Total liabilities and stockholders' equity | $ | 889.4 |  |  | $ | 1,766.8 |  |  | $ | 980.6 |  |  | $ | (1,610.5 | ) |  | $ | 2,026.3 |  |

[0001069202-15-000008:notes:36]
[same as prior period, unchanged from 0001069202-15-000006:notes:35]

[0001069202-15-000008:notes:37]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 11.5 |  |  | $ | 25.0 |  |  | $ | — |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net | — |  |  | 12.3 |  |  | 409.1 |  |  | — |  |  | 421.4 |  |
| Inventories, net | — |  |  | 350.6 |  |  | 119.7 |  |  | (7.0 | ) |  | 463.3 |  |
| Deferred income taxes, net | 2.8 |  |  | 27.3 |  |  | 7.4 |  |  | (5.0 | ) |  | 32.5 |  |
| Other assets | 3.6 |  |  | 45.7 |  |  | 67.2 |  |  | (57.2 | ) |  | 59.3 |  |
| Total current assets | 7.4 |  |  | 447.4 |  |  | 628.4 |  |  | (69.2 | ) |  | 1,014.0 |  |
| Property, plant and equipment, net | — |  |  | 269.0 |  |  | 89.6 |  |  | — |  |  | 358.6 |  |
| Goodwill | — |  |  | 140.4 |  |  | 69.0 |  |  | — |  |  | 209.4 |  |
| Investment in subsidiaries | 978.1 |  |  | 263.5 |  |  | (0.6 | ) |  | (1,241.0 | ) |  | — |  |
| Deferred income taxes | 0.5 |  |  | 90.8 |  |  | 15.8 |  |  | (9.6 | ) |  | 97.5 |  |
| Other assets, net | 5.2 |  |  | 61.0 |  |  | 20.1 |  |  | (1.5 | ) |  | 84.8 |  |
| Intercompany receivables (payables), net | (280.4 | ) |  | 302.4 |  |  | (22.0 | ) |  | — |  |  | — |  |
| Total assets | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 226.6 |  |  | $ | — |  |  | $ | 226.6 |  |
| Current maturities of long-term debt | 22.5 |  |  | 1.2 |  |  | 0.3 |  |  | — |  |  | 24.0 |  |
| Accounts payable | 13.4 |  |  | 237.8 |  |  | 73.1 |  |  | — |  |  | 324.3 |  |
| Accrued expenses | 9.0 |  |  | 175.5 |  |  | 54.5 |  |  | — |  |  | 239.0 |  |
| Income taxes payable | (3.7 | ) |  | 34.7 |  |  | 47.5 |  |  | (65.1 | ) |  | 13.4 |  |
| Total current liabilities | 41.2 |  |  | 449.2 |  |  | 402.0 |  |  | (65.1 | ) |  | 827.3 |  |
| Long-term debt | 659.5 |  |  | 15.3 |  |  | 0.2 |  |  | — |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| Pensions | — |  |  | 117.6 |  |  | 12.3 |  |  | — |  |  | 129.9 |  |
| Other liabilities | 1.1 |  |  | 118.7 |  |  | 11.7 |  |  | (12.9 | ) |  | 118.6 |  |
| Total liabilities | 701.8 |  |  | 705.3 |  |  | 426.2 |  |  | (78.0 | ) |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 9.0 |  |  | 869.2 |  |  | 374.1 |  |  | (1,243.3 | ) |  | 9.0 |  |
| Total liabilities and stockholders' equity | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |

[0001069202-15-000008:notes:38]
[same as prior period, unchanged from 0001069202-15-000006:notes:37]

[0001069202-15-000008:notes:39]
For the Three Months Ended June 30, 2015

[0001069202-15-000008:notes:40]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 864.6 |  |  | $ | 181.7 |  |  | $ | (53.8 | ) |  | $ | 992.5 |  |
| Cost of goods sold | — |  |  | 617.2 |  |  | 145.1 |  |  | (53.2 | ) |  | 709.1 |  |
| Gross profit | — |  |  | 247.4 |  |  | 36.6 |  |  | (0.6 | ) |  | 283.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 130.1 |  |  | 22.8 |  |  | — |  |  | 152.9 |  |
| Losses (gains) and other expenses, net | 0.4 |  |  | 1.1 |  |  | 1.8 |  |  | — |  |  | 3.3 |  |
| Restructuring charges | — |  |  | (0.5 | ) |  | 2.3 |  |  | — |  |  | 1.8 |  |
| Income from equity method investments | (85.6 | ) |  | 0.2 |  |  | (4.5 | ) |  | 84.4 |  |  | (5.5 | ) |
| Operational income from continuing operations | 85.2 |  |  | 116.5 |  |  | 14.2 |  |  | (85.0 | ) |  | 130.9 |  |
| Interest expense, net | 6.2 |  |  | (0.6 | ) |  | 0.8 |  |  | — |  |  | 6.4 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 79.0 |  |  | 117.1 |  |  | 13.4 |  |  | (85.0 | ) |  | 124.5 |  |
| Provision for income taxes | (2.2 | ) |  | 40.4 |  |  | 5.0 |  |  | (0.3 | ) |  | 42.9 |  |
| Income from continuing operations | 81.2 |  |  | 76.7 |  |  | 8.4 |  |  | (84.7 | ) |  | 81.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Net income | $ | 81.2 |  |  | $ | 76.7 |  |  | $ | 8.0 |  |  | $ | (84.7 | ) |  | $ | 81.2 |  |
| Other comprehensive income (loss), net of tax | 0.3 |  |  | (1.3 | ) |  | 0.5 |  |  | 0.3 |  |  | (0.2 | ) |
| Comprehensive income | $ | 81.5 |  |  | $ | 75.4 |  |  | $ | 8.5 |  |  | $ | (84.4 | ) |  | $ | 81.0 |  |

[0001069202-15-000008:notes:41]
For the Six Months Ended June 30, 2015

[0001069202-15-000008:notes:42]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,440.7 |  |  | $ | 335.5 |  |  | $ | (97.9 | ) |  | $ | 1,678.3 |  |
| Cost of goods sold | — |  |  | 1,060.8 |  |  | 268.0 |  |  | (96.9 | ) |  | 1,231.9 |  |
| Gross profit | — |  |  | 379.9 |  |  | 67.5 |  |  | (1.0 | ) |  | 446.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 238.0 |  |  | 48.2 |  |  | — |  |  | 286.2 |  |
| Losses (gains) and other expenses, net | 0.5 |  |  | 5.0 |  |  | 3.5 |  |  | (0.1 | ) |  | 8.9 |  |
| Restructuring charges | — |  |  | (0.4 | ) |  | 2.5 |  |  | — |  |  | 2.1 |  |
| Income from equity method investments | (103.1 | ) |  | 2.6 |  |  | (7.3 | ) |  | 99.0 |  |  | (8.8 | ) |
| Operational income from continuing operations | 102.6 |  |  | 134.7 |  |  | 20.6 |  |  | (99.9 | ) |  | 158.0 |  |
| Interest expense, net | 11.7 |  |  | (1.1 | ) |  | 1.6 |  |  | — |  |  | 12.2 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 90.9 |  |  | 135.8 |  |  | 19.0 |  |  | (99.9 | ) |  | 145.8 |  |
| Provision for income taxes | (4.2 | ) |  | 48.2 |  |  | 6.6 |  |  | (0.4 | ) |  | 50.2 |  |
| Income from continuing operations | 95.1 |  |  | 87.6 |  |  | 12.4 |  |  | (99.5 | ) |  | 95.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Net income | $ | 95.1 |  |  | $ | 87.6 |  |  | $ | 11.9 |  |  | $ | (99.5 | ) |  | $ | 95.1 |  |
| Other comprehensive income (loss), net of tax | 1.3 |  |  | (5.2 | ) |  | (20.1 | ) |  | (1.4 | ) |  | (25.4 | ) |
| Comprehensive income | $ | 96.4 |  |  | $ | 82.4 |  |  | $ | (8.2 | ) |  | $ | (100.9 | ) |  | $ | 69.7 |  |

[0001069202-15-000008:notes:43]
For the Three Months Ended June 30, 2014

[0001069202-15-000008:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 793.6 |  |  | $ | 210.4 |  |  | $ | (43.3 | ) |  | $ | 960.7 |  |
| Cost of goods sold | — |  |  | 583.0 |  |  | 157.0 |  |  | (41.9 | ) |  | 698.1 |  |
| Gross profit | — |  |  | 210.6 |  |  | 53.4 |  |  | (1.4 | ) |  | 262.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 131.2 |  |  | 17.7 |  |  | — |  |  | 148.9 |  |
| Losses (gains) and other expenses, net | (1.1 | ) |  | 0.3 |  |  | (0.2 | ) |  | — |  |  | (1.0 | ) |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Income from equity method investments | (75.5 | ) |  | (12.1 | ) |  | (4.0 | ) |  | 87.0 |  |  | (4.6 | ) |
| Operational income from continuing operations | 76.6 |  |  | 91.1 |  |  | 39.8 |  |  | (88.4 | ) |  | 119.1 |  |
| Interest expense, net | 3.5 |  |  | (0.9 | ) |  | 1.1 |  |  | — |  |  | 3.7 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 73.1 |  |  | 92.0 |  |  | 38.7 |  |  | (88.4 | ) |  | 115.4 |  |
| Provision for income taxes | (0.8 | ) |  | 28.1 |  |  | 13.9 |  |  | (0.4 | ) |  | 40.8 |  |
| Income from continuing operations | 73.9 |  |  | 63.9 |  |  | 24.8 |  |  | (88.0 | ) |  | 74.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.7 | ) |  | — |  |  | (0.7 | ) |
| Net income | $ | 73.9 |  |  | $ | 63.9 |  |  | $ | 24.1 |  |  | $ | (88.0 | ) |  | $ | 73.9 |  |
| Other comprehensive income, net of tax | 10.2 |  |  | 1.6 |  |  | 4.1 |  |  | (5.7 | ) |  | 10.2 |  |
| Comprehensive income | $ | 84.1 |  |  | $ | 65.5 |  |  | $ | 28.2 |  |  | $ | (93.7 | ) |  | $ | 84.1 |  |

[0001069202-15-000008:notes:45]
For the Six Months Ended June 30, 2014

[0001069202-15-000008:notes:46]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,352.8 |  |  | $ | 393.0 |  |  | $ | (89.7 | ) |  | $ | 1,656.1 |  |
| Cost of goods sold | — |  |  | 1,016.3 |  |  | 296.4 |  |  | (87.3 | ) |  | 1,225.4 |  |
| Gross profit | — |  |  | 336.5 |  |  | 96.6 |  |  | (2.4 | ) |  | 430.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 235.5 |  |  | 49.0 |  |  | — |  |  | 284.5 |  |
| Losses and other expenses, net | (0.2 | ) |  | 1.1 |  |  | 0.5 |  |  |  |  |  | 1.4 |  |
| Restructuring charges | — |  |  | 0.1 |  |  | 0.2 |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (97.9 | ) |  | (14.6 | ) |  | (7.1 | ) |  | 111.1 |  |  | (8.5 | ) |
| Operational income from continuing operations | 98.1 |  |  | 114.4 |  |  | 54.0 |  |  | (113.5 | ) |  | 153.0 |  |
| Interest expense, net | 6.5 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 7.0 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 91.6 |  |  | 115.9 |  |  | 52.0 |  |  | (113.5 | ) |  | 146.0 |  |
| Provision for income taxes | (2.2 | ) |  | 35.9 |  |  | 18.6 |  |  | (0.8 | ) |  | 51.5 |  |
| Income from continuing operations | 93.8 |  |  | 80.0 |  |  | 33.4 |  |  | (112.7 | ) |  | 94.5 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.7 | ) |  | — |  |  | (0.7 | ) |
| Net income | $ | 93.8 |  |  | $ | 80.0 |  |  | $ | 32.7 |  |  | $ | (112.7 | ) |  | $ | 93.8 |  |
| Other comprehensive income (loss), net of tax | 10.2 |  |  | 4.9 |  |  | 5.4 |  |  | (10.3 | ) |  | 10.2 |  |
| Comprehensive income | $ | 104.0 |  |  | $ | 84.9 |  |  | $ | 38.1 |  |  | $ | (123.0 | ) |  | $ | 104.0 |  |

[0001069202-15-000008:notes:47]
[same as prior period, unchanged from 0001069202-15-000006:notes:42]

[0001069202-15-000008:notes:48]
For the Six Months Ended June 30, 2015

[0001069202-15-000008:notes:49]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 2.1 |  |  | $ | (45.0 | ) |  | $ | (9.4 | ) |  | $ | — |  |  | $ | (52.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (27.8 | ) |  | (5.2 | ) |  | — |  |  | (33.0 | ) |
| Net cash used in investing activities | — |  |  | (27.8 | ) |  | (5.2 | ) |  | — |  |  | (33.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Long-term debt payments | (22.5 | ) |  | (0.3 | ) |  | (0.2 | ) |  | — |  |  | (23.0 | ) |
| Borrowings from credit facility | 999.0 |  |  | — |  |  | — |  |  | — |  |  | 999.0 |  |
| Payments on credit facility | (845.5 | ) |  | — |  |  | — |  |  | — |  |  | (845.5 | ) |
| Proceeds from employee stock purchases | 1.1 |  |  | — |  |  | — |  |  | — |  |  | 1.1 |  |
| Repurchases of common stock | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (21.8 | ) |  | — |  |  | — |  |  | — |  |  | (21.8 | ) |
| Excess tax benefits related to share-based payments | 17.3 |  |  | — |  |  | — |  |  | — |  |  | 17.3 |  |
| Intercompany financing activity | (24.3 | ) |  | 3.4 |  |  | 20.9 |  |  | — |  |  | — |  |
| Intercompany investments | (77.8 | ) |  | 79.9 |  |  | (2.1 | ) |  | — |  |  | — |  |
| Cash dividends paid | (26.9 | ) |  | — |  |  | — |  |  | — |  |  | (26.9 | ) |
| Net cash provided by financing activities | (1.4 | ) |  | 83.0 |  |  | 19.0 |  |  | — |  |  | 100.6 |  |
| Increase in cash and cash equivalents | 0.7 |  |  | 10.2 |  |  | 4.4 |  |  | — |  |  | 15.3 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (5.3 | ) |  | — |  |  | (5.3 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of period | $ | 1.7 |  |  | $ | 21.7 |  |  | $ | 24.1 |  |  | $ | — |  |  | $ | 47.5 |  |

[0001069202-15-000008:notes:50]
For the Six Months Ended June 30, 2014

[0001069202-15-000008:notes:51]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 48.6 |  |  | $ | (92.5 | ) |  | $ | (29.5 | ) |  | $ | — |  |  | $ | (73.4 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | (29.9 | ) |  | (11.3 | ) |  | — |  |  | (41.2 | ) |
| Net cash used in investing activities | — |  |  | (29.9 | ) |  | (11.3 | ) |  | — |  |  | (41.2 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.6 | ) |  | — |  |  | (0.6 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | — |  |  | (0.7 | ) |  | (0.2 | ) |  | — |  |  | (0.9 | ) |
| Borrowings from credit facility | 1,018.5 |  |  | — |  |  | — |  |  | — |  |  | 1,018.5 |  |
| Payments on credit facility | (832.5 | ) |  | — |  |  | — |  |  | — |  |  | (832.5 | ) |
| Proceeds from employee stock purchases | 1.0 |  |  | — |  |  | — |  |  | — |  |  | 1.0 |  |
| Repurchases of common stock | (50.0 | ) |  | — |  |  | — |  |  | — |  |  | (50.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (10.8 | ) |  | — |  |  | — |  |  | — |  |  | (10.8 | ) |
| Excess tax benefits related to share-based payments | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |
| Intercompany debt | (5.6 | ) |  | (6.3 | ) |  | 11.9 |  |  | — |  |  | — |  |
| Intercompany financing activity | (149.8 | ) |  | 141.0 |  |  | 8.8 |  |  | — |  |  | — |  |
| Intercompany investments |  |  | (3.0 | ) |  | 3.0 |  |  |  |  |  |
| Cash dividends paid | (23.6 | ) |  | — |  |  | — |  |  | — |  |  | (23.6 | ) |
| Net cash used in financing activities | (48.8 | ) |  | 131.0 |  |  | 42.9 |  |  | — |  |  | 125.1 |  |
| Decrease in cash and cash equivalents | (0.2 | ) |  | 8.6 |  |  | 2.1 |  |  | — |  |  | 10.5 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 1.1 |  |  | — |  |  | 1.1 |  |
| Cash and cash equivalents, beginning of period | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of period | $ | 0.9 |  |  | $ | 19.1 |  |  | $ | 29.6 |  |  | $ | — |  |  | $ | 49.6 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-15-000008:notes:52]
Lines of Credit and Financing Arrangements:

[0001069202-15-000008:notes:53]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000008:notes:54]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 220.0 |  |
| Foreign obligations | 6.1 |  |  | 6.6 |  |
| Total short-term debt | $ | 226.1 |  |  | $ | 226.6 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.5 |  |
| Domestic credit facility | 15.0 |  |  | 22.5 |  |
| Total current maturities of long-term debt | $ | 16.3 |  |  | $ | 24.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.2 |  |  | $ | 15.5 |  |
| Domestic credit facility | 598.0 |  |  | 459.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 813.2 |  |  | $ | 675.0 |  |
| Total debt | $ | 1,055.6 |  |  | $ | 925.6 |  |

[0001069202-15-000008:notes:55]
Short-Term Debt

[0001069202-15-000008:notes:56]
Foreign Obligations

[0001069202-15-000008:notes:57]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $6.1 million and $6.6 million of foreign obligations as of June 30, 2015 and December 31, 2014, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $32.4 million and $23.6 million during the six months ended June 30, 2015 and 2014, respectively. Repayments on the facilities were $32.1 million and $24.2 million and during the six months ended June 30, 2015 and 2014, respectively.

[0001069202-15-000008:notes:58]
Asset Securitization Program

[0001069202-15-000008:notes:59]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-15-000008:notes:60]
The ASP provides for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-15-000008:notes:61]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for June 30, 2015 and December 31, 2014 was 0.80% and 0.79% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-15-000008:notes:62]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2015, we were in compliance with all covenant requirements.

[0001069202-15-000008:notes:63]
Long-Term Debt

[0001069202-15-000008:notes:64]
Domestic Credit Facility

[0001069202-15-000008:notes:65]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consisted of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $613.0 million, of which $277.5 million was the term loan balance, as well as $24.7 million committed to standby letters of credit as of June 30, 2015. Subject to covenant limitations, $289.8 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. We paid $22.5 million in principal payments in June 2015 for the term loan, which represents the required principal payments for the remainder of 2015.  The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-15-000008:notes:66]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-15-000008:notes:67]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-15-000008:notes:68]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-15-000008:notes:69]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-15-000008:notes:70]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2015, we were in compliance with all covenant requirements.

[0001069202-15-000008:notes:71]
Senior Unsecured Notes

[0001069202-15-000008:notes:72]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2015, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-15-000008:notes:73]
[same as prior period, unchanged from 0001069202-15-000006:notes:67]

[0001069202-15-000008:notes:74]
[same as prior period, unchanged from 0001069202-15-000006:notes:68]

[0001069202-15-000008:notes:75]
[same as prior period, unchanged from 0001069202-15-000006:notes:69]

[0001069202-15-000008:notes:76]
[same as prior period, unchanged from 0001069202-15-000006:notes:70]

[0001069202-15-000008:notes:77]
[same as prior period, unchanged from 0001069202-15-000006:notes:71]

[0001069202-15-000008:notes:78]
[same as prior period, unchanged from 0001069202-15-000006:notes:72]

[0001069202-15-000008:notes:79]
We have commodity futures contracts designated as cash flow hedges that are scheduled to mature through December 2016.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-15-000008:notes:80]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Unrealized losses on unsettled futures contracts | $ | 5.3 |  |  | $ | 7.2 |  |
| Income tax benefit | (1.9 | ) |  | (2.6 | ) |
| Losses included in AOCL, net of tax (1) | $ | 3.4 |  |  | $ | 4.6 |  |

[0001069202-15-000008:notes:81]
(1) Assuming commodity prices remain constant, we expect to reclassify $3.2 million of derivative losses into earnings within the next 12 months.

[0001069202-15-000008:notes:82]
[same as prior period, unchanged from 0001069202-15-000006:notes:77]

[0001069202-15-000008:notes:83]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Copper | 20.2 |  |  | 29.4 |  |

[0001069202-15-000008:notes:84]
[same as prior period, unchanged from 0001069202-15-000006:notes:79]

[0001069202-15-000008:notes:85]
[same as prior period, unchanged from 0001069202-15-000006:notes:80]

[0001069202-15-000008:notes:86]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Copper | 2.2 |  |  | 2.9 |  |
| Aluminum | 2.2 |  |  | 2.2 |  |

[0001069202-15-000008:notes:87]
[same as prior period, unchanged from 0001069202-15-000006:notes:82]

[0001069202-15-000008:notes:88]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Notional Amounts (in local currency): |  |  |  |
| Brazilian Real | 1.6 |  |  | 8.7 |  |
| Mexican Peso | 23.3 |  |  | 229.7 |  |
| United States Dollar | 7.6 |  |  | 4.5 |  |
| Euro | 4.3 |  |  | 3.6 |  |
| Polish Zloty | 17.7 |  |  | 30.6 |  |
| Russian Ruble | 45.1 |  |  | 80.8 |  |

[0001069202-15-000008:notes:89]
[same as prior period, unchanged from 0001069202-15-000006:notes:84]

[0001069202-15-000008:notes:90]
[same as prior period, unchanged from 0001069202-15-000006:notes:85]

[0001069202-15-000008:notes:91]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of June 30, 2015 |  | As of December 31, 2014 |  | As of June 30, 2015 |  | As of December 31, 2014 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.2 |  |  | 0.3 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Assets | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | 0.3 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 5.1 |  |  | $ | 6.7 |  |  | $ | 0.8 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.2 |  |  | 0.5 |  |  | — |  |  | 0.1 |  |
| Total Liabilities | $ | 5.3 |  |  | $ | 7.2 |  |  | $ | 0.9 |  |  | $ | 0.8 |  |

[0001069202-15-000008:notes:92]
[same as prior period, unchanged from 0001069202-15-000006:notes:87]

[0001069202-15-000008:notes:93]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Amount of Loss reclassified from AOCL into Income (Effective Portion) (1) |  | $ | 2.8 |  |  | $ | 2.8 |  |  | $ | 6.2 |  |  | $ | 3.9 |  |
| Amount of Loss (Gain) recognized in Net income (Ineffective Portion) (2) |  | $ | — |  |  | $ | (0.1 | ) |  | $ | — |  |  | $ | 0.1 |  |

[0001069202-15-000008:notes:94]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | 0.4 |  |  | $ | (0.4 | ) |  | $ | 0.8 |  |  | $ | 0.3 |  |
| Foreign currency forward contracts (2) |  | — |  |  | — |  |  | 0.2 |  |  | 0.1 |  |
|  |  | $ | 0.4 |  |  | $ | (0.4 | ) |  | $ | 1.0 |  |  | $ | 0.4 |  |

[0001069202-15-000008:notes:95]
[same as prior period, unchanged from 0001069202-15-000006:notes:90]

[0001069202-15-000008:notes:96]
[same as prior period, unchanged from 0001069202-15-000006:notes:91]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-15-000008:notes:97]
[same as prior period, unchanged from 0001069202-15-000006:notes:92]

[0001069202-15-000008:notes:98]
[same as prior period, unchanged from 0001069202-15-000006:notes:93]

[0001069202-15-000008:notes:99]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Stock-based compensation expense (1) | $ | 7.3 |  |  | $ | 6.9 |  |  | $ | 10.8 |  |  | $ | 10.7 |  |

[0001069202-15-000008:notes:100]
[same as prior period, unchanged from 0001069202-15-000006:notes:95]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-15-000008:notes:101]
[same as prior period, unchanged from 0001069202-15-000006:notes:96]

[0001069202-15-000008:notes:102]
[same as prior period, unchanged from 0001069202-15-000006:notes:97]

[0001069202-15-000008:notes:103]
There were no assets and liabilities related to the Service Experts or Hearth businesses included in the accompanying Consolidated Balance Sheets as of June 30, 2015 or December 31, 2014, except for insurance casualty loss reserves which we retained after the respective transactions.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in Discontinued Operations in the accompanying Consolidated Statements of Operations.  The following table provides a summary of net trade sales, pre-tax operating income (loss) and other supplemental information related to discontinued operations (in millions):

[0001069202-15-000008:notes:104]
|  | Service Experts |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | (0.8 | ) |  | 1.2 |  |  | (0.8 | ) |  | 1.1 |  |
| Gain (loss) on sale of business | — |  |  | — |  |  | — |  |  | — |  |

[0001069202-15-000008:notes:105]
[same as prior period, unchanged from 0001069202-15-000006:notes:100]

[0001069202-15-000008:notes:106]
|  | Hearth |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net trade sales (1) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | 0.1 |  |  | (2.3 | ) |  | — |  |  | (2.2 | ) |
| Gain (loss) on sale of business | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-15-000008:notes:107]
[same as prior period, unchanged from 0001069202-15-000006:notes:102]

[0001069202-15-000008:notes:108]
[same as prior period, unchanged from 0001069202-15-000006:notes:103]

[0001069202-15-000008:notes:109]
[same as prior period, unchanged from 0001069202-15-000006:notes:104]

[0001069202-15-000008:notes:110]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net income | $ | 81.2 |  |  | $ | 73.9 |  |  | $ | 95.1 |  |  | $ | 93.8 |  |
| Add: Loss from discontinued operations | 0.4 |  |  | 0.7 |  |  | 0.5 |  |  | 0.7 |  |
| Income from continuing operations | $ | 81.6 |  |  | $ | 74.6 |  |  | $ | 95.6 |  |  | $ | 94.5 |  |
| Weighted-average shares outstanding – basic | 45.0 |  |  | 48.8 |  |  | 44.9 |  |  | 48.9 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.6 |  |  | 0.8 |  |  | 0.7 |  |  | 0.8 |  |
| Weighted-average shares outstanding – diluted | 45.6 |  |  | 49.6 |  |  | 45.6 |  |  | 49.7 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.81 |  |  | $ | 1.53 |  |  | $ | 2.13 |  |  | $ | 1.93 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.02 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Net income | $ | 1.80 |  |  | $ | 1.51 |  |  | $ | 2.12 |  |  | $ | 1.92 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.79 |  |  | $ | 1.50 |  |  | $ | 2.10 |  |  | $ | 1.90 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Net income | $ | 1.78 |  |  | $ | 1.49 |  |  | $ | 2.09 |  |  | $ | 1.89 |  |

[0001069202-15-000008:notes:111]
[same as prior period, unchanged from 0001069202-15-000006:notes:106]

[0001069202-15-000008:notes:112]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Weighted-average number of shares | 0.2 |  |  | 0.3 |  |  | 0.2 |  |  | 0.3 |  |
| Price range per share | $ | 92.64 |  |  | $81.11 - $81.14 |  |  | $ | 92.64 |  |  | $81.11 - $81.14 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-15-000008:notes:113]
[same as prior period, unchanged from 0001069202-15-000006:notes:108]

[0001069202-15-000008:notes:114]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Senior unsecured notes | $ | 209.8 |  |  | $ | 210.6 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-15-000008:notes:115]
[same as prior period, unchanged from 0001069202-15-000006:notes:110]

[0001069202-15-000008:notes:116]
[same as prior period, unchanged from 0001069202-15-000006:notes:111]

[0001069202-15-000008:notes:117]
The methodologies used to determine the fair value of our financial assets and liabilities at June 30, 2015 were the same as those used at December 31, 2014.

[0001069202-15-000008:notes:118]
[same as prior period, unchanged from 0001069202-15-000006:notes:113]

[0001069202-15-000008:notes:119]
[same as prior period, unchanged from 0001069202-15-000006:notes:114]

[0001069202-15-000008:notes:120]
[same as prior period, unchanged from 0001069202-15-000006:notes:115]

[0001069202-15-000008:notes:121]
[same as prior period, unchanged from 0001069202-15-000006:notes:116]

[0001069202-15-000008:notes:122]
[same as prior period, unchanged from 0001069202-15-000006:notes:117]

[0001069202-15-000008:notes:123]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Investment in marketable equity securities | $ | 5.7 |  |  | $ | 5.3 |  |

[0001069202-15-000008:notes:124]
[same as prior period, unchanged from 0001069202-15-000006:notes:119]

[0001069202-15-000008:notes:125]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-15-000008:notes:126]
[same as prior period, unchanged from 0001069202-15-000006:notes:121]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-15-000008:notes:127]
[same as prior period, unchanged from 0001069202-15-000006:notes:122]

[0001069202-15-000008:notes:128]
The changes in the carrying amount of goodwill for the first six months of 2015, in total and by segment, are summarized in the table below (in millions):

[0001069202-15-000008:notes:129]
|  | Balance at December 31, 2014 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at June 30, 2015 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 62.3 |  |  | — |  |  | (1.2 | ) |  | 61.1 |  |
| Refrigeration | 121.0 |  |  | — |  |  | (3.7 | ) |  | 117.3 |  |
| Total Goodwill | $ | 209.4 |  |  | $ | — |  |  | $ | (4.9 | ) |  | $ | 204.5 |  |

[0001069202-15-000008:notes:130]
[same as prior period, unchanged from 0001069202-15-000006:notes:125]

[0001069202-15-000008:notes:131]
[same as prior period, unchanged from 0001069202-15-000006:notes:126]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-15-000008:notes:132]
[same as prior period, unchanged from 0001069202-15-000006:notes:127]

[0001069202-15-000008:notes:133]
As of June 30, 2015, we had approximately $1.6 million in total gross unrecognized tax benefits. Of this amount, $1.2 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of June 30, 2015, we had approximately $0.2 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-15-000008:notes:134]
[same as prior period, unchanged from 0001069202-15-000006:notes:129]

[0001069202-15-000008:notes:135]
Since January 1, 2015, numerous states, including Connecticut, North Dakota, Tennessee and Texas, have enacted legislation effective for tax years beginning on or after January 1, 2015, including changes to rates, apportionment methodologies and unitary reporting requirements.  The impact of these changes is immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-15-000008:notes:136]
[same as prior period, unchanged from 0001069202-15-000006:notes:130]

[0001069202-15-000008:notes:137]
[same as prior period, unchanged from 0001069202-15-000006:notes:131]

[0001069202-15-000008:notes:138]
|  | As of June 30, 2015 |  | As of December 31, 2014 |
| Finished goods | $ | 403.2 |  |  | $ | 338.2 |  |
| Work in process | 9.2 |  |  | 8.1 |  |
| Raw materials and parts | 194.4 |  |  | 182.6 |  |
| Subtotal | 606.8 |  |  | 528.9 |  |
| Excess of current cost over last-in, first-out cost | (66.1 | ) |  | (65.6 | ) |
| Total inventories, net | $ | 540.7 |  |  | $ | 463.3 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-15-000008:notes:139]
[same as prior period, unchanged from 0001069202-15-000006:notes:133]

[0001069202-15-000008:notes:140]
[same as prior period, unchanged from 0001069202-15-000006:notes:134]

[0001069202-15-000008:notes:141]
[same as prior period, unchanged from 0001069202-15-000006:notes:135]

[0001069202-15-000008:notes:142]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-15-000008:notes:143]
[same as prior period, unchanged from 0001069202-15-000006:notes:137]

[0001069202-15-000008:notes:144]
[same as prior period, unchanged from 0001069202-15-000006:notes:138]

[0001069202-15-000008:notes:145]
[same as prior period, unchanged from 0001069202-15-000006:notes:139]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-15-000008:notes:146]
[same as prior period, unchanged from 0001069202-15-000006:notes:140]

[0001069202-15-000008:notes:147]
[same as prior period, unchanged from 0001069202-15-000006:notes:141]

[0001069202-15-000008:notes:148]
|  | For the Three Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.2 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.3 |  |  | 4.4 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on plan assets | (5.4 | ) |  | (5.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  | (0.8 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.4 |  |  | 1.6 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 2.6 |  |  | $ | 1.5 |  |  | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0001069202-15-000008:notes:149]
|  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 2.3 |  |  | $ | 2.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 8.6 |  |  | 8.8 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on plan assets | (10.7 | ) |  | (11.3 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.2 |  |  | (1.5 | ) |  | (1.5 | ) |
| Recognized actuarial loss | 4.8 |  |  | 3.2 |  |  | 0.8 |  |  | 0.7 |  |
| Settlements and curtailments | 0.4 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 5.5 |  |  | $ | 3.1 |  |  | $ | (0.6 | ) |  | $ | (0.7 | ) |

[0001069202-15-000008:notes:150]
(1) All net periodic benefit cost for the three and six months ended June 30, 2015 and 2014 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-15-000008:notes:151]
[same as prior period, unchanged from 0001069202-15-000006:notes:144]

[0001069202-15-000008:notes:152]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 555.1 |  |  | $ | 527.7 |  |  | $ | 917.7 |  |  | $ | 869.8 |  |
| Commercial Heating & Cooling | 253.6 |  |  | 241.0 |  |  | 413.5 |  |  | 414.0 |  |
| Refrigeration | 183.8 |  |  | 192.0 |  |  | 347.1 |  |  | 372.3 |  |
|  | $ | 992.5 |  |  | $ | 960.7 |  |  | $ | 1,678.3 |  |  | $ | 1,656.1 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 99.9 |  |  | $ | 85.0 |  |  | $ | 131.2 |  |  | $ | 109.4 |  |
| Commercial Heating & Cooling | 43.0 |  |  | 39.0 |  |  | 50.7 |  |  | 49.2 |  |
| Refrigeration | 13.3 |  |  | 13.7 |  |  | 17.2 |  |  | 25.8 |  |
| Corporate and other | (22.0 | ) |  | (19.2 | ) |  | (33.7 | ) |  | (30.6 | ) |
| Subtotal that includes segment profit and eliminations | 134.2 |  |  | 118.5 |  |  | 165.4 |  |  | 153.8 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |
| Special product quality adjustments | (1.1 | ) |  | (0.4 | ) |  | (1.4 | ) |  | (0.3 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 2.6 |  |  | (0.4 | ) |  | 6.7 |  |  | 0.8 |  |
| Restructuring charges | 1.8 |  |  | 0.2 |  |  | 2.1 |  |  | 0.3 |  |
| Interest expense, net | 6.4 |  |  | 3.7 |  |  | 12.2 |  |  | 7.0 |  |
| Other expense (income), net | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | $ | 124.5 |  |  | $ | 115.4 |  |  | $ | 145.8 |  |  | $ | 146.0 |  |

[0001069202-15-000008:notes:153]
[same as prior period, unchanged from 0001069202-15-000006:notes:146]

[0001069202-15-000008:notes:154]
[same as prior period, unchanged from 0001069202-15-000006:notes:147]

[0001069202-15-000008:notes:155]
[same as prior period, unchanged from 0001069202-15-000006:notes:148]

[0001069202-15-000008:notes:156]
[same as prior period, unchanged from 0001069202-15-000006:notes:149]

[0001069202-15-000008:notes:157]
| ◦ | Special legal contingency charges, |

[0001069202-15-000008:notes:158]
| ◦ | Asbestos-related litigation, |

[0001069202-15-000008:notes:159]
| ◦ | Contractor tax payments, |

[0001069202-15-000008:notes:160]
[same as prior period, unchanged from 0001069202-15-000006:notes:152]

[0001069202-15-000008:notes:161]
[same as prior period, unchanged from 0001069202-15-000006:notes:153]

[0001069202-15-000008:notes:162]
[same as prior period, unchanged from 0001069202-15-000006:notes:154]

[0001069202-15-000008:notes:163]
[same as prior period, unchanged from 0001069202-15-000006:notes:155]

[0001069202-15-000008:notes:164]
[same as prior period, unchanged from 0001069202-15-000006:notes:156]

[0001069202-15-000008:notes:165]
[same as prior period, unchanged from 0001069202-15-000006:notes:157]

[0001069202-15-000008:notes:166]
[same as prior period, unchanged from 0001069202-15-000006:notes:158]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-15-000008:notes:167]
[same as prior period, unchanged from 0001069202-15-000006:notes:159]

[0001069202-15-000008:notes:168]
[same as prior period, unchanged from 0001069202-15-000006:notes:160]

[0001069202-15-000008:notes:169]
[same as prior period, unchanged from 0001069202-15-000006:notes:161]

[0001069202-15-000008:notes:170]
Information regarding the restructuring charges for all ongoing activities are presented in the following table (in millions):

[0001069202-15-000008:notes:171]
|  | Charges Incurred in 2015 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 1.8 |  |  | $ | 8.7 |  |  | $ | 8.7 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 2.0 |  |  | 2.0 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | 0.1 |  |
| Other | 0.2 |  |  | 2.0 |  |  | 2.3 |  |
| Total restructuring charges | $ | 2.1 |  |  | $ | 12.7 |  |  | $ | 13.1 |  |

[0001069202-15-000008:notes:172]
[same as prior period, unchanged from 0001069202-15-000006:notes:164]

[0001069202-15-000008:notes:173]
|  | Charges Incurred in 2015 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.1 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | 2.0 |  |  | 10.2 |  |  | 10.6 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total restructuring charges | $ | 2.1 |  |  | $ | 12.7 |  |  | $ | 13.1 |  |

[0001069202-15-000008:notes:174]
[same as prior period, unchanged from 0001069202-15-000006:notes:166]

[0001069202-15-000008:notes:175]
|  | Balance as ofDecember 31, 2014 |  | Charged to Earnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of June 30, 2015 |
| Severance and related expense | $ | 1.5 |  |  | $ | 1.8 |  |  | $ | (0.6 | ) |  | $ | — |  |  | $ | 2.7 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Equipment moves | 0.1 |  |  | — |  |  | (0.1 | ) |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.2 |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Total restructuring accruals | $ | 1.6 |  |  | $ | 2.1 |  |  | $ | (0.9 | ) |  | $ | (0.1 | ) |  | $ | 2.7 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-15-000008:notes:176]
[same as prior period, unchanged from 0001069202-15-000006:notes:168]

[0001069202-15-000008:notes:177]
[same as prior period, unchanged from 0001069202-15-000006:notes:169]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-15-000008:notes:178]
[same as prior period, unchanged from 0001069202-15-000006:notes:170]

[0001069202-15-000008:notes:179]
[same as prior period, unchanged from 0001069202-15-000006:notes:171]

[0001069202-15-000008:notes:180]
[same as prior period, unchanged from 0001069202-15-000006:notes:172]

[0001069202-15-000008:notes:181]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII. We recorded these share-based awards as corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-15-000008:notes:182]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations for the periods presented.

[0001069202-15-000008:notes:183]
[same as prior period, unchanged from 0001069202-15-000006:notes:175]

[0001069202-15-000008:notes:184]
[same as prior period, unchanged from 0001069202-15-000006:notes:176]

[0001069202-15-000008:notes:185]
[same as prior period, unchanged from 0001069202-15-000006:notes:177]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-15-000008:notes:186]
[same as prior period, unchanged from 0001069202-15-000006:notes:178]

[0001069202-15-000008:notes:187]
Our Board of Directors has authorized a total of $1.4 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first six months of 2015. As of June 30, 2015, $396.0 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-15-000008:notes:188]
We also repurchased 0.2 million shares for $21.8 million for the six months ended June 30, 2015 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
