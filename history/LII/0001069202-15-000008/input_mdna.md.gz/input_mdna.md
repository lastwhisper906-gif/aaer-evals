# LII MD&A — 0001069202-15-000008


## mdna

[0001069202-15-000008:mdna:1]
[same as prior period, unchanged from 0001069202-15-000006:mdna:1]

[0001069202-15-000008:mdna:2]
[same as prior period, unchanged from 0001069202-15-000006:mdna:2]

[0001069202-15-000008:mdna:3]
[same as prior period, unchanged from 0001069202-15-000006:mdna:3]

[0001069202-15-000008:mdna:4]
[same as prior period, unchanged from 0001069202-15-000006:mdna:4]

[0001069202-15-000008:mdna:5]
[same as prior period, unchanged from 0001069202-15-000006:mdna:5]

[0001069202-15-000008:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated warranty costs, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components have impacted us and the HVACR industry in general.  We seek to mitigate the impact of higher commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-15-000008:mdna:7]
Financial Overview

[0001069202-15-000008:mdna:8]
In the second quarter of 2015, the Residential Heating & Cooling segment continued to lead our overall operational performance with a 5% increase in net sales and a $15 million increase in segment profit compared to the second quarter of 2014.  The primary growth drivers for this segment were increases in both price and mix as well as volume gains.  Our Commercial Heating & Cooling segment also performed well in the second quarter of 2015 with a 5% increase in net sales and $4 million in increased segment profit compared to the second quarter of 2014.  This segment's profits were up largely due to volume increases and material cost savings.  Sales in our Refrigeration segment decreased by 4% while segment profit was relatively flat compared to the second quarter of 2014.  Higher sales volume and lower material costs were offset by unfavorable foreign currency exchange rates and a negative impact from the Australian carbon tax levy repeal.

[0001069202-15-000008:mdna:9]
On a consolidated basis, our product profit margins improved quarter over quarter primarily due to lower material costs.  We continue to manage our cost structure by utilizing a combination of commodity hedging and controllable product cost management initiatives.

[0001069202-15-000008:mdna:10]
[same as prior period, unchanged from 0001069202-15-000006:mdna:7]

[0001069202-15-000008:mdna:11]
| • | Net sales increased $32 million, or 3%, to $993 million in the second quarter of 2015 compared to $961 million in the second quarter of 2014. |

[0001069202-15-000008:mdna:12]
| • | Operational income from continuing operations in the second quarter of 2015 increased $12 million to $131 million from $119 million in the second quarter of 2014. |

[0001069202-15-000008:mdna:13]
| • | Net income for the second quarter of 2015 increased $7 million to $81 million from $74 million in the second quarter of 2014. |

[0001069202-15-000008:mdna:14]
| • | Diluted earnings per share from continuing operations were $1.79 per share in the second quarter of 2015 compared to $1.50 per share in the second quarter of 2014. |

[0001069202-15-000008:mdna:15]
| • | During the second quarter of 2015, we returned $14 million to shareholders through dividend payments. |

[0001069202-15-000008:mdna:16]
| • | Cash used in operating activities was $52 million in the first six months of 2015 compared to $73 million in the first six months of 2014. |

[0001069202-15-000008:mdna:17]
Second Quarter of 2015 Compared to Second Quarter of 2014 - Consolidated Results

[0001069202-15-000008:mdna:18]
[same as prior period, unchanged from 0001069202-15-000006:mdna:18]

[0001069202-15-000008:mdna:19]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | $ | 992.5 |  |  | $ | 960.7 |  |  | 3.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 709.1 |  |  | 698.1 |  |  | (1.6 | ) |  | 71.4 |  |  | 72.7 |  |
| Gross profit | 283.4 |  |  | 262.6 |  |  | 7.9 |  |  | 28.6 |  |  | 27.3 |  |
| Selling, general and administrative expenses | 152.9 |  |  | 148.9 |  |  | (2.7 | ) |  | 15.4 |  |  | 15.5 |  |
| Losses (gains) and other expenses, net | 3.3 |  |  | (1.0 | ) |  | (430.0 | ) |  | 0.3 |  |  | (0.1 | ) |
| Restructuring charges | 1.8 |  |  | 0.2 |  |  | (800.0 | ) |  | 0.2 |  |  | — |  |
| Income from equity method investments | (5.5 | ) |  | (4.6 | ) |  | 19.6 |  |  | (0.6 | ) |  | (0.5 | ) |
| Operational income from continuing operations | $ | 130.9 |  |  | $ | 119.1 |  |  | 9.9 | % |  | 13.2 | % |  | 12.4 | % |

[0001069202-15-000008:mdna:20]
[same as prior period, unchanged from 0001069202-15-000006:mdna:20]

[0001069202-15-000008:mdna:21]
Net sales increased 3% in the second quarter of 2015 compared to the second quarter of 2014, primarily from 5% higher sales volumes and 2% favorable price and mix.  The Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments all delivered higher volume and pricing by capturing additional replacement and new construction business.  These increases were offset by a 3% unfavorable impact from foreign currency exchanges rates and a 1% decrease from lower refrigerant pricing on our Australia wholesale business.

[0001069202-15-000008:mdna:22]
[same as prior period, unchanged from 0001069202-15-000006:mdna:22]

[0001069202-15-000008:mdna:23]
Gross profit margin in the second quarter of 2015 increased 130 basis points ("bps") to 28.6% compared to the second quarter of 2014.  Lower material costs increased our profit margin by 220 bps. Offsetting this increase were decreases of 50 bps for unfavorable mix and price, 20 bps from lower refrigerant pricing on our Australia wholesale business when compared to the prior year quarter, and 10 bps investments in distribution and other growth initiatives with the balance from other cost changes.

[0001069202-15-000008:mdna:24]
[same as prior period, unchanged from 0001069202-15-000006:mdna:24]

[0001069202-15-000008:mdna:25]
SG&A was $153 million in the second quarter of 2015 compared to $149 million in the second quarter of 2014, and as a percentage of net sales declined 10 bps to 15.4%.  SG&A expenses have increased at a slower pace than the increase in net sales.

[0001069202-15-000008:mdna:26]
[same as prior period, unchanged from 0001069202-15-000006:mdna:26]

[0001069202-15-000008:mdna:27]
Losses (gains) and other expenses, net for the second quarter of 2015 and 2014 included the following (in millions):

[0001069202-15-000008:mdna:28]
|  | For the Three Months Ended June 30, |
|  | 2015 |  | 2014 |
| Realized losses on settled future contracts | $ | 0.3 |  |  | $ | 0.3 |  |
| Foreign currency exchange losses (gains) | 0.4 |  |  | (0.8 | ) |
| Gain on disposal of fixed assets | — |  |  | (0.1 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | (0.8 | ) |
| Special legal contingency charges | 0.7 |  |  | (0.2 | ) |
| Asbestos-related litigation | 0.4 |  |  | 0.4 |  |
| Contractor tax payments | 1.6 |  |  | — |  |
| Environmental liabilities | (0.2 | ) |  | — |  |
| Other items, net | — |  |  | 0.2 |  |
| Losses (gains) and other expenses, net | $ | 3.3 |  |  | $ | (1.0 | ) |

[0001069202-15-000008:mdna:29]
The net change in unrealized losses (gains) on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange losses increased in the second quarter of 2015 primarily due to the Australian and Canadian dollar exchange rates.  Contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  For more information on special legal contingency charges, asbestos-related litigation and contractor tax payments, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000008:mdna:30]
[same as prior period, unchanged from 0001069202-15-000006:mdna:30]

[0001069202-15-000008:mdna:31]
Restructuring charges increased to $2 million in the second quarter of 2015 while minimal restructuring charges were incurred in the second quarter of 2014.  The increase was primarily due to the restructuring of our Australian operations in the Refrigeration segment.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000008:mdna:32]
[same as prior period, unchanged from 0001069202-15-000006:mdna:32]

[0001069202-15-000008:mdna:33]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $6 million in the second quarter of 2015 increased over the second quarter of 2014 due to improved operating results from our joint ventures.

[0001069202-15-000008:mdna:34]
[same as prior period, unchanged from 0001069202-15-000006:mdna:34]

[0001069202-15-000008:mdna:35]
Interest expense, net of $6 million in the second quarter of 2015 increased from $4 million in the second quarter of 2014 due primarily to an increase in our average borrowings.

[0001069202-15-000008:mdna:36]
[same as prior period, unchanged from 0001069202-15-000006:mdna:36]

[0001069202-15-000008:mdna:37]
The Provision for income taxes was $43 million in the second quarter of 2015 compared to $41 million in the second quarter of 2014.  The effective tax rate was 34.5% for the second quarter of 2015 compared to 35.4% for the second quarter of 2014.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-15-000008:mdna:38]
Second Quarter of 2015 Compared to Second Quarter of 2014 - Results by Segment

[0001069202-15-000008:mdna:39]
[same as prior period, unchanged from 0001069202-15-000006:mdna:39]

[0001069202-15-000008:mdna:40]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the second quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000008:mdna:41]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 555.1 |  |  | $ | 527.7 |  |  | $ | 27.4 |  |  | 5.2 | % |
| Profit | $ | 99.9 |  |  | $ | 85.0 |  |  | $ | 14.9 |  |  | 17.5 | % |
| % of net sales | 18.0 | % |  | 16.1 | % |  |  |  |  |

[0001069202-15-000008:mdna:42]
Net sales increased by 5% in the second quarter of 2015 compared to the second quarter of 2014.  Volume increased by 2% due to industry growth and market share gains and favorable price and mix increased net sales by 4%, with a 1% decrease from unfavorable foreign currency exchange rates.

[0001069202-15-000008:mdna:43]
Segment profit for the second quarter of 2015 increased $15 million due to $13 million in material cost savings, $3 million in higher sales volumes, $8 million from favorable price and mix, and $1 million from favorable other product costs.  Partially offsetting these increases was $2 million of unfavorable foreign currency exchange rates, $6 million of higher SG&A expenses due to increased wages and higher information technology investments, and $2 million from investments in distribution.

[0001069202-15-000008:mdna:44]
[same as prior period, unchanged from 0001069202-15-000006:mdna:44]

[0001069202-15-000008:mdna:45]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000008:mdna:46]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 253.6 |  |  | $ | 241.0 |  |  | $ | 12.6 |  |  | 5.2 | % |
| Profit | $ | 43.0 |  |  | $ | 39.0 |  |  | $ | 4.0 |  |  | 10.3 | % |
| % of net sales | 17.0 | % |  | 16.2 | % |  |  |  |  |

[0001069202-15-000008:mdna:47]
Net sales increased 5% in the second quarter of 2015 compared to the second quarter of 2014.  Sales volume increased by 10% primarily due to strong North American equipment volumes, mid single digit growth in Europe, and new customer gains in our service business.  Unfavorable foreign currency exchange rates had a negative 5% impact.

[0001069202-15-000008:mdna:48]
Segment profit in the second quarter of 2015 increased $4 million compared to the second quarter of 2014, primarily due to $7 million in higher sales volumes and $4 from lower material costs.  Partially offsetting these increases was $3 million in unfavorable mix, $2 million for information technology and distribution investments and start-up costs to enter the Variable Refrigerant Flow ("VRF") market, and $2 million of higher SG&A expenses.

[0001069202-15-000008:mdna:49]
[same as prior period, unchanged from 0001069202-15-000006:mdna:49]

[0001069202-15-000008:mdna:50]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2015 and 2014 (dollars in millions):

[0001069202-15-000008:mdna:51]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 183.8 |  |  | $ | 192.0 |  |  | $ | (8.2 | ) |  | (4.3 | )% |
| Profit | $ | 13.3 |  |  | $ | 13.7 |  |  | $ | (0.4 | ) |  | (2.9 | )% |
| % of net sales | 7.2 | % |  | 7.1 | % |  |  |  |  |

[0001069202-15-000008:mdna:52]
Net sales decreased 4% in the second quarter of 2015 compared to the second quarter of 2014 primarily due to an 8% unfavorable

[0001069202-15-000008:mdna:53]
impact from foreign currency exchange rates and a 3% negative impact from the Australian carbon tax levy repeal that was effective July 1, 2014.  These decreases were partially offset by 6% volume growth led by our North American supermarket businesses and by 1% from combined price and mix.

[0001069202-15-000008:mdna:54]
Segment profit for the second quarter of 2015 decreased $0.4 million compared to the second quarter of 2014.  Higher sales volumes of $2 million, $4 million from lower material costs and $3 million from factory productivity and other product costs were offset by $3 million of unfavorable mix predominantly in the North American supermarket business, $3 million lower profitability in our Australia refrigerant business, $2 million of SG&A inflation and costs related to investments for future growth, and $1 million from unfavorable foreign currency exchanges rates.

[0001069202-15-000008:mdna:55]
[same as prior period, unchanged from 0001069202-15-000006:mdna:54]

[0001069202-15-000008:mdna:56]
Corporate and other expenses increased $3 million to $22 million in the second quarter of 2015 from $19 million in the second quarter of 2014 due primarily to general wage inflation, health care costs and currency losses.

[0001069202-15-000008:mdna:57]
Year-to-Date through June 30, 2015 Compared to Year-to-Date through June 30, 2014 - Consolidated Results

[0001069202-15-000008:mdna:58]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-15-000008:mdna:59]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales | $ | 1,678.3 |  |  | $ | 1,656.1 |  |  | 1.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,231.9 |  |  | 1,225.4 |  |  | 0.5 |  |  | 73.4 |  |  | 74.0 |  |
| Gross profit | 446.4 |  |  | 430.7 |  |  | 3.6 |  |  | 26.6 |  |  | 26.0 |  |
| Selling, general and administrative expenses | 286.2 |  |  | 284.5 |  |  | 0.6 |  |  | 17.1 |  |  | 17.2 |  |
| Losses and other expenses, net | 8.9 |  |  | 1.4 |  |  | 535.7 |  |  | 0.5 |  |  | 0.1 |  |
| Restructuring charges | 2.1 |  |  | 0.3 |  |  | 600.0 |  |  | 0.1 |  |  | — |  |
| Income from equity method investments | (8.8 | ) |  | (8.5 | ) |  | 3.5 |  |  | (0.5 | ) |  | (0.5 | ) |
| Operational income from continuing operations | $ | 158.0 |  |  | $ | 153.0 |  |  | 3.3 |  |  | 9.4 | % |  | 9.2 | % |

[0001069202-15-000008:mdna:60]
Net Sales

[0001069202-15-000008:mdna:61]
Net sales increased 1% in the first six months of 2015 compared to the first six months of 2014, with sales volumes up 4% and price and mix up 2%.  The volume increases were driven by our Residential Heating & Cooling, Commercial Heating & Cooling and Refrigeration segments all capturing additional replacement and new construction business.  Partially offsetting these increases was a 4% decrease from unfavorable foreign currency exchange rates and a 1% decrease from lower refrigerant pricing on our Australia wholesale business.

[0001069202-15-000008:mdna:62]
Gross Profit

[0001069202-15-000008:mdna:63]
Gross profit margins in the first six months of 2015 increased 60 bps to 27% compared to the first six months of 2014.  Improvements of 230 bps from material cost savings were offset by 60 bps from unfavorable price and mix, 40 bps for investments in distribution and other growth initiatives, 40 bps from lower refrigerant pricing on our Australia wholesale business when compared to the prior year quarter with the balance attributable to increased other product costs.

[0001069202-15-000008:mdna:64]
Selling, General and Administrative Expenses

[0001069202-15-000008:mdna:65]
SG&A was $286 million for the first six months of 2015 compared to $285 million for the first six months of 2014, and as a percentage of net sales, declined 10 bps from 17.2% to 17.1%.  SG&A expenses have increased at a slower pace than the increase in net sales.

[0001069202-15-000008:mdna:66]
Losses and Other Expenses, Net

[0001069202-15-000008:mdna:67]
Losses and other expenses, net for the first six months of 2015 and 2014 included the following (in millions):

[0001069202-15-000008:mdna:68]
|  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |
| Realized losses on settled future contracts | $ | 0.7 |  |  | $ | 0.6 |  |
| Foreign currency exchange losses (gains) | 1.5 |  |  | 0.1 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | — |  |  | (0.2 | ) |
| Special legal contingency charges | 4.1 |  |  | 0.2 |  |
| Asbestos-related litigation | 0.6 |  |  | 0.6 |  |
| Environmental liabilities | 0.4 |  |  | — |  |
| Contractor tax payments | 1.6 |  |  | — |  |
| Other items, net | — |  |  | 0.2 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 8.9 |  |  | $ | 1.4 |  |

[0001069202-15-000008:mdna:69]
Foreign currency exchange losses increased in the second quarter of 2015 primarily due to the Australian and Canadian dollar exchange rates. Special legal contingency charges increased for our estimate of costs expected to be incurred for an attempted class action lawsuit.  Contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  For more information on special legal contingency charges, asbestos-related litigation and contractor tax payments, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000008:mdna:70]
Restructuring Charges

[0001069202-15-000008:mdna:71]
Restructuring charges increased to $2 million in the first six months of 2015 while minimal restructuring charges were incurred in the first six months of 2014.  The increase was primarily due to the restructuring of our Australian operations in the Refrigeration segment.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000008:mdna:72]
Income from Equity Method Investments

[0001069202-15-000008:mdna:73]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $9 million in the first six months of 2015 was relatively flat as compared to the first six months of 2014.

[0001069202-15-000008:mdna:74]
Interest Expense, net

[0001069202-15-000008:mdna:75]
Interest expense, net of $12 million in the first six months of 2015 increased from $7 million in the first six months of 2014 due to an increase in our average net borrowings and an increase in our weighted average borrowing rates over the comparable periods.

[0001069202-15-000008:mdna:76]
Income Taxes

[0001069202-15-000008:mdna:77]
The Provision for income taxes was $50 million in the first six months of 2015 compared to $52 million in the first six months of 2014.  The effective tax rate was 34.4% for the first six months of 2015 compared to 35.3% for the first six months of 2014.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-15-000008:mdna:78]
Year-to-Date through June 30, 2015 Compared to Year-to-Date through June 30, 2014 - Results by Segment

[0001069202-15-000008:mdna:79]
Residential Heating & Cooling

[0001069202-15-000008:mdna:80]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first six months of 2015 and 2014 (dollars in millions):

[0001069202-15-000008:mdna:81]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 917.7 |  |  | $ | 869.8 |  |  | $ | 47.9 |  |  | 5.5 | % |
| Profit | $ | 131.2 |  |  | $ | 109.4 |  |  | $ | 21.8 |  |  | 19.9 | % |
| % of net sales | 14.3 | % |  | 12.6 | % |  |  |  |  |

[0001069202-15-000008:mdna:82]
Net sales increased by 6%  in the first six months of 2015 compared to the first six months of 2014.  Sales volumes increased net sales by 4% due to industry growth and market share gains and the benefits of favorable price and mix contributed 3%.  Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-15-000008:mdna:83]
Segment profit for the first six months of 2015 increased $22 million due to $24 million from material cost savings, $7 million from higher sales volume, and $9 million from favorable price and mix. Partially offsetting these increases was $5 million of unfavorable foreign exchange rates, $5 million in distribution expenses related to continued investment in distribution expansion, and $7 million of SG&A inflation and investments with the balance attributable to increased other product costs.

[0001069202-15-000008:mdna:84]
Commercial Heating & Cooling

[0001069202-15-000008:mdna:85]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first six months of 2015 and 2014 (dollars in millions):

[0001069202-15-000008:mdna:86]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 413.5 |  |  | $ | 414.0 |  |  | $ | (0.5 | ) |  | (0.1 | )% |
| Profit | $ | 50.7 |  |  | $ | 49.2 |  |  | $ | 1.5 |  |  | 3.0 | % |
| % of net sales | 12.3 | % |  | 11.9 | % |  |  |  |  |

[0001069202-15-000008:mdna:87]
Commercial Heating & Cooling net sales were flat in the first six months of 2015 compared to the first six months of 2014. Sales volumes increased net sales by 5% and changes in foreign currency exchange rates unfavorably impacted net sales by 5%.

[0001069202-15-000008:mdna:88]
Segment profit in the first six months of 2015 increased $2 million compared to the first six months of 2014.  The benefits of $6 million from incremental volume and $7 million from material cost savings were partially offset by $3 million in unfavorable price and mix, $4 million for information technology and distribution investments and start-up costs to enter the VRF market, and $4 million of higher SG&A expenses.

[0001069202-15-000008:mdna:89]
Refrigeration

[0001069202-15-000008:mdna:90]
The following table presents our Refrigeration segment's net sales and profit for the first six months of 2015 and 2014 (dollars in millions):

[0001069202-15-000008:mdna:91]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2015 |  | 2014 |  | Difference |  | % Change |
| Net sales | $ | 347.1 |  |  | $ | 372.3 |  |  | $ | (25.2 | ) |  | (6.8 | )% |
| Profit | $ | 17.2 |  |  | $ | 25.8 |  |  | $ | (8.6 | ) |  | (33.3 | )% |
| % of net sales | 5.0 | % |  | 6.9 | % |  |  |  |  |

[0001069202-15-000008:mdna:92]
Refrigeration net sales declined 7% in the first six months of 2015 compared to the first six months of 2014 primarily due to an 8% impact from unfavorable foreign exchange rates and a 3% impact from the Australian carbon levy repeal that was effective

[0001069202-15-000008:mdna:93]
July 1, 2014.  These decreases were partially offset by 4% volume growth led by our North American supermarket businesses.

[0001069202-15-000008:mdna:94]
Segment profit for the first six months of 2015 decreased $9 million compared to the first six months of 2014 primarily due to $7 million from unfavorable mix predominantly in the North American supermarket business, $9 million lower profitability in our Australia refrigerant business, $1 million of costs related to investments for future growth, $3 million from unfavorable foreign currency exchange rates and $2 million from SG&A inflation.  Partially offsetting these decreases were $6 million from lower material costs, $1 million from higher sales volumes, and $6 million from factory productivity and other product costs.

[0001069202-15-000008:mdna:95]
Corporate and Other

[0001069202-15-000008:mdna:96]
Corporate and other expenses increased $3 million to $34 million in the first six months of 2015 from $31 million in the first six months of 2014 due primarily to general wage inflation, health care costs and currency losses.

[0001069202-15-000008:mdna:97]
[same as prior period, unchanged from 0001069202-15-000006:mdna:56]

[0001069202-15-000008:mdna:98]
[same as prior period, unchanged from 0001069202-15-000006:mdna:57]

[0001069202-15-000008:mdna:99]
[same as prior period, unchanged from 0001069202-15-000006:mdna:58]

[0001069202-15-000008:mdna:100]
The following table summarizes our cash flow activity for the six months ended June 30, 2015 and 2014 (in millions):

[0001069202-15-000008:mdna:101]
|  | For the Six Months Ended June 30, |
|  | 2015 |  | 2014 |
| Net cash used in operating activities | $ | (52.3 | ) |  | $ | (73.4 | ) |
| Net cash used in investing activities | (33.0 | ) |  | (41.2 | ) |
| Net cash provided by financing activities | 100.6 |  |  | 125.1 |  |

[0001069202-15-000008:mdna:102]
Net Cash Used In Operating Activities - Net cash used in operating activities decreased approximately $21 million in the first six months of 2015 compared to $73 million in the first six months of 2014.   This decrease was primarily attributable to the seasonal increase in working capital requirements in 2015 being smaller than the increase in 2014,  offset by an unfavorable impact from timing of payments in the ordinary course of business.

[0001069202-15-000008:mdna:103]
Net Cash Used in Investing Activities - Capital expenditures were $33 million and $41 million in the first six months of 2015 and 2014, respectively.  Capital expenditures in 2015 were primarily related to investments in systems and software to support the overall enterprise and continued investments in our distribution network.

[0001069202-15-000008:mdna:104]
Net Cash Provided by Financing Activities - Net cash provided by financing activities decreased to $101 million in the first six months of 2015 primarily due to an increase in payments on borrowings and partially offset by decreases in stock repurchases.   Net borrowings were higher in 2015 to support the increased stock repurchases and dividend payments.  Final settlement of the $450 million Accelerated Share Repurchase Plan (ASR) executed in the fourth quarter of 2014 is expected in the second half of 2015.

[0001069202-15-000008:mdna:105]
[same as prior period, unchanged from 0001069202-15-000006:mdna:64]

[0001069202-15-000008:mdna:106]
The following table details our lines of credit and financing arrangements as of June 30, 2015 (in millions):

[0001069202-15-000008:mdna:107]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-term debt: |  |  |  |  |  |
| Foreign obligations | $ | 28.2 |  |  | $ | 6.1 |  |  | $ | 22.1 |  |
| Asset Securitization Program (1) | 220.0 |  |  | 220.0 |  |  | — |  |
| Total short-term debt | $ | 248.2 |  |  | $ | 226.1 |  |  | $ | 22.1 |  |
| Current maturities of long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | — |  |
| Domestic credit facility (2) | 15.0 |  |  | 15.0 |  |  | — |  |
| Total current maturities of long-term debt | $ | 16.3 |  |  | $ | 16.3 |  |  | $ | — |  |
| Long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 15.2 |  |  | $ | 15.2 |  |  | $ | — |  |
| Domestic credit facility (2) | 912.5 |  |  | 598.0 |  |  | 289.8 |  |
| Senior unsecured notes | $ | 200.0 |  |  | $ | 200.0 |  |  | $ | — |  |
| Total long-term debt | 1,127.7 |  |  | 813.2 |  |  | 289.8 |  |
| Total debt | $ | 1,392.2 |  |  | $ | 1,055.6 |  |  | $ | 311.9 |  |

[0001069202-15-000008:mdna:108]
[same as prior period, unchanged from 0001069202-15-000006:mdna:67]

[0001069202-15-000008:mdna:109]
(2) The available future borrowings on our domestic credit facility were reduced by the outstanding borrowings and $24.7 million in outstanding standby letters of credit.  We also had $26.4 million in outstanding standby letters of credit outside of the domestic credit facility as of June 30, 2015.

[0001069202-15-000008:mdna:110]
[same as prior period, unchanged from 0001069202-15-000006:mdna:69]

[0001069202-15-000008:mdna:111]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 95.0% at June 30, 2015 from 99.0% at December 31, 2014.

[0001069202-15-000008:mdna:112]
As of June 30, 2015, our senior credit ratings were Baa3 with a negative outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to ensure the capital markets remain available to us.

[0001069202-15-000008:mdna:113]
[same as prior period, unchanged from 0001069202-15-000006:mdna:72]

[0001069202-15-000008:mdna:114]
We believe our cash and cash equivalents of $48 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $48 million as of June 30, 2015 was $24.1 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States. If we were to repatriate foreign earnings, we would be required to accrue and pay taxes in the United States, less foreign tax credits, for the amounts that were repatriated.

[0001069202-15-000008:mdna:115]
Our expected capital expenditures for 2015 are $80 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with the completion of our $450 million accelerated share repurchase program in 2015 and a target of between $55 million and $60 million of dividend payments in 2015.

[0001069202-15-000008:mdna:116]
[same as prior period, unchanged from 0001069202-15-000006:mdna:75]

[0001069202-15-000008:mdna:117]
[same as prior period, unchanged from 0001069202-15-000006:mdna:76]

[0001069202-15-000008:mdna:118]
Commitments, Contingencies and Guarantees

[0001069202-15-000008:mdna:119]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-15-000008:mdna:120]
[same as prior period, unchanged from 0001069202-15-000006:mdna:79]

[0001069202-15-000008:mdna:121]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.

[0001069202-15-000008:mdna:122]
In January 2015, the FASB issued ASU No. 2015-01, Income Statement - Extraordinary and Unusual Items (Subtopic 225-20): Simplifying Income Statement Presentation by Eliminating the Concept of Extraordinary Items. ASU No. 2015-01 eliminates the concept of an extraordinary item from GAAP. As a result, an entity will no longer be required to separately present an extraordinary item on its statement of operations, net of tax, after income from continuing operations or to disclose income taxes and net income per share data applicable to an extraordinary item. However, ASU No. 2015-01 will still retain the presentation and disclosure guidance for items that are unusual in nature and occur infrequently. ASU No. 2015-01 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period, although early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements, absent any material transactions in future periods that would have qualified for extraordinary item presentation under the prior guidance.

[0001069202-15-000008:mdna:123]
In February 2015, the FASB issued ASU 2015-02, Consolidation: Amendments to the Consolidation Analysis, or ASU 2015-02, which amends the criteria for determining which entities are considered variable interest entities (“VIEs”), amends the criteria for determining if a service provider possesses a variable interest in a VIE and ends the deferral granted to investment companies for application of the VIE consolidation model. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015 and early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements.

[0001069202-15-000008:mdna:124]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. This guidance is effective for annual and interim reporting periods of public entities beginning after December 15, 2015, and early adoption is permitted. We do not expect the adoption of this standard to materially impact our consolidated financial statements.
