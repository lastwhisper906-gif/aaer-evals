# LII MD&A — 0001628280-22-002664


## mdna

[0001628280-22-002664:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-22-002664:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the Consolidated Financial Statements and related Notes to the Consolidated Financial Statements in Item 8, “Other Financial Statement Details,” of this Annual Report on Form 10-K.

[0001628280-22-002664:mdna:3]
Business Overview

[0001628280-22-002664:mdna:4]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 3 in the Notes to the Consolidated Financial Statements.

[0001628280-22-002664:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001628280-22-002664:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001628280-22-002664:mdna:7]
Impact of COVID-19 Pandemic

[0001628280-22-002664:mdna:8]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. Currently the COVID-19 pandemic has disrupted

[0001628280-22-002664:mdna:9]
17

[0001628280-22-002664:mdna:10]
our business operations and caused a significant unfavorable impact on our results of operations in 2020. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations.

[0001628280-22-002664:mdna:11]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

[0001628280-22-002664:mdna:12]
Financial Highlights

[0001628280-22-002664:mdna:13]
•Net sales increased $560 million, or 15%, to $4,194 million in 2021 from $3,634 million in 2020.

[0001628280-22-002664:mdna:14]
•Operating income in 2021 was $590 million compared to $479 million in 2020.

[0001628280-22-002664:mdna:15]
•Net income in 2021 increased to $464 million from $356 million in 2020.

[0001628280-22-002664:mdna:16]
•Diluted earnings per share from continuing operations were $12.39 per share in 2021 compared to $9.26 per share in 2020.

[0001628280-22-002664:mdna:17]
•We generated $516 million of cash flow from operating activities in 2021 compared to $612 million in 2020.

[0001628280-22-002664:mdna:18]
•In 2021, we returned $127 million to shareholders through dividend payments and we used $600 million to purchase 1.9 million shares of stock under our Share Repurchase Plans.

[0001628280-22-002664:mdna:19]
Overview of Results

[0001628280-22-002664:mdna:20]
The Residential Heating & Cooling segment performed well in 2021, with an 18% increase in net sales and a $112 million increase in segment profit compared to 2020 primarily due to higher sales volumes.  Our Commercial Heating & Cooling segment saw an increase in net sales of 8% and a $26 million decrease in segment profit compared to 2020 primarily due to increased combined price and sales mix and increased product costs, respectively.  Sales in our Refrigeration segment increased 17% and segment profit increased $16 million compared to 2020 primarily due to higher sales volumes.

[0001628280-22-002664:mdna:21]
Results of Operations

[0001628280-22-002664:mdna:22]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001628280-22-002664:mdna:23]
|  | For the Years Ended December 31, |
|  | 2021 |  | 2020 |  | 2019 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 4,194.1 |  |  | 100.0 | % |  | $ | 3,634.1 |  |  | 100.0 | % |  | $ | 3,807.2 |  |  | 100.0 | % |
| Cost of goods sold | 3,005.7 |  |  | 71.7 | % |  | 2,594.0 |  |  | 71.4 | % |  | 2,727.4 |  |  | 71.6 | % |
| Gross profit | 1,188.4 |  |  | 28.3 | % |  | 1,040.1 |  |  | 28.6 | % |  | 1,079.8 |  |  | 28.4 | % |
| Selling, general and administrative expenses | 598.9 |  |  | 14.3 | % |  | 555.9 |  |  | 15.3 | % |  | 585.9 |  | 15.4 | % |
| Losses (gains) and other expenses, net | 9.2 |  |  | 0.2 | % |  | 7.4 |  |  | 0.2 | % |  | 8.3 |  | 0.2 | % |
| Restructuring charges | 1.8 |  |  | — | % |  | 10.8 |  |  | 0.3 | % |  | 10.3 |  | 0.3 | % |
| Loss (gain), net on sale of businesses and related property | — |  |  | — | % |  | — |  |  | — | % |  | 10.6 |  |  | 0.3 | % |
| (Gain) loss from natural disasters, net of insurance recoveries | — |  |  | — | % |  | 3.1 |  |  | 0.1 | % |  | (178.8) |  |  | (4.7) | % |
| Income from equity method investments | (11.8) |  |  | (0.3) | % |  | (15.6) |  |  | (0.4) | % |  | (13.4) |  |  | (0.4) | % |
| Operating income | $ | 590.3 |  |  | 14.1 | % |  | $ | 478.5 |  |  | 13.2 | % |  | $ | 656.9 |  |  | 17.3 | % |
| Loss from discontinued operations | — |  |  | — | % |  | (0.8) |  |  | — | % |  | (0.1) |  |  | — | % |
| Net income | $ | 464.0 |  |  | 11.1 | % |  | $ | 356.3 |  |  | 9.8 | % |  | $ | 408.7 |  |  | 10.7 | % |

[0001628280-22-002664:mdna:24]
Year Ended December 31, 2021 Compared to Year Ended December 31, 2020 - Consolidated Results

[0001628280-22-002664:mdna:25]
Net Sales

[0001628280-22-002664:mdna:26]
Net sales increased 15% in 2021 compared to 2020, driven by higher sales volumes of 11% and an improved combined price and mix of 4%. The increase in volume and price and mix was due to strong demand across all three of our business segments.

[0001628280-22-002664:mdna:27]
Gross Profit

[0001628280-22-002664:mdna:28]
Gross profit margins for 2021 decreased 30 basis points (“bps”) to 28.3% compared to 28.6% in 2020.  Gross profit margin decreased 180 bps from higher commodity costs, 90 bps from other product costs, 20 bps from higher freight and distribution costs, and 10 bps for lower factory efficiency.  Partially offsetting these cost increases was 270 bps from favorable combined price and mix.

[0001628280-22-002664:mdna:29]
Selling, General and Administrative Expenses

[0001628280-22-002664:mdna:30]
SG&A expenses increased by $43 million in 2021 compared to 2020.  As a percentage of net sales, SG&A expenses decreased 100 bps from 15.3% to 14.3% in the same periods primarily due to lower discretionary expenditures.

[0001628280-22-002664:mdna:31]
Losses (Gains) and Other Expenses, Net

[0001628280-22-002664:mdna:32]
Losses (gains) and other expenses, net for 2021 and 2020 included the following (in millions):

[0001628280-22-002664:mdna:33]
|  | For the Years Ended December 31, |
|  | 2021 |  | 2020 |
| Realized (gains) losses on settled futures contracts | $ | (1.2) |  |  | $ | 0.1 |  |
| Foreign currency exchange gains | (2.2) |  |  | (3.6) |  |
| Gain on disposal of fixed assets | (0.2) |  |  | (0.2) |  |
| Other operating income | (1.5) |  |  | (2.2) |  |
| Net change in unrealized gains on unsettled futures contracts | — |  |  | (0.3) |  |
| Special legal contingency charges | 1.3 |  |  | 1.1 |  |
| Asbestos-related litigation | 5.4 |  |  | 5.6 |  |
| Environmental liabilities | 2.9 |  |  | (1.4) |  |
| Charges incurred related to COVID-19 pandemic | 2.2 |  |  | 8.3 |  |
| Other items, net | 2.5 |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 9.2 |  |  | $ | 7.4 |  |

[0001628280-22-002664:mdna:34]
The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and sanitization supplies to ensure the health and safety of our employees.  The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001628280-22-002664:mdna:35]
Foreign currency exchange gains decreased in 2021 primarily due to weakening in foreign exchange rates in our primary markets.  The special legal contingency charges in 2021 relate to outstanding legal settlements.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001628280-22-002664:mdna:36]
Restructuring Charges

[0001628280-22-002664:mdna:37]
Restructuring charges were $1.8 million in 2021 compared to $10.8 million in 2020. Charges in 2021 were related to ongoing cost reduction actions taken in prior years.  The charges in 2020 related primarily to several cost reduction actions taken in response to the economic impact of the COVID-19 pandemic on our business.  These actions consisted of employee terminations for positions that were no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities.  For more information on our restructuring activities, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001628280-22-002664:mdna:38]
Goodwill

[0001628280-22-002664:mdna:39]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2021.  We did not record any goodwill impairments in 2021 or 2020.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001628280-22-002664:mdna:40]
Asset Impairments

[0001628280-22-002664:mdna:41]
We did not have any impairments of assets related to continuing operations in 2021 or 2020.

[0001628280-22-002664:mdna:42]
Pension Settlement

[0001628280-22-002664:mdna:43]
We did not have significant pension buyout activity in 2021 and 2020.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001628280-22-002664:mdna:44]
Income from Equity Method Investments

[0001628280-22-002664:mdna:45]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $12 million in 2021 compared to $16 million in 2020.  The decrease is due to rising production costs at the joint ventures.

[0001628280-22-002664:mdna:46]
Interest Expense, net

[0001628280-22-002664:mdna:47]
Net interest expense of $25 million in 2021 decreased from $28 million in 2020 primarily due to lower borrowing and lower borrowing costs.

[0001628280-22-002664:mdna:48]
Income Taxes

[0001628280-22-002664:mdna:49]
The income tax provision was $96 million in 2021 compared to $88 million in 2020, and the effective tax rate was 17.2% in 2021 compared to 19.8% in 2020.  The 2021 and 2020 effective tax rates differ from the statutory rate of 21% primarily due to state and foreign taxes. Refer to Note 13 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001628280-22-002664:mdna:50]
Loss from Discontinued Operations

[0001628280-22-002664:mdna:51]
Losses from discontinued operations were immaterial in 2021 and 2020 and relate to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001628280-22-002664:mdna:52]
Year Ended December 31, 2021 Compared to Year Ended December 31, 2020 - Results by Segment

[0001628280-22-002664:mdna:53]
Residential Heating & Cooling

[0001628280-22-002664:mdna:54]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2021 and 2020 (dollars in millions):

[0001628280-22-002664:mdna:55]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 2,775.6 |  |  | $ | 2,361.5 |  |  | $ | 414.1 |  |  | 18% |
| Profit | $ | 540.3 |  |  | $ | 428.5 |  |  | $ | 111.8 |  |  | 26% |
| % of net sales | 19.5 | % |  | 18.1 | % |  |  |  |  |

[0001628280-22-002664:mdna:56]
Residential Heating & Cooling net sales increased 18% in 2021 compared to 2020. Sales volume increased 13%, price increased 5% and favorable foreign currency exchange rates caused an increase of 1%.  Partially offsetting these increases was a 1% reduction due to unfavorable product mix.

[0001628280-22-002664:mdna:57]
Segment profit in 2021 increased $112 million compared to 2020 due to $108 million from favorable pricing, $91 million from higher sales volume, $9 million from favorable foreign currency exchange, $5 million from higher factory productivity, and $2 million from sourcing and engineering-led cost reductions.  Partially offsetting these increases were $59 million from

[0001628280-22-002664:mdna:58]
commodity costs, $20 million from higher warranty and other product costs, $14 million from higher SG&A, $5 million from unfavorable product mix, and $5 million from lower income from equity method investments.

[0001628280-22-002664:mdna:59]
Commercial Heating & Cooling

[0001628280-22-002664:mdna:60]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2021 and 2020 (dollars in millions):

[0001628280-22-002664:mdna:61]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 864.8 |  |  | $ | 800.9 |  |  | $ | 63.9 |  |  | 8 | % |
| Profit | $ | 110.9 |  |  | $ | 136.9 |  |  | $ | (26.0) |  |  | (19) | % |
| % of net sales | 12.8 | % |  | 17.1 | % |  |  |  |  |

[0001628280-22-002664:mdna:62]
Commercial Heating & Cooling net sales increased 8% in 2021 compared to 2020.  Price and mix combined increased 4%, sales volume was 3% higher, and foreign currency improved 1%.

[0001628280-22-002664:mdna:63]
Segment profit in 2021 decreased $26 million compared to 2020 due to $17 million from higher other product costs, $14 million from factory inefficiencies, $6 million from sourcing and engineering-led cost increases, $6 million from higher commodity costs, $6 million from higher freight and distribution costs, $4 million from higher SG&A costs, and $1 million from unfavorable foreign currency. Partially offsetting these declines was a favorable increase in combined price and mix of $19 million and $9 million from higher sales volume.

[0001628280-22-002664:mdna:64]
Refrigeration

[0001628280-22-002664:mdna:65]
The following table presents our Refrigeration segment’s net sales and profit for 2021 and 2020 (dollars in millions):

[0001628280-22-002664:mdna:66]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | Difference |  | % Change |
| Net sales | $ | 553.7 |  |  | $ | 471.7 |  |  | $ | 82.0 |  |  | 17 | % |
| Profit | $ | 49.1 |  |  | $ | 32.8 |  |  | $ | 16.3 |  |  | 50 | % |
| % of net sales | 8.9 | % |  | 7.0 | % |  |  |  |  |

[0001628280-22-002664:mdna:67]
Net sales increased 17% in 2021 compared to 2020. Sales volume increased 14%, price increased 3%, and foreign currency improved 1%.  Partially offsetting these increases was a 1% reduction due to unfavorable mix.

[0001628280-22-002664:mdna:68]
Segment profit in 2021 increased $16 million compared to 2020 due to $23 million from higher sales volume, $13 million from higher price, $3 million from higher factory productivity, and $1 million from higher income from equity method investments. Partially offsetting these increases were $10 million from higher SG&A, $8 million from higher commodity costs, $2 million from higher other product costs, $2 million from unfavorable product mix, and $2 million from higher freight and distribution costs.

[0001628280-22-002664:mdna:69]
Corporate and Other

[0001628280-22-002664:mdna:70]
Corporate and other expenses increased by $5 million in 2021 compared to 2020 primarily due to increased headcount and increases in incentive compensation costs.

[0001628280-22-002664:mdna:71]
Year Ended December 31, 2020 Compared to Year Ended December 31, 2019 - Consolidated Results

[0001628280-22-002664:mdna:72]
Net Sales

[0001628280-22-002664:mdna:73]
Net sales decreased 5% in 2020 compared to 2019, driven by lower sales volumes of 5% and a 1% decline related to the sale of our Kysor Warren business in the first quarter of 2019, partially offset by improved combined price and mix of 1%.   The decrease in sales volume was primarily due to the impact of the COVID-19 pandemic on our Commercial and Refrigeration segments.

[0001628280-22-002664:mdna:74]
Gross Profit

[0001628280-22-002664:mdna:75]
Gross profit margins for 2020 increased 20 basis points (“bps”) to 28.6% compared to 28.4% in 2019.  We saw margin increases of 90 bps from engineering and sourcing led cost reductions, 70 bps from lower commodity costs, and 20 bps from lower freight and distribution costs.  These were partially offset by 120 bps from unfavorable combined price and mix, 30 bps from higher product warranties, and 10 bps from other product costs.

[0001628280-22-002664:mdna:76]
Selling, General and Administrative Expenses

[0001628280-22-002664:mdna:77]
SG&A expenses decreased by $30 million in 2020 compared to 2019.  As a percentage of net sales, SG&A expenses decreased 10 bps from 15.4% to 15.3% in the same periods primarily due to lower discretionary expenditures.

[0001628280-22-002664:mdna:78]
Losses (Gains) and Other Expenses, Net

[0001628280-22-002664:mdna:79]
Losses (gains) and other expenses, net for 2020 and 2019 included the following (in millions):

[0001628280-22-002664:mdna:80]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2019 |
| Realized losses on settled futures contracts | $ | 0.1 |  |  | $ | 0.4 |  |
| Foreign currency exchange gains | (3.6) |  |  | (1.5) |  |
| Gain on disposal of fixed assets | (0.2) |  |  | (0.2) |  |
| Net change in unrealized gains on unsettled futures contracts | (0.3) |  |  | (0.5) |  |
| Other operating income | (2.2) |  |  | (1.7) |  |
| Special legal contingency charges | 1.1 |  |  | 1.2 |  |
| Asbestos charges | 5.6 |  |  | 3.1 |  |
| Environmental liabilities | (1.4) |  |  | 5.7 |  |
| Losses from pandemic | 8.3 |  |  | — |  |
| Other items, net | — |  |  | 1.8 |  |
| Losses (gains) and other expenses, net | $ | 7.4 |  |  | $ | 8.3 |  |

[0001628280-22-002664:mdna:81]
The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and sanitization supplies to ensure the health and safety of our employees.  The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001628280-22-002664:mdna:82]
Foreign currency exchange gains increased in 2020 primarily due to strengthening in foreign exchange rates in our primary markets.  The special legal contingency charges in 2020 relate to outstanding legal settlements.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001628280-22-002664:mdna:83]
Restructuring Charges

[0001628280-22-002664:mdna:84]
Restructuring charges were $10.8 million in 2020 compared to $10.3 million in 2019. The charges in 2020 related primarily to several cost reduction actions taken in response to the economic impact of the COVID-19 pandemic on our business.  These actions consisted of employee terminations for positions that were no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities.

[0001628280-22-002664:mdna:85]
Goodwill

[0001628280-22-002664:mdna:86]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2020.  We did not record any goodwill impairments in 2019 or 2020.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001628280-22-002664:mdna:87]
Asset Impairments

[0001628280-22-002664:mdna:88]
We did not have any impairments of assets related to continuing operations in 2020 or 2019.

[0001628280-22-002664:mdna:89]
Pension Settlement

[0001628280-22-002664:mdna:90]
In the second and fourth quarters of 2019, we entered into agreements to purchase group annuity contracts and transfer certain pension assets and related pension benefit obligations to Pacific Life Insurance Company.  We recognized $99.2 million of pension settlement charges related to these transactions.  We did not have significant pension buyout activity in 2020.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001628280-22-002664:mdna:91]
Income from Equity Method Investments

[0001628280-22-002664:mdna:92]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $16 million in 2020 compared to $13 million in 2019.  The increase is due to improved operating performance at the joint ventures.

[0001628280-22-002664:mdna:93]
Interest Expense, net

[0001628280-22-002664:mdna:94]
Net interest expense of $28 million in 2020 decreased from $48 million in 2019 primarily due to lower borrowing and lower borrowing costs.

[0001628280-22-002664:mdna:95]
Income Taxes

[0001628280-22-002664:mdna:96]
The income tax provision was $88 million in 2020 compared to $99 million in 2019, and the effective tax rate was 19.8% in 2020 compared to 19.5% in 2019.  The 2020 and 2019 effective tax rates differ from the statutory rate of 21% primarily due to state and foreign taxes. Refer to Note 13 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001628280-22-002664:mdna:97]
Loss from Discontinued Operations

[0001628280-22-002664:mdna:98]
Losses from discontinued operations were $1 million in 2020 which primarily relate to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001628280-22-002664:mdna:99]
Year Ended December 31, 2020 Compared to Year Ended December 31, 2019 - Results by Segment

[0001628280-22-002664:mdna:100]
Residential Heating & Cooling

[0001628280-22-002664:mdna:101]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2020 and 2019 (dollars in millions):

[0001628280-22-002664:mdna:102]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 2,361.5 |  |  | $ | 2,291.1 |  |  | $ | 70.4 |  |  | 3% |
| Profit | $ | 428.5 |  |  | $ | 464.6 |  |  | $ | (36.1) |  |  | (8)% |
| % of net sales | 18.1 | % |  | 20.3 | % |  |  |  |  |

[0001628280-22-002664:mdna:103]
Residential Heating & Cooling net sales increased 3% in 2020 compared to 2019. Sales volume increased 2% and price and mix combined increased 1%.

[0001628280-22-002664:mdna:104]
Segment profit in 2020 declined $36 million compared to 2019 due to $99 million of non-recurring insurance proceeds for lost profits related to the Marshalltown tornado, $10 million of higher warranty and other product costs, $5 million of higher tariffs, $3 million of combined price and mix, and $1 million of factory inefficiency. Partially offsetting these declines were $25 million of lower SG&A, $25 million of engineering and sourcing led cost reductions, $17 million from lower commodity costs, $8 million of lower freight and distribution expense, $5 million of higher sales volume, and $2 million of higher income from equity method investments.

[0001628280-22-002664:mdna:105]
Commercial Heating & Cooling

[0001628280-22-002664:mdna:106]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2020 and 2019 (dollars in millions):

[0001628280-22-002664:mdna:107]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 800.9 |  |  | $ | 947.4 |  |  | $ | (146.5) |  |  | (15) | % |
| Profit | $ | 136.9 |  |  | $ | 165.4 |  |  | $ | (28.5) |  |  | (17) | % |
| % of net sales | 17.1 | % |  | 17.5 | % |  |  |  |  |

[0001628280-22-002664:mdna:108]
Commercial Heating & Cooling net sales decreased 15% in 2020 compared to 2019.  Sales volume was 14% lower and price and mix combined decreased 1%.

[0001628280-22-002664:mdna:109]
Segment profit in 2020 decreased $29 million compared to 2019 due to $47 million of lower sales volume and $10 million of unfavorable mix.  Partially offsetting these declines were $9 million of lower SG&A, $7 million of engineering and sourcing led cost reductions, $6 million from lower commodity costs, $2 million of factory productivity, $2 million of other product costs, $1 million of lower tariffs on imports, and $1 million of favorable foreign currency exchange rates.

[0001628280-22-002664:mdna:110]
Refrigeration

[0001628280-22-002664:mdna:111]
The following table presents our Refrigeration segment’s net sales and profit for 2020 and 2019 (dollars in millions):

[0001628280-22-002664:mdna:112]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 471.7 |  |  | $ | 568.7 |  |  | $ | (97.0) |  |  | (17) | % |
| Profit | $ | 32.8 |  |  | $ | 61.3 |  |  | $ | (28.5) |  |  | (46) | % |
| % of net sales | 7.0 | % |  | 10.8 | % |  |  |  |  |

[0001628280-22-002664:mdna:113]
Net sales decreased 17% in 2020 compared to 2019.  Sales volume was 13% lower and the loss of sales from our divested Kysor Warren business contributed 6% which was partially offset by 1% of favorable combined price and mix and 1% from favorable foreign currency exchange rates.

[0001628280-22-002664:mdna:114]
Segment profit in 2020 decreased $29 million compared to 2019 due to $26 million of lower sales volumes, $10 million of factory inefficiency, $5 million of other product costs and warranty, $2 million from non-recurring European refrigerant quota sales, $1 million of combined price and mix, and $1 million from lower income from equity method investments.  Partially offsetting these declines were $5 million from lower commodity costs, $4 million of engineering and sourcing led cost reductions, $4 million lower SG&A, $1 million lower freight and distribution expense, $1 million of higher profit due to the divestiture of the Kysor Warren business, and $1 million of favorable foreign currency exchange rates.

[0001628280-22-002664:mdna:115]
Corporate and Other

[0001628280-22-002664:mdna:116]
Corporate and other expenses increased by $9 million in 2020 compared to 2019 primarily due to short-term and long-term stock-based incentive compensation.

[0001628280-22-002664:mdna:117]
Accounting for Futures Contracts

[0001628280-22-002664:mdna:118]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 10 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 3 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to operating income.

[0001628280-22-002664:mdna:119]
Liquidity and Capital Resources

[0001628280-22-002664:mdna:120]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001628280-22-002664:mdna:121]
Statement of Cash Flows

[0001628280-22-002664:mdna:122]
The following table summarizes our cash flow activity for the years ended December 31, 2021, 2020 and 2019 (in millions):

[0001628280-22-002664:mdna:123]
|  | 2021 |  | 2020 |  | 2019 |
| Net cash provided by operating activities | $ | 515.5 |  |  | $ | 612.4 |  |  | $ | 396.1 |  |
| Net cash (used in) provided by investing activities | (106.4) |  |  | (79.7) |  |  | 15.9 |  |
| Net cash used in financing activities | $ | (498.7) |  |  | $ | (441.8) |  |  | $ | (423.4) |  |

[0001628280-22-002664:mdna:124]
Net Cash Provided by Operating Activities - Net cash provided by operating activities decreased $96 million to $516 million in 2021 compared to $612 million in 2020.  The decrease was primarily attributable to increases in working capital partially offset by an increase in net income.

[0001628280-22-002664:mdna:125]
Net Cash (Used in) Provided by Investing Activities -  Net cash used in investing activities increased $27 million from 2020 to 2021 primarily due to increased capital expenditures. Capital expenditures were $107 million, $79 million and $106 million in 2021, 2020 and 2019, respectively.  Capital expenditures in 2021 were primarily related to the expansion of our manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.

[0001628280-22-002664:mdna:126]
Net Cash Used in Financing Activities - Net cash used in financing activities increased to $499 million in 2021 from $442 million in 2020.  The increase is primarily due to an increase in share repurchases in 2021 partially offset by net borrowings and repayments on debt.  During 2021 we repurchased $600 million of shares compared to $100 million of shares in 2020.  We also returned $127 million to shareholders through dividend payments in 2021.  For additional information on share repurchases, refer to Note 6 in the Notes to the Consolidated Financial Statements.

[0001628280-22-002664:mdna:127]
Debt Position

[0001628280-22-002664:mdna:128]
The following table details our lines of credit and financing arrangements as of December 31, 2021 (in millions):

[0001628280-22-002664:mdna:129]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset Securitization Program (1) | $ | — |  |
| Capital lease obligations | 11.3 |  |
| Debt issuance costs | — |  |
| Total current maturities of long-term debt | $ | 11.3 |  |
| Long-term debt: |  |
| Asset Securitization Program (1) | $ | 250.0 |  |
| Capital lease obligations | 29.0 |  |
| Domestic credit facility (2) | 6.5 |  |
| Senior unsecured notes | 950.0 |  |
| Debt issuance costs | (9.0) |  |
| Total long-term debt | 1,226.5 |  |
| Total debt | $ | 1,237.8 |  |

[0001628280-22-002664:mdna:130]
(1)The maximum securitization amount ranges from $300.0 million to $450.0 million, depending on the period. The maximum capacity of the Asset Securitization Program (“ASP”) is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 14 in the Notes to the Consolidated Financial Statements for more details.

[0001628280-22-002664:mdna:131]
(2)The total capacity on the facility is $750.0 million.  The amount available future borrowings on our domestic credit facility are $742 million after being reduced by the outstanding borrowings and $2 million in outstanding standby letters of credit as of December 31, 2021.

[0001628280-22-002664:mdna:132]
July 2021 Credit Agreement

[0001628280-22-002664:mdna:133]
In July 2021, we entered into the Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Prior Credit Agreement, among the Company, JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.

[0001628280-22-002664:mdna:134]
The Credit Agreement provides for revolving credit commitments of $750 million with sublimits for swingline loans of up to $65 million, letters of credit up to $100 million and revolving loans in certain non-U.S. currencies up to the U.S. dollar equivalent of $40 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement. At our request and subject to certain conditions, the revolving credit commitments under the Credit Agreement may be increased by up to a total of $350 million to the extent that existing or new lenders agree to provide additional commitments.

[0001628280-22-002664:mdna:135]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and its subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of its assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control.  As of December 31, 2021, we believe we were in compliance with all covenant requirements.

[0001628280-22-002664:mdna:136]
Financial Leverage

[0001628280-22-002664:mdna:137]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001628280-22-002664:mdna:138]
We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our Share Repurchase Plans.  Our book value of debt-to-total-capital ratio increased to 128% at December 31, 2021 compared to 102% at December 31, 2020.

[0001628280-22-002664:mdna:139]
As of December 31, 2021, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody’s Investors Service, Inc. (“Moody’s”) and Standard & Poor’s Rating Group (“S&P”), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody’s and S&P to help ensure the capital markets remain available to us.

[0001628280-22-002664:mdna:140]
Liquidity

[0001628280-22-002664:mdna:141]
We believe our cash and cash equivalents of $31 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents as of December 31, 2021 was $14 million of cash held in foreign locations, although that amount can fluctuate significantly depending on the timing of cash receipts and payments.  Our cash and cash equivalents held in foreign locations is generally available for use in our U.S. operations and could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-22-002664:mdna:142]
No contributions are required to be made to our U.S. defined benefit plans in 2022. We made $2 million in total contributions to pension plans in 2021.

[0001628280-22-002664:mdna:143]
Dividend payments were $127 million in 2021 compared to $118 million in 2020. On May 19, 2021, our Board of Directors approved a 19% increase in our quarterly dividend on common stock from $0.77 to $0.92 per share effective with the July 2021 dividend payment.

[0001628280-22-002664:mdna:144]
We also continued to increase shareholder value through our Share Repurchase Plans.  We returned $600 million to our investors through share repurchases in 2021.  Our Board of Directors authorized an incremental $1.0 billion of share repurchases in July 2021, and we had $846 million of repurchases available under the Share Repurchase Plans at December 31, 2021. We expect to repurchase $400 million of shares in 2022.

[0001628280-22-002664:mdna:145]
We expect capital expenditures of approximately $125 million in 2022.

[0001628280-22-002664:mdna:146]
Financial Covenants related to our Debt

[0001628280-22-002664:mdna:147]
Our domestic credit facility is guaranteed by certain of our subsidiaries and contains a financial covenant relating to leverage.  Other covenants contained in the domestic credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenant requires us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio of no greater than 3.5 : 1.0.

[0001628280-22-002664:mdna:148]
Our domestic credit facility contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001628280-22-002664:mdna:149]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-22-002664:mdna:150]
•We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-22-002664:mdna:151]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our domestic credit facility, our senior unsecured notes, or our ASP were to

[0001628280-22-002664:mdna:152]
occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-22-002664:mdna:153]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our domestic credit facility and accelerate amounts due under our domestic credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001628280-22-002664:mdna:154]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee payment by us of any indebtedness under our domestic credit facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001628280-22-002664:mdna:155]
As of December 31, 2021, we believe we were in compliance with all covenant requirements. Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared and/or the preceding fiscal year.  In addition, stock repurchases can only be made out of surplus and only if our capital would not be impaired.

[0001628280-22-002664:mdna:156]
Leasing Commitments

[0001628280-22-002664:mdna:157]
Refer to Note 5 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001628280-22-002664:mdna:158]
Guarantees related to our Debt Obligations

[0001628280-22-002664:mdna:159]
Our senior unsecured notes were issued by Lennox International Inc. (the “Parent”) and are unconditionally guaranteed by certain of our subsidiaries (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries.  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001628280-22-002664:mdna:160]
In connection with the Credit Agreement, we entered into in July 2021, Heatcraft Technologies Inc., Lennox National Account Services Inc., Lennox Procurement Company Inc. and Lennox Services LLC became additional guarantors of our debt obligations, guaranteeing the payment when due of all monetary obligations under the Credit Agreement and the Notes.  In addition, Lennox Switzerland GmbH was released as a guarantor of all monetary obligations under the Credit Agreement and the Notes.  These changes did not result in a material change to the Parent and Guarantor Subsidiaries financial information.

[0001628280-22-002664:mdna:161]
Off Balance Sheet Arrangements

[0001628280-22-002664:mdna:162]
We have no off-balance sheet arrangements that we believe may have a material current or future effect on our financial condition, liquidity or results of operations.

[0001628280-22-002664:mdna:163]
Contractual Obligations

[0001628280-22-002664:mdna:164]
Contractual obligations arise in the normal course of business and include debt and related interest payments, leases, purchase obligations, pension and post-retirement benefits and warranty liabilities.  For additional information regarding our contractual obligations, see Note 5 of the Notes to the Consolidated Financial Statements.  See Note 11 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.  See Note 14 of the Notes to the Consolidated Financial Statements for more information on our debt obligations.

[0001628280-22-002664:mdna:165]
Fair Value Measurements

[0001628280-22-002664:mdna:166]
Fair value is the price that would be received to sell an asset or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001628280-22-002664:mdna:167]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001628280-22-002664:mdna:168]
Level 1 -          Quoted prices for identical instruments in active markets at the measurement date.

[0001628280-22-002664:mdna:169]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001628280-22-002664:mdna:170]
Level 3 -     Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001628280-22-002664:mdna:171]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2021 and 2020, the measurement dates.  See Note 17 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001628280-22-002664:mdna:172]
Market Risk

[0001628280-22-002664:mdna:173]
Commodity Price Risk

[0001628280-22-002664:mdna:174]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001628280-22-002664:mdna:175]
| Notional amount (pounds of aluminum and copper) | 62.4 |  |
| Carrying amount and fair value of net asset | $ | 13.3 |  |
| Change in fair value from 10% change in forward prices | $ | 14.2 |  |

[0001628280-22-002664:mdna:176]
Refer to Note 10 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001628280-22-002664:mdna:177]
Interest Rate Risk

[0001628280-22-002664:mdna:178]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $0.4 million, $1.3 million and $3.9 million for the years ended December 31, 2021, 2020 and 2019, respectively.

[0001628280-22-002664:mdna:179]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2021 and 2020, no interest rate swaps were in effect.

[0001628280-22-002664:mdna:180]
Foreign Currency Exchange Rate Risk

[0001628280-22-002664:mdna:181]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  During 2021, 2020 and 2019, net sales from outside the U.S. represented 13.1%, 13.0% and 13.2%, respectively, of our total net sales.  For the years ended December 31, 2021,  2020, and 2019, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $2.7 million, $0.6 million and $4.2 million impact to net income for the years ended December 31, 2021, 2020 and 2019, respectively.

[0001628280-22-002664:mdna:182]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 10 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001628280-22-002664:mdna:183]
Critical Accounting Estimates

[0001628280-22-002664:mdna:184]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following describes our critical accounting estimate related to product warranties and product-related contingencies and how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements. This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001628280-22-002664:mdna:185]
Product Warranties and Product-Related Contingencies

[0001628280-22-002664:mdna:186]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.

[0001628280-22-002664:mdna:187]
From time to time, we may also incur costs to repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.  These product-related costs may not be covered under our warranties and are not covered by insurance.

[0001628280-22-002664:mdna:188]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 5 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001628280-22-002664:mdna:189]
Recent Accounting Pronouncements

[0001628280-22-002664:mdna:190]
See Note 2 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
