# LII 8-K — 0001193125-22-024009 filed 2022-02-01

## item codes, every 8-K on or before 2022-02-15

- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2022-02-15

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-024009:8k_2_02:1]
EX-99.1
2
d93654dex991.htm
EX-99.1

[0001193125-22-024009:8k_2_02:2]
EX-99.1

[0001193125-22-024009:8k_2_02:3]
Exhibit 99.1

[0001193125-22-024009:8k_2_02:4]
Lennox International Reports Record Revenue and EPS for 2021

[0001193125-22-024009:8k_2_02:5]
|  | • |  | Fourth-quarter revenue up 6% to fourth-quarter record $965 million |

[0001193125-22-024009:8k_2_02:6]
|  | • |  | Fourth-quarter GAAP EPS from continuing operations of $2.27, compared to $2.91 in the prior-year quarter; adjusted EPS from continuing operations of $2.35, compared to $2.89 in the prior-year quarter |

[0001193125-22-024009:8k_2_02:7]
|  | • |  | Full year 2021 revenue up 15% to record $4.2 billion, GAAP EPS from continuing operations up 34% to record $12.39, and adjusted EPS from continuing operations up 27% to record $12.60 |

[0001193125-22-024009:8k_2_02:8]
|  | • |  | Fourth quarter impacted by 6% fewer days than prior-year quarter, Covid-19 and global supply chain disruptions |

[0001193125-22-024009:8k_2_02:9]
|  | • |  | Tax timing and one-time benefits lowered the effective tax rate to 7% for the fourth quarter and 17% for the full year on a GAAP basis, and to 8% and 18% respectively on an adjusted basis |

[0001193125-22-024009:8k_2_02:10]
|  | • |  | Repurchased $600 million of stock and paid $127 million in dividends in 2021 |

[0001193125-22-024009:8k_2_02:11]
|  | • |  | Reiterating 2022 guidance for revenue growth of 5-10% |

[0001193125-22-024009:8k_2_02:12]
|  | • |  | Raising 2022 guidance for GAAP and adjusted EPS from continuing operations from $13.40-$14.40 to $13.50-$14.50, reflecting the net benefit of lower effective tax rate guidance of 18-20% and higher interest expense assumptions |

[0001193125-22-024009:8k_2_02:13]
DALLAS, February 1, 2022 – Lennox International Inc. (NYSE: LII), a global leader in energy-efficient
climate-control solutions, today reported fourth-quarter and full-year 2021 results. All comparisons are to the prior-year period.

[0001193125-22-024009:8k_2_02:14]
For the fourth quarter
of 2021, revenue was a fourth-quarter record $965 million, up 6%. Foreign exchange was neutral to revenue. GAAP operating income was $98 million compared to $139 million in the prior-year quarter. Fourth-quarter GAAP earnings per
share from continuing operations was $2.27 compared to $2.91 in the prior-year quarter.

[0001193125-22-024009:8k_2_02:15]
Total segment profit in the fourth quarter was $102 million
compared to $139 million in the prior-year quarter, and total segment margin was 10.6% compared to 15.2% in the prior-year quarter. Adjusted earnings per share from continuing operations was $2.35 compared to $2.89 in the prior-year quarter.

[0001193125-22-024009:8k_2_02:16]
For the full year, revenue was up 15% to a record $4.19 billion. Foreign exchange had a 1% benefit to revenue growth. GAAP operating income rose 23%
to $590 million. GAAP earnings per share from continuing operations rose 34% to a record $12.39.

[0001193125-22-024009:8k_2_02:17]
Total segment profit for the full year rose 19% to
$604 million, and total segment margin expanded 50 basis points to 14.4%. Adjusted earnings per share from continuing operations rose 27% to a record $12.60.

[0001193125-22-024009:8k_2_02:18]
“Covid-19 and global supply chain disruptions continued to have
a significant impact on operations in the fourth quarter as expected, and reported financial results were also impacted from having 6% fewer days than in the prior-year quarter,” said Chairman and CEO Todd Bluedorn. “In the face of these
challenges, the team performed extremely well.

[0001193125-22-024009:8k_2_02:19]
“In Residential, revenue was up 12% on double-digit growth in both replacement and new construction
business. Segment profit was down 5%, and segment margin was down 310 basis points to 17.8%. The Commercial business continued to be hit the hardest by Covid-19 and global supply chain disruptions in the
fourth quarter. Commercial revenue was down 11%, segment profit was down 64%, and segment margin contracted 1170 basis points to 7.7%. Market demand remains strong, and we expect Commercial revenue to resume growth in the first quarter and
profitability to be up by mid-2022 and for the full year. In Refrigeration, revenue was up 6% as reported and up 8% at constant currency, led by more than 20% growth in North America. Segment profit rose 29%,
and segment margin expanded 170 basis points to 9.2%.

[0001193125-22-024009:8k_2_02:20]
“For the year overall, Lennox International posted record revenue and EPS. Revenue was up 15%,
and adjusted EPS from continuing operations was up 27%. For 2022, we are reiterating guidance for revenue growth of 5-10% and raising guidance for EPS to $13.50-$14.50,
reflecting the net benefit of a lower effective tax rate and higher interest expense. We are reiterating plans for $400 million of stock repurchases for the year.”

[0001193125-22-024009:8k_2_02:21]
FOURTH QUARTER 2021 FINANCIAL HIGHLIGHTS

[0001193125-22-024009:8k_2_02:22]
Revenue:
Revenue for the fourth quarter was $965 million, up 6%. Foreign exchange was neutral to revenue. Volume was down, price was up, and mix was favorable.

[0001193125-22-024009:8k_2_02:23]
Gross Profit: For the fourth quarter, gross profit was $254 million compared to $275 million in the prior-year quarter. Gross margin was
26.3% compared to 30.1% in the prior-year quarter. Gross profit was primarily impacted by 6% fewer days than the prior-year quarter, the Covid-19 pandemic, global supply chain disruptions, lower volume, and
higher material, freight, and other product costs. Partial offsets included favorable price and mix, distribution efficiency initiatives, and favorable foreign exchange.

[0001193125-22-024009:8k_2_02:24]
Income from Continuing Operations: On a GAAP basis, fourth quarter income from continuing operations was $83.5 million, or $2.27 diluted earnings
per share, compared to $112.2 million, or $2.91 diluted earnings per share, in the prior-year quarter.

[0001193125-22-024009:8k_2_02:25]
On an adjusted basis, fourth quarter income
from continuing operations was $86.7 million, or $2.35 diluted earnings per share, compared to $111.4 million, or $2.89 diluted earnings per share, in the prior-year quarter. Adjusted income from continuing operations for the fourth
quarter of 2021 excludes net after-tax charges of $3.2 million.

[0001193125-22-024009:8k_2_02:26]
FULL YEAR 2021 FINANCIAL HIGHLIGHTS

[0001193125-22-024009:8k_2_02:27]
Revenue: For the full year, revenue was $4.19 billion, up 15%. Foreign exchange was 1% favorable to revenue growth. Volume was up, and price and
mix were both favorable.

[0001193125-22-024009:8k_2_02:28]
Gross Profit: Gross profit for the full year was $1.19 billion, up 14%. Gross margin was 28.3%, down 30 basis
points. Gross profit benefitted from higher volume, favorable price and mix, and favorable foreign exchange. Partial offsets included the impact from the Covid-19 pandemic, global supply chain disruptions, and
higher material, warranty, tariffs, freight, distribution, and other product costs.

[0001193125-22-024009:8k_2_02:29]
Income from Continuing Operations: On a GAAP basis, income
from continuing operations for 2021 was $464.0 million, or $12.39 diluted earnings per share, compared to $357.1 million, or $9.26 diluted earnings per share, in the prior year.

[0001193125-22-024009:8k_2_02:30]
On an adjusted basis, income from continuing operations for 2021 was $471.4 million, or $12.60 diluted earnings per share, compared to
$383.1 million, or $9.94 diluted earnings per share, in the prior year. Adjusted income from continuing operations for 2021 excludes net after-tax charges of $7.4 million.

[0001193125-22-024009:8k_2_02:31]
Free Cash Flow and Total Debt: For the full year, cash from operations was $516 million compared to $612 million in the prior year. Capital
expenditures were approximately $106 million compared to approximately $77 million in the prior year. Free cash flow was $410 million for the full year compared to $535 million in the prior year. In 2021, the company paid
approximately $127 million in dividends and repurchased $600 million of company stock. Ending the year, total debt was $1.24 billion, and the company’s
debt-to-EBITDA ratio stood at 1.8. Total cash and cash equivalents were $31 million at the end of the year.

[0001193125-22-024009:8k_2_02:32]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001193125-22-024009:8k_2_02:33]
Residential Heating and Cooling

[0001193125-22-024009:8k_2_02:34]
|  | • |  | 4Q21 revenue a fourth-quarter record $620 million, up 12%; neutral foreign exchange |

[0001193125-22-024009:8k_2_02:35]
|  | • |  | 4Q21 segment profit of $110 million, down 5% |

[0001193125-22-024009:8k_2_02:36]
|  | • |  | 4Q21 segment margin of 17.8%, down 310 basis points |

[0001193125-22-024009:8k_2_02:37]
|  | • |  | 2021 revenue a record $2.78 billion, up 18%; up 17% at constant currency |

[0001193125-22-024009:8k_2_02:38]
|  | • |  | 2021 segment profit a record $540 million, up 26% |

[0001193125-22-024009:8k_2_02:39]
|  | • |  | 2021 segment margin of 19.5%, up 140 basis points |

[0001193125-22-024009:8k_2_02:40]
Fourth-quarter results were negatively impacted by 6% fewer days than the prior-year quarter, the Covid-19 pandemic,
global supply chain disruptions, higher material, freight and other product costs, and higher SG&A. Positive impacts included higher volume, favorable price, mix, foreign exchange and warranty, and distribution efficiency programs.

[0001193125-22-024009:8k_2_02:41]
Full-year results were positively impacted by higher volume and factory productivity, favorable price, sourcing and
engineering-led cost reductions, and favorable foreign exchange. Partial offsets included the Covid-19 pandemic, global supply chain disruptions, unfavorable mix, higher
commodity, tariff, warranty, freight, distribution, and other product costs, and higher SG&A including R&D and IT investments.

[0001193125-22-024009:8k_2_02:42]
Commercial
Heating and Cooling

[0001193125-22-024009:8k_2_02:43]
|  | • |  | 4Q21 revenue of $201 million, down 11%; neutral foreign exchange |

[0001193125-22-024009:8k_2_02:44]
|  | • |  | 4Q21 segment profit of $16 million, down 64% |

[0001193125-22-024009:8k_2_02:45]
|  | • |  | 4Q21 segment margin 7.7%, down 1170 basis points |

[0001193125-22-024009:8k_2_02:46]
|  | • |  | 2021 revenue of $865 million, up 8%; up 7% at constant currency |

[0001193125-22-024009:8k_2_02:47]
|  | • |  | 2021 segment profit of $111 million, down 19% |

[0001193125-22-024009:8k_2_02:48]
|  | • |  | 2021 segment margin of 12.8%, down 430 basis points |

[0001193125-22-024009:8k_2_02:49]
Fourth-quarter results were negatively impacted by 6% fewer days than the prior-year quarter, the Covid-19 pandemic,
global supply chain disruptions, lower volume, higher material, warranty, tariff, freight and other product costs, and higher SG&A. Partial offsets included favorable price and mix.

[0001193125-22-024009:8k_2_02:50]
Full-year results were negatively impacted by the Covid-19 pandemic, global supply chain disruptions, higher material,
tariff, freight, distribution and other product costs, higher SG&A, and unfavorable foreign exchange. Partial offsets included higher volume and favorable price and mix.

[0001193125-22-024009:8k_2_02:51]
Refrigeration

[0001193125-22-024009:8k_2_02:52]
|  | • |  | 4Q21 revenue a fourth-quarter record $143 million, up 6%; up 8% at constant currency |

[0001193125-22-024009:8k_2_02:53]
|  | • |  | 4Q21 segment profit of $13 million, up 29% |

[0001193125-22-024009:8k_2_02:54]
|  | • |  | 4Q21 segment margin of 9.2%, up 170 basis points |

[0001193125-22-024009:8k_2_02:55]
|  | • |  | 2021 revenue of $554 million, up 17%; up 16% at constant currency |

[0001193125-22-024009:8k_2_02:56]
|  | • |  | 2021 segment profit of $49 million, up 50% |

[0001193125-22-024009:8k_2_02:57]
|  | • |  | 2021 segment margin of 8.9%, up 190 basis points |

[0001193125-22-024009:8k_2_02:58]
Fourth-quarter results were positively impacted by higher volume, favorable price and mix, and lower SG&A. Partial offsets included 6% fewer days than the
prior-year quarter, the Covid-19 pandemic, global supply chain disruptions, and higher material, freight and other product costs.

[0001193125-22-024009:8k_2_02:59]
Full-year results were positively impacted by higher volume and factory productivity, favorable price, and joint-venture equity-method income. Partial offsets
included the Covid-19 pandemic, global supply chain disruptions, higher material, tariff, freight and other product costs, and higher SG&A.

[0001193125-22-024009:8k_2_02:60]
2022 FULL-YEAR OUTLOOK

[0001193125-22-024009:8k_2_02:61]
|  | • |  | Reiterating guidance for revenue growth of 5-10% |

[0001193125-22-024009:8k_2_02:62]
|  | • |  | Raising guidance for GAAP and adjusted EPS from continuing operations from $13.40-$14.40 to $13.50-$14.50 |

[0001193125-22-024009:8k_2_02:63]
|  | • |  | Reiterating guidance for corporate expenses of approximately $95 million |

[0001193125-22-024009:8k_2_02:64]
|  | • |  | Updating effective tax rate guidance from approximately 20% to a range of 18-20% on an adjusted basis for the full year |

[0001193125-22-024009:8k_2_02:65]
|  | • |  | Raising guidance for interest expense and other from approximately $35 million to $40 million |

[0001193125-22-024009:8k_2_02:66]
|  | • |  | Reiterating guidance for capital expenditures of approximately $125 million |

[0001193125-22-024009:8k_2_02:67]
|  | • |  | Reiterating guidance for stock repurchases of $400 million |

[0001193125-22-024009:8k_2_02:68]
CONFERENCE CALL INFORMATION

[0001193125-22-024009:8k_2_02:69]
A conference call to discuss
the company’s fourth-quarter and full-year 2021 results and 2022 outlook will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at
844-291-6362 (U.S.) or 234-720-6995 (international) at least 10 minutes prior to the
scheduled start time and use participant code 7814058. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from approximately 11:00 a.m. Central time on
February 1 through February 15, 2022 by dialing 866-207-1041 (U.S.) or
402-970-0847 (international) and using access code 1725607. The call also will be archived on the company’s website.

[0001193125-22-024009:8k_2_02:70]
ABOUT LENNOX INTERNATIONAL

[0001193125-22-024009:8k_2_02:71]
Lennox International Inc. is a global leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier
environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our air conditioning, heating, indoor air quality, and refrigeration systems. Lennox International stock is listed
on the New York Stock Exchange and traded under the symbol “LII”. Additional information on Lennox International is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-22-024009:8k_2_02:72]
FORWARD-LOOKING STATEMENTS

[0001193125-22-024009:8k_2_02:73]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-024009:8k_2_02:74]
Consolidated Statements of Operations

[0001193125-22-024009:8k_2_02:75]
| (Amounts in millions, except per share data) |  | For the Three Months EndedDecember 31,(Unaudited) |  |  | For the Years EndedDecember 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net sales |  | $ | 964.8 |  |  | $ | 914.0 |  |  | $ | 4,194.1 |  |  | $ | 3,634.1 |  |
| Cost of goods sold |  |  | 711.2 |  |  |  | 638.7 |  |  |  | 3,005.7 |  |  |  | 2,594.0 |  |
| Gross profit |  |  | 253.6 |  |  |  | 275.3 |  |  |  | 1,188.4 |  |  |  | 1,040.1 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 151.5 |  |  |  | 143.3 |  |  |  | 598.9 |  |  |  | 555.9 |  |
| Losses (gains) and other expenses, net |  |  | 4.5 |  |  |  | 1.7 |  |  |  | 9.2 |  |  |  | 7.4 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 1.8 |  |  |  | 10.8 |  |
| (Gain) loss from natural disasters, net of insurance recoveries |  |  | — |  |  |  | (4.5 | ) |  |  | — |  |  |  | 3.1 |  |
| Income from equity method investments |  |  | (0.2 | ) |  |  | (4.4 | ) |  |  | (11.8 | ) |  |  | (15.6 | ) |
| Operating income |  |  | 97.6 |  |  |  | 139.0 |  |  |  | 590.3 |  |  |  | 478.5 |  |
| Pension settlements |  |  | 0.1 |  |  |  | 0.3 |  |  |  | 1.2 |  |  |  | 0.6 |  |
| Interest expense, net |  |  | 6.2 |  |  |  | 6.3 |  |  |  | 25.0 |  |  |  | 28.3 |  |
| Other expense (income), net |  |  | 1.1 |  |  |  | 1.0 |  |  |  | 4.0 |  |  |  | 4.4 |  |
| Income from continuing operations before income taxes |  |  | 90.2 |  |  |  | 131.4 |  |  |  | 560.1 |  |  |  | 445.2 |  |
| Provision for income taxes |  |  | 6.7 |  |  |  | 19.2 |  |  |  | 96.1 |  |  |  | 88.1 |  |
| Income from continuing operations |  |  | 83.5 |  |  |  | 112.2 |  |  |  | 464.0 |  |  |  | 357.1 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from discontinued operations before income |  |  | 0.2 |  |  |  | (0.6 | ) |  |  | — |  |  |  | (1.5 | ) |
| Income tax expense (benefit) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | — |  |  |  | (0.7 | ) |
| Income (loss) from discontinued operations |  |  | 0.1 |  |  |  | (0.5 | ) |  |  | — |  |  |  | (0.8 | ) |
| Net income |  | $ | 83.6 |  |  | $ | 111.7 |  |  | $ | 464.0 |  |  | $ | 356.3 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.28 |  |  | $ | 2.93 |  |  | $ | 12.47 |  |  | $ | 9.32 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.01 | ) |  |  | — |  |  |  | (0.02 | ) |
| Net income |  | $ | 2.28 |  |  | $ | 2.92 |  |  | $ | 12.47 |  |  | $ | 9.30 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2.27 |  |  | $ | 2.91 |  |  | $ | 12.39 |  |  | $ | 9.26 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.02 | ) |  |  | — |  |  |  | (0.02 | ) |
| Net income |  | $ | 2.27 |  |  | $ | 2.89 |  |  | $ | 12.39 |  |  | $ | 9.24 |  |
| Weighted Average Number of Shares Outstanding—Basic |  |  | 36.6 |  |  |  | 38.3 |  |  |  | 37.2 |  |  |  | 38.3 |  |
| Weighted Average Number of Shares Outstanding—Diluted |  |  | 36.8 |  |  |  | 38.6 |  |  |  | 37.5 |  |  |  | 38.6 |  |

[0001193125-22-024009:8k_2_02:76]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-024009:8k_2_02:77]
Segment Net Sales and Profit (Loss)

[0001193125-22-024009:8k_2_02:78]
| (Amounts in millions) |  | For the Three MonthsEnded December 31,(Unaudited) |  |  | For the Years EndedDecember 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 620.3 |  |  | $ | 552.7 |  |  | $ | 2,775.6 |  |  | $ | 2,361.5 |  |
| Commercial Heating & Cooling |  |  | 201.4 |  |  |  | 226.2 |  |  |  | 864.8 |  |  |  | 800.9 |  |
| Refrigeration |  |  | 143.1 |  |  |  | 135.1 |  |  |  | 553.7 |  |  |  | 471.7 |  |
|  |  | $ | 964.8 |  |  | $ | 914.0 |  |  | $ | 4,194.1 |  |  | $ | 3,634.1 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 110.3 |  |  | $ | 115.6 |  |  | $ | 540.3 |  |  | $ | 428.5 |  |
| Commercial Heating & Cooling |  |  | 15.6 |  |  |  | 43.8 |  |  |  | 110.9 |  |  |  | 136.9 |  |
| Refrigeration |  |  | 13.2 |  |  |  | 10.2 |  |  |  | 49.1 |  |  |  | 32.8 |  |
| Corporate and other |  |  | (37.2 | ) |  |  | (30.3 | ) |  |  | (96.4 | ) |  |  | (91.5 | ) |
| Total segment profit |  |  | 101.9 |  |  |  | 139.3 |  |  |  | 603.9 |  |  |  | 506.7 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (1.4 | ) |  |  | 2.0 |  |  |  | (2.5 | ) |  |  | 1.0 |  |
| (Gain) loss from natural disasters, net of insurance recoveries |  |  | — |  |  |  | (4.5 | ) |  |  | — |  |  |  | 3.1 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) |  |  | 5.5 |  |  |  | 2.6 |  |  |  | 14.3 |  |  |  | 13.3 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 1.8 |  |  |  | 10.8 |  |
| Operating income |  | $ | 97.6 |  |  | $ | 139.0 |  |  | $ | 590.3 |  |  | $ | 478.5 |  |

[0001193125-22-024009:8k_2_02:79]
| (1) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-22-024009:8k_2_02:80]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-22-024009:8k_2_02:81]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-22-024009:8k_2_02:82]
|  | • |  | Special legal contingency charges, |

[0001193125-22-024009:8k_2_02:83]
|  | • |  | Asbestos-related litigation, |

[0001193125-22-024009:8k_2_02:84]
|  | • |  | Environmental liabilities, |

[0001193125-22-024009:8k_2_02:85]
|  | • |  | Charges incurred related to COVID-19 pandemic; and |

[0001193125-22-024009:8k_2_02:86]
|  | • |  | Other items, net, |

[0001193125-22-024009:8k_2_02:87]
|  | • |  | Special product quality adjustments |

[0001193125-22-024009:8k_2_02:88]
|  | • |  | (Gain) loss from natural disasters, net of insurance recoveries; and |

[0001193125-22-024009:8k_2_02:89]
|  | • |  | Restructuring charges. |

[0001193125-22-024009:8k_2_02:90]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-024009:8k_2_02:91]
Consolidated Balance Sheets

[0001193125-22-024009:8k_2_02:92]
| (Amounts in millions, except shares and par values) |  | As of December 31,2021 |  |  | As of December 31,2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 31.0 |  |  | $ | 123.9 |  |
| Short-term investments |  |  | 5.5 |  |  |  | 5.1 |  |
| Accounts and notes receivable, net of allowances of $10.7 and $9.6 in 2021 and 2020, respectively |  |  | 508.3 |  |  |  | 448.3 |  |
| Inventories, net |  |  | 510.9 |  |  |  | 439.4 |  |
| Other assets |  |  | 119.7 |  |  |  | 70.9 |  |
| Total current assets |  |  | 1,175.4 |  |  |  | 1,087.6 |  |
| Property, plant and equipment, net of accumulated depreciation of $888.8 and $880.6 in 2021 and 2020, respectively |  |  | 515.1 |  |  |  | 464.3 |  |
| Right-of-use assets from operating leases |  |  | 196.1 |  |  |  | 194.4 |  |
| Goodwill |  |  | 186.6 |  |  |  | 186.9 |  |
| Deferred income taxes |  |  | 11.3 |  |  |  | 13.2 |  |
| Other assets, net |  |  | 87.4 |  |  |  | 86.1 |  |
| Total assets |  | $ | 2,171.9 |  |  | $ | 2,032.5 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 11.3 |  |  | $ | 9.9 |  |
| Current operating lease liabilities |  |  | 54.8 |  |  |  | 55.0 |  |
| Accounts payable |  |  | 402.1 |  |  |  | 340.3 |  |
| Accrued expenses |  |  | 358.9 |  |  |  | 296.1 |  |
| Total current liabilities |  |  | 827.1 |  |  |  | 701.3 |  |
| Long-term debt |  |  | 1,226.5 |  |  |  | 970.7 |  |
| Long-term operating lease liabilities |  |  | 145.0 |  |  |  | 142.8 |  |
| Pensions |  |  | 83.3 |  |  |  | 92.5 |  |
| Other liabilities |  |  | 159.0 |  |  |  | 142.3 |  |
| Total liabilities |  |  | 2,440.9 |  |  |  | 2,049.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ deficit: |  |  |  |  |  |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,133.7 |  |  |  | 1,113.2 |  |
| Retained earnings |  |  | 2,719.3 |  |  |  | 2,385.8 |  |
| Accumulated other comprehensive loss |  |  | (88.1 | ) |  |  | (97.2 | ) |
| Treasury stock, at cost, 50,536,125 shares and 48,820,969 shares for 2021 and 2020, respectively |  |  | (4,034.8 | ) |  |  | (3,419.8 | ) |
| Total stockholders’ deficit |  |  | (269.0 | ) |  |  | (17.1 | ) |
| Total liabilities and stockholders’ deficit |  | $ | 2,171.9 |  |  | $ | 2,032.5 |  |

[0001193125-22-024009:8k_2_02:93]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-024009:8k_2_02:94]
Consolidated Statements of Cash Flows

[0001193125-22-024009:8k_2_02:95]
| (Amounts in millions) |  | For the Years EndedDecember 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 464.0 |  |  | $ | 356.3 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (11.8 | ) |  |  | (15.6 | ) |
| Dividends from affiliates |  |  | 9.1 |  |  |  | 12.3 |  |
| Restructuring charges, net of cash paid |  |  | 1.1 |  |  |  | 3.4 |  |
| Provision for credit losses |  |  | 4.9 |  |  |  | 8.1 |  |
| Unrealized (gains) losses on derivative contracts |  |  | (0.6 | ) |  |  | 0.3 |  |
| Stock-based compensation expense |  |  | 24.3 |  |  |  | 24.3 |  |
| Depreciation and amortization |  |  | 72.4 |  |  |  | 72.6 |  |
| Deferred income taxes |  |  | (5.4 | ) |  |  | 7.2 |  |
| Pension expense |  |  | 11.3 |  |  |  | 10.5 |  |
| Pension contributions |  |  | (1.5 | ) |  |  | (3.3 | ) |
| Other items, net |  |  | 0.3 |  |  |  | 0.2 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (68.8 | ) |  |  | 26.5 |  |
| Inventories |  |  | (71.0 | ) |  |  | 110.3 |  |
| Other current assets |  |  | (19.2 | ) |  |  | 5.3 |  |
| Accounts payable |  |  | 55.2 |  |  |  | (31.7 | ) |
| Accrued expenses |  |  | 64.2 |  |  |  | 35.4 |  |
| Income taxes payable and receivable, net |  |  | (26.5 | ) |  |  | (5.7 | ) |
| Leases, net |  |  | 0.2 |  |  |  | 2.1 |  |
| Other, net |  |  | 13.3 |  |  |  | (6.1 | ) |
| Net cash provided by operating activities |  |  | 515.5 |  |  |  | 612.4 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.9 |  |  |  | 1.0 |  |
| Purchases of property, plant and equipment |  |  | (106.8 | ) |  |  | (78.5 | ) |
| Proceeds from (purchases of) short-term investments, net |  |  | (0.5 | ) |  |  | (2.2 | ) |
| Net cash (used in) provided by investing activities |  |  | (106.4 | ) |  |  | (79.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term debt payments |  |  | — |  |  |  | (4.6 | ) |
| Short-term debt borrowings |  |  | — |  |  |  | 4.6 |  |
| Asset securitization borrowings |  |  | 627.0 |  |  |  | 91.0 |  |
| Asset securitization payments |  |  | (377.0 | ) |  |  | (376.0 | ) |
| Long-term debt borrowings |  |  | — |  |  |  | 600.0 |  |
| Long-term debt payments |  |  | (12.3 | ) |  |  | (10.8 | ) |
| Borrowings from credit facility |  |  | 1,162.5 |  |  |  | 1,576.0 |  |
| Payments on credit facility |  |  | (1,156.0 | ) |  |  | (2,081.5 | ) |
| Payments of deferred financing costs |  |  | 2.4 |  |  |  | (7.5 | ) |
| Proceeds from employee stock purchases |  |  | 3.3 |  |  |  | 3.0 |  |
| Repurchases of common stock |  |  | (600.0 | ) |  |  | (100.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (22.1 | ) |  |  | (17.9 | ) |
| Cash dividends paid |  |  | (126.5 | ) |  |  | (118.1 | ) |
| Net cash used in financing activities |  |  | (498.7 | ) |  |  | (441.8 | ) |
| (Decrease) increase in cash and cash equivalents |  |  | (89.6 | ) |  |  | 90.9 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (3.3 | ) |  |  | (4.3 | ) |
| Cash and cash equivalents, beginning of period |  |  | 123.9 |  |  |  | 37.3 |  |
| Cash and cash equivalents, end of period |  | $ | 31.0 |  |  | $ | 123.9 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 23.8 |  |  | $ | 25.3 |  |
| Income taxes paid (net of refunds) |  | $ | 128.5 |  |  | $ | 90.3 |  |

[0001193125-22-024009:8k_2_02:96]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-024009:8k_2_02:97]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-22-024009:8k_2_02:98]
(Unaudited, in millions, except per share and ratio data)

[0001193125-22-024009:8k_2_02:99]
Use of Non-GAAP Financial Measures

[0001193125-22-024009:8k_2_02:100]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance.

[0001193125-22-024009:8k_2_02:101]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted
Income from Continuing Operations, a Non-GAAP measure

[0001193125-22-024009:8k_2_02:102]
|  |  | For the Three Months Ended December 31, (Unaudited) |  |
|  |  | 2021 |  |  | 2020 |  |
|  |  | Pre-Tax |  |  | TaxImpact (d) |  |  | After Tax |  |  | Pre-Tax |  |  | TaxImpact (d) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 90.2 |  |  | $ | (6.7 | ) |  | $ | 83.5 |  |  | $ | 131.4 |  |  | $ | (19.2 | ) |  | $ | 112.2 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Pension settlements |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | — |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |
| Special product quality adjustments (b) |  |  | (1.4 | ) |  |  | 0.4 |  |  |  | (1.0 | ) |  |  | 2.0 |  |  |  | (0.5 | ) |  |  | 1.5 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  | 5.5 |  |  |  | (2.2 | ) |  |  | 3.3 |  |  |  | 2.6 |  |  |  | (0.8 | ) |  |  | 1.8 |  |
| Excess tax expense (benefits) from share-based compensation (c) |  |  | — |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | — |  |  |  | (1.5 | ) |  |  | (1.5 | ) |
| Other tax items, net (c) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.4 |  |  |  | 0.4 |  |
| Gain from natural disasters, net of insurance recoveries (e) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (4.5 | ) |  |  | 1.1 |  |  |  | (3.4 | ) |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 94.6 |  |  | $ | (7.9 | ) |  | $ | 86.7 |  |  | $ | 132.0 |  |  | $ | (20.6 | ) |  | $ | 111.4 |  |
| Earnings per share from continuing operations—diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.27 |  |  |  |  |  |  |  |  |  |  | $ | 2.91 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  |  |  |  |  |  |  |  |  | 0.09 |  |  |  |  |  |  |  |  |  |  |  | 0.05 |  |
| Excess tax expense (benefits) from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | (0.04 | ) |
| Other tax items, net (c) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Gain from natural disasters, net of insurance recoveries (e) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.10 | ) |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.35 |  |  |  |  |  |  |  |  |  |  | $ | 2.89 |  |

[0001193125-22-024009:8k_2_02:103]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-22-024009:8k_2_02:104]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-22-024009:8k_2_02:105]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-22-024009:8k_2_02:106]
| (d) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-22-024009:8k_2_02:107]
| (e) | Recorded in (Gain) loss from natural disasters, net of insurance recoveries in the Consolidated Statement of Operations. |

[0001193125-22-024009:8k_2_02:108]
|  |  | For the Years Ended December 31, (Unaudited) |  |
|  |  | 2021 |  |  | 2020 |  |
|  |  | Pre-Tax |  |  | Tax Impact(d) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact(d) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 560.1 |  |  | $ | (96.1 | ) |  | $ | 464.0 |  |  | $ | 445.2 |  |  | $ | (88.1 | ) |  | $ | 357.1 |  |
| Restructuring charges |  |  | 1.8 |  |  |  | (0.4 | ) |  |  | 1.4 |  |  |  | 10.8 |  |  |  | (2.4 | ) |  |  | 8.4 |  |
| Pension settlements |  |  | 1.2 |  |  |  | (0.3 | ) |  |  | 0.9 |  |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | 0.4 |  |
| Special product quality adjustments (b) |  |  | (2.5 | ) |  |  | 0.7 |  |  |  | (1.8 | ) |  |  | 1.0 |  |  |  | (0.2 | ) |  |  | 0.8 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  | 14.3 |  |  |  | (3.8 | ) |  |  | 10.5 |  |  |  | 13.3 |  |  |  | (3.5 | ) |  |  | 9.8 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (5.7 | ) |  |  | (5.7 | ) |  |  |  |  |  |  | (4.2 | ) |  |  | (4.2 | ) |
| Other tax items, net (c) |  |  | — |  |  |  | 2.1 |  |  |  | 2.1 |  |  |  | — |  |  |  | 8.5 |  |  |  | 8.5 |  |
| Loss from natural disasters, net of insurance recoveries (e) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3.1 |  |  |  | (0.8 | ) |  |  | 2.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 574.9 |  |  | $ | (103.5 | ) |  | $ | 471.4 |  |  | $ | 474.0 |  |  | $ | (90.9 | ) |  | $ | 383.1 |  |
| Earnings per share from continuing operations—diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 12.39 |  |  |  |  |  |  |  |  |  |  | $ | 9.26 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | 0.22 |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | (0.05 | ) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  |  |  |  |  |  |  |  |  | 0.29 |  |  |  |  |  |  |  |  |  |  |  | 0.25 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.15 | ) |  |  |  |  |  |  |  |  |  |  | (0.11 | ) |
| Other tax items, net (c) |  |  |  |  |  |  |  |  |  |  | 0.06 |  |  |  |  |  |  |  |  |  |  |  | 0.23 |  |
| Loss from natural disasters, net of insurance recoveries (e) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.06 |  |
| Adjusted earnings per share from continuing operations—diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 12.60 |  |  |  |  |  |  |  |  |  |  | $ | 9.94 |  |

[0001193125-22-024009:8k_2_02:109]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-22-024009:8k_2_02:110]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-22-024009:8k_2_02:111]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-22-024009:8k_2_02:112]
| (d) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-22-024009:8k_2_02:113]
| (e) | Recorded in (Gain) loss from natural disasters, net of insurance recoveries in the Consolidated Statement of Operations. |

[0001193125-22-024009:8k_2_02:114]
|  |  |  | For the Three MonthsEndedDecember 31, |  |  |  | For the Years EndedDecember 31, |  |
|  |  |  | 2021 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2020 |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized (gains) losses on settled futures contracts (a) |  | $ | (0.3 | ) |  | $ | (0.1 | ) |  | $ | (1.2 | ) |  | $ | 0.1 |  |
| Foreign currency exchange gains (a) |  |  | (0.6 | ) |  |  | (0.5 | ) |  |  | (2.2 | ) |  |  | (3.6 | ) |
| Loss (gain) on disposal of fixed assets (a) |  |  | 0.4 |  |  |  | 0.2 |  |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Other operating income (a) |  |  | (0.5 | ) |  |  | (0.5 | ) |  |  | (1.5 | ) |  |  | (2.2 | ) |
| Net change in unrealized gains on unsettled futures contracts (b) |  |  | — |  |  |  | (0.4 | ) |  |  | — |  |  |  | (0.3 | ) |
| Special legal contingency charges (b) |  |  | 0.4 |  |  |  | 0.2 |  |  |  | 1.3 |  |  |  | 1.1 |  |
| Asbestos-related litigation (b) |  |  | 0.9 |  |  |  | 3.7 |  |  |  | 5.4 |  |  |  | 5.6 |  |
| Environmental liabilities (b) |  |  | 1.2 |  |  |  | (2.9 | ) |  |  | 2.9 |  |  |  | (1.4 | ) |
| Charges incurred related to COVID-19 pandemic (b) |  |  | 0.3 |  |  |  | 1.8 |  |  |  | 2.2 |  |  |  | 8.3 |  |
| Other items, net (b) |  |  | 2.7 |  |  |  | 0.2 |  |  |  | 2.5 |  |  |  | — |  |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 4.5 |  |  | $ | 1.7 |  |  | $ | 9.2 |  |  | $ | 7.4 |  |

[0001193125-22-024009:8k_2_02:115]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-22-024009:8k_2_02:116]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-22-024009:8k_2_02:117]
| Reconciliation of Estimated Earnings per Share from Continuing Operations—Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations—Diluted, a Non-GAAP measure |  |
|  |  | For the Year EndedDecember 31, 2022ESTIMATED |  |
| Estimated Earnings per share from continuing operations—diluted, a GAAP measure |  | $ | 13.50-$14.50 |  |
| Other non-core EBIT charges and other non-core tax items |  |  | — |  |
| Estimated Adjusted Earnings per share from continuing operations—diluted, a Non-GAAP measure |  | $ | 13.50-$14.50 |  |

[0001193125-22-024009:8k_2_02:118]
| Reconciliation of Average Shares Outstanding—Diluted, a GAAP measure, to Adjusted Average Shares Outstanding—Diluted, a Non-GAAP measure (shares in millions): |  |
|  |  | For the Three MonthsEnded December 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Average shares outstanding—diluted, a GAAP measure |  |  | 36.8 |  |  |  | 38.6 |  |  |  | 37.5 |  |  |  | 38.6 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Adjusted average shares outstanding—diluted, a Non-GAAP measure |  |  | 36.8 |  |  |  | 38.6 |  |  |  | 37.4 |  |  |  | 38.5 |  |
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |  |
|  |  | Forthe Three MonthsEndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net cash provided by operating activities |  | $ | 119.2 |  |  | $ | 166.1 |  |  | $ | 515.5 |  |  | $ | 612.4 |  |
| Purchases of property, plant and equipment |  |  | (38.3 | ) |  |  | (22.6 | ) |  |  | (106.8 | ) |  |  | (78.5 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.9 |  |  |  | 1.0 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 81.1 |  |  | $ | 143.8 |  |  | $ | 409.6 |  |  | $ | 534.9 |  |

[0001193125-22-024009:8k_2_02:119]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | Trailing TwelveMonths toDecember 31,2021 |  |
| Adjusted EBIT (a) |  | $ | 603.9 |  |
| Depreciation and amortization expense (b) |  |  | 69.9 |  |
| EBITDA (a + b) |  | $ | 673.8 |  |
| Total debt at December 31, 2021 (c) |  | $ | 1,237.8 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 1.8 |  |
| Reconciliation of Income From Continuing Operations Before Income Taxes, a GAAP measure to Adjusted EBIT, a Non-GAAP measure |  |
|  |  | Trailing TwelveMonths toDecember 31,2021 |  |
| Income from continuing operations before income taxes, a GAAP measure |  |  | 560.1 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit |  |  | 14.3 |  |
| Special product quality adjustments |  |  | (2.5 | ) |
| Restructuring charges |  |  | 1.8 |  |
| Interest expense, net |  |  | 25.0 |  |
| Pension settlements |  |  | 1.2 |  |
| Other expense (income), net |  |  | 4.0 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  | 603.9 |  |
