# LII notes — 0000950123-11-091697


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950123-11-091697:notes:1]
[same as prior period, unchanged from 0000950123-11-068216:notes:1]

[0000950123-11-091697:notes:2]
[same as prior period, unchanged from 0000950123-11-068216:notes:2]

[0000950123-11-091697:notes:3]
[same as prior period, unchanged from 0000950123-11-068216:notes:3]

[0000950123-11-091697:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2011, the
   accompanying unaudited Consolidated Statements of Operations for the three and nine months ended
   September 30, 2011 and 2010, and the accompanying unaudited Consolidated Statements of Cash Flows
   for the nine months ended September 30, 2011 and 2010 should be read in conjunction with our
   audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K
   for the year ended December 31, 2010. The accompanying unaudited consolidated financial statements
   have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim
   financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The
   accompanying consolidated financial statements contain all material adjustments, consisting
   principally of normal recurring adjustments, necessary for a fair presentation of our financial
   position, results of operations and cash flows. Certain information and footnote disclosures
   normally included in financial statements prepared in accordance with GAAP have been condensed or
   omitted pursuant to applicable rules and regulations, although we believe that the disclosures
   herein are adequate to make the information presented not misleading. The operating results for
   the interim periods are not necessarily indicative of the results that may be expected for a full
   year.

[0000950123-11-091697:notes:5]
[same as prior period, unchanged from 0000950123-11-068216:notes:5]

[0000950123-11-091697:notes:6]
[same as prior period, unchanged from 0000950123-11-068216:notes:6]

[0000950123-11-091697:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about
   future events. These estimates and the underlying assumptions affect the amounts of assets and
   liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of
   revenues and expenses. Such estimates include the valuation of accounts receivable, inventories,
   goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations,
   indemnifications, and assumptions used in the calculation of income taxes, pension and
   postretirement medical benefits, among others. These estimates and assumptions are based on
   management’s best estimates and judgment.

[0000950123-11-091697:notes:8]
[same as prior period, unchanged from 0000950123-11-068216:notes:8]

[0000950123-11-091697:notes:9]
[same as prior period, unchanged from 0000950123-11-068216:notes:9]

[0000950123-11-091697:notes:10]
[same as prior period, unchanged from 0000950123-11-068216:notes:10]

[0000950123-11-091697:notes:11]
[same as prior period, unchanged from 0000950123-11-068216:notes:11]

[0000950123-11-091697:notes:12]
In June 2011, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards
   Update (“ASU”) No. 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income
   (“ASU 2011-05”). This ASU eliminates the option to present the components of other comprehensive
   income as part of the statement of changes in stockholders’ equity. Rather, it gives an entity the
   choice to present the components of net income and other comprehensive income in either a single
   continuous statement or two separate but
   consecutive statements. The components of comprehensive
   income and timing of reclassification of an item to net income do not change with this update. ASU
   2011-05 requires retrospective application and is effective for
   annual and interim periods beginning after December 15, 2011. Early adoption is permitted.
   We are currently evaluating which presentation to apply and will adopt the ASU in the first quarter
   of 2012.

[0000950123-11-091697:notes:13]
In April 2011, the FASB issued ASU No. 2011-02, Receivables (Topic 310): A Creditor’s
   Determination of Whether a Restructuring Is a Troubled Debt Restructuring (“ASU 2011-02”). This ASU
   provides additional guidance clarifying when the restructuring of a receivable should be considered
   a troubled debt restructuring. The additional guidance this update provides is for determining
   whether a creditor has granted a concession and whether the debtor is experiencing financial
   difficulty. ASU 2011-02 also ends the deferral of activity-based disclosures related to troubled
   debt restructurings. This ASU should be applied retrospectively and is effective for interim and
   annual periods beginning on or after June 15, 2011. Early adoption is permitted. We adopted ASU
   2011-02 in the third quarter of 2011 with no material impact on our financial statements.

[0000950123-11-091697:notes:14]
In September 2011, the FASB issued ASU No. 2011-08 — Intangibles — Goodwill and Other (Topic
   350):Testing Goodwill for Impairment (“ASU 2011-08”) related to goodwill impairment guidance. This
   ASU gives an option to first assess qualitative factors to determine whether the existence of
   events or circumstances leads to a determination that it is more likely than not that the fair
   value of a reporting unit is less than its carrying amount. If after assessing all events and
   circumstances, an entity determines it is not more likely than not that the fair value of a
   reporting unit is less than its carrying amount, the performance of the two-step impairment test is
   unnecessary. The effective date is for fiscal years beginning after December 15, 2011. We will
   adopt the ASU in the first quarter of 2012 when we perform our annual goodwill impairment test.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-091697:notes:15]
[same as prior period, unchanged from 0000950123-11-068216:notes:14]

[0000950123-11-091697:notes:16]
[same as prior period, unchanged from 0000950123-11-068216:notes:15]

[0000950123-11-091697:notes:17]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Finished goods |  | $ | 266.6 |  |  | $ | 213.4 |  |
| Work in process |  |  | 17.2 |  |  |  | 6.5 |  |
| Raw materials and repair parts. |  |  | 182.1 |  |  |  | 137.1 |  |
|  |  |  | 465.9 |  |  |  | 357.0 |  |
| Excess of current cost over last-in, first-out cost and other items |  |  | (71.6 | ) |  |  | (70.8 | ) |
| Total inventories, net |  | $ | 394.3 |  |  | $ | 286.2 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950123-11-091697:notes:18]
[same as prior period, unchanged from 0000950123-11-068216:notes:17]

[0000950123-11-091697:notes:19]
On January 14, 2011, we acquired substantially all the assets of the Kysor/Warren business
   from The Manitowoc Company. Kysor/Warren is a leading manufacturer of refrigerated systems and
   display cases for supermarkets throughout North America and is included in our Refrigeration
   Segment. The total consideration for the acquisition was $143.3 million, which reflects
   post-closing purchase price working capital adjustments. In connection with this acquisition, we
   recorded goodwill of $42.0 million and intangible assets of $33.9 million. The intangible assets
   consisted of the following: trade names of $5.0 million with indefinite lives, customer
   relationships of $26.7 million with 11 to 12 year lives, and other intangibles of $2.2 million with
   lives ranging from one to eight years. We paid more than the fair value of the underlying net
   assets as a result of expected operational synergies. The entire $42.0 million of goodwill is
   expected to be deductible for tax purposes. The initial accounting for this acquisition is
   substantially complete with the exception of additional minor adjustments as allowed under the
   purchase agreement. The acquisition would not have had a significant impact on our historical
   results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950123-11-091697:notes:20]
[same as prior period, unchanged from 0000950123-11-068216:notes:19]

[0000950123-11-091697:notes:21]
The changes in the carrying amount of goodwill for the first nine months of 2011, in total and
   by segment, are as follows (in millions):

[0000950123-11-091697:notes:22]
|  |  | Balance at |  |  |  |  |  |  |  |  |  |  | Balance at |  |
|  |  | December 31, |  |  | Acquisitions/ |  |  |  |  |  |  | September |  |
|  |  | 2010 |  |  | (Dispositions) |  |  |  |  |  |  | 30, 2011 |  |
| Segment: |  | Goodwill |  |  | (2) |  |  | Other(3) |  |  | Goodwill |  |
| Residential Heating & Cooling |  | $ | 33.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 33.7 |  |
| Commercial Heating & Cooling. |  |  | 30.0 |  |  |  | — |  |  |  | — |  |  |  | 30.0 |  |
| Service Experts(1) |  |  | 116.6 |  |  |  | 3.0 |  |  |  | (6.1 | ) |  |  | 113.5 |  |
| Refrigeration |  |  | 91.5 |  |  |  | 42.0 |  |  |  | (3.7 | ) |  |  | 129.8 |  |
|  |  | $ | 271.8 |  |  | $ | 45.0 |  |  | $ | (9.8 | ) |  | $ | 307.0 |  |

[0000950123-11-091697:notes:23]
| (1) |  | Service Experts goodwill includes accumulated impairment losses of $208.0 million from prior periods with no impairment losses in the current year. |
| (2) |  | During the second quarter of 2011, our Service Experts segment acquired a company, which resulted in additional goodwill of $3.0 million. During the first quarter of 2011, our Refrigeration segment acquired Kysor/Warren which resulted in additional goodwill of $42.0 million. See Note 3 for more information on the Kysor/Warren acquisition. |
| (3) |  | Other consists primarily of changes in foreign currency translation rates. |

[0000950123-11-091697:notes:24]
We performed our annual goodwill impairment test in the first quarter of 2011. Our fair
   values exceeded the carrying values for each of our reporting units in our annual test; therefore,
   we recognized no goodwill impairment for any of our reporting units.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950123-11-091697:notes:25]
[same as prior period, unchanged from 0000950123-11-068216:notes:24]

[0000950123-11-091697:notes:26]
[same as prior period, unchanged from 0000950123-11-068216:notes:25]

[0000950123-11-091697:notes:27]
[same as prior period, unchanged from 0000950123-11-068216:notes:26]

[0000950123-11-091697:notes:28]
[same as prior period, unchanged from 0000950123-11-068216:notes:27]

[0000950123-11-091697:notes:29]
[same as prior period, unchanged from 0000950123-11-068216:notes:28]

[0000950123-11-091697:notes:30]
A portion of our debt bears interest at variable interest rates and therefore, we are subject
   to variability in cash paid for interest expense. In order to mitigate a portion of the risk, we
   use a hedging strategy to eliminate the variability of cash flows in the interest payments
   associated with the first $100 million outstanding under our revolving credit facility that is
   solely due to changes in the benchmark interest rate. This strategy allows us to fix a portion of
   our variable interest payments.

[0000950123-11-091697:notes:31]
[same as prior period, unchanged from 0000950123-11-068216:notes:30]

[0000950123-11-091697:notes:32]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar
   value of assets and liabilities arising in foreign currencies. Our objective for entering into
   foreign currency forward contracts is to mitigate the impact of short-term currency exchange rate
   movements on certain short-term intercompany transactions. In order to meet that objective, we
   periodically enter into foreign currency forward contracts that act as economic hedges against
   changes in foreign currency exchange rates. These forward contracts are not
   designated as hedges
   and generally expire within three months. By entering into these forward contracts, we lock in
   exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should
   the U.S. dollar depreciate.

[0000950123-11-091697:notes:33]
[same as prior period, unchanged from 0000950123-11-068216:notes:32]

[0000950123-11-091697:notes:34]
We include gains or losses from our commodity cash flow hedges in accumulated other
   comprehensive income (“AOCI”). The gains or losses related to commodity price hedges are expected
   to be reclassified into earnings based on the prices of the commodities at the settlement dates.
   Assuming that commodity prices remain constant, $8.8 million of derivative losses are expected to
   be reclassified into earnings within the next 12 months. Commodity futures contracts that are
   designated as cash flow hedges and are in place as of September 30, 2011 are scheduled to mature
   through February 2013.

[0000950123-11-091697:notes:35]
[same as prior period, unchanged from 0000950123-11-068216:notes:34]

[0000950123-11-091697:notes:36]
[same as prior period, unchanged from 0000950123-11-068216:notes:35]

[0000950123-11-091697:notes:37]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Commodity Price Hedges: |  |  |  |  |  |  |  |  |
| Losses (gains) included in AOCI, net of tax |  | $ | 10.0 |  |  | $ | (11.7 | ) |
| (Benefit from) provision for income taxes |  |  | (5.7 | ) |  |  | 6.7 |  |
| Interest Rate Swap: |  |  |  |  |  |  |  |  |
| Losses included in AOCI, net of tax |  | $ | 1.5 |  |  | $ | 2.3 |  |
| Benefit from income taxes |  |  | (0.8 | ) |  |  | (1.3 | ) |

[0000950123-11-091697:notes:38]
[same as prior period, unchanged from 0000950123-11-068216:notes:37]

[0000950123-11-091697:notes:39]
|  |  | As of |  |  |  |  |  |
|  |  | September 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 20.4 |  |  |  | 18.5 |  |

[0000950123-11-091697:notes:40]
[same as prior period, unchanged from 0000950123-11-068216:notes:39]

[0000950123-11-091697:notes:41]
[same as prior period, unchanged from 0000950123-11-068216:notes:40]

[0000950123-11-091697:notes:42]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 2.8 |  |  |  | 1.4 |  |
| Aluminum |  |  | 2.6 |  |  |  | 1.4 |  |

[0000950123-11-091697:notes:43]
[same as prior period, unchanged from 0000950123-11-068216:notes:42]

[0000950123-11-091697:notes:44]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Notional amounts: |  |  |  |  |  |  |  |  |
| Brazilian Real |  |  | 3.6 |  |  |  | 5.6 |  |
| Mexican Peso |  |  | 170.0 |  |  |  | 138.0 |  |
| Euros |  |  | 7.8 |  |  |  | 15.6 |  |
| British Pounds |  |  | 7.0 |  |  |  | 2.0 |  |

[0000950123-11-091697:notes:45]
[same as prior period, unchanged from 0000950123-11-068216:notes:44]

[0000950123-11-091697:notes:46]
[same as prior period, unchanged from 0000950123-11-068216:notes:45]

[0000950123-11-091697:notes:47]
|  |  | Fair Values of Derivative Instruments(1) |  |
|  |  | Derivatives Designated as |  |  | Derivatives Not Designated as |  |
|  |  | Hedging Instruments |  |  | Hedging Instruments |  |
|  |  | As of September 30, |  |  | As of December 31, |  |  | As of September 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | — |  |  | $ | 17.4 |  |  | $ | — |  |  | $ | 1.4 |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.5 |  |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | — |  |  |  | 1.3 |  |  |  | — |  |  |  | 0.1 |  |
| Total Assets |  | $ | — |  |  | $ | 18.7 |  |  | $ | 0.5 |  |  | $ | 1.7 |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 13.9 |  |  | $ | — |  |  | $ | 2.9 |  |  | $ | — |  |
| Interest rate swap |  |  | 2.1 |  |  |  | 2.2 |  |  |  | — |  |  |  | — |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | 1.8 |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Interest rate swap |  |  | 0.2 |  |  |  | 1.4 |  |  |  | — |  |  |  | — |  |
| Total Liabilities |  | $ | 18.0 |  |  | $ | 3.6 |  |  | $ | 3.2 |  |  | $ | — |  |

[0000950123-11-091697:notes:48]
| (1) |  | All our derivative instruments are classified as Level 2 within the fair value hierarchy. For more information on other fair value measurements, see Note 16. |

[0000950123-11-091697:notes:49]
|  |  | Derivatives in Cash Flow Hedging Relationships |  |
|  |  | For the Three Months |  |  | For the Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Amount of Loss or (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(1) |  | $ | (2.9 | ) |  | $ | (1.4 | ) |  | $ | (12.8 | ) |  | $ | (9.0 | ) |
| Interest rate swap(2) |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 1.9 |  |  |  | 1.8 |  |
|  |  | $ | (2.3 | ) |  | $ | (0.8 | ) |  | $ | (10.9 | ) |  | $ | (7.2 | ) |
| Amount of (Gain) or Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(3) |  | $ | 0.1 |  |  | $ | (0.3 | ) |  | $ | 0.1 |  |  | $ | (0.4 | ) |

[0000950123-11-091697:notes:50]
|  |  | Derivatives Not Designated as Hedging Instruments |  |
|  |  | For the Three Months |  |  | For the Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Amount of (Gain) or Loss Recognized in Income on Derivatives: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts(3) |  | $ | 3.3 |  |  | $ | (1.3 | ) |  | $ | 3.8 |  |  | $ | (0.7 | ) |
| Foreign currency forward contracts(3) |  |  | (0.4 | ) |  |  | 0.7 |  |  |  | 0.9 |  |  |  | (0.1 | ) |
|  |  | $ | 2.9 |  |  | $ | (0.6 | ) |  | $ | 4.7 |  |  | $ | (0.8 | ) |

[0000950123-11-091697:notes:51]
[same as prior period, unchanged from 0000950123-11-068216:notes:50]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-091697:notes:52]
[same as prior period, unchanged from 0000950123-11-068216:notes:51]

[0000950123-11-091697:notes:53]
As of September 30, 2011, we had approximately $1.1 million in total gross unrecognized tax
   benefits. Of this amount, $0.7 million (net of federal benefit on state issues), if recognized,
   would be recorded through the Consolidated Statement of Operations. As of September 30, 2011, we
   recognized $0.1 million (net of federal tax benefits) in interest and penalties in income tax
   expense in accordance with Financial Accounting Standards Board (“FASB”) Accounting Standards
   Codification (“ASC”) Topic 740.

[0000950123-11-091697:notes:54]
The IRS completed its examination of our consolidated tax returns for the years ended 2008 —
   2009 and we reached a settlement with the IRS on April 7, 2011, which resulted in an immaterial
   impact to the Consolidated Statements of Operations.

[0000950123-11-091697:notes:55]
[same as prior period, unchanged from 0000950123-11-068216:notes:54]

[0000950123-11-091697:notes:56]
[same as prior period, unchanged from 0000950123-11-068216:notes:55]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-091697:notes:57]
7. Commitments and Contingencies:

[0000950123-11-091697:notes:58]
We are subject to contingencies that arise in the normal course of business, including product
   warranties and other product related contingencies, pending litigation, environmental matters and
   other guarantees or claims.

[0000950123-11-091697:notes:59]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to provide protection against claims relating to contingencies such as workers’
   compensation, general liability, product liability, property damage, aviation liability, directors’
   and officers’ liability, auto liability, physical damage and other exposures. Self-insurance
   expense and liabilities are actuarially determined based on our historical claims information, as
   well as industry factors and trends. Because we have a captive insurance company, we are required
   to maintain specified levels of liquid assets from which we must pay claims. The majority of our
   self-insured risks (excluding auto liability and physical damage) will be paid over an extended
   period of time. There have been no material changes in our insurance liability since our latest
   fiscal year-end. We also maintain third-party insurance coverage for risks not retained within our
   large deductible or captive insurance plans. The self-insurance liabilities recorded in Accrued
   expenses in the accompanying Consolidated Balance Sheets were $67.6 million and $61.3 million as of
   September 30, 2011 and December 31, 2010, respectively.

[0000950123-11-091697:notes:60]
Product Warranties and Product Related Contingencies

[0000950123-11-091697:notes:61]
Total liabilities for estimated product warranty are included in the following captions on the
   accompanying Consolidated Balance Sheets (in millions):

[0000950123-11-091697:notes:62]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Accrued expenses |  | $ | 31.1 |  |  | $ | 31.2 |  |
| Other liabilities |  |  | 40.2 |  |  |  | 44.3 |  |
|  |  | $ | 71.3 |  |  | $ | 75.5 |  |

[0000950123-11-091697:notes:63]
The changes in total product warranty liabilities for the first nine months of 2011 were as
   follows (in millions):

[0000950123-11-091697:notes:64]
| Total warranty liability as of December 31, 2010 |  | $ | 75.5 |  |
| Payments made in 2011 |  |  | (22.1 | ) |
| Changes resulting from issuance of new warranties |  |  | 20.1 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (1.8 | ) |
| Changes in foreign currency translation rates and other |  |  | (0.4 | ) |
| Total warranty liability as of September 30, 2011 |  | $ | 71.3 |  |

[0000950123-11-091697:notes:65]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete re-evaluation of our heating, ventilation and
   air conditioning (“HVAC”) warranty liabilities. As a result of the second quarter re-evaluation, we
   decreased our warranty liability by $2.5 million.

[0000950123-11-091697:notes:66]
We incur the risk of liability claims for the installation and service of heating and air
   conditioning products, and we maintain liabilities for those claims that we self-insure. We are
   involved in various claims and lawsuits related to our products. Our product liability insurance
   policies have limits that, if exceeded, may result in substantial costs that could have an adverse
   effect on our results of operations. In addition, warranty claims are not covered by our product
   liability insurance and certain product liability claims also may not be covered by our product
   liability insurance. There have been no material changes in the circumstances that affect our
   product warranties since our latest fiscal year-end.

[0000950123-11-091697:notes:67]
We may also incur costs related to our products that may not be covered under our warranties
   and are not covered by insurance, and we may, from time to time, repair or replace installed
   products experiencing quality issues in order to satisfy our customers and to protect our brand.
   These product quality issues may be caused by vendor-supplied components that fail to meet required
   specifications.

[0000950123-11-091697:notes:68]
In addition to normal product warranty, we identified a product quality issue in a heating and
   cooling product line produced in 2006 and 2007 that we believe resulted from a vendor-supplied
   materials quality issue. The expense for this product quality issue, and the related liability, is
   not included in the above tables related to our estimated warranty liabilities. We did not incur
   any additional expense in the first nine months of 2011; however, we may incur additional charges
   in the future as more information becomes available. The changes in the accrued product quality
   issue for the first nine months of 2011 were as follows (in millions):

[0000950123-11-091697:notes:69]
| Total accrued product quality issue as of December 31, 2010 |  | $ | 16.0 |  |
| Product quality claims |  |  | (4.5 | ) |
| Changes in estimates associated with pre-existing liabilities |  |  | (1.4 | ) |
| Total accrued product quality issue as of September 30, 2011 |  | $ | 10.1 |  |

[0000950123-11-091697:notes:70]
We estimate the costs to settle pending litigation based on experience involving similar
   claims and specific facts known. We do not believe that any current or pending or threatened
   litigation will have a material adverse effect on our financial position. Litigation and
   arbitration, however, involve uncertainties and it is possible that the eventual outcome of
   litigation could adversely affect our results of operations for a particular period.

[0000950123-11-091697:notes:71]
We were the defendant in a class action lawsuit seeking economic damages for alleged
   diminished value for plaintiffs’ homes relative to certain hearth products we produced and sold. On
   June 10, 2011, the litigation of this
   matter concluded when the court issued its Order Granting
   Final Approval of Class Settlement; Final Judgment
   and Order of Dismissal. We do not expect to incur any significant additional expense and
   substantially all of the expenses incurred to date were paid.

[0000950123-11-091697:notes:72]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We were in compliance with these financial covenants as of September 30, 2011.


## us-gaap:DebtDisclosureTextBlock

[0000950123-11-091697:notes:73]
8. Lines of Credit and Financing Arrangements:

[0000950123-11-091697:notes:74]
The following tables summarize our outstanding debt obligations and the classification in the
   accompanying Consolidated Balance Sheets (in millions):

[0000950123-11-091697:notes:75]
|  |  | As of September 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 3.5 |  |  | $ | 1.4 |  |
| Total short-term debt |  | $ | 3.5 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt: |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 17.2 |  |  |  | 17.0 |  |
| Domestic revolving credit facility |  |  | 278.5 |  |  |  | 100.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 495.7 |  |  | $ | 317.0 |  |
| Total debt |  | $ | 499.6 |  |  | $ | 319.0 |  |

[0000950123-11-091697:notes:76]
Short-Term Debt

[0000950123-11-091697:notes:77]
Foreign Obligations

[0000950123-11-091697:notes:78]
Through several of our foreign subsidiaries, we have $3.7 million in committed combined
   foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We
   had $3.7 million and $10.1 million of available capacity as of September 30, 2011 and December 31,
   2010, respectively. Our foreign obligations of $3.5 million represented borrowings under
   non-committed facilities.

[0000950123-11-091697:notes:79]
Asset Securitization

[0000950123-11-091697:notes:80]
Under a revolving period asset securitization arrangement (“ASA”), we are eligible to sell
   beneficial interests in a portion of our trade accounts receivable to participating financial
   institutions for cash. The arrangement is subject to renewal and contains a provision whereby we
   retain the right to repurchase all of the outstanding beneficial interests transferred. Our
   continued involvement with the transferred assets includes servicing, collection and administration
   of the transferred beneficial interests. The sale of the beneficial interests in our trade
   accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance
   Sheets and proceeds received are included in cash flows from financing activities in the
   accompanying Consolidated Statements of Cash Flows. The ASA provides for a maximum securitization
   amount of $100.0 million or 100% of the net pool balance as defined by the ASA. However,
   eligibility for securitization is limited based on the amount and quality of the qualifying
   accounts receivable and is calculated monthly. The beneficial interest sold cannot exceed the
   maximum amount even if our qualifying accounts receivable is greater than the maximum amount at any
   point in time. The eligible amounts available and beneficial interests sold were as follows (in
   millions):

[0000950123-11-091697:notes:81]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 100.0 |  |  | $ | 100.0 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 100.0 |  |  | $ | 100.0 |  |

[0000950123-11-091697:notes:82]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 0.75%. The rate
   as of September 30, 2011 was 1.04% and the rate at December 31, 2010 was 1.06%. The unused fee is
   based on 102% of the maximum available amount less the beneficial interest sold and calculated at a
   0.375% fixed rate throughout the term of the agreement. We recorded these fees in Selling, General
   and Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):

[0000950123-11-091697:notes:83]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |

[0000950123-11-091697:notes:84]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our domestic revolving credit facility and
   senior unsecured notes. The administrative agent under the ASA is also a participant in our
   domestic revolving credit facility. The participating financial institution has an investment grade
   credit rating and we continue to monitor its credit rating. We have no reason to believe it will
   not perform under the ASA. As of September 30, 2011, we were in compliance with all covenant
   requirements.

[0000950123-11-091697:notes:85]
Long-Term Debt

[0000950123-11-091697:notes:86]
Domestic Revolving Credit Facility

[0000950123-11-091697:notes:87]
Under the $650 million Third Amended and Restated Credit Agreement (“Domestic Revolving Credit
   Facility”), we had outstanding borrowings of $278.5 million and $80.0 million committed to standby
   letters of credit as of September 30, 2011. Subject to covenant limitations, $291.5 million was
   available for future borrowings. This domestic revolving credit facility provides for issuance of
   letters of credit for the full amount of the credit facility and matures in October 2012 (see Note
   17, Subsequent Event).

[0000950123-11-091697:notes:88]
Our weighted average borrowing rate on the facility was as follows:

[0000950123-11-091697:notes:89]
|  |  | As of September 30, 2011 |  |  | As of December 31, 2010 |  |
| Weighted average borrowing rate |  |  | 1.01 | % |  |  | 0.96 | % |

[0000950123-11-091697:notes:90]
Our domestic revolving credit facility contains financial covenants relating to leverage
   and interest coverage. Other covenants contained in the domestic revolving credit facility
   restrict, among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a
   Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The
   required ratios under our domestic revolving credit facility as of September 30, 2011 are detailed
   below:

[0000950123-11-091697:notes:91]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |

[0000950123-11-091697:notes:92]
Our domestic revolving credit facility contains customary events of default. These events of
   default include nonpayment of principal or interest, breach of covenants or other restrictions or
   requirements, default on certain other indebtedness or receivables securitizations (cross default),
   and bankruptcy. A cross default under our revolving credit facility could occur if:

[0000950123-11-091697:notes:93]
|  | • |  | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $40.0 million; or |

[0000950123-11-091697:notes:94]
|  | • |  | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $40.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0000950123-11-091697:notes:95]
Each of our major debt agreements contains provisions by which a default under one agreement
   causes a default in the others (a cross default). If a cross default under the revolving credit
   facility, our senior unsecured notes, or our ASA were to occur, it could have a wider impact on our
   liquidity than might otherwise occur from a default of a single debt instrument or lease
   commitment.

[0000950123-11-091697:notes:96]
If any event of default occurs and is continuing, lenders with a majority of the aggregate
   commitments may require the administrative agent to terminate our right to borrow under our
   domestic revolving credit facility and accelerate amounts due under our domestic revolving credit
   facility (except for a bankruptcy event of default, in which case such amounts will automatically
   become due and payable and the lenders’ commitments will automatically terminate). As of
   September 30, 2011, we were in compliance with all covenant requirements.

[0000950123-11-091697:notes:97]
Senior Unsecured Notes

[0000950123-11-091697:notes:98]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering.
   Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per
   annum. These notes mature on May 15, 2017.

[0000950123-11-091697:notes:99]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries
   that guarantee payment by us of any indebtedness under our domestic revolving credit facility. The
   indenture governing the notes contains covenants that, among other things, limit our ability and
   the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale
   and leaseback transactions; enter into certain mergers, consolidations and transfers of
   substantially all of our assets; and transfer certain properties. The indenture also contains a
   cross default provision which is triggered if we default on other debt of at least $75 million in
   principal which is then accelerated, and such acceleration is not rescinded within 30 days of the
   notice date. As of September 30, 2011, we were in compliance with all covenant requirements.

[0000950123-11-091697:notes:100]
Credit Rating

[0000950123-11-091697:notes:101]
At September 30, 2011, our senior credit ratings were Baa3, with a stable outlook, and BBB-,
   with a stable outlook by Moody’s and Standard & Poor’s Rating Group (“S&P”), respectively.

[0000950123-11-091697:notes:102]
Other Financing Arrangements

[0000950123-11-091697:notes:103]
In the first quarter 2010, our captive insurance subsidiary entered into an agreement in which
   cash was placed into a trust for the benefit of a third-party insurance provider. The purpose of
   the trust is to pay workers compensation claims for policy years 2003 — 2009 until the liabilities
   are fully extinguished. These policies were written by the third-party insurance provider, and
   then reinsured by our captive insurance subsidiary. In the second quarter of 2011, we changed how
   these claims were secured. Substantially all claims for the workers compensation claims for policy
   years 2003-2009 are now secured by standby letters of credit. As of December 31, 2010, we had
   $12.2 million in Restricted Cash on the accompanying Consolidated Balance Sheets to pay these
   claims.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950123-11-091697:notes:104]
[same as prior period, unchanged from 0000950123-11-068216:notes:102]

[0000950123-11-091697:notes:105]
[same as prior period, unchanged from 0000950123-11-068216:notes:103]

[0000950123-11-091697:notes:106]
|  |  | For the Three Months Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
|  |  | Pension Benefits |  |  | Other Benefits |  |
| Service cost |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |
| Interest cost |  |  | 4.5 |  |  |  | 4.4 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Expected return on plan assets |  |  | (4.7 | ) |  |  | (4.9 | ) |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.1 |  |  |  | 0.1 |  |  |  | (0.4 | ) |  |  | (0.5 | ) |
| Amortization of net loss |  |  | 1.7 |  |  |  | 2.1 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Settlements or curtailments |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total net periodic pension cost |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 0.3 |  |  | $ | 0.2 |  |

[0000950123-11-091697:notes:107]
|  |  | For the Nine Months Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
|  |  | Pension Benefits |  |  | Other Benefits |  |
| Service cost |  | $ | 4.0 |  |  | $ | 3.7 |  |  | $ | 0.6 |  |  | $ | 0.4 |  |
| Interest cost |  |  | 13.5 |  |  |  | 13.2 |  |  |  | 0.7 |  |  |  | 0.6 |  |
| Expected return on plan assets |  |  | (14.2 | ) |  |  | (14.5 | ) |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.3 |  |  |  | 0.4 |  |  |  | (1.4 | ) |  |  | (1.4 | ) |
| Amortization of net loss |  |  | 5.2 |  |  |  | 6.4 |  |  |  | 0.9 |  |  |  | 0.9 |  |
| Settlements or curtailments |  |  | 1.7 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total net periodic pension cost |  | $ | 10.5 |  |  | $ | 9.2 |  |  | $ | 0.8 |  |  | $ | 0.5 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950123-11-091697:notes:108]
[same as prior period, unchanged from 0000950123-11-068216:notes:106]

[0000950123-11-091697:notes:109]
[same as prior period, unchanged from 0000950123-11-068216:notes:107]

[0000950123-11-091697:notes:110]
|  |  | For the Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net income |  | $ | 71.6 |  |  | $ | 88.5 |  |
| Foreign currency translation adjustments, net |  |  | (27.4 | ) |  |  | 17.8 |  |
| Derivatives and other, net of tax benefit of $11.9 in 2011 and tax provision of $1.7 in 2010 |  |  | (31.6 | ) |  |  | 2.6 |  |
| Comprehensive income |  | $ | 12.6 |  |  | $ | 108.9 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-091697:notes:111]
[same as prior period, unchanged from 0000950123-11-068216:notes:109]

[0000950123-11-091697:notes:112]
[same as prior period, unchanged from 0000950123-11-068216:notes:110]

[0000950123-11-091697:notes:113]
|  |  | For the Three Months |  |  | For the Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net stock-based compensation expense |  | $ | 3.5 |  |  | $ | 4.1 |  |  | $ | 12.6 |  |  | $ | 11.8 |  |

[0000950123-11-091697:notes:114]
[same as prior period, unchanged from 0000950123-11-068216:notes:112]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950123-11-091697:notes:115]
12. Stock Repurchases:

[0000950123-11-091697:notes:116]
In June 2008 our Board of Directors approved a $300 million share repurchase plan which
   authorizes us to repurchase shares of our common stock through open market purchases (the “2008
   Share Repurchase Plan”). The 2008 Share Repurchase Plan has no stated expiration date.
   Additionally, in connection with the vesting of restricted stock units and performance share units,
   employees may surrender shares to satisfy tax-withholding obligations. Through the third quarter
   of 2011, we repurchased 2,305,810 shares of our common stock including 25,399 in surrendered
   shares, totaling $90.9 million. These repurchased and surrendered shares are included in Treasury
   Stock.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950123-11-091697:notes:117]
13. Restructuring Charges:

[0000950123-11-091697:notes:118]
As part of our strategic priorities of manufacturing and sourcing excellence and expense
   reduction, we initiated various manufacturing rationalization actions designed to lower our cost
   structure. We expanded these expense reductions across the organization by initiating a number of
   activities to rationalize and reorganize various support and administrative functions.
   Restructuring charges are not included in our calculation of segment profit (loss), see Note 15 for
   further discussion. Detailed below are the restructuring activities that we incurred additional
   expense in 2011.

[0000950123-11-091697:notes:119]
2011 Plans

[0000950123-11-091697:notes:120]
Corporate and Other

[0000950123-11-091697:notes:121]
In the third quarter of 2011, we terminated our airplane lease, closed the aviation
   department, and reorganized certain support functions within our organization. Substantially all
   of the costs related to these activities were recognized in the third quarter of 2011 and consisted
   of $4.3 million in lease termination costs, $1.0 million in severance costs and $0.2 million in
   accelerated depreciation.

[0000950123-11-091697:notes:122]
[same as prior period, unchanged from 0000950123-11-068216:notes:115]

[0000950123-11-091697:notes:123]
[same as prior period, unchanged from 0000950123-11-068216:notes:116]

[0000950123-11-091697:notes:124]
We began to exit certain Refrigeration manufacturing operations in Milperra, Australia in
   2010, specifically our OEM coil manufacturing and contract coil manufacturing. In the first
   quarter of 2010, we began to exit OEM coil manufacturing. We reversed approximately $0.5 million in
   severance in the first nine months of 2011 to adjust estimated charges to actual. This activity was
   substantially complete in 2010. We initiated restructuring activities related to exiting contract
   coil manufacturing in the third quarter of 2010. In the first nine months of 2011, we recognized
   $1.4 million in other plant closure costs related to these restructuring activities. The total
   expected expenses for the OEM coil restructuring are $5.3 million and the contract coil
   manufacturing restructuring is $5.2 million.

[0000950123-11-091697:notes:125]
[same as prior period, unchanged from 0000950123-11-068216:notes:118]

[0000950123-11-091697:notes:126]
We began to reorganize certain administrative functions and the management structure of our
   Service Experts business in 2010 and initiated two actions. The first action, started in the
   second quarter of 2010, was to reorganize the administrative operations of an acquired company.
   This project was completed in 2010. The second action, initiated in the fourth quarter of 2010,
   was to reorganize the management structure of our Service Experts business. We expect to complete
   this project in the fourth quarter of 2011. We recognized $4.6 million in severance, lease
   termination and other costs in the first nine months of 2011. The total expected expenses related
   to the second action for the administrative and management restructuring is $5.7 million.

[0000950123-11-091697:notes:127]
[same as prior period, unchanged from 0000950123-11-068216:notes:120]

[0000950123-11-091697:notes:128]
[same as prior period, unchanged from 0000950123-11-068216:notes:122]

[0000950123-11-091697:notes:129]
We completed the consolidation of certain manufacturing operations from Mions, France into our
   Longvic, France operations in the first quarter of 2010. We reversed $0.1 million in severance
   charges in the first nine months of 2011 to adjust estimated charges to actual. The total expected
   restructuring charges for this consolidation is $6.3 million.

[0000950123-11-091697:notes:130]
[same as prior period, unchanged from 0000950123-11-068216:notes:124]

[0000950123-11-091697:notes:131]
We consolidated our manufacturing operations from Blackville, South Carolina into our
   Orangeburg, South Carolina and Saltillo, Mexico operations. We expect to complete this
   consolidation in the fourth quarter of 2011. We recognized $0.8 million in restructuring charges
   in the first nine months of 2011 related to other plant closure costs. The total expected expenses
   for this consolidation is $13.6 million.

[0000950123-11-091697:notes:132]
[same as prior period, unchanged from 0000950123-11-068216:notes:126]

[0000950123-11-091697:notes:133]
In the fourth quarter of 2008, we commenced the transition of activities performed at our
   North American Parts Center in Des Moines, Iowa to other locations, including our North American
   Distribution Center in Marshalltown, Iowa. In the first nine months of 2011, we recognized $0.9
   million primarily in other restructuring charges. The total expected restructuring charges for the
   regional distribution network is $4.9 million

[0000950123-11-091697:notes:134]
[same as prior period, unchanged from 0000950123-11-068216:notes:128]

[0000950123-11-091697:notes:135]
[same as prior period, unchanged from 0000950123-11-068216:notes:129]

[0000950123-11-091697:notes:136]
|  |  |  |  |  |  |  |  |  |  | Total |  |
|  |  | Charges |  |  | Charges |  |  | Charges |  |
|  |  | Incurred in |  |  | Incurred to |  |  | Expected to |  |
|  |  | 2011 |  |  | Date |  |  | be Incurred |  |
| Severance and related expense |  | $ | 2.1 |  |  | $ | 46.6 |  |  | $ | 47.0 |  |
| Asset write-offs and accelerated depreciation |  |  | 0.4 |  |  |  | 11.5 |  |  |  | 11.5 |  |
| Equipment moves |  |  | 0.6 |  |  |  | 1.8 |  |  |  | 2.3 |  |
| Lease termination |  |  | 6.0 |  |  |  | 8.4 |  |  |  | 8.4 |  |
| Other |  |  | 5.3 |  |  |  | 11.2 |  |  |  | 12.6 |  |
| Total |  | $ | 14.4 |  |  | $ | 79.5 |  |  | $ | 81.8 |  |

[0000950123-11-091697:notes:137]
[same as prior period, unchanged from 0000950123-11-068216:notes:131]

[0000950123-11-091697:notes:138]
|  |  |  |  |  |  |  |  |  |  | Total |  |
|  |  | Charges |  |  | Charges |  |  | Charges |  |
|  |  | Incurred in |  |  | Incurred to |  |  | Expected to |  |
|  |  | 2011 |  |  | Date |  |  | be Incurred |  |
| Residential Heating & Cooling |  | $ | 2.2 |  |  | $ | 17.8 |  |  | $ | 19.8 |  |
| Commercial Heating & Cooling |  |  | 0.1 |  |  |  | 16.6 |  |  |  | 16.8 |  |
| Service Experts |  |  | 4.9 |  |  |  | 8.2 |  |  |  | 8.3 |  |
| Refrigeration |  |  | 1.7 |  |  |  | 19.9 |  |  |  | 19.9 |  |
| Corporate & Other |  |  | 5.5 |  |  |  | 17.0 |  |  |  | 17.0 |  |
| Total |  | $ | 14.4 |  |  | $ | 79.5 |  |  | $ | 81.8 |  |

[0000950123-11-091697:notes:139]
Restructuring reserves are included in Accrued Expenses in the accompanying Consolidated
   Balance Sheets. The table below details activity within the restructuring reserves for the first
   nine months of 2011 (in millions):

[0000950123-11-091697:notes:140]
|  |  | Balance as of |  |  | Charged |  |  |  |  |  |  | Non-Cash |  |  | Balance as of |  |
|  |  | December 31, |  |  | to |  |  | Cash |  |  | Utilization |  |  | September 30, |  |
| Description of Reserves |  | 2010 |  |  | Earnings |  |  | Utilization |  |  | and Other |  |  | 2011 |  |
| Severance and related expense |  | $ | 6.2 |  |  | $ | 2.1 |  |  | $ | (3.8 | ) |  | $ | — |  |  | $ | 4.5 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | (0.4 | ) |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 0.6 |  |  |  | (0.6 | ) |  |  | — |  |  |  | — |  |
| Lease termination |  |  | 0.3 |  |  |  | 6.0 |  |  |  | (1.0 | ) |  |  | — |  |  |  | 5.3 |  |
| Other |  |  | 0.7 |  |  |  | 5.3 |  |  |  | (6.0 | ) |  |  | — |  |  |  | — |  |
| Total restructuring reserves |  | $ | 7.2 |  |  | $ | 14.4 |  |  | $ | (11.4 | ) |  | $ | (0.4 | ) |  | $ | 9.8 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-091697:notes:141]
14. Earnings Per Share:

[0000950123-11-091697:notes:142]
[same as prior period, unchanged from 0000950123-11-068216:notes:136]

[0000950123-11-091697:notes:143]
[same as prior period, unchanged from 0000950123-11-068216:notes:137]

[0000950123-11-091697:notes:144]
|  |  | For the |  |  | For the |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net income |  | $ | 33.8 |  |  | $ | 41.8 |  |  | $ | 71.6 |  |  | $ | 88.5 |  |
| Add: Loss from discontinued operations |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.8 |  |
| Income from continuing operations |  | $ | 33.8 |  |  | $ | 41.9 |  |  | $ | 71.6 |  |  | $ | 89.3 |  |
| Weighted-average shares outstanding — basic |  |  | 52.2 |  |  |  | 53.8 |  |  |  | 53.0 |  |  |  | 55.0 |  |
| Effect of dilutive securities attributable to stock-based payments |  |  | 0.6 |  |  |  | 1.2 |  |  |  | 0.9 |  |  |  | 1.2 |  |
| Weighted-average shares outstanding — diluted |  |  | 52.8 |  |  |  | 55.0 |  |  |  | 53.9 |  |  |  | 56.2 |  |
| Earnings per share from continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | 0.78 |  |  | $ | 1.35 |  |  | $ | 1.62 |  |
| Diluted |  | $ | 0.64 |  |  | $ | 0.76 |  |  | $ | 1.33 |  |  | $ | 1.59 |  |

[0000950123-11-091697:notes:145]
[same as prior period, unchanged from 0000950123-11-068216:notes:139]

[0000950123-11-091697:notes:146]
|  |  | For the Nine Months Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Number of shares |  |  | 2,275,894 |  |  |  | 520,817 |  |
| Price ranges per share |  | $ | 28.24 — $46.78 |  |  | $ | $36.94 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-091697:notes:147]
15. Reportable Business Segments:

[0000950123-11-091697:notes:148]
[same as prior period, unchanged from 0000950123-11-068216:notes:142]

[0000950123-11-091697:notes:149]
[same as prior period, unchanged from 0000950123-11-068216:notes:143]

[0000950123-11-091697:notes:150]
[same as prior period, unchanged from 0000950123-11-068216:notes:144]

[0000950123-11-091697:notes:151]
[same as prior period, unchanged from 0000950123-11-068216:notes:145]

[0000950123-11-091697:notes:152]
Our corporate costs include those costs related to corporate functions such as legal, internal
   audit, treasury, human resources, tax compliance and senior executive staff. Corporate costs also
   include the long-term share-
   based incentive awards provided to employees throughout LII. We
   recorded these share-based awards as Corporate costs as they are determined at the discretion of the Board of Directors and based
   on the historical practice of doing so for internal reporting purposes.

[0000950123-11-091697:notes:153]
[same as prior period, unchanged from 0000950123-11-068216:notes:147]

[0000950123-11-091697:notes:154]
|  |  | For the Three Months |  |  | For the Nine Months Ended |  |
|  |  | Ended September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 373.6 |  |  | $ | 370.9 |  |  | $ | 1,040.7 |  |  | $ | 1,068.5 |  |
| Commercial Heating & Cooling |  |  | 199.3 |  |  |  | 176.3 |  |  |  | 536.4 |  |  |  | 471.7 |  |
| Service Experts |  |  | 144.7 |  |  |  | 150.9 |  |  |  | 406.6 |  |  |  | 445.6 |  |
| Refrigeration |  |  | 223.7 |  |  |  | 140.6 |  |  |  | 616.3 |  |  |  | 411.8 |  |
| Eliminations (1) |  |  | (18.3 | ) |  |  | (20.5 | ) |  |  | (52.3 | ) |  |  | (63.2 | ) |
|  |  | $ | 923.0 |  |  | $ | 818.2 |  |  | $ | 2,547.7 |  |  | $ | 2,334.4 |  |
| Segment Profit (Loss)(2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 28.8 |  |  | $ | 39.0 |  |  | $ | 60.8 |  |  | $ | 98.6 |  |
| Commercial Heating & Cooling |  |  | 28.7 |  |  |  | 24.9 |  |  |  | 61.7 |  |  |  | 56.2 |  |
| Service Experts |  |  | 5.4 |  |  |  | 6.0 |  |  |  | 0.4 |  |  |  | 14.2 |  |
| Refrigeration |  |  | 20.5 |  |  |  | 17.3 |  |  |  | 55.5 |  |  |  | 47.5 |  |
| Corporate and other |  |  | (15.4 | ) |  |  | (15.5 | ) |  |  | (41.4 | ) |  |  | (48.2 | ) |
| Eliminations (1) |  |  | 0.3 |  |  |  | 0.1 |  |  |  | — |  |  |  | (0.2 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 68.3 |  |  |  | 71.8 |  |  |  | 137.0 |  |  |  | 168.1 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | — |  |  |  | — |  |  |  | (2.4 | ) |  |  | — |  |
| Items in losses and other expenses, net that are excluded from segment profit (3) |  |  | 3.0 |  |  |  | 0.5 |  |  |  | 5.0 |  |  |  | 6.7 |  |
| Restructuring charges |  |  | 10.8 |  |  |  | 4.7 |  |  |  | 14.4 |  |  |  | 15.0 |  |
| Interest expense, net |  |  | 4.1 |  |  |  | 3.5 |  |  |  | 12.5 |  |  |  | 9.1 |  |
| Other expense, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 50.4 |  |  | $ | 63.1 |  |  | $ | 107.4 |  |  | $ | 137.2 |  |

[0000950123-11-091697:notes:155]
| (1) |  | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |
| (2) |  | We define segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0000950123-11-091697:notes:156]
|  | • |  | Special product quality adjustments. |
|  | • |  | Items within Losses and Other Expenses, net that are noted in (3). |
|  | • |  | Restructuring charges. |
|  | • |  | Goodwill and equity method investment impairments. |
|  | • |  | Interest expense, net. |
|  | • |  | Acquisition costs. |
|  | • |  | Other expense, net. |

[0000950123-11-091697:notes:157]
| (3) |  | Items in Losses and Other Expenses, net that are excluded from segment profit are net change in unrealized gains and/or losses on open futures contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |

[0000950123-11-091697:notes:158]
[same as prior period, unchanged from 0000950123-11-068216:notes:152]

[0000950123-11-091697:notes:159]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Total Assets |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 568.8 |  |  | $ | 519.8 |  |
| Commercial Heating & Cooling |  |  | 295.9 |  |  |  | 252.7 |  |
| Service Experts |  |  | 185.6 |  |  |  | 186.2 |  |
| Refrigeration |  |  | 565.5 |  |  |  | 389.7 |  |
| Corporate and other |  |  | 227.2 |  |  |  | 354.9 |  |
| Eliminations (1) |  |  | (8.7 | ) |  |  | (11.3 | ) |
| Total assets |  | $ | 1,834.3 |  |  | $ | 1,692.0 |  |

[0000950123-11-091697:notes:160]
[same as prior period, unchanged from 0000950123-11-068216:notes:154]


## us-gaap:FairValueDisclosuresTextBlock

[0000950123-11-091697:notes:161]
16. Fair Value Measurements:

[0000950123-11-091697:notes:162]
[same as prior period, unchanged from 0000950123-11-068216:notes:156]

[0000950123-11-091697:notes:163]
[same as prior period, unchanged from 0000950123-11-068216:notes:157]

[0000950123-11-091697:notes:164]
|  |  | Quoted Prices in Active Markets for |  |
|  |  | Identical Assets (Level 1) |  |
|  |  | As of September 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Assets: |  |  |  |  |  |  |  |  |
| Investment in marketable equity securities (1) |  | $ | 7.7 |  |  | $ | 18.0 |  |

[0000950123-11-091697:notes:165]
[same as prior period, unchanged from 0000950123-11-068216:notes:159]

[0000950123-11-091697:notes:166]
[same as prior period, unchanged from 0000950123-11-068216:notes:160]

[0000950123-11-091697:notes:167]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net,
   accounts payable, other current liabilities, and short-term debt approximate fair value due to the
   short maturities of these instruments. The fair values of each of our long-term debt instruments
   are based on the quoted market prices for the same issues or on the amount of future cash flows
   associated with each instrument using current market rates for debt instruments of similar
   maturities and credit risk. The fair values presented are estimates and are not necessarily
   indicative of amounts for which we could settle such instruments currently or indicative of our
   intent or ability to dispose of or liquidate them. The estimated fair value of our debt was as
   follows (in millions):

[0000950123-11-091697:notes:168]
|  |  | As of September 30, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Long-term debt (1) |  | $ | 293.9 |  |  | $ | 114.6 |  |
| Senior unsecured notes |  |  | 217.9 |  |  |  | 203.0 |  |

[0000950123-11-091697:notes:169]
| (1) |  | Long-term debt includes our domestic revolving credit facility, capital lease obligations, and any related current maturities. |


## us-gaap:SubsequentEventsTextBlock

[0000950123-11-091697:notes:170]
17. Subsequent Event:

[0000950123-11-091697:notes:171]
On October 21, 2011, we amended our domestic revolving credit facility through the Fourth
   Amended and Restated Revolving Credit Facility Agreement. This amended facility has up to $650 million in
   capacity and provides for issuance of letters of credit up to the full amount of the facility. The
   interest terms, financial covenants and
   events of default are substantially the same as under the Third Amended and Restated Credit
   Agreement. Certain of the covenants contained in the prior credit agreement were liberalized. The Fourth Amended and Restated Credit Agreement extends the maturity to October 2016.


## lii:ScheduleOfCondensedConsolidatingFinancialStatementsTextBlock

[0000950123-11-091697:notes:172]
18. Condensed Consolidating Financial Statements:

[0000950123-11-091697:notes:173]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the
   Company’s subsidiaries (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries
   (the “Non-Guarantor Subsidiaries”). As a result of the guarantee arrangements, we are required to
   present the following condensed consolidating financial statements. During the first quarter of
   2011, our guarantor and non-guarantor subsidiary structure changed as required by our credit
   facility due to the Kysor/Warren acquisition. Three subsidiaries previously classified as
   non-guarantor subsidiaries as of December 31, 2010 are now classified as guarantor subsidiaries.
   These changes are reflected in the condensed consolidating financial statements for periods after
   December 31, 2010.

[0000950123-11-091697:notes:174]
The condensed consolidating financial statements reflect the investments in subsidiaries of
   the Company using the equity method of accounting. Intercompany account balances have been
   included in Accounts and Notes Receivable, Other (Current) Assets, Other Assets, net, Short-Term
   Debt, Accounts Payable, and Long-Term Debt line items of the Parent, Guarantor and Non-Guarantor
   balance sheets. The principal elimination entries eliminate investments in subsidiaries and
   intercompany balances and transactions.

[0000950123-11-091697:notes:175]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and
   Non-Guarantor Subsidiaries as of September 30, 2011 and December 31, 2010 and for the three and
   nine months ended September 30, 2011 and 2010 are shown below:

[0000950123-11-091697:notes:176]
Condensed Consolidating Balance Sheets

[0000950123-11-091697:notes:177]
As of September 30, 2011

[0000950123-11-091697:notes:178]
(In millions)

[0000950123-11-091697:notes:179]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 0.3 |  |  | $ | 19.1 |  |  | $ | 38.5 |  |  | $ | — |  |  | $ | 57.9 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Accounts and notes receivable, net |  |  | (917.0 | ) |  |  | 1,004.3 |  |  |  | 391.8 |  |  |  | (0.9 | ) |  |  | 478.2 |  |
| Inventories, net |  |  | — |  |  |  | 274.9 |  |  |  | 124.4 |  |  |  | (5.0 | ) |  |  | 394.3 |  |
| Deferred income taxes, net |  |  | 14.9 |  |  |  | 30.7 |  |  |  | 8.7 |  |  |  | (4.2 | ) |  |  | 50.1 |  |
| Other assets |  |  | 20.5 |  |  |  | 23.2 |  |  |  | 82.9 |  |  |  | (78.3 | ) |  |  | 48.3 |  |
| Total current assets |  |  | (881.3 | ) |  |  | 1,352.2 |  |  |  | 646.3 |  |  |  | (88.4 | ) |  |  | 1,028.8 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 258.1 |  |  |  | 75.2 |  |  |  | — |  |  |  | 333.3 |  |
| GOODWILL |  |  | — |  |  |  | 111.8 |  |  |  | 195.2 |  |  |  | — |  |  |  | 307.0 |  |
| DEFERRED INCOME TAXES |  |  | (3.9 | ) |  |  | 81.0 |  |  |  | 20.1 |  |  |  | (13.0 | ) |  |  | 84.2 |  |
| OTHER ASSETS, net |  |  | 2,143.6 |  |  |  | 493.4 |  |  |  | 23.7 |  |  |  | (2,579.7 | ) |  |  | 81.0 |  |
| TOTAL ASSETS |  | $ | 1,258.4 |  |  | $ | 2,296.5 |  |  | $ | 960.5 |  |  | $ | (2,681.1 | ) |  | $ | 1,834.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 102.8 |  |  | $ | — |  |  | $ | (37.5 | ) |  | $ | (61.8 | ) |  | $ | 3.5 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.3 |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.4 |  |
| Accounts payable |  |  | 9.3 |  |  |  | 225.1 |  |  |  | 98.9 |  |  |  | 9.9 |  |  |  | 343.2 |  |
| Accrued expenses |  |  | 25.9 |  |  |  | 203.3 |  |  |  | 89.6 |  |  |  | (2.7 | ) |  |  | 316.1 |  |
| Income taxes payable |  |  | (10.5 | ) |  |  | 31.4 |  |  |  | 6.0 |  |  |  | (17.3 | ) |  |  | 9.6 |  |
| Total current liabilities |  |  | 127.5 |  |  |  | 460.1 |  |  |  | 157.1 |  |  |  | (71.9 | ) |  |  | 672.8 |  |
| LONG-TERM DEBT |  |  | 478.4 |  |  |  | 16.8 |  |  |  | 101.2 |  |  |  | (100.7 | ) |  |  | 495.7 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 15.6 |  |  |  | — |  |  |  | — |  |  |  | 15.6 |  |
| PENSIONS |  |  | — |  |  |  | 79.5 |  |  |  | 9.4 |  |  |  | 0.1 |  |  |  | 89.0 |  |
| OTHER LIABILITIES |  |  | 8.1 |  |  |  | 53.4 |  |  |  | 15.6 |  |  |  | (14.6 | ) |  |  | 62.5 |  |
| Total liabilities |  |  | 614.0 |  |  |  | 625.4 |  |  |  | 283.3 |  |  |  | (187.1 | ) |  |  | 1,335.6 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 644.4 |  |  |  | 1,671.1 |  |  |  | 677.2 |  |  |  | (2,494.0 | ) |  |  | 498.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,258.4 |  |  | $ | 2,296.5 |  |  | $ | 960.5 |  |  | $ | (2,681.1 | ) |  | $ | 1,834.3 |  |

[0000950123-11-091697:notes:180]
Condensed Consolidating Statements of Operations

[0000950123-11-091697:notes:181]
For the Three Months Ended September 30, 2011

[0000950123-11-091697:notes:182]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 722.4 |  |  | $ | 255.3 |  |  | $ | (54.7 | ) |  | $ | 923.0 |  |
| COST OF GOODS SOLD |  |  | — |  |  |  | 555.5 |  |  |  | 191.6 |  |  |  | (55.2 | ) |  |  | 691.9 |  |
| Gross profit |  |  | — |  |  |  | 166.9 |  |  |  | 63.7 |  |  |  | 0.5 |  |  |  | 231.1 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses. |  |  | — |  |  |  | 124.8 |  |  |  | 41.5 |  |  |  | — |  |  |  | 166.3 |  |
| Losses (gains) and other expenses, net |  |  | 2.3 |  |  |  | 0.4 |  |  |  | (0.2 | ) |  |  | — |  |  |  | 2.5 |  |
| Restructuring charges |  |  | — |  |  |  | 9.9 |  |  |  | 0.9 |  |  |  | — |  |  |  | 10.8 |  |
| (Income) loss from equity method investments |  |  | (48.0 | ) |  |  | (11.1 | ) |  |  | (2.1 | ) |  |  | 58.2 |  |  |  | (3.0 | ) |
| Operational income (loss) from continuing operations |  |  | 45.7 |  |  |  | 42.9 |  |  |  | 23.6 |  |  |  | (57.7 | ) |  |  | 54.5 |  |
| INTEREST EXPENSE, net |  |  | 4.4 |  |  |  | (0.9 | ) |  |  | 0.6 |  |  |  | — |  |  |  | 4.1 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Income (loss) from continuing operations before income taxes |  |  | 41.3 |  |  |  | 43.8 |  |  |  | 23.0 |  |  |  | (57.7 | ) |  |  | 50.4 |  |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (2.3 | ) |  |  | 11.1 |  |  |  | 7.6 |  |  |  | 0.2 |  |  |  | 16.6 |  |
| Net income (loss) |  | $ | 43.6 |  |  | $ | 32.7 |  |  | $ | 15.4 |  |  | $ | (57.9 | ) |  | $ | 33.8 |  |

[0000950123-11-091697:notes:183]
For the Nine Months Ended September 30, 2011

[0000950123-11-091697:notes:184]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 1,983.2 |  |  | $ | 715.7 |  |  | $ | (151.2 | ) |  | $ | 2,547.7 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 1,515.0 |  |  |  | 541.2 |  |  |  | (152.4 | ) |  |  | 1,903.9 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 468.2 |  |  |  | 174.5 |  |  |  | 1.2 |  |  |  | 643.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 383.2 |  |  |  | 132.0 |  |  |  | — |  |  |  | 515.2 |  |
| Losses (gains) and other expenses, net |  |  | 4.5 |  |  |  | (0.8 | ) |  |  | (0.6 | ) |  |  | — |  |  |  | 3.1 |  |
| Restructuring charges |  |  | — |  |  |  | 13.1 |  |  |  | 1.3 |  |  |  | — |  |  |  | 14.4 |  |
| (Income) loss from equity method investments |  |  | (96.9 | ) |  |  | (16.8 | ) |  |  | (7.0 | ) |  |  | 111.8 |  |  |  | (8.9 | ) |
| Operational income (loss) from continuing operations |  |  | 92.3 |  |  |  | 89.5 |  |  |  | 48.8 |  |  |  | (110.6 | ) |  |  | 120.0 |  |
| INTEREST EXPENSE, net |  |  | 12.4 |  |  |  | (2.7 | ) |  |  | 2.8 |  |  |  | — |  |  |  | 12.5 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 79.9 |  |  |  | 92.2 |  |  |  | 45.9 |  |  |  | (110.6 | ) |  |  | 107.4 |  |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (5.8 | ) |  |  | 25.6 |  |  |  | 15.5 |  |  |  | 0.5 |  |  |  | 35.8 |  |
| Net income (loss) |  | $ | 85.7 |  |  | $ | 66.6 |  |  | $ | 30.4 |  |  | $ | (111.1 | ) |  | $ | 71.6 |  |

[0000950123-11-091697:notes:185]
As of December 31, 2010

[0000950123-11-091697:notes:186]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 81.1 |  |  | $ | 14.7 |  |  | $ | 64.2 |  |  | $ | — |  |  | $ | 160.0 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 12.2 |  |  |  | — |  |  |  | 12.2 |  |
| Accounts and notes receivable, net |  |  | (1,169.7 | ) |  |  | 933.3 |  |  |  | 613.2 |  |  |  | 8.0 |  |  |  | 384.8 |  |
| Inventories, net |  |  | — |  |  |  | 163.7 |  |  |  | 128.7 |  |  |  | (6.2 | ) |  |  | 286.2 |  |
| Deferred income taxes, net |  |  | — |  |  |  | 27.6 |  |  |  | 12.1 |  |  |  | (3.0 | ) |  |  | 36.7 |  |
| Other assets |  |  | 19.3 |  |  |  | 21.0 |  |  |  | 121.2 |  |  |  | (94.5 | ) |  |  | 67.0 |  |
| Total current assets |  |  | (1,069.3 | ) |  |  | 1,160.3 |  |  |  | 951.6 |  |  |  | (95.7 | ) |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 202.8 |  |  |  | 121.6 |  |  |  | (0.1 | ) |  |  | 324.3 |  |
| GOODWILL |  |  | — |  |  |  | 50.8 |  |  |  | 225.8 |  |  |  | (4.8 | ) |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | — |  |  |  | 77.3 |  |  |  | 22.6 |  |  |  | (12.7 | ) |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 2,068.3 |  |  |  | 415.6 |  |  |  | 51.8 |  |  |  | (2,473.9 | ) |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 31.1 |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | (31.5 | ) |  | $ | 1.4 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |
| Accounts payable |  |  | 8.1 |  |  |  | 133.1 |  |  |  | 131.0 |  |  |  | 1.6 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 6.6 |  |  |  | 262.0 |  |  |  | 115.5 |  |  |  | (49.6 | ) |  |  | 334.5 |  |
| Income taxes payable |  |  | (36.1 | ) |  |  | 30.6 |  |  |  | 28.3 |  |  |  | (17.5 | ) |  |  | 5.3 |  |
| Total current liabilities |  |  | 9.7 |  |  |  | 425.9 |  |  |  | 277.0 |  |  |  | (97.0 | ) |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 300.0 |  |  |  | 5.4 |  |  |  | 139.6 |  |  |  | (128.0 | ) |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 15.9 |  |  |  | — |  |  |  | — |  |  |  | 15.9 |  |
| PENSIONS |  |  | — |  |  |  | 77.4 |  |  |  | 10.7 |  |  |  | — |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 5.8 |  |  |  | 46.8 |  |  |  | 25.9 |  |  |  | (12.8 | ) |  |  | 65.7 |  |
| Total liabilities |  |  | 315.5 |  |  |  | 571.4 |  |  |  | 453.2 |  |  |  | (237.8 | ) |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 683.5 |  |  |  | 1,335.4 |  |  |  | 920.2 |  |  |  | (2,349.4 | ) |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |

[0000950123-11-091697:notes:187]
For the Three Months Ended September 30, 2010

[0000950123-11-091697:notes:188]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 563.0 |  |  | $ | 318.8 |  |  | $ | (63.6 | ) |  | $ | 818.2 |  |
| COST OF GOODS SOLD |  |  | 0.1 |  |  |  | 413.4 |  |  |  | 233.6 |  |  |  | (61.7 | ) |  |  | 585.4 |  |
| Gross profit |  |  | (0.1 | ) |  |  | 149.6 |  |  |  | 85.2 |  |  |  | (1.9 | ) |  |  | 232.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses. |  |  | — |  |  |  | 120.0 |  |  |  | 43.5 |  |  |  | — |  |  |  | 163.5 |  |
| Losses (gains) and other expenses, net |  |  | (1.5 | ) |  |  | 2.1 |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.8 |  |
| Restructuring charges |  |  | — |  |  |  | 0.8 |  |  |  | 3.8 |  |  |  | 0.1 |  |  |  | 4.7 |  |
| (Income) loss from equity method investments |  |  | (52.6 | ) |  |  | (4.1 | ) |  |  | (2.8 | ) |  |  | 56.7 |  |  |  | (2.8 | ) |
| Operational income (loss) from continuing operations |  |  | 54.0 |  |  |  | 30.8 |  |  |  | 40.4 |  |  |  | (58.6 | ) |  |  | 66.6 |  |
| INTEREST EXPENSE, net |  |  | 8.9 |  |  |  | (5.9 | ) |  |  | 0.5 |  |  |  | — |  |  |  | 3.5 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Income (loss) from continuing operations before income taxes |  |  | 45.1 |  |  |  | 36.7 |  |  |  | 39.9 |  |  |  | (58.6 | ) |  |  | 63.1 |  |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (2.7 | ) |  |  | 12.1 |  |  |  | 11.9 |  |  |  | (0.1 | ) |  |  | 21.2 |  |
| Income (loss) from continuing operations |  |  | 47.8 |  |  |  | 24.6 |  |  |  | 28.0 |  |  |  | (58.5 | ) |  |  | 41.9 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Net income (loss) |  | $ | 47.8 |  |  | $ | 24.6 |  |  | $ | 27.9 |  |  | $ | (58.5 | ) |  | $ | 41.8 |  |

[0000950123-11-091697:notes:189]
For the Nine Months Ended September 30, 2010

[0000950123-11-091697:notes:190]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 1,606.7 |  |  | $ | 922.9 |  |  | $ | (195.2 | ) |  | $ | 2,334.4 |  |
| COST OF GOODS SOLD |  |  | 0.2 |  |  |  | 1,170.9 |  |  |  | 684.7 |  |  |  | (193.2 | ) |  |  | 1,662.6 |  |
| Gross profit |  |  | (0.2 | ) |  |  | 435.8 |  |  |  | 238.2 |  |  |  | (2.0 | ) |  |  | 671.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 367.3 |  |  |  | 145.7 |  |  |  | — |  |  |  | 513.0 |  |
| Losses (gains) and other expenses, net |  |  | (0.1 | ) |  |  | 6.6 |  |  |  | (0.2 | ) |  |  | — |  |  |  | 6.3 |  |
| Restructuring charges |  |  | — |  |  |  | 4.0 |  |  |  | 11.0 |  |  |  | — |  |  |  | 15.0 |  |
| (Income) loss from equity method investments |  |  | (103.8 | ) |  |  | (7.6 | ) |  |  | (8.9 | ) |  |  | 111.4 |  |  |  | (8.9 | ) |
| Operational income (loss) from continuing operations |  |  | 103.7 |  |  |  | 65.5 |  |  |  | 90.6 |  |  |  | (113.4 | ) |  |  | 146.4 |  |
| INTEREST EXPENSE, net |  |  | 8.9 |  |  |  | (2.1 | ) |  |  | 2.3 |  |  |  | — |  |  |  | 9.1 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Income (loss) from continuing operations before income taxes |  |  | 94.8 |  |  |  | 67.6 |  |  |  | 88.2 |  |  |  | (113.4 | ) |  |  | 137.2 |  |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (3.3 | ) |  |  | 22.2 |  |  |  | 29.0 |  |  |  | — |  |  |  | 47.9 |  |
| Income (loss) from continuing operations |  |  | 98.1 |  |  |  | 45.4 |  |  |  | 59.2 |  |  |  | (113.4 | ) |  |  | 89.3 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.8 |  |  |  | — |  |  |  | 0.8 |  |
| Net income (loss) |  | $ | 98.1 |  |  | $ | 45.4 |  |  | $ | 58.4 |  |  | $ | (113.4 | ) |  | $ | 88.5 |  |

[0000950123-11-091697:notes:191]
Condensed Consolidating Statements of Cash Flows

[0000950123-11-091697:notes:192]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | 31.8 |  |  | $ | (64.1 | ) |  | $ | 30.1 |  |  | $ | — |  |  | $ | (2.2 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.3 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (23.6 | ) |  |  | (3.5 | ) |  |  | — |  |  |  | (27.1 | ) |
| Proceeds from sale of business |  |  | — |  |  |  | — |  |  |  | 0.6 |  |  |  | — |  |  |  | 0.6 |  |
| Acquisition of business |  |  | — |  |  |  | (147.7 | ) |  |  | — |  |  |  | — |  |  |  | (147.7 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 12.2 |  |  |  | — |  |  |  | 12.2 |  |
| Net cash used in investing activities |  |  | — |  |  |  | (171.2 | ) |  |  | 9.5 |  |  |  | — |  |  |  | (161.7 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 2.5 |  |  |  | — |  |  |  | 2.5 |  |
| Asset securitization borrowings |  |  | — |  |  |  | — |  |  |  | 220.0 |  |  |  | — |  |  |  | 220.0 |  |
| Asset securitization payments |  |  | — |  |  |  | — |  |  |  | (220.0 | ) |  |  | — |  |  |  | (220.0 | ) |
| Long-term payments |  |  | — |  |  |  | (0.7 | ) |  |  | — |  |  |  | — |  |  |  | (0.7 | ) |
| Revolver long-term borrowings |  |  | 1,090.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,090.0 |  |
| Revolver long-term payments |  |  | (911.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (911.5 | ) |
| Proceeds from stock option exercises |  |  | 1.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.5 |  |
| Repurchases of common stock |  |  | (90.9 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (90.9 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.5 |  |
| Intercompany debt |  |  | 76.7 |  |  |  | (2.3 | ) |  |  | (74.4 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (252.7 | ) |  |  | 242.7 |  |  |  | 10.0 |  |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (27.2 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (27.2 | ) |
| Net cash (used in) provided by financing activities |  |  | (112.6 | ) |  |  | 239.7 |  |  |  | (61.9 | ) |  |  | — |  |  |  | 65.2 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | (80.8 | ) |  |  | 4.4 |  |  |  | (22.3 | ) |  |  | — |  |  |  | (98.7 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | (3.4 | ) |  |  | — |  |  |  | (3.4 | ) |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 81.1 |  |  |  | 14.7 |  |  |  | 64.2 |  |  |  | — |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | 0.3 |  |  | $ | 19.1 |  |  | $ | 38.5 |  |  | $ | — |  |  | $ | 57.9 |  |

[0000950123-11-091697:notes:193]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | (89.4 | ) |  | $ | 158.2 |  |  | $ | (25.2 | ) |  | $ | — |  |  | $ | 43.6 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | 0.1 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (23.2 | ) |  |  | (6.8 | ) |  |  | — |  |  |  | (30.0 | ) |
| Proceeds from sale of business |  |  | — |  |  |  | 0.1 |  |  |  | 3.4 |  |  |  | — |  |  |  | 3.5 |  |
| Acquisition of business |  |  | — |  |  |  | (6.0 | ) |  |  | — |  |  |  | — |  |  |  | (6.0 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | (13.1 | ) |  |  | — |  |  |  | (13.1 | ) |
| Net cash used in investing activities |  |  | — |  |  |  | (29.0 | ) |  |  | (16.5 | ) |  |  | — |  |  |  | (45.5 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 5.7 |  |  |  | — |  |  |  | 5.7 |  |
| Long-term payments |  |  | (35.0 | ) |  |  | (0.1 | ) |  |  | (0.7 | ) |  |  | — |  |  |  | (35.8 | ) |
| Issuance of senior unsecured notes. |  |  | 199.8 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 199.8 |  |
| Revolver long-term borrowings |  |  | 875.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 875.0 |  |
| Revolver long-term payments |  |  | (906.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (906.5 | ) |
| Additional investment in affiliates |  |  | — |  |  |  | — |  |  |  | (1.0 | ) |  |  | — |  |  |  | (1.0 | ) |
| Proceeds from stock option exercises |  |  | 2.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2.5 |  |
| Payments of deferred financing costs |  |  | (1.8 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.8 | ) |
| Repurchases of common stock |  |  | (150.3 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (150.3 | ) |
| Excess tax benefits related to share-based payments |  |  | 3.7 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3.7 |  |
| Intercompany debt |  |  | 82.5 |  |  |  | (102.6 | ) |  |  | 20.1 |  |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | 42.8 |  |  |  | (15.3 | ) |  |  | (27.5 | ) |  |  | — |  |  |  | — |  |
| Intercompany investments |  |  | (7.9 | ) |  |  | — |  |  |  | 7.9 |  |  |  | — |  |  |  | — |  |
| Intercompany dividends |  |  | 9.0 |  |  |  | — |  |  |  | (9.0 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (24.4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (24.4 | ) |
| Net cash (used in) provided by financing activities |  |  | 89.4 |  |  |  | (118.0 | ) |  |  | (4.5 | ) |  |  | — |  |  |  | (33.1 | ) |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | 11.2 |  |  |  | (46.2 | ) |  |  | — |  |  |  | (35.0 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 3.1 |  |  |  | — |  |  |  | 3.1 |  |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 0.8 |  |  |  | 6.6 |  |  |  | 116.9 |  |  |  | — |  |  |  | 124.3 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | 0.8 |  |  | $ | 17.8 |  |  | $ | 73.8 |  |  | $ | — |  |  | $ | 92.4 |  |
