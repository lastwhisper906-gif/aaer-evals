# LII MD&A — 0000950123-11-091697


## mdna

[0000950123-11-091697:mdna:1]
| Item 2. |  | Management’s Discussion and Analysis of Financial Condition and Results of Operations. |

[0000950123-11-091697:mdna:2]
[same as prior period, unchanged from 0000950123-11-068216:mdna:2]

[0000950123-11-091697:mdna:3]
We operate in four reportable business segments of the heating, ventilation, air
conditioning and refrigeration (‘HVACR’) industry. Our reportable segments consist of
Residential Heating & Cooling, Commercial Heating & Cooling, Service Experts and Refrigeration.
For more detailed information regarding our reportable segments, see Note 15 in the Notes to our
Consolidated Financial Statements.

[0000950123-11-091697:mdna:4]
Our fiscal year ends on December 31 and our interim fiscal quarters are each comprised of
13 weeks. For convenience, throughout this Management’s Discussion and Analysis of Financial
Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are
denoted by the last day of the calendar quarter.

[0000950123-11-091697:mdna:5]
Our products and services are sold through a combination of distributors, independent and
company-owned dealer service centers, other installing contractors, wholesalers, manufacturers’
representatives, original equipment manufacturers and directly to national account customers. The
demand for our products and services is seasonal and dependent on the weather. Warmer than normal
summer temperatures generate strong demand for replacement air conditioning and refrigeration
products and services and colder than normal winter temperatures have the same effect on heating
products and services. Conversely, cooler than normal summers and warmer than normal winters
depress the demand for HVACR products and services. In addition to weather, demand for our
products and services is influenced by national and regional economic and demographic factors, such
as interest rates, the availability of financing, regional population and employment trends, new
construction, general economic conditions and consumer spending habits and confidence.

[0000950123-11-091697:mdna:6]
[same as prior period, unchanged from 0000950123-11-068216:mdna:6]

[0000950123-11-091697:mdna:7]
[same as prior period, unchanged from 0000950123-11-068216:mdna:7]

[0000950123-11-091697:mdna:8]
We experienced similar challenges in the third quarter of 2011 as we did in the second quarter
of 2011, particularly in our Residential Heating & Cooling and Service Experts segments. The
significant reduction in the government tax credit for high-efficiency heating and cooling products
and overall consumer weakness in 2011 shifted our customers to replacement of components rather
than entire system replacements resulting in unfavorable product mix in our Residential Heating &
Cooling and Service Experts businesses. This unfavorable shift in product mix for these businesses
was the biggest driver in our decline in operational income in the third

[0000950123-11-091697:mdna:9]
quarter of 2011, which was
down 18% from the third quarter of 2010. However, we did see a positive shift in volume in our
Residential Heating & Cooling business in the third quarter of 2011 primarily through an increase
in our component sales. This positive shift in volume along with net sales growth from our
Commercial Heating & Cooling and Refrigeration businesses resulted in an increase in our net sales
from $818 million in the third quarter of 2010 to $923 million in the third quarter of 2011, or a
13% increase. Excluding Kysor/Warren and currency impact, our net sales increased by 2%. Our
Commercial Heating & Cooling business showed strong growth in the quarter with a 13% growth in net
sales, largely driven by volume and price and mix. The Refrigeration segment also showed strong
growth with a 59% increase in net sales for the quarter. The increase in net sales for this
segment was comprised of organic growth of 2%, excluding a 7% impact of foreign currency exchange
rates, with the remainder of the growth from the acquisition of the Kysor/Warren business in
January 2011.

[0000950123-11-091697:mdna:10]
We are seeing margin pressure in all of our segments largely driven by commodity prices
putting a strain on raw material and component costs. Margins were also negatively affected by mix
from our Residential Heating & Cooling and Service Experts businesses discussed above. We are
managing our pricing structure to offset a large portion of our commodity price increases on raw
materials. We believe we are managing our other costs well and continue to look for ways to lower
our controllable cost structure through manufacturing and sourcing excellence.

[0000950123-11-091697:mdna:11]
[same as prior period, unchanged from 0000950123-11-068216:mdna:11]

[0000950123-11-091697:mdna:12]
|  | • |  | Net sales for the third quarter of 2011 increased to $923 million as compared to $818 million in 2010, or a 13% increase. The Kysor/Warren acquisition contributed 9% to the net sales growth and favorable currency exchange rates positively impacted our growth by 2%. Organically, sales for LII increased by 2% which excludes Kysor/Warren and currency impact. |
|  | • |  | Operational income for the third quarter of 2011 decreased to $54.5 million as compared to $66.6 million in 2010. The decline in operational income was primarily due to lower price and mix and lower margins from increased commodity costs from raw materials and components. |
|  | • |  | Net income for the third quarter of 2011 was $33.8 million compared to $41.8 million in 2010. Diluted earnings per share from continuing operations were $0.64 in the third quarter of 2011 compared to diluted earnings per share from continuing operations of $0.76 in 2010. |
|  | • |  | Cash of $2.2 million was used in operating activities for the first nine months of 2011 compared to cash provided by operating activities of $43.6 million in the first nine months of 2010. The increase in cash used in operating activities was due to lower net income, an unfavorable change in accrued expenses with favorable working capital partially offsetting these items. |
|  | • |  | During the first nine months of 2011, we returned $116.8 million to shareholders through share repurchases and dividends. |

[0000950123-11-091697:mdna:13]
31

[0000950123-11-091697:mdna:14]
Third Quarter of 2011 Compared to Third Quarter of 2010 – Consolidated Results

[0000950123-11-091697:mdna:15]
[same as prior period, unchanged from 0000950123-11-068216:mdna:15]

[0000950123-11-091697:mdna:16]
[same as prior period, unchanged from 0000950123-11-068216:mdna:16]

[0000950123-11-091697:mdna:17]
|  |  | Three Months Ended September 30, |  |
|  |  |  |  |  |  |  |  |  |  | Percent |  |  |  |  |
|  |  | Dollars |  |  | Change |  |  | Percent Sales |  |
|  |  | 2011 |  |  | 2010 |  |  | Fav/(Unfav) |  |  | 2011 |  |  | 2010 |  |
| Net sales |  | $ | 923.0 |  |  | $ | 818.2 |  |  |  | 12.8 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 691.9 |  |  |  | 585.4 |  |  |  | (18.2 | ) |  |  | 75.0 |  |  |  | 71.5 |  |
| Gross profit |  |  | 231.1 |  |  |  | 232.8 |  |  |  | (0.7 | ) |  |  | 25.0 |  |  |  | 28.5 |  |
| Selling, general and administrative expenses |  |  | 166.3 |  |  |  | 163.5 |  |  |  | (1.7 | ) |  |  | 18.0 |  |  |  | 20.0 |  |
| Losses and other expenses, net |  |  | 2.5 |  |  |  | 0.8 |  |  |  | (212.5 | ) |  |  | 0.3 |  |  |  | 0.1 |  |
| Restructuring charges |  |  | 10.8 |  |  |  | 4.7 |  |  |  | (129.8 | ) |  |  | 1.2 |  |  |  | 0.6 |  |
| Income from equity method investments |  |  | (3.0 | ) |  |  | (2.8 | ) |  |  | 7.1 |  |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Operational income |  | $ | 54.5 |  |  | $ | 66.6 |  |  |  | (18.2 | )% |  |  | 5.8 | % |  |  | 8.1 | % |
| Net income |  | $ | 33.8 |  |  | $ | 41.8 |  |  |  | (19.1 | )% |  |  | 3.7 | % |  |  | 5.1 | % |

[0000950123-11-091697:mdna:18]
[same as prior period, unchanged from 0000950123-11-068216:mdna:18]

[0000950123-11-091697:mdna:19]
Net sales increased 13% in the third quarter of 2011 compared to the third quarter of 2010.
The Kysor/Warren acquisition added 9% to our net sales. Our sales volume was up 2% and price and
mix were flat in the comparable period. We saw positive volume in our Residential Heating &
Cooling, Commercial Heating & Cooling and Refrigeration segments partially offset by declines in
volume in our Service Experts segment. Changes in foreign currency exchange rates favorably
impacted net sales by 2%. Excluding the impact from the Kysor/Warren acquisition and favorable
foreign currency exchange rates, net sales in the third quarter of 2011 were up 2% from the third
quarter of 2010.

[0000950123-11-091697:mdna:20]
[same as prior period, unchanged from 0000950123-11-068216:mdna:20]

[0000950123-11-091697:mdna:21]
Gross profit declined $2 million in the third quarter of 2011 compared to 2010 resulting in a
350 basis point decline in margins from 28.5% in 2010 to 25.0% in
2011. Commodity cost impact on our
raw materials and component products contributed 160 basis points and mix contributed 20 basis
points to the decline. Additionally, the Kysor/Warren acquisition negatively impacted our gross
profit margin by 150 basis points in the third quarter of 2011.

[0000950123-11-091697:mdna:22]
[same as prior period, unchanged from 0000950123-11-068216:mdna:22]

[0000950123-11-091697:mdna:23]
Selling, general and administrative (“SG&A”) expenses increased $3 million in the third
quarter of 2011 compared to 2010, but as a percentage of net sales, SG&A expenses declined to 18%
in 2011 from 20% in 2010. At constant currency, SG&A decreased $1 million in 2011 compared to
2010. The decline in SG&A expenses was principally due to a $2 million decline in 2011 variable
compensation expense and general cost control in the quarter largely offset by Kysor/Warren SG&A
expenses included in 2011.

[0000950123-11-091697:mdna:24]
[same as prior period, unchanged from 0000950123-11-068216:mdna:24]

[0000950123-11-091697:mdna:25]
Losses and other expenses, net for the third quarters of 2011 and 2010 included the following
(in millions):

[0000950123-11-091697:mdna:26]
|  |  | Three Months Ended |  |
|  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Realized gains on settled futures contracts |  | $ | (0.1 | ) |  | $ | (0.2 | ) |
| Unrealized losses (gains) on unsettled futures contracts not designated as cash flow hedges |  |  | 3.5 |  |  |  | (1.4 | ) |
| Special legal contingency charge |  |  | (0.1 | ) |  |  | 1.8 |  |
| Foreign currency exchange (gains) losses |  |  | (0.5 | ) |  |  | 0.6 |  |
| Other items, net |  |  | (0.3 | ) |  |  | — |  |
| Losses and other expenses, net |  | $ | 2.5 |  |  | $ | 0.8 |  |

[0000950123-11-091697:mdna:27]
The change in losses and other expenses, net is primarily due to the unrealized losses on
unsettled future commodity contracts. Refer to Note 5 in the Notes to the Consolidated Financial
Statements for more information.

[0000950123-11-091697:mdna:28]
[same as prior period, unchanged from 0000950123-11-068216:mdna:28]

[0000950123-11-091697:mdna:29]
Restructuring charges increased from $5 million in the third quarter of 2010 to $11
million in the third quarter of 2011. The charges in the third quarter of 2011 were from corporate
restructuring that included the exit of the corporate airplane lease, closure of the aviation
department, and reorganization of certain support function initiated in the third quarter of 2011.
Additionally, we had charges related to the reorganization of the Service Experts administrative
function and management structure initiated in the fourth quarter of 2010. The restructuring
charges from the third quarter of 2010 were primarily related to the exit of the contract coil
manufacturing in our Refrigeration segment in Australia. The remaining restructuring charges from
the third quarter of 2010 were minor
charges from various open projects initiated in 2010 and prior
years. Refer to Note 13 in the Notes to the Consolidated Financial Statements for more
information.

[0000950123-11-091697:mdna:30]
[same as prior period, unchanged from 0000950123-11-068216:mdna:30]

[0000950123-11-091697:mdna:31]
Investments over which we do not exercise control but have significant influence are accounted
for using the equity method of accounting. Income from equity method investments increased
slightly to $3.0 million in the third quarter of 2011 from $2.8 million in 2010.

[0000950123-11-091697:mdna:32]
[same as prior period, unchanged from 0000950123-11-068216:mdna:32]

[0000950123-11-091697:mdna:33]
Interest expense, net, increased to $4.1 million in 2011 from $3.5 million in 2010. The
increase in interest expense was primarily attributable to the increase in average amounts borrowed
in the third quarter of 2011 compared to 2010 and an increase in our weighted average interest rate
in the comparable period.

[0000950123-11-091697:mdna:34]
[same as prior period, unchanged from 0000950123-11-068216:mdna:34]

[0000950123-11-091697:mdna:35]
Income tax expense was $17 million in the third quarter of 2011 compared $21 million in 2010.
The effective tax rate was 32.9% for 2011 and 33.6% in 2010. Our effective rates differ from the
statutory federal rate of 35% for certain items, such as research tax credits, foreign taxes at
rates other than 35%, and other permanent items.

[0000950123-11-091697:mdna:36]
Third Quarter of 2011 Compared to Third Quarter of 2010 – Results by Segment

[0000950123-11-091697:mdna:37]
[same as prior period, unchanged from 0000950123-11-068216:mdna:37]

[0000950123-11-091697:mdna:38]
The following table summarizes our Residential Heating & Cooling segment’s net sales and
profit for the third quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-091697:mdna:39]
|  |  | Three Months Ended |  |  |  |  |  |  |  |
|  |  | September 30, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 373.6 |  |  | $ | 370.9 |  |  | $ | 2.7 |  |  |  | 0.7 | % |
| Profit |  |  | 28.8 |  |  |  | 39.0 |  |  |  | (10.2 | ) |  |  | (26.2 | )% |
| % of net sales |  |  | 7.7 | % |  |  | 10.5 | % |  |  |  |  |  |  |  |  |

[0000950123-11-091697:mdna:40]
Residential Heating & Cooling net sales increased by almost 1% in the third quarter of 2011
compared to the third quarter of 2010. Sales volumes increased by almost 4% which was almost fully
offset with the decline in price and mix in the third quarter of 2011 when compared to the
comparable period in 2010. A favorable impact from foreign currency exchange rates of 1% increased
net sales. Mix was 5% unfavorable in the quarter due to the move from replacement of systems to
component replacement from a lower government high-efficiency tax credit and consumer weakness in
2011.

[0000950123-11-091697:mdna:41]
Segment profit
decreased $10 million, including $10 million from a decline in price and mix,
$9 million from commodity cost impact on both raw material and component purchases. Partially
offsetting this decline was a $5 million decrease in SG&A expense, a $5 million increase in volume,
and $2 million from favorable foreign currency translation rates. The SG&A expense decrease was
primarily due to lower variable compensation expense and general cost control in 2011.

[0000950123-11-091697:mdna:42]
[same as prior period, unchanged from 0000950123-11-068216:mdna:42]

[0000950123-11-091697:mdna:43]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit
for the third quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-091697:mdna:44]
|  |  | Three Months Ended |  |  |  |  |  |  |  |
|  |  | September 30, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 199.3 |  |  | $ | 176.3 |  |  | $ | 23.0 |  |  |  | 13.0 | % |
| Profit |  |  | 28.7 |  |  |  | 24.9 |  |  |  | 3.8 |  |  |  | 15.3 | % |
| % of net sales |  |  | 14.4 | % |  |  | 14.1 | % |  |  |  |  |  |  |  |  |

[0000950123-11-091697:mdna:45]
Our Commercial Heating & Cooling business experienced a 13% increase in net sales in the third
quarter of 2011 compared to 2010 primarily due to an increase in our replacement business which
resulted in a 3% increase in sales volume and a 7% increase in price and mix. Mix was driven by
strength in our high efficiency premier products like Strategos® and
Energence®. Changes in foreign currency exchange rates favorably impacted sales by 3%.

[0000950123-11-091697:mdna:46]
Segment profit for the third quarter of 2011 increased almost $4 million, including a $2
million increase in volume, a $5 million increase in price and mix, and a $2 million decrease in
SG&A expenses. The decline in SG&A expenses was primarily due to variable compensation and general
cost control. Increased commodity costs of $5 million on raw material and component costs partially
offset the increases to segment profit.

[0000950123-11-091697:mdna:47]
[same as prior period, unchanged from 0000950123-11-068216:mdna:47]

[0000950123-11-091697:mdna:48]
The following table summarizes our Service Experts segment’s net sales and profit for the
third quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-091697:mdna:49]
|  |  | Three Months Ended |  |  |  |  |  |  |  |
|  |  | September 30, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 144.7 |  |  | $ | 150.9 |  |  | $ | (6.2 | ) |  |  | (4.1 | )% |
| Profit |  |  | 5.4 |  |  |  | 6.0 |  |  |  | (0.6 | ) |  |  | (10.0 | )% |
| % of net sales |  |  | 3.7 | % |  |  | 4.0 | % |  |  |  |  |  |  |  |  |

[0000950123-11-091697:mdna:50]
Service
Experts net sales declined 4% in the third quarter of 2011 compared to the third
quarter of 2010. Sales volumes contributed 7% to the decline in sales. Offsetting the decline in
sales volume was 2% in favorable price and mix and 1% in favorable foreign currency exchange rates. The
decline in this segment’s
sales volume is primarily due to a decline in residential HVAC equipment installations.

[0000950123-11-091697:mdna:51]
Segment profit decreased $1 million due to a $5 million decline in volume, partially offset by
a $4 million decline in SG&A expenses. The decline in SG&A expenses is primarily due to lower
variable compensation.

[0000950123-11-091697:mdna:52]
[same as prior period, unchanged from 0000950123-11-068216:mdna:52]

[0000950123-11-091697:mdna:53]
The following table summarizes our Refrigeration segment’s net sales and profit for the third
quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-091697:mdna:54]
|  |  | Three Months Ended |  |  |  |  |  |  |  |
|  |  | September 30, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 223.7 |  |  | $ | 140.6 |  |  | $ | 83.1 |  |  |  | 59.1 | % |
| Profit |  |  | 20.5 |  |  |  | 17.3 |  |  |  | 3.2 |  |  |  | 18.5 | % |
| % of net sales |  |  | 9.2 | % |  |  | 12.3 | % |  |  |  |  |  |  |  |  |

[0000950123-11-091697:mdna:55]
Net sales, excluding Kysor/Warren and foreign currency impact, increased 2% in the third
quarter of 2011 when compared to 2010 due to a 1% increase in sales volume and a 1% increase in
price and mix. Favorable foreign exchange rates accounted for 7% of the increase in net sales and
the Kysor/Warren acquisition contributed 50% to the increase in net sales.

[0000950123-11-091697:mdna:56]
Segment profit increased $3 million primarily due to a $1 million increase in volume, a $3
million increase in our price and mix and $1 million in favorable foreign currency translation
rates. Partially offsetting these increases was SG&A, excluding Kysor/Warren SG&A, of $2 million
primarily due to higher variable compensation.

[0000950123-11-091697:mdna:57]
[same as prior period, unchanged from 0000950123-11-068216:mdna:57]

[0000950123-11-091697:mdna:58]
Corporate and other expenses were flat at $15 million in the third quarter of 2011 compared to
the third quarter of 2010.

[0000950123-11-091697:mdna:59]
Year-to-Date through September 30, 2011 Compared to Year-to-Date through September 30, 2010 –
Consolidated Results

[0000950123-11-091697:mdna:60]
[same as prior period, unchanged from 0000950123-11-068216:mdna:60]

[0000950123-11-091697:mdna:61]
[same as prior period, unchanged from 0000950123-11-068216:mdna:61]

[0000950123-11-091697:mdna:62]
|  |  | Nine Months Ended September 30, |  |
|  |  |  |  |  |  |  |  |  |  | Percent |  |  |  |  |
|  |  | Dollars |  |  | Change |  |  | Percent Sales |  |
|  |  | 2011 |  |  | 2010 |  |  | Fav/(Unfav) |  |  | 2011 |  |  | 2010 |  |
| Net sales |  | $ | 2,547.7 |  |  | $ | 2,334.4 |  |  |  | 9.1 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 1,903.9 |  |  |  | 1,662.6 |  |  |  | (14.5 | ) |  |  | 74.7 |  |  |  | 71.2 |  |
| Gross profit |  |  | 643.8 |  |  |  | 671.8 |  |  |  | (4.2 | ) |  |  | 25.3 |  |  |  | 28.8 |  |
| Selling, general and administrative expenses |  |  | 515.2 |  |  |  | 513.0 |  |  |  | (0.4 | ) |  |  | 20.2 |  |  |  | 22.0 |  |
| Losses and other expenses, net |  |  | 3.1 |  |  |  | 6.3 |  |  |  | 50.8 |  |  |  | 0.1 |  |  |  | 0.3 |  |
| Restructuring charges |  |  | 14.4 |  |  |  | 15.0 |  |  |  | 4.0 |  |  |  | 0.6 |  |  |  | 0.6 |  |
| Income from equity method investments |  |  | (8.9 | ) |  |  | (8.9 | ) |  |  | — |  |  |  | (0.3 | ) |  |  | (0.4 | ) |
| Operational income |  | $ | 120.0 |  |  | $ | 146.4 |  |  |  | (18.0 | )% |  |  | 4.7 | % |  |  | 6.3 | % |
| Net income |  | $ | 71.6 |  |  | $ | 88.5 |  |  |  | (19.1 | )% |  |  | 2.8 | % |  |  | 3.8 | % |

[0000950123-11-091697:mdna:63]
[same as prior period, unchanged from 0000950123-11-068216:mdna:63]

[0000950123-11-091697:mdna:64]
Net sales increased 9% in the first nine months of 2011 compared to the first nine months of
2010. The Kysor/Warren acquisition added 7% to our net sales. Our price and mix were up 1% while
sales volume was down 1% in the comparable period. The decline in volume was predominantly in our
Residential Heating & Cooling and Service Experts segments partially offset by volume growth in our
Commercial Heating & Cooling and Refrigeration segments. Changes in foreign currency exchange
rates favorably impacted net sales by 2%. Excluding the favorable impact from the Kysor/Warren
acquisition and foreign currency exchange rates, our net sales for the first nine months of 2011
were flat compared to the first nine months of 2010.

[0000950123-11-091697:mdna:65]
[same as prior period, unchanged from 0000950123-11-068216:mdna:65]

[0000950123-11-091697:mdna:66]
Gross profit declined $28 million in the first nine months of 2011 compared to 2010 resulting
in a 350 basis point decline in margins from 28.8% in 2010 to 25.3%
in 2011. The impact from commodity costs
on both raw material and components contributed approximately 180 basis points to the decline with
freight and distribution contributing 70 basis points to the decline in gross profit margin.
Additionally, the Kysor/Warren acquisition has negatively impacted our gross profit margin by
approximately 130 basis points in the first nine months of 2011.

[0000950123-11-091697:mdna:67]
[same as prior period, unchanged from 0000950123-11-068216:mdna:68]

[0000950123-11-091697:mdna:68]
SG&A expenses increased by $2 million in the first nine months of 2011 compared to 2010, but
as a percentage of net sales, SG&A expenses declined to 20% in 2011 from 22% in 2010. The increase
in SG&A expenses was principally due to $12 million in unfavorable foreign currency exchange rates.
Excluding the Kysor/Warren acquisition, we had a $20 million decline in variable compensation
expense as well as an additional $4 million from general cost control initiatives partially
offsetting these increases.

[0000950123-11-091697:mdna:69]
[same as prior period, unchanged from 0000950123-11-068216:mdna:70]

[0000950123-11-091697:mdna:70]
[same as prior period, unchanged from 0000950123-11-068216:mdna:71]

[0000950123-11-091697:mdna:71]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Realized gains on settled futures contracts |  | $ | (1.0 | ) |  | $ | (1.0 | ) |
| Unrealized loss on unsettled futures contracts not designated as cash flow hedges |  |  | 4.9 |  |  |  | — |  |
| Special legal contingency charge |  |  | (0.4 | ) |  |  | 6.3 |  |
| Foreign currency exchange loss |  |  | — |  |  |  | 0.6 |  |
| Other items, net |  |  | (0.4 | ) |  |  | 0.4 |  |
| Losses and other expenses, net |  | $ | 3.1 |  |  | $ | 6.3 |  |

[0000950123-11-091697:mdna:72]
The change in losses and other expenses, net is primarily due to the special legal contingency
charge related to the class action lawsuit that concluded in the second quarter of 2011 and the
unrealized losses on unsettled future commodity contracts. Refer to Note 7 in the Notes to the
Consolidated Financial Statements for more information on the special legal contingency charge and
Note 5 for more information on the unrealized losses on unsettled future commodity contracts.

[0000950123-11-091697:mdna:73]
[same as prior period, unchanged from 0000950123-11-068216:mdna:74]

[0000950123-11-091697:mdna:74]
Restructuring charges were $14 million in the first nine months of 2011 compared to $15
million in the first nine months of 2010. The charges in the first nine months of 2011 were from
corporate restructuring charges that included the exit of the corporate airplane lease, closure of
the aviation department, and reorganization of certain support function initiated in the third
quarter of 2011. Additionally, we had charges related to the reorganization of the Service Experts
administrative functions and management structure initiated in the fourth quarter of 2010. The
restructuring charges from the first nine months of 2010 were primarily related to the exit of the
contract coil and OEM coil manufacturing in Australia and consolidation of our Parets, Spain
manufacturing facility into our Genas, France facility in our Refrigeration segment, as well as,
the relocation of a research and development facility and administrative offices from California to
Tennessee in our Residential Heating &Cooling segment. The remaining restructuring charges from
the first nine months of 2010 were minor

[0000950123-11-091697:mdna:75]
charges from various open projects initiated in 2010 and
prior years. Refer to Note 13 in the Notes to the Consolidated Financial Statements for more
information.

[0000950123-11-091697:mdna:76]
[same as prior period, unchanged from 0000950123-11-068216:mdna:76]

[0000950123-11-091697:mdna:77]
Investments over which we do not exercise control but have significant influence are accounted
for using the equity method of accounting. Income from equity method investments was flat at $9
million in the first nine months of 2011 and 2010.

[0000950123-11-091697:mdna:78]
[same as prior period, unchanged from 0000950123-11-068216:mdna:78]

[0000950123-11-091697:mdna:79]
Interest expense, net, increased to almost $13 million in the first nine months of 2011 from
$9 million in the same period in 2010. The increase in interest expense was primarily attributable
to an increase in the average amounts borrowed in the first nine months of 2011 compared to 2010 as
well as an increase in our weighted average interest rate in the comparable period.

[0000950123-11-091697:mdna:80]
[same as prior period, unchanged from 0000950123-11-068216:mdna:80]

[0000950123-11-091697:mdna:81]
The income tax expense was $36 million in the first nine months of 2011 compared to $48
million in 2010. The effective tax rate was 33.3% for 2011 and 34.9% in 2010. Our effective rates
differ from the statutory federal rate of 35% for certain items, such as research tax credits,
foreign taxes at rates other than 35%, and other permanent items.

[0000950123-11-091697:mdna:82]
Year-to-Date Through September 30, 2011 Compared to Year-to-Date Through September 30, 2010 –
Results by Segment

[0000950123-11-091697:mdna:83]
[same as prior period, unchanged from 0000950123-11-068216:mdna:84]

[0000950123-11-091697:mdna:84]
The following table summarizes our Residential Heating & Cooling segment’s net sales and
profit for the first nine months of 2011 and 2010 (dollars in millions):

[0000950123-11-091697:mdna:85]
|  |  | Nine Months Ended |  |  |  |  |  |  |  |
|  |  | September 30, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 1,040.7 |  |  | $ | 1,068.5 |  |  | $ | (27.8 | ) |  |  | (2.6 | )% |
| Profit |  |  | 60.8 |  |  |  | 98.6 |  |  |  | (37.8 | ) |  |  | (38.3 | )% |
| % of net sales |  |  | 5.8 | % |  |  | 9.2 | % |  |  |  |  |  |  |  |  |

[0000950123-11-091697:mdna:86]
Residential Heating & Cooling net sales declined by 3% in the first nine months of 2011
compared to the first nine months of 2010. Sales volumes declined by 3% and price and mix were
flat in 2011 as compared to 2010. Our Residential Heating & Cooling segment’s sales volumes were
negatively affected by consumer weakness and a significant reduction in the federal tax credits in
2011 offered to consumers for high efficiency system purchases.

[0000950123-11-091697:mdna:87]
Segment profit decreased $38 million due to $14 million in lower sales volumes, $32 million in
increased commodity costs from both raw materials and components and $14 million in higher freight and
distribution charges. An $11 million decline in SG&A expenses, $3 million in favorable price and
mix and $3 million in favorable foreign currency exchange rates partially offset the decreases in
segment profit. The decline in SG&A expenses was primarily due to lower variable compensation and
general cost control.

[0000950123-11-091697:mdna:88]
[same as prior period, unchanged from 0000950123-11-068216:mdna:89]

[0000950123-11-091697:mdna:89]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit
for the first nine months of 2011 and 2010 (dollars in millions):

[0000950123-11-091697:mdna:90]
|  |  | Nine Months Ended |  |  |  |  |  |  |  |
|  |  | September 30, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 536.4 |  |  | $ | 471.7 |  |  | $ | 64.7 |  |  |  | 13.7 | % |
| Profit |  |  | 61.7 |  |  |  | 56.2 |  |  |  | 5.5 |  |  |  | 9.8 | % |
| % of net sales |  |  | 11.5 | % |  |  | 11.9 | % |  |  |  |  |  |  |  |  |

[0000950123-11-091697:mdna:91]
Our Commercial Heating & Cooling business experienced 14% in higher net sales in the
first nine months of 2011 compared to 2010 primarily due to an increase in our replacement business
which resulted in a 7% increase in sales volume. Additionally, our price and mix increased 4% in
the comparable period and changes in foreign currency exchange rates favorably impacted net sales
by 3%.

[0000950123-11-091697:mdna:92]
Segment profit for the first nine months of 2011 increased almost $6 million from the first
nine months of 2010. Segment profit increased from the impact of higher sales volume by $9 million
and positive price and mix by $8 million. Partially offsetting these increases to segment profit
were increased commodity costs of $13 million.

[0000950123-11-091697:mdna:93]
[same as prior period, unchanged from 0000950123-11-068216:mdna:94]

[0000950123-11-091697:mdna:94]
The following table summarizes our Service Experts segment’s net sales profit for the first
nine months of 2011 and 2010 (dollars in millions):

[0000950123-11-091697:mdna:95]
|  |  | Nine Months Ended |  |  |  |  |  |  |  |
|  |  | September 30, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 406.6 |  |  | $ | 445.6 |  |  | $ | (39.0 | ) |  |  | (8.8 | )% |
| Profit |  |  | 0.4 |  |  |  | 14.2 |  |  |  | (13.8 | ) |  |  | (97.2 | )% |
| % of net sales |  |  | 0.1 | % |  |  | 3.2 | % |  |  |  |  |  |  |  |  |

[0000950123-11-091697:mdna:96]
Service Experts net sales declined 9% in the first nine months of 2011 compared to the first
nine months of 2010. Sales volumes contributed 10% to the decline in sales. Offsetting the decline
in sales volume was 1% from favorable foreign currency exchange rates. The decline in this
segment’s sales volume is primarily due to a decline in residential HVAC equipment installations.

[0000950123-11-091697:mdna:97]
Segment profit decreased $14 million due to a $20 million decline in volume, partially offset
by a $6 million decline in SG&A expenses. The decline in SG&A expenses is primarily due to lower
variable compensation and general cost control.

[0000950123-11-091697:mdna:98]
[same as prior period, unchanged from 0000950123-11-068216:mdna:99]

[0000950123-11-091697:mdna:99]
The following table summarizes our Refrigeration segment’s net sales and profit for the first
nine months of 2011 and 2010 (dollars in millions):

[0000950123-11-091697:mdna:100]
|  |  | Nine Months Ended |  |  |  |  |  |  |  |
|  |  | September 30, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 616.3 |  |  | $ | 411.8 |  |  | $ | 204.5 |  |  |  | 49.7 | % |
| Profit |  |  | 55.5 |  |  |  | 47.5 |  |  |  | 8.0 |  |  |  | 16.8 | % |
| % of net sales |  |  | 9.0 | % |  |  | 11.5 | % |  |  |  |  |  |  |  |  |

[0000950123-11-091697:mdna:101]
Net sales, excluding Kysor/Warren, increased 10% due to higher sales volumes of 1%, higher
price and mix of 2% and favorable foreign currency exchange rates of 7%. The Kysor/Warren
acquisition contributed 40% to the increase in net sales.

[0000950123-11-091697:mdna:102]
Segment profit increased by $8 million, including a $9 million increase in volume, an $8
million positive impact from price and mix, and $3 million in favorable foreign exchange rates.
Partially offsetting these increases in segment profit were declines
of $5 million from increased commodity
costs, $3 million in other product costs savings and $3 million in higher freight and
distribution charges. The remaining segment profit increase is related to the Kysor/Warren
acquisition.

[0000950123-11-091697:mdna:103]
[same as prior period, unchanged from 0000950123-11-068216:mdna:104]

[0000950123-11-091697:mdna:104]
Corporate and other expenses were $41 million in the first nine months of 2011, down from $48
million in the first nine months of 2010. The decrease was primarily driven by a $7 million
decline in compensation expense, primarily incentive compensation, for 2011 as well as expense
control and productivity.

[0000950123-11-091697:mdna:105]
[same as prior period, unchanged from 0000950123-11-068216:mdna:106]

[0000950123-11-091697:mdna:106]
Our working capital and capital expenditure requirements are generally met through internally
generated funds, bank lines of credit and a revolving asset securitization arrangement. Working
capital needs are generally greater in the first and second quarters due to the seasonal nature of
our business cycle.

[0000950123-11-091697:mdna:107]
[same as prior period, unchanged from 0000950123-11-068216:mdna:108]

[0000950123-11-091697:mdna:108]
The following table summarizes our cash activity for the nine months ended September 30, 2011
and 2010 (in millions):

[0000950123-11-091697:mdna:109]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net cash (used in) provided by operating activities |  | $ | (2.2 | ) |  | $ | 43.6 |  |
| Net cash used in investing activities |  |  | (161.7 | ) |  |  | (45.5 | ) |
| Net cash provided by (used in) financing activities |  |  | 65.2 |  |  |  | (33.1 | ) |

[0000950123-11-091697:mdna:110]
Net Cash (Used in) Provided by Operating Activities

[0000950123-11-091697:mdna:111]
Operating activities resulted in a $2.2 million use of cash in 2011 compared to a source of
$43.6 million in 2010. This increased use was primarily due to lower net income and an unfavorable
change in accrued expenses with favorable working capital partially offsetting these items. The
unfavorable comparison for accrued expenses was due to higher payments and lower accruals for
incentive compensation in the first nine months of 2011 versus 2010. Incentive compensation is
accrued in the current year based on performance, but paid in the first quarter of the subsequent
year. In addition, we had an increase in accrued expenses related to class action litigation in
the first nine months of 2010 but a significant reduction in 2011 when nearly all of these accrued
expenses were paid. Improved management of working capital including lower production rates in the
third quarter resulted in a lower use of cash for inventory and a higher source of cash from
accounts payable in the first nine months of 2011 compared to 2010.

[0000950123-11-091697:mdna:112]
[same as prior period, unchanged from 0000950123-11-068216:mdna:114]

[0000950123-11-091697:mdna:113]
Net cash used in investing activities for the first nine months of 2011 included $143.3
million for the acquisition of the Kysor/Warren business from The Manitowoc Company and $4.4
million for the acquisition of a commercial services business in our Service Experts segment.
Kysor/Warren is a leading manufacturer of refrigerated systems and display cases for supermarkets
throughout North America and is included in our Refrigeration Segment.

[0000950123-11-091697:mdna:114]
Capital expenditures in the first nine months of 2011 were $27.1 million, which was slightly
lower than the $30.0 million in the first nine months of 2010. Capital expenditures in the first
nine months were primarily related to investments in our distribution network and investments in
systems and software to support the overall enterprise.

[0000950123-11-091697:mdna:115]
Offsetting the cash used for capital expenditures and to acquire businesses in the first nine
months of 2011 was a change in the security requirements for the remaining claims for our captive
insurance subsidiary. We transferred substantially all security from restricted cash to stand-by
letters of credit resulting in a refund of $12.2 million of restricted cash.

[0000950123-11-091697:mdna:116]
In addition to the $30.0 million in capital expenditures in the first nine months of 2010, net
cash used in investing activities included $13.1 million placed in a trust for our captive
insurance subsidiary and $6.0 million for business acquisitions. Offsetting these uses were $3.5
million in proceeds from the sale of businesses.

[0000950123-11-091697:mdna:117]
[same as prior period, unchanged from 0000950123-11-068216:mdna:119]

[0000950123-11-091697:mdna:118]
Net cash provided by financing activities increased by $98.3 million in the first nine months
of 2011 compared to the first nine months of 2010. This increase was primarily related to an
increase in net borrowings to support the Kysor/Warren acquisition. We had fewer repurchases of
common stock in 2011 which also increased the net cash provided by financing activities.

[0000950123-11-091697:mdna:119]
[same as prior period, unchanged from 0000950123-11-068216:mdna:121]

[0000950123-11-091697:mdna:120]
The following table details our lines of credit and financing arrangements as of September 30,
2011:

[0000950123-11-091697:mdna:121]
|  |  |  |  |  |  |  |  |  |  | Available for |  |
|  |  | Maximum |  |  | Outstanding |  |  | Future |  |
|  |  | Capacity |  |  | Borrowings |  |  | Borrowings |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign Obligations |  |  |  |  |  |  |  |  |  |  |  |  |
| Committed |  | $ | 3.7 |  |  | $ | — |  |  | $ | 3.7 |  |
| Non-committed |  |  | 3.5 |  |  |  | 3.5 |  |  |  | — |  |
| Asset Securitization (1) |  |  | 100.0 |  |  |  | — |  |  |  | 100.0 |  |
| Total short-term debt |  | $ | 107.2 |  |  | $ | 3.5 |  |  | $ | 103.7 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital lease obligations |  | $ | 17.6 |  |  |  | 17.6 |  |  |  | — |  |
| Domestic revolving credit facility (2) |  |  | 650.0 |  |  |  | 278.5 |  |  |  | 291.5 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |  |  | — |  |
| Total long-term debt |  | $ | 867.6 |  |  | $ | 496.1 |  |  |  | 291.5 |  |
| Total |  | $ | 974.8 |  |  | $ | 499.6 |  |  | $ | 395.2 |  |

[0000950123-11-091697:mdna:122]
| (1) |  | The maximum capacity under the asset securitization arrangement (“ASA”) is the lesser of $100.0 million or 100% of the net pool balance defined under the ASA. |
| (2) |  | The available future borrowings on our domestic revolving credit facility exclude $80.0 million in standby letters of credit. |

[0000950123-11-091697:mdna:123]
As discussed above, we utilized our domestic revolving credit facility (“credit facility”) to
support the acquisition of the Kysor/Warren business. As our peak season arrives, we typically pay
down debt. We believe our available future borrowings combined with our cash of $57.9 million and
anticipated cash from operations in the remainder of the year will be more than sufficient to fund
our operations, capital expenditures, share repurchases, dividends and other needs in the
foreseeable future. Our expected capital expenditures are approximately $45 to $50
million for 2011.

[0000950123-11-091697:mdna:124]
Our debt-to-total-capital ratio increased to 50.0% at September 30, 2011 compared to 35.1% at
December 31, 2010. The increase in the ratio is primarily due to the increase in debt since
December 31, 2010 from the acquisition of the Kysor/Warren business.

[0000950123-11-091697:mdna:125]
Covenants on our outstanding debt did not change in the first nine months of 2011 and we were
in compliance with all of our debt covenants as of September 30, 2011. For a more detailed
discussion of our debt, see Note 8 in the Notes to the Consolidated Financial Statements set forth
in Part I, Item I of this Quarterly Report on Form 10-Q.

[0000950123-11-091697:mdna:126]
We periodically review our capital structure, including our primary bank facility, to ensure
that it has adequate liquidity. Our ASA expires on November 18, 2011 and our credit facility
was due to mature in October 2012. We amended and restated our credit facility on October 21, 2011. The
borrowing capacity of $650 million, interest rate structure and debt covenants are substantially
the same as the credit facility that was in effect as of September 30, 2011. The primary changes
reflected in the amended credit facility relate to relaxing of certain covenants contained in the
prior credit agreement and the extension of the maturity date to October 2016. Although pricing
under the amended facility is slightly higher, we don’t believe it will significantly increase our
interest expense on an annual basis. We expect to amend, renew or replace the ASA prior to or
upon its expiration. We also periodically consider various other financing alternatives and may,
from time to time, seek to take advantage of favorable interest rate environments or other market
conditions, which may include accessing the capital markets. We filed a shelf registration
statement with the SEC that became effective on December 1, 2008, which allows us to offer and sell
an indeterminate number or amount of debt securities, common shares, preferred shares, subscription
rights, warrants, depositary shares and units.

[0000950123-11-091697:mdna:127]
On March 11, 2011, we announced that our Board of Directors approved a 20% increase in our
quarterly dividend on common stock from $0.15 to $0.18 effective with the April dividend payment.
Dividend payments are expected to be approximately $35 million in 2011. We also continue to
increase shareholder value through our share repurchase program. During the first nine months of
2011, we returned $90 million to our investors through share repurchases. We are targeting
approximately $120 million in share repurchases in 2011.

[0000950123-11-091697:mdna:128]
[same as prior period, unchanged from 0000950123-11-068216:mdna:130]

[0000950123-11-091697:mdna:129]
[same as prior period, unchanged from 0000950123-11-068216:mdna:131]

[0000950123-11-091697:mdna:130]
Commitments, Contingencies and Guarantees

[0000950123-11-091697:mdna:131]
For a detailed discussion of commitments, contingencies and guarantees, see Note 7 in the
Notes to the Consolidated Financial Statements.

[0000950123-11-091697:mdna:132]
The estimate of our liability for future warranty costs requires us to make significant
assumptions about the amount, timing and nature of the costs we will incur in the future. We
periodically review the assumptions used to determine the liability and we adjust our assumptions
based upon factors such as actual failure rates and cost experience. Numerous factors could affect
actual failure rates and cost experience, including the amount and timing of new product
introductions, changes in manufacturing techniques or locations, components or suppliers used. In
recent years, changes in the warranty liability as the result of the issuance of new warranties and
the payments made have remained relatively stable. Should actual warranty costs differ from our
estimates, we may be required to record adjustments to accruals and expense in the future. At the
end of each accounting period, we evaluate our warranty liabilities and during the second quarter
of each year, we perform a complete reevaluation of our warranty liabilities.

[0000950123-11-091697:mdna:133]
We also may incur costs related to our products that may not be covered under our warranties
and are not covered by insurance, and we may, from time to time, repair or replace installed
products experiencing quality issues in order to satisfy our customers and to protect our brand.
These product quality issues may be caused by vendor-supplied components that fail to meet required
specifications. We have identified a product quality issue in a heating and cooling product line
produced in 2006 and 2007 related to a vendor-supplied materials quality issue. To date, we
recorded expenses of $22.7 million for the portion of the issue that is probable and can be
reasonably estimated. We decreased this liability by $1.4 million in the second quarter of 2011 to
adjust the estimated claim cost based on historical claims paid. As of September 30, 2011, we had
$10.1 million accrued for this matter. We may incur additional charges in the future as more
information becomes available.

[0000950123-11-091697:mdna:134]
We estimate the costs to settle pending litigation based on experience involving similar
claims and specific facts known. We do not believe that any current or pending or threatened
litigation will have a material adverse effect on our financial position. Litigation and
arbitration, however, involve uncertainties and it is possible that the eventual outcome of
litigation could adversely affect our results of operations for a particular period.

[0000950123-11-091697:mdna:135]
We were the defendant in a class action lawsuit seeking economic damages for alleged
diminished value for plaintiffs’ homes relative to certain hearth products we produced and sold. On
June 10, 2011, the litigation of this matter concluded when the court issued its Order Granting
Final Approval of Class Settlement; Final Judgment and Order of Dismissal. We do not expect to
incur any significant additional expense and substantially all of the expenses incurred to date
were paid.
