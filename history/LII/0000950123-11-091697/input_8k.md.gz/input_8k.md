# LII 8-K — 0000950123-11-091662 filed 2011-10-25

## item codes, every 8-K on or before 2011-10-25

- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2011-10-25

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000950123-11-091662:8k_2_02:1]
EX-99.1
3
d85276exv99w1.htm
EX-99.1

[0000950123-11-091662:8k_2_02:2]
exv99w1

[0000950123-11-091662:8k_2_02:3]
Exhibit 99.1

[0000950123-11-091662:8k_2_02:4]
Lennox International Reports Third Quarter Results

[0000950123-11-091662:8k_2_02:5]
| • |  | Total revenue up 13%, with organic revenue up 4% |

[0000950123-11-091662:8k_2_02:6]
| • |  | Adjusted EPS of $0.80 and GAAP EPS of $0.64 |

[0000950123-11-091662:8k_2_02:7]
| • |  | 2011 revenue growth guidance range now 7-9% |

[0000950123-11-091662:8k_2_02:8]
| • |  | Narrowing 2011 adjusted EPS guidance range to $2.00-$2.15 |

[0000950123-11-091662:8k_2_02:9]
| • |  | Repurchased $55 million of stock in the third quarter |

[0000950123-11-091662:8k_2_02:10]
| • |  | Repurchased $90 million of stock year-to-date and increasing buyback target to $120 million in total for 2011 |

[0000950123-11-091662:8k_2_02:11]
DALLAS, October 25 – Lennox International Inc. (NYSE: LII) today reported financial results for the
third quarter of 2011.

[0000950123-11-091662:8k_2_02:12]
Revenue for the third quarter was $923 million, up 13% from the prior-year quarter including a 2
point positive impact from foreign exchange. Excluding the Kysor/Warren acquisition that closed in
January 2011, organic revenue was up 4% in the third quarter. At constant currency, organic revenue
was up 2% from the prior-year quarter. Diluted earnings per share from continuing operations on an
adjusted basis was $0.80, compared to $0.83 in the prior-year quarter. Diluted earnings per share
from continuing operations on a GAAP basis was $0.64, compared to $0.76 in the prior-year quarter.

[0000950123-11-091662:8k_2_02:13]
“Revenue from our Residential business was up slightly in the third quarter, led by a 4% increase
in shipments as well as price realization, although product mix was down from a year ago when the
federal government’s $1,500 tax credit for high-efficiency cooling and heating products was still
in place,” said Todd Bluedorn, CEO of Lennox International. “Commercial revenue was up 10% at
constant currency as we continued to see strong, broad-based growth across the business, as well as
favorable price and mix. Refrigeration organic revenue was up 4% at constant currency, adjusted for
the strategic exit of third-party coil business in Australia last year. Refrigeration also realized
favorable price and mix on top of shipment growth. In our Service Experts business, residential
revenue was down, while commercial revenue was up 6%. Overall, the company had strong cash
generation in the third quarter with free cash flow of $132 million and repurchased $55 million of
stock and paid out $10 million in dividends. For 2011, we now expect company revenue growth of 7-9%
and are narrowing our guidance range for adjusted EPS to $2.00-$2.15 for the year.”

[0000950123-11-091662:8k_2_02:14]
FINANCIAL HIGHLIGHTS

[0000950123-11-091662:8k_2_02:15]
Revenue: Revenue for the third quarter was $923 million, up 13% from the prior-year quarter,
including a positive 2 point impact from foreign exchange. On an organic basis and at constant
currency, revenue was up 2% from the third quarter a year ago. Volume was up, and price/mix was
flat from the prior-year quarter.

[0000950123-11-091662:8k_2_02:16]
Gross Profit: Gross profit for the third quarter was $231 million, down 1% from $233 million in the
prior-year quarter. Gross margin was 25.0% compared to 28.5% in the prior-year quarter. Gross
margin was impacted primarily by higher raw and component commodity costs, lower product mix, and
the Kysor/Warren acquisition, partially offset by favorable price.

[0000950123-11-091662:8k_2_02:17]
Income from Continuing Operations: Adjusted income from continuing operations in the third quarter
was $42.5 million, or $0.80 diluted earnings per share, compared to adjusted income from continuing
operations of $45.5 million, or $0.83 diluted earnings per share in the prior-year quarter.
Adjusted income from continuing operations for the third quarter of 2011 excludes: an after-tax
charge of $6.7 million for restructuring activities; $2.2 million after-tax for the net change in
unrealized losses on open future contracts; and a $0.2 million after-tax benefit for other items.

[0000950123-11-091662:8k_2_02:18]
On a GAAP basis, income from continuing operations for the third quarter was $33.8 million, or
$0.64 diluted earnings per share, compared to $41.9 million income from continuing operations, or
$0.76 diluted earnings per share, in the prior-year quarter.

[0000950123-11-091662:8k_2_02:19]
Free Cash Flow and Total Debt: Net cash from operations in the third quarter was $140 million
compared to $70 million in the prior-year quarter. The company invested approximately $8 million in
capital assets in the third quarter. Free cash flow was $132 million, up 122% from $59 million in
the prior-year quarter. The company paid $10 million in dividends and repurchased $55 million of
stock in the third quarter. For the first 9 months of the year, the company paid $27 million in
dividends and repurchased $90 million of stock. Total cash and cash equivalents were $58 million at
the end of the third quarter. Total debt at the end of the third quarter was $500 million, down $78
million from the second quarter. On October 21, 2011, the company extended the maturity on its $650
million senior unsecured revolving credit facility from October 2012 to October 2016 through an
amended and restated agreement.

[0000950123-11-091662:8k_2_02:20]
BUSINESS SEGMENT HIGHLIGHTS

[0000950123-11-091662:8k_2_02:21]
Residential Heating & Cooling

[0000950123-11-091662:8k_2_02:22]
Third quarter revenue in the Residential Heating & Cooling business segment was $374 million, up 1%
from $371 million in the prior-year quarter. At constant currency, revenue was up slightly. Segment
profit was $29 million and segment profit margin was 7.7%, compared to segment profit of $39
million and segment profit margin of 10.5% in the prior-year quarter. Results were primarily
impacted by lower mix and higher commodity costs, with offsets from higher volume, favorable price,
and lower SG&A.

[0000950123-11-091662:8k_2_02:23]
Commercial Heating & Cooling

[0000950123-11-091662:8k_2_02:24]
Revenue in the Commercial Heating & Cooling business segment was $199 million, up 13% from $176
million in the prior-year quarter. At constant currency, revenue was up 10%. Total segment profit
was $29 million, and segment profit margin was 14.4%, compared to segment profit of $25 million and
segment profit margin of 14.1% in the prior-year quarter. Results were primarily impacted by higher
volume, favorable price/mix, and lower SG&A expenses, which more than offset higher commodity
costs.

[0000950123-11-091662:8k_2_02:25]
Service Experts

[0000950123-11-091662:8k_2_02:26]
Revenue in the Service Experts business segment was $145 million in the third quarter, down 4% from
$151 million in the prior-year quarter. At constant currency, revenue was down 5%. Segment profit
was $5 million and segment profit margin was 3.7%, compared to segment profit of $6 million and
segment profit margin of 4.0% in the prior-year quarter. Results were primarily impacted by lower
volume in the residential business, with a partial offset from lower SG&A expenses.

[0000950123-11-091662:8k_2_02:27]
Refrigeration

[0000950123-11-091662:8k_2_02:28]
Revenue in the Refrigeration business segment was $224 million in the third quarter, up 59% from
$141 million in the prior-year quarter. At constant currency, revenue was up 52%. Excluding the
Kysor/Warren acquisition, organic revenue was up 2% at constant currency. Segment profit was $21
million and segment profit margin was 9.2% in the third quarter, compared to segment profit of $17
million and segment profit margin of 12.3% in the prior-year quarter. Excluding the Kysor/Warren
acquisition, segment profit margin was up 20 basis points from the prior-year quarter. Results were
primarily impacted by higher volume and favorable price/mix, with offsets from higher commodity
costs and SG&A expenses.

[0000950123-11-091662:8k_2_02:29]
FULL-YEAR OUTLOOK

[0000950123-11-091662:8k_2_02:30]
The company is adjusting its revenue guidance range and narrowing its EPS guidance ranges for 2011.

[0000950123-11-091662:8k_2_02:31]
|  | • |  | Adjusting revenue growth guidance from a range of 8-11% to a range of 7-9%; adjusting organic revenue growth guidance from a range of 1-4% to a range of 0-2%; foreign exchange is estimated to have 2 points of positive impact. |
|  | • |  | Narrowing adjusted EPS from continuing operations guidance from a range of $2.00-$2.30 to a range of $2.00-$2.15. |
|  | • |  | Narrowing GAAP EPS from continuing operations guidance from a range of $1.93-$2.23 to a range of $1.78-$1.93. |
|  | • |  | The company continues to expect $60-65 million of headwind from raw and component commodity costs for the full year. |
|  | • |  | Lowering tax rate guidance from approximately 34% to approximately 33.5% for the full year. |
|  | • |  | Lowering capital expenditure guidance from approximately $60 million to approximately $45-50 million for the full year. |
|  | • |  | Raising 2011 stock repurchase guidance from more than $100 million to a target of $120 million for the full year. |

[0000950123-11-091662:8k_2_02:32]
CONFERENCE CALL INFORMATION

[0000950123-11-091662:8k_2_02:33]
A conference call to discuss the company’s third quarter results will be held this morning at 8:30
a.m. Central time. To listen, please call the conference call line at 612-288-0337 at least 10
minutes prior to the scheduled start time and use reservation number 219563. This conference call
will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0000950123-11-091662:8k_2_02:34]
A replay will be available from 11:00 a.m. Central time on October 25 through November 1, 2011, by
dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 219563. This call
will also be archived on the company’s web site.

[0000950123-11-091662:8k_2_02:35]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration
markets. Lennox International stock is traded on the New York Stock Exchange under the symbol
“LII.” Additional information is available at: http://www.lennoxinternational.com or by contacting
Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0000950123-11-091662:8k_2_02:36]
FORWARD-LOOKING AND CAUTIONARY STATEMENTS

[0000950123-11-091662:8k_2_02:37]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-091662:8k_2_02:38]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950123-11-091662:8k_2_02:39]
(Unaudited, in millions, except per share data)

[0000950123-11-091662:8k_2_02:40]
|  |  | For the Three Months |  |  | For the Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| NET SALES |  | $ | 923.0 |  |  | $ | 818.2 |  |  | $ | 2,547.7 |  |  | $ | 2,334.4 |  |
| COST OF GOODS SOLD |  |  | 691.9 |  |  |  | 585.4 |  |  |  | 1,903.9 |  |  |  | 1,662.6 |  |
| Gross profit |  |  | 231.1 |  |  |  | 232.8 |  |  |  | 643.8 |  |  |  | 671.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 166.3 |  |  |  | 163.5 |  |  |  | 515.2 |  |  |  | 513.0 |  |
| Losses and other expenses, net |  |  | 2.5 |  |  |  | 0.8 |  |  |  | 3.1 |  |  |  | 6.3 |  |
| Restructuring charges |  |  | 10.8 |  |  |  | 4.7 |  |  |  | 14.4 |  |  |  | 15.0 |  |
| Income from equity method investments |  |  | (3.0 | ) |  |  | (2.8 | ) |  |  | (8.9 | ) |  |  | (8.9 | ) |
| Operational income from continuing operations |  |  | 54.5 |  |  |  | 66.6 |  |  |  | 120.0 |  |  |  | 146.4 |  |
| INTEREST EXPENSE, net |  |  | 4.1 |  |  |  | 3.5 |  |  |  | 12.5 |  |  |  | 9.1 |  |
| OTHER EXPENSE, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 50.4 |  |  |  | 63.1 |  |  |  | 107.4 |  |  |  | 137.2 |  |
| PROVISION FOR INCOME TAXES |  |  | 16.6 |  |  |  | 21.2 |  |  |  | 35.8 |  |  |  | 47.9 |  |
| Income from continuing operations |  |  | 33.8 |  |  |  | 41.9 |  |  |  | 71.6 |  |  |  | 89.3 |  |
| DISCONTINUED OPERATIONS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operational loss from discontinued operations |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.9 |  |
| Income tax benefit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.8 |  |
| Net income |  | $ | 33.8 |  |  | $ | 41.8 |  |  | $ | 71.6 |  |  | $ | 88.5 |  |
| EARNINGS PER SHARE — BASIC: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.65 |  |  | $ | 0.78 |  |  | $ | 1.35 |  |  | $ | 1.62 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.01 | ) |
| Net income |  | $ | 0.65 |  |  | $ | 0.78 |  |  | $ | 1.35 |  |  | $ | 1.61 |  |
| EARNINGS PER SHARE — DILUTED: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.64 |  |  | $ | 0.76 |  |  | $ | 1.33 |  |  | $ | 1.59 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.02 | ) |
| Net income |  | $ | 0.64 |  |  | $ | 0.76 |  |  | $ | 1.33 |  |  | $ | 1.57 |  |
| AVERAGE SHARES OUTSTANDING: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 52.2 |  |  |  | 53.8 |  |  |  | 53.0 |  |  |  | 55.0 |  |
| Diluted |  |  | 52.8 |  |  |  | 55.0 |  |  |  | 53.9 |  |  |  | 56.2 |  |
| CASH DIVIDENDS DECLARED PER SHARE |  | $ | 0.18 |  |  | $ | 0.15 |  |  | $ | 0.54 |  |  | $ | 0.45 |  |

[0000950123-11-091662:8k_2_02:41]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-091662:8k_2_02:42]
SEGMENT NET SALES AND PROFIT

[0000950123-11-091662:8k_2_02:43]
(Unaudited, in millions)

[0000950123-11-091662:8k_2_02:44]
|  |  | For the Three Months |  |  | For the Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 373.6 |  |  | $ | 370.9 |  |  | $ | 1,040.7 |  |  | $ | 1,068.5 |  |
| Commercial Heating & Cooling |  |  | 199.3 |  |  |  | 176.3 |  |  |  | 536.4 |  |  |  | 471.7 |  |
| Service Experts |  |  | 144.7 |  |  |  | 150.9 |  |  |  | 406.6 |  |  |  | 445.6 |  |
| Refrigeration |  |  | 223.7 |  |  |  | 140.6 |  |  |  | 616.3 |  |  |  | 411.8 |  |
| Eliminations (A) |  |  | (18.3 | ) |  |  | (20.5 | ) |  |  | (52.3 | ) |  |  | (63.2 | ) |
|  |  | $ | 923.0 |  |  | $ | 818.2 |  |  | $ | 2,547.7 |  |  | $ | 2,334.4 |  |
| Segment Profit (Loss) (B) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 28.8 |  |  | $ | 39.0 |  |  | $ | 60.8 |  |  | $ | 98.6 |  |
| Commercial Heating & Cooling |  |  | 28.7 |  |  |  | 24.9 |  |  |  | 61.7 |  |  |  | 56.2 |  |
| Service Experts |  |  | 5.4 |  |  |  | 6.0 |  |  |  | 0.4 |  |  |  | 14.2 |  |
| Refrigeration |  |  | 20.5 |  |  |  | 17.3 |  |  |  | 55.5 |  |  |  | 47.5 |  |
| Corporate and other |  |  | (15.4 | ) |  |  | (15.5 | ) |  |  | (41.4 | ) |  |  | (48.2 | ) |
| Eliminations (A) |  |  | 0.3 |  |  |  | 0.1 |  |  |  | — |  |  |  | (0.2 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 68.3 |  |  |  | 71.8 |  |  |  | 137.0 |  |  |  | 168.1 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustment |  |  | — |  |  |  | — |  |  |  | (2.4 | ) |  |  | — |  |
| Items in losses and other expenses, net that are excluded from segment profit (C) |  |  | 3.0 |  |  |  | 0.5 |  |  |  | 5.0 |  |  |  | 6.7 |  |
| Restructuring charges |  |  | 10.8 |  |  |  | 4.7 |  |  |  | 14.4 |  |  |  | 15.0 |  |
| Interest expense, net |  |  | 4.1 |  |  |  | 3.5 |  |  |  | 12.5 |  |  |  | 9.1 |  |
| Other expense, net |  |  | — |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  | $ | 50.4 |  |  | $ | 63.1 |  |  | $ | 107.4 |  |  | $ | 137.2 |  |

[0000950123-11-091662:8k_2_02:45]
| (A) |  | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |
| (B) |  | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |
|  |  | Excluding: |

[0000950123-11-091662:8k_2_02:46]
|  | o |  | Special product quality adjustment. |
|  | o |  | Items within Gains and/or losses and other expenses, net that are noted in (C) . |
|  | o |  | Restructuring charges. |
|  | o |  | Goodwill and equity method investment impairments. |
|  | o |  | Interest expense, net. |
|  | o |  | Acquisition costs |
|  | o |  | Other expense, net. |

[0000950123-11-091662:8k_2_02:47]
| (C) |  | Items in Gains and/or losses and other expenses, net that are excluded from segment profit or loss are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |

[0000950123-11-091662:8k_2_02:48]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-091662:8k_2_02:49]
CONSOLIDATED BALANCE SHEETS

[0000950123-11-091662:8k_2_02:50]
(In millions, except share and per share data)

[0000950123-11-091662:8k_2_02:51]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 57.9 |  |  | $ | 160.0 |  |
| Restricted cash |  |  | — |  |  |  | 12.2 |  |
| Accounts and notes receivable, net of allowances of $13.5 and $12.8 in 2011 and 2010, respectively |  |  | 478.2 |  |  |  | 384.8 |  |
| Inventories, net |  |  | 394.3 |  |  |  | 286.2 |  |
| Deferred income taxes, net |  |  | 50.1 |  |  |  | 36.7 |  |
| Other assets |  |  | 48.3 |  |  |  | 67.0 |  |
| Total current assets |  |  | 1,028.8 |  |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net of accumulated depreciation of $601.1 and $584.7 in 2011 and 2010, respectively |  |  | 333.3 |  |  |  | 324.3 |  |
| GOODWILL |  |  | 307.0 |  |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | 84.2 |  |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 81.0 |  |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 1,834.3 |  |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 3.5 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt |  |  | 0.4 |  |  |  | 0.6 |  |
| Accounts payable |  |  | 343.2 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 316.1 |  |  |  | 334.5 |  |
| Income taxes payable |  |  | 9.6 |  |  |  | 5.3 |  |
| Total current liabilities |  |  | 672.8 |  |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 495.7 |  |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | 15.6 |  |  |  | 15.9 |  |
| PENSIONS |  |  | 89.0 |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 62.5 |  |  |  | 65.7 |  |
| Total liabilities |  |  | 1,335.6 |  |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 86,648,631 shares and 86,480,816 shares issued for 2011 and 2010, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 879.2 |  |  |  | 863.5 |  |
| Retained earnings |  |  | 685.4 |  |  |  | 642.2 |  |
| Accumulated other comprehensive (loss)/income |  |  | (28.8 | ) |  |  | 30.2 |  |
| Treasury stock, at cost, 35,090,313 shares and 32,784,503 shares for 2011 and 2010, respectively |  |  | (1,038.0 | ) |  |  | (947.1 | ) |
| Total stockholders’ equity |  |  | 498.7 |  |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,834.3 |  |  | $ | 1,692.0 |  |

[0000950123-11-091662:8k_2_02:52]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-091662:8k_2_02:53]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0000950123-11-091662:8k_2_02:54]
(Unaudited, in millions, except per share and ratio data)

[0000950123-11-091662:8k_2_02:55]
Use of Non-GAAP Financial Measures

[0000950123-11-091662:8k_2_02:56]
To supplement the Company’s consolidated financial statements and segment net sales and profit
presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and
reconciled in the following tables. The Company believes that these non-GAAP financial measures,
when considered together with the GAAP financial measures, provide information that is useful to
investors in understanding period-over-period operating results. The Company believes that these
non-GAAP financial measures enhance the ability of investors to analyze the Company’s business
trends and operating performance.

[0000950123-11-091662:8k_2_02:57]
Reconciliation of Income From Continuing Operations, a GAAP Measure, to Adjusted Income From
Continuing Operations, a Non-GAAP Measure

[0000950123-11-091662:8k_2_02:58]
|  |  | For The Three Months |  |  | For The Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Income from continuing operations, a GAAP measure |  | $ | 33.8 |  |  | $ | 41.9 |  |  | $ | 71.6 |  |  | $ | 89.3 |  |
| Restructuring charges, after tax |  |  | 6.7 |  |  |  | 3.5 |  |  |  | 9.0 |  |  |  | 10.2 |  |
| Special product quality adjustment, net (b) |  |  | — |  |  |  | — |  |  |  | (1.5 | ) |  |  | — |  |
| Acquisition costs, net (b) |  |  | — |  |  |  | 0.3 |  |  |  | 0.7 |  |  |  | 0.3 |  |
| Special legal contingency charge, after-tax (a) |  |  | (0.1 | ) |  |  | 1.0 |  |  |  | (0.2 | ) |  |  | 3.9 |  |
| Gain on sale of entity (a) |  |  | (0.1 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Net change in unrealized losses on open future contracts, after tax (a) |  |  | 2.2 |  |  |  | (0.9 | ) |  |  | 3.2 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |  |  | 0.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 42.5 |  |  | $ | 45.5 |  |  | $ | 82.2 |  |  | $ | 103.7 |  |
| Reconciliation of Earnings per Share from Continuing Operations — Diluted, a GAAP Measure, to Adjusted Earnings per Share From Continuing Operations — Diluted, a Non-GAAP Measure |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings per share from continuing operations — diluted, a GAAP measure |  | $ | 0.64 |  |  | $ | 0.76 |  |  | $ | 1.33 |  |  | $ | 1.59 |  |
| Restructuring charges |  |  | 0.13 |  |  |  | 0.06 |  |  |  | 0.17 |  |  |  | 0.18 |  |
| Special product quality adjustment (b) |  |  | — |  |  |  | — |  |  |  | (0.03 | ) |  |  | — |  |
| Gain on sale of entity (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Special legal contingency charge (a) |  |  | — |  |  |  | 0.02 |  |  |  | — |  |  |  | 0.07 |  |
| Net change in unrealized losses on open future contracts and other items, net (a) |  |  | 0.03 |  |  |  | (0.01 | ) |  |  | 0.05 |  |  |  | — |  |
| Adjusted earnings per share from continuing operations — diluted, a non-GAAP measure |  | $ | 0.80 |  |  | $ | 0.83 |  |  | $ | 1.52 |  |  | $ | 1.84 |  |

[0000950123-11-091662:8k_2_02:59]
| (a) |  | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |
| (b) |  | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0000950123-11-091662:8k_2_02:60]
|  |  | For The Three Months |  |  | For The Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
| Components of Losses and other expenses, net (pre-tax): |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Realized gains on settled future contracts (a) |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (1.0 | ) |  |  | (1.0 | ) |
| Foreign currency exchange (gain) loss (a) |  |  | (0.5 | ) |  |  | 0.6 |  |  |  | — |  |  |  | 0.6 |  |
| Gain on disposal of fixed assets (a) |  |  | — |  |  |  | (0.1 | ) |  |  | (0.9 | ) |  |  | — |  |
| Special legal contingency charge (b) |  |  | (0.1 | ) |  |  | 1.8 |  |  |  | (0.4 | ) |  |  | 6.3 |  |
| Acquisition costs, net (b) |  |  | — |  |  |  | 0.4 |  |  |  | 0.9 |  |  |  | 0.4 |  |
| Net change in unrealized (gains)/losses on open futures contracts (b) |  |  | 3.5 |  |  |  | (1.4 | ) |  |  | 4.9 |  |  |  | — |  |
| Gain on sale of entity (b) |  |  | (0.2 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Other items, net (b) |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |  |  | 0.3 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 2.5 |  |  | $ | 0.8 |  |  | $ | 3.1 |  |  | $ | 6.3 |  |

[0000950123-11-091662:8k_2_02:61]
| (a) |  | Included in segment profit and adjusted income from continuing operations |
| (b) |  | Excluded from segment profit and adjusted income from continuing operations |

[0000950123-11-091662:8k_2_02:62]
Reconciliation of Estimated Adjusted Earnings per Share from Continuing
Operations — Diluted, a Non-GAAP Measure, to
Earnings per Share from Continuing Operations — Diluted, a GAAP Measure

[0000950123-11-091662:8k_2_02:63]
|  |  | For the |  |
|  |  | Year Ended |  |
|  |  | December 31, |  |
|  |  | 2011 |  |
|  |  | ESTIMATED |  |
| Adjusted earnings per share from continuing operations — diluted |  | $ | 2.00 - $2.15 |  |
| Restructuring charges |  |  | (0.19 | ) |
| Special legal contingency charge |  |  | — |  |
| Special product quality adjustment, net |  |  | 0.03 |  |
| Net change in unrealized losses on open futures contracts and other items, net |  |  | (0.06 | ) |
| GAAP earnings per share from continuing operations — diluted |  | $ | 1.78 - $1.93 |  |

[0000950123-11-091662:8k_2_02:64]
Reconciliation of Net Cash Used in Operating Activities, a GAAP Measure, to Free Cash Flow, a
Non-GAAP Measure

[0000950123-11-091662:8k_2_02:65]
|  |  | For the Three Months |  |  | For the Nine Months |  |
|  |  | Ended September 30, |  |  | Ended September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 140.2 |  |  | $ | 69.6 |  |  | $ | (2.2 | ) |  | $ | 43.6 |  |
| Purchase of property, plant and equipment |  |  | (8.5 | ) |  |  | (10.3 | ) |  |  | (27.1 | ) |  |  | (30.0 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | 131.7 |  |  | $ | 59.3 |  |  | $ | (29.3 | ) |  | $ | 13.6 |  |

[0000950123-11-091662:8k_2_02:66]
Calculation of Debt to EBITDA Ratio:

[0000950123-11-091662:8k_2_02:67]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | September 30, |  |
|  |  | 2011 |  |
| EBIT (a) |  | $ | 185.9 |  |
| Depreciation and amortization expense (b) |  |  | 58.8 |  |
| EBITDA (a + b) |  | $ | 244.7 |  |
| Total debt at September 30, 2011 (c) |  | $ | 499.6 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 2.0 |  |

[0000950123-11-091662:8k_2_02:68]
Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income
Taxes, a GAAP Measure

[0000950123-11-091662:8k_2_02:69]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | September 30, |  |
|  |  | 2011 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 185.9 |  |
| Special product quality adjustment |  |  | (2.6 | ) |
| Items in losses and other expenses, net that are excluded from segment profit |  |  | 9.5 |  |
| Restructuring charges |  |  | 15.0 |  |
| Interest expense, net |  |  | 16.2 |  |
| Other expenses, net |  |  | 1.0 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 146.8 |  |

[0000950123-11-091662:8k_2_02:70]
Reconciliation of Reported Revenue Growth, a GAAP measure, to Organic Revenue Growth, a non-GAAP Measure

[0000950123-11-091662:8k_2_02:71]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Translational |  |  | Net Sales |  |
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |  | Currency |  |  | Growth % |  |
|  |  | For The Three Months |  |  | Net |  |  | Net |  |  | Impact |  |  | Excluding |  |
|  |  | Ended September 30, |  |  | Sales |  |  | Sales |  |  | Favorable |  |  | Currency |  |
|  |  | 2011 |  |  | 2010 |  |  | Variance |  |  | Growth % |  |  | (Unfavorable) |  |  | Impact |  |
| Lennox International Inc. and Subsidiaries |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 923.0 |  |  | $ | 818.2 |  |  | $ | 104.8 |  |  |  | 12.8 | % |  | $ | 19.1 |  |  |  | 10.5 | % |
| Less: Kysor/Warren acquisition |  |  | (71.0 | ) |  |  | — |  |  |  | (71.0 | ) |  |  |  |  |  |  | (0.6 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 852.0 |  |  | $ | 818.2 |  |  | $ | 33.8 |  |  |  | 4.1 | % |  | $ | 18.5 |  |  |  | 1.9 | % |
| Refrigeration Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 223.7 |  |  | $ | 140.6 |  |  | $ | 83.1 |  |  |  | 59.1 | % |  | $ | 10.1 |  |  |  | 51.9 | % |
| Less: Kysor/Warren acquisition |  |  | (71.0 | ) |  |  | — |  |  |  | (71.0 | ) |  |  |  |  |  |  | (0.6 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 152.7 |  |  | $ | 140.6 |  |  | $ | 12.1 |  |  |  | 8.6 | % |  | $ | 9.5 |  |  |  | 1.8 | % |

[0000950123-11-091662:8k_2_02:72]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Translational |  |  | Net Sales |  |
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |  | Currency |  |  | Growth % |  |
|  |  | For The Nine Months |  |  | Net |  |  | Net |  |  | Impact |  |  | Excluding |  |
|  |  | Ended September 30, |  |  | Sales |  |  | Sales |  |  | Favorable |  |  | Currency |  |
|  |  | 2011 |  |  | 2010 |  |  | Variance |  |  | Growth % |  |  | (Unfavorable) |  |  | Impact |  |
| Lennox International Inc. and Subsidiaries |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 2,547.7 |  |  | $ | 2,334.4 |  |  | $ | 213.3 |  |  |  | 9.1 | % |  | $ | 54.6 |  |  |  | 6.8 | % |
| Less: Kysor/Warren acquisition |  |  | (165.1 | ) |  |  | — |  |  |  | (165.1 | ) |  |  |  |  |  |  | (2.0 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 2,382.6 |  |  | $ | 2,334.4 |  |  | $ | 48.2 |  |  |  | 2.1 | % |  | $ | 52.6 |  |  |  | -0.2 | % |
| Refrigeration Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 616.3 |  |  | $ | 411.8 |  |  | $ | 204.5 |  |  |  | 49.7 | % |  | $ | 30.3 |  |  |  | 42.3 | % |
| Less: Kysor/Warren acquisition |  |  | (165.1 | ) |  |  | — |  |  |  | (165.1 | ) |  |  |  |  |  |  | (2.0 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 451.2 |  |  | $ | 411.8 |  |  | $ | 39.4 |  |  |  | 9.6 | % |  | $ | 28.3 |  |  |  | 2.7 | % |

[0000950123-11-091662:8k_2_02:73]
Reconciliation of Reported Refrigeration Segment Profit Margin to Organic Segment Profit Margin

[0000950123-11-091662:8k_2_02:74]
|  |  | For the Three Months Ended September 30, 2011 |  |  | For the Three Months Ended September 30, 2010 |  |
|  |  |  |  |  |  |  |  |  |  | Segment |  |  |  |  |  |  |  |  |  |  | Segment |  |
|  |  | Net |  |  | Segment |  |  | Profit |  |  | Net |  |  | Segment |  |  | Profit |  |
|  |  | Sales |  |  | Profit |  |  | Margin |  |  | Sales |  |  | Profit |  |  | Margin |  |
| Refrigeration Segment, as reported |  | $ | 223.7 |  |  | $ | 20.5 |  |  |  | 9.2 | % |  | $ | 140.6 |  |  | $ | 17.3 |  |  |  | 12.3 | % |
| Less: Kysor/Warren acquisition |  |  | (71.0 | ) |  |  | (1.4 | ) |  |  | -2.0 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Refrigeration Segment, organic |  | $ | 152.7 |  |  | $ | 19.1 |  |  |  | 12.5 | % |  | $ | 140.6 |  |  | $ | 17.3 |  |  |  | 12.3 | % |

[0000950123-11-091662:8k_2_02:75]
|  |  | For the Nine Months Ended September 30, 2011 |  |  | For the Nine Months Ended September 30, 2010 |  |
|  |  |  |  |  |  |  |  |  |  | Segment |  |  |  |  |  |  |  |  |  |  | Segment |  |
|  |  | Net |  |  | Segment |  |  | Profit |  |  | Net |  |  | Segment |  |  | Profit |  |
|  |  | Sales |  |  | Profit |  |  | Margin |  |  | Sales |  |  | Profit |  |  | Margin |  |
| Refrigeration Segment, as reported |  | $ | 616.3 |  |  | $ | 55.5 |  |  |  | 9.0 | % |  | $ | 411.8 |  |  | $ | 47.5 |  |  |  | 11.5 | % |
| Less: Kysor/Warren acquisition |  |  | (165.1 | ) |  |  | 0.2 |  |  |  | 0.1 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Refrigeration Segment, organic |  | $ | 451.2 |  |  | $ | 55.7 |  |  |  | 12.3 | % |  | $ | 411.8 |  |  | $ | 47.5 |  |  |  | 11.5 | % |

[0000950123-11-091662:8k_2_02:76]
Reconciliation of Operational Working Capital, a Non-GAAP Measure, to GAAP Balance Sheet Line Items

[0000950123-11-091662:8k_2_02:77]
|  |  |  |  |  |  | September 30, |  |  |  |  |  |  | September 30, |  |
|  |  |  |  |  |  | 2011 |  |  |  |  |  |  | 2010 |  |
|  |  | September 30, |  |  | Trailing |  |  | September 30, |  |  | Trailing |  |
|  |  | 2011 (c) |  |  | 12 Mo. Avg. (c) |  |  | 2010 |  |  | 12 Mo. Avg. |  |
| Accounts and Notes Receivable, Net |  | $ | 424.6 |  |  |  |  |  |  | $ | 429.2 |  |  |  |  |  |
| Asset Securitization |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Allowance for Doubtful Accounts |  |  | 11.2 |  |  |  |  |  |  |  | 14.9 |  |  |  |  |  |
| Accounts and Notes Receivable, Gross |  |  | 435.8 |  |  | $ | 421.0 |  |  |  | 444.1 |  |  | $ | 405.9 |  |
| Inventories |  |  | 360.4 |  |  |  |  |  |  |  | 347.7 |  |  |  |  |  |
| Excess of Current Cost Over Last-in, First-out |  |  | 71.6 |  |  |  |  |  |  |  | 71.9 |  |  |  |  |  |
| Inventories as Adjusted |  |  | 432.0 |  |  |  | 451.6 |  |  |  | 419.6 |  |  |  | 388.2 |  |
| Accounts Payable |  |  | (313.3 | ) |  |  | (292.1 | ) |  |  | (284.0 | ) |  |  | (280.3 | ) |
| Operating Working Capital (a) |  |  | 554.5 |  |  |  | 580.5 |  |  |  | 579.7 |  |  |  | 513.8 |  |
| Net Sales, Trailing Twelve Months (b) |  |  | 3,144.6 |  |  |  | 3,144.6 |  |  |  | 3,067.9 |  |  |  | 3,067.9 |  |
| Operational Working Capital Ratio (a / b) |  |  | 17.6 | % |  |  | 18.5 | % |  |  | 18.9 | % |  |  | 16.7 | % |

[0000950123-11-091662:8k_2_02:78]
| (c) |  | Excludes the impact of the Kysor/Warren acquisition completed in January 2011. Including the impact of the Kysor/Warren acquisition to the September 30, 2011 operational working capital items above would increase Accounts and Notes Receivable, Gross from $435.8 to $491.7, Inventories as Adjusted from $432.0 to $465.9 and Accounts Payable from $(313.3) to $(343.2). Net Sales, Trailing Twelve Months would increase $165.1 (representing approximately eight and a half months of Net Sales) to $3,309.6 resulting in an Operational Working Capital Ratio of 18.6%. |

## item 1.01 — body, verbatim

[0000950123-11-091662:8k_body:1]
Item 1.01 Entry into a Material Definitive Agreement.

[0000950123-11-091662:8k_body:2]
On October 21, 2011, Lennox International Inc. (the “Company”) entered into a Fourth
Amended and Restated Revolving Credit Facility Agreement (the “Credit Agreement”) with
JPMorgan Chase Bank, National Association, as administrative agent, and the other Lenders party
thereto. The Credit Agreement replaces the Company’s previous credit agreement, the Third Amended
and Restated Revolving Credit Facility Agreement, dated as of October 12, 2007, among the Company, Bank of
America, N.A., as administrative agent, and the other lenders named therein.

[0000950123-11-091662:8k_body:3]
The Credit Agreement provides for an unsecured $650 million revolving credit facility that
matures on October 21, 2016. The revolving credit facility includes a subfacility for swingline
loans of up to $65,000,000 and provides for the issuance of letters of credit for the full amount
of the credit facility. At the Company’s request and subject to certain conditions, the
commitments under the Credit Agreement may be increased by up to $100 million to the extent that
existing or new lenders agree to provide such additional commitments.

[0000950123-11-091662:8k_body:4]
Each
revolving borrowing under the Credit Agreement is comprised of either ABR Loans or Eurodollar Loans. ABR
Loans bear interest at the Alternate Base Rate plus an Applicable Rate. The Alternate Base Rate is
a rate per annum equal to the greatest of (a) the Prime Rate
(b) the Federal Funds Effective Rate  plus 0.5% and (c) the Adjusted LIBO Rate
for a one month interest period. Eurodollar Loans bear interest at the Adjusted LIBO
Rate for the interest period in effect for the applicable borrowing
plus an Applicable Rate. The Adjusted LIBO Rate for such purpose is a rate
per annum equal to (a) the LIBO Rate for the applicable
interest period (or, with respect to the determination of the
Alternate Base Rate and the Eurodollar Daily Floating Rate, for a one
month interest period) multiplied by (b) the Statutory Reserve Rate. The Applicable Rate used in these calculations is
based on the Company’s leverage ratio and ranges from 0% to 1.00% for ABR Loans and from 1.00 to
2.00% for Eurodollar Loans. The Company may prepay the revolving loans at any time without premium
or penalty, other than customary breakage costs in the case of
Eurodollar Loans.

[0000950123-11-091662:8k_body:5]
The Credit Agreement contains several customary covenants including, but not limited to,
limitations on certain indebtedness, liens, mergers, investments, acquisitions and asset sales. In
addition, the Credit Agreement contains financial covenants requiring the Company to maintain a
consolidated leverage ratio of no more than 3.50 to 1.00 as of the most recently ended four fiscal
quarters, and a consolidated interest coverage ratio of at least 3.00 to 1.00 as of the most
recently ended four fiscal quarters. The Credit Agreement is subject to customary events of
default, including, but not limited to, non-payment of principal or other amounts under the Credit
Agreement, material inaccuracy of representations and warranties, breach of covenants,
cross-default to other material indebtedness, certain voluntary and involuntary bankruptcy events,
and the occurrence of a change of control. The occurrence of an event of default could result in the acceleration
of amounts due, and termination of the lenders’ commitments, under the Credit Agreement.

[0000950123-11-091662:8k_body:6]
The Company’s obligations under the Credit Agreement are required to be guaranteed by certain
of its material domestic subsidiaries. The initial subsidiary guarantors are Allied Air Enterprises
Inc., Advanced Distributor Products LLC, Heatcraft Inc., Heatcraft Refrigeration Products LLC,
Lennox Global Ltd., Lennox Industries Inc., Service Experts LLC and Service Experts Heating & Air
Conditioning LLC.

[0000950123-11-091662:8k_body:7]
A copy of the Credit Agreement is filed as Exhibit 10.1 hereto. The foregoing description of
the Credit Agreement does not purport to be complete and is qualified in its entirety by reference
to the full text of the Credit Agreement, which is incorporated by reference herein.
