# LII 8-K — 0001069202-25-000015 filed 2025-04-23

## item codes, every 8-K on or before 2025-04-23

- 2025-04-23 0001069202-25-000015 — 2.02, 9.01
- 2025-03-13 0001069202-25-000005 — 4.01, 9.01
- 2025-01-29 0001628280-25-002910 — 2.02, 9.01
- 2024-12-06 0001628280-24-050201 — 5.02
- 2024-10-23 0001628280-24-043349 — 2.02, 5.02, 7.01, 9.01
- 2024-07-24 0001628280-24-032683 — 2.02, 9.01
- 2024-05-23 0001628280-24-024875 — 5.02, 9.01
- 2024-05-20 0001628280-24-024385 — 5.07
- 2024-04-24 0001628280-24-017515 — 2.02, 9.01
- 2024-03-18 0001628280-24-011594 — 5.02, 9.01
- 2024-01-31 0001628280-24-002634 — 2.02, 9.01
- 2023-12-11 0001628280-23-041239 — 5.02, 9.01 — amendment of 0001628280-23-035187
- 2023-12-08 0001628280-23-041128 — 5.02
- 2023-10-26 0001628280-23-035187 — 2.02, 5.02, 7.01, 9.01
- 2023-09-21 0001628280-23-032729 — 8.01, 9.01
- 2023-09-15 0001628280-23-032385 — 1.01, 2.03, 8.01, 9.01
- 2023-09-12 0001628280-23-032078 — 8.01, 9.01
- 2023-08-28 0001628280-23-030777 — 1.01, 2.03, 9.01
- 2023-08-25 0001628280-23-030602 — 8.01, 9.01
- 2023-07-27 0001628280-23-025808 — 2.02, 9.01
- 2023-05-19 0001628280-23-019040 — 5.07
- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2025-04-23

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-25-000015:8k_2_02:1]
EX-99.1
2
lii-2025331xexx991pressrel.htm
EX-99.1

[0001069202-25-000015:8k_2_02:2]
Document

[0001069202-25-000015:8k_2_02:3]
Exhibit 99.1

[0001069202-25-000015:8k_2_02:4]
Lennox Reports First Quarter Results

[0001069202-25-000015:8k_2_02:5]
____________________________________________________________________________

[0001069202-25-000015:8k_2_02:6]
Q1 Highlights

[0001069202-25-000015:8k_2_02:7]
(All comparisons are year-over-year, unless otherwise noted)

[0001069202-25-000015:8k_2_02:8]
•Revenue $1.1 billion, up 2%

[0001069202-25-000015:8k_2_02:9]
•GAAP Operating Income $156 million  –  Segment profit down 7% to $156 million

[0001069202-25-000015:8k_2_02:10]
•GAAP diluted EPS $3.37  –  Adjusted diluted EPS down 3% to $3.37

[0001069202-25-000015:8k_2_02:11]
•Maintaining 2% revenue guidance and narrowing the adjusted EPS range to $22.25-$23.50

[0001069202-25-000015:8k_2_02:12]
____________________________________________________________________________

[0001069202-25-000015:8k_2_02:13]
DALLAS, April 23, 2025 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported first quarter financial results with $1.1 billion of revenue, $156 million of operating income and $3.37 GAAP diluted earnings per share.

[0001069202-25-000015:8k_2_02:14]
Revenue grew 2% to $1.1 billion. Segment profit decreased 7% to $156 million. Segment margin was down 140 basis points to 14.5%. Adjusted diluted earnings per share decreased 3% to $3.37.

[0001069202-25-000015:8k_2_02:15]
“Our results this quarter highlight the strength of our replacement-driven business model and the value of our North American-focused strategy. We are navigating the shifting trade dynamics with flexibility, supported by a more resilient supply chain built through past disruptions,” said CEO, Alok Maskara. “While the current environment presents uncertainty, we remain focused on being a reliable partner to our customers and making necessary pricing adjustments to maintain supply chain stability. We are narrowing our full-year guidance, with pricing expected to offset any volume impacts.”

[0001069202-25-000015:8k_2_02:16]
The Home Comfort Solutions segment achieved 7% revenue growth in the first quarter, driven by favorable product and channel mix along with sustained pricing excellence. Segment profit margins decreased by 40 basis points, driven by tariff and commodity impacts. Sales volumes were flat as dealers and distributors continued to purchase remaining R-410A inventory while transitioning to the new low GWP product. Replacement-driven demand continues to serve as a stable foundation for this business.

[0001069202-25-000015:8k_2_02:17]
Building Climate Solutions segment revenue decreased by 6% this quarter, as sales volumes were impacted by the timing of customer transitions to low GWP products. There were also expected factory cost inefficiencies during the transition. In addition, timing of tariff related costs compared to pricing realization put temporary pressure on segment profit margins. Despite these headwinds, order rates remain healthy as low GWP adoption grows and emergency replacement activity gains momentum.

[0001069202-25-000015:8k_2_02:18]
FIRST QUARTER 2025 FINANCIAL HIGHLIGHTS

[0001069202-25-000015:8k_2_02:19]
(All comparisons are year-over-year, unless otherwise noted)

[0001069202-25-000015:8k_2_02:20]
Revenue: $1.1 billion was up 2% driven by favorable price and mix benefits.

[0001069202-25-000015:8k_2_02:21]
Operating Income: $156 million, down 7%, with operating profit margin of 14.5%, down 140 basis points.

[0001069202-25-000015:8k_2_02:22]
Segment Profit: $156 million, down 7%, and segment profit margin of 14.5%, down 140 basis points. Profit decline can be attributed to $12 million in sales volume; $29 million of product cost primarily related to tariff impacts and factory inefficiencies; and, $10 million of other costs, including distribution investments, freight and selling expense. This was partially offset by $40 million of price/mix benefits, driven primarily by the transition to the new low GWP product.

[0001069202-25-000015:8k_2_02:23]
Net Income: $120 million, or $3.37 per share, compared to $124 million, or $3.47 per share, in the prior-year quarter.

[0001069202-25-000015:8k_2_02:24]
Adjusted Net Income: $120 million, or $3.37 per share, compared to $124 million, or $3.47 per share, in the prior-year quarter.

[0001069202-25-000015:8k_2_02:25]
Cash Flow: Operating cash flow used was $36 million compared to $23 million in the prior-year quarter. Net capital expenditures were $25 million compared to $29 million in the prior-year quarter. This quarter the company repurchased $85 million in shares.

[0001069202-25-000015:8k_2_02:26]
Home Comfort Solutions: Business segment revenue was $721 million, up 7%. Segment profit was $117 million, up 4%, and segment margin was 16.2%, down 40 basis points. Segment profit increased $5 million compared to the prior-year quarter. The increase was driven by $31 million in price/mix benefits. This was partially offset by a $15 million increase in product costs driven by the impact of tariffs. Profit was also impacted by $11 million of continued investments in distribution and selling and other miscellaneous items.

[0001069202-25-000015:8k_2_02:27]
Building Climate Solutions: Business segment revenue was $351 million, down 6%. Segment profit was $54 million, down $25 million or 32%, and segment margin decreased 580 basis points to 15.2%. The decline was driven by a $12 million decrease in sales volume; $14 million of expense related to the new factory ramp-up, manufacturing inefficiencies at existing facilities, and the impact of tariffs; and $8 million in investments in emergency replacement sales force and other miscellaneous items. These impacts were offset by $9 million in price/mix benefits.

[0001069202-25-000015:8k_2_02:28]
Corporate and Other: Corporate expenses were $15 million, a decrease of $9 million versus the prior-year quarter primarily driven by timing.

[0001069202-25-000015:8k_2_02:29]
FULL YEAR 2025 GUIDANCE

[0001069202-25-000015:8k_2_02:30]
For full year 2025, adjusted earnings per share is now expected to be within the range of $22.25 to $23.50.

[0001069202-25-000015:8k_2_02:31]
Revenue is still anticipated to increase by approximately 2%. We now expect additional pricing gains to overcome tariffs while preserving profit margins and offsetting the impact of potential volume declines.

[0001069202-25-000015:8k_2_02:32]
Capital expenditures are still projected to be approximately $150 million, and the Free Cash Flow range remains at  $650 million to $800 million.

[0001069202-25-000015:8k_2_02:33]
CONFERENCE CALL INFORMATION

[0001069202-25-000015:8k_2_02:34]
A conference call to discuss the company’s first quarter results will be held this morning at 8:30 a.m. Central Time. To participate in the earnings conference, please call 800-343-4136 (U.S.) or +1 203-518-9843 (international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ125. The conference call also will be webcast live on the company’s investor relations web site at investor.lennox.com. A replay of the conference call will be available until April 30, 2025, by calling toll-free 800-839-1180 (U.S.) or +1 402-220-0400 (international). The call will also be archived on the company's investor relations website at investor.lennox.com.

[0001069202-25-000015:8k_2_02:35]
ABOUT LENNOX

[0001069202-25-000015:8k_2_02:36]
Lennox (NYSE: LII) is a leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our cooling, heating, indoor air quality, and refrigeration systems. Additional information on Lennox is available at Lennox.com or by contacting investor@lennox.com.

[0001069202-25-000015:8k_2_02:37]
FORWARD-LOOKING STATEMENTS & NON-GAAP FINANCIAL MEASURES

[0001069202-25-000015:8k_2_02:38]
For information concerning these and other risks and uncertainties, see LII’s publicly available filings with the Securities and Exchange Commission. LII disclaims any intention or obligation to update or revise any forward-looking statements, whether as a result of new information, future events or otherwise, except as required by law.

[0001069202-25-000015:8k_2_02:39]
A reconciliation of non-GAAP financial measures appearing in this document to financial measures prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP) are included in the Annex to this document.

[0001069202-25-000015:8k_2_02:40]
This document includes forward-looking statements regarding segment profit, adjusted net income, adjusted diluted earnings per share, free cash flow, and Debt to EBITDA, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, changes in environmental liabilities, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on LII’s full year GAAP financial results.

[0001069202-25-000015:8k_2_02:41]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-25-000015:8k_2_02:42]
Consolidated Statements of Operations

[0001069202-25-000015:8k_2_02:43]
(Unaudited)

[0001069202-25-000015:8k_2_02:44]
| (Amounts in millions, except per share data) | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Net sales | $ | 1,072.6 |  |  | $ | 1,047.1 |  |  |  |  |  |
| Cost of goods sold | 744.1 |  |  | 707.1 |  |  |  |  |  |
| Gross profit | 328.5 |  |  | 340.0 |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 171.3 |  |  | 170.7 |  |  |  |  |  |
| Losses and other expenses, net | 2.8 |  |  | 3.7 |  |  |  |  |  |
| Income from equity method investments | (1.2) |  |  | (1.2) |  |  |  |  |  |
| Operating income | 155.6 |  |  | 166.8 |  |  |  |  |  |
| Pension settlements | 0.1 |  |  | — |  |  |  |  |  |
| Interest expense, net | 6.2 |  |  | 11.8 |  |  |  |  |  |
| Other expense, net | 0.9 |  |  | 0.8 |  |  |  |  |  |
| Income before income taxes | 148.4 |  |  | 154.2 |  |  |  |  |  |
| Provision for income taxes | 28.1 |  |  | 29.9 |  |  |  |  |  |
| Net income | $ | 120.3 |  |  | $ | 124.3 |  |  |  |  |  |
| Earnings per share – Basic: | $ | 3.39 |  |  | $ | 3.49 |  |  |  |  |  |
| Earnings per share – Diluted: | $ | 3.37 |  |  | $ | 3.47 |  |  |  |  |  |
| Weighted Average Number of Shares Outstanding - Basic | 35.5 |  |  | 35.6 |  |  |  |  |  |
| Weighted Average Number of Shares Outstanding - Diluted | 35.7 |  |  | 35.8 |  |  |  |  |  |

[0001069202-25-000015:8k_2_02:45]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |
| Segment Net Sales and Profit (Loss) |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |

[0001069202-25-000015:8k_2_02:46]
| (Amounts in millions) | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Net Sales |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 721.4 |  |  | $ | 674.6 |  |  |  |  |  |
| Building Climate Solutions | 351.2 |  |  | 372.5 |  |  |  |  |  |
| Corporate and other | — |  |  | — |  |  |  |  |  |
| Total segment sales | $ | 1,072.6 |  |  | $ | 1,047.1 |  |  |  |  |  |
| Segment Profit (Loss)(1) |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 116.8 |  |  | $ | 112.1 |  |  |  |  |  |
| Building Climate Solutions | 53.5 |  |  | 78.2 |  |  |  |  |  |
| Corporate and other | (14.7) |  |  | (23.5) |  |  |  |  |  |
| Total segment profit | 155.6 |  |  | 166.8 |  |  |  |  |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Restructuring charges | — |  |  | — |  |  |  |  |  |
| Loss (gain) on sale from previous dispositions | — |  |  | — |  |  |  |  |  |
| Operating income | $ | 155.6 |  |  | $ | 166.8 |  |  |  |  |  |

[0001069202-25-000015:8k_2_02:47]
(1) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-25-000015:8k_2_02:48]
•Restructuring charges, and;

[0001069202-25-000015:8k_2_02:49]
•Loss (gain) on sale of previous dispositions

[0001069202-25-000015:8k_2_02:50]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-25-000015:8k_2_02:51]
Consolidated Balance Sheets

[0001069202-25-000015:8k_2_02:52]
| (Amounts in millions, except shares and par values) | As of March 31, 2025 |  | As of December 31, 2024 |
| ASSETS | (Unaudited) |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 217.2 |  |  | $ | 415.1 |  |
| Short-term investments | 5.7 |  |  | 7.2 |  |
| Accounts and notes receivable, net of allowances of $16.2 and $17.8 in 2025 and 2024, respectively | 651.7 |  |  | 661.1 |  |
| Inventories, net | 902.3 |  |  | 704.8 |  |
| Other current assets | 78.1 |  |  | 96.0 |  |
| Total current assets | 1,855.0 |  |  | 1,884.2 |  |
| Property, plant and equipment, net of accumulated depreciation of $978.3 and $956.8 in 2025 and 2024, respectively | 810.3 |  |  | 800.1 |  |
| Right-of-use assets from operating leases | 323.1 |  |  | 327.2 |  |
| Goodwill | 220.0 |  |  | 220.0 |  |
| Deferred income taxes | 76.6 |  |  | 75.1 |  |
| Other assets, net | 170.4 |  |  | 165.2 |  |
| Total assets | $ | 3,455.4 |  |  | $ | 3,471.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current Liabilities: |  |  |  |
| Accounts payable | $ | 576.6 |  |  | $ | 490.0 |  |
| Accrued expenses | 326.3 |  |  | 435.4 |  |
| Current maturities of long-term debt | 315.2 |  |  | 314.5 |  |
| Current operating lease liabilities | 76.5 |  |  | 73.4 |  |
| Total current liabilities | 1,294.6 |  |  | 1,313.3 |  |
| Long-term debt | 834.2 |  |  | 833.1 |  |
| Long-term operating lease liabilities | 263.9 |  |  | 267.6 |  |
| Pensions | 19.7 |  |  | 18.9 |  |
| Other liabilities | 190.5 |  |  | 188.7 |  |
| Total liabilities | 2,602.9 |  |  | 2,621.6 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' equity: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,219.0 |  |  | 1,213.3 |  |
| Retained earnings | 4,230.3 |  |  | 4,150.8 |  |
| Accumulated other comprehensive loss | (80.6) |  |  | (93.7) |  |
| Treasury stock, at cost, 51,678,069 shares and 51,573,986 shares for 2025 and 2024, respectively | (4,517.1) |  |  | (4,421.1) |  |
| Total stockholders' equity | 852.5 |  |  | 850.2 |  |
| Total liabilities and stockholders' equity | $ | 3,455.4 |  |  | $ | 3,471.8 |  |

[0001069202-25-000015:8k_2_02:53]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-25-000015:8k_2_02:54]
Consolidated Statements of Cash Flows

[0001069202-25-000015:8k_2_02:55]
(Unaudited)

[0001069202-25-000015:8k_2_02:56]
| (Amounts in millions) | For the Three Months Ended March 31, |  |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income | $ | 120.3 |  |  | $ | 124.3 |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments | (1.2) |  |  | (1.2) |  |  |  |  |  |  |
| Provision for credit losses | 1.3 |  |  | 1.8 |  |  |  |  |  |  |
| Unrealized (gains) losses, net on derivative contracts | (0.5) |  |  | 4.4 |  |  |  |  |  |  |
| Stock-based compensation expense | 6.3 |  |  | 6.6 |  |  |  |  |  |  |
| Depreciation and amortization | 25.6 |  |  | 24.0 |  |  |  |  |  |  |
| Deferred income taxes | (4.2) |  |  | (9.3) |  |  |  |  |  |  |
| Pension expense | 1.1 |  |  | 0.1 |  |  |  |  |  |  |
| Pension contributions | (0.3) |  |  | (5.1) |  |  |  |  |  |  |
| Other items, net | — |  |  | (0.1) |  |  |  |  |  |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable | 8.3 |  |  | (24.9) |  |  |  |  |  |  |
| Inventories | (197.0) |  |  | (125.4) |  |  |  |  |  |  |
| Other current assets | (1.7) |  |  | (7.7) |  |  |  |  |  |  |
| Accounts payable | 85.2 |  |  | 65.0 |  |  |  |  |  |  |
| Accrued expenses | (105.1) |  |  | (113.8) |  |  |  |  |  |  |
| Income taxes payable and receivable, net | 27.1 |  |  | 34.7 |  |  |  |  |  |  |
| Leases, net | 3.4 |  |  | (1.1) |  |  |  |  |  |  |
| Other, net | (4.4) |  |  | 4.9 |  |  |  |  |  |  |
| Net cash used in operating activities | (35.8) |  |  | (22.8) |  |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.5 |  |  | 0.5 |  |  |  |  |  |  |
| Purchases of property, plant and equipment | (25.5) |  |  | (29.5) |  |  |  |  |  |  |
| Acquisitions, net of cash | — |  |  | 1.8 |  |  |  |  |  |  |
| Proceeds from (purchases of) investments and other | 1.5 |  |  | (3.5) |  |  |  |  |  |  |
| Net cash used in investing activities | (23.5) |  |  | (30.7) |  |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings from debt arrangements | — |  |  | 303.6 |  |  |  |  |  |  |
| Payments on debt arrangements | (5.0) |  |  | (215.1) |  |  |  |  |  |  |
| Proceeds from employee stock purchases | 1.2 |  |  | 1.1 |  |  |  |  |  |  |
| Repurchases of common stock | (85.2) |  |  | — |  |  |  |  |  |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (11.3) |  |  | (8.1) |  |  |  |  |  |  |
| Cash dividends paid | (40.9) |  |  | (39.1) |  |  |  |  |  |  |
| Net cash (used in) provided by financing activities | (141.2) |  |  | 42.4 |  |  |  |  |  |  |
| Decrease in cash and cash equivalents | (200.5) |  |  | (11.1) |  |  |  |  |  |  |
| Effect of exchange rates on cash and cash equivalents | 2.6 |  |  | (3.9) |  |  |  |  |  |  |
| Cash and cash equivalents, beginning of period | 415.1 |  |  | 60.7 |  |  |  |  |  |  |
| Cash and cash equivalents, end of period | $ | 217.2 |  |  | $ | 45.7 |  |  |  |  |  |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid | $ | 19.2 |  |  | $ | 21.8 |  |  |  |  |  |  |
| Income taxes paid (net of refunds) | $ | 5.1 |  |  | $ | 4.0 |  |  |  |  |  |  |

[0001069202-25-000015:8k_2_02:57]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit (loss) presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company's business trends and operating performance. |
| Reconciliation of Net income, a GAAP measure, to Adjusted net income, a Non-GAAP measure |
|  | For the Three Months Ended March 31, |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |  |
|  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  |  |  |  |  |  |  |  |
| Net income, a GAAP measure | $ | 120.3 |  | $ | 3.37 |  |  | $ | 124.3 |  | $ | 3.47 |  |  |  |  |  |  |  |  |  |
| Restructuring charges | — |  | — |  |  | — |  | — |  |  |  |  |  |  |  |  |  |
| Loss (gain) on sale from previous dispositions | — |  | — |  |  | — |  | — |  |  |  |  |  |  |  |  |  |
| Adjusted net income, a non-GAAP measure | $ | 120.3 |  | $ | 3.37 |  |  | $ | 124.3 |  | $ | 3.47 |  |  |  |  |  |  |  |  |  |

[0001069202-25-000015:8k_2_02:58]
| Reconciliation of Net Cash Used in Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure |
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Net cash used in operating activities | $ | (35.8) |  |  | $ | (22.8) |  |  |  |  |  |
| Purchases of property, plant and equipment | (25.5) |  |  | (29.5) |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.5 |  |  | 0.5 |  |  |  |  |  |
| Free cash flow, a Non-GAAP measure | $ | (60.8) |  |  | $ | (51.8) |  |  |  |  |  |
