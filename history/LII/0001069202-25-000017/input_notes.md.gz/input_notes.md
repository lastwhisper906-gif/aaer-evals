# LII notes — 0001069202-25-000017


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-25-000017:notes:1]
[same as prior period, unchanged from 0001628280-24-043392:notes:1]

[0001069202-25-000017:notes:2]
[same as prior period, unchanged from 0001628280-24-043392:notes:2]

[0001069202-25-000017:notes:3]
[same as prior period, unchanged from 0001628280-24-043392:notes:3]

[0001069202-25-000017:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2025, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2025 and 2024, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2025 and 2024, the accompanying unaudited Consolidated Statements of Stockholders' Equity for the three months ended March 31, 2025 and 2024, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2025 and 2024 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2024.

[0001069202-25-000017:notes:5]
[same as prior period, unchanged from 0001628280-24-043392:notes:5]

[0001069202-25-000017:notes:6]
[same as prior period, unchanged from 0001628280-24-043392:notes:6]

[0001069202-25-000017:notes:7]
[same as prior period, unchanged from 0001628280-24-043392:notes:7]

[0001069202-25-000017:notes:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-25-000017:notes:9]
[same as prior period, unchanged from 0001628280-24-043392:notes:9]

[0001069202-25-000017:notes:10]
[same as prior period, unchanged from 0001628280-24-043392:notes:10]

[0001069202-25-000017:notes:11]
[same as prior period, unchanged from 0001628280-24-043392:notes:11]

[0001069202-25-000017:notes:12]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before interest and income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation in the table below details the items excluded.

[0001069202-25-000017:notes:13]
[same as prior period, unchanged from 0001628280-24-043392:notes:13]

[0001069202-25-000017:notes:14]
The chief operating decision maker uses segment profit or loss from operations before interest and income taxes, excluding certain items, and return on sales to allocate resources (including employees, financial, or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances in segment profit or loss and its individual components as well as return on sales on a monthly basis when evaluating segment performance and making decisions about allocating resources to the segments.

[0001069202-25-000017:notes:15]
Our chief operating decision maker is Alok Maskara, Chief Executive Officer.

[0001069202-25-000017:notes:16]
Key financial information for each segment is shown below (in millions):

[0001069202-25-000017:notes:17]
|  | Home Comfort Solutions |  | Business Climate Solutions |  | Corporate and Other |  | Total |
| Three months ended March 31, 2025 |  |  |  |  |  |  |  |
| Net Sales(1) | $ | 721.4 |  |  | $ | 351.2 |  |  | $ | — |  |  | $ | 1,072.6 |  |
| Cost of Goods Sold | 507.2 |  |  | 237.2 |  |  | (0.3) |  |  | 744.1 |  |
| Selling, general and administrative | 98.4 |  |  | 60.4 |  |  | 12.5 |  |  | 171.3 |  |
| Other (income) expense(2) | (1.0) |  |  | 0.1 |  |  | 2.5 |  |  | 1.6 |  |
| Segment profit (loss)(3) | $ | 116.8 |  |  | $ | 53.5 |  |  | $ | (14.7) |  |  | $ | 155.6 |  |
| Three months ended March 31, 2024 |  |  |  |  |  |  |  |
| Net Sales(1) | $ | 674.6 |  |  | $ | 372.5 |  |  | $ | — |  |  | $ | 1,047.1 |  |
| Cost of Goods Sold | 466.1 |  |  | 241.3 |  |  | (0.3) |  |  | 707.1 |  |
| Selling, general and administrative | 97.5 |  |  | 53.6 |  |  | 19.6 |  |  | 170.7 |  |
| Other (income) expense(2) | (1.1) |  |  | (0.6) |  |  | 4.2 |  |  | 2.5 |  |
| Segment profit (loss)(3) | $ | 112.1 |  |  | $ | 78.2 |  |  | $ | (23.5) |  |  | $ | 166.8 |  |

[0001069202-25-000017:notes:18]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-25-000017:notes:19]
(2) Other (income) expense is primarily comprised of (income) loss from equity method investments and losses and other expenses, net.

[0001069202-25-000017:notes:20]
(3) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-25-000017:notes:21]
•Restructuring charges, and;

[0001069202-25-000017:notes:22]
•Loss (gain) on sale from previous dispositions.

[0001069202-25-000017:notes:23]
The reconciliations of segment profit to Operating income and Net income before income taxes are presented below (in millions):

[0001069202-25-000017:notes:24]
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Total segment profit(1) | $ | 155.6 |  |  | $ | 166.8 |  |  |  |  |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Restructuring charges | — |  |  | — |  |  |  |  |  |
| Loss (gain) on sale from previous dispositions | — |  |  | — |  |  |  |  |  |
| Operating income | 155.6 |  |  | 166.8 |  |  |  |  |  |
| Reconciliation to income before income taxes: |  |  |  |  |  |  |  |
| Pension settlements | 0.1 |  |  | — |  |  |  |  |  |
| Interest expense, net | 6.2 |  |  | 11.8 |  |  |  |  |  |
| Other expense, net | 0.9 |  |  | 0.8 |  |  |  |  |  |
| Income before income taxes | $ | 148.4 |  |  | $ | 154.2 |  |  |  |  |  |

[0001069202-25-000017:notes:25]
(1)  We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-25-000017:notes:26]
Total assets by segment are shown below (in millions) as of:

[0001069202-25-000017:notes:27]
|  | March 31, 2025 |  | December 31, 2024 |
| Total Assets: |  |  |  |
| Home Comfort Solutions | $ | 1,761.6 |  |  | $ | 1,626.0 |  |
| Building Climate Solutions | 1,108.0 |  |  | 1,052.6 |  |
| Corporate and Other | 585.8 |  |  | 793.2 |  |
| Total assets | $ | 3,455.4 |  |  | $ | 3,471.8 |  |

[0001069202-25-000017:notes:28]
The assets in the Corporate and Other segment primarily consist of cash, property, plant and equipment and short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-25-000017:notes:29]
Total capital expenditures by segment are shown below (in millions):

[0001069202-25-000017:notes:30]
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Capital Expenditures: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 11.4 |  |  | $ | 14.2 |  |  |  |  |  |
| Building Climate Solutions | 6.3 |  |  | 10.4 |  |  |  |  |  |
| Corporate and Other | 7.8 |  |  | 4.9 |  |  |  |  |  |
| Total capital expenditures | $ | 25.5 |  |  | $ | 29.5 |  |  |  |  |  |

[0001069202-25-000017:notes:31]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-25-000017:notes:32]
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Depreciation and Amortization: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 10.4 |  |  | $ | 10.8 |  |  |  |  |  |
| Building Climate Solutions | 7.9 |  |  | 5.7 |  |  |  |  |  |
| Corporate and Other | 7.3 |  |  | 7.5 |  |  |  |  |  |
| Total depreciation and amortization | $ | 25.6 |  |  | $ | 24.0 |  |  |  |  |  |

[0001069202-25-000017:notes:33]
The income from equity method investments is shown below (in millions):

[0001069202-25-000017:notes:34]
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Income from Equity Method Investments: |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 0.7 |  |  | $ | 0.9 |  |  |  |  |  |
| Building Climate Solutions | 0.4 |  |  | 0.4 |  |  |  |  |  |
| Corporate and Other | 0.1 |  |  | (0.1) |  |  |  |  |  |
| Total income from equity method investments | $ | 1.2 |  |  | $ | 1.2 |  |  |  |  |  |

[0001069202-25-000017:notes:35]
Geographic Information

[0001069202-25-000017:notes:36]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions) as of:

[0001069202-25-000017:notes:37]
|  | March 31, 2025 |  | December 31, 2024 |  |  |  |  |
| Property, Plant and Equipment, net: |  |  |  |  |  |  |  |
| United States | $ | 544.3 |  |  | $ | 537.3 |  |  |  |  |  |
| Mexico | 255.7 |  |  | 254.0 |  |  |  |  |  |
| Canada | 2.8 |  |  | 2.9 |  |  |  |  |  |
| Other international | 7.5 |  |  | 5.9 |  |  |  |  |  |
| Total Property, plant and equipment, net | $ | 810.3 |  |  | $ | 800.1 |  |  |  |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-25-000017:notes:38]
[same as prior period, unchanged from 0001628280-24-043392:notes:23]

[0001069202-25-000017:notes:39]
[same as prior period, unchanged from 0001628280-24-043392:notes:24]

[0001069202-25-000017:notes:40]
[same as prior period, unchanged from 0001628280-24-043392:notes:25]

[0001069202-25-000017:notes:41]
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Net income | $ | 120.3 |  |  | $ | 124.3 |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 35.5 |  |  | 35.6 |  |  |  |  |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.2 |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 35.7 |  |  | 35.8 |  |  |  |  |  |
| Earnings per share – Basic: | $ | 3.39 |  |  | $ | 3.49 |  |  |  |  |  |
| Earnings per share – Diluted: | $ | 3.37 |  |  | $ | 3.47 |  |  |  |  |  |

[0001069202-25-000017:notes:42]
[same as prior period, unchanged from 0001628280-24-043392:notes:27]

[0001069202-25-000017:notes:43]
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Weighted-average number of shares | — |  |  | — |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-25-000017:notes:44]
4. Commitments and Contingencies:

[0001069202-25-000017:notes:45]
Leases

[0001069202-25-000017:notes:46]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.  We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001069202-25-000017:notes:47]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition of a lease under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-25-000017:notes:48]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-25-000017:notes:49]
We lease certain real and personal property under non-cancelable operating leases. Approximately 81% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-25-000017:notes:50]
Product Warranties and Product Related Contingencies

[0001069202-25-000017:notes:51]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001069202-25-000017:notes:52]
Liabilities for estimated product warranty costs are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:

[0001069202-25-000017:notes:53]
|  | March 31, 2025 |  | December 31, 2024 |
| Accrued expenses | $ | 51.2 |  |  | $ | 49.1 |  |
| Other liabilities | 111.3 |  |  | 109.4 |  |
| Total warranty liability | $ | 162.5 |  |  | $ | 158.4 |  |

[0001069202-25-000017:notes:54]
The changes in product warranty liabilities for the three months ended March 31, 2025 were as follows (in millions):

[0001069202-25-000017:notes:55]
| Total warranty liability as of December 31, 2024 | $ | 158.4 |  |
| Warranty claims paid | (8.0) |  |
| Changes resulting from issuance of new warranties | 11.4 |  |
| Changes in estimates associated with pre-existing liabilities | 0.6 |  |
| Changes in foreign currency translation rates and other | 0.1 |  |
| Total warranty liability as of March 31, 2025 | $ | 162.5 |  |

[0001069202-25-000017:notes:56]
Litigation

[0001069202-25-000017:notes:57]
We are involved in a number of claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-25-000017:notes:58]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-25-000017:notes:59]
[same as prior period, unchanged from 0001628280-24-043392:notes:45]

[0001069202-25-000017:notes:60]
Our Board of Directors has authorized a total of $4.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in July 2021. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. Such repurchases may also be made in compliance with Rule 10b5-1 trading plans entered into by us, which would permit common stock to be repurchased when the Company might otherwise be precluded from doing so under insider trading laws or self-imposed trading restrictions. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of March 31, 2025, $406.1 million was available for repurchase under the Share Repurchase Plans.

[0001069202-25-000017:notes:61]
For the three months ended March 31, 2025, we repurchased 144,532 shares at an aggregate cost, inclusive of fees, of $85.8 million.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-25-000017:notes:62]
[same as prior period, unchanged from 0001628280-24-043392:notes:48]

[0001069202-25-000017:notes:63]
[same as prior period, unchanged from 0001628280-24-043392:notes:49]

[0001069202-25-000017:notes:64]
|  | For the Three Months Ended March 31, 2025 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 667.8 |  |  | $ | 332.6 |  |  | $ | — |  |  | $ | 1,000.4 |  |
| Canada | 53.6 |  |  | 18.6 |  |  | — |  |  | 72.2 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 721.4 |  |  | $ | 351.2 |  |  | $ | — |  |  | $ | 1,072.6 |  |

[0001069202-25-000017:notes:65]
|  | For the Three Months Ended March 31, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 626.1 |  |  | $ | 357.3 |  |  | $ | — |  |  | $ | 983.4 |  |
| Canada | 48.5 |  |  | 15.2 |  |  | — |  |  | 63.7 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 674.6 |  |  | $ | 372.5 |  |  | $ | — |  |  | $ | 1,047.1 |  |

[0001069202-25-000017:notes:66]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2025 and 2024, direct sales represented 73% and 74% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-25-000017:notes:67]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. We also provide installation, service and preventive maintenance for HVAC national account customers in the United States and Canada, and manufacture curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2025 and 2024, equipment sales represented 79% and 83% of revenues and the remainder of our revenue was generated from our service business.

[0001069202-25-000017:notes:68]
[same as prior period, unchanged from 0001628280-24-043392:notes:57]

[0001069202-25-000017:notes:69]
|  | March 31, 2025 |  | December 31, 2024 |  |  |  |  |
| Contract assets | $ | 1.6 |  |  | $ | 1.2 |  |  |  |  |  |
| Contract liabilities - current | (4.6) |  |  | (5.0) |  |  |  |  |  |
| Contract liabilities - noncurrent | (8.8) |  |  | (8.4) |  |  |  |  |  |
| Total | $ | (11.8) |  |  | $ | (12.2) |  |  |  |  |  |

[0001069202-25-000017:notes:70]
For the three months ended March 31, 2025 and 2024, we recognized revenue of $2.3 million and $5.7 million related to our contract liabilities at January 1, 2025 and 2024, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2025 and 2024.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-25-000017:notes:71]
[same as prior period, unchanged from 0001628280-24-043392:notes:60]

[0001069202-25-000017:notes:72]
[same as prior period, unchanged from 0001628280-24-043392:notes:61]

[0001069202-25-000017:notes:73]
|  | March 31, 2025 |  | December 31, 2024 |
| Finished goods | $ | 599.6 |  |  | $ | 422.6 |  |
| Work in process | 8.1 |  |  | 11.0 |  |
| Raw materials and parts | 441.3 |  |  | 410.7 |  |
| Subtotal | 1,049.0 |  |  | 844.3 |  |
| Excess of current cost over last-in, first-out cost | (146.7) |  |  | (139.5) |  |
| Total inventories, net | $ | 902.3 |  |  | $ | 704.8 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-25-000017:notes:74]
[same as prior period, unchanged from 0001628280-24-043392:notes:63]

[0001069202-25-000017:notes:75]
The changes in the carrying amount of goodwill in 2025, in total and by segment, are summarized in the table below (in millions):

[0001069202-25-000017:notes:76]
|  | Balance as of December 31, 2024 |  | Goodwill Adjustment |  |  |  | Balance as of March 31, 2025 |
| Home Comfort Solutions | $ | 26.1 |  |  | $ | — |  |  |  |  | $ | 26.1 |  |
| Building Climate Solutions | 193.9 |  |  | — |  |  |  |  | 193.9 |  |
| Total Goodwill | $ | 220.0 |  |  | $ | — |  |  |  |  | $ | 220.0 |  |

[0001069202-25-000017:notes:77]
We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We have not recorded any goodwill impairments for the three months ended March 31, 2025 or in any periods presented for our continuing businesses.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-25-000017:notes:78]
[same as prior period, unchanged from 0001628280-24-043392:notes:68]

[0001069202-25-000017:notes:79]
[same as prior period, unchanged from 0001628280-24-043392:notes:69]

[0001069202-25-000017:notes:80]
[same as prior period, unchanged from 0001628280-24-043392:notes:70]

[0001069202-25-000017:notes:81]
[same as prior period, unchanged from 0001628280-24-043392:notes:71]

[0001069202-25-000017:notes:82]
[same as prior period, unchanged from 0001628280-24-043392:notes:72]

[0001069202-25-000017:notes:83]
[same as prior period, unchanged from 0001628280-24-043392:notes:73]

[0001069202-25-000017:notes:84]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through September 2026.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions) as of:

[0001069202-25-000017:notes:85]
|  | March 31, 2025 |  | December 31, 2024 |
| Unrealized losses (gains), net on unsettled contracts | $ | (9.4) |  |  | $ | 2.0 |  |
| Income tax (benefit) expense | 2.2 |  |  | (0.6) |  |
| Unrealized losses (gains), net included in AOCL, net of tax (1) | $ | (7.2) |  |  | $ | 1.4 |  |

[0001069202-25-000017:notes:86]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $6.6 million of derivative gain as of March 31, 2025 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-25-000017:notes:87]
[same as prior period, unchanged from 0001628280-24-043392:notes:78]

[0001069202-25-000017:notes:88]
[same as prior period, unchanged from 0001628280-24-043392:notes:79]

[0001069202-25-000017:notes:89]
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Stock-based compensation expense | $ | 6.3 |  |  | $ | 6.6 |  |  |  |  |  |

[0001069202-25-000017:notes:90]
Equity awards granted in February 2025 were as follows:

[0001069202-25-000017:notes:91]
|  | Shares |  | Weighed-Average Grant Date Fair Value per Share |  |  |  |  |
| Performance Share Units | 17,427 |  |  | $ | 560.53 |  |  |  |  |  |
| Restricted Stock Units | 19,338 |  |  | $ | 560.53 |  |  |  |  |  |
| Stock Appreciation Rights | 37,306 |  |  | $ | 161.50 |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-25-000017:notes:92]
[same as prior period, unchanged from 0001628280-24-043392:notes:81]

[0001069202-25-000017:notes:93]
[same as prior period, unchanged from 0001628280-24-043392:notes:82]

[0001069202-25-000017:notes:94]
|  | For the Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Service cost | $ | 0.3 |  |  | $ | 0.4 |  |  |  |  |  |
| Interest cost | 2.1 |  |  | 2.2 |  |  |  |  |  |
| Expected return on plan assets | (1.8) |  |  | (1.9) |  |  |  |  |  |
| Recognized actuarial loss | 0.4 |  |  | 0.3 |  |  |  |  |  |
| Other | — |  |  | 0.1 |  |  |  |  |  |
| Settlements and curtailments | 0.1 |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 1.1 |  |  | $ | 1.1 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-25-000017:notes:95]
[same as prior period, unchanged from 0001628280-24-043392:notes:84]

[0001069202-25-000017:notes:96]
As of March 31, 2025, we had approximately $4.7 million in total gross unrecognized tax benefits. If recognized, $4.7 million would be recorded through the Consolidated Statements of Operations.

[0001069202-25-000017:notes:97]
Our effective tax rate was 18.9% for the three months ended March 31, 2025 compared to 19.4% for the three months ended March 31, 2024. The decrease in rate is primarily due to income in low tax jurisdictions.

[0001069202-25-000017:notes:98]
We are currently under a limited scope audit by the Internal Revenue Service for our 2021 and 2022 tax years. There are also ongoing U.S. state and local audits and other foreign audits covering fiscal years 2018 through 2023. We are generally no

[0001069202-25-000017:notes:99]
longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2018.


## us-gaap:DebtDisclosureTextBlock

[0001069202-25-000017:notes:100]
10. Lines of Credit and Financing Arrangements:

[0001069202-25-000017:notes:101]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:

[0001069202-25-000017:notes:102]
|  | March 31, 2025 |  | December 31, 2024 |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 15.4 |  |  | $ | 14.9 |  |
| Senior unsecured notes | 300.0 |  |  | 300.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.4) |  |
| Total current maturities of long-term debt | $ | 315.2 |  |  | $ | 314.5 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 40.0 |  |  | $ | 39.5 |  |
| Senior unsecured notes | 800.0 |  |  | 800.0 |  |
| Debt issuance costs | (5.8) |  |  | (6.4) |  |
| Total long-term debt | $ | 834.2 |  |  | $ | 833.1 |  |
| Total debt | $ | 1,149.4 |  |  | $ | 1,147.6 |  |

[0001069202-25-000017:notes:103]
Commercial Paper Program

[0001069202-25-000017:notes:104]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There were no CP Notes currently outstanding under the Program as of March 31, 2025.

[0001069202-25-000017:notes:105]
Credit Agreement

[0001069202-25-000017:notes:106]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of March 31, 2025. Subject to covenant limitations, $1,098.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001069202-25-000017:notes:107]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers, and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001069202-25-000017:notes:108]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events, and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001069202-25-000017:notes:109]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001069202-25-000017:notes:110]
• We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001069202-25-000017:notes:111]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-25-000017:notes:112]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-25-000017:notes:113]
We are currently in compliance with all covenant requirements.

[0001069202-25-000017:notes:114]
Senior Unsecured Notes

[0001069202-25-000017:notes:115]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. We are currently in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-25-000017:notes:116]
[same as prior period, unchanged from 0001628280-24-043392:notes:110]

[0001069202-25-000017:notes:117]
[same as prior period, unchanged from 0001628280-24-043392:notes:111]

[0001069202-25-000017:notes:118]
|  |  | For the Three Months Ended March 31, |  |  |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2025 |  | 2024 |  |  |  |  |  |
| Gains (Losses) on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | 2.6 |  |  | $ | (2.0) |  |  |  |  |  |  | Cost of goods sold; Losses and other expenses, net |
| Income tax (expense) benefit |  | (0.6) |  |  | 0.5 |  |  |  |  |  |  | Provision for income taxes |
| Net of tax |  | $ | 2.0 |  |  | $ | (1.5) |  |  |  |  |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (0.4) |  |  | $ | (0.3) |  |  |  |  |  |  | Other expense, net |
| Pension settlements |  | (0.1) |  |  | — |  |  |  |  |  |  | Pension settlements |
| Income tax benefit |  | 0.1 |  |  | 0.1 |  |  |  |  |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.4) |  |  | $ | (0.2) |  |  |  |  |  |  |  |
| Total reclassifications from AOCL |  | $ | 1.6 |  |  | $ | (1.7) |  |  |  |  |  |  |  |

[0001069202-25-000017:notes:119]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2025 (in millions):

[0001069202-25-000017:notes:120]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2024 |  | $ | (1.5) |  |  | $ | 0.4 |  |  | $ | (45.7) |  |  | $ | (46.9) |  |  | $ | (93.7) |  |
| Other comprehensive income (loss) before reclassifications |  | 10.7 |  |  | — |  |  | (0.2) |  |  | 5.5 |  |  | 16.0 |  |
| Amounts reclassified from AOCL |  | (2.0) |  |  | — |  |  | 0.4 |  |  | (1.3) |  |  | (2.9) |  |
| Net other comprehensive income (loss) |  | 8.7 |  |  | — |  |  | 0.2 |  |  | 4.2 |  |  | 13.1 |  |
| Balance as of March 31, 2025 |  | $ | 7.2 |  |  | $ | 0.4 |  |  | $ | (45.5) |  |  | $ | (42.7) |  |  | $ | (80.6) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-25-000017:notes:121]
[same as prior period, unchanged from 0001628280-24-043392:notes:115]

[0001069202-25-000017:notes:122]
[same as prior period, unchanged from 0001628280-24-043392:notes:116]

[0001069202-25-000017:notes:123]
The methodologies used to determine the fair value of our financial assets and liabilities as of March 31, 2025 were the same as those used as of December 31, 2024.

[0001069202-25-000017:notes:124]
[same as prior period, unchanged from 0001628280-24-043392:notes:118]

[0001069202-25-000017:notes:125]
[same as prior period, unchanged from 0001628280-24-043392:notes:119]

[0001069202-25-000017:notes:126]
[same as prior period, unchanged from 0001628280-24-043392:notes:120]

[0001069202-25-000017:notes:127]
[same as prior period, unchanged from 0001628280-24-043392:notes:121]

[0001069202-25-000017:notes:128]
[same as prior period, unchanged from 0001628280-24-043392:notes:122]

[0001069202-25-000017:notes:129]
|  | March 31, 2025 |  | December 31, 2024 |
| Senior unsecured notes | $ | 1,093.4 |  |  | $ | 1,093.4 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001069202-25-000017:notes:130]
Sivasankaran Somasundaram, a director, adopted a non-Rule 10b5-1 trading arrangement on February 11, 2025, pursuant to which he elected to receive all of his director retainer to be paid between July 1, 2025 and June 30, 2026 in shares of the Company's common stock.  The amount of shares to be awarded will be determined based on the closing price of the Company's common stock on the second Friday of each quarter during the payment period.

[0001069202-25-000017:notes:131]
John W. Norris, III, a director, adopted a prearranged stock trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act on February 20, 2025. Mr. Norris’ plan provides for the sale of approximately 31,899 shares of the Company's common stock between May 22, 2025 and January 25, 2026.
