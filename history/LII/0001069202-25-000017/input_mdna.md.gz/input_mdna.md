# LII MD&A — 0001069202-25-000017


## mdna

[0001069202-25-000017:mdna:1]
[same as prior period, unchanged from 0001628280-24-043392:mdna:1]

[0001069202-25-000017:mdna:2]
[same as prior period, unchanged from 0001628280-24-043392:mdna:2]

[0001069202-25-000017:mdna:3]
[same as prior period, unchanged from 0001628280-24-043392:mdna:3]

[0001069202-25-000017:mdna:4]
[same as prior period, unchanged from 0001628280-24-043392:mdna:4]

[0001069202-25-000017:mdna:5]
[same as prior period, unchanged from 0001628280-24-043392:mdna:5]

[0001069202-25-000017:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, aluminum and copper.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of certain commodity price volatility and tariffs through a combination of pricing actions, vendor contracts, improved production efficiency, and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-25-000017:mdna:7]
[same as prior period, unchanged from 0001628280-24-043392:mdna:7]

[0001069202-25-000017:mdna:8]
Results for the first quarter of 2025 were driven by overall year-over-year sales increases while operating income decreased. Net sales increased 7% and segment profit increased $5 million for our Home Comfort Solutions segment. Net sales decreased 6% and segment profit decreased $25 million for our Building Climate Solutions segment. Segment loss decreased $9 million for our Corporate and Other segment.

[0001069202-25-000017:mdna:9]
[same as prior period, unchanged from 0001628280-24-043392:mdna:10]

[0001069202-25-000017:mdna:10]
•Net sales of $1,073 million in the first quarter of 2025 reflected a 2% increase as compared to the same period in 2024.

[0001069202-25-000017:mdna:11]
•Operating income in the first quarter of 2025 decreased $11 million to $156 million as higher material costs, primarily related to tariff impacts and factory inefficiencies, and lower sales volumes were partially offset by favorable price and mix.

[0001069202-25-000017:mdna:12]
•Net income for the first quarter of 2025 was $120 million.

[0001069202-25-000017:mdna:13]
•Diluted earnings per share was $3.37 per share in the first quarter of 2025 as compared to $3.47 per share in the same period in 2024.

[0001069202-25-000017:mdna:14]
•For the three months ended March 31, 2025, we returned $41 million to shareholders through dividend payments.

[0001069202-25-000017:mdna:15]
For 2025, we expect additional pricing gains to overcome tariffs while preserving profit margins and offsetting the impact of potential volume declines.

[0001069202-25-000017:mdna:16]
Three Months Ended March 31, 2025 Compared to Three Months Ended March 31, 2024 - Consolidated Results

[0001069202-25-000017:mdna:17]
[same as prior period, unchanged from 0001628280-24-043392:mdna:17]

[0001069202-25-000017:mdna:18]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 1,072.6 |  |  | $ | 1,047.1 |  |  | 2.4 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 744.1 |  |  | 707.1 |  |  | (5.2) |  |  | 69.4 |  |  | 67.5 |  |
| Gross profit | 328.5 |  |  | 340.0 |  |  | (3.4) |  |  | 30.6 |  |  | 32.5 |  |
| Selling, general and administrative expenses | 171.3 |  |  | 170.7 |  |  | (0.4) |  |  | 16.0 |  |  | 16.3 |  |
| Losses and other expenses, net | 2.8 |  |  | 3.7 |  |  | 24.3 |  |  | 0.3 |  |  | 0.4 |  |
| Income from equity method investments | (1.2) |  |  | (1.2) |  |  | — |  |  | (0.1) |  |  | (0.1) |  |
| Operating income | $ | 155.6 |  |  | $ | 166.8 |  |  | (6.7) | % |  | 14.5 | % |  | 15.9 | % |

[0001069202-25-000017:mdna:19]
[same as prior period, unchanged from 0001628280-24-043392:mdna:19]

[0001069202-25-000017:mdna:20]
Net sales for the first quarter of 2025 increased 2% as compared to the same period in 2024 primarily due to a 6% increase in price and mix, which was partially offset by a 4% decrease in sales volumes.

[0001069202-25-000017:mdna:21]
[same as prior period, unchanged from 0001628280-24-043392:mdna:21]

[0001069202-25-000017:mdna:22]
Gross profit margins in the first quarter of 2025 decreased 190 basis points ("bps") to 30.6% as compared to 32.5% in the same period in 2024. Gross margins decreased 270 bps from higher product costs primarily related to tariff impacts and factory inefficiencies and 110 bps from higher freight and distribution costs, which were partially offset by 190 bps from favorable price and mix.

[0001069202-25-000017:mdna:23]
[same as prior period, unchanged from 0001628280-24-043392:mdna:23]

[0001069202-25-000017:mdna:24]
Selling, general and administrative expenses ("SG&A") remained flat at $171 million in the first quarter of 2025 as compared to the same period in 2024.

[0001069202-25-000017:mdna:25]
[same as prior period, unchanged from 0001628280-24-043392:mdna:25]

[0001069202-25-000017:mdna:26]
Losses (gains) and other expenses, net for the first quarter of 2025 and 2024 included the following (in millions):

[0001069202-25-000017:mdna:27]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |  |  |
| Foreign currency exchange losses | 0.8 |  |  | 1.3 |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.1) |  |  | (0.4) |  |  |  |  |  |  |  |
| Other operating loss | — |  |  | 0.3 |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | — |  |  | 0.1 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 2.1 |  |  | 2.4 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 2.8 |  |  | $ | 3.7 |  |  |  |  |  |  |  |

[0001069202-25-000017:mdna:28]
[same as prior period, unchanged from 0001628280-24-043392:mdna:28]

[0001069202-25-000017:mdna:29]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments was $1 million in the first quarter of 2025 consistent with 2024.

[0001069202-25-000017:mdna:30]
[same as prior period, unchanged from 0001628280-24-043392:mdna:30]

[0001069202-25-000017:mdna:31]
Interest expense, net decreased to $6 million in the first quarter of 2025 from $12 million in the same period in 2024 primarily due to lower borrowings.

[0001069202-25-000017:mdna:32]
[same as prior period, unchanged from 0001628280-24-043392:mdna:32]

[0001069202-25-000017:mdna:33]
Our effective tax rate was 18.9% for the first quarter of 2025 as compared to 19.4% in the same period in 2024.  The decrease in rate is primarily due to income in low tax jurisdictions.

[0001069202-25-000017:mdna:34]
First Quarter of 2025 Compared to First Quarter of 2024 - Results by Segment

[0001069202-25-000017:mdna:35]
[same as prior period, unchanged from 0001628280-24-043392:mdna:35]

[0001069202-25-000017:mdna:36]
The following table presents our Home Comfort Solutions segment's net sales and profit for the first quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000017:mdna:37]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 721.4 |  |  | $ | 674.6 |  |  | $ | 46.8 |  |  | 7 | % |
| Profit | $ | 116.8 |  |  | $ | 112.1 |  |  | $ | 4.7 |  |  | 4 | % |
| % of net sales | 16.2 | % |  | 16.6 | % |  |  |  |  |

[0001069202-25-000017:mdna:38]
Net sales increased 7% in the first quarter of 2025 as compared to the same period in 2024 due to favorable price and mix.

[0001069202-25-000017:mdna:39]
Segment profit in the first quarter of 2025 increased $5 million as compared to the same period in 2024 primarily due to  $31 million from favorable price and mix, which was partially offset by $15 million from higher product and other material costs, including tariffs, and $11 million from higher freight and distribution costs and other miscellaneous items.

[0001069202-25-000017:mdna:40]
[same as prior period, unchanged from 0001628280-24-043392:mdna:40]

[0001069202-25-000017:mdna:41]
The following table presents our Building Climate Solutions segment's net sales and profit for the first quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000017:mdna:42]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | 351.2 |  |  | $ | 372.5 |  |  | $ | (21.3) |  |  | (6) | % |
| Profit | $ | 53.5 |  |  | $ | 78.2 |  |  | $ | (24.7) |  |  | (32) | % |
| % of net sales | 15.2 | % |  | 21.0 | % |  |  |  |  |

[0001069202-25-000017:mdna:43]
Net sales decreased 6% in the first quarter of 2025 as compared to the same period in 2024 primarily due to lower sales volumes of 9% which was partially offset by favorable price and mix of 3%.

[0001069202-25-000017:mdna:44]
Segment profit in the first quarter of 2025 decreased $25 million as compared to the same period in 2024 primarily due to $12 million from lower sales volumes, $14 million from higher costs related to the new factory ramp up, manufacturing inefficiencies at existing facilities, and the impact of tariffs, and $8 million in investments in emergency replacement sales force and other miscellaneous items, which were partially offset by $9 million from favorable price and mix.

[0001069202-25-000017:mdna:45]
[same as prior period, unchanged from 0001628280-24-043392:mdna:45]

[0001069202-25-000017:mdna:46]
The following table presents our Corporate and Other segment's net sales and loss for the first quarter of 2025 and 2024 (dollars in millions):

[0001069202-25-000017:mdna:47]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | — | % |
| Loss | $ | (14.7) |  |  | $ | (23.5) |  |  | $ | 8.8 |  |  | 37 | % |

[0001069202-25-000017:mdna:48]
Segment loss decreased $9 million in the first quarter of 2025 as compared to the same period in 2024 due to a $7 million reduction in SG&A costs and $2 million from miscellaneous and other items.

[0001069202-25-000017:mdna:49]
[same as prior period, unchanged from 0001628280-24-043392:mdna:82]

[0001069202-25-000017:mdna:50]
[same as prior period, unchanged from 0001628280-24-043392:mdna:83]

[0001069202-25-000017:mdna:51]
[same as prior period, unchanged from 0001628280-24-043392:mdna:84]

[0001069202-25-000017:mdna:52]
The following table summarizes our cash flow activity for the three months ended March 31, 2025 and 2024 (in millions):

[0001069202-25-000017:mdna:53]
|  | For the Three Months Ended March 31, |
|  | 2025 |  | 2024 |
| Net cash used in operating activities | $ | (35.8) |  |  | $ | (22.8) |  |
| Net cash used in investing activities | (23.5) |  |  | (30.7) |  |
| Net cash (used in) provided by financing activities | (141.2) |  |  | 42.4 |  |

[0001069202-25-000017:mdna:54]
Net Cash Used In Operating Activities - The change in net cash used in operating activities for the three months ended March 31, 2025 compared to the net cash used in operating activities for the same period in 2024 primarily reflects less favorable changes in working capital.

[0001069202-25-000017:mdna:55]
Net Cash Used In Investing Activities - Capital expenditures were $26 million for the three months ended March 31, 2025 compared to $30 million in the same period of 2024.  Reduction in capital expenditures was primarily driven by the general expansion of manufacturing capacity and equipment of the Commercial factory in Mexico in 2024.

[0001069202-25-000017:mdna:56]
Net Cash (Used In) Provided By Financing Activities - Net cash used in financing activities for the three months ended March 31, 2025 increased to $141 million as compared to $42 million provided by in the same period of 2024.  The change was primarily due to changes in net borrowings and repayments of long-term debt and repurchase of common stock through our share repurchase program.  We returned $41 million to shareholders through dividend payments for the three months ended March 31, 2025 and $39 million in the same period of 2024.

[0001069202-25-000017:mdna:57]
[same as prior period, unchanged from 0001628280-24-043392:mdna:91]

[0001069202-25-000017:mdna:58]
The following table details our lines of credit and financing arrangements as of March 31, 2025 (in millions):

[0001069202-25-000017:mdna:59]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 15.4 |  |
| Senior unsecured notes | 300.0 |  |
| Debt issuance costs | (0.2) |  |
| Total current maturities of long-term debt | $ | 315.2 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 40.0 |  |
| Senior unsecured notes | 800.0 |  |
| Debt issuance costs | (5.8) |  |
| Total long-term debt | $ | 834.2 |  |
| Total debt | $ | 1,149.4 |  |

[0001069202-25-000017:mdna:60]
[same as prior period, unchanged from 0001628280-24-043392:mdna:94]

[0001069202-25-000017:mdna:61]
On October 25, 2023, we established a commercial paper program, as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. There are no CP Notes currently outstanding under the Program as of March 31, 2025.

[0001069202-25-000017:mdna:62]
[same as prior period, unchanged from 0001628280-24-043392:mdna:96]

[0001069202-25-000017:mdna:63]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had no outstanding borrowings and $1.7 million committed to standby letters of credit as of March 31, 2025. Subject to covenant limitations, $1,098.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001069202-25-000017:mdna:64]
[same as prior period, unchanged from 0001628280-24-043392:mdna:99]

[0001069202-25-000017:mdna:65]
[same as prior period, unchanged from 0001628280-24-043392:mdna:100]

[0001069202-25-000017:mdna:66]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2025, we believe we were in compliance with all covenant requirements.

[0001069202-25-000017:mdna:67]
[same as prior period, unchanged from 0001628280-24-043392:mdna:102]

[0001069202-25-000017:mdna:68]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio remains unchanged at 57% as of March 31, 2025, as compared to December 31, 2024.

[0001069202-25-000017:mdna:69]
As of March 31, 2025, our senior credit ratings were Baa2 with a POS outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-25-000017:mdna:70]
[same as prior period, unchanged from 0001628280-24-043392:mdna:105]

[0001069202-25-000017:mdna:71]
We believe our cash and cash equivalents of $217.2 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends, and other needs in the foreseeable future, including the maturity of $300.0 million senior unsecured notes on August 1, 2025.  Included in our cash and cash equivalents of $217.2 million as of March 31, 2025 was $20 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-25-000017:mdna:72]
[same as prior period, unchanged from 0001628280-24-043392:mdna:111]

[0001069202-25-000017:mdna:73]
[same as prior period, unchanged from 0001628280-24-043392:mdna:112]

[0001069202-25-000017:mdna:74]
Commitments, Contingencies, and Guarantees

[0001069202-25-000017:mdna:75]
For information regarding our commitments, contingencies, and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-25-000017:mdna:76]
[same as prior period, unchanged from 0001628280-24-043392:mdna:115]

[0001069202-25-000017:mdna:77]
[same as prior period, unchanged from 0001628280-24-043392:mdna:116]
