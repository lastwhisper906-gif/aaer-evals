# LII MD&A — 0001069202-20-000048


## mdna

[0001069202-20-000048:mdna:1]
[same as prior period, unchanged from 0001069202-20-000039:mdna:1]

[0001069202-20-000048:mdna:2]
[same as prior period, unchanged from 0001069202-20-000039:mdna:2]

[0001069202-20-000048:mdna:3]
[same as prior period, unchanged from 0001069202-20-000039:mdna:3]

[0001069202-20-000048:mdna:4]
[same as prior period, unchanged from 0001069202-20-000039:mdna:4]

[0001069202-20-000048:mdna:5]
[same as prior period, unchanged from 0001069202-20-000039:mdna:5]

[0001069202-20-000048:mdna:6]
[same as prior period, unchanged from 0001069202-20-000039:mdna:6]

[0001069202-20-000048:mdna:7]
Impact of COVID-19 Pandemic and the Resulting Changes to our 2020 Financial Performance

[0001069202-20-000048:mdna:8]
[same as prior period, unchanged from 0001069202-20-000039:mdna:8]

[0001069202-20-000048:mdna:9]
[same as prior period, unchanged from 0001069202-20-000039:mdna:9]

[0001069202-20-000048:mdna:10]
Additionally, certain of our manufacturing facilities experienced short-term suspensions of operations for COVID-19 employee health concerns during the second and third quarters of 2020.

[0001069202-20-000048:mdna:11]
Due to the adverse impact of the COVID-19 pandemic on our European manufacturing facilities and the resulting downturn in the related business, we recorded an $8 million valuation allowance in the first quarter of 2020 on certain foreign deferred tax assets as we concluded that it was no longer more likely than not that these foreign tax loss carryforwards would be realized.

[0001069202-20-000048:mdna:12]
In April 2020, we implemented cost reduction actions to realize $115 million of SG&A savings relative to our initial 2020 financial plans based on expectations that the North American unitary HVAC and refrigeration market would be negatively impacted by approximately 20% due to the pandemic.  During the third quarter, we revised our outlook for the remainder of 2020 due to the improved performance of our end markets and our strong operational performance. We are now planning for $65 million of SG&A savings this year, with the decrease in savings due primarily to reinstituting the temporary salary reductions, increasing sales commissions and paying performance-based incentive compensation.

[0001069202-20-000048:mdna:13]
In connection with these cost saving actions, we incurred pre-tax charges of $10 million in the second and third quarters of 2020 related primarily to personnel severance and benefits and facility exit costs. Also, we incurred $6 million of expenses for the nine months ended September 30, 2020 for facility cleaning and sanitization supplies to ensure the health and safety of our employees.

[0001069202-20-000048:mdna:14]
The magnitude of the impact of COVID-19 remains unpredictable and we, therefore, continue to anticipate potential supply chain disruptions, employee absenteeism and short-term suspensions of manufacturing facilities, and additional health and safety costs related to the COVID-19 pandemic that could unfavorably impact our business.  Since the first quarter of 2020, we have reset our financial expectations and, based on our latest guidance, now expect 2020 revenue to be down 5% to 9% from last year versus our initial 2020 guidance for growth of 4% to 8%.  Additionally, we now expect Diluted EPS from continuing operations in the range of $8.35 to $8.95 for the year as compared to our initial expected range of $11.30 to $11.90 for 2020.

[0001069202-20-000048:mdna:15]
We expect our cash generation to remain strong for 2020 as our working capital requirements decline, and currently project approximately $525 million in cash flows from operations for the year. We reduced our capital expenditure plans for 2020 from $153 million initially to $100 million. We are rated investment grade by both S&P and Moody’s, and we expect to remain well within our debt covenants. We do not anticipate any liquidity concerns as we issued $600 million in senior unsecured notes in the third quarter of 2020 and extended the term of bank revolver by one year until the latter half of 2022.  Our quarterly dividend plans are unchanged, most recently $0.77 per share, or more than $115 million in total payments for the year. We repurchased $100 million of stock in the first quarter of the $400 million we had planned to repurchase for the year. However, we placed the remaining repurchase plans for 2020 on hold.

[0001069202-20-000048:mdna:16]
[same as prior period, unchanged from 0001069202-20-000039:mdna:15]

[0001069202-20-000048:mdna:17]
Results for the third quarter of 2020 were mixed and adversely impacted by the business downturn caused by the COVID-19 pandemic. Year over year sales and profit were up in our Residential Heating & Cooling segment primarily due to higher volumes, while they were down in our Commercial Heating & Cooling and Refrigeration segments primarily due to lower sales volumes. The Residential Heating & Cooling segment saw a 13% increase in net sales and a $27 million increase in segment profit. The Commercial Heating & Cooling segment had a 18% decrease in net sales and a $8 million decrease in segment profit. The Refrigeration segment had a 12% decline in net sales and a $7 million decline in segment profit.

[0001069202-20-000048:mdna:18]
[same as prior period, unchanged from 0001069202-20-000039:mdna:17]

[0001069202-20-000048:mdna:19]
•Net sales increased $22 million to $1,055 million in the third quarter of 2020 driven by favorable price and mix combined and net volume increases.

[0001069202-20-000048:mdna:20]
•Operating income in the third quarter of 2020 increased $10 million to $167 million primarily driven by factory productivity, lower commodity costs, and sourcing and engineering-led cost reductions, partially offset by non-recurring insurance recoveries in 2019 for lost profits related to the Marshalltown tornado.

[0001069202-20-000048:mdna:21]
•Net income for the third quarter of 2020 increased $17 million to $132 million.

[0001069202-20-000048:mdna:22]
•Diluted earnings per share from continuing operations were $3.42 per share in the third quarter of 2020 compared to $2.94 per share in the third quarter of 2019.

[0001069202-20-000048:mdna:23]
•For the nine months ended September 30, 2020, we returned $89 million to shareholders through dividend payments and repurchased $100 million of common stock through our share repurchase program.

[0001069202-20-000048:mdna:24]
Third Quarter of 2020 Compared to Third Quarter of 2019 - Consolidated Results

[0001069202-20-000048:mdna:25]
[same as prior period, unchanged from 0001069202-20-000039:mdna:24]

[0001069202-20-000048:mdna:26]
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |  |  |
|  | Dollars (in millions) |  |  |  | PercentChangeFav/(Unfav) |  | Percent of Sales |  |  |
|  | 2020 |  | 2019 |  |  |  | 2020 |  | 2019 |
| Net sales | $ | 1,055.0 |  |  | $ | 1,032.9 |  |  | 2.1 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 731.7 |  |  | 734.6 |  |  | 0.4 |  |  | 69.4 |  |  | 71.1 |  |
| Gross profit | 323.3 |  |  | 298.3 |  |  | 8.4 |  |  | 30.6 |  |  | 28.9 |  |
| Selling, general and administrative expenses | 151.8 |  |  | 143.4 |  |  | (5.9) |  |  | 14.4 |  |  | 13.9 |  |
| Losses (gains) and other expenses, net | 3.4 |  |  | 2.2 |  |  | (54.5) |  |  | 0.3 |  |  | 0.2 |  |
| Restructuring charges | 0.1 |  |  | 6.1 |  |  | 98.4 |  |  | — |  |  | 0.6 |  |
| Loss on sale of business | — |  |  | 0.2 |  |  | 100.0 |  |  | — |  |  | — |  |
| Loss (gain) from natural disasters, net of insurance recoveries | 4.9 |  |  | (7.1) |  |  | (169.0) |  |  | 0.5 |  |  | (0.7) |  |
| Income from equity method investments | (4.0) |  |  | (3.3) |  |  | 21.2 |  |  | (0.4) |  |  | (0.3) |  |
| Operating income | $ | 167.1 |  |  | $ | 156.8 |  |  | 6.6 | % |  | 15.8 | % |  | 15.2 | % |

[0001069202-20-000048:mdna:27]
[same as prior period, unchanged from 0001069202-20-000039:mdna:26]

[0001069202-20-000048:mdna:28]
Net sales increased 2% in the third quarter of 2020 compared to the third quarter of 2019 driven by higher sales volumes of 1% and favorable combined price and mix of 1%.

[0001069202-20-000048:mdna:29]
[same as prior period, unchanged from 0001069202-20-000039:mdna:28]

[0001069202-20-000048:mdna:30]
Gross profit margin in the third quarter of 2020 increased 170 basis points ("bps") to 30.6% compared to 28.9% in the third quarter of 2019. We saw margin increases of 80 bps from lower commodity costs, 80 bps from sourcing and engineering-led cost reductions, 60 bps from lower freight and distribution costs, and 50 bps from factory productivity. Partially offsetting these were margin decreases of 70 bps from unfavorable combined price and mix and 30 bps from higher tariffs.

[0001069202-20-000048:mdna:31]
[same as prior period, unchanged from 0001069202-20-000039:mdna:30]

[0001069202-20-000048:mdna:32]
Selling, general and administrative expenses ("SG&A") increased $8 million to $152 million in the third quarter of 2020 compared to $143 million in the third quarter of 2019 primarily due to higher incentive compensation costs. As a percentage of net sales, SG&A increased 50 bps to 14.4% .

[0001069202-20-000048:mdna:33]
[same as prior period, unchanged from 0001069202-20-000039:mdna:32]

[0001069202-20-000048:mdna:34]
Losses (gains) losses and other expenses, net for the third quarter of 2020 and 2019 included the following (in millions):

[0001069202-20-000048:mdna:35]
|  | For the Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |
| Realized losses on settled futures contracts | $ | — |  |  | $ | 0.1 |  |
| Foreign currency exchange gains | (0.4) |  |  | (0.3) |  |
| Gain on disposal of fixed assets | (0.2) |  |  | — |  |
| Other operating income | (0.4) |  |  | (1.2) |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (1.4) |  |  | 0.1 |  |
| Special legal contingency charges | 0.2 |  |  | 0.3 |  |
| Asbestos-related litigation | 2.4 |  |  | 1.5 |  |
| Environmental liabilities | 0.3 |  |  | 1.1 |  |
| Charges incurred related to COVID-19 pandemic | 3.0 |  |  | — |  |
| Other items, net | (0.1) |  |  | 0.6 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.4 |  |  | $ | 2.2 |  |

[0001069202-20-000048:mdna:36]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 9 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities related to estimated remediation costs for contamination at some of our facilities. The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and sanitization supplies to ensure the health and safety of our employees.

[0001069202-20-000048:mdna:37]
[same as prior period, unchanged from 0001069202-20-000039:mdna:36]

[0001069202-20-000048:mdna:38]
Restructuring charges were insignificant in the third quarter of 2020 and related to ongoing cost reduction actions taken in prior periods. For additional information on our restructuring activities, refer to Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000048:mdna:39]
Gains and Losses related to Natural Disasters

[0001069202-20-000048:mdna:40]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  On August 10, 2020, the Marshalltown facility was partially damaged by a derecho wind storm. The costs and losses incurred as well as any insurance recoveries for both of these natural disasters are shown in Loss (gain) from natural disasters, net of insurance recoveries in the Consolidated Statements of Operations.

[0001069202-20-000048:mdna:41]
In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019.  During the third quarter of 2020, we incurred expenses of less than $1 million related to damages caused by the tornado, which primarily related to other restoration costs.

[0001069202-20-000048:mdna:42]
We have insurance for the repair and replacement of our assets that suffered damage or loss related to the wind storm.  We are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and losses we suffered.  Our insurance policies also provide business interruption coverage, including lost profits and reimbursement for other expenses and costs that have been incurred related to the damages and losses suffered.  During the third quarter of 2020, we incurred expenses of approximately $5 million related to damages caused by the wind storm, which included site clean up, building repairs and other restoration costs.

[0001069202-20-000048:mdna:43]
See Note 4 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-20-000048:mdna:44]
[same as prior period, unchanged from 0001069202-20-000039:mdna:42]

[0001069202-20-000048:mdna:45]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to

[0001069202-20-000048:mdna:46]
venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $4 million in the third quarter of 2020 was up slightly compared to the third quarter of 2019.

[0001069202-20-000048:mdna:47]
[same as prior period, unchanged from 0001069202-20-000039:mdna:46]

[0001069202-20-000048:mdna:48]
Interest expense, net of $7 million in the third quarter of 2020 was down $6 million from $13 million in the third quarter of 2019 due to lower borrowing costs and fewer borrowings.

[0001069202-20-000048:mdna:49]
[same as prior period, unchanged from 0001069202-20-000039:mdna:48]

[0001069202-20-000048:mdna:50]
Our effective tax rate was 17.3% for the third quarter of 2020 compared to 20.2% for the third quarter of 2019.  The rate decreased primarily due to higher excess tax benefits from stock-based compensation and a favorable mix of income from jurisdictions with lower tax rates.  We expect our annual effective tax rate in 2020 to be between 19% and 20%, after excluding the impacts of excess tax benefits recorded under ASU No. 2016-09, after the $8 million valuation allowance recorded in the first quarter of 2020 and after the tax impacts of restructuring and pandemic-related charges.

[0001069202-20-000048:mdna:51]
Third Quarter of 2020 Compared to Third Quarter of 2019 - Results by Segment

[0001069202-20-000048:mdna:52]
[same as prior period, unchanged from 0001069202-20-000039:mdna:51]

[0001069202-20-000048:mdna:53]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the third quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000048:mdna:54]
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 722.0 |  |  | $ | 637.6 |  |  | $ | 84.4 |  |  | 13.2 | % |
| Profit | $ | 153.0 |  |  | $ | 126.5 |  |  | $ | 26.5 |  |  | 20.9 | % |
| % of net sales | 21.2 | % |  | 19.8 | % |  |  |  |  |

[0001069202-20-000048:mdna:55]
Net sales increased 13% in the third quarter of 2020 compared to the third quarter of 2019.  Sales volumes increased 11% and combined price and mix increased 2%.

[0001069202-20-000048:mdna:56]
Segment profit in the third quarter of 2020 increased $27 million compared to the third quarter of 2019 due to $19 million from higher sales volumes, $7 million of factory productivity, $6 million from engineering and sourcing-led cost reductions, $6 million from lower freight and distribution costs, $5 million from lower commodity costs, $4 million of favorable price, $2 million from lower warranty and other product costs, and $1 million of income from equity method investments.  Partially offsetting these increases was $16 million of non-recurring insurance proceeds for lost profits related to the Marshalltown tornado, $4 million from timing of tariffs for certain Chinese imports, $1 million from unfavorable mix, $1 million from higher SG&A expenses, and $1 million from unfavorable foreign currency exchange rates.

[0001069202-20-000048:mdna:57]
[same as prior period, unchanged from 0001069202-20-000039:mdna:56]

[0001069202-20-000048:mdna:58]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the third quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000048:mdna:59]
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 207.9 |  |  | $ | 253.3 |  |  | $ | (45.4) |  |  | (17.9) | % |
| Profit | $ | 38.8 |  |  | $ | 47.1 |  |  | $ | (8.3) |  |  | (17.6) | % |
| % of net sales | 18.7 | % |  | 18.6 | % |  |  |  |  |

[0001069202-20-000048:mdna:60]
Net sales decreased 18% in the third quarter of 2020 compared to the third quarter of 2019.  Sales volumes declined 15% and mix was unfavorable 3%.

[0001069202-20-000048:mdna:61]
Segment profit decreased $8 million in the third quarter of 2020 compared to the third quarter of 2019 due to $14 million from lower sales volumes, $2 million from unfavorable mix, and $1 million from other product costs.  Partially offsetting these declines was $3 million from lower SG&A expenses, $2 million from lower commodity costs, $2 million from engineering and sourcing-led cost reductions, $1 million of factory productivity, and $1 million from lower freight and distribution expense.

[0001069202-20-000048:mdna:62]
[same as prior period, unchanged from 0001069202-20-000039:mdna:61]

[0001069202-20-000048:mdna:63]
The following table presents our Refrigeration segment's net sales and profit for the third quarter of 2020 and 2019 (dollars in millions):

[0001069202-20-000048:mdna:64]
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 125.1 |  |  | $ | 142.0 |  |  | $ | (16.9) |  |  | (11.9) | % |
| Profit | $ | 13.0 |  |  | $ | 19.8 |  |  | $ | (6.8) |  |  | (34.3) | % |
| % of net sales | 10.4 | % |  | 13.9 | % |  |  |  |  |

[0001069202-20-000048:mdna:65]
Net sales decreased 12% in the third quarter of 2020 compared to the third quarter of 2019. Sales volumes decreased 16%, partially offset by favorable combined price and mix of 2% and favorable foreign currency exchange rates of 2%.

[0001069202-20-000048:mdna:66]
Segment profit decreased $7 million in the third quarter of 2020 compared to the third quarter of 2019 due to $9 million from lower sales volumes, $2 million of factory inefficiencies, and $1 million of lower income from equity method investments.  Partially offsetting these declines was $3 million from lower SG&A expenses, $1 million from lower commodity costs, and $1 million from favorable foreign currency exchange rates.

[0001069202-20-000048:mdna:67]
[same as prior period, unchanged from 0001069202-20-000039:mdna:66]

[0001069202-20-000048:mdna:68]
Corporate and other expenses increased $10 million in the third quarter of 2020 compared to the third quarter of 2019 primarily due to higher incentive compensation costs.  Due to the timing of our earnings, certain annual incentive compensation costs were not earned and recorded until the third quarter of 2020, while the same incentive compensation costs were earned and recorded in earlier quarters of 2019.

[0001069202-20-000048:mdna:69]
Year-to-Date through September 30, 2020 Compared to Year-to-Date through September 30, 2019 - Consolidated Results

[0001069202-20-000048:mdna:70]
[same as prior period, unchanged from 0001069202-20-000039:mdna:69]

[0001069202-20-000048:mdna:71]
|  | For the Nine Months Ended September 30, |  |  |  |  |  |  |  |  |
|  | Dollars (in millions) |  |  |  | PercentChangeFav/(Unfav) |  | Percent of Sales |  |  |
|  | 2020 |  | 2019 |  |  |  | 2020 |  | 2019 |
| Net sales | $ | 2,720.1 |  |  | $ | 2,922.2 |  |  | (6.9) |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,955.3 |  |  | 2,090.3 |  |  | 6.5 |  |  | 71.9 |  |  | 71.5 |  |
| Gross profit | 764.8 |  |  | 831.9 |  |  | (8.1) |  |  | 28.1 |  |  | 28.5 |  |
| Selling, general and administrative expenses | 412.7 |  |  | 441.6 |  |  | 6.5 |  |  | 15.2 |  |  | 15.1 |  |
| Losses (gains) and other expenses, net | 5.6 |  |  | 5.3 |  |  | (5.7) |  |  | 0.2 |  |  | 0.2 |  |
| Restructuring charges | 10.6 |  |  | 6.5 |  |  | (63.1) |  |  | 0.4 |  |  | 0.2 |  |
| Loss on sale of business | — |  |  | 9.1 |  |  | 100.0 |  |  | — |  |  | 0.3 |  |
| Loss (gain) from natural disasters, net of insurance recoveries | 7.6 |  |  | (85.4) |  |  | (108.9) |  |  | 0.3 |  |  | (2.9) |  |
| Income from equity method investments | (11.2) |  |  | (10.5) |  |  | 6.7 |  |  | (0.4) |  |  | (0.4) |  |
| Operating income | $ | 339.5 |  |  | $ | 465.3 |  |  | (27.0) |  |  | 12.5 | % |  | 15.9 | % |

[0001069202-20-000048:mdna:72]
[same as prior period, unchanged from 0001069202-20-000039:mdna:71]

[0001069202-20-000048:mdna:73]
Net sales decreased 7% in the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019 due to lower sales volumes of 7% and a 1% decline related to the sale of our Kysor Warren business in the first quarter of 2019, partially offset by 1% from favorable combined price and mix.

[0001069202-20-000048:mdna:74]
[same as prior period, unchanged from 0001069202-20-000039:mdna:73]

[0001069202-20-000048:mdna:75]
Gross profit margins for the nine months ended September 30, 2020 decreased 40 bps to 28.1% compared to the nine months ended September 30, 2019. Our profit margin decreased 150 bps from unfavorable combined price and mix, 60 bps from factory inefficiencies, 40 bps from higher product warranties and other product costs, and 10 bps from higher tariffs for certain Chinese imports.  These were partially offset by 80 bps from lower commodities costs, 70 bps from sourcing and engineering-led cost reductions, 50 bps from lower freight and distribution costs, and 20 bps from the divested Kysor Warren business which had lower margins.

[0001069202-20-000048:mdna:76]
[same as prior period, unchanged from 0001069202-20-000039:mdna:75]

[0001069202-20-000048:mdna:77]
SG&A declined $29 million to $413 million for the nine months ended September 30, 2020 compared to $442 million for the nine months ended September 30, 2019 primarily due to lower salaries and discretionary expenditures, and the sale of our Kysor Warren business in the first quarter of 2019. As a percentage of net sales, SG&A increased 10 bps to 15.2% from 15.1%.

[0001069202-20-000048:mdna:78]
[same as prior period, unchanged from 0001069202-20-000039:mdna:77]

[0001069202-20-000048:mdna:79]
Losses (gains) and other expenses, net for the nine months ended September 30, 2020 and 2019 included the following (in millions):

[0001069202-20-000048:mdna:80]
|  | Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |
| Realized losses on settled futures contracts | $ | 0.2 |  |  | $ | 0.4 |  |
| Foreign currency exchange gains | (3.0) |  |  | (1.0) |  |
| Gain on disposal of fixed assets | (0.4) |  |  | (0.2) |  |
| Other operating income | (1.7) |  |  | (1.2) |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | — |  |  | (0.2) |  |
| Special legal contingency charges | 0.9 |  |  | 0.5 |  |
| Asbestos-related litigation | 1.9 |  |  | 3.3 |  |
| Environmental liabilities | 1.5 |  |  | 2.4 |  |
| Charges incurred related to COVID-19 pandemic | 6.4 |  |  | — |  |
| Other items, net | (0.2) |  |  | 1.3 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 5.6 |  |  | $ | 5.3 |  |

[0001069202-20-000048:mdna:81]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 9 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities related to estimated remediation costs for contamination at some of our facilities.  The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and sanitization supplies to ensure the health and safety of our employees.

[0001069202-20-000048:mdna:82]
[same as prior period, unchanged from 0001069202-20-000039:mdna:81]

[0001069202-20-000048:mdna:83]
Restructuring charges were $11 million for the nine months ended September 30, 2020 and related to several cost reduction actions taken in response to the economic impact of the COVID-19 pandemic on our business. These actions consisted of employee terminations for positions that were no longer needed to support the business, selective facility closures, and cancellations of certain sales and marketing activities. For additional information on our restructuring activities, refer to Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000048:mdna:84]
[same as prior period, unchanged from 0001069202-20-000039:mdna:83]

[0001069202-20-000048:mdna:85]
We recognized a loss of $9 million for the nine months ended September 30, 2019 related to the sale of our Kysor Warren business in the first quarter of 2019.  There were no losses related to this sale for the nine months ended September 30, 2020.  Refer to Note 6 in the Notes to the Consolidated Financial Statements for additional information on this divestiture.

[0001069202-20-000048:mdna:86]
Gains and Losses related to Natural Disasters

[0001069202-20-000048:mdna:87]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  On August 10, 2020, the Marshalltown facility was partially damaged by a derecho wind storm. The costs and losses incurred as well as any insurance recoveries for both of these natural disasters are shown in Loss (gain) from natural disasters, net of insurance recoveries in the Consolidated Statements of Operations.

[0001069202-20-000048:mdna:88]
In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019.  For the nine months ended September 30, 2020, we incurred expenses of $3 million related to damages caused by the tornado, which primarily related to other restoration costs.

[0001069202-20-000048:mdna:89]
We have insurance for the repair and replacement of our assets that suffered damage or loss related to the wind storm.  We are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and losses we suffered.  Our insurance policies also provide business interruption coverage, including lost profits and reimbursement for other expenses and costs that have been incurred related to the damages and losses suffered.  During the third quarter of 2020, we incurred expenses of approximately $5 million related to damages caused by the wind storm, which included site clean up, building repairs and other restoration costs.

[0001069202-20-000048:mdna:90]
[same as prior period, unchanged from 0001069202-20-000039:mdna:89]

[0001069202-20-000048:mdna:91]
Income from equity method investments of $11 million for the nine months ended September 30, 2020 was up approximately $1 million compared to the nine months ended September 30, 2019.

[0001069202-20-000048:mdna:92]
Pension Settlements

[0001069202-20-000048:mdna:93]
In the second quarter of 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and $105.6 million of related pension benefit obligations. We recognized a $60.6 million pension settlement charge in the Statement of Operations as a result of this transaction. There were less than $1 million of pension settlements for the nine months ended September 30, 2020. For additional information, refer to Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000048:mdna:94]
[same as prior period, unchanged from 0001069202-20-000039:mdna:93]

[0001069202-20-000048:mdna:95]
Interest expense, net of $22 million for the nine months ended September 30, 2020 decreased $15 million from $37 million for the nine months ended September 30, 2019 due to lower borrowing costs and lower borrowings.

[0001069202-20-000048:mdna:96]
[same as prior period, unchanged from 0001069202-20-000039:mdna:95]

[0001069202-20-000048:mdna:97]
Our effective tax rate increased to 21.9% for the nine months ended September 30, 2020 compared to 19.5% for the nine months ended September 30, 2019 primarily due to lower excess tax benefits from stock-based compensation and the recording of a $8 million valuation allowance on certain foreign deferred tax assets recorded in the first quarter of 2020.

[0001069202-20-000048:mdna:98]
Year-to-Date through September 30, 2020 Compared to Year-to-Date through September 30, 2019 - Results by Segment

[0001069202-20-000048:mdna:99]
[same as prior period, unchanged from 0001069202-20-000039:mdna:98]

[0001069202-20-000048:mdna:100]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the nine months ended September 30, 2020 and 2019 (dollars in millions):

[0001069202-20-000048:mdna:101]
|  | Nine Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 1,808.8 |  |  | $ | 1,792.2 |  |  | $ | 16.6 |  |  | 0.9 | % |
| Profit | $ | 312.8 |  |  | $ | 366.6 |  |  | $ | (53.8) |  |  | (14.7) | % |
| % of net sales | 17.3 | % |  | 20.5 | % |  |  |  |  |

[0001069202-20-000048:mdna:102]
Net sales increased 1% in the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019. Price increased 1% and mix was favorable by 1%, partially offset by lower sales volumes of 1%.

[0001069202-20-000048:mdna:103]
Segment profit for the nine months ended September 30, 2020 decreased $54 million compared to the same period in 2019 due to $74 million of non-recurring insurance proceeds in 2019 for lost profits related to the Marshalltown tornado, $10 million of factory inefficiencies, $14 million of higher warranty and other product costs, $6 million from lower sales volume, $19 million from unfavorable mix, and $2 million from higher tariffs on certain Chinese imports.  Partially offsetting these declines was $17 million from lower SG&A expenses, $14 million from engineering and sourcing-led cost reductions, $13 million from lower commodity costs, $13 million of higher price, $13 million from lower freight and distribution expense, and $1 million from favorable foreign currency exchange rates.

[0001069202-20-000048:mdna:104]
[same as prior period, unchanged from 0001069202-20-000039:mdna:103]

[0001069202-20-000048:mdna:105]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the nine months ended September 30, 2020 and 2019 (dollars in millions):

[0001069202-20-000048:mdna:106]
|  | Nine Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 574.6 |  |  | $ | 687.9 |  |  | $ | (113.3) |  |  | (16.5) | % |
| Profit | $ | 93.1 |  |  | $ | 116.0 |  |  | $ | (22.9) |  |  | (19.7) | % |
| % of net sales | 16.2 | % |  | 16.9 | % |  |  |  |  |

[0001069202-20-000048:mdna:107]
Net sales decreased 16% in the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019 due to lower sales volumes.

[0001069202-20-000048:mdna:108]
Segment profit for the nine months ended September 30, 2020 decreased $23 million compared to the same period of 2019 due to $40 million from lower sales volumes, $5 million from unfavorable mix, and $2 million from higher warranty and other product costs.  Partially offsetting these declines was $9 million from lower SG&A expenses, $6 million from engineering and sourcing-led cost reductions, $5 million from lower commodity costs, $1 million of factory productivity, $2 million from lower freight and distribution expenses, and $1 million from favorable foreign currency exchange rates.

[0001069202-20-000048:mdna:109]
[same as prior period, unchanged from 0001069202-20-000039:mdna:108]

[0001069202-20-000048:mdna:110]
The following table presents our Refrigeration segment's net sales and profit for the nine months ended September 30, 2020 and 2019 (dollars in millions):

[0001069202-20-000048:mdna:111]
|  | Nine Months Ended September 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | Difference |  | % Change |
| Net sales | $ | 336.7 |  |  | $ | 442.1 |  |  | $ | (105.4) |  |  | (23.8) | % |
| Profit | $ | 22.6 |  |  | $ | 47.3 |  |  | $ | (24.7) |  |  | (52.2) | % |
| % of net sales | 6.7 | % |  | 10.7 | % |  |  |  |  |

[0001069202-20-000048:mdna:112]
Net sales decreased 24% for the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019. Sales volumes were lower by 17% and the loss of sales from our divested Kysor Warren business contributed 8%, which was partially offset by favorable combined price and mix of 1%.

[0001069202-20-000048:mdna:113]
Segment profit for the nine months ended September 30, 2020 decreased $25 million compared to the same period of 2019 due to $26 million from lower sales volumes, $9 million of factory inefficiencies, $4 million from warranty and other product costs, $2 million from non-recurring European refrigerant quota sales in 2019, and $1 million from lower income from equity method investments.  Partially offsetting these declines was $7 million from lower SG&A expenses, $4 million from lower commodity costs, $2 million from engineering and souring-led cost reductions, $1 million from favorable combined price and mix, $1 million from lower freight and distribution expenses, $1 million of higher profit due to the divestiture of the Kysor Warren business, and $1 million from favorable foreign currency exchange rates.

[0001069202-20-000048:mdna:114]
[same as prior period, unchanged from 0001069202-20-000039:mdna:113]

[0001069202-20-000048:mdna:115]
Corporate and other expenses increased $7 million in the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019 due to higher incentive compensation costs.

[0001069202-20-000048:mdna:116]
[same as prior period, unchanged from 0001069202-20-000039:mdna:115]

[0001069202-20-000048:mdna:117]
[same as prior period, unchanged from 0001069202-20-000039:mdna:116]

[0001069202-20-000048:mdna:118]
[same as prior period, unchanged from 0001069202-20-000039:mdna:117]

[0001069202-20-000048:mdna:119]
The following table summarizes our cash flow activity for the nine months ended September 30, 2020 and 2019 (in millions):

[0001069202-20-000048:mdna:120]
|  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |
| Net cash provided by operating activities | $ | 446.2 |  |  | $ | 124.5 |  |
| Net cash used in investing activities | (56.5) |  |  | (23.1) |  |
| Net cash used in financing activities | (365.0) |  |  | (102.8) |  |

[0001069202-20-000048:mdna:121]
Net Cash Provided by Operating Activities - We generated $446 million in cash from operating activities during the nine months ended September 30, 2020. The increase in net cash provided by operating activities for the nine months ended September 30, 2020 compared to the same period in 2019 reflects lower working capital requirements in 2020.

[0001069202-20-000048:mdna:122]
Net Cash Used in Investing Activities - Capital expenditures were $56 million in the nine months ended September 30, 2020 compared to $77 million in the same period of 2019.  Capital expenditures in 2020 were primarily related to the expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.  For the nine months ended September 30, 2019, we also received net proceeds of $44 million for the sale of our Kysor Warren business and insurance recoveries of $12 million to replace property and equipment damaged by the Marshalltown tornado.

[0001069202-20-000048:mdna:123]
Net Cash Used in Financing Activities - Net cash used in financing activities in the nine months ended September 30, 2020 increased to $365 million from $103 million in the same period of 2019.  The increase was primarily due to lower net borrowings, which resulted from reduced working capital requirements, and was partially offset by fewer stock repurchases.  We repurchased $100 million of shares for the nine months ended September 30, 2020 and returned $89 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000048:mdna:124]
[same as prior period, unchanged from 0001069202-20-000039:mdna:123]

[0001069202-20-000048:mdna:125]
The following table details our lines of credit and financing arrangements as of September 30, 2020 (in millions):

[0001069202-20-000048:mdna:126]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (2) | $ | — |  |
| Finance lease obligations | 9.6 |  |
| Domestic credit facility (1) | — |  |
| Debt issuance costs | (2.6) |  |
| Total current maturities of long-term debt | $ | 7.0 |  |
| Long-term debt: |  |
| Finance lease obligations | 28.8 |  |
| Domestic credit facility (1) | 34.5 |  |
| Senior unsecured notes | 950.0 |  |
| Debt issuance costs | (6.7) |  |
| Total long-term debt | 1,006.6 |  |
| Total debt | $ | 1,013.6 |  |

[0001069202-20-000048:mdna:127]
(1) The available future borrowings on our domestic credit facility are $713.3 million, after being reduced by the outstanding borrowings and $2.2 million in outstanding standby letters of credit.  We also had $29.6 million in outstanding standby letters of credit outside of the domestic credit facility as of September 30, 2020. The domestic credit facility matures in August 2022.

[0001069202-20-000048:mdna:128]
[same as prior period, unchanged from 0001069202-20-000039:mdna:127]

[0001069202-20-000048:mdna:129]
[same as prior period, unchanged from 0001069202-20-000039:mdna:128]

[0001069202-20-000048:mdna:130]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 112.9% at September 30, 2020 from 117.0% at December 31, 2019.

[0001069202-20-000048:mdna:131]
As of September 30, 2020, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-20-000048:mdna:132]
[same as prior period, unchanged from 0001069202-20-000039:mdna:131]

[0001069202-20-000048:mdna:133]
We believe our cash and cash equivalents of $55 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $55 million as of September 30, 2020 was $25 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-20-000048:mdna:134]
[same as prior period, unchanged from 0001069202-20-000039:mdna:133]

[0001069202-20-000048:mdna:135]
[same as prior period, unchanged from 0001069202-20-000039:mdna:134]

[0001069202-20-000048:mdna:136]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of September 30, 2020 and December 31, 2019 and for the three and nine months ended September 30, 2020 (in millions):

[0001069202-20-000048:mdna:137]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Current assets | $ | 464.8 |  |  | $ | 594.5 |  |
| Non-current assets | $ | 2,880.8 |  |  | $ | 2,297.8 |  |
| Current liabilities | $ | 590.3 |  |  | $ | 619.7 |  |
| Non-current liabilities | $ | 1,355.1 |  |  | $ | 1,169.4 |  |
| Amounts due to non-guarantor subsidiaries | $ | (329.0) |  |  | $ | (339.2) |  |

[0001069202-20-000048:mdna:138]
|  | For the Three Months EndedSeptember 30, 2020 |  | For the Nine Months EndedSeptember 30, 2020 |  | For the Year Ended December 31, 2019 |
| Net sales | $ | 960.0 |  |  | $ | 2,531.1 |  |  | $ | 3,479.8 |  |
| Gross profit | $ | 294.6 |  |  | $ | 725.9 |  |  | $ | 966.6 |  |
| Income from continuing operations | $ | 262.0 |  |  | $ | 500.2 |  |  | $ | 828.4 |  |
| Net income | $ | 262.0 |  |  | $ | 500.2 |  |  | $ | 828.4 |  |
| Net sales to non-guarantor subsidiaries | $ | 55.0 |  |  | $ | 178.0 |  |  | $ | 228.3 |  |

[0001069202-20-000048:mdna:139]
[same as prior period, unchanged from 0001069202-20-000039:mdna:138]

[0001069202-20-000048:mdna:140]
[same as prior period, unchanged from 0001069202-20-000039:mdna:139]

[0001069202-20-000048:mdna:141]
Commitments, Contingencies and Guarantees

[0001069202-20-000048:mdna:142]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000048:mdna:143]
[same as prior period, unchanged from 0001069202-20-000039:mdna:142]

[0001069202-20-000048:mdna:144]
[same as prior period, unchanged from 0001069202-20-000039:mdna:143]
