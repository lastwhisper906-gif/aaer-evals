# LII 8-K — 0001069202-20-000042 filed 2020-10-19

## item codes, every 8-K on or before 2020-10-19

- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2020-10-19

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-20-000042:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetabl.htm
EX-99.1

[0001069202-20-000042:8k_2_02:2]
Document

[0001069202-20-000042:8k_2_02:3]
Exhibit-99.1

[0001069202-20-000042:8k_2_02:4]
Lennox International Reports Record Third Quarter Revenue and Profit and Raises 2020 Guidance

[0001069202-20-000042:8k_2_02:5]
•Revenue up 2% to third-quarter record $1.06 billion, led by 13% Residential growth

[0001069202-20-000042:8k_2_02:6]
•GAAP EPS from continuing operations up 16% to record $3.42

[0001069202-20-000042:8k_2_02:7]
•Adjusted EPS from continuing operations up 6% to third-quarter record $3.53

[0001069202-20-000042:8k_2_02:8]
•Raising 2020 guidance for adjusted revenue from a decline of 10-15% to a decline of 5-9%

[0001069202-20-000042:8k_2_02:9]
•Raising 2020 guidance for GAAP EPS from continuing operations from $7.31-$8.11 to $8.35-$8.95

[0001069202-20-000042:8k_2_02:10]
•Raising 2020 guidance for adjusted EPS from continuing operations from $7.90-$8.70 to $9.05-$9.65

[0001069202-20-000042:8k_2_02:11]
DALLAS, October 19, 2020 – Lennox International Inc. (NYSE: LII) today reported financial results for the third quarter of 2020. All comparisons are to the prior-year period. The company’s prior-year insurance references relate to the July 2018 tornado damage at a Residential manufacturing facility in Iowa. Adjusted revenue and profit for the first nine months of 2019 exclude non-core Refrigeration businesses divested in the first half of that year.

[0001069202-20-000042:8k_2_02:12]
Lennox International reported record third-quarter revenue of $1.06 billion, up 2%. GAAP operating income was a third-quarter record $167 million, up 7%. GAAP earnings per share from continuing operations was a record $3.42, up 16%. The third quarter of 2019 included an insurance benefit of $2 million.

[0001069202-20-000042:8k_2_02:13]
Total segment profit was a third-quarter record $177 million, up 1% from the prior-year quarter that included $16 million of insurance benefit. Total segment margin was 16.7% compared to the third-quarter record 17.0% in the prior-year quarter with the insurance benefit. Adjusted earnings per share from continuing operations was a third-quarter record $3.53, up 6%.

[0001069202-20-000042:8k_2_02:14]
“Lennox International posted record third-quarter revenue and profit driven by the performance of our Residential business in the quarter,” said Chairman and CEO Todd Bluedorn. “Residential revenue rose 13% and set a new record for any quarter at $722 million. Revenue from replacement business was up low-double digits, and revenue from new construction was up mid-teens. Residential segment profit grew 21% to a third-quarter record $153 million, and segment margin expanded 140 basis points to a third-quarter record 21.2%. On an operational basis excluding $16 million of insurance benefit in the prior-year quarter, segment profit was up 38% and segment margin expanded 390 basis points.

[0001069202-20-000042:8k_2_02:15]
“Turning to our commercial-facing businesses, both Commercial and Refrigeration continued to be more impacted than Residential from the pandemic, but the year-over-year decline moderated in the third quarter from what we saw in the second quarter this year. In Commercial, revenue and profit were down 18%. Commercial equipment revenue was down 20%, and service revenue was down low-double digits. Segment margin expanded 10 basis points to 18.7%. In the Refrigeration segment, revenue was down 14% at constant currency, with North America down high-teens and Europe down high-single digits. Refrigeration profit declined 34%, and segment margin contracted 350 basis points to 10.4%.

[0001069202-20-000042:8k_2_02:16]
“We continue to face highly uncertain economic conditions in the fourth quarter and remain cautious on the potential impact from the pandemic heading into the winter season. The company remains competitively well-positioned to capitalize on market opportunities with a seasoned team experienced in managing through downturns, while continuing to invest and advance the company’s position for the future. For 2020, we are raising revenue guidance from a decline of 10-15% to a decline of 5-9% for the full year. We are raising 2020 guidance for adjusted EPS from continuing operations from a range of $7.90-$8.70 to $9.05-$9.65. And we are raising free cash flow guidance from approximately $340 million to $425 million this year as the company maintains a strong balance sheet with strong cash generation.”

[0001069202-20-000042:8k_2_02:17]
FINANCIAL HIGHLIGHTS

[0001069202-20-000042:8k_2_02:18]
Revenue: Revenue was a third-quarter record $1.06 billion, up 2% with volume, price and mix favorable to revenue. Foreign exchange was neutral to revenue.

[0001069202-20-000042:8k_2_02:19]
Gross Profit: Gross profit was $323 million, up 8%, and gross margin was 30.6%, up 170 basis points. Gross profit was positively impacted by favorable price, lower material and other product costs, higher factory productivity, lower distribution and freight costs, and favorable foreign exchange. Partial offsets included unfavorable mix and tariffs.

[0001069202-20-000042:8k_2_02:20]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the third quarter was $131.7 million, or $3.42 per share, compared to $114.7 million, or $2.94 per share, in the prior-year quarter.

[0001069202-20-000042:8k_2_02:21]
Adjusted income from continuing operations in the third quarter was $136.1 million, or $3.53 per share, compared to $130.0 million, or $3.34 per share, in the prior-year quarter. Adjusted income from continuing operations for the third quarter of 2020 excludes net after-tax charges of $4.4 million, consisting of: a $3.6 million loss from natural disasters, net of insurance recoveries, related to the August 2020 high-wind damage at the company’s manufacturing facility in Iowa; $2.2 million for personal protective equipment and facility deep cleaning expenses incurred due to the COVID-19 pandemic; a net charge of $1.4 million for various other items; and a benefit of $2.8 million for excess tax benefits from share-based compensation.

[0001069202-20-000042:8k_2_02:22]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from operations in the third quarter was $440 million, compared to $236 million in the prior-year quarter. Capital expenditures were $12 million in the third quarter, compared to approximately $25 million in the prior-year quarter. Free cash flow was $428 million compared to $211 million in the third quarter a year ago. Total debt at the end of the third quarter was $1.01 billion. Total cash, cash equivalents and short-term investments were $59 million at the end of September. In the third quarter, the company paid approximately $30 million in dividends.

[0001069202-20-000042:8k_2_02:23]
BUSINESS SEGMENT HIGHLIGHTS

[0001069202-20-000042:8k_2_02:24]
Residential Heating & Cooling

[0001069202-20-000042:8k_2_02:25]
Revenue in the Residential Heating & Cooling business segment was a record $722 million, up 13%. Foreign exchange was neutral to revenue. Segment profit was a third-quarter record $153 million, up 21% from the prior-year quarter that included $16 million of insurance benefit. Segment margin was a third-quarter record 21.2%, up 140 basis points from the prior-year quarter that included the insurance benefit. Residential results were primarily impacted by higher volume, favorable price, lower material and other product costs, higher factory productivity, and lower distribution and freight costs. Partial offsets included the year-over-year difference in insurance benefit, higher selling and incentive expenses, and tariffs.

[0001069202-20-000042:8k_2_02:26]
Commercial Heating & Cooling

[0001069202-20-000042:8k_2_02:27]
Revenue in the Commercial Heating & Cooling business segment was $208 million, down 18%. Foreign exchange was neutral to revenue. Segment profit was $39 million, down 18%, and segment margin was 18.7%, up 10 basis points. Commercial results were primarily impacted by lower volume driven by the COVID-19 pandemic and unfavorable mix. Partial offsets included lower material costs, higher factory productivity, lower distribution costs, and lower SG&A expense.

[0001069202-20-000042:8k_2_02:28]
Refrigeration

[0001069202-20-000042:8k_2_02:29]
Revenue in the Refrigeration business segment was $125 million, down 12%. Foreign exchange had a favorable 2% impact on revenue. Segment profit was $13 million, down 34%, and segment margin was 10.4%, down 350 basis points. Refrigeration results were primarily impacted by lower volume and lower factory efficiency due to the COVID-19 pandemic, and unfavorable mix. Partial offsets included favorable price, lower material costs, lower SG&A expense, and favorable foreign exchange.

[0001069202-20-000042:8k_2_02:30]
FULL-YEAR GUIDANCE

[0001069202-20-000042:8k_2_02:31]
The company is updating its 2020 guidance and raising estimates for revenue and EPS from continuing operations.

[0001069202-20-000042:8k_2_02:32]
•Raising guidance for adjusted revenue to be down 5-9% from the prior year compared to previous guidance to be down 10-15%.

[0001069202-20-000042:8k_2_02:33]
•Raising guidance for GAAP EPS from continuing operations to $8.35-$8.95 from previous guidance of $7.31-$8.11.

[0001069202-20-000042:8k_2_02:34]
•Raising guidance for adjusted EPS from continuing operations to $9.05-$9.65 from previous guidance of $7.90-$8.70.

[0001069202-20-000042:8k_2_02:35]
•Corporate expense is now expected to be approximately $90 million, primarily due to higher incentive compensation, compared to prior guidance of $75 million.

[0001069202-20-000042:8k_2_02:36]
•The effective tax rate is now expected to be 19-20% on an adjusted basis for the full year compared to prior guidance of 21-22%.

[0001069202-20-000042:8k_2_02:37]
•Capital expenditures are now targeted to be approximately $100 million compared to previous guidance of approximately $120 million.

[0001069202-20-000042:8k_2_02:38]
•Free cash flow is now expected to be approximately $425 million for the full year, up from prior guidance of approximately $340 million.

[0001069202-20-000042:8k_2_02:39]
•The company’s remaining 2020 stock repurchase program of $300 million currently remains on hold; the company repurchased $100 million of stock in the first quarter.

[0001069202-20-000042:8k_2_02:40]
•The company’s quarterly dividend plans remain unchanged at $0.77 per share, or more than $115 million in total for the year.

[0001069202-20-000042:8k_2_02:41]
CONFERENCE CALL INFORMATION

[0001069202-20-000042:8k_2_02:42]
A conference call to discuss the company’s third-quarter results and outlook will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 877-336-4440 (U.S.) or 409-207-6984 (international) at least 10 minutes prior to the scheduled start time and use participant code 8252687. The conference call also will be webcast on Lennox International’s web

[0001069202-20-000042:8k_2_02:43]
site at www.lennoxinternational.com. A replay will be available from approximately 11:00 a.m. Central time on October 19 through November 2, 2020 by dialing 866-207-1041 (U.S.) or 402-970-0847 (international) and using access code 9386544. The call also will be archived on the company’s website.

[0001069202-20-000042:8k_2_02:44]
About Lennox International

[0001069202-20-000042:8k_2_02:45]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-20-000042:8k_2_02:46]
FORWARD-LOOKING STATEMENTS

[0001069202-20-000042:8k_2_02:47]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000042:8k_2_02:48]
Consolidated Statements of Operations

[0001069202-20-000042:8k_2_02:49]
(Unaudited)

[0001069202-20-000042:8k_2_02:50]
| (Amounts in millions, except per share data) | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales | $ | 1,055.0 |  |  | $ | 1,032.9 |  |  | $ | 2,720.1 |  |  | $ | 2,922.2 |  |
| Cost of goods sold | 731.7 |  |  | 734.6 |  |  | 1,955.3 |  |  | 2,090.3 |  |
| Gross profit | 323.3 |  |  | 298.3 |  |  | 764.8 |  |  | 831.9 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 151.8 |  |  | 143.4 |  |  | 412.7 |  |  | 441.6 |  |
| Losses (gains) and other expenses, net | 3.4 |  |  | 2.2 |  |  | 5.6 |  |  | 5.3 |  |
| Restructuring charges | 0.1 |  |  | 6.1 |  |  | 10.6 |  |  | 6.5 |  |
| Loss on sale of business | — |  |  | 0.2 |  |  | — |  |  | 9.1 |  |
| Loss (gain) from natural disasters, net of insurance recoveries | 4.9 |  |  | (7.1) |  |  | 7.6 |  |  | (85.4) |  |
| Income from equity method investments | (4.0) |  |  | (3.3) |  |  | (11.2) |  |  | (10.5) |  |
| Operating income | 167.1 |  |  | 156.8 |  |  | 339.5 |  |  | 465.3 |  |
| Pension settlements | 0.3 |  |  | — |  |  | 0.3 |  |  | 60.6 |  |
| Interest expense, net | 6.5 |  |  | 12.5 |  |  | 22.2 |  |  | 36.5 |  |
| Other expense (income), net | 1.1 |  |  | 0.6 |  |  | 3.3 |  |  | 1.7 |  |
| Income from continuing operations before income taxes | 159.2 |  |  | 143.7 |  |  | 313.7 |  |  | 366.5 |  |
| Provision for income taxes | 27.5 |  |  | 29.0 |  |  | 68.8 |  |  | 71.5 |  |
| Income from continuing operations | 131.7 |  |  | 114.7 |  |  | 244.9 |  |  | 295.0 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes | — |  |  | — |  |  | (0.9) |  |  | (0.4) |  |
| Income tax benefit | — |  |  | — |  |  | (0.6) |  |  | (0.1) |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.3) |  |  | (0.3) |  |
| Net income | $ | 131.7 |  |  | $ | 114.7 |  |  | $ | 244.6 |  |  | $ | 294.7 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.44 |  |  | $ | 2.97 |  |  | $ | 6.39 |  |  | $ | 7.54 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01) |  |  | (0.01) |  |
| Net income | $ | 3.44 |  |  | $ | 2.97 |  |  | $ | 6.38 |  |  | $ | 7.53 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.42 |  |  | $ | 2.94 |  |  | $ | 6.35 |  |  | $ | 7.46 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01) |  |  | — |  |
| Net income | $ | 3.42 |  |  | $ | 2.94 |  |  | $ | 6.34 |  |  | $ | 7.46 |  |
| Weighted Average Number of Shares Outstanding - Basic | 38.3 |  |  | 38.6 |  |  | 38.3 |  |  | 39.1 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 38.6 |  |  | 39.0 |  |  | 38.6 |  |  | 39.5 |  |

[0001069202-20-000042:8k_2_02:51]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |
| Adjusted Segment Net Sales and Profit (Loss) |  |  |  |
| (Unaudited) |  |  |  |

[0001069202-20-000042:8k_2_02:52]
| (Amounts in millions) | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 722.0 |  |  | $ | 637.6 |  |  | $ | 1,808.8 |  |  | $ | 1,792.2 |  |
| Commercial Heating & Cooling | 207.9 |  |  | 253.3 |  |  | 574.6 |  |  | 687.9 |  |
| Refrigeration (1) | 125.1 |  |  | 142.0 |  |  | $ | 336.7 |  |  | 407.8 |  |
|  | $ | 1,055.0 |  |  | $ | 1,032.9 |  |  | $ | 2,720.1 |  |  | $ | 2,887.9 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 153.0 |  |  | $ | 126.5 |  |  | $ | 312.8 |  |  | $ | 366.6 |  |
| Commercial Heating & Cooling | 38.8 |  |  | 47.1 |  |  | 93.1 |  |  | 116.0 |  |
| Refrigeration (1) | 13.0 |  |  | 19.8 |  |  | 22.6 |  |  | 48.3 |  |
| Corporate and other | (28.3) |  |  | (18.1) |  |  | (61.3) |  |  | (54.3) |  |
| Total adjusted segment profit | 176.5 |  |  | 175.3 |  |  | 367.2 |  |  | 476.6 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Special product quality adjustments | — |  |  | (0.5) |  |  | (1.0) |  |  | (1.0) |  |
| Loss on sale of business | — |  |  | 0.2 |  |  | — |  |  | 9.1 |  |
| Prior quarter partial advance of insurance recoveries related to lost profits | — |  |  | 8.0 |  |  | — |  |  | — |  |
| Loss (gain) from natural disasters, net of insurance recoveries | 4.9 |  |  | 1.2 |  |  | 7.6 |  |  | (11.6) |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 4.4 |  |  | 3.5 |  |  | 10.5 |  |  | 7.3 |  |
| Restructuring charges | 0.1 |  |  | 6.1 |  |  | 10.6 |  |  | 6.5 |  |
| Operating loss from non-core business (1) | — |  |  | — |  |  | — |  |  | 1.0 |  |
| Operating income | $ | 167.1 |  |  | $ | 156.8 |  |  | $ | 339.5 |  |  | $ | 465.3 |  |

[0001069202-20-000042:8k_2_02:53]
(1) Excludes the non-core business results related to Kysor Warren, which was sold in March 2019.

[0001069202-20-000042:8k_2_02:54]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-20-000042:8k_2_02:55]
•The following items in Losses (gains) and other expenses, net:

[0001069202-20-000042:8k_2_02:56]
◦Net change in unrealized (gains) losses on unsettled futures contracts,

[0001069202-20-000042:8k_2_02:57]
◦Special legal contingency charges,

[0001069202-20-000042:8k_2_02:58]
◦Asbestos-related litigation,

[0001069202-20-000042:8k_2_02:59]
◦Environmental liabilities,

[0001069202-20-000042:8k_2_02:60]
◦Charges incurred related to COVID-19 pandemic,

[0001069202-20-000042:8k_2_02:61]
◦Other items, net,

[0001069202-20-000042:8k_2_02:62]
•Loss on sale of business,

[0001069202-20-000042:8k_2_02:63]
•Special product quality adjustments,

[0001069202-20-000042:8k_2_02:64]
•Prior quarter partial advance of insurance recoveries related to lost profits,

[0001069202-20-000042:8k_2_02:65]
•Loss (gain) from natural disasters, net of insurance recoveries,

[0001069202-20-000042:8k_2_02:66]
•Operating loss (income) from non-core business; and

[0001069202-20-000042:8k_2_02:67]
•Restructuring charges.

[0001069202-20-000042:8k_2_02:68]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000042:8k_2_02:69]
Consolidated Balance Sheets

[0001069202-20-000042:8k_2_02:70]
| (Amounts in millions, except shares and par values) | As of September 30, 2020 |  | As of December 31, 2019 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 55.0 |  |  | $ | 37.3 |  |
| Short-term investments | 4.1 |  |  | 2.9 |  |
| Accounts and notes receivable, net of allowances of $7.3 and $6.1 in 2020 and 2019, respectively | 542.7 |  |  | 477.8 |  |
| Inventories, net | 408.7 |  |  | 544.1 |  |
| Other assets | 53.5 |  |  | 58.8 |  |
| Total current assets | 1,064.0 |  |  | 1,120.9 |  |
| Property, plant and equipment, net of accumulated depreciation of $862.3 and $824.3 in 2020 and 2019, respectively | 444.9 |  |  | 445.4 |  |
| Right-of-use assets from operating leases | 196.0 |  |  | 181.6 |  |
| Goodwill | 186.7 |  |  | 186.5 |  |
| Deferred income taxes | 15.2 |  |  | 21.5 |  |
| Other assets, net | 74.4 |  |  | 79.0 |  |
| Total assets | $ | 1,981.2 |  |  | $ | 2,034.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 7.0 |  |  | 321.9 |  |
| Current operating lease liabilities | 54.1 |  |  | 52.7 |  |
| Accounts payable | 361.0 |  |  | 372.4 |  |
| Accrued expenses | 287.8 |  |  | 255.7 |  |
| Income taxes payable | 1.1 |  |  | — |  |
| Total current liabilities | 711.0 |  |  | 1,002.7 |  |
| Long-term debt | 1,006.6 |  |  | 849.3 |  |
| Long-term operating lease liabilities | 144.5 |  |  | 131.0 |  |
| Pensions | 92.9 |  |  | 87.4 |  |
| Other liabilities | 141.9 |  |  | 134.7 |  |
| Total liabilities | 2,096.9 |  |  | 2,205.1 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,109.4 |  |  | 1,093.5 |  |
| Retained earnings | 2,303.7 |  |  | 2,148.7 |  |
| Accumulated other comprehensive loss | (114.9) |  |  | (103.8) |  |
| Treasury stock, at cost, 48,883,807 shares and 48,575,901 shares for 2020 and 2019, respectively | (3,414.8) |  |  | (3,309.5) |  |
| Total stockholders' deficit | (115.7) |  |  | (170.2) |  |
| Total liabilities and stockholders' deficit | $ | 1,981.2 |  |  | $ | 2,034.9 |  |

[0001069202-20-000042:8k_2_02:71]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000042:8k_2_02:72]
Consolidated Statements of Cash Flows

[0001069202-20-000042:8k_2_02:73]
(Unaudited)

[0001069202-20-000042:8k_2_02:74]
| (Amounts in millions) | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 244.6 |  |  | $ | 294.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Loss on sale of business | — |  |  | 9.1 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | (11.6) |  |
| Income from equity method investments | (11.2) |  |  | (10.5) |  |
| Dividends from affiliates | 9.3 |  |  | 9.3 |  |
| Restructuring charges, net of cash paid | 3.5 |  |  | 6.0 |  |
| Provision for credit losses | 5.0 |  |  | 4.0 |  |
| Unrealized losses (gains), net on derivative contracts | 0.5 |  |  | (0.1) |  |
| Stock-based compensation expense | 18.4 |  |  | 15.6 |  |
| Depreciation and amortization | 55.4 |  |  | 53.1 |  |
| Deferred income taxes | 5.6 |  |  | 17.0 |  |
| Pension expense | 7.7 |  |  | 65.9 |  |
| Pension contributions | (2.8) |  |  | (1.7) |  |
| Other items, net | 2.0 |  |  | (0.4) |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (69.3) |  |  | (178.2) |  |
| Inventories | 137.6 |  |  | (107.0) |  |
| Other current assets | 2.0 |  |  | 1.5 |  |
| Accounts payable | (2.4) |  |  | (24.5) |  |
| Accrued expenses | 29.6 |  |  | 7.6 |  |
| Income taxes payable / receivable | 6.8 |  |  | (8.2) |  |
| Other, net | 3.9 |  |  | (17.1) |  |
| Net cash provided by operating activities | 446.2 |  |  | 124.5 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.7 |  |  | 1.2 |  |
| Purchases of property, plant and equipment | (55.9) |  |  | (77.0) |  |
| Net proceeds from sale of business | — |  |  | 43.5 |  |
| Purchases of short-term investments | (1.3) |  |  | (2.4) |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 11.6 |  |
| Net cash used in investing activities | (56.5) |  |  | (23.1) |  |
| Cash flows from financing activities: |  |  |  |
| Short-term debt payments | (4.6) |  |  | (5.3) |  |
| Short-term debt borrowings | 4.6 |  |  | 5.3 |  |
| Asset securitization borrowings | 91.0 |  |  | 155.5 |  |
| Asset securitization payments | (376.0) |  |  | (58.0) |  |
| Long-term debt payments | (5.4) |  |  | (35.0) |  |
| Long-term debt borrowings | 600.0 |  |  | — |  |
| Borrowings from credit facility | 1,509.5 |  |  | 1,938.5 |  |
| Payments on credit facility | (1,980.5) |  |  | (1,608.5) |  |
| Payments of deferred financing costs | (7.1) |  |  | — |  |
| Proceeds from employee stock purchases | 2.2 |  |  | 2.5 |  |
| Repurchases of common stock | (100.0) |  |  | (400.0) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (10.1) |  |  | (16.9) |  |
| Cash dividends paid | (88.6) |  |  | (80.9) |  |
| Net cash used in financing activities | (365.0) |  |  | (102.8) |  |
| Increase in cash and cash equivalents | 24.7 |  |  | (1.4) |  |
| Effect of exchange rates on cash and cash equivalents | (7.0) |  |  | 1.2 |  |
| Cash and cash equivalents, beginning of period | 37.3 |  |  | 46.3 |  |
| Cash and cash equivalents, end of period | $ | 55.0 |  |  | $ | 46.1 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 19.0 |  |  | $ | 31.5 |  |
| Income taxes paid (net of refunds) | $ | 55.1 |  |  | $ | 78.7 |  |
| Insurance recoveries received | $ | — |  |  | $ | 138.0 |  |

[0001069202-20-000042:8k_2_02:75]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |  |  |  |  |  |  |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |  |  |  |  |  |  |  |  |  |  |  |
| (Unaudited, in millions, except per share and ratio data) |  |  |  |  |  |  |  |  |  |  |  |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. During the first quarter of 2019, the Company completed the sale of its Kysor Warren business. The results from operations for this business have been shown in the tables below as “Non-core business results”. |  |  |  |  |  |  |  |  |  |  |  |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |  |  |  |  |  |  |  |  |  |  |  |
|  | For the Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |  |  |  |  |
| Income from continuing operations, a GAAP measure | $ | 159.2 |  | $ | (27.5) |  | $ | 131.7 |  |  | $ | 143.7 |  | $ | (29.0) |  | $ | 114.7 |  |  |  |  |  |
| Restructuring charges | 0.1 |  | — |  | 0.1 |  |  | 6.1 |  | (1.3) |  | 4.8 |  |  |  |  |  |
| Pension settlement | 0.3 |  | (0.1) |  | 0.2 |  |  | — |  | — |  | — |  |  |  |  |  |
| Special product quality adjustments (b) | — |  | — |  | — |  |  | (0.5) |  | 0.1 |  | (0.4) |  |  |  |  |  |
| Special legal contingency charges (a) | 0.2 |  | (0.1) |  | 0.1 |  |  | 0.3 |  | (0.1) |  | 0.2 |  |  |  |  |  |
| Asbestos-related litigation (a) | 2.4 |  | (0.6) |  | 1.8 |  |  | 1.5 |  | (0.3) |  | 1.2 |  |  |  |  |  |
| Net change in unrealized (gains) losses on unsettled futures contracts (a) | (1.4) |  | 0.3 |  | (1.1) |  |  | 0.1 |  | (0.1) |  | — |  |  |  |  |  |
| Environmental liabilities (a) | 0.3 |  | (0.1) |  | 0.2 |  |  | 1.1 |  | (0.2) |  | 0.9 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) | — |  | (2.8) |  | (2.8) |  |  | — |  | (1.7) |  | (1.7) |  |  |  |  |  |
| Other tax items, net (c) | — |  | 0.1 |  | 0.1 |  |  | — |  | 2.7 |  | 2.7 |  |  |  |  |  |
| Loss on sale of business | — |  | — |  | — |  |  | 0.2 |  | — |  | 0.2 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) | 3.0 |  | (0.8) |  | 2.2 |  |  | — |  | — |  | — |  |  |  |  |  |
| Prior quarter partial advance of insurance recoveries related to lost profits (f) | — |  | — |  | — |  |  | 8.0 |  | (2.1) |  | 5.9 |  |  |  |  |  |
| Loss from natural disasters, net of insurance recoveries | 4.9 |  | (1.3) |  | 3.6 |  |  | 1.2 |  | (0.2) |  | 1.0 |  |  |  |  |  |
| Other items, net (a) | (0.1) |  | 0.1 |  | — |  |  | 0.6 |  | (0.1) |  | 0.5 |  |  |  |  |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 168.9 |  | $ | (32.8) |  | $ | 136.1 |  |  | $ | 162.3 |  | $ | (32.3) |  | $ | 130.0 |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  | $ | 3.42 |  |  |  |  | $ | 2.94 |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  |  | 0.12 |  |  |  |  |  |
| Pension settlement |  |  | 0.01 |  |  |  |  | — |  |  |  |  |  |
| Special product quality adjustments (b) |  |  | — |  |  |  |  | (0.01) |  |  |  |  |  |
| Special legal contingency charges (a) |  |  | — |  |  |  |  | 0.01 |  |  |  |  |  |
| Asbestos-related litigation (a) |  |  | 0.05 |  |  |  |  | 0.03 |  |  |  |  |  |
| Net change in unrealized (gains) losses on unsettled futures contracts (a) |  |  | (0.03) |  |  |  |  | — |  |  |  |  |  |
| Environmental liabilities (a) |  |  | 0.01 |  |  |  |  | 0.02 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) |  |  | (0.07) |  |  |  |  | (0.04) |  |  |  |  |  |
| Other tax items, net (c) |  |  | — |  |  |  |  | 0.07 |  |  |  |  |  |
| Loss on sale of business |  |  | — |  |  |  |  | 0.01 |  |  |  |  |  |

[0001069202-20-000042:8k_2_02:76]
| Charges incurred related to COVID-19 pandemic (a) |  |  | 0.05 |  |  |  |  | — |  |  |  |  |  |
| Prior quarter partial advance of insurance recoveries related to lost profits (f) |  |  | — |  |  |  |  | 0.15 |  |  |  |  |  |
| Loss from natural disasters, net of insurance recoveries |  |  | 0.09 |  |  |  |  | 0.03 |  |  |  |  |  |
| Other items, net (a) |  |  | — |  |  |  |  | 0.01 |  |  |  |  |  |
| Change in share counts from share-based compensation (d) |  |  | — |  |  |  |  | — |  |  |  |  |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 3.53 |  |  |  |  | $ | 3.34 |  |  |  |  |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount.. |  |  |  |  |  |  |  |  |  |  |  |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |  |  |  |  |  |  |  |  |  |  |  |
| (f) During the second quarter of 2019, the Company received a partial advance of $8 million related to lost profits incurred in the second quarter. The Company included this amount in adjusted income in the third quarter as the lost profits related to the second quarter were collected in full. |  |  |  |  |  |  |  |  |  |  |  |
|  | For the Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |  |  |  |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |  |  |  |  |
| Income from continuing operations, a GAAP measure | $ | 313.7 |  | $ | (68.8) |  | $ | 244.9 |  |  | $ | 366.5 |  | $ | (71.5) |  | $ | 295.0 |  |  |  |  |  |
| Restructuring charges | 10.6 |  | (2.4) |  | 8.2 |  |  | 6.5 |  | (1.4) |  | 5.1 |  |  |  |  |  |
| Pension settlements | 0.3 |  | (0.1) |  | 0.2 |  |  | 60.6 |  | (15.1) |  | 45.5 |  |  |  |  |  |
| Special product quality adjustments (b) | (1.0) |  | 0.2 |  | (0.8) |  |  | (1.0) |  | 0.2 |  | (0.8) |  |  |  |  |  |
| Special legal contingency charges (a) | 0.9 |  | (0.2) |  | 0.7 |  |  | 0.5 |  | (0.1) |  | 0.4 |  |  |  |  |  |
| Asbestos-related litigation (a) | 1.9 |  | (0.4) |  | 1.5 |  |  | 3.3 |  | (0.7) |  | 2.6 |  |  |  |  |  |
| Net change in unrealized gains on unsettled futures contracts (a) | — |  | — |  | — |  |  | (0.2) |  | — |  | (0.2) |  |  |  |  |  |
| Environmental liabilities (a) | 1.5 |  | (0.3) |  | 1.2 |  |  | 2.4 |  | (0.5) |  | 1.9 |  |  |  |  |  |
| Excess tax benefits from share-based compensation (c) | — |  | (2.8) |  | (2.8) |  |  | — |  | (7.0) |  | (7.0) |  |  |  |  |  |
| Other tax items, net (c) | — |  | 8.2 |  | 8.2 |  |  | — |  | 3.3 |  | 3.3 |  |  |  |  |  |
| Loss on sale of business | — |  | — |  | — |  |  | 9.1 |  | (3.5) |  | 5.6 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) | 6.4 |  | (1.6) |  | 4.8 |  |  | — |  | — |  | — |  |  |  |  |  |
| Loss (gain) from natural disasters, net of insurance recoveries | 7.6 |  | (1.9) |  | 5.7 |  |  | (11.6) |  | 2.9 |  | (8.7) |  |  |  |  |  |
| Other items, net (a) | (0.2) |  | 0.1 |  | (0.1) |  |  | 1.3 |  | (0.2) |  | 1.1 |  |  |  |  |  |
| Non-core business results (f) | — |  | — |  | — |  |  | 1.3 |  | (0.3) |  | 1.0 |  |  |  |  |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 341.7 |  | $ | (70.0) |  | $ | 271.7 |  |  | $ | 438.7 |  | $ | (93.9) |  | $ | 344.8 |  |  |  |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  | $ | 6.35 |  |  |  |  | $ | 7.46 |  |  |  |  |  |
| Restructuring charges |  |  | 0.21 |  |  |  |  | 0.13 |  |  |  |  |  |
| Pension settlements |  |  | 0.01 |  |  |  |  | 1.15 |  |  |  |  |  |
| Special product quality adjustments (b) |  |  | (0.02) |  |  |  |  | (0.02) |  |  |  |  |  |
| Special legal contingency charges (a) |  |  | 0.02 |  |  |  |  | 0.01 |  |  |  |  |  |
| Asbestos-related litigation (a) |  |  | 0.04 |  |  |  |  | 0.07 |  |  |  |  |  |
| Net change in unrealized gains on unsettled futures contracts (a) |  |  | — |  |  |  |  | (0.01) |  |  |  |  |  |
| Environmental liabilities (a) |  |  | 0.03 |  |  |  |  | 0.05 |  |  |  |  |  |

[0001069202-20-000042:8k_2_02:77]
| Excess tax benefits from share-based compensation (c) |  |  | (0.07) |  |  |  |  | (0.18) |  |  |  |  |  |
| Other tax items, net (c) |  |  | 0.21 |  |  |  |  | 0.08 |  |  |  |  |  |
| Loss on sale of business |  |  | — |  |  |  |  | 0.14 |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic (a) |  |  | 0.12 |  |  |  |  | — |  |  |  |  |  |
| Loss (gain) from natural disasters, net of insurance recoveries |  |  | 0.15 |  |  |  |  | (0.22) |  |  |  |  |  |
| Other items, net (a) |  |  | — |  |  |  |  | 0.03 |  |  |  |  |  |
| Non-core business results (f) |  |  | — |  |  |  |  | 0.03 |  |  |  |  |  |
| Change in share counts from share-based compensation (d) |  |  | — |  |  |  |  | 0.02 |  |  |  |  |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 7.05 |  |  |  |  | $ | 8.74 |  |  |  |  |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |  |  |  |  |  |  |  |  |  |  |  |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |  |  |  |  |  |  |  |  |  |  |  |
| (f) Non-core business results represent the Kysor Warren business, not included elsewhere in the reconciliation. |  |  |  |  |  |  |  |  |  |  |  |

[0001069202-20-000042:8k_2_02:78]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) | $ | — |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.4 |  |
| Foreign currency exchange gains (a) | (0.4) |  |  | (0.3) |  |  | (3.0) |  |  | (1.0) |  |
| Gain on disposal of fixed assets (a) | (0.2) |  |  | — |  |  | (0.4) |  |  | (0.2) |  |
| Other operating income (a) | (0.4) |  |  | (1.2) |  |  | (1.7) |  |  | (1.2) |  |
| Net change in unrealized (gains) losses on unsettled futures contracts (b) | (1.4) |  |  | 0.1 |  |  | — |  |  | (0.2) |  |
| Special legal contingency charges (b) | 0.2 |  |  | 0.3 |  |  | 0.9 |  |  | 0.5 |  |
| Asbestos-related litigation (b) | 2.4 |  |  | 1.5 |  |  | 1.9 |  |  | 3.3 |  |
| Environmental liabilities (b) | 0.3 |  |  | 1.1 |  |  | 1.5 |  |  | 2.4 |  |
| Charges incurred related to COVID-19 pandemic (b) | 3.0 |  |  | — |  |  | 6.4 |  |  | — |  |
| Other items, net (b) | (0.1) |  |  | 0.6 |  |  | (0.2) |  |  | 1.3 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.4 |  |  | $ | 2.2 |  |  | $ | 5.6 |  |  | $ | 5.3 |  |

[0001069202-20-000042:8k_2_02:79]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |  |  |  |  |  |  |  |  |  |  |  |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |  |  |  |  |  |  |  |  |  |  |  |

[0001069202-20-000042:8k_2_02:80]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |  |  |  |  |  |  |  |
|  |  |  |  |  | For the Year Ended December 31, 2020ESTIMATED |  |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $8.35-$8.95 |  |  |
| Other non-core EBIT charges and other non-core tax items, net, incurred in 1Q 2020, 2Q 2020 and 3Q 2020 |  |  |  |  | (0.70) |  |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  |  |  |  | $9.05-$9.65 |  |  |

[0001069202-20-000042:8k_2_02:81]
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |  |  |  |  |  |  |  |
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Average shares outstanding - diluted, a GAAP measure | 38.6 |  | $ | 39.0 |  |  | 38.6 |  | $ | 39.5 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | (0.1) |  |  | (0.1) |  |  | (0.1) |  |  | — |  |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 38.5 |  | 38.9 |  |  | 38.5 |  | 39.5 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended September 30, |  |  |  | For the Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales, a GAAP measure | $ | 125.1 |  |  | $ | 142.0 |  |  | $ | 1,055.0 |  |  | $ | 1,032.9 |  |
| Net sales from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted net sales, a Non-GAAP measure | $ | 125.1 |  |  | $ | 142.0 |  |  | $ | 1,055.0 |  |  | $ | 1,032.9 |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Nine Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales, a GAAP measure | $ | 336.7 |  |  | $ | 442.1 |  |  | $ | 2,720.1 |  |  | $ | 2,922.2 |  |
| Net sales from non-core business (a) | — |  |  | 34.3 |  |  | — |  |  | 34.3 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 336.7 |  |  | $ | 407.8 |  |  | $ | 2,720.1 |  |  | $ | 2,887.9 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended September 30, |  |  |  | For the Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit, a GAAP measure | $ | 38.5 |  |  | $ | 47.4 |  |  | $ | 323.3 |  |  | $ | 298.3 |  |
| Non-GAAP adjustments to gross profit | — |  |  | — |  |  | — |  |  | 0.5 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 38.5 |  |  | $ | 47.4 |  |  | $ | 323.3 |  |  | $ | 297.8 |  |

[0001069202-20-000042:8k_2_02:82]
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Nine Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit, a GAAP measure | $ | 98.2 |  |  | $ | 135.6 |  |  | $ | 764.8 |  |  | $ | 831.9 |  |
| Non-GAAP adjustments to gross profit | — |  |  | — |  |  | 1.0 |  |  | 1.0 |  |
| Gross profit from non-core business (a) | — |  |  | 3.6 |  |  | — |  |  | 3.6 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 98.2 |  |  | $ | 132.0 |  |  | $ | 763.8 |  |  | $ | 827.3 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended September 30, |  |  |  | For the Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment profit, a Non-GAAP measure | $ | 13.0 |  |  | $ | 19.8 |  |  | $ | 176.5 |  |  | $ | 175.3 |  |
| (Loss) profit from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 13.0 |  |  | $ | 19.8 |  |  | $ | 176.5 |  |  | $ | 175.3 |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Nine Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment profit, a Non-GAAP measure | $ | 22.6 |  |  | $ | 47.3 |  |  | $ | 367.2 |  |  | $ | 475.6 |  |
| (Loss) profit from non-core business (a) | — |  |  | (1.0) |  |  | — |  |  | (1.0) |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 22.6 |  |  | $ | 48.3 |  |  | $ | 367.2 |  |  | $ | 476.6 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Three Months Ended September 30, |  |  |  | For the Three Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Selling, general and administrative expenses, a GAAP measure | $ | 27.3 |  |  | $ | 30.4 |  |  | $ | 151.8 |  |  | $ | 143.4 |  |
| Selling, general and administrative expenses from non-core business | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 27.3 |  |  | $ | 30.4 |  |  | $ | 151.8 |  |  | $ | 143.4 |  |
|  | Refrigeration Segment |  |  |  | Consolidated |  |  |
|  | For the Nine Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Selling, general and administrative expenses, a GAAP measure | $ | 80.9 |  |  | $ | 96.3 |  |  | $ | 412.7 |  |  | $ | 441.6 |  |
| Selling, general and administrative expenses from non-core business (a) | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 80.9 |  |  | $ | 91.7 |  |  | $ | 412.7 |  |  | $ | 437.0 |  |
| (a) Non-Core businesses represent the Kysor Warren business. |  |  |  |  |  |  |  |

[0001069202-20-000042:8k_2_02:83]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net cash provided by operating activities | $ | 439.7 |  |  | $ | 235.5 |  |  | $ | 446.2 |  |  | $ | 124.5 |  |
| Purchases of property, plant and equipment | (12.4) |  |  | (23.5) |  |  | (55.9) |  |  | (77.0) |  |
| Proceeds from the disposal of property, plant and equipment | 0.4 |  |  | 0.4 |  |  | 0.7 |  |  | 1.2 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | (1.2) |  |  | — |  |  | 11.6 |  |
| Free cash flow, a Non-GAAP measure | 427.7 |  |  | 211.2 |  |  | 391.0 |  |  | 60.3 |  |

[0001069202-20-000042:8k_2_02:84]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to September 30, 2020 |
| Adjusted EBIT (a) |  |  |  |  |  |  | $ | 500.4 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  | 72.2 |  |
| EBITDA (a + b) |  |  |  |  |  |  | $ | 572.6 |  |
| Total debt at September 30, 2020 (c) |  |  |  |  |  |  | $ | 1,013.6 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  | 1.8 |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | Trailing Twelve Months to September 30, 2020 |
| Income from continuing operations before income taxes, a GAAP measure |  |  |  |  |  |  | $ | 455.1 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  |  |  |  |  | 14.5 |  |
| Special product quality adjustments |  |  |  |  |  |  | (0.6) |  |
| Restructuring charges |  |  |  |  |  |  | 14.4 |  |
| Interest expense, net |  |  |  |  |  |  | 33.1 |  |
| Pension settlements |  |  |  |  |  |  | 38.9 |  |
| Loss on sale of business |  |  |  |  |  |  | 1.5 |  |
| Insurance recoveries received for property damage incurred from natural disaster |  |  |  |  |  |  | (60.4) |  |
| Other expense (income), net |  |  |  |  |  |  | 3.9 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  |  |  |  |  | $ | 500.4 |  |
