# LII note change history — 0001069202-20-000039 → 0001069202-20-000048


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-10-19):
[0001069202-20-000048:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.
  (was, 2020-07-20, similarity 0.8737):
[0001069202-20-000039:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

- changed (2020-10-19):
[0001069202-20-000048:note_history:2]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Accrued expenses | $ | 37.0 |  |  | $ | 38.2 |  |
| Other liabilities | 80.4 |  |  | 74.6 |  |
| Total warranty liability | $ | 117.4 |  |  | $ | 112.8 |  |
  (was, 2020-07-20, similarity 0.9687):
[0001069202-20-000039:note_history:2]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Accrued expenses | $ | 37.5 |  |  | $ | 38.2 |  |
| Other liabilities | 79.4 |  |  | 74.6 |  |
| Total warranty liability | $ | 116.9 |  |  | $ | 112.8 |  |

- changed (2020-10-19):
[0001069202-20-000048:note_history:3]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2020 were as follows (in millions):
  (was, 2020-07-20, similarity 0.9444):
[0001069202-20-000039:note_history:3]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2020 were as follows (in millions):

- changed (2020-10-19):
[0001069202-20-000048:note_history:4]
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Warranty claims paid | (26.9) |  |
| Changes resulting from issuance of new warranties | 31.2 |  |
| Changes in estimates associated with pre-existing liabilities | 0.3 |  |
| Changes in foreign currency translation rates and other | — |  |
| Total warranty liability as of September 30, 2020 | $ | 117.4 |  |
  (was, 2020-07-20, similarity 0.9754):
[0001069202-20-000039:note_history:4]
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Warranty claims paid | (15.2) |  |
| Changes resulting from issuance of new warranties | 19.5 |  |
| Changes in estimates associated with pre-existing liabilities | 0.1 |  |
| Changes in foreign currency translation rates and other | (0.3) |  |
| Total warranty liability as of June 30, 2020 | $ | 116.9 |  |

- changed (2020-10-19):
[0001069202-20-000048:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):
  (was, 2020-07-20, similarity 0.9929):
[0001069202-20-000039:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

- changed (2020-10-19):
[0001069202-20-000048:note_history:6]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Expense (gain) for asbestos-related litigation, net | $ | 2.4 |  |  | $ | 1.5 |  |  | $ | 1.9 |  |  | $ | 3.3 |  |
  (was, 2020-07-20, similarity 0.6943):
[0001069202-20-000039:note_history:6]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Expense (gain) for asbestos-related litigation, net | $ | 1.2 |  |  | $ | 0.4 |  |  | $ | (0.5) |  |  | $ | 1.8 |  |

- added (2020-10-19):
[0001069202-20-000048:note_history:7]
Natural Disasters and Recovery

- added (2020-10-19):
[0001069202-20-000048:note_history:8]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  On August 10, 2020, the Marshalltown facility was partially damaged by a derecho wind storm. The costs and losses incurred as well as any insurance recoveries for both of these natural disasters are shown in Loss (gain) from natural disasters, net of insurance recoveries in the Consolidated Statements of Operations.

- changed (2020-10-19):
[0001069202-20-000048:note_history:9]
The following table summarizes the components of Loss (gain) from natural disasters, net of insurance recoveries (in millions):
  (was, 2020-07-20, similarity 0.6359):
[0001069202-20-000039:note_history:9]
The following table summarizes the Gain from insurance recoveries, net of losses incurred:

- added (2020-10-19):
[0001069202-20-000048:note_history:10]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Marshalltown tornado | $ | 0.4 |  |  | $ | (7.1) |  |  | $ | 3.1 |  |  | $ | (85.4) |  |
| Marshalltown wind storm | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |
| Loss (gain) from natural disasters, net of insurance recoveries | $ | 4.9 |  |  | $ | (7.1) |  |  | $ | 7.6 |  |  | $ | (85.4) |  |

- changed (2020-10-19):
[0001069202-20-000048:note_history:11]
Marshalltown Tornado
  (was, 2020-07-20, similarity 0.7547):
[0001069202-20-000039:note_history:11]
Marshalltown Tornado and Recovery

- added (2020-10-19):
[0001069202-20-000048:note_history:12]
Insurance covered the repair or replacement of our assets that suffered damage or loss, and business interruption costs, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.  In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019. The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the tornado (in millions):

- changed (2020-10-19):
[0001069202-20-000048:note_history:13]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Insurance recoveries received | $ | — |  |  | $ | 10.0 |  |  | $ | — |  |  | $ | 138.0 |  |
| Losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | — |  |  | (3.5) |  |  | — |  |  | 19.8 |  |
| Factory inefficiencies due to lower productivity | — |  |  | 0.8 |  |  | — |  |  | 9.3 |  |
| Other | 0.4 |  |  | 5.6 |  |  | 3.1 |  |  | 23.5 |  |
| Total losses and expenses | $ | 0.4 |  |  | $ | 2.9 |  |  | $ | 3.1 |  |  | $ | 52.6 |  |
| Components of Marshalltown tornado in Loss (gain) from natural disasters, net of insurance recoveries: |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits | — |  |  | (8.3) |  |  | — |  |  | (73.8) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 0.4 |  |  | 1.2 |  |  | 3.1 |  |  | (11.6) |  |
|  | $ | 0.4 |  |  | $ | (7.1) |  |  | $ | 3.1 |  |  | $ | (85.4) |  |
  (was, 2020-07-20, similarity 0.6813):
[0001069202-20-000039:note_history:13]
| (Amounts in millions) | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Insurance recoveries received | $ | — |  |  | $ | 52.0 |  |  | $ | — |  |  | $ | 128.0 |  |
| Losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | — |  |  | 6.2 |  |  | — |  |  | 23.3 |  |
| Factory inefficiencies due to lower productivity | — |  |  | 4.5 |  |  | — |  |  | 8.0 |  |
| Other | 1.0 |  |  | 9.4 |  |  | 2.7 |  |  | 18.4 |  |
| Total losses and expenses | $ | 1.0 |  |  | $ | 20.1 |  |  | $ | 2.7 |  |  | $ | 49.7 |  |
| Presentation in the Consolidated Statements of Operations: |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits | — |  |  | (26.0) |  |  | — |  |  | (65.5) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 1.0 |  |  | (5.9) |  |  | 2.7 |  |  | (12.8) |  |

- added (2020-10-19):
[0001069202-20-000048:note_history:14]
Marshalltown Wind Storm

- added (2020-10-19):
[0001069202-20-000048:note_history:15]
We have insurance for the repair and replacement of our assets that suffered damage or loss, and are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and losses we suffered.  Our insurance policies also provide business interruption coverage, including lost profits and reimbursement for other expenses and costs that have been incurred related to the damages and losses suffered. The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the wind storm (in millions):

- added (2020-10-19):
[0001069202-20-000048:note_history:16]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Inventory write-offs | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |
| Site clean-up and remediation | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |
| Building repairs | 2.8 |  |  | — |  |  | 2.8 |  |  | — |  |
| Factory inefficiencies due to lower productivity | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |
| Other | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |
| Total losses and expenses | $ | 4.5 |  |  | $ | — |  |  | $ | 4.5 |  |  | $ | — |  |
| Components of Marshalltown wind storm in Loss (gain) from natural disasters, net of insurance recoveries: |  |  |  |  |  |  |  |
| Loss (gain) from natural disaster | $ | 4.5 |  |  | $ | — |  |  | $ | 4.5 |  |  | $ | — |  |

- removed (2020-10-19):
[0001069202-20-000039:note_history:17]
4. Commitments and Contingencies:

- removed (2020-10-19):
[0001069202-20-000039:note_history:18]
Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

- removed (2020-10-19):
[0001069202-20-000039:note_history:19]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covered the repair or replacement of our assets that suffered damage or loss, and business interruption costs, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Insurance proceeds for lost profits and Loss (gain) from natural disaster, net of insurance recoveries in the Consolidated Statements of Operations.

- removed (2020-10-19):
[0001069202-20-000039:note_history:20]
In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-10-19):
[0001069202-20-000048:note_history:21]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2020, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2020 and 2019, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2020 and 2019 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2019.

- changed (2020-10-19):
[0001069202-20-000048:note_history:22]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls. For convenience, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.
  (was, 2020-07-20, similarity 0.845):
[0001069202-20-000039:note_history:22]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls.

- changed (2020-10-19):
[0001069202-20-000048:note_history:23]
The magnitude of the impact of COVID-19 remains unpredictable and we, therefore, continue to anticipate potential supply chain disruptions, employee absenteeism, short-term suspensions of manufacturing facilities and additional health and safety costs related to the COVID-19 pandemic that could unfavorably impact our business.  Although these disruptions and costs are expected to be temporary, there is significant uncertainty around the duration and overall impact to our business operations.  We believe it is possible that the impact of the COVID-19 pandemic could have a material adverse effect on the results of our operations, financial position and cash flows.
  (was, 2020-07-20, similarity 0.9686):
[0001069202-20-000039:note_history:23]
The magnitude of the impact of COVID-19 remains unpredictable and we, therefore, continue to anticipate potential supply chain disruptions, employee absenteeism, short-term suspensions of manufacturing facilities and additional health and safety costs related to the COVID-19 pandemic that could unfavorably impact our business.  Although these disruptions and costs are expected to be temporary, there is significant uncertainty around the duration and overall impact to our business operations.  We believe it is possible that the impact of the COVID-19 pandemic could have a material adverse effect on the results of our operations, financial position and cash flows as of and for the year ended December 31, 2020.

- removed (2020-10-19):
[0001069202-20-000039:note_history:24]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2020, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and six months ended June 30, 2020 and 2019, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2020 and 2019 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2019.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-19):
[0001069202-20-000048:note_history:25]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 1.65 | % |  | 2.93 | % |
  (was, 2020-07-20, similarity 0.9447):
[0001069202-20-000039:note_history:25]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 1.36 | % |  | 2.93 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-10-19):
[0001069202-20-000039:note_history:26]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

- removed (2020-10-19):
[0001069202-20-000039:note_history:27]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 306.0 |  |  | $ | 285.0 |  |
| Finance lease obligations | 8.5 |  |  | 7.8 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 343.6 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 26.3 |  |  | 25.9 |  |
| Domestic credit facility | 672.5 |  |  | 475.5 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (1.6) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,047.2 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,390.8 |  |  | $ | 1,171.2 |  |

- removed (2020-10-19):
[0001069202-20-000039:note_history:28]
Short-Term Debt

- removed (2020-10-19):
[0001069202-20-000039:note_history:29]
Foreign Obligations

- removed (2020-10-19):
[0001069202-20-000039:note_history:30]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2020 or December 31, 2019 and there were $1.9 million of borrowings and repayments on these facilities for the six months ended June 30, 2020.  There were no significant borrowings or repayments on these facilities for the six months ended June 30, 2019.

- removed (2020-10-19):
[0001069202-20-000039:note_history:31]
Asset Securitization Program

- removed (2020-10-19):
[0001069202-20-000039:note_history:32]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale. Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

- removed (2020-10-19):
[0001069202-20-000039:note_history:33]
We renewed the ASP in November 2019, extending its term to November 2021 and increasing the maximum securitization amount to a range from $250.0 million to $400.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- removed (2020-10-19):
[0001069202-20-000039:note_history:34]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 306.0 |  |  | $ | 320.0 |  |
| Less: Beneficial interest transferred | (306.0) |  |  | (285.0) |  |
| Remaining amount available | $ | — |  |  | $ | 35.0 |  |

- removed (2020-10-19):
[0001069202-20-000039:note_history:35]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average

- removed (2020-10-19):
[0001069202-20-000039:note_history:36]
LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2020 and December 31, 2019 were 1.02% and 2.51%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- removed (2020-10-19):
[0001069202-20-000039:note_history:37]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2020, we believe we were in compliance with all covenant requirements.

- removed (2020-10-19):
[0001069202-20-000039:note_history:38]
Long-Term Debt

- removed (2020-10-19):
[0001069202-20-000039:note_history:39]
Domestic Credit Facility

- removed (2020-10-19):
[0001069202-20-000039:note_history:40]
On January 22, 2019, we amended our Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $160.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). We will seek to extend the Maturity Date of the Domestic Credit Facility prior to its expiration.

- removed (2020-10-19):
[0001069202-20-000039:note_history:41]
Under our Domestic Credit Facility, we had outstanding borrowings of $702.5 million, of which $145.0 million was the term loan balance, as well as $2.4 million committed to standby letters of credit as of June 30, 2020. Subject to covenant limitations, $440.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

- removed (2020-10-19):
[0001069202-20-000039:note_history:42]
Our weighted average borrowing rate on the facility was as follows:

- removed (2020-10-19):
[0001069202-20-000039:note_history:43]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 1.36 | % |  | 2.93 | % |

- removed (2020-10-19):
[0001069202-20-000039:note_history:44]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

- removed (2020-10-19):
[0001069202-20-000039:note_history:45]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

- removed (2020-10-19):
[0001069202-20-000039:note_history:46]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

- removed (2020-10-19):
[0001069202-20-000039:note_history:47]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or

- removed (2020-10-19):
[0001069202-20-000039:note_history:48]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

- removed (2020-10-19):
[0001069202-20-000039:note_history:49]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

- removed (2020-10-19):
[0001069202-20-000039:note_history:50]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due

- removed (2020-10-19):
[0001069202-20-000039:note_history:51]
and payable and the lenders’ commitments will automatically terminate). As of June 30, 2020, we believe we were in compliance with all covenant requirements.

- removed (2020-10-19):
[0001069202-20-000039:note_history:52]
Senior Unsecured Notes
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2020, we believe we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-19):
[0001069202-20-000048:note_history:53]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 285.0 |  |
| Finance lease obligations | 9.6 |  |  | 7.8 |  |
| Domestic credit facility | — |  |  | 30.0 |  |
| Debt issuance costs | (2.6) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 7.0 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 28.8 |  |  | 25.9 |  |
| Domestic credit facility | 34.5 |  |  | 475.5 |  |
| Senior unsecured notes | 950.0 |  |  | 350.0 |  |
| Debt issuance costs | (6.7) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,006.6 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,013.6 |  |  | $ | 1,171.2 |  |
  (was, 2020-07-20, similarity 0.9864):
[0001069202-20-000039:note_history:53]
|  | As of June 30, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 306.0 |  |  | $ | 285.0 |  |
| Finance lease obligations | 8.5 |  |  | 7.8 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 343.6 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 26.3 |  |  | 25.9 |  |
| Domestic credit facility | 672.5 |  |  | 475.5 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (1.6) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,047.2 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,390.8 |  |  | $ | 1,171.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-19):
[0001069202-20-000048:note_history:54]
|  | For the Three Months Ended September 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 665.6 |  |  | $ | 184.6 |  |  | $ | 67.2 |  |  | $ | 917.4 |  |
| Canada | 56.4 |  |  | 22.7 |  |  | — |  |  | 79.1 |  |
| Other international | — |  |  | 0.6 |  |  | 57.9 |  |  | 58.5 |  |
| Total | $ | 722.0 |  |  | $ | 207.9 |  |  | $ | 125.1 |  |  | $ | 1,055.0 |  |
  (was, 2020-07-20, similarity 0.8991):
[0001069202-20-000039:note_history:54]
|  | For the Three Months Ended June 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 603.8 |  |  | $ | 173.1 |  |  | $ | 61.3 |  |  | $ | 838.2 |  |
| Canada | 41.0 |  |  | 15.0 |  |  | — |  |  | 56.0 |  |
| Other international | — |  |  | 0.2 |  |  | 46.9 |  |  | 47.1 |  |
| Total | $ | 644.8 |  |  | $ | 188.3 |  |  | $ | 108.2 |  |  | $ | 941.3 |  |

- changed (2020-10-19):
[0001069202-20-000048:note_history:55]
|  | For the Three Months Ended September 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 597.3 |  |  | $ | 227.0 |  |  | $ | 82.5 |  |  | $ | 906.8 |  |
| Canada | 40.3 |  |  | 26.0 |  |  | — |  |  | 66.3 |  |
| Other international | — |  |  | 0.3 |  |  | 59.5 |  |  | 59.8 |  |
| Total | $ | 637.6 |  |  | $ | 253.3 |  |  | $ | 142.0 |  |  | $ | 1,032.9 |  |
  (was, 2020-07-20, similarity 0.8991):
[0001069202-20-000039:note_history:55]
|  | For the Three Months Ended June 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 647.2 |  |  | $ | 239.1 |  |  | $ | 80.0 |  |  | $ | 966.3 |  |
| Canada | 41.9 |  |  | 21.9 |  |  | — |  |  | 63.8 |  |
| Other international | — |  |  | 0.3 |  |  | 68.7 |  |  | 69.0 |  |
| Total | $ | 689.1 |  |  | $ | 261.3 |  |  | $ | 148.7 |  |  | $ | 1,099.1 |  |

- changed (2020-10-19):
[0001069202-20-000048:note_history:56]
|  | For the Nine Months Ended September 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,681.8 |  |  | $ | 518.9 |  |  | $ | 188.0 |  |  | $ | 2,388.7 |  |
| Canada | 127.0 |  |  | 54.8 |  |  | — |  |  | $ | 181.8 |  |
| Other international | — |  |  | 0.9 |  |  | 148.7 |  |  | $ | 149.6 |  |
| Total | $ | 1,808.8 |  |  | $ | 574.6 |  |  | $ | 336.7 |  |  | $ | 2,720.1 |  |
  (was, 2020-07-20, similarity 0.9755):
[0001069202-20-000039:note_history:56]
|  | For the Six Months Ended June 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,016.2 |  |  | $ | 334.3 |  |  | $ | 120.8 |  |  | $ | 1,471.3 |  |
| Canada | 70.7 |  |  | 32.0 |  |  | — |  |  | $ | 102.7 |  |
| Other international | — |  |  | 0.4 |  |  | 90.7 |  |  | $ | 91.1 |  |
| Total | $ | 1,086.9 |  |  | $ | 366.7 |  |  | $ | 211.5 |  |  | $ | 1,665.1 |  |

- changed (2020-10-19):
[0001069202-20-000048:note_history:57]
|  | For the Nine Months Ended September 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,677.6 |  |  | $ | 623.3 |  |  | $ | 254.1 |  |  | $ | 2,555.0 |  |
| Canada | 114.6 |  |  | 63.8 |  |  | 0.7 |  |  | $ | 179.1 |  |
| International | — |  |  | 0.8 |  |  | 187.3 |  |  | $ | 188.1 |  |
| Total | $ | 1,792.2 |  |  | $ | 687.9 |  |  | $ | 442.1 |  |  | $ | 2,922.2 |  |
  (was, 2020-07-20, similarity 0.691):
[0001069202-20-000039:note_history:57]
|  | For the Six Months Ended June 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,080.3 |  |  | $ | 396.4 |  |  | $ | 171.6 |  |  | $ | 1,648.3 |  |
| Canada | 74.3 |  |  | 37.8 |  |  | 0.7 |  |  | 112.8 |  |
| International | — |  |  | 0.5 |  |  | 127.8 |  |  | 128.3 |  |
| Total | $ | 1,154.6 |  |  | $ | 434.7 |  |  | $ | 300.1 |  |  | $ | 1,889.4 |  |

- changed (2020-10-19):
[0001069202-20-000048:note_history:58]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2020 and 2019, direct sales represented 74% and 74% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2020 and 2019, direct sales represented 75% and 74% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2020-07-20, similarity 0.9702):
[0001069202-20-000039:note_history:58]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2020 and 2019, direct sales represented 76% and 75% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2020 and 2019, direct sales represented 75% and 74% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- added (2020-10-19):
[0001069202-20-000048:note_history:59]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These

- changed (2020-10-19):
[0001069202-20-000048:note_history:60]
products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2020 and 2019, equipment sales represented 83% and 86% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2020 and 2019, equipment sales represented 84% and 86% of revenues, and the remainder of our revenue was generated from our service business.
  (was, 2020-07-20, similarity 0.6366):
[0001069202-20-000039:note_history:60]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the

- added (2020-10-19):
[0001069202-20-000048:note_history:61]
|  | September 30, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (7.0) |  |  | $ | (8.4) |  |  | $ | 1.4 |  |  | (16.7) | % |
| Contract liabilities - noncurrent | (5.6) |  |  | (5.9) |  |  | 0.3 |  |  | (5.1) | % |
| Total | $ | (12.6) |  |  | $ | (14.3) |  |  | $ | 1.7 |  |  |  |

- changed (2020-10-19):
[0001069202-20-000048:note_history:62]
For the three months ended September 30, 2020 and 2019, we recognized revenue of $1.4 million and $0.2 million and for the nine months ended September 30, 2020 and 2019 we recognized revenue of $5.9 million and $2.8 million related to our contract liabilities at January 1, 2020 and 2019, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020 and 2019.
  (was, 2020-07-20, similarity 0.9149):
[0001069202-20-000039:note_history:62]
For the three months ended June 30, 2020 and 2019, we recognized revenue of $2.9 million and $1.5 million and for the six months ended June 30, 2020 and 2019 we recognized revenue of $4.5 million and $2.6 million related to our contract liabilities at January 1, 2020 and 2019, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020 and 2019.

- removed (2020-10-19):
[0001069202-20-000039:note_history:63]
relative fair value of the services provided. For the three months ended June 30, 2020 and 2019, equipment sales represented 86% and 87% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2020 and 2019, equipment sales represented 85% and 85% of revenues, and the remainder of our revenue was generated from our service business.

- removed (2020-10-19):
[0001069202-20-000039:note_history:64]
|  | June 30, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (6.8) |  |  | $ | (8.4) |  |  | $ | 1.6 |  |  | (19.0) | % |
| Contract liabilities - noncurrent | (5.6) |  |  | (5.9) |  |  | 0.3 |  |  | (5.1) | % |
| Total | $ | (12.4) |  |  | $ | (14.3) |  |  | $ | 1.9 |  |  |  |
