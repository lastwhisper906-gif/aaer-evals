# LII notes — 0001069202-20-000048


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-20-000048:notes:1]
[same as prior period, unchanged from 0001069202-20-000039:notes:1]

[0001069202-20-000048:notes:2]
[same as prior period, unchanged from 0001069202-20-000039:notes:2]

[0001069202-20-000048:notes:3]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2020, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2020 and 2019, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2020 and 2019, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2020 and 2019 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2019.

[0001069202-20-000048:notes:4]
[same as prior period, unchanged from 0001069202-20-000039:notes:4]

[0001069202-20-000048:notes:5]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls. For convenience, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.

[0001069202-20-000048:notes:6]
[same as prior period, unchanged from 0001069202-20-000039:notes:6]

[0001069202-20-000048:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-20-000048:notes:8]
[same as prior period, unchanged from 0001069202-20-000039:notes:8]

[0001069202-20-000048:notes:9]
[same as prior period, unchanged from 0001069202-20-000039:notes:9]

[0001069202-20-000048:notes:10]
[same as prior period, unchanged from 0001069202-20-000039:notes:10]

[0001069202-20-000048:notes:11]
[same as prior period, unchanged from 0001069202-20-000039:notes:11]

[0001069202-20-000048:notes:12]
[same as prior period, unchanged from 0001069202-20-000039:notes:12]

[0001069202-20-000048:notes:13]
The magnitude of the impact of COVID-19 remains unpredictable and we, therefore, continue to anticipate potential supply chain disruptions, employee absenteeism, short-term suspensions of manufacturing facilities and additional health and safety costs related to the COVID-19 pandemic that could unfavorably impact our business.  Although these disruptions and costs are expected to be temporary, there is significant uncertainty around the duration and overall impact to our business operations.  We believe it is possible that the impact of the COVID-19 pandemic could have a material adverse effect on the results of our operations, financial position and cash flows.

[0001069202-20-000048:notes:14]
Recently Adopted Accounting Guidance

[0001069202-20-000048:notes:15]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to estimate credit losses. ASU 2016-13 is effective for SEC filers for interim and annual periods beginning after December 15, 2019.  We adopted ASU 2016-13 using the modified retrospective method for all financial assets measured at amortized cost.  Results for periods after January 1, 2020 are presented under ASU 2016-13 while prior period amounts continue to be reported under previously applicable accounting standards.  We recorded a $1.3 million net decrease to retained earnings as of January 1, 2020 for the cumulative effect of adopting ASU 2016-13.

[0001069202-20-000048:notes:16]
In January 2017, the FASB issued ASU No. 2017-04, Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates step two of the goodwill impairment test and specifies that goodwill impairment should be measured by comparing the fair value of a reporting unit with its carrying amount. Additionally, the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount of net assets should be disclosed. ASU 2017-04 is effective for annual or interim goodwill impairment tests performed in fiscal years beginning after December 15, 2019.  The adoption of ASU 2017-04 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.
In August 2018, the FASB issued ASU No. 2018-15, Intangibles – Internal-Use Software (Topic 350-40): Customer’s Accounting for Implementation Costs incurred in a Cloud Computing Arrangement That is a Service Contract.  ASU 2018-15 provides guidance to determine how implementation costs associated with cloud computing arrangements that are incurred to develop or obtain internal-use software should be capitalized or expensed as incurred. ASU 2018-15 is effective for fiscal years beginning after December 15, 2019.  The adoption of ASU 2018-15 did not have a material impact on our consolidated results of operations, cash flows, or statement of financial position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-20-000048:notes:17]
[same as prior period, unchanged from 0001069202-20-000039:notes:17]

[0001069202-20-000048:notes:18]
[same as prior period, unchanged from 0001069202-20-000039:notes:18]

[0001069202-20-000048:notes:19]
[same as prior period, unchanged from 0001069202-20-000039:notes:19]

[0001069202-20-000048:notes:20]
[same as prior period, unchanged from 0001069202-20-000039:notes:20]

[0001069202-20-000048:notes:21]
[same as prior period, unchanged from 0001069202-20-000039:notes:21]

[0001069202-20-000048:notes:22]
[same as prior period, unchanged from 0001069202-20-000039:notes:22]

[0001069202-20-000048:notes:23]
[same as prior period, unchanged from 0001069202-20-000039:notes:23]

[0001069202-20-000048:notes:24]
[same as prior period, unchanged from 0001069202-20-000039:notes:24]

[0001069202-20-000048:notes:25]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 722.0 |  |  | $ | 637.6 |  |  | $ | 1,808.8 |  |  | $ | 1,792.2 |  |
| Commercial Heating & Cooling | 207.9 |  |  | 253.3 |  |  | 574.6 |  |  | 687.9 |  |
| Refrigeration | 125.1 |  |  | 142.0 |  |  | 336.7 |  |  | 442.1 |  |
|  | $ | 1,055.0 |  |  | $ | 1,032.9 |  |  | $ | 2,720.1 |  |  | $ | 2,922.2 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 153.0 |  |  | $ | 126.5 |  |  | $ | 312.8 |  |  | $ | 366.6 |  |
| Commercial Heating & Cooling | 38.8 |  |  | 47.1 |  |  | 93.1 |  |  | 116.0 |  |
| Refrigeration | 13.0 |  |  | 19.8 |  |  | 22.6 |  |  | 47.3 |  |
| Corporate and other | (28.3) |  |  | (18.1) |  |  | (61.3) |  |  | (54.3) |  |
| Total segment profit | 176.5 |  |  | 175.3 |  |  | 367.2 |  |  | 475.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Special product quality adjustments | — |  |  | (0.5) |  |  | (1.0) |  |  | (1.0) |  |
| Loss on sale of business | — |  |  | 0.2 |  |  | — |  |  | 9.1 |  |
| Prior quarter partial advance of insurance recoveries related to lost profits | — |  |  | 8.0 |  |  | — |  |  | — |  |
| Loss (gain) from natural disasters, net of insurance recoveries | 4.9 |  |  | 1.2 |  |  | 7.6 |  |  | (11.6) |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 4.4 |  |  | 3.5 |  |  | 10.5 |  |  | 7.3 |  |
| Restructuring charges | 0.1 |  |  | 6.1 |  |  | 10.6 |  |  | 6.5 |  |
| Operating income | $ | 167.1 |  |  | $ | 156.8 |  |  | $ | 339.5 |  |  | $ | 465.3 |  |

[0001069202-20-000048:notes:26]
[same as prior period, unchanged from 0001069202-20-000039:notes:26]

[0001069202-20-000048:notes:27]
•The following items in Losses (gains) and other expenses, net:

[0001069202-20-000048:notes:28]
◦Net change in unrealized (gains) losses on unsettled futures contracts,

[0001069202-20-000048:notes:29]
◦Special legal contingency charges,

[0001069202-20-000048:notes:30]
◦Asbestos-related litigation,

[0001069202-20-000048:notes:31]
[same as prior period, unchanged from 0001069202-20-000039:notes:31]

[0001069202-20-000048:notes:32]
[same as prior period, unchanged from 0001069202-20-000039:notes:32]

[0001069202-20-000048:notes:33]
[same as prior period, unchanged from 0001069202-20-000039:notes:33]

[0001069202-20-000048:notes:34]
[same as prior period, unchanged from 0001069202-20-000039:notes:34]

[0001069202-20-000048:notes:35]
[same as prior period, unchanged from 0001069202-20-000039:notes:35]

[0001069202-20-000048:notes:36]
•Prior quarter partial advance of insurance recoveries related to lost profits,

[0001069202-20-000048:notes:37]
•Loss (gain) from natural disasters, net of insurance recoveries; and,

[0001069202-20-000048:notes:38]
[same as prior period, unchanged from 0001069202-20-000039:notes:38]


## us-gaap:EarningsPerShareTextBlock

[0001069202-20-000048:notes:39]
[same as prior period, unchanged from 0001069202-20-000039:notes:39]

[0001069202-20-000048:notes:40]
[same as prior period, unchanged from 0001069202-20-000039:notes:40]

[0001069202-20-000048:notes:41]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net income | $ | 131.7 |  |  | $ | 114.7 |  |  | $ | 244.6 |  |  | $ | 294.7 |  |
| Exclude: Loss from discontinued operations | — |  |  | — |  |  | 0.3 |  |  | 0.3 |  |
| Income from continuing operations | $ | 131.7 |  |  | $ | 114.7 |  |  | $ | 244.9 |  |  | $ | 295.0 |  |
| Weighted-average shares outstanding – basic | 38.3 |  |  | 38.6 |  |  | 38.3 |  |  | 39.1 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.3 |  |  | 0.4 |  |  | 0.3 |  |  | 0.4 |  |
| Weighted-average shares outstanding – diluted | 38.6 |  |  | 39.0 |  |  | 38.6 |  |  | 39.5 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.44 |  |  | $ | 2.97 |  |  | $ | 6.39 |  |  | $ | 7.54 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01) |  |  | (0.01) |  |
| Net income | $ | 3.44 |  |  | $ | 2.97 |  |  | $ | 6.38 |  |  | $ | 7.53 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.42 |  |  | $ | 2.94 |  |  | $ | 6.35 |  |  | $ | 7.46 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.01) |  |  | — |  |
| Net income | $ | 3.42 |  |  | $ | 2.94 |  |  | $ | 6.34 |  |  | $ | 7.46 |  |

[0001069202-20-000048:notes:42]
[same as prior period, unchanged from 0001069202-20-000039:notes:42]

[0001069202-20-000048:notes:43]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Weighted-average number of shares | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| Price per share | $257.08 |  | $ | — |  |  | $257.08 |  | $ | — |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-20-000048:notes:44]
Leases

[0001069202-20-000048:notes:45]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001069202-20-000048:notes:46]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-20-000048:notes:47]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-20-000048:notes:48]
We lease certain real and personal property under non-cancelable operating leases. Approximately 72% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001069202-20-000048:notes:49]
Product Warranties and Product Related Contingencies

[0001069202-20-000048:notes:50]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-20-000048:notes:51]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000048:notes:52]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Accrued expenses | $ | 37.0 |  |  | $ | 38.2 |  |
| Other liabilities | 80.4 |  |  | 74.6 |  |
| Total warranty liability | $ | 117.4 |  |  | $ | 112.8 |  |

[0001069202-20-000048:notes:53]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2020 were as follows (in millions):

[0001069202-20-000048:notes:54]
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |
| Warranty claims paid | (26.9) |  |
| Changes resulting from issuance of new warranties | 31.2 |  |
| Changes in estimates associated with pre-existing liabilities | 0.3 |  |
| Changes in foreign currency translation rates and other | — |  |
| Total warranty liability as of September 30, 2020 | $ | 117.4 |  |

[0001069202-20-000048:notes:55]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

[0001069202-20-000048:notes:56]
Litigation

[0001069202-20-000048:notes:57]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-20-000048:notes:58]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):

[0001069202-20-000048:notes:59]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Expense (gain) for asbestos-related litigation, net | $ | 2.4 |  |  | $ | 1.5 |  |  | $ | 1.9 |  |  | $ | 3.3 |  |

[0001069202-20-000048:notes:60]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.

[0001069202-20-000048:notes:61]
Natural Disasters and Recovery

[0001069202-20-000048:notes:62]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  On August 10, 2020, the Marshalltown facility was partially damaged by a derecho wind storm. The costs and losses incurred as well as any insurance recoveries for both of these natural disasters are shown in Loss (gain) from natural disasters, net of insurance recoveries in the Consolidated Statements of Operations.

[0001069202-20-000048:notes:63]
The following table summarizes the components of Loss (gain) from natural disasters, net of insurance recoveries (in millions):

[0001069202-20-000048:notes:64]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Marshalltown tornado | $ | 0.4 |  |  | $ | (7.1) |  |  | $ | 3.1 |  |  | $ | (85.4) |  |
| Marshalltown wind storm | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |
| Loss (gain) from natural disasters, net of insurance recoveries | $ | 4.9 |  |  | $ | (7.1) |  |  | $ | 7.6 |  |  | $ | (85.4) |  |

[0001069202-20-000048:notes:65]
Marshalltown Tornado

[0001069202-20-000048:notes:66]
Insurance covered the repair or replacement of our assets that suffered damage or loss, and business interruption costs, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.  In December 2019, we reached a final settlement with our insurance carriers for a total cumulative insurance recovery of $367.5 million for the losses we incurred and will incur from the tornado.  All recoveries related to the final settlement were received in 2018 and 2019. The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the tornado (in millions):

[0001069202-20-000048:notes:67]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Insurance recoveries received | $ | — |  |  | $ | 10.0 |  |  | $ | — |  |  | $ | 138.0 |  |
| Losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | — |  |  | (3.5) |  |  | — |  |  | 19.8 |  |
| Factory inefficiencies due to lower productivity | — |  |  | 0.8 |  |  | — |  |  | 9.3 |  |
| Other | 0.4 |  |  | 5.6 |  |  | 3.1 |  |  | 23.5 |  |
| Total losses and expenses | $ | 0.4 |  |  | $ | 2.9 |  |  | $ | 3.1 |  |  | $ | 52.6 |  |
| Components of Marshalltown tornado in Loss (gain) from natural disasters, net of insurance recoveries: |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits | — |  |  | (8.3) |  |  | — |  |  | (73.8) |  |
| Loss (gain) from natural disaster, net of insurance recoveries | 0.4 |  |  | 1.2 |  |  | 3.1 |  |  | (11.6) |  |
|  | $ | 0.4 |  |  | $ | (7.1) |  |  | $ | 3.1 |  |  | $ | (85.4) |  |

[0001069202-20-000048:notes:68]
Marshalltown Wind Storm

[0001069202-20-000048:notes:69]
We have insurance for the repair and replacement of our assets that suffered damage or loss, and are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and losses we suffered.  Our insurance policies also provide business interruption coverage, including lost profits and reimbursement for other expenses and costs that have been incurred related to the damages and losses suffered. The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the wind storm (in millions):

[0001069202-20-000048:notes:70]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Inventory write-offs | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |
| Site clean-up and remediation | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |
| Building repairs | 2.8 |  |  | — |  |  | 2.8 |  |  | — |  |
| Factory inefficiencies due to lower productivity | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |
| Other | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |
| Total losses and expenses | $ | 4.5 |  |  | $ | — |  |  | $ | 4.5 |  |  | $ | — |  |
| Components of Marshalltown wind storm in Loss (gain) from natural disasters, net of insurance recoveries: |  |  |  |  |  |  |  |
| Loss (gain) from natural disaster | $ | 4.5 |  |  | $ | — |  |  | $ | 4.5 |  |  | $ | — |  |


## us-gaap:ScheduleOfUnusualOrInfrequentItemsTextBlock

[0001069202-20-000048:notes:71]
The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the tornado (in millions):

[0001069202-20-000048:notes:72]
The following table summarizes the Loss (gain) from natural disasters, net of insurance recoveries relating to the wind storm (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-20-000048:notes:73]
Our Board of Directors have authorized a total of $3 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in December 2019. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of September 30, 2020, $446 million of shares may be repurchased under the Share Repurchase Plans.

[0001069202-20-000048:notes:74]
On February 13, 2020, we entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the "ASR Agreement") with Bank of America, to effect an accelerated stock buyback of the Company's common stock.  Under the ASR Agreement, we paid Bank of America $100.0 million and Bank of America delivered to us common stock representing approximately 85% of the shares expected to be purchased under the ASR Agreement.  The ASR was completed in March 2020 and Bank of America delivered a total of 0.4 million shares of common stock repurchased under this ASR Agreement.
We also repurchased shares for $10.1 million during the nine months ended September 30, 2020 from employees who tendered their shares to satisfy minimum tax withholding obligations upon the vesting and exercise of stock-based compensation awards.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-20-000048:notes:75]
During the first quarter of 2019, we obtained Board of Directors' approval and signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. The sale was completed on March 29, 2019 and the following table summarizes the net loss recognized in connection with this divestiture.  There were no gains or losses on the sale of this business for the nine months ended September 30, 2020.

[0001069202-20-000048:notes:76]
[same as prior period, unchanged from 0001069202-20-000039:notes:72]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-20-000048:notes:77]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.

[0001069202-20-000048:notes:78]
|  | For the Three Months Ended September 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 665.6 |  |  | $ | 184.6 |  |  | $ | 67.2 |  |  | $ | 917.4 |  |
| Canada | 56.4 |  |  | 22.7 |  |  | — |  |  | 79.1 |  |
| Other international | — |  |  | 0.6 |  |  | 57.9 |  |  | 58.5 |  |
| Total | $ | 722.0 |  |  | $ | 207.9 |  |  | $ | 125.1 |  |  | $ | 1,055.0 |  |

[0001069202-20-000048:notes:79]
|  | For the Three Months Ended September 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 597.3 |  |  | $ | 227.0 |  |  | $ | 82.5 |  |  | $ | 906.8 |  |
| Canada | 40.3 |  |  | 26.0 |  |  | — |  |  | 66.3 |  |
| Other international | — |  |  | 0.3 |  |  | 59.5 |  |  | 59.8 |  |
| Total | $ | 637.6 |  |  | $ | 253.3 |  |  | $ | 142.0 |  |  | $ | 1,032.9 |  |

[0001069202-20-000048:notes:80]
|  | For the Nine Months Ended September 30, 2020 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,681.8 |  |  | $ | 518.9 |  |  | $ | 188.0 |  |  | $ | 2,388.7 |  |
| Canada | 127.0 |  |  | 54.8 |  |  | — |  |  | $ | 181.8 |  |
| Other international | — |  |  | 0.9 |  |  | 148.7 |  |  | $ | 149.6 |  |
| Total | $ | 1,808.8 |  |  | $ | 574.6 |  |  | $ | 336.7 |  |  | $ | 2,720.1 |  |

[0001069202-20-000048:notes:81]
|  | For the Nine Months Ended September 30, 2019 |  |  |  |  |  |  |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,677.6 |  |  | $ | 623.3 |  |  | $ | 254.1 |  |  | $ | 2,555.0 |  |
| Canada | 114.6 |  |  | 63.8 |  |  | 0.7 |  |  | $ | 179.1 |  |
| International | — |  |  | 0.8 |  |  | 187.3 |  |  | $ | 188.1 |  |
| Total | $ | 1,792.2 |  |  | $ | 687.9 |  |  | $ | 442.1 |  |  | $ | 2,922.2 |  |

[0001069202-20-000048:notes:82]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2020 and 2019, direct sales represented 74% and 74% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2020 and 2019, direct sales represented 75% and 74% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-20-000048:notes:83]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These

[0001069202-20-000048:notes:84]
products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2020 and 2019, equipment sales represented 83% and 86% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2020 and 2019, equipment sales represented 84% and 86% of revenues, and the remainder of our revenue was generated from our service business.

[0001069202-20-000048:notes:85]
[same as prior period, unchanged from 0001069202-20-000039:notes:87]

[0001069202-20-000048:notes:86]
[same as prior period, unchanged from 0001069202-20-000039:notes:88]

[0001069202-20-000048:notes:87]
[same as prior period, unchanged from 0001069202-20-000039:notes:89]

[0001069202-20-000048:notes:88]
[same as prior period, unchanged from 0001069202-20-000039:notes:90]

[0001069202-20-000048:notes:89]
[same as prior period, unchanged from 0001069202-20-000039:notes:91]

[0001069202-20-000048:notes:90]
[same as prior period, unchanged from 0001069202-20-000039:notes:92]

[0001069202-20-000048:notes:91]
|  | September 30, 2020 |  | December 31, 2019 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (7.0) |  |  | $ | (8.4) |  |  | $ | 1.4 |  |  | (16.7) | % |
| Contract liabilities - noncurrent | (5.6) |  |  | (5.9) |  |  | 0.3 |  |  | (5.1) | % |
| Total | $ | (12.6) |  |  | $ | (14.3) |  |  | $ | 1.7 |  |  |  |

[0001069202-20-000048:notes:92]
For the three months ended September 30, 2020 and 2019, we recognized revenue of $1.4 million and $0.2 million and for the nine months ended September 30, 2020 and 2019 we recognized revenue of $5.9 million and $2.8 million related to our contract liabilities at January 1, 2020 and 2019, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2020 and 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-20-000048:notes:93]
[same as prior period, unchanged from 0001069202-20-000039:notes:95]

[0001069202-20-000048:notes:94]
[same as prior period, unchanged from 0001069202-20-000039:notes:96]

[0001069202-20-000048:notes:95]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Finished goods | $ | 258.4 |  |  | $ | 402.9 |  |
| Work in process | 5.7 |  |  | 6.0 |  |
| Raw materials and parts | 204.8 |  |  | 198.8 |  |
| Subtotal | 468.9 |  |  | 607.7 |  |
| Excess of current cost over last-in, first-out cost | (60.2) |  |  | (63.6) |  |
| Total inventories, net | $ | 408.7 |  |  | $ | 544.1 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-20-000048:notes:96]
[same as prior period, unchanged from 0001069202-20-000039:notes:98]

[0001069202-20-000048:notes:97]
[same as prior period, unchanged from 0001069202-20-000039:notes:99]

[0001069202-20-000048:notes:98]
|  | Balance at December 31, 2019 |  |  |  | Changes in foreign currency translation rates |  | Balance at September 30, 2020 |
| Residential Heating & Cooling | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.3 |  |  |  |  | 0.2 |  |  | 99.5 |  |
| Total Goodwill | $ | 186.5 |  |  |  |  | $ | 0.2 |  |  | $ | 186.7 |  |

[0001069202-20-000048:notes:99]
We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-20-000048:notes:100]
[same as prior period, unchanged from 0001069202-20-000039:notes:102]

[0001069202-20-000048:notes:101]
[same as prior period, unchanged from 0001069202-20-000039:notes:103]

[0001069202-20-000048:notes:102]
[same as prior period, unchanged from 0001069202-20-000039:notes:104]

[0001069202-20-000048:notes:103]
[same as prior period, unchanged from 0001069202-20-000039:notes:105]

[0001069202-20-000048:notes:104]
[same as prior period, unchanged from 0001069202-20-000039:notes:106]

[0001069202-20-000048:notes:105]
[same as prior period, unchanged from 0001069202-20-000039:notes:107]

[0001069202-20-000048:notes:106]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through January 2021 and February 2022, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings

[0001069202-20-000048:notes:107]
within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-20-000048:notes:108]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Unrealized (gains) losses on unsettled contracts | $ | (2.0) |  |  | $ | 0.2 |  |
| Income tax expense (benefit) | 0.3 |  |  | (0.2) |  |
| (Gains) included in AOCL, net of tax (1) | $ | (1.7) |  |  | $ | — |  |

[0001069202-20-000048:notes:109]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $1.2 million of derivative gains into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-20-000048:notes:110]
[same as prior period, unchanged from 0001069202-20-000039:notes:111]

[0001069202-20-000048:notes:111]
[same as prior period, unchanged from 0001069202-20-000039:notes:112]

[0001069202-20-000048:notes:112]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Stock-based compensation expense (1) | $ | 8.0 |  |  | $ | 4.2 |  |  | $ | 18.4 |  |  | $ | 15.6 |  |

[0001069202-20-000048:notes:113]
[same as prior period, unchanged from 0001069202-20-000039:notes:114]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-20-000048:notes:114]
The components of net periodic benefit cost for pension benefits were as follows (in millions):

[0001069202-20-000048:notes:115]
|  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Service cost | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 4.2 |  |  | $ | 3.6 |  |
| Interest cost | 1.6 |  |  | 2.7 |  |  | 5.0 |  |  | 8.1 |  |
| Expected return on plan assets | (2.0) |  |  | (3.6) |  |  | (6.2) |  |  | (10.8) |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Recognized actuarial loss | 1.4 |  |  | 1.4 |  |  | 4.3 |  |  | 4.3 |  |
| Other | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Settlements and curtailments | 0.3 |  |  | — |  |  | 0.3 |  |  | 60.6 |  |
| Net periodic benefit cost | $ | 2.8 |  |  | $ | 1.8 |  |  | $ | 7.7 |  |  | $ | 65.9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-20-000048:notes:116]
, we had approximately $3.2 million in total gross unrecognized tax benefits. Of this amount $3.2 million, if recognized, would be recorded through the Consolidated Statements of Operations.We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2019 and are subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2012.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001069202-20-000048:notes:117]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000048:notes:118]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 285.0 |  |
| Finance lease obligations | 9.6 |  |  | 7.8 |  |
| Domestic credit facility | — |  |  | 30.0 |  |
| Debt issuance costs | (2.6) |  |  | (0.9) |  |
| Total current maturities of long-term debt | $ | 7.0 |  |  | $ | 321.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 28.8 |  |  | 25.9 |  |
| Domestic credit facility | 34.5 |  |  | 475.5 |  |
| Senior unsecured notes | 950.0 |  |  | 350.0 |  |
| Debt issuance costs | (6.7) |  |  | (2.1) |  |
| Total long-term debt | $ | 1,006.6 |  |  | $ | 849.3 |  |
| Total debt | $ | 1,013.6 |  |  | $ | 1,171.2 |  |


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-20-000048:notes:119]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 328.9 |  |  | $ | 320.0 |  |
| Less: Beneficial interest transferred | — |  |  | (285.0) |  |
| Remaining amount available | $ | 328.9 |  |  | $ | 35.0 |  |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-20-000048:notes:120]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-20-000048:notes:121]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Weighted average borrowing rate | 1.65 | % |  | 2.93 | % |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-20-000048:notes:122]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-20-000048:notes:123]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-20-000048:notes:124]
The following table provides information on items not reclassified in their entirety from AOCL to Net income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-20-000048:notes:125]
|  |  | For the Three Months Ended September 30, |  |  |  | For the Nine Months Ended September 30, |  |  |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |
| (Losses) Gains on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | (0.4) |  |  | $ | (2.5) |  |  | $ | (5.5) |  |  | $ | (6.9) |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax benefit |  | 0.1 |  |  | 0.5 |  |  | 1.4 |  |  | 1.6 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.3) |  |  | $ | (2.0) |  |  | $ | (4.1) |  |  | $ | (5.3) |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.4) |  |  | $ | (1.5) |  |  | $ | (4.4) |  |  | $ | (4.4) |  |  | Cost of goods sold; Selling, general and administrative expenses |
| Pension settlements |  | (0.3) |  |  | — |  |  | (0.3) |  |  | (60.6) |  |  | Pension settlements |
| Income tax benefit |  | 0.4 |  |  | 0.4 |  |  | 1.1 |  |  | 16.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.3) |  |  | $ | (1.1) |  |  | $ | (3.6) |  |  | $ | (48.8) |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency adjustments on sale of business |  | — |  |  | — |  |  | — |  |  | (2.1) |  |  | Loss on sale of business |
| Net of tax |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (2.1) |  |  |  |
| Total reclassifications from AOCL |  | $ | (1.6) |  |  | $ | (3.1) |  |  | $ | (7.7) |  |  | $ | (56.2) |  |  |  |

[0001069202-20-000048:notes:126]
The following table provides information on changes in AOCL, by component (net of tax), for the nine months ended September 30, 2020 (in millions):

[0001069202-20-000048:notes:127]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2019 |  | $ | — |  |  | $ | — |  |  | $ | (81.5) |  |  | $ | (22.3) |  |  | $ | (103.8) |  |
| Other comprehensive loss before reclassifications |  | (2.4) |  |  | (1.2) |  |  | (3.4) |  |  | (11.8) |  |  | (18.8) |  |
| Amounts reclassified from AOCL |  | 4.1 |  |  | — |  |  | 3.6 |  |  | — |  |  | 7.7 |  |
| Net other comprehensive (loss) income |  | 1.7 |  |  | (1.2) |  |  | 0.2 |  |  | (11.8) |  |  | (11.1) |  |
| Balance as of September 30, 2020 |  | $ | 1.7 |  |  | $ | (1.2) |  |  | $ | (81.3) |  |  | $ | (34.1) |  |  | $ | (114.9) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-20-000048:notes:128]
[same as prior period, unchanged from 0001069202-20-000039:notes:149]

[0001069202-20-000048:notes:129]
The methodologies used to determine the fair value of our financial assets and liabilities at September 30, 2020 were the same as those used at December 31, 2019.

[0001069202-20-000048:notes:130]
[same as prior period, unchanged from 0001069202-20-000039:notes:151]

[0001069202-20-000048:notes:131]
[same as prior period, unchanged from 0001069202-20-000039:notes:152]

[0001069202-20-000048:notes:132]
[same as prior period, unchanged from 0001069202-20-000039:notes:153]

[0001069202-20-000048:notes:133]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-20-000048:notes:134]
[same as prior period, unchanged from 0001069202-20-000039:notes:155]

[0001069202-20-000048:notes:135]
|  | As of September 30, 2020 |  | As of December 31, 2019 |
| Senior unsecured notes | $ | 945.0 |  |  | $ | 356.8 |  |
