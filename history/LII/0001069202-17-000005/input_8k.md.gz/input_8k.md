# LII 8-K — 0001193125-17-133519 filed 2017-04-24

## item codes, every 8-K on or before 2017-04-24

- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2017-04-24

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-133519:8k_2_02:1]
EX-99.1
2
d384706dex991.htm
EX-99.1

[0001193125-17-133519:8k_2_02:2]
EX-99.1

[0001193125-17-133519:8k_2_02:3]
Exhibit 99.1

[0001193125-17-133519:8k_2_02:4]
Lennox International Reports Record First-Quarter Revenue and Profit

[0001193125-17-133519:8k_2_02:5]
| • |  | Revenue up 11% to first-quarter record $793 million |

[0001193125-17-133519:8k_2_02:6]
| • |  | GAAP EPS from continuing operations up 79% to first-quarter record $1.00 |

[0001193125-17-133519:8k_2_02:7]
| • |  | Adjusted EPS from continuing operations up 50% to first-quarter record $0.90 |

[0001193125-17-133519:8k_2_02:8]
| • |  | Reiterating 2017 revenue growth guidance of 3-7% |

[0001193125-17-133519:8k_2_02:9]
| • |  | Raising 2017 GAAP EPS from continuing operations guidance from $7.55-$8.15 to $7.65-$8.25 |

[0001193125-17-133519:8k_2_02:10]
| • |  | Reiterating 2017 adjusted EPS from continuing operations guidance of $7.55-$8.15 |

[0001193125-17-133519:8k_2_02:11]
| • |  | Repurchased $75 million of stock in first quarter, and reiterating plans for $250 million of stock repurchases in total for the year |

[0001193125-17-133519:8k_2_02:12]
DALLAS, April 24, 2017 – Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2017. All comparisons are
to the prior-year period.

[0001193125-17-133519:8k_2_02:13]
For the first quarter, revenue was a first-quarter record $793 million, up 11%. Foreign exchange was neutral to revenue. GAAP
operating income was up 39% to a first-quarter record $61 million. GAAP earnings per share from continuing operations was up 79% to a first-quarter record of $1.00, including a $0.17 benefit from recent GAAP accounting requirements regarding excess
tax benefits from share-based compensation against $0.07 in charges for special items. On an adjusted basis, total segment profit increased 39% to a first-quarter record $65 million, and margin expanded 170 basis points to a first-quarter record
8.2%. Adjusted EPS from continuing operations rose 50% to a first-quarter record $0.90.

[0001193125-17-133519:8k_2_02:14]
“Lennox International posted strong revenue growth and
margin expansion in a record first quarter, despite some headwind from weather,” said Chairman and CEO Todd Bluedorn. “The company hit new first-quarter highs for revenue, total segment profit and margin, as well as earnings per share.
Growth in the quarter included the benefit of five more days, or 6% more days, this year than in the first quarter last year. This balances out on a full-year basis with the fourth quarter having 6% fewer days than a year ago.

[0001193125-17-133519:8k_2_02:15]
“In our Residential business, revenue was up 11% to a new first-quarter high. Segment margin was relatively flat in our seasonally smallest quarter on
investments in distribution expansion, information technology, research and development, and other SG&A investments. With warmer weather than last year, Residential mix was not as favorable as expected due to faster growth in new construction
than replacement business. We continue to expect strong margin expansion for 2017 overall as we head into our seasonally largest quarters.

[0001193125-17-133519:8k_2_02:16]
“In Commercial, revenue, margin and profit all set new first-quarter records. Commercial revenue was up 15%,
led by more than 20% growth in North America equipment. Commercial profit rose 35% as segment margin expanded 150 basis points to 9.8%. In Refrigeration, revenue was up 6%, and profit rose 57% as segment margin expanded 250 basis points to 7.9%.

[0001193125-17-133519:8k_2_02:17]
“Looking ahead for the company overall, we are reiterating guidance for revenue and adjusted EPS from continuing operations for 2017. While early,
the company is off to a strong start, and we continue to expect another record year as we enter our largest seasonal period. We remain focused on capitalizing on end market growth, capturing additional market share with our strategic initiatives,
and driving higher profitability.”

[0001193125-17-133519:8k_2_02:18]
FINANCIAL HIGHLIGHTS

[0001193125-17-133519:8k_2_02:19]
Revenue: Revenue for the first quarter was $793 million, up 11% from the prior-year quarter. Foreign exchange was neutral to revenue. Volume and
price/mix were up on a revenue basis from the prior-year quarter.

[0001193125-17-133519:8k_2_02:20]
Gross Profit: Gross profit in the first quarter was $211 million, up 15%. Gross
margin was 26.6%, up 90 basis points. Gross profit was positively impacted by higher volume and lower material costs, with a partial offset from investments in distribution expansion.

[0001193125-17-133519:8k_2_02:21]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for the first quarter was $43.5 million, or $1.00 per share,
compared to $24.9 million, or $0.56 per share, in the prior-year quarter.

[0001193125-17-133519:8k_2_02:22]
Adjusted income from continuing operations in the first quarter was $38.9
million, or $0.90 per share, compared to $27.0 million, or $0.60 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the first quarter of 2017 excludes a benefit of $4.6 million, net of special after-tax charges: a
$7.4 million benefit for excess tax benefits from share-based compensation, a charge of $1.1 million for asbestos-related litigation, $0.9 million for special legal contingency charges, and $0.8 million in charges for other items.

[0001193125-17-133519:8k_2_02:23]
Free Cash Flow and Total Debt: Net cash from operations in the first quarter was ($108) million compared to ($102) million in the prior-year quarter.
Capital expenditures were $25 million in the first quarter compared to $24 million in the first quarter a year ago. Free cash flow was approximately ($133) million compared to ($126) million in the prior-year quarter. Total debt at the end of the
first quarter was $1,103 million. Total cash and cash equivalents were $49 million at the end of the quarter. The company paid $19 million in dividends and $75 million for stock repurchases in the first quarter.

[0001193125-17-133519:8k_2_02:24]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-17-133519:8k_2_02:25]
Residential Heating & Cooling

[0001193125-17-133519:8k_2_02:26]
Revenue in the
Residential Heating & Cooling business segment was a first-quarter record $420 million, up 11%. Foreign exchange was neutral on a revenue basis. Segment profit was a first-quarter record $43 million, up 11%. Segment profit margin was 10.1%
compared to 10.2% in the prior-year quarter. Results were impacted by higher volume, lower material costs, and favorable foreign exchange, with offsets from investments in distribution expansion, information technology, research and development, and
other SG&A investments.

[0001193125-17-133519:8k_2_02:27]
Commercial Heating & Cooling

[0001193125-17-133519:8k_2_02:28]
Revenue in the Commercial Heating & Cooling business segment was a first-quarter record $196 million, up 15%. Foreign exchange was neutral on a
revenue basis. Segment profit was a first-quarter record $19 million, up 35%. Segment profit margin was a first-quarter record 9.8%, up 150 basis points. Results were impacted by higher volume and lower material costs, with a partial offset from
SG&A investments.

[0001193125-17-133519:8k_2_02:29]
Refrigeration

[0001193125-17-133519:8k_2_02:30]
Revenue in the
Refrigeration business segment was $178 million, up 6%. At constant currency, revenue was up 5%. Segment profit was $14 million, up 57%. Segment profit margin was 7.9%, up 250 basis points. Results were impacted by higher volume, lower material
costs and favorable mix, with a partial offset from SG&A investments.

[0001193125-17-133519:8k_2_02:31]
FULL-YEAR OUTLOOK

[0001193125-17-133519:8k_2_02:32]
For 2017, the company is raising guidance for GAAP EPS from continuing operations and reiterating all other guidance points.

[0001193125-17-133519:8k_2_02:33]
| • |  | Reiterating 2017 guidance for revenue growth of 3-7%, with a minimal impact from foreign exchange. |

[0001193125-17-133519:8k_2_02:34]
| • |  | Raising 2017 guidance for GAAP EPS from continuing operations from $7.55-$8.15 to $7.65-$8.25, incorporating the $0.17 first-quarter benefit from recent GAAP accounting requirements regarding excess tax benefits from share-based compensation against $0.07 in charges for special items. |

[0001193125-17-133519:8k_2_02:35]
| • |  | Reiterating 2017 guidance for adjusted EPS from continuing operations of $7.55-$8.15. |

[0001193125-17-133519:8k_2_02:36]
| • |  | Reiterating 2017 corporate expenses of approximately $85 million. |

[0001193125-17-133519:8k_2_02:37]
| • |  | Reiterating an effective tax rate of approximately 32% on an adjusted basis for the full year. |

[0001193125-17-133519:8k_2_02:38]
| • |  | Reiterating 2017 capital expenditures of approximately $100 million. |

[0001193125-17-133519:8k_2_02:39]
| • |  | Reiterating guidance for a weighted average diluted share count of 42-43 million shares on a full-year basis, including plans for $250 million of stock repurchases for 2017 in total. |

[0001193125-17-133519:8k_2_02:40]
CONFERENCE CALL INFORMATION

[0001193125-17-133519:8k_2_02:41]
A conference call to discuss the company’s first quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call
line at 612-332-0107 at least 10 minutes prior to the scheduled start time and use reservation number 421542. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available
from 11:00 a.m. Central time on April 24 through May 8, 2017 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 421542. The call also will be archived on the company’s website.

[0001193125-17-133519:8k_2_02:42]
About Lennox International

[0001193125-17-133519:8k_2_02:43]
Lennox International Inc. is
a global leader in the heating, air conditioning, and refrigeration markets. Lennox International is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information is available at:
www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-17-133519:8k_2_02:44]
Forward-Looking Statements

[0001193125-17-133519:8k_2_02:45]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-133519:8k_2_02:46]
Consolidated Statements of Operations

[0001193125-17-133519:8k_2_02:47]
(Unaudited)

[0001193125-17-133519:8k_2_02:48]
| (Amounts in millions, except per share data) |  | For the Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Net sales |  | $ | 793.4 |  |  | $ | 715.2 |  |
| Cost of goods sold |  |  | 582.5 |  |  |  | 531.6 |  |
| Gross profit |  |  | 210.9 |  |  |  | 183.6 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 152.4 |  |  |  | 140.4 |  |
| Losses and other expenses, net |  |  | 3.1 |  |  |  | 4.3 |  |
| Restructuring charges (gains) |  |  | 0.1 |  |  |  | (0.2 | ) |
| Income from equity method investments |  |  | (5.5 | ) |  |  | (4.6 | ) |
| Operating income |  |  | 60.8 |  |  |  | 43.7 |  |
| Interest expense, net |  |  | 7.4 |  |  |  | 5.8 |  |
| Income from continuing operations before income taxes |  |  | 53.4 |  |  |  | 37.9 |  |
| Provision for income taxes |  |  | 9.9 |  |  |  | 13.0 |  |
| Income from continuing operations |  |  | 43.5 |  |  |  | 24.9 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | — |  |  |  | — |  |
| Benefit from income taxes |  |  | — |  |  |  | — |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 43.5 |  |  | $ | 24.9 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.02 |  |  | $ | 0.57 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 1.02 |  |  | $ | 0.57 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.00 |  |  | $ | 0.56 |  |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |
| Net income |  | $ | 1.00 |  |  | $ | 0.56 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 42.8 |  |  |  | 44.0 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 43.5 |  |  |  | 44.7 |  |
| Cash dividends declared per share |  | $ | 0.43 |  |  | $ | 0.36 |  |

[0001193125-17-133519:8k_2_02:49]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-133519:8k_2_02:50]
Segment Net Sales and Profit (Loss)

[0001193125-17-133519:8k_2_02:51]
(Unaudited)

[0001193125-17-133519:8k_2_02:52]
| (Amounts in millions) |  | For the Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 419.8 |  |  | $ | 377.3 |  |
| Commercial Heating & Cooling |  |  | 195.5 |  |  |  | 170.3 |  |
| Refrigeration |  |  | 178.1 |  |  |  | 167.6 |  |
|  |  | $ | 793.4 |  |  | $ | 715.2 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 42.5 |  |  | $ | 38.3 |  |
| Commercial Heating & Cooling |  |  | 19.1 |  |  |  | 14.2 |  |
| Refrigeration |  |  | 14.1 |  |  |  | 9.0 |  |
| Corporate and other |  |  | (11.0 | ) |  |  | (14.8 | ) |
| Total segment profit |  |  | 64.7 |  |  |  | 46.7 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | — |  |  |  | (0.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 3.8 |  |  |  | 3.6 |  |
| Restructuring charges (gains) |  |  | 0.1 |  |  |  | (0.2 | ) |
| Operating income |  | $ | 60.8 |  |  | $ | 43.7 |  |

[0001193125-17-133519:8k_2_02:53]
| (1) | The Company defines segment profit and loss as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-17-133519:8k_2_02:54]
|  | • |  | Special product quality adjustments; |

[0001193125-17-133519:8k_2_02:55]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-17-133519:8k_2_02:56]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-17-133519:8k_2_02:57]
|  | • |  | Special legal contingency charges, |

[0001193125-17-133519:8k_2_02:58]
|  | • |  | Asbestos-related litigation, |

[0001193125-17-133519:8k_2_02:59]
|  | • |  | Contractor tax payments, |

[0001193125-17-133519:8k_2_02:60]
|  | • |  | Environmental liabilities, |

[0001193125-17-133519:8k_2_02:61]
|  | • |  | Acquisition costs, |

[0001193125-17-133519:8k_2_02:62]
|  | • |  | Other items, net; and, |

[0001193125-17-133519:8k_2_02:63]
|  | • |  | Restructuring charges (gains). |

[0001193125-17-133519:8k_2_02:64]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-133519:8k_2_02:65]
Consolidated Balance Sheets

[0001193125-17-133519:8k_2_02:66]
| (Amounts in millions, except shares and par values) |  | As of March 31,2017 |  |  | As of December 31,2016 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 48.8 |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net of allowances of $6.0 and $6.7 in 2017 and 2016, respectively |  |  | 513.4 |  |  |  | 469.8 |  |
| Inventories, net |  |  | 522.8 |  |  |  | 418.5 |  |
| Other assets |  |  | 101.4 |  |  |  | 67.4 |  |
| Total current assets |  |  | 1,186.4 |  |  |  | 1,005.9 |  |
| Property, plant and equipment, net of accumulated depreciation of $734.1 and $717.2 in 2017 and 2016, respectively |  |  | 365.6 |  |  |  | 361.4 |  |
| Goodwill |  |  | 197.6 |  |  |  | 195.1 |  |
| Deferred income taxes |  |  | 134.0 |  |  |  | 136.7 |  |
| Other assets, net |  |  | 67.0 |  |  |  | 61.2 |  |
| Total assets |  | $ | 1,950.6 |  |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 201.6 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt |  |  | 207.6 |  |  |  | 200.1 |  |
| Accounts payable |  |  | 401.0 |  |  |  | 361.2 |  |
| Accrued expenses |  |  | 224.8 |  |  |  | 265.9 |  |
| Income taxes payable |  |  | 2.5 |  |  |  | 9.0 |  |
| Total current liabilities |  |  | 1,037.5 |  |  |  | 888.6 |  |
| Long-term debt |  |  | 693.9 |  |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions |  |  | 2.4 |  |  |  | 2.8 |  |
| Pensions |  |  | 88.3 |  |  |  | 87.5 |  |
| Other liabilities |  |  | 129.5 |  |  |  | 127.7 |  |
| Total liabilities |  |  | 1,951.6 |  |  |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,034.1 |  |  |  | 1,046.2 |  |
| Retained earnings |  |  | 1,378.1 |  |  |  | 1,353.0 |  |
| Accumulated other comprehensive loss |  |  | (176.5 | ) |  |  | (195.1 | ) |
| Treasury stock, at cost, 44,436,331 shares and 44,195,250 shares as of March 31, 2017 and December 31, 2016, respectively |  |  | (2,238.0 | ) |  |  | (2,167.4 | ) |
| Noncontrolling interests |  |  | 0.4 |  |  |  | 0.4 |  |
| Total stockholders’ equity |  |  | (1.0 | ) |  |  | 38.0 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,950.6 |  |  | $ | 1,760.3 |  |

[0001193125-17-133519:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-133519:8k_2_02:68]
Consolidated Statements of Cash Flows

[0001193125-17-133519:8k_2_02:69]
(Unaudited)

[0001193125-17-133519:8k_2_02:70]
| (Amounts in millions) |  | For the Three Months EndedMarch 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 43.5 |  |  | $ | 24.9 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (5.5 | ) |  |  | (4.6 | ) |
| Restructuring gains, net of cash paid |  |  | — |  |  |  | (0.5 | ) |
| Provision for bad debts |  |  | 1.1 |  |  |  | 1.3 |  |
| Unrealized gains on derivative contracts |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Stock-based compensation expense |  |  | 4.9 |  |  |  | 6.3 |  |
| Depreciation and amortization |  |  | 15.7 |  |  |  | 14.2 |  |
| Deferred income taxes |  |  | (1.1 | ) |  |  | (0.5 | ) |
| Other items, net |  |  | 0.1 |  |  |  | 0.1 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (40.9 | ) |  |  | (44.5 | ) |
| Inventories |  |  | (101.2 | ) |  |  | (95.5 | ) |
| Other current assets |  |  | (4.3 | ) |  |  | (6.2 | ) |
| Accounts payable |  |  | 47.3 |  |  |  | 67.9 |  |
| Accrued expenses |  |  | (41.7 | ) |  |  | (28.0 | ) |
| Income taxes payable and receivable |  |  | (28.0 | ) |  |  | (37.6 | ) |
| Other |  |  | 3.0 |  |  |  | 1.6 |  |
| Net cash used in operating activities |  |  | (107.6 | ) |  |  | (101.6 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | — |  |
| Purchases of property, plant and equipment |  |  | (24.9 | ) |  |  | (23.8 | ) |
| Net cash used in investing activities |  |  | (24.8 | ) |  |  | (23.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (0.8 | ) |  |  | (0.4 | ) |
| Asset securitization borrowings |  |  | 150.0 |  |  |  | — |  |
| Asset securitization payments |  |  | — |  |  |  | (20.0 | ) |
| Long-term debt payments |  |  | (0.2 | ) |  |  | (0.3 | ) |
| Borrowings from credit facility |  |  | 583.0 |  |  |  | 770.5 |  |
| Payments on credit facility |  |  | (497.5 | ) |  |  | (392.0 | ) |
| Proceeds from employee stock purchases |  |  | 0.7 |  |  |  | 0.6 |  |
| Repurchases of common stock |  |  | (75.0 | ) |  |  | (200.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (13.3 | ) |  |  | (16.8 | ) |
| Cash dividends paid |  |  | (18.5 | ) |  |  | (16.1 | ) |
| Net cash provided by financing activities |  |  | 128.4 |  |  |  | 125.5 |  |
| (Decrease) increase in cash and cash equivalents |  |  | (4.0 | ) |  |  | 0.1 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | 2.6 |  |  |  | 1.6 |  |
| Cash and cash equivalents, beginning of period |  |  | 50.2 |  |  |  | 38.9 |  |
| Cash and cash equivalents, end of period |  | $ | 48.8 |  |  | $ | 40.6 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 2.4 |  |  | $ | 3.3 |  |
| Income taxes paid (net of refunds) |  | $ | 36.7 |  |  | $ | 51.2 |  |

[0001193125-17-133519:8k_2_02:71]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-17-133519:8k_2_02:72]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-17-133519:8k_2_02:73]
(Unaudited, in millions, except per share and ratio data)

[0001193125-17-133519:8k_2_02:74]
Use of Non-GAAP Financial Measures

[0001193125-17-133519:8k_2_02:75]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with
the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the
Company’s business trends and operating performance.

[0001193125-17-133519:8k_2_02:76]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from
Continuing Operations, a Non-GAAP measure

[0001193125-17-133519:8k_2_02:77]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 53.4 |  |  | $ | (9.9 | ) |  | $ | 43.5 |  |  | $ | 37.9 |  |  | $ | (13.0 | ) |  | $ | 24.9 |  |
| Restructuring charges |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | (0.1 | ) |
| Special product quality adjustments (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |
| Special legal contingency charges (a) |  |  | 0.9 |  |  |  | — |  |  |  | 0.9 |  |  |  | 1.7 |  |  |  | (0.5 | ) |  |  | 1.2 |  |
| Asbestos-related litigation (a) |  |  | 1.7 |  |  |  | (0.6 | ) |  |  | 1.1 |  |  |  | 0.8 |  |  |  | (0.3 | ) |  |  | 0.5 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 0.7 |  |  |  | (0.3 | ) |  |  | 0.4 |  |  |  | (0.5 | ) |  |  | 0.2 |  |  |  | (0.3 | ) |
| Environmental liabilities(a) |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.3 |  |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 0.5 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (7.4 | ) |  |  | (7.4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractor tax payments (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.3 |  |
| Other items, net (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 0.3 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 57.3 |  |  | $ | (18.4 | ) |  | $ | 38.9 |  |  | $ | 40.9 |  |  | $ | (13.9 | ) |  | $ | 27.0 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 1.00 |  |  |  |  |  |  |  |  |  |  | $ | 0.56 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |
| Special legal contingency charges(a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Asbestos-related litigation(a) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.17 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 0.90 |  |  |  |  |  |  |  |  |  |  | $ | 0.60 |  |

[0001193125-17-133519:8k_2_02:78]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-17-133519:8k_2_02:79]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-17-133519:8k_2_02:80]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-17-133519:8k_2_02:81]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-17-133519:8k_2_02:82]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-17-133519:8k_2_02:83]
|  |  | For the Three Months EndedMarch 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |
| Realized (gains) losses on settled future contracts (a) |  | $ | (0.4 | ) |  | $ | 0.5 |  |
| Foreign currency exchange (gains) losses (a) |  |  | (0.2 | ) |  |  | 0.2 |  |
| Gains on disposal of fixed assets (a) |  |  | (0.1 | ) |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | 0.7 |  |  |  | (0.5 | ) |
| Special legal contingency charges (b) |  |  | 0.9 |  |  |  | 1.7 |  |
| Asbestos-related litigation (b) |  |  | 1.7 |  |  |  | 0.8 |  |
| Environmental liabilities (b) |  |  | 0.5 |  |  |  | 0.7 |  |
| Contractor tax payments (b) |  |  | — |  |  |  | 0.5 |  |
| Acquisition costs (b) |  |  | — |  |  |  | 0.4 |  |
| Other items, net (b) |  |  | — |  |  |  | — |  |
| Losses and other expenses, net (pre-tax) |  | $ | 3.1 |  |  | $ | 4.3 |  |

[0001193125-17-133519:8k_2_02:84]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-17-133519:8k_2_02:85]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-17-133519:8k_2_02:86]
Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated
Adjusted

[0001193125-17-133519:8k_2_02:87]
Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure

[0001193125-17-133519:8k_2_02:88]
|  |  | For the Year EndedDecember 31, 2017ESTIMATED |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $ | 7.65 - $8.25 |  |
| Excess tax benefits from share-based compensation and other items |  |  | (0.10 | ) |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 7.55 - $8.15 |  |

[0001193125-17-133519:8k_2_02:89]
Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted
Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions):

[0001193125-17-133519:8k_2_02:90]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Average shares outstanding - diluted, a GAAP measure |  |  | 43.5 |  |  |  | 44.7 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | (0.2 | ) |  |  | — |  |
| Adjusted average shares outstanding - diluted, a Non- GAAP measure |  |  | 43.3 |  |  |  | 44.7 |  |

[0001193125-17-133519:8k_2_02:91]
Reconciliation of Net Cash Used in Operating Activities, a
GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-17-133519:8k_2_02:92]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Net cash used in operating activities, a GAAP measure |  | $ | (107.6 | ) |  | $ | (101.6 | ) |
| Purchases of property, plant and equipment |  |  | (24.9 | ) |  |  | (23.8 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | — |  |
| Free cash flow, a Non-GAAP measure |  | $ | (132.4 | ) |  | $ | (125.4 | ) |

[0001193125-17-133519:8k_2_02:93]
|  |  | TrailingTwelveMonths toMarch 31, 2017 |  |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |
| Adjusted EBIT (a) |  | $ | 487.6 |  |
| Depreciation and amortization expense (b) |  |  | 59.7 |  |
| EBITDA (a + b) |  | $ | 547.3 |  |
| Total debt at March 31, 2017 (c) |  | $ | 1,103.1 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.0 |  |

[0001193125-17-133519:8k_2_02:94]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing
Operations Before Income Taxes, a GAAP measure (dollars in millions)

[0001193125-17-133519:8k_2_02:95]
|  |  | TrailingTwelveMonths toMarch 31, 2017 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 487.6 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 7.6 |  |
| Restructuring charges |  |  | 2.1 |  |
| Interest expense, net |  |  | 28.6 |  |
| Pension Settlement |  |  | 31.4 |  |
| Other expenses, net |  |  | (0.3 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 418.2 |  |
