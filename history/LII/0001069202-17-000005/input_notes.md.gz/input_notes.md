# LII notes — 0001069202-17-000005


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-17-000005:notes:1]
[same as prior period, unchanged from 0001069202-16-000024:notes:1]

[0001069202-17-000005:notes:2]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 200.0 |  |  | $ | 250.0 |  |
| Beneficial interest sold | 200.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-17-000005:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-17-000005:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-17-000005:notes:5]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-17-000005:notes:6]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.23 | % |  | 2.00 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-17-000005:notes:7]
[same as prior period, unchanged from 0001069202-16-000024:notes:7]

[0001069202-17-000005:notes:8]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2017, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three  months ended March 31, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-17-000005:notes:9]
Our fiscal year ends on December 31 and each quarter is comprised of approximately 13 weeks but the number of days per quarter may vary year-over-year. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.  The first quarter of 2017 included the benefit of five more days, or 6%, this year than in the first quarter last year.  This balances out on a full-year basis with the fourth quarter having 6% fewer days than a year ago.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-17-000005:notes:10]
Commitments and Contingencies:

[0001069202-17-000005:notes:11]
Product Warranties and Product Related Contingencies

[0001069202-17-000005:notes:12]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-17-000005:notes:13]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000005:notes:14]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 30.8 |  |  | $ | 30.0 |  |
| Other liabilities | 71.8 |  |  | 71.1 |  |
| Total warranty liability | $ | 102.6 |  |  | $ | 101.1 |  |

[0001069202-17-000005:notes:15]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2017 were as follows (in millions):

[0001069202-17-000005:notes:16]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (5.2 | ) |
| Changes resulting from issuance of new warranties | 8.2 |  |
| Changes in estimates associated with pre-existing liabilities | (1.7 | ) |
| Changes in foreign currency translation rates and other | 0.2 |  |
| Total warranty liability as of March 31, 2017 | $ | 102.6 |  |

[0001069202-17-000005:notes:17]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. We currently estimate our probable liability for a certain supplier quality issue within a range of $0.9 million and $9.1 million with all amounts in that range equally likely. We have accrued a $0.9 million liability in Accrued expenses on the Consolidated Balance Sheet at March 31, 2017. The supplier is reimbursing the majority of costs related to this liability.

[0001069202-17-000005:notes:18]
Litigation

[0001069202-17-000005:notes:19]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-17-000005:notes:20]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended  March 31, 2017 and 2016, expense for asbestos-related litigation was $1.7 million and $0.8 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation.

[0001069202-17-000005:notes:21]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants. The alleged payment was purportedly made to release a shipment of goods being held by Russian customs officials due to inaccurate paperwork. The value of the shipment was approximately €62,000(approximately US $68,500). The allegations are related to our subsidiary in Russia, which had 2016 annual sales of US $4 million. The scope of the investigation was later expanded to include our operations in Poland and Ukraine. To date, the investigation has not resulted in any evidence of other potentially improper payments. However, the investigation has raised questions regarding possible irregularities with respect to possible non-compliance with customs documents and procedures related to these operations.  The investigation is ongoing. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.

[0001069202-17-000005:notes:22]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-17-000005:notes:23]
[same as prior period, unchanged from 0001069202-16-000024:notes:22]

[0001069202-17-000005:notes:24]
[same as prior period, unchanged from 0001069202-16-000024:notes:23]

[0001069202-17-000005:notes:25]
|  |  | For the Three Months Ended March 31, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2017 |  | 2016 |  |
| (Losses)/Gains on cash flow hedges: |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 3.0 |  |  | $ | (4.8 | ) |  | Cost of goods sold |
| Income tax benefit |  | (1.0 | ) |  | 1.7 |  |  | Provision for income taxes |
| Net of tax |  | $ | 2.0 |  |  | $ | (3.1 | ) |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.9 | ) |  | $ | (1.8 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.6 |  |  | 0.6 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.3 | ) |  | $ | (1.2 | ) |  |  |
| Total reclassifications from AOCL |  | $ | 0.7 |  |  | $ | (4.3 | ) |  |  |

[0001069202-17-000005:notes:26]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2017 (in millions):

[0001069202-17-000005:notes:27]
|  |  | (Losses) Gains on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2016 |  | $ | 5.6 |  |  | $ | 2.3 |  |  | $ | (130.0 | ) |  | $ | (73.0 | ) |  | $ | (195.1 | ) |
| Other comprehensive (loss) income before reclassifications |  | 4.2 |  |  | 0.8 |  |  | (1.6 | ) |  | 15.9 |  |  | 19.3 |  |
| Amounts reclassified from AOCL |  | (2.0 | ) |  | — |  |  | 1.3 |  |  | — |  |  | (0.7 | ) |
| Net other comprehensive (loss) income |  | 2.2 |  |  | 0.8 |  |  | (0.3 | ) |  | 15.9 |  |  | 18.6 |  |
| Balance as of March 31,2017 |  | $ | 7.8 |  |  | $ | 3.1 |  |  | $ | (130.3 | ) |  | $ | (57.1 | ) |  | $ | (176.5 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-17-000005:notes:28]
[same as prior period, unchanged from 0001069202-16-000024:notes:27]

[0001069202-17-000005:notes:29]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor Subsidiaries”) and are not guaranteed by our other subsidiaries (the “Non-Guarantor Subsidiaries”).  The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several.  As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001069202-17-000005:notes:30]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of March 31, 2017 and December 31, 2016 and for the three months ended March 31, 2017 and 2016 are shown on the following pages.

[0001069202-17-000005:notes:31]
[same as prior period, unchanged from 0001069202-16-000024:notes:30]

[0001069202-17-000005:notes:32]
[same as prior period, unchanged from 0001069202-16-000024:notes:31]

[0001069202-17-000005:notes:33]
As of March 31, 2017

[0001069202-17-000005:notes:34]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.5 |  |  | $ | 14.0 |  |  | $ | 33.3 |  |  | $ | — |  |  | $ | 48.8 |  |
| Accounts and notes receivable, net | — |  |  | 45.4 |  |  | 468.0 |  |  | — |  |  | 513.4 |  |
| Inventories, net | — |  |  | 406.8 |  |  | 127.3 |  |  | (11.3 | ) |  | 522.8 |  |
| Other assets | 16.1 |  |  | 50.9 |  |  | 89.4 |  |  | (55.0 | ) |  | 101.4 |  |
| Total current assets | 17.6 |  |  | 517.1 |  |  | 718.0 |  |  | (66.3 | ) |  | 1,186.4 |  |
| Property, plant and equipment, net | — |  |  | 238.9 |  |  | 131.4 |  |  | (4.7 | ) |  | 365.6 |  |
| Goodwill | — |  |  | 134.9 |  |  | 62.7 |  |  | — |  |  | 197.6 |  |
| Investment in subsidiaries | 961.7 |  |  | 427.3 |  |  | (0.6 | ) |  | (1,388.4 | ) |  | — |  |
| Deferred income taxes | 8.1 |  |  | 109.3 |  |  | 31.3 |  |  | (14.7 | ) |  | 134.0 |  |
| Other assets, net | 2.4 |  |  | 41.2 |  |  | 24.9 |  |  | (1.5 | ) |  | 67.0 |  |
| Intercompany receivables (payables), net | (62.1 | ) |  | 62.4 |  |  | 72.9 |  |  | (73.2 | ) |  | — |  |
| Total assets | $ | 927.7 |  |  | $ | 1,531.1 |  |  | $ | 1,040.6 |  |  | $ | (1,548.8 | ) |  | $ | 1,950.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 201.6 |  |  | $ | — |  |  | $ | 201.6 |  |
| Current maturities of long-term debt | 206.9 |  |  | 0.4 |  |  | 0.3 |  |  | — |  |  | 207.6 |  |
| Accounts payable | 18.4 |  |  | 270.8 |  |  | 111.8 |  |  | — |  |  | 401.0 |  |
| Accrued expenses | 11.0 |  |  | 163.4 |  |  | 50.4 |  |  | — |  |  | 224.8 |  |
| Income taxes payable | 12.3 |  |  | 5.5 |  |  | 64.9 |  |  | (80.2 | ) |  | 2.5 |  |
| Total current liabilities | 248.6 |  |  | 440.1 |  |  | 429.0 |  |  | (80.2 | ) |  | 1,037.5 |  |
| Long-term debt | 679.2 |  |  | 14.4 |  |  | 0.3 |  |  | — |  |  | 693.9 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.4 |  |  | — |  |  | — |  |  | 2.4 |  |
| Pensions | — |  |  | 76.4 |  |  | 11.9 |  |  | — |  |  | 88.3 |  |
| Other liabilities | 0.9 |  |  | 120.2 |  |  | 10.9 |  |  | (2.5 | ) |  | 129.5 |  |
| Total liabilities | 928.7 |  |  | 653.5 |  |  | 452.1 |  |  | (82.7 | ) |  | 1,951.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | (1.0 | ) |  | 877.6 |  |  | 588.5 |  |  | (1,466.1 | ) |  | (1.0 | ) |
| Total liabilities and stockholders' equity | $ | 927.7 |  |  | $ | 1,531.1 |  |  | $ | 1,040.6 |  |  | $ | (1,548.8 | ) |  | $ | 1,950.6 |  |

[0001069202-17-000005:notes:35]
As of December 31, 2016

[0001069202-17-000005:notes:36]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 17.1 |  |  | $ | 31.9 |  |  | $ | — |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net | — |  |  | 30.6 |  |  | 439.2 |  |  | — |  |  | 469.8 |  |
| Inventories, net | — |  |  | 314.7 |  |  | 108.9 |  |  | (5.1 | ) |  | 418.5 |  |
| Other assets | 12.8 |  |  | 48.8 |  |  | 67.5 |  |  | (61.7 | ) |  | 67.4 |  |
| Total current assets | 14.0 |  |  | 411.2 |  |  | 647.5 |  |  | (66.8 | ) |  | 1,005.9 |  |
| Property, plant and equipment, net | — |  |  | 237.6 |  |  | 123.8 |  |  | — |  |  | 361.4 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 1,166.9 |  |  | 524.7 |  |  | (0.5 | ) |  | (1,691.1 | ) |  | — |  |
| Deferred income taxes | 6.8 |  |  | 113.5 |  |  | 31.1 |  |  | (14.7 | ) |  | 136.7 |  |
| Other assets, net | 3.6 |  |  | 40.0 |  |  | 19.0 |  |  | (1.4 | ) |  | 61.2 |  |
| Intercompany (payables) receivables, net | (382.4 | ) |  | 375.2 |  |  | 80.4 |  |  | (73.2 | ) |  | — |  |
| Total assets | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | — |  |  | $ | 52.4 |  |
| Current maturities of long-term debt | 199.3 |  |  | 0.4 |  |  | 0.4 |  |  | — |  |  | 200.1 |  |
| Accounts payable | 18.5 |  |  | 248.5 |  |  | 94.2 |  |  | — |  |  | 361.2 |  |
| Accrued expenses | 6.3 |  |  | 206.3 |  |  | 53.3 |  |  | — |  |  | 265.9 |  |
| Income taxes (receivable) payable | (54.0 | ) |  | 89.8 |  |  | 52.5 |  |  | (79.3 | ) |  | 9.0 |  |
| Total current liabilities | 170.1 |  |  | 545.0 |  |  | 252.8 |  |  | (79.3 | ) |  | 888.6 |  |
| Long-term debt | 600.9 |  |  | 14.5 |  |  | 0.3 |  |  | — |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.8 |  |  | — |  |  | — |  |  | 2.8 |  |
| Pensions | — |  |  | 75.5 |  |  | 12.0 |  |  | — |  |  | 87.5 |  |
| Other liabilities | — |  |  | 119.1 |  |  | 11.1 |  |  | (2.5 | ) |  | 127.7 |  |
| Total liabilities | 771.0 |  |  | 756.9 |  |  | 276.2 |  |  | (81.8 | ) |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 37.9 |  |  | 1,080.2 |  |  | 685.3 |  |  | (1,765.4 | ) |  | 38.0 |  |
| Total liabilities and stockholders' equity | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |

[0001069202-17-000005:notes:37]
[same as prior period, unchanged from 0001069202-16-000024:notes:36]

[0001069202-17-000005:notes:38]
For the Three Months Ended March 31, 2017

[0001069202-17-000005:notes:39]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 686.3 |  |  | $ | 258.8 |  |  | $ | (151.7 | ) |  | $ | 793.4 |  |
| Cost of goods sold | — |  |  | 513.3 |  |  | 217.7 |  |  | (148.5 | ) |  | 582.5 |  |
| Gross profit | — |  |  | 173.0 |  |  | 41.1 |  |  | (3.2 | ) |  | 210.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 130.5 |  |  | 22.1 |  |  | (0.2 | ) |  | 152.4 |  |
| Losses (gains) and other expenses, net | 0.6 |  |  | 2.0 |  |  | 0.6 |  |  | (0.1 | ) |  | 3.1 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (48.6 | ) |  | (12.7 | ) |  | (4.9 | ) |  | 60.7 |  |  | (5.5 | ) |
| Operating income | 48.0 |  |  | 53.2 |  |  | 23.2 |  |  | (63.6 | ) |  | 60.8 |  |
| Interest expense, net | 7.2 |  |  | (0.8 | ) |  | 1.0 |  |  | — |  |  | 7.4 |  |
| Income from continuing operations before income taxes | 40.8 |  |  | 54.0 |  |  | 22.2 |  |  | (63.6 | ) |  | 53.4 |  |
| Provision for income taxes | (2.7 | ) |  | 7.1 |  |  | 6.3 |  |  | (0.8 | ) |  | 9.9 |  |
| Income from continuing operations | 43.5 |  |  | 46.9 |  |  | 15.9 |  |  | (62.8 | ) |  | 43.5 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 43.5 |  |  | $ | 46.9 |  |  | $ | 15.9 |  |  | $ | (62.8 | ) |  | $ | 43.5 |  |
| Other comprehensive income (loss), net of tax | (71.2 | ) |  | (29.4 | ) |  | 10.8 |  |  | 108.4 |  |  | 18.6 |  |
| Comprehensive income | $ | (27.7 | ) |  | $ | 17.5 |  |  | $ | 26.7 |  |  | $ | 45.6 |  |  | $ | 62.1 |  |

[0001069202-17-000005:notes:40]
For the Three Months Ended March 31, 2016

[0001069202-17-000005:notes:41]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 613.8 |  |  | $ | 143.8 |  |  | $ | (42.4 | ) |  | $ | 715.2 |  |
| Cost of goods sold | — |  |  | 460.7 |  |  | 111.3 |  |  | (40.4 | ) |  | 531.6 |  |
| Gross profit | — |  |  | 153.1 |  |  | 32.5 |  |  | (2.0 | ) |  | 183.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 118.9 |  |  | 21.5 |  |  | — |  |  | 140.4 |  |
| Losses and other expenses, net | (0.6 | ) |  | 2.5 |  |  | 2.4 |  |  | — |  |  | 4.3 |  |
| Restructuring gains | — |  |  | 0.1 |  |  | (0.3 | ) |  | — |  |  | (0.2 | ) |
| Income from equity method investments | (28.1 | ) |  | — |  |  | (4.0 | ) |  | 27.5 |  |  | (4.6 | ) |
| Operating income | 28.7 |  |  | 31.6 |  |  | 12.9 |  |  | (29.5 | ) |  | 43.7 |  |
| Interest expense, net | 5.3 |  |  | (0.5 | ) |  | 1.0 |  |  | — |  |  | 5.8 |  |
| Income from continuing operations before income taxes | 23.4 |  |  | 32.1 |  |  | 11.9 |  |  | (29.5 | ) |  | 37.9 |  |
| Provision for income taxes | (1.5 | ) |  | 11.9 |  |  | 3.5 |  |  | (0.9 | ) |  | 13.0 |  |
| Income from continuing operations | 24.9 |  |  | 20.2 |  |  | 8.4 |  |  | (28.6 | ) |  | 24.9 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 24.9 |  |  | $ | 20.2 |  |  | $ | 8.4 |  |  | $ | (28.6 | ) |  | $ | 24.9 |  |
| Other comprehensive loss, net of tax | 4.6 |  |  | 2.1 |  |  | 6.3 |  |  | 1.0 |  |  | 14.0 |  |
| Comprehensive income (loss) | $ | 29.5 |  |  | $ | 22.3 |  |  | $ | 14.7 |  |  | $ | (27.6 | ) |  | $ | 38.9 |  |

[0001069202-17-000005:notes:42]
[same as prior period, unchanged from 0001069202-16-000024:notes:45]

[0001069202-17-000005:notes:43]
For the Three Months Ended March 31, 2017

[0001069202-17-000005:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 341.2 |  |  | $ | (308.6 | ) |  | $ | (140.2 | ) |  | $ | — |  |  | $ | (107.6 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (22.0 | ) |  | (2.9 | ) |  | — |  |  | (24.9 | ) |
| Net cash used in investing activities | — |  |  | (22.0 | ) |  | (2.8 | ) |  | — |  |  | (24.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 150.0 |  |  | — |  |  | 150.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | — |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |  | (0.2 | ) |
| Borrowings from credit facility | 583.0 |  |  | — |  |  | — |  |  | — |  |  | 583.0 |  |
| Payments on credit facility | (497.5 | ) |  | — |  |  | — |  |  | — |  |  | (497.5 | ) |
| Proceeds from employee stock purchases | 0.7 |  |  | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Repurchases of common stock | (75.0 | ) |  | — |  |  | — |  |  | — |  |  | (75.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (13.3 | ) |  | — |  |  | — |  |  | — |  |  | (13.3 | ) |
| Intercompany debt | (29.3 | ) |  | 7.6 |  |  | 21.7 |  |  | — |  |  | — |  |
| Intercompany financing activity | (291.0 | ) |  | 320.0 |  |  | (29.0 | ) |  | — |  |  | — |  |
| Cash dividends paid | (18.5 | ) |  | — |  |  | — |  |  | — |  |  | (18.5 | ) |
| Net cash provided by financing activities | (340.9 | ) |  | 327.5 |  |  | 141.8 |  |  | — |  |  | 128.4 |  |
| Increase in cash and cash equivalents | 0.3 |  |  | (3.1 | ) |  | (1.2 | ) |  | — |  |  | (4.0 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 2.6 |  |  | — |  |  | 2.6 |  |
| Cash and cash equivalents, beginning of period | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of period | $ | 1.5 |  |  | $ | 14.0 |  |  | $ | 33.3 |  |  | $ | — |  |  | $ | 48.8 |  |

[0001069202-17-000005:notes:45]
For the Three Months Ended March 31, 2016

[0001069202-17-000005:notes:46]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 59.0 |  |  | $ | (163.1 | ) |  | $ | 2.5 |  |  | $ | — |  |  | $ | (101.6 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Purchases of property, plant and equipment | — |  |  | (20.9 | ) |  | (2.9 | ) |  | — |  |  | (23.8 | ) |
| Net cash used in investing activities | — |  |  | (20.9 | ) |  | (2.9 | ) |  | — |  |  | (23.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset securitization payments | — |  |  | — |  |  | (20.0 | ) |  | — |  |  | (20.0 | ) |
| Long-term debt payments | — |  |  | (0.2 | ) |  | (0.1 | ) |  | — |  |  | (0.3 | ) |
| Borrowings from credit facility | 770.5 |  |  | — |  |  | — |  |  | — |  |  | 770.5 |  |
| Payments on credit facility | (392.0 | ) |  | — |  |  | — |  |  | — |  |  | (392.0 | ) |
| Proceeds from employee stock purchases | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |
| Repurchases of common stock | (200.0 | ) |  | — |  |  | — |  |  | — |  |  | (200.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (16.8 | ) |  | — |  |  | — |  |  | — |  |  | (16.8 | ) |
| Intercompany financing activity | (8.6 | ) |  | (2.9 | ) |  | 11.5 |  |  | — |  |  | — |  |
| Intercompany investments | (196.1 | ) |  | 194.5 |  |  | 1.6 |  |  | — |  |  | — |  |
| Cash dividends paid | (16.1 | ) |  | — |  |  | — |  |  | — |  |  | (16.1 | ) |
| Net cash provided by financing activities | (58.5 | ) |  | 191.4 |  |  | (7.4 | ) |  | — |  |  | 125.5 |  |
| Increase in cash and cash equivalents | 0.5 |  |  | 7.4 |  |  | (7.8 | ) |  | — |  |  | 0.1 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Cash and cash equivalents, beginning of period | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of period | $ | 1.0 |  |  | $ | 15.2 |  |  | $ | 24.4 |  |  | $ | — |  |  | $ | 40.6 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-17-000005:notes:47]
Lines of Credit and Financing Arrangements:

[0001069202-17-000005:notes:48]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-17-000005:notes:49]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 200.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.6 |  |  | 2.4 |  |
| Total short-term debt | $ | 201.6 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.7 |  |  | $ | 0.8 |  |
| Domestic credit facility | 7.5 |  |  | — |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 207.6 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.9 |  |  | $ | 15.0 |  |
| Domestic credit facility | 334.0 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (5.0 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 693.9 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,103.1 |  |  | $ | 868.2 |  |

[0001069202-17-000005:notes:50]
Short-Term Debt

[0001069202-17-000005:notes:51]
Foreign Obligations

[0001069202-17-000005:notes:52]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.6 million and $2.4 million of foreign obligations as of March 31, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.3 million  and $1.2 million during the three months ended March 31, 2017 and 2016, respectively. Repayments on the facilities were $1.1 million and $1.6 million during the three months ended March 31, 2017 and 2016, respectively.

[0001069202-17-000005:notes:53]
Asset Securitization Program

[0001069202-17-000005:notes:54]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-17-000005:notes:55]
The ASP provides for a maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-17-000005:notes:56]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rates for March 31, 2017 and December 31, 2016 were 1.70% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-17-000005:notes:57]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of  March 31, 2017, we believe we were in compliance with all covenant requirements.

[0001069202-17-000005:notes:58]
Long-Term Debt

[0001069202-17-000005:notes:59]
Domestic Credit Facility

[0001069202-17-000005:notes:60]
On August 30, 2016, we replaced an earlier $950.0 million credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $341.5 million, of which $220.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of March 31, 2017. Subject to covenant limitations, $524.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-17-000005:notes:61]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-17-000005:notes:62]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-17-000005:notes:63]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-17-000005:notes:64]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-17-000005:notes:65]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2017, we believe we were in compliance with all covenant requirements.

[0001069202-17-000005:notes:66]
Senior Unsecured Notes

[0001069202-17-000005:notes:67]
We issued $350.0 million of senior unsecured notes in November 2016 (the "2016 Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also have $200.0 million of senior unsecured notes issued in 2010 (the "2010 Notes") which will mature on  May 15, 2017  with interest being paid at 4.90%   per annum semiannually. Both Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and, in the case of the 2010 Notes, transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of  March 31, 2017, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-17-000005:notes:68]
[same as prior period, unchanged from 0001069202-16-000024:notes:72]

[0001069202-17-000005:notes:69]
[same as prior period, unchanged from 0001069202-16-000024:notes:73]

[0001069202-17-000005:notes:70]
[same as prior period, unchanged from 0001069202-16-000024:notes:74]

[0001069202-17-000005:notes:71]
[same as prior period, unchanged from 0001069202-16-000024:notes:75]

[0001069202-17-000005:notes:72]
Foreign Currency Risk - Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001069202-17-000005:notes:73]
[same as prior period, unchanged from 0001069202-16-000024:notes:77]

[0001069202-17-000005:notes:74]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flow hedges that are scheduled to mature through August 2018 and December 2017, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-17-000005:notes:75]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Unrealized gains on unsettled contracts | $ | (12.3 | ) |  | $ | (8.9 | ) |
| Income tax expense | 4.5 |  |  | 3.3 |  |
| Gains included in AOCL, net of tax (1) | $ | (7.8 | ) |  | $ | (5.6 | ) |

[0001069202-17-000005:notes:76]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $7.3 million of derivative gains into earnings within the next 12 months.

[0001069202-17-000005:notes:77]
[same as prior period, unchanged from 0001069202-16-000024:notes:81]

[0001069202-17-000005:notes:78]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Copper | 26.0 |  |  | 30.4 |  |

[0001069202-17-000005:notes:79]
[same as prior period, unchanged from 0001069202-16-000024:notes:83]

[0001069202-17-000005:notes:80]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 232.0 |  |  | 310.1 |  |
| Canadian Dollar | — |  |  | 24.9 |  |

[0001069202-17-000005:notes:81]
[same as prior period, unchanged from 0001069202-16-000024:notes:85]

[0001069202-17-000005:notes:82]
[same as prior period, unchanged from 0001069202-16-000024:notes:86]

[0001069202-17-000005:notes:83]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Copper | 2.2 |  |  | 2.4 |  |
| Aluminum | 2.4 |  |  | 2.6 |  |

[0001069202-17-000005:notes:84]
[same as prior period, unchanged from 0001069202-16-000024:notes:88]

[0001069202-17-000005:notes:85]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Notional Amounts (in local currency): |  |  |  |
| Chinese Yuan | 13.0 |  |  | 10.5 |  |
| Mexican Peso | 59.5 |  |  | 64.5 |  |
| Euro | 43.0 |  |  | 46.9 |  |
| British Pound | 0.6 |  |  | 1.3 |  |
| Indian Rupee | 488.5 |  |  | 584.6 |  |

[0001069202-17-000005:notes:86]
[same as prior period, unchanged from 0001069202-16-000024:notes:90]

[0001069202-17-000005:notes:87]
[same as prior period, unchanged from 0001069202-16-000024:notes:91]

[0001069202-17-000005:notes:88]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of March 31, 2017 |  | As of December 31, 2016 |  | As of March 31, 2017 |  | As of December 31, 2016 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 11.0 |  |  | $ | 8.7 |  |  | $ | 1.2 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts | 0.6 |  |  | 0.5 |  |  | 0.1 |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.9 |  |  | 1.9 |  |  | 0.1 |  |  | 0.2 |  |
| Total Assets | $ | 12.5 |  |  | $ | 11.1 |  |  | $ | 1.4 |  |  | $ | 1.1 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | 0.8 |  |  | 2.0 |  |  | 3.2 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | — |  |  | $ | 0.8 |  |  | $ | 2.0 |  |  | $ | 3.2 |  |

[0001069202-17-000005:notes:89]
[same as prior period, unchanged from 0001069202-16-000024:notes:93]

[0001069202-17-000005:notes:90]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended March 31, |
|  |  | 2017 |  | 2016 |
| Amount of (Gain)/Loss reclassified from AOCL into Income (effective portion) (1) |  | $ | (3.0 | ) |  | $ | 4.8 |  |
| Amount of Loss recognized in Net income (ineffective portion) (2) |  | $ | 1.1 |  |  | $ | 0.1 |  |

[0001069202-17-000005:notes:91]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended March 31, |
|  |  | 2017 |  | 2016 |
| Amount of (Gain)/Loss Recognized in Net Income: |  |  |  |  |
| Commodity futures contracts (2) |  | $ | (0.8 | ) |  | $ | — |  |
| Foreign currency forward contracts (2) |  | (0.7 | ) |  | 0.3 |  |
|  |  | $ | (1.5 | ) |  | $ | 0.3 |  |

[0001069202-17-000005:notes:92]
(1) The (gain)/loss was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-17-000005:notes:93]
(2) The (gain)/loss was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-17-000005:notes:94]
[same as prior period, unchanged from 0001069202-16-000024:notes:98]

[0001069202-17-000005:notes:95]
[same as prior period, unchanged from 0001069202-16-000024:notes:99]

[0001069202-17-000005:notes:96]
|  | For the Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| Stock-based compensation expense (1) | $ | 4.9 |  |  | $ | 6.3 |  |

[0001069202-17-000005:notes:97]
(1) All expense was recorded in our Corporate and Other business segment.


## us-gaap:EarningsPerShareTextBlock

[0001069202-17-000005:notes:98]
[same as prior period, unchanged from 0001069202-16-000024:notes:102]

[0001069202-17-000005:notes:99]
[same as prior period, unchanged from 0001069202-16-000024:notes:103]

[0001069202-17-000005:notes:100]
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-17-000005:notes:101]
|  | For the Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| Net income | $ | 43.5 |  |  | $ | 24.9 |  |
| Add: Loss from discontinued operations | — |  |  | — |  |
| Income from continuing operations | $ | 43.5 |  |  | $ | 24.9 |  |
| Weighted-average shares outstanding – basic | 42.8 |  |  | 44.0 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.7 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 43.5 |  |  | 44.7 |  |
| Earnings per share – Basic: |  |  |  |
| Income from continuing operations | $ | 1.02 |  |  | $ | 0.57 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 1.02 |  |  | $ | 0.57 |  |
| Earnings per share – Diluted: |  |  |  |
| Income from continuing operations | $ | 1.00 |  |  | $ | 0.56 |  |
| Loss from discontinued operations | — |  |  | — |  |
| Net income | $ | 1.00 |  |  | $ | 0.56 |  |

[0001069202-17-000005:notes:102]
[same as prior period, unchanged from 0001069202-16-000024:notes:106]

[0001069202-17-000005:notes:103]
|  | For the Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| Weighted-average number of shares | 0.2 |  |  | 0.3 |  |
| Price range per share | $ | 156.94 |  |  | $124.97 - $131.94 |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-17-000005:notes:104]
[same as prior period, unchanged from 0001069202-16-000024:notes:108]

[0001069202-17-000005:notes:105]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Senior unsecured notes | $ | 505.6 |  |  | $ | 499.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-17-000005:notes:106]
[same as prior period, unchanged from 0001069202-16-000024:notes:110]

[0001069202-17-000005:notes:107]
[same as prior period, unchanged from 0001069202-16-000024:notes:111]

[0001069202-17-000005:notes:108]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2017 were the same as those used at December 31, 2016.

[0001069202-17-000005:notes:109]
[same as prior period, unchanged from 0001069202-16-000024:notes:113]

[0001069202-17-000005:notes:110]
[same as prior period, unchanged from 0001069202-16-000024:notes:114]

[0001069202-17-000005:notes:111]
[same as prior period, unchanged from 0001069202-16-000024:notes:115]

[0001069202-17-000005:notes:112]
[same as prior period, unchanged from 0001069202-16-000024:notes:116]

[0001069202-17-000005:notes:113]
[same as prior period, unchanged from 0001069202-16-000024:notes:117]

[0001069202-17-000005:notes:114]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Investment in marketable equity securities | $ | 5.2 |  |  | $ | 4.4 |  |

[0001069202-17-000005:notes:115]
[same as prior period, unchanged from 0001069202-16-000024:notes:119]

[0001069202-17-000005:notes:116]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-17-000005:notes:117]
[same as prior period, unchanged from 0001069202-16-000024:notes:121]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-17-000005:notes:118]
[same as prior period, unchanged from 0001069202-16-000024:notes:122]

[0001069202-17-000005:notes:119]
The changes in the carrying amount of goodwill for the first three months of 2017, in total and by segment, are summarized in the table below (in millions):

[0001069202-17-000005:notes:120]
|  | Balance at December 31, 2016 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at March 31, 2017 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 60.1 |  |  | — |  |  | 0.2 |  |  | 60.3 |  |
| Refrigeration | 108.9 |  |  | — |  |  | 2.3 |  |  | 111.2 |  |
| Total Goodwill | $ | 195.1 |  |  | $ | — |  |  | $ | 2.5 |  |  | $ | 197.6 |  |

[0001069202-17-000005:notes:121]
[same as prior period, unchanged from 0001069202-16-000024:notes:125]

[0001069202-17-000005:notes:122]
We perform our annual goodwill impairment test in the fourth quarter of each year.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  In the current year, we have noted no indicators of impairment of our reporting units.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-17-000005:notes:123]
[same as prior period, unchanged from 0001069202-16-000024:notes:127]

[0001069202-17-000005:notes:124]
As of March 31, 2017, we had approximately $2.4 million in total gross unrecognized tax benefits. Of this amount, $2.3 million, if recognized, would be recorded through the Consolidated Statement of Operations. As of March 31, 2017, we had approximately $0.1 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification (“ASC”) Topic 740.

[0001069202-17-000005:notes:125]
We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2017, 2016 and 2015 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2011.

[0001069202-17-000005:notes:126]
Since January 1, 2017, numerous states and the District of Columbia have enacted legislation effective for tax years beginning on or after January 1, 2017, including changes to tax rates.  The impact of these changes is immaterial.

[0001069202-17-000005:notes:127]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity. We recognized discrete tax benefits of $7.4 million in the income taxes line item of our consolidated statement of operations for the three months ended March 31, 2017 related to excess tax benefits upon vesting or settlement in that period.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-17-000005:notes:128]
[same as prior period, unchanged from 0001069202-16-000024:notes:131]

[0001069202-17-000005:notes:129]
[same as prior period, unchanged from 0001069202-16-000024:notes:132]

[0001069202-17-000005:notes:130]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Finished goods | $ | 381.6 |  |  | $ | 287.2 |  |
| Work in process | 5.9 |  |  | 5.1 |  |
| Raw materials and parts | 192.4 |  |  | 183.4 |  |
| Subtotal | 579.9 |  |  | 475.7 |  |
| Excess of current cost over last-in, first-out cost | (57.1 | ) |  | (57.2 | ) |
| Total inventories, net | $ | 522.8 |  |  | $ | 418.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-17-000005:notes:131]
[same as prior period, unchanged from 0001069202-16-000024:notes:134]

[0001069202-17-000005:notes:132]
[same as prior period, unchanged from 0001069202-16-000024:notes:135]

[0001069202-17-000005:notes:133]
[same as prior period, unchanged from 0001069202-16-000024:notes:136]

[0001069202-17-000005:notes:134]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-17-000005:notes:135]
[same as prior period, unchanged from 0001069202-16-000024:notes:138]

[0001069202-17-000005:notes:136]
Recently Adopted Accounting Guidance

[0001069202-17-000005:notes:137]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations.  This is in comparison to the prior requirement that these excess tax benefits be recognized in additional paid-in capital. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity.

[0001069202-17-000005:notes:138]
We have adopted ASU 2016-09 effective January 1, 2017 on a prospective basis where permitted by the new standard. As a result of this adoption:

[0001069202-17-000005:notes:139]
| • | We recognized discrete tax benefits of $7.4 million in the income taxes line item of our consolidated statement of operations for the three months ended March 31, 2017 related to excess tax benefits upon vesting or settlement in that period. |

[0001069202-17-000005:notes:140]
| • | We elected to adopt the cash flow presentation of the excess tax benefits retrospectively where these benefits are classified along with other income tax cash flows as operating cash flows. |

[0001069202-17-000005:notes:141]
| • | We have elected to continue to estimate the number of stock-based awards expected to vest, rather than electing to account for forfeitures as they occur to determine the amount of compensation cost to be recognized in each period. |

[0001069202-17-000005:notes:142]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three months ended March 31, 2017. |

[0001069202-17-000005:notes:143]
[same as prior period, unchanged from 0001069202-16-000024:notes:139]

[0001069202-17-000005:notes:144]
[same as prior period, unchanged from 0001069202-16-000024:notes:140]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-17-000005:notes:145]
[same as prior period, unchanged from 0001069202-16-000024:notes:141]

[0001069202-17-000005:notes:146]
[same as prior period, unchanged from 0001069202-16-000024:notes:142]

[0001069202-17-000005:notes:147]
|  | For the Three Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.3 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.2 |  |  | 3.7 |  |  | — |  |  | — |  |
| Expected return on plan assets | (5.4 | ) |  | (5.1 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.6 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 2.1 |  |  | 2.1 |  |  | 0.3 |  |  | 0.4 |  |
| Settlements and curtailments | 0.3 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.6 |  |  | $ | 1.9 |  |  | $ | (0.3 | ) |  | $ | (0.4 | ) |

[0001069202-17-000005:notes:148]
(1) All net periodic benefit cost for the three months ended March 31, 2017 and 2016 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-17-000005:notes:149]
[same as prior period, unchanged from 0001069202-16-000024:notes:146]

[0001069202-17-000005:notes:150]
|  | For the Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| Net sales |  |  |  |
| Residential Heating & Cooling | $ | 419.8 |  |  | $ | 377.3 |  |
| Commercial Heating & Cooling | 195.5 |  |  | 170.3 |  |
| Refrigeration | 178.1 |  |  | 167.6 |  |
|  | $ | 793.4 |  |  | $ | 715.2 |  |
| Segment profit (loss) (1) |  |  |  |
| Residential Heating & Cooling | $ | 42.5 |  |  | $ | 38.3 |  |
| Commercial Heating & Cooling | 19.1 |  |  | 14.2 |  |
| Refrigeration | 14.1 |  |  | 9.0 |  |
| Corporate and other | (11.0 | ) |  | (14.8 | ) |
| Total segment profit | 64.7 |  |  | 46.7 |  |
| Reconciliation to Operating income: |  |  |  |
| Special product quality adjustments | — |  |  | (0.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) | 3.8 |  |  | 3.6 |  |
| Restructuring charges (gains) | 0.1 |  |  | (0.2 | ) |
| Operating income | $ | 60.8 |  |  | $ | 43.7 |  |

[0001069202-17-000005:notes:151]
[same as prior period, unchanged from 0001069202-16-000024:notes:148]

[0001069202-17-000005:notes:152]
[same as prior period, unchanged from 0001069202-16-000024:notes:149]

[0001069202-17-000005:notes:153]
[same as prior period, unchanged from 0001069202-16-000024:notes:150]

[0001069202-17-000005:notes:154]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-17-000005:notes:155]
| ◦ | Special legal contingency charges, |

[0001069202-17-000005:notes:156]
| ◦ | Asbestos-related litigation, |

[0001069202-17-000005:notes:157]
[same as prior period, unchanged from 0001069202-16-000024:notes:154]

[0001069202-17-000005:notes:158]
| ◦ | Environmental liabilities, |

[0001069202-17-000005:notes:159]
| ◦ | Acquisition costs, |

[0001069202-17-000005:notes:160]
| ◦ | Other items, net; and |

[0001069202-17-000005:notes:161]
| • | Restructuring charges (gains). |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-17-000005:notes:162]
[same as prior period, unchanged from 0001069202-16-000024:notes:159]

[0001069202-17-000005:notes:163]
[same as prior period, unchanged from 0001069202-16-000024:notes:160]

[0001069202-17-000005:notes:164]
Restructuring Activities in 2017

[0001069202-17-000005:notes:165]
[same as prior period, unchanged from 0001069202-16-000024:notes:162]

[0001069202-17-000005:notes:166]
|  | Charges Incurred in 2017 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related (gains) expense | $ | — |  |  | $ | 9.3 |  |  | $ | 9.3 |  |
| Asset write-offs and accelerated depreciation | 0.1 |  |  | 2.5 |  |  | 2.5 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | 0.2 |  |  | 0.2 |  |
| Other | — |  |  | 3.7 |  |  | 4.1 |  |
| Total restructuring charges | $ | 0.1 |  |  | $ | 15.7 |  |  | $ | 16.1 |  |

[0001069202-17-000005:notes:167]
[same as prior period, unchanged from 0001069202-16-000024:notes:164]

[0001069202-17-000005:notes:168]
|  | Charges Incurred in 2017 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Commercial Heating & Cooling | — |  |  | 1.1 |  |  | 1.1 |  |
| Refrigeration | 0.1 |  |  | 12.0 |  |  | 12.0 |  |
| Corporate & Other | — |  |  | 1.7 |  |  | 2.1 |  |
| Total restructuring charges | $ | 0.1 |  |  | $ | 15.7 |  |  | $ | 16.1 |  |

[0001069202-17-000005:notes:169]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below details the activity in 2017 within the restructuring accruals (in millions):

[0001069202-17-000005:notes:170]
|  | Balance as ofDecember 31, 2016 |  | Included inEarnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of March 31, 2017 |
| Severance and related expense | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  |  |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total restructuring accruals | $ | — |  |  | $ | 0.1 |  |  | $ | (0.1 | ) |  | $ | — |  |  | $ | — |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001069202-17-000005:notes:171]
[same as prior period, unchanged from 0001069202-16-000024:notes:168]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-17-000005:notes:172]
[same as prior period, unchanged from 0001069202-16-000024:notes:169]

[0001069202-17-000005:notes:173]
[same as prior period, unchanged from 0001069202-16-000024:notes:170]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-17-000005:notes:174]
[same as prior period, unchanged from 0001069202-16-000024:notes:171]

[0001069202-17-000005:notes:175]
[same as prior period, unchanged from 0001069202-16-000024:notes:172]

[0001069202-17-000005:notes:176]
[same as prior period, unchanged from 0001069202-16-000024:notes:173]

[0001069202-17-000005:notes:177]
[same as prior period, unchanged from 0001069202-16-000024:notes:174]

[0001069202-17-000005:notes:178]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations for the periods presented.

[0001069202-17-000005:notes:179]
[same as prior period, unchanged from 0001069202-16-000024:notes:176]

[0001069202-17-000005:notes:180]
[same as prior period, unchanged from 0001069202-16-000024:notes:177]

[0001069202-17-000005:notes:181]
Except for the seasonal increase in total assets across all reportable segments, there have not been any material changes in the composition of total assets by segment since December 31, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-17-000005:notes:182]
[same as prior period, unchanged from 0001069202-16-000024:notes:179]

[0001069202-17-000005:notes:183]
Our Board of Directors has authorized a total of $2 billion  towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $550 million share repurchase authorization in 2016. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date. As of March 31, 2017, $571 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-17-000005:notes:184]
On February 9, 2017, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “ASR Agreement”) with J.P. Morgan Stanley, to effect an accelerated stock buyback of the Company’s common stock (the “Common Stock”).

[0001069202-17-000005:notes:185]
Under the ASR Agreement, on February 9, 2017, the Company paid J.P. Morgan Stanley an initial purchase price of $75 million, and J.P. Morgan Stanley delivered to the Company approximately 0.4 million shares of Common Stock, representing approximately 85% of the shares expected to be purchased under the ASR Agreement. The ASR Agreement will be completed in the second quarter of 2017.

[0001069202-17-000005:notes:186]
We also repurchased 0.1 million shares for $13.3 million during the three months ended March 31, 2017 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
