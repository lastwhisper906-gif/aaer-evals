# LII MD&A — 0001069202-17-000005


## mdna

[0001069202-17-000005:mdna:1]
[same as prior period, unchanged from 0001069202-16-000024:mdna:1]

[0001069202-17-000005:mdna:2]
[same as prior period, unchanged from 0001069202-16-000024:mdna:2]

[0001069202-17-000005:mdna:3]
[same as prior period, unchanged from 0001069202-16-000024:mdna:3]

[0001069202-17-000005:mdna:4]
[same as prior period, unchanged from 0001069202-16-000024:mdna:4]

[0001069202-17-000005:mdna:5]
[same as prior period, unchanged from 0001069202-16-000024:mdna:5]

[0001069202-17-000005:mdna:6]
[same as prior period, unchanged from 0001069202-16-000024:mdna:6]

[0001069202-17-000005:mdna:7]
[same as prior period, unchanged from 0001069202-16-000024:mdna:7]

[0001069202-17-000005:mdna:8]
In the first quarter of 2017, all business segments showed strong growth.  The Residential Heating & Cooling segment continued to grow with an 11% increase in net sales and a $4 million increase in segment profit compared to the first quarter of 2016.  The primary growth driver for this segment was volume gains.  Our Commercial Heating & Cooling segment also performed well in the first quarter of 2017 with a 15% increase in net sales and $5 million in increased segment profit compared to the first quarter of 2016.  This segment's profits were up largely due to volume increases.  Sales in our Refrigeration segment increased by 6% and segment profit increased $5 million compared to the first quarter of 2016.  Higher sales volume, favorable foreign currency exchange rates and favorable mix were partially offset by higher selling, general and administrative expenses.  Growth in the quarter included the benefit of five more days, or 6%, this year than in the first quarter last year.  This balances out on a full-year basis with the fourth quarter having 6% fewer days than a year ago.

[0001069202-17-000005:mdna:9]
[same as prior period, unchanged from 0001069202-16-000024:mdna:10]

[0001069202-17-000005:mdna:10]
| • | Net sales increased $78 million, or 11%, to $793 million in the first quarter of 2017 compared to the first quarter of 2016. |

[0001069202-17-000005:mdna:11]
| • | Operating income in the first quarter of 2017 increased $17 million to $61 million. |

[0001069202-17-000005:mdna:12]
| • | Net income for the first quarter of 2017 increased $19 million to $44 million, including the benefit of $7.4 million of discrete tax benefits in the first quarter of 2017 related to excess tax benefits from share-based compensation. |

[0001069202-17-000005:mdna:13]
| • | Diluted earnings per share from continuing operations were $1.00 per share in the first quarter of 2017 compared to $0.56 per share in the first quarter of 2016. |

[0001069202-17-000005:mdna:14]
| • | During the first quarter of 2017, we returned $19 million to shareholders through dividend payments and initiated a $75 million repurchase of common stock that will be completed in the second quarter of 2017. |

[0001069202-17-000005:mdna:15]
First Quarter of 2017 Compared to First Quarter of 2016 - Consolidated Results

[0001069202-17-000005:mdna:16]
[same as prior period, unchanged from 0001069202-16-000024:mdna:18]

[0001069202-17-000005:mdna:17]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 793.4 |  |  | $ | 715.2 |  |  | 10.9 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 582.5 |  |  | 531.6 |  |  | (9.6 | ) |  | 73.4 |  |  | 74.3 |  |
| Gross profit | 210.9 |  |  | 183.6 |  |  | 14.9 |  |  | 26.6 |  |  | 25.7 |  |
| Selling, general and administrative expenses | 152.4 |  |  | 140.4 |  |  | (8.5 | ) |  | 19.2 |  |  | 19.6 |  |
| Losses and other expenses, net | 3.1 |  |  | 4.3 |  |  | 27.9 |  |  | 0.4 |  |  | 0.6 |  |
| Restructuring charges | 0.1 |  |  | (0.2 | ) |  | (150.0 | ) |  | — |  |  | — |  |
| Income from equity method investments | (5.5 | ) |  | (4.6 | ) |  | 19.6 |  |  | (0.7 | ) |  | (0.6 | ) |
| Operating income | $ | 60.8 |  |  | $ | 43.7 |  |  | 39.1 | % |  | 7.7 | % |  | 6.1 | % |

[0001069202-17-000005:mdna:18]
[same as prior period, unchanged from 0001069202-16-000024:mdna:20]

[0001069202-17-000005:mdna:19]
Net sales increased 11% in the first quarter of 2017 compared to the first quarter of 2016, primarily from 10% higher sales volumes and 1% from price and mix.  The Residential Heating & Cooling segment delivered higher volume from additional replacement and new construction business.  The Commercial Heating & Cooling segment delivered higher volume from our national accounts and districts and the Refrigeration segment delivered higher volume from our wholesaler and cold storage business.

[0001069202-17-000005:mdna:20]
[same as prior period, unchanged from 0001069202-16-000024:mdna:22]

[0001069202-17-000005:mdna:21]
Gross profit margin in the first quarter of 2017 increased 90 basis points ("bps") to 26.6% compared to the first quarter of 2016.  Our profit margin increased 110 bps from lower material costs, 60 bps from favorable mix and price and 10 bps from favorable foreign currency rates.  Offsetting these increases were decreases of 70 bps from combined freight and distribution, 10 bps from other product costs and 10 bps from product warranties.

[0001069202-17-000005:mdna:22]
[same as prior period, unchanged from 0001069202-16-000024:mdna:24]

[0001069202-17-000005:mdna:23]
Selling, general and administrative expenses, or SG&A, was $152 million in the  first quarter of 2017 compared to $140 million in the first quarter of 2016, and as a percentage of net sales decreased 40 bps to 19.2%.  SG&A increased due to wage inflation and increased investment in information technology and research and development partially offset by decreases in long-term incentive compensation and healthcare costs.

[0001069202-17-000005:mdna:24]
[same as prior period, unchanged from 0001069202-16-000024:mdna:26]

[0001069202-17-000005:mdna:25]
Losses and other expenses, net for the first quarter of 2017 and 2016 included the following (in millions):

[0001069202-17-000005:mdna:26]
|  | For the Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| Realized (gains) losses on settled future contracts | $ | (0.4 | ) |  | $ | 0.5 |  |
| Foreign currency exchange (gains) losses | (0.2 | ) |  | 0.2 |  |
| Gain on disposal of fixed assets | (0.1 | ) |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.7 |  |  | (0.5 | ) |
| Special legal contingency charges | 0.9 |  |  | 1.7 |  |
| Asbestos-related litigation | 1.7 |  |  | 0.8 |  |
| Contractor tax payments | — |  |  | 0.5 |  |
| Environmental liabilities | 0.5 |  |  | 0.7 |  |
| Acquisition costs | — |  |  | 0.4 |  |
| Other items, net | — |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 3.1 |  |  | $ | 4.3 |  |

[0001069202-17-000005:mdna:27]
The net change in unrealized losses (gains) on unsettled futures contracts was due to higher commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000005:mdna:28]
[same as prior period, unchanged from 0001069202-16-000024:mdna:30]

[0001069202-17-000005:mdna:29]
There were minor restructuring charges in the first quarter of 2017.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000005:mdna:30]
[same as prior period, unchanged from 0001069202-16-000024:mdna:32]

[0001069202-17-000005:mdna:31]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $6 million in the first quarter of 2017 increased from $5 million in the first quarter of 2016.

[0001069202-17-000005:mdna:32]
[same as prior period, unchanged from 0001069202-16-000024:mdna:34]

[0001069202-17-000005:mdna:33]
Interest expense, net of $7 million in the first quarter of 2017 was up from $6 million as compared to the first quarter of 2016.

[0001069202-17-000005:mdna:34]
[same as prior period, unchanged from 0001069202-16-000024:mdna:36]

[0001069202-17-000005:mdna:35]
We expect our annual effective tax rate to be 32%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09, in 2017 and subsequent years.

[0001069202-17-000005:mdna:36]
The effective tax rate was 19% for the first quarter of 2017, after the impact of excess tax benefits, compared to 34% for the first quarter of 2016, which excluded the impact of excess tax benefits.

[0001069202-17-000005:mdna:37]
First Quarter of 2017 Compared to First Quarter of 2016 - Results by Segment

[0001069202-17-000005:mdna:38]
[same as prior period, unchanged from 0001069202-16-000024:mdna:40]

[0001069202-17-000005:mdna:39]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000005:mdna:40]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 419.8 |  |  | $ | 377.3 |  |  | $ | 42.5 |  |  | 11.3 | % |
| Profit | $ | 42.5 |  |  | $ | 38.3 |  |  | $ | 4.2 |  |  | 11.0 | % |
| % of net sales | 10.1 | % |  | 10.2 | % |  |  |  |  |

[0001069202-17-000005:mdna:41]
Net sales increased by 11% in the first quarter of 2017 compared to the first quarter of 2016.  Sales volume increased by 10% and price and mix combined increased sales by 1%.

[0001069202-17-000005:mdna:42]
Segment profit in the first quarter of 2017 increased $4 million compared to the first quarter of 2016 due to $11 million in higher sales volume, $4 million in lower material costs and $1 million from favorable foreign currency rates.  Partially offsetting these increases was $6 million of SG&A expenses primarily for information technology and research and development investments, incremental headcount and higher personnel related costs, $5 million in distribution investments and $1 million in higher commodities.

[0001069202-17-000005:mdna:43]
[same as prior period, unchanged from 0001069202-16-000024:mdna:45]

[0001069202-17-000005:mdna:44]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000005:mdna:45]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 195.5 |  |  | $ | 170.3 |  |  | $ | 25.2 |  |  | 14.8 | % |
| Profit | $ | 19.1 |  |  | $ | 14.2 |  |  | $ | 4.9 |  |  | 34.5 | % |
| % of net sales | 9.8 | % |  | 8.3 | % |  |  |  |  |

[0001069202-17-000005:mdna:46]
Net sales increased by 15% in the first quarter of 2017 compared to the first quarter of 2016.  Sales volume increased by 14% primarily the result of growth in national accounts and districts and price and mix combined increased sales by 1%.

[0001069202-17-000005:mdna:47]
Segment profit in the first quarter of 2017 increased $5 million compared to the first quarter of 2016 due to $7 million from higher sales volume, $1 million in lower commodities and $1 million in lower material costs.  Partially offsetting these increases was $3 million in SG&A expenses and $1 million from other product costs.

[0001069202-17-000005:mdna:48]
[same as prior period, unchanged from 0001069202-16-000024:mdna:50]

[0001069202-17-000005:mdna:49]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2017 and 2016 (dollars in millions):

[0001069202-17-000005:mdna:50]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 178.1 |  |  | $ | 167.6 |  |  | $ | 10.5 |  |  | 6.3 | % |
| Profit | $ | 14.1 |  |  | $ | 9.0 |  |  | $ | 5.1 |  |  | 56.7 | % |
| % of net sales | 7.9 | % |  | 5.4 | % |  |  |  |  |

[0001069202-17-000005:mdna:51]
Net sales increased 6% in the first quarter of 2017 compared to the first quarter of 2016.  Sales volumes increased by 4%, mix increased sales by 1% and favorable foreign currency rates increased sales by 1%.

[0001069202-17-000005:mdna:52]
Segment profit for the first quarter of 2017 increased $5 million compared to the first quarter of 2016 due to $3 million from favorable mix, $3 million from lower material costs, $2 million from higher sales volumes, $1 million from lower commodities, $1 million from favorable other product costs and $1 million from favorable foreign currency rates.  Partially offsetting these increases was $5 million in SG&A expenses and $1 million in unfavorable freight and distribution.

[0001069202-17-000005:mdna:53]
[same as prior period, unchanged from 0001069202-16-000024:mdna:55]

[0001069202-17-000005:mdna:54]
Corporate and other expenses decreased $4 million in the first quarter of 2017 compared to the first quarter of 2016 primarily due to $2 million in lower health care expenses and $1 million in lower long-term incentive compensation.

[0001069202-17-000005:mdna:55]
[same as prior period, unchanged from 0001069202-16-000024:mdna:99]

[0001069202-17-000005:mdna:56]
[same as prior period, unchanged from 0001069202-16-000024:mdna:100]

[0001069202-17-000005:mdna:57]
[same as prior period, unchanged from 0001069202-16-000024:mdna:101]

[0001069202-17-000005:mdna:58]
The following table summarizes our cash flow activity for the three months ended March 31, 2017 and 2016 (in millions):

[0001069202-17-000005:mdna:59]
|  | For the Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| Net cash used in operating activities | $ | (107.6 | ) |  | $ | (101.6 | ) |
| Net cash used in investing activities | (24.8 | ) |  | (23.8 | ) |
| Net cash provided by financing activities | 128.4 |  |  | 125.5 |  |

[0001069202-17-000005:mdna:60]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first three months of 2017 and 2016 reflects the seasonal increase in working capital requirements and was relatively flat year over year. The increase in net income in the first three months of 2017 as compared to 2016 was offset by increases in working capital.

[0001069202-17-000005:mdna:61]
Net Cash Used in Investing Activities - Capital expenditures were $25 million and $24 million in the first three months of 2017 and 2016, respectively.  Capital expenditures in 2017 were primarily related to investments in systems and software to support the overall enterprise, expansion of our manufacturing capacity and equipment, and continued investments in our distribution network.

[0001069202-17-000005:mdna:62]
Net Cash Provided by Financing Activities - Net cash provided by financing activities was relatively flat with cash provided by financing activities of $128 million in the first three months of 2017  as compared to $126 million in the first three months of 2016.   Cash continues to be provided by an increase in net borrowings and we continue to make share repurchases.  Final settlement of the $75 million Accelerated Share Repurchase Transaction executed in the first quarter of 2017 will be in the second quarter of 2017.

[0001069202-17-000005:mdna:63]
[same as prior period, unchanged from 0001069202-16-000024:mdna:107]

[0001069202-17-000005:mdna:64]
The following table details our lines of credit and financing arrangements as of March 31, 2017 (in millions):

[0001069202-17-000005:mdna:65]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 1.6 |  |
| Asset Securitization Program (1) | 200.0 |  |
| Total short-term debt | $ | 201.6 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 0.7 |  |
| Domestic credit facility (2) | 7.5 |  |
| Senior unsecured notes | 200.0 |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 207.6 |  |
| Long-term debt: |  |
| Capital lease obligations | 14.9 |  |
| Domestic credit facility (2) | 334.0 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (5.0 | ) |
| Total long-term debt | 693.9 |  |
| Total debt | $ | 1,103.1 |  |

[0001069202-17-000005:mdna:66]
(1) The maximum securitization amount ranges from $200.0 million to $325.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.

[0001069202-17-000005:mdna:67]
(2) The available future borrowings on our domestic credit facility are $524.1 million after being reduced by the outstanding borrowings and $4.4 million in outstanding standby letters of credit.  We also had $38.3 million in outstanding standby letters of credit outside of the domestic credit facility as of March 31, 2017.

[0001069202-17-000005:mdna:68]
[same as prior period, unchanged from 0001069202-16-000024:mdna:112]

[0001069202-17-000005:mdna:69]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 100.1% at March 31, 2017 from 95.8% at December 31, 2016.

[0001069202-17-000005:mdna:70]
As of March 31, 2017, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-17-000005:mdna:71]
[same as prior period, unchanged from 0001069202-16-000024:mdna:115]

[0001069202-17-000005:mdna:72]
We believe our cash and cash equivalents of $49 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, potential dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $49 million as of March 31, 2017 was $33.3 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States. If we were to repatriate foreign earnings, we would be required to accrue and pay taxes in the United States, less foreign tax credits, for the amounts that were repatriated.

[0001069202-17-000005:mdna:73]
Our expected capital expenditures for 2017 are $100 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with the initiation of a $75 million stock repurchase program and the declaration of $18 million of cash dividends in the first quarter of 2017.

[0001069202-17-000005:mdna:74]
[same as prior period, unchanged from 0001069202-16-000024:mdna:118]

[0001069202-17-000005:mdna:75]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Our operating lease commitments have not materially changed since December 31, 2016.

[0001069202-17-000005:mdna:76]
Commitments, Contingencies and Guarantees

[0001069202-17-000005:mdna:77]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-17-000005:mdna:78]
[same as prior period, unchanged from 0001069202-16-000024:mdna:122]

[0001069202-17-000005:mdna:79]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. We substantially completed our evaluation of the effect that ASU 2014-09 will have on our Consolidated Financial Statements and related disclosures. We do not expect the ASU to have a material impact on the amount and timing of revenue recognition.  We will adopt the new standard using the modified retrospective approach.

[0001069202-17-000005:mdna:80]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.  As a result of the new standard, all of our leases greater than one year in duration will be recognized on our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.

[0001069202-17-000005:mdna:81]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees.  For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017.  This standard is not expected to have a material impact on our consolidated financial statements.

[0001069202-17-000005:mdna:82]
On October 24, 2016, the FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory. The new ASU eliminates the existing exception from recognition of the tax consequences of intercompany sales of assets other than inventory.  Under the new standard, when an asset (other than inventory) is sold from one consolidated entity to another, the tax consequences to the seller will be recognized currently as a component of the current tax provision.  The new guidance will be effective for public business entities in fiscal years beginning after December 15, 2017, including interim periods within those years.  In accordance with the ASU, our previously deferred tax costs and unrecognized deferred tax assets related to intra-entity asset transfers will need to be recognized at the date of transition through a cumulative effect adjustment to opening retained earnings upon adoption of the standard.

[0001069202-17-000005:mdna:83]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other Income, net. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We do not expect the ASU to have a material impact on our financial results.
