# LII note change history — 0001069202-16-000024 → 0001069202-17-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-04-24):
[0001069202-17-000005:note_history:1]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Accrued expenses | $ | 30.8 |  |  | $ | 30.0 |  |
| Other liabilities | 71.8 |  |  | 71.1 |  |
| Total warranty liability | $ | 102.6 |  |  | $ | 101.1 |  |
  (was, 2016-10-17, similarity 0.9716):
[0001069202-16-000024:note_history:1]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Accrued expenses | $ | 30.3 |  |  | $ | 26.7 |  |
| Other liabilities | 69.9 |  |  | 65.6 |  |
| Total warranty liability | $ | 100.2 |  |  | $ | 92.3 |  |

- changed (2017-04-24):
[0001069202-17-000005:note_history:2]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2017 were as follows (in millions):
  (was, 2016-10-17, similarity 0.9416):
[0001069202-16-000024:note_history:2]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2016 were as follows (in millions):

- changed (2017-04-24):
[0001069202-17-000005:note_history:3]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Warranty claims paid | (5.2 | ) |
| Changes resulting from issuance of new warranties | 8.2 |  |
| Changes in estimates associated with pre-existing liabilities | (1.7 | ) |
| Changes in foreign currency translation rates and other | 0.2 |  |
| Total warranty liability as of March 31, 2017 | $ | 102.6 |  |
  (was, 2016-10-17, similarity 0.9799):
[0001069202-16-000024:note_history:3]
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |
| Warranty claims paid | (20.4 | ) |
| Changes resulting from issuance of new warranties | 31.6 |  |
| Changes in estimates associated with pre-existing liabilities | (3.9 | ) |
| Changes in foreign currency translation rates and other | 0.6 |  |
| Total warranty liability as of September 30, 2016 | $ | 100.2 |  |

- changed (2017-04-24):
[0001069202-17-000005:note_history:4]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. We currently estimate our probable liability for a certain supplier quality issue within a range of $0.9 million and $9.1 million with all amounts in that range equally likely. We have accrued a $0.9 million liability in Accrued expenses on the Consolidated Balance Sheet at March 31, 2017. The supplier is reimbursing the majority of costs related to this liability.
  (was, 2016-10-17, similarity 0.9908):
[0001069202-16-000024:note_history:4]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which is not included in the estimated warranty liabilities tables immediately above.   Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a certain supplier quality issue within a range of $1.9 million and $9.1 million  with all amounts in that range equally likely.  We have accrued a $1.9 million liability in Accrued expenses on the Consolidated Balance Sheet at September 30, 2016. The supplier is reimbursing the majority of costs related to this liability.

- changed (2017-04-24):
[0001069202-17-000005:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended  March 31, 2017 and 2016, expense for asbestos-related litigation was $1.7 million and $0.8 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation.
  (was, 2016-10-17, similarity 0.912):
[0001069202-16-000024:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and is subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2016, and 2015, expense for asbestos-related litigation was $2.3 million, and $1.0 million, net of insurance recoveries, respectively.

- added (2017-04-24):
[0001069202-17-000005:note_history:6]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants. The alleged payment was purportedly made to release a shipment of goods being held by Russian customs officials due to inaccurate paperwork. The value of the shipment was approximately €62,000(approximately US $68,500). The allegations are related to our subsidiary in Russia, which had 2016 annual sales of US $4 million. The scope of the investigation was later expanded to include our operations in Poland and Ukraine. To date, the investigation has not resulted in any evidence of other potentially improper payments. However, the investigation has raised questions regarding possible irregularities with respect to possible non-compliance with customs documents and procedures related to these operations.  The investigation is ongoing. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-04-24):
[0001069202-17-000005:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2017, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2017 and 2016, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three  months ended March 31, 2017 and 2016, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2017 and 2016 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2016. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2016-10-17, similarity 0.9465):
[0001069202-16-000024:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2016, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2016 and 2015, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine  months ended September 30, 2016 and 2015, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2016 and 2015 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2015. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- added (2017-04-24):
[0001069202-17-000005:note_history:8]
Our fiscal year ends on December 31 and each quarter is comprised of approximately 13 weeks but the number of days per quarter may vary year-over-year. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.  The first quarter of 2017 included the benefit of five more days, or 6%, this year than in the first quarter last year.  This balances out on a full-year basis with the fourth quarter having 6% fewer days than a year ago.

- added (2017-04-24):
[0001069202-17-000005:note_history:9]
Recently Adopted Accounting Guidance

- added (2017-04-24):
[0001069202-17-000005:note_history:10]
On March 30, 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations.  This is in comparison to the prior requirement that these excess tax benefits be recognized in additional paid-in capital. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity.

- added (2017-04-24):
[0001069202-17-000005:note_history:11]
We have adopted ASU 2016-09 effective January 1, 2017 on a prospective basis where permitted by the new standard. As a result of this adoption:

- added (2017-04-24):
[0001069202-17-000005:note_history:12]
| • | We recognized discrete tax benefits of $7.4 million in the income taxes line item of our consolidated statement of operations for the three months ended March 31, 2017 related to excess tax benefits upon vesting or settlement in that period. |

- added (2017-04-24):
[0001069202-17-000005:note_history:13]
| • | We elected to adopt the cash flow presentation of the excess tax benefits retrospectively where these benefits are classified along with other income tax cash flows as operating cash flows. |

- added (2017-04-24):
[0001069202-17-000005:note_history:14]
| • | We have elected to continue to estimate the number of stock-based awards expected to vest, rather than electing to account for forfeitures as they occur to determine the amount of compensation cost to be recognized in each period. |

- added (2017-04-24):
[0001069202-17-000005:note_history:15]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the three months ended March 31, 2017. |

- removed (2017-04-24):
[0001069202-16-000024:note_history:16]
Our fiscal year ends on December 31 and each quarter is comprised of approximately13 weeks. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-04-24):
[0001069202-17-000005:note_history:17]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.23 | % |  | 2.00 | % |
  (was, 2016-10-17, similarity 0.95):
[0001069202-16-000024:note_history:17]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.70 | % |  | 1.90 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-04-24):
[0001069202-17-000005:note_history:18]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 200.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.6 |  |  | 2.4 |  |
| Total short-term debt | $ | 201.6 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.7 |  |  | $ | 0.8 |  |
| Domestic credit facility | 7.5 |  |  | — |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 207.6 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.9 |  |  | $ | 15.0 |  |
| Domestic credit facility | 334.0 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (5.0 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 693.9 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,103.1 |  |  | $ | 868.2 |  |
  (was, 2016-10-17, similarity 0.9388):
[0001069202-16-000024:note_history:18]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 325.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 2.8 |  |  | 4.1 |  |
| Total short-term debt | $ | 327.8 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.9 |  |  | $ | 1.2 |  |
| Domestic credit facility | 15.0 |  |  | 30.0 |  |
| Senior unsecured notes | 200.0 |  |  | — |  |
| Debt issuance costs | (0.3 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 215.6 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.1 |  |  | $ | 15.6 |  |
| Domestic credit facility | 500.0 |  |  | 293.0 |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (2.6 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 512.5 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,055.9 |  |  | $ | 741.1 |  |

- changed (2017-04-24):
[0001069202-17-000005:note_history:19]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $1.6 million and $2.4 million of foreign obligations as of March 31, 2017 and December 31, 2016, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.3 million  and $1.2 million during the three months ended March 31, 2017 and 2016, respectively. Repayments on the facilities were $1.1 million and $1.6 million during the three months ended March 31, 2017 and 2016, respectively.
  (was, 2016-10-17, similarity 0.8962):
[0001069202-16-000024:note_history:19]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $2.8 million and $4.1 million of foreign obligations as of September 30, 2016 and December 31, 2015, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $28.2 million  and $63.6 million during the nine months ended September 30, 2016 and 2015, respectively. Repayments on the facilities were $30.3 million and $61.7 million during the nine months ended September 30, 2016 and 2015, respectively.

- changed (2017-04-24):
[0001069202-17-000005:note_history:20]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.
  (was, 2016-10-17, similarity 0.958):
[0001069202-16-000024:note_history:20]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP matures in November 2017 and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

- changed (2017-04-24):
[0001069202-17-000005:note_history:21]
The ASP provides for a maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):
  (was, 2016-10-17, similarity 0.8282):
[0001069202-16-000024:note_history:21]
Prior to the amendment in July 2016, the ASP provided for a maximum securitization amount ranging from $180.0 million to $220.0 million, depending on the period.  The ASP was amended effective as of July 5, 2016 to increase the maximum securitization range from $200.0 million to $325.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- added (2017-04-24):
[0001069202-17-000005:note_history:22]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 200.0 |  |  | $ | 250.0 |  |
| Beneficial interest sold | 200.0 |  |  | 50.0 |  |
| Remaining amount available | $ | — |  |  | $ | 200.0 |  |

- changed (2017-04-24):
[0001069202-17-000005:note_history:23]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on floating commercial paper rates determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rates for March 31, 2017 and December 31, 2016 were 1.70% and 1.66%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2016-10-17, similarity 0.9391):
[0001069202-16-000024:note_history:23]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.65%. The average rate for September 30, 2016 and December 31, 2015 was 1.49% and 1.06% respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and is calculated at a 0.33% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $200 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2017-04-24):
[0001069202-17-000005:note_history:24]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of  March 31, 2017, we believe we were in compliance with all covenant requirements.
  (was, 2016-10-17, similarity 0.968):
[0001069202-16-000024:note_history:24]
The ASP contains certain restrictive qualifications relating to the quality of our accounts receivable and certain cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2016, we believe we were in compliance with all covenant requirements.

- changed (2017-04-24):
[0001069202-17-000005:note_history:25]
On August 30, 2016, we replaced an earlier $950.0 million credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $341.5 million, of which $220.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of March 31, 2017. Subject to covenant limitations, $524.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million; however, we made $30.0 million of required principal repayments for 2017 in November 2016. The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.
  (was, 2016-10-17, similarity 0.6161):
[0001069202-16-000024:note_history:25]
On August 30, 2016, we replaced an earlier $950.0 million credit facility with a $900.0 million credit facility (the "Domestic Credit Facility"), which consisted of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $515.0 million, of which $250.0 million was the term loan balance, as well as $4.4 million committed to standby letters of credit as of September 30, 2016. Subject to covenant limitations, $380.6 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million beginning in March 2017.  The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2017-04-24):
[0001069202-17-000005:note_history:26]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Weighted average borrowing rate | 2.23 | % |  | 2.00 | % |
  (was, 2016-10-17, similarity 0.95):
[0001069202-16-000024:note_history:26]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Weighted average borrowing rate | 1.70 | % |  | 1.90 | % |

- changed (2017-04-24):
[0001069202-17-000005:note_history:27]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2017, we believe we were in compliance with all covenant requirements.
  (was, 2016-10-17, similarity 0.9931):
[0001069202-16-000024:note_history:27]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2016, we believe we were in compliance with all covenant requirements.

- added (2017-04-24):
[0001069202-17-000005:note_history:28]
We issued $350.0 million of senior unsecured notes in November 2016 (the "2016 Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also have $200.0 million of senior unsecured notes issued in 2010 (the "2010 Notes") which will mature on  May 15, 2017  with interest being paid at 4.90%   per annum semiannually. Both Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and, in the case of the 2010 Notes, transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of  March 31, 2017, we believe we were in compliance with all covenant requirements.

- removed (2017-04-24):
[0001069202-16-000024:note_history:29]
In April 2015, the FASB issued ASU No. 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. We adopted this guidance in the first quarter of 2016 and have reclassified the unamortized debt issuance costs into the debt liability as shown in the table above.

- removed (2017-04-24):
[0001069202-16-000024:note_history:30]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 325.0 |  |  | $ | 220.0 |  |
| Beneficial interest sold | 325.0 |  |  | 200.0 |  |
| Remaining amount available | $ | — |  |  | $ | 20.0 |  |

- removed (2017-04-24):
[0001069202-16-000024:note_history:31]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2016, we believe we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-04-24):
[0001069202-17-000005:note_history:32]
|  | As of March 31, 2017 |  | As of December 31, 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 200.0 |  |  | $ | 50.0 |  |
| Foreign obligations | 1.6 |  |  | 2.4 |  |
| Total short-term debt | $ | 201.6 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.7 |  |  | $ | 0.8 |  |
| Domestic credit facility | 7.5 |  |  | — |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 207.6 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 14.9 |  |  | $ | 15.0 |  |
| Domestic credit facility | 334.0 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (5.0 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 693.9 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,103.1 |  |  | $ | 868.2 |  |
  (was, 2016-10-17, similarity 0.9388):
[0001069202-16-000024:note_history:32]
|  | As of September 30, 2016 |  | As of December 31, 2015 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 325.0 |  |  | $ | 200.0 |  |
| Foreign obligations | 2.8 |  |  | 4.1 |  |
| Total short-term debt | $ | 327.8 |  |  | $ | 204.1 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.9 |  |  | $ | 1.2 |  |
| Domestic credit facility | 15.0 |  |  | 30.0 |  |
| Senior unsecured notes | 200.0 |  |  | — |  |
| Debt issuance costs | (0.3 | ) |  | (0.2 | ) |
| Total current maturities of long-term debt | $ | 215.6 |  |  | $ | 31.0 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.1 |  |  | $ | 15.6 |  |
| Domestic credit facility | 500.0 |  |  | 293.0 |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (2.6 | ) |  | (2.6 | ) |
| Total long-term debt | $ | 512.5 |  |  | $ | 506.0 |  |
| Total debt | $ | 1,055.9 |  |  | $ | 741.1 |  |
