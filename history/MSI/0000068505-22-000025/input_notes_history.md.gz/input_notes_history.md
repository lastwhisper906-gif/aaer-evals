# MSI note change history — 0000068505-22-000019 → 0000068505-22-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000068505-22-000025:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for not making the royalty payment.
  (was, 2022-05-12, similarity 0.728):
[0000068505-22-000019:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  The Court also ordered the parties to jointly file by February 22, 2022, a proposed royalty agreement for the Court's review and approval. Because the parties could not concur on the royalty agreement, they each filed supporting papers for their proposed draft agreements, and on April 12, 2022, the Court issued a ruling generally favorable to the Company on the critical aspects of the royalty agreement. On April 19, 2022, the parties filed an agreed royalty agreement that incorporates the findings of the Court's ruling.

- changed (2022-08-04):
[0000068505-22-000025:note_history:2]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.
  (was, 2022-05-12, similarity 0.6484):
[0000068505-22-000019:note_history:2]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief. On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

- added (2022-08-04):
[0000068505-22-000025:note_history:3]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions due to ongoing appeals in the case.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000068505-22-000025:note_history:4]
Basis of Presentation
The condensed consolidated financial statements as of July 2, 2022 and for the three and six months ended July 2, 2022 and July 3, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2022-05-12, similarity 0.9461):
[0000068505-22-000019:note_history:4]
Basis of Presentation
The condensed consolidated financial statements as of April 2, 2022 and for the three months ended April 2, 2022 and April 3, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2022-08-04):
[0000068505-22-000025:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three and six months ended July 2, 2022 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2022-05-12, similarity 0.8167):
[0000068505-22-000019:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three months ended April 2, 2022 are not necessarily indicative of the operating results to be expected for the full year.

- added (2022-08-04):
[0000068505-22-000025:note_history:6]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center Software.

- changed (2022-08-04):
[0000068505-22-000025:note_history:7]
On May 12, 2022, the Company acquired Videotec S.p.A. ("Videotec"), a global provider of ruggedized video security solutions, for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of the Products and Systems Integration segment.
  (was, 2022-05-12, similarity 0.8805):
[0000068505-22-000019:note_history:7]
Subsequent to quarter end, on May 12, 2022, the Company acquired Videotec S.p.A. ("Videotec"), a global provider of ruggedized video security solutions, for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- changed (2022-08-04):
[0000068505-22-000025:note_history:8]
On April 19, 2022, the Company acquired Calipsa, Inc. ("Calipsa"), a technology leader in cloud-native advanced video analytics, for $40 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.
  (was, 2022-05-12, similarity 0.9774):
[0000068505-22-000019:note_history:8]
Subsequent to quarter end, on April 19, 2022, the Company acquired Calipsa, Inc. ("Calipsa"), a technology leader in cloud-native advanced video analytics, for $40 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.

- changed (2022-08-04):
[0000068505-22-000025:note_history:9]
On October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy to be a global leader in end-to-end video security solutions within Video. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.
  (was, 2022-05-12, similarity 0.9778):
[0000068505-22-000019:note_history:9]
On October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy to be a global leader in end-to-end video security solutions within Video Security and Access Control. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- changed (2022-08-04):
[0000068505-22-000025:note_history:10]
On July 15, 2021, the Company acquired Openpath Security Inc. ("Openpath"), a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.
  (was, 2022-05-12, similarity 0.9823):
[0000068505-22-000019:note_history:10]
On July 15, 2021, the Company acquired Openpath Security Inc. ("Openpath"), a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- changed (2022-08-04):
[0000068505-22-000025:note_history:11]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the Senior Convertible Notes on diluted earnings per common share.
  (was, 2022-05-12, similarity 0.998):
[0000068505-22-000019:note_history:11]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the convertible notes on diluted earnings per common share.

- changed (2022-08-04):
[0000068505-22-000025:note_history:12]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, "which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.
  (was, 2022-05-12, similarity 0.9929):
[0000068505-22-000019:note_history:12]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, "which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 will result in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

- changed (2022-08-04):
[0000068505-22-000025:note_history:13]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures that are expected to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU was effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.
  (was, 2022-05-12, similarity 0.6586):
[0000068505-22-000019:note_history:13]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures that are expected to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.

- removed (2022-08-04):
[0000068505-22-000019:note_history:14]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control, and Command Center Software. In January 2022 the Company renamed one of its three major products and services technologies from LMR Mission Critical Communications to LMR Communications in an effort to more succinctly brand its LMR technology. The change was to the name of the technology only and no financial information was reclassified from previous periods presented or for the quarter ended April 2, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-08-04):
[0000068505-22-000025:note_history:15]
Debt and Credit Facilities

- added (2022-08-04):
[0000068505-22-000025:note_history:16]
|  | July 2, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 2 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (2) |  |  | (5) |  |
| Long-term debt | $ | 6,011 |  |  | $ | 5,688 |  |

- added (2022-08-04):
[0000068505-22-000025:note_history:17]
On May 31, 2022, the Company issued $600 million of 5.6% senior notes due 2032. The Company recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

- changed (2022-08-04):
[0000068505-22-000025:note_history:18]
As of July 2, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 2, 2022.
  (was, 2022-05-12, similarity 0.9737):
[0000068505-22-000019:note_history:18]
Debt and Credit Facilities
As of April 2, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 2, 2022.

- changed (2022-08-04):
[0000068505-22-000025:note_history:19]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 2, 2022 the Company had no outstanding debt under the commercial paper program.
  (was, 2022-05-12, similarity 0.9934):
[0000068505-22-000019:note_history:19]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 2, 2022 the Company had no outstanding debt under the commercial paper program.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-08-04):
[0000068505-22-000025:note_history:20]
|  | July 2, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 2 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (2) |  |  | (5) |  |
| Long-term debt | $ | 6,011 |  |  | $ | 5,688 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000068505-22-000025:note_history:21]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 2, 2022 and July 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2022-05-12, similarity 0.9282):
[0000068505-22-000019:note_history:21]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 2, 2022 and April 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2022-08-04):
[0000068505-22-000025:note_history:22]
|  | Three Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |  | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |
| International | 322 |  |  | 334 |  |  | 656 |  |  | 329 |  |  | 330 |  |  | 659 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |  | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |
| Video Security and Access Control | 247 |  |  | 123 |  |  | 370 |  |  | 212 |  |  | 94 |  |  | 306 |  |
| Command Center Software | — |  |  | 162 |  |  | 162 |  |  | — |  |  | 134 |  |  | 134 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |  | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |
| Indirect | 574 |  |  | 77 |  |  | 651 |  |  | 492 |  |  | 67 |  |  | 559 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
  (was, 2022-05-12, similarity 0.9856):
[0000068505-22-000019:note_history:22]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |  | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |
| International | 272 |  |  | 315 |  |  | 587 |  |  | 273 |  |  | 315 |  |  | 588 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |  | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |
| Video Security and Access Control | 194 |  |  | 113 |  |  | 307 |  |  | 165 |  |  | 88 |  |  | 253 |  |
| Command Center Software | — |  |  | 130 |  |  | 130 |  |  | — |  |  | 119 |  |  | 119 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |  | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |
| Indirect | 447 |  |  | 87 |  |  | 534 |  |  | 411 |  |  | 68 |  |  | 479 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |

- added (2022-08-04):
[0000068505-22-000025:note_history:23]
|  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |  | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |
| International | 594 |  |  | 650 |  |  | 1,244 |  |  | 602 |  |  | 645 |  |  | 1,247 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |  | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |
| Video Security and Access Control | 441 |  |  | 236 |  |  | 677 |  |  | 377 |  |  | 182 |  |  | 559 |  |
| Command Center Software | — |  |  | 292 |  |  | 292 |  |  | — |  |  | 254 |  |  | 254 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |  | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |
| Indirect | 1,021 |  |  | 164 |  |  | 1,185 |  |  | 903 |  |  | 135 |  |  | 1,038 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000068505-22-000025:note_history:24]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 2, 2022 and July 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2022-05-12, similarity 0.9282):
[0000068505-22-000019:note_history:24]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 2, 2022 and April 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2022-08-04):
[0000068505-22-000025:note_history:25]
|  | Three Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |  | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |
| International | 322 |  |  | 334 |  |  | 656 |  |  | 329 |  |  | 330 |  |  | 659 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |  | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |
| Video Security and Access Control | 247 |  |  | 123 |  |  | 370 |  |  | 212 |  |  | 94 |  |  | 306 |  |
| Command Center Software | — |  |  | 162 |  |  | 162 |  |  | — |  |  | 134 |  |  | 134 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |  | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |
| Indirect | 574 |  |  | 77 |  |  | 651 |  |  | 492 |  |  | 67 |  |  | 559 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
  (was, 2022-05-12, similarity 0.9856):
[0000068505-22-000019:note_history:25]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |  | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |
| International | 272 |  |  | 315 |  |  | 587 |  |  | 273 |  |  | 315 |  |  | 588 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |  | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |
| Video Security and Access Control | 194 |  |  | 113 |  |  | 307 |  |  | 165 |  |  | 88 |  |  | 253 |  |
| Command Center Software | — |  |  | 130 |  |  | 130 |  |  | — |  |  | 119 |  |  | 119 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |  | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |
| Indirect | 447 |  |  | 87 |  |  | 534 |  |  | 411 |  |  | 68 |  |  | 479 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |

- added (2022-08-04):
[0000068505-22-000025:note_history:26]
|  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |  | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |
| International | 594 |  |  | 650 |  |  | 1,244 |  |  | 602 |  |  | 645 |  |  | 1,247 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |  | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |
| Video Security and Access Control | 441 |  |  | 236 |  |  | 677 |  |  | 377 |  |  | 182 |  |  | 559 |  |
| Command Center Software | — |  |  | 292 |  |  | 292 |  |  | — |  |  | 254 |  |  | 254 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |  | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |
| Indirect | 1,021 |  |  | 164 |  |  | 1,185 |  |  | 903 |  |  | 135 |  |  | 1,038 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |

- changed (2022-08-04):
[0000068505-22-000025:note_history:27]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 2, 2022 was $9.0 billion. A total of $4.3 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of July 2, 2022, of which $2.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.7 billion was from Software and Services performance obligations that were not yet satisfied as of July 2, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2022-05-12, similarity 0.9906):
[0000068505-22-000019:note_history:27]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 2, 2022 was $9.0 billion. A total of $4.1 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of April 2, 2022, of which $2.5 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.9 billion was from Software and Services performance obligations that were not yet satisfied as of April 2, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2022-08-04):
[0000068505-22-000025:note_history:28]
| (In millions) | July 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,284 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 1,045 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,556 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 308 |  |  | 306 |  |  |  |  |  |
  (was, 2022-05-12, similarity 0.6514):
[0000068505-22-000019:note_history:28]
| (In millions) | April 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 39 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 118 |  |  | 124 |  |  |  |  |  |

- added (2022-08-04):
[0000068505-22-000025:note_history:29]
Revenue recognized during the three months ended July 2, 2022 which was previously included in Contract liabilities as of April 2, 2022 was $456 million, compared to $483 million of revenue recognized during the three months ended July 3, 2021 which was previously included in Contract liabilities as of April 3, 2021. Revenue recognized during the six months ended July 2, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $712 million, compared to $705 million recognized during the six months ended July 3, 2021 which was previously included in Contract liabilities as of December 31, 2020. The Company did not reverse any revenue during the three months ended July 2, 2022 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $10 million of reversals for the three months ended July 3, 2021, primarily driven by changes in the estimates of progress on system contracts, Revenue of $22 million was reversed during the six months ended July 2, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million of reversals for the six months ended July 3, 2021.

- changed (2022-08-04):
[0000068505-22-000025:note_history:30]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 2, 2022 and July 3, 2021.
  (was, 2022-05-12, similarity 0.9203):
[0000068505-22-000019:note_history:30]
There were no material expected credit losses recorded on contract assets during each of the three months ended April 2, 2022 and April 3, 2021.

- added (2022-08-04):
[0000068505-22-000025:note_history:31]
| (In millions) | July 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 39 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 118 |  |  | 124 |  |  |  |  |  |

- changed (2022-08-04):
[0000068505-22-000025:note_history:32]
Amortization of non-current contract cost assets was $13 million and $26 million for the three and six months ended July 2, 2022, respectively, and $12 million and $25 million for the three and six months ended July 3, 2021, respectively
  (was, 2022-05-12, similarity 0.6203):
[0000068505-22-000019:note_history:32]
Amortization of non-current contract cost assets was $13 million for each of the three months ended April 2, 2022 and April 3, 2021

- removed (2022-08-04):
[0000068505-22-000019:note_history:33]
| (In millions) | April 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,151 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 999 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,590 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 299 |  |  | 306 |  |  |  |  |  |

- removed (2022-08-04):
[0000068505-22-000019:note_history:34]
Revenue recognized during the three months ended April 2, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $456 million, compared to $396 million of revenue recognized during the three months ended April 3, 2021 which was previously included in Contract liabilities as of December 31, 2020. Revenue of $17 million was reversed during the three months ended April 2, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $4 million of reversals for the three months ended April 3, 2021.
