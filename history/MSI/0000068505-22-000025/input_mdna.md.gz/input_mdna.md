# MSI MD&A — 0000068505-22-000025


## mdna

[0000068505-22-000025:mdna:1]
[same as prior period, unchanged from 0000068505-22-000019:mdna:1]

[0000068505-22-000025:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and six months ended July 2, 2022 and July 3, 2021, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2021 (the "Form 10-K").

[0000068505-22-000025:mdna:3]
[same as prior period, unchanged from 0000068505-22-000019:mdna:3]

[0000068505-22-000025:mdna:4]
[same as prior period, unchanged from 0000068505-22-000019:mdna:4]

[0000068505-22-000025:mdna:5]
[same as prior period, unchanged from 0000068505-22-000019:mdna:5]

[0000068505-22-000025:mdna:6]
The Company reports net sales in the following three major products and services (which we refer to as “technologies” in this Form 10-Q): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video") and Command Center Software.

[0000068505-22-000025:mdna:7]
[same as prior period, unchanged from 0000068505-22-000019:mdna:7]

[0000068505-22-000025:mdna:8]
[same as prior period, unchanged from 0000068505-22-000019:mdna:8]

[0000068505-22-000025:mdna:9]
[same as prior period, unchanged from 0000068505-22-000019:mdna:9]

[0000068505-22-000025:mdna:10]
Second Quarter Financial Results

[0000068505-22-000025:mdna:11]
•Net sales were $2.1 billion in the second quarter of 2022 compared to $2.0 billion in the second quarter of 2021.

[0000068505-22-000025:mdna:12]
•Operating earnings were $358 million in the second quarter of 2022 compared to $370 million in the second quarter of 2021.

[0000068505-22-000025:mdna:13]
•Net earnings attributable to Motorola Solutions, Inc. were $228 million, or $1.33 per diluted common share, in the second quarter of 2022, compared to $293 million, or $1.69 per diluted common share, in the second quarter of 2021.

[0000068505-22-000025:mdna:14]
•Operating cash flow decreased $596 million to $162 million in the first half of 2022 compared to $758 million in the first half of 2021.

[0000068505-22-000025:mdna:15]
•We repurchased $655 million of common stock and paid $266 million in dividends in the first half of 2022.

[0000068505-22-000025:mdna:16]
[same as prior period, unchanged from 0000068505-22-000019:mdna:16]

[0000068505-22-000025:mdna:17]
Recent macroeconomic events impacting our business are discussed below. During the second quarter of 2022, we continued to operate under challenging market conditions, influenced by events such as the Russia-Ukraine conflict, the continuing impact of the COVID-19 pandemic, disruption to our supply chain and the inflationary cost environment.

[0000068505-22-000025:mdna:18]
[same as prior period, unchanged from 0000068505-22-000019:mdna:18]

[0000068505-22-000025:mdna:19]
During the first quarter of 2022, in response to Russia's invasion of Ukraine, we suspended all sales, provision of services and shipments of our products to Russia and Belarus. Russia, Ukraine and Belarus do not constitute a material portion of our business. For the year ended December 31, 2021, our net sales in Russia and Belarus were less than $25 million. While we do not anticipate that the current posture of the Russia-Ukraine conflict will materially and adversely affect our results of operations, the conflict is still ongoing and future impacts are difficult to estimate. An escalation of the conflict’s current scope or expansion of the conflict’s economic disruption could materially and adversely affect our company and its operations. During the first half of 2022, we indirectly experienced impacts from the Russia-Ukraine conflict (as further described below). The conflict has and may continue to have a significant impact on the global macroeconomic and geopolitical environments, including increased volatility in capital and commodity markets, rapid changes to regulatory conditions (including the use of sanctions), supply chain and operational challenges for multinational corporations, inflationary pressures and an increased risk of cybersecurity incidents. For a more complete discussion of the risks we encounter in our business, please refer to Part I, Item 1A, "Risk Factors" in the Form 10-K and Part II, Item 1A, "Risk Factors" in this Form 10-Q.

[0000068505-22-000025:mdna:20]
[same as prior period, unchanged from 0000068505-22-000019:mdna:20]

[0000068505-22-000025:mdna:21]
As we have progressed throughout the first half of 2022, our supply chain has been impacted by global issues related to the effects of the COVID-19 pandemic, the Russia-Ukraine conflict and the inflationary cost environment, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity and labor constraints. This has resulted in disruptions in our supply chain, as well as difficulties and delays in procuring certain semiconductor components. Since the latter part of the fourth quarter of 2021, cost increases have been driven by elevated lead times and increased material costs, in particular the need to purchase semiconductor components from alternative sources, including brokers. We anticipate increased costs to procure materials within the semiconductor market to continue throughout 2022. Further, we anticipate the broader impact of inflationary pressures and increased material and supply chain costs and disruptions to continue throughout 2022. We are closely monitoring our supply chain, including impacts from manufacturing lockdowns related to the spread of COVID-19 in China which continue to disrupt the semiconductor supply market. Accordingly, in the first half of 2022 we focused on improving our supplier network, engineering alternative designs and working to reduce supply shortages. We are actively managing our inventory in an effort to minimize supply chain disruptions and enable continuity of supply and services to our customers, and we expect to maintain elevated levels of inventory until supply constraints have been remediated.

[0000068505-22-000025:mdna:22]
In order to combat rising inflation in the U.S., the Federal Reserve has raised interest rates multiple times since the beginning of 2022. The increase in U.S. dollar interest rates and overall market conditions have led to significant strengthening of the U.S. dollar against other global currencies in 2022. The strong U.S. dollar reduced the impact of cash generated from our foreign operations during the first half of 2022, driven by revenues and costs that are denominated in foreign currencies, which has impacted, and which we expect to continue to impact, our operating cash flows and net earnings throughout 2022.

[0000068505-22-000025:mdna:23]
Although the macroeconomic environment continued to introduce challenges in the first half of 2022, we are encouraged by customer demand for our products and services. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impact to operating margin will be limited throughout 2022. While we are encouraged by strong backlog and growth in our Products and Systems Integration segment in the first half of 2022, which we expect to continue to grow for the remainder of 2022, supply constraints continue to impact our business and we expect demand for our products will continue to out-pace our ability to obtain semiconductor component supply throughout 2022. Where appropriate, we have taken pricing actions around our product and service offerings to mitigate our exposure to inflationary pressures on our businesses and expect to benefit from these adjustments in the second half of 2022. Further, demand continues to be supported with ongoing sources of government funding. In March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. We experienced the positive impact of the ARPA funding on our business and results of operations during the first half of 2022 and anticipate that the ARPA will continue to have a positive impact throughout the remainder of 2022.

[0000068505-22-000025:mdna:24]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of July 2, 2022. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-22-000025:mdna:25]
Lastly, we evaluated whether there were any impairment indicators as of July 2, 2022, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the second quarter of 2022, we concluded our assets were fairly stated and recoverable.

[0000068505-22-000025:mdna:26]
[same as prior period, unchanged from 0000068505-22-000019:mdna:26]

[0000068505-22-000025:mdna:27]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Video Security and Access Control | Products and Systems Integration | Videotec S.p.A. | Provider of ruggedized video security solutions. | $22 million and share-based compensation of $4 million | May 12, 2022 |
| Video Security and Access Control | Software and Services | Calipsa, Inc. | Provider of cloud-native advanced video analytics. | $40 million and share-based compensation of $4 million | April 19, 2022 |
| LMR Communications | Software and Services | TETRA Ireland Communications Limited | Provider of Ireland's National Digital Radio Service. | $120 million | March 23, 2022 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Ava Security Limited | Provider of cloud-native video security and analytics. | $388 million and share-based awards of $7 million | March 3, 2022 |
| Command Center Software | Software and Services | 911 Datamaster, Inc. | Provider of Next Generation 911 data solutions that help to ensure emergency calls are accurately located and routed based on the caller's location. | $35 million and share-based compensation of $3 million | December 16, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Envysion, Inc. | Provider of enterprise video security and business analytics. | $124 million and share-based compensation of $1 million | October 29, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Openpath Security, Inc. | Provider of cloud-based mobile access control. | $298 million and share-based compensation of $29 million | July 15, 2021 |

[0000068505-22-000025:mdna:28]
[same as prior period, unchanged from 0000068505-22-000019:mdna:32]

[0000068505-22-000025:mdna:29]
[same as prior period, unchanged from 0000068505-22-000019:mdna:29]

[0000068505-22-000025:mdna:30]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | July 2, 2022 |  | % ofSales* |  | July 3, 2021 |  | % ofSales* |  | July 2, 2022 |  | % ofSales* |  | July 3, 2021 |  | % ofSales* |
| Net sales from products | $ | 1,212 |  |  |  |  | $ | 1,094 |  |  |  |  | $ | 2,258 |  |  |  |  | $ | 2,027 |  |  |  |
| Net sales from services | 928 |  |  |  |  | 877 |  |  |  |  | 1,774 |  |  |  |  | 1,717 |  |  |  |
| Net sales | 2,140 |  |  |  |  | 1,971 |  |  |  |  | 4,032 |  |  |  |  | 3,744 |  |  |  |
| Costs of products sales | 637 |  |  | 52.6 | % |  | 511 |  |  | 46.7 | % |  | 1,185 |  |  | 52.5 | % |  | 952 |  |  | 47.0 | % |
| Costs of services sales | 513 |  |  | 55.3 | % |  | 508 |  |  | 57.9 | % |  | 1,001 |  |  | 56.4 | % |  | 980 |  |  | 57.1 | % |
| Costs of sales | 1,150 |  |  |  |  | 1,019 |  |  |  |  | 2,186 |  |  |  |  | 1,932 |  |  |  |
| Gross margin | 990 |  |  | 46.3 | % |  | 952 |  |  | 48.3 | % |  | 1,846 |  |  | 45.8 | % |  | 1,812 |  |  | 48.4 | % |
| Selling, general and administrative expenses | 356 |  |  | 16.6 | % |  | 331 |  |  | 16.8 | % |  | 692 |  |  | 17.2 | % |  | 633 |  |  | 16.9 | % |
| Research and development expenditures | 191 |  |  | 8.9 | % |  | 181 |  |  | 9.2 | % |  | 380 |  |  | 9.4 | % |  | 361 |  |  | 9.6 | % |
| Other charges | 85 |  |  | 4.0 | % |  | 70 |  |  | 3.5 | % |  | 177 |  |  | 4.4 | % |  | 150 |  |  | 4.0 | % |
| Operating earnings | 358 |  |  | 16.7 | % |  | 370 |  |  | 18.8 | % |  | 597 |  |  | 14.8 | % |  | 668 |  |  | 17.8 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (56) |  |  | (2.6) | % |  | (44) |  |  | (2.2) | % |  | (112) |  |  | (2.8) | % |  | (98) |  |  | (2.6) | % |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | — |  |  | — | % |  | 2 |  |  | — | % |  | — |  |  | — | % |
| Other, net | (2) |  |  | (0.1) | % |  | 14 |  |  | 0.7 | % |  | 33 |  |  | 0.8 | % |  | 60 |  |  | 1.6 | % |
| Total other expense | (58) |  |  | (2.7) | % |  | (30) |  |  | (1.5) | % |  | (77) |  |  | (1.9) | % |  | (38) |  |  | (1.0) | % |
| Net earnings before income taxes | 300 |  |  | 14.0 | % |  | 340 |  |  | 17.3 | % |  | 520 |  |  | 12.9 | % |  | 630 |  |  | 16.8 | % |
| Income tax expense | 71 |  |  | 3.3 | % |  | 46 |  |  | 2.3 | % |  | 23 |  |  | 0.6 | % |  | 90 |  |  | 2.4 | % |
| Net earnings | 229 |  |  | 10.7 | % |  | 294 |  |  | 14.9 | % |  | 497 |  |  | 12.3 | % |  | 540 |  |  | 14.4 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | — | % |  | 1 |  |  | 0.1 | % |  | 2 |  |  | — | % |  | 3 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 228 |  |  | 10.7 | % |  | $ | 293 |  |  | 14.9 | % |  | $ | 495 |  |  | 12.3 | % |  | $ | 537 |  |  | 14.3 | % |
| Earnings per diluted common share | $ | 1.33 |  |  |  |  | $ | 1.69 |  |  |  |  | $ | 2.88 |  |  |  |  | $ | 3.10 |  |  |  |

[0000068505-22-000025:mdna:31]
[same as prior period, unchanged from 0000068505-22-000019:mdna:31]

[0000068505-22-000025:mdna:32]
30

[0000068505-22-000025:mdna:33]
Results of Operations—Three months ended July 2, 2022 compared to three months ended July 3, 2021

[0000068505-22-000025:mdna:34]
The results of operations for the second quarter of 2022 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-22-000025:mdna:35]
[same as prior period, unchanged from 0000068505-22-000019:mdna:35]

[0000068505-22-000025:mdna:36]
[same as prior period, unchanged from 0000068505-22-000019:mdna:36]

[0000068505-22-000025:mdna:37]
[same as prior period, unchanged from 0000068505-22-000019:mdna:37]

[0000068505-22-000025:mdna:38]
[same as prior period, unchanged from 0000068505-22-000019:mdna:38]

[0000068505-22-000025:mdna:39]
[same as prior period, unchanged from 0000068505-22-000019:mdna:39]

[0000068505-22-000025:mdna:40]
|  | Three Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |  | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |
| International | 322 |  |  | 334 |  |  | 656 |  |  | 329 |  |  | 330 |  |  | 659 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |  | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |
| Video Security and Access Control | 247 |  |  | 123 |  |  | 370 |  |  | 212 |  |  | 94 |  |  | 306 |  |
| Command Center Software | — |  |  | 162 |  |  | 162 |  |  | — |  |  | 134 |  |  | 134 |  |
| Total | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Operating earnings | $ | 118 |  |  | $ | 240 |  |  | $ | 358 |  |  | $ | 139 |  |  | $ | 231 |  |  | $ | 370 |  |
| Operating margins | 9.2 | % |  | 28.1 | % |  | 16.7 | % |  | 11.6 | % |  | 29.9 | % |  | 18.8 | % |

[0000068505-22-000025:mdna:41]
[same as prior period, unchanged from 0000068505-22-000019:mdna:41]

[0000068505-22-000025:mdna:42]
The Products and Systems Integration segment’s net sales represented 60% of our net sales in the second quarter of 2022 and 61% in the second quarter of 2021. The Software and Services segment’s net sales represented 40% of our net sales in the second quarter of 2022 and 39% in the second quarter of 2021.

[0000068505-22-000025:mdna:43]
Net sales increased $169 million, or 9%, in the second quarter of 2022 compared to the second quarter of 2021. The $87 million, or 7%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 11% in the North America region, partially offset by a decrease of 2% in the International region. The $82 million, or 11%, increase in net sales within the Software and Services segment was driven by an increase of 18% in the North America region and an increase of 1% in the International region. Net sales includes:

[0000068505-22-000025:mdna:44]
•an increase in the Products and Systems Integration segment, inclusive of $14 million of revenue from acquisitions, driven by an increase in LMR and Video; and

[0000068505-22-000025:mdna:45]
•an increase in the Software and Services segment, inclusive of $20 million of revenue from acquisitions, driven by an increase in Video, Command Center Software and LMR services; partially offset by

[0000068505-22-000025:mdna:46]
•$44 million from unfavorable currency rates.

[0000068505-22-000025:mdna:47]
[same as prior period, unchanged from 0000068505-22-000019:mdna:47]

[0000068505-22-000025:mdna:48]
•a 13% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center Software; and

[0000068505-22-000025:mdna:49]
•consistent net sales in the International region, inclusive of revenue from acquisitions, on growth in Video and Command Center Software net sales, partially offset by a slight decline in LMR due to unfavorable currency rates.

[0000068505-22-000025:mdna:50]
[same as prior period, unchanged from 0000068505-22-000019:mdna:50]

[0000068505-22-000025:mdna:51]
The 7% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-22-000025:mdna:52]
•$52 million, or 5% growth in LMR, driven by the North America region; and

[0000068505-22-000025:mdna:53]
•$35 million, or 17% growth in Video, inclusive of revenue from acquisitions, driven by the North America region; partially offset by

[0000068505-22-000025:mdna:54]
•$19 million from unfavorable currency rates.

[0000068505-22-000025:mdna:55]
[same as prior period, unchanged from 0000068505-22-000019:mdna:55]

[0000068505-22-000025:mdna:56]
The 11% increase in the Software and Services segment was driven by the following:

[0000068505-22-000025:mdna:57]
•$29 million, or 31% growth in Video, inclusive of revenue from acquisitions, driven primarily by the North America region;

[0000068505-22-000025:mdna:58]
•$28 million, or 21% growth in Command Center Software, inclusive of revenue from acquisitions, driven by the North America region; and

[0000068505-22-000025:mdna:59]
•$25 million, or 5% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America region; partially offset by

[0000068505-22-000025:mdna:60]
•$25 million from unfavorable currency rates.

[0000068505-22-000025:mdna:61]
[same as prior period, unchanged from 0000068505-22-000019:mdna:61]

[0000068505-22-000025:mdna:62]
|  | Three Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |  | % Change |
| Gross margin | $ | 990 |  |  | $ | 952 |  |  | 4 | % |

[0000068505-22-000025:mdna:63]
Gross margin was 46.3% of net sales in the second quarter of 2022 compared to 48.3% in the second quarter of 2021. The primary drivers of this decrease of gross margin as a percentage of net sales were:

[0000068505-22-000025:mdna:64]
•lower gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by an increase in material and freight costs; and

[0000068505-22-000025:mdna:65]
•lower gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by a change in year-over-year mix.

[0000068505-22-000025:mdna:66]
[same as prior period, unchanged from 0000068505-22-000019:mdna:66]

[0000068505-22-000025:mdna:67]
|  | Three Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |  | % Change |
| Selling, general and administrative expenses | $ | 356 |  |  | $ | 331 |  |  | 8 | % |

[0000068505-22-000025:mdna:68]
SG&A expenses increased 8% in the second quarter of 2022 compared to the second quarter of 2021. The increase in SG&A expenses was primarily due to higher expenses associated with acquired businesses and higher travel expenses. SG&A expenses were 16.6% of net sales in the second quarter of 2022 compared to 16.8% of net sales in the second quarter of 2021.

[0000068505-22-000025:mdna:69]
[same as prior period, unchanged from 0000068505-22-000019:mdna:69]

[0000068505-22-000025:mdna:70]
|  | Three Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |  | % Change |
| Research and development expenditures | $ | 191 |  |  | $ | 181 |  |  | 6 | % |

[0000068505-22-000025:mdna:71]
R&D expenditures increased 6% in the second quarter of 2022 compared to the second quarter of 2021 primarily due to higher expenses associated with acquired businesses. R&D expenditures decreased to 8.9% of net sales in the second quarter of 2022 compared to 9.2% of net sales in the second quarter of 2021.

[0000068505-22-000025:mdna:72]
[same as prior period, unchanged from 0000068505-22-000019:mdna:72]

[0000068505-22-000025:mdna:73]
|  | Three Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Other charges | $ | 85 |  |  | $ | 70 |  |

[0000068505-22-000025:mdna:74]
Other charges increased by $15 million in the second quarter of 2022 compared to the second quarter of 2021. The change was driven primarily by the following:

[0000068505-22-000025:mdna:75]
•$8 million of fixed asset impairments in the second quarter of 2022 that did not occur in the second quarter of 2021;

[0000068505-22-000025:mdna:76]
•$65 million of intangible asset amortization expense in the second quarter of 2022 compared to $58 million of intangible asset amortization expense in the second quarter of 2021;

[0000068505-22-000025:mdna:77]
•$3 million of operating lease asset impairments in the second quarter of 2022 that did not occur in the second quarter of 2021; and

[0000068505-22-000025:mdna:78]
•$4 million of acquisition-related transaction fees in the second quarter of 2022 compared to $3 million of acquisition-related transaction fees in the second quarter of 2021; partially offset by

[0000068505-22-000025:mdna:79]
•$3 million of legal settlement charges in the second quarter of 2021 that did not occur in the second quarter of 2022; and

[0000068505-22-000025:mdna:80]
•$5 million of net reorganization of business charges in the second quarter of 2022 compared to $6 million of net reorganization business charges in the second quarter of 2021 (see further detail in the “Reorganization of Business” section in this Part I, Item 2 of this Form 10-Q).

[0000068505-22-000025:mdna:81]
[same as prior period, unchanged from 0000068505-22-000019:mdna:82]

[0000068505-22-000025:mdna:82]
|  | Three Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Operating earnings from Products and Systems Integration | $ | 118 |  |  | $ | 139 |  |
| Operating earnings from Software and Services | 240 |  |  | 231 |  |
| Operating earnings | $ | 358 |  |  | $ | 370 |  |

[0000068505-22-000025:mdna:83]
Operating earnings decreased $12 million, or 3%, in the second quarter of 2022 compared to the second quarter of 2021. The decrease in Operating earnings was due to:

[0000068505-22-000025:mdna:84]
•$21 million decrease in the Products and Systems Integration segment, driven by higher expenses related to material and freight costs and higher expenses associated with acquired businesses, partially offset by higher sales; partially offset by

[0000068505-22-000025:mdna:85]
•$9 million increase in the Software and Services segment, driven by higher sales, partially offset by a change in year-over-year mix and higher expenses associated with acquired businesses.

[0000068505-22-000025:mdna:86]
[same as prior period, unchanged from 0000068505-22-000019:mdna:87]

[0000068505-22-000025:mdna:87]
|  | Three Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Interest expense, net | $ | (56) |  |  | $ | (44) |  |

[0000068505-22-000025:mdna:88]
The $12 million increase in Interest expense, net in the second quarter of 2022 compared to the second quarter of 2021 was primarily driven by the reversal of a non-cash interest accrual related to an international tax audit recorded in the second quarter of 2021 and higher outstanding debt.

[0000068505-22-000025:mdna:89]
[same as prior period, unchanged from 0000068505-22-000019:mdna:90]

[0000068505-22-000025:mdna:90]
|  | Three Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Other, net | $ | (2) |  |  | $ | 14 |  |

[0000068505-22-000025:mdna:91]
The $16 million decrease in Other, net in the second quarter of 2022 compared to the second quarter of 2021 was primarily driven by:

[0000068505-22-000025:mdna:92]
•$34 million loss on derivatives in the second quarter of 2022 compared to a $1 million loss on derivatives in the second quarter of 2021;

[0000068505-22-000025:mdna:93]
•$12 million loss on fair value adjustments to equity investments in the second quarter of 2022 compared to a $8 million gain on fair value adjustments to equity investments in the second quarter of 2021;

[0000068505-22-000025:mdna:94]
•$2 million loss on equity method investments in the second quarter of 2022 compared to a $2 million gain on equity method investments in the second quarter of 2021;

[0000068505-22-000025:mdna:95]
•$5 million loss in other income in the second quarter of 2022 compared to a $2 million loss in other income in the second quarter of 2021; and

[0000068505-22-000025:mdna:96]
•$30 million of net periodic pension and postretirement benefit in the second quarter of 2022 compared to $31 million of net periodic pension and postretirement benefit in the second quarter of 2021; partially offset by

[0000068505-22-000025:mdna:97]
•$27 million of foreign currency gains in the second quarter of 2022 compared to $6 million of foreign currency losses in the second quarter of 2021; and

[0000068505-22-000025:mdna:98]
33

[0000068505-22-000025:mdna:99]
•$6 million loss from the extinguishment of long-term debt in the second quarter of 2022 compared to a $18 million loss from the extinguishment of long-term debt in the second quarter of 2021 (see further detail in Note 5, "Debt and Credit Facilities" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q).

[0000068505-22-000025:mdna:100]
[same as prior period, unchanged from 0000068505-22-000019:mdna:100]

[0000068505-22-000025:mdna:101]
|  | Three Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Income tax expense | $ | 71 |  |  | $ | 46 |  |

[0000068505-22-000025:mdna:102]
Income tax expense increased by $25 million in the second quarter of 2022 compared to the second quarter of 2021, resulting in an effective tax rate of 24%. Our effective tax rate for the three months ended July 2, 2022 of 24% was higher than the effective tax rate for the three months ended July 3, 2021 of 14%, primarily due to a tax benefit related to the partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward in 2021 (see Note 7, "Income Taxes" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q for further information).

[0000068505-22-000025:mdna:103]
Results of Operations—Six months ended July 2, 2022 compared to Six months ended July 3, 2021

[0000068505-22-000025:mdna:104]
|  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |  | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |
| International | 594 |  |  | 650 |  |  | 1,244 |  |  | 602 |  |  | 645 |  |  | 1,247 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |  | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |
| Video Security and Access Control | 441 |  |  | 236 |  |  | 677 |  |  | 377 |  |  | 182 |  |  | 559 |  |
| Command Center Software | — |  |  | 292 |  |  | 292 |  |  | — |  |  | 254 |  |  | 254 |  |
| Total | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Operating earnings | 157 |  |  | 440 |  |  | 597 |  |  | 216 |  |  | 452 |  |  | 668 |  |
| Operating margins | 6.6 | % |  | 26.8 | % |  | 14.8 | % |  | 9.8 | % |  | 29.5 | % |  | 17.8 | % |

[0000068505-22-000025:mdna:105]
Net Sales

[0000068505-22-000025:mdna:106]
The Products and Systems Integration segment's net sales represented 59% of our net sales in both the first half of 2022 and 2021. Net sales from the Software and Services segment represented 41% of our net sales in both the first half of 2022 and 2021.

[0000068505-22-000025:mdna:107]
Net sales increased $288 million, or 8%, in the first half of 2022 compared to the first half of 2021. The $175 million, or 8%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 11% in the North America region, partially offset by a decrease of 1% in the International region. The $113 million, or 7%, increase in net sales within the Software and Services segment was driven by an increase of 12% in the North America region and an increase of 1% in the International region. Net sales includes:

[0000068505-22-000025:mdna:108]
•an increase in the Products and Systems Integration segment, inclusive of $20 million of revenue from acquisitions, driven by an increase in LMR and Video; and

[0000068505-22-000025:mdna:109]
•an increase in Software and Services, inclusive of $31 million of revenue from acquisitions, driven by an increase in Video, Command Center Software and LMR services; partially offset by

[0000068505-22-000025:mdna:110]
•$62 million from unfavorable currency rates.

[0000068505-22-000025:mdna:111]
Regional results include:

[0000068505-22-000025:mdna:112]
•a 12% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center Software; and

[0000068505-22-000025:mdna:113]
•consistent net sales in the International region, inclusive of revenue from acquisitions, driven by an increase in Video and Command Center Software and offset by a decrease in LMR.

[0000068505-22-000025:mdna:114]
Products and Systems Integration

[0000068505-22-000025:mdna:115]
The 8% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-22-000025:mdna:116]
•$111 million, or 6% growth in LMR, driven by the North America region and partially offset by the International region; and

[0000068505-22-000025:mdna:117]
•$64 million, or 17% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions; partially offset by

[0000068505-22-000025:mdna:118]
•$27 million from unfavorable currency rates.

[0000068505-22-000025:mdna:119]
Software and Services

[0000068505-22-000025:mdna:120]
The 7% increase in the Software and Services segment was driven by the following:

[0000068505-22-000025:mdna:121]
•$54 million, or 30% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-22-000025:mdna:122]
•$38 million, or 15% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-22-000025:mdna:123]
•$21 million, or 2% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America region; partially offset by

[0000068505-22-000025:mdna:124]
•$35 million from unfavorable currency rates.

[0000068505-22-000025:mdna:125]
Gross Margin

[0000068505-22-000025:mdna:126]
|  | Six Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |  | % Change |
| Gross margin | $ | 1,846 |  |  | $ | 1,812 |  |  | 2 | % |

[0000068505-22-000025:mdna:127]
Gross margin was 45.8% of net sales in the first half of 2022 compared to 48.4% in the first half of 2021. The primary drivers of this decrease of gross margin as a percentage of net sales were:

[0000068505-22-000025:mdna:128]
•lower gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by an increase in material and freight costs; and

[0000068505-22-000025:mdna:129]
•lower gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by a change in year-over-year mix.

[0000068505-22-000025:mdna:130]
Selling, General and Administrative Expenses

[0000068505-22-000025:mdna:131]
|  | Six Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |  | % Change |
| Selling, general and administrative expenses | $ | 692 |  |  | $ | 633 |  |  | 9 | % |

[0000068505-22-000025:mdna:132]
SG&A expenses increased 9% in the first half of 2022 compared to the first half of 2021. The increase in SG&A expenses was primarily due to higher expenses associated with acquired businesses, higher share-based compensation and higher travel expenses. SG&A expenses were 17.2% of net sales in the first half of 2022 compared to 16.9% of net sales in the first half of 2021.

[0000068505-22-000025:mdna:133]
Research and Development Expenditures

[0000068505-22-000025:mdna:134]
|  | Six Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |  | % Change |
| Research and development expenditures | $ | 380 |  |  | $ | 361 |  |  | 5 | % |

[0000068505-22-000025:mdna:135]
R&D expenditures increased 5% in the first half of 2022 compared to the first half of 2021 primarily due to higher expenses associated with acquired businesses and higher share-based compensation. R&D expenditures decreased to 9.4% of net sales in the first half of 2022 compared to 9.6% of net sales in the first half of 2021.

[0000068505-22-000025:mdna:136]
Other Charges

[0000068505-22-000025:mdna:137]
|  | Six Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Other charges | $ | 177 |  |  | $ | 150 |  |

[0000068505-22-000025:mdna:138]
Other charges increased by $27 million in the first half of 2022 compared to the first half of 2021. The change was driven primarily by the following:

[0000068505-22-000025:mdna:139]
•$131 million of intangible asset amortization expense in the first half of 2022 compared to $116 million of intangible asset amortization expense in the first half of 2021;

[0000068505-22-000025:mdna:140]
•$11 million of fixed asset impairment in the first half of 2022 that did not recur in the first half of 2021.

[0000068505-22-000025:mdna:141]
•$14 million of acquisition-related transaction fees in the first half of 2022 compared to $4 million of acquisition-related transaction fees in the first half of 2021;

[0000068505-22-000025:mdna:142]
•$11 million of losses on legal settlements in the first half of 2022 compared to $3 million of losses on legal settlements in the first half of 2021; and

[0000068505-22-000025:mdna:143]
•$12 million of operating lease asset impairments in the first half of 2022 compared to $7 million of operating lease asset impairments in the first half of 2021; partially offset by

[0000068505-22-000025:mdna:144]
•$13 million gain on recoveries from the legal settlement under the Hytera bankruptcy proceedings in the first half of 2022 (see further detail in "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q); and

[0000068505-22-000025:mdna:145]
•$12 million of net reorganization business charges in the first half of 2022 compared to $20 million of net reorganization business charges in the first half of 2021 (see further detail in the “Reorganization of Business” section in this Part I, Item 2 of this Form 10-Q).

[0000068505-22-000025:mdna:146]
Operating Earnings

[0000068505-22-000025:mdna:147]
|  | Six Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Operating earnings from Products and Systems Integration | $ | 157 |  |  | $ | 216 |  |
| Operating earnings from Software and Services | 440 |  |  | 452 |  |
| Operating earnings | $ | 597 |  |  | $ | 668 |  |

[0000068505-22-000025:mdna:148]
Operating earnings decreased $71 million, or 11%, in the first half of 2022 compared to the first half of 2021. The decrease in Operating earnings was due to:

[0000068505-22-000025:mdna:149]
•$59 million decrease in the Products and Systems Integration segment, primarily driven by lower gross margin contribution, higher expenses related to material and freight costs, higher expenses associated with acquired businesses and higher travel expenses, partially offset by a gain on recoveries related to the legal settlement of the Hytera bankruptcy proceedings in the first half of 2022 (see further detail in "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q) and lower reorganization of business charges; and

[0000068505-22-000025:mdna:150]
•$12 million decrease in the Software and Services segment, primarily driven by higher expenses associated with acquired businesses and a change in year-over-year mix, partially offset by increased net sales.

[0000068505-22-000025:mdna:151]
Interest Expense, net

[0000068505-22-000025:mdna:152]
|  | Six Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Interest expense, net | $ | (112) |  |  | $ | (98) |  |

[0000068505-22-000025:mdna:153]
The $14 million increase in net interest expense in the first half of 2022 compared to the first half of 2021 was a result of the reversal of a non-cash interest accrual related to an international tax audit recorded in the first half of 2021 and higher outstanding debt.

[0000068505-22-000025:mdna:154]
36

[0000068505-22-000025:mdna:155]
Other, net

[0000068505-22-000025:mdna:156]
|  | Six Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Other, net | $ | 33 |  |  | $ | 60 |  |

[0000068505-22-000025:mdna:157]
The $27 million decrease in Other, net in the first half of 2022 compared to the first half of 2021 was primarily driven by:

[0000068505-22-000025:mdna:158]
•$57 million of losses on derivative instruments in the first half of 2022 compared to $9 million of losses on derivative instruments in the first half of 2021;

[0000068505-22-000025:mdna:159]
•$30 million loss on fair value adjustments to equity investments in the first half of 2022 compared to a $13 million gain on fair value adjustments to equity investments in the first half of 2021;

[0000068505-22-000025:mdna:160]
•$5 million loss in other income in the first half of 2022 compared to a $3 million gain in other income in the first half of 2021; and

[0000068505-22-000025:mdna:161]
•$1 million of investment impairment in the first half of 2022 that did not occur in the first half of 2021; partially offset by

[0000068505-22-000025:mdna:162]
•$50 million of foreign currency gains in the first half of 2022 compared to $8 million of foreign currency gains in the first half of 2021;

[0000068505-22-000025:mdna:163]
•$19 million gain on equity method investments in the first half of 2022, driven by a $21 million gain on the TETRA Ireland equity method investment, partially offset by a $2 million loss on equity method investments, compared to a $3 million gain on equity method investments in the second quarter of 2021 (see further detail in "Other Charges" in Note 4, "Other Financial Data" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q);

[0000068505-22-000025:mdna:164]
•$6 million loss on the extinguishment of long-term debt in the first half of 2022 compared to a $18 million loss on the extinguishment of long-term debt in the first half of 2021; and

[0000068505-22-000025:mdna:165]
•$63 million of net periodic pension and postretirement benefit in the first half of 2022 compared to $60 million of net periodic pension and postretirement benefit in the first half of 2021.

[0000068505-22-000025:mdna:166]
Effective Tax Rate

[0000068505-22-000025:mdna:167]
|  | Six Months Ended |
| (In millions) | July 2, 2022 |  | July 3, 2021 |
| Income tax expense | $ | 23 |  |  | $ | 90 |  |

[0000068505-22-000025:mdna:168]
Income tax expense decreased by $67 million in the first half of 2022 compared to the first half of 2021, resulting in an effective tax rate of 4%. Our effective tax rate of 4% for the six months ended July 2, 2022 was lower than the effective tax rate for the six months ended July 3, 2021 of 14%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain intellectual property rights and a higher tax rate benefit from the foreign derived intangible income deduction, offset by a tax benefit due to a partial release of a valuation allowance in 2021 (see Note 7, "Income Taxes" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q for further information).

[0000068505-22-000025:mdna:169]
[same as prior period, unchanged from 0000068505-22-000019:mdna:103]

[0000068505-22-000025:mdna:170]
During the second quarter of 2022, we recorded net reorganization of business charges of $7 million, including $5 million of charges recorded within Other charges and $2 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $7 million were charges of $11 million related to employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-22-000025:mdna:171]
During the first half of 2022, we recorded net reorganization of business charges of $17 million, including $12 million of charges recorded within Other charges and $5 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $17 million were charges of $24 million related to employee separation costs, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-22-000025:mdna:172]
During the second quarter of 2021, we recorded net reorganization of business charges of $9 million, including $6 million of charges in Other charges and $3 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $9 million were charges of $12 million related to employee separation costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-22-000025:mdna:173]
During the first half of 2021, we recorded net reorganization of business charges of $25 million, including $20 million of charges in Other charges and $5 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $25 million were charges of $30 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-22-000025:mdna:174]
[same as prior period, unchanged from 0000068505-22-000019:mdna:106]

[0000068505-22-000025:mdna:175]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Products and Systems Integration | $ | 6 |  |  | $ | 7 |  |  | $ | 14 |  |  | $ | 19 |  |
| Software and Services | 1 |  |  | 2 |  |  | 3 |  |  | 6 |  |
|  | $ | 7 |  |  | $ | 9 |  |  | $ | 17 |  |  | $ | 25 |  |

[0000068505-22-000025:mdna:176]
Cash payments for employee severance in connection with the reorganization of business plans were $20 million in the first half of 2022 and $56 million in the first half of 2021. The reorganization of business accrual at July 2, 2022 was $31 million related to employee separation costs that are expected to be paid within one year.

[0000068505-22-000025:mdna:177]
[same as prior period, unchanged from 0000068505-22-000019:mdna:109]

[0000068505-22-000025:mdna:178]
|  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 162 |  |  | $ | 758 |  |
| Investing activities | (673) |  |  | (114) |  |
| Financing activities | (564) |  |  | 30 |  |
| Effect of exchange rates on cash and cash equivalents | (82) |  |  | (7) |  |
| Increase (decrease) in cash and cash equivalents | $ | (1,157) |  |  | $ | 667 |  |

[0000068505-22-000025:mdna:179]
[same as prior period, unchanged from 0000068505-22-000019:mdna:111]

[0000068505-22-000025:mdna:180]
At July 2, 2022, $309 million of the $717 million cash and cash equivalents balance was held in the U.S. and $408 million was held in other countries, with $96 million held in the United Kingdom.

[0000068505-22-000025:mdna:181]
[same as prior period, unchanged from 0000068505-22-000019:mdna:113]

[0000068505-22-000025:mdna:182]
The decrease in cash flows provided by operating activities from the first half of 2021 to the first half of 2022 was driven primarily by higher working capital due to an increase in inventory and higher employee incentive payments.

[0000068505-22-000025:mdna:183]
[same as prior period, unchanged from 0000068505-22-000019:mdna:115]

[0000068505-22-000025:mdna:184]
The increase in cash flows used for investing activities in the first half of 2022 compared to the first half of 2021 was primarily due to a $562 million increase in cash used for acquisitions and investments.

[0000068505-22-000025:mdna:185]
[same as prior period, unchanged from 0000068505-22-000019:mdna:117]

[0000068505-22-000025:mdna:186]
The increase in cash flows used for financing activities in the first half of 2022 compared to the first half of 2021 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-22-000025:mdna:187]
•$383 million increase in share repurchases in the first half of 2022 compared to the first half of 2021;

[0000068505-22-000025:mdna:188]
•$249 million decrease in net proceeds from issuance of debt in the first half of 2022 compared to the first half of 2021;

[0000068505-22-000025:mdna:189]
•$24 million increase in the payment of dividends in the first half of 2022 compared to the first half of 2021; and

[0000068505-22-000025:mdna:190]
•$9 million decrease in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first half of 2022 compared to the first half of 2021; partially offset by

[0000068505-22-000025:mdna:191]
•$65 million decrease in repayments of debt in the first half of 2022 compared to the first half of 2021; and

[0000068505-22-000025:mdna:192]
•$7 million related to the payment of revolving credit facility renewal fees in the first half of 2021 that did not occur in the first half of 2022.

[0000068505-22-000025:mdna:193]
[same as prior period, unchanged from 0000068505-22-000019:mdna:123]

[0000068505-22-000025:mdna:194]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended July 2, 2022 and July 3, 2021:

[0000068505-22-000025:mdna:195]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Contract-specific discounting facility | $ | — |  |  | $ | 36 |  |  | $ | 49 |  |  | $ | 107 |  |
| Accounts receivable sales proceeds | 40 |  |  | 8 |  |  | $ | 62 |  |  | $ | 8 |  |
| Long-term receivables sales proceeds | 5 |  |  | 30 |  |  | 22 |  |  | 84 |  |
| Total proceeds from receivable sales | $ | 45 |  |  | $ | 74 |  |  | $ | 133 |  |  | $ | 199 |  |

[0000068505-22-000025:mdna:196]
During the six months ended July 2, 2022, we completed the final draw against a cost-efficient receivables discounting facility, implemented in 2020 to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe. The proceeds of our receivable sales are included in Operating activities within our Condensed Consolidated Statements of Cash Flows.

[0000068505-22-000025:mdna:197]
[same as prior period, unchanged from 0000068505-22-000019:mdna:127]

[0000068505-22-000025:mdna:198]
We had outstanding debt of $6.0 billion and $5.7 billion at July 2, 2022 and December 31, 2021, including the current portions of $2 million and $5 million, at July 2, 2022 and December 31, 2021, respectively.

[0000068505-22-000025:mdna:199]
On May 31, 2022, we issued $600 million of 5.6% senior notes due 2032. We recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, we recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-22-000025:mdna:200]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing us to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of July 2, 2022.

[0000068505-22-000025:mdna:201]
[same as prior period, unchanged from 0000068505-22-000019:mdna:130]

[0000068505-22-000025:mdna:202]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of July 2, 2022 we had no outstanding debt under the commercial paper program.

[0000068505-22-000025:mdna:203]
[same as prior period, unchanged from 0000068505-22-000019:mdna:133]

[0000068505-22-000025:mdna:204]
During the three and six months ended July 2, 2022, we paid an aggregate of $162 million and $655 million, respectively, including transaction costs, to repurchase approximately 0.7 million and 2.9 million shares at an average price of $217.73 and $222.72 per share. As of July 2, 2022, we had used approximately $14.5 billion of the share repurchase authority to repurchase shares, leaving $1.5 billion of authority available for future repurchases.

[0000068505-22-000025:mdna:205]
[same as prior period, unchanged from 0000068505-22-000019:mdna:135]

[0000068505-22-000025:mdna:206]
During the second quarter of 2022 we paid $132 million in cash dividends to holders of our common stock. During the first half of 2022 we paid $266 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $132 million in cash dividends to holders of our common stock.

[0000068505-22-000025:mdna:207]
[same as prior period, unchanged from 0000068505-22-000019:mdna:137]

[0000068505-22-000025:mdna:208]
[same as prior period, unchanged from 0000068505-22-000019:mdna:138]

[0000068505-22-000025:mdna:209]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing

[0000068505-22-000025:mdna:210]
products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases. Refer also to the “Macroeconomic Events” section in this Part I, Item 2 of this Form 10-Q for a discussion of the impact of macroeconomic events on our liquidity.

[0000068505-22-000025:mdna:211]
[same as prior period, unchanged from 0000068505-22-000019:mdna:140]

[0000068505-22-000025:mdna:212]
We had outstanding commitments to provide long-term financing to third parties totaling $102 million at July 2, 2022, compared to $56 million at December 31, 2021.

[0000068505-22-000025:mdna:213]
[same as prior period, unchanged from 0000068505-22-000019:mdna:142]

[0000068505-22-000025:mdna:214]
See “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
