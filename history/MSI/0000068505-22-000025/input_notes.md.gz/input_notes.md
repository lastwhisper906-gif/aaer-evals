# MSI notes — 0000068505-22-000025


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-22-000025:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of July 2, 2022 and for the three and six months ended July 2, 2022 and July 3, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-22-000025:notes:2]
[same as prior period, unchanged from 0000068505-22-000019:notes:2]

[0000068505-22-000025:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three and six months ended July 2, 2022 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-22-000025:notes:4]
[same as prior period, unchanged from 0000068505-22-000019:notes:4]

[0000068505-22-000025:notes:5]
[same as prior period, unchanged from 0000068505-22-000019:notes:5]

[0000068505-22-000025:notes:6]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center Software.

[0000068505-22-000025:notes:7]
[same as prior period, unchanged from 0000068505-22-000019:notes:7]

[0000068505-22-000025:notes:8]
[same as prior period, unchanged from 0000068505-22-000019:notes:8]

[0000068505-22-000025:notes:9]
[same as prior period, unchanged from 0000068505-22-000019:notes:9]

[0000068505-22-000025:notes:10]
[same as prior period, unchanged from 0000068505-22-000019:notes:10]

[0000068505-22-000025:notes:11]
On May 12, 2022, the Company acquired Videotec S.p.A. ("Videotec"), a global provider of ruggedized video security solutions, for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of the Products and Systems Integration segment.

[0000068505-22-000025:notes:12]
On April 19, 2022, the Company acquired Calipsa, Inc. ("Calipsa"), a technology leader in cloud-native advanced video analytics, for $40 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.

[0000068505-22-000025:notes:13]
[same as prior period, unchanged from 0000068505-22-000019:notes:13]

[0000068505-22-000025:notes:14]
On March 3, 2022, the Company acquired Ava Security Limited ("Ava"), a global provider of cloud-native video security and analytics, for $388 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000025:notes:15]
[same as prior period, unchanged from 0000068505-22-000019:notes:15]

[0000068505-22-000025:notes:16]
On October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy to be a global leader in end-to-end video security solutions within Video. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000025:notes:17]
On July 15, 2021, the Company acquired Openpath Security Inc. ("Openpath"), a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000025:notes:18]
Recently Adopted Accounting Pronouncements

[0000068505-22-000025:notes:19]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the Senior Convertible Notes on diluted earnings per common share.

[0000068505-22-000025:notes:20]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, "which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

[0000068505-22-000025:notes:21]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures that are expected to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU was effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-22-000025:notes:22]
[same as prior period, unchanged from 0000068505-22-000019:notes:22]

[0000068505-22-000025:notes:23]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 2, 2022 and July 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-22-000025:notes:24]
|  | Three Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |  | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |
| International | 322 |  |  | 334 |  |  | 656 |  |  | 329 |  |  | 330 |  |  | 659 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |  | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |
| Video Security and Access Control | 247 |  |  | 123 |  |  | 370 |  |  | 212 |  |  | 94 |  |  | 306 |  |
| Command Center Software | — |  |  | 162 |  |  | 162 |  |  | — |  |  | 134 |  |  | 134 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |  | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |
| Indirect | 574 |  |  | 77 |  |  | 651 |  |  | 492 |  |  | 67 |  |  | 559 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |

[0000068505-22-000025:notes:25]
|  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |  | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |
| International | 594 |  |  | 650 |  |  | 1,244 |  |  | 602 |  |  | 645 |  |  | 1,247 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |  | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |
| Video Security and Access Control | 441 |  |  | 236 |  |  | 677 |  |  | 377 |  |  | 182 |  |  | 559 |  |
| Command Center Software | — |  |  | 292 |  |  | 292 |  |  | — |  |  | 254 |  |  | 254 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |  | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |
| Indirect | 1,021 |  |  | 164 |  |  | 1,185 |  |  | 903 |  |  | 135 |  |  | 1,038 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |

[0000068505-22-000025:notes:26]
[same as prior period, unchanged from 0000068505-22-000019:notes:25]

[0000068505-22-000025:notes:27]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 2, 2022 was $9.0 billion. A total of $4.3 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of July 2, 2022, of which $2.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.7 billion was from Software and Services performance obligations that were not yet satisfied as of July 2, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-22-000025:notes:28]
[same as prior period, unchanged from 0000068505-22-000019:notes:27]

[0000068505-22-000025:notes:29]
| (In millions) | July 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,284 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 1,045 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,556 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 308 |  |  | 306 |  |  |  |  |  |

[0000068505-22-000025:notes:30]
Revenue recognized during the three months ended July 2, 2022 which was previously included in Contract liabilities as of April 2, 2022 was $456 million, compared to $483 million of revenue recognized during the three months ended July 3, 2021 which was previously included in Contract liabilities as of April 3, 2021. Revenue recognized during the six months ended July 2, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $712 million, compared to $705 million recognized during the six months ended July 3, 2021 which was previously included in Contract liabilities as of December 31, 2020. The Company did not reverse any revenue during the three months ended July 2, 2022 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $10 million of reversals for the three months ended July 3, 2021, primarily driven by changes in the estimates of progress on system contracts, Revenue of $22 million was reversed during the six months ended July 2, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million of reversals for the six months ended July 3, 2021.

[0000068505-22-000025:notes:31]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 2, 2022 and July 3, 2021.

[0000068505-22-000025:notes:32]
[same as prior period, unchanged from 0000068505-22-000019:notes:31]

[0000068505-22-000025:notes:33]
| (In millions) | July 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 39 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 118 |  |  | 124 |  |  |  |  |  |

[0000068505-22-000025:notes:34]
Amortization of non-current contract cost assets was $13 million and $26 million for the three and six months ended July 2, 2022, respectively, and $12 million and $25 million for the three and six months ended July 3, 2021, respectively


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-22-000025:notes:35]
LeasesComponents of Lease Expense

[0000068505-22-000025:notes:36]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 33 |  |  | $ | 34 |  |  | $ | 66 |  |  | $ | 67 |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 2 |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | 6 |  |
| Short-term lease cost | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |
| Variable cost | 8 |  |  | 9 |  |  | 17 |  |  | 18 |  |
| Sublease income | (2) |  |  | (1) |  |  | (3) |  |  | (2) |  |
| Net lease expense | $ | 41 |  |  | $ | 46 |  |  | $ | 85 |  |  | $ | 91 |  |

[0000068505-22-000025:notes:37]
[same as prior period, unchanged from 0000068505-22-000019:notes:36]

[0000068505-22-000025:notes:38]
| (in millions) |  | Statement Line Classification |  | July 2, 2022 |  | December 31, 2021 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 366 |  |  | $ | 382 |  |  |  |
| Finance lease assets |  | Property, plant and equipment, net |  | 11 |  |  | 16 |  |  |  |
|  |  |  |  | $ | 377 |  |  | $ | 398 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 94 |  |  | $ | 124 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 2 |  |  | 4 |  |  |  |
|  |  |  |  | $ | 96 |  |  | $ | 128 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 308 |  |  | $ | 313 |  |  |  |
|  |  |  |  | $ | 308 |  |  | $ | 313 |  |  |  |

[0000068505-22-000025:notes:39]
[same as prior period, unchanged from 0000068505-22-000019:notes:38]

[0000068505-22-000025:notes:40]
|  | Six Months Ended |  |  |
| (in millions) | July 2, 2022 |  | July 3, 2021 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 93 |  |  | $ | 95 |  |  |  |
| Net cash used for financing activities related to finance leases | 3 |  |  | 7 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 65 |  |  | $ | 22 |  |  |  |

[0000068505-22-000025:notes:41]
The increase in assets obtained in exchange for lease liabilities for the six months ended July 2, 2022 compared to the six months ended July 3, 2021 was primarily due to $34 million of additional leases acquired in connection with the Company's acquisition of TETRA Ireland during the quarter ended April 2, 2022.

[0000068505-22-000025:notes:42]
|  | July 2, 2022 |  | December 31, 2021 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 6 |  | 6 |
| Finance leases | 1 |  | 1 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.05 | % |  | 3.11 | % |
| Finance leases | 3.92 | % |  | 3.99 | % |

[0000068505-22-000025:notes:43]
[same as prior period, unchanged from 0000068505-22-000019:notes:42]

[0000068505-22-000025:notes:44]
|  | July 2, 2022 |
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2022 | $ | 48 |  |  | $ | 2 |  |  | $ | 50 |  |
| 2023 | 91 |  |  | — |  |  | 91 |  |
| 2024 | 77 |  |  | — |  |  | 77 |  |
| 2025 | 63 |  |  | — |  |  | 63 |  |
| 2026 | 50 |  |  | — |  |  | 50 |  |
| Thereafter | 113 |  |  | — |  |  | 113 |  |
| Total lease payments | $ | 442 |  |  | $ | 2 |  |  | $ | 444 |  |
| Less: interest | 40 |  |  | — |  |  | 40 |  |
| Present value of lease liabilities | $ | 402 |  |  | $ | 2 |  |  | $ | 404 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-22-000025:notes:45]
[same as prior period, unchanged from 0000068505-22-000019:notes:44]

[0000068505-22-000025:notes:46]
[same as prior period, unchanged from 0000068505-22-000019:notes:45]

[0000068505-22-000025:notes:47]
[same as prior period, unchanged from 0000068505-22-000019:notes:46]

[0000068505-22-000025:notes:48]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 65 |  |  | $ | 58 |  |  | $ | 131 |  |  | $ | 116 |  |
| Reorganization of business (Note 14) | 5 |  |  | 6 |  |  | 12 |  |  | 20 |  |
| Operating lease asset impairments | 3 |  |  | — |  |  | 12 |  |  | 7 |  |
| Acquisition-related transaction fees | 4 |  |  | 3 |  |  | 14 |  |  | 4 |  |
| Legal settlements | — |  |  | 3 |  |  | 11 |  |  | 3 |  |
| Fixed asset impairments | 8 |  |  | — |  |  | 11 |  |  | — |  |
| Gain on Hytera legal settlement | — |  |  | — |  |  | (13) |  |  | — |  |
| Other | — |  |  | — |  |  | (1) |  |  | — |  |
|  | $ | 85 |  |  | $ | 70 |  |  | $ | 177 |  |  | $ | 150 |  |

[0000068505-22-000025:notes:49]
In February 2022, the Company recognized a gain of $13 million related to the recovery, through legal proceedings to seize and liquidate assets, of financial receivables owed to the Company by the bankruptcy estate of the two U.S. subsidiaries of Hytera Communications Corporation Limited of Shenzhen, China. Refer also to "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for additional information related to these proceedings.

[0000068505-22-000025:notes:50]
[same as prior period, unchanged from 0000068505-22-000019:notes:49]

[0000068505-22-000025:notes:51]
[same as prior period, unchanged from 0000068505-22-000019:notes:50]

[0000068505-22-000025:notes:52]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (59) |  |  | $ | (46) |  |  | $ | (117) |  |  | $ | (102) |  |
| Interest income | 3 |  |  | 2 |  |  | 5 |  |  | 4 |  |
|  | $ | (56) |  |  | $ | (44) |  |  | $ | (112) |  |  | (98) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 30 |  |  | $ | 31 |  |  | $ | 63 |  |  | $ | 60 |  |
| Loss from the extinguishment of long-term debt (Note 5) | (6) |  |  | (18) |  |  | (6) |  |  | (18) |  |
| Investment impairments | — |  |  | — |  |  | (1) |  |  | — |  |
| Foreign currency gain (loss) | 27 |  |  | (6) |  |  | 50 |  |  | 8 |  |
| Loss on derivative instruments (Note 6) | (34) |  |  | (1) |  |  | (57) |  |  | (9) |  |
| Gain (loss) on equity method investments | (2) |  |  | 2 |  |  | (2) |  |  | 3 |  |
| Fair value adjustments to equity investments | (12) |  |  | 8 |  |  | (30) |  |  | 13 |  |
| Gain on TETRA Ireland equity method investment | — |  |  | — |  |  | 21 |  |  | — |  |
| Other | (5) |  |  | (2) |  |  | (5) |  |  | 3 |  |
|  | $ | (2) |  |  | $ | 14 |  |  | $ | 33 |  |  | $ | 60 |  |

[0000068505-22-000025:notes:53]
The Company previously held a minority ownership interest in TETRA Ireland, and, upon acquisition of 100% of the equity of TETRA Ireland in the first quarter of 2022, recorded a $21 million gain to adjust the Company's initial equity method investment to fair value during the six months ended July 2, 2022. Refer to Note 15, "Intangible Assets and Goodwill" to the Company's condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for further information related to this acquisition.

[0000068505-22-000025:notes:54]
[same as prior period, unchanged from 0000068505-22-000019:notes:53]

[0000068505-22-000025:notes:55]
[same as prior period, unchanged from 0000068505-22-000019:notes:54]

[0000068505-22-000025:notes:56]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 228 |  |  | $ | 293 |  |  | $ | 495 |  |  | $ | 537 |  |
| Weighted average common shares outstanding | 167.2 |  |  | 169.6 |  |  | 167.6 |  |  | 169.4 |  |
| Per share amount | $ | 1.36 |  |  | $ | 1.73 |  |  | $ | 2.95 |  |  | $ | 3.17 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 228 |  |  | $ | 293 |  |  | $ | 495 |  |  | $ | 537 |  |
| Weighted average common shares outstanding | 167.2 |  |  | 169.6 |  |  | 167.6 |  |  | 169.4 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.4 |  |  | 3.5 |  |  | 3.9 |  |  | 3.7 |  |
| 1.75% senior convertible notes | 0.3 |  |  | — |  |  | 0.5 |  |  | — |  |
| Diluted weighted average common shares outstanding | 170.9 |  |  | 173.1 |  |  | 172.0 |  |  | 173.1 |  |
| Per share amount | $ | 1.33 |  |  | $ | 1.69 |  |  | $ | 2.88 |  |  | $ | 3.10 |  |

[0000068505-22-000025:notes:57]
In the computation of diluted earnings per common share for the three months ended July 2, 2022, the assumed exercise of 0.2 million options, including 0.1 million subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. For the six months ended July 2, 2022, the assumed exercise of 0.2 million options were excluded because their inclusion would have been antidilutive.

[0000068505-22-000025:notes:58]
In the computation of diluted earnings per common share for the three months ended July 3, 2021, the assumed exercise of 0.4 million options, including 0.2 million subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. For the six months ended July 3, 2021, the assumed exercise of 0.4 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-22-000025:notes:59]
As of July 2, 2022, the Company had $1.0 billion of the Senior Convertible Notes outstanding, which mature on September 15, 2024. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share), adjusted for dividends declared through the date of settlement. The notes became fully convertible as of September 5, 2021, when the average stock price exceeded the contractual conversion price, providing the holders the option to convert all or any portion of their Senior Convertible Notes. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash. Because the Company has irrevocably decided to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the quarter ended October 2, 2021. Upon conversion of the Senior Convertible Notes, the Company has the option to settle the conversion spread in cash or shares. The Company included the number of shares that would be issuable upon conversion in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended July 2, 2022. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of July 2, 2022 was $54 million. For the period ended July 3, 2021, there was no dilutive effect of the Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price.

[0000068505-22-000025:notes:60]
[same as prior period, unchanged from 0000068505-22-000019:notes:58]

[0000068505-22-000025:notes:61]
[same as prior period, unchanged from 0000068505-22-000019:notes:59]

[0000068505-22-000025:notes:62]
[same as prior period, unchanged from 0000068505-22-000019:notes:60]

[0000068505-22-000025:notes:63]
|  | July 2, 2022 |  | December 31, 2021 |
| Accounts receivable | $ | 1,346 |  |  | $ | 1,456 |  |
| Less allowance for credit losses | (62) |  |  | (70) |  |
|  | $ | 1,284 |  |  | $ | 1,386 |  |

[0000068505-22-000025:notes:64]
[same as prior period, unchanged from 0000068505-22-000019:notes:62]

[0000068505-22-000025:notes:65]
[same as prior period, unchanged from 0000068505-22-000019:notes:63]

[0000068505-22-000025:notes:66]
|  | July 2, 2022 |  | December 31, 2021 |
| Finished goods | $ | 331 |  |  | $ | 268 |  |
| Work-in-process and production materials | 860 |  |  | 643 |  |
|  | 1,191 |  |  | 911 |  |
| Less inventory reserves | (120) |  |  | (123) |  |
|  | $ | 1,071 |  |  | $ | 788 |  |

[0000068505-22-000025:notes:67]
[same as prior period, unchanged from 0000068505-22-000019:notes:65]

[0000068505-22-000025:notes:68]
[same as prior period, unchanged from 0000068505-22-000019:notes:66]

[0000068505-22-000025:notes:69]
|  | July 2, 2022 |  | December 31, 2021 |
| Current contract cost assets (Note 2) | $ | 39 |  |  | $ | 30 |  |
| Tax-related deposits | 37 |  |  | 41 |  |
| Other | 218 |  |  | 188 |  |
|  | $ | 294 |  |  | $ | 259 |  |

[0000068505-22-000025:notes:70]
[same as prior period, unchanged from 0000068505-22-000019:notes:68]

[0000068505-22-000025:notes:71]
[same as prior period, unchanged from 0000068505-22-000019:notes:69]

[0000068505-22-000025:notes:72]
|  | July 2, 2022 |  | December 31, 2021 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 458 |  |  | 474 |  |
| Machinery and equipment | 2,431 |  |  | 2,439 |  |
|  | 2,894 |  |  | 2,918 |  |
| Less accumulated depreciation | (1,855) |  |  | (1,876) |  |
|  | $ | 1,039 |  |  | $ | 1,042 |  |

[0000068505-22-000025:notes:73]
Depreciation expense for the three months ended July 2, 2022 and July 3, 2021 was $47 million and $52 million, respectively. Depreciation expense for the six months ended July 2, 2022 and July 3, 2021 was $92 million and $104 million, respectively.

[0000068505-22-000025:notes:74]
[same as prior period, unchanged from 0000068505-22-000019:notes:72]

[0000068505-22-000025:notes:75]
[same as prior period, unchanged from 0000068505-22-000019:notes:73]

[0000068505-22-000025:notes:76]
|  | July 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Common stock | $ | 39 |  |  | $ | 69 |  |  |  |  |  |
| Strategic investments | 42 |  |  | 35 |  |  |  |  |  |
| Company-owned life insurance policies | 68 |  |  | 81 |  |  |  |  |  |
| Equity method investments | 13 |  |  | 24 |  |  |  |  |  |
|  | $ | 162 |  |  | $ | 209 |  |  |  |  |  |

[0000068505-22-000025:notes:77]
On July 16, 2021, the Company paid $50 million for equity securities of NewHold Investment Corp. ("NHIC"), a special purpose acquisition company (SPAC) that completed a business combination with Evolv Technologies, Inc. After the business combination, NHIC was renamed “Evolv Technologies Holdings, Inc.” (together with its subsidiaries, “Evolv”). During the six months ended July 2, 2022, the Company recognized a loss of $11 million in Other income (expense) related to a decrease in the fair value of the investment.

[0000068505-22-000025:notes:78]
[same as prior period, unchanged from 0000068505-22-000019:notes:76]

[0000068505-22-000025:notes:79]
[same as prior period, unchanged from 0000068505-22-000019:notes:77]

[0000068505-22-000025:notes:80]
|  | July 2, 2022 |  | December 31, 2021 |
| Defined benefit plan assets | $ | 383 |  |  | $ | 365 |  |
| Non-current contract cost assets (Note 2) | 118 |  |  | 124 |  |
| Other | 61 |  |  | 69 |  |
|  | $ | 562 |  |  | $ | 558 |  |

[0000068505-22-000025:notes:81]
[same as prior period, unchanged from 0000068505-22-000019:notes:79]

[0000068505-22-000025:notes:82]
[same as prior period, unchanged from 0000068505-22-000019:notes:80]

[0000068505-22-000025:notes:83]
|  | July 2, 2022 |  | December 31, 2021 |
| Compensation | $ | 233 |  |  | $ | 360 |  |
| Tax liabilities | 190 |  |  | 183 |  |
| Dividend payable | 132 |  |  | 134 |  |
| Trade liabilities | 154 |  |  | 235 |  |
| Operating lease liabilities (Note 3) | 94 |  |  | 124 |  |
| Other | 521 |  |  | 521 |  |
|  | $ | 1,324 |  |  | $ | 1,557 |  |

[0000068505-22-000025:notes:84]
[same as prior period, unchanged from 0000068505-22-000019:notes:82]

[0000068505-22-000025:notes:85]
[same as prior period, unchanged from 0000068505-22-000019:notes:83]

[0000068505-22-000025:notes:86]
|  | July 2, 2022 |  | December 31, 2021 |
| Defined benefit plans | $ | 1,277 |  |  | $ | 1,390 |  |
| Non-current contract liabilities (Note 2) | 308 |  |  | 306 |  |
| Unrecognized tax benefits (Note 7) | 35 |  |  | 36 |  |
| Deferred income taxes (Note 7) | 140 |  |  | 183 |  |
| Environmental reserve | 108 |  |  | 108 |  |
| Other | 114 |  |  | 125 |  |
|  | $ | 1,982 |  |  | $ | 2,148 |  |

[0000068505-22-000025:notes:87]
[same as prior period, unchanged from 0000068505-22-000019:notes:85]

[0000068505-22-000025:notes:88]
Share Repurchase Program: During the three and six months ended July 2, 2022, the Company paid an aggregate of $162 million, and $655 million, including transaction costs, to repurchase approximately 0.7 million and 2.9 million shares at an average price of $217.73 and $222.72 per share, respectively. As of July 2, 2022, the Company had $1.5 billion of authority available for future repurchases.

[0000068505-22-000025:notes:89]
Payment of Dividends: During the three months ended July 2, 2022 and July 3, 2021, the Company paid $132 million and $121 million, respectively, in cash dividends to holders of its common stock. During the six months ended July 2, 2022 and July 3, 2021, the Company paid $266 and $242 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $132 million in cash dividends to holders of its common stock.

[0000068505-22-000025:notes:90]
[same as prior period, unchanged from 0000068505-22-000019:notes:88]

[0000068505-22-000025:notes:91]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and six months ended July 2, 2022 and July 3, 2021:

[0000068505-22-000025:notes:92]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (404) |  |  | $ | (341) |  |  | $ | (384) |  |  | $ | (360) |  |
| Other comprehensive income (loss) before reclassification adjustment | (132) |  |  | 6 |  |  | (151) |  |  | 23 |  |
| Tax benefit (expense) | (3) |  |  | — |  |  | (4) |  |  | 2 |  |
| Other comprehensive income (loss), net of tax | (135) |  |  | 6 |  |  | (155) |  |  | 25 |  |
| Balance at end of period | $ | (539) |  |  | $ | (335) |  |  | $ | (539) |  |  | $ | (335) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,980) |  |  | $ | (2,069) |  |  | $ | (1,995) |  |  | $ | (2,086) |  |
| Other comprehensive income before reclassification adjustment | 17 |  |  | — |  |  | 17 |  |  | — |  |
| Tax expense | (3) |  |  | — |  |  | (3) |  |  | — |  |
| Other comprehensive income before reclassification adjustment, net of tax | 14 |  |  | — |  |  | 14 |  |  | — |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 20 |  |  | 21 |  |  | 40 |  |  | 43 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | (1) |  |  | (2) |  |  | (2) |  |  | (4) |  |
| Tax expense | (5) |  |  | (3) |  |  | (9) |  |  | (6) |  |
| Reclassification adjustment into Net earnings, net of tax | 14 |  |  | 16 |  |  | 29 |  |  | 33 |  |
| Other comprehensive income, net of tax | 28 |  |  | 16 |  |  | 43 |  |  | 33 |  |
| Balance at end of period | $ | (1,952) |  |  | $ | (2,053) |  |  | $ | (1,952) |  |  | $ | (2,053) |  |
| Total Accumulated other comprehensive loss | $ | (2,491) |  |  | $ | (2,388) |  |  | $ | (2,491) |  |  | $ | (2,388) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-22-000025:notes:93]
Debt and Credit Facilities

[0000068505-22-000025:notes:94]
|  | July 2, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 2 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (2) |  |  | (5) |  |
| Long-term debt | $ | 6,011 |  |  | $ | 5,688 |  |

[0000068505-22-000025:notes:95]
On May 31, 2022, the Company issued $600 million of 5.6% senior notes due 2032. The Company recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-22-000025:notes:96]
As of July 2, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 2, 2022.

[0000068505-22-000025:notes:97]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 2, 2022 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-22-000025:notes:98]
[same as prior period, unchanged from 0000068505-22-000019:notes:93]

[0000068505-22-000025:notes:99]
The Company had outstanding foreign exchange contracts with notional amounts totaling $991 million and $1.1 billion for the periods ended July 2, 2022 and December 31, 2021, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-22-000025:notes:100]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of July 2, 2022, and the corresponding positions as of December 31, 2021:

[0000068505-22-000025:notes:101]
|  | Notional Amount |
| Net Buy (Sell) by Currency | July 2, 2022 |  | December 31, 2021 |
| Euro | $ | 202 |  |  | $ | 164 |  |
| British pound | 200 |  |  | 128 |  |
| Canadian dollar | 51 |  |  | 27 |  |
| Australian dollar | (77) |  |  | (76) |  |
| Chinese renminbi | (73) |  |  | (89) |  |

[0000068505-22-000025:notes:102]
[same as prior period, unchanged from 0000068505-22-000019:notes:97]

[0000068505-22-000025:notes:103]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of July 2, 2022, all of the counterparties had investment grade credit ratings. As of July 2, 2022, the Company had $19 million of exposure to aggregate credit risk with all counterparties.

[0000068505-22-000025:notes:104]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of July 2, 2022 and December 31, 2021:

[0000068505-22-000025:notes:105]
|  | Fair Values of Derivative Instruments |
| July 2, 2022 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 12 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 7 |  |  | 17 |  |
| Total derivatives | $ | 19 |  |  | $ | 17 |  |

[0000068505-22-000025:notes:106]
[same as prior period, unchanged from 0000068505-22-000019:notes:101]

[0000068505-22-000025:notes:107]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and six months ended July 2, 2022 and July 3, 2021:

[0000068505-22-000025:notes:108]
|  | Financial Statement Location | Three Months Ended |  | Six Months Ended |
| Foreign Exchange Contracts | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Effective portion | Accumulated othercomprehensive gain (loss) | $ | 10 |  |  | $ | (1) |  |  | $ | 12 |  |  | $ | 3 |  |
| Forward points recognized | Other income (expense) | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Undesignated derivatives recognized | Other income (expense) | (34) |  |  | (1) |  |  | (57) |  |  | (9) |  |

[0000068505-22-000025:notes:109]
[same as prior period, unchanged from 0000068505-22-000019:notes:104]

[0000068505-22-000025:notes:110]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of July 2, 2022, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £25 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-22-000025:notes:111]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. During the six months ended July 2, 2022 and July 3, 2021, the Company amortized $1 million of income from the excluded components through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-22-000025:notes:112]
[same as prior period, unchanged from 0000068505-22-000019:notes:106]

[0000068505-22-000025:notes:113]
[same as prior period, unchanged from 0000068505-22-000019:notes:107]

[0000068505-22-000025:notes:114]
[same as prior period, unchanged from 0000068505-22-000019:notes:108]

[0000068505-22-000025:notes:115]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Net earnings before income taxes | $ | 300 |  |  | $ | 340 |  |  | $ | 520 |  |  | $ | 630 |  |
| Income tax expense | 71 |  |  | 46 |  |  | 23 |  |  | 90 |  |
| Effective tax rate | 24 | % |  | 14 | % |  | 4 | % |  | 14 | % |

[0000068505-22-000025:notes:116]
The effective tax rate for the three months ended July 2, 2022 of 24% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense. The effective tax rate for the six months ended July 2, 2022 of 4% was lower than the U.S. federal statutory tax rate of 21% primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights (as described above), a higher foreign derived intangible income deduction and the excess tax benefits of share-based compensation.

[0000068505-22-000025:notes:117]
The effective tax rate for the three and six months ended July 3, 2021 of 14% was lower than the U.S. federal statutory tax rate of 21% due to a tax benefit related to a partial release of $33 million of a valuation allowance recorded on the U.S. foreign tax credit carryforward and the recognition of excess tax benefits of share-based compensation, offset by state tax expense.
The effective tax rate for the three months ended July 2, 2022 of 24% was higher than the effective tax rate for the three months ended July 3, 2021 of 14%, primarily due to a tax benefit related to the partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward in 2021. The effective tax rate for the six months ended July 2, 2022 of 4% was lower than the effective tax rate for the six months ended July 3, 2021 of 14%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights (as described above) and a higher tax rate benefit from the foreign derived intangible income deduction in 2022, offset by a tax benefit due to a partial release of a valuation allowance in 2021


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-22-000025:notes:118]
[same as prior period, unchanged from 0000068505-22-000019:notes:112]

[0000068505-22-000025:notes:119]
[same as prior period, unchanged from 0000068505-22-000019:notes:113]

[0000068505-22-000025:notes:120]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 32 |  |  | 29 |  |  | 8 |  |  | 5 |  |  | — |  |  | 1 |  |
| Expected return on plan assets | (64) |  |  | (59) |  |  | (26) |  |  | (25) |  |  | (3) |  |  | (2) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 15 |  |  | 17 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | — |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | — |  |  | — |  |  | (2) |  |
| Net periodic pension benefits | $ | (17) |  |  | $ | (13) |  |  | $ | (14) |  |  | $ | (16) |  |  | $ | (2) |  |  | $ | (3) |  |

[0000068505-22-000025:notes:121]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 64 |  |  | 58 |  |  | 16 |  |  | 10 |  |  | — |  |  | 1 |  |
| Expected return on plan assets | (127) |  |  | (118) |  |  | (51) |  |  | (50) |  |  | (6) |  |  | (5) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 30 |  |  | 34 |  |  | 8 |  |  | 8 |  |  | 2 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (2) |  |  | (1) |  |  | — |  |  | (3) |  |
| Net periodic pension benefits | $ | (33) |  |  | $ | (26) |  |  | $ | (28) |  |  | $ | (32) |  |  | $ | (4) |  |  | $ | (6) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-22-000025:notes:122]
[same as prior period, unchanged from 0000068505-22-000019:notes:115]

[0000068505-22-000025:notes:123]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 7 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 8 |  |
| Selling, general and administrative expenses | 25 |  |  | 19 |  |  | 46 |  |  | 36 |  |
| Research and development expenditures | 12 |  |  | 8 |  |  | 22 |  |  | 16 |  |
| Share-based compensation expense included in Operating earnings | 44 |  |  | 31 |  |  | 81 |  |  | 60 |  |
| Tax benefit | (9) |  |  | (2) |  |  | (17) |  |  | (8) |  |
| Share-based compensation expense, net of tax | $ | 35 |  |  | $ | 29 |  |  | $ | 64 |  |  | $ | 52 |  |
| Decrease in basic earnings per share | $ | (0.21) |  |  | $ | (0.17) |  |  | $ | (0.38) |  |  | $ | (0.31) |  |
| Decrease in diluted earnings per share | $ | (0.21) |  |  | $ | (0.17) |  |  | $ | (0.37) |  |  | $ | (0.30) |  |

[0000068505-22-000025:notes:124]
During the six months ended July 2, 2022, the Company granted 0.7 million restricted stock units (RSUs), 0.1 million performance stock units (PSUs) and 0.1 million market stock units (MSUs) with an aggregate grant-date fair value of $152 million, $17 million and $10 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $8 million and $10 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.

[0000068505-22-000025:notes:125]
During the six months ended July 2, 2022, the Company granted 0.1 million shares of restricted stock with an aggregate grant-date fair value of $10 million to certain key employees of Ava, Calipsa and Videotec in connection with the acquisitions of 
such entities. The share-based compensation for Ava and Calipsa will each be expensed over an average service period of two years, while the share-based compensation for Videotec will be expensed over an average service period of one year.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-22-000025:notes:126]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of July 2, 2022 and December 31, 2021 were as follows:

[0000068505-22-000025:notes:127]
| July 2, 2022 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 19 |  |  |  |  | $ | 19 |  |
| Common stock | 39 |  |  | — |  |  |  |  | 39 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 17 |  |  |  |  | $ | 17 |  |

[0000068505-22-000025:notes:128]
[same as prior period, unchanged from 0000068505-22-000019:notes:121]

[0000068505-22-000025:notes:129]
The Company had no foreign exchange derivative contracts or common stock investments in Level 3 holdings as of July 2, 2022 or December 31, 2021.

[0000068505-22-000025:notes:130]
At July 2, 2022 and December 31, 2021, the Company had $144 million and $685 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-22-000025:notes:131]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of July 2, 2022 was $5.8 billion, of which the Senior Convertible Notes were $1.2 billion (Level 2). The fair value of long-term debt at December 31, 2021 was $6.2 billion (Level 2).

[0000068505-22-000025:notes:132]
[same as prior period, unchanged from 0000068505-22-000019:notes:125]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-22-000025:notes:133]
[same as prior period, unchanged from 0000068505-22-000019:notes:126]

[0000068505-22-000025:notes:134]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended July 2, 2022 and July 3, 2021:

[0000068505-22-000025:notes:135]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Contract-specific discounting facility | $ | — |  |  | $ | 36 |  |  | $ | 49 |  |  | $ | 107 |  |
| Accounts receivable sales proceeds | 40 |  |  | 8 |  |  | 62 |  |  | 8 |  |
| Long-term receivables sales proceeds | 5 |  |  | 30 |  |  | 22 |  |  | 84 |  |
| Total proceeds from receivable sales | $ | 45 |  |  | $ | 74 |  |  | $ | 133 |  |  | $ | 199 |  |

[0000068505-22-000025:notes:136]
At July 2, 2022, the Company had retained servicing obligations for $875 million of long-term receivables, compared to $940 million at December 31, 2021. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $102 million at July 2, 2022, compared to $56 million at December 31, 2021.

[0000068505-22-000025:notes:137]
During the six months ended July 2, 2022, the Company completed its final draw against a cost-efficient receivables discounting facility, implemented in 2020 to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe. The proceeds of the Company's receivable sales are included in Operating activities within the Company's Condensed Consolidated Statements of Cash Flows.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-22-000025:notes:138]
Commitments and Contingencies
Legal Matters

[0000068505-22-000025:notes:139]
Hytera Litigation

[0000068505-22-000025:notes:140]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for not making the royalty payment.

[0000068505-22-000025:notes:141]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

[0000068505-22-000025:notes:142]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions due to ongoing appeals in the case.

[0000068505-22-000025:notes:143]
Hytera Bankruptcy Proceedings

[0000068505-22-000025:notes:144]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. The gain was recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-22-000025:notes:145]
[same as prior period, unchanged from 0000068505-22-000019:notes:137]

[0000068505-22-000025:notes:146]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Products and Systems Integration | $ | 1,285 |  |  | $ | 1,198 |  |  | $ | 2,388 |  |  | $ | 2,213 |  |
| Software and Services | 855 |  |  | 773 |  |  | 1,644 |  |  | 1,531 |  |
|  | $ | 2,140 |  |  | $ | 1,971 |  |  | $ | 4,032 |  |  | $ | 3,744 |  |

[0000068505-22-000025:notes:147]
[same as prior period, unchanged from 0000068505-22-000019:notes:139]

[0000068505-22-000025:notes:148]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Products and Systems Integration | $ | 118 |  |  | $ | 139 |  |  | $ | 157 |  |  | $ | 216 |  |
| Software and Services | 240 |  |  | 231 |  |  | 440 |  |  | 452 |  |
| Operating earnings | 358 |  |  | 370 |  |  | 597 |  |  | 668 |  |
| Total other expense | (58) |  |  | (30) |  |  | (77) |  |  | (38) |  |
| Earnings before income taxes | $ | 300 |  |  | $ | 340 |  |  | $ | 520 |  |  | $ | 630 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-22-000025:notes:149]
[same as prior period, unchanged from 0000068505-22-000019:notes:141]

[0000068505-22-000025:notes:150]
During the three months ended July 2, 2022, the Company recorded net reorganization of business charges of $7 million, including $5 million of charges in Other charges and $2 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $7 million were charges of $11 million related to employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-22-000025:notes:151]
During the six months ended July 2, 2022, the Company recorded net reorganization of business charges of $17 million, including $12 million of charges in Other charges and $5 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $17 million were charges of $24 million related to employee separation costs, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-22-000025:notes:152]
[same as prior period, unchanged from 0000068505-22-000019:notes:143]

[0000068505-22-000025:notes:153]
| July 2, 2022 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 14 |  |
| Software and Services | 1 |  |  | 3 |  |
|  | $ | 7 |  |  | $ | 17 |  |

[0000068505-22-000025:notes:154]
[same as prior period, unchanged from 0000068505-22-000019:notes:145]

[0000068505-22-000025:notes:155]
| January 1, 2022 |  | Additional Charges |  | Adjustments |  | Amount Used |  | July 2, 2022 |
| $ | 34 |  |  | $ | 24 |  |  | $ | (7) |  |  | $ | (20) |  |  | $ | 31 |  |

[0000068505-22-000025:notes:156]
[same as prior period, unchanged from 0000068505-22-000019:notes:147]

[0000068505-22-000025:notes:157]
At January 1, 2022, the Company had an accrual of $34 million for employee separation costs. The 2022 additional charges of $24 million represent severance costs for approximately 310 employees. The adjustment of $7 million reflects reversals for accruals no longer needed. The $20 million used reflects cash payments to severed employees. The remaining accrual of $31 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at July 2, 2022, is expected to be paid, primarily within one year, to approximately 550 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-22-000025:notes:158]
[same as prior period, unchanged from 0000068505-22-000019:notes:149]

[0000068505-22-000025:notes:159]
During the three months ended July 3, 2021, the Company recorded net reorganization of business charges of $9 million, including $6 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $9 million were charges of $12 million related to employee separation costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-22-000025:notes:160]
During the six months ended July 3, 2021, the Company recorded net reorganization of business charges of $25 million, including $20 million of charges in Other charges and $5 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $25 million were charges of $30 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-22-000025:notes:161]
| July 3, 2021 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 7 |  |  | $ | 19 |  |
| Software and Services | 2 |  |  | 6 |  |
|  | $ | 9 |  |  | $ | 25 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-22-000025:notes:162]
Intangible Assets and Goodwill
On May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The Company recognized $8 million of goodwill, $6 million of identifiable intangible assets, and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of four years. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-22-000025:notes:163]
On April 19, 2022, the Company acquired Calipsa, a technology leader in cloud-native advanced video analytics, for $40 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The Company recognized $25 million of goodwill, $20 million of identifiable intangible assets, and $5 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $19 million of developed technology and $1 million of customer relationships that will be amortized over a period of fifteen and three years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-22-000025:notes:164]
On March 23, 2022, the Company acquired TETRA Ireland, the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. As a result of the acquisition, the Company recognized a $21 million gain recorded within Other income (expense) on the Company's initial minority interest. The Company recognized $47 million of goodwill, $90 million of identifiable intangible assets, and $6 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $83 million of customer relationships and $7 million of trade names that will be amortized over a period of twelve years and fourteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-22-000025:notes:165]
On March 3, 2022, the Company acquired Ava, a global provider of cloud-native video security and analytics, for $388 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The Company recognized $267 million of goodwill, $165 million of identifiable intangible assets, and $44 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $144 million of developed technology and $21 million of customer relationships that will be amortized over a period of fourteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-22-000025:notes:166]
On December 16, 2021, the Company acquired 911 Datamaster, an NG911 data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of two years. This acquisition reinforces Motorola Solutions’ commitment to being a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The Company recognized $21 million of goodwill, $16 million of identifiable intangible assets, and $2 million of net liabilities. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $9 million of developed technology and $7 million of customer relationships that will be amortized over a period of nine years and fourteen years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts and goodwill may be subject to change.

[0000068505-22-000025:notes:167]
On October 29, 2021, the Company acquired Envysion, a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy to be a global leader in end-to-end video security solutions within Video. The Company recognized $79 million of goodwill, $37 million of identifiable intangible assets, and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $26 million of customer relationships, $6 million of developed technology, and $5 million of trade names that will be amortized over a period of fifteen, four, and nine years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts and goodwill may be subject to change.

[0000068505-22-000025:notes:168]
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments of up to $40 million based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. The Company estimated there will be no payout related to the earn-out payments. This acquisition expands the Company's ability to combine video security and access control solutions within Video to help support enterprise customers. The Company recognized $234 million of goodwill, $73 million of identifiable intangible assets, and $9 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $57 million of developed technology and $16 million of customer relationships that will be amortized over a period of sixteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts and goodwill may be subject to change.

[0000068505-22-000025:notes:169]
[same as prior period, unchanged from 0000068505-22-000019:notes:159]

[0000068505-22-000025:notes:170]
[same as prior period, unchanged from 0000068505-22-000019:notes:160]

[0000068505-22-000025:notes:171]
|  | July 2, 2022 |  | December 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,003 |  |  | $ | 318 |  |  | $ | 828 |  |  | $ | 278 |  |
| Customer-related | 1,391 |  |  | 848 |  |  | 1,367 |  |  | 836 |  |
| Other intangibles | 87 |  |  | 60 |  |  | 84 |  |  | 60 |  |
|  | $ | 2,481 |  |  | $ | 1,226 |  |  | $ | 2,279 |  |  | $ | 1,174 |  |

[0000068505-22-000025:notes:172]
Amortization expense on intangible assets was $65 million and $131 million for the three and six months ended July 2, 2022, respectively. Amortization expense on intangible assets was $58 million and $116 million for the three and six months ended July 3, 2021, respectively. As of July 2, 2022, annual amortization expense is estimated to be $252 million in 2022, $160 million in 2023, $123 million in 2024, $110 million in 2025, $102 million in 2026, and $92 million in 2027.

[0000068505-22-000025:notes:173]
[same as prior period, unchanged from 0000068505-22-000019:notes:163]

[0000068505-22-000025:notes:174]
|  | July 2, 2022 |  | December 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 899 |  |  | $ | 222 |  |  | $ | 766 |  |  | $ | 184 |  |
| Software and Services | 1,582 |  |  | 1,004 |  |  | 1,513 |  |  | 990 |  |
|  | $ | 2,481 |  |  | $ | 1,226 |  |  | $ | 2,279 |  |  | $ | 1,174 |  |

[0000068505-22-000025:notes:175]
[same as prior period, unchanged from 0000068505-22-000019:notes:165]

[0000068505-22-000025:notes:176]
The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2022 to July 2, 2022:

[0000068505-22-000025:notes:177]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2022 | $ | 1,236 |  |  | $ | 1,329 |  |  | $ | 2,565 |  |
| Goodwill acquired | 209 |  |  | 142 |  |  | 351 |  |
| Purchase accounting adjustments | 4 |  |  | (25) |  |  | (21) |  |
| Foreign currency | — |  |  | (22) |  |  | (22) |  |
| Balance as of July 2, 2022 | $ | 1,449 |  |  | $ | 1,424 |  |  | $ | 2,873 |  |
