# MSI note change history — 0000068505-23-000026 → 0000068505-23-000039


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-03):
[0000068505-23-000039:note_history:1]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. Hytera made quarterly royalty payments on October 31, 2022, January 31, 2023, April 25, 2023 and July 25, 2023 into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow. On July 11, 2023, the Court denied Hytera's modification and stay motions and stated that it will consider the Company's contempt motion on August 8, 2023, if Hytera has not yet made the deposit previously due on July 31, 2022, into the escrow account. The Court subsequently set the Company's contempt motion for hearing on August 17, 2023.
  (was, 2023-05-04, similarity 0.8522):
[0000068505-23-000026:note_history:1]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment in July. Hytera made quarterly royalty payments on October 31, 2022, January 31, 2023 and April 25, 2023, into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow.

- added (2023-08-03):
[0000068505-23-000039:note_history:2]
On August 2, 2022, Hytera appealed the Court's judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. The parties have now submitted all briefs and responses on Hytera's appeal and the Company's cross-appeal. The Court of Appeals has not set an oral argument date yet.

- removed (2023-08-03):
[0000068505-23-000026:note_history:3]
On August 2, 2022, Hytera appealed the Court's judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. On November 15, 2022, Hytera filed its appellate court brief in the Court of Appeals. The Company filed its response brief with the appellate court on February 13, 2023. Hytera’s reply brief is due May 1, 2023.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-03):
[0000068505-23-000039:note_history:4]
Basis of Presentation
The condensed consolidated financial statements as of July 1, 2023 and for the three and six months ended July 1, 2023 and July 2, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2023-05-04, similarity 0.9451):
[0000068505-23-000026:note_history:4]
Basis of Presentation
The condensed consolidated financial statements as of April 1, 2023 and for the three months ended April 1, 2023 and April 2, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2023-08-03):
[0000068505-23-000039:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three and six months ended July 1, 2023 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2023-05-04, similarity 0.8167):
[0000068505-23-000026:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three months ended April 1, 2023 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2023-08-03):
[0000068505-23-000039:note_history:6]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center.
  (was, 2023-05-04, similarity 0.6468):
[0000068505-23-000026:note_history:6]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center. In January 2023, we began using Command Center as a naming convention, eliminating the "Software" descriptor from Command Center Software in order to inform investors that the Company has software components more broadly across all technologies; this name change does not require any financial information to be reclassified from previous periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-03):
[0000068505-23-000039:note_history:7]
Debt and Credit Facilities
As of July 1, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 1, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.
  (was, 2023-05-04, similarity 0.9918):
[0000068505-23-000026:note_history:7]
Debt and Credit Facilities
As of April 1, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 1, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

- changed (2023-08-03):
[0000068505-23-000039:note_history:8]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 1, 2023 the Company had no outstanding debt under the commercial paper program.
  (was, 2023-05-04, similarity 0.9934):
[0000068505-23-000026:note_history:8]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 1, 2023 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-03):
[0000068505-23-000039:note_history:9]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 1, 2023 and July 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2023-05-04, similarity 0.9282):
[0000068505-23-000026:note_history:9]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 1, 2023 and April 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2023-08-03):
[0000068505-23-000039:note_history:10]
|  | Three Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |  | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |
| International | 412 |  |  | 350 |  |  | 762 |  |  | 322 |  |  | 334 |  |  | 656 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |  | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |
| Video | 287 |  |  | 146 |  |  | 433 |  |  | 247 |  |  | 123 |  |  | 370 |  |
| Command Center | — |  |  | 194 |  |  | 194 |  |  | — |  |  | 162 |  |  | 162 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 796 |  |  | $ | 875 |  |  | $ | 1,671 |  |  | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |
| Indirect | 641 |  |  | 91 |  |  | 732 |  |  | 574 |  |  | 77 |  |  | 651 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
  (was, 2023-05-04, similarity 0.9851):
[0000068505-23-000026:note_history:10]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |  | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |
| International | 353 |  |  | 326 |  |  | 679 |  |  | 272 |  |  | 315 |  |  | 587 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |  | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |
| Video | 223 |  |  | 136 |  |  | 359 |  |  | 194 |  |  | 113 |  |  | 307 |  |
| Command Center | — |  |  | 155 |  |  | 155 |  |  | — |  |  | 130 |  |  | 130 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |  | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |
| Indirect | 580 |  |  | 73 |  |  | 653 |  |  | 447 |  |  | 87 |  |  | 534 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |

- added (2023-08-03):
[0000068505-23-000039:note_history:11]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |  | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |
| International | 765 |  |  | 676 |  |  | 1,441 |  |  | 594 |  |  | 650 |  |  | 1,244 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |  | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |
| Video | 510 |  |  | 282 |  |  | 792 |  |  | 441 |  |  | 236 |  |  | 677 |  |
| Command Center | — |  |  | 349 |  |  | 349 |  |  | — |  |  | 292 |  |  | 292 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,519 |  |  | $ | 1,670 |  |  | $ | 3,189 |  |  | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |
| Indirect | 1,221 |  |  | 164 |  |  | 1,385 |  |  | 1,021 |  |  | 164 |  |  | 1,185 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |

- removed (2023-08-03):
[0000068505-23-000026:note_history:12]
|  | Three Months Ended |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-03):
[0000068505-23-000039:note_history:13]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 1, 2023 and July 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2023-05-04, similarity 0.9282):
[0000068505-23-000026:note_history:13]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 1, 2023 and April 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2023-08-03):
[0000068505-23-000039:note_history:14]
|  | Three Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |  | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |
| International | 412 |  |  | 350 |  |  | 762 |  |  | 322 |  |  | 334 |  |  | 656 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |  | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |
| Video | 287 |  |  | 146 |  |  | 433 |  |  | 247 |  |  | 123 |  |  | 370 |  |
| Command Center | — |  |  | 194 |  |  | 194 |  |  | — |  |  | 162 |  |  | 162 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 796 |  |  | $ | 875 |  |  | $ | 1,671 |  |  | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |
| Indirect | 641 |  |  | 91 |  |  | 732 |  |  | 574 |  |  | 77 |  |  | 651 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
  (was, 2023-05-04, similarity 0.9851):
[0000068505-23-000026:note_history:14]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |  | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |
| International | 353 |  |  | 326 |  |  | 679 |  |  | 272 |  |  | 315 |  |  | 587 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |  | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |
| Video | 223 |  |  | 136 |  |  | 359 |  |  | 194 |  |  | 113 |  |  | 307 |  |
| Command Center | — |  |  | 155 |  |  | 155 |  |  | — |  |  | 130 |  |  | 130 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |  | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |
| Indirect | 580 |  |  | 73 |  |  | 653 |  |  | 447 |  |  | 87 |  |  | 534 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |

- added (2023-08-03):
[0000068505-23-000039:note_history:15]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |  | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |
| International | 765 |  |  | 676 |  |  | 1,441 |  |  | 594 |  |  | 650 |  |  | 1,244 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |  | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |
| Video | 510 |  |  | 282 |  |  | 792 |  |  | 441 |  |  | 236 |  |  | 677 |  |
| Command Center | — |  |  | 349 |  |  | 349 |  |  | — |  |  | 292 |  |  | 292 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,519 |  |  | $ | 1,670 |  |  | $ | 3,189 |  |  | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |
| Indirect | 1,221 |  |  | 164 |  |  | 1,385 |  |  | 1,021 |  |  | 164 |  |  | 1,185 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |

- added (2023-08-03):
[0000068505-23-000039:note_history:16]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 1, 2023 was $9.4 billion. A total of $4.8 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of July 1, 2023, of which $3.0 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.6 billion was from Software and Services performance obligations that were not yet satisfied as of July 1, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

- changed (2023-08-03):
[0000068505-23-000039:note_history:17]
| (In millions) | July 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,513 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,033 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,764 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 382 |  |  | 363 |  |  |  |  |  |
  (was, 2023-05-04, similarity 0.6514):
[0000068505-23-000026:note_history:17]
| (In millions) | April 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 119 |  |  | 130 |  |  |  |  |  |

- added (2023-08-03):
[0000068505-23-000039:note_history:18]
Revenue recognized during the three months ended July 1, 2023 which was previously included in Contract liabilities as of April 1, 2023 was $502 million, compared to $456 million of revenue recognized during the three months ended July 2, 2022 which was previously included in Contract liabilities as of April 2, 2022. Revenue recognized during the six months ended July 1, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $824 million, compared to $712 million recognized during the six months ended July 2, 2022 which was previously included in Contract liabilities as of December 31, 2021. The Company reversed $10 million of revenue during the three months ended July 1, 2023 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to no reversals for the three months ended July 2, 2022, primarily driven by changes in the estimates of progress on system contracts. Revenue of $15 million was reversed during the six months ended July 1, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $22 million of reversals for the six months ended July 2, 2022.

- changed (2023-08-03):
[0000068505-23-000039:note_history:19]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 1, 2023 and July 2, 2022.
  (was, 2023-05-04, similarity 0.9203):
[0000068505-23-000026:note_history:19]
There were no material expected credit losses recorded on contract assets during each of the three months ended April 1, 2023 and April 2, 2022.

- added (2023-08-03):
[0000068505-23-000039:note_history:20]
| (In millions) | July 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 84 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 105 |  |  | 130 |  |  |  |  |  |

- changed (2023-08-03):
[0000068505-23-000039:note_history:21]
Amortization of non-current contract cost assets was $16 million and $35 million for the three and six months ended July 1, 2023, respectively, and $13 million and $26 million for the three and six months ended July 2, 2022, respectively.
  (was, 2023-05-04, similarity 0.6239):
[0000068505-23-000026:note_history:21]
Amortization of non-current contract cost assets was $17 million for both the three months ended April 1, 2023, and April 2, 2022.

- removed (2023-08-03):
[0000068505-23-000026:note_history:22]
|  | Three Months Ended |

- removed (2023-08-03):
[0000068505-23-000026:note_history:23]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 1, 2023 was $9.2 billion. A total of $4.7 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of April 1, 2023, of which $2.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.5 billion was from Software and Services performance obligations that were not yet

- removed (2023-08-03):
[0000068505-23-000026:note_history:24]
satisfied as of April 1, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- removed (2023-08-03):
[0000068505-23-000026:note_history:25]
| (In millions) | April 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,340 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,024 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,793 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 378 |  |  | 363 |  |  |  |  |  |

- removed (2023-08-03):
[0000068505-23-000026:note_history:26]
Revenue recognized during the three months ended April 1, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $474 million, compared to $456 million of revenue recognized during the three months ended April 2, 2022 which was previously included in Contract liabilities as of December 31, 2021. Revenue of $10 million was reversed during the three months ended April 1, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $17 million of reversals for the three months ended April 2, 2022.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2023-08-03):
[0000068505-23-000026:note_history:27]
Subsequent EventsIn October 2021, the United Kingdom’s Competition and Markets Authority (the "CMA") announced that it had opened a market investigation into the Mobile Radio Network for the Police and Emergency Services. This investigation affects Airwave, the Company's private mobile radio communications network that the Company acquired in 2016. Airwave provides mission-critical voice and data communications to public emergency service agencies in Great Britain.Subsequent to the quarter, the CMA issued its final decision which states it intends to impose a prospective price control on Airwave. As a result of the issuance of a final decision from the CMA subsequent to quarter close on April 1, 2023, the Company tested the Airwave asset group for impairment, noting the assets are expected to be recoverable
