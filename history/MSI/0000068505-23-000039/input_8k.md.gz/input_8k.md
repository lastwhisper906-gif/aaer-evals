# MSI 8-K — 0000068505-23-000035 filed 2023-08-03

## item codes, every 8-K on or before 2023-08-03

- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2023-08-03

- none on or before 2023-08-03

## item 2.02 — earnings release, exhibit 99.1

[0000068505-23-000035:8k_2_02:1]
EX-99.1
2
msiq22023pressrelease.htm
EX-99.1

[0000068505-23-000035:8k_2_02:2]
Document

[0000068505-23-000035:8k_2_02:3]
Exhibit 99.1

[0000068505-23-000035:8k_2_02:4]
Motorola Solutions Reports Second Quarter 2023 Financial Results

[0000068505-23-000035:8k_2_02:5]
Company raises full-year revenue and earnings outlook again driven by record Q2 orders and backlog

[0000068505-23-000035:8k_2_02:6]
•Sales of $2.4 billion, up 12% versus a year ago

[0000068505-23-000035:8k_2_02:7]
◦Products and Systems Integration sales up 12%

[0000068505-23-000035:8k_2_02:8]
◦Software and Services sales up 13%

[0000068505-23-000035:8k_2_02:9]
•GAAP earnings per share (EPS) of $2.15, up 62% versus a year ago

[0000068505-23-000035:8k_2_02:10]
•Non-GAAP EPS* of $2.65, up 28% versus a year ago

[0000068505-23-000035:8k_2_02:11]
•GAAP operating margin of 21.6%, up 490 bps versus a year ago

[0000068505-23-000035:8k_2_02:12]
•Non-GAAP operating margin* of 26.7%, up 350 bps versus a year ago

[0000068505-23-000035:8k_2_02:13]
•Record Q2 ending backlog of $14.3 billion, up 6% versus a year ago, driven by record Q2 orders in both segments

[0000068505-23-000035:8k_2_02:14]
CHICAGO – August 3, 2023 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the second quarter of 2023.

[0000068505-23-000035:8k_2_02:15]
“Q2 was another exceptional quarter across the board, highlighted by double-digit revenue and operating earnings growth in both segments,” said Greg Brown, chairman and CEO. “The continued strong demand we’re seeing in all technologies and regions resulted in record second-quarter orders and record ending backlog. Our momentum entering the second half is strong and we’re again raising our revenue and earnings guidance for the full year.”

[0000068505-23-000035:8k_2_02:16]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-23-000035:8k_2_02:17]
|  | Q2 2023 |  | Q2 2022 | % Change |
| Sales | $2,403 |  | $2,140 | 12 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $518 |  | $358 | 45 | % |
| % of Sales | 21.6 | % |  | 16.7 | % |  |
| EPS | $2.15 |  | $1.33 | 62 | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $641 |  | $497 | 29 | % |
| % of Sales | 26.7 | % |  | 23.2 | % |  |
| EPS | $2.65 |  | $2.07 | 28 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,437 |  | $1,285 | 12 | % |
| GAAP Operating Earnings | $212 |  | $118 | 80 | % |
| % of Sales | 14.8 | % |  | 9.2 | % |  |
| Non-GAAP Operating Earnings* | $285 |  | $188 | 52 | % |
| % of Sales | 19.8 | % |  | 14.6 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $966 |  | $855 | 13 | % |
| GAAP Operating Earnings | $306 |  | $240 | 28 | % |
| % of Sales | 31.7 | % |  | 28.1 | % |  |
| Non-GAAP Operating Earnings* | $356 |  | $309 | 15 | % |
| % of Sales | 36.9 | % |  | 36.1 | % |  |

[0000068505-23-000035:8k_2_02:18]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.50 per diluted share related to highlighted items, including share-based compensation expenses and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-23-000035:8k_2_02:19]
1

[0000068505-23-000035:8k_2_02:20]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-23-000035:8k_2_02:21]
•Revenue - Sales were $2.4 billion, up 12% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $20 million and currency headwinds were $23 million in the quarter. The Products and Systems Integration segment grew 12%, driven by growth in Land Mobile Radio Communications ("LMR") and Video Security and Access Control ("Video"). The Software and Services segment grew 13%, driven by growth in LMR, Command Center and Video.

[0000068505-23-000035:8k_2_02:22]
•Operating margin - GAAP operating margin was 21.6% of sales, up from 16.7% in the year-ago quarter and Non-GAAP operating margin was 26.7% of sales, up 350 basis points from 23.2% in the year-ago quarter.  The increase in both GAAP and Non-GAAP operating margin was driven by higher sales, inclusive of higher pricing, lower direct material costs, and improved operating leverage.

[0000068505-23-000035:8k_2_02:23]
•Taxes - The GAAP effective tax rate was 23.4%, down from 23.7% in the year-ago quarter. The non-GAAP effective tax rate was 22.9%, up from 22.3% in the year-ago quarter, primarily driven by a higher UK tax rate in the current year.

[0000068505-23-000035:8k_2_02:24]
•Cash flow - Operating cash flow was $93 million, compared to $10 million in the year-ago quarter and free cash flow was $40 million compared to a usage of $49 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter increased primarily due to higher earnings, net of non-cash charges and improved working capital, partially offset by higher cash taxes.

[0000068505-23-000035:8k_2_02:25]
•Capital allocation - During the quarter, the company repurchased $224 million of shares, paid $148 million in cash dividends, and incurred $53 million of capital expenditures.

[0000068505-23-000035:8k_2_02:26]
•Backlog - The company ended the quarter with record Q2 backlog of $14.3 billion, up 6% or $856 million from the year-ago quarter. Products and Systems Integration segment backlog was up $496 million, or 11%, driven primarily by strong LMR demand. Software and Services segment backlog was up $360 million or 4%, driven by an increase in multi-year software and services contracts in North America, partially offset by revenue recognition for the Airwave contract and a reduction related to the exit from the ESN contract.

[0000068505-23-000035:8k_2_02:27]
2

[0000068505-23-000035:8k_2_02:28]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-23-000035:8k_2_02:29]
Software and Services

[0000068505-23-000035:8k_2_02:30]
•$34M video order for the Virginia State Police, which included our largest ever in-car video order

[0000068505-23-000035:8k_2_02:31]
•$15M LMR service agreement with City of Baltimore, MD

[0000068505-23-000035:8k_2_02:32]
•$13M LMR managed services agreement renewal in Latin America

[0000068505-23-000035:8k_2_02:33]
•$12M command center order for a U.S. federal customer

[0000068505-23-000035:8k_2_02:34]
•$8M LMR service agreement with a U.S. federal customer

[0000068505-23-000035:8k_2_02:35]
Products and Systems Integration

[0000068505-23-000035:8k_2_02:36]
•$145M P25 system upgrade for Kern County, CA

[0000068505-23-000035:8k_2_02:37]
•$41M P25 system and device order for a U.S. federal customer

[0000068505-23-000035:8k_2_02:38]
•$31M P25 system expansion for Ventura County, CA

[0000068505-23-000035:8k_2_02:39]
•$19M P25 device order for a U.S. federal customer

[0000068505-23-000035:8k_2_02:40]
•$6M fixed video order for a U.S. healthcare customer

[0000068505-23-000035:8k_2_02:41]
BUSINESS OUTLOOK

[0000068505-23-000035:8k_2_02:42]
•Third quarter 2023 - The company expects revenue growth of approximately 6%, compared to the third quarter of 2022. The company expects non-GAAP EPS in the range of $2.99 to $3.04 per share. This assumes approximately 172 million fully diluted shares and a non-GAAP effective tax rate between 23% and 24%.

[0000068505-23-000035:8k_2_02:43]
•Full-year 2023 - The company now expects revenue in the range of $9.875 billion to $9.900 billion, up from its prior guidance of $9.725 billion to $9.775 billion, and non-GAAP EPS of between $11.40 and $11.48 per share, up from its prior guidance of between $11.21 and $11.29 per share. This outlook assumes approximately $25 million in foreign exchange headwinds, approximately 172 million fully diluted shares and a non-GAAP effective tax rate between 23% and 24%.

[0000068505-23-000035:8k_2_02:44]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-23-000035:8k_2_02:45]
RECENT EVENTS

[0000068505-23-000035:8k_2_02:46]
CMA UPDATE

[0000068505-23-000035:8k_2_02:47]
In October 2021, the United Kingdom’s Competition and Markets Authority (the "CMA") announced that it had opened a market investigation into the Mobile Radio Network Services market. This investigation included Airwave, the company's private mobile radio communications network that it acquired in 2016. Airwave provides mission-critical voice and data communications to emergency services and other agencies in Great Britain.

[0000068505-23-000035:8k_2_02:48]
On April 5, 2023, the CMA issued its final decision which stated it will impose a prospective price control on Airwave. The company strongly disagrees with the CMA’s final decision and it filed an appeal with the Competition Appeal Tribunal (“CAT”) on June 5, 2023. On July 31, 2023, the CMA adopted a remedies order which implements the price control set out in its final decision; however, the remedies order has been suspended until the CAT’s judgment on the company’s appeal. The CAT appeal hearing took place on August 2 and 3, 2023. Depending on the outcome, further appeals may occur throughout 2023 and 2024.

[0000068505-23-000035:8k_2_02:49]
3

[0000068505-23-000035:8k_2_02:50]
Based on the adoption of the remedies order, beginning August 1, 2023, revenue under the Airwave contract will be recognized in accordance with the prospective price control until a successful appeal. Further, as a result of the issuance of a final decision from the CMA during the quarter ended July 1, 2023, the company has tested its Airwave asset group for impairment, noting the assets are expected to be recoverable.

[0000068505-23-000035:8k_2_02:51]
MACROECONOMIC EVENTS

[0000068505-23-000035:8k_2_02:52]
Since the beginning of the COVID-19 pandemic, the company has navigated disruptions in its supply chain, in particular challenges in procuring certain semiconductor components along with diminished transportation capacity and higher freight costs. During 2023 the company experienced gradual improvement in the market conditions influenced by the effects of the COVID-19 pandemic and the inflationary cost environment, particularly with respect to availability of materials in the semiconductor market. Where appropriate, the company has taken pricing actions around its product and service offerings to mitigate its exposure to inflationary pressures and benefited from these adjustments during the first half of 2023, and expects to continue to benefit from such adjustments in the second half of 2023. The company continues to remain focused on improving its supplier network, engineering alternative designs and working to reduce supply shortages and effectively manage costs. In addition, the company continues to actively manage its inventory in an effort to enable continuity of supply and services to its customers, which includes making changes that diversify the footprint of its supply chain operations. The company expects to maintain elevated levels of inventory until supply conditions stabilize.

[0000068505-23-000035:8k_2_02:53]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, August 3. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-23-000035:8k_2_02:54]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-23-000035:8k_2_02:55]
A comparison of results from operations is as follows:

[0000068505-23-000035:8k_2_02:56]
|  | Q2 2023 | Q2 2022 |
| Net sales | $2,403 | $2,140 |
| Gross margin | $1,189 | $990 |
| Operating earnings | $518 | $358 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $371 | $228 |
| Diluted EPS | $2.15 | $1.33 |
| Weighted average diluted common shares outstanding | 172.6 |  | 170.9 |  |

[0000068505-23-000035:8k_2_02:57]
4

[0000068505-23-000035:8k_2_02:58]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-23-000035:8k_2_02:59]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-23-000035:8k_2_02:60]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-23-000035:8k_2_02:61]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-23-000035:8k_2_02:62]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-23-000035:8k_2_02:63]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-23-000035:8k_2_02:64]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-23-000035:8k_2_02:65]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things,

[0000068505-23-000035:8k_2_02:66]
5

[0000068505-23-000035:8k_2_02:67]
injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-23-000035:8k_2_02:68]
On December 17, 2020, the Court held that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court’s previous July 5, 2022 royalty order. On August 3, 2022, the company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. Hytera made quarterly royalty payments on October 31, 2022, January 31, 2023, April 25, 2023 and July 25, 2023 into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow. On July 11, 2023, the Court denied Hytera's modification and stay motions and stated that it will consider the company's contempt motion on August 8, 2023, if Hytera has not yet made the deposit previously due on July 31, 2022, into the escrow account. The Court subsequently set the company's contempt motion for hearing on August 17, 2023.

[0000068505-23-000035:8k_2_02:69]
On August 2, 2022,  Hytera appealed the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals").The company filed its cross-appeal on August 5, 2022. The parties have now submitted all briefs and responses on Hytera's appeal and the company's cross-appeal. The Court of Appeals has not set an oral argument date yet.

[0000068505-23-000035:8k_2_02:70]
Separate from the company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including $13 million to the company. On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gain was recorded to Other charges (income).

[0000068505-23-000035:8k_2_02:71]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the $13 million of proceeds realized in Q1 2022. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-23-000035:8k_2_02:72]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based

[0000068505-23-000035:8k_2_02:73]
6

[0000068505-23-000035:8k_2_02:74]
compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-23-000035:8k_2_02:75]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-23-000035:8k_2_02:76]
7

[0000068505-23-000035:8k_2_02:77]
FORWARD LOOKING STATEMENTS

[0000068505-23-000035:8k_2_02:78]
8

[0000068505-23-000035:8k_2_02:79]
ABOUT MOTOROLA SOLUTIONS

[0000068505-23-000035:8k_2_02:80]
Motorola Solutions is a global leader in public safety and enterprise security. Our solutions in land mobile radio communications, video security and access control and command center, bolstered by managed & support services, create an integrated technology ecosystem to help make communities safer and businesses stay productive and secure. At Motorola Solutions, we’re ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-23-000035:8k_2_02:81]
MEDIA CONTACT

[0000068505-23-000035:8k_2_02:82]
Alexandra Reynolds

[0000068505-23-000035:8k_2_02:83]
Motorola Solutions

[0000068505-23-000035:8k_2_02:84]
+1 312-965-3968

[0000068505-23-000035:8k_2_02:85]
alexandra.reynolds@motorolasolutions.com

[0000068505-23-000035:8k_2_02:86]
INVESTOR CONTACT

[0000068505-23-000035:8k_2_02:87]
Tim Yocum

[0000068505-23-000035:8k_2_02:88]
Motorola Solutions

[0000068505-23-000035:8k_2_02:89]
+1 847-576-6899

[0000068505-23-000035:8k_2_02:90]
Tim.Yocum@motorolasolutions.com

[0000068505-23-000035:8k_2_02:91]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2023 Motorola Solutions, Inc. All rights reserved.

[0000068505-23-000035:8k_2_02:92]
9

[0000068505-23-000035:8k_2_02:93]
GAAP-1

[0000068505-23-000035:8k_2_02:94]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:95]
Condensed Consolidated Statements of Operations

[0000068505-23-000035:8k_2_02:96]
(In millions, except per share amounts)

[0000068505-23-000035:8k_2_02:97]
|  | Three Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| Net sales from products | $ | 1,349 |  |  | $ | 1,212 |  |
| Net sales from services | 1,054 |  |  | 928 |  |
| Net sales | 2,403 |  |  | 2,140 |  |
| Costs of products sales | 636 |  |  | 637 |  |
| Costs of services sales | 578 |  |  | 513 |  |
| Costs of sales | 1,214 |  |  | 1,150 |  |
| Gross margin | 1,189 |  |  | 990 |  |
| Selling, general and administrative expenses | 390 |  |  | 356 |  |
| Research and development expenditures | 215 |  |  | 191 |  |
| Other charges | 23 |  |  | 20 |  |
| Intangibles amortization | 43 |  |  | 65 |  |
| Operating earnings | 518 |  |  | 358 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (57) |  |  | (56) |  |
| Other, net | 26 |  |  | (2) |  |
| Total other expense | (31) |  |  | (58) |  |
| Net earnings before income taxes | 487 |  |  | 300 |  |
| Income tax expense | 114 |  |  | 71 |  |
| Net earnings | 373 |  |  | 229 |  |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 371 |  |  | $ | 228 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 2.21 |  |  | $ | 1.36 |  |
| Diluted | $ | 2.15 |  |  | $ | 1.33 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 167.5 |  |  | 167.2 |  |
| Diluted | 172.6 |  |  | 170.9 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 56.1 | % |  | 56.6 | % |
| Net sales from services | 43.9 | % |  | 43.4 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.1 | % |  | 52.6 | % |
| Costs of services sales | 54.8 | % |  | 55.3 | % |
| Costs of sales | 50.5 | % |  | 53.7 | % |
| Gross margin | 49.5 | % |  | 46.3 | % |
| Selling, general and administrative expenses | 16.2 | % |  | 16.6 | % |
| Research and development expenditures | 8.9 | % |  | 8.9 | % |
| Other charges | 1.0 | % |  | 0.9 | % |
| Intangibles amortization | 1.8 | % |  | 3.0 | % |
| Operating earnings | 21.6 | % |  | 16.7 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.4) | % |  | (2.6) | % |
| Other, net | 1.1 | % |  | (0.1) | % |
| Total other expense | (1.3) | % |  | (2.7) | % |
| Net earnings before income taxes | 20.3 | % |  | 14.0 | % |
| Income tax expense | 4.7 | % |  | 3.3 | % |
| Net earnings | 15.5 | % |  | 10.7 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 15.4 | % |  | 10.7 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-23-000035:8k_2_02:98]
10

[0000068505-23-000035:8k_2_02:99]
GAAP-2

[0000068505-23-000035:8k_2_02:100]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:101]
Condensed Consolidated Statements of Operations

[0000068505-23-000035:8k_2_02:102]
(In millions, except per share amounts)

[0000068505-23-000035:8k_2_02:103]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| Net sales from products | $ | 2,573 |  |  | $ | 2,258 |  |
| Net sales from services | 2,001 |  |  | 1,774 |  |
| Net sales | 4,574 |  |  | 4,032 |  |
| Costs of products sales | 1,209 |  |  | 1,185 |  |
| Costs of services sales | 1,130 |  |  | 1,001 |  |
| Costs of sales | 2,339 |  |  | 2,186 |  |
| Gross margin | 2,235 |  |  | 1,846 |  |
| Selling, general and administrative expenses | 757 |  |  | 692 |  |
| Research and development expenditures | 426 |  |  | 380 |  |
| Other charges | 37 |  |  | 46 |  |
| Intangibles amortization | 98 |  |  | 131 |  |
| Operating earnings | 917 |  |  | 597 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (111) |  |  | (112) |  |
| Gain on sales of investments and businesses, net | 1 |  |  | 2 |  |
| Other, net | 39 |  |  | 33 |  |
| Total other expense | (71) |  |  | (77) |  |
| Net earnings before income taxes | 846 |  |  | 520 |  |
| Income tax expense | 194 |  |  | 23 |  |
| Net earnings | 652 |  |  | 497 |  |
| Less: Earnings attributable to non-controlling interests | 3 |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 649 |  |  | $ | 495 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.88 |  |  | $ | 2.95 |  |
| Diluted | $ | 3.76 |  |  | $ | 2.88 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 167.4 |  |  | 167.6 |  |
| Diluted | 172.5 |  |  | 172.0 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 56.3 | % |  | 56.0 | % |
| Net sales from services | 43.7 | % |  | 44.0 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.0 | % |  | 52.5 | % |
| Costs of services sales | 56.5 | % |  | 56.4 | % |
| Costs of sales | 51.1 | % |  | 54.2 | % |
| Gross margin | 48.9 | % |  | 45.8 | % |
| Selling, general and administrative expenses | 16.6 | % |  | 17.2 | % |
| Research and development expenditures | 9.3 | % |  | 9.4 | % |
| Other charges | 0.8 | % |  | 1.1 | % |
| Intangibles amortization | 2.1 | % |  | 3.2 | % |
| Operating earnings | 20.0 | % |  | 14.8 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.4) | % |  | (2.8) | % |
| Gain on sales of investments and businesses, net | — | % |  | — | % |
| Other, net | 0.9 | % |  | 0.8 | % |
| Total other expense | (1.6) | % |  | (1.9) | % |
| Net earnings before income taxes | 18.5 | % |  | 12.9 | % |
| Income tax expense | 4.2 | % |  | 0.6 | % |
| Net earnings | 14.3 | % |  | 12.3 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 14.2 | % |  | 12.3 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-23-000035:8k_2_02:104]
11

[0000068505-23-000035:8k_2_02:105]
GAAP-3

[0000068505-23-000035:8k_2_02:106]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:107]
Condensed Consolidated Balance Sheets

[0000068505-23-000035:8k_2_02:108]
(In millions)

[0000068505-23-000035:8k_2_02:109]
|  | July 1, 2023 |  | December 31, 2022 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 710 |  |  | $ | 1,325 |  |
| Accounts receivable, net | 1,513 |  |  | 1,518 |  |
| Contract assets | 1,033 |  |  | 974 |  |
| Inventories, net | 1,020 |  |  | 1,055 |  |
| Other current assets | 350 |  |  | 383 |  |
| Total current assets | 4,626 |  |  | 5,255 |  |
| Property, plant and equipment, net | 935 |  |  | 927 |  |
| Operating lease assets | 478 |  |  | 485 |  |
| Investments | 162 |  |  | 147 |  |
| Deferred income taxes | 1,172 |  |  | 1,036 |  |
| Goodwill | 3,295 |  |  | 3,312 |  |
| Intangible assets, net | 1,261 |  |  | 1,342 |  |
| Other assets | 323 |  |  | 310 |  |
| Total assets | $ | 12,252 |  |  | $ | 12,814 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Current portion of long-term debt | $ | — |  |  | $ | 1 |  |
| Accounts payable | 676 |  |  | 1,062 |  |
| Contract liabilities | 1,764 |  |  | 1,859 |  |
| Accrued liabilities | 1,326 |  |  | 1,638 |  |
| Total current liabilities | 3,766 |  |  | 4,560 |  |
| Long-term debt | 6,015 |  |  | 6,013 |  |
| Operating lease liabilities | 391 |  |  | 419 |  |
| Other liabilities | 1,729 |  |  | 1,691 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 337 |  |  | 116 |  |
| Non-controlling interests | 14 |  |  | 15 |  |
| Total liabilities and stockholders’ equity | $ | 12,252 |  |  | $ | 12,814 |  |

[0000068505-23-000035:8k_2_02:110]
12

[0000068505-23-000035:8k_2_02:111]
GAAP-4

[0000068505-23-000035:8k_2_02:112]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:113]
Condensed Consolidated Statements of Cash Flows

[0000068505-23-000035:8k_2_02:114]
(In millions)

[0000068505-23-000035:8k_2_02:115]
|  | Three Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| Operating |  |  |  |
| Net earnings | $ | 373 |  |  | $ | 229 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 87 |  |  | 112 |  |
| Non-cash other charges (income) | (11) |  |  | 17 |  |
| Share-based compensation expenses | 53 |  |  | 44 |  |
| Loss from the extinguishment of long-term debt | — |  |  | 6 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (169) |  |  | (142) |  |
| Inventories | 62 |  |  | (115) |  |
| Other current assets and contract assets | 11 |  |  | (61) |  |
| Accounts payable, accrued liabilities and contract liabilities | (215) |  |  | (111) |  |
| Other assets and liabilities | 6 |  |  | (27) |  |
| Deferred income taxes | (104) |  |  | 58 |  |
| Net cash provided by operating activities | 93 |  |  | 10 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (6) |  |  | (59) |  |
| Proceeds from sales of investments and businesses, net | 1 |  |  | 2 |  |
| Capital expenditures | (53) |  |  | (59) |  |
| Net cash used for investing activities | (58) |  |  | (116) |  |
| Financing |  |  |  |
| Repayments of debt | (1) |  |  | (281) |  |
| Net proceeds from issuance of debt | — |  |  | 595 |  |
| Issuances of common stock | 10 |  |  | (1) |  |
| Purchases of common stock | (224) |  |  | (162) |  |
| Payments of dividends | (148) |  |  | (132) |  |
| Payments of dividends to non-controlling interests | (3) |  |  | (6) |  |
| Net cash provided by (used for) financing activities | (366) |  |  | 13 |  |
| Effect of exchange rate changes on total cash and cash equivalents | 19 |  |  | (68) |  |
| Net decrease in total cash and cash equivalents | (312) |  |  | (161) |  |
| Cash and cash equivalents, beginning of period | 1,022 |  |  | 878 |  |
| Cash and cash equivalents, end of period | $ | 710 |  |  | $ | 717 |  |

[0000068505-23-000035:8k_2_02:116]
13

[0000068505-23-000035:8k_2_02:117]
GAAP-5

[0000068505-23-000035:8k_2_02:118]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:119]
Condensed Consolidated Statements of Cash Flows

[0000068505-23-000035:8k_2_02:120]
(In millions)

[0000068505-23-000035:8k_2_02:121]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| Operating |  |  |  |
| Net earnings | $ | 652 |  |  | $ | 497 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 185 |  |  | 223 |  |
| Non-cash other charges (income) | (4) |  |  | 19 |  |
| Share-based compensation expenses | 108 |  |  | 81 |  |
| Gain on sales of investments and businesses, net | (1) |  |  | (2) |  |
| Loss from the extinguishment of long-term debt | — |  |  | 6 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 10 |  |  | 106 |  |
| Inventories | 36 |  |  | (277) |  |
| Other current assets and contract assets | (29) |  |  | (14) |  |
| Accounts payable, accrued liabilities and contract liabilities | (751) |  |  | (299) |  |
| Other assets and liabilities | (1) |  |  | (57) |  |
| Deferred income taxes | (120) |  |  | (121) |  |
| Net cash provided by operating activities | 85 |  |  | 162 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (10) |  |  | (571) |  |
| Proceeds from sales of investments and businesses, net | 6 |  |  | 11 |  |
| Capital expenditures | (107) |  |  | (113) |  |
| Net cash used for investing activities | (111) |  |  | (673) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | — |  |  | 595 |  |
| Repayments of debt | (1) |  |  | (283) |  |
| Issuances of common stock | 36 |  |  | 51 |  |
| Purchases of common stock | (364) |  |  | (655) |  |
| Payments of dividends | (296) |  |  | (266) |  |
| Payments of dividends to non-controlling interests | (4) |  |  | (6) |  |
| Net cash used for financing activities | (629) |  |  | (564) |  |
| Effect of exchange rate changes on total cash and cash equivalents | 40 |  |  | (82) |  |
| Net decrease in total cash and cash equivalents | (615) |  |  | (1,157) |  |
| Cash and cash equivalents, beginning of period | 1,325 |  |  | 1,874 |  |
| Cash and cash equivalents, end of period | $ | 710 |  |  | $ | 717 |  |

[0000068505-23-000035:8k_2_02:122]
14

[0000068505-23-000035:8k_2_02:123]
Non-GAAP-1

[0000068505-23-000035:8k_2_02:124]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:125]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-23-000035:8k_2_02:126]
(In millions)

[0000068505-23-000035:8k_2_02:127]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net cash provided by operating activities |  | $ | 93 |  |  | $ | 10 |  |  | $ | 85 |  |  | $ | 162 |  |
| Capital expenditures |  | (53) |  |  | (59) |  |  | (107) |  |  | (113) |  |
| Free cash flow |  | $ | 40 |  |  | $ | (49) |  |  | $ | (22) |  |  | $ | 49 |  |

[0000068505-23-000035:8k_2_02:128]
15

[0000068505-23-000035:8k_2_02:129]
Non-GAAP-2

[0000068505-23-000035:8k_2_02:130]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:131]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-23-000035:8k_2_02:132]
(In millions)

[0000068505-23-000035:8k_2_02:133]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  | Statement Line |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net earnings attributable to MSI |  |  |  | $ | 371 |  |  | $ | 228 |  |  | $ | 649 |  |  | $ | 495 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 53 |  |  | $ | 44 |  |  | $ | 108 |  |  | $ | 81 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 43 |  |  | 65 |  |  | 98 |  |  | 131 |  |
| Environmental reserve expense |  | Other charges (income) |  | 15 |  |  | — |  |  | 15 |  |  | — |  |
| Hytera-related legal expenses |  | SG&A |  | 7 |  |  | 8 |  |  | 10 |  |  | 10 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 3 |  |  | 7 |  |  | 16 |  |  | 17 |  |
| Investment impairments |  | Other (income) expense |  | 3 |  |  | — |  |  | 9 |  |  | 1 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 1 |  |  | 3 |  |  | 4 |  |  | 12 |  |
| Fixed asset impairments |  | Other charges (income) |  | 1 |  |  | 8 |  |  | 3 |  |  | 11 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | — |  |  | 4 |  |  | 2 |  |  | 14 |  |
| Loss from extinguishment of long-term debt |  | Other (income) expense |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Legal settlements |  | Other charges (income) |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | — |  |  | — |  |  | — |  |  | (2) |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | — |  |  | — |  |  | — |  |  | (13) |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | — |  |  | (1) |  |  | (2) |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (16) |  |  | 12 |  |  | (19) |  |  | 30 |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 110 |  |  | $ | 157 |  |  | $ | 245 |  |  | $ | 286 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 23 |  | 31 |  | 52 |  | 133 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 87 |  | 126 |  | 193 |  | 153 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 458 |  |  | $ | 354 |  |  | $ | 842 |  |  | $ | 648 |  |

[0000068505-23-000035:8k_2_02:134]
Calculation of Non-GAAP Tax Rate

[0000068505-23-000035:8k_2_02:135]
(In millions)

[0000068505-23-000035:8k_2_02:136]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net earnings before income taxes |  | $ | 487 |  |  | $ | 300 |  |  | $ | 846 |  |  | $ | 520 |  |
| Total Non-GAAP adjustments before income taxes* |  | 110 |  |  | 157 |  |  | 245 |  |  | 286 |  |
| Non-GAAP Net earnings before income taxes |  | 597 |  |  | 457 |  |  | 1,091 |  |  | 806 |  |
| Income tax expense |  | 114 |  |  | 71 |  |  | 194 |  |  | 23 |  |
| Income tax expense on Non-GAAP adjustments** |  | 23 |  |  | 31 |  |  | 52 |  |  | 133 |  |
| Total Non-GAAP Income tax expense |  | 137 |  |  | 102 |  |  | 246 |  |  | 156 |  |
| Non-GAAP Tax rate |  | 22.9 | % |  | 22.3 | % |  | 22.5 | % |  | 19.4 | % |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |

[0000068505-23-000035:8k_2_02:137]
16

[0000068505-23-000035:8k_2_02:138]
Non-GAAP-2

[0000068505-23-000035:8k_2_02:139]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-23-000035:8k_2_02:140]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  | Statement Line |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net earnings attributable to MSI |  |  |  | $ | 2.15 |  |  | $ | 1.33 |  |  | $ | 3.76 |  |  | $ | 2.88 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 0.30 |  |  | $ | 0.25 |  |  | $ | 0.63 |  |  | $ | 0.46 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.24 |  |  | 0.38 |  |  | 0.57 |  |  | 0.76 |  |
| Environmental reserve expense |  | Other charges (income) |  | 0.09 |  |  | — |  |  | 0.09 |  |  | — |  |
| Hytera-related legal expenses |  | SG&A |  | 0.04 |  |  | 0.05 |  |  | 0.06 |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.02 |  |  | 0.04 |  |  | 0.09 |  |  | 0.10 |  |
| Investment impairments |  | Other (income) expense |  | 0.02 |  |  | — |  |  | 0.05 |  |  | 0.01 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.01 |  |  | 0.02 |  |  | 0.02 |  |  | 0.07 |  |
| Fixed asset impairments |  | Other charges (income) |  | 0.01 |  |  | 0.05 |  |  | 0.02 |  |  | 0.06 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | — |  |  | 0.02 |  |  | 0.01 |  |  | 0.08 |  |
| Loss from extinguishment of long-term debt |  | Other (income) expense |  | — |  |  | 0.04 |  |  | — |  |  | 0.04 |  |
| Legal settlements |  | Other charges (income) |  | — |  |  | — |  |  | — |  |  | 0.06 |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | — |  |  | — |  |  | — |  |  | (0.01) |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | — |  |  | — |  |  | — |  |  | (0.07) |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | (0.12) |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | — |  |  | (0.01) |  |  | (0.01) |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (0.09) |  |  | 0.07 |  |  | (0.11) |  |  | 0.17 |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.64 |  |  | $ | 0.92 |  |  | $ | 1.42 |  |  | $ | 1.66 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.14 |  | 0.18 |  | 0.30 |  | 0.77 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.50 |  | 0.74 |  | 1.12 |  | 0.89 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 2.65 |  |  | $ | 2.07 |  |  | $ | 4.88 |  |  | $ | 3.77 |  |
| Diluted Weighted Average Common Shares |  |  |  | 172.6 |  |  | 170.9 |  |  | 172.5 |  |  | 172.0 |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |

[0000068505-23-000035:8k_2_02:141]
17

[0000068505-23-000035:8k_2_02:142]
Non-GAAP-3

[0000068505-23-000035:8k_2_02:143]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:144]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-23-000035:8k_2_02:145]
(In millions)

[0000068505-23-000035:8k_2_02:146]
|  |  | Three Months Ended |
|  |  | July 1, 2023 |  | July 2, 2022 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Operating earnings ("OE") |  | $ | 212 |  |  | $ | 306 |  |  | $ | 518 |  |  | $ | 118 |  |  | $ | 240 |  |  | $ | 358 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 38 |  |  | 15 |  |  | 53 |  |  | 32 |  |  | 12 |  |  | 44 |  |
| Intangible assets amortization expense |  | 10 |  |  | 33 |  |  | 43 |  |  | 15 |  |  | 50 |  |  | 65 |  |
| Environmental reserve expense |  | 10 |  |  | 5 |  |  | 15 |  |  | — |  |  | — |  |  | — |  |
| Hytera-related legal expenses |  | 7 |  |  | — |  |  | 7 |  |  | 8 |  |  | — |  |  | 8 |  |
| Reorganization of business charges |  | 6 |  |  | (3) |  |  | 3 |  |  | 6 |  |  | 1 |  |  | 7 |  |
| Fixed asset impairments |  | 1 |  |  | — |  |  | 1 |  |  | 6 |  |  | 2 |  |  | 8 |  |
| Operating lease asset impairments |  | 1 |  |  | — |  |  | 1 |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Acquisition-related transaction fees |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 3 |  |  | 4 |  |
| Total above-OE non-GAAP adjustments |  | 73 |  |  | 50 |  |  | 123 |  |  | 70 |  |  | 69 |  |  | 139 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 285 |  |  | $ | 356 |  |  | $ | 641 |  |  | $ | 188 |  |  | $ | 309 |  |  | $ | 497 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 14.8 | % |  | 31.7 | % |  | 21.6 | % |  | 9.2 | % |  | 28.1 | % |  | 16.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 19.8 | % |  | 36.9 | % |  | 26.7 | % |  | 14.6 | % |  | 36.1 | % |  | 23.2 | % |

[0000068505-23-000035:8k_2_02:147]
18

[0000068505-23-000035:8k_2_02:148]
Non-GAAP-4

[0000068505-23-000035:8k_2_02:149]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:150]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-23-000035:8k_2_02:151]
(In millions)

[0000068505-23-000035:8k_2_02:152]
|  |  | Six Months Ended |
|  |  | July 1, 2023 |  | July 2, 2022 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Operating earnings ("OE") |  | $ | 388 |  |  | $ | 529 |  |  | $ | 917 |  |  | $ | 157 |  |  | $ | 440 |  |  | $ | 597 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 78 |  |  | 30 |  |  | 108 |  |  | 59 |  |  | 22 |  |  | 81 |  |
| Intangible assets amortization expense |  | 23 |  |  | 75 |  |  | 98 |  |  | 30 |  |  | 101 |  |  | 131 |  |
| Reorganization of business charges |  | 17 |  |  | (1) |  |  | 16 |  |  | 14 |  |  | 3 |  |  | 17 |  |
| Environmental reserve expense |  | 10 |  |  | 5 |  |  | 15 |  |  | — |  |  | — |  |  | — |  |
| Hytera-related legal expenses |  | 10 |  |  | — |  |  | 10 |  |  | 10 |  |  | — |  |  | 10 |  |
| Operating lease asset impairments |  | 3 |  |  | 1 |  |  | 4 |  |  | 11 |  |  | 1 |  |  | 12 |  |
| Fixed asset impairments |  | 2 |  |  | 1 |  |  | 3 |  |  | 9 |  |  | 2 |  |  | 11 |  |
| Acquisition-related transaction fees |  | — |  |  | 2 |  |  | 2 |  |  | 7 |  |  | 7 |  |  | 14 |  |
| Gain on Hytera legal settlement |  | — |  |  | — |  |  | — |  |  | (13) |  |  | — |  |  | (13) |  |
| Legal settlements |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |  | 11 |  |
| Total above-OE non-GAAP adjustments |  | 143 |  |  | 113 |  |  | 256 |  |  | 127 |  |  | 147 |  |  | 274 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 531 |  |  | $ | 642 |  |  | $ | 1,173 |  |  | $ | 284 |  |  | $ | 587 |  |  | $ | 871 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 14.2 | % |  | 28.8 | % |  | 20.0 | % |  | 6.6 | % |  | 26.8 | % |  | 14.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 19.4 | % |  | 35.0 | % |  | 25.6 | % |  | 11.9 | % |  | 35.7 | % |  | 21.6 | % |

[0000068505-23-000035:8k_2_02:153]
19

[0000068505-23-000035:8k_2_02:154]
Non-GAAP-5

[0000068505-23-000035:8k_2_02:155]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000035:8k_2_02:156]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-23-000035:8k_2_02:157]
(In millions)

[0000068505-23-000035:8k_2_02:158]
|  |  | Three Months Ended |  |  |
|  |  | July 1, 2023 |  | July 2, 2022 |  | % Change |
| Net sales |  | $ | 2,403 |  |  | $ | 2,140 |  |  | 12 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 22 |  |  | 2 |  |  |  |
| Organic revenue |  | $ | 2,381 |  |  | $ | 2,138 |  |  | 11 | % |
|  |  | Six Months Ended |  |  |
|  |  | July 1, 2023 |  | July 2, 2022 |  | % Change |
| Net sales |  | $ | 4,574 |  |  | $ | 4,032 |  |  | 13 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 66 |  |  | 4 |  |  |  |
| Organic revenue |  | $ | 4,508 |  |  | $ | 4,028 |  |  | 12 | % |

[0000068505-23-000035:8k_2_02:159]
20
