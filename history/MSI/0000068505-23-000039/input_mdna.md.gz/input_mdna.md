# MSI MD&A — 0000068505-23-000039


## mdna

[0000068505-23-000039:mdna:1]
[same as prior period, unchanged from 0000068505-23-000026:mdna:1]

[0000068505-23-000039:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and six months ended July 1, 2023 and July 2, 2022, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2022 (the "Form 10-K").

[0000068505-23-000039:mdna:3]
[same as prior period, unchanged from 0000068505-23-000026:mdna:3]

[0000068505-23-000039:mdna:4]
[same as prior period, unchanged from 0000068505-23-000026:mdna:4]

[0000068505-23-000039:mdna:5]
[same as prior period, unchanged from 0000068505-23-000026:mdna:5]

[0000068505-23-000039:mdna:6]
The Company reports net sales in the following three major products and services (which we refer to as “technologies” in this Form 10-Q): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video") and Command Center.

[0000068505-23-000039:mdna:7]
[same as prior period, unchanged from 0000068505-23-000026:mdna:7]

[0000068505-23-000039:mdna:8]
[same as prior period, unchanged from 0000068505-23-000026:mdna:8]

[0000068505-23-000039:mdna:9]
[same as prior period, unchanged from 0000068505-23-000026:mdna:9]

[0000068505-23-000039:mdna:10]
Second Quarter Financial Results

[0000068505-23-000039:mdna:11]
•Net sales were $2.4 billion in the second quarter of 2023 compared to $2.1 billion in the second quarter of 2022.

[0000068505-23-000039:mdna:12]
•Operating earnings were $518 million in the second quarter of 2023 compared to $358 million in the second quarter of 2022.

[0000068505-23-000039:mdna:13]
•Net earnings attributable to Motorola Solutions, Inc. were $371 million, or $2.15 per diluted common share, in the second quarter of 2023, compared to $228 million, or $1.33 per diluted common share, in the second quarter of 2022.

[0000068505-23-000039:mdna:14]
[same as prior period, unchanged from 0000068505-23-000026:mdna:30]

[0000068505-23-000039:mdna:15]
•Operating cash flow decreased $77 million to $85 million in the first half of 2023 compared to $162 million in the first half of 2022.

[0000068505-23-000039:mdna:16]
•We repurchased $364 million of common stock and paid $296 million in dividends in the first half of 2023.

[0000068505-23-000039:mdna:17]
[same as prior period, unchanged from 0000068505-23-000026:mdna:16]

[0000068505-23-000039:mdna:18]
Since the beginning of the COVID-19 pandemic, we have navigated disruptions in our supply chain, in particular, challenges in procuring certain semiconductor components along with diminished transportation capacity and higher freight costs. During 2023 we experienced gradual improvement in the market conditions influenced by the effects of the COVID-19 pandemic and the inflationary cost environment, particularly with respect to availability of materials in the semiconductor market. Where appropriate, we have taken pricing actions around our product and service offerings to mitigate our exposure to inflationary pressures and benefited from these adjustments during the first half of 2023, and expect to continue to benefit from such adjustments in the second half of 2023. We continue to remain focused on improving our supplier network, engineering alternative designs and working to reduce supply shortages and effectively manage costs. In addition, we continue to actively manage our inventory in an effort to enable continuity of supply and services to our customers, which includes making changes that diversify the footprint of our supply chain operations. We expect to maintain elevated levels of inventory until supply conditions stabilize.

[0000068505-23-000039:mdna:19]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of July 1, 2023. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-23-000039:mdna:20]
Lastly, as a result of the challenging market conditions described above, we evaluated whether there were any impairment indicators as of July 1, 2023, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the second quarter of 2023, we concluded our assets were fairly stated and recoverable.

[0000068505-23-000039:mdna:21]
[same as prior period, unchanged from 0000068505-23-000026:mdna:22]

[0000068505-23-000039:mdna:22]
[same as prior period, unchanged from 0000068505-23-000026:mdna:23]

[0000068505-23-000039:mdna:23]
In October 2021, the United Kingdom’s Competition and Markets Authority (the "CMA") announced that it had opened a market investigation into the Mobile Radio Network Services market. This investigation included Airwave, our private mobile radio communications network that we acquired in 2016. Airwave provides mission-critical voice and data communications to emergency services and other agencies in Great Britain.

[0000068505-23-000039:mdna:24]
On April 5, 2023, the CMA issued its final decision which stated it will impose a prospective price control on Airwave. We strongly disagree with the CMA’s final decision and we filed an appeal with the Competition Appeal Tribunal ("CAT") on June 5, 2023. On July 31, 2023, the CMA adopted a remedies order which implements the price control set out in its final decision; however, the remedies order has been suspended until the CAT's judgment on our appeal. The CAT appeal hearing took place on August 2 and 3, 2023. Depending on the outcome, further appeals may occur throughout 2023 and 2024.

[0000068505-23-000039:mdna:25]
Based on the adoption of the remedies order, beginning August 1, 2023, revenue under the Airwave contract will be recognized in accordance with the prospective price control until a successful appeal. Further, as a result of the issuance of a final decision from the CMA during the quarter ended July 1, 2023, we have tested our Airwave asset group for impairment, noting the assets are expected to be recoverable.

[0000068505-23-000039:mdna:26]
[same as prior period, unchanged from 0000068505-23-000026:mdna:28]

[0000068505-23-000039:mdna:27]
[same as prior period, unchanged from 0000068505-23-000026:mdna:29]

[0000068505-23-000039:mdna:28]
28

[0000068505-23-000039:mdna:29]
[same as prior period, unchanged from 0000068505-23-000026:mdna:31]

[0000068505-23-000039:mdna:30]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | July 1, 2023 |  | % ofSales* |  | July 2, 2022 |  | % ofSales* |  | July 1, 2023 |  | % ofSales* |  | July 2, 2022 |  | % ofSales* |
| Net sales from products | $ | 1,349 |  |  |  |  | $ | 1,212 |  |  |  |  | $ | 2,573 |  |  |  |  | $ | 2,258 |  |  |  |
| Net sales from services | 1,054 |  |  |  |  | 928 |  |  |  |  | 2,001 |  |  |  |  | 1,774 |  |  |  |
| Net sales | 2,403 |  |  |  |  | 2,140 |  |  |  |  | 4,574 |  |  |  |  | 4,032 |  |  |  |
| Costs of products sales | 636 |  |  | 47.1 | % |  | 637 |  |  | 52.6 | % |  | 1,209 |  |  | 47.0 | % |  | 1,185 |  |  | 52.5 | % |
| Costs of services sales | 578 |  |  | 54.8 | % |  | 513 |  |  | 55.3 | % |  | 1,130 |  |  | 56.5 | % |  | 1,001 |  |  | 56.4 | % |
| Costs of sales | 1,214 |  |  |  |  | 1,150 |  |  |  |  | 2,339 |  |  |  |  | 2,186 |  |  |  |
| Gross margin | 1,189 |  |  | 49.5 | % |  | 990 |  |  | 46.3 | % |  | 2,235 |  |  | 48.9 | % |  | 1,846 |  |  | 45.8 | % |
| Selling, general and administrative expenses | 390 |  |  | 16.2 | % |  | 356 |  |  | 16.6 | % |  | 757 |  |  | 16.6 | % |  | 692 |  |  | 17.2 | % |
| Research and development expenditures | 215 |  |  | 8.9 | % |  | 191 |  |  | 8.9 | % |  | 426 |  |  | 9.3 | % |  | 380 |  |  | 9.4 | % |
| Other charges | 66 |  |  | 2.7 | % |  | 85 |  |  | 4.0 | % |  | 135 |  |  | 3.0 | % |  | 177 |  |  | 4.4 | % |
| Operating earnings | 518 |  |  | 21.6 | % |  | 358 |  |  | 16.7 | % |  | 917 |  |  | 20.0 | % |  | 597 |  |  | 14.8 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (57) |  |  | (2.4) | % |  | (56) |  |  | (2.6) | % |  | (111) |  |  | (2.4) | % |  | (112) |  |  | (2.8) | % |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | — |  |  | — | % |  | 1 |  |  | — | % |  | 2 |  |  | — | % |
| Other, net | 26 |  |  | 1.1 | % |  | (2) |  |  | (0.1) | % |  | 39 |  |  | 0.9 | % |  | 33 |  |  | 0.8 | % |
| Total other expense | (31) |  |  | (1.3) | % |  | (58) |  |  | (2.7) | % |  | (71) |  |  | (1.6) | % |  | (77) |  |  | (1.9) | % |
| Net earnings before income taxes | 487 |  |  | 20.3 | % |  | 300 |  |  | 14.0 | % |  | 846 |  |  | 18.5 | % |  | 520 |  |  | 12.9 | % |
| Income tax expense | 114 |  |  | 4.7 | % |  | 71 |  |  | 3.3 | % |  | 194 |  |  | 4.2 | % |  | 23 |  |  | 0.6 | % |
| Net earnings | 373 |  |  | 15.5 | % |  | 229 |  |  | 10.7 | % |  | 652 |  |  | 14.3 | % |  | 497 |  |  | 12.3 | % |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 0.1 | % |  | 1 |  |  | — | % |  | 3 |  |  | 0.1 | % |  | 2 |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 371 |  |  | 15.4 | % |  | $ | 228 |  |  | 10.7 | % |  | $ | 649 |  |  | 14.2 | % |  | $ | 495 |  |  | 12.3 | % |
| Earnings per diluted common share | $ | 2.15 |  |  |  |  | $ | 1.33 |  |  |  |  | $ | 3.76 |  |  |  |  | $ | 2.88 |  |  |  |

[0000068505-23-000039:mdna:31]
[same as prior period, unchanged from 0000068505-23-000026:mdna:33]

[0000068505-23-000039:mdna:32]
29

[0000068505-23-000039:mdna:33]
Results of Operations—Three months ended July 1, 2023 compared to three months ended July 2, 2022

[0000068505-23-000039:mdna:34]
The results of operations for the second quarter of 2023 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-23-000039:mdna:35]
[same as prior period, unchanged from 0000068505-23-000026:mdna:37]

[0000068505-23-000039:mdna:36]
[same as prior period, unchanged from 0000068505-23-000026:mdna:38]

[0000068505-23-000039:mdna:37]
[same as prior period, unchanged from 0000068505-23-000026:mdna:39]

[0000068505-23-000039:mdna:38]
[same as prior period, unchanged from 0000068505-23-000026:mdna:40]

[0000068505-23-000039:mdna:39]
[same as prior period, unchanged from 0000068505-23-000026:mdna:41]

[0000068505-23-000039:mdna:40]
|  | Three Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |  | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |
| International | 412 |  |  | 350 |  |  | 762 |  |  | 322 |  |  | 334 |  |  | 656 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |  | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |
| Video | 287 |  |  | 146 |  |  | 433 |  |  | 247 |  |  | 123 |  |  | 370 |  |
| Command Center | — |  |  | 194 |  |  | 194 |  |  | — |  |  | 162 |  |  | 162 |  |
| Total | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Operating earnings | $ | 212 |  |  | $ | 306 |  |  | $ | 518 |  |  | $ | 118 |  |  | $ | 240 |  |  | $ | 358 |  |
| Operating margins | 14.8 | % |  | 31.7 | % |  | 21.6 | % |  | 9.2 | % |  | 28.1 | % |  | 16.7 | % |

[0000068505-23-000039:mdna:41]
[same as prior period, unchanged from 0000068505-23-000026:mdna:43]

[0000068505-23-000039:mdna:42]
The Products and Systems Integration segment’s net sales represented 60% of our net sales in the second quarter of 2023 and in the second quarter of 2022. The Software and Services segment’s net sales represented 40% of our net sales in the second quarter of 2023 and in the second quarter of 2022.

[0000068505-23-000039:mdna:43]
Net sales increased $263 million, or 12%, in the second quarter of 2023 compared to the second quarter of 2022. The $152 million, or 12%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 28% in the International region and an increase of 6% in the North America region. The $111 million, or 13%, increase in net sales within the Software and Services segment was driven by an increase of 18% in the North America region and an increase of 5% in the International region. Net sales includes:

[0000068505-23-000039:mdna:44]
•an increase in the Products and Systems Integration segment, inclusive of $2 million of revenue from acquisitions, driven by an increase in LMR and Video; and

[0000068505-23-000039:mdna:45]
•an increase in the Software and Services segment, inclusive of $18 million of revenue from acquisitions, driven by an increase in LMR, Command Center and Video;

[0000068505-23-000039:mdna:46]
•inclusive of $23 million from unfavorable currency rates.

[0000068505-23-000039:mdna:47]
[same as prior period, unchanged from 0000068505-23-000026:mdna:49]

[0000068505-23-000039:mdna:48]
•a 11% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-23-000039:mdna:49]
•a 16% increase in the International region, primarily driven by an increase in LMR and Video.

[0000068505-23-000039:mdna:50]
[same as prior period, unchanged from 0000068505-23-000026:mdna:52]

[0000068505-23-000039:mdna:51]
The 12% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-23-000039:mdna:52]
•$112 million, or 11% growth in LMR, inclusive of revenue from acquisitions, driven by the International and North America regions; and

[0000068505-23-000039:mdna:53]
•$40 million, or 16% growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-23-000039:mdna:54]
•inclusive of $10 million from unfavorable currency rates.

[0000068505-23-000039:mdna:55]
[same as prior period, unchanged from 0000068505-23-000026:mdna:57]

[0000068505-23-000039:mdna:56]
The 13% increase in the Software and Services segment was driven by the following:

[0000068505-23-000039:mdna:57]
•$56 million, or 10% growth in LMR, driven by the North America and International regions;

[0000068505-23-000039:mdna:58]
•$32 million, or 20% growth in Command Center, inclusive of revenue from acquisitions, driven by the North America region; and

[0000068505-23-000039:mdna:59]
•$23 million, or 19% growth in Video, driven by the North America region and partially offset by the International region;

[0000068505-23-000039:mdna:60]
•inclusive of $13 million from unfavorable currency rates.

[0000068505-23-000039:mdna:61]
[same as prior period, unchanged from 0000068505-23-000026:mdna:63]

[0000068505-23-000039:mdna:62]
|  | Three Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |  | % Change |
| Gross margin | $ | 1,189 |  |  | $ | 990 |  |  | 20 | % |

[0000068505-23-000039:mdna:63]
Gross margin was 49.5% of net sales in the second quarter of 2023 compared to 46.3% in the second quarter of 2022. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-23-000039:mdna:64]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales, inclusive of higher pricing, and lower direct material costs; and

[0000068505-23-000039:mdna:65]
•higher gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales.

[0000068505-23-000039:mdna:66]
[same as prior period, unchanged from 0000068505-23-000026:mdna:68]

[0000068505-23-000039:mdna:67]
|  | Three Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |  | % Change |
| Selling, general and administrative expenses | $ | 390 |  |  | $ | 356 |  |  | 10 | % |

[0000068505-23-000039:mdna:68]
SG&A expenses increased 10% in the second quarter of 2023 compared to the second quarter of 2022. The increase in SG&A expenses was primarily due to higher employee incentive costs including share-based compensation and higher expenses associated with acquired businesses. SG&A expenses were 16.2% of net sales in the second quarter of 2023 compared to 16.6% of net sales in the second quarter of 2022.

[0000068505-23-000039:mdna:69]
[same as prior period, unchanged from 0000068505-23-000026:mdna:71]

[0000068505-23-000039:mdna:70]
|  | Three Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |  | % Change |
| Research and development expenditures | $ | 215 |  |  | $ | 191 |  |  | 13 | % |

[0000068505-23-000039:mdna:71]
R&D expenditures increased 13% in the second quarter of 2023 compared to the second quarter of 2022 primarily due to higher employee incentive costs including share-based compensation and higher expenses associated with acquired businesses. R&D expenditures were 8.9% of net sales in both the second quarter of 2023 and the second quarter of 2022.

[0000068505-23-000039:mdna:72]
[same as prior period, unchanged from 0000068505-23-000026:mdna:74]

[0000068505-23-000039:mdna:73]
|  | Three Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Other charges | $ | 66 |  |  | $ | 85 |  |

[0000068505-23-000039:mdna:74]
Other charges decreased by $19 million in the second quarter of 2023 compared to the second quarter of 2022. The change was driven primarily by the following:

[0000068505-23-000039:mdna:75]
•$43 million of intangible asset amortization expense in the second quarter of 2023 compared to $65 million of intangible asset amortization expense in the second quarter of 2022;

[0000068505-23-000039:mdna:76]
•$1 million of fixed asset impairments in the second quarter of 2023 compared to $8 million of fixed asset impairment in the second quarter of 2022;

[0000068505-23-000039:mdna:77]
•$4 million of acquisition-related transaction fees in the second quarter of 2022 that did not recur in the second quarter of 2023; and

[0000068505-23-000039:mdna:78]
•$1 million of operating lease asset impairments in the second quarter of 2023 compared to $3 million of operating lease asset impairments in the second quarter 2022; partially offset by

[0000068505-23-000039:mdna:79]
•$15 million of environmental reserve expense in the second quarter of 2023 that did not occur in the second quarter of 2022.

[0000068505-23-000039:mdna:80]
[same as prior period, unchanged from 0000068505-23-000026:mdna:83]

[0000068505-23-000039:mdna:81]
|  | Three Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Operating earnings from Products and Systems Integration | $ | 212 |  |  | $ | 118 |  |
| Operating earnings from Software and Services | 306 |  |  | 240 |  |
| Operating earnings | $ | 518 |  |  | $ | 358 |  |

[0000068505-23-000039:mdna:82]
Operating earnings increased $160 million, or 45%, in the second quarter of 2023 compared to the second quarter of 2022. The increase in Operating earnings was due to:

[0000068505-23-000039:mdna:83]
•$94 million increase in the Products and Systems Integration segment, primarily driven by higher sales, inclusive of higher pricing, lower direct material costs and improved operating leverage, partially offset by higher employee incentive costs, including share-based compensation; and

[0000068505-23-000039:mdna:84]
•$66 million increase in the Software and Services segment, primarily driven by higher sales, improved operating leverage and a reduction in intangible amortization expenses, partially offset by higher expenses associated with acquired businesses.

[0000068505-23-000039:mdna:85]
[same as prior period, unchanged from 0000068505-23-000026:mdna:88]

[0000068505-23-000039:mdna:86]
|  | Three Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Interest expense, net | $ | (57) |  |  | $ | (56) |  |

[0000068505-23-000039:mdna:87]
The $1 million increase in Interest expense, net in the second quarter of 2023 compared to the second quarter of 2022 was primarily driven by interest on higher outstanding debt partially offset by higher interest income earned on cash.

[0000068505-23-000039:mdna:88]
[same as prior period, unchanged from 0000068505-23-000026:mdna:91]

[0000068505-23-000039:mdna:89]
|  | Three Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Other, net | $ | 26 |  |  | $ | (2) |  |

[0000068505-23-000039:mdna:90]
The $28 million increase in Other, net in the second quarter of 2023 compared to the second quarter of 2022 was primarily driven by:

[0000068505-23-000039:mdna:91]
•$9 million gain on derivatives in the second quarter of 2023 compared to a $34 million loss on derivatives in the second quarter of 2022;

[0000068505-23-000039:mdna:92]
•$16 million gain on fair value adjustments to equity investments in the second quarter of 2023 compared to a $12 million loss on fair value adjustments to equity investments in the second quarter of 2022;

[0000068505-23-000039:mdna:93]
•$6 million loss from the extinguishment of long-term debt in the second quarter of 2022 that did not recur in the second quarter of 2023; and

[0000068505-23-000039:mdna:94]
•$1 million gain on an equity method investment in the second quarter of 2023 compared to a $2 million loss on an equity method investment in the second quarter of 2022; partially offset by

[0000068505-23-000039:mdna:95]
•$21 million of foreign currency losses in the second quarter of 2023 compared to $27 million of foreign currency gains in the second quarter of 2022;

[0000068505-23-000039:mdna:96]
•$24 million of net periodic pension and postretirement benefit in the second quarter of 2023 compared to $30 million of net periodic pension and postretirement benefit in the second quarter of 2022; and

[0000068505-23-000039:mdna:97]
•$3 million of investment impairments in the second quarter of 2023 that did not occur in the second quarter of 2022.

[0000068505-23-000039:mdna:98]
[same as prior period, unchanged from 0000068505-23-000026:mdna:100]

[0000068505-23-000039:mdna:99]
|  | Three Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Income tax expense | $ | 114 |  |  | $ | 71 |  |

[0000068505-23-000039:mdna:100]
Income tax expense increased by $43 million in the second quarter of 2023 compared to the second quarter of 2022, resulting in an effective tax rate of 23%. Our effective tax rate for the three months ended July 1, 2023 of 23% was lower than the effective tax rate for the three months ended July 2, 2022 of 24%, primarily due to higher excess tax benefits of share-based compensation in 2023.

[0000068505-23-000039:mdna:101]
Results of Operations—Six months ended July 1, 2023 compared to Six months ended July 2, 2022

[0000068505-23-000039:mdna:102]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |  | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |
| International | 765 |  |  | 676 |  |  | 1,441 |  |  | 594 |  |  | 650 |  |  | 1,244 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |  | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |
| Video | 510 |  |  | 282 |  |  | 792 |  |  | 441 |  |  | 236 |  |  | 677 |  |
| Command Center | — |  |  | 349 |  |  | 349 |  |  | — |  |  | 292 |  |  | 292 |  |
| Total | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Operating earnings | 388 |  |  | 529 |  |  | 917 |  |  | 157 |  |  | 440 |  |  | 597 |  |
| Operating margins | 14.2 | % |  | 28.8 | % |  | 20.0 | % |  | 6.6 | % |  | 26.8 | % |  | 14.8 | % |

[0000068505-23-000039:mdna:103]
Net Sales

[0000068505-23-000039:mdna:104]
The Products and Systems Integration segment's net sales represented 60% of our net sales in the first half of 2023 and 59% in the first half of 2022. Net sales from the Software and Services segment represented 40% of our net sales in the first half of 2023 and 41% in the first half of 2022.

[0000068505-23-000039:mdna:105]
Net sales increased $542 million, or 13%, in the first half of 2023 compared to the first half of 2022. The $352 million, or 15%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 10% in the North America region and an increase of 29% in the International region. The $190 million, or 12%, increase in net sales within the Software and Services segment was driven by an increase of 16% in the North America region and an increase of 4% in the International region. Net sales includes:

[0000068505-23-000039:mdna:106]
•an increase in the Products and Systems Integration segment, inclusive of $14 million of revenue from acquisitions, driven by an increase in LMR and Video; and

[0000068505-23-000039:mdna:107]
•an increase in Software and Services, inclusive of $48 million of revenue from acquisitions, driven by an increase in LMR, Command Center and Video;

[0000068505-23-000039:mdna:108]
•inclusive of $67 million from unfavorable currency rates.

[0000068505-23-000039:mdna:109]
Regional results include:

[0000068505-23-000039:mdna:110]
•a 12% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-23-000039:mdna:111]
•a 16% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in LMR and Video.

[0000068505-23-000039:mdna:112]
Products and Systems Integration

[0000068505-23-000039:mdna:113]
The 15% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-23-000039:mdna:114]
33

[0000068505-23-000039:mdna:115]
•$283 million, or 15% growth in LMR, inclusive of revenue from acquisitions, driven by both the International and North America regions; and

[0000068505-23-000039:mdna:116]
•$69 million, or 16% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-23-000039:mdna:117]
•inclusive of $28 million from unfavorable currency rates.

[0000068505-23-000039:mdna:118]
Software and Services

[0000068505-23-000039:mdna:119]
The 12% increase in the Software and Services segment was driven by the following:

[0000068505-23-000039:mdna:120]
•$87 million, or 8% growth in LMR, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-23-000039:mdna:121]
•$57 million, or 20% growth in Command Center, inclusive of revenue from acquisitions, driven by the North America region;

[0000068505-23-000039:mdna:122]
•$46 million, or 19% growth in Video, inclusive of revenue from acquisitions, driven by the North America region and partially offset by the International region;

[0000068505-23-000039:mdna:123]
•inclusive of $39 million from unfavorable currency rates.

[0000068505-23-000039:mdna:124]
Gross Margin

[0000068505-23-000039:mdna:125]
|  | Six Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |  | % Change |
| Gross margin | $ | 2,235 |  |  | $ | 1,846 |  |  | 21 | % |

[0000068505-23-000039:mdna:126]
Gross margin was 48.9% of net sales in the first half of 2023 compared to 45.8% in the first half of 2022. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-23-000039:mdna:127]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales, inclusive of higher pricing, and lower direct material costs; and

[0000068505-23-000039:mdna:128]
•consistent gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales and offset by mix.

[0000068505-23-000039:mdna:129]
Selling, General and Administrative Expenses

[0000068505-23-000039:mdna:130]
|  | Six Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |  | % Change |
| Selling, general and administrative expenses | $ | 757 |  |  | $ | 692 |  |  | 9 | % |

[0000068505-23-000039:mdna:131]
SG&A expenses increased 9% in the first half of 2023 compared to the first half of 2022. The increase in SG&A expenses was primarily due to higher employee incentive costs including share-based compensation and higher expenses associated with acquired businesses. SG&A expenses were 16.6% of net sales in the first half of 2023 compared to 17.2% of net sales in the first half of 2022.

[0000068505-23-000039:mdna:132]
Research and Development Expenditures

[0000068505-23-000039:mdna:133]
|  | Six Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |  | % Change |
| Research and development expenditures | $ | 426 |  |  | $ | 380 |  |  | 12 | % |

[0000068505-23-000039:mdna:134]
R&D expenditures increased 12% in the first half of 2023 compared to the first half of 2022 primarily due to higher employee incentive costs including share-based compensation and higher expenses associated with acquired businesses. R&D expenditures decreased to 9.3% of net sales in the first half of 2023 compared to 9.4% of net sales in the first half of 2022.

[0000068505-23-000039:mdna:135]
Other Charges

[0000068505-23-000039:mdna:136]
|  | Six Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Other charges | $ | 135 |  |  | $ | 177 |  |

[0000068505-23-000039:mdna:137]
Other charges decreased by $42 million in the first half of 2023 compared to the first half of 2022. The change was driven primarily by the following:

[0000068505-23-000039:mdna:138]
•$98 million of intangible asset amortization expense in the first half of 2023 compared to $131 million of intangible asset amortization expense in the first half of 2022;

[0000068505-23-000039:mdna:139]
•$2 million of acquisition-related transaction fees in the first half of 2023 compared to $14 million of acquisition-related transaction fees in the first half of 2022;

[0000068505-23-000039:mdna:140]
•$11 million of losses on legal settlements in the first half of 2022 that did not recur in the first half of 2023;

[0000068505-23-000039:mdna:141]
•$3 million of fixed asset impairments in the first half of 2023 compared to $11 million of fixed asset impairments in the first half of 2022; and

[0000068505-23-000039:mdna:142]
•$4 million of operating lease asset impairments in the first half of 2023 compared to $12 million of operating lease asset impairments in the first half of 2022; partially offset by

[0000068505-23-000039:mdna:143]
•$15 million of environmental reserve expense in the first half of 2023 that did not occur in the first half of 2022; and

[0000068505-23-000039:mdna:144]
•$13 million gain on recoveries from the legal settlement under the Hytera bankruptcy proceedings in the first half of 2022 (see further detail in "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q), that did not recur in the first half of 2023.

[0000068505-23-000039:mdna:145]
Operating Earnings

[0000068505-23-000039:mdna:146]
|  | Six Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Operating earnings from Products and Systems Integration | $ | 388 |  |  | $ | 157 |  |
| Operating earnings from Software and Services | 529 |  |  | 440 |  |
| Operating earnings | $ | 917 |  |  | $ | 597 |  |

[0000068505-23-000039:mdna:147]
Operating earnings increased $320 million, or 54%, in the first half of 2023 compared to the first half of 2022. The increase in Operating earnings was due to:

[0000068505-23-000039:mdna:148]
•$231 million increase in the Products and Systems Integration segment, primarily driven by higher sales, pricing actions and lower supply chain costs, partially offset by higher employee incentive costs, including share-based compensation; and

[0000068505-23-000039:mdna:149]
•$89 million increase in the Software and Services segment, primarily driven by higher sales and a reduction in intangible amortization expenses, partially offset by higher expenses associated with acquired businesses.

[0000068505-23-000039:mdna:150]
Interest Expense, net

[0000068505-23-000039:mdna:151]
|  | Six Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Interest expense, net | $ | (111) |  |  | $ | (112) |  |

[0000068505-23-000039:mdna:152]
The $1 million decrease in net interest expense in the first half of 2023 compared to the first half of 2022 was primarily driven by higher interest income earned on cash, partially offset by interest on higher outstanding debt.

[0000068505-23-000039:mdna:153]
Other, net

[0000068505-23-000039:mdna:154]
|  | Six Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Other, net | $ | 39 |  |  | $ | 33 |  |

[0000068505-23-000039:mdna:155]
The $6 million increase in Other, net in the first half of 2023 compared to the first half of 2022 was primarily driven by:

[0000068505-23-000039:mdna:156]
•$17 million of gains on derivative instruments in the first half of 2023 compared to $57 million of losses on derivative instruments in the first half of 2022;

[0000068505-23-000039:mdna:157]
•$19 million gain on fair value adjustments to equity investments in the first half of 2023 compared to a $30 million loss on fair value adjustments to equity investments in the first half of 2022; and

[0000068505-23-000039:mdna:158]
•$6 million loss on the extinguishment of long-term debt in the first half of 2022 that did not recur in the first half of 2023; partially offset by

[0000068505-23-000039:mdna:159]
•$40 million of foreign currency losses in the first half of 2023 compared to $50 million of foreign currency gains in the first half of 2022;

[0000068505-23-000039:mdna:160]
• $1 million gain on equity method investments in the first half of 2023 compared to a $19 million gain on equity method investments in the first half of 2022;

[0000068505-23-000039:mdna:161]
•$49 million of net periodic pension and postretirement benefit in the first half of 2023 compared to $63 million

[0000068505-23-000039:mdna:162]
of net periodic pension and postretirement benefit in the first half of 2022; and

[0000068505-23-000039:mdna:163]
•$9 million of investment impairments in the first half of 2023 compared to $1 million of investment impairments in the first half of 2022.

[0000068505-23-000039:mdna:164]
Effective Tax Rate

[0000068505-23-000039:mdna:165]
|  | Six Months Ended |
| (In millions) | July 1, 2023 |  | July 2, 2022 |
| Income tax expense | $ | 194 |  |  | $ | 23 |  |

[0000068505-23-000039:mdna:166]
Income tax expense increased by $171 million in the first half of 2023 compared to the first half of 2022, resulting in an effective tax rate of 23%. Our effective tax rate of 23% for the six months ended July 1, 2023 was higher than than the effective tax rate for the six months ended July 2, 2022 of 4%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights, higher excess tax benefits of share-based compensation, and a higher foreign derived intangible income deduction in 2022.

[0000068505-23-000039:mdna:167]
[same as prior period, unchanged from 0000068505-23-000026:mdna:103]

[0000068505-23-000039:mdna:168]
During the second quarter of 2023, we recorded net reorganization of business charges of $3 million, including $5 million of charges recorded within Other charges and $2 million of reversals recorded in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $3 million were charges of $9 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $1 million of reversals for employee separation accruals no longer needed.

[0000068505-23-000039:mdna:169]
During the first half of 2023, we recorded net reorganization of business charges of $16 million, including $12 million of charges recorded within Other charges and $4 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $16 million were charges of $24 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $3 million of reversals for employee separation accruals no longer needed.

[0000068505-23-000039:mdna:170]
During the second quarter of 2022, we recorded net reorganization of business charges of $7 million, including $5 million of charges in Other charges and $2 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $7 million were charges of $11 million related to employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-23-000039:mdna:171]
During the first half of 2022, we recorded net reorganization of business charges of $17 million, including $12 million of charges recorded within Other charges and $5 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $17 million were charges of $24 million related to employee separation costs, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-23-000039:mdna:172]
[same as prior period, unchanged from 0000068505-23-000026:mdna:106]

[0000068505-23-000039:mdna:173]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Products and Systems Integration | $ | 6 |  |  | $ | 6 |  |  | $ | 17 |  |  | $ | 14 |  |
| Software and Services | (3) |  |  | 1 |  |  | (1) |  |  | 3 |  |
|  | $ | 3 |  |  | $ | 7 |  |  | $ | 16 |  |  | $ | 17 |  |

[0000068505-23-000039:mdna:174]
Cash payments for employee severance in connection with the reorganization of business plans were $19 million in the first half of 2023 and $20 million in the first half of 2022. The reorganization of business accrual at July 1, 2023 was $28 million related to employee separation costs that are expected to be paid within one year.

[0000068505-23-000039:mdna:175]
At January 1, 2023, we had an accrual of $10 million for exit costs, related to our exit of the ESN contract with the Home Office in 2022. During the three months ended July 1, 2023, the Company recorded a $5 million reversal for accruals no longer needed. The $5 million of exit costs are recorded in Accrued liabilities in the our Condensed Consolidated Balance Sheet at July 1, 2023, and are expected to be paid within one year.

[0000068505-23-000039:mdna:176]
[same as prior period, unchanged from 0000068505-23-000026:mdna:110]

[0000068505-23-000039:mdna:177]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 85 |  |  | $ | 162 |  |
| Investing activities | (111) |  |  | (673) |  |
| Financing activities | (629) |  |  | (564) |  |
| Effect of exchange rates on cash and cash equivalents | 40 |  |  | (82) |  |
| Increase (decrease) in cash and cash equivalents | $ | (615) |  |  | $ | (1,157) |  |

[0000068505-23-000039:mdna:178]
[same as prior period, unchanged from 0000068505-23-000026:mdna:112]

[0000068505-23-000039:mdna:179]
At July 1, 2023, $356 million of the $710 million cash and cash equivalents balance was held in the U.S. and $354 million was held in other countries, with $68 million held in the United Kingdom.

[0000068505-23-000039:mdna:180]
[same as prior period, unchanged from 0000068505-23-000026:mdna:114]

[0000068505-23-000039:mdna:181]
The decrease in cash flows provided by operating activities from the first half of 2022 to the first half of 2023 was driven primarily by a one time $70 million cash tax payment related to an intellectual property reorganization completed in 2022 and an increase in working capital; partially offset by higher earnings, net of non-cash charges.

[0000068505-23-000039:mdna:182]
[same as prior period, unchanged from 0000068505-23-000026:mdna:116]

[0000068505-23-000039:mdna:183]
The decrease in cash flows used for investing activities in the first half of 2023 compared to the first half of 2022 was primarily due to a $561 million decrease in cash used for acquisitions and investments.

[0000068505-23-000039:mdna:184]
[same as prior period, unchanged from 0000068505-23-000026:mdna:118]

[0000068505-23-000039:mdna:185]
The increase in cash flows used for financing activities in the first half of 2023 compared to the first half of 2022 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-23-000039:mdna:186]
•$595 million in net proceeds from issuance of debt in the first half of 2022 that did not recur in the first half of 2023;

[0000068505-23-000039:mdna:187]
•$30 million increase in the payment of dividends in the first half of 2023 compared to the first half of 2022;

[0000068505-23-000039:mdna:188]
•$15 million decrease in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first half of 2023 compared to the first half of 2022; partially offset by

[0000068505-23-000039:mdna:189]
•$291 million decrease in share repurchases in the first half of 2023 compared to the first half of 2022; and

[0000068505-23-000039:mdna:190]
•$282 million decrease in repayments of debt in the first half of 2023 compared to the first half of 2022.

[0000068505-23-000039:mdna:191]
[same as prior period, unchanged from 0000068505-23-000026:mdna:124]

[0000068505-23-000039:mdna:192]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended July 1, 2023 and July 2, 2022:

[0000068505-23-000039:mdna:193]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Contract-specific discounting facility | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 49 |  |
| Accounts receivable sales proceeds | — |  |  | 40 |  |  | $ | — |  |  | $ | 62 |  |
| Long-term receivables sales proceeds | 26 |  |  | 5 |  |  | 58 |  |  | 22 |  |
| Total proceeds from receivable sales | $ | 26 |  |  | $ | 45 |  |  | $ | 58 |  |  | $ | 133 |  |

[0000068505-23-000039:mdna:194]
[same as prior period, unchanged from 0000068505-23-000026:mdna:127]

[0000068505-23-000039:mdna:195]
We had outstanding debt of $6.0 billion at July 1, 2023, none of which was current. We had outstanding debt of $6.0 billion at December 31, 2022, $1 million of which was current.

[0000068505-23-000039:mdna:196]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We

[0000068505-23-000039:mdna:197]
must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of July 1, 2023. On February 8, 2023, we entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

[0000068505-23-000039:mdna:198]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("Senior Convertible Notes"). Interest on these notes is payable semiannually. The Senior Convertible Notes became fully convertible on September 5, 2021. The notes are convertible based on a conversion rate of 4.9670 per $1,000 principal amount (which is equal to conversion price of $201.33 per share) adjusted for dividends declared through the date of settlement. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash.

[0000068505-23-000039:mdna:199]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of July 1, 2023 we had no outstanding debt under the commercial paper program.

[0000068505-23-000039:mdna:200]
We have investment grade ratings on our senior unsecured long-term debt. Subsequent to the quarter, on July 31, 2023, Moody's Investors Service upgraded our credit rating to Baa2 from Baa3. We continue to believe that we will be able to maintain sufficient access to the capital markets.

[0000068505-23-000039:mdna:201]
[same as prior period, unchanged from 0000068505-23-000026:mdna:132]

[0000068505-23-000039:mdna:202]
During the three and six months ended July 1, 2023, we paid an aggregate of $224 million and $364 million, respectively, including transaction costs, to repurchase approximately 0.8 million and 1.3 million shares at an average price of $283.39 and $274.66 per share. As of July 1, 2023, we had used approximately $15.1 billion of the share repurchase authority to repurchase shares, leaving $921 million of authority available for future repurchases.

[0000068505-23-000039:mdna:203]
[same as prior period, unchanged from 0000068505-23-000026:mdna:135]

[0000068505-23-000039:mdna:204]
During the second quarter of 2023 we paid $148 million in cash dividends to holders of our common stock. During the first half of 2023 we paid $296 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $147 million in cash dividends to holders of our common stock.

[0000068505-23-000039:mdna:205]
[same as prior period, unchanged from 0000068505-23-000026:mdna:137]

[0000068505-23-000039:mdna:206]
[same as prior period, unchanged from 0000068505-23-000026:mdna:138]

[0000068505-23-000039:mdna:207]
[same as prior period, unchanged from 0000068505-23-000026:mdna:139]

[0000068505-23-000039:mdna:208]
[same as prior period, unchanged from 0000068505-23-000026:mdna:140]

[0000068505-23-000039:mdna:209]
We had outstanding commitments to provide long-term financing to third parties totaling $207 million at July 1, 2023, compared to $65 million at December 31, 2022.

[0000068505-23-000039:mdna:210]
[same as prior period, unchanged from 0000068505-23-000026:mdna:142]

[0000068505-23-000039:mdna:211]
See "Recent Accounting Pronouncements" and “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
