# MSI notes — 0000068505-23-000039


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-23-000039:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of July 1, 2023 and for the three and six months ended July 1, 2023 and July 2, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-23-000039:notes:2]
[same as prior period, unchanged from 0000068505-23-000026:notes:2]

[0000068505-23-000039:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three and six months ended July 1, 2023 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-23-000039:notes:4]
[same as prior period, unchanged from 0000068505-23-000026:notes:4]

[0000068505-23-000039:notes:5]
[same as prior period, unchanged from 0000068505-23-000026:notes:5]

[0000068505-23-000039:notes:6]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center.

[0000068505-23-000039:notes:7]
[same as prior period, unchanged from 0000068505-23-000026:notes:7]

[0000068505-23-000039:notes:8]
[same as prior period, unchanged from 0000068505-23-000026:notes:8]

[0000068505-23-000039:notes:9]
[same as prior period, unchanged from 0000068505-23-000026:notes:9]

[0000068505-23-000039:notes:10]
[same as prior period, unchanged from 0000068505-23-000026:notes:10]

[0000068505-23-000039:notes:11]
[same as prior period, unchanged from 0000068505-23-000026:notes:11]

[0000068505-23-000039:notes:12]
[same as prior period, unchanged from 0000068505-23-000026:notes:12]

[0000068505-23-000039:notes:13]
[same as prior period, unchanged from 0000068505-23-000026:notes:13]

[0000068505-23-000039:notes:14]
[same as prior period, unchanged from 0000068505-23-000026:notes:14]

[0000068505-23-000039:notes:15]
[same as prior period, unchanged from 0000068505-23-000026:notes:15]

[0000068505-23-000039:notes:16]
[same as prior period, unchanged from 0000068505-23-000026:notes:16]

[0000068505-23-000039:notes:17]
[same as prior period, unchanged from 0000068505-23-000026:notes:17]

[0000068505-23-000039:notes:18]
Recently Adopted Accounting Pronouncements

[0000068505-23-000039:notes:19]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs" (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted ASU 2022-04 on January 1, 2023. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-23-000039:notes:20]
[same as prior period, unchanged from 0000068505-23-000026:notes:20]

[0000068505-23-000039:notes:21]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 1, 2023 and July 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-23-000039:notes:22]
|  | Three Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |  | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |
| International | 412 |  |  | 350 |  |  | 762 |  |  | 322 |  |  | 334 |  |  | 656 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |  | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |
| Video | 287 |  |  | 146 |  |  | 433 |  |  | 247 |  |  | 123 |  |  | 370 |  |
| Command Center | — |  |  | 194 |  |  | 194 |  |  | — |  |  | 162 |  |  | 162 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 796 |  |  | $ | 875 |  |  | $ | 1,671 |  |  | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |
| Indirect | 641 |  |  | 91 |  |  | 732 |  |  | 574 |  |  | 77 |  |  | 651 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |

[0000068505-23-000039:notes:23]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |  | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |
| International | 765 |  |  | 676 |  |  | 1,441 |  |  | 594 |  |  | 650 |  |  | 1,244 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |  | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |
| Video | 510 |  |  | 282 |  |  | 792 |  |  | 441 |  |  | 236 |  |  | 677 |  |
| Command Center | — |  |  | 349 |  |  | 349 |  |  | — |  |  | 292 |  |  | 292 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,519 |  |  | $ | 1,670 |  |  | $ | 3,189 |  |  | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |
| Indirect | 1,221 |  |  | 164 |  |  | 1,385 |  |  | 1,021 |  |  | 164 |  |  | 1,185 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |

[0000068505-23-000039:notes:24]
[same as prior period, unchanged from 0000068505-23-000026:notes:24]

[0000068505-23-000039:notes:25]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 1, 2023 was $9.4 billion. A total of $4.8 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of July 1, 2023, of which $3.0 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.6 billion was from Software and Services performance obligations that were not yet satisfied as of July 1, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

[0000068505-23-000039:notes:26]
[same as prior period, unchanged from 0000068505-23-000026:notes:27]

[0000068505-23-000039:notes:27]
| (In millions) | July 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,513 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,033 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,764 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 382 |  |  | 363 |  |  |  |  |  |

[0000068505-23-000039:notes:28]
Revenue recognized during the three months ended July 1, 2023 which was previously included in Contract liabilities as of April 1, 2023 was $502 million, compared to $456 million of revenue recognized during the three months ended July 2, 2022 which was previously included in Contract liabilities as of April 2, 2022. Revenue recognized during the six months ended July 1, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $824 million, compared to $712 million recognized during the six months ended July 2, 2022 which was previously included in Contract liabilities as of December 31, 2021. The Company reversed $10 million of revenue during the three months ended July 1, 2023 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to no reversals for the three months ended July 2, 2022, primarily driven by changes in the estimates of progress on system contracts. Revenue of $15 million was reversed during the six months ended July 1, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $22 million of reversals for the six months ended July 2, 2022.

[0000068505-23-000039:notes:29]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 1, 2023 and July 2, 2022.

[0000068505-23-000039:notes:30]
[same as prior period, unchanged from 0000068505-23-000026:notes:31]

[0000068505-23-000039:notes:31]
| (In millions) | July 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 84 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 105 |  |  | 130 |  |  |  |  |  |

[0000068505-23-000039:notes:32]
Amortization of non-current contract cost assets was $16 million and $35 million for the three and six months ended July 1, 2023, respectively, and $13 million and $26 million for the three and six months ended July 2, 2022, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-23-000039:notes:33]
Leases
Components of Lease Expense

[0000068505-23-000039:notes:34]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 34 |  |  | $ | 33 |  |  | $ | 68 |  |  | $ | 66 |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 4 |  |
| Short-term lease cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Variable cost | 8 |  |  | 8 |  |  | 17 |  |  | 17 |  |
| Sublease income | (1) |  |  | (2) |  |  | (3) |  |  | (3) |  |
| Net lease expense | $ | 42 |  |  | $ | 41 |  |  | $ | 85 |  |  | $ | 85 |  |

[0000068505-23-000039:notes:35]
Lease Assets and Liabilities

[0000068505-23-000039:notes:36]
| (in millions) |  | Statement Line Classification |  | July 1, 2023 |  | December 31, 2022 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 478 |  |  | $ | 485 |  |  |  |
| Finance lease assets |  | Property, plant and equipment, net |  | 9 |  |  | 9 |  |  |  |
|  |  |  |  | $ | 487 |  |  | $ | 494 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 114 |  |  | $ | 118 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | — |  |  | 1 |  |  |  |
|  |  |  |  | $ | 114 |  |  | $ | 119 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 391 |  |  | $ | 419 |  |  |  |

[0000068505-23-000039:notes:37]
Other Information Related to Leases

[0000068505-23-000039:notes:38]
|  | Six Months Ended |  |  |
| (in millions) | July 1, 2023 |  | July 2, 2022 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 81 |  |  | $ | 93 |  |  |  |
| Net cash used for financing activities related to finance leases | — |  |  | 3 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 39 |  |  | $ | 65 |  |  |  |

[0000068505-23-000039:notes:39]
Assets obtained in exchange for lease liabilities for the six months ended July 1, 2023 included $20 million of additional leases due to a renewal of a large managed services contract. Assets obtained in exchange for lease liabilities for the six months ended July 2, 2022 included $34 million of additional leases acquired in connection with the Company's acquisition of TETRA Ireland.

[0000068505-23-000039:notes:40]
|  | July 1, 2023 |  | December 31, 2022 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 5 |  | 5 |
| Finance leases | 1 |  | 1 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 4.24 | % |  | 4.07 | % |
| Finance leases | 2.77 | % |  | 3.23 | % |

[0000068505-23-000039:notes:41]
Future Lease Payments

[0000068505-23-000039:notes:42]
|  | July 1, 2023 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2023 | $ | 52 |  |  |  |  |  |
| 2024 | 135 |  |  |  |  |  |
| 2025 | 122 |  |  |  |  |  |
| 2026 | 102 |  |  |  |  |  |
| 2027 | 54 |  |  |  |  |  |
| Thereafter | 96 |  |  |  |  |  |
| Total lease payments | $ | 561 |  |  |  |  |  |
| Less: Interest | 56 |  |  |  |  |  |
| Present value of lease liabilities | $ | 505 |  |  |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-23-000039:notes:43]
[same as prior period, unchanged from 0000068505-23-000026:notes:44]

[0000068505-23-000039:notes:44]
[same as prior period, unchanged from 0000068505-23-000026:notes:45]

[0000068505-23-000039:notes:45]
[same as prior period, unchanged from 0000068505-23-000026:notes:46]

[0000068505-23-000039:notes:46]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 43 |  |  | $ | 65 |  |  | $ | 98 |  |  | $ | 131 |  |
| Environmental reserve expense | 15 |  |  | — |  |  | 15 |  |  | — |  |
| Reorganization of business (Note 14) | 5 |  |  | 5 |  |  | 12 |  |  | 12 |  |
| Operating lease asset impairments | 1 |  |  | 3 |  |  | 4 |  |  | 12 |  |
| Acquisition-related transaction fees | — |  |  | 4 |  |  | 2 |  |  | 14 |  |
| Legal settlements | — |  |  | — |  |  | — |  |  | 11 |  |
| Fixed asset impairments | 1 |  |  | 8 |  |  | 3 |  |  | 11 |  |
| Gain on Hytera legal settlement | — |  |  | — |  |  | — |  |  | (13) |  |
| Other | 1 |  |  | — |  |  | 1 |  |  | (1) |  |
|  | $ | 66 |  |  | $ | 85 |  |  | $ | 135 |  |  | $ | 177 |  |

[0000068505-23-000039:notes:47]
During the three months ended July 1, 2023, the Company revised the estimate for its liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the "Superfund Act") incurred by a legacy business. It is the Company's policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. During three months ended July 1, 2023, the Company became aware of incremental costs required in its remediation of the Superfund site. As such, the Company recorded a charge of $15 million, increasing the reserve balance to $127 million. The Company discounted the cash flows used in estimating this accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is $4 million and is included in the Accrued liabilities statement line and the non-current portion is included in the "Other liabilities" statement line within the Company's Condensed Consolidated Balance Sheet.

[0000068505-23-000039:notes:48]
[same as prior period, unchanged from 0000068505-23-000026:notes:48]

[0000068505-23-000039:notes:49]
[same as prior period, unchanged from 0000068505-23-000026:notes:49]

[0000068505-23-000039:notes:50]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (63) |  |  | $ | (59) |  |  | $ | (126) |  |  | $ | (117) |  |
| Interest income | 6 |  |  | 3 |  |  | 15 |  |  | 5 |  |
|  | $ | (57) |  |  | $ | (56) |  |  | $ | (111) |  |  | (112) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 24 |  |  | $ | 30 |  |  | $ | 49 |  |  | $ | 63 |  |
| Loss from the extinguishment of long-term debt (Note 5) | — |  |  | (6) |  |  | — |  |  | (6) |  |
| Investment impairments | (3) |  |  | — |  |  | (9) |  |  | (1) |  |
| Foreign currency gain (loss) | (21) |  |  | 27 |  |  | (40) |  |  | 50 |  |
| Gain (loss) on derivative instruments (Note 6) | 9 |  |  | (34) |  |  | 17 |  |  | (57) |  |
| Gain (loss) on equity method investments | 1 |  |  | (2) |  |  | 1 |  |  | (2) |  |
| Fair value adjustments to equity investments | 16 |  |  | (12) |  |  | 19 |  |  | (30) |  |
| Gain on TETRA Ireland equity method investment | — |  |  | — |  |  | — |  |  | 21 |  |
| Other | — |  |  | (5) |  |  | 2 |  |  | (5) |  |
|  | $ | 26 |  |  | $ | (2) |  |  | $ | 39 |  |  | $ | 33 |  |

[0000068505-23-000039:notes:51]
[same as prior period, unchanged from 0000068505-23-000026:notes:51]

[0000068505-23-000039:notes:52]
[same as prior period, unchanged from 0000068505-23-000026:notes:52]

[0000068505-23-000039:notes:53]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 371 |  |  | $ | 228 |  |  | $ | 649 |  |  | $ | 495 |  |
| Weighted average common shares outstanding | 167.5 |  |  | 167.2 |  |  | 167.4 |  |  | 167.6 |  |
| Per share amount | $ | 2.21 |  |  | $ | 1.36 |  |  | $ | 3.88 |  |  | $ | 2.95 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 371 |  |  | $ | 228 |  |  | $ | 649 |  |  | $ | 495 |  |
| Weighted average common shares outstanding | 167.5 |  |  | 167.2 |  |  | 167.4 |  |  | 167.6 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.6 |  |  | 3.4 |  |  | 3.8 |  |  | 3.9 |  |
| 1.75% senior convertible notes | 1.5 |  |  | 0.3 |  |  | 1.3 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding | 172.6 |  |  | 170.9 |  |  | 172.5 |  |  | 172.0 |  |
| Per share amount | $ | 2.15 |  |  | $ | 1.33 |  |  | $ | 3.76 |  |  | $ | 2.88 |  |

[0000068505-23-000039:notes:54]
In the computation of diluted earnings per common share for the three months ended July 1, 2023, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the six months ended July 1, 2023, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-23-000039:notes:55]
In the computation of diluted earnings per common share for the three months ended July 2, 2022, the assumed exercise of 0.2 million options, inclusive of 0.1 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In the computation

[0000068505-23-000039:notes:56]
of diluted earnings per common share for the six months ended July 2, 2022, the assumed exercise of 0.2 million options were excluded because their inclusion would have been antidilutive.

[0000068505-23-000039:notes:57]
As of July 1, 2023, the Company had $1.0 billion of the Senior Convertible Notes outstanding, which mature on September 15, 2024. The notes are convertible based on a conversion rate of 4.9670 per $1,000 principal amount (which is equal to a conversion price of $201.33 per share), adjusted for dividends declared through the date of settlement. The notes became fully convertible as of September 5, 2021, when the average stock price exceeded the contractual conversion price, providing the holders the option to convert all or any portion of their Senior Convertible Notes. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash. Because the Company has irrevocably decided to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the quarter ended October 2, 2021. Upon conversion of the Senior Convertible Notes, the Company has the option to settle the conversion spread in cash or shares. The Company included the number of shares that would be issuable upon conversion in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended July 1, 2023. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of July 1, 2023 was $402 million.

[0000068505-23-000039:notes:58]
[same as prior period, unchanged from 0000068505-23-000026:notes:56]

[0000068505-23-000039:notes:59]
[same as prior period, unchanged from 0000068505-23-000026:notes:57]

[0000068505-23-000039:notes:60]
[same as prior period, unchanged from 0000068505-23-000026:notes:58]

[0000068505-23-000039:notes:61]
|  | July 1, 2023 |  | December 31, 2022 |
| Accounts receivable | $ | 1,578 |  |  | $ | 1,579 |  |
| Less allowance for credit losses | (65) |  |  | (61) |  |
|  | $ | 1,513 |  |  | $ | 1,518 |  |

[0000068505-23-000039:notes:62]
[same as prior period, unchanged from 0000068505-23-000026:notes:60]

[0000068505-23-000039:notes:63]
[same as prior period, unchanged from 0000068505-23-000026:notes:61]

[0000068505-23-000039:notes:64]
|  | July 1, 2023 |  | December 31, 2022 |
| Finished goods | $ | 337 |  |  | $ | 354 |  |
| Work-in-process and production materials | 821 |  |  | 829 |  |
|  | 1,158 |  |  | 1,183 |  |
| Less inventory reserves | (138) |  |  | (128) |  |
|  | $ | 1,020 |  |  | $ | 1,055 |  |

[0000068505-23-000039:notes:65]
[same as prior period, unchanged from 0000068505-23-000026:notes:63]

[0000068505-23-000039:notes:66]
[same as prior period, unchanged from 0000068505-23-000026:notes:64]

[0000068505-23-000039:notes:67]
|  | July 1, 2023 |  | December 31, 2022 |
| Current contract cost assets (Note 2) | $ | 84 |  |  | $ | 61 |  |
| Tax-related deposits | 34 |  |  | 33 |  |
| Other | 232 |  |  | 289 |  |
|  | $ | 350 |  |  | $ | 383 |  |

[0000068505-23-000039:notes:68]
[same as prior period, unchanged from 0000068505-23-000026:notes:66]

[0000068505-23-000039:notes:69]
[same as prior period, unchanged from 0000068505-23-000026:notes:67]

[0000068505-23-000039:notes:70]
|  | July 1, 2023 |  | December 31, 2022 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 460 |  |  | 456 |  |
| Machinery and equipment | 2,282 |  |  | 2,303 |  |
|  | 2,747 |  |  | 2,764 |  |
| Less accumulated depreciation | (1,812) |  |  | (1,837) |  |
|  | $ | 935 |  |  | $ | 927 |  |

[0000068505-23-000039:notes:71]
Depreciation expense for the three months ended July 1, 2023 and July 2, 2022 was $44 million and $47 million, respectively. Depreciation expense for the six months ended July 1, 2023 and July 2, 2022 was $87 million and $92 million, respectively.

[0000068505-23-000039:notes:72]
[same as prior period, unchanged from 0000068505-23-000026:notes:70]

[0000068505-23-000039:notes:73]
[same as prior period, unchanged from 0000068505-23-000026:notes:71]

[0000068505-23-000039:notes:74]
|  | July 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Common stock | $ | 38 |  |  | $ | 21 |  |  |  |  |  |
| Strategic investments | 35 |  |  | 45 |  |  |  |  |  |
| Company-owned life insurance policies | 76 |  |  | 69 |  |  |  |  |  |
| Equity method investments | 13 |  |  | 12 |  |  |  |  |  |
|  | $ | 162 |  |  | $ | 147 |  |  |  |  |  |

[0000068505-23-000039:notes:75]
During the six months ended July 1, 2023, the Company recognized a gain of $17 million in Other income (expense) within the Condensed Consolidated Statement of Operations related to an increase in the fair value of its investment in Evolv Technologies, Inc. During the six months ended July 1, 2023, the Company recorded a $9 million investment impairment charge, representing an other-than-temporary decline in the value of the Company's strategic equity investment portfolio. The investment impairment charge is classified within Other income (expense) within the Condensed Consolidated Statement of Operations.

[0000068505-23-000039:notes:76]
[same as prior period, unchanged from 0000068505-23-000026:notes:74]

[0000068505-23-000039:notes:77]
[same as prior period, unchanged from 0000068505-23-000026:notes:75]

[0000068505-23-000039:notes:78]
|  | July 1, 2023 |  | December 31, 2022 |
| Defined benefit plan assets | $ | 156 |  |  | $ | 164 |  |
| Non-current contract cost assets (Note 2) | 105 |  |  | 130 |  |
| Other | 62 |  |  | 16 |  |
|  | $ | 323 |  |  | $ | 310 |  |

[0000068505-23-000039:notes:79]
[same as prior period, unchanged from 0000068505-23-000026:notes:77]

[0000068505-23-000039:notes:80]
[same as prior period, unchanged from 0000068505-23-000026:notes:78]

[0000068505-23-000039:notes:81]
The Company's outstanding amounts related to the suppliers participating in this program was $32 million and $37 million as of July 1, 2023 and December 31, 2022, respectively. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-23-000039:notes:82]
[same as prior period, unchanged from 0000068505-23-000026:notes:80]

[0000068505-23-000039:notes:83]
[same as prior period, unchanged from 0000068505-23-000026:notes:81]

[0000068505-23-000039:notes:84]
|  | July 1, 2023 |  | December 31, 2022 |
| Compensation | $ | 270 |  |  | $ | 374 |  |
| Tax liabilities | 270 |  |  | 367 |  |
| Dividend payable | 147 |  |  | 148 |  |
| Trade liabilities | 136 |  |  | 145 |  |
| Operating lease liabilities (Note 3) | 114 |  |  | 118 |  |
| Customer reserves | 67 |  |  | 78 |  |
| Other | 322 |  |  | 408 |  |
|  | $ | 1,326 |  |  | $ | 1,638 |  |

[0000068505-23-000039:notes:85]
[same as prior period, unchanged from 0000068505-23-000026:notes:83]

[0000068505-23-000039:notes:86]
[same as prior period, unchanged from 0000068505-23-000026:notes:84]

[0000068505-23-000039:notes:87]
|  | July 1, 2023 |  | December 31, 2022 |
| Defined benefit plans | $ | 949 |  |  | $ | 1,004 |  |
| Non-current contract liabilities (Note 2) | 382 |  |  | 363 |  |
| Unrecognized tax benefits (Note 7) | 29 |  |  | 29 |  |
| Deferred income taxes (Note 7) | 71 |  |  | 73 |  |
| Environmental reserve | 123 |  |  | 108 |  |
| Other | 175 |  |  | 114 |  |
|  | $ | 1,729 |  |  | $ | 1,691 |  |

[0000068505-23-000039:notes:88]
[same as prior period, unchanged from 0000068505-23-000026:notes:86]

[0000068505-23-000039:notes:89]
Share Repurchase Program: During the three and six months ended July 1, 2023, the Company paid an aggregate of $224 million and $364 million, including transaction costs, to repurchase approximately 0.8 million and 1.3 million shares at an average price of $283.39 and $274.66 per share, respectively. As of July 1, 2023, the Company had $921 million of authority available for future repurchases.

[0000068505-23-000039:notes:90]
Payment of Dividends: During the three months ended July 1, 2023 and July 2, 2022, the Company paid $148 million and $132 million, respectively, in cash dividends to holders of its common stock. During the six months ended July 1, 2023 and July 2, 2022, the Company paid $296 million and $266 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $147 million in cash dividends to holders of its common stock.

[0000068505-23-000039:notes:91]
[same as prior period, unchanged from 0000068505-23-000026:notes:89]

[0000068505-23-000039:notes:92]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and six months ended July 1, 2023 and July 2, 2022:

[0000068505-23-000039:notes:93]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (503) |  |  | $ | (404) |  |  | $ | (539) |  |  | $ | (384) |  |
| Other comprehensive income (loss) before reclassification adjustment | 27 |  |  | (132) |  |  | 54 |  |  | (151) |  |
| Tax benefit (expense) | — |  |  | (3) |  |  | 9 |  |  | (4) |  |
| Other comprehensive income (loss), net of tax | 27 |  |  | (135) |  |  | 63 |  |  | (155) |  |
| Balance at end of period | $ | (476) |  |  | $ | (539) |  |  | $ | (476) |  |  | $ | (539) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,984) |  |  | $ | (1,980) |  |  | $ | (1,996) |  |  | $ | (1,995) |  |
| Other comprehensive income before reclassification adjustment | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Tax expense | — |  |  | (3) |  |  | — |  |  | (3) |  |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 15 |  |  | 20 |  |  | 30 |  |  | 40 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | 1 |  |  | (1) |  |  | 2 |  |  | (2) |  |
| Tax expense | (3) |  |  | (5) |  |  | (7) |  |  | (9) |  |
| Reclassification adjustments into Net earnings, net of tax | 13 |  |  | 14 |  |  | 25 |  |  | 29 |  |
| Other comprehensive income, net of tax | 13 |  |  | 28 |  |  | 25 |  |  | 43 |  |
| Balance at end of period | $ | (1,971) |  |  | $ | (1,952) |  |  | $ | (1,971) |  |  | $ | (1,952) |  |
| Total Accumulated other comprehensive loss | $ | (2,447) |  |  | $ | (2,491) |  |  | $ | (2,447) |  |  | $ | (2,491) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-23-000039:notes:94]
Debt and Credit Facilities
As of July 1, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 1, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

[0000068505-23-000039:notes:95]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 1, 2023 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-23-000039:notes:96]
[same as prior period, unchanged from 0000068505-23-000026:notes:94]

[0000068505-23-000039:notes:97]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.2 billion and $1.1 billion for periods ended July 1, 2023 and December 31, 2022, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-23-000039:notes:98]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of July 1, 2023, and the corresponding positions as of December 31, 2022:

[0000068505-23-000039:notes:99]
|  | Notional Amount |
| Net Buy (Sell) by Currency | July 1, 2023 |  | December 31, 2022 |
| British pound | $ | 257 |  |  | $ | 290 |  |
| Euro | 214 |  |  | 185 |  |
| Australian dollar | (150) |  |  | (130) |  |
| Chinese renminbi | (61) |  |  | (61) |  |
| Danish krone | 48 |  |  | 32 |  |

[0000068505-23-000039:notes:100]
[same as prior period, unchanged from 0000068505-23-000026:notes:98]

[0000068505-23-000039:notes:101]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of July 1, 2023, all of the counterparties had investment grade credit ratings. As of July 1, 2023, the Company had $6 million of exposure to aggregate credit risk with all counterparties.

[0000068505-23-000039:notes:102]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of July 1, 2023 and December 31, 2022:

[0000068505-23-000039:notes:103]
|  | Fair Values of Derivative Instruments |
| July 1, 2023 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 2 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 6 |  |  | — |  |
| Total derivatives | $ | 6 |  |  | $ | 2 |  |

[0000068505-23-000039:notes:104]
[same as prior period, unchanged from 0000068505-23-000026:notes:102]

[0000068505-23-000039:notes:105]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and six months ended July 1, 2023 and July 2, 2022:

[0000068505-23-000039:notes:106]
|  | Financial Statement Location | Three Months Ended |  | Six Months Ended |
| Foreign Exchange Contracts | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Effective portion of derivatives designated | Accumulated othercomprehensive gain (loss) | $ | (2) |  |  | $ | 10 |  |  | $ | (4) |  |  | $ | 12 |  |
| Forward points recognized | Other income (expense) | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Derivatives not designated as hedging instruments | Other income (expense) | 9 |  |  | (34) |  |  | 17 |  |  | (57) |  |

[0000068505-23-000039:notes:107]
[same as prior period, unchanged from 0000068505-23-000026:notes:105]

[0000068505-23-000039:notes:108]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of July 1, 2023, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £55 million of net investment hedges in a British pound functional subsidiary.

[0000068505-23-000039:notes:109]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. During the six months ended July 1, 2023 and July 2, 2022, the Company amortized $1 million of income from the excluded components through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-23-000039:notes:110]
[same as prior period, unchanged from 0000068505-23-000026:notes:108]

[0000068505-23-000039:notes:111]
[same as prior period, unchanged from 0000068505-23-000026:notes:109]

[0000068505-23-000039:notes:112]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net earnings before income taxes | $ | 487 |  |  | $ | 300 |  |  | $ | 846 |  |  | $ | 520 |  |
| Income tax expense | 114 |  |  | 71 |  |  | 194 |  |  | 23 |  |
| Effective tax rate | 23 | % |  | 24 | % |  | 23 | % |  | 4 | % |

[0000068505-23-000039:notes:113]
The effective tax rate for the three months ended July 1, 2023 of 23% and the effective tax rate for the six months ended July 1, 2023 of 23% were higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by excess tax benefits of share-based compensation.

[0000068505-23-000039:notes:114]
The effective tax rate for the three months ended July 2, 2022 of 24% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense. The effective tax rate for the six months ended July 2, 2022 of 4% was lower than the U.S. federal statutory tax rate of 21% primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights, higher excess tax benefits of share-based compensation, and a higher foreign derived intangible income deduction in 2022.

[0000068505-23-000039:notes:115]
The effective tax rate for the three months ended July 1, 2023 of 23% was lower than the effective tax rate for the three months ended July 2, 2022 of 24%, primarily due to higher excess tax benefits of share-based compensation in 2023. The effective tax rate for the six months ended July 1, 2023 of 23% was higher than the effective tax rate for the six months ended July 2, 2022 of 4%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights, higher excess tax benefits of share-based compensation, and a higher foreign derived intangible income deduction in 2022.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-23-000039:notes:116]
[same as prior period, unchanged from 0000068505-23-000026:notes:113]

[0000068505-23-000039:notes:117]
[same as prior period, unchanged from 0000068505-23-000026:notes:114]

[0000068505-23-000039:notes:118]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 47 |  |  | 32 |  |  | 2 |  |  | 8 |  |  | 2 |  |  | — |  |
| Expected return on plan assets | (73) |  |  | (64) |  |  | (15) |  |  | (26) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 5 |  |  | 15 |  |  | 9 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | — |  |  | (1) |  |  | 1 |  |  | — |  |
| Net periodic pension cost (benefits) | $ | (21) |  |  | $ | (17) |  |  | $ | (4) |  |  | $ | (14) |  |  | $ | 1 |  |  | $ | (2) |  |

[0000068505-23-000039:notes:119]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 94 |  |  | 64 |  |  | 4 |  |  | 16 |  |  | 3 |  |  | — |  |
| Expected return on plan assets | (146) |  |  | (127) |  |  | (30) |  |  | (51) |  |  | (6) |  |  | (6) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 10 |  |  | 30 |  |  | 18 |  |  | 8 |  |  | 2 |  |  | 2 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | — |  |  | (2) |  |  | 2 |  |  | — |  |
| Net periodic pension cost (benefits) | $ | (42) |  |  | $ | (33) |  |  | $ | (8) |  |  | $ | (28) |  |  | $ | 1 |  |  | $ | (4) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-23-000039:notes:120]
[same as prior period, unchanged from 0000068505-23-000026:notes:116]

[0000068505-23-000039:notes:121]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 10 |  |  | $ | 7 |  |  | $ | 20 |  |  | $ | 13 |  |
| Selling, general and administrative expenses | 29 |  |  | 25 |  |  | 59 |  |  | 46 |  |
| Research and development expenditures | 14 |  |  | 12 |  |  | 29 |  |  | 22 |  |
| Share-based compensation expense included in Operating earnings | 53 |  |  | 44 |  |  | 108 |  |  | 81 |  |
| Tax benefit | (11) |  |  | (9) |  |  | (22) |  |  | (17) |  |
| Share-based compensation expense, net of tax | $ | 42 |  |  | $ | 35 |  |  | $ | 86 |  |  | $ | 64 |  |
| Decrease in basic earnings per share | $ | (0.25) |  |  | $ | (0.21) |  |  | $ | (0.51) |  |  | $ | (0.38) |  |
| Decrease in diluted earnings per share | $ | (0.24) |  |  | $ | (0.21) |  |  | $ | (0.50) |  |  | $ | (0.37) |  |

[0000068505-23-000039:notes:122]
During the six months ended July 1, 2023, the Company granted 0.6 million restricted stock units (RSUs) and 0.1 million performance stock units (PSUs) and 0.1 million market stock units (MSUs) with an aggregate grant-date fair value of $166 million, $19 million and $13 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $7 million and $13 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-23-000039:notes:123]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of July 1, 2023 and December 31, 2022 were as follows:

[0000068505-23-000039:notes:124]
| July 1, 2023 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 6 |  |  |  |  | $ | 6 |  |
| Common stock | 38 |  |  | — |  |  |  |  | 38 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 2 |  |  |  |  | $ | 2 |  |

[0000068505-23-000039:notes:125]
[same as prior period, unchanged from 0000068505-23-000026:notes:121]

[0000068505-23-000039:notes:126]
The Company had no foreign exchange derivative contracts or common stock investments in Level 3 holdings as of July 1, 2023 or December 31, 2022.

[0000068505-23-000039:notes:127]
At July 1, 2023 and December 31, 2022, the Company had $228 million and $490 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-23-000039:notes:128]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of July 1, 2023 was $6.1 billion, of which the Senior Convertible Notes were $1.4 billion (Level 2). The fair value of long-term debt at December 31, 2022 was $5.9 billion, of which the Senior Convertible Notes were $1.3 billion (Level 2).

[0000068505-23-000039:notes:129]
[same as prior period, unchanged from 0000068505-23-000026:notes:125]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-23-000039:notes:130]
[same as prior period, unchanged from 0000068505-23-000026:notes:126]

[0000068505-23-000039:notes:131]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended July 1, 2023 and July 2, 2022:

[0000068505-23-000039:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Contract-specific discounting facility | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 49 |  |
| Accounts receivable sales proceeds | — |  |  | 40 |  |  | — |  |  | 62 |  |
| Long-term receivables sales proceeds | 26 |  |  | 5 |  |  | 58 |  |  | 22 |  |
| Total proceeds from receivable sales | $ | 26 |  |  | $ | 45 |  |  | $ | 58 |  |  | $ | 133 |  |

[0000068505-23-000039:notes:133]
At July 1, 2023, the Company had retained servicing obligations for $834 million of long-term receivables, compared to $891 million at December 31, 2022. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $207 million at July 1, 2023, compared to $65 million at December 31, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-23-000039:notes:134]
Commitments and Contingencies
Legal Matters

[0000068505-23-000039:notes:135]
Hytera Litigation

[0000068505-23-000039:notes:136]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-23-000039:notes:137]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. Hytera made quarterly royalty payments on October 31, 2022, January 31, 2023, April 25, 2023 and July 25, 2023 into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow. On July 11, 2023, the Court denied Hytera's modification and stay motions and stated that it will consider the Company's contempt motion on August 8, 2023, if Hytera has not yet made the deposit previously due on July 31, 2022, into the escrow account. The Court subsequently set the Company's contempt motion for hearing on August 17, 2023.

[0000068505-23-000039:notes:138]
On August 2, 2022, Hytera appealed the Court's judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. The parties have now submitted all briefs and responses on Hytera's appeal and the Company's cross-appeal. The Court of Appeals has not set an oral argument date yet.

[0000068505-23-000039:notes:139]
Hytera Bankruptcy Proceedings

[0000068505-23-000039:notes:140]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gains for the two monetary distributions were recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-23-000039:notes:141]
[same as prior period, unchanged from 0000068505-23-000026:notes:137]

[0000068505-23-000039:notes:142]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Products and Systems Integration | $ | 1,437 |  |  | $ | 1,285 |  |  | $ | 2,740 |  |  | $ | 2,388 |  |
| Software and Services | 966 |  |  | 855 |  |  | 1,834 |  |  | 1,644 |  |
|  | $ | 2,403 |  |  | $ | 2,140 |  |  | $ | 4,574 |  |  | $ | 4,032 |  |

[0000068505-23-000039:notes:143]
[same as prior period, unchanged from 0000068505-23-000026:notes:139]

[0000068505-23-000039:notes:144]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Products and Systems Integration | $ | 212 |  |  | $ | 118 |  |  | $ | 388 |  |  | $ | 157 |  |
| Software and Services | 306 |  |  | 240 |  |  | 529 |  |  | 440 |  |
| Operating earnings | 518 |  |  | 358 |  |  | 917 |  |  | 597 |  |
| Total other expense | (31) |  |  | (58) |  |  | (71) |  |  | (77) |  |
| Earnings before income taxes | $ | 487 |  |  | $ | 300 |  |  | $ | 846 |  |  | $ | 520 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-23-000039:notes:145]
[same as prior period, unchanged from 0000068505-23-000026:notes:141]

[0000068505-23-000039:notes:146]
During the three months ended July 1, 2023, the Company recorded net reorganization of business charges of $3 million, including $5 million of charges in Other charges and $2 million of reversals recorded in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $3 million were charges of $9 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $1 million of reversals for employee separation accruals no longer needed.

[0000068505-23-000039:notes:147]
During the six months ended July 1, 2023, the Company recorded net reorganization of business charges of $16 million, including $12 million of charges in Other charges and $4 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $16 million were charges of $24 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $3 million of reversals for employee separation accruals no longer needed.

[0000068505-23-000039:notes:148]
[same as prior period, unchanged from 0000068505-23-000026:notes:143]

[0000068505-23-000039:notes:149]
| July 1, 2023 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 17 |  |
| Software and Services | (3) |  |  | (1) |  |
|  | $ | 3 |  |  | $ | 16 |  |

[0000068505-23-000039:notes:150]
[same as prior period, unchanged from 0000068505-23-000026:notes:145]

[0000068505-23-000039:notes:151]
|  | January 1, 2023 |  | Additional Charges |  | Adjustments |  | Amount Used |  | July 1, 2023 |
| Employee separation costs | $ | 26 |  |  | $ | 24 |  |  | $ | (3) |  |  | $ | (19) |  |  | $ | 28 |  |
| Exit costs | 10 |  |  | — |  |  | (5) |  |  | — |  |  | 5 |  |
|  | $ | 36 |  |  | $ | 24 |  |  | $ | (8) |  |  | $ | (19) |  |  | $ | 33 |  |

[0000068505-23-000039:notes:152]
[same as prior period, unchanged from 0000068505-23-000026:notes:147]

[0000068505-23-000039:notes:153]
At January 1, 2023, the Company had an accrual of $10 million for exit costs, related to the Company's exit of the ESN contract with the Home Office in 2022. During the three months ended July 1, 2023, the Company recorded a $5 million reversal for accruals no longer needed. The $5 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at July 1, 2023, and are expected to be paid within one year.

[0000068505-23-000039:notes:154]
[same as prior period, unchanged from 0000068505-23-000026:notes:149]

[0000068505-23-000039:notes:155]
At January 1, 2023, the Company had an accrual of $26 million for employee separation costs. The 2023 additional charges of $24 million represent severance costs for approximately 440 employees. The adjustment of $3 million reflects reversals for accruals no longer needed. The $19 million used reflects cash payments to severed employees. The remaining accrual of $28 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at July 1, 2023, is expected to be paid, primarily within one year, to approximately 550 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-23-000039:notes:156]
[same as prior period, unchanged from 0000068505-23-000026:notes:151]

[0000068505-23-000039:notes:157]
During the three months ended July 2, 2022, the Company recorded net reorganization of business charges of $7 million, including $5 million of charges in Other charges and $2 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $7 million were charges of $11 million related to employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-23-000039:notes:158]
During the six months ended July 2, 2022, the Company recorded net reorganization of business charges of $17 million, including $12 million of charges in Other charges and $5 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $17 million were charges of $24 million related to employee separation costs, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-23-000039:notes:159]
| July 2, 2022 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 14 |  |
| Software and Services | 1 |  |  | 3 |  |
|  | $ | 7 |  |  | $ | 17 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-23-000039:notes:160]
Intangible Assets and Goodwill
On December 14, 2022, the Company acquired Rave Mobile, a leader in mass notification and incident management, for $553 million net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The Company recognized $405 million of goodwill, $212 million of identifiable intangible assets and $64 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $9 million of trade names, $82 million of developed technology and $121 million of customer relationships and will be amortized over a period of nine, seventeen years and seventeen years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-23-000039:notes:161]
On October 25, 2022, the Company acquired Futurecom, a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The Company recognized $11 million of goodwill, $11 million of identifiable intangible assets, and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of six years. The business is a part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-23-000039:notes:162]
On August 8, 2022, the Company acquired Barrett Communications, a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The Company recognized $1 million of goodwill, $3 million of identifiable intangible assets, and $14 million of net assets. The identifiable intangible assets were classified as $1 million of trade names and $2 million of developed technology, both of which will be amortized over a period of seven years.The goodwill is not deductible for tax purposes. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-23-000039:notes:163]
On May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The Company recognized $9 million of goodwill, $7 million of identifiable intangible assets and $7 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of four years. The business is part of the Products and Systems Integration segment. The purchase accounting was completed as of the second quarter of 2023.

[0000068505-23-000039:notes:164]
On April 19, 2022, the Company acquired Calipsa, a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The Company recognized $24 million of goodwill, $21 million of identifiable intangible assets and $6 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $20 million of developed technology and $1 million of customer relationships that will be amortized over a period of fifteen and three years, respectively. The business is a part of the Software and Services segment. The purchase accounting was completed as of the second quarter of 2023.

[0000068505-23-000039:notes:165]
[same as prior period, unchanged from 0000068505-23-000026:notes:159]

[0000068505-23-000039:notes:166]
[same as prior period, unchanged from 0000068505-23-000026:notes:160]

[0000068505-23-000039:notes:167]
[same as prior period, unchanged from 0000068505-23-000026:notes:161]

[0000068505-23-000039:notes:168]
[same as prior period, unchanged from 0000068505-23-000026:notes:162]

[0000068505-23-000039:notes:169]
|  | July 1, 2023 |  | December 31, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,097 |  |  | $ | 402 |  |  | $ | 1,083 |  |  | $ | 358 |  |
| Customer-related | 1,555 |  |  | 1,019 |  |  | 1,519 |  |  | 935 |  |
| Other intangibles | 100 |  |  | 70 |  |  | 99 |  |  | 66 |  |
|  | $ | 2,752 |  |  | $ | 1,491 |  |  | $ | 2,701 |  |  | $ | 1,359 |  |

[0000068505-23-000039:notes:170]
Amortization expense on intangible assets was $43 million and $98 million for the three and six months ended July 1, 2023, respectively. Amortization expense on intangible assets was $65 million and $131 million for the three and six months ended July 2, 2022, respectively. As of July 1, 2023, annual amortization expense is estimated to be $176 million in 2023, $139 million in 2024, $126 million in 2025, $117 million in 2026, $107 million in 2027 and $107 million in 2028.

[0000068505-23-000039:notes:171]
[same as prior period, unchanged from 0000068505-23-000026:notes:165]

[0000068505-23-000039:notes:172]
|  | July 1, 2023 |  | December 31, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 913 |  |  | $ | 301 |  |  | $ | 913 |  |  | $ | 261 |  |
| Software and Services | 1,839 |  |  | 1,190 |  |  | 1,788 |  |  | 1,098 |  |
|  | $ | 2,752 |  |  | $ | 1,491 |  |  | $ | 2,701 |  |  | $ | 1,359 |  |

[0000068505-23-000039:notes:173]
[same as prior period, unchanged from 0000068505-23-000026:notes:167]

[0000068505-23-000039:notes:174]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2023 to July 1, 2023:

[0000068505-23-000039:notes:175]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2023 | $ | 1,461 |  |  | $ | 1,851 |  |  | $ | 3,312 |  |
| Goodwill acquired | — |  |  | — |  |  | — |  |
| Purchase accounting adjustments | (1) |  |  | (25) |  |  | (26) |  |
| Foreign currency | 1 |  |  | 8 |  |  | 9 |  |
| Balance as of July 1, 2023 | $ | 1,461 |  |  | $ | 1,834 |  |  | $ | 3,295 |  |
