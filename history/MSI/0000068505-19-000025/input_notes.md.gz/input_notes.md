# MSI notes — 0000068505-19-000025


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-19-000025:notes:1]
[same as prior period, unchanged from 0000068505-19-000019:notes:1]

[0000068505-19-000025:notes:2]
The condensed consolidated financial statements as of September 28, 2019 and for the three and nine months ended September 28, 2019 and September 29, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-19-000025:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three and nine months ended September 28, 2019 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-19-000025:notes:4]
[same as prior period, unchanged from 0000068505-19-000019:notes:4]

[0000068505-19-000025:notes:5]
[same as prior period, unchanged from 0000068505-19-000019:notes:5]

[0000068505-19-000025:notes:6]
[same as prior period, unchanged from 0000068505-19-000019:notes:6]

[0000068505-19-000025:notes:7]
[same as prior period, unchanged from 0000068505-19-000019:notes:7]

[0000068505-19-000025:notes:8]
[same as prior period, unchanged from 0000068505-19-000019:notes:8]

[0000068505-19-000025:notes:9]
[same as prior period, unchanged from 0000068505-19-000019:notes:9]

[0000068505-19-000025:notes:10]
[same as prior period, unchanged from 0000068505-19-000019:notes:10]

[0000068505-19-000025:notes:11]
[same as prior period, unchanged from 0000068505-19-000019:notes:11]

[0000068505-19-000025:notes:12]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-19-000025:notes:13]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019 and May 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” “ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ” “Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” and “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for the Company on January 1, 2020 and requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-19-000025:notes:14]
Recently Adopted Accounting Pronouncements

[0000068505-19-000025:notes:15]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-19-000025:notes:16]
[same as prior period, unchanged from 0000068505-19-000019:notes:16]

[0000068505-19-000025:notes:17]
[same as prior period, unchanged from 0000068505-19-000019:notes:17]

[0000068505-19-000025:notes:18]
[same as prior period, unchanged from 0000068505-19-000019:notes:18]

[0000068505-19-000025:notes:19]
[same as prior period, unchanged from 0000068505-19-000019:notes:19]

[0000068505-19-000025:notes:20]
[same as prior period, unchanged from 0000068505-19-000019:notes:20]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-19-000025:notes:21]
[same as prior period, unchanged from 0000068505-19-000019:notes:21]

[0000068505-19-000025:notes:22]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 28, 2019 and September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

[0000068505-19-000025:notes:23]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,050 |  |  | $ | 403 |  |  | $ | 957 |  |  | $ | 343 |  |
| EMEA | 182 |  |  | 201 |  |  | 199 |  |  | 189 |  |
| Asia Pacific | 117 |  |  | 41 |  |  | 132 |  |  | 42 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 896 |  |  | $ | — |  |  | $ | 828 |  |  | $ | — |  |
| Systems and Systems Integration | 453 |  |  | — |  |  | 460 |  |  | — |  |
| Services | — |  |  | 479 |  |  | — |  |  | 455 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 119 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 602 |  |  | $ | 811 |  |  | $ | 543 |  |
| Indirect | 489 |  |  | 43 |  |  | 477 |  |  | 31 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |

[0000068505-19-000025:notes:24]
|  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 2,832 |  |  | $ | 1,133 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 499 |  |  | 603 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 325 |  |  | 119 |  |  | 353 |  |  | 126 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 2,391 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 1,265 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 1,400 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 455 |  |  | — |  |  | 303 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,289 |  |  | $ | 1,737 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 1,367 |  |  | 118 |  |  | 1,261 |  |  | 74 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |

[0000068505-19-000025:notes:25]
[same as prior period, unchanged from 0000068505-19-000019:notes:25]

[0000068505-19-000025:notes:26]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of September 28, 2019 is $7.1 billion. A total of $3.2 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion is from Services and Software performance obligations that are not yet satisfied as of September 28, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-19-000025:notes:27]
[same as prior period, unchanged from 0000068505-19-000019:notes:27]

[0000068505-19-000025:notes:28]
|  | September 28, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,295 |  |  | $ | 1,293 |  |
| Contract assets | 921 |  |  | 1,012 |  |
| Contract liabilities | 1,223 |  |  | 1,263 |  |
| Non-current contract liabilities | 253 |  |  | 214 |  |

[0000068505-19-000025:notes:29]
Revenue recognized during the three months ended September 28, 2019 which was previously included in Contract liabilities as of June 29, 2019 is $342 million, compared to $327 million of revenue recognized during the three months ended September 29, 2018 which was previously included in Contract liabilities as of July 1, 2018. Revenue recognized during the nine months ended September 28, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $783 million, compared to $777 million of revenue recognized during the nine months ended September 29, 2018 which was previously included in Contract liabilities as of January 1, 2018. Revenue of $26 million and $42 million was reversed during the three and nine months ended September 28, 2019, respectively, which were primarily driven by changes in the estimates of progress on two Americas system contracts, compared to $7 million and $4 million of reversals for the three and nine months ended September 29, 2018, respectively.

[0000068505-19-000025:notes:30]
There were no material impairment losses recognized on contract assets during the three and nine months ended September 28, 2019 and September 29, 2018.

[0000068505-19-000025:notes:31]
[same as prior period, unchanged from 0000068505-19-000019:notes:31]

[0000068505-19-000025:notes:32]
|  | September 28, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 28 |  |  | $ | 30 |  |
| Non-current contract cost assets | 102 |  |  | 98 |  |

[0000068505-19-000025:notes:33]
Amortization of non-current contract cost assets was $10 million and $11 million for the three months ended September 28, 2019 and September 29, 2018, respectively, and $32 million and $34 million for the nine months ended September 28, 2019 and September 29, 2018, respectively.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-19-000025:notes:34]
[same as prior period, unchanged from 0000068505-19-000019:notes:34]

[0000068505-19-000025:notes:35]
[same as prior period, unchanged from 0000068505-19-000019:notes:35]

[0000068505-19-000025:notes:36]
[same as prior period, unchanged from 0000068505-19-000019:notes:36]

[0000068505-19-000025:notes:37]
[same as prior period, unchanged from 0000068505-19-000019:notes:37]

[0000068505-19-000025:notes:38]
[same as prior period, unchanged from 0000068505-19-000019:notes:38]

[0000068505-19-000025:notes:39]
[same as prior period, unchanged from 0000068505-19-000019:notes:39]

[0000068505-19-000025:notes:40]
| September 28, 2019 |  | Three Months Ended |  | Nine Months Ended |
| Lease expense: |  |  |  |  |
| Operating lease cost |  | $ | 33 |  |  | $ | 99 |  |
| Finance lease cost |  |  |  |  |
| Amortization of right-of-use assets |  | 3 |  |  | 9 |  |
| Interest on lease liabilities |  | 1 |  |  | 1 |  |
| Total finance lease cost |  | 4 |  |  | 10 |  |
| Short-term lease cost |  | 1 |  |  | 4 |  |
| Variable cost |  | 8 |  |  | 25 |  |
| Sublease income |  | (1 | ) |  | (3 | ) |
| Net lease expense |  | $ | 45 |  |  | $ | 135 |  |

[0000068505-19-000025:notes:41]
[same as prior period, unchanged from 0000068505-19-000019:notes:41]

[0000068505-19-000025:notes:42]
|  |  | Statement Line Classification |  | September 28, 2019 |
| Assets: |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 561 |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 43 |  |
|  |  |  |  | $ | 604 |  |
| Current liabilities: |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 118 |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 13 |  |
|  |  |  |  | $ | 131 |  |
| Non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 499 |  |
| Finance lease liabilities |  | Long-term debt |  | 18 |  |
|  |  |  |  | $ | 517 |  |

[0000068505-19-000025:notes:43]
[same as prior period, unchanged from 0000068505-19-000019:notes:43]

[0000068505-19-000025:notes:44]
|  | Nine Months Ended |
|  | September 28, 2019 |
| Supplemental cash flow information: |  |
| Net cash used for operating activities related to operating leases | $ | 110 |  |
| Net cash used for operating activities related to finance leases | 1 |  |
| Net cash used for financing activities related to finance leases | 11 |  |
| Assets obtained in exchange for lease liabilities: |  |
| Operating leases | $ | 69 |  |

[0000068505-19-000025:notes:45]
|  | September 28, 2019 |
| Weighted average remaining lease terms (years): |  |
| Operating leases | 8 |  |
| Finance leases | 2 |  |
| Weighted average discount rate: |  |
| Operating leases | 3.67 | % |
| Finance leases | 4.95 | % |

[0000068505-19-000025:notes:46]
Future lease payments as of September 28, 2019 are as follows:

[0000068505-19-000025:notes:47]
|  | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2019 | $ | 28 |  |  | $ | 4 |  |  | $ | 32 |  |
| 2020 | 137 |  |  | 14 |  |  | 151 |  |
| 2021 | 123 |  |  | 11 |  |  | 134 |  |
| 2022 | 108 |  |  | 4 |  |  | 112 |  |
| 2023 | 58 |  |  | — |  |  | 58 |  |
| Thereafter | 258 |  |  | — |  |  | 258 |  |
| Total lease payments | 712 |  |  | 33 |  |  | 745 |  |
| Less: Interest | 95 |  |  | 2 |  |  | 97 |  |
| Present value of lease liabilities | $ | 617 |  |  | $ | 31 |  |  | $ | 648 |  |

[0000068505-19-000025:notes:48]
[same as prior period, unchanged from 0000068505-19-000019:notes:48]

[0000068505-19-000025:notes:49]
[same as prior period, unchanged from 0000068505-19-000019:notes:49]

[0000068505-19-000025:notes:50]
[same as prior period, unchanged from 0000068505-19-000019:notes:50]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-19-000025:notes:51]
[same as prior period, unchanged from 0000068505-19-000019:notes:51]

[0000068505-19-000025:notes:52]
[same as prior period, unchanged from 0000068505-19-000019:notes:52]

[0000068505-19-000025:notes:53]
[same as prior period, unchanged from 0000068505-19-000019:notes:53]

[0000068505-19-000025:notes:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 52 |  |  | $ | 46 |  |  | $ | 154 |  |  | $ | 140 |  |
| Reorganization of business (Note 14) | 15 |  |  | 21 |  |  | 27 |  |  | 46 |  |
| Environmental reserve expense | — |  |  | 57 |  |  | — |  |  | 57 |  |
| Loss (gain) on legal settlements | (5 | ) |  | 2 |  |  | (5 | ) |  | 3 |  |
| Acquisition-related transaction fees | 1 |  |  | — |  |  | 4 |  |  | 17 |  |
|  | $ | 63 |  |  | $ | 126 |  |  | $ | 180 |  |  | $ | 263 |  |

[0000068505-19-000025:notes:55]
During the nine months ended September 28, 2019, the Company recognized $4 million of acquisition-related transaction fees compared to $17 million for the Avigilon and Plant acquisitions during the nine months ended September 29, 2018.

[0000068505-19-000025:notes:56]
During the third quarter of 2018, the Company revised the estimate of a liability related to a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. During the third quarter of 2018, the Company became aware of additional remediation requirements for the Superfund site. As such, the Company recorded a charge of $57 million during the third quarter of 2018 which was primarily due to: (i) changes in the expected timeline of the remediation activities to 30 years and (ii) additional costs for further remediation efforts, increasing the reserve to $107 million. Given the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounted the cash flows used in estimating this accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is $4 million and is included in the “Accrued liabilities” statement line and the non-current portion is included in the “Other liabilities” statement line within the Company's Condensed Consolidated Balance Sheet.

[0000068505-19-000025:notes:57]
[same as prior period, unchanged from 0000068505-19-000019:notes:56]

[0000068505-19-000025:notes:58]
Interest expense, net, and Other, net, both included in Other income (expense), consist of the following:

[0000068505-19-000025:notes:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (60 | ) |  | $ | (62 | ) |  | $ | (178 | ) |  | $ | (178 | ) |
| Interest income | 6 |  |  | 3 |  |  | 13 |  |  | 15 |  |
|  | $ | (54 | ) |  | $ | (59 | ) |  | $ | (165 | ) |  | $ | (163 | ) |
| Other,net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 17 |  |  | $ | 18 |  |  | $ | 50 |  |  | $ | 58 |  |
| Gain from the extinguishment of 2.00% senior convertible notes (Note 5) | 4 |  |  | 6 |  |  | 4 |  |  | 6 |  |
| Loss from the extinguishment of long-term debt (Note 5) | (7 | ) |  | — |  |  | (50 | ) |  | — |  |
| Investment impairments (Note 4) | (5 | ) |  | — |  |  | (16 | ) |  | — |  |
| Foreign currency gain (loss) | 3 |  |  | (14 | ) |  | (7 | ) |  | (14 | ) |
| Gain (loss) on derivative instruments | (9 | ) |  | 8 |  |  | (16 | ) |  | (15 | ) |
| Gains on equity method investments | 2 |  |  | 1 |  |  | 3 |  |  | 2 |  |
| Fair value adjustments to equity investments (Note 4) | (18 | ) |  | 7 |  |  | (3 | ) |  | 7 |  |
| Other | 2 |  |  | 3 |  |  | 13 |  |  | 1 |  |
|  | $ | (11 | ) |  | $ | 29 |  |  | $ | (22 | ) |  | $ | 45 |  |

[0000068505-19-000025:notes:60]
During the three months ended September 28, 2019, the Company recognized a foreign currency gain of $3 million, primarily driven by the Euro, the British Pound, and the Norwegian Kroner, and a loss of $9 million on derivative instruments put in place to manage foreign exchange risk related to currency fluctuations. During the nine months ended September 28, 2019, the Company recognized a foreign currency loss of $7 million, primarily related to the Israeli Shekel, Brazilian real, the Australian dollar, and the Canadian dollar, and a loss of $16 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-19-000025:notes:61]
During the three and nine months ended September 29, 2018, the Company recognized a foreign currency loss of $14 million, primarily driven by the Brazilian real, the Euro, the Australian dollar and the Argentinian peso. During the three and nine months ended September 29, 2018, the Company recognized a gain of $8 million and a loss of $15 million, respectively, on derivative instruments put in place to manage foreign exchange risk related to currency fluctuations. The loss on derivative instruments during the nine months ended September 29, 2018, includes a loss of $14 million on foreign currency derivatives put in place to minimize the exposure to the Canadian dollar related to the acquisition of Avigilon.

[0000068505-19-000025:notes:62]
[same as prior period, unchanged from 0000068505-19-000019:notes:61]

[0000068505-19-000025:notes:63]
[same as prior period, unchanged from 0000068505-19-000019:notes:62]

[0000068505-19-000025:notes:64]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 267 |  |  | $ | 247 |  |  | $ | 625 |  |  | $ | 544 |  |
| Weighted average common shares outstanding | 166.7 |  |  | 162.6 |  |  | 165.3 |  |  | 162.0 |  |
| Per share amount | $ | 1.60 |  |  | $ | 1.52 |  |  | $ | 3.78 |  |  | $ | 3.36 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 267 |  |  | $ | 247 |  |  | $ | 625 |  |  | $ | 544 |  |
| Weighted average common shares outstanding | 166.7 |  |  | 162.6 |  |  | 165.3 |  |  | 162.0 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 4.8 |  |  | 4.6 |  |  | 4.7 |  |  | 4.2 |  |
| 2.00% senior convertible notes | 4.9 |  |  | 5.4 |  |  | 5.7 |  |  | 5.4 |  |
| 1.75% senior convertible notes | — |  |  | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 176.4 |  |  | 172.6 |  |  | 175.7 |  |  | 171.6 |  |
| Per share amount | $ | 1.51 |  |  | $ | 1.43 |  |  | $ | 3.56 |  |  | $ | 3.17 |  |

[0000068505-19-000025:notes:65]
In the computation of diluted earnings per common share for the three months ended September 28, 2019, the assumed exercise of 19,584 employee stock options were excluded because their inclusion would have been antidilutive. In the computation of the diluted earnings per common share for the nine months ended September 28, 2019, the assumed exercise of 0.3 million employee stock options were excluded because their inclusion would have been antidilutive.

[0000068505-19-000025:notes:66]
For the three months ended September 29, 2018, the assumed exercise of 0.2 million employee stock options, were excluded because their inclusion would have been antidilutive. For the nine months ended September 29, 2018, the assumed exercise of 3.2 million options, were excluded because their inclusion would have been antidilutive.

[0000068505-19-000025:notes:67]
On September 5, 2019, the Company issued $1.0 billion of 1.75% senior convertible notes which mature in September 15, 2024 ("New Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). See discussion in Note 5.

[0000068505-19-000025:notes:68]
In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the New Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the New Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $203.50. For the period ended September 28, 2019, there was no dilutive effect of the New Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price.

[0000068505-19-000025:notes:69]
[same as prior period, unchanged from 0000068505-19-000019:notes:67]

[0000068505-19-000025:notes:70]
[same as prior period, unchanged from 0000068505-19-000019:notes:68]

[0000068505-19-000025:notes:71]
[same as prior period, unchanged from 0000068505-19-000019:notes:69]

[0000068505-19-000025:notes:72]
|  | September 28, 2019 |  | December 31, 2018 |
| Accounts receivable | $ | 1,345 |  |  | $ | 1,344 |  |
| Less allowance for doubtful accounts | (50 | ) |  | (51 | ) |
|  | $ | 1,295 |  |  | $ | 1,293 |  |

[0000068505-19-000025:notes:73]
[same as prior period, unchanged from 0000068505-19-000019:notes:71]

[0000068505-19-000025:notes:74]
[same as prior period, unchanged from 0000068505-19-000019:notes:72]

[0000068505-19-000025:notes:75]
|  | September 28, 2019 |  | December 31, 2018 |
| Finished goods | $ | 221 |  |  | $ | 206 |  |
| Work-in-process and production materials | 380 |  |  | 293 |  |
|  | 601 |  |  | 499 |  |
| Less inventory reserves | (141 | ) |  | (143 | ) |
|  | $ | 460 |  |  | $ | 356 |  |

[0000068505-19-000025:notes:76]
[same as prior period, unchanged from 0000068505-19-000019:notes:74]

[0000068505-19-000025:notes:77]
[same as prior period, unchanged from 0000068505-19-000019:notes:75]

[0000068505-19-000025:notes:78]
|  | September 28, 2019 |  | December 31, 2018 |
| Current contract cost assets (Note 2) | $ | 28 |  |  | $ | 30 |  |
| Tax-related deposits | 111 |  |  | 138 |  |
| Other | 199 |  |  | 186 |  |
|  | $ | 338 |  |  | $ | 354 |  |

[0000068505-19-000025:notes:79]
[same as prior period, unchanged from 0000068505-19-000019:notes:77]

[0000068505-19-000025:notes:80]
[same as prior period, unchanged from 0000068505-19-000019:notes:78]

[0000068505-19-000025:notes:81]
|  | September 28, 2019 |  | December 31, 2018 |
| Land | $ | 15 |  |  | $ | 10 |  |
| Leasehold improvements | 404 |  |  | 362 |  |
| Machinery and equipment | 1,961 |  |  | 1,886 |  |
|  | 2,380 |  |  | 2,258 |  |
| Less accumulated depreciation | (1,417 | ) |  | (1,363 | ) |
|  | $ | 963 |  |  | $ | 895 |  |

[0000068505-19-000025:notes:82]
Depreciation expense for the three months ended September 28, 2019 and September 29, 2018 was $47 million and $43 million, respectively. Depreciation expense for the nine months ended September 28, 2019 and September 29, 2018 was $136 million and $127 million, respectively.

[0000068505-19-000025:notes:83]
[same as prior period, unchanged from 0000068505-19-000019:notes:81]

[0000068505-19-000025:notes:84]
[same as prior period, unchanged from 0000068505-19-000019:notes:82]

[0000068505-19-000025:notes:85]
|  | September 28, 2019 |  | December 31, 2018 |
| Corporate bonds | $ | — |  |  | $ | 1 |  |
| Common stock | 22 |  |  | 19 |  |
| Strategic investments, at cost | 40 |  |  | 62 |  |
| Company-owned life insurance policies | 78 |  |  | 75 |  |
| Equity method investments | 19 |  |  | 12 |  |
|  | $ | 159 |  |  | $ | 169 |  |

[0000068505-19-000025:notes:86]
Strategic investments include investments in non-public technology startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities. The Company did not recognize any significant adjustments to the recorded cost basis during the nine months ended September 28, 2019, with the exception of one company becoming publicly-traded during the second quarter, which required the investment to be reclassified to common stock.

[0000068505-19-000025:notes:87]
The Company’s common stock portfolio reflects investments in publicly-traded companies within the communications services sector and is valued utilizing active market prices for similar instruments. During the three and nine months ended

[0000068505-19-000025:notes:88]
September 28, 2019, the Company recognized losses of $18 million and $3 million, respectively, in Other income (expense) related to a decrease in the fair value of the investments.

[0000068505-19-000025:notes:89]
During the three months ended September 28, 2019, the Company recognized no gains or losses on the sale of investments and businesses, compared to gains of $6 million, during the three months ended September 29, 2018.

[0000068505-19-000025:notes:90]
During the nine months ended September 28, 2019, Gains on the sale of investments and businesses, net were $4 million, compared to $16 million, during the nine months ended September 29, 2018.

[0000068505-19-000025:notes:91]
During the three and nine months ended September 28, 2019, the Company recorded investment impairment charges of $5 million and $16 million, respectively, representing other-than-temporary declines in the value of the Company’s strategic investments portfolio. There were no investment impairments recorded during the three and nine months ended September 29, 2018. Investment impairment charges are included in Other within Other income (expense) in the Company’s Condensed Consolidated Statements of Operations.

[0000068505-19-000025:notes:92]
[same as prior period, unchanged from 0000068505-19-000019:notes:90]

[0000068505-19-000025:notes:93]
[same as prior period, unchanged from 0000068505-19-000019:notes:91]

[0000068505-19-000025:notes:94]
|  | September 28, 2019 |  | December 31, 2018 |
| Defined benefit plan assets | $ | 175 |  |  | $ | 135 |  |
| Tax receivable | — |  |  | 39 |  |
| Non-current contract cost assets (Note 2) | 102 |  |  | 98 |  |
| Other | 56 |  |  | 72 |  |
|  | $ | 333 |  |  | $ | 344 |  |

[0000068505-19-000025:notes:95]
[same as prior period, unchanged from 0000068505-19-000019:notes:93]

[0000068505-19-000025:notes:96]
[same as prior period, unchanged from 0000068505-19-000019:notes:94]

[0000068505-19-000025:notes:97]
|  | September 28, 2019 |  | December 31, 2018 |
| Compensation | $ | 313 |  |  | $ | 324 |  |
| Tax liabilities | 86 |  |  | 111 |  |
| Dividend payable | 98 |  |  | 93 |  |
| Trade liabilities | 156 |  |  | 185 |  |
| Operating lease liabilities (Note 3) | 118 |  |  | — |  |
| Other | 488 |  |  | 497 |  |
|  | $ | 1,259 |  |  | $ | 1,210 |  |

[0000068505-19-000025:notes:98]
[same as prior period, unchanged from 0000068505-19-000019:notes:96]

[0000068505-19-000025:notes:99]
[same as prior period, unchanged from 0000068505-19-000019:notes:97]

[0000068505-19-000025:notes:100]
|  | September 28, 2019 |  | December 31, 2018 |
| Defined benefit plans | $ | 1,480 |  |  | $ | 1,557 |  |
| Non-current contract liabilities (Note 2) | 253 |  |  | 214 |  |
| Unrecognized tax benefits | 52 |  |  | 51 |  |
| Deferred income taxes | 172 |  |  | 201 |  |
| Other | 233 |  |  | 277 |  |
|  | $ | 2,190 |  |  | $ | 2,300 |  |

[0000068505-19-000025:notes:101]
[same as prior period, unchanged from 0000068505-19-000019:notes:99]

[0000068505-19-000025:notes:102]
Share Repurchase Program: During the nine months ended September 28, 2019, the Company paid an aggregate of $170 million, including transaction costs, to repurchase approximately 1.4 million shares at an average price of $122.31 per share. As of September 28, 2019, the Company had used approximately $12.6 billion of the share repurchase authority to repurchase shares, leaving $1.4 billion of authority available for future repurchases.

[0000068505-19-000025:notes:103]
Payment of Dividends: During the three months ended September 28, 2019 and September 29, 2018, the Company paid $94 million and $84 million, respectively, in cash dividends to holders of its common stock. During the nine months ended September 28, 2019 and September 29, 2018, the Company paid $281 million and $252 million, respectively, in cash dividends to holders of its common stock.

[0000068505-19-000025:notes:104]
[same as prior period, unchanged from 0000068505-19-000019:notes:102]

[0000068505-19-000025:notes:105]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and nine months ended September 28, 2019 and September 29, 2018:

[0000068505-19-000025:notes:106]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (437 | ) |  | $ | (391 | ) |  | $ | (444 | ) |  | $ | (353 | ) |
| Other comprehensive loss before reclassification adjustment | (33 | ) |  | (3 | ) |  | (23 | ) |  | (33 | ) |
| Tax expense | — |  |  | (1 | ) |  | (3 | ) |  | (9 | ) |
| Other comprehensive loss, net of tax | (33 | ) |  | (4 | ) |  | (26 | ) |  | (42 | ) |
| Balance at end of period | $ | (470 | ) |  | $ | (395 | ) |  | $ | (470 | ) |  | $ | (395 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net | — |  |  | — |  |  | — |  |  | (8 | ) |
| Tax benefit | — |  |  | — |  |  | — |  |  | 2 |  |
| Other comprehensive loss, net of tax | — |  |  | — |  |  | — |  |  | (6 | ) |
| Balance at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,300 | ) |  | $ | (2,189 | ) |  | $ | (2,321 | ) |  | $ | (2,215 | ) |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 16 |  |  | 20 |  |  | 50 |  |  | 57 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (4 | ) |  | (4 | ) |  | (11 | ) |  | (11 | ) |
| Tax expense | (1 | ) |  | (3 | ) |  | (7 | ) |  | (7 | ) |
| Other comprehensive income, net of tax | 11 |  |  | 13 |  |  | 32 |  |  | 39 |  |
| Balance at end of period | $ | (2,289 | ) |  | $ | (2,176 | ) |  | $ | (2,289 | ) |  | $ | (2,176 | ) |
| Total Accumulated other comprehensive loss | $ | (2,759 | ) |  | $ | (2,571 | ) |  | $ | (2,759 | ) |  | $ | (2,571 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000068505-19-000025:notes:107]
Debt and Credit Facilities

[0000068505-19-000025:notes:108]
|  | September 28, 2019 |  | December 31, 2018 |
| Term Loan due 2021 | $ | — |  |  | $ | 399 |  |
| 3.5% senior notes due 2021 | — |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 1.75% senior convertible notes due 2024 | 987 |  |  | — |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 804 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 638 |  |  | 862 |  |
|  | 5,732 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3 | ) |  | (4 | ) |
| Less: current portion | (617 | ) |  | (31 | ) |
| Long-term debt | $ | 5,112 |  |  | $ | 5,289 |  |

[0000068505-19-000025:notes:109]
As of September 28, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 28, 2019. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of December 31, 2018 and September 28, 2019.

[0000068505-19-000025:notes:110]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rates for amounts outstanding during the three and nine months ended September 28, 2019 were 3.53% and 3.68%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed. During the three months ended September 28, 2019, the Company repaid all amounts borrowed under the Term Loan.

[0000068505-19-000025:notes:111]
In May of 2019, the Company issued $650 million of 4.60% senior notes due 2029, receiving proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to repurchase $614 million in principal amount of its outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $43 million related to this repurchase in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-19-000025:notes:112]
In August of 2019, the Company issued a follow-on $150 million to the outstanding 4.60% senior notes due 2029, bringing the total outstanding principal to $800 million. The Company recognized net proceeds of $159 million after debt premiums and debt issuance costs. These proceeds were then used to repurchase the remaining $150 million principal amount outstanding of the 3.5% senior notes due 2021 for a purchase price of $155 million, excluding approximately $2 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $7 million related to this repurchase in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-19-000025:notes:113]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% senior convertible notes ("Senior Convertible Notes") which were scheduled to mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes were convertible based on a conversion rate adjusted for dividends declared which automatically adjusts the exercise price. During the third quarter of 2018, the Company settled $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium.

[0000068505-19-000025:notes:114]
During the third quarter of 2019, the remaining notes were convertible based on a conversion rate of 14.9186, adjusted for dividends declared, per $1,000 principal amount (equal to a conversion price of $67.03 per share). On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to settle the remaining $800 million in principal amount of the Senior Convertible Notes in two installments: (i) $200 million of principal notes were repurchased during the third quarter for an aggregate consideration of $526 million in cash, inclusive of the conversion premium and (ii) $600 million of principal paid in cash on October 7, 2019, subsequent to the quarter, with 5.5 million shares converted into common stock on September 5, 2019.  As of September 28, 2019, the Company reflected the principal amount of $600 million paid subsequent to the quarter as short term debt and recognized a gain of $4 million from the extinguishment of the 2.00% senior convertible notes in Other, net within Other income (expense) in the Condensed Consolidated Statement of Operations.

[0000068505-19-000025:notes:115]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("New Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
During the third quarter of 2019, the Company established an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 28, 2019 the Company had no outstanding debt under the commercial paper program. Subsequent to the end of the quarter, the Company issued $265 million commercial paper under the program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-19-000025:notes:116]
[same as prior period, unchanged from 0000068505-19-000019:notes:113]

[0000068505-19-000025:notes:117]
As of September 28, 2019, the Company had outstanding foreign exchange contracts with notional amounts totaling $1.1 billion, compared to $819 million outstanding at December 31, 2018. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-19-000025:notes:118]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of September 28, 2019, and the corresponding positions as of December 31, 2018:

[0000068505-19-000025:notes:119]
|  | Notional Amount |
| Net Buy (Sell) by Currency | September 28, 2019 |  | December 31, 2018 |
| Euro | $ | 138 |  |  | $ | 89 |  |
| British pound | 73 |  |  | 139 |  |
| Australian dollar | (122 | ) |  | (105 | ) |
| Chinese renminbi | (67 | ) |  | (55 | ) |
| Brazilian Real | (43 | ) |  | (41 | ) |

[0000068505-19-000025:notes:120]
[same as prior period, unchanged from 0000068505-19-000019:notes:117]

[0000068505-19-000025:notes:121]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of September 28, 2019, all of the counterparties have investment grade credit ratings. As of September 28, 2019, the Company had $17 million of exposure to aggregate credit risk with all counterparties.

[0000068505-19-000025:notes:122]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of September 28, 2019 and December 31, 2018:

[0000068505-19-000025:notes:123]
|  | Fair Values of Derivative Instruments |
| September 28, 2019 | Other Current Assets | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 16 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | $ | 1 |  |
| Total derivatives | $ | 17 |  |  | $ | 1 |  |

[0000068505-19-000025:notes:124]
[same as prior period, unchanged from 0000068505-19-000019:notes:121]

[0000068505-19-000025:notes:125]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and nine months ended September 28, 2019 and September 29, 2018:

[0000068505-19-000025:notes:126]
|  | Three Months Ended |  | Nine Months Ended |  | Financial Statement Location |
| Foreign Exchange Contracts | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |  |
| Effective portion | $ | 8 |  |  | $ | (1 | ) |  | $ | 16 |  |  | $ | — |  |  | Accumulated othercomprehensive income |
| Forward points recognized | 2 |  |  | — |  |  | 5 |  |  | — |  |  | Other income |
| Undesignated derivatives recognized | (9 | ) |  | 8 |  |  | (16 | ) |  | (15 | ) |  | Other expense |

[0000068505-19-000025:notes:127]
[same as prior period, unchanged from 0000068505-19-000019:notes:124]

[0000068505-19-000025:notes:128]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. The Company has elected to exclude the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. As of September 28, 2019, the Company had €95 million of net investment hedges in certain Euro functional subsidiaries and £100 million of net investment hedges in certain British pound functional subsidiaries. During the three and nine months ended September 28, 2019, the Company amortized $2 million and $5 million, respectively, of income from the excluded components through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-19-000025:notes:129]
[same as prior period, unchanged from 0000068505-19-000019:notes:126]

[0000068505-19-000025:notes:130]
[same as prior period, unchanged from 0000068505-19-000019:notes:127]

[0000068505-19-000025:notes:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Net earnings before income taxes | $ | 348 |  |  | $ | 270 |  |  | $ | 808 |  |  | $ | 637 |  |
| Income tax expense | 80 |  |  | 22 |  |  | 180 |  |  | 91 |  |
| Effective tax rate | 23 | % |  | 8 | % |  | 22 | % |  | 14 | % |

[0000068505-19-000025:notes:132]
During the three and nine months ended September 28, 2019, the Company recorded $80 million and $180 million of net tax expense, resulting in effective tax rates of 23% and 22%, respectively. During the three and nine months ended September 29, 2018, the Company recorded $22 million and $91 million of net tax expense, resulting in effective tax rates of 8% and 14%, respectively. The three and nine months ended September 28, 2019 effective tax rates include state tax expense, offset by excess tax benefits on share-based compensation. The effective tax rates for the three and nine months ended September 28, 2019 of 23% and 22%, respectively, are higher than the effective tax rates for the three and nine months ended September 29, 2018 of 8% and 14%, respectively, primarily due to a favorable settlement of a state audit and favorable U.S. return-to-provision adjustments related to significant tax legislation, both of which were recorded in 2018.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-19-000025:notes:133]
[same as prior period, unchanged from 0000068505-19-000019:notes:130]

[0000068505-19-000025:notes:134]
[same as prior period, unchanged from 0000068505-19-000019:notes:131]

[0000068505-19-000025:notes:135]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 50 |  |  | 47 |  |  | 9 |  |  | 9 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (69 | ) |  | (68 | ) |  | (20 | ) |  | (22 | ) |  | (2 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 11 |  |  | 15 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Net periodic pension benefits | $ | (8 | ) |  | $ | (6 | ) |  | $ | (7 | ) |  | $ | (8 | ) |  | $ | (4 | ) |  | $ | (5 | ) |

[0000068505-19-000025:notes:136]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 152 |  |  | 139 |  |  | 29 |  |  | 30 |  |  | 2 |  |  | 2 |  |
| Expected return on plan assets | (207 | ) |  | (203 | ) |  | (62 | ) |  | (70 | ) |  | (7 | ) |  | (8 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 35 |  |  | 43 |  |  | 12 |  |  | 11 |  |  | 3 |  |  | 3 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (11 | ) |  | (11 | ) |
| Net periodic pension benefits | $ | (20 | ) |  | $ | (21 | ) |  | $ | (19 | ) |  | $ | (27 | ) |  | $ | (13 | ) |  | $ | (14 | ) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-19-000025:notes:137]
[same as prior period, unchanged from 0000068505-19-000019:notes:134]

[0000068505-19-000025:notes:138]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 3 |  |  | $ | 3 |  |  | $ | 11 |  |  | $ | 8 |  |
| Selling, general and administrative expenses | 16 |  |  | 12 |  |  | 46 |  |  | 33 |  |
| Research and development expenditures | 11 |  |  | 4 |  |  | 30 |  |  | 12 |  |
| Share-based compensation expense included in Operating earnings | 30 |  |  | 19 |  |  | 87 |  |  | 53 |  |
| Tax benefit | (5 | ) |  | (5 | ) |  | (16 | ) |  | (13 | ) |
| Share-based compensation expense, net of tax | $ | 25 |  |  | $ | 14 |  |  | $ | 71 |  |  | $ | 40 |  |
| Decrease in basic earnings per share | $ | (0.15 | ) |  | $ | (0.09 | ) |  | $ | (0.43 | ) |  | $ | (0.25 | ) |
| Decrease in diluted earnings per share | $ | (0.14 | ) |  | $ | (0.08 | ) |  | $ | (0.40 | ) |  | $ | (0.23 | ) |

[0000068505-19-000025:notes:139]
During the nine months ended September 28, 2019, the Company granted:

[0000068505-19-000025:notes:140]
| • | 0.5 million restricted stock units ("RSUs") and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $68 million and $7 million, respectively, and 0.2 million stock options and 0.2 million performance options ("POs") with an aggregate grant-date fair value of $7 million and $7 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years. |

[0000068505-19-000025:notes:141]
| • | 0.4 million of restricted stock in connection with the acquisition of VaaS, for an aggregate grant-date fair value of $38 million related to compensation withheld from the purchase price that will be expensed over an average service period of one year. |

[0000068505-19-000025:notes:142]
| • | 0.1 million of restricted stock and 14,071 restricted stock units in connection with the acquisition of WatchGuard for an aggregate grant date fair value of $13.8 million and $2.3 million, respectively, that will be expensed over an average service period of two years. |

[0000068505-19-000025:notes:143]
•
$5.5 million of aggregate grant date fair value performance stock units ("PSUs"), during the second quarter of 2019 as a portion of Long Range Incentive Plan ("LRIP") issued to certain Company executive officers. The 2019 PSUs have a three-year performance period and were granted at a target number of units subject to adjustment based on company performance. The number of PSU's will be based on the actual total shareholder return ("TSR") compared to the S&P 500 over the three-year performance period.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-19-000025:notes:144]
[same as prior period, unchanged from 0000068505-19-000019:notes:143]

[0000068505-19-000025:notes:145]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-19-000025:notes:146]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-19-000025:notes:147]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-19-000025:notes:148]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of September 28, 2019 and December 31, 2018 were as follows:

[0000068505-19-000025:notes:149]
| September 28, 2019 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 17 |  |  | $ | 17 |  |
| Common stock | 22 |  |  | — |  |  | 22 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |

[0000068505-19-000025:notes:150]
[same as prior period, unchanged from 0000068505-19-000019:notes:149]

[0000068505-19-000025:notes:151]
The Company had no Level 3 holdings as of September 28, 2019 or December 31, 2018.

[0000068505-19-000025:notes:152]
At September 28, 2019 and December 31, 2018, the Company had $534 million and $734 million, respectively, of investments in money market prime and government funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-19-000025:notes:153]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at September 28, 2019 and December 31, 2018 was $6.0 billion and $5.4 billion (Level 2), respectively.

[0000068505-19-000025:notes:154]
[same as prior period, unchanged from 0000068505-19-000019:notes:153]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-19-000025:notes:155]
Sales of Receivables
Sales of Receivables

[0000068505-19-000025:notes:156]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended September 28, 2019 and September 29, 2018:

[0000068505-19-000025:notes:157]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Accounts receivable sales proceeds | $ | 4 |  |  | $ | — |  |  | $ | 31 |  |  | $ | 76 |  |
| Long-term receivables sales proceeds | 56 |  |  | 73 |  |  | 132 |  |  | 101 |  |
| Total proceeds from receivable sales | $ | 60 |  |  | $ | 73 |  |  | $ | 163 |  |  | $ | 177 |  |

[0000068505-19-000025:notes:158]
At September 28, 2019, the Company had retained servicing obligations for $969 million of long-term receivables, compared to $970 million at December 31, 2018. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $98 million at September 28, 2019, compared to $62 million at December 31, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-19-000025:notes:159]
Commitments and Contingencies
Legal Matters

[0000068505-19-000025:notes:160]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-19-000025:notes:161]
Other Indemnifications

[0000068505-19-000025:notes:162]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-19-000025:notes:163]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-19-000025:notes:164]
[same as prior period, unchanged from 0000068505-19-000019:notes:166]

[0000068505-19-000025:notes:165]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Products and Systems Integration | $ | 1,349 |  |  | $ | 1,288 |  |  | $ | 3,656 |  |  | $ | 3,429 |  |
| Services and Software | 645 |  |  | 574 |  |  | 1,855 |  |  | 1,660 |  |
|  | $ | 1,994 |  |  | $ | 1,862 |  |  | $ | 5,511 |  |  | $ | 5,089 |  |

[0000068505-19-000025:notes:166]
[same as prior period, unchanged from 0000068505-19-000019:notes:168]

[0000068505-19-000025:notes:167]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Products and Systems Integration | $ | 258 |  |  | $ | 183 |  |  | $ | 568 |  |  | $ | 449 |  |
| Services and Software | 155 |  |  | 111 |  |  | 423 |  |  | 290 |  |
| Operating earnings | 413 |  |  | 294 |  |  | 991 |  |  | 739 |  |
| Total other expense | (65 | ) |  | (24 | ) |  | (183 | ) |  | (102 | ) |
| Earnings before income taxes | $ | 348 |  |  | $ | 270 |  |  | $ | 808 |  |  | $ | 637 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-19-000025:notes:168]
[same as prior period, unchanged from 0000068505-19-000019:notes:170]

[0000068505-19-000025:notes:169]
During the three months ended September 28, 2019, the Company recorded net reorganization of business charges of $18 million including $15 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $18 million were charges of $19 million related to employee separation, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-19-000025:notes:170]
During the nine months ended September 28, 2019, the Company recorded net reorganization of business charges of $37 million including $27 million of charges in Other charges and $10 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $37 million were charges of $48 million related to employee separation, partially offset by $11 million of reversals for accruals no longer needed.

[0000068505-19-000025:notes:171]
[same as prior period, unchanged from 0000068505-19-000019:notes:174]

[0000068505-19-000025:notes:172]
| September 28, 2019 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 14 |  |  | $ | 29 |  |
| Services and Software | 4 |  |  | 8 |  |
|  | $ | 18 |  |  | $ | 37 |  |

[0000068505-19-000025:notes:173]
The following table displays a rollforward of the reorganization of business accruals established for employee separation costs from January 1, 2019 to September 28, 2019:

[0000068505-19-000025:notes:174]
|  | January 1, 2019 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | September 28, 2019 |
| Employee separation costs | $ | 84 |  |  | $ | 48 |  |  | $ | (11 | ) |  | $ | (44 | ) |  | $ | 77 |  |

[0000068505-19-000025:notes:175]
[same as prior period, unchanged from 0000068505-19-000019:notes:178]

[0000068505-19-000025:notes:176]
At January 1, 2019, the Company had an accrual of $84 million for employee separation costs. The 2019 additional charges of $48 million represent severance costs for approximately 600 employees. The adjustment of $11 million reflects reversals for accruals no longer needed. The $44 million used reflects cash payments to severed employees. The remaining accrual of $77 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at September 28, 2019, is expected to be paid, primarily within one year, to approximately 900 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-19-000025:notes:177]
[same as prior period, unchanged from 0000068505-19-000019:notes:180]

[0000068505-19-000025:notes:178]
[same as prior period, unchanged from 0000068505-19-000019:notes:181]

[0000068505-19-000025:notes:179]
During the three months ended September 29, 2018, the Company recorded net reorganization of business charges of $25 million including $21 million of charges in Other charges and $4 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $25 million were charges of $13 million related to employee separation costs and $12 million related to exit costs.

[0000068505-19-000025:notes:180]
During the nine months ended September 29, 2018, the Company recorded net reorganization of business charges of $62 million including $46 million of charges in Other charges and $16 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $62 million were charges of $61 million related to employee separation costs and $16 million related to exit costs, partially offset by $15 million of reversals for accruals no longer needed.

[0000068505-19-000025:notes:181]
| September 29, 2018 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 19 |  |  | $ | 47 |  |
| Services and Software | 6 |  |  | 15 |  |
|  | $ | 25 |  |  | $ | 62 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-19-000025:notes:182]
[same as prior period, unchanged from 0000068505-19-000019:notes:185]

[0000068505-19-000025:notes:183]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million, net of cash acquired. The acquisition expands the Company's video security solutions platform. The business will be part of both the Products and Systems Integration and Services and Software segments.   The Company recognized $157 million of goodwill, $63 million of identifiable intangible assets, and $30 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $33 million of customer relationships and $30 million of completed technology that will be amortized over a period of thirteen years and seven years, respectively. The purchase accounting is not yet complete and as such the final allocation between goodwill and net assets may be subject to change based on the finalization of working capital considerations.

[0000068505-19-000025:notes:184]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Services and Software segments. The Company recognized $68 million of goodwill, $64 million of identifiable intangible assets, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $43 million of completed technology and $21 million of customer relationship intangibles and will be amortized over a period of 15 years. The purchase accounting has been completed as of the third quarter of 2019.

[0000068505-19-000025:notes:185]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million to be utilized in the purchase price allocation. The business will be part of both the Products and Systems Integration and Services and Software segments. The Company recognized $261 million of goodwill, $141 million of identifiable intangible assets, and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $99 million of completed technology that will be amortized over a period of ten years and $42 million of customer relationship intangibles that will be amortized over a period of 15 years. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts and goodwill may be subject to change.

[0000068505-19-000025:notes:186]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation, a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions. The purchase price of $974 million, consisted of cash payments of $980 million for outstanding common stock, restricted stock units and employee held stock options, net of cash acquired of $107 million, debt assumed of $75 million and transaction costs of $26 million. Prior to the end of the first quarter of 2018, $35 million of the assumed debt was repaid with the remaining $40 million repaid during the second quarter of 2018. The Company recognized $498 million of identifiable intangible assets, $434 million of goodwill, and $42 million of net assets. Acquired intangible assets consist of $110 million of customer relationships, $380 million of developed technology and $8 million of trade names and will have useful lives of two to twenty years. The fair values of all intangible assets were estimated using the income approach. Customer relationships and developed technology were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them. Goodwill was calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. The goodwill is not deductible for tax purposes.

[0000068505-19-000025:notes:187]
[same as prior period, unchanged from 0000068505-19-000019:notes:190]

[0000068505-19-000025:notes:188]
[same as prior period, unchanged from 0000068505-19-000019:notes:191]

[0000068505-19-000025:notes:189]
Any sales from devices from these acquisitions are included within the Products and Systems Integration segment whereas sales from services and software offerings from these acquisitions are included in the Services and Software segment.

[0000068505-19-000025:notes:190]
[same as prior period, unchanged from 0000068505-19-000019:notes:193]

[0000068505-19-000025:notes:191]
[same as prior period, unchanged from 0000068505-19-000019:notes:194]

[0000068505-19-000025:notes:192]
|  | September 28, 2019 |  | December 31, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 730 |  |  | $ | 133 |  |  | $ | 558 |  |  | $ | 92 |  |
| Customer-related | 1,159 |  |  | 459 |  |  | 1,085 |  |  | 364 |  |
| Other intangibles | 75 |  |  | 41 |  |  | 76 |  |  | 33 |  |
|  | $ | 1,964 |  |  | $ | 633 |  |  | $ | 1,719 |  |  | $ | 489 |  |

[0000068505-19-000025:notes:193]
Amortization expense on intangible assets was $52 million for the three months ended September 28, 2019 and $154 million for the nine months ended September 28, 2019. Amortization expense on intangible assets was $46 million for the three months ended September 29, 2018 and $140 million for the nine months ended September 29, 2018. As of September 28, 2019, annual amortization expense is estimated to be $206 million in 2019, $203 million 2020, $201 million in 2021, $198 million in 2022, $104 million in 2023, and $80 million in 2024.

[0000068505-19-000025:notes:194]
[same as prior period, unchanged from 0000068505-19-000019:notes:198]

[0000068505-19-000025:notes:195]
|  | September 28, 2019 |  | December 31, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 652 |  |  | $ | 70 |  |  | $ | 510 |  |  | $ | 38 |  |
| Services and Software | 1,312 |  |  | 563 |  |  | 1,209 |  |  | 451 |  |
|  | $ | 1,964 |  |  | $ | 633 |  |  | $ | 1,719 |  |  | $ | 489 |  |

[0000068505-19-000025:notes:196]
[same as prior period, unchanged from 0000068505-19-000019:notes:200]

[0000068505-19-000025:notes:197]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2019 to September 28, 2019:

[0000068505-19-000025:notes:198]
|  | Products and Systems Integration |  | Services and Software |  | Total |
| Balance as of January 1, 2019 | $ | 722 |  |  | $ | 792 |  |  | $ | 1,514 |  |
| Goodwill acquired | 251 |  |  | 236 |  |  | 487 |  |
| Purchase accounting adjustments | — |  |  | 9 |  |  | 9 |  |
| Foreign currency | — |  |  | (4 | ) |  | (4 | ) |
| Balance as of September 28, 2019 | $ | 973 |  |  | $ | 1,033 |  |  | $ | 2,006 |  |
