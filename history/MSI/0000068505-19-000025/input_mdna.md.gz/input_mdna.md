# MSI MD&A — 0000068505-19-000025


## mdna

[0000068505-19-000025:mdna:1]
[same as prior period, unchanged from 0000068505-19-000019:mdna:1]

[0000068505-19-000025:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and nine months ended September 28, 2019 and September 29, 2018, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2018.

[0000068505-19-000025:mdna:3]
[same as prior period, unchanged from 0000068505-19-000019:mdna:3]

[0000068505-19-000025:mdna:4]
Third Quarter Financial Results

[0000068505-19-000025:mdna:5]
| • | Net sales were $2.0 billion in the third quarter of 2019 compared to $1.9 billion in the third quarter of 2018, an increase of 7%. |

[0000068505-19-000025:mdna:6]
| • | Operating earnings were $413 million in the third quarter of 2019 compared to $294 million in the third quarter of 2018. |

[0000068505-19-000025:mdna:7]
| • | Earnings attributable to Motorola Solutions, Inc. were $267 million, or $1.51 per diluted common share, in the third quarter of 2019, compared to $247 million, or $1.43 per diluted common share, in the third quarter of 2018. |

[0000068505-19-000025:mdna:8]
| • | Our operating cash flow increased $765 million to $1.0 billion in the first nine months of 2019 compared to the first nine months of 2018. |

[0000068505-19-000025:mdna:9]
| • | We repurchased $170 million of common stock and paid $281 million in dividends in the first nine months of 2019. |

[0000068505-19-000025:mdna:10]
[same as prior period, unchanged from 0000068505-19-000019:mdna:4]

[0000068505-19-000025:mdna:11]
On September 5, 2019, we extended our strategic partnership with Silver Lake with new $1.0 billion 1.75% senior convertible notes.  In exchange, we settled the outstanding $800 million 2.00% senior convertible notes with the issuance of 5.5 million shares and $1.1 billion in cash, of which, $600 million was paid subsequent to quarter end.

[0000068505-19-000025:mdna:12]
[same as prior period, unchanged from 0000068505-19-000019:mdna:5]

[0000068505-19-000025:mdna:13]
[same as prior period, unchanged from 0000068505-19-000019:mdna:6]

[0000068505-19-000025:mdna:14]
[same as prior period, unchanged from 0000068505-19-000019:mdna:7]

[0000068505-19-000025:mdna:15]
[same as prior period, unchanged from 0000068505-19-000019:mdna:8]

[0000068505-19-000025:mdna:16]
[same as prior period, unchanged from 0000068505-19-000019:mdna:9]

[0000068505-19-000025:mdna:17]
[same as prior period, unchanged from 0000068505-19-000019:mdna:10]

[0000068505-19-000025:mdna:18]
[same as prior period, unchanged from 0000068505-19-000019:mdna:23]

[0000068505-19-000025:mdna:19]
A summary of our segment results for the third quarter of 2019 is as follows:

[0000068505-19-000025:mdna:20]
| • | In the Products and Systems Integration segment, net sales were $1.3 billion in the third quarter of 2019, an increase of $61 million, or 5%, compared to $1.3 billion in the third quarter of 2018. On a geographic basis, net sales increased in the Americas, partially offset by a decline in sales in the other regions, compared to the year-ago quarter. Operating earnings were $258 million in the third quarter of 2019, compared to $183 million in the third quarter of 2018. Operating margin increased in 2019 to 19.1% from 14.2% in 2018 driven by higher sales and gross margin, and lower operating expenses primarily due to a $40 million environmental reserve expense that was recorded in the third quarter of 2018, partially offset by expenses related to acquisitions. |

[0000068505-19-000025:mdna:21]
| • | In the Services and Software segment, net sales were $645 million in the third quarter of 2019, an increase of $71 million, or 12%, compared to net sales of $574 million in the third quarter of 2018. On a geographic basis, net sales increased in the Americas and EMEA, partially offset by a decline in sales in AP, compared to the year-ago quarter. Operating earnings were |

[0000068505-19-000025:mdna:22]
[same as prior period, unchanged from 0000068505-19-000019:mdna:27]

[0000068505-19-000025:mdna:23]
$155 million in the third quarter of 2019, compared to $111 million in the third quarter of 2018. Operating margin increased in 2019 to 24.0% from 19.3% in 2018 driven by higher sales, gross margin, and a $17 million environmental reserve expense that was recorded in the third quarter of 2018, partially offset by higher operating expenses related to acquisitions.

[0000068505-19-000025:mdna:24]
[same as prior period, unchanged from 0000068505-19-000019:mdna:31]

[0000068505-19-000025:mdna:25]
[same as prior period, unchanged from 0000068505-19-000019:mdna:28]

[0000068505-19-000025:mdna:26]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | September 28, 2019 |  | % ofSales* |  | September 29, 2018 |  | % ofSales* |  | September 28, 2019 |  | % ofSales* |  | September 29, 2018 |  | % ofSales* |
| Net sales from products | $ | 1,196 |  |  |  |  | $ | 1,151 |  |  |  |  | $ | 3,260 |  |  |  |  | $ | 2,993 |  |  |  |
| Net sales from services | 798 |  |  |  |  | 711 |  |  |  |  | 2,251 |  |  |  |  | 2,096 |  |  |  |
| Net sales | 1,994 |  |  |  |  | 1,862 |  |  |  |  | 5,511 |  |  |  |  | 5,089 |  |  |  |
| Costs of products sales | 501 |  |  | 41.9 | % |  | 516 |  |  | 44.8 | % |  | 1,435 |  |  | 44.0 | % |  | 1,383 |  |  | 46.2 | % |
| Costs of services sales | 486 |  |  | 60.9 | % |  | 445 |  |  | 62.6 | % |  | 1,365 |  |  | 60.6 | % |  | 1,314 |  |  | 62.7 | % |
| Costs of sales | 987 |  |  |  |  | 961 |  |  |  |  | 2,800 |  |  |  |  | 2,697 |  |  |  |
| Gross margin | 1,007 |  |  | 50.5 | % |  | 901 |  |  | 48.4 | % |  | 2,711 |  |  | 49.2 | % |  | 2,392 |  |  | 47.0 | % |
| Selling, general and administrative expenses | 359 |  |  | 18.0 | % |  | 323 |  |  | 17.3 | % |  | 1,035 |  |  | 18.8 | % |  | 918 |  |  | 18.0 | % |
| Research and development expenditures | 172 |  |  | 8.6 | % |  | 158 |  |  | 8.5 | % |  | 505 |  |  | 9.2 | % |  | 472 |  |  | 9.3 | % |
| Other charges | 63 |  |  | 3.2 | % |  | 126 |  |  | 6.8 | % |  | 180 |  |  | 3.3 | % |  | 263 |  |  | 5.2 | % |
| Operating earnings | 413 |  |  | 20.7 | % |  | 294 |  |  | 15.8 | % |  | 991 |  |  | 18.0 | % |  | 739 |  |  | 14.5 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (54 | ) |  | (2.7 | )% |  | (59 | ) |  | (3.2 | )% |  | (165 | ) |  | (3.0 | )% |  | (163 | ) |  | (3.2 | )% |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | 6 |  |  | 0.3 | % |  | 4 |  |  | 0.1 | % |  | 16 |  |  | 0.3 | % |
| Other, net | (11 | ) |  | (0.6 | )% |  | 29 |  |  | 1.6 | % |  | (22 | ) |  | (0.4 | )% |  | 45 |  |  | 0.9 | % |
| Total other expense | (65 | ) |  | (3.3 | )% |  | (24 | ) |  | (1.3 | )% |  | (183 | ) |  | (3.3 | )% |  | (102 | ) |  | (2.0 | )% |
| Net earnings before income taxes | 348 |  |  | 17.5 | % |  | 270 |  |  | 14.5 | % |  | 808 |  |  | 14.7 | % |  | 637 |  |  | 12.5 | % |
| Income tax expense | 80 |  |  | 4.0 | % |  | 22 |  |  | 1.2 | % |  | 180 |  |  | 3.3 | % |  | 91 |  |  | 1.8 | % |
| Net earnings | 268 |  |  | 13.4 | % |  | 248 |  |  | 13.3 | % |  | 628 |  |  | 11.4 | % |  | 546 |  |  | 10.7 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 3 |  |  | 0.1 | % |  | 2 |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 267 |  |  | 13.4 | % |  | $ | 247 |  |  | 13.3 | % |  | $ | 625 |  |  | 11.3 | % |  | $ | 544 |  |  | 10.7 | % |
| Earnings per diluted common share | $ | 1.51 |  |  |  |  |  | $ | 1.43 |  |  |  |  |  | $ | 3.56 |  |  |  |  | $ | 3.17 |  |  |  |

[0000068505-19-000025:mdna:27]
[same as prior period, unchanged from 0000068505-19-000019:mdna:30]

[0000068505-19-000025:mdna:28]
31

[0000068505-19-000025:mdna:29]
Results of Operations—Three months ended September 28, 2019 compared to three months ended September 29, 2018

[0000068505-19-000025:mdna:30]
The results of operations for the third quarter of 2019 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-19-000025:mdna:31]
[same as prior period, unchanged from 0000068505-19-000019:mdna:34]

[0000068505-19-000025:mdna:32]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Net sales from Products and Systems Integration | $ | 1,349 |  |  | $ | 1,288 |  |  | 5 | % |
| Net sales from Services and Software | 645 |  |  | 574 |  |  | 12 | % |
| Net sales | $ | 1,994 |  |  | $ | 1,862 |  |  | 7 | % |

[0000068505-19-000025:mdna:33]
The Products and Systems Integration segment’s net sales represented 68% of our consolidated net sales in the third quarter of 2019 and 69% in the third quarter of 2018. The Services and Software segment’s net sales represented 32% of our consolidated net sales in the third quarter of 2019 and 31% in the third quarter of 2018.

[0000068505-19-000025:mdna:34]
Net sales were up $132 million, or 7%, compared to the third quarter of 2018. The increase in net sales was driven by the Americas, partially offset by a sales decline in EMEA and AP, with a 5% increase in the Products and Systems Integration segment and a 12% increase in the Services and Software segment. Net sales includes:

[0000068505-19-000025:mdna:35]
| • | growth in Devices primarily due to strong demand in the Americas, inclusive of acquisitions; |

[0000068505-19-000025:mdna:36]
| • | $58 million of revenue from the acquisitions of VaaS, WatchGuard, and Avtec; and |

[0000068505-19-000025:mdna:37]
| • | partially offset by $21 million from unfavorable currency rates. |

[0000068505-19-000025:mdna:38]
[same as prior period, unchanged from 0000068505-19-000019:mdna:41]

[0000068505-19-000025:mdna:39]
| • | growth in the Americas region of 12% driven by growth in both segments, inclusive of revenue from acquisitions; |

[0000068505-19-000025:mdna:40]
| • | a decline in the AP region of 9% driven primarily by China and currency headwinds; and |

[0000068505-19-000025:mdna:41]
| • | a decline in the EMEA region of 1% primarily due to large system deployments in the Middle East in the third quarter of 2018 and currency headwinds, partially offset by growth within Europe. |

[0000068505-19-000025:mdna:42]
[same as prior period, unchanged from 0000068505-19-000019:mdna:45]

[0000068505-19-000025:mdna:43]
The 5% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-19-000025:mdna:44]
| • | $27 million of revenue from the acquisitions of WatchGuard, VaaS and Avtec; |

[0000068505-19-000025:mdna:45]
| • | 8% growth in Devices revenue primarily due to strong demand for land mobile radio ("LMR") and video devices in the Americas, inclusive of revenue from acquisitions; and |

[0000068505-19-000025:mdna:46]
| • | partially offset by a 1% decline in Systems and Systems Integration revenue in the third quarter of 2019, as compared to the third quarter of 2018 primarily due to large system deployments in the Middle East in the third quarter of 2018. |

[0000068505-19-000025:mdna:47]
[same as prior period, unchanged from 0000068505-19-000019:mdna:50]

[0000068505-19-000025:mdna:48]
The 12% increase in the Services and Software segment was driven by the following:

[0000068505-19-000025:mdna:49]
| • | $31 million of revenue from the acquisitions of VaaS, WatchGuard, and Avtec; |

[0000068505-19-000025:mdna:50]
| • | 39% growth in Software, driven primarily by growth in our video security solutions portfolio and command center software sales, inclusive of acquisitions; and |

[0000068505-19-000025:mdna:51]
| • | 5% growth in Services, driven by growth in software and hardware maintenance revenue as well as managed services revenue, inclusive of acquisitions, and partially offset by currency headwinds. |

[0000068505-19-000025:mdna:52]
[same as prior period, unchanged from 0000068505-19-000019:mdna:55]

[0000068505-19-000025:mdna:53]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Gross margin | $ | 1,007 |  |  | $ | 901 |  |  | 12 | % |

[0000068505-19-000025:mdna:54]
Gross margin was 50.5% of net sales in the third quarter of 2019 compared to 48.4% in the third quarter of 2018. The primary drivers of the increase are as follows:

[0000068505-19-000025:mdna:55]
| • | higher margins in Products and Systems Integration driven by a favorable mix of Devices to Systems and Systems Integration, as well as higher margin contribution from acquisitions; and |

[0000068505-19-000025:mdna:56]
| • | higher margins within Services and Software primarily driven by higher margin contribution within our Software portfolio, inclusive of acquisitions. |

[0000068505-19-000025:mdna:57]
[same as prior period, unchanged from 0000068505-19-000019:mdna:60]

[0000068505-19-000025:mdna:58]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Selling, general and administrative expenses | $ | 359 |  |  | $ | 323 |  |  | 11 | % |

[0000068505-19-000025:mdna:59]
SG&A expenses increased 11% compared to the third quarter of 2018. SG&A expenses were 18.0% of net sales compared to 17.3% of net sales in the third quarter of 2018. The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-19-000025:mdna:60]
[same as prior period, unchanged from 0000068505-19-000019:mdna:63]

[0000068505-19-000025:mdna:61]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Research and development expenditures | $ | 172 |  |  | $ | 158 |  |  | 9 | % |

[0000068505-19-000025:mdna:62]
R&D expenditures increased 9% primarily due to increased expenses associated with acquired businesses. R&D expenditures were 8.6% of net sales compared to 8.5% of net sales in the third quarter of 2018.

[0000068505-19-000025:mdna:63]
[same as prior period, unchanged from 0000068505-19-000019:mdna:66]

[0000068505-19-000025:mdna:64]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Other charges | $ | 63 |  |  | $ | 126 |  |

[0000068505-19-000025:mdna:65]
The reduction of Other charges in the third quarter of 2019 as compared to the third quarter of 2018 is primarily due to a $57 million environmental reserve expense that was recorded in the third quarter of 2018 and $15 million of net reorganization of business charges in the third quarter of 2019 as compared to $21 million in the third quarter of 2018 (see further detail in “Reorganization of Businesses” section).

[0000068505-19-000025:mdna:66]
[same as prior period, unchanged from 0000068505-19-000019:mdna:69]

[0000068505-19-000025:mdna:67]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Operating earnings from Products and Systems Integration | $ | 258 |  |  | $ | 183 |  |
| Operating earnings from Services and Software | 155 |  |  | 111 |  |
| Operating earnings | $ | 413 |  |  | $ | 294 |  |

[0000068505-19-000025:mdna:68]
Operating earnings were up $119 million, or 40%, compared to the third quarter of 2018. The increase in Operating earnings was due to:

[0000068505-19-000025:mdna:69]
| • | Products and Systems Integration, which was up $75 million from the third quarter of 2018 compared to the third quarter of 2019, driven by higher sales and gross margin and lower operating expenses primarily due to a $40 million environmental reserve expense that was recorded in the third quarter of 2018, partially offset by expenses related to acquisitions; and |

[0000068505-19-000025:mdna:70]
| • | Services and Software, which was up $44 million from the third quarter of 2018 compared to the third quarter of 2019, primarily driven by higher sales, gross margin, and a $17 million environmental reserve expense that was recorded in the third quarter of 2018, partially offset by higher operating expenses related to acquisitions. |

[0000068505-19-000025:mdna:71]
[same as prior period, unchanged from 0000068505-19-000019:mdna:74]

[0000068505-19-000025:mdna:72]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Interest expense, net | $ | (54 | ) |  | $ | (59 | ) |

[0000068505-19-000025:mdna:73]
The decrease in net interest expense in the third quarter of 2019 compared to the third quarter of 2018 was a result of less average debt outstanding as of and for the period ending September 28, 2019 and higher cash balances generating more interest income as compared to the period ending September 29, 2018.

[0000068505-19-000025:mdna:74]
[same as prior period, unchanged from 0000068505-19-000019:mdna:77]

[0000068505-19-000025:mdna:75]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Gains on sales of investments and businesses, net | $ | — |  |  | $ | 6 |  |

[0000068505-19-000025:mdna:76]
The net gain of $6 million in the third quarter of 2018 was primarily related to the sale of one strategic investment.

[0000068505-19-000025:mdna:77]
[same as prior period, unchanged from 0000068505-19-000019:mdna:80]

[0000068505-19-000025:mdna:78]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Other, net | $ | (11 | ) |  | $ | 29 |  |

[0000068505-19-000025:mdna:79]
The change in net Other expense in the third quarter of 2019 as compared to the net Other income in the third quarter of 2018 was driven by:

[0000068505-19-000025:mdna:80]
| • | $18 million of unfavorable fair value adjustments to equity investments in the third quarter of 2019 as compared to $7 million of favorable fair value adjustments to equity investments in the third quarter of 2018; |

[0000068505-19-000025:mdna:81]
| • | a $9 million loss on derivative instruments in the third quarter of 2019 as compared to an $8 million gain in the third quarter of 2018; |

[0000068505-19-000025:mdna:82]
| • | a $7 million loss from the extinguishment of long-term debt in the third quarter of 2019; |

[0000068505-19-000025:mdna:83]
| • | $5 million of investment impairments in the third quarter of 2019; and |

[0000068505-19-000025:mdna:84]
| • | a $4 million gain from the extinguishment of 2.00% senior convertible notes in the third quarter of 2019 as compared to a $6 million gain in the third quarter of 2018; |

[0000068505-19-000025:mdna:85]
| • | partially offset by $3 million of foreign currency gains in the third quarter of 2019 as compared to $14 million of losses in the third quarter of 2018. |

[0000068505-19-000025:mdna:86]
[same as prior period, unchanged from 0000068505-19-000019:mdna:89]

[0000068505-19-000025:mdna:87]
|  | Three Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Income tax expense | $ | 80 |  |  | $ | 22 |  |

[0000068505-19-000025:mdna:88]
Income tax expense increased by $58 million compared to the third quarter of 2018, for an effective tax rate of 23%. Our effective tax rate for the three months ended September 28, 2019 of 23% is higher than the effective tax rate for the three months ended September 29, 2018 of 8%, primarily due to favorable US return-to-provision adjustments related to significant tax legislation recorded in 2018.

[0000068505-19-000025:mdna:89]
Results of Operations—Nine months ended September 28, 2019 compared to nine months ended September 29, 2018

[0000068505-19-000025:mdna:90]
[same as prior period, unchanged from 0000068505-19-000019:mdna:93]

[0000068505-19-000025:mdna:91]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Net sales from Products and Systems Integration | $ | 3,656 |  |  | $ | 3,429 |  |  | 7 | % |
| Net sales from Services and Software | 1,855 |  |  | 1,660 |  |  | 12 | % |
| Net sales | $ | 5,511 |  |  | $ | 5,089 |  |  | 8 | % |

[0000068505-19-000025:mdna:92]
The Products and Systems Integration segment’s net sales represented 66% of our consolidated net sales in the first nine months of 2019 and 67% in the first nine months of 2018. The Services and Software segment’s net sales represented 34% of our consolidated net sales in the first nine months of 2019 and 33% in the first nine months of 2018.

[0000068505-19-000025:mdna:93]
Net sales were up $422 million, or 8%, compared to the first nine months of 2018. The increase in net sales was driven by the Americas, partially offset by a sales decline in AP, with a 7% increase in the Products and Systems Integration segment and a 12% increase in the Services and Software segment. Net sales includes:

[0000068505-19-000025:mdna:94]
| • | $227 million of revenue from the acquisitions of VaaS, WatchGuard, and Avtec which closed during the first nine months of 2019 and Avigilon and Plant which were acquired towards the end of the first quarter of 2018; |

[0000068505-19-000025:mdna:95]
[same as prior period, unchanged from 0000068505-19-000019:mdna:98]

[0000068505-19-000025:mdna:96]
| • | partially offset by $96 million from unfavorable currency rates. |

[0000068505-19-000025:mdna:97]
[same as prior period, unchanged from 0000068505-19-000019:mdna:100]

[0000068505-19-000025:mdna:98]
| • | growth in the Americas region of 13% across both segments, inclusive of acquisitions; |

[0000068505-19-000025:mdna:99]
| • | a decline in the AP region of 7% driven primarily by China and currency headwinds; and |

[0000068505-19-000025:mdna:100]
| • | a decline in the EMEA region of 1% primarily due to currency headwinds and large system deployments in the Middle East completed in 2018, currency headwinds and partially offset by growth within Europe. |

[0000068505-19-000025:mdna:101]
[same as prior period, unchanged from 0000068505-19-000019:mdna:104]

[0000068505-19-000025:mdna:102]
The 7% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-19-000025:mdna:103]
| • | $120 million of revenue from acquisitions; |

[0000068505-19-000025:mdna:104]
| • | 9% growth in Devices revenue primarily due to strong demand for LMR and video devices across all regions, inclusive of acquisitions; and |

[0000068505-19-000025:mdna:105]
| • | partially offset by large system deployments in the Middle East completed in 2018. |

[0000068505-19-000025:mdna:106]
[same as prior period, unchanged from 0000068505-19-000019:mdna:109]

[0000068505-19-000025:mdna:107]
The 12% increase in the Services and Software segment was driven by the following:

[0000068505-19-000025:mdna:108]
| • | $107 million of revenue from acquisitions; |

[0000068505-19-000025:mdna:109]
| • | 50% growth in Software, driven primarily by revenue from our video security solutions portfolio and growth in our command center software sales, inclusive of acquisitions; and |

[0000068505-19-000025:mdna:110]
| • | 3% growth in Services, driven by growth in software and hardware maintenance revenue as well as managed services revenue, inclusive of acquisitions, partially offset by unfavorable currency headwinds. |

[0000068505-19-000025:mdna:111]
[same as prior period, unchanged from 0000068505-19-000019:mdna:114]

[0000068505-19-000025:mdna:112]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Gross margin | $ | 2,711 |  |  | $ | 2,392 |  |  | 13 | % |

[0000068505-19-000025:mdna:113]
Gross margin was 49.2% of net sales in the first nine months of 2019 compared to 47.0% in the first nine months of 2018. The primary drivers of the increase are as follows:

[0000068505-19-000025:mdna:114]
| • | higher margins in Products and Systems Integration driven by a favorable mix of Devices to Systems and Systems Integration, as well as higher margin contribution from acquisitions; and |

[0000068505-19-000025:mdna:115]
| • | higher margins within Services and Software primarily driven by higher margin contribution within our Software portfolio from acquisitions and operational efficiencies in service delivery costs of our Services portfolio. |

[0000068505-19-000025:mdna:116]
[same as prior period, unchanged from 0000068505-19-000019:mdna:119]

[0000068505-19-000025:mdna:117]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Selling, general and administrative expenses | $ | 1,035 |  |  | $ | 918 |  |  | 13 | % |

[0000068505-19-000025:mdna:118]
SG&A expenses increased 13% compared to the first nine months of 2018. SG&A expenses were 18.8% of net sales compared to 18.0% of net sales in the first nine months quarter of 2018. The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-19-000025:mdna:119]
[same as prior period, unchanged from 0000068505-19-000019:mdna:122]

[0000068505-19-000025:mdna:120]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Research and development expenditures | $ | 505 |  |  | $ | 472 |  |  | 7 | % |

[0000068505-19-000025:mdna:121]
R&D expenditures increased 7% primarily due to increased expenses associated with acquired businesses. R&D expenditures were 9.2% of net sales compared to 9.3% of net sales in the first nine months of 2018.

[0000068505-19-000025:mdna:122]
[same as prior period, unchanged from 0000068505-19-000019:mdna:125]

[0000068505-19-000025:mdna:123]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Other charges | $ | 180 |  |  | $ | 263 |  |

[0000068505-19-000025:mdna:124]
The reduction of Other charges in the first nine months of 2019 as compared to the first nine months of 2018 can be summarized as follows:

[0000068505-19-000025:mdna:125]
| • | a $57 million environmental reserve expense in the first nine months of 2018; |

[0000068505-19-000025:mdna:126]
| • | $4 million of charges for acquisition-related transaction fees in the first nine months of 2019 as compared to $17 million in the first nine months of 2018; |

[0000068505-19-000025:mdna:127]
| • | $27 million of net reorganization of business charges in the first nine months of 2019 as compared to $46 million in the first nine months of 2018 (see further detail in “Reorganization of Businesses” section); and |

[0000068505-19-000025:mdna:128]
| • | partially offset by $154 million of amortization of intangibles in the first nine months of 2019 compared to $140 million in the first nine months of 2018. |

[0000068505-19-000025:mdna:129]
[same as prior period, unchanged from 0000068505-19-000019:mdna:131]

[0000068505-19-000025:mdna:130]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Operating earnings from Products and Systems Integration | $ | 568 |  |  | $ | 449 |  |
| Operating earnings from Services and Software | 423 |  |  | 290 |  |
| Operating earnings | $ | 991 |  |  | $ | 739 |  |

[0000068505-19-000025:mdna:131]
Operating earnings were up $252 million, or 34%, compared to the first nine months of 2018. The increase in Operating earnings was due to:

[0000068505-19-000025:mdna:132]
| • | Services and Software, which was up $133 million from the first nine months of 2018 compared to the first nine months of 2019, driven by higher sales and gross margin, and a $17 million environmental reserve expense that was recorded in the third quarter of 2018, partially offset by higher operating expenses related to acquisitions; and |

[0000068505-19-000025:mdna:133]
| • | Products and Systems Integration, which was up $119 million from the first nine months of 2018 compared to the first nine months of 2019, driven by higher sales and gross margin and a $40 million environmental reserve expense that was recorded in the third quarter of 2018, partially offset by higher operating expenses related to acquisitions. |

[0000068505-19-000025:mdna:134]
[same as prior period, unchanged from 0000068505-19-000019:mdna:136]

[0000068505-19-000025:mdna:135]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Interest expense, net | $ | (165 | ) |  | $ | (163 | ) |

[0000068505-19-000025:mdna:136]
The increase in net interest expense in the first nine months of 2019 compared to the first nine months of 2018 was a result of more average debt outstanding as of and for the period ending September 28, 2019 as compared to the period ending September 29, 2018.

[0000068505-19-000025:mdna:137]
[same as prior period, unchanged from 0000068505-19-000019:mdna:139]

[0000068505-19-000025:mdna:138]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Gains on sales of investments and businesses, net | $ | 4 |  |  | $ | 16 |  |

[0000068505-19-000025:mdna:139]
Net gains on sales of investments and businesses were $4 million in the first nine months of 2019 compared to $16 million during the first nine months of 2018. The net gains in the first nine months of 2019 were related to the sale of our two-way communications rental business and various equity method investments. The net gains in the first nine months of 2018 were primarily related to the sale of two investments.

[0000068505-19-000025:mdna:140]
[same as prior period, unchanged from 0000068505-19-000019:mdna:142]

[0000068505-19-000025:mdna:141]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Other, net | $ | (22 | ) |  | $ | 45 |  |

[0000068505-19-000025:mdna:142]
The change in net Other expense in the first nine months of 2019 as compared to the net Other income in the first nine months of 2018 was primarily driven by:

[0000068505-19-000025:mdna:143]
| • | a $50 million loss from the extinguishment of long-term debt in the first nine months of 2019; |

[0000068505-19-000025:mdna:144]
| • | $16 million of investment impairments in the first nine months of 2019; |

[0000068505-19-000025:mdna:145]
| • | $3 million of unfavorable fair value adjustments to equity investments in the first nine months of 2019 as compared to $7 million of favorable fair value adjustments in the first nine months of 2018; |

[0000068505-19-000025:mdna:146]
| • | $50 million of net periodic pension and postretirement benefit in the first nine months of 2019 as compared to $58 million in the first nine months of 2018; |

[0000068505-19-000025:mdna:147]
| • | a $4 million gain from the extinguishment of 2.00% senior convertible notes in the first nine months of 2019 as compared to a $6 million gain in the first nine months of 2018; |

[0000068505-19-000025:mdna:148]
| • | a $16 million loss on derivative instruments in the first nine months of 2019 as compared to $15 million in the first nine months of 2018; |

[0000068505-19-000025:mdna:149]
| • | partially offset by $13 million of other non-operating income in the first nine months of 2019 as compared to expense of $1 million in the first nine months of 2018; and |

[0000068505-19-000025:mdna:150]
| • | foreign currency losses of $7 million in the first nine months of 2019 as compared to $14 million in the first nine months of 2018. |

[0000068505-19-000025:mdna:151]
[same as prior period, unchanged from 0000068505-19-000019:mdna:152]

[0000068505-19-000025:mdna:152]
|  | Nine Months Ended |
| (In millions) | September 28, 2019 |  | September 29, 2018 |
| Income tax expense | $ | 180 |  |  | $ | 91 |  |

[0000068505-19-000025:mdna:153]
Income tax expense increased by $89 million compared to the first nine months of 2018, for an effective tax rate of 22%. Our effective tax rate for the nine months ended September 28, 2019 of 22% is higher than the effective tax rate for the nine months ended September 29, 2018 of 14%, primarily due to a primarily due to a favorable settlement of a state audit and favorable U.S. return-to-provision adjustments related to significant tax legislation, both of which were recorded in 2018.

[0000068505-19-000025:mdna:154]
[same as prior period, unchanged from 0000068505-19-000019:mdna:164]

[0000068505-19-000025:mdna:155]
[same as prior period, unchanged from 0000068505-19-000019:mdna:155]

[0000068505-19-000025:mdna:156]
During the third quarter of 2019, we recorded net reorganization of business charges of $18 million including $15 million of charges recorded within Other charges and $3 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $18 million were charges of $19 million related to employee separation costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-19-000025:mdna:157]
During the first nine months of 2019, we recorded net reorganization of business charges of $37 million including $27 million of charges in Other charges and $10 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $37 million were charges of $48 million related to employee separation, partially offset by $11 million of reversals for accruals no longer needed.

[0000068505-19-000025:mdna:158]
During the third quarter of 2018, we recorded net reorganization of business charges of $25 million including $21 million of charges in Other charges and $4 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $25 million were charges of $13 million related to employee separation costs and $12 million related to exit costs.

[0000068505-19-000025:mdna:159]
During the first nine months of 2018, we recorded net reorganization of business charges of $62 million including $46 million of charges recorded within Other charges and $16 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $62 million were charges of $61 million related to employee separation costs and $16 million related to exit costs, partially offset by $15 million of reversals for accruals no longer needed.

[0000068505-19-000025:mdna:160]
[same as prior period, unchanged from 0000068505-19-000019:mdna:160]

[0000068505-19-000025:mdna:161]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Products and Systems Integration | $ | 14 |  |  | $ | 19 |  |  | $ | 29 |  |  | $ | 47 |  |
| Services and Software | 4 |  |  | 6 |  |  | 8 |  |  | 15 |  |
|  | $ | 18 |  |  | $ | 25 |  |  | $ | 37 |  |  | $ | 62 |  |

[0000068505-19-000025:mdna:162]
Cash payments for employee severance in connection with the reorganization of business plans were $44 million in the first nine months of 2019 and employee severance costs were $48 million in the first nine months of 2018. The reorganization of business accrual at September 28, 2019 was $77 million, of which relate to employee separation costs that are expected to be paid within one year.

[0000068505-19-000025:mdna:163]
[same as prior period, unchanged from 0000068505-19-000019:mdna:163]

[0000068505-19-000025:mdna:164]
[same as prior period, unchanged from 0000068505-19-000019:mdna:165]

[0000068505-19-000025:mdna:165]
|  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 1,028 |  |  | $ | 263 |  |
| Investing activities | (802 | ) |  | (1,196 | ) |
| Financing activities | (329 | ) |  | 534 |  |
| Effect of exchange rates on cash and cash equivalents | (14 | ) |  | (18 | ) |
| Decrease in cash and cash equivalents | $ | (117 | ) |  | $ | (417 | ) |

[0000068505-19-000025:mdna:166]
[same as prior period, unchanged from 0000068505-19-000019:mdna:167]

[0000068505-19-000025:mdna:167]
At September 28, 2019, $744 million of the $1.1 billion cash and cash equivalents balance was held in the U.S. and $396 million was held in other countries, with $74 million held in the United Kingdom.

[0000068505-19-000025:mdna:168]
[same as prior period, unchanged from 0000068505-19-000019:mdna:169]

[0000068505-19-000025:mdna:169]
The increase in operating cash flows from the first nine months of 2018 to the first nine months of 2019 was driven by:

[0000068505-19-000025:mdna:170]
| • | a $500 million debt-funded voluntary contribution to our U.S. pension plan in the first nine months of 2018; |

[0000068505-19-000025:mdna:171]
| • | higher earnings and working capital contribution in the first nine months of 2019; and |

[0000068505-19-000025:mdna:172]
| • | a $51 million payment out of restricted cash related to a settlement arising from a legacy business in 2018; |

[0000068505-19-000025:mdna:173]
| • | partially offset by $32 million of higher tax payments in the first nine months of 2019; and |

[0000068505-19-000025:mdna:174]
| • | $12 million of higher interest payments in the first nine months of 2019 driven by additional debt issued towards the end of first quarter of 2018. |

[0000068505-19-000025:mdna:175]
[same as prior period, unchanged from 0000068505-19-000019:mdna:175]

[0000068505-19-000025:mdna:176]
The decrease in net cash used by investing activities from the first nine months of 2018 to the first nine months of 2019 was primarily due to:

[0000068505-19-000025:mdna:177]
| • | a $535 million decrease in acquisitions and investments, primarily driven by cash used for the purchases of VaaS, Avtec and WatchGuard for $617 million, as compared to the first nine months of 2018 when we made acquisitions of Avigilon, and Plant Holdings for $1.1 billion; and |

[0000068505-19-000025:mdna:178]
| • | partially offset by $80 million of lower proceeds from sales of investments and businesses, primarily driven by $60 million of excess cash withdrawn from company-sponsored life insurance investments in the first nine months of 2018; and |

[0000068505-19-000025:mdna:179]
| • | a $61 million increase in capital expenditures in the first nine months of 2019 as compared to the first nine months of 2018, primarily due to the network builds including Airwave and ESN, as well as expenditures for Avigilon, supply chain and information technology. |

[0000068505-19-000025:mdna:180]
[same as prior period, unchanged from 0000068505-19-000019:mdna:180]

[0000068505-19-000025:mdna:181]
The increase in cash used for financing activities in the first nine months of 2019 as compared to the cash provided by financing activities in the first nine months of 2018 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" below):

[0000068505-19-000025:mdna:182]
| • | a $1.0 billion increase in the repayment of debt; |

[0000068505-19-000025:mdna:183]
| • | a $157 million increase in the settlement of the conversion premium on the 2.00% senior convertible notes; |

[0000068505-19-000025:mdna:184]
| • | a $104 million increase in share repurchases; and |

[0000068505-19-000025:mdna:185]
| • | a $29 million increase in payments of dividends in the first nine months of 2019 as compared to the first nine months of 2018; |

[0000068505-19-000025:mdna:186]
| • | partially offset by a $509 million increase in debt issuance. |

[0000068505-19-000025:mdna:187]
[same as prior period, unchanged from 0000068505-19-000019:mdna:187]

[0000068505-19-000025:mdna:188]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended September 28, 2019 and September 29, 2018:

[0000068505-19-000025:mdna:189]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Accounts receivable sales proceeds | $ | 4 |  |  | $ | — |  |  | $ | 31 |  |  | $ | 76 |  |
| Long-term receivables sales proceeds | 56 |  |  | 73 |  |  | 132 |  |  | 101 |  |
| Total proceeds from sales of accounts receivable | $ | 60 |  |  | $ | 73 |  |  | $ | 163 |  |  | $ | 177 |  |

[0000068505-19-000025:mdna:190]
[same as prior period, unchanged from 0000068505-19-000019:mdna:190]

[0000068505-19-000025:mdna:191]
[same as prior period, unchanged from 0000068505-19-000019:mdna:191]

[0000068505-19-000025:mdna:192]
We had outstanding long-term debt of $5.7 billion and $5.3 billion, including the current portions of $617 million and $31 million at September 28, 2019 and December 31, 2018, respectively.

[0000068505-19-000025:mdna:193]
In February of 2018, we issued $500 million of 4.60% Senior notes due 2028. After debt issuance costs and debt discounts, we recognized net proceeds of $497 million. These proceeds were then used to make a $500 million contribution to our U.S. pension plan in the first quarter of 2018. During the second half of 2018, we issued an additional $200 million on the outstanding 4.6% senior notes bringing the total outstanding principal to $700 million. We recognized net proceeds of $196 million after debt issuance costs and debt discounts, which was then used to pay the $200 million principal due to Silver Lake Partners on October 15, 2018.

[0000068505-19-000025:mdna:194]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, we entered into a term loan for $400 million with a maturity date of March 26, 2021 (the "Term Loan"). The interest on the Term Loan was variable, indexed to the London Inter-bank Offered Rate ("LIBOR"), and paid monthly. The weighted average borrowing rate for amounts outstanding during the three and nine months ended September 28, 2019 was 3.53% and 3.68%, respectively. During the three months ended September 28, 2019, we repaid all amounts borrowed under the Term Loan.

[0000068505-19-000025:mdna:195]
In May of 2019, we issued $650 million of 4.60% Senior notes due 2029. We received proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to repurchase $614 million in principal amount of our

[0000068505-19-000025:mdna:196]
outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, we recognized a loss of approximately $43 million related to this repurchase in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-19-000025:mdna:197]
In August of 2019, we issued a follow-on $150 million to the outstanding 4.60% senior notes due 2029 bringing the outstanding total to $800 million. We recognized net proceeds of $159 million after debt premiums and debt issuance costs. These proceeds were then used to repurchase the remaining $150 million principal amount of the 3.5% senior notes due 2021 for a purchase price of $155 million, excluding approximately $2 million of accrued interest. After accelerating the amortization of debt issuance costs, we recognized a loss of approximately $7 million related to this repurchase in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-19-000025:mdna:198]
In 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% senior convertible notes which mature in September 2020 ("Senior Convertible Notes"). The notes became fully convertible as of August 25, 2017. The notes were convertible based on a conversion rate that may be adjusted for dividends declared and automatically adjusts the exercise price. During the third quarter of 2018, we repurchased $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium.

[0000068505-19-000025:mdna:199]
As of the third quarter of 2019, the remaining notes were convertible based on a conversion rate of rate of 14.9186, adjusted for dividends declared, per $1,000 principal amount (equal to a conversion price of $67.03 per share). On September 5, 2019, we entered into an agreement with Silver Lake Partners to settle the remaining $800 million in principal amount of the Senior Convertible Notes in two installments: (ii) $200 million of notes were repurchased during the third quarter for an aggregate consideration of $526 million in cash, inclusive of the conversion premium and (ii) $600 million of principal in cash paid on October 7, 2019, and 5.5 million shares converted into common stock.  As of September 28, 2019, we reflected the principal amount of $600 million paid subsequent to the quarter as short term debt and recognized a gain of $4 million from the extinguishment of the 2.00% senior convertible notes in Other, net within other income (expense) in the Condensed Consolidated Statement of Operations.

[0000068505-19-000025:mdna:200]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("New Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, we intend to settle the principal amount of the New Senior Convertible Notes in cash. We recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, we calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital.

[0000068505-19-000025:mdna:201]
During the third quarter of 2019, we established an unsecured commercial paper program, backed by the revolving credit facility, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time.  Proceeds from the issuances of the notes are expected to be used for general corporate purposes.  As of September 28, 2019 we had no outstanding debt under the commercial paper program. Subsequent to the end of the quarter, the Company issued $265 million commercial paper under the program.

[0000068505-19-000025:mdna:202]
[same as prior period, unchanged from 0000068505-19-000019:mdna:197]

[0000068505-19-000025:mdna:203]
[same as prior period, unchanged from 0000068505-19-000019:mdna:198]

[0000068505-19-000025:mdna:204]
As of September 28, 2019, we had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above LIBOR, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of September 28, 2019. During the first quarter of 2018, we borrowed $400 million to facilitate the Avigilon acquisition, which was subsequently paid during the fourth quarter of 2018. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of September 28, 2019.

[0000068505-19-000025:mdna:205]
[same as prior period, unchanged from 0000068505-19-000019:mdna:200]

[0000068505-19-000025:mdna:206]
During the nine months ended September 28, 2019, we paid an aggregate of $170 million, including transaction costs, to repurchase approximately 1.4 million shares at an average price of $122.31 per share. As of September 28, 2019, the Company had used approximately $12.6 billion of the share repurchase authority to repurchase shares, leaving $1.4 billion of authority available for future repurchases.

[0000068505-19-000025:mdna:207]
[same as prior period, unchanged from 0000068505-19-000019:mdna:202]

[0000068505-19-000025:mdna:208]
During the third quarter of 2019, we paid $94 million in cash dividends to holders of our common stock. During the first nine months of 2019, we paid $281 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $98 million in cash dividends to holders of our common stock.

[0000068505-19-000025:mdna:209]
[same as prior period, unchanged from 0000068505-19-000019:mdna:204]

[0000068505-19-000025:mdna:210]
We had outstanding commitments to provide long-term financing to third parties totaling $98 million at September 28, 2019, compared to $62 million at December 31, 2018.

[0000068505-19-000025:mdna:211]
[same as prior period, unchanged from 0000068505-19-000019:mdna:208]

[0000068505-19-000025:mdna:212]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-19-000025:mdna:213]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires us to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019 and May 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,”“ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ”“Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” and “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for us on January 1, 2020. The ASU requires a modified retrospective adoption method. We are still evaluating the impact of adoption on our financial statements and disclosures.

[0000068505-19-000025:mdna:214]
Recently Adopted Accounting Pronouncements

[0000068505-19-000025:mdna:215]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-19-000025:mdna:216]
[same as prior period, unchanged from 0000068505-19-000019:mdna:213]

[0000068505-19-000025:mdna:217]
[same as prior period, unchanged from 0000068505-19-000019:mdna:214]

[0000068505-19-000025:mdna:218]
[same as prior period, unchanged from 0000068505-19-000019:mdna:215]

[0000068505-19-000025:mdna:219]
[same as prior period, unchanged from 0000068505-19-000019:mdna:216]

[0000068505-19-000025:mdna:220]
For arrangements where we are the lessor, the adoption of ASC 842 did not have a material impact on our financial statements as the majority of our leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (i) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (ii) the lease component, if accounted for separately, would be classified as an operating lease. The

[0000068505-19-000025:mdna:221]
accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 "Revenue from Contracts with Customers" and accounting and disclosure under ASC 842 is not applicable. We have elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.

[0000068505-19-000025:mdna:222]
42
