# MSI 8-K — 0000068505-19-000023 filed 2019-10-30

## item codes, every 8-K on or before 2019-10-31

- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2019-10-31

- none on or before 2019-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000068505-19-000023:8k_2_02:1]
EX-99.1
2
msiq32019pressrelease.htm
EXHIBIT 99.1

[0000068505-19-000023:8k_2_02:2]
Exhibit

[0000068505-19-000023:8k_2_02:3]
Exhibit 99.1

[0000068505-19-000023:8k_2_02:4]
Motorola Solutions Reports Third-Quarter 2019 Financial Results

[0000068505-19-000023:8k_2_02:5]
Company raises full-year earnings outlook

[0000068505-19-000023:8k_2_02:6]
| • | Revenue of $2.0 billion, up 7% from a year ago |

[0000068505-19-000023:8k_2_02:7]
| • | GAAP earnings per share (EPS) of $1.51, up 6% |

[0000068505-19-000023:8k_2_02:8]
| • | Non-GAAP EPS* of $2.04, up 5% |

[0000068505-19-000023:8k_2_02:9]
| • | Backlog of $11.0 billion, up $1.6 billion or 17% from a year ago |

[0000068505-19-000023:8k_2_02:10]
| • | Generated $525 million of operating cash flow, up 55% |

[0000068505-19-000023:8k_2_02:11]
CHICAGO – Oct. 30, 2019 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the third quarter of 2019. Click here for a printable news release and financial tables.

[0000068505-19-000023:8k_2_02:12]
"Q3 was another excellent quarter of revenue growth and cash generation," said Greg Brown, chairman and CEO of Motorola Solutions. “Our ending backlog and continued strong business performance position us well to finish the year with record sales, earnings and cash flow.”

[0000068505-19-000023:8k_2_02:13]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-19-000023:8k_2_02:14]
|  | Q3 2019 |  | Q3 2018 |  | % Change |
| Sales | $1,994 | $1,862 | 7 | % |
| GAAP |  |  |  |
| Operating Earnings | $413 | $294 | 40 | % |
| % of Sales | 20.7 | % | 15.8 | % |  |
| EPS | $1.51 | $1.43 | 6 | % |
| Non-GAAP* |  |  |  |
| Operating Earnings | $509 | $452 | 13 | % |
| % of Sales | 25.5 | % | 24.3 | % |  |
| EPS | $2.04 | $1.94 | 5 | % |
| Products and Systems Integration Segment |  |  |  |
| Sales | $1,349 | $1,288 | 5 | % |
| GAAP Operating Earnings | $258 | $183 | 41 | % |
| % of Sales | 19.1 | % | 14.2 | % |  |
| Non-GAAP Operating Earnings* | $300 | $276 | 9 | % |
| % of Sales | 22.2 | % | 21.4 | % |  |
| Services and Software Segment |  |  |  |
| Sales | $645 | $574 | 12 | % |
| GAAP Operating Earnings | $155 | $111 | 40 | % |
| % of Sales | 24.0 | % | 19.3 | % |  |
| Non-GAAP Operating Earnings* | $209 | $176 | 19 | % |
| % of Sales | 32.4 | % | 30.7 | % |  |

[0000068505-19-000023:8k_2_02:15]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.53 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-19-000023:8k_2_02:16]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-19-000023:8k_2_02:17]
| • | Revenue - Sales were $2.0 billion, up $132 million, or 7% from the year-ago quarter, driven by growth in the Americas. Revenue from acquisitions was $58 million, and currency headwinds were $21 million in the quarter. The Products and Systems Integration segment grew 5%, and the Services and Software segment grew 12%. Both segments were driven by growth in the Americas, partially offset by unfavorable currency rates. |

[0000068505-19-000023:8k_2_02:18]
| • | Operating margin - GAAP operating margin was 20.7% of sales, up from 15.8% in the year-ago quarter. The improvement was primarily due to higher sales and gross margin in the current year, as well as costs related to an increase to an existing environmental reserve booked in the prior year, partially offset by higher operating expenses related to acquisitions. Non-GAAP operating margin was 25.5% of sales, up from 24.3% in the year-ago quarter due to higher sales and gross margin, partially offset by higher operating expenses related to acquisitions. |

[0000068505-19-000023:8k_2_02:19]
| • | Taxes - The GAAP effective tax rate was 23%, compared with 8% in the year-ago quarter. The non-GAAP effective tax rate was 23% compared with 18% in the year-ago quarter. Both the GAAP and non-GAAP tax rates were higher in the current year due to the recognition of favorable return-to- provision adjustments in the prior year. |

[0000068505-19-000023:8k_2_02:20]
| • | Cash flow - Operating cash flow was $525 million, compared with $338 million in the year-ago quarter. Free cash flow was $465 million, compared with $292 million in the year-ago quarter. Cash flow for the quarter increased year over year primarily due to improved working capital, a settlement payment in the prior year related to a legacy business, and higher earnings. |

[0000068505-19-000023:8k_2_02:21]
| • | Capital allocation - During the quarter, the company paid $271 million in cash and equity to acquire WatchGuard Inc., paid $94 million in cash dividends, and incurred $60 million of capital expenditures. Additionally, we extended our strategic partnership with Silver Lake with a new $1 billion five-year convertible note. In exchange, we settled the outstanding $800 million note with 5.5 million shares and $1.1 billion in cash, of which $600 million was paid subsequent to quarter-end. The transaction resulted in an overall reduction to our diluted share count in the quarter. The company also paid off the $400 million term loan used to acquire Avigilon. |

[0000068505-19-000023:8k_2_02:22]
| • | Backlog - The company ended the quarter with backlog of $11.0 billion, up $1.6 billion from the year-ago quarter. Services and Software backlog was up 26% or $1.6 billion due to growth in EMEA and the Americas. Products and Systems Integration segment backlog was down 1% or $39 million primarily due to two large system deployments in the Middle East and Africa in the prior year, partially offset by growth in the Americas. |

[0000068505-19-000023:8k_2_02:23]
NOTABLE WINS

[0000068505-19-000023:8k_2_02:24]
Services and Software

[0000068505-19-000023:8k_2_02:25]
| • | $78 million P25 multi-year service contract with State of Michigan, extending service through 2029 |

[0000068505-19-000023:8k_2_02:26]
| • | $58 million P25 multi-year statewide service contract in North America |

[0000068505-19-000023:8k_2_02:27]
| • | $11 million command center software suite contract with Glendale, Arizona |

[0000068505-19-000023:8k_2_02:28]
| • | $4 million for a 911 system in Bogota, Colombia |

[0000068505-19-000023:8k_2_02:29]
Products and Systems Integration

[0000068505-19-000023:8k_2_02:30]
| • | The largest Canadian P25 award in history serving the province of Ontario |

[0000068505-19-000023:8k_2_02:31]
| • | $27 million in video security wins in education |

[0000068505-19-000023:8k_2_02:32]
| • | $16 million P25 order from Lee County, Florida |

[0000068505-19-000023:8k_2_02:33]
| • | Several large awards in mobile and in-car video including $13 million for city of Nashville, Tennessee and $4 million for the Michigan State Police |

[0000068505-19-000023:8k_2_02:34]
| • | $3 million in fixed video security wins for government customers |

[0000068505-19-000023:8k_2_02:35]
BUSINESS OUTLOOK

[0000068505-19-000023:8k_2_02:36]
| • | Fourth-quarter 2019 - Motorola Solutions expects revenue growth of 5% to 5.5% compared with the fourth quarter of 2018. The company expects non-GAAP earnings per share in the range of $2.75 to $2.80. This assumes current foreign exchange rates, approximately 176 million fully diluted shares and an effective tax rate of approximately 25%. |

[0000068505-19-000023:8k_2_02:37]
| • | Full-year 2019 - The company now expects revenue growth of 7.25% to 7.5%. The company now expects non-GAAP earnings per share in the range of $7.77 to $7.82, up from the prior guidance of $7.67 to $7.77. This assumes current foreign exchange rates, approximately 176 million fully diluted shares and an effective tax rate of approximately 23.5%. |

[0000068505-19-000023:8k_2_02:38]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Wednesday, Oct. 30. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0000068505-19-000023:8k_2_02:39]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-19-000023:8k_2_02:40]
A comparison of results from operations is as follows:

[0000068505-19-000023:8k_2_02:41]
|  | Q3 2019 |  | Q3 2018 |  |
| Net sales | $1,994 | $1,862 |
| Gross margin | 1,007 |  | 901 |  |
| Operating earnings | 413 |  | 294 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | 267 |  | 247 |  |
| Diluted EPS | $1.51 | $1.43 |
| Weighted average diluted common shares outstanding | 176.4 |  | 172.6 |  |

[0000068505-19-000023:8k_2_02:42]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0000068505-19-000023:8k_2_02:43]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the third quarter of 2019.

[0000068505-19-000023:8k_2_02:44]
| (per diluted common share) | Q3 2019 |  |
| GAAP Earnings | $1.51 |
| Highlighted Items: |  |
| Intangibles amortization expense | 0.22 |  |
| Share-based compensation expense | 0.13 |  |
| Reorganization of business charges | 0.08 |  |
| Fair value adjustments to equity investments | 0.08 |  |
| Loss from the extinguishment of long-term debt | 0.03 |  |
| Investment impairments | 0.02 |  |
| Acquisition-related transaction fees | 0.01 |  |
| Gain from the extinguishment of 2.00% senior convertible notes | (0.02 | ) |
| Gain on legal settlement | (0.02 | ) |
| Non-GAAP Diluted EPS | $2.04 |

[0000068505-19-000023:8k_2_02:45]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-19-000023:8k_2_02:46]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-19-000023:8k_2_02:47]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-19-000023:8k_2_02:48]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-19-000023:8k_2_02:49]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-19-000023:8k_2_02:50]
Free cash flow:  Free cash flow represents operating cash flow less capital expenditures. We believe that free cash flow is also useful to investors as the basis for comparing our performance and coverage ratios with other companies in our industries, although our measure of free cash flow may not be directly comparable to similar measures used by other companies.

[0000068505-19-000023:8k_2_02:51]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes non-GAAP organic

[0000068505-19-000023:8k_2_02:52]
revenue growth provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-19-000023:8k_2_02:53]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-19-000023:8k_2_02:54]
The company has not quantitatively reconciled its guidance for non-GAAP metrics to their most comparable GAAP measure because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-19-000023:8k_2_02:55]
BUSINESS RISKS

[0000068505-19-000023:8k_2_02:56]
acquisitions or divestitures; (12) risks related to the company's manufacturing and business operations in foreign countries; (13) the creditworthiness of the company's customers and distributors, particularly purchasers of large infrastructure systems; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company's intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to complete acquisitions or repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company's use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; and (22) the company’s ability to settle the par value of its 1.75% senior convertible notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-19-000023:8k_2_02:57]
ABOUT MOTOROLA SOLUTIONS

[0000068505-19-000023:8k_2_02:58]
Motorola Solutions is a global leader in mission-critical communications. Our technology platforms in communications, command center software, video security solutions and managed and support services make cities safer and help communities and businesses thrive. At Motorola Solutions, we are ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com

[0000068505-19-000023:8k_2_02:59]
MEDIA CONTACT

[0000068505-19-000023:8k_2_02:60]
Kate Dyer

[0000068505-19-000023:8k_2_02:61]
Motorola Solutions

[0000068505-19-000023:8k_2_02:62]
+1 224-374-3124

[0000068505-19-000023:8k_2_02:63]
Kate.Dyer@motorolasolutions.com

[0000068505-19-000023:8k_2_02:64]
INVESTOR CONTACT

[0000068505-19-000023:8k_2_02:65]
Tim Yocum

[0000068505-19-000023:8k_2_02:66]
Motorola Solutions

[0000068505-19-000023:8k_2_02:67]
+1 847-576-6899

[0000068505-19-000023:8k_2_02:68]
Tim.Yocum@motorolasolutions.com

[0000068505-19-000023:8k_2_02:69]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2019 Motorola Solutions, Inc. All rights reserved.

[0000068505-19-000023:8k_2_02:70]
GAAP-1

[0000068505-19-000023:8k_2_02:71]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:72]
Condensed Consolidated Statements of Operations

[0000068505-19-000023:8k_2_02:73]
(In millions, except per share amounts)

[0000068505-19-000023:8k_2_02:74]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Net sales from products | $ | 1,196 |  |  | $ | 1,151 |  |
| Net sales from services | 798 |  |  | 711 |  |
| Net sales | 1,994 |  |  | 1,862 |  |
| Costs of products sales | 501 |  |  | 516 |  |
| Costs of services sales | 486 |  |  | 445 |  |
| Costs of sales | 987 |  |  | 961 |  |
| Gross margin | 1,007 |  |  | 901 |  |
| Selling, general and administrative expenses | 359 |  |  | 323 |  |
| Research and development expenditures | 172 |  |  | 158 |  |
| Other charges | 11 |  |  | 80 |  |
| Intangibles amortization | 52 |  |  | 46 |  |
| Operating earnings | 413 |  |  | 294 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (54 | ) |  | (59 | ) |
| Gains on sales of investments and businesses, net | — |  |  | 6 |  |
| Other, net | (11 | ) |  | 29 |  |
| Total other expense | (65 | ) |  | (24 | ) |
| Net earnings before income taxes | 348 |  |  | 270 |  |
| Income tax expense | 80 |  |  | 22 |  |
| Net earnings | 268 |  |  | 248 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 267 |  |  | $ | 247 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.60 |  |  | $ | 1.52 |  |
| Diluted | $ | 1.51 |  |  | $ | 1.43 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 166.7 |  |  | 162.6 |  |
| Diluted | 176.4 |  |  | 172.6 |  |

[0000068505-19-000023:8k_2_02:75]
|  | Percentage of Net Sales* |
| Net sales from products | 60.0 | % |  | 61.8 | % |
| Net sales from services | 40.0 | % |  | 38.2 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 41.9 | % |  | 44.8 | % |
| Costs of services sales | 60.9 | % |  | 62.6 | % |
| Costs of sales | 49.5 | % |  | 51.6 | % |
| Gross margin | 50.5 | % |  | 48.4 | % |
| Selling, general and administrative expenses | 18.0 | % |  | 17.3 | % |
| Research and development expenditures | 8.6 | % |  | 8.5 | % |
| Other charges | 0.6 | % |  | 4.3 | % |
| Intangibles amortization | 2.6 | % |  | 2.5 | % |
| Operating earnings | 20.7 | % |  | 15.8 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.7 | )% |  | (3.2 | )% |
| Gains on sales of investments and businesses, net | — | % |  | 0.3 | % |
| Other, net | (0.6 | )% |  | 1.6 | % |
| Total other expense | (3.3 | )% |  | (1.3 | )% |
| Net earnings before income taxes | 17.4 | % |  | 14.5 | % |
| Income tax expense | 4.0 | % |  | 1.2 | % |
| Net earnings | 13.4 | % |  | 13.3 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 13.4 | % |  | 13.3 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-19-000023:8k_2_02:76]
GAAP-2

[0000068505-19-000023:8k_2_02:77]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:78]
Condensed Consolidated Statements of Operations

[0000068505-19-000023:8k_2_02:79]
(In millions, except per share amounts)

[0000068505-19-000023:8k_2_02:80]
|  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Net sales from products | $ | 3,260 |  |  | $ | 2,993 |  |
| Net sales from services | 2,251 |  |  | 2,096 |  |
| Net sales | 5,511 |  |  | 5,089 |  |
| Costs of products sales | 1,435 |  |  | 1,383 |  |
| Costs of services sales | 1,365 |  |  | 1,314 |  |
| Costs of sales | 2,800 |  |  | 2,697 |  |
| Gross margin | 2,711 |  |  | 2,392 |  |
| Selling, general and administrative expenses | 1,035 |  |  | 918 |  |
| Research and development expenditures | 505 |  |  | 472 |  |
| Other charges | 26 |  |  | 123 |  |
| Intangibles amortization | 154 |  |  | 140 |  |
| Operating earnings | 991 |  |  | 739 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (165 | ) |  | (163 | ) |
| Gains on sales of investments and businesses, net | 4 |  |  | 16 |  |
| Other, net | (22 | ) |  | 45 |  |
| Total other expense | (183 | ) |  | (102 | ) |
| Net earnings before income taxes | 808 |  |  | 637 |  |
| Income tax expense | 180 |  |  | 91 |  |
| Net earnings | 628 |  |  | 546 |  |
| Less: Earnings attributable to non-controlling interests | 3 |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 625 |  |  | $ | 544 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.78 |  |  | $ | 3.36 |  |
| Diluted | $ | 3.56 |  |  | $ | 3.17 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 165.3 |  |  | 162.0 |  |
| Diluted | 175.7 |  |  | 171.6 |  |

[0000068505-19-000023:8k_2_02:81]
|  | Percentage of Net Sales* |
| Net sales from products | 59.2 | % |  | 58.8 | % |
| Net sales from services | 40.8 | % |  | 41.2 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 44.0 | % |  | 46.2 | % |
| Costs of services sales | 60.6 | % |  | 62.7 | % |
| Costs of sales | 50.8 | % |  | 53.0 | % |
| Gross margin | 49.2 | % |  | 47.0 | % |
| Selling, general and administrative expenses | 18.8 | % |  | 18.0 | % |
| Research and development expenditures | 9.2 | % |  | 9.3 | % |
| Other charges | 0.5 | % |  | 2.4 | % |
| Intangibles amortization | 2.8 | % |  | 2.8 | % |
| Operating earnings | 18.0 | % |  | 14.5 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.0 | )% |  | (3.2 | )% |
| Gains on sales of investments and businesses, net | 0.1 | % |  | 0.3 | % |
| Other, net | (0.4 | )% |  | 0.9 | % |
| Total other expense | (3.3 | )% |  | (2.0 | )% |
| Net earnings before income taxes | 14.7 | % |  | 12.5 | % |
| Income tax expense | 3.3 | % |  | 1.8 | % |
| Net earnings | 11.4 | % |  | 10.7 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 11.3 | % |  | 10.7 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-19-000023:8k_2_02:82]
GAAP-3

[0000068505-19-000023:8k_2_02:83]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:84]
Condensed Consolidated Balance Sheets

[0000068505-19-000023:8k_2_02:85]
(In millions)

[0000068505-19-000023:8k_2_02:86]
|  |  | September 28, 2019 |  | December 31, 2018 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,138 |  |  | $ | 1,246 |  |
| Restricted cash |  | 2 |  |  | 11 |  |
| Total cash and cash equivalents |  | 1,140 |  |  | 1,257 |  |
| Accounts receivable, net |  | 1,295 |  |  | 1,293 |  |
| Contract assets |  | 921 |  |  | 1,012 |  |
| Inventories, net |  | 460 |  |  | 356 |  |
| Other current assets |  | 338 |  |  | 354 |  |
| Total current assets |  | 4,154 |  |  | 4,272 |  |
| Property, plant and equipment, net |  | 963 |  |  | 895 |  |
| Operating lease assets |  | 561 |  |  | — |  |
| Investments |  | 159 |  |  | 169 |  |
| Deferred income taxes |  | 866 |  |  | 985 |  |
| Goodwill |  | 2,006 |  |  | 1,514 |  |
| Intangible assets, net |  | 1,331 |  |  | 1,230 |  |
| Other assets |  | 333 |  |  | 344 |  |
| Total assets |  | $ | 10,373 |  |  | $ | 9,409 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Current portion of long-term debt |  | $ | 617 |  |  | $ | 31 |  |
| Accounts payable |  | 557 |  |  | 592 |  |
| Contract liabilities |  | 1,223 |  |  | 1,263 |  |
| Accrued liabilities |  | 1,259 |  |  | 1,210 |  |
| Total current liabilities |  | 3,656 |  |  | 3,096 |  |
| Long-term debt |  | 5,112 |  |  | 5,289 |  |
| Operating lease liabilities |  | 499 |  |  | — |  |
| Other liabilities |  | 2,190 |  |  | 2,300 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (1,101 | ) |  | (1,293 | ) |
| Non-controlling interests |  | 17 |  |  | 17 |  |
| Total liabilities and stockholders’ equity |  | $ | 10,373 |  |  | $ | 9,409 |  |

[0000068505-19-000023:8k_2_02:87]
GAAP-4

[0000068505-19-000023:8k_2_02:88]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:89]
Condensed Consolidated Statements of Cash Flows

[0000068505-19-000023:8k_2_02:90]
(In millions)

[0000068505-19-000023:8k_2_02:91]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 267 |  |  | $ | 247 |  |
| Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings | 268 |  |  | 248 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 99 |  |  | 89 |  |
| Non-cash other charges | 22 |  |  | 50 |  |
| Share-based compensation expense | 30 |  |  | 19 |  |
| Gain on sales of investments and businesses, net | — |  |  | (6 | ) |
| Losses from the extinguishment of long term debt | 7 |  |  | — |  |
| Gain from the extinguishment of 2.00% senior convertible notes | (4 | ) |  | (6 | ) |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (80 | ) |  | (20 | ) |
| Inventories | (27 | ) |  | 24 |  |
| Other current assets and contract assets | (24 | ) |  | (180 | ) |
| Accounts payable, accrued liabilities, and contract liabilities | 202 |  |  | 170 |  |
| Other assets and liabilities | 8 |  |  | (38 | ) |
| Deferred income taxes | 24 |  |  | (12 | ) |
| Net cash provided by operating activities | 525 |  |  | 338 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (252 | ) |  | (5 | ) |
| Proceeds from sales of investments and businesses, net | — |  |  | 11 |  |
| Capital expenditures | (60 | ) |  | (46 | ) |
| Net cash used for investing activities | (312 | ) |  | (40 | ) |
| Financing |  |  |  |
| Repayment of debt | (770 | ) |  | (215 | ) |
| Net proceeds from the issuances of debt | 1,159 |  |  | — |  |
| Issuances of common stock | 12 |  |  | 80 |  |
| Payments of dividends | (94 | ) |  | (84 | ) |
| Settlements of conversion premium on 2.00% senior convertible notes | (326 | ) |  | (169 | ) |
| Net cash used for financing activities | (19 | ) |  | (388 | ) |
| Effect of exchange rate changes on total cash and cash equivalents | (18 | ) |  | — |  |
| Net increase (decrease) in total cash and cash equivalents | 176 |  |  | (90 | ) |
| Total cash and cash equivalents, beginning of period | 964 |  |  | 941 |  |
| Total cash and cash equivalents, end of period | $ | 1,140 |  |  | $ | 851 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 465 |  |  | $ | 292 |  |
| *Free cash flow = Net cash provided by (used for) operating activities - Capital expenditures |  |  |  |

[0000068505-19-000023:8k_2_02:92]
GAAP-5

[0000068505-19-000023:8k_2_02:93]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:94]
Condensed Consolidated Statements of Cash Flows

[0000068505-19-000023:8k_2_02:95]
(In millions)

[0000068505-19-000023:8k_2_02:96]
|  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 625 |  |  | $ | 544 |  |
| Earnings attributable to non-controlling interests | 3 |  |  | 2 |  |
| Net earnings | 628 |  |  | 546 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 290 |  |  | 267 |  |
| Non-cash other charges | 27 |  |  | 56 |  |
| Share-based compensation expense | 87 |  |  | 53 |  |
| Gains on sales of investments and businesses, net | (4 | ) |  | (16 | ) |
| Losses from the extinguishment of long term debt | 50 |  |  | — |  |
| Gain from the extinguishment of 2.00% senior convertible notes | (4 | ) |  | (6 | ) |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 30 |  |  | 186 |  |
| Inventories | (88 | ) |  | 61 |  |
| Other current assets and contract assets | 104 |  |  | (137 | ) |
| Accounts payable, accrued liabilities, and contract liabilities | (143 | ) |  | (170 | ) |
| Other assets and liabilities | 10 |  |  | (596 | ) |
| Deferred income taxes | 41 |  |  | 19 |  |
| Net cash provided by operating activities | 1,028 |  |  | 263 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (623 | ) |  | (1,158 | ) |
| Proceeds from sales of investments and businesses, net | 10 |  |  | 90 |  |
| Capital expenditures | (189 | ) |  | (128 | ) |
| Net cash used for investing activities | (802 | ) |  | (1,196 | ) |
| Financing |  |  |  |
| Repayment of debt | (1,435 | ) |  | (412 | ) |
| Net proceeds from the issuances of debt | 1,804 |  |  | 1,295 |  |
| Issuances of common stock | 82 |  |  | 139 |  |
| Purchases of common stock | (170 | ) |  | (66 | ) |
| Payments of dividends | (281 | ) |  | (252 | ) |
| Payments of dividends to non-controlling interests | (3 | ) |  | (1 | ) |
| Settlements of conversion premium on 2.00% senior convertible notes | (326 | ) |  | (169 | ) |
| Net cash provided by (used for) financing activities | (329 | ) |  | 534 |  |
| Effect of exchange rate changes on total cash and cash equivalents | (14 | ) |  | (18 | ) |
| Net decrease in total cash and cash equivalents | (117 | ) |  | (417 | ) |
| Total cash and cash equivalents, beginning of period | 1,257 |  |  | 1,268 |  |
| Total cash and cash equivalents, end of period | $ | 1,140 |  |  | $ | 851 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 839 |  |  | $ | 135 |  |
| *Free cash flow = Net cash provided by (used for) operating activities - Capital expenditures |  |  |  |

[0000068505-19-000023:8k_2_02:97]
GAAP-6

[0000068505-19-000023:8k_2_02:98]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:99]
Segment Information

[0000068505-19-000023:8k_2_02:100]
(In millions)

[0000068505-19-000023:8k_2_02:101]
| Net Sales |
|  | Three Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Products and Systems Integration | $ | 1,349 |  |  | $ | 1,288 |  |  | 5 | % |
| Services and Software | 645 |  |  | 574 |  |  | 12 | % |
| Total Motorola Solutions | $ | 1,994 |  |  | $ | 1,862 |  |  | 7 | % |
|  | Nine Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Products and Systems Integration | $ | 3,656 |  |  | $ | 3,429 |  |  | 7 | % |
| Services and Software | 1,855 |  |  | 1,660 |  |  | 12 | % |
| Total Motorola Solutions | $ | 5,511 |  |  | $ | 5,089 |  |  | 8 | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Products and Systems Integration | $ | 258 |  |  | $ | 183 |  |  | 41 | % |
| Services and Software | 155 |  |  | 111 |  |  | 40 | % |
| Total Motorola Solutions | $ | 413 |  |  | $ | 294 |  |  | 40 | % |
|  | Nine Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Products and Systems Integration | $ | 568 |  |  | $ | 449 |  |  | 27 | % |
| Services and Software | 423 |  |  | 290 |  |  | 46 | % |
| Total Motorola Solutions | $ | 991 |  |  | $ | 739 |  |  | 34 | % |

[0000068505-19-000023:8k_2_02:102]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  |  |
| Products and Systems Integration | 19.1 | % |  | 14.2 | % |  |  |
| Services and Software | 24.0 | % |  | 19.3 | % |  |  |
| Total Motorola Solutions | 20.7 | % |  | 15.8 | % |  |  |
|  | Nine Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  |  |
| Products and Systems Integration | 15.5 | % |  | 13.1 | % |  |  |
| Services and Software | 22.8 | % |  | 17.5 | % |  |  |
| Total Motorola Solutions | 18.0 | % |  | 14.5 | % |  |  |

[0000068505-19-000023:8k_2_02:103]
Non-GAAP-1

[0000068505-19-000023:8k_2_02:104]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:105]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expense, and Highlighted Items)

[0000068505-19-000023:8k_2_02:106]
(In millions)

[0000068505-19-000023:8k_2_02:107]
| Q1 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 50 |  |  | $ | 11 |  |  | $ | 39 |  |  | $ | 0.23 |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | 27 |  |  | 6 |  |  | 21 |  |  | 0.12 |  |
| Investment impairments |  | Investment impairments |  | 8 |  |  | 2 |  |  | 6 |  |  | 0.04 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 8 |  |  | 2 |  |  | 6 |  |  | 0.04 |  |
| Acquisition-related transaction fees |  | Other charges |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other expense |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Release of uncertain tax positions |  | Income tax expense |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Legal settlement |  | Other charges |  | (1 | ) |  | — |  |  | (1 | ) |  | (0.01 | ) |
| Sale of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (1 | ) |  | — |  |  | (1 | ) |  | (0.01 | ) |
| Total impact on Net earnings |  |  |  | $ | 94 |  |  | $ | 22 |  |  | $ | 72 |  |  | $ | 0.42 |  |
| Q2 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 52 |  |  | $ | 11 |  |  | $ | 41 |  |  | $ | 0.23 |  |
| Loss from the extinguishment of long-term debt |  | Other expense |  | 43 |  |  | 11 |  |  | 32 |  |  | 0.18 |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | 30 |  |  | 7 |  |  | 23 |  |  | 0.13 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 12 |  |  | 3 |  |  | 9 |  |  | 0.05 |  |
| Investment impairments |  | Investment impairments |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |
| Legal settlements |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Sale of a business |  | (Gain) or loss on sales of investments and businesses, net |  | (3 | ) |  | (1 | ) |  | (2 | ) |  | (0.01 | ) |
| Release of uncertain tax positions |  | Other income, Income tax expense |  | (4 | ) |  | (1 | ) |  | (3 | ) |  | (0.02 | ) |
| Fair value adjustments to equity investments |  | Other income |  | (16 | ) |  | (4 | ) |  | (12 | ) |  | (0.07 | ) |
| Total impact on Net earnings |  |  |  | $ | 118 |  |  | $ | 27 |  |  | $ | 91 |  |  | $ | 0.51 |  |

[0000068505-19-000023:8k_2_02:108]
| Q3 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 52 |  |  | $ | 12 |  |  | $ | 40 |  |  | $ | 0.22 |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | 30 |  |  | 7 |  |  | 23 |  |  | 0.13 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Fair value adjustments to equity investments |  | Other income |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Loss from the extinguishment of long-term debt |  | Other expense |  | 7 |  |  | 2 |  |  | 5 |  |  | 0.03 |  |
| Investment impairments |  | Other expense |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Acquisition-related transaction fees |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Gain from the extinguishment of 2.00% senior convertible notes |  | Other income |  | (4 | ) |  | (1 | ) |  | (3 | ) |  | (0.02 | ) |
| Gain on legal settlement |  | Other charges |  | (5 | ) |  | (1 | ) |  | (4 | ) |  | (0.02 | ) |
| Total impact on Net earnings |  |  |  | $ | 122 |  |  | $ | 28 |  |  | $ | 94 |  |  | $ | 0.53 |  |

[0000068505-19-000023:8k_2_02:109]
Non-GAAP-2

[0000068505-19-000023:8k_2_02:110]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:111]
Non-GAAP Segment Information

[0000068505-19-000023:8k_2_02:112]
(In millions)

[0000068505-19-000023:8k_2_02:113]
| Net Sales |
|  | Three Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Products and Systems Integration | $ | 1,349 |  |  | $ | 1,288 |  |  | 5 | % |
| Services and Software | 645 |  |  | 574 |  |  | 12 | % |
| Total Motorola Solutions | $ | 1,994 |  |  | $ | 1,862 |  |  | 7 | % |
|  | Nine Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Products and Systems Integration | $ | 3,656 |  |  | $ | 3,429 |  |  | 7 | % |
| Services and Software | 1,855 |  |  | 1,660 |  |  | 12 | % |
| Total Motorola Solutions | $ | 5,511 |  |  | $ | 5,089 |  |  | 8 | % |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Products and Systems Integration | $ | 300 |  |  | $ | 276 |  |  | 9 | % |
| Services and Software | 209 |  |  | 176 |  |  | 19 | % |
| Total Motorola Solutions | $ | 509 |  |  | $ | 452 |  |  | 13 | % |
|  | Nine Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Products and Systems Integration | $ | 689 |  |  | $ | 627 |  |  | 10 | % |
| Services and Software | 580 |  |  | 463 |  |  | 25 | % |
| Total Motorola Solutions | $ | 1,269 |  |  | $ | 1,090 |  |  | 16 | % |

[0000068505-19-000023:8k_2_02:114]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  |  |
| Products and Systems Integration | 22.2 | % |  | 21.4 | % |  |  |
| Services and Software | 32.4 | % |  | 30.7 | % |  |  |
| Total Motorola Solutions | 25.5 | % |  | 24.3 | % |  |  |
|  | Nine Months Ended |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  |  |
| Products and Systems Integration | 18.8 | % |  | 18.3 | % |  |  |
| Services and Software | 31.3 | % |  | 27.9 | % |  |  |
| Total Motorola Solutions | 23.0 | % |  | 21.4 | % |  |  |

[0000068505-19-000023:8k_2_02:115]
Non-GAAP-3

[0000068505-19-000023:8k_2_02:116]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:117]
Operating Earnings after Non-GAAP Adjustments

[0000068505-19-000023:8k_2_02:118]
(In millions)

[0000068505-19-000023:8k_2_02:119]
| Q1 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,657 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Operating earnings ("OE") |  | $ | 229 |  |  | $ | 108 |  |  | $ | 121 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 27 |  |  | 21 |  |  | 6 |  |
| Reorganization of business charges |  | 8 |  |  | 7 |  |  | 1 |  |
| Intangibles amortization expense |  | 50 |  |  | 11 |  |  | 39 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 1 |  |  | 1 |  |
| Legal settlement |  | (1 | ) |  | (1 | ) |  | — |  |
| Total above-OE non-GAAP adjustments |  | 86 |  |  | 39 |  |  | 47 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 315 |  |  | $ | 147 |  |  | $ | 168 |  |

[0000068505-19-000023:8k_2_02:120]
| Operating earnings as a percentage of net sales - GAAP |  | 13.8 | % |  | 10.1 | % |  | 20.6 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 19.0 | % |  | 13.8 | % |  | 28.6 | % |

[0000068505-19-000023:8k_2_02:121]
| Q2 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,860 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Operating earnings ("OE") |  | $ | 349 |  |  | $ | 201 |  |  | $ | 148 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 30 |  |  | 19 |  |  | 11 |  |
| Reorganization of business charges |  | 12 |  |  | 9 |  |  | 3 |  |
| Intangibles amortization expense |  | 52 |  |  | 12 |  |  | 40 |  |
| Legal settlements |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 95 |  |  | 41 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 444 |  |  | $ | 242 |  |  | $ | 202 |  |

[0000068505-19-000023:8k_2_02:122]
| Operating earnings as a percentage of net sales - GAAP |  | 18.8 | % |  | 16.2 | % |  | 23.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 23.9 | % |  | 19.5 | % |  | 32.5 | % |

[0000068505-19-000023:8k_2_02:123]
| Q3 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,994 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Operating earnings ("OE") |  | $ | 413 |  |  | $ | 258 |  |  | $ | 155 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 30 |  |  | 20 |  |  | 10 |  |
| Reorganization of business charges |  | 18 |  |  | 14 |  |  | 4 |  |
| Intangibles amortization expense |  | 52 |  |  | 12 |  |  | 40 |  |
| Gain on legal settlement |  | (5 | ) |  | (5 | ) |  | — |  |
| Acquisition-related transaction fees |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 96 |  |  | 42 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 509 |  |  | $ | 300 |  |  | $ | 209 |  |

[0000068505-19-000023:8k_2_02:124]
| Operating earnings as a percentage of net sales - GAAP |  | 20.7 | % |  | 19.1 | % |  | 24.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 25.5 | % |  | 22.2 | % |  | 32.4 | % |

[0000068505-19-000023:8k_2_02:125]
Non-GAAP-4

[0000068505-19-000023:8k_2_02:126]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000023:8k_2_02:127]
Non-GAAP Organic Revenue

[0000068505-19-000023:8k_2_02:128]
(In millions)

[0000068505-19-000023:8k_2_02:129]
| Total Motorola Solutions |
|  |  | Three Months Ended |  |  |
|  |  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Net sales |  | $ | 1,994 |  |  | $ | 1,862 |  |  | 7 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | (58 | ) |  | — |  |  |  |
| Organic revenue |  | $ | 1,936 |  |  | $ | 1,862 |  |  | 4 | % |

[0000068505-19-000023:8k_2_02:130]
| Total Motorola Solutions |
|  |  | Nine Months Ended |  |  |
|  |  | September 28, 2019 |  | September 29, 2018 |  | % Change |
| Net sales |  | $ | 5,511 |  |  | $ | 5,089 |  |  | 8 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | (256 | ) |  | (29 | ) |  |  |
| Organic revenue |  | $ | 5,255 |  |  | $ | 5,060 |  |  | 4 | % |
