# MSI notes — 0000068505-14-000010


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-14-000010:notes:1]
[same as prior period, unchanged from 0000068505-14-000008:notes:1]

[0000068505-14-000010:notes:2]
[same as prior period, unchanged from 0000068505-14-000008:notes:2]

[0000068505-14-000010:notes:3]
[same as prior period, unchanged from 0000068505-14-000008:notes:3]

[0000068505-14-000010:notes:4]
[same as prior period, unchanged from 0000068505-14-000008:notes:4]

[0000068505-14-000010:notes:5]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |
| Reorganization of businesses | 25 |  |  | 13 |  |  | 34 |  |  | 20 |  |
| Legal settlement | 8 |  |  | — |  |  | 8 |  |  | — |  |
| Gain on sale of building and land | — |  |  | — |  |  | (21 | ) |  | — |  |
|  | $ | 34 |  |  | $ | 13 |  |  | $ | 23 |  |  | $ | 20 |  |

[0000068505-14-000010:notes:6]
During the first quarter of 2014, the Company completed the sale of a building and parcel of land on its Schaumburg, IL campus with a net book value of $3 million for net cash proceeds of $24 million resulting in a gain on sale of $21 million.

[0000068505-14-000010:notes:7]
[same as prior period, unchanged from 0000068505-14-000008:notes:7]

[0000068505-14-000010:notes:8]
[same as prior period, unchanged from 0000068505-14-000008:notes:8]

[0000068505-14-000010:notes:9]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (34 | ) |  | $ | (38 | ) |  | $ | (64 | ) |  | $ | (68 | ) |
| Interest income | 5 |  |  | 6 |  |  | 10 |  |  | 11 |  |
|  | $ | (29 | ) |  | $ | (32 | ) |  | $ | (54 | ) |  | $ | (57 | ) |
| Other: |  |  |  |  |  |  |  |
| Investment impairments | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Foreign currency loss | (8 | ) |  | (4 | ) |  | $ | (10 | ) |  | $ | (7 | ) |
| Gains on equity method investments | 2 |  |  | 1 |  |  | 2 |  |  | — |  |
| Other | (1 | ) |  | 2 |  |  | (1 | ) |  | 6 |  |
|  | $ | (7 | ) |  | $ | (3 | ) |  | $ | (9 | ) |  | $ | (3 | ) |

[0000068505-14-000010:notes:10]
[same as prior period, unchanged from 0000068505-14-000008:notes:10]

[0000068505-14-000010:notes:11]
[same as prior period, unchanged from 0000068505-14-000008:notes:11]

[0000068505-14-000010:notes:12]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations |  | Net Earnings |
| Three Months Ended | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 78 |  |  | $ | 223 |  |  | $ | 824 |  |  | $ | 258 |  |
| Weighted average common shares outstanding | 253.7 |  |  | 269.5 |  |  | 253.7 |  |  | 269.5 |  |
| Per share amount | $ | 0.31 |  |  | $ | 0.83 |  |  | $ | 3.25 |  |  | $ | 0.96 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 78 |  |  | $ | 223 |  |  | $ | 824 |  |  | $ | 258 |  |
| Weighted average common shares outstanding | 253.7 |  |  | 269.5 |  |  | 253.7 |  |  | 269.5 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.5 |  |  | 5.2 |  |  | 2.5 |  |  | 5.2 |  |
| Diluted weighted average common shares outstanding | 256.2 |  |  | 274.7 |  |  | 256.2 |  |  | 274.7 |  |
| Per share amount | $ | 0.30 |  |  | $ | 0.81 |  |  | $ | 3.22 |  |  | $ | 0.94 |  |

[0000068505-14-000010:notes:13]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations |  | Net Earnings |
| Six Months Ended | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 163 |  |  | $ | 380 |  |  | $ | 951 |  |  | $ | 450 |  |
| Weighted average common shares outstanding | 253.8 |  |  | 271.9 |  |  | 253.8 |  |  | 271.9 |  |
| Per share amount | $ | 0.64 |  |  | $ | 1.40 |  |  | $ | 3.75 |  |  | $ | 1.66 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 163 |  |  | $ | 380 |  |  | $ | 951 |  |  | $ | 450 |  |
| Weighted average common shares outstanding | 253.8 |  |  | 271.9 |  |  | 253.8 |  |  | 271.9 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.4 |  |  | 5.8 |  |  | 3.4 |  |  | 5.8 |  |
| Diluted weighted average common shares outstanding | 257.2 |  |  | 277.7 |  |  | 257.2 |  |  | 277.7 |  |
| Per share amount | $ | 0.63 |  |  | $ | 1.37 |  |  | $ | 3.70 |  |  | $ | 1.62 |  |

[0000068505-14-000010:notes:14]
In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three and six months ended June 28, 2014, the assumed exercise of 4.6 million and 4.8 million stock options, respectively, were excluded because their inclusion would have been antidilutive.  In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three and six months ended June 29, 2013, the assumed exercise of 4.3 million and 4.4 million stock options, respectively, were excluded because their inclusion would have been antidilutive.

[0000068505-14-000010:notes:15]
[same as prior period, unchanged from 0000068505-14-000008:notes:14]

[0000068505-14-000010:notes:16]
[same as prior period, unchanged from 0000068505-14-000008:notes:15]

[0000068505-14-000010:notes:17]
The Company’s cash and cash equivalents (which are highly-liquid investments with an original maturity of three months or less) were $2.9 billion at June 28, 2014 and $3.2 billion at December 31, 2013. Of these amounts, $64 million at June 28, 2014 and $63 million at December 31, 2013 were restricted.

[0000068505-14-000010:notes:18]
[same as prior period, unchanged from 0000068505-14-000008:notes:17]

[0000068505-14-000010:notes:19]
[same as prior period, unchanged from 0000068505-14-000008:notes:18]

[0000068505-14-000010:notes:20]
|  | June 28, 2014 |  | December 31, 2013 |
| Available-for-sale securities: |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 15 |  |  | $ | 15 |  |
| Corporate bonds | 8 |  |  | 7 |  |
| Mutual funds | 11 |  |  | 11 |  |
| Common stock and equivalents | — |  |  | 2 |  |
|  | 34 |  |  | 35 |  |
| Other investments, at cost | 185 |  |  | 182 |  |
| Equity method investments | 17 |  |  | 15 |  |
|  | $ | 236 |  |  | $ | 232 |  |

[0000068505-14-000010:notes:21]
The Company had no unrealized gains or losses on its investments as of both June 28, 2014 and December 31, 2013.

[0000068505-14-000010:notes:22]
[same as prior period, unchanged from 0000068505-14-000008:notes:21]

[0000068505-14-000010:notes:23]
[same as prior period, unchanged from 0000068505-14-000008:notes:22]

[0000068505-14-000010:notes:24]
|  | June 28, 2014 |  | December 31, 2013 |
| Accounts receivable | $ | 1,240 |  |  | $ | 1,422 |  |
| Less allowance for doubtful accounts | (55 | ) |  | (53 | ) |
|  | $ | 1,185 |  |  | $ | 1,369 |  |

[0000068505-14-000010:notes:25]
[same as prior period, unchanged from 0000068505-14-000008:notes:24]

[0000068505-14-000010:notes:26]
[same as prior period, unchanged from 0000068505-14-000008:notes:25]

[0000068505-14-000010:notes:27]
|  | June 28, 2014 |  | December 31, 2013 |
| Finished goods | $ | 142 |  |  | $ | 157 |  |
| Work-in-process and production materials | 313 |  |  | 315 |  |
|  | 455 |  |  | 472 |  |
| Less inventory reserves | (125 | ) |  | (125 | ) |
|  | $ | 330 |  |  | $ | 347 |  |

[0000068505-14-000010:notes:28]
[same as prior period, unchanged from 0000068505-14-000008:notes:27]

[0000068505-14-000010:notes:29]
[same as prior period, unchanged from 0000068505-14-000008:notes:28]

[0000068505-14-000010:notes:30]
|  | June 28, 2014 |  | December 31, 2013 |
| Costs and earnings in excess of billings | $ | 374 |  |  | $ | 390 |  |
| Contract-related deferred costs | 14 |  |  | 15 |  |
| Tax-related deposits and refunds receivable | 64 |  |  | 107 |  |
| Other | 75 |  |  | 123 |  |
|  | $ | 527 |  |  | $ | 635 |  |

[0000068505-14-000010:notes:31]
[same as prior period, unchanged from 0000068505-14-000008:notes:30]

[0000068505-14-000010:notes:32]
[same as prior period, unchanged from 0000068505-14-000008:notes:31]

[0000068505-14-000010:notes:33]
|  | June 28, 2014 |  | December 31, 2013 |
| Land | $ | 21 |  |  | $ | 22 |  |
| Building | 554 |  |  | 582 |  |
| Machinery and equipment | 1,840 |  |  | 1,760 |  |
|  | 2,415 |  |  | 2,364 |  |
| Less accumulated depreciation | (1,733 | ) |  | (1,669 | ) |
|  | $ | 682 |  |  | $ | 695 |  |

[0000068505-14-000010:notes:34]
Depreciation expense for the three months ended June 28, 2014 and June 29, 2013 was $45 million and $40 million, respectively. Depreciation expense for the six months ended June 28, 2014 and June 29, 2013 was $84 million and $75 million, respectively.

[0000068505-14-000010:notes:35]
[same as prior period, unchanged from 0000068505-14-000008:notes:35]

[0000068505-14-000010:notes:36]
[same as prior period, unchanged from 0000068505-14-000008:notes:36]

[0000068505-14-000010:notes:37]
|  | June 28, 2014 |  | December 31, 2013 |
| Intangible assets, net | $ | 24 |  |  | $ | 6 |  |
| Long-term receivables | 18 |  |  | 1 |  |
| Other | 86 |  |  | 82 |  |
|  | $ | 128 |  |  | $ | 89 |  |

[0000068505-14-000010:notes:38]
[same as prior period, unchanged from 0000068505-14-000008:notes:38]

[0000068505-14-000010:notes:39]
[same as prior period, unchanged from 0000068505-14-000008:notes:39]

[0000068505-14-000010:notes:40]
|  | June 28, 2014 |  | December 31, 2013 |
| Deferred revenue | $ | 333 |  |  | $ | 359 |  |
| Compensation | 212 |  |  | 315 |  |
| Billings in excess of costs and earnings | 354 |  |  | 295 |  |
| Tax liabilities | 76 |  |  | 85 |  |
| Customer reserves | 44 |  |  | 52 |  |
| Dividend payable | 78 |  |  | 79 |  |
| Other | 518 |  |  | 578 |  |
|  | $ | 1,615 |  |  | $ | 1,763 |  |

[0000068505-14-000010:notes:41]
[same as prior period, unchanged from 0000068505-14-000008:notes:41]

[0000068505-14-000010:notes:42]
[same as prior period, unchanged from 0000068505-14-000008:notes:42]

[0000068505-14-000010:notes:43]
|  | June 28, 2014 |  | December 31, 2013 |
| Defined benefit plans, including split dollar life insurance arrangements | $ | 1,654 |  |  | $ | 1,751 |  |
| Postretirement health care benefit plan | 118 |  |  | 118 |  |
| Deferred revenue | 150 |  |  | 162 |  |
| Unrecognized tax benefits | 57 |  |  | 99 |  |
| Other | 172 |  |  | 184 |  |
|  | $ | 2,151 |  |  | $ | 2,314 |  |

[0000068505-14-000010:notes:44]
[same as prior period, unchanged from 0000068505-14-000008:notes:44]

[0000068505-14-000010:notes:45]
Share Repurchase Program:   The Company paid an aggregate of $416 million during the second quarter of 2014, including transaction costs, to repurchase approximately 6.2 million shares at an average price of $66.96 per share. The Company paid an aggregate of $473 million during the first half of 2014, including transaction costs, to repurchase approximately 7.1 million shares at an average price of $66.88 per share. As of June 28, 2014, the Company had used approximately $5.7 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.3 billion of authority available for future repurchases.

[0000068505-14-000010:notes:46]
Payment of Dividends:  During the three months ended June 28, 2014 and June 29, 2013, the Company paid $79 million and $71 million, respectively, in cash dividends to holders of its common stock. During the six months ended June 28, 2014 and June 29, 2013, the Company paid $158 million and $143 million, respectively, in cash dividends to holders of its common stock.

[0000068505-14-000010:notes:47]
On July 31, 2014, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.31 per share to $0.34 per share of common stock.

[0000068505-14-000010:notes:48]
[same as prior period, unchanged from 0000068505-14-000008:notes:47]

[0000068505-14-000010:notes:49]
The following table displays the changes in Accumulated other comprehensive loss, net of tax, by component from January 1, 2014 to June 28, 2014:

[0000068505-14-000010:notes:50]
|  | Gains and Losses on Cash Flow Hedges |  | Unrealized Gains and Losses on Available-for-Sale Securities |  | Retirement Benefit Items |  | Foreign Currency Translation Adjustments |  | Total |
| Balance as of January 1, 2014 | $ | (1 | ) |  | $ | (2 | ) |  | $ | (2,188 | ) |  | $ | (96 | ) |  | $ | (2,287 | ) |
| Other comprehensive income before reclassifications | — |  |  | 2 |  |  | — |  |  | 15 |  |  | 17 |  |
| Amounts reclassified from accumulated other comprehensive loss | 1 |  |  | — |  |  | 24 |  |  | — |  |  | 25 |  |
| Current period change in Other comprehensive income | 1 |  |  | 2 |  |  | 24 |  |  | 15 |  |  | 42 |  |
| Balance as of June 28, 2014 | $ | — |  |  | $ | — |  |  | $ | (2,164 | ) |  | $ | (81 | ) |  | $ | (2,245 | ) |

[0000068505-14-000010:notes:51]
The following table displays the amounts reclassified from Accumulated other comprehensive loss and the affected line items in the condensed consolidated statement of operations during the three and six months ended June 28, 2014 and June 29, 2013:

[0000068505-14-000010:notes:52]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |  |  |
| Loss (gain) on cash flow hedges: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | (1 | ) |  | Cost of sales |
|  | 1 |  |  | — |  |  | 1 |  |  | (1 | ) |  | Net of tax |
| Amortization of retirement benefit items: |  |  |  |  |  |  |  |  |  |
| Prior service costs | $ | (9 | ) |  | (14 | ) |  | $ | (18 | ) |  | $ | (25 | ) |  | Selling, general, and administrative expenses |
| Actuarial net losses | 25 |  |  | 40 |  |  | 53 |  |  | 79 |  |  | Selling, general, and administrative expenses |
|  | 16 |  |  | 26 |  |  | 35 |  |  | 54 |  |  | Total before tax |
|  | (5 | ) |  | (10 | ) |  | (11 | ) |  | (19 | ) |  | Tax benefit |
|  | $ | 11 |  |  | $ | 16 |  |  | $ | 24 |  |  | $ | 35 |  |  | Net of tax |
| Total reclassifications for the period, net of tax | $ | 12 |  |  | $ | 16 |  |  | $ | 25 |  |  | $ | 34 |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-14-000010:notes:53]
Commitments and Contingencies

[0000068505-14-000010:notes:54]
Legal Matters

[0000068505-14-000010:notes:55]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company’s results of operations in the periods in which the matters are ultimately resolved.

[0000068505-14-000010:notes:56]
Other Indemnifications

[0000068505-14-000010:notes:57]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters.  In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims.  In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-14-000010:notes:58]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements.  Historically, the Company has not made significant payments under these agreements.

[0000068505-14-000010:notes:59]
Also, pursuant to the Master Separation and Distribution Agreement and certain other agreements entered into in connection with the separating of Motorola Mobility Holdings, Inc. ("Motorola Mobility"),  Motorola Mobility agreed to indemnify the Company for certain liabilities, and the Company agreed to indemnify Motorola Mobility for certain liabilities, in each case for uncapped amounts.


## us-gaap:DebtDisclosureTextBlock

[0000068505-14-000010:notes:60]
Debt and Credit Facilities

[0000068505-14-000010:notes:61]
As of June 28, 2014, the Company had a $2.0 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. Effective May 29, 2014, this facility replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) which was scheduled to mature on June 30, 2014. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company is no longer subject to a minimum interest coverage covenant under the new facility. The Company was in compliance with its financial covenants as of June 28, 2014. The Company did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the three and six months ended June 28, 2014.

[0000068505-14-000010:notes:62]
As of June 28, 2014, the Company had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of June 28, 2014.

[0000068505-14-000010:notes:63]
During the first quarter of 2013, the Company issued an aggregate face principal amount of $600 million of 3.500% Senior Notes due 2023, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds from issuance of this debt of $588 million.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-14-000010:notes:64]
[same as prior period, unchanged from 0000068505-14-000008:notes:62]

[0000068505-14-000010:notes:65]
[same as prior period, unchanged from 0000068505-14-000008:notes:63]

[0000068505-14-000010:notes:66]
At June 28, 2014, the Company had outstanding foreign exchange contracts with notional amounts totaling $867 million, compared to $837 million outstanding at December 31, 2013.  The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions, except for the ineffective portion of the instruments, which are charged to Other within Other income (expense) in the Company’s condensed consolidated statements of operations.

[0000068505-14-000010:notes:67]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of June 28, 2014, and the corresponding positions as of December 31, 2013:

[0000068505-14-000010:notes:68]
|  | Notional Amount |
| Net Buy (Sell) by Currency | June 28, 2014 |  | December 31, 2013 |
| British Pound | $ | 243 |  |  | $ | 257 |  |
| Chinese Renminbi | (184 | ) |  | (181 | ) |
| Euro | 146 |  |  | (132 | ) |
| Norwegian Krone | (120 | ) |  | (95 | ) |
| Brazilian Real | (54 | ) |  | (44 | ) |

[0000068505-14-000010:notes:69]
[same as prior period, unchanged from 0000068505-14-000008:notes:67]

[0000068505-14-000010:notes:70]
At June 28, 2014, the Company had $2.5 billion of long-term debt, including the current portion, which is primarily priced at long-term, fixed interest rates.

[0000068505-14-000010:notes:71]
As part of its liability management program, one of the Company’s European subsidiaries has outstanding interest rate agreements (“Interest Agreements”) relating to Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Interest Agreements change the characteristics of interest payments from variable to maximum fixed-rate payments. The Interest Agreements are not accounted for as a part of a hedging relationship and, accordingly, the changes in the fair value of the Interest Agreements are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the Interest Agreements was in a liability position of $3 million at June 28, 2014 and  December 31, 2013.

[0000068505-14-000010:notes:72]
[same as prior period, unchanged from 0000068505-14-000008:notes:70]

[0000068505-14-000010:notes:73]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of June 28, 2014, all of the counterparties have investment grade credit ratings. As of June 28, 2014, the Company had no exposure to aggregate net credit risk with all counterparties.

[0000068505-14-000010:notes:74]
The following tables summarize the fair values and location in the condensed consolidated balance sheets of all derivative financial instruments held by the Company at June 28, 2014 and December 31, 2013:

[0000068505-14-000010:notes:75]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| June 28, 2014 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | Other assets |  | $ | 3 |  |  | Other liabilities |
| Interest agreements | — |  |  | Other assets |  | 3 |  |  | Other liabilities |
| Total derivatives | $ | 1 |  |  |  |  | $ | 6 |  |  |  |

[0000068505-14-000010:notes:76]
[same as prior period, unchanged from 0000068505-14-000008:notes:74]

[0000068505-14-000010:notes:77]
The following table summarizes the effect of derivative instruments in the Company's condensed consolidated statements of operations for the three and six months ended June 28, 2014 and June 29, 2013:

[0000068505-14-000010:notes:78]
|  | Three Months Ended |  | Six Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Interest rate contracts | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | Other income (expense) |
| Foreign exchange contracts | (1 | ) |  | 8 |  |  | (2 | ) |  | (9 | ) |  | Other income (expense) |
| Total derivatives not designated as hedging instruments | $ | (1 | ) |  | $ | 9 |  |  | $ | (2 | ) |  | $ | (8 | ) |  |  |

[0000068505-14-000010:notes:79]
The following table summarizes the gains and losses reclassified from Accumulated other comprehensive loss into Net earnings during the three and six months ended June 28, 2014 and June 29, 2013:

[0000068505-14-000010:notes:80]
|  | Three Months Ended |  | Six Months Ended |  | Financial StatementLocation |
| Foreign Exchange Contracts | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |  |
| Derivatives in cash flow hedging relationships: |  |  |  |  |  |  |  |  |  |
| Gains (losses) reclassified from Accumulated other comprehensive loss into Net earnings | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |  | $ | 1 |  |  | Costs of sales |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-14-000010:notes:81]
[same as prior period, unchanged from 0000068505-14-000008:notes:79]

[0000068505-14-000010:notes:82]
[same as prior period, unchanged from 0000068505-14-000008:notes:80]

[0000068505-14-000010:notes:83]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 3 |  |  | $ | 4 |  |  | $ | 7 |  |  | $ | 8 |  |
| Selling, general and administrative expenses | 16 |  |  | 16 |  |  | 33 |  |  | 38 |  |
| Research and development expenditures | 7 |  |  | 7 |  |  | 14 |  |  | 16 |  |
| Share-based compensation expense included in Operating earnings | 26 |  |  | 27 |  |  | 54 |  |  | 62 |  |
| Tax benefit | 8 |  |  | 8 |  |  | 17 |  |  | 19 |  |
| Share-based compensation expense, net of tax | $ | 18 |  |  | $ | 19 |  |  | $ | 37 |  |  | $ | 43 |  |
| Decrease in basic earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |  | $ | (0.15 | ) |  | $ | (0.16 | ) |
| Decrease in diluted earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |  | $ | (0.14 | ) |  | $ | (0.15 | ) |
| Share-based compensation expense in discontinued operations | $ | 5 |  |  | $ | 7 |  |  | $ | 13 |  |  | $ | 17 |  |

[0000068505-14-000010:notes:84]
For the six months ended June 28, 2014, the Company granted 1.2 million RSUs and 1.2 million stock options.  The total aggregate compensation expense, net of estimated forfeitures, for these RSUs and stock options, including those awards granted to employees of the Enterprise business, was $63 million and $15 million, respectively, which will be recognized over a weighted average vesting period of three years.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-14-000010:notes:85]
Discontinued Operations

[0000068505-14-000010:notes:86]
On April 14, 2014, the Company entered into a Master Acquisition Agreement (the “Acquisition Agreement”) with Zebra Technologies Corporation to sell the Company’s Enterprise business for $3.45 billion in cash. Certain assets of the Enterprise business will be excluded from the transaction and retained by the Company, including the Company’s iDEN business, and other assets and certain liabilities as specified in the Acquisition Agreement. The transaction is expected to close by the end of 2014. The historical financial results of the Enterprise business, excluding those assets and liabilities retained in the transaction, are reflected in the Company's condensed consolidated financial statements and footnotes as discontinued operations for all periods presented.

[0000068505-14-000010:notes:87]
The following table displays summarized activity in the Company's condensed consolidated statements of operations for discontinued operations during the three and six months ended June 28, 2014 and June 29, 2013:

[0000068505-14-000010:notes:88]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Net sales | $ | 560 |  |  | $ | 610 |  |  | $ | 1,133 |  |  | $ | 1,187 |  |
| Operating earnings | 55 |  |  | 63 |  |  | 118 |  |  | 106 |  |
| Loss on sales of investments and businesses, net | (1 | ) |  | — |  |  | (1 | ) |  | — |  |
| Investment impairments | (3 | ) |  | (2 | ) |  | (3 | ) |  | (2 | ) |
| Earnings before income taxes | 50 |  |  | 57 |  |  | 112 |  |  | 106 |  |
| Income tax expense (benefit) | (696 | ) |  | 22 |  |  | (676 | ) |  | 36 |  |
| Earnings from discontinued operations, net of tax | $ | 746 |  |  | $ | 35 |  |  | $ | 788 |  |  | $ | 70 |  |

[0000068505-14-000010:notes:89]
During the three months ended June 28, 2014, the Company recorded a $721 million tax benefit to establish a deferred tax asset associated with an outside basis difference which we now expect to realize in the foreseeable future. The tax benefit represents the excess of the tax basis of our investment in the Enterprise subsidiaries over the financial statement carrying value (the deductible outside basis difference).

[0000068505-14-000010:notes:90]
The following table displays a summary of the assets and liabilities held for sale as of June 28, 2014 and December 31, 2013:

[0000068505-14-000010:notes:91]
|  | June 28, 2014 |  | December 31, 2013 |
| Assets: |  |  |  |
| Accounts receivable, net | $ | 468 |  |  | $ | 551 |  |
| Inventories, net | 215 |  |  | 175 |  |
| Deferred income taxes | 225 |  |  | 219 |  |
| Other current assets | 132 |  |  | 134 |  |
| Property, plant and equipment, net | 94 |  |  | 115 |  |
| Investments | 20 |  |  | 19 |  |
| Goodwill | 1,151 |  |  | 1,149 |  |
| Other assets | 102 |  |  | 95 |  |
|  | $ | 2,407 |  |  | $ | 2,457 |  |
| Liabilities: |  |  |  |
| Accounts payable | $ | 196 |  |  | $ | 231 |  |
| Accrued liabilities | 656 |  |  | 639 |  |
| Other liabilities | 178 |  |  | 171 |  |
|  | $ | 1,030 |  |  | $ | 1,041 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-14-000010:notes:92]
[same as prior period, unchanged from 0000068505-14-000008:notes:83]

[0000068505-14-000010:notes:93]
[same as prior period, unchanged from 0000068505-14-000008:notes:84]

[0000068505-14-000010:notes:94]
[same as prior period, unchanged from 0000068505-14-000008:notes:85]

[0000068505-14-000010:notes:95]
[same as prior period, unchanged from 0000068505-14-000008:notes:86]

[0000068505-14-000010:notes:96]
[same as prior period, unchanged from 0000068505-14-000008:notes:87]

[0000068505-14-000010:notes:97]
[same as prior period, unchanged from 0000068505-14-000008:notes:88]

[0000068505-14-000010:notes:98]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of June 28, 2014 and December 31, 2013 were as follows:

[0000068505-14-000010:notes:99]
| June 28, 2014 | Level 2 |
| Assets: |  |
| Foreign exchange derivative contracts | $ | 1 |  |
| Available-for-sale securities: |  |
| Government, agency, and government-sponsored enterprise obligations | 15 |  |
| Corporate bonds | 8 |  |
| Mutual funds | 11 |  |
| Liabilities: |  |
| Foreign exchange derivative contracts | $ | 3 |  |
| Interest agreement derivative contracts | 3 |  |

[0000068505-14-000010:notes:100]
[same as prior period, unchanged from 0000068505-14-000008:notes:91]

[0000068505-14-000010:notes:101]
The Company had no Level 3 holdings as of June 28, 2014 or December 31, 2013.

[0000068505-14-000010:notes:102]
At June 28, 2014 and December 31, 2013, the Company had $1.8 billion and $2.1 billion, respectively, of investments in money market mutual funds (Level 2) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-14-000010:notes:103]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at June 28, 2014 was $2.6 billion (Level 2), as compared to the instruments' face value of $2.5 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-14-000010:notes:104]
[same as prior period, unchanged from 0000068505-14-000008:notes:95]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-14-000010:notes:105]
[same as prior period, unchanged from 0000068505-14-000008:notes:96]

[0000068505-14-000010:notes:106]
[same as prior period, unchanged from 0000068505-14-000008:notes:97]

[0000068505-14-000010:notes:107]
[same as prior period, unchanged from 0000068505-14-000008:notes:98]

[0000068505-14-000010:notes:108]
|  | June 28, 2014 |  | December 31, 2013 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 35 |  |  | $ | 25 |  |  | $ | 24 |  |  | $ | 24 |  |
| Patents | 8 |  |  | 4 |  |  | 8 |  |  | 3 |  |
| Customer-related | 13 |  |  | 6 |  |  | 6 |  |  | 6 |  |
| Other intangibles | 17 |  |  | 14 |  |  | 15 |  |  | 14 |  |
|  | $ | 73 |  |  | $ | 49 |  |  | $ | 53 |  |  | $ | 47 |  |

[0000068505-14-000010:notes:109]
Amortization expense on intangible assets was $1 million for the three months ended June 28, 2014 and $2 million for the six months ended June 28, 2014.  There was no amortization expense incurred during the three or six months ended June 29, 2013.  As of June 28, 2014, annual amortization expense is estimated to be $4 million in 2014, 2015, and 2016, and $3 million in 2017 and 2018.

[0000068505-14-000010:notes:110]
[same as prior period, unchanged from 0000068505-14-000008:notes:101]

[0000068505-14-000010:notes:111]
|  | June 28, 2014 |  | December 31, 2013 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 70 |  |  | $ | 49 |  |  | $ | 53 |  |  | $ | 47 |  |
| Services | 3 |  |  | — |  |  | — |  |  | — |  |
|  | $ | 73 |  |  | $ | 49 |  |  | $ | 53 |  |  | $ | 47 |  |

[0000068505-14-000010:notes:112]
[same as prior period, unchanged from 0000068505-14-000008:notes:103]

[0000068505-14-000010:notes:113]
During the second quarter of 2014 as a result of the reclassification of the Enterprise business to discontinued operations, the Company determined the reportable segments and reporting units of its continuing operations. The Company now has two segments, Products and Services, which are the same as its reporting units. The Company's goodwill was allocated to its new reporting units based on their relative fair values. In conjunction with the reporting unit change in the second quarter of 2014, the Company evaluated its goodwill for impairment concluding it is more-likely-than-not that the fair values of each of its reporting units exceed their respective carrying values.  As such, a goodwill impairment was not recorded.

[0000068505-14-000010:notes:114]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2014 to June 28, 2014:

[0000068505-14-000010:notes:115]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2014 |  |  |  |  |  |
| Aggregate goodwill | $ | 249 |  |  | $ | 112 |  |  | $ | 361 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 249 |  |  | $ | 112 |  |  | $ | 361 |  |
| Goodwill acquired | 15 |  |  | 7 |  |  | 22 |  |
| Balance as of June 28, 2014 |  |  |  |  |  |
| Aggregate goodwill | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |

[0000068505-14-000010:notes:116]
On December 31, 2013, the Company completed the acquisition of a communications software provider in push-to-talk-over-broadband applications for a gross purchase price of $48 million. During the six months ended June 28, 2014, the Company completed the purchase accounting for this acquisition, recognizing $22 million of goodwill and $20 million of identifiable intangible assets. The results of operations for this acquisition have been included in the Company’s condensed consolidated statement of operations subsequent to the acquisition date. The pro forma effects of this acquisition were not significant.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-14-000010:notes:117]
[same as prior period, unchanged from 0000068505-14-000008:notes:107]

[0000068505-14-000010:notes:118]
During the three months ended June 28, 2014, the Company increased current deferred tax assets by $721 million related to an outside basis difference.  The outside basis difference represents the excess of the tax basis of our investment in the Enterprise subsidiaries over the financial statement carrying value (the deductible outside basis difference).

[0000068505-14-000010:notes:119]
At June 28, 2014 and December 31, 2013, the Company had valuation allowances of $212 million and $200 million, respectively, including $179 million and $178 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries.  The Company believes the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-14-000010:notes:120]
Undistributed earnings the Company intends to reinvest indefinitely, and for which no income taxes have been provided, aggregate to $1.4 billion at June 28, 2014 and December 31, 2013. The Company currently has no plans to repatriate the foreign earnings permanently reinvested and therefore, the time and manner of repatriation is uncertain. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-14-000010:notes:121]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and, except for certain earnings the Company intends to reinvest indefinitely, accrues for the U.S. federal and foreign tax applicable to the earnings.  During the first quarter of 2013, the Company reassessed its unremitted earnings position and concluded that certain of its non-U.S. subsidiaries' earnings were permanently reinvested overseas. The Company intends to utilize the offshore earnings to fund foreign investments, such as potential acquisitions and capital expenditures.  In the first quarter of 2013, the Company recorded a net tax benefit of $25 million related to reversals of deferred tax liabilities for undistributed foreign earnings due to the change in permanent reinvestment assertion.

[0000068505-14-000010:notes:122]
As of June 28, 2014, the Company has approximately $650 million of foreign earnings not considered permanently reinvested and which may be repatriated without an additional tax charge, given the U.S. federal and foreign tax accrued on undistributed earnings and the utilization of available foreign tax credits.

[0000068505-14-000010:notes:123]
The Company had unrecognized tax benefits of $120 million and $147 million at June 28, 2014 and December 31, 2013, respectively, of which $99 million and $125 million, respectively, if recognized, would affect the effective tax rate, net of resulting changes to valuation allowances.  During the six months ended June 28, 2014, the Company adjusted its unrecognized tax benefits for prior year tax positions for facts that now indicate the extent to which certain tax positions are more-likely-than-not of being sustained.  As a result, the Company recorded a gross increase of $24 million and a gross decrease of $51 million to unrecognized tax benefits for prior year tax positions resulting in a net tax benefit of $27 million.

[0000068505-14-000010:notes:124]
[same as prior period, unchanged from 0000068505-14-000008:notes:113]

[0000068505-14-000010:notes:125]
[same as prior period, unchanged from 0000068505-14-000008:notes:114]


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-14-000010:notes:126]
[same as prior period, unchanged from 0000068505-14-000008:notes:115]

[0000068505-14-000010:notes:127]
The condensed consolidated financial statements as of June 28, 2014 and for the three and six months ended June 28, 2014 and June 29, 2013, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-14-000010:notes:128]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2013.  The results of operations for the three and six months ended June 28, 2014 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-14-000010:notes:129]
[same as prior period, unchanged from 0000068505-14-000008:notes:118]

[0000068505-14-000010:notes:130]
[same as prior period, unchanged from 0000068505-14-000008:notes:119]

[0000068505-14-000010:notes:131]
In January 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for the Company beginning January 1, 2015. The Company is currently assessing the impact of this standard on its consolidated financial statements and footnote disclosures.

[0000068505-14-000010:notes:132]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. The ASU will be effective for the Company beginning January 1, 2017, and allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.


## us-gaap:PastDueFinancingReceivablesTableTextBlock

[0000068505-14-000010:notes:133]
An aging analysis of financing receivables at June 28, 2014 and December 31, 2013 is as follows:

[0000068505-14-000010:notes:134]
| June 28, 2014 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 36 |  |  | 1 |  |  | 2 |  |  | 12 |  |
| Total gross long-term receivables, including current portion | $ | 37 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 12 |  |

[0000068505-14-000010:notes:135]
| December 31, 2013 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 26 |  |  | 10 |  |  | 2 |  |  | 10 |  |
| Total gross long-term receivables, including current portion | $ | 27 |  |  | $ | 10 |  |  | $ | 2 |  |  | $ | 10 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-14-000010:notes:136]
[same as prior period, unchanged from 0000068505-14-000008:notes:124]

[0000068505-14-000010:notes:137]
[same as prior period, unchanged from 0000068505-14-000008:notes:125]

[0000068505-14-000010:notes:138]
The net periodic costs (benefits) for Pension and Postretirement Health Care Benefits plans were as follows:

[0000068505-14-000010:notes:139]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | — |  |
| Interest cost | 93 |  |  | 88 |  |  | 20 |  |  | 16 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets | (98 | ) |  | (90 | ) |  | (23 | ) |  | (18 | ) |  | (2 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 21 |  |  | 33 |  |  | 3 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | 2 |  |  | (2 | ) |  | (11 | ) |  | (11 | ) |
| Net periodic pension cost (benefit) | $ | 16 |  |  | $ | 31 |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | (6 | ) |  | $ | (8 | ) |

[0000068505-14-000010:notes:140]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 7 |  |  | $ | 6 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 185 |  |  | 176 |  |  | 40 |  |  | 33 |  |  | 6 |  |  | 6 |  |
| Expected return on plan assets | (196 | ) |  | (182 | ) |  | (45 | ) |  | (37 | ) |  | (5 | ) |  | (5 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 44 |  |  | 66 |  |  | 6 |  |  | 6 |  |  | 6 |  |  | 7 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | 3 |  |  | (4 | ) |  | (21 | ) |  | (22 | ) |
| Net periodic pension cost (benefit) | $ | 33 |  |  | $ | 60 |  |  | $ | 11 |  |  | $ | 4 |  |  | $ | (13 | ) |  | $ | (13 | ) |

[0000068505-14-000010:notes:141]
During the three months ended June 28, 2014 and June 29, 2013, contributions of $40 million and $26 million were made to the Company’s U.S. Pension Benefit Plans, respectively.  During both the three months ended June 28, 2014 and June 29, 2013, contributions of $3 million were made to the Company’s Non U.S. Pension Benefit Plans.

[0000068505-14-000010:notes:142]
During the six months ended June 28, 2014 and June 29, 2013, contributions of $66 million and $50 million were made to the Company’s U.S. Pension Benefit Plans, respectively.  During the six months ended June 28, 2014 and June 29, 2013, contributions of $20 million and $17 million were made to the Company’s Non U.S. Pension Benefit Plans, respectively.

[0000068505-14-000010:notes:143]
The Company made no contributions to its Postretirement Health Care Benefits Plan during the three and six months ended June 28, 2014 and June 29, 2013.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-14-000010:notes:144]
[same as prior period, unchanged from 0000068505-14-000008:notes:130]

[0000068505-14-000010:notes:145]
[same as prior period, unchanged from 0000068505-14-000008:notes:131]

[0000068505-14-000010:notes:146]
During the three months ended June 28, 2014, the Company recorded net reorganization of business charges of $28 million including $25 million of charges in Other charges, and $3 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. The $28 million of charges were all related to employee separation costs.

[0000068505-14-000010:notes:147]
During the six months ended June 28, 2014, the Company recorded net reorganization of business charges of $38 million including $34 million of charges in Other charges, and $4 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $38 million were charges of $34 million for employee separation costs and $4 million for exit costs.

[0000068505-14-000010:notes:148]
[same as prior period, unchanged from 0000068505-14-000008:notes:133]

[0000068505-14-000010:notes:149]
| June 28, 2014 | Three Months Ended |  | Six Months Ended |
| Products | $ | 18 |  |  | $ | 24 |  |
| Services | 10 |  |  | 14 |  |
|  | $ | 28 |  |  | $ | 38 |  |

[0000068505-14-000010:notes:150]
The following table displays a rollforward of the reorganization of businesses accruals established for lease exit costs and employee separation costs, including those related to discontinued operations which will be maintained by the Company after the sale of the Enterprise business, from January 1, 2014 to June 28, 2014:

[0000068505-14-000010:notes:151]
|  | January 1, 2014 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | June 28, 2014 |
| Exit costs | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |  | $ | (5 | ) |  | $ | 7 |  |
| Employee separation costs | 103 |  |  | 47 |  |  | (2 | ) |  | (70 | ) |  | 78 |  |
|  | $ | 109 |  |  | $ | 53 |  |  | $ | (2 | ) |  | $ | (75 | ) |  | $ | 85 |  |

[0000068505-14-000010:notes:152]
[same as prior period, unchanged from 0000068505-14-000008:notes:137]

[0000068505-14-000010:notes:153]
At January 1, 2014, the Company had an accrual of $6 million for exit costs attributable to lease terminations. During the six months ended June 28, 2014, there were $6 million of additional charges and $5 million of cash payments related to the exit of leased facilities. The remaining accrual of $7 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at June 28, 2014, primarily represents future cash payments for lease termination obligations that are expected to be paid over a number of years.

[0000068505-14-000010:notes:154]
[same as prior period, unchanged from 0000068505-14-000008:notes:139]

[0000068505-14-000010:notes:155]
At January 1, 2014, the Company had an accrual of $103 million for employee separation costs. The 2014 additional charges of $47 million represent severance costs for approximately 600 employees, all of which were indirect employees. The adjustment of $2 million reflects reversals of accruals no longer needed. The $70 million used reflects cash payments, including $25 million related to employees of discontinued operations. The remaining accrual of $78 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at June 28, 2014, is expected to be paid, primarily within one year, to approximately 750 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-14-000010:notes:156]
[same as prior period, unchanged from 0000068505-14-000008:notes:141]

[0000068505-14-000010:notes:157]
During the three months ended June 29, 2013, the Company recorded net reorganization of business charges of $18 million, including $13 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the aggregate $18 million were charges of $19 million related to employee separation costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-14-000010:notes:158]
During the six months ended June 29, 2013, the Company recorded net reorganization of business charges of $25 million, including $20 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the aggregate $25 million were charges of $29 million related to employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-14-000010:notes:159]
| June 29, 2013 | Three Months Ended |  | Six Months Ended |
| Products | $ | 12 |  |  | $ | 17 |  |
| Services | 6 |  |  | 8 |  |
|  | $ | 18 |  |  | $ | 25 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-14-000010:notes:160]
[same as prior period, unchanged from 0000068505-14-000008:notes:144]

[0000068505-14-000010:notes:161]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Products | $ | 887 |  |  | $ | 986 |  |  | $ | 1,640 |  |  | $ | 1,899 |  |
| Services | 506 |  |  | 511 |  |  | 982 |  |  | 994 |  |
|  | $ | 1,393 |  |  | $ | 1,497 |  |  | $ | 2,622 |  |  | $ | 2,893 |  |

[0000068505-14-000010:notes:162]
[same as prior period, unchanged from 0000068505-14-000008:notes:146]

[0000068505-14-000010:notes:163]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Products | $ | 95 |  |  | $ | 125 |  |  | $ | 134 |  |  | $ | 231 |  |
| Services | 43 |  |  | 78 |  |  | 111 |  |  | 145 |  |
| Operating earnings | 138 |  |  | 203 |  |  | 245 |  |  | 376 |  |
| Total other expense | (40 | ) |  | (35 | ) |  | (59 | ) |  | (53 | ) |
| Earnings from continuing operations before income taxes | $ | 98 |  |  | $ | 168 |  |  | $ | 186 |  |  | $ | 323 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-14-000010:notes:164]
[same as prior period, unchanged from 0000068505-14-000008:notes:148]

[0000068505-14-000010:notes:165]
As a result of the reclassification of the Enterprise business to discontinued operations beginning in the second quarter of 2014, the Company has the following two segments:

[0000068505-14-000010:notes:166]
Products: The Products segment offers an extensive portfolio of network infrastructure, devices, system software and applications for the public safety, hospitality, education, manufacturing, transportation, utilities, mining and retail industries, including: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) integrated digital enhanced network (“iDEN”) products, and (v) broadband technology products, such as Long-Term Evolution (“LTE”). In addition, the Products segment offers smart public safety solutions including computer-aided dispatch, records systems, data management systems and Real Time Crime Center solutions.

[0000068505-14-000010:notes:167]
Services: The Services segment has a full breadth of service offerings for both public safety and private communication networks including: (i) Integration services, (ii) Lifecycle Management and Support services, (iii) Managed services, and (iv) Solutions services. Integration services includes implementation, optimization, and integration of networks, devices, and applications.  Lifecycle Management and Support services includes lifecycle planning, upgrades, call center, network monitoring, and repair services.  Managed services includes managing customer networks at defined services levels. Solutions services includes integration of hardware and software to meet customer needs.


## msi:LongTermCustomerFinancingAndSalesOfReceivablesTextBlock

[0000068505-14-000010:notes:168]
[same as prior period, unchanged from 0000068505-14-000008:notes:151]

[0000068505-14-000010:notes:169]
[same as prior period, unchanged from 0000068505-14-000008:notes:152]

[0000068505-14-000010:notes:170]
[same as prior period, unchanged from 0000068505-14-000008:notes:153]

[0000068505-14-000010:notes:171]
|  | June 28, 2014 |  | December 31, 2013 |
| Long-term receivables | $ | 37 |  |  | $ | 27 |  |
| Less current portion | (19 | ) |  | (26 | ) |
| Non-current long-term receivables, net | $ | 18 |  |  | $ | 1 |  |

[0000068505-14-000010:notes:172]
[same as prior period, unchanged from 0000068505-14-000008:notes:155]

[0000068505-14-000010:notes:173]
Certain purchasers of the Company’s products and services may request that the Company provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company’s obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser’s credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company.  The Company had outstanding commitments to provide long-term financing to third parties totaling $166 million at June 28, 2014, compared to $50 million at December 31, 2013.

[0000068505-14-000010:notes:174]
[same as prior period, unchanged from 0000068505-14-000008:notes:157]

[0000068505-14-000010:notes:175]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended June 28, 2014 and June 29, 2013:

[0000068505-14-000010:notes:176]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Cumulative annual proceeds received from sales: |  |  |  |  |  |  |  |
| Accounts receivable sales proceeds | $ | 26 |  |  | $ | 2 |  |  | $ | 33 |  |  | $ | 3 |  |
| Long-term receivables sales proceeds | 52 |  |  | 25 |  |  | 52 |  |  | 52 |  |
| Total proceeds from receivable sales | $ | 78 |  |  | $ | 27 |  |  | $ | 85 |  |  | $ | 55 |  |

[0000068505-14-000010:notes:177]
At June 28, 2014, the Company had retained servicing obligations for $460 million of long-term receivables, compared to $434 million of long-term receivables at December 31, 2013.  Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-14-000010:notes:178]
[same as prior period, unchanged from 0000068505-14-000008:notes:161]

[0000068505-14-000010:notes:179]
The Company had a total of $12 million of financing receivables past due over 90 days as of June 28, 2014 in relation to two loans. The Company has not accrued interest on these loans, which are adequately reserved, during the three and six months ended June 28, 2014.
