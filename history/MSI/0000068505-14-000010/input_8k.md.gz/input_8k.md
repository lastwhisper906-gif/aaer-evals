# MSI 8-K — 0001193125-14-294493 filed 2014-08-05

## item codes, every 8-K on or before 2014-08-05

- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2014-08-05

- none on or before 2014-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-294493:8k_2_02:1]
EX-99.1
2
d767855dex991.htm
EX-99.1

[0001193125-14-294493:8k_2_02:2]
EX-99.1

[0001193125-14-294493:8k_2_02:3]
Exhibit 99.1

[0001193125-14-294493:8k_2_02:4]
Motorola Solutions Reports Second-Quarter 2014

[0001193125-14-294493:8k_2_02:5]
Financial Results

[0001193125-14-294493:8k_2_02:6]
|  | • |  | Sales of $1.4 billion, down 7 percent from a year ago |

[0001193125-14-294493:8k_2_02:7]
|  | • |  | GAAP earnings per share (EPS) from continuing operations* of $0.30 |

[0001193125-14-294493:8k_2_02:8]
|  | • |  | Non-GAAP** EPS from continuing operations of $0.47 |

[0001193125-14-294493:8k_2_02:9]
|  | • |  | Generated $118 million in operating cash flow |

[0001193125-14-294493:8k_2_02:10]
|  | • |  | Repurchased $416 million in shares; recently announced 10 percent increase to quarterly cash dividend |

[0001193125-14-294493:8k_2_02:11]
|  | • |  | Cost-reduction target increased from $200 million to approximately $300 million by end of 2015 |

[0001193125-14-294493:8k_2_02:12]
SCHAUMBURG,
Ill. – Aug. 5, 2014 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the second quarter of 2014. Click here for a printable news release and financial tables.

[0001193125-14-294493:8k_2_02:13]
Motorola Solutions’ Enterprise business now is reflected in discontinued operations for both the current quarter and prior periods due to its planned
divestiture by the end of 2014. All financials cited reflect the company’s ongoing operations, including iDEN, with its new reporting segments: Products and Services.

[0001193125-14-294493:8k_2_02:14]
REVENUE

[0001193125-14-294493:8k_2_02:15]
Sales declined 7 percent to $1.4 billion
primarily reflecting lower sales in North America state and local markets as well as in Asia Pacific & the Middle East. Europe & Africa and Latin America sales grew double-digits. Product sales declined 10 percent driven primarily
by lower subscriber and systems revenues, while Services declined 1 percent.

[0001193125-14-294493:8k_2_02:16]
SUPPORTING QUOTE

[0001193125-14-294493:8k_2_02:17]
“Second quarter results were in line with our expectations. Additionally, we made significant progress toward simplifying our operations and accelerating
our cost reduction efforts,” said Greg Brown, chairman and CEO, Motorola Solutions. “We believe our continued focus on execution, targeted investments and capital return positions us well to grow and create long-term value for our
shareholders.”

[0001193125-14-294493:8k_2_02:18]
KEY FINANCIAL RESULTS

[0001193125-14-294493:8k_2_02:19]
|  |  | Second Quarter |  |  | Change |  |
|  |  | 2014 |  |  | 2013 |  |  |
| Motorola Solutions, Inc. |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 1,393 |  |  | $ | 1,497 |  |  |  | -7 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings ($M) |  | $ | 138 |  |  | $ | 203 |  |  |  | -32 | % |
| Percent of sales |  |  | 9.9 | % |  |  | 13.6 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.30 |  |  | $ | 0.81 |  |  |  | -63 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings ($M) |  | $ | 201 |  |  | $ | 248 |  |  |  | -19 | % |
| Percent of sales |  |  | 14.4 | % |  |  | 16.6 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.47 |  |  | $ | 0.94 |  |  |  | -50 | % |

[0001193125-14-294493:8k_2_02:20]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 887 |  |  | $ | 986 |  |  |  | -10 | % |
| GAAP operating earnings ($M) |  | $ | 95 |  |  | $ | 125 |  |  |  | -24 | % |
| Percent of sales |  |  | 10.7 | % |  |  | 12.7 | % |  |  |  |  |
| Non-GAAP operating earnings ($M) |  | $ | 133 |  |  | $ | 154 |  |  |  | -14 | % |
| Percent of sales |  |  | 15.0 | % |  |  | 15.6 | % |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 506 |  |  | $ | 511 |  |  |  | -1 | % |
| GAAP operating earnings ($M) |  | $ | 43 |  |  | $ | 78 |  |  |  | -45 | % |
| Percent of sales |  |  | 8.5 | % |  |  | 15.3 | % |  |  |  |  |
| Non-GAAP operating earnings ($M) |  | $ | 68 |  |  | $ | 94 |  |  |  | -28 | % |
| Percent of sales |  |  | 13.4 | % |  |  | 18.4 | % |  |  |  |  |

[0001193125-14-294493:8k_2_02:21]
Non-GAAP financial information excludes after-tax charges of approximately $0.17 per diluted share related to share-based
compensation and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0001193125-14-294493:8k_2_02:22]
OTHER SELECTED FINANCIAL RESULTS

[0001193125-14-294493:8k_2_02:23]
|  | • |  | Operating margin — GAAP operating margin was 9.9 percent of sales; non-GAAP operating margin was 14.4 percent. These results include $49 million in lower operating expenses compared with the second quarter of 2013 primarily due to ongoing cost-reduction initiatives. In the second quarter, the company achieved $75 million in cost reductions. |

[0001193125-14-294493:8k_2_02:24]
|  | • |  | Taxes — The 2014 GAAP effective tax rate was 20 percent compared with a negative effective tax rate in the second quarter of 2013. The 2014 non-GAAP effective tax rate was 25 percent compared with a negative tax rate in the second quarter of 2013. The GAAP and non-GAAP effective tax rates in the second quarter of 2013 were favorably impacted by benefits largely associated with excess foreign tax credits on undistributed foreign earnings in that quarter. |

[0001193125-14-294493:8k_2_02:25]
|  | • |  | Cash flow — The company generated $118 million in operating cash flow from continuing operations during the quarter. This is a $140 million improvement from the second quarter of 2013 primarily driven by improved collections and other improvements in working capital accounts. |

[0001193125-14-294493:8k_2_02:26]
|  | • |  | Cash and cash equivalents — The company ended the quarter with cash and cash equivalents of $2.9 billion while returning $495 million to shareholders through share repurchases and cash dividends. The company repurchased $416 million of its common stock in the second quarter, reflecting only two months of repurchase. On July 31, the company announced it would increase its quarterly cash dividend by 10 percent to 34 cents per share. The next quarterly dividend will be payable in cash on Oct. 15, 2014, to stockholders of record at the close of business on Sept. 15, 2014. |

[0001193125-14-294493:8k_2_02:27]
KEY HIGHLIGHTS

[0001193125-14-294493:8k_2_02:28]
|  | • |  | Secured significant Product wins such as a $23 million contract with the Ecuador Ministry of Interior for its nationwide public safety system, a $10 million system contract with Denton County in Texas and a $10 million system contract with Marathon Galveston Bay Refinery |

[0001193125-14-294493:8k_2_02:29]
|  | • |  | Continued progress in Services with multiyear lifecycle support wins including a $19 million contract with Montgomery County in Maryland and a $19 million contract with Butler County in Ohio, as well as an $8 million multiyear managed services contract with Queensland Gas Company in Australia |

[0001193125-14-294493:8k_2_02:30]
|  | • |  | Launched the Intelligent Data Portal, which gives first responders in the field instant access to enhanced situational awareness through mobile apps |

[0001193125-14-294493:8k_2_02:31]
BUSINESS OUTLOOK***

[0001193125-14-294493:8k_2_02:32]
|  | • |  | Third quarter 2014 — Motorola Solutions expects a revenue decline of 7 to 9 percent compared with the third quarter of 2013, with non-GAAP earnings per share from continuing operations in the range of $0.35 to $0.41 per share. |

[0001193125-14-294493:8k_2_02:33]
|  | • |  | Full year 2014 — The company still expects a revenue decline of low- to mid- single digits, excluding IDEN, with non-GAAP operating margins from continuing operations of approximately 18.5 percent of sales, consistent with the previous outlook. |

[0001193125-14-294493:8k_2_02:34]
|  | • |  | The company has increased its target for cost reductions from $200 million to approximately $300 million by the end of 2015. This will result in a total reduction in operating expenses from $2 billion in 2013 to approximately $1.7 billion for 2015. |

[0001193125-14-294493:8k_2_02:35]
RESULTS FROM DISCONTINUED OPERATIONS

[0001193125-14-294493:8k_2_02:36]
On April 15, Motorola Solutions announced that it had entered into a definitive agreement to sell its Enterprise business to Zebra Technologies in a $3.45
billion all-cash transaction, subject to customary closing conditions. The Enterprise business is reflected as discontinued operations.

[0001193125-14-294493:8k_2_02:37]
Sales from
discontinued operations were $560 million in the second quarter of 2014 compared with $610 million in the year-ago quarter. The sales decline reflects some supply chain and IT execution issues related to transitioning business processes as well as
weaker demand in Asia.

[0001193125-14-294493:8k_2_02:38]
CONFERENCE CALL AND WEBCAST

[0001193125-14-294493:8k_2_02:39]
Motorola Solutions will host its quarterly conference call beginning at 7 a.m. U.S. Central Daylight Time (8 a.m. U.S. Eastern Daylight Time) Tuesday, Aug. 5.
The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-14-294493:8k_2_02:40]
CONSOLIDATED GAAP RESULTS

[0001193125-14-294493:8k_2_02:41]
A comparison of results from operations is as follows:

[0001193125-14-294493:8k_2_02:42]
|  |  | Second Quarter |  |
|  |  | 2014 |  |  | 2013 |  |
| Net sales ($M) |  | $ | 1,393 |  |  | $ | 1,497 |  |
| Gross margin ($M) |  |  | 656 |  |  |  | 750 |  |
| Operating earnings ($M) |  |  | 138 |  |  |  | 203 |  |
| Earnings from continuing operations ($M) |  |  | 78 |  |  |  | 223 |  |
| Diluted EPS from continuing operations |  | $ | 0.30 |  |  | $ | 0.81 |  |
| Weighted average diluted common shares outstanding |  |  | 256.2 |  |  |  | 274.7 |  |

[0001193125-14-294493:8k_2_02:43]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-14-294493:8k_2_02:44]
The table below includes highlighted items and share-based compensation expense for the second quarter of 2014.

[0001193125-14-294493:8k_2_02:45]
|  |  | SecondQuarter |  |
| (per diluted common share) |  | 2014 |  |
| GAAP Earnings from Continuing Operations |  | $ | 0.30 |  |
| Highlighted Items: |  |  |  |  |
| Reorganization of business charges |  |  | 0.08 |  |
| Legal settlement |  |  | 0.02 |  |
| Total Highlighted Items |  |  | 0.10 |  |
| Share-based compensation expense |  |  | 0.07 |  |
| Total Non-GAAP Adjustments |  |  | 0.17 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 0.47 |  |

[0001193125-14-294493:8k_2_02:46]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-14-294493:8k_2_02:47]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP

[0001193125-14-294493:8k_2_02:48]
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result,
investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-14-294493:8k_2_02:49]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of highlighted items recorded in prior periods) from
its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s
current operating performance or comparisons to the company’s past operating performance.

[0001193125-14-294493:8k_2_02:50]
Share-based compensation expense: The company has
excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation
contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily
because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0001193125-14-294493:8k_2_02:51]
Intangible assets amortization
expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net income measurements, primarily because it represents a significant non-cash expense and because the company evaluates its
performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but can be affected by the timing and size of the company’s acquisitions. Investors should note that the use
of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-14-294493:8k_2_02:52]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press
release.

[0001193125-14-294493:8k_2_02:53]
BUSINESS RISKS

[0001193125-14-294493:8k_2_02:54]
Motorola Solutions, Inc.‘s 2013 Annual Report on Form 10-K, on Page 31 in Part II, Item 1A of Motorola Solutions, Inc.’s Quarterly Report on Form 10-Q for the period ended
March 29, 2014, and in its other SEC filings available for free on the SEC’s website at www.sec.gov and on Motorola Solutions’ website at www.motorolasolutions.com, could cause Motorola Solutions’ actual results to
differ materially from those estimated or predicted in the forward-looking statements. Many of these risks and uncertainties cannot be controlled by Motorola Solutions and factors that may impact forward-looking statements include, but are not
limited to: (1) the economic outlook for the government communications industries; (2) the level of demand for the company’s products, particularly if businesses and governments defer or cancel purchases in response to tighter credit
or as a result of the pending transaction to sell the Enterprise business to Zebra Technologies; (3) the company’s ability to introduce new products and technologies in a timely manner; (4) negative impact on the company’s
business from global economic conditions, which may include: (i) continued deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company’s products;
(iii) increased demand to provide vendor financing to customers; (iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company’s suppliers that may no longer have access
to necessary financing; (vi) counterparty failures negatively impacting the company’s financial position; (vii) changes in the value of investments held by the company’s pension plan and other defined benefit plans, which could
impact future required or voluntary pension contributions; and (viii) the company’s ability to access the capital markets on acceptable terms and conditions; (5) the impact of foreign currency fluctuations on the company when
competing for business in foreign markets; (6) the outcome of currently ongoing and future tax matters; (7) the company’s ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of
global economic conditions; (8) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (9) the impact on the company’s performance and financial results from strategic
acquisitions or divestitures, including the sale of the Enterprise business and those that may occur in the future; (10) risks related to the company’s manufacturing and business operations in foreign countries; (11) the
creditworthiness of the company’s customers and distributors, particularly purchasers of large infrastructure systems; (12) exposure under large systems and managed services contracts, including risks related to the fact that certain
customers require that the company build, own and operate their systems, often over a multi-year period; (13) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility
Holdings, Inc.; (14) variability in income received from licensing the company’s intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (15) unexpected liabilities or
expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (16) the impact of the percentage of cash and cash equivalents held outside of the United States; (17) the ability of the
company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (18) the ability of the company to repurchase shares under its repurchase program due to possible adverse market
conditions or adverse impacts on the company’s cash flow; (19) the impact of changes in governmental policies, laws or regulations; (20) negative consequences from the company’s outsourcing of various activities, including
certain business operations, information technology and administrative functions; (21) the impact of the company’s multi-year phased upgrade and consolidation of its enterprise resource planning systems into a single global platform;
(22) the satisfaction of the conditions to closing the transaction to sell the Enterprise business to Zebra Technologies; (23) the expected timeline for completing such transaction; and (24) the ability of Motorola Solutions to return
proceeds of the transaction to its shareholders and the timing thereof. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0001193125-14-294493:8k_2_02:55]
DEFINITIONS

[0001193125-14-294493:8k_2_02:56]
* Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0001193125-14-294493:8k_2_02:57]
** Non-GAAP financial information excludes from GAAP results the effects of share-based compensation expense, intangible assets amortization expense and
highlighted items.

[0001193125-14-294493:8k_2_02:58]
*** Business outlook excludes share-based compensation, intangible amortization and charges associated with items typically highlighted
by the company in its quarterly earnings releases.

[0001193125-14-294493:8k_2_02:59]
ABOUT MOTOROLA SOLUTIONS

[0001193125-14-294493:8k_2_02:60]
Motorola Solutions is a leading provider of mission-critical communication solutions and services for enterprise and government customers. Through leading-edge
innovation and communications technology, it is a global leader that enables its customers to be their best in the moments that matter. Motorola Solutions trades on the New York Stock Exchange under the ticker “MSI.” To learn more, visit
www.motorolasolutions.com. For ongoing news, please visit our newsroom or subscribe to our news feed.

[0001193125-14-294493:8k_2_02:61]
MEDIA CONTACT

[0001193125-14-294493:8k_2_02:62]
Kurt Ebenhoch

[0001193125-14-294493:8k_2_02:63]
Motorola Solutions

[0001193125-14-294493:8k_2_02:64]
+1 847-576-1341

[0001193125-14-294493:8k_2_02:65]
kurt.ebenhoch@motorolasolutions.com

[0001193125-14-294493:8k_2_02:66]
INVESTOR CONTACTS

[0001193125-14-294493:8k_2_02:67]
Shep Dunlap

[0001193125-14-294493:8k_2_02:68]
Motorola Solutions

[0001193125-14-294493:8k_2_02:69]
+1 847-576-6899

[0001193125-14-294493:8k_2_02:70]
shep.dunlap@motorolasolutions.com

[0001193125-14-294493:8k_2_02:71]
Chris Kutsor

[0001193125-14-294493:8k_2_02:72]
Motorola Solutions

[0001193125-14-294493:8k_2_02:73]
+1 847-576-4995

[0001193125-14-294493:8k_2_02:74]
chris.kutsor@motorolasolutions.com

[0001193125-14-294493:8k_2_02:75]
MOTOROLA, MOTOROLA
SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners.
©2014 Motorola Solutions, Inc. All rights reserved.

[0001193125-14-294493:8k_2_02:76]
GAAP-1

[0001193125-14-294493:8k_2_02:77]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:78]
Condensed Consolidated Statements of Operations

[0001193125-14-294493:8k_2_02:79]
(In millions, except per share amounts)

[0001193125-14-294493:8k_2_02:80]
|  |  | Three Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Net sales from products |  | $ | 887 |  |  | $ | 986 |  |
| Net sales from services |  |  | 506 |  |  |  | 511 |  |
| Net sales |  |  | 1,393 |  |  |  | 1,497 |  |
| Costs of products sales |  |  | 400 |  |  |  | 435 |  |
| Costs of services sales |  |  | 337 |  |  |  | 312 |  |
| Costs of sales |  |  | 737 |  |  |  | 747 |  |
| Gross margin |  |  | 656 |  |  |  | 750 |  |
| Selling, general and administrative expenses |  |  | 308 |  |  |  | 339 |  |
| Research and development expenditures |  |  | 176 |  |  |  | 195 |  |
| Other charges |  |  | 33 |  |  |  | 13 |  |
| Intangibles amortization |  |  | 1 |  |  |  | — |  |
| Operating earnings |  |  | 138 |  |  |  | 203 |  |
| Other expense: |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (29 | ) |  |  | (32 | ) |
| Losses on sales of investments and businesses, net |  |  | (4 | ) |  |  | — |  |
| Other |  |  | (7 | ) |  |  | (3 | ) |
| Total other expense |  |  | (40 | ) |  |  | (35 | ) |
| Earnings from continuing operations before income taxes |  |  | 98 |  |  |  | 168 |  |
| Income tax expense (benefit) |  |  | 20 |  |  |  | (59 | ) |
| Earnings from continuing operations |  |  | 78 |  |  |  | 227 |  |
| Earnings from discontinued operations, net of tax |  |  | 746 |  |  |  | 35 |  |
| Net earnings |  |  | 824 |  |  |  | 262 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | — |  |  |  | 4 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 824 |  |  | $ | 258 |  |
| Amounts attributable to Motorola Solutions, Inc. common shareholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 78 |  |  | $ | 223 |  |
| Earnings from discontinued operations, net of tax |  |  | 746 |  |  |  | 35 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 824 |  |  | $ | 258 |  |
| Earnings per common share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.31 |  |  | $ | 0.83 |  |
| Discontinued operations |  |  | 2.94 |  |  |  | 0.13 |  |
|  |  | $ | 3.25 |  |  | $ | 0.96 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.30 |  |  | $ | 0.81 |  |
| Discontinued operations |  |  | 2.92 |  |  |  | 0.13 |  |
|  |  | $ | 3.22 |  |  | $ | 0.94 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 253.7 |  |  |  | 269.5 |  |
| Diluted |  |  | 256.2 |  |  |  | 274.7 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 63.7 | % |  |  | 65.9 | % |
| Net sales from services |  |  | 36.3 | % |  |  | 34.1 | % |
| Net sales |  |  | 100 | % |  |  | 100 | % |
| Costs of products sales |  |  | 45.1 | % |  |  | 44.1 | % |
| Costs of services sales |  |  | 66.6 | % |  |  | 61.1 | % |
| Costs of sales |  |  | 52.9 | % |  |  | 49.9 | % |
| Gross margin |  |  | 47.1 | % |  |  | 50.1 | % |
| Selling, general and administrative expenses |  |  | 22.1 | % |  |  | 22.6 | % |
| Research and development expenditures |  |  | 12.6 | % |  |  | 13.0 | % |
| Other charges |  |  | 2.4 | % |  |  | 0.9 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.0 | % |
| Operating earnings |  |  | 9.9 | % |  |  | 13.6 | % |
| Other expense: |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | -2.1 | % |  |  | -2.1 | % |
| Losses on sales of investments and businesses, net |  |  | -0.3 | % |  |  | 0.0 | % |
| Other |  |  | -0.5 | % |  |  | -0.2 | % |
| Total other expense |  |  | -2.9 | % |  |  | -2.3 | % |
| Earnings from continuing operations before income taxes |  |  | 7.0 | % |  |  | 11.2 | % |
| Income tax expense (benefit) |  |  | 1.4 | % |  |  | -3.9 | % |
| Earnings from continuing operations |  |  | 5.6 | % |  |  | 15.2 | % |
| Earnings from discontinued operations, net of tax |  |  | 53.6 | % |  |  | 2.3 | % |
| Net earnings |  |  | 59.2 | % |  |  | 17.5 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.0 | % |  |  | 0.3 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 59.2 | % |  |  | 17.2 | % |

[0001193125-14-294493:8k_2_02:81]
| * | Percentages may not add up due to rounding |

[0001193125-14-294493:8k_2_02:82]
GAAP-2

[0001193125-14-294493:8k_2_02:83]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:84]
Condensed Consolidated Statements of Operations

[0001193125-14-294493:8k_2_02:85]
(In millions, except per share amounts)

[0001193125-14-294493:8k_2_02:86]
|  |  | Six Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Net sales from products |  | $ | 1,640 |  |  | $ | 1,899 |  |
| Net sales from services |  |  | 982 |  |  |  | 994 |  |
| Net sales |  |  | 2,622 |  |  |  | 2,893 |  |
| Costs of products sales |  |  | 751 |  |  |  | 840 |  |
| Costs of services sales |  |  | 638 |  |  |  | 610 |  |
| Costs of sales |  |  | 1,389 |  |  |  | 1,450 |  |
| Gross margin |  |  | 1,233 |  |  |  | 1,443 |  |
| Selling, general and administrative expenses |  |  | 615 |  |  |  | 665 |  |
| Research and development expenditures |  |  | 350 |  |  |  | 382 |  |
| Other charges |  |  | 21 |  |  |  | 20 |  |
| Intangibles amortization |  |  | 2 |  |  |  | — |  |
| Operating earnings |  |  | 245 |  |  |  | 376 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (54 | ) |  |  | (57 | ) |
| Gains on sales of investments and businesses, net |  |  | 4 |  |  |  | 7 |  |
| Other |  |  | (9 | ) |  |  | (3 | ) |
| Total other expense |  |  | (59 | ) |  |  | (53 | ) |
| Earnings from continuing operations before income taxes |  |  | 186 |  |  |  | 323 |  |
| Income tax expense (benefit) |  |  | 23 |  |  |  | (61 | ) |
| Earnings from continuing operations |  |  | 163 |  |  |  | 384 |  |
| Earnings from discontinued operations, net of tax |  |  | 788 |  |  |  | 70 |  |
| Net earnings |  |  | 951 |  |  |  | 454 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | — |  |  |  | 4 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 951 |  |  | $ | 450 |  |
| Amounts attributable to Motorola Solutions, Inc. common shareholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 163 |  |  | $ | 380 |  |
| Earnings from discontinued operations, net of tax |  |  | 788 |  |  |  | 70 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 951 |  |  | $ | 450 |  |
| Earnings per common share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.64 |  |  | $ | 1.40 |  |
| Discontinued operations |  |  | 3.11 |  |  |  | 0.26 |  |
|  |  | $ | 3.75 |  |  | $ | 1.66 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.63 |  |  | $ | 1.37 |  |
| Discontinued operations |  |  | 3.07 |  |  |  | 0.25 |  |
|  |  | $ | 3.70 |  |  | $ | 1.62 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 253.8 |  |  |  | 271.9 |  |
| Diluted |  |  | 257.2 |  |  |  | 277.7 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 62.5 | % |  |  | 65.6 | % |
| Net sales from services |  |  | 37.5 | % |  |  | 34.4 | % |
| Net sales |  |  | 100 | % |  |  | 100 | % |
| Costs of products sales |  |  | 45.8 | % |  |  | 44.2 | % |
| Costs of services sales |  |  | 65.0 | % |  |  | 61.4 | % |
| Costs of sales |  |  | 53.0 | % |  |  | 50.1 | % |
| Gross margin |  |  | 47.0 | % |  |  | 49.9 | % |
| Selling, general and administrative expenses |  |  | 23.5 | % |  |  | 23.0 | % |
| Research and development expenditures |  |  | 13.3 | % |  |  | 13.2 | % |
| Other charges |  |  | 0.8 | % |  |  | 0.7 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.0 | % |
| Operating earnings |  |  | 9.3 | % |  |  | 13.0 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | -2.1 | % |  |  | -2.0 | % |
| Gains on sales of investments and businesses, net |  |  | 0.2 | % |  |  | 0.2 | % |
| Other |  |  | -0.3 | % |  |  | -0.1 | % |
| Total other expense |  |  | -2.3 | % |  |  | -1.8 | % |
| Earnings from continuing operations before income taxes |  |  | 7.1 | % |  |  | 11.2 | % |
| Income tax expense (benefit) |  |  | 0.9 | % |  |  | -2.1 | % |
| Earnings from continuing operations |  |  | 6.2 | % |  |  | 13.3 | % |
| Earnings from discontinued operations, net of tax |  |  | 30.1 | % |  |  | 2.4 | % |
| Net earnings |  |  | 36.3 | % |  |  | 15.7 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.0 | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 36.3 | % |  |  | 15.6 | % |

[0001193125-14-294493:8k_2_02:87]
| * | Percentages may not add up due to rounding |

[0001193125-14-294493:8k_2_02:88]
GAAP-3

[0001193125-14-294493:8k_2_02:89]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:90]
Condensed Consolidated Balance Sheets

[0001193125-14-294493:8k_2_02:91]
(In millions)

[0001193125-14-294493:8k_2_02:92]
|  |  | June 28,2014 |  |  | December 31,2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,876 |  |  | $ | 3,225 |  |
| Accounts receivable, net |  |  | 1,185 |  |  |  | 1,369 |  |
| Inventories, net |  |  | 330 |  |  |  | 347 |  |
| Deferred income taxes |  |  | 1,205 |  |  |  | 451 |  |
| Other current assets |  |  | 527 |  |  |  | 635 |  |
| Current assets held for sale |  |  | 943 |  |  |  | 993 |  |
| Total current assets |  |  | 7,066 |  |  |  | 7,020 |  |
| Property, plant and equipment, net |  |  | 682 |  |  |  | 695 |  |
| Investments |  |  | 236 |  |  |  | 232 |  |
| Deferred income taxes |  |  | 1,909 |  |  |  | 1,990 |  |
| Goodwill |  |  | 383 |  |  |  | 361 |  |
| Other assets |  |  | 128 |  |  |  | 89 |  |
| Noncurrent assets held for sale |  |  | 1,464 |  |  |  | 1,464 |  |
| Total assets |  | $ | 11,868 |  |  | $ | 11,851 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 4 |  |  | $ | 4 |  |
| Accounts payable |  |  | 453 |  |  |  | 583 |  |
| Accrued liabilities |  |  | 1,615 |  |  |  | 1,763 |  |
| Current liabilities held for sale |  |  | 852 |  |  |  | 870 |  |
| Total current liabilities |  |  | 2,924 |  |  |  | 3,220 |  |
| Long-term debt |  |  | 2,446 |  |  |  | 2,457 |  |
| Other liabilities |  |  | 2,151 |  |  |  | 2,314 |  |
| Noncurrent liabilities held for sale |  |  | 178 |  |  |  | 171 |  |
| Total Motorola Solutions, Inc. stockholders’ equity |  |  | 4,139 |  |  |  | 3,659 |  |
| Noncontrolling interests |  |  | 30 |  |  |  | 30 |  |
| Total liabilities and stockholders’ equity |  | $ | 11,868 |  |  | $ | 11,851 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash* |  | $ | 426 |  |  | $ | 764 |  |

[0001193125-14-294493:8k_2_02:93]
| * | Net cash = Total cash—Current portion of long-term debt—Long-term debt |

[0001193125-14-294493:8k_2_02:94]
GAAP-4

[0001193125-14-294493:8k_2_02:95]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:96]
Condensed Consolidated Statements of Cash Flows

[0001193125-14-294493:8k_2_02:97]
(In millions)

[0001193125-14-294493:8k_2_02:98]
|  |  | Three Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 824 |  |  | $ | 258 |  |
| Earnings attributable to noncontrolling interests |  |  | — |  |  |  | 4 |  |
| Net earnings |  |  | 824 |  |  |  | 262 |  |
| Earnings from discontinued operations, net of tax |  |  | 746 |  |  |  | 35 |  |
| Earnings from continuing operations, net of tax |  |  | 78 |  |  |  | 227 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 46 |  |  |  | 40 |  |
| Non-cash other income |  |  | (1 | ) |  |  | (6 | ) |
| Share-based compensation expense |  |  | 25 |  |  |  | 27 |  |
| Loss on sales of investments and businesses, net |  |  | 4 |  |  |  | — |  |
| Deferred income taxes |  |  | (16 | ) |  |  | (167 | ) |
| Changes in assets and liabilities, net of effects of acquisitions and dispositions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 30 |  |  |  | (108 | ) |
| Inventories |  |  | 29 |  |  |  | 8 |  |
| Other current assets |  |  | 60 |  |  |  | 61 |  |
| Accounts payable and accrued liabilities |  |  | (124 | ) |  |  | (113 | ) |
| Other assets and liabilities |  |  | (13 | ) |  |  | 9 |  |
| Net cash provided by (used for) operating activities from continuing operations |  |  | 118 |  |  |  | (22 | ) |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (6 | ) |  |  | (5 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 10 |  |  |  | 2 |  |
| Capital expenditures |  |  | (42 | ) |  |  | (37 | ) |
| Proceeds from sales of property, plant and equipment |  |  | — |  |  |  | 15 |  |
| Proceeds from sales of Sigma Fund and short-term investments, net |  |  | — |  |  |  | 489 |  |
| Net cash provided by (used for) investing activities from continuing operations |  |  | (38 | ) |  |  | 464 |  |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (1 | ) |  |  | (1 | ) |
| Issuance of common stock |  |  | 71 |  |  |  | 60 |  |
| Repurchase of common stock |  |  | (416 | ) |  |  | (550 | ) |
| Excess tax benefit from share-based compensation |  |  | 1 |  |  |  | 9 |  |
| Payments of dividends |  |  | (79 | ) |  |  | (71 | ) |
| Distributions from discontinued operations |  |  | 74 |  |  |  | 95 |  |
| Net cash used for financing activities from continuing operations |  |  | (350 | ) |  |  | (458 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | 55 |  |  |  | 105 |  |
| Net cash provided by (used for) investing activities from discontinued operations |  |  | 19 |  |  |  | (12 | ) |
| Net cash used for financing activities from discontinued operations |  |  | (74 | ) |  |  | (95 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | — |  |  |  | 2 |  |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | 5 |  |  |  | 3 |  |
| Net decrease in cash and cash equivalents |  |  | (265 | ) |  |  | (13 | ) |
| Cash and cash equivalents, beginning of period |  |  | 3,141 |  |  |  | 1,470 |  |
| Cash and cash equivalents, end of period |  | $ | 2,876 |  |  | $ | 1,457 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 76 |  |  | $ | (59 | ) |

[0001193125-14-294493:8k_2_02:99]
| * | Free cash flow = Net cash provided by operating activities—Capital expenditures |

[0001193125-14-294493:8k_2_02:100]
GAAP-5

[0001193125-14-294493:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:102]
Condensed Consolidated Statements of Cash Flows

[0001193125-14-294493:8k_2_02:103]
(In millions)

[0001193125-14-294493:8k_2_02:104]
|  |  | Six Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 951 |  |  | $ | 450 |  |
| Earnings attributable to noncontrolling interests |  |  | — |  |  |  | 4 |  |
| Net earnings |  |  | 951 |  |  |  | 454 |  |
| Earnings from discontinued operations, net of tax |  |  | 788 |  |  |  | 70 |  |
| Earnings from continuing operations, net of tax |  |  | 163 |  |  |  | 384 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 86 |  |  |  | 76 |  |
| Gain on sale of building and land |  |  | (21 | ) |  |  | — |  |
| Non-cash other income |  |  | (5 | ) |  |  | (7 | ) |
| Share-based compensation expense |  |  | 54 |  |  |  | 62 |  |
| Gains on sales of investments and businesses, net |  |  | (4 | ) |  |  | (7 | ) |
| Deferred income taxes |  |  | 6 |  |  |  | (193 | ) |
| Changes in assets and liabilities, net of effects of acquisitions and dispositions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 190 |  |  |  | 78 |  |
| Inventories |  |  | 17 |  |  |  | 14 |  |
| Other current assets |  |  | 76 |  |  |  | (23 | ) |
| Accounts payable and accrued liabilities |  |  | (299 | ) |  |  | (479 | ) |
| Other assets and liabilities |  |  | (133 | ) |  |  | (5 | ) |
| Net cash provided by (used for) operating activities from continuing operations |  |  | 130 |  |  |  | (100 | ) |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (11 | ) |  |  | (8 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 21 |  |  |  | 21 |  |
| Capital expenditures |  |  | (82 | ) |  |  | (79 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 24 |  |  |  | 15 |  |
| Proceeds from sales of Sigma Fund and short-term investments, net |  |  | — |  |  |  | 376 |  |
| Net cash provided by (used for) investing activities from continuing operations |  |  | (48 | ) |  |  | 325 |  |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (2 | ) |  |  | (2 | ) |
| Net proceeds from issuance of debt |  |  | 4 |  |  |  | 593 |  |
| Issuance of common stock |  |  | 85 |  |  |  | 99 |  |
| Repurchase of common stock |  |  | (473 | ) |  |  | (907 | ) |
| Excess tax benefit from share-based compensation |  |  | 6 |  |  |  | 18 |  |
| Payments of dividends |  |  | (158 | ) |  |  | (143 | ) |
| Distributions from discontinued operations |  |  | 100 |  |  |  | 137 |  |
| Net cash used for financing activities from continuing operations |  |  | (438 | ) |  |  | (205 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | 89 |  |  |  | 152 |  |
| Net cash provided by (used for) investing activities from discontinued operations |  |  | 11 |  |  |  | (17 | ) |
| Net cash used for financing activities from discontinued operations |  |  | (100 | ) |  |  | (137 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | — |  |  |  | 2 |  |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | 7 |  |  |  | (31 | ) |
| Net decrease in cash and cash equivalents |  |  | (349 | ) |  |  | (11 | ) |
| Cash and cash equivalents, beginning of period |  |  | 3,225 |  |  |  | 1,468 |  |
| Cash and cash equivalents, end of period |  | $ | 2,876 |  |  | $ | 1,457 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 48 |  |  | $ | (179 | ) |

[0001193125-14-294493:8k_2_02:105]
| * | Free cash flow = Net cash provided by operating activities—Capital expenditures |

[0001193125-14-294493:8k_2_02:106]
GAAP-6

[0001193125-14-294493:8k_2_02:107]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:108]
Segment Information

[0001193125-14-294493:8k_2_02:109]
(In
millions)

[0001193125-14-294493:8k_2_02:110]
Net Sales

[0001193125-14-294493:8k_2_02:111]
|  |  | Three Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | % Change |  |
| Products |  | $ | 887 |  |  | $ | 986 |  |  |  | -10 | % |
| Services |  |  | 506 |  |  |  | 511 |  |  |  | -1 | % |
| Total Motorola Solutions |  | $ | 1,393 |  |  | $ | 1,497 |  |  |  | -7 | % |
|  |  | Six Months Ended |  |
|  |  | June 28, |  |  | June 29, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 1,640 |  |  | $ | 1,899 |  |  |  | -14 | % |
| Services |  |  | 982 |  |  |  | 994 |  |  |  | -1 | % |
| Total Motorola Solutions |  | $ | 2,622 |  |  | $ | 2,893 |  |  |  | -9 | % |

[0001193125-14-294493:8k_2_02:112]
Operating Earnings

[0001193125-14-294493:8k_2_02:113]
|  |  | Three Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | % Change |  |
| Products |  | $ | 95 |  |  | $ | 125 |  |  |  | -24 | % |
| Services |  |  | 43 |  |  |  | 78 |  |  |  | -45 | % |
| Total Motorola Solutions |  | $ | 138 |  |  | $ | 203 |  |  |  | -32 | % |
|  |  | Six Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | % Change |  |
| Products |  | $ | 134 |  |  | $ | 231 |  |  |  | -42 | % |
| Services |  |  | 111 |  |  |  | 145 |  |  |  | -23 | % |
| Total Motorola Solutions |  | $ | 245 |  |  | $ | 376 |  |  |  | -35 | % |

[0001193125-14-294493:8k_2_02:114]
Operating Earnings %

[0001193125-14-294493:8k_2_02:115]
|  |  | Three Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |
| Products |  |  | 10.7 | % |  |  | 12.7 | % |
| Services |  |  | 8.5 | % |  |  | 15.3 | % |
| Total Motorola Solutions |  |  | 9.9 | % |  |  | 13.6 | % |
|  |  | Six Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |
| Products |  |  | 8.2 | % |  |  | 12.2 | % |
| Services |  |  | 11.3 | % |  |  | 14.6 | % |
| Total Motorola Solutions |  |  | 9.3 | % |  |  | 13.0 | % |

[0001193125-14-294493:8k_2_02:116]
Non-GAAP-1

[0001193125-14-294493:8k_2_02:117]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:118]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and Highlighted Items)

[0001193125-14-294493:8k_2_02:119]
| Q1 2014 |  |
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPSimpact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 29 |  |  |  | 9 |  |  |  | 20 |  |  |  | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 10 |  |  |  | 2 |  |  |  | 8 |  |  |  | 0.03 |  |
| Gain on sale of building and land |  | Other charges |  |  | (21 | ) |  |  | (8 | ) |  |  | (13 | ) |  |  | (0.05 | ) |
| Recognition of previously unrecognized income tax benefits |  | Income tax expense |  |  | — |  |  |  | 29 |  |  |  | (29 | ) |  |  | (0.11 | ) |
| Total impact on Net earnings |  |  |  | $ | 19 |  |  | $ | 32 |  |  | $ | (13 | ) |  | $ | (0.05 | ) |
| Q2 2014 |  |
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPSimpact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 26 |  |  |  | 9 |  |  |  | 17 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 28 |  |  |  | 8 |  |  |  | 20 |  |  | $ | 0.08 |  |
| Legal settlement |  | Other charges |  |  | 8 |  |  |  | 3 |  |  |  | 5 |  |  | $ | 0.02 |  |
| Total impact on Net earnings |  |  |  | $ | 63 |  |  | $ | 20 |  |  | $ | 43 |  |  | $ | 0.17 |  |

[0001193125-14-294493:8k_2_02:120]
Non-GAAP-2

[0001193125-14-294493:8k_2_02:121]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:122]
Non-GAAP Segment Information

[0001193125-14-294493:8k_2_02:123]
(In millions)

[0001193125-14-294493:8k_2_02:124]
Net Sales

[0001193125-14-294493:8k_2_02:125]
|  |  | Three Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | % Change |  |
| Products |  | $ | 887 |  |  | $ | 986 |  |  |  | -10 | % |
| Services |  |  | 506 |  |  |  | 511 |  |  |  | -1 | % |
| Total Motorola Solutions |  | $ | 1,393 |  |  | $ | 1,497 |  |  |  | -7 | % |
|  |  | Six Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | % Change |  |
| Products |  | $ | 1,640 |  |  | $ | 1,899 |  |  |  | -14 | % |
| Services |  |  | 982 |  |  |  | 994 |  |  |  | -1 | % |
| Total Motorola Solutions |  | $ | 2,622 |  |  | $ | 2,893 |  |  |  | -9 | % |
| Non-GAAP Operating Earnings |  |
|  |  | Three Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | % Change |  |
| Products |  | $ | 133 |  |  | $ | 154 |  |  |  | -14 | % |
| Services |  |  | 68 |  |  |  | 94 |  |  |  | -28 | % |
| Total Motorola Solutions |  | $ | 201 |  |  | $ | 248 |  |  |  | -19 | % |
|  |  | Six Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | % Change |  |
| Products |  | $ | 185 |  |  | $ | 288 |  |  |  | -36 | % |
| Services |  |  | 142 |  |  |  | 176 |  |  |  | -19 | % |
| Total Motorola Solutions |  | $ | 327 |  |  | $ | 464 |  |  |  | -30 | % |

[0001193125-14-294493:8k_2_02:126]
Non-GAAP Operating Earnings %

[0001193125-14-294493:8k_2_02:127]
|  |  | Three Months Ended |  |
|  |  | 2014 |  |  | 2013 |  |
| Products |  |  | 15.0 | % |  |  | 15.6 | % |
| Services |  |  | 13.4 | % |  |  | 18.4 | % |
| Total Motorola Solutions |  |  | 14.4 | % |  |  | 16.6 | % |
|  |  | Six Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |
| Products |  |  | 11.3 | % |  |  | 15.2 | % |
| Services |  |  | 14.5 | % |  |  | 17.7 | % |
| Total Motorola Solutions |  |  | 12.5 | % |  |  | 16.0 | % |

[0001193125-14-294493:8k_2_02:128]
Non-GAAP-3

[0001193125-14-294493:8k_2_02:129]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-294493:8k_2_02:130]
Operating Earnings after Non-GAAP Adjustments

[0001193125-14-294493:8k_2_02:131]
| Q1 2014 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,228 |  |  | $ | 753 |  |  | $ | 475 |  |
| Operating earnings (“OE”) |  | $ | 107 |  |  | $ | 39 |  |  | $ | 68 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 29 |  |  |  | 19 |  |  |  | 10 |  |
| Reorganization of business charges |  |  | 10 |  |  |  | 6 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Gain on sale of building and land |  |  | (21 | ) |  |  | (14 | ) |  |  | (7 | ) |
| Total above-OE non-GAAP adjustments |  |  | 19 |  |  |  | 12 |  |  |  | 7 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 126 |  |  | $ | 51 |  |  | $ | 75 |  |
| Operating earnings as a percentage of net sales—GAAP |  |  | 8.7 | % |  |  | 5.2 | % |  |  | 14.3 | % |
| Operating earnings as a percentage of net sales—after non-GAAP adjustments |  |  | 10.3 | % |  |  | 6.8 | % |  |  | 15.8 | % |
| Q2 2014 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,393 |  |  | $ | 887 |  |  | $ | 506 |  |
| Operating earnings (“OE”) |  | $ | 138 |  |  | $ | 95 |  |  | $ | 43 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 26 |  |  |  | 14 |  |  |  | 12 |  |
| Reorganization of business charges |  |  | 28 |  |  |  | 18 |  |  |  | 10 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Legal settlement |  |  | 8 |  |  |  | 5 |  |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  |  | 63 |  |  |  | 38 |  |  |  | 25 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 201 |  |  | $ | 133 |  |  | $ | 68 |  |
| Operating earnings as a percentage of net sales—GAAP |  |  | 9.9 | % |  |  | 10.7 | % |  |  | 8.5 | % |
| Operating earnings as a percentage of net sales—after non-GAAP adjustments |  |  | 14.4 | % |  |  | 15.0 | % |  |  | 13.4 | % |
