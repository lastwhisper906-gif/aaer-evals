# MSI 10-Q controls and the auditor's report


## item_4_controls

[0000068505-14-000010:item_4_controls:1]
Item 4. Controls and Procedures

[0000068505-14-000010:item_4_controls:2]
(a) Evaluation of disclosure controls and procedures. Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of the end of the period covered by this quarterly report (the “Evaluation Date”). Based on this evaluation, our chief executive officer and chief financial officer concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information relating to Motorola Solutions, including our consolidated subsidiaries, required to be disclosed in our Securities and Exchange Commission (“SEC”) reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and (ii) is accumulated and communicated to Motorola Solutions’ management, including our chief executive officer and chief financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000068505-14-000010:item_4_controls:3]
(b) Changes in internal control over financial reporting. There have been no changes in our internal control over financial reporting that occurred during the quarter ended June 28, 2014, that have materially affected or are reasonably likely to materially affect our internal control over financial reporting.

[0000068505-14-000010:item_4_controls:4]
We are in the process of a multi-year phased upgrade and consolidation of our enterprise resource planning (“ERP”) systems into a single global platform across our business.  The second and third phases were successfully implemented during the first six months of 2014 with no significant changes to our internal controls over financial reporting.

[0000068505-14-000010:item_4_controls:5]
Continuing to implement the remaining phases of our ERP system on a widespread basis involves significant changes in business processes and extensive organizational training.  A phased approach reduces the risks associated with making these changes.  We believe we are taking the necessary steps to monitor and maintain appropriate internal controls during these transition periods.   Such steps include deploying resources to mitigate internal control risks and performing additional verifications and testing to ensure data integrity.  In connection with the continued implementation of our global ERP system, we expect there will be certain redesigns of our business processes throughout the implementation, some of which may be related to internal control over financial reporting and disclosure controls and procedures.

[0000068505-14-000010:item_4_controls:6]
37
