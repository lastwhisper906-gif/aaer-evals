# MSI note change history — 0000068505-14-000008 → 0000068505-14-000010


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0000068505-14-000010:note_history:1]
The condensed consolidated financial statements as of June 28, 2014 and for the three and six months ended June 28, 2014 and June 29, 2013, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2014-05-01, similarity 0.9429):
[0000068505-14-000008:note_history:1]
The condensed consolidated financial statements as of March 29, 2014 and for the three months ended March 29, 2014 and March 30, 2013, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2014-08-05):
[0000068505-14-000010:note_history:2]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2013.  The results of operations for the three and six months ended June 28, 2014 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2014-05-01, similarity 0.8081):
[0000068505-14-000008:note_history:2]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2013.  The results of operations for the three months ended March 29, 2014 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2014-08-05):
[0000068505-14-000010:note_history:3]
In January 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for the Company beginning January 1, 2015. The Company is currently assessing the impact of this standard on its consolidated financial statements and footnote disclosures.
  (was, 2014-05-01, similarity 0.9498):
[0000068505-14-000008:note_history:3]
In January 2014, the FASB issued ASU No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for the Company beginning January 1, 2015. The Company is currently assessing the impact of this standard on its consolidated financial statements and footnote disclosures.

- added (2014-08-05):
[0000068505-14-000010:note_history:4]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. The ASU will be effective for the Company beginning January 1, 2017, and allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-08-05):
[0000068505-14-000010:note_history:5]
As of June 28, 2014, the Company had a $2.0 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. Effective May 29, 2014, this facility replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) which was scheduled to mature on June 30, 2014. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company is no longer subject to a minimum interest coverage covenant under the new facility. The Company was in compliance with its financial covenants as of June 28, 2014. The Company did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the three and six months ended June 28, 2014.

- added (2014-08-05):
[0000068505-14-000010:note_history:6]
As of June 28, 2014, the Company had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of June 28, 2014.

- removed (2014-08-05):
[0000068505-14-000008:note_history:7]
As of March 29, 2014, the Company had a $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) scheduled to mature on June 30, 2014.  The Company must comply with certain customary covenants, including maximum leverage and minimum interest coverage ratios as defined in the 2011 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 29, 2014. The Company did not borrow under the 2011 Motorola Solutions Credit Agreement during the three months ended March 29, 2014.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-08-05):
[0000068505-14-000008:note_history:8]
Subsequent Events

- removed (2014-08-05):
[0000068505-14-000008:note_history:9]
On April 14, 2014, the Company entered into a Master Acquisition Agreement (the “Acquisition Agreement”) with Zebra Technologies Corporation to sell the Company’s Enterprise business for $3.45 billion in cash. Certain assets of the Enterprise business will be excluded from the transaction and retained by the Company, including the Company’s iDEN infrastructure business, and other assets and certain liabilities as specified in the Acquisition Agreement. The transaction is expected to close by the end of 2014.
