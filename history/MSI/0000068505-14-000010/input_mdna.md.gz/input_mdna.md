# MSI MD&A — 0000068505-14-000010


## mdna

[0000068505-14-000010:mdna:1]
[same as prior period, unchanged from 0000068505-14-000008:mdna:1]

[0000068505-14-000010:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and six months ended months ended June 28, 2014 and June 29, 2013, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000068505-14-000010:mdna:3]
[same as prior period, unchanged from 0000068505-14-000008:mdna:3]

[0000068505-14-000010:mdna:4]
Recent Developments

[0000068505-14-000010:mdna:5]
On April 14, 2014, we entered into a Master Acquisition Agreement (the “Acquisition Agreement”) with Zebra Technologies Corporation to sell our Enterprise business for $3.45 billion in cash. Certain assets of the Enterprise business will be excluded from the transaction and retained by us, including our iDEN business, and other assets and certain liabilities as specified in the Acquisition Agreement. The transaction is expected to close by the end of 2014. As a result of the pending sale, we have reported the Enterprise business as a discontinued operation in our condensed consolidated financial statements and footnotes for all periods presented.

[0000068505-14-000010:mdna:6]
Our Business

[0000068505-14-000010:mdna:7]
We are a leading provider of mission-critical communication infrastructure, devices, software and services. Our products and services help government, public safety and commercial customers improve their operations through increased effectiveness and efficiency of their mobile workforces. Our customers benefit from our global footprint and thought leadership, with sales in more than 100 countries, an industry leadership position, an unmatched portfolio of products and services and a strong patent portfolio.

[0000068505-14-000010:mdna:8]
As of the second quarter of 2014, we report financial results for the following two segments:

[0000068505-14-000010:mdna:9]
Products: The Products segment offers an extensive portfolio of network infrastructure, devices, system software and applications for the public safety, hospitality, education, manufacturing, transportation, utilities, mining and retail industries, including our: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) integrated digital enhanced network (“iDEN”) products, and (v) broadband technology products, such as Long-Term Evolution (“LTE”). In addition, the Products segment offers smart public safety solutions including computer-aided dispatch, records systems, data management systems and Real Time Crime Center solutions. In the second quarter of 2014, the segment’s net sales were $887 million, representing 64% of our consolidated net sales.

[0000068505-14-000010:mdna:10]
Services: The Services segment has a full breadth of service offerings for both public safety and private communication networks including: (i) Integration services, (ii) Lifecycle Management and Support services, (iii) Managed services, and (iv) Solutions services. Integration services includes implementation, optimization, and integration of networks, devices, and applications.  Lifecycle Management and Support services includes lifecycle planning, upgrades, call center, network monitoring, and repair services.  Managed services includes managing customer networks at defined services levels. Solutions services includes integration of hardware and software to meet customer needs. In the second quarter of 2014, the segment’s net sales were $506 million, representing 36% of our consolidated net sales.

[0000068505-14-000010:mdna:11]
Second Quarter Summary

[0000068505-14-000010:mdna:12]
| • | Net sales decreased by $104 million, or 7%, to $1.4 billion in the second quarter of 2014, compared to net sales of $1.5 billion in the second quarter of 2013. |

[0000068505-14-000010:mdna:13]
| • | We generated operating earnings of $138 million, or 10% of net sales, in the second quarter of 2014, compared to $203 million, or 14% of net sales, in the second quarter of 2013. |

[0000068505-14-000010:mdna:14]
| • | We had earnings from continuing operations of $78 million, or $0.30 per diluted common share, in the second quarter of 2014, compared to earnings from continuing operations of $223 million, or $0.81 per diluted common share, in the second quarter of 2013. |

[0000068505-14-000010:mdna:15]
| • | We generated net cash from operating activities of $130 million during the first half of 2014, compared to $100 million of net cash used for operating activities in the first half of 2013. |

[0000068505-14-000010:mdna:16]
| • | We returned $495 million and $631 million in capital to shareholders through share repurchases and dividends during the second quarter and first half of 2014, respectively. |

[0000068505-14-000010:mdna:17]
[same as prior period, unchanged from 0000068505-14-000008:mdna:14]

[0000068505-14-000010:mdna:18]
[same as prior period, unchanged from 0000068505-14-000008:mdna:58]

[0000068505-14-000010:mdna:19]
| • | Products: Net sales were $887 million in the second quarter of 2014, a decrease of $99 million, or 10%, compared to net sales of $986 million during the second quarter of 2013. On a geographic basis, net sales declined in North America and APME, and increased in Latin America and EA, compared to the year-ago quarter. |

[0000068505-14-000010:mdna:20]
| • | Services: Net sales were $506 million in the second quarter of 2014, a decrease of $5 million, or 1%, compared to net sales of $511 million in the second quarter of 2013. On a geographic basis, net sales declined in North America and APME, increased in EA, and were flat in Latin America, compared to the year-ago quarter. |

[0000068505-14-000010:mdna:21]
25

[0000068505-14-000010:mdna:22]
[same as prior period, unchanged from 0000068505-14-000008:mdna:17]

[0000068505-14-000010:mdna:23]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | June 28, 2014 |  | % ofSales** |  | June 29, 2013 |  | % ofSales** |  | June 28, 2014 |  | % ofSales** |  | June 29, 2013 |  | % ofSales** |
| Net sales from products | $ | 887 |  |  |  |  | $ | 986 |  |  |  |  | $ | 1,640 |  |  |  |  | $ | 1,899 |  |  |  |
| Net sales from services | 506 |  |  |  |  | 511 |  |  |  |  | 982 |  |  |  |  | 994 |  |  |  |
| Net sales | 1,393 |  |  |  |  | 1,497 |  |  |  |  | 2,622 |  |  |  |  | 2,893 |  |  |  |
| Costs of product sales | 400 |  |  | 45.1 | % |  | 435 |  |  | 44.1 | % |  | 751 |  |  | 45.8 | % |  | 840 |  |  | 44.2 | % |
| Costs of services sales | 337 |  |  | 66.6 | % |  | 312 |  |  | 61.1 | % |  | 638 |  |  | 65.0 | % |  | 610 |  |  | 61.4 | % |
| Costs of sales | 737 |  |  |  |  | 747 |  |  |  |  | 1,389 |  |  |  |  | 1,450 |  |  |  |
| Gross margin | 656 |  |  | 47.1 | % |  | 750 |  |  | 50.1 | % |  | 1,233 |  |  | 47.0 | % |  | 1,443 |  |  | 49.9 | % |
| Selling, general and administrative expenses | 308 |  |  | 22.1 | % |  | 339 |  |  | 22.6 | % |  | 615 |  |  | 23.5 | % |  | 665 |  |  | 23.0 | % |
| Research and development expenditures | 176 |  |  | 12.6 | % |  | 195 |  |  | 13.0 | % |  | 350 |  |  | 13.3 | % |  | 382 |  |  | 13.2 | % |
| Other charges | 34 |  |  | 2.4 | % |  | 13 |  |  | 0.9 | % |  | 23 |  |  | 0.9 | % |  | 20 |  |  | 0.7 | % |
| Operating earnings | 138 |  |  | 9.9 | % |  | 203 |  |  | 13.6 | % |  | 245 |  |  | 9.3 | % |  | 376 |  |  | 13.0 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (29 | ) |  | (2.1 | )% |  | (32 | ) |  | (2.1 | )% |  | (54 | ) |  | (2.1 | )% |  | (57 | ) |  | (2.0 | )% |
| Gain (loss) on sales of investments and businesses, net | (4 | ) |  | (0.3 | )% |  | — |  |  | — | % |  | 4 |  |  | 0.2 | % |  | 7 |  |  | 0.2 | % |
| Other | (7 | ) |  | (0.5 | )% |  | (3 | ) |  | (0.2 | )% |  | (9 | ) |  | (0.3 | )% |  | (3 | ) |  | (0.1 | )% |
| Total other expense | (40 | ) |  | (2.9 | )% |  | (35 | ) |  | (2.3 | )% |  | (59 | ) |  | (2.3 | )% |  | (53 | ) |  | (1.8 | )% |
| Earnings from continuing operations before income taxes | 98 |  |  | 7.0 | % |  | 168 |  |  | 11.2 | % |  | 186 |  |  | 7.1 | % |  | 323 |  |  | 11.2 | % |
| Income tax expense (benefit) | 20 |  |  | 1.4 | % |  | (59 | ) |  | (3.9 | )% |  | 23 |  |  | 0.9 | % |  | (61 | ) |  | (2.1 | )% |
| Earnings from continuing operations | 78 |  |  | 5.6 | % |  | 227 |  |  | 15.2 | % |  | 163 |  |  | 6.2 | % |  | 384 |  |  | 13.3 | % |
| Less: Earnings attributable to noncontrolling interests | — |  |  | — | % |  | 4 |  |  | 0.3 | % |  | — |  |  | — | % |  | 4 |  |  | 0.1 | % |
| Earnings from continuing operations* | 78 |  |  | 5.6 | % |  | 223 |  |  | 14.9 | % |  | 163 |  |  | 6.2 | % |  | 380 |  |  | 13.1 | % |
| Earnings from discontinued operations, net of tax | 746 |  |  | 53.6 | % |  | 35 |  |  | 2.3 | % |  | 788 |  |  | 30.1 | % |  | 70 |  |  | 2.4 | % |
| Net earnings* | $ | 824 |  |  | 59.2 | % |  | $ | 258 |  |  | 17.2 | % |  | $ | 951 |  |  | 36.3 | % |  | $ | 450 |  |  | 15.6 | % |
| Earnings per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.30 |  |  |  |  | $ | 0.81 |  |  |  |  | $ | 0.63 |  |  |  |  | $ | 1.37 |  |  |  |
| Discontinued operations | 2.92 |  |  |  |  | 0.13 |  |  |  |  | 3.07 |  |  |  |  | 0.25 |  |  |  |
| Earnings per diluted common share* | $ | 3.22 |  |  |  |  |  | $ | 0.94 |  |  |  |  |  | $ | 3.70 |  |  |  |  | $ | 1.62 |  |  |  |

[0000068505-14-000010:mdna:24]
[same as prior period, unchanged from 0000068505-14-000008:mdna:19]

[0000068505-14-000010:mdna:25]
[same as prior period, unchanged from 0000068505-14-000008:mdna:20]

[0000068505-14-000010:mdna:26]
26

[0000068505-14-000010:mdna:27]
Results of Operations—Three months ended June 28, 2014 compared to three months ended June 29, 2013

[0000068505-14-000010:mdna:28]
[same as prior period, unchanged from 0000068505-14-000008:mdna:23]

[0000068505-14-000010:mdna:29]
Net sales were $1.4 billion in the second quarter of 2014, down $104 million, or 7%, compared to net sales of $1.5 billion in the second quarter of 2013. The decrease in net sales reflects a $99 million, or 10%, decrease in net sales in the Products segment, driven by declines in: (i) North America, primarily in ASTRO sales to our state and local customers, as a result of fewer device sales from narrowbanding, and (ii) APME, partially offset by double-digit growth in the Products segment in EA and Latin America reflecting solid performance in all major product categories.  In addition, the decrease in net sales includes a $5 million, or 1%, decrease in net sales in the Services segment, driven by declines in: (i) North America as a result of iDEN services declines and (ii) APME, partially offset by double-digit Services growth in EA in Integration and Managed services.

[0000068505-14-000010:mdna:30]
[same as prior period, unchanged from 0000068505-14-000008:mdna:25]

[0000068505-14-000010:mdna:31]
Gross margin was $656 million, or 47.1% of net sales, in the second quarter of 2014, compared to $750 million, or 50.1% of net sales, in the second quarter of 2013. The decrease in gross margin percentage is driven primarily by: (i) a decline in gross margin as a percentage of sales in ASTRO in North America as a result of a shift from subscribers to infrastructure, which includes more third party equipment, (ii) overall sales mix between the Products and Services segments, and (iii) lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-14-000010:mdna:32]
[same as prior period, unchanged from 0000068505-14-000008:mdna:27]

[0000068505-14-000010:mdna:33]
Selling, general and administrative (“SG&A”) expenses decreased 9% to $308 million, or 22.1% of net sales, in the second quarter of 2014, compared to $339 million, or 22.6% of net sales, in the second quarter of 2013. The decrease in SG&A expenditures is primarily due to reduced compensation expenses, including incentives, pension expense, and the effect of headcount reductions enacted in previous periods.

[0000068505-14-000010:mdna:34]
[same as prior period, unchanged from 0000068505-14-000008:mdna:29]

[0000068505-14-000010:mdna:35]
Research and development (“R&D”) expenditures decreased 10% to $176 million, or 12.6% of net sales, in the second quarter of 2014, from $195 million, or 13.0% of net sales, in the second quarter of 2013. The decrease in R&D expenditures is primarily due to: (i) headcount reductions enacted during previous periods, (ii) lower incentive compensation expenses, and (iii) the reduction of spending in certain development programs, such as iDEN.

[0000068505-14-000010:mdna:36]
[same as prior period, unchanged from 0000068505-14-000008:mdna:31]

[0000068505-14-000010:mdna:37]
We recorded net charges of $34 million in Other charges in the second quarter of 2014, compared to net charges of $13 million in the second quarter of 2013. The net charges in the second quarter of 2014 included: (i) $25 million of net reorganization of business charges and (ii) an $8 million charge for a legal settlement. The net charges in the second quarter of 2013 of $13 million were all related to net reorganization of business charges. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-14-000010:mdna:38]
[same as prior period, unchanged from 0000068505-14-000008:mdna:33]

[0000068505-14-000010:mdna:39]
Net interest expense was $29 million in the second quarter of 2014, compared to net interest expense of $32 million in the second quarter of 2013. Net interest expense in the second quarter of 2014 included interest expense of $34 million, partially offset by interest income of $5 million. Net interest expense in the second quarter of 2013 included interest expense of $38 million, partially offset by interest income of $6 million. The decrease in net interest expense in the second quarter of 2014 is primarily attributable to: (i) lower interest expense due to income tax-related interest charges of $5 million incurred in the second quarter of 2013 and (ii) a decrease in interest income due to lower average cash and cash equivalents during the second quarter of 2014.

[0000068505-14-000010:mdna:40]
Net Loss on Sales of Investments and Businesses

[0000068505-14-000010:mdna:41]
Net loss on sales of investments and businesses was $4 million in the second quarter of 2014, consisting of a loss on the sale of equity investments.

[0000068505-14-000010:mdna:42]
[same as prior period, unchanged from 0000068505-14-000008:mdna:37]

[0000068505-14-000010:mdna:43]
Net Other expense was $7 million in the second quarter of 2014, compared to net Other expense of $3 million in the second quarter of 2013. The net Other expense in both the second quarter of 2014 and 2013 was primarily comprised of foreign currency losses.

[0000068505-14-000010:mdna:44]
[same as prior period, unchanged from 0000068505-14-000008:mdna:39]

[0000068505-14-000010:mdna:45]
We recorded $20 million of net tax expense in the second quarter of 2014, resulting in an effective tax rate of 20%, compared to $59 million of net tax benefit in the second quarter of 2013, resulting in a negative effective tax rate. Our effective tax rate in the second quarter of 2014 was favorably impacted by $12 million of discrete tax benefits primarily related to return-to-provision adjustments associated with our deferred tax liability for undistributed foreign earnings. Our effective tax rate in

[0000068505-14-000010:mdna:46]
27

[0000068505-14-000010:mdna:47]
the second quarter of 2013 was favorably impacted by $118 million of net tax benefits largely associated with the recognition of excess foreign tax credits on undistributed foreign earnings.

[0000068505-14-000010:mdna:48]
Earnings from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-14-000010:mdna:49]
We had earnings from continuing operations attributable to Motorola Solutions, Inc. of $78 million, or $0.30 per diluted share, in the second quarter of 2014, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $223 million, or $0.81 per diluted share, in the second quarter of 2013.

[0000068505-14-000010:mdna:50]
The decrease in earnings from continuing operations in the second quarter of 2014, as compared to the second quarter of 2013, was primarily driven by: (i) a $94 million decrease in gross margin primarily due to sales declines and a change in sales mix and (ii) a higher effective tax rate.  The decrease in earnings per diluted share from continuing operations was driven by lower earnings from continuing operations, partially offset by a reduction in shares outstanding as a result of our share repurchase program.

[0000068505-14-000010:mdna:51]
Earnings from Discontinued Operations

[0000068505-14-000010:mdna:52]
After taxes, we had $746 million, or $2.92 per diluted share, earnings from discontinued operations in the second quarter of 2014, compared to earnings from discontinued operations of $35 million, or $0.13 per diluted share, in the second quarter of 2013.

[0000068505-14-000010:mdna:53]
The increase in earnings from discontinued operations in the second quarter of 2014, as compared to the second quarter of 2013, was primarily driven by a $721 million tax benefit associated with establishing a deferred tax asset for outside basis differences on the Enterprise business. The $721 million tax benefit was partially offset by lower earnings in the Enterprise business in the second quarter of 2014 as compared to the second quarter of 2013. Upon the expected closing of the Enterprise business in the fourth quarter of 2014, we expect to incur a tax expense which will substantially offset this $721 tax benefit on a year-to-date basis.

[0000068505-14-000010:mdna:54]
Results of Operations—Six months ended June 28, 2014 compared to six months ended June 29, 2013

[0000068505-14-000010:mdna:55]
Net Sales

[0000068505-14-000010:mdna:56]
Net sales were $2.6 billion in the first half of 2014, down $271 million, or 9%, compared to net sales of $2.9 billion in the first half of 2013. The decrease in net sales reflects a $259 million, or 14%, decrease in net sales in the Products segment driven by: (i) declines in ASTRO in North America, as a result of fewer device sales from narrowbanding, and APME and (ii) PCR sales, primarily in North America, partially offset by single digit growth in EA and Latin America. In addition, the decrease in sales includes a $12 million, or 1%, decrease in net sales in the Services segment driven by declines in North America, as a result of iDEN services declines, and APME, partially offset by an increase in EA in Integration and Managed services.

[0000068505-14-000010:mdna:57]
Gross Margin

[0000068505-14-000010:mdna:58]
Gross margin was $1.2 billion, or 47.0% of net sales, in the first half of 2014, compared to $1.4 billion, or 49.9% of net sales, in the first half of 2013. The decrease in gross margin percentage is primarily due to: (i) a decline in gross margin as a percentage of sales in ASTRO in North America as a result of a shift from subscribers to infrastructure, which includes more third party equipment, and (ii) the lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-14-000010:mdna:59]
Selling, General and Administrative Expenses

[0000068505-14-000010:mdna:60]
Selling, general and administrative (“SG&A”) expenses decreased 8% to $615 million, or 23.5% of net sales, in the first half of 2014, compared to $665 million, or 23.0% of net sales, in the first half of 2013. The decrease in SG&A expenditures is primarily due to reduced compensation expenses, including incentives, pension expense, and the effect of headcount reductions enacted in previous periods.

[0000068505-14-000010:mdna:61]
Research and Development Expenditures

[0000068505-14-000010:mdna:62]
Research and development (“R&D”) expenditures decreased $32 million to $350 million, or 13.3% of net sales, in the first half of 2014, compared to $382 million, or 13.2% of net sales, in the first half of 2013. The decrease in R&D expenditures is primarily due to: (i) headcount reductions enacted during previous periods, (ii) lower incentive compensation expenses, and (iii) the reduction of spending in certain development programs, such as iDEN.

[0000068505-14-000010:mdna:63]
Other Charges

[0000068505-14-000010:mdna:64]
We recorded net charges of $23 million in Other charges in the first half of 2014, compared to net charges of $20 million in the first half of 2013. The net charges in the first half of 2014 included: (i) $34 million of net reorganization of business charges, (ii) $8 million of legal settlement charges, and (iii) $2 million of charges relating to the amortization of intangibles, partially offset by a $21 million gain on the sale of a building and land. The net charges in the first half of 2013 of $20 million

[0000068505-14-000010:mdna:65]
[same as prior period, unchanged from 0000068505-14-000008:mdna:112]

[0000068505-14-000010:mdna:66]
all related to net reorganization of business charges. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-14-000010:mdna:67]
Net Interest Expense

[0000068505-14-000010:mdna:68]
Net interest expense was $54 million in the first half of 2014, as compared to $57 million in the first half of 2013. Net interest expense in the first half of 2014 includes interest expense of $64 million, partially offset by interest income of $10 million.  Net interest expense in the first half of 2013 includes interest expense of $68 million, partially offset by interest income of $11 million.  The decrease in net interest expense in the first half of 2014  is primarily attributable to: (i) lower interest expense due to income tax-related interest charges of $5 million incurred in the second quarter of 2013 and (ii) a decrease in interest income due to lower average cash and cash equivalents during the first half of 2014 compared to the first half of 2013.

[0000068505-14-000010:mdna:69]
[same as prior period, unchanged from 0000068505-14-000008:mdna:35]

[0000068505-14-000010:mdna:70]
Net gains on sales of investments and businesses were $4 million in the first half of 2014 and $7 million in the first half of 2013. These net gains consisted primarily of gains on the sales of equity investments.

[0000068505-14-000010:mdna:71]
Other

[0000068505-14-000010:mdna:72]
Net Other expense was $9 million in the first half of 2014, compared to $3 million in the first half of 2013. The net Other expense in the first half of 2014 was primarily comprised of a $10 million foreign currency loss. The net Other expense in the first half of 2013 was primarily comprised of a $7 million loss on foreign currency, partially offset by $6 million of other net investment earnings.

[0000068505-14-000010:mdna:73]
Effective Tax Rate

[0000068505-14-000010:mdna:74]
We recorded $23 million of net tax expense in the first half of 2014, resulting in an effective tax rate of 12%, compared to $61 million of net tax benefit in the first half of 2013, resulting in a negative effective tax rate.  Our effective tax rate in the first half of 2014 was lower than the U.S. statutory tax rate of 35% due to: (i) a $30 million tax benefit associated with the net reduction in unrecognized tax benefits recorded in the first quarter of 2014 and (ii) $12 million of discrete tax benefits primarily related to return-to-provision adjustments associated with our deferred tax liability for undistributed foreign earnings. Our effective tax rate in the first half of 2013 was lower than the U.S. statutory tax rate of 35% due to: (i) $128 million of net tax benefits largely associated with excess foreign tax credits on undistributed foreign earnings, (ii) a $25 million reduction in our deferred tax liability for undistributed foreign earnings primarily due to changes in permanent reinvestment assertions, and (iii) an $8 million tax benefit for R&D tax credits.

[0000068505-14-000010:mdna:75]
Earnings from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-14-000010:mdna:76]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $163 million, or $0.63 per diluted share, in the first half of 2014, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $380 million, or $1.37 per diluted share, in the first half of 2013.

[0000068505-14-000010:mdna:77]
The decrease in earnings from continuing operations in the first half of 2014, as compared to the first half of 2013, was primarily driven by: (i) a $210 million decrease in gross margin primarily due to sales declines and a change in sales mix and (ii) a higher effective tax rate. The decrease in earnings per diluted share was driven by lower earnings from continuing operations, partially offset by a reduction in shares outstanding as a result of our share repurchase program.

[0000068505-14-000010:mdna:78]
Earnings from Discontinued Operations

[0000068505-14-000010:mdna:79]
After taxes, we had $788 million, or $3.07 per diluted share, earnings from discontinued operations in the first half of 2014, compared to earnings from discontinued operations of $70 million, or $0.25 per diluted share, in the first half of 2013.

[0000068505-14-000010:mdna:80]
The increase in earnings from discontinued operations in the first half of 2014, as compared to the first half of 2013, was primarily driven by a $721 million tax benefit associated with establishing a deferred tax asset for outside basis differences on the Enterprise business. The $721 million tax benefit was partially offset by slightly lower earnings in the Enterprise business in the first half of 2014 as compared to the first half of 2013. Upon the expected closing of the Enterprise business in the fourth quarter of 2014, we expect to incur a tax expense which will substantially offset this $721 tax benefit on a year-to-date basis.

[0000068505-14-000010:mdna:81]
[same as prior period, unchanged from 0000068505-14-000008:mdna:45]

[0000068505-14-000010:mdna:82]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and six months ended June 28, 2014 and June 29, 2013 as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-14-000010:mdna:83]
Products Segment

[0000068505-14-000010:mdna:84]
For the second quarter of 2014, the segment’s net sales represented 64% of our consolidated net sales, compared to 66% of our consolidated net sales for the second quarter of 2013. For the first half of 2014, the segment’s net sales represented 63% of our consolidated net sales, compared to 66% of our consolidated net sales for the first half of 2013.

[0000068505-14-000010:mdna:85]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 28, 2014 |  | June 29, 2013 |  | % Change |  | June 28, 2014 |  | June 29, 2013 |  | % Change |
| Segment net sales | $ | 887 |  |  | $ | 986 |  |  | (10 | )% |  | $ | 1,640 |  |  | $ | 1,899 |  |  | (14 | )% |
| Operating earnings | 95 |  |  | 125 |  |  | (24 | )% |  | 134 |  |  | 231 |  |  | (42 | )% |

[0000068505-14-000010:mdna:86]
Three months ended June 28, 2014 compared to three months ended June 29, 2013

[0000068505-14-000010:mdna:87]
The segment’s net sales decreased $99 million, to $887 million in the second quarter of 2014, as compared to $986 million during the second quarter of 2013. The decrease in net sales in the Products segment reflects a decrease in sales of: (i) ASTRO equipment in North America and APME and (ii) PCR sales in North America, partially offset by growth in TETRA. On a geographic basis, net sales declined in North America and APME, and increased in Latin America and EA, compared to the second quarter of 2013. The decline in North America was driven by lower ASTRO sales to state and local public safety customers and lower PCR sales.  The decline in APME was driven by lower sales in ASTRO.  The increase in Latin America was driven by double-digit growth in ASTRO.  The increase in EA was primarily driven by TETRA sales. Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 60% of the segment’s net sales in the second quarter of 2014 and 67% of the segment’s net sales in the second quarter of 2013.

[0000068505-14-000010:mdna:88]
The segment had operating earnings of $95 million in the second quarter of 2014, compared to $125 million in the second quarter of 2013.  As a percentage of net sales in the second quarter of 2014 as compared to the second quarter of 2013, gross margin decreased, SG&A expenditures decreased, and R&D expenditures decreased.  The decrease in operating earnings was primarily driven by a decrease in net sales and change in product mix resulting in lower gross margin and an increase in Other charges as a result of increased reorganization of business charges.

[0000068505-14-000010:mdna:89]
Six months ended June 28, 2014 compared to six months ended June 29, 2013

[0000068505-14-000010:mdna:90]
The segment’s net sales decreased $259 million, to $1.6 billion in the first half of 2014, as compared to $1.9 billion in the first half of 2013. The decrease in net sales in the Products segment reflects a decrease in sales of: (i) ASTRO equipment in North America and APME and (ii) PCR sales in North America, partially offset by growth in TETRA. On a geographic basis, net sales declined in North America and APME, and increased in Latin America and EA, compared to the first half of 2013. The decline in North America was driven by lower ASTRO sales to state and local public safety customers and lower PCR sales. The decline in APME was driven by lower sales in ASTRO. The increase in Latin America was driven by double-digit growth in ASTRO. The increase in EA was primarily driven by TETRA sales. Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 60% of the segment’s net sales in the first half of 2014 and 64% of the segment’s net sales in the first half of 2013.

[0000068505-14-000010:mdna:91]
The segment had operating earnings of $134 million in the first half of 2014, compared to $231 million in the first half of 2013. As a percentage of net sales in the first half of 2014 as compared to the first half of 2013, gross margin decreased, SG&A expenditures decreased, and R&D expenditures decreased.  The decrease in operating earnings was primarily driven by a decrease in net sales and change in product mix resulting in lower gross margin and an increase in Other charges as a result of increased reorganization of business charges.

[0000068505-14-000010:mdna:92]
Services Segment

[0000068505-14-000010:mdna:93]
For the second quarter of 2014, the segment’s net sales represented 36% of our consolidated net sales, compared to 34% of our consolidated net sales for the second quarter of 2013. For the first half of 2014, the segment’s net sales represented 37% of our consolidated net sales, compared to 34% of our consolidated net sales for the first half of 2013.

[0000068505-14-000010:mdna:94]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 28, 2014 |  | June 29, 2013 |  | % Change |  | June 28, 2014 |  | June 29, 2013 |  | % Change |
| Segment net sales | $ | 506 |  |  | $ | 511 |  |  | (1 | )% |  | $ | 982 |  |  | $ | 994 |  |  | (1 | )% |
| Operating earnings | 43 |  |  | 78 |  |  | (45 | )% |  | 111 |  |  | 145 |  |  | (23 | )% |

[0000068505-14-000010:mdna:95]
Three months ended June 28, 2014 compared to three months ended June 29, 2013

[0000068505-14-000010:mdna:96]
The segment’s net sales decreased $5 million, or 1%, to $506 million in the second quarter of 2014, as compared to $511 million in the second quarter of 2013. The 1% decrease in net sales in the Services segment reflects a decrease in sales of iDEN services, partially offset by a slight increase in Integration services. On a geographic basis, net sales declined in North America and APME, increased slightly in EA, and remained constant in Latin America, compared to the second quarter of 2013.  The decline in North America was driven by the decline in iDEN services sales. The decrease in APME was driven by lower Integration services sales.  The increase in EA was primarily driven by Integration and Managed services sales.  Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 61% of the segment’s net sales in the second quarters of 2014 and 2013.

[0000068505-14-000010:mdna:97]
The segment had operating earnings of $43 million in the second quarter of 2014, compared to $78 million in the second quarter of 2013 as a result of lower gross margins related to long-term project mix.  As a percentage of net sales in the second quarter of 2014 as compared to the second quarter of 2013, gross margin and SG&A expenditures decreased, and R&D expenditures increased.

[0000068505-14-000010:mdna:98]
Six months ended June 28, 2014 compared to six months ended June 29, 2013

[0000068505-14-000010:mdna:99]
The segment’s net sales decreased $12 million, or 1%, to $982 million in the first half of 2014, as compared to net sales of $994 million in the first half of 2013. The 1% decrease in net sales in the Services segment reflects a decrease in sales of: (i) iDEN services and (ii) Lifecycle Management and Support services, partially offset by an increase in sales of Integration services. On a geographic basis, net sales declined in North America and APME, increased in EA, and remained constant in Latin America, compared to the first half of 2013.  The decline in North America was driven by lower sales in (i) iDEN and (ii) Lifecycle Management and Support services. The decrease in APME was driven by lower Lifecycle Management and Support and Integration services.  The increase in EA was primarily driven by higher Integration and Managed services, partially offset by lower sales of Lifecycle Management and Support services.  Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 60% of the segment’s net sales in the first half of 2014 and 61% of the segment’s net sales in the first half of 2013.

[0000068505-14-000010:mdna:100]
The segment had operating earnings of $111 million in the first half of 2014, compared to operating earnings of $145 million in the first half of 2013.  As a percentage of net sales in the first half of 2014 as compared to the first half of 2013, gross margin and SG&A expenditures decreased, and R&D expenditures increased. The decrease in operating earnings was primarily related to declines in gross margin.

[0000068505-14-000010:mdna:101]
[same as prior period, unchanged from 0000068505-14-000008:mdna:61]

[0000068505-14-000010:mdna:102]
During the first half of 2014, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the three months ended June 28, 2014, we recorded net reorganization of business charges of $28 million related to the separation of approximately 400 employees, of which 300 were indirect employees and 100 were direct employees. Of the $28 million, $25 million of charges were recorded within Other charges and $3 million in Cost of sales in our condensed consolidated statements of operations. The $28 million of charges were all related to employee separation costs.

[0000068505-14-000010:mdna:103]
During the six months ended June 28, 2014, we recorded net reorganization of business charges of $38 million including separation costs for approximately 600 employees, of which 500 were indirect employees and 100 were direct employees. The $38 million recorded for net reorganization of business charges included $34 million of charges recorded in Other charges and $4 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $38 million are charges of $34 million for employee separation costs and $4 million for exit costs.

[0000068505-14-000010:mdna:104]
During the three months ended June 29, 2013, we recorded net reorganization of business charges of $18 million related to the separation of approximately 300 employees, of which 200 were indirect employees and 100 were direct employees. Included in the aggregate $18 million of charges were $13 million of charges recorded in Other charges and $5 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $18 million are charges of $19 million for employee separation costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-14-000010:mdna:105]
During the six months ended June 29, 2013, we recorded net reorganization of business charges of $25 million including separation costs for approximately 400 employees, of which 100 were direct employees and 300 were indirect employees. The $25 million of charges included $20 million recorded in Other charges and $5 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $25 million are charges of $29 million for employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-14-000010:mdna:106]
We expect to realize cost-saving benefits of approximately $23 million during the remaining six months of 2014 from the plans that were initiated during the first six months of 2014. Beyond 2014, we expect the reorganization plans initiated during

[0000068505-14-000010:mdna:107]
the first six months of 2014 to provide annualized cost savings of approximately $37 million, consisting of: (i) $33 million of savings in operating expenses and (ii) $4 million of savings in Cost of Sales.

[0000068505-14-000010:mdna:108]
[same as prior period, unchanged from 0000068505-14-000008:mdna:65]

[0000068505-14-000010:mdna:109]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Products | $ | 18 |  |  | $ | 12 |  |  | $ | 24 |  |  | $ | 17 |  |
| Services | 10 |  |  | 6 |  |  | 14 |  |  | 8 |  |
|  | $ | 28 |  |  | $ | 18 |  |  | $ | 38 |  |  | $ | 25 |  |

[0000068505-14-000010:mdna:110]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $75 million in the first six months of 2014 and $32 million in the first six months of 2013. These cash payments included $25 million in the first six months of 2014 and $11 million in the first six months of 2013. Of the $85 million of reorganization of businesses accruals at June 28, 2014, including those related to discontinued operations which will be maintained by us after the sale of our Enterprise business, $78 million relate to employee separation costs and are expected to be paid within one year. The remaining $7 million in accruals primarily relate to lease termination obligations that are expected to be paid over a number of years.

[0000068505-14-000010:mdna:111]
[same as prior period, unchanged from 0000068505-14-000008:mdna:68]

[0000068505-14-000010:mdna:112]
We decreased the aggregate of our cash and cash equivalent balances by $349 million from $3.2 billion as of December 31, 2013 to $2.9 billion as of June 28, 2014.  The decrease is primarily due to $631 million of capital returned to shareholders through share repurchases and dividends paid during the first half of 2014, partially offset by: (i) $100 million of distributions from discontinued operations and (ii) $130 million generated by operating activities.

[0000068505-14-000010:mdna:113]
[same as prior period, unchanged from 0000068505-14-000008:mdna:70]

[0000068505-14-000010:mdna:114]
[same as prior period, unchanged from 0000068505-14-000008:mdna:71]

[0000068505-14-000010:mdna:115]
Our cash and cash equivalents (which are highly-liquid investments with an original maturity of three months or less) were $2.9 billion at June 28, 2014 and $3.2 billion at December 31, 2013. At June 28, 2014, $1.7 billion of this amount was held in the U.S. and approximately $1.2 billion was held by the Company or its subsidiaries in other countries (including $516 million in the United Kingdom). At June 28, 2014 and December 31, 2013, restricted cash was $64 million and $63 million, respectively.

[0000068505-14-000010:mdna:116]
[same as prior period, unchanged from 0000068505-14-000008:mdna:73]

[0000068505-14-000010:mdna:117]
review various repatriation strategies to efficiently repatriate funds in the context of meeting our business needs in a tax efficient manner. During the first half of 2014, we repatriated $297 million in funds to the U.S. from international jurisdictions. We have approximately $650 million of foreign earnings that are not permanently reinvested and may be repatriated without an additional income tax charge given the U.S. federal and foreign tax accrued on undistributed earnings and the utilization of available foreign tax credits. Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy. While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay for local country approvals and could have potential adverse cash tax consequences.

[0000068505-14-000010:mdna:118]
[same as prior period, unchanged from 0000068505-14-000008:mdna:76]

[0000068505-14-000010:mdna:119]
[same as prior period, unchanged from 0000068505-14-000008:mdna:77]

[0000068505-14-000010:mdna:120]
Net cash provided by operating activities in the first half of 2014 was $130 million, as compared to $100 million of cash used for operating activities in the first half of 2013. Operating cash flows in the first half of 2014, as compared to the first half of 2013, were positively impacted by: (i) collections primarily related to our long-term contracts, (ii) the return of the India tax withdrawals seized in the first quarter of 2013, and (iii) lower incentive and legal settlement payments, partially offset by: (i) lower operating earnings and (ii) higher employee severance payments.

[0000068505-14-000010:mdna:121]
[same as prior period, unchanged from 0000068505-14-000008:mdna:79]

[0000068505-14-000010:mdna:122]
[same as prior period, unchanged from 0000068505-14-000008:mdna:80]

[0000068505-14-000010:mdna:123]
Competent Authorities. As a result of our appeals, the Supreme Court of India directed the Indian tax authorities to refund the full amount of cash seized and such refund was received by our Indian subsidiary during the first half of 2014.

[0000068505-14-000010:mdna:124]
We contributed $66 million to our U.S. pension plans during the first half of 2014, compared to $50 million contributed in the first half of 2013. Subsequent to quarter end, we made a planned contribution of $40 million to our U.S. pension plans. We contributed $20 million to our non-U.S. pension plans during the first half of 2014, compared to $17 million contributed in the first half of 2013.

[0000068505-14-000010:mdna:125]
[same as prior period, unchanged from 0000068505-14-000008:mdna:83]

[0000068505-14-000010:mdna:126]
Net cash used for investing activities was $48 million in the first half of 2014, compared to net cash provided by investing activities of $325 million in the first half of 2013. This $373 million decline was primarily due to $376 million of proceeds from sales of Sigma Fund investments in the first half of 2013 with no comparable activity in the first half of 2014.

[0000068505-14-000010:mdna:127]
Acquisition and Investments: We used net cash for acquisitions and investments of $11 million during the first six months of 2014 compared to $8 million in the first six months of 2013. The cash used for investments in both periods relates to a number of equity investments.

[0000068505-14-000010:mdna:128]
Sales of Investments and Businesses: We had $21 million of proceeds related to the sales of investments and businesses in both the first six months of 2014 and the first six months of 2013.  The proceeds in both periods were comprised of sales of certain equity investments.

[0000068505-14-000010:mdna:129]
Capital Expenditures: Capital expenditures increased slightly in the first six months of 2014 to $82 million, compared to $79 million in the first six months of 2013.  The increase in capital expenditures was driven by increased revenue-generating network expenditures, partially offset by decreased information technology infrastructure expenditures.

[0000068505-14-000010:mdna:130]
Sales of Property, Plant, and Equipment:  We had $24 million of proceeds related to the sale of property, plant, and equipment in the first six months of 2014 compared to $15 million in the first six months of 2013.  The proceeds in both periods were comprised of sales of buildings and land.

[0000068505-14-000010:mdna:131]
[same as prior period, unchanged from 0000068505-14-000008:mdna:88]

[0000068505-14-000010:mdna:132]
Net cash used for financing activities was $438 million in the first six months of 2014, compared to $205 million in the first six months of 2013. Cash used for financing activities in the first six months of 2014 was primarily comprised of: (i) $473 million used for purchases of our common stock under our share repurchase program and (ii) $158 million of cash used for the payment of dividends, partially offset by: (i) $100 million of distributions from discontinued operations and (ii) $85 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.  Net cash used for financing activities in the first six months of 2013 was primarily comprised of: (i) $907 million used for purchases of our common stock under our share repurchase program and (ii) $143 million of cash used for the payment of dividends, partially offset by: (i) $593 million of net proceeds from the issuance of debt, (ii) $99 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan, and (iii) $137 million of distributions from discontinued operations.

[0000068505-14-000010:mdna:133]
Long-Term Debt: We had outstanding long-term debt of $2.5 billion at both June 28, 2014 and December 31, 2013, including the current portions of $4 million at both June 28, 2014 and December 31, 2013.

[0000068505-14-000010:mdna:134]
[same as prior period, unchanged from 0000068505-14-000008:mdna:91]

[0000068505-14-000010:mdna:135]
Share Repurchase Program: We paid an aggregate of $416 million during the second quarter of 2014, including transaction costs, to repurchase 6.2 million shares at an average price of $66.96 per share. We paid an aggregate of $473 million during the first half of 2014, including transaction costs, to repurchase approximately 7.1 million shares at an average price of $66.88 per share.  All repurchased shares have been retired.

[0000068505-14-000010:mdna:136]
As of June 28, 2014, we have used approximately $5.7 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $1.3 billion of authority available for future repurchases.

[0000068505-14-000010:mdna:137]
Payment of Dividends: During the second quarter of 2014, we paid $79 million in cash dividends to holders of our common stock. During the first half of 2014, we paid $158 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid $78 million in cash dividends to holders of our common stock.

[0000068505-14-000010:mdna:138]
On July 31, 2014, we announced that our Board of Directors approved an increase in the quarterly cash dividend from $0.31 per share to $0.34 per share of common stock.

[0000068505-14-000010:mdna:139]
33

[0000068505-14-000010:mdna:140]
[same as prior period, unchanged from 0000068505-14-000008:mdna:96]

[0000068505-14-000010:mdna:141]
As of June 28, 2014, we had a $2.0 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. Effective May 29, 2014, this facility replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) which was scheduled to mature on June 30, 2014. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We are no longer subject to a minimum interest coverage covenant under the new facility. We were in compliance with our financial covenants as of June 28, 2014. We did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the six months ended June 28, 2014.

[0000068505-14-000010:mdna:142]
As of June 28, 2014, we had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of June 28, 2014.

[0000068505-14-000010:mdna:143]
[same as prior period, unchanged from 0000068505-14-000008:mdna:98]

[0000068505-14-000010:mdna:144]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser’s credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us.  We had outstanding commitments to provide long-term financing to third parties totaling $166 million at June 28, 2014, compared to $50 million at December 31, 2013.

[0000068505-14-000010:mdna:145]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $18 million at June 28, 2014, compared to $1 million at December 31, 2013. These long-term receivables are generally interest bearing, with interest rates ranging from 0% to 9%.

[0000068505-14-000010:mdna:146]
[same as prior period, unchanged from 0000068505-14-000008:mdna:101]

[0000068505-14-000010:mdna:147]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended June 28, 2014 and June 29, 2013:

[0000068505-14-000010:mdna:148]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Proceeds received: |  |  |  |  |  |  |  |
| Accounts receivable sales proceeds | $ | 26 |  |  | $ | 2 |  |  | $ | 33 |  |  | $ | 3 |  |
| Long-term receivables sales proceeds | 52 |  |  | 25 |  |  | 52 |  |  | 52 |  |
| Total proceeds from sales of accounts receivable | $ | 78 |  |  | $ | 27 |  |  | $ | 85 |  |  | $ | 55 |  |

[0000068505-14-000010:mdna:149]
At June 28, 2014, we had retained servicing obligations for $460 million of sold long-term receivables, compared to $434 million of sold long-term receivables at December 31, 2013.  Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-14-000010:mdna:150]
Other Contingencies

[0000068505-14-000010:mdna:151]
[same as prior period, unchanged from 0000068505-14-000008:mdna:106]

[0000068505-14-000010:mdna:152]
Indemnification Provisions:  We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial, intellectual property and divestiture agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, our payment is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, for which procedures typically allow us to challenge the other party’s claims. Further, our obligations under divestiture agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, typically not more than 24 months, and for amounts not in excess of the contract value.

[0000068505-14-000010:mdna:153]
34

[0000068505-14-000010:mdna:154]
[same as prior period, unchanged from 0000068505-14-000008:mdna:108]

[0000068505-14-000010:mdna:155]
[same as prior period, unchanged from 0000068505-14-000008:mdna:109]

[0000068505-14-000010:mdna:156]
[same as prior period, unchanged from 0000068505-14-000008:mdna:110]

[0000068505-14-000010:mdna:157]
In January 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for us beginning January 1, 2015. We are currently assessing the impact of this standard on our consolidated financial statements and footnote disclosures.

[0000068505-14-000010:mdna:158]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. The ASU will be effective for us beginning January 1, 2017, and allows for both retrospective and modified-retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-14-000010:mdna:159]
35
