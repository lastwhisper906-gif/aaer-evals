# MSI notes — 0000068505-15-000010


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-15-000010:notes:1]
[same as prior period, unchanged from 0000068505-15-000006:notes:1]

[0000068505-15-000010:notes:2]
| July 4, 2015 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Corporate bonds | 9 |  |  | — |  |  | 9 |  |
| Common stock | — |  |  | 23 |  |  | 23 |  |
|  | 40 |  |  | 23 |  |  | 63 |  |
| Other investments, at cost | 208 |  |  | — |  |  | 208 |  |
| Equity method investments | 14 |  |  | — |  |  | 14 |  |
|  | $ | 262 |  |  | $ | 23 |  |  | $ | 285 |  |

[0000068505-15-000010:notes:3]
[same as prior period, unchanged from 0000068505-15-000006:notes:3]


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-15-000010:notes:4]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of July 4, 2015 and December 31, 2014 were as follows:

[0000068505-15-000010:notes:5]
| July 4, 2015 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 3 |  |  | $ | 3 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 31 |  |  | 31 |  |
| Corporate bonds | — |  |  | 9 |  |  | 9 |  |
| Common stock | 23 |  |  | — |  |  | 23 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest rate swap | — |  |  | 2 |  |  | 2 |  |

[0000068505-15-000010:notes:6]
[same as prior period, unchanged from 0000068505-15-000006:notes:6]


## msi:LongTermReceivableLoansAndLeaseTableTextBlock

[0000068505-15-000010:notes:7]
[same as prior period, unchanged from 0000068505-15-000006:notes:7]

[0000068505-15-000010:notes:8]
|  | July 4, 2015 |  | December 31, 2014 |
| Long-term receivables | $ | 29 |  |  | $ | 49 |  |
| Less current portion | (11 | ) |  | (18 | ) |
| Non-current long-term receivables, net | $ | 18 |  |  | $ | 31 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-15-000010:notes:9]
[same as prior period, unchanged from 0000068505-15-000006:notes:9]

[0000068505-15-000010:notes:10]
[same as prior period, unchanged from 0000068505-15-000006:notes:10]

[0000068505-15-000010:notes:11]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $107 million at July 4, 2015, compared to $293 million at December 31, 2014. Outstanding commitments decreased during the six months ended July 4, 2015 primarily as a result of two large customer contracts, one of which was converted to an order without long-term financing and the other where the financing commitment was funded and sold.

[0000068505-15-000010:notes:12]
[same as prior period, unchanged from 0000068505-15-000006:notes:12]

[0000068505-15-000010:notes:13]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended July 4, 2015 and June 28, 2014:

[0000068505-15-000010:notes:14]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Accounts receivable sales proceeds | $ | 5 |  |  | $ | 26 |  |  | $ | 11 |  |  | $ | 33 |  |
| Long-term receivables sales proceeds | 43 |  |  | 52 |  |  | 108 |  |  | 52 |  |
| Total proceeds from receivable sales | $ | 48 |  |  | $ | 78 |  |  | $ | 119 |  |  | $ | 85 |  |

[0000068505-15-000010:notes:15]
At July 4, 2015, the Company had retained servicing obligations for $627 million of long-term receivables, compared to $496 million of long-term receivables at December 31, 2014.  Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-15-000010:notes:16]
[same as prior period, unchanged from 0000068505-15-000006:notes:16]

[0000068505-15-000010:notes:17]
An aging analysis of financing receivables at July 4, 2015 and December 31, 2014 is as follows:

[0000068505-15-000010:notes:18]
| July 4, 2015 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 24 |  |  | — |  |  | 1 |  |  | 1 |  |
| Total gross long-term receivables, including current portion | $ | 29 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |

[0000068505-15-000010:notes:19]
[same as prior period, unchanged from 0000068505-15-000006:notes:19]


## msi:OtherChargesTableTextBlock

[0000068505-15-000010:notes:20]
[same as prior period, unchanged from 0000068505-15-000006:notes:21]

[0000068505-15-000010:notes:21]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization | $ | 3 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 2 |  |
| Reorganization of business | 13 |  |  | 25 |  |  | 26 |  |  | 34 |  |
| Legal settlement | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Non-U.S. pension curtailment gain | (32 | ) |  | — |  |  | (32 | ) |  | — |  |
| Gain on sale of building and land | — |  |  | — |  |  | — |  |  | (21 | ) |
|  | $ | (16 | ) |  | $ | 34 |  |  | $ | (2 | ) |  | $ | 23 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-15-000010:notes:22]
[same as prior period, unchanged from 0000068505-15-000006:notes:23]

[0000068505-15-000010:notes:23]
| July 4, 2015 | Three Months Ended |  | Six Months Ended |
| Products | $ | 12 |  |  | $ | 22 |  |
| Services | 4 |  |  | 8 |  |
|  | $ | 16 |  |  | $ | 30 |  |

[0000068505-15-000010:notes:24]
| June 28, 2014 | Three Months Ended |  | Six Months Ended |
| Products | $ | 18 |  |  | $ | 24 |  |
| Services | 10 |  |  | 14 |  |
|  | $ | 28 |  |  | $ | 38 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-15-000010:notes:25]
[same as prior period, unchanged from 0000068505-15-000006:notes:26]

[0000068505-15-000010:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 7 |  |
| Selling, general and administrative expenses | 12 |  |  | 16 |  |  | 25 |  |  | 33 |  |
| Research and development expenditures | 5 |  |  | 7 |  |  | 10 |  |  | 14 |  |
| Share-based compensation expense included in Operating earnings | 19 |  |  | 26 |  |  | 40 |  |  | 54 |  |
| Tax benefit | 6 |  |  | 8 |  |  | 13 |  |  | 17 |  |
| Share-based compensation expense, net of tax | $ | 13 |  |  | $ | 18 |  |  | $ | 27 |  |  | $ | 37 |  |
| Decrease in basic earnings per share | $ | (0.06 | ) |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.15 | ) |
| Decrease in diluted earnings per share | $ | (0.06 | ) |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.14 | ) |
| Share-based compensation expense in discontinued operations | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 13 |  |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-15-000010:notes:27]
[same as prior period, unchanged from 0000068505-15-000006:notes:28]

[0000068505-15-000010:notes:28]
|  | July 4, 2015 |  | December 31, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 89 |  |  | $ | 57 |  |  | $ | 77 |  |  | $ | 54 |  |
| Services | 21 |  |  | 1 |  |  | — |  |  | — |  |
|  | $ | 110 |  |  | $ | 58 |  |  | $ | 77 |  |  | $ | 54 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-15-000010:notes:29]
[same as prior period, unchanged from 0000068505-15-000006:notes:30]

[0000068505-15-000010:notes:30]
|  | July 4, 2015 |  | December 31, 2014 |
| Defined benefit plans | $ | 1,600 |  |  | $ | 1,611 |  |
| Postretirement Health Care Benefit Plan | 39 |  |  | 49 |  |
| Deferred revenue | 121 |  |  | 139 |  |
| Unrecognized tax benefits | 51 |  |  | 54 |  |
| Other | 162 |  |  | 158 |  |
|  | $ | 1,973 |  |  | $ | 2,011 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-15-000010:notes:31]
[same as prior period, unchanged from 0000068505-15-000006:notes:32]

[0000068505-15-000010:notes:32]
[same as prior period, unchanged from 0000068505-15-000006:notes:33]

[0000068505-15-000010:notes:33]
[same as prior period, unchanged from 0000068505-15-000006:notes:34]

[0000068505-15-000010:notes:34]
[same as prior period, unchanged from 0000068505-15-000006:notes:35]

[0000068505-15-000010:notes:35]
[same as prior period, unchanged from 0000068505-15-000006:notes:36]

[0000068505-15-000010:notes:36]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (42 | ) |  | $ | (34 | ) |  | $ | (86 | ) |  | $ | (64 | ) |
| Interest income | 3 |  |  | 5 |  |  | 7 |  |  | 10 |  |
|  | $ | (39 | ) |  | $ | (29 | ) |  | $ | (79 | ) |  | $ | (54 | ) |
| Other: |  |  |  |  |  |  |  |
| Investment impairments | (3 | ) |  | — |  |  | (3 | ) |  | — |  |
| Foreign currency gain (loss) | (11 | ) |  | (7 | ) |  | $ | 7 |  |  | $ | (8 | ) |
| Gain (loss) on derivative instruments | 4 |  |  | (1 | ) |  | (12 | ) |  | (2 | ) |
| Gains on equity method investments | 4 |  |  | 2 |  |  | 4 |  |  | 2 |  |
| Other | 2 |  |  | (1 | ) |  | 3 |  |  | (1 | ) |
|  | $ | (4 | ) |  | $ | (7 | ) |  | $ | (1 | ) |  | $ | (9 | ) |

[0000068505-15-000010:notes:37]
[same as prior period, unchanged from 0000068505-15-000006:notes:38]

[0000068505-15-000010:notes:38]
[same as prior period, unchanged from 0000068505-15-000006:notes:39]

[0000068505-15-000010:notes:39]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Three Months Ended | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 150 |  |  | $ | 78 |  |  | $ | 142 |  |  | $ | 824 |  |
| Weighted average common shares outstanding | 208.0 |  |  | 253.7 |  |  | 208.0 |  |  | 253.7 |  |
| Per share amount | $ | 0.72 |  |  | $ | 0.31 |  |  | $ | 0.68 |  |  | $ | 3.25 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 150 |  |  | $ | 78 |  |  | $ | 142 |  |  | $ | 824 |  |
| Weighted average common shares outstanding | 208.0 |  |  | 253.7 |  |  | 208.0 |  |  | 253.7 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 1.5 |  |  | 2.5 |  |  | 1.5 |  |  | 2.5 |  |
| Diluted weighted average common shares outstanding | 209.5 |  |  | 256.2 |  |  | 209.5 |  |  | 256.2 |  |
| Per share amount | $ | 0.72 |  |  | $ | 0.30 |  |  | $ | 0.68 |  |  | $ | 3.22 |  |

[0000068505-15-000010:notes:40]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Six Months Ended | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 238 |  |  | $ | 163 |  |  | $ | 217 |  |  | $ | 951 |  |
| Weighted average common shares outstanding | 211.7 |  |  | 253.8 |  |  | 211.7 |  |  | 253.8 |  |
| Per share amount | $ | 1.12 |  |  | $ | 0.64 |  |  | $ | 1.03 |  |  | $ | 3.75 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 238 |  |  | $ | 163 |  |  | $ | 217 |  |  | $ | 951 |  |
| Weighted average common shares outstanding | 211.7 |  |  | 253.8 |  |  | 211.7 |  |  | 253.8 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.1 |  |  | 3.4 |  |  | 2.1 |  |  | 3.4 |  |
| Diluted weighted average common shares outstanding | 213.8 |  |  | 257.2 |  |  | 213.8 |  |  | 257.2 |  |
| Per share amount | $ | 1.11 |  |  | $ | 0.63 |  |  | $ | 1.01 |  |  | $ | 3.70 |  |

[0000068505-15-000010:notes:41]
In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three months ended July 4, 2015, the assumed exercise of 1.7 million options and the assumed vesting of 0.7 million RSUs were excluded because their inclusion would have been antidilutive. For the six months ended July 4, 2015, the assumed exercise of 3.9 million options and the assumed vesting of 1.2 million RSUs were excluded because their inclusion would have been antidilutive.

[0000068505-15-000010:notes:42]
For the three and six months ended June 28, 2014, the assumed exercise of 4.6 million and 4.8 million stock options, respectively, were excluded because their inclusion would have been antidilutive.

[0000068505-15-000010:notes:43]
[same as prior period, unchanged from 0000068505-15-000006:notes:42]

[0000068505-15-000010:notes:44]
[same as prior period, unchanged from 0000068505-15-000006:notes:43]

[0000068505-15-000010:notes:45]
The Company’s cash and cash equivalents were $3.1 billion at July 4, 2015 and $4.0 billion at December 31, 2014. Of these amounts, $63 million was restricted at both July 4, 2015 and December 31, 2014.

[0000068505-15-000010:notes:46]
[same as prior period, unchanged from 0000068505-15-000006:notes:45]

[0000068505-15-000010:notes:47]
During the three months ended July 4, 2015, the Company recorded investment impairment charges of $3 million related to cost method investments and sold a cost method investment recognizing a gain on sale of $4 million. During the six months ended July 4, 2015, the Company sold shares of an equity investment realizing cash proceeds of $47 million and a previously unrecognized gain of $46 million.

[0000068505-15-000010:notes:48]
[same as prior period, unchanged from 0000068505-15-000006:notes:47]

[0000068505-15-000010:notes:49]
[same as prior period, unchanged from 0000068505-15-000006:notes:48]

[0000068505-15-000010:notes:50]
|  | July 4, 2015 |  | December 31, 2014 |
| Accounts receivable | $ | 1,168 |  |  | $ | 1,444 |  |
| Less allowance for doubtful accounts | (27 | ) |  | (35 | ) |
|  | $ | 1,141 |  |  | $ | 1,409 |  |

[0000068505-15-000010:notes:51]
[same as prior period, unchanged from 0000068505-15-000006:notes:50]

[0000068505-15-000010:notes:52]
[same as prior period, unchanged from 0000068505-15-000006:notes:51]

[0000068505-15-000010:notes:53]
|  | July 4, 2015 |  | December 31, 2014 |
| Finished goods | $ | 165 |  |  | $ | 163 |  |
| Work-in-process and production materials | 337 |  |  | 313 |  |
|  | 502 |  |  | 476 |  |
| Less inventory reserves | (138 | ) |  | (131 | ) |
|  | $ | 364 |  |  | $ | 345 |  |

[0000068505-15-000010:notes:54]
[same as prior period, unchanged from 0000068505-15-000006:notes:53]

[0000068505-15-000010:notes:55]
[same as prior period, unchanged from 0000068505-15-000006:notes:54]

[0000068505-15-000010:notes:56]
|  | July 4, 2015 |  | December 31, 2014 |
| Costs and earnings in excess of billings | $ | 385 |  |  | $ | 417 |  |
| Tax-related refunds receivable | 90 |  |  | 103 |  |
| Zebra receivable for cash transferred | — |  |  | 49 |  |
| Other | 118 |  |  | 171 |  |
|  | $ | 593 |  |  | $ | 740 |  |

[0000068505-15-000010:notes:57]
In conjunction with the sale of the Enterprise business to Zebra Technologies, the Company transferred legal entities which maintained cash balances. During the six months ended July 4, 2015, approximately $49 million of transferred cash balances were reimbursed by Zebra in accordance with the sales agreement.

[0000068505-15-000010:notes:58]
[same as prior period, unchanged from 0000068505-15-000006:notes:57]

[0000068505-15-000010:notes:59]
[same as prior period, unchanged from 0000068505-15-000006:notes:58]

[0000068505-15-000010:notes:60]
|  | July 4, 2015 |  | December 31, 2014 |
| Land | $ | 18 |  |  | $ | 18 |  |
| Building | 555 |  |  | 559 |  |
| Machinery and equipment | 1,695 |  |  | 1,672 |  |
|  | 2,268 |  |  | 2,249 |  |
| Less accumulated depreciation | (1,726 | ) |  | (1,700 | ) |
|  | $ | 542 |  |  | $ | 549 |  |

[0000068505-15-000010:notes:61]
Depreciation expense for the three months ended July 4, 2015 and June 28, 2014 was $38 million and $45 million, respectively. Depreciation expense for the six months ended July 4, 2015 and June 28, 2014 was $77 million and $84 million, respectively.

[0000068505-15-000010:notes:62]
[same as prior period, unchanged from 0000068505-15-000006:notes:61]

[0000068505-15-000010:notes:63]
[same as prior period, unchanged from 0000068505-15-000006:notes:62]

[0000068505-15-000010:notes:64]
|  | July 4, 2015 |  | December 31, 2014 |
| Intangible assets, net | $ | 52 |  |  | $ | 23 |  |
| Long-term receivables | 18 |  |  | 31 |  |
| Other | 90 |  |  | 91 |  |
|  | $ | 160 |  |  | $ | 145 |  |

[0000068505-15-000010:notes:65]
[same as prior period, unchanged from 0000068505-15-000006:notes:64]

[0000068505-15-000010:notes:66]
[same as prior period, unchanged from 0000068505-15-000006:notes:65]

[0000068505-15-000010:notes:67]
|  | July 4, 2015 |  | December 31, 2014 |
| Deferred revenue | $ | 335 |  |  | $ | 355 |  |
| Compensation | 180 |  |  | 190 |  |
| Billings in excess of costs and earnings | 346 |  |  | 358 |  |
| Tax liabilities | 68 |  |  | 91 |  |
| Dividend payable | 70 |  |  | 75 |  |
| Other | 551 |  |  | 637 |  |
|  | $ | 1,550 |  |  | $ | 1,706 |  |

[0000068505-15-000010:notes:68]
[same as prior period, unchanged from 0000068505-15-000006:notes:67]

[0000068505-15-000010:notes:69]
[same as prior period, unchanged from 0000068505-15-000006:notes:68]

[0000068505-15-000010:notes:70]
[same as prior period, unchanged from 0000068505-15-000006:notes:69]

[0000068505-15-000010:notes:71]
The Company paid an aggregate of $285 million during the three months ended July 4, 2015, including transaction costs, to repurchase approximately 4.6 million shares at an average price of $61.63 per share. The Company paid an aggregate of $938 million during the six months ended July 4, 2015, including transaction costs, to repurchase approximately 14.5 million shares at an average price of $64.69 per share. As of July 4, 2015, the Company had used approximately $8.7 billion of the share repurchase authority, including transaction costs, to repurchase shares leaving $3.3 billion of authority available for future repurchases.

[0000068505-15-000010:notes:72]
On August 4, 2015, the Board of Directors authorized the Company to commence a modified "Dutch auction" tender offer to repurchase up to $2 billion of its outstanding shares of common stock. The repurchase of these shares is authorized under the existing share repurchase authority as outlined above and the purchase will be funded with a combination of cash on hand and a portion of the proceeds raised through the issuance of new convertible notes (see Note 4). The Company anticipates commencing the tender offer on or about August 7, 2015. The tender offer is expected to close on or about September 4, 2015.

[0000068505-15-000010:notes:73]
Payment of Dividends:  During the three months ended July 4, 2015 and June 28, 2014, the Company paid $72 million and $79 million, respectively, in cash dividends to holders of its common stock. During the six months ended July 4, 2015 and June 28, 2014, the Company paid $148 million and $158 million, respectively, in cash dividends to holders of its common stock.

[0000068505-15-000010:notes:74]
[same as prior period, unchanged from 0000068505-15-000006:notes:72]

[0000068505-15-000010:notes:75]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three and six months ended July 4, 2015 and June 28, 2014:

[0000068505-15-000010:notes:76]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (230 | ) |  | $ | (94 | ) |  | $ | (204 | ) |  | $ | (96 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 7 |  |  | 8 |  |  | (18 | ) |  | 11 |  |
| Tax (expense) benefit | — |  |  | 5 |  |  | (1 | ) |  | 4 |  |
| Other comprehensive income (loss), net of tax | 7 |  |  | 13 |  |  | (19 | ) |  | 15 |  |
| Balance at end of period | $ | (223 | ) |  | $ | (81 | ) |  | $ | (223 | ) |  | $ | (81 | ) |
| Net loss on derivative instruments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |
| Reclassification adjustment into Cost of Sales | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Tax expense | — |  |  | — |  |  | — |  |  | — |  |
| Reclassification adjustment into Cost of Sales, net of tax | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other comprehensive income, net of tax | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Balance at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Unrealized Gains and Losses on Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | 11 |  |  | $ | — |  |  | $ | 44 |  |  | $ | (2 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 6 |  |  | — |  |  | (1 | ) |  | 2 |  |
| Tax (expense) benefit | (2 | ) |  | — |  |  | 1 |  |  | — |  |
| Other comprehensive income before reclassification adjustment, net of tax | 4 |  |  | — |  |  | — |  |  | 2 |  |
| Reclassification adjustment into Gains on Sales of investments and businesses, net | — |  |  | — |  |  | (46 | ) |  | — |  |
| Tax expense | — |  |  | — |  |  | 17 |  |  | — |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net of tax | — |  |  | — |  |  | (29 | ) |  | — |  |
| Other comprehensive income (loss), net of tax | 4 |  |  | — |  |  | (29 | ) |  | 2 |  |
| Balance at end of period | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | (1,694 | ) |  | (2,175 | ) |  | (1,695 | ) |  | (2,188 | ) |
| Other comprehensive loss before reclassification adjustment | (53 | ) |  | — |  |  | (53 | ) |  | — |  |
| Tax expense | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive loss before reclassification adjustment, net of tax | (53 | ) |  | — |  |  | (53 | ) |  | — |  |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 18 |  |  | 25 |  |  | 36 |  |  | 53 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (16 | ) |  | (9 | ) |  | (32 | ) |  | (18 | ) |
| Reclassification adjustment - Non-U.S. pension curtailment gain into Selling, general, and administrative expenses | (32 | ) |  | — |  |  | (32 | ) |  | — |  |
| Tax benefit | — |  |  | (5 | ) |  | (1 | ) |  | (11 | ) |
| Reclassification adjustment into Selling, general, and administrative expenses, net of tax | (30 | ) |  | 11 |  |  | (29 | ) |  | 24 |  |
| Other comprehensive income (loss), net of tax | (83 | ) |  | 11 |  |  | (82 | ) |  | 24 |  |
| Balance at end of period | $ | (1,777 | ) |  | $ | (2,164 | ) |  | $ | (1,777 | ) |  | $ | (2,164 | ) |
| Total Accumulated other comprehensive loss | $ | (1,985 | ) |  | $ | (2,245 | ) |  | $ | (1,985 | ) |  | $ | (2,245 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-15-000010:notes:77]
Commitments and Contingencies

[0000068505-15-000010:notes:78]
Legal Matters

[0000068505-15-000010:notes:79]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s condensed consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company’s: (i) results of operations in the periods in which an adverse outcome becomes both probable and estimable or (ii) financial position or liquidity in the periods in which the matters are ultimately resolved.

[0000068505-15-000010:notes:80]
Other Indemnifications

[0000068505-15-000010:notes:81]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters.  In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims.  In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-15-000010:notes:82]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at July 4, 2015.

[0000068505-15-000010:notes:83]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements.  Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-15-000010:notes:84]
Debt and Credit Facilities

[0000068505-15-000010:notes:85]
As of July 4, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 4, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the six months ended July 4, 2015.

[0000068505-15-000010:notes:86]
On August 4, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1 billion of 2% convertible notes which mature in September 2020. Interest on the notes will be payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.59854 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). The Company may, at its option, elect to settle the amount due upon conversion in cash, common stock, or a combination of cash and common stock. The Company expects to close this transaction on August 25, 2015.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-15-000010:notes:87]
[same as prior period, unchanged from 0000068505-15-000006:notes:84]

[0000068505-15-000010:notes:88]
[same as prior period, unchanged from 0000068505-15-000006:notes:85]

[0000068505-15-000010:notes:89]
As of July 4, 2015, the Company had outstanding foreign exchange contracts with notional amounts totaling $609 million, compared to $628 million outstanding at December 31, 2014.  The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-15-000010:notes:90]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of July 4, 2015, and the corresponding positions as of December 31, 2014:

[0000068505-15-000010:notes:91]
|  | Notional Amount |
| Net Buy (Sell) by Currency | July 4, 2015 |  | December 31, 2014 |
| Euro | $ | 158 |  |  | $ | 214 |  |
| Chinese Renminbi | (148 | ) |  | (161 | ) |
| Norwegian Krone | (91 | ) |  | (90 | ) |
| Australian Dollar | (60 | ) |  | (42 | ) |
| Brazilian Real | (46 | ) |  | (28 | ) |

[0000068505-15-000010:notes:92]
[same as prior period, unchanged from 0000068505-15-000006:notes:89]

[0000068505-15-000010:notes:93]
As of July 4, 2015, the Company had $3.4 billion of long-term debt, including the current portion, which is primarily priced at long-term, fixed interest rates.

[0000068505-15-000010:notes:94]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable and the Company has an interest rate swap in place which is not designated as a hedge. As such, the changes in the fair value of the interest rate swap are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swap was in a liability position of $2 million at July 4, 2015 and December 31, 2014.

[0000068505-15-000010:notes:95]
[same as prior period, unchanged from 0000068505-15-000006:notes:92]

[0000068505-15-000010:notes:96]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of July 4, 2015, all of the counterparties have investment grade credit ratings. As of July 4, 2015, the Company had $3 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-15-000010:notes:97]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of July 4, 2015 and December 31, 2014:

[0000068505-15-000010:notes:98]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| July 4, 2015 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  | Other current assets |  | $ | 1 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other current assets |  | 2 |  |  | Accrued liabilities |
| Total derivatives | $ | 3 |  |  |  |  | $ | 3 |  |  |  |

[0000068505-15-000010:notes:99]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2014 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | 1 |  |  | Other current assets |  | 5 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other current assets |  | 2 |  |  | Accrued liabilities |
| Total derivatives | 1 |  |  |  |  | 7 |  |  |  |

[0000068505-15-000010:notes:100]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated statements of operations for the three and six months ended July 4, 2015 and June 28, 2014:

[0000068505-15-000010:notes:101]
|  | Three Months Ended |  | Six Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |  |
| Interest rate swap | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | Other income (expense) |
| Foreign exchange contracts | 4 |  |  | (1 | ) |  | (13 | ) |  | (2 | ) |  | Other income (expense) |
| Total derivatives | $ | 4 |  |  | $ | (1 | ) |  | $ | (12 | ) |  | $ | (2 | ) |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-15-000010:notes:102]
[same as prior period, unchanged from 0000068505-15-000006:notes:99]

[0000068505-15-000010:notes:103]
During the six months ended July 4, 2015, the Company granted 0.8 million RSUs and 0.8 million stock options. The total aggregate compensation expense, net of estimated forfeitures, for these RSUs and stock options was $39 million and $9 million, respectively, which will be recognized over the vesting period of three years.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-15-000010:notes:104]
[same as prior period, unchanged from 0000068505-15-000006:notes:101]

[0000068505-15-000010:notes:105]
On October 27, 2014, the Company completed the sale of its Enterprise business to Zebra Technologies Corporation for $3.45 billion in cash. Certain assets of the Enterprise business were excluded from the transaction and retained by the Company, including the Company’s iDEN business. The historical financial results of the Enterprise business, excluding those assets and liabilities retained in the transaction, are reflected in the Company's condensed consolidated financial statements and footnotes as discontinued operations for all periods presented.

[0000068505-15-000010:notes:106]
The following table displays summarized activity in the Company's condensed consolidated statements of operations for discontinued operations during the three and six months ended July 4, 2015 and June 28, 2014:

[0000068505-15-000010:notes:107]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Net sales | $ | — |  |  | $ | 560 |  |  | $ | — |  |  | $ | 1,133 |  |
| Operating earnings | — |  |  | 55 |  |  | — |  |  | 118 |  |
| Losses on sales of investments and businesses, net | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Investment impairments | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Earnings (loss) before income taxes | (8 | ) |  | 50 |  |  | (28 | ) |  | 112 |  |
| Income tax benefit | — |  |  | (696 | ) |  | (7 | ) |  | (676 | ) |
| Earnings (loss) from discontinued operations, net of tax | $ | (8 | ) |  | $ | 746 |  |  | $ | (21 | ) |  | $ | 788 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-15-000010:notes:108]
[same as prior period, unchanged from 0000068505-15-000006:notes:106]

[0000068505-15-000010:notes:109]
[same as prior period, unchanged from 0000068505-15-000006:notes:107]

[0000068505-15-000010:notes:110]
[same as prior period, unchanged from 0000068505-15-000006:notes:108]

[0000068505-15-000010:notes:111]
[same as prior period, unchanged from 0000068505-15-000006:notes:109]

[0000068505-15-000010:notes:112]
[same as prior period, unchanged from 0000068505-15-000006:notes:110]

[0000068505-15-000010:notes:113]
[same as prior period, unchanged from 0000068505-15-000006:notes:111]

[0000068505-15-000010:notes:114]
The Company had no Level 3 holdings as of July 4, 2015 or December 31, 2014.

[0000068505-15-000010:notes:115]
At July 4, 2015 and December 31, 2014, the Company had $2.2 billion and $3.3 billion, respectively, of investments in money market mutual funds (Level 2) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-15-000010:notes:116]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at July 4, 2015 was $3.4 billion (Level 2).

[0000068505-15-000010:notes:117]
[same as prior period, unchanged from 0000068505-15-000006:notes:115]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-15-000010:notes:118]
[same as prior period, unchanged from 0000068505-15-000006:notes:116]

[0000068505-15-000010:notes:119]
[same as prior period, unchanged from 0000068505-15-000006:notes:117]

[0000068505-15-000010:notes:120]
[same as prior period, unchanged from 0000068505-15-000006:notes:118]

[0000068505-15-000010:notes:121]
|  | July 4, 2015 |  | December 31, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 59 |  |  | $ | 29 |  |  | $ | 37 |  |  | $ | 27 |  |
| Patents | 8 |  |  | 5 |  |  | 8 |  |  | 4 |  |
| Customer-related | 23 |  |  | 9 |  |  | 15 |  |  | 8 |  |
| Other intangibles | 20 |  |  | 15 |  |  | 17 |  |  | 15 |  |
|  | $ | 110 |  |  | $ | 58 |  |  | $ | 77 |  |  | $ | 54 |  |

[0000068505-15-000010:notes:122]
Amortization expense on intangible assets was $3 million for the three months ended July 4, 2015 and $4 million for the six months ended July 4, 2015. Amortization expense on intangible assets was $1 million for the three months ended June 28, 2014 and $2 million for the six months ended June 28, 2014. As of July 4, 2015, annual amortization expense is estimated to be $8 million in 2015, $9 million in 2016 and 2017, $8 million in 2018, $7 million in 2019, and $4 million in 2020.

[0000068505-15-000010:notes:123]
[same as prior period, unchanged from 0000068505-15-000006:notes:121]

[0000068505-15-000010:notes:124]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2015 to July 4, 2015:

[0000068505-15-000010:notes:125]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2015 |  |  |  |  |  |
| Aggregate goodwill | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Goodwill acquired | 7 |  |  | 32 |  |  | 39 |  |
| Purchase accounting adjustments | 1 |  |  | — |  |  | 1 |  |
| Balance as of July 4, 2015 |  |  |  |  |  |
| Aggregate goodwill | $ | 272 |  |  | $ | 151 |  |  | $ | 423 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 272 |  |  | $ | 151 |  |  | $ | 423 |  |

[0000068505-15-000010:notes:126]
Acquisitions

[0000068505-15-000010:notes:127]
On November 18, 2014, the Company completed the acquisition of an equipment provider for a purchase price of $22 million. During the six months ended July 4, 2015, the Company completed the purchase accounting for this acquisition, recognizing $8 million of goodwill and $12 million of identifiable intangible assets. These identifiable intangible assets were classified as completed technology to be amortized over five years.

[0000068505-15-000010:notes:128]
During the quarter ended April 4, 2015 the Company completed the acquisitions of two providers of public safety software-based solutions for an aggregate purchase price of $50 million. During the six months ended July 4, 2015, the Company recognized an additional $32 million of goodwill, $21 million of identifiable intangible assets, and $4 million of acquired liabilities related to these acquisitions. The $21 million of identifiable intangible assets were classified as: (i) $10 million completed technology, (ii) $8 million customer-related, and (iii) $3 million of other intangibles. These intangible assets will be amortized over periods ranging from five to ten years.

[0000068505-15-000010:notes:129]
[same as prior period, unchanged from 0000068505-15-000006:notes:126]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-15-000010:notes:130]
[same as prior period, unchanged from 0000068505-15-000006:notes:127]

[0000068505-15-000010:notes:131]
At the end of each interim reporting period, the Company makes an estimate of its annual effective income tax rate.  Tax items included in the annual effective income tax rate are pro-rated for the full year and tax items discrete to a specific quarter are included in the effective income tax rate for that quarter.  The estimate used in providing for income taxes on a year-to-date basis may change in subsequent interim periods.

[0000068505-15-000010:notes:132]
[same as prior period, unchanged from 0000068505-15-000006:notes:129]

[0000068505-15-000010:notes:133]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Earnings from continuing operations before income taxes | $ | 215 |  |  | $ | 98 |  |  | $ | 343 |  |  | $ | 186 |  |
| Income tax expense | 64 |  |  | 20 |  |  | 104 |  |  | 23 |  |
| Effective tax rate | 30 | % |  | 20 | % |  | 30 | % |  | 12 | % |

[0000068505-15-000010:notes:134]
The Company recorded $64 million of net tax expense in the second quarter of 2015 resulting in an effective tax rate of 30%, compared to $20 million of net tax expense in the second quarter of 2014 resulting in an effective tax rate of 20%. The effective tax rate in the second quarter of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S domestic production tax deduction.

[0000068505-15-000010:notes:135]
The effective tax rate in the second quarter of 2014 was lower than the U.S. statutory tax rate of 35% due to discrete tax benefits, primarily related to return-to-provision adjustments associated with our deferred tax liability for undistributed foreign earnings, the rate differential for foreign affiliates, and the U.S domestic production tax deduction.

[0000068505-15-000010:notes:136]
The Company recorded $104 million of net income tax expense in the first half of 2015 resulting in an effective tax rate of 30%, compared to $23 million of net tax expense resulting in an effective tax rate of 12% in the first half of 2014. The effective tax rate for the first half of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S domestic production tax deduction.

[0000068505-15-000010:notes:137]
The effective tax rate in the first half of 2014 was lower than the U.S. statutory tax rate of 35% due to a tax benefit associated with the net reduction in unrecognized tax benefits for facts that indicated the extent to which certain tax positions were more-likely-than-not of being sustained, discrete tax benefits primarily related to return-to-provision adjustments associated with our deferred tax liability for undistributed foreign earnings, the rate differential for foreign affiliates, and the U.S domestic production tax deduction.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-15-000010:notes:138]
Recent Accounting Pronouncements

[0000068505-15-000010:notes:139]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. This ASU will be effective for the Company beginning January 1, 2018. This ASU allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-15-000010:notes:140]
In April 2015, the FASB issued ASU No. 2015-03, Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, the Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of July 4, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $18 million.

[0000068505-15-000010:notes:141]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 340): Simplifying the Measurement of Inventory. Under this guidance, entities utilizing the FIFO or average cost method should measure inventory at the lower of cost or net realizable value, whereas net realizable value is defined as the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This ASU should be applied prospectively and will be effective for the Company beginning January 1, 2017 with early adoption permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-15-000010:notes:142]
[same as prior period, unchanged from 0000068505-15-000006:notes:137]

[0000068505-15-000010:notes:143]
The condensed consolidated financial statements as of July 4, 2015 and for the three and six months ended July 4, 2015 and June 28, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-15-000010:notes:144]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three and six months ended July 4, 2015 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-15-000010:notes:145]
[same as prior period, unchanged from 0000068505-15-000006:notes:140]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-15-000010:notes:146]
[same as prior period, unchanged from 0000068505-15-000006:notes:141]

[0000068505-15-000010:notes:147]
[same as prior period, unchanged from 0000068505-15-000006:notes:142]

[0000068505-15-000010:notes:148]
[same as prior period, unchanged from 0000068505-15-000006:notes:143]

[0000068505-15-000010:notes:149]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 47 |  |  | 93 |  |  | 19 |  |  | 20 |  |  | 2 |  |  | 3 |  |
| Expected return on plan assets | (52 | ) |  | (98 | ) |  | (31 | ) |  | (23 | ) |  | (3 | ) |  | (2 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 11 |  |  | 21 |  |  | 5 |  |  | 3 |  |  | 2 |  |  | 3 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (1 | ) |  | 2 |  |  | (15 | ) |  | (11 | ) |
| Curtailment gain | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | 6 |  |  | $ | 16 |  |  | $ | (36 | ) |  | $ | 6 |  |  | $ | (13 | ) |  | $ | (6 | ) |

[0000068505-15-000010:notes:150]
During the three months ended July 4, 2015, the Company amended its Non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.  As a result, the Company recorded a curtailment gain of $32 million to Other charges in the Company’s condensed consolidated statements of operations.

[0000068505-15-000010:notes:151]
The Company made no contributions to its U.S. Pension Benefit Plans during the three months ended July 4, 2015 and $40 million of contributions to its U.S. Pension Benefit plans for the three months ended June 28, 2014. During both the three months ended July 4, 2015 and June 28, 2014, contributions of $3 million were made to the Company’s Non U.S. Pension Benefit Plans.

[0000068505-15-000010:notes:152]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 7 |  |  | $ | 7 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 96 |  |  | 185 |  |  | 35 |  |  | 40 |  |  | 4 |  |  | 6 |  |
| Expected return on plan assets | (106 | ) |  | (196 | ) |  | (57 | ) |  | (45 | ) |  | (5 | ) |  | (5 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 23 |  |  | 44 |  |  | 9 |  |  | 6 |  |  | 5 |  |  | 6 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (2 | ) |  | 3 |  |  | (30 | ) |  | (21 | ) |
| Curtailment gain | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | 13 |  |  | $ | 33 |  |  | $ | (40 | ) |  | $ | 11 |  |  | $ | (25 | ) |  | $ | (13 | ) |

[0000068505-15-000010:notes:153]
The Company made no contributions to its U.S. Pension Benefit Plans during the six months ended July 4, 2015 and $66 million of contributions to its U.S. Pension Benefit Plans for the six months ended June 28, 2014. During the six months ended July 4, 2015 and June 28, 2014, contributions of $6 million and $20 million were made to the Company’s Non U.S. Pension Benefit Plans, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-15-000010:notes:154]
[same as prior period, unchanged from 0000068505-15-000006:notes:146]

[0000068505-15-000010:notes:155]
[same as prior period, unchanged from 0000068505-15-000006:notes:147]

[0000068505-15-000010:notes:156]
During the three months ended July 4, 2015, the Company recorded net reorganization of business charges of $16 million including $13 million of charges in Other charges, and $3 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. The $16 million of charges were all related to employee separation costs.

[0000068505-15-000010:notes:157]
During the six months ended July 4, 2015, the Company recorded net reorganization of business charges of $30 million including $26 million of charges in Other charges and $4 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $30 million were charges of $26 million for employee separation costs and $4 million for exit costs.

[0000068505-15-000010:notes:158]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2015 to July 4, 2015, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business:

[0000068505-15-000010:notes:159]
|  | January 1, 2015 |  | AdditionalCharges |  | AmountUsed |  | July 4, 2015 |
| Exit costs | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Employee separation costs | 57 |  |  | 26 |  |  | (40 | ) |  | 43 |  |
|  | $ | 57 |  |  | $ | 30 |  |  | $ | (40 | ) |  | $ | 47 |  |

[0000068505-15-000010:notes:160]
[same as prior period, unchanged from 0000068505-15-000006:notes:151]

[0000068505-15-000010:notes:161]
At January 1, 2015, the Company had no accruals for exit costs. During the six months ended July 4, 2015, there were $4 million of additional charges related to the exit of leased facilities. The remaining accrual of $4 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at July 4, 2015, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-15-000010:notes:162]
[same as prior period, unchanged from 0000068505-15-000006:notes:153]

[0000068505-15-000010:notes:163]
At January 1, 2015, the Company had an accrual of $57 million for employee separation costs. The 2015 additional charges of $26 million represent severance costs for approximately 300 employees. The $40 million used reflects cash payments to severed employees. The remaining accrual of $43 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at July 4, 2015, is expected to be paid, primarily within one year, to approximately 400 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-15-000010:notes:164]
[same as prior period, unchanged from 0000068505-15-000006:notes:155]

[0000068505-15-000010:notes:165]
During the three months ended June 28, 2014, the Company recorded net reorganization of business charges of $28 million, including $25 million of charges in Other charges and $3 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. The $28 million of charges were all related to employee separation costs.

[0000068505-15-000010:notes:166]
During the six months ended June 28, 2014, the Company recorded net reorganization of business charges of $38 million, including $34 million of charges in Other charges and $4 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the aggregate $38 million were charges of $34 million related to employee separation costs and $4 million related to exit costs.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-15-000010:notes:167]
[same as prior period, unchanged from 0000068505-15-000006:notes:157]

[0000068505-15-000010:notes:168]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Products | $ | 867 |  |  | $ | 887 |  |  | $ | 1,626 |  |  | $ | 1,640 |  |
| Services | 501 |  |  | 506 |  |  | 965 |  |  | 982 |  |
|  | $ | 1,368 |  |  | $ | 1,393 |  |  | $ | 2,591 |  |  | $ | 2,622 |  |

[0000068505-15-000010:notes:169]
[same as prior period, unchanged from 0000068505-15-000006:notes:159]

[0000068505-15-000010:notes:170]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Products | $ | 171 |  |  | $ | 95 |  |  | $ | 235 |  |  | $ | 134 |  |
| Services | 83 |  |  | 43 |  |  | 138 |  |  | 111 |  |
| Operating earnings | 254 |  |  | 138 |  |  | 373 |  |  | 245 |  |
| Total other expense | (39 | ) |  | (40 | ) |  | (30 | ) |  | (59 | ) |
| Earnings from continuing operations before income taxes | $ | 215 |  |  | $ | 98 |  |  | $ | 343 |  |  | $ | 186 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-15-000010:notes:171]
[same as prior period, unchanged from 0000068505-15-000006:notes:161]

[0000068505-15-000010:notes:172]
[same as prior period, unchanged from 0000068505-15-000006:notes:162]

[0000068505-15-000010:notes:173]
[same as prior period, unchanged from 0000068505-15-000006:notes:163]

[0000068505-15-000010:notes:174]
[same as prior period, unchanged from 0000068505-15-000006:notes:164]
