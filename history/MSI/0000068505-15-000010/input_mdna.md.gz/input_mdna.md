# MSI MD&A — 0000068505-15-000010


## mdna

[0000068505-15-000010:mdna:1]
[same as prior period, unchanged from 0000068505-15-000006:mdna:1]

[0000068505-15-000010:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and six months ended July 4, 2015 and June 28, 2014, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2014.

[0000068505-15-000010:mdna:3]
[same as prior period, unchanged from 0000068505-15-000006:mdna:3]

[0000068505-15-000010:mdna:4]
[same as prior period, unchanged from 0000068505-15-000006:mdna:4]

[0000068505-15-000010:mdna:5]
[same as prior period, unchanged from 0000068505-15-000006:mdna:5]

[0000068505-15-000010:mdna:6]
[same as prior period, unchanged from 0000068505-15-000006:mdna:6]

[0000068505-15-000010:mdna:7]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the second quarter of 2015, the segment’s net sales were $867 million, representing 63% of our consolidated net sales.

[0000068505-15-000010:mdna:8]
Services: The Services segment provides a full set of service offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Lifecycle Support services, (iii) Managed services, (iv) Smart Public Safety Solutions, and (v) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications.  Lifecycle Support services includes lifecycle planning, software and hardware maintenance, security patches and upgrades, call center support, network monitoring, and repair services.  Managed services includes managing and operating customer systems and devices at defined services levels. Smart Public Safety Solutions includes software and hardware solutions for our customers' "Command & Control" centers providing video monitoring support, data analytics, and content management with the objective of enabling smart policing. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the second quarter of 2015, the segment’s net sales were $501 million, representing 37% of our consolidated net sales.

[0000068505-15-000010:mdna:9]
[same as prior period, unchanged from 0000068505-15-000006:mdna:9]

[0000068505-15-000010:mdna:10]
Impact of Foreign Exchange Rate Fluctuations: Although we are a global corporation and our net sales are impacted by the strengthening of the U.S. dollar in relation to foreign currencies, primarily the Euro, we expect the overall impact of foreign exchange rate fluctuations on our net earnings to be less significant. The impact of foreign exchange rate fluctuations on net earnings is mitigated by the following: (i) the majority of our revenues are derived from contracts within North America denominated in U.S. dollars, (ii) the cost of sales for the delivery of our Services offerings are predominately labor costs incurred within the same geographic region as the associated sale, resulting in minimal impact of foreign exchange rates on gross margin within the Services segment, and (iii) a significant portion of our operating expenses are derived in foreign currencies as a result of our offshore research and development and selling, general, and administrative footprint.

[0000068505-15-000010:mdna:11]
Cost Savings Initiatives: We are committed to employing disciplined financial policies and driving continuous efficiencies and improvements in our cost structure. We expect to reduce selling, general, and administrative and research and development expenses during 2015 by approximately $175 million in comparison to 2014.

[0000068505-15-000010:mdna:12]
[same as prior period, unchanged from 0000068505-15-000006:mdna:12]

[0000068505-15-000010:mdna:13]
iDEN: We have experienced a downward trend in iDEN product and services sales over the last three years due to decreased demand as a result of the dated nature of the technology.  We expect the downward trend to continue as service contracts expire and new technology replaces iDEN equipment in the marketplace.  This trend primarily relates to our Services segment as the majority of iDEN sales are hardware and software maintenance services. The expected decline in iDEN sales will impact both revenues and gross margins within the Services segment as iDEN services’ gross margins are generally higher than the remainder of our services portfolio.

[0000068505-15-000010:mdna:14]
23

[0000068505-15-000010:mdna:15]
Second Quarter Summary

[0000068505-15-000010:mdna:16]
| • | Net sales were $1.4 billion in both the second quarter of 2015 and 2014. Net sales in the second quarter of 2015 included the unfavorable impact of foreign currency fluctuations of $53 million, primarily within EA, AP, and Latin America, partially offset by growth of $42 million in North America. |

[0000068505-15-000010:mdna:17]
| • | We generated operating earnings of $254 million, or 19% of net sales, in the second quarter of 2015, compared to $138 million, or 10% of net sales, in the second quarter of 2014. Profitability improvements were primarily driven by lower operating expenses as a result of: (i) cost savings initiatives, (ii) the favorable impact of foreign exchange rates on operating costs, and (iii) lower pension expense. |

[0000068505-15-000010:mdna:18]
| • | We had earnings from continuing operations attributable to Motorola Solutions, Inc. of $150 million, or $0.72 per diluted common share, in the second quarter of 2015, compared to $78 million, or $0.30 per diluted common share, in the second quarter of 2014. The unfavorable impact of foreign currency fluctuations on net sales was largely offset by foreign exchange rate favorability within Cost of sales and operating expenses reducing the impact on earnings from continuing operations attributable to Motorola Solutions, Inc. |

[0000068505-15-000010:mdna:19]
| • | We generated net cash from operating activities of $291 million during the first half of 2015, compared to $130 million of net cash provided by operating activities in the first half of 2014. Operating cash flows improved primarily as a result of increased earnings, reduced pension contributions, and improved accounts receivable collections. |

[0000068505-15-000010:mdna:20]
| • | We returned $357 million and $1.1 billion in capital to shareholders through dividends and share repurchases during the second quarter of 2015 and first half of 2015, respectively. |

[0000068505-15-000010:mdna:21]
[same as prior period, unchanged from 0000068505-15-000006:mdna:24]

[0000068505-15-000010:mdna:22]
| • | Products: Net sales were $867 million in the second quarter of 2015, a decrease of $20 million, or 2%, compared to net sales of $887 million during the second quarter of 2014. On a geographic basis, net sales increased in North America and ME, decreased in Latin America and EA, and were flat in AP, compared to the year-ago quarter. |

[0000068505-15-000010:mdna:23]
| • | Services: Net sales were $501 million in the second quarter of 2015, a decrease of $5 million, or 1%, compared to net sales of $506 million in the second quarter of 2014. On a geographic basis, net sales declined in EA, Latin America, and AP and increased in ME and North America, compared to the year-ago quarter. |

[0000068505-15-000010:mdna:24]
Recent Developments

[0000068505-15-000010:mdna:25]
Subsequent to the second quarter of 2015, the Board of Directors authorized the following two transactions:

[0000068505-15-000010:mdna:26]
| • | On August 4, 2015, the Board of Directors authorized a modified "Dutch auction" tender offer to repurchase up to $2 billion of our outstanding common stock under the previously existing share repurchase authority. The Company anticipates commencing the tender offer on or about August 7, 2015. The tender offer is expected to close on or about September 4, 2015. |

[0000068505-15-000010:mdna:27]
| • | On August 4, 2015, we entered into an agreement with Silver Lake Partners to issue $1 billion of 2% convertible notes which mature in September 2020. Interest on the notes will be payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.59854 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). Upon conversion, we may elect to settle the amount due in cash, common stock, or a combination of cash and common stock, at our option. We expect to close this transaction on August 25, 2015. |

[0000068505-15-000010:mdna:28]
24

[0000068505-15-000010:mdna:29]
[same as prior period, unchanged from 0000068505-15-000006:mdna:28]

[0000068505-15-000010:mdna:30]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | July 4, 2015 |  | % ofSales** |  | June 28, 2014 |  | % ofSales** |  | July 4, 2015 |  | % ofSales** |  | June 28, 2014 |  | % ofSales** |
| Net sales from products | $ | 867 |  |  |  |  | $ | 887 |  |  |  |  | $ | 1,626 |  |  |  |  | $ | 1,640 |  |  |  |
| Net sales from services | 501 |  |  |  |  | 506 |  |  |  |  | 965 |  |  |  |  | 982 |  |  |  |
| Net sales | 1,368 |  |  |  |  | 1,393 |  |  |  |  | 2,591 |  |  |  |  | 2,622 |  |  |  |
| Costs of product sales | 385 |  |  | 44.4 | % |  | 400 |  |  | 45.1 | % |  | 745 |  |  | 45.8 | % |  | 751 |  |  | 45.8 | % |
| Costs of services sales | 335 |  |  | 66.9 | % |  | 337 |  |  | 66.6 | % |  | 650 |  |  | 67.4 | % |  | 638 |  |  | 65.0 | % |
| Costs of sales | 720 |  |  |  |  | 737 |  |  |  |  | 1,395 |  |  |  |  | 1,389 |  |  |  |
| Gross margin | 648 |  |  | 47.4 | % |  | 656 |  |  | 47.1 | % |  | 1,196 |  |  | 46.2 | % |  | 1,233 |  |  | 47.0 | % |
| Selling, general and administrative expenses | 254 |  |  | 18.6 | % |  | 308 |  |  | 22.1 | % |  | 510 |  |  | 19.7 | % |  | 615 |  |  | 23.5 | % |
| Research and development expenditures | 156 |  |  | 11.4 | % |  | 176 |  |  | 12.6 | % |  | 315 |  |  | 12.2 | % |  | 350 |  |  | 13.3 | % |
| Other charges (income) | (16 | ) |  | (1.2 | )% |  | 34 |  |  | 2.4 | % |  | (2 | ) |  | (0.1 | )% |  | 23 |  |  | 0.9 | % |
| Operating earnings | 254 |  |  | 18.6 | % |  | 138 |  |  | 9.9 | % |  | 373 |  |  | 14.4 | % |  | 245 |  |  | 9.3 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (39 | ) |  | (2.9 | )% |  | (29 | ) |  | (2.1 | )% |  | (79 | ) |  | (3.0 | )% |  | (54 | ) |  | (2.1 | )% |
| Gain (loss) on sales of investments and businesses, net | 4 |  |  | 0.3 | % |  | (4 | ) |  | (0.3 | )% |  | 50 |  |  | 1.9 | % |  | 4 |  |  | 0.2 | % |
| Other | (4 | ) |  | (0.3 | )% |  | (7 | ) |  | (0.5 | )% |  | (1 | ) |  | — | % |  | (9 | ) |  | (0.3 | )% |
| Total other expense | (39 | ) |  | (2.9 | )% |  | (40 | ) |  | (2.9 | )% |  | (30 | ) |  | (1.2 | )% |  | (59 | ) |  | (2.3 | )% |
| Earnings from continuing operations before income taxes | 215 |  |  | 15.7 | % |  | 98 |  |  | 7.0 | % |  | 343 |  |  | 13.2 | % |  | 186 |  |  | 7.1 | % |
| Income tax expense | 64 |  |  | 4.7 | % |  | 20 |  |  | 1.4 | % |  | 104 |  |  | 4.0 | % |  | 23 |  |  | 0.9 | % |
| Earnings from continuing operations | 151 |  |  | 11.0 | % |  | 78 |  |  | 5.6 | % |  | 239 |  |  | 9.2 | % |  | 163 |  |  | 6.2 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | — |  |  | — | % |  | 1 |  |  | — | % |  | — |  |  | — | % |
| Earnings from continuing operations* | 150 |  |  | 11.0 | % |  | 78 |  |  | 5.6 | % |  | 238 |  |  | 9.2 | % |  | 163 |  |  | 6.2 | % |
| Earnings (loss) from discontinued operations, net of tax | (8 | ) |  | (0.6 | )% |  | 746 |  |  | 53.6 | % |  | (21 | ) |  | (0.8 | )% |  | 788 |  |  | 30.1 | % |
| Net earnings* | $ | 142 |  |  | 10.4 | % |  | $ | 824 |  |  | 59.2 | % |  | $ | 217 |  |  | 8.4 | % |  | $ | 951 |  |  | 36.3 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.72 |  |  |  |  | $ | 0.30 |  |  |  |  | $ | 1.11 |  |  |  |  | $ | 0.63 |  |  |  |
| Discontinued operations | (0.04 | ) |  |  |  | 2.92 |  |  |  |  | (0.10 | ) |  |  |  | 3.07 |  |  |  |
| Earnings per diluted common share* | $ | 0.68 |  |  |  |  |  | $ | 3.22 |  |  |  |  |  | $ | 1.01 |  |  |  |  | $ | 3.70 |  |  |  |

[0000068505-15-000010:mdna:31]
[same as prior period, unchanged from 0000068505-15-000006:mdna:30]

[0000068505-15-000010:mdna:32]
[same as prior period, unchanged from 0000068505-15-000006:mdna:31]

[0000068505-15-000010:mdna:33]
Results of Operations—Three months ended July 4, 2015 compared to three months ended June 28, 2014

[0000068505-15-000010:mdna:34]
The results of operations for the second quarter of 2015 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-15-000010:mdna:35]
[same as prior period, unchanged from 0000068505-15-000006:mdna:34]

[0000068505-15-000010:mdna:36]
Net sales were $1.4 billion in the second quarter of 2015, a $25 million, or 2%, decrease compared to the second quarter of 2014. The slight decline in net sales is reflective of decreases in Latin America, EA, and AP, partially offset by growth in North America and ME. The decrease in  EA and AP was primarily the result of foreign exchange rate unfavorability. The decrease in Latin America was primarily the result of foreign exchange rate unfavorability, lower Products sales, and declines in iDen services. North America grew on strong Products sales while ME realized an increase in both Products and Services sales.

[0000068505-15-000010:mdna:37]
[same as prior period, unchanged from 0000068505-15-000006:mdna:37]

[0000068505-15-000010:mdna:38]
Gross margin was $648 million, or 47.4% of net sales, in the second quarter of 2015, compared to $656 million, or 47.1% of net sales, in the second quarter of 2014. The slight increase in gross margin percentage is attributable to the mix of large projects within North America and AP, partially offset by lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-15-000010:mdna:39]
[same as prior period, unchanged from 0000068505-15-000006:mdna:39]

[0000068505-15-000010:mdna:40]
Selling, general and administrative (“SG&A”) expenses decreased 18% to $254 million, or 18.6% of net sales, in the second quarter of 2015, compared to $308 million, or 22.1% of net sales, in the second quarter of 2014. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, (ii) lower pension expenses, and (iii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-15-000010:mdna:41]
Research and Development Expenditures

[0000068505-15-000010:mdna:42]
Research and development (“R&D”) expenditures decreased 11% to $156 million, or 11.4% of net sales, in the second quarter of 2015, from $176 million, or 12.6% of net sales, in the second quarter of 2014. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions and the movement of employees to lower cost work sites, and (ii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-15-000010:mdna:43]
[same as prior period, unchanged from 0000068505-15-000006:mdna:43]

[0000068505-15-000010:mdna:44]
We recorded net income of $16 million in Other charges (income) in the second quarter of 2015, compared to net charges of $34 million in the second quarter of 2014. The net Other income in the second quarter of 2015 included: (i) $32 million non-U.S. pension curtailment gain, partially offset by: (i) $13 million of net reorganization of business charges and (ii) $3 million of charges relating to the amortization of intangibles. The net charges in the second quarter of 2014 of $34 million included: (i) $25 million of net reorganization of business charges, (ii) $8 million of legal settlement charges, and (iii) $1 million of charges relating to the amortization of intangibles. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-15-000010:mdna:45]
[same as prior period, unchanged from 0000068505-15-000006:mdna:45]

[0000068505-15-000010:mdna:46]
Net interest expense was $39 million in the second quarter of 2015, compared to net interest expense of $29 million in the second quarter of 2014. Net interest expense in the second quarter of 2015 included interest expense of $42 million, partially offset by interest income of $3 million. Net interest expense in the second quarter of 2014 included interest expense of $34 million, partially offset by interest income of $5 million. The increase of $8 million in interest expense in the second quarter of 2015 as compared to the second quarter of 2014 was a result of higher outstanding debt balances.

[0000068505-15-000010:mdna:47]
Gains (losses) on Sales of Investments, net

[0000068505-15-000010:mdna:48]
Net Gains on sales of investments and businesses were $4 million in the second quarter of 2015 compared to $4 million of net losses in the second quarter of 2014. The net gains in the second quarter of 2015 and the net losses in the second quarter of 2014 were related to the sales of equity investments.

[0000068505-15-000010:mdna:49]
[same as prior period, unchanged from 0000068505-15-000006:mdna:49]

[0000068505-15-000010:mdna:50]
Net Other expense was $4 million in the second quarter of 2015, compared to $7 million in the second quarter of 2014. The net Other expense in the second quarter of 2015 was comprised of: (i) a $11 million foreign currency loss and (ii) a $3 million investment impairment, partially offset by: (i) a $4 million gain on derivative investments, (ii) a $4 million gain on equity method investments, and (iii) $2 million of other non-operating gains. The net Other expense in the second quarter of 2014 was primarily comprised of $7 million of foreign currency losses.

[0000068505-15-000010:mdna:51]
[same as prior period, unchanged from 0000068505-15-000006:mdna:51]

[0000068505-15-000010:mdna:52]
We recorded $64 million of net tax expense in the second quarter of 2015, resulting in an effective tax rate of 30%, compared to $20 million of net tax expense in the second quarter of 2014, resulting in an effective tax rate of 20%. Our effective tax rate in the second quarter of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S domestic production tax deduction.

[0000068505-15-000010:mdna:53]
26

[0000068505-15-000010:mdna:54]
Our effective tax rate in the second quarter of 2014 was lower than the U.S. statutory tax rate of 35% due to discrete tax benefits, primarily related to return-to-provision adjustments associated with our deferred tax liability for undistributed foreign earnings, the rate differential for foreign affiliates, and the U.S domestic production tax deduction.

[0000068505-15-000010:mdna:55]
[same as prior period, unchanged from 0000068505-15-000006:mdna:54]

[0000068505-15-000010:mdna:56]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $150 million, or $0.72 per diluted share, in the second quarter of 2015, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $78 million, or $0.30 per diluted share, in the second quarter of 2014.

[0000068505-15-000010:mdna:57]
The increase in earnings from continuing operations in the second quarter of 2015, as compared to the second quarter of 2014, was primarily driven by: (i) a $54 million decrease in SG&A spend, (ii) a $50 million decrease in Other charges as a result of a $32 million non-U.S. pension curtailment gain, and (iii) a $20 million decrease in R&D, partially offset by a $44 million increase in income tax expense. Earnings from continuing operations attributable to Motorola Solutions, Inc. was not significantly impacted by the overall strengthening of the U.S. dollar in relation to other currencies in the second quarter of 2015. The unfavorable impact of foreign currency fluctuations on net sales was largely offset by foreign exchange rate favorability within cost of sales and operating expenses. The increase in earnings from continuing operations per diluted share was driven by a reduction in shares outstanding as a result of our share repurchase program and increase in earnings from continuing operations.

[0000068505-15-000010:mdna:58]
[same as prior period, unchanged from 0000068505-15-000006:mdna:57]

[0000068505-15-000010:mdna:59]
After taxes, we had an $8 million, or $0.04 per diluted share, loss from discontinued operations in the second quarter of 2015, compared to earnings from discontinued operations of $746 million, or $2.92 per diluted share, in the second quarter of 2014.

[0000068505-15-000010:mdna:60]
Results of Operations—Six months ended July 4, 2015 compared to six months ended June 28, 2014

[0000068505-15-000010:mdna:61]
Net Sales

[0000068505-15-000010:mdna:62]
Net sales were $2.6 billion in the first half of 2015, a $31 million decrease from the first half of 2014. The slight decline in net sales is reflective of decreases in Latin America, EA, and AP, partially offset by growth in North America and ME. The decrease in  EA and AP was primarily the result of foreign exchange rate unfavorability. The decrease in Latin America was primarily the result of foreign exchange rate unfavorability, lower Products sales, and declines in iDen services. North America grew on strong Products sales while ME realized an increase in both Products and Services sales.

[0000068505-15-000010:mdna:63]
Gross Margin

[0000068505-15-000010:mdna:64]
Gross margin was $1.2 billion, or 46.2% of net sales, in the first half of 2015, compared to $1.2 billion, or 47.0% of net sales, in the first half of 2014. The decrease in gross margin percentage was driven primarily by a decrease in margins within the Services segment while gross margin of the Products segment remained relatively flat. The decrease in gross margin in the Services segment was primarily driven by: (i) a decrease in Integration services margins as a result of the deployment of certain large projects at lower gross margins and (ii) lower net sales in iDEN services which have a higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-15-000010:mdna:65]
Selling, General and Administrative Expenses

[0000068505-15-000010:mdna:66]
SG&A expenses decreased $105 million to $510 million, or 19.7% of net sales, in the first half of 2015, compared to $615 million, or 23.5% of net sales, in the first half of 2014. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, (ii) lower pension expenses, and (iii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-15-000010:mdna:67]
[same as prior period, unchanged from 0000068505-15-000006:mdna:41]

[0000068505-15-000010:mdna:68]
R&D expenditures decreased $35 million to $315 million, or 12.2% of net sales, in the first half of 2015, compared to $350 million, or 13.3% of net sales, in the first half of 2014. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions and the movement of employees to lower cost work sites, and (ii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-15-000010:mdna:69]
Other Charges (income)

[0000068505-15-000010:mdna:70]
We recorded net income of $2 million in Other income in the first half of 2015, compared to net charges of $23 million in the first half of 2014. The net income in the first half of 2015 included a $32 million gain related to the curtailment of a non-U.S. pension plan, partially offset by: (i) $26 million of net reorganization of business charges and (ii) $4 million of charges relating to the amortization of intangibles. The net Other charges in the first half of 2014 of $23 million included: (i) $34 million of net reorganization of business charges, (ii) $8 million of legal settlement charges, and (iii) $2 million of charges relating to the amortization of intangibles, partially offset by a $21 million gain on the sale of a building and land. The net reorganization of business charges are discussed in further detail in the “Reorganization of Business” section.

[0000068505-15-000010:mdna:71]
Net Interest Expense

[0000068505-15-000010:mdna:72]
Net interest expense was $79 million in the first half of 2015 and $54 million in the first half of 2014. Net interest expense in the first half of 2015 includes interest expense of $86 million, partially offset by interest income of $7 million.  Net interest expense in the first half of 2014 includes interest expense of $64 million, partially offset by interest income of $10 million. The increase of $22 million in interest expense in the first half of 2015 as compared to the first half of 2014 was a result of higher outstanding debt balances.

[0000068505-15-000010:mdna:73]
Gains (losses) on Sales of Investments, net

[0000068505-15-000010:mdna:74]
Net gains on sales of investments and businesses were $50 million in the first half of 2015 and $4 million in the first half of 2014. The net gains in the first half of 2015 and 2014 consisted of gains on the sales of equity investments.

[0000068505-15-000010:mdna:75]
Other

[0000068505-15-000010:mdna:76]
Net Other expense was $1 million in the first half of 2015, compared to $9 million in the first half of 2014. The net Other expense in the first half of 2015 was comprised of: (i) $12 million loss on derivative instruments and (ii) a $3 million investment impairment, partially offset by: (i) a $7 million foreign currency gain, (ii) $4 million gain on equity method investments, and (iii) $3 million of other non-operating gains. The net Other expense in the first half of 2014 was primarily comprised of $8 million of foreign currency losses.

[0000068505-15-000010:mdna:77]
Effective Tax Rate

[0000068505-15-000010:mdna:78]
We recorded $104 million of net tax expense in the first half of 2015, resulting in an effective tax rate of 30%, compared to $23 million of net tax expense, resulting in an effective tax rate of 12% in the first half of 2014. Our effective tax rate in 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S domestic production tax deduction.

[0000068505-15-000010:mdna:79]
Our effective tax rate in the first half of 2014 was lower than the U.S. statutory tax rate of 35% due to a tax benefit associated with the net reduction in unrecognized tax benefits for facts that indicated the extent to which certain tax positions were more-likely-than-not of being sustained, discrete tax benefits primarily related to return-to-provision adjustments associated with our deferred tax liability for undistributed foreign earnings, the rate differential for foreign affiliates, and the U.S domestic production tax deduction.

[0000068505-15-000010:mdna:80]
Earnings from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-15-000010:mdna:81]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $238 million, or $1.11 per diluted share, in the first half of 2015, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $163 million, or $0.63 per diluted share, in the first half of 2014.

[0000068505-15-000010:mdna:82]
The increase in earnings from continuing operations in the first half of 2015, as compared to the first half of 2014, was primarily driven by: (i) a $105 million decrease in SG&A spend, (ii) an increase in Gains on sales of investments and businesses of $46 million and (iii) a $35 million decrease in R&D, partially offset by: (i) an $81 million increase in income tax expenses and (ii) a $37 million decrease in gross margin. Earnings from continuing operations attributable to Motorola Solutions, Inc. was not significantly impacted by the overall strengthening of the U.S. dollar in relation to other currencies in the first half of 2015. The unfavorable impact of foreign currency fluctuations on net sales was largely offset by foreign exchange rate favorability within cost of sales and operating expenses. The increase in earnings from continuing operations per diluted share was driven by a reduction in shares outstanding as a result of our share repurchase program and increase in earnings from continuing operations.

[0000068505-15-000010:mdna:83]
Earnings from Discontinued Operations

[0000068505-15-000010:mdna:84]
After taxes, we had a $21 million, or $0.10 per diluted share, loss from discontinued operations in the first half of 2015, compared to earnings from discontinued operations of $788 million, or $3.07 per diluted share, in the first half of 2014.

[0000068505-15-000010:mdna:85]
[same as prior period, unchanged from 0000068505-15-000006:mdna:59]

[0000068505-15-000010:mdna:86]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and six months ended July 4, 2015 and June 28, 2014, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-15-000010:mdna:87]
28

[0000068505-15-000010:mdna:88]
[same as prior period, unchanged from 0000068505-15-000006:mdna:61]

[0000068505-15-000010:mdna:89]
For the second quarter of 2015, the segment’s net sales represented 63% of our consolidated net sales, compared to 64% of our consolidated net sales for the second quarter of 2014. For the first half of 2015 and 2014, the segment’s net sales represented 63% of our consolidated net sales.

[0000068505-15-000010:mdna:90]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 4, 2015 |  | June 28, 2014 |  | % Change |  | July 4, 2015 |  | June 28, 2014 |  | % Change |
| Segment net sales | $ | 867 |  |  | $ | 887 |  |  | (2 | )% |  | $ | 1,626 |  |  | $ | 1,640 |  |  | (1 | )% |
| Operating earnings | 171 |  |  | 95 |  |  | 80 | % |  | 235 |  |  | 134 |  |  | 75 | % |

[0000068505-15-000010:mdna:91]
Three months ended July 4, 2015 compared to three months ended June 28, 2014

[0000068505-15-000010:mdna:92]
The segment’s net sales decreased $20 million, to $867 million in the second quarter of 2015, as compared to $887 million during the second quarter of 2014. The decrease in the segment's net sales was primarily driven by: (i) unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, AP, and Latin America and (ii) a decrease in devices and systems sales in Latin America and EA, partially offset by: (i) an increase in devices and systems sales in North America and (ii) increased devices sales in ME. On a geographic basis, net sales decreased in Latin America and EA, increased in North America and ME, and were flat in AP for the second quarter of 2015, compared to the second quarter of 2014.

[0000068505-15-000010:mdna:93]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 66% of the segment’s net sales in the second quarter of 2015, up from 60% of the segment’s net sales in the second quarter of 2014.

[0000068505-15-000010:mdna:94]
The segment had operating earnings of $171 million in the second quarter of 2015, compared to $95 million in the second quarter of 2014. The increase in operating earnings was primarily driven by: (i) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and reduced pension expenses, (ii) a $22 million non-U.S. pension curtailment gain within Other income, and (iii) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign exchange rates.

[0000068505-15-000010:mdna:95]
Six months ended July 4, 2015 compared to six months ended June 28, 2014

[0000068505-15-000010:mdna:96]
The segment’s net sales decreased $14 million, to $1.6 billion in the first half of 2015, as compared to the first half of 2014. The decrease in the segment's net sales was primarily driven by: (i) unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, AP, and Latin America and (ii) a decrease in devices and systems sales in Latin America and EA, partially offset by: (i) growth in devices and systems in North America and (ii) increased devices sales in ME. On a geographic basis, net sales decreased in Latin America, EA, and AP and increased in North America and ME for the first half of 2015, compared to the first half of 2014.

[0000068505-15-000010:mdna:97]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 63% of the segment’s net sales in the first half of 2015 and 2014.

[0000068505-15-000010:mdna:98]
The segment had operating earnings of $235 million in the first half of 2015, compared to $134 million in the first half of 2014. The increase in operating earnings in the first half of 2015 compared to the first half of 2014, was primarily driven by: (i) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and reduced pension expenses, (ii) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign exchange rates, and (iii) a $22 million non-U.S. pension curtailment gain within Other income.

[0000068505-15-000010:mdna:99]
[same as prior period, unchanged from 0000068505-15-000006:mdna:68]

[0000068505-15-000010:mdna:100]
For the second quarter of 2015, the segment’s net sales represented 37% of our consolidated net sales, compared to 36% of our consolidated net sales for the second quarter of 2014. For the first half of 2015 and 2014, the segment’s net sales represented 37% of our consolidated net sales.

[0000068505-15-000010:mdna:101]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 4, 2015 |  | June 28, 2014 |  | % Change |  | July 4, 2015 |  | June 28, 2014 |  | % Change |
| Segment net sales | $ | 501 |  |  | $ | 506 |  |  | (1 | )% |  | $ | 965 |  |  | $ | 982 |  |  | (2 | )% |
| Operating earnings | 83 |  |  | 43 |  |  | 93 | % |  | 138 |  |  | 111 |  |  | 24 | % |

[0000068505-15-000010:mdna:102]
Three months ended July 4, 2015 compared to three months ended June 28, 2014

[0000068505-15-000010:mdna:103]
The segment’s net sales decreased $5 million, or 1%, to $501 million in the second quarter of 2015, as compared to $506 million in the second quarter of 2014. The decrease in the segment's net sales was driven by: (i) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, AP, and Latin America, (ii) decreased Integration services sales in North America as a result of the timing of delivery on larger projects, and (iii) declining iDEN services sales in Latin America, partially offset by an increase in: (i) Lifecycle Support services in North America and (ii) Integration services in ME. On a geographic basis, net sales for the second quarter of 2015 decreased in Latin America, AP, and EA, partially offset by growth in ME and North America, compared to the second quarter of 2014.

[0000068505-15-000010:mdna:104]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 62% of the segment’s net sales in the second quarter of 2015, compared to 61% of the segment’s net sales in the second quarter of 2014.

[0000068505-15-000010:mdna:105]
The segment had operating earnings of $83 million in the second quarter of 2015, compared to $43 million in the second quarter of 2014. The increase in operating earnings in the second quarter of 2015 compared to the second quarter of 2014 was driven by: (i) a reduction in SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and lower pension expenses and (ii) a $10 million non-U.S. pension curtailment gain within Other income.

[0000068505-15-000010:mdna:106]
Six months ended July 4, 2015 compared to six months ended June 28, 2014

[0000068505-15-000010:mdna:107]
The segment’s net sales decreased $17 million, or 2%, to $965 million in the first half of 2015, as compared to net sales of $982 million in the first half of 2014. The decrease in the segment's net sales was driven by: (i) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, AP, and Latin America, (ii) declining iDEN services sales in Latin America, and (iii) lower Integration services sales in North America as a result of the timing of delivery on larger projects. On a geographic basis, net sales declined in EA, Latin America, and AP and increased in ME, while remaining flat in North America for the first half of 2015, compared to the first half of 2014.

[0000068505-15-000010:mdna:108]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 61% of the segment’s net sales in the first half of 2015, compared to 60% of the segment’s net sales in the first half of 2014.

[0000068505-15-000010:mdna:109]
The segment had operating earnings of $138 million in the first half of 2015, compared to operating earnings of $111 million in the first half of 2014. The increase in operating earnings in the first half of 2015 as compared to the first half of 2014 was driven by: (i) a reduction in SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and lower pension expenses and (ii) a $10 million non-U.S. pension curtailment gain within Other income, partially offset by a decrease in gross margin driven by Integration services on large system deployments and iDEN services.

[0000068505-15-000010:mdna:110]
[same as prior period, unchanged from 0000068505-15-000006:mdna:75]

[0000068505-15-000010:mdna:111]
During the second quarter of 2015, we recorded net reorganization of business charges of $16 million including $13 million of charges recorded within Other charges and $3 million in Cost of sales in our condensed consolidated statements of operations. The aggregate $16 million of charges represent employee separation costs.

[0000068505-15-000010:mdna:112]
During the first half of 2015, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first half of 2015, we recorded net reorganization of business charges of $30 million including charges of $26 million recorded in Other charges and $4 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $30 million are charges of $26 million for employee separation costs and $4 million for exit costs.

[0000068505-15-000010:mdna:113]
During the second quarter of 2014, we recorded net reorganization of business charges of $28 million including charges of $25 million recorded in Other charges and $3 million in Cost of sales in our condensed consolidated statements of operations. The $28 million of charges was all related to employee separation costs.

[0000068505-15-000010:mdna:114]
During the first half of 2014, we recorded net reorganization of business charges of $38 million including charges of $34 million recorded in Other charges and $4 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $38 million are charges of $34 million for employee separation costs and $4 million of exit costs.

[0000068505-15-000010:mdna:115]
We expect to realize cost-saving benefits of approximately $16 million during the remaining six months of 2015 from the plans that were initiated during the second quarter of 2015. Beyond 2015, we expect the reorganization plans initiated during the first six months of 2015 to provide annualized cost savings of approximately $32 million, consisting of: (i) $27 million of savings in operating expenses and (ii) $5 million of savings in Cost of Sales.

[0000068505-15-000010:mdna:116]
30

[0000068505-15-000010:mdna:117]
[same as prior period, unchanged from 0000068505-15-000006:mdna:79]

[0000068505-15-000010:mdna:118]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Products | $ | 12 |  |  | $ | 18 |  |  | $ | 22 |  |  | $ | 24 |  |
| Services | 4 |  |  | 10 |  |  | 8 |  |  | 14 |  |
|  | $ | 16 |  |  | $ | 28 |  |  | $ | 30 |  |  | $ | 38 |  |

[0000068505-15-000010:mdna:119]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $40 million in the first half of 2015 and $75 million in the first half of 2014. The cash payments related to discontinued operations included in the first half of 2014 were $25 million. The reorganization of business accruals at July 4, 2015 were $47 million, of which $43 million relate to employee separation costs that are expected to be paid within one year and $4 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-15-000010:mdna:120]
[same as prior period, unchanged from 0000068505-15-000006:mdna:82]

[0000068505-15-000010:mdna:121]
We continue to manage our capital structure focused on maintaining a robust liquidity position and managing to an investment grade credit rating. We decreased the aggregate of our cash and cash equivalent balances by $842 million from $4.0 billion as of December 31, 2014 to $3.1 billion as of July 4, 2015.  The decrease is primarily due to $1.1 billion of capital returned to shareholders through share repurchases and dividends paid, partially offset by $291 million of cash provided by operating activities.

[0000068505-15-000010:mdna:122]
[same as prior period, unchanged from 0000068505-15-000006:mdna:84]

[0000068505-15-000010:mdna:123]
[same as prior period, unchanged from 0000068505-15-000006:mdna:85]

[0000068505-15-000010:mdna:124]
Our cash and cash equivalents were $3.1 billion at July 4, 2015 and $4.0 billion at December 31, 2014. At July 4, 2015, $2.2 billion of this amount was held in the U.S. and approximately $896 million was held by the Company or its subsidiaries in other countries. At both July 4, 2015 and December 31, 2014, restricted cash was $63 million.

[0000068505-15-000010:mdna:125]
Undistributed earnings that we intend to reinvest indefinitely, and for which no income taxes have been provided, aggregate to $1.5 billion at July 4, 2015. We currently have no plans to repatriate these permanently reinvested foreign earnings.  If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-15-000010:mdna:126]
[same as prior period, unchanged from 0000068505-15-000006:mdna:88]

[0000068505-15-000010:mdna:127]
Net cash provided by operating activities in the first half of 2015 was $291 million, as compared to $130 million in the first half of 2014. Operating cash flows in the first half of 2015, as compared to the first half of 2014, were positively impacted by: (i) an increase in earnings from continuing operations, (ii) reduced pension contributions, (iii) improved accounts receivable collections, (iv) proceeds from the sale of long-term receivables, and (v) decreased cash payments for accounts payable and accrued liabilities.

[0000068505-15-000010:mdna:128]
We made no contributions to our U.S. pension plans during the first half of 2015, compared to $66 million contributed in the first half of 2014. We contributed $6 million to our non-U.S. pension plans during the first half of 2015, compared to $20 million contributed in the first half of 2014.

[0000068505-15-000010:mdna:129]
[same as prior period, unchanged from 0000068505-15-000006:mdna:91]

[0000068505-15-000010:mdna:130]
Net cash used by investing activities was $62 million in the first half of 2015, compared to $48 million in the first half of 2014. The $62 million cash used in the first half of 2015 included $93 million cash used for acquisitions and investments and $81 million in capital expenditures, partially offset by $111 million of proceeds from sales of investments and businesses. The cash usage in the first half of 2014 consisted primarily of $82 million in capital expenditures and $11 million cash used for acquisitions and investments, partially offset by $24 million of proceeds from the sale of property, plant and equipment and $21 million of proceeds from the sale of investments and businesses.

[0000068505-15-000010:mdna:131]
Acquisition and Investments: We used net cash for acquisitions and investments of $93 million during the first half of 2015 compared to $11 million in the first half of 2014. The cash used during the first half of 2015 consisted of $49 million related to the acquisition of two public safety software solution providers and several debt and equity investments. The cash used during the first half of 2014 related to a number of small equity investments.

[0000068505-15-000010:mdna:132]
Sales of Investments and Businesses: We had $111 million of proceeds related to the sales of investments and businesses in the first half of 2015 compared to $21 million in the first half of 2014. The proceeds in the first half of 2015 primarily consists of: (i) $49 million reimbursement from Zebra Technologies for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale; (ii) $47 million from the sale of an equity investment, (iii) $21

[0000068505-15-000010:mdna:133]
million net cash received from Zebra Technologies for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, and (iv) proceeds from the sale of various debt and equity securities, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest. The proceeds in the first half of 2014 were comprised of sales of equity investments.

[0000068505-15-000010:mdna:134]
Capital Expenditures: Capital expenditures were relatively flat in the first half of 2015 as compared to the first half of 2014.  Capital expenditures in both periods were primarily related to information technology-related spend and revenue-generating network expenditures.

[0000068505-15-000010:mdna:135]
Sales of Property, Plant, and Equipment:  We had $1 million of proceeds related to the sale of property, plant, and equipment in the first half of 2015 compared to $24 million in the first half of 2014. The proceeds in the first half of 2014 were comprised of proceeds from the sale of buildings and land.

[0000068505-15-000010:mdna:136]
[same as prior period, unchanged from 0000068505-15-000006:mdna:97]

[0000068505-15-000010:mdna:137]
Net cash used for financing activities was $1.0 billion in the first half of 2015, compared to $438 million in the first half of 2014. Cash used for financing activities in the first half of 2015 was primarily comprised of: (i) $938 million used for purchases of our common stock under our share repurchase program and (ii) $148 million of cash used for the payment of dividends, partially offset by $51 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan. Net cash used for financing activities in the first half of 2014 was primarily comprised of: (i) $473 million used for purchases of our common stock under our share repurchase program and (ii) $158 million of cash used for the payment of dividends, partially offset by: (i) $100 million of distributions from discontinued operations and (ii) $85 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-15-000010:mdna:138]
Long-Term Debt: We had outstanding long-term debt of $3.4 billion, including the current portions of $4 million, at both July 4, 2015 and December 31, 2014.

[0000068505-15-000010:mdna:139]
On August 4, 2015, we entered into an agreement with Silver Lake Partners to issue $1 billion of 2% convertible notes which mature in September 2020. Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.59854 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). We may, at our option, elect to settle the amount due upon conversion in cash, common stock, or a combination of cash and common stock. We expect to close this transaction on August 25, 2015.

[0000068505-15-000010:mdna:140]
[same as prior period, unchanged from 0000068505-15-000006:mdna:100]

[0000068505-15-000010:mdna:141]
Share Repurchase Program: We paid an aggregate of $285 million during the second quarter of 2015, including transaction costs, to repurchase 4.6 million shares at an average price of $61.63 per share. We paid an aggregate of $938 million during the first half of 2015, including transaction costs, to repurchase approximately 14.5 million shares at an average price of $64.69 per share.  All repurchased shares have been retired.

[0000068505-15-000010:mdna:142]
The Board of Directors has authorized a share repurchase program for an aggregate amount of $12.0 billion of outstanding shares of common stock. As of July 4, 2015, we have used approximately $8.7 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $3.3 billion of authority available for future repurchases.

[0000068505-15-000010:mdna:143]
In addition to our ongoing share repurchase program, on August 4, 2015, the Board of Directors authorized a modified "Dutch auction" tender offer to repurchase $2 billion of our outstanding shares of common stock. This repurchase will be funded from a combination of cash on hand and a portion of the proceeds from the issuance of new convertible notes as discussed above. We anticipate commencing the tender offer on or about August 7, 2015. The tender offer is expected to close on or about September 4, 2015.

[0000068505-15-000010:mdna:144]
Payment of Dividends: During the second quarter of 2015, we paid $72 million in cash dividends to holders of our common stock. During the first half of 2015, we paid $148 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $70 million in cash dividends to holders of our common stock.

[0000068505-15-000010:mdna:145]
[same as prior period, unchanged from 0000068505-15-000006:mdna:104]

[0000068505-15-000010:mdna:146]
As of July 4, 2015, we had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of July 4, 2015. We did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the first half of 2015.

[0000068505-15-000010:mdna:147]
[same as prior period, unchanged from 0000068505-15-000006:mdna:106]

[0000068505-15-000010:mdna:148]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $107 million at July 4, 2015, compared to $293 million at December 31, 2014.  Outstanding commitments decreased during the first half of 2015 primarily as a result of two large customer contracts, one of which was converted to an order without long-term financing and the other where the financing commitment was funded and sold.

[0000068505-15-000010:mdna:149]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $18 million at July 4, 2015, compared to $31 million at December 31, 2014.

[0000068505-15-000010:mdna:150]
[same as prior period, unchanged from 0000068505-15-000006:mdna:109]

[0000068505-15-000010:mdna:151]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended July 4, 2015 and June 28, 2014:

[0000068505-15-000010:mdna:152]
|  | Three Months Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Accounts receivable sales proceeds | $ | 5 |  |  | $ | 26 |  |  | $ | 11 |  |  | $ | 33 |  |
| Long-term receivables sales proceeds | 43 |  |  | 52 |  |  | 108 |  |  | 52 |  |
| Total proceeds from sales of accounts receivable | $ | 48 |  |  | $ | 78 |  |  | $ | 119 |  |  | $ | 85 |  |

[0000068505-15-000010:mdna:153]
As of July 4, 2015, we had retained servicing obligations for $627 million of sold long-term receivables, compared to $496 million of sold long-term receivables at December 31, 2014. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-15-000010:mdna:154]
Other Contingencies

[0000068505-15-000010:mdna:155]
[same as prior period, unchanged from 0000068505-15-000006:mdna:114]

[0000068505-15-000010:mdna:156]
[same as prior period, unchanged from 0000068505-15-000006:mdna:115]

[0000068505-15-000010:mdna:157]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value.  We had no accruals for any such obligations at July 4, 2015.

[0000068505-15-000010:mdna:158]
[same as prior period, unchanged from 0000068505-15-000006:mdna:117]

[0000068505-15-000010:mdna:159]
[same as prior period, unchanged from 0000068505-15-000006:mdna:118]

[0000068505-15-000010:mdna:160]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of this ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. This ASU will be effective for us beginning January 1, 2018. This ASU allows for both retrospective and modified-retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-15-000010:mdna:161]
In April 2015, the FASB issued ASU No. 2015-03, Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, we will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of July 4, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $18 million.

[0000068505-15-000010:mdna:162]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 340): Simplifying the Measurement of Inventory. Under this guidance, entities utilizing the FIFO or average cost method should measure inventory at the lower of cost or net realizable

[0000068505-15-000010:mdna:163]
33

[0000068505-15-000010:mdna:164]
value, whereas net realizable value is defined as the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This ASU should be applied prospectively and will be effective for us beginning January 1, 2017 with early adoption permitted. We are in the process of assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-15-000010:mdna:165]
34
