# MSI note change history — 0000068505-15-000006 → 0000068505-15-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-08-05):
[0000068505-15-000010:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at July 4, 2015.
  (was, 2015-05-06, similarity 0.9925):
[0000068505-15-000006:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at April 4, 2015.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-08-05):
[0000068505-15-000010:note_history:2]
The condensed consolidated financial statements as of July 4, 2015 and for the three and six months ended July 4, 2015 and June 28, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2015-05-06, similarity 0.9429):
[0000068505-15-000006:note_history:2]
The condensed consolidated financial statements as of April 4, 2015 and for the three months ended April 4, 2015 and March 29, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2015-08-05):
[0000068505-15-000010:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three and six months ended July 4, 2015 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2015-05-06, similarity 0.8081):
[0000068505-15-000006:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three months ended April 4, 2015 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2015-08-05):
[0000068505-15-000010:note_history:4]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. This ASU will be effective for the Company beginning January 1, 2018. This ASU allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.
  (was, 2015-05-06, similarity 0.9354):
[0000068505-15-000006:note_history:4]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. This ASU will be effective for the Company beginning January 1, 2017; however, in April 2015, the FASB proposed a one year delay in the effective date of the standard. This ASU allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

- changed (2015-08-05):
[0000068505-15-000010:note_history:5]
In April 2015, the FASB issued ASU No. 2015-03, Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, the Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of July 4, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $18 million.
  (was, 2015-05-06, similarity 0.9732):
[0000068505-15-000006:note_history:5]
In April 2015, the FASB issued ASU No. 2015-03, "Interest—Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.” Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. The Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of April 4, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $19 million.

- added (2015-08-05):
[0000068505-15-000010:note_history:6]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 340): Simplifying the Measurement of Inventory. Under this guidance, entities utilizing the FIFO or average cost method should measure inventory at the lower of cost or net realizable value, whereas net realizable value is defined as the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This ASU should be applied prospectively and will be effective for the Company beginning January 1, 2017 with early adoption permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

- removed (2015-08-05):
[0000068505-15-000006:note_history:7]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU 2015-02 changes the consolidation analysis required for limited partnerships and other variable interest entities. This ASU will be effective for the Company beginning January 1, 2016, with early adoption permitted. This ASU allows for either retrospective or modified retrospective application.  The Company does not expect this ASU will have a material impact on its consolidated financial statements.

- removed (2015-08-05):
[0000068505-15-000006:note_history:8]
In April 2015, the FASB issued ASU No. 2015-05, "Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer's Accounting for Fees Paid in a Cloud Computing Arrangement." Under this guidance, if it is determined that a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses; however, if it is determined that a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. This ASU allows for the option of applying either a full retrospective approach to all periods presented or a prospective approach to all arrangements entered into or materially modified after the effective date of January 1, 2016. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-05):
[0000068505-15-000010:note_history:9]
As of July 4, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 4, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the six months ended July 4, 2015.
  (was, 2015-05-06, similarity 0.94):
[0000068505-15-000006:note_history:9]
As of April 4, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 4, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the three months ended April 4, 2015.

- added (2015-08-05):
[0000068505-15-000010:note_history:10]
On August 4, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1 billion of 2% convertible notes which mature in September 2020. Interest on the notes will be payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.59854 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). The Company may, at its option, elect to settle the amount due upon conversion in cash, common stock, or a combination of cash and common stock. The Company expects to close this transaction on August 25, 2015.
