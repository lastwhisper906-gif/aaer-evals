# MSI 10-Q controls and the auditor's report


## item_4_controls

[0000068505-15-000010:item_4_controls:1]
Item 4. Controls and Procedures

[0000068505-15-000010:item_4_controls:2]
(a) Evaluation of disclosure controls and procedures. Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of the end of the period covered by this quarterly report (the “Evaluation Date”). Based on this evaluation, our chief executive officer and chief financial officer concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information relating to Motorola Solutions, including our consolidated subsidiaries, required to be disclosed in our Securities and Exchange Commission (“SEC”) reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and (ii) is accumulated and communicated to Motorola Solutions’ management, including our chief executive officer and chief financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000068505-15-000010:item_4_controls:3]
(b) Changes in internal control over financial reporting. There have been no changes in our internal control over financial reporting that occurred during the quarter ended July 4, 2015, that have materially affected or are reasonably likely to materially affect our internal control over financial reporting.

[0000068505-15-000010:item_4_controls:4]
The sale of the Enterprise business included the transfer of our existing Enterprise Resource Planning ("ERP") system to Zebra. We have entered into transition service agreements which require us to operate in a shared information technology environment with Zebra for a period of two years from the transaction closing date with the option to extend up to an additional twelve months. We are currently in the planning phases of determining our future ERP needs, which may include the redesign of current processes and controls.

[0000068505-15-000010:item_4_controls:5]
36
