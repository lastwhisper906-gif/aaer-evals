# MSI 8-K — 0001193125-15-277673 filed 2015-08-05

## item codes, every 8-K on or before 2015-08-05

- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2015-08-05

- none on or before 2015-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-277673:8k_2_02:1]
EX-99.1
4
d60966dex991.htm
EX-99.1

[0001193125-15-277673:8k_2_02:2]
EX-99.1

[0001193125-15-277673:8k_2_02:3]
Exhibit 99.1

[0001193125-15-277673:8k_2_02:4]
Motorola Solutions Announces Strategic Partnership

[0001193125-15-277673:8k_2_02:5]
and $1 Billion Investment by Silver Lake

[0001193125-15-277673:8k_2_02:6]
Partnership Expected to Drive Growth of Global Market Leader

[0001193125-15-277673:8k_2_02:7]
in Public Safety Communications Technology

[0001193125-15-277673:8k_2_02:8]
SCHAUMBURG, Ill. – Aug. 5, 2015 – Motorola Solutions (NYSE: MSI), the leading global provider of innovative mission-critical communications
solutions for public safety and commercial customers, today announced that Silver Lake, the global leader in technology investing, will make a $1 billion investment in Motorola Solutions. The company expects to use the Silver Lake investment to
accelerate growth in its smart public safety solutions and services businesses through new partnerships, investments and acquisitions.

[0001193125-15-277673:8k_2_02:9]
“Silver Lake
has a proven track record of creating value by partnering with leading technology companies around the world,” said Greg Brown, chairman and CEO of Motorola Solutions. “This strategic partnership and investment combine Silver Lake’s
expertise in technology products, services and information solutions with our vision to create safer communities and more successful businesses. It represents a strong vote of confidence in our company’s strategy and future growth
opportunities.”

[0001193125-15-277673:8k_2_02:10]
Motorola Solutions serves more than 100,000 customers in 100 countries, including local, state and national public safety agencies
as well as businesses in industries such as utilities, mining and transportation. The company’s communications technology portfolio includes devices used by professionals in the field, problem-solving software that drives effectiveness,
mission-critical systems for command centers, network infrastructure and a range of services.

[0001193125-15-277673:8k_2_02:11]
In connection with Silver Lake’s investment, Egon
Durban and Greg Mondre, managing partners of Silver Lake, will be appointed to Motorola Solutions’ board of directors when the transaction closes, which is expected to occur in the third quarter of 2015.

[0001193125-15-277673:8k_2_02:12]
“Motorola Solutions is an iconic company and the global market leader in public safety technology,” said Durban and Mondre. “We believe it is
creating a new era in data-rich public safety communications and has significant potential for growth. Its core business is unrivaled in the United States and around the world with a broad and loyal customer base, an outstanding record of
reliability, and growing reach and scale driven by technology innovation. Greg Brown and his talented management team have a strong record of performance and corporate transformation that has created exciting new opportunities to innovate and expand
the company’s next-generation software, smart public safety and service offerings.”

[0001193125-15-277673:8k_2_02:13]
Brown added, “The addition of Egon and Greg will
provide our board with valuable insight and expertise as we grow through new partnerships, investments and acquisitions. Both have a history of working closely with management teams to create value by identifying and delivering unique business
opportunities in the technology industry.”

[0001193125-15-277673:8k_2_02:14]
Durban is a managing partner and managing director of Silver Lake, which he joined in 1999 as a founding
principal. He is based in the firm’s Menlo Park, Calif., office and has previously worked in the New York office as well as the London office, which he launched and managed from 2005 to 2010. Durban serves on the board of directors of Dell and
Intelsat S.A., and is chairman of the board of directors of WME Entertainment. Durban graduated from Georgetown University with a bachelor’s degree in finance.

[0001193125-15-277673:8k_2_02:15]
Mondre joined Silver Lake in 1999 and is a managing partner and managing director based in New York. He currently serves as a director of Avaya, Inc., Go
Daddy, Inc., Red Ventures, Sabre Holdings and Vantage Data Centers, and is on the operating committee of SunGard Capital Corp. Mondre graduated from The Wharton School of the University of Pennsylvania with a bachelor’s degree in economics.

[0001193125-15-277673:8k_2_02:16]
Motorola Solutions also today announced its intent to repurchase up to $2 billion of stock through a tender offer, reflecting confidence in the future
value of the business while maintaining considerable financial flexibility to pursue further growth. The company will fund the tender offer with a combination of existing cash on the company’s balance sheet and a portion of the proceeds from
the $1 billion strategic investment by Silver Lake.

[0001193125-15-277673:8k_2_02:17]
Under the terms of the agreement, Silver Lake is purchasing $1 billion aggregate principal amount of
2.0 percent convertible senior notes due 2020 with an initial conversion price of $68.50 per share. The initial conversion price represents a conversion premium of 17.0 percent over the volume-weighted average price of the company’s common
stock sale price of $58.55 per share on the New York Stock Exchange during the 30 trading days ended Aug. 4, 2015. Additional information may be found in the Form 8-K that will be filed today with the U.S. Securities and Exchange Commission.

[0001193125-15-277673:8k_2_02:18]
Goldman, Sachs & Co and J.P. Morgan acted as financial advisors to Motorola Solutions, and Wachtell, Lipton, Rosen & Katz served as Motorola
Solutions’ legal advisor in the transaction.

[0001193125-15-277673:8k_2_02:19]
DBO Partners served as financial advisors to Silver Lake, and Simpson Thacher & Bartlett acted
as Silver Lake’s legal advisor.

[0001193125-15-277673:8k_2_02:20]
About Motorola Solutions

[0001193125-15-277673:8k_2_02:21]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build
safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0001193125-15-277673:8k_2_02:22]
About
Silver Lake

[0001193125-15-277673:8k_2_02:23]
Silver Lake is the global leader in technology investing, with over $26 billion in combined assets under management and committed capital.
The firm’s portfolio of investments collectively generates more than $85 billion of revenue annually and

[0001193125-15-277673:8k_2_02:24]
employs more than 170,000 people globally. Silver Lake has a team of approximately 100 investment and value creation professionals located in New York, Menlo Park, San Mateo, London, Hong Kong
and Tokyo. The firm’s current portfolio includes leading technology and technology-enabled businesses such as Alibaba Group, Avago, Avaya, Dell, Global Blue, Go Daddy, Hillstone Networks, Intelsat, Interactive Data Corporation, Qunar, Quorum
Business Solutions, Red Ventures, Sabre, SMART Modular, SunGard, Vantage Data Centers, Virtu Financial and WME/IMG. For more information about Silver Lake and its entire portfolio, please visit www.silverlake.com.

[0001193125-15-277673:8k_2_02:25]
Forward-Looking Statements

[0001193125-15-277673:8k_2_02:26]
light of global economic conditions and reductions in the company’s purchasing power; (9) risks related to dependence on certain key suppliers, subcontractors, third-party distributors
and other representatives; (10) the impact on the company’s performance and financial results from strategic acquisitions or divestitures; (11) risks related to the company’s manufacturing and business operations in foreign
countries; (12) the creditworthiness of the company’s customers and distributors, particularly purchasers of large infrastructure systems; (13) exposure under large systems and managed services contracts, including risks related to
the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by
Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company’s intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others;
(16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United
States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to repurchase shares under its repurchase program
due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company’s outsourcing of
various activities, including certain business operations, information technology and administrative functions; (22) the impact of the sale of the company’s enterprise legacy information systems, including components of the enterprise
resource planning (ERP) system and the implementation of a new ERP system; (23) the satisfaction of the conditions to closing the investment by Silver Lake; and (24) the ability of Motorola Solutions to commence and complete the intended
tender offer for its shares, including the amount of such tender offer. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0001193125-15-277673:8k_2_02:27]
Additional Information for Investors

[0001193125-15-277673:8k_2_02:28]
This
communication is for informational purposes only, is not a recommendation to buy or sell Motorola Solutions common stock, and does not constitute an offer to buy or the solicitation to sell shares of Motorola Solutions common stock. The tender offer
described in this communication has not yet commenced, and there can be no assurances that Motorola Solutions will commence the tender offer on the terms described in this communication or at all. The tender offer will be made only pursuant to the
Offer to Purchase, Letter of Transmittal and related materials that Motorola Solutions expects to file with the Securities and Exchange Commission upon commencement of the tender offer. STOCKHOLDERS ARE URGED TO CAREFULLY READ THE OFFER TO PURCHASE,
LETTER OF TRANSMITTAL AND RELATED MATERIALS WHEN THEY BECOME AVAILABLE BECAUSE THEY CONTAIN IMPORTANT INFORMATION, INCLUDING THE VARIOUS TERMS OF, AND CONDITIONS TO, THE TENDER OFFER, THAT STOCKHOLDERS SHOULD CONSIDER BEFORE MAKING ANY DECISION
REGARDING TENDERING THEIR SHARES. Once the tender offer is commenced, stockholders will be able to obtain a

[0001193125-15-277673:8k_2_02:29]
free copy of the tender offer statement on Schedule TO, the Offer to Purchase, Letter of Transmittal and other documents that Motorola Solutions will be filing with the Securities and Exchange
Commission at the Commission’s website at www.sec.gov. Additional copies of these materials may be obtained for free by contacting Motorola Solutions at 1303 E. Algonquin Road, Schaumburg, Illinois, 60196, Attn: Investor Relations, or Alliance
Advisors, LLC, the information agent for the tender offer, at (855) 737-3180.

[0001193125-15-277673:8k_2_02:30]
Media Contacts

[0001193125-15-277673:8k_2_02:31]
MOTOROLA SOLUTIONS

[0001193125-15-277673:8k_2_02:32]
Tama McWhinney

[0001193125-15-277673:8k_2_02:33]
+1 847-538-1865

[0001193125-15-277673:8k_2_02:34]
tama.mcwhinney@motorolasolutions.com

[0001193125-15-277673:8k_2_02:35]
SILVER LAKE

[0001193125-15-277673:8k_2_02:36]
Patricia Graue

[0001193125-15-277673:8k_2_02:37]
+1 212-333-3018

[0001193125-15-277673:8k_2_02:38]
silverlake@brunswickgroup.com

[0001193125-15-277673:8k_2_02:39]
Investor Contacts

[0001193125-15-277673:8k_2_02:40]
MOTOROLA SOLUTIONS

[0001193125-15-277673:8k_2_02:41]
Shep Dunlap

[0001193125-15-277673:8k_2_02:42]
+1 847-538-7367

[0001193125-15-277673:8k_2_02:43]
shep.dunlap@motorolasolutions.com

[0001193125-15-277673:8k_2_02:44]
Chris Kutsor

[0001193125-15-277673:8k_2_02:45]
+1 847-538-7367

[0001193125-15-277673:8k_2_02:46]
chris.kutsor@motorolasolutions.com

## item 1.01 — body, verbatim

[0001193125-15-277673:8k_body:1]
Item 1.01

[0001193125-15-277673:8k_body:2]
Entry into a Material Definitive Agreement.

[0001193125-15-277673:8k_body:3]
On August 4, 2015, Motorola Solutions, Inc. (the
“Company” or “Motorola Solutions”) entered into an investment agreement (the “Investment Agreement”) with Silver Lake Partners IV, L.P. and Silver Lake Partners IV Cayman (AIV II), L.P. (collectively, “Silver
Lake”), relating to the issuance to one of the Silver Lake entities of $1 billion principal amount of convertible 2.0% unsecured notes, due 2020 (the “Notes”). The transactions contemplated by the Investment Agreement (the
“Silver Lake Transactions”) are expected to close on August 25, 2015 (the “Closing”).

[0001193125-15-277673:8k_body:4]
On August 5, 2015, the Company issued
a press release announcing the Silver Lake Transactions. A copy of this press release is attached hereto as Exhibit 99.1.

[0001193125-15-277673:8k_body:5]
Issuance of Convertible
Notes

[0001193125-15-277673:8k_body:6]
The Notes are expected to be governed by an indenture (the “Indenture”) between the Company and The Bank of New York Mellon Trust
Company, N.A. (the “Trustee”), and are expected to bear interest at a rate of 2.0% per annum, payable semiannually in cash. It is expected that the notes will mature in September 2020 subject to earlier conversion.

[0001193125-15-277673:8k_body:7]
It is expected that the Notes will be convertible into cash and, at the Company’s option, shares of the Company’s common stock (the “Common
Stock”), based on a conversion rate of 14.5985 per $1,000 principal amount of the Notes (which is equal to an initial conversion price of $68.50 per share), in each case subject to customary anti-dilution and other adjustments, including a
make-whole adjustment in connection with certain extraordinary transactions.

[0001193125-15-277673:8k_body:8]
With certain exceptions, upon a change of control of the Company or the
failure of the Common Stock to be listed on certain stock exchanges (a “Fundamental Change”), the holders of the Notes may require that the Company repurchase all or part of the principal amount of the Notes at purchase price of par plus
accrued and unpaid interest.

[0001193125-15-277673:8k_body:9]
The Indenture will include customary “events of default,” which may result in the acceleration of the maturity of
the Notes under the Indenture. The Indenture will also include customary covenants for convertible notes of this type.

[0001193125-15-277673:8k_body:10]
Board Representation

[0001193125-15-277673:8k_body:11]
In connection with the Closing, the Company will expand the size of the Company’s Board of Directors (the “Board”) and appoint two Silver Lake
managing partners, Egon Durban and Greg Mondre, to the Board.

[0001193125-15-277673:8k_body:12]
Silver Lake’s rights to Board representation will terminate under certain
circumstances, as described in the Investment Agreement, including if Silver Lake and its affiliates beneficially own less than 50% of the Common Stock (on an as-converted basis) owned by Silver Lake immediately following the Closing. The Company
also has the right to require that one director affiliated with Silver Lake resign from the Board if Silver Lake and its affiliates beneficially own less than 75% of the Common Stock (on an as-converted basis) owned by Silver Lake immediately
following the Closing. In addition, the Company has the right to require that one director affiliated with Silver Lake resign from the Board after the 18 month anniversary of the Closing, in which case Silver Lake’s transfer and conversion
restrictions with respect to 50% of the principal amount of the Notes will be released if Silver Lake and affiliates own at least 75% of the Common Stock (on as–converted basis) owned by Silver Lake immediately following the Closing.

[0001193125-15-277673:8k_body:13]
For so long as Silver Lake has rights to nominate a director to the Board, the Company has agreed to include such person in its slate of nominees for election
to the Board at each of the Company’s meetings of stockholders in which directors are to be elected and to use its reasonable efforts to cause the election of such person.

[0001193125-15-277673:8k_body:14]
Standstill and Voting Obligations

[0001193125-15-277673:8k_body:15]
Pursuant to the
Investment Agreement, Silver Lake has agreed, subject to certain exceptions, that until the earliest of (A) the later of (1) 90 days after Silver Lake no longer has a representative or rights to have a representative on the Board and
(2) the three-year anniversary of the closing of the Silver Lake Transactions, (B) the effective date of a change of control of the Company and (C) 90 days after Silver Lake does not beneficially own any Notes or shares of Common
Stock other than the shares issued to Silver Lake designees as compensation for their service on the Board (the “Standstill Period”), Silver Lake will not, among other things: (i) acquire any securities of the Company if, immediately
after such acquisition, Silver Lake would collectively own in the aggregate more than 12.5% of the then outstanding voting securities of the Company, (ii) propose or seek to effect any tender or exchange offer, merger or other business
combination involving the Company, or make any public

[0001193125-15-277673:8k_body:16]
statement with respect to such transaction, (iii) make, or in any way participate in any “proxy contest” or other solicitation of proxies, (iv) sell, transfer or otherwise
dispose of any voting securities of the Company to any person who is (or will become upon consummation of such sale, transfer or other disposition) a beneficial owner of 12.5% or more of the outstanding voting securities of the Company, or
(v) call or seek to call any meeting of stockholders or other referendum or consent solicitation.

[0001193125-15-277673:8k_body:17]
In addition, Silver Lake has agreed to vote any
shares of Common Stock beneficially owned by it in support of Company-nominated directors and otherwise in accordance with the recommendations of the Board.

[0001193125-15-277673:8k_body:18]
Conversion and Transfer Restrictions / Registration Rights

[0001193125-15-277673:8k_body:19]
The Investment Agreement restricts Silver Lake’s ability to transfer or convert the Notes to Common Stock, subject to certain exceptions specified in the
Investment Agreement and summarized below.

[0001193125-15-277673:8k_body:20]
Except as described below, prior to the earlier of (i) the second anniversary of the Closing,
(ii) such time as there is no Silver Lake affiliated director on the Board (subject to certain exceptions) and (iii) a change of control of the Company, Silver Lake will be restricted from transferring or entering into an agreement that
transfers the economic consequences of ownership of the Notes or converting the Notes. Exceptions include, among others: (A) with respect to pledging the Notes or satisfying obligations related to pledged Notes, (B) if at any time the
average of the daily volume weighted average price of the Common Stock over ten consecutive trading days exceeds $85 per share, Silver Lake may transfer or convert, at any time after the one-year anniversary of the Closing, up to 20% of the
principal amount of the Notes (or shares of Common Stock issuable upon conversion of such notes), and (C) Silver Lake will be released from its transfer and conversion restrictions for up to 50% of the principal amount of the Notes if the
Company exercises its right to require that one Silver Lake affiliated director resign from the Board after 18 months following the Closing and at such time Silver Lake beneficially owns at least 75% of the Common Stock (on an as-converted basis)
owned by Silver Lake immediately following the Closing.

[0001193125-15-277673:8k_body:21]
Subject to certain limitations, the Investment Agreement provides Silver Lake with certain
registration rights for the Notes and the shares of Common Stock issuable upon conversion of the Notes.

[0001193125-15-277673:8k_body:22]
The foregoing description of the Notes and
Investment Agreement is qualified in its entirety by reference to the Investment Agreement and form of Indenture, which are attached hereto as Exhibit 10.1 and Exhibit 10.2, respectively, and incorporated herein by reference.

## item 5.02 — body, verbatim

[0001193125-15-277673:8k_body:23]
Item 5.02

[0001193125-15-277673:8k_body:24]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001193125-15-277673:8k_body:25]
The information contained in Item 1.01 of this Current Report on Form 8-K is incorporated herein by reference.

[0001193125-15-277673:8k_body:26]
The Compensation and Leadership Committee of the Board has discussed a general framework for a one-time grant of performance contingent stock options
(“PCSOs”) to members of the Company’s senior leadership team. The one-time grant is expected to represent approximately 1% of the fully-diluted equity of the Company assuming the completion of the Tender Offer (as defined below). The
PCSOs are expected to have a seven-year term and a per share strike price equal to the greater of $68.50 and the closing price of a share of common stock of the Company on the grant date. The PCSOs will vest upon satisfaction of specified Company
stock price hurdles which must be maintained for 10-consecutive trading days during the three year period following the grant date – 20% of the total award would vest at an $85 stock price; 30% of the total award would vest at a $102.50 stock
price; and 50% of the total award would vest at a $120 stock price. If the stock price hurdles are not met during the three year period the unvested PCSOs will expire. The grant of PCSOs is subject to completion of the Closing and approval by the
Compensation and Leadership Committee. The Company will disclose the final terms of the PCSOs if and when the grants occur.
