# MSI 10-Q controls and the auditor's report


## item_4_controls

[0000068505-16-000020:item_4_controls:1]
Item 4. Controls and Procedures

[0000068505-16-000020:item_4_controls:2]
(a) Evaluation of disclosure controls and procedures. Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of the end of the period covered by this quarterly report (the “Evaluation Date”). Based on this evaluation, our chief executive officer and chief financial officer concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information relating to Motorola Solutions, including our consolidated subsidiaries, required to be disclosed in our Securities and Exchange Commission (“SEC”) reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and (ii) is accumulated and communicated to Motorola Solutions’ management, including our chief executive officer and chief financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000068505-16-000020:item_4_controls:3]
(b) Changes in internal control over financial reporting. There have been no changes in our internal control over financial reporting that occurred during the quarter ended April 2, 2016, that have materially affected or are reasonably likely to materially affect our internal control over financial reporting.

[0000068505-16-000020:item_4_controls:4]
We previously were in the process of a multi-year phased upgrade and consolidation of our enterprise resource planning (“ERP”) systems into a single global platform across our businesses. With the sale of the Enterprise business which included the transfer of our existing ERP system to Zebra, we have entered into transition service agreements which require us to operate in a shared information technology environment with Zebra until 2017. We are completing the design phase for the initial release of our future ERP system and have begun system integration testing. There will be two phases of our move to the new ERP. Phase one will allow us to cease using the Zebra transition services agreement and includes the replacement of regional systems supporting our product based business and the current indirect procurement system. Phase two will address the consolidation of our projects based business. Both phases are scheduled to go-live in 2017.

[0000068505-16-000020:item_4_controls:5]
33
