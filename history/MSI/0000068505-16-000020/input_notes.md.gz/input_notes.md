# MSI notes — 0000068505-16-000020


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-16-000020:notes:1]
Investments

[0000068505-16-000020:notes:2]
[same as prior period, unchanged from 0000068505-15-000013:notes:1]

[0000068505-16-000020:notes:3]
| April 2, 2016 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 52 |  |  | $ | — |  |  | $ | 52 |  |
| Corporate bonds | 7 |  |  | — |  |  | 7 |  |
| Common stock | — |  |  | 2 |  |  | 2 |  |
|  | 59 |  |  | 2 |  |  | 61 |  |
| Other investments, at cost | 204 |  |  | — |  |  | 204 |  |
| Equity method investments | 10 |  |  | — |  |  | 10 |  |
|  | $ | 273 |  |  | $ | 2 |  |  | $ | 275 |  |
| Less: current portion of available-for-sale securities |  |  |  |  | 47 |  |
|  |  |  |  |  | $ | 228 |  |

[0000068505-16-000020:notes:4]
| December 31, 2015 | Cost Basis |  | Unrealized Gains |  | Unrealized Losses |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 455 |  |  | $ | — |  |  | $ | (11 | ) |  | $ | 444 |  |
| Corporate bonds | 7 |  |  | — |  |  | — |  |  | 7 |  |
| Common stock | — |  |  | 6 |  |  | — |  |  | 6 |  |
|  | 462 |  |  | 6 |  |  | (11 | ) |  | 457 |  |
| Other investments, at cost | 203 |  |  | — |  |  | — |  |  | 203 |  |
| Equity method investments | 9 |  |  | — |  |  | — |  |  | 9 |  |
|  | 674 |  |  | 6 |  |  | (11 | ) |  | 669 |  |
| Less: current portion of available-for-sale securities |  |  |  |  |  |  | 438 |  |
|  |  |  |  |  |  |  | $ | 231 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-16-000020:notes:5]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of April 2, 2016 and December 31, 2015 were as follows:

[0000068505-16-000020:notes:6]
| April 2, 2016 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 3 |  |  | $ | 3 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | — |  |  | $ | 52 |  |  | $ | 52 |  |
| Corporate bonds | — |  |  | 7 |  |  | 7 |  |
| Common stock | 2 |  |  | — |  |  | 2 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Interest rate swap | — |  |  | 1 |  |  | 1 |  |

[0000068505-16-000020:notes:7]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 444 |  |  | 444 |  |
| Corporate bonds | — |  |  | 7 |  |  | 7 |  |
| Common stock | 6 |  |  | — |  |  | 6 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |
| Interest rate swap | — |  |  | 1 |  |  | 1 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-16-000020:notes:8]
Long-term Financing and Sales of Receivables

[0000068505-16-000020:notes:9]
Long-term Financing

[0000068505-16-000020:notes:10]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-16-000020:notes:11]
|  | April 2, 2016 |  | December 31, 2015 |
| Long-term receivables | $ | 42 |  |  | $ | 60 |  |
| Less current portion | (13 | ) |  | (13 | ) |
| Gross non-current long-term receivables | $ | 29 |  |  | $ | 47 |  |

[0000068505-16-000020:notes:12]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $91 million at April 2, 2016, compared to $112 million at December 31, 2015.

[0000068505-16-000020:notes:13]
[same as prior period, unchanged from 0000068505-15-000013:notes:12]

[0000068505-16-000020:notes:14]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended April 2, 2016 and April 4, 2015:

[0000068505-16-000020:notes:15]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Accounts receivable sales proceeds | $ | 2 |  |  | $ | 6 |  |
| Long-term receivables sales proceeds | 42 |  |  | 65 |  |
| Total proceeds from receivable sales | $ | 44 |  |  | $ | 71 |  |

[0000068505-16-000020:notes:16]
At both April 2, 2016 and December 31, 2015, the Company had retained servicing obligations for $668 million of long-term receivables. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-16-000020:notes:17]
Credit Quality of Financing Receivables and Allowance for Credit Losses

[0000068505-16-000020:notes:18]
An aging analysis of financing receivables at April 2, 2016 and December 31, 2015 is as follows:

[0000068505-16-000020:notes:19]
| April 2, 2016 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 38 |  |  | 4 |  |  | — |  |  | 1 |  |
| Total gross long-term receivables, including current portion | $ | 42 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 1 |  |

[0000068505-16-000020:notes:20]
| December 31, 2015 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 35 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 25 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Total gross long-term receivables, including current portion | $ | 60 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |


## msi:OtherChargesTableTextBlock

[0000068505-16-000020:notes:21]
[same as prior period, unchanged from 0000068505-15-000013:notes:20]

[0000068505-16-000020:notes:22]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Other charges: |  |  |  |
| Intangibles amortization | $ | 13 |  |  | $ | 2 |  |
| Reorganization of business | 7 |  |  | 12 |  |
| Acquisition related transaction fees | 13 |  |  | — |  |
|  | $ | 33 |  |  | $ | 14 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-16-000020:notes:23]
[same as prior period, unchanged from 0000068505-15-000013:notes:22]

[0000068505-16-000020:notes:24]
| April 2, 2016 | Three Months Ended |
| Products | $ | 21 |  |
| Services | 2 |  |
|  | $ | 23 |  |

[0000068505-16-000020:notes:25]
| April 4, 2015 | Three Months Ended |
| Products | $ | 10 |  |
| Services | 4 |  |
|  | $ | 14 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-16-000020:notes:26]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-16-000020:notes:27]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Share-based compensation expense included in: |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 3 |  |
| Selling, general and administrative expenses | 12 |  |  | 13 |  |
| Research and development expenditures | 3 |  |  | 5 |  |
| Share-based compensation expense included in Operating earnings | 17 |  |  | 21 |  |
| Tax benefit | 5 |  |  | 7 |  |
| Share-based compensation expense, net of tax | $ | 12 |  |  | $ | 14 |  |
| Decrease in basic earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |
| Decrease in diluted earnings per share | $ | (0.07 | ) |  | $ | (0.06 | ) |
| Share-based compensation expense in discontinued operations | $ | — |  |  | $ | — |  |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-16-000020:notes:28]
[same as prior period, unchanged from 0000068505-15-000013:notes:27]

[0000068505-16-000020:notes:29]
|  | April 2, 2016 |  | December 31, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 86 |  |  | $ | 59 |  |  | $ | 89 |  |  | $ | 60 |  |
| Services | 657 |  |  | 15 |  |  | 22 |  |  | 2 |  |
|  | $ | 743 |  |  | $ | 74 |  |  | $ | 111 |  |  | $ | 62 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-16-000020:notes:30]
[same as prior period, unchanged from 0000068505-15-000013:notes:29]

[0000068505-16-000020:notes:31]
|  | April 2, 2016 |  | December 31, 2015 |
| Defined benefit plans | $ | 1,511 |  |  | $ | 1,512 |  |
| Postretirement Health Care Benefit Plan | 46 |  |  | 49 |  |
| Deferred revenue | 113 |  |  | 113 |  |
| Unrecognized tax benefits | 42 |  |  | 50 |  |
| Deferred income taxes | 141 |  |  | — |  |
| Deferred consideration (Note 14) | 82 |  |  | — |  |
| Other | 196 |  |  | 180 |  |
|  | $ | 2,131 |  |  | $ | 1,904 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-16-000020:notes:32]
[same as prior period, unchanged from 0000068505-15-000013:notes:31]

[0000068505-16-000020:notes:33]
[same as prior period, unchanged from 0000068505-15-000013:notes:32]

[0000068505-16-000020:notes:34]
[same as prior period, unchanged from 0000068505-15-000013:notes:33]

[0000068505-16-000020:notes:35]
[same as prior period, unchanged from 0000068505-15-000013:notes:34]

[0000068505-16-000020:notes:36]
[same as prior period, unchanged from 0000068505-15-000013:notes:35]

[0000068505-16-000020:notes:37]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Interest income (expense), net: |  |  |  |
| Interest expense | $ | (53 | ) |  | $ | (43 | ) |
| Interest income | 4 |  |  | 3 |  |
|  | $ | (49 | ) |  | $ | (40 | ) |
| Other: |  |  |  |
| Foreign currency gain | $ | 13 |  |  | $ | 18 |  |
| Loss on derivative instruments | (12 | ) |  | (17 | ) |
| Gains on equity method investments | 1 |  |  | — |  |
| Realized foreign currency loss on acquisition | (10 | ) |  | — |  |
| Other | — |  |  | 2 |  |
|  | $ | (8 | ) |  | $ | 3 |  |

[0000068505-16-000020:notes:38]
[same as prior period, unchanged from 0000068505-15-000013:notes:37]

[0000068505-16-000020:notes:39]
[same as prior period, unchanged from 0000068505-15-000013:notes:38]

[0000068505-16-000020:notes:40]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Three Months Ended | April 2, 2016 |  | April 4, 2015 |  | April 2, 2016 |  | April 4, 2015 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 17 |  |  | $ | 87 |  |  | $ | 17 |  |  | $ | 74 |  |
| Weighted average common shares outstanding | 174.5 |  |  | 215.3 |  |  | 174.5 |  |  | 215.3 |  |
| Per share amount | $ | 0.10 |  |  | $ | 0.40 |  |  | $ | 0.10 |  |  | $ | 0.34 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 17 |  |  | $ | 87 |  |  | $ | 17 |  |  | $ | 74 |  |
| Weighted average common shares outstanding | 174.5 |  |  | 215.3 |  |  | 174.5 |  |  | 215.3 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.5 |  |  | 2.5 |  |  | 2.5 |  |  | 2.5 |  |
| Diluted weighted average common shares outstanding | 177.0 |  |  | 217.8 |  |  | 177.0 |  |  | 217.8 |  |
| Per share amount | $ | 0.10 |  |  | $ | 0.40 |  |  | $ | 0.10 |  |  | $ | 0.34 |  |

[0000068505-16-000020:notes:41]
In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three months ended April 2, 2016, the assumed exercise of 4.0 million options and the assumed vesting of 0.6 million restricted stock units ("RSUs") were excluded because their inclusion would have been antidilutive. For the three months ended April 4, 2015, the assumed exercise of 2.2 million stock options and the assumed vesting of 0.5 million RSUs were excluded because their inclusion would have been antidilutive.

[0000068505-16-000020:notes:42]
On August 25, 2015, the Company issued $1.0 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). See discussion in Note 4. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-16-000020:notes:43]
Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, Motorola Solutions does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. In this case, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $68.50. For the three months ended April 2, 2016, there was no dilutive impact of the Senior Convertible Notes.

[0000068505-16-000020:notes:44]
[same as prior period, unchanged from 0000068505-15-000013:notes:45]

[0000068505-16-000020:notes:45]
[same as prior period, unchanged from 0000068505-15-000013:notes:46]

[0000068505-16-000020:notes:46]
The Company’s cash and cash equivalents were $1.9 billion at April 2, 2016 and $2.0 billion at December 31, 2015. Of these amounts, $63 million was restricted at both April 2, 2016 and December 31, 2015.

[0000068505-16-000020:notes:47]
[same as prior period, unchanged from 0000068505-15-000013:notes:50]

[0000068505-16-000020:notes:48]
[same as prior period, unchanged from 0000068505-15-000013:notes:51]

[0000068505-16-000020:notes:49]
|  | April 2, 2016 |  | December 31, 2015 |
| Accounts receivable | $ | 1,179 |  |  | $ | 1,390 |  |
| Less allowance for doubtful accounts | (31 | ) |  | (28 | ) |
|  | $ | 1,148 |  |  | $ | 1,362 |  |

[0000068505-16-000020:notes:50]
[same as prior period, unchanged from 0000068505-15-000013:notes:53]

[0000068505-16-000020:notes:51]
[same as prior period, unchanged from 0000068505-15-000013:notes:54]

[0000068505-16-000020:notes:52]
|  | April 2, 2016 |  | December 31, 2015 |
| Finished goods | $ | 163 |  |  | $ | 151 |  |
| Work-in-process and production materials | 271 |  |  | 287 |  |
|  | 434 |  |  | 438 |  |
| Less inventory reserves | (147 | ) |  | (142 | ) |
|  | $ | 287 |  |  | $ | 296 |  |

[0000068505-16-000020:notes:53]
[same as prior period, unchanged from 0000068505-15-000013:notes:56]

[0000068505-16-000020:notes:54]
[same as prior period, unchanged from 0000068505-15-000013:notes:57]

[0000068505-16-000020:notes:55]
|  | April 2, 2016 |  | December 31, 2015 |
| Available-for-sale securities | $ | 47 |  |  | $ | 438 |  |
| Costs and earnings in excess of billings | 324 |  |  | 374 |  |
| Tax-related refunds receivable | 110 |  |  | 44 |  |
| Other | 145 |  |  | 98 |  |
|  | $ | 626 |  |  | $ | 954 |  |

[0000068505-16-000020:notes:56]
[same as prior period, unchanged from 0000068505-15-000013:notes:60]

[0000068505-16-000020:notes:57]
[same as prior period, unchanged from 0000068505-15-000013:notes:61]

[0000068505-16-000020:notes:58]
|  | April 2, 2016 |  | December 31, 2015 |
| Land | $ | 17 |  |  | $ | 17 |  |
| Building | 521 |  |  | 523 |  |
| Machinery and equipment | 2,109 |  |  | 1,585 |  |
|  | 2,647 |  |  | 2,125 |  |
| Less accumulated depreciation | (1,650 | ) |  | (1,638 | ) |
|  | $ | 997 |  |  | $ | 487 |  |

[0000068505-16-000020:notes:59]
Depreciation expense for the three months ended April 2, 2016 and April 4, 2015 was $49 million and $39 million, respectively.

[0000068505-16-000020:notes:60]
On February 1, 2016, the Company completed the sale of its Penang, Malaysia manufacturing operations, including the land, building, equipment, and inventory, as well as the transfer of employees to a contract manufacturer. During the three months ended April 2, 2016, the Company incurred a loss of $7 million on the sale of its Penang, Malaysia facility and manufacturing operations, which is included within Gains (losses) on sales of investments and businesses, net.

[0000068505-16-000020:notes:61]
Subsequent to the three months ended April 2, 2016, the Company entered into an agreement for the sale of its corporate aircraft. The Company recognized an impairment loss of $3 million within Other charges during the three months ended April 2, 2016 based on the contracted sales price of the aircraft held for sale and has presented the aircraft as assets held for sale in its condensed consolidated balance sheets.

[0000068505-16-000020:notes:62]
The Company acquired property, plant and equipment, including network assets, of $481 million in the acquisition of GDCL. The valuation of acquired property, plant and equipment is not yet finalized and may be subject to a fair value adjustment. See discussion in Note 14.

[0000068505-16-000020:notes:63]
In December 2015, the Company invested $401 million in United Kingdom treasury securities in order to partially offset the risk associated with fluctuations in the British Pound Sterling in the period before the closing of the purchase of GDCL. The investments were recorded within Other current assets in the Company's consolidated balance sheets. The Company liquidated these investments in February 2016 to partially fund the acquisition of GDCL. During the three months ended April 2, 2016, the Company realized a loss of $19 million associated with the sale, of which, $11 million was unrealized as of December 31, 2015.

[0000068505-16-000020:notes:64]
[same as prior period, unchanged from 0000068505-15-000013:notes:66]

[0000068505-16-000020:notes:65]
[same as prior period, unchanged from 0000068505-15-000013:notes:67]

[0000068505-16-000020:notes:66]
|  | April 2, 2016 |  | December 31, 2015 |
| Intangible assets, net | $ | 669 |  |  | $ | 49 |  |
| Long-term receivables | 29 |  |  | 47 |  |
| Defined benefit plan assets | 135 |  |  | 128 |  |
| Other | 51 |  |  | 47 |  |
|  | $ | 884 |  |  | $ | 271 |  |

[0000068505-16-000020:notes:67]
[same as prior period, unchanged from 0000068505-15-000013:notes:69]

[0000068505-16-000020:notes:68]
[same as prior period, unchanged from 0000068505-15-000013:notes:70]

[0000068505-16-000020:notes:69]
|  | April 2, 2016 |  | December 31, 2015 |
| Deferred revenue | $ | 399 |  |  | $ | 390 |  |
| Compensation | 167 |  |  | 241 |  |
| Billings in excess of costs and earnings | 301 |  |  | 337 |  |
| Tax liabilities | 49 |  |  | 48 |  |
| Dividend payable | 72 |  |  | 71 |  |
| Trade liabilities | 133 |  |  | 135 |  |
| Other | 483 |  |  | 449 |  |
|  | $ | 1,604 |  |  | $ | 1,671 |  |

[0000068505-16-000020:notes:70]
[same as prior period, unchanged from 0000068505-15-000013:notes:72]

[0000068505-16-000020:notes:71]
During the three months ended April 2, 2016, the Company recorded an increase to its deferred income tax liability as a result of the acquisition of GDCL, as well as a liability of $82 million in the accounting for the acquisition of GDCL related to a payment of deferred consideration due on November 15, 2018 to the former owners. See discussion in Note 14.

[0000068505-16-000020:notes:72]
[same as prior period, unchanged from 0000068505-15-000013:notes:73]

[0000068505-16-000020:notes:73]
[same as prior period, unchanged from 0000068505-15-000013:notes:74]

[0000068505-16-000020:notes:74]
During the three months ended April 2, 2016, the Company paid an aggregate of $64 million, including transaction costs, to repurchase approximately 0.9 million shares at an average price of $71.41 per share. As of April 2, 2016, the Company had used approximately $11.0 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.0 billion of authority available for future repurchases.

[0000068505-16-000020:notes:75]
Payment of Dividends:  During the three months ended April 2, 2016 and April 4, 2015, the Company paid $71 million and $75 million, respectively, in cash dividends to holders of its common stock.

[0000068505-16-000020:notes:76]
[same as prior period, unchanged from 0000068505-15-000013:notes:79]

[0000068505-16-000020:notes:77]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three months ended April 2, 2016 and April 4, 2015:

[0000068505-16-000020:notes:78]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Foreign Currency Translation Adjustments: |  |  |  |
| Balance at beginning of period | $ | (266 | ) |  | $ | (204 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 14 |  |  | (27 | ) |
| Tax (expense) benefit | (1 | ) |  | 1 |  |
| Other comprehensive income (loss), net of tax | 13 |  |  | (26 | ) |
| Balance at end of period | $ | (253 | ) |  | $ | (230 | ) |
| Available-for-Sale Securities: |  |  |  |
| Balance at beginning of period | $ | (3 | ) |  | $ | 44 |  |
| Other comprehensive loss before reclassification adjustment | — |  |  | (7 | ) |
| Tax benefit | — |  |  | 3 |  |
| Other comprehensive loss before reclassification adjustment, net of tax | — |  |  | (4 | ) |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net | 6 |  |  | (46 | ) |
| Tax expense (benefit) | (2 | ) |  | 17 |  |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net of tax | 4 |  |  | (29 | ) |
| Other comprehensive income (loss), net of tax | 4 |  |  | (33 | ) |
| Balance at end of period | $ | 1 |  |  | $ | 11 |  |
| Defined Benefit Plans: |  |  |  |
| Balance at beginning of period | $ | (1,597 | ) |  | $ | (1,695 | ) |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 10 |  |  | 19 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (5 | ) |  | (17 | ) |
| Tax benefit | (1 | ) |  | (1 | ) |
| Reclassification adjustment into Selling, general, and administrative expenses, net of tax | 4 |  |  | 1 |  |
| Other comprehensive income, net of tax | 4 |  |  | 1 |  |
| Balance at end of period | $ | (1,593 | ) |  | $ | (1,694 | ) |
| Total Accumulated other comprehensive loss | $ | (1,845 | ) |  | $ | (1,913 | ) |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000068505-16-000020:notes:79]
The following table presents the unaudited pro forma combined results of operations of the Company and GDCL for the three months ended April 2, 2016 and April 4, 2015 as if the acquisition of GDCL had occurred on January 1, 2016 and January 1, 2015, respectively, (in millions, except per share amounts):

[0000068505-16-000020:notes:80]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Revenues | $ | 1,264 |  |  | $ | 1,364 |  |
| Earnings from continuing operations | 41 |  |  | 100 |  |
| Basic earnings per share | 0.24 |  |  | 0.46 |  |
| Diluted earnings per share | 0.23 |  |  | 0.46 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-16-000020:notes:81]
Commitments and Contingencies

[0000068505-16-000020:notes:82]
Legal Matters

[0000068505-16-000020:notes:83]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-16-000020:notes:84]
Other Indemnifications

[0000068505-16-000020:notes:85]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-16-000020:notes:86]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at April 2, 2016.

[0000068505-16-000020:notes:87]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-16-000020:notes:88]
Debt and Credit Facilities

[0000068505-16-000020:notes:89]
As of April 2, 2016, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 2, 2016. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the three months ended April 2, 2016.

[0000068505-16-000020:notes:90]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-16-000020:notes:91]
The Company has recorded a debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.4%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $992 million, indicating an $8 million discount to be amortized over the expected life of the debt instrument. The total of proceeds received in excess of the fair value of the debt liability of $8 million has been recorded within Additional paid-in capital.

[0000068505-16-000020:notes:92]
In connection with the completion of the acquisition of GDCL, the Company entered into a new term loan credit agreement (the “Term Loan Agreement”), under which the Company borrowed a Term Loan with an initial principal amount of $675 million and a maturity date of February 18, 2019. Interest on the Term Loan is variable and indexed to LIBOR. The interest expense on the Term Loan is payable semi-annually in May and November. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed. The Company's borrowing capacity under the 2014 Motorola Solutions Credit Agreement may be partially limited during the second quarter of 2016 due to the additional indebtedness incurred in connection with the Term Loan.

[0000068505-16-000020:notes:93]
Effective January 1, 2016, the Company retrospectively adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, we have revised the presentation of debt issuance costs which were previously capitalized in other assets in the consolidated balance sheet to be presented as a reduction to long-term debt. As of April 2, 2016 and December 31, 2015, $40 million and $41 million, respectively, have been reclassified to be presented as a component of long-term debt.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-16-000020:notes:94]
[same as prior period, unchanged from 0000068505-15-000013:notes:93]

[0000068505-16-000020:notes:95]
[same as prior period, unchanged from 0000068505-15-000013:notes:94]

[0000068505-16-000020:notes:96]
As of April 2, 2016, the Company had outstanding foreign exchange contracts with notional amounts totaling $708 million, compared to $494 million outstanding at December 31, 2015. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-16-000020:notes:97]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of April 2, 2016, and the corresponding positions as of December 31, 2015:

[0000068505-16-000020:notes:98]
|  | Notional Amount |
| Net Buy (Sell) by Currency | April 2, 2016 |  | December 31, 2015 |
| Euro | $ | 233 |  |  | $ | 99 |  |
| British Pound | 150 |  |  | 62 |  |
| Chinese Renminbi | (95 | ) |  | (114 | ) |
| Australian Dollar | (51 | ) |  | (60 | ) |
| Brazilian Real | (49 | ) |  | (44 | ) |

[0000068505-16-000020:notes:99]
[same as prior period, unchanged from 0000068505-15-000013:notes:98]

[0000068505-16-000020:notes:100]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as a hedge. As such, the changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swap was in a liability position of $1 million at both April 2, 2016 and  December 31, 2015.

[0000068505-16-000020:notes:101]
[same as prior period, unchanged from 0000068505-15-000013:notes:101]

[0000068505-16-000020:notes:102]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of April 2, 2016, all of the counterparties have investment grade credit ratings. As of April 2, 2016, the Company had $3 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-16-000020:notes:103]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of April 2, 2016 and December 31, 2015:

[0000068505-16-000020:notes:104]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| April 2, 2016 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  | Other current assets |  | $ | 5 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other current assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives | $ | 3 |  |  |  |  | $ | 6 |  |  |  |

[0000068505-16-000020:notes:105]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2015 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | 6 |  |  | Other current assets |  | 2 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other current assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives | 6 |  |  |  |  | 3 |  |  |  |

[0000068505-16-000020:notes:106]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated statements of operations for the three months ended April 2, 2016 and April 4, 2015:

[0000068505-16-000020:notes:107]
|  | Three Months Ended |  | Statements ofOperations Location |
| Loss on Derivative Instruments | April 2, 2016 |  | April 4, 2015 |  |
| Interest rate swap | $ | — |  |  | $ | (1 | ) |  | Other income (expense) |
| Foreign exchange contracts | (12 | ) |  | (16 | ) |  | Other income (expense) |
| Total derivatives | $ | (12 | ) |  | $ | (17 | ) |  |  |

[0000068505-16-000020:notes:108]
The Company had no instruments designated as hedging instruments for the three months ended April 2, 2016 and April 4, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-16-000020:notes:109]
[same as prior period, unchanged from 0000068505-15-000013:notes:110]

[0000068505-16-000020:notes:110]
During the three months ended April 2, 2016, the Company granted 0.6 million RSUs and market stock units ("MSUs") and 0.6 million stock options and performance options ("POs"). The total aggregate compensation expense, net of estimated forfeitures, for these RSUs and MSUs was $36 million and stock options and POs was $10 million, respectively, which will generally be recognized over the vesting period of three years.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-16-000020:notes:111]
[same as prior period, unchanged from 0000068505-15-000013:notes:113]

[0000068505-16-000020:notes:112]
[same as prior period, unchanged from 0000068505-15-000013:notes:114]

[0000068505-16-000020:notes:113]
During the three months ended April 2, 2016, the Company had no activity in the condensed consolidated statements of operations for discontinued operations. During the three months ended April 4, 2015, the Company recorded a $13 million loss from discontinued operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-16-000020:notes:114]
[same as prior period, unchanged from 0000068505-15-000013:notes:118]

[0000068505-16-000020:notes:115]
[same as prior period, unchanged from 0000068505-15-000013:notes:119]

[0000068505-16-000020:notes:116]
[same as prior period, unchanged from 0000068505-15-000013:notes:120]

[0000068505-16-000020:notes:117]
[same as prior period, unchanged from 0000068505-15-000013:notes:121]

[0000068505-16-000020:notes:118]
[same as prior period, unchanged from 0000068505-15-000013:notes:122]

[0000068505-16-000020:notes:119]
[same as prior period, unchanged from 0000068505-15-000013:notes:123]

[0000068505-16-000020:notes:120]
The Company had no Level 3 holdings as of April 2, 2016 or December 31, 2015.

[0000068505-16-000020:notes:121]
At both April 2, 2016 and December 31, 2015, the Company had $1.3 billion of investments in money market mutual funds (Level 2) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-16-000020:notes:122]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at April 2, 2016 and December 31, 2015 was $5.0 billion and $4.1 billion (Level 2), respectively.

[0000068505-16-000020:notes:123]
[same as prior period, unchanged from 0000068505-15-000013:notes:127]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-16-000020:notes:124]
[same as prior period, unchanged from 0000068505-15-000013:notes:128]

[0000068505-16-000020:notes:125]
[same as prior period, unchanged from 0000068505-15-000013:notes:136]

[0000068505-16-000020:notes:126]
During the year ended December 31, 2015 the Company completed the acquisitions of two providers of public safety software-based solutions for an aggregate purchase price of $50 million, recognizing an additional $31 million of goodwill, $22 million of identifiable intangible assets, and $3 million of acquired liabilities related to these acquisitions. The $22 million of identifiable intangible assets were classified as: (i) $11 million of completed technology, (ii) $8 million of customer-related, and (iii) $3 million of other intangibles. These intangible assets will be amortized over periods ranging from five to ten years. The results of operations for these acquisitions have been included in the Company’s condensed consolidated statements of operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-16-000020:notes:127]
On February 19, 2016, the Company completed the acquisition of GDCL, a holding company of Airwave, the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which the Company invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. The Company will make a deferred cash payment of £64 million on November 15, 2018.

[0000068505-16-000020:notes:128]
The acquisition of GDCL enables the Company to geographically diversify its global Managed & Support services offerings within its Services segment, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. During the three months ended April 2, 2016, the Company recorded $61 million within Net sales and $3 million within Net earnings from the operations of Airwave.

[0000068505-16-000020:notes:129]
The acquisition of GDCL has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value. The valuation of assets acquired and liabilities assumed in the acquisition has not yet been finalized as of April 2, 2016. As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. The final allocation could differ materially from the preliminary allocation. The final allocation may include: (i) changes in fair values of property, plant and equipment, (ii) changes in allocations to intangible assets such as trade names, customer relationships, and goodwill, and (iii) other changes to assets and liabilities.

[0000068505-16-000020:notes:130]
The total consideration for the acquisition of GDCL was approximately $1.1 billion, consisting of cash payments of $1.0 billion, net of cash acquired, and deferred consideration valued at fair value based on its net present value on the date of the acquisition of $82 million. The net present value has been calculated using a discount rate of 4.2%, which is reflective of the credit standing of the combined entity. The following table summarizes preliminary fair values of assets acquired and liabilities assumed as of the February 19, 2016 acquisition date:

[0000068505-16-000020:notes:131]
| Cash |  | $ | 86 |  |
| Accounts receivable, net |  | 55 |  |
| Other current assets |  | 36 |  |
| Property, plant and equipment, net |  | 481 |  |
| Deferred income taxes |  | 79 |  |
| Intangible assets |  | 631 |  |
| Accounts payable |  | (18 | ) |
| Accrued liabilities |  | (184 | ) |
| Other liabilities |  | (254 | ) |
| Goodwill |  | 170 |  |
| Total consideration |  | $ | 1,082 |  |
| Net present value of deferred consideration payment to former owners |  | (82 | ) |
| Net cash consideration at purchase |  | $ | 1,000 |  |

[0000068505-16-000020:notes:132]
Acquired intangible assets consist of $602 million of customer relationships and $29 million of trade names. All intangibles have a useful life of 7 years, over which amortization expense will be recognized on a straight line basis.

[0000068505-16-000020:notes:133]
The fair values of trade names and customer relationships were estimated using the income approach. Customer relationships were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them.

[0000068505-16-000020:notes:134]
Goodwill is calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. Goodwill is not deductible for tax purposes.

[0000068505-16-000020:notes:135]
Pro Forma Financial Information

[0000068505-16-000020:notes:136]
The pro forma results are based on estimates and assumptions, which the Company believes are reasonable. They are not necessarily indicative of its consolidated results of operations in future periods or the results that actually would have been realized had we been a combined company during the periods presented. The pro forma results include adjustments primarily related to amortization of acquired intangible assets, interest expense, and transaction costs expensed during the period.

[0000068505-16-000020:notes:137]
[same as prior period, unchanged from 0000068505-15-000013:notes:129]

[0000068505-16-000020:notes:138]
[same as prior period, unchanged from 0000068505-15-000013:notes:130]

[0000068505-16-000020:notes:139]
|  | April 2, 2016 |  | December 31, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 60 |  |  | $ | 33 |  |  | $ | 60 |  |  | $ | 32 |  |
| Patents | 8 |  |  | 5 |  |  | 8 |  |  | 5 |  |
| Customer-related | 629 |  |  | 21 |  |  | 23 |  |  | 10 |  |
| Other intangibles | 46 |  |  | 15 |  |  | 20 |  |  | 15 |  |
|  | $ | 743 |  |  | $ | 74 |  |  | $ | 111 |  |  | $ | 62 |  |

[0000068505-16-000020:notes:140]
Amortization expense on intangible assets was $13 million for the three months ended April 2, 2016 and $2 million for the three months ended April 4, 2015. The increase in amortization expense is due to the acquisition of GDCL. As of April 2, 2016, annual amortization expense is estimated to be $87 million in 2016, $98 million in 2017 and 2018, $97 million in 2019, and $94 million in 2020 and 2021.

[0000068505-16-000020:notes:141]
[same as prior period, unchanged from 0000068505-15-000013:notes:133]

[0000068505-16-000020:notes:142]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2016 to April 2, 2016:

[0000068505-16-000020:notes:143]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2016 |  |  |  |  |  |
| Aggregate goodwill | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |
| Goodwill acquired | — |  |  | 170 |  |  | 170 |  |
| Balance as of April 2, 2016 |  |  |  |  |  |
| Aggregate goodwill | $ | 270 |  |  | $ | 320 |  |  | $ | 590 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 270 |  |  | $ | 320 |  |  | $ | 590 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-16-000020:notes:144]
[same as prior period, unchanged from 0000068505-15-000013:notes:140]

[0000068505-16-000020:notes:145]
At the end of each interim reporting period, the Company makes an estimate of its annual effective income tax rate. Tax expense in interim periods is calculated at the estimated annual effective tax rate plus or minus the tax effects of items of income and expense that are discrete to the period. The estimate used in providing for income taxes on a year-to-date basis may change in subsequent interim periods.

[0000068505-16-000020:notes:146]
[same as prior period, unchanged from 0000068505-15-000013:notes:142]

[0000068505-16-000020:notes:147]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Earnings from continuing operations before income taxes | $ | 22 |  |  | $ | 128 |  |
| Income tax expense | 5 |  |  | 40 |  |
| Effective tax rate | 23 | % |  | 31 | % |

[0000068505-16-000020:notes:148]
The Company recorded $5 million of net tax expense in the first quarter of 2016 resulting in an effective tax rate of 23%, compared to $40 million of net tax expense in the first quarter of 2015 resulting in an effective tax rate of 31%. The effective tax rate in the first quarter of 2016 was lower than the U.S. statutory tax rate of 35% primarily due to the recognition of excess tax benefits on share-based compensation in income tax expense as a result of the Company's adoption of ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." The rate was also positively impacted by the release of unrecognized tax benefit reserves, offset by increases in state valuation allowances and other adjustments to certain deferred tax assets. The effective tax rate in the first quarter of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the U.S. domestic production tax deduction and rate differential for foreign affiliates.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-16-000020:notes:149]
Recent Accounting Pronouncements

[0000068505-16-000020:notes:150]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017. In March 2016, the FASB issued ASU 2016-08, "Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net)" which clarifies the implementation guidance on principal versus agent considerations and includes indicators to assist an entity in determining whether it controls a specified good or service before it is transferred to the customers. ASU 2014-09 allows for both retrospective and modified retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-16-000020:notes:151]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU requires a modified retrospective method upon adoption. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0000068505-16-000020:notes:152]
In March 2016, the FASB issued ASU 2016-07, "Investments - Equity Method and Joint Ventures: Simplifying the Transition to the Equity Method of Accounting," which eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. ASU 2016-07 is effective for the Company January 1, 2017 and interim periods within that reporting period. The adoption of ASU 2016-07 is not expected to have a material effect on the Company’s consolidated financial statements.

[0000068505-16-000020:notes:153]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting,” which simplifies several aspects of the accounting for employee share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The Company has elected to adopt this accounting standard as of January 1, 2016. The impact of the prospective adoption of the provisions related to the recognition of excess tax benefits in income tax expense was a $2 million income tax benefit during the three months ended April 2, 2016. Additionally, as a result of the adoption of this accounting standard, excess tax benefits on share-based compensation have been reported as a component of operating cash rather than within financing cash flows as previously presented, while the payment of withholding taxes on the settlement of share-based awards has been reported as a component of financing cash flows rather than within operating cash flows as previously presented. The change in presentation of withholding taxes within the condensed consolidated statements of cash flows has been adopted retrospectively, thereby increasing operating cash flows and reducing financing cash flows by $9 million and $5 million for the three months ended April 2, 2016 and April 4, 2015. The presentation of excess tax benefits on share-based compensation has been adjusted prospectively within the condensed consolidated statement of cash flows, increasing operating cash flow and decreasing financing cash flow by $2 million for the three months ended April 2, 2016.

[0000068505-16-000020:notes:154]
In April 2015, the FASB issued ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. We have retrospectively adopted ASU 2015-03 effective January 1, 2016. As a result, debt issuance costs which were previously capitalized in other assets in the condensed consolidated balance sheet have been presented as a reduction to long-term debt. As of April 2, 2016 and December 31, 2015, $40 million and $41 million, respectively, have been presented as a component of long-term debt.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-16-000020:notes:155]
[same as prior period, unchanged from 0000068505-15-000013:notes:150]

[0000068505-16-000020:notes:156]
The condensed consolidated financial statements as of April 2, 2016 and for the three months ended April 2, 2016 and April 4, 2015 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-16-000020:notes:157]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2015. The results of operations for the three months ended April 2, 2016 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-16-000020:notes:158]
[same as prior period, unchanged from 0000068505-15-000013:notes:153]

[0000068505-16-000020:notes:159]
Recent Developments

[0000068505-16-000020:notes:160]
On February 19, 2016, the Company completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which the Company invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. The Company will make a deferred cash payment of £64 million on November 15, 2018. The Company funded the investment with a $675 million term loan (the “Term Loan”) and approximately $400 million of international cash on hand. The acquisition will be reported within our Services segment. It will enable the Company to geographically diversify its global Managed & Support services offerings within its Services segment, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. See discussion in Note 14.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-16-000020:notes:161]
[same as prior period, unchanged from 0000068505-15-000013:notes:154]

[0000068505-16-000020:notes:162]
[same as prior period, unchanged from 0000068505-15-000013:notes:155]

[0000068505-16-000020:notes:163]
[same as prior period, unchanged from 0000068505-15-000013:notes:156]

[0000068505-16-000020:notes:164]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | April 2, 2016 |  | April 4, 2015 |  | April 2, 2016 |  | April 4, 2015 |  | April 2, 2016 |  | April 4, 2015 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 46 |  |  | 49 |  |  | 14 |  |  | 16 |  |  | 1 |  |  | 2 |  |
| Expected return on plan assets | (55 | ) |  | (54 | ) |  | (24 | ) |  | (26 | ) |  | (2 | ) |  | (2 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 9 |  |  | 12 |  |  | 3 |  |  | 4 |  |  | 1 |  |  | 3 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (2 | ) |  | (5 | ) |  | (15 | ) |
| Net periodic cost (benefit) | $ | — |  |  | $ | 7 |  |  | $ | (5 | ) |  | $ | (5 | ) |  | $ | (5 | ) |  | $ | (12 | ) |

[0000068505-16-000020:notes:165]
Effective January 1, 2016, the Company changed the method used to estimate the interest and service cost components of net periodic cost for defined benefit pension and other post-retirement benefit plans. Historically, the interest and service cost components were estimated using a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. The Company has elected to use a full yield curve approach in the estimation of these components of net periodic cost by applying the specific spot rates along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows. The Company made this change to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. This change does not affect the measurement of total benefit obligations as the change in interest and service cost is completely offset in the actuarial loss reported in the period. The Company has concluded that this change is a change in estimate and, therefore, has accounted for it prospectively beginning January 1, 2016. Based on the change in estimate, the Company experienced no reduction in service costs and a $7 million reduction in interest costs for the three months ended April 2, 2016 compared to the prior approach. The overall reduction in the quarterly interest cost is comprised of $5 million related to the U.S. Pension Benefit Plans, $1 million related to the Postretirement Health Care Benefit Plans, and $1 million related to the Non U.S. Pension Benefits Plan.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-16-000020:notes:166]
[same as prior period, unchanged from 0000068505-15-000013:notes:162]

[0000068505-16-000020:notes:167]
2016 Charges

[0000068505-16-000020:notes:168]
During the three months ended April 2, 2016, the Company recorded net reorganization of business charges of $23 million including $7 million of charges in Other charges and $16 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $23 million were charges of: (i) $24 million for employee separation costs and (ii) $3 million for the impairment of the corporate aircraft, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-16-000020:notes:169]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2016 to April 2, 2016:

[0000068505-16-000020:notes:170]
|  | January 1, 2016 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | April 2, 2016 |
| Exit costs | $ | 9 |  |  | $ | — |  |  | $ | — |  |  | $ | (2 | ) |  | $ | 7 |  |
| Employee separation costs | 51 |  |  | 24 |  |  | (4 | ) |  | (21 | ) |  | 50 |  |
|  | $ | 60 |  |  | $ | 24 |  |  | $ | (4 | ) |  | $ | (23 | ) |  | $ | 57 |  |

[0000068505-16-000020:notes:171]
[same as prior period, unchanged from 0000068505-15-000013:notes:168]

[0000068505-16-000020:notes:172]
At January 1, 2016, the Company had $9 million of accruals for exit costs. During the three months ended April 2, 2016, there were no additional charges and $2 million of cash payments related to the exit of leased facilities. The remaining accrual of $7 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at April 2, 2016, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-16-000020:notes:173]
[same as prior period, unchanged from 0000068505-15-000013:notes:170]

[0000068505-16-000020:notes:174]
At January 1, 2016, the Company had an accrual of $51 million for employee separation costs. The 2016 additional charges of $24 million represent severance costs for approximately 250 employees. The adjustment of $4 million reflects  reversals for accruals no longer needed. The $21 million used reflects cash payments to severed employees. The remaining accrual of $50 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at April 2, 2016, is expected to be paid, primarily within one year, to approximately 400 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-16-000020:notes:175]
[same as prior period, unchanged from 0000068505-15-000013:notes:163]

[0000068505-16-000020:notes:176]
During the three months ended April 4, 2015, the Company recorded net reorganization of business charges of $14 million, including $12 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the aggregate $14 million were charges of $10 million related to employee separation costs and $4 million related to exit costs.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-16-000020:notes:177]
[same as prior period, unchanged from 0000068505-15-000013:notes:175]

[0000068505-16-000020:notes:178]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Products | $ | 702 |  |  | $ | 758 |  |
| Services | 491 |  |  | 465 |  |
|  | $ | 1,193 |  |  | $ | 1,223 |  |

[0000068505-16-000020:notes:179]
[same as prior period, unchanged from 0000068505-15-000013:notes:177]

[0000068505-16-000020:notes:180]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Products | $ | 51 |  |  | $ | 64 |  |
| Services | 49 |  |  | 55 |  |
| Operating earnings | 100 |  |  | 119 |  |
| Total other income (expense) | (78 | ) |  | 9 |  |
| Earnings from continuing operations before income taxes | $ | 22 |  |  | $ | 128 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-16-000020:notes:181]
[same as prior period, unchanged from 0000068505-15-000013:notes:179]

[0000068505-16-000020:notes:182]
[same as prior period, unchanged from 0000068505-15-000013:notes:180]

[0000068505-16-000020:notes:183]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce.

[0000068505-16-000020:notes:184]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers.
