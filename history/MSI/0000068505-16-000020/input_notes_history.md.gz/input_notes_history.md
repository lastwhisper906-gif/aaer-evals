# MSI note change history — 0000068505-15-000013 → 0000068505-16-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-05-06):
[0000068505-16-000020:note_history:1]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

- changed (2016-05-06):
[0000068505-16-000020:note_history:2]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at April 2, 2016.
  (was, 2015-11-04, similarity 0.99):
[0000068505-15-000013:note_history:2]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at October 3, 2015.

- removed (2016-05-06):
[0000068505-15-000013:note_history:3]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s condensed consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company’s: (i) results of operations in the periods in which an adverse outcome becomes both probable and estimable or (ii) financial position or liquidity in the periods in which the matters are ultimately resolved.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0000068505-16-000020:note_history:4]
The condensed consolidated financial statements as of April 2, 2016 and for the three months ended April 2, 2016 and April 4, 2015 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2015-11-04, similarity 0.9325):
[0000068505-15-000013:note_history:4]
The condensed consolidated financial statements as of October 3, 2015 and for the three and nine months ended October 3, 2015 and September 27, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2016-05-06):
[0000068505-16-000020:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2015. The results of operations for the three months ended April 2, 2016 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2015-11-04, similarity 0.959):
[0000068505-15-000013:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three and nine months ended October 3, 2015 are not necessarily indicative of the operating results to be expected for the full year.

- added (2016-05-06):
[0000068505-16-000020:note_history:6]
Recent Developments

- added (2016-05-06):
[0000068505-16-000020:note_history:7]
On February 19, 2016, the Company completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which the Company invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. The Company will make a deferred cash payment of £64 million on November 15, 2018. The Company funded the investment with a $675 million term loan (the “Term Loan”) and approximately $400 million of international cash on hand. The acquisition will be reported within our Services segment. It will enable the Company to geographically diversify its global Managed & Support services offerings within its Services segment, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. See discussion in Note 14.

- changed (2016-05-06):
[0000068505-16-000020:note_history:8]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017. In March 2016, the FASB issued ASU 2016-08, "Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net)" which clarifies the implementation guidance on principal versus agent considerations and includes indicators to assist an entity in determining whether it controls a specified good or service before it is transferred to the customers. ASU 2014-09 allows for both retrospective and modified retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.
  (was, 2015-11-04, similarity 0.6581):
[0000068505-15-000013:note_history:8]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers: Deferral of the Effective Date that delayed the effective date of ASU 2014-09 by one year to January 1, 2018 as the Company’s annual reporting period begins after December 15, 2017. ASU 2014-09 allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

- added (2016-05-06):
[0000068505-16-000020:note_history:9]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU requires a modified retrospective method upon adoption. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

- added (2016-05-06):
[0000068505-16-000020:note_history:10]
In March 2016, the FASB issued ASU 2016-07, "Investments - Equity Method and Joint Ventures: Simplifying the Transition to the Equity Method of Accounting," which eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. ASU 2016-07 is effective for the Company January 1, 2017 and interim periods within that reporting period. The adoption of ASU 2016-07 is not expected to have a material effect on the Company’s consolidated financial statements.

- added (2016-05-06):
[0000068505-16-000020:note_history:11]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting,” which simplifies several aspects of the accounting for employee share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The Company has elected to adopt this accounting standard as of January 1, 2016. The impact of the prospective adoption of the provisions related to the recognition of excess tax benefits in income tax expense was a $2 million income tax benefit during the three months ended April 2, 2016. Additionally, as a result of the adoption of this accounting standard, excess tax benefits on share-based compensation have been reported as a component of operating cash rather than within financing cash flows as previously presented, while the payment of withholding taxes on the settlement of share-based awards has been reported as a component of financing cash flows rather than within operating cash flows as previously presented. The change in presentation of withholding taxes within the condensed consolidated statements of cash flows has been adopted retrospectively, thereby increasing operating cash flows and reducing financing cash flows by $9 million and $5 million for the three months ended April 2, 2016 and April 4, 2015. The presentation of excess tax benefits on share-based compensation has been adjusted prospectively within the condensed consolidated statement of cash flows, increasing operating cash flow and decreasing financing cash flow by $2 million for the three months ended April 2, 2016.

- added (2016-05-06):
[0000068505-16-000020:note_history:12]
In April 2015, the FASB issued ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. We have retrospectively adopted ASU 2015-03 effective January 1, 2016. As a result, debt issuance costs which were previously capitalized in other assets in the condensed consolidated balance sheet have been presented as a reduction to long-term debt. As of April 2, 2016 and December 31, 2015, $40 million and $41 million, respectively, have been presented as a component of long-term debt.

- removed (2016-05-06):
[0000068505-15-000013:note_history:13]
In April 2015, the FASB issued ASU No. 2015-03, Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, the Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of October 3, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $44 million.

- removed (2016-05-06):
[0000068505-15-000013:note_history:14]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 340): Simplifying the Measurement of Inventory. Under this guidance, entities utilizing the FIFO or average cost method should measure inventory at the lower of cost or net realizable value, where net realizable value is defined as the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This ASU should be applied prospectively and will be effective for the Company beginning January 1, 2017 with early adoption permitted. The Company does not expect this ASU will have a material impact on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0000068505-16-000020:note_history:15]
As of April 2, 2016, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 2, 2016. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the three months ended April 2, 2016.
  (was, 2015-11-04, similarity 0.912):
[0000068505-15-000013:note_history:15]
As of October 3, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 3, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the nine months ended October 3, 2015.

- changed (2016-05-06):
[0000068505-16-000020:note_history:16]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.
  (was, 2015-11-04, similarity 0.9722):
[0000068505-15-000013:note_history:16]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

- added (2016-05-06):
[0000068505-16-000020:note_history:17]
In connection with the completion of the acquisition of GDCL, the Company entered into a new term loan credit agreement (the “Term Loan Agreement”), under which the Company borrowed a Term Loan with an initial principal amount of $675 million and a maturity date of February 18, 2019. Interest on the Term Loan is variable and indexed to LIBOR. The interest expense on the Term Loan is payable semi-annually in May and November. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed. The Company's borrowing capacity under the 2014 Motorola Solutions Credit Agreement may be partially limited during the second quarter of 2016 due to the additional indebtedness incurred in connection with the Term Loan.

- added (2016-05-06):
[0000068505-16-000020:note_history:18]
Effective January 1, 2016, the Company retrospectively adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, we have revised the presentation of debt issuance costs which were previously capitalized in other assets in the consolidated balance sheet to be presented as a reduction to long-term debt. As of April 2, 2016 and December 31, 2015, $40 million and $41 million, respectively, have been reclassified to be presented as a component of long-term debt.
