# MSI 8-K — 0001193125-16-579931 filed 2016-05-05

## item codes, every 8-K on or before 2016-05-06

- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2016-05-06

- none on or before 2016-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-579931:8k_2_02:1]
EX-99.1
2
d193384dex991.htm
EX-99.1

[0001193125-16-579931:8k_2_02:2]
EX-99.1

[0001193125-16-579931:8k_2_02:3]
Exhibit 99.1

[0001193125-16-579931:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2016 Financial Results

[0001193125-16-579931:8k_2_02:5]
|  | • |  | Sales of $1.2 billion, down 2 percent from a year ago, including $22 million of unfavorable foreign currency impact and $61 million in revenues associated with the Airwave acquisition |

[0001193125-16-579931:8k_2_02:6]
|  | • |  | North America sales grew 2 percent, driven by both Products and Services segment sales |

[0001193125-16-579931:8k_2_02:7]
|  | • |  | Managed & Support services grew 30 percent, or 6 percent excluding Airwave |

[0001193125-16-579931:8k_2_02:8]
|  | • |  | Backlog ended at $8.3 billion, an increase of 43 percent, driven by Airwave and Managed & Support services growth |

[0001193125-16-579931:8k_2_02:9]
|  | • |  | GAAP earnings per share (EPS) from continuing operations1 of $0.10 |

[0001193125-16-579931:8k_2_02:10]
|  | • |  | Non-GAAP EPS from continuing operations* of $0.52, up 37 percent |

[0001193125-16-579931:8k_2_02:11]
SCHAUMBURG, III. – May 5,
2016 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2016. Click here for a printable news release and financial tables.

[0001193125-16-579931:8k_2_02:12]
SUPPORTING QUOTE

[0001193125-16-579931:8k_2_02:13]
“We delivered strong earnings
growth in the first quarter driven by our North America business and Managed & Support services,” said Greg Brown, chairman and CEO of Motorola Solutions. “We’re encouraged by the progress in our services business and overall
backlog, which positions us well for continued earnings and cash flow growth.”

[0001193125-16-579931:8k_2_02:14]
KEY FINANCIAL RESULTS (presented in millions, except per share
data and percentages)

[0001193125-16-579931:8k_2_02:15]
|  |  | Q1 2016 |  |  | Q1 2015 |  |  | % Change |  |
| Sales |  | $ | 1,193 |  |  | $ | 1,223 |  |  |  | (2 | )% |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 100 |  |  | $ | 119 |  |  |  | (16 | )% |
| % of Sales |  |  | 8.4 | % |  |  | 9.7 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.10 |  |  | $ | 0.40 |  |  |  | (75 | )% |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 166 |  |  | $ | 156 |  |  |  | 6 | % |
| % of Sales |  |  | 13.9 | % |  |  | 12.8 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.52 |  |  | $ | 0.38 |  |  |  | 37 | % |
| Product Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 702 |  |  | $ | 758 |  |  |  | (7 | )% |
| GAAP Operating Earnings |  | $ | 51 |  |  | $ | 64 |  |  |  | (20 | )% |
| % of Sales |  |  | 7.3 | % |  |  | 8.4 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 84 |  |  | $ | 90 |  |  |  | (7 | )% |
| % of Sales |  |  | 12.0 | % |  |  | 11.9 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 491 |  |  | $ | 465 |  |  |  | 6 | % |
| GAAP Operating Earnings |  | $ | 49 |  |  | $ | 55 |  |  |  | (11 | )% |
| % of Sales |  |  | 10.0 | % |  |  | 11.8 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 82 |  |  | $ | 66 |  |  |  | 24 | % |
| % of Sales |  |  | 16.7 | % |  |  | 14.2 | % |  |  |  |  |

[0001193125-16-579931:8k_2_02:16]
| * | Non-GAAP financial information excludes the after-tax impact of approximately $0.42 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release. |

[0001193125-16-579931:8k_2_02:17]
OTHER SELECTED FINANCIAL RESULTS

[0001193125-16-579931:8k_2_02:18]
|  | • |  | Revenue – Sales decreased 2 percent, including $22 million of unfavorable foreign currency impact and $61 million in sales associated with the Airwave acquisition. These results include 2 percent growth in North America, which delivered increases in both Products and Services sales. Overall company product sales declined due to weakness in Latin America and Europe as well as currency headwinds. The Services business increased 6 percent due to the addition of Airwave and solid growth in organic Managed & Support results. The Services business declined 8 percent excluding the impact of Airwave, due primarily to currency headwinds and a decline in systems integration revenues associated with a large project in Europe. |

[0001193125-16-579931:8k_2_02:19]
|  | • |  | Operating margin – GAAP operating margin was 8.4 percent of sales in the first quarter of 2016, compared with 9.7 percent in the first quarter of 2015; non-GAAP operating margin was 13.9 percent of sales, compared with 12.8 percent in the first quarter of 2015, reflecting $43 million in lower operating expenses compared with the first quarter of 2015, due to the company’s cost reduction initiatives and a stronger dollar. |

[0001193125-16-579931:8k_2_02:20]
|  | • |  | Taxes – The first quarter of 2016 GAAP effective tax rate was 23 percent. This compares with a tax rate of 31 percent in the first quarter of 2015. The first quarter of 2016 non-GAAP tax rate was 26 percent, compared with a tax rate of 29 percent in the first quarter of 2015. The full-year non-GAAP tax rate is expected to be approximately 33 percent. |

[0001193125-16-579931:8k_2_02:21]
|  | • |  | Cash flow – The company generated $13 million in operating cash from continuing operations during the quarter, reflecting a decrease of $143 million over the prior year. Free cash flow2 was a use of $38 million in the quarter. The decrease was largely driven by incentive costs and higher tax payments during the quarter. |

[0001193125-16-579931:8k_2_02:22]
|  | • |  | Cash and cash equivalents – The company ended the quarter with cash and cash equivalents of $1.9 billion and a net debt position of approximately $3.1 billion3. The company repurchased approximately $64 million of its common stock in the first quarter of 2016 and paid approximately $71 million in cash dividends. |

[0001193125-16-579931:8k_2_02:23]
KEY HIGHLIGHTS

[0001193125-16-579931:8k_2_02:24]
|  | • |  | Significant win in the United Kingdom to provide interoperability between the nationwide land-mobile radio (LMR) network and new public safety long-term evolution (LTE) network with Motorola’s WAVE 7000 solution |

[0001193125-16-579931:8k_2_02:25]
|  | • |  | $77 million with five U.S. state and local customers to upgrade their mission-critical communication networks to Motorola’s latest P25 solution |

[0001193125-16-579931:8k_2_02:26]
|  | • |  | $25 million in North Africa for next-generation DMR MOTOTRBO trunking solution |

[0001193125-16-579931:8k_2_02:27]
|  | • |  | $20 million with a U.S. utility customer for a multi-year Managed & Support services contract |

[0001193125-16-579931:8k_2_02:28]
|  | • |  | Continued wins and expansion of the Emergency CallWorks Next Gen 9-1-1 solution that now has deployments in more than half of the U.S. states |

[0001193125-16-579931:8k_2_02:29]
BUSINESS OUTLOOK

[0001193125-16-579931:8k_2_02:30]
|  | • |  | Second quarter 2016 – Motorola Solutions expects a revenue increase of 1 to 3 percent compared with the second quarter of 2015. This assumes approximately $130 million in revenues associated with the Airwave acquisition. The company expects non-GAAP earnings per share from continuing operations in the range of $0.82 to $0.88 per share. |

[0001193125-16-579931:8k_2_02:31]
|  | • |  | Full-year 2016 – The company reaffirms its full-year outlook for revenue growth of 5 to 7 percent compared to 2015. This revenue outlook includes approximately $450 million in revenues associated with the Airwave acquisition. The company expects non-GAAP earnings per share from continuing operations in the range of $4.45 to $4.65 per share. |

[0001193125-16-579931:8k_2_02:32]
CONFERENCE CALL AND WEBCAST

[0001193125-16-579931:8k_2_02:33]
Motorola Solutions will host
its quarterly conference call beginning at 4 p.m. U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, May 5. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-16-579931:8k_2_02:34]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0001193125-16-579931:8k_2_02:35]
A comparison of results from operations is as follows:

[0001193125-16-579931:8k_2_02:36]
|  |  | Q1 2016 |  |  | Q1 2015 |  |
| Net sales |  | $ | 1,193 |  |  | $ | 1,223 |  |
| Gross margin |  |  | 502 |  |  |  | 548 |  |
| Operating earnings |  |  | 100 |  |  |  | 119 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  |  | 17 |  |  |  | 87 |  |
| Net earnings |  |  | 17 |  |  |  | 74 |  |
| Diluted EPS from continuing operations |  | $ | 0.10 |  |  | $ | 0.40 |  |
| Weighted average diluted common shares outstanding |  |  | 177.0 |  |  |  | 217.8 |  |

[0001193125-16-579931:8k_2_02:37]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-16-579931:8k_2_02:38]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the first quarter of 2016.

[0001193125-16-579931:8k_2_02:39]
| (per diluted common share) |  | Q1 2016 |  |
| GAAP Earnings from Continuing Operations |  | $ | 0.10 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  |  | 0.06 |  |
| Reorganization of business charges |  |  | 0.08 |  |
| Intangibles amortization expense |  |  | 0.06 |  |
| Acquisition related transaction fees |  |  | 0.07 |  |
| Loss on investment in United Kingdom treasuries |  |  | 0.07 |  |
| Realized foreign currency loss on acquisition |  |  | 0.04 |  |
| Loss on sale of Malaysia facility and operations |  |  | 0.04 |  |
| Total Highlighted Items |  |  | 0.42 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 0.52 |  |

[0001193125-16-579931:8k_2_02:40]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-16-579931:8k_2_02:41]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in
addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-16-579931:8k_2_02:42]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of highlighted items recorded in prior periods) from
its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s
current operating performance or comparisons to the company’s past operating performance.

[0001193125-16-579931:8k_2_02:43]
Share-based compensation expense: The company has excluded share-based compensation expense from its
non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods
presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense.
Share-based compensation expense will recur in future periods.

[0001193125-16-579931:8k_2_02:44]
Intangible assets amortization expense: The company has excluded intangible
assets amortization expense from its Non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense.
Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the
company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-16-579931:8k_2_02:45]
Constant Currency: The company evaluates its results of operations on both an as reported and a constant currency basis. The constant currency
presentation, which is a non-GAAP measure, excludes the impact of fluctuations in foreign currency exchange rates. The company calculates constant currency percentages by converting the current period local currency results using prior-period
exchange rates, and then comparing these adjusted values to prior-period reported results.

[0001193125-16-579931:8k_2_02:46]
Details of the above items and reconciliations of the
non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0001193125-16-579931:8k_2_02:47]
BUSINESS RISKS

[0001193125-16-579931:8k_2_02:48]
markets on acceptable terms and conditions; (6) the impact of a security breach or other significant disruption in the company’s IT systems, those of its partners or suppliers or those
it sells to or operate or maintain for its customers; (7) the outcome of ongoing and future tax matters; (8) the company’s ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light
of global economic conditions and reductions in the company’s purchasing power; (9) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (10) the impact on the
company’s performance and financial results from strategic acquisitions or divestitures, including the acquisition of Airwave; (11) risks related to the company’s manufacturing and business operations in foreign countries;
(12) the creditworthiness of the company’s customers and distributors, particularly purchasers of large infrastructure systems; (13) exposure under large systems and managed services contracts, including risks related to the fact that
certain customers require that the company build, own and operate their systems, often over a multi-year period; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility
Holdings, Inc.; (15) variability in income received from licensing the company’s intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or
expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the
company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to repurchase shares under its repurchase program due to possible adverse market
conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company’s outsourcing of various activities, including
certain manufacturing operations, information technology and administrative functions; (22) the impact of the sale of the company’s legacy information systems, including components of the enterprise resource planning (ERP) system and the
implementation of a new ERP system; and (23) the company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk
factor, whether as a result of new information, future events or otherwise.

[0001193125-16-579931:8k_2_02:49]
DEFINITIONS

[0001193125-16-579931:8k_2_02:50]
| 1 | Amounts attributable to Motorola Solutions, Inc. common shareholders. |

[0001193125-16-579931:8k_2_02:51]
| 2 | Free cash flow represents operating cash flow less capex |

[0001193125-16-579931:8k_2_02:52]
| 3 | Net debt represents cash and cash equivalents less long-term debt, including current portion |

[0001193125-16-579931:8k_2_02:53]
ABOUT
MOTOROLA SOLUTIONS

[0001193125-16-579931:8k_2_02:54]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety
and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0001193125-16-579931:8k_2_02:55]
MEDIA CONTACT

[0001193125-16-579931:8k_2_02:56]
Tama McWhinney

[0001193125-16-579931:8k_2_02:57]
Motorola Solutions

[0001193125-16-579931:8k_2_02:58]
+1 847-538-1865

[0001193125-16-579931:8k_2_02:59]
tama.mcwhinney@motorolasolutions.com

[0001193125-16-579931:8k_2_02:60]
INVESTOR
CONTACTS

[0001193125-16-579931:8k_2_02:61]
Shep Dunlap

[0001193125-16-579931:8k_2_02:62]
Motorola Solutions

[0001193125-16-579931:8k_2_02:63]
+1 847-576-6899

[0001193125-16-579931:8k_2_02:64]
shep.dunlap@motorolasolutions.com

[0001193125-16-579931:8k_2_02:65]
Chris Kutsor

[0001193125-16-579931:8k_2_02:66]
Motorola Solutions

[0001193125-16-579931:8k_2_02:67]
+1 847-576-4995

[0001193125-16-579931:8k_2_02:68]
chris.kutsor@motorolasolutions.com

[0001193125-16-579931:8k_2_02:69]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola
Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2016 Motorola Solutions, Inc. All rights reserved.

[0001193125-16-579931:8k_2_02:70]
GAAP-1

[0001193125-16-579931:8k_2_02:71]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-579931:8k_2_02:72]
Condensed Consolidated Statements of Operations

[0001193125-16-579931:8k_2_02:73]
(In millions, except per share amounts)

[0001193125-16-579931:8k_2_02:74]
|  |  | Three Months Ended |  |
|  |  | April 2, 2016 |  |  | April 4, 2015 |  |
| Net sales from products |  | $ | 702 |  |  | $ | 758 |  |
| Net sales from services |  |  | 491 |  |  |  | 465 |  |
| Net sales |  |  | 1,193 |  |  |  | 1,223 |  |
| Costs of products sales |  |  | 366 |  |  |  | 359 |  |
| Costs of services sales |  |  | 325 |  |  |  | 316 |  |
| Costs of sales |  |  | 691 |  |  |  | 675 |  |
| Gross margin |  |  | 502 |  |  |  | 548 |  |
| Selling, general and administrative expenses |  |  | 234 |  |  |  | 256 |  |
| Research and development expenditures |  |  | 135 |  |  |  | 159 |  |
| Other charges |  |  | 20 |  |  |  | 12 |  |
| Intangibles amortization |  |  | 13 |  |  |  | 2 |  |
| Operating earnings |  |  | 100 |  |  |  | 119 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (49 | ) |  |  | (40 | ) |
| Gains (losses) on sales of investments and businesses, net |  |  | (21 | ) |  |  | 46 |  |
| Other |  |  | (8 | ) |  |  | 3 |  |
| Total other income (expense) |  |  | (78 | ) |  |  | 9 |  |
| Earnings from continuing operations before income taxes |  |  | 22 |  |  |  | 128 |  |
| Income tax expense |  |  | 5 |  |  |  | 40 |  |
| Earnings from continuing operations |  |  | 17 |  |  |  | 88 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (13 | ) |
| Net earnings |  |  | 17 |  |  |  | 75 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | — |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 17 |  |  | $ | 74 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 17 |  |  | $ | 87 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (13 | ) |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 17 |  |  | $ | 74 |  |
| Earnings (loss) per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.10 |  |  | $ | 0.40 |  |
| Discontinued operations |  |  | — |  |  |  | (0.06 | ) |
|  |  | $ | 0.10 |  |  | $ | 0.34 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.10 |  |  | $ | 0.40 |  |
| Discontinued operations |  |  | — |  |  |  | (0.06 | ) |
|  |  | $ | 0.10 |  |  | $ | 0.34 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 174.5 |  |  |  | 215.3 |  |
| Diluted |  |  | 177.0 |  |  |  | 217.8 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 58.8 | % |  |  | 62.0 | % |
| Net sales from services |  |  | 41.2 | % |  |  | 38.0 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 52.1 | % |  |  | 47.4 | % |
| Costs of services sales |  |  | 66.2 | % |  |  | 68.0 | % |
| Costs of sales |  |  | 57.9 | % |  |  | 55.2 | % |
| Gross margin |  |  | 42.1 | % |  |  | 44.8 | % |
| Selling, general and administrative expenses |  |  | 19.6 | % |  |  | 20.9 | % |
| Research and development expenditures |  |  | 11.3 | % |  |  | 13.0 | % |
| Other charges |  |  | 1.7 | % |  |  | 1.0 | % |
| Intangibles amortization |  |  | 1.1 | % |  |  | 0.2 | % |
| Operating earnings |  |  | 8.4 | % |  |  | 9.7 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (4.1 | )% |  |  | (3.3 | )% |
| Gains (losses) on sales of investments and businesses, net |  |  | (1.8 | )% |  |  | 3.8 | % |
| Other |  |  | (0.7 | )% |  |  | 0.2 | % |
| Total other income (expense) |  |  | (6.5 | )% |  |  | 0.7 | % |
| Earnings from continuing operations before income taxes |  |  | 1.8 | % |  |  | 10.5 | % |
| Income tax expense |  |  | 0.4 | % |  |  | 3.3 | % |
| Earnings from continuing operations |  |  | 1.4 | % |  |  | 7.2 | % |
| Loss from discontinued operations, net of tax |  |  | — | % |  |  | (1.1 | )% |
| Net earnings |  |  | 1.4 | % |  |  | 6.1 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | — | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 1.4 | % |  |  | 6.1 | % |

[0001193125-16-579931:8k_2_02:75]
| * | Percentages may not add up due to rounding |

[0001193125-16-579931:8k_2_02:76]
GAAP-2

[0001193125-16-579931:8k_2_02:77]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-579931:8k_2_02:78]
Condensed Consolidated Balance Sheets

[0001193125-16-579931:8k_2_02:79]
(In millions)

[0001193125-16-579931:8k_2_02:80]
|  |  | April 2, 2016 |  |  | December 31, 2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,940 |  |  | $ | 1,980 |  |
| Accounts receivable, net |  |  | 1,148 |  |  |  | 1,362 |  |
| Inventories, net |  |  | 287 |  |  |  | 296 |  |
| Other current assets |  |  | 626 |  |  |  | 954 |  |
| Current assets held for disposition |  |  | — |  |  |  | 27 |  |
| Total current assets |  |  | 4,001 |  |  |  | 4,619 |  |
| Property, plant and equipment, net |  |  | 997 |  |  |  | 487 |  |
| Investments |  |  | 228 |  |  |  | 231 |  |
| Deferred income taxes |  |  | 2,330 |  |  |  | 2,278 |  |
| Goodwill |  |  | 590 |  |  |  | 420 |  |
| Other assets |  |  | 884 |  |  |  | 271 |  |
| Non-current assets held for disposition |  |  | 19 |  |  |  | 40 |  |
| Total assets |  | $ | 9,049 |  |  | $ | 8,346 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 4 |  |  | $ | 4 |  |
| Accounts payable |  |  | 424 |  |  |  | 518 |  |
| Accrued liabilities |  |  | 1,604 |  |  |  | 1,671 |  |
| Total current liabilities |  |  | 2,032 |  |  |  | 2,193 |  |
| Long-term debt |  |  | 5,023 |  |  |  | 4,345 |  |
| Other liabilities |  |  | 2,131 |  |  |  | 1,904 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  |  | (147 | ) |  |  | (106 | ) |
| Noncontrolling interests |  |  | 10 |  |  |  | 10 |  |
| Total liabilities and stockholders’ equity |  | $ | 9,049 |  |  | $ | 8,346 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (3,087 | ) |  | $ | (2,369 | ) |

[0001193125-16-579931:8k_2_02:81]
| * | Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-16-579931:8k_2_02:82]
GAAP-3

[0001193125-16-579931:8k_2_02:83]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-579931:8k_2_02:84]
Condensed Consolidated Statements of Cash Flows

[0001193125-16-579931:8k_2_02:85]
(In millions)

[0001193125-16-579931:8k_2_02:86]
|  |  | Three Months Ended |  |
|  |  | April 2, 2016 |  |  | April 4, 2015 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 17 |  |  | $ | 74 |  |
| Earnings attributable to noncontrolling interests |  |  | — |  |  |  | 1 |  |
| Net earnings |  |  | 17 |  |  |  | 75 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (13 | ) |
| Earnings from continuing operations, net of tax |  |  | 17 |  |  |  | 88 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities from continuing operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 62 |  |  |  | 41 |  |
| Non-cash other charges |  |  | 11 |  |  |  | 1 |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 21 |  |
| Losses (gains) on sales of investments and businesses, net |  |  | 21 |  |  |  | (46 | ) |
| Deferred income taxes |  |  | 35 |  |  |  | 23 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 277 |  |  |  | 309 |  |
| Inventories |  |  | (4 | ) |  |  | (44 | ) |
| Other current assets |  |  | (43 | ) |  |  | 26 |  |
| Accounts payable and accrued liabilities |  |  | (363 | ) |  |  | (247 | ) |
| Other assets and liabilities |  |  | (17 | ) |  |  | (16 | ) |
| Net cash provided by operating activities from continuing operations |  |  | 13 |  |  |  | 156 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (1,053 | ) |  |  | (74 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 481 |  |  |  | 88 |  |
| Capital expenditures |  |  | (51 | ) |  |  | (33 | ) |
| Proceeds from sales of property, plant and equipment |  |  | — |  |  |  | 1 |  |
| Net cash used for investing activities from continuing operations |  |  | (623 | ) |  |  | (18 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (1 | ) |  |  | (1 | ) |
| Net proceeds from issuance of debt |  |  | 673 |  |  |  | — |  |
| Issuance of common stock |  |  | 40 |  |  |  | 41 |  |
| Purchase of common stock |  |  | (64 | ) |  |  | (653 | ) |
| Excess tax benefit from share-based compensation |  |  | — |  |  |  | 1 |  |
| Payment of dividends |  |  | (71 | ) |  |  | (75 | ) |
| Net cash provided by (used for) financing activities from continuing operations |  |  | 577 |  |  |  | (687 | ) |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (7 | ) |  |  | (52 | ) |
| Net decrease in cash and cash equivalents |  |  | (40 | ) |  |  | (601 | ) |
| Cash and cash equivalents, beginning of period |  |  | 1,980 |  |  |  | 3,954 |  |
| Cash and cash equivalents, end of period |  | $ | 1,940 |  |  | $ | 3,353 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | (38 | ) |  | $ | 123 |  |

[0001193125-16-579931:8k_2_02:87]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-16-579931:8k_2_02:88]
GAAP-4

[0001193125-16-579931:8k_2_02:89]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-579931:8k_2_02:90]
Segment Information

[0001193125-16-579931:8k_2_02:91]
(In millions)

[0001193125-16-579931:8k_2_02:92]
| Net Sales |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 2, 2016 |  |  | April 4, 2015 |  |  | % Change |  |
| Products |  | $ | 702 |  |  | $ | 758 |  |  |  | (7 | )% |
| Services |  |  | 491 |  |  |  | 465 |  |  |  | 6 | % |
| Total Motorola Solutions |  | $ | 1,193 |  |  | $ | 1,223 |  |  |  | (2 | )% |
| Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 2, 2016 |  |  | April 4, 2015 |  |  | % Change |  |
| Products |  | $ | 51 |  |  | $ | 64 |  |  |  | (20 | )% |
| Services |  |  | 49 |  |  |  | 55 |  |  |  | (11 | )% |
| Total Motorola Solutions |  | $ | 100 |  |  | $ | 119 |  |  |  | (16 | )% |
| Operating Earnings % |  |  |  |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 2, 2016 |  |  | April 4, 2015 |  |  |  |  |
| Products |  |  | 7.3 | % |  |  | 8.4 | % |  |  |  |  |
| Services |  |  | 10.0 | % |  |  | 11.8 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 8.4 | % |  |  | 9.7 | % |  |  |  |  |

[0001193125-16-579931:8k_2_02:93]
GAAP-5

[0001193125-16-579931:8k_2_02:94]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-579931:8k_2_02:95]
Regional Revenue Information

[0001193125-16-579931:8k_2_02:96]
(In millions)

[0001193125-16-579931:8k_2_02:97]
During the first quarter
of 2016, we restructured our regions operationally combining the Europe and Africa and Middle East regions into one region which is now reflected as Europe, Middle East, and Africa (“EMEA”). Accordingly, we now report net sales in the
following four geographic regions: North America, Latin America, EMEA, and Asia Pacific (“AP”). We have updated all periods presented to reflect this change in presentation.

[0001193125-16-579931:8k_2_02:98]
The Company’s regional net sales under the new regional alignment and as previously reported were as follows:

[0001193125-16-579931:8k_2_02:99]
|  |  | Revised regional sales |  |
|  |  | Q12015 |  |  | Q22015 |  |  | Q32015 |  |  | Q42015 |  |  | FY2015 |  |  | FY2014 |  |  | FY2013 |  |
| North America |  |  | 770 |  |  |  | 883 |  |  |  | 922 |  |  |  | 1,138 |  |  |  | 3,713 |  |  |  | 3,599 |  |  |  | 3,894 |  |
| Latin America |  |  | 96 |  |  |  | 95 |  |  |  | 85 |  |  |  | 82 |  |  |  | 358 |  |  |  | 508 |  |  |  | 518 |  |
| EMEA |  |  | 223 |  |  |  | 227 |  |  |  | 244 |  |  |  | 280 |  |  |  | 974 |  |  |  | 1,129 |  |  |  | 1,066 |  |
| AP |  |  | 134 |  |  |  | 163 |  |  |  | 171 |  |  |  | 182 |  |  |  | 650 |  |  |  | 645 |  |  |  | 749 |  |
|  |  | $ | 1,223 |  |  | $ | 1,368 |  |  | $ | 1,422 |  |  | $ | 1,682 |  |  | $ | 5,695 |  |  | $ | 5,881 |  |  | $ | 6,227 |  |
|  |  | Regional sales as previously reported |  |
|  |  | Q12015 |  |  | Q22015 |  |  | Q32015 |  |  | Q42015 |  |  | FY2015 |  |  | FY2014 |  |  | FY2013 |  |
| North America |  |  | 770 |  |  |  | 883 |  |  |  | 922 |  |  |  | 1,138 |  |  |  | 3,713 |  |  |  | 3,599 |  |  |  | 3,894 |  |
| Latin America |  |  | 96 |  |  |  | 95 |  |  |  | 85 |  |  |  | 82 |  |  |  | 358 |  |  |  | 508 |  |  |  | 518 |  |
| EA |  |  | 192 |  |  |  | 197 |  |  |  | 213 |  |  |  | 247 |  |  |  | 849 |  |  |  | 1,034 |  |  |  | 988 |  |
| AP |  |  | 134 |  |  |  | 163 |  |  |  | 171 |  |  |  | 182 |  |  |  | 650 |  |  |  | 645 |  |  |  | 749 |  |
| ME |  |  | 31 |  |  |  | 30 |  |  |  | 31 |  |  |  | 33 |  |  |  | 125 |  |  |  | 95 |  |  |  | 78 |  |
|  |  | $ | 1,223 |  |  | $ | 1,368 |  |  | $ | 1,422 |  |  | $ | 1,682 |  |  | $ | 5,695 |  |  | $ | 5,881 |  |  | $ | 6,227 |  |

[0001193125-16-579931:8k_2_02:100]
Non-GAAP-1

[0001193125-16-579931:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-579931:8k_2_02:102]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and Highlighted Items)

[0001193125-16-579931:8k_2_02:103]
| Q1 2016 |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  |  | 6 |  |  | $ | 11 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 23 |  |  |  | 8 |  |  |  | 15 |  |  |  | 0.08 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 13 |  |  |  | 3 |  |  |  | 10 |  |  |  | 0.06 |  |
| Acquisition related transaction fees |  | Other charges |  |  | 13 |  |  |  | — |  |  |  | 13 |  |  |  | 0.07 |  |
| Loss on investment in United Kingdom treasuries |  | Other expense (income) |  |  | 19 |  |  |  | 7 |  |  |  | 12 |  |  |  | 0.07 |  |
| Realized foreign currency loss on acquisition |  | Other expense (income) |  |  | 10 |  |  |  | 3 |  |  |  | 7 |  |  |  | 0.04 |  |
| Loss on sale of Malaysia facility and operations |  | Other expense (income) |  |  | 7 |  |  |  | — |  |  |  | 7 |  |  |  | 0.04 |  |
| Total impact on Net earnings |  |  |  | $ | 102 |  |  | $ | 27 |  |  | $ | 75 |  |  | $ | 0.42 |  |

[0001193125-16-579931:8k_2_02:104]
Non-GAAP-2

[0001193125-16-579931:8k_2_02:105]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-579931:8k_2_02:106]
Non-GAAP Segment Information

[0001193125-16-579931:8k_2_02:107]
(In millions)

[0001193125-16-579931:8k_2_02:108]
| Net Sales |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 2, 2016 |  |  | April 4, 2015 |  |  | % Change |  |
| Products |  | $ | 702 |  |  | $ | 758 |  |  |  | (7 | )% |
| Services |  |  | 491 |  |  |  | 465 |  |  |  | 6 | % |
| Total Motorola Solutions |  | $ | 1,193 |  |  | $ | 1,223 |  |  |  | (2 | )% |
| Non-GAAP Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 2, 2016 |  |  | April 4, 2015 |  |  | % Change |  |
| Products |  | $ | 84 |  |  | $ | 90 |  |  |  | (7 | )% |
| Services |  |  | 82 |  |  |  | 66 |  |  |  | 24 | % |
| Total Motorola Solutions |  | $ | 166 |  |  | $ | 156 |  |  |  | 6 | % |
| Non-GAAP Operating Earnings % |  |  |  |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 2, 2016 |  |  | April 4, 2015 |  |  |  |  |
| Products |  |  | 12.0 | % |  |  | 11.9 | % |  |  |  |  |
| Services |  |  | 16.7 | % |  |  | 14.2 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 13.9 | % |  |  | 12.8 | % |  |  |  |  |

[0001193125-16-579931:8k_2_02:109]
Non-GAAP-3

[0001193125-16-579931:8k_2_02:110]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-579931:8k_2_02:111]
Operating Earnings after Non-GAAP Adjustments

[0001193125-16-579931:8k_2_02:112]
| Q1 2016 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,193 |  |  | $ | 702 |  |  | $ | 491 |  |
| Operating earnings (“OE”) |  | $ | 100 |  |  | $ | 51 |  |  | $ | 49 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 11 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 23 |  |  |  | 21 |  |  |  | 2 |  |
| Intangibles amortization expense |  |  | 13 |  |  |  | 1 |  |  |  | 12 |  |
| Acquisition related transaction fees |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Total above-OE non-GAAP adjustments |  |  | 66 |  |  |  | 33 |  |  |  | 33 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 166 |  |  | $ | 84 |  |  | $ | 82 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 8.4 | % |  |  | 7.3 | % |  |  | 10.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 13.9 | % |  |  | 12.0 | % |  |  | 16.7 | % |
