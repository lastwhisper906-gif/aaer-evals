# MSI MD&A — 0000068505-16-000020


## mdna

[0000068505-16-000020:mdna:1]
[same as prior period, unchanged from 0000068505-15-000013:mdna:1]

[0000068505-16-000020:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three months ended April 2, 2016 and April 4, 2015, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0000068505-16-000020:mdna:3]
[same as prior period, unchanged from 0000068505-15-000013:mdna:3]

[0000068505-16-000020:mdna:4]
Recent Developments

[0000068505-16-000020:mdna:5]
On February 19, 2016, we completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which we invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. We will make a deferred cash payment of £64 million on November 15, 2018. We funded the investment with a $675 million term loan (the “Term Loan”) and approximately $400 million of international cash on hand. The acquisition of GDCL enables us to geographically diversify our global Managed & Support services offerings within our Services segment, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers.

[0000068505-16-000020:mdna:6]
[same as prior period, unchanged from 0000068505-15-000013:mdna:4]

[0000068505-16-000020:mdna:7]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries and 13,000 employees worldwide, based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-16-000020:mdna:8]
[same as prior period, unchanged from 0000068505-15-000013:mdna:6]

[0000068505-16-000020:mdna:9]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the first quarter of 2016, the segment’s net sales were $702 million, representing 59% of our consolidated net sales.

[0000068505-16-000020:mdna:10]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the first quarter of 2016, the segment’s net sales were $491 million, representing 41% of our consolidated net sales.

[0000068505-16-000020:mdna:11]
[same as prior period, unchanged from 0000068505-15-000013:mdna:9]

[0000068505-16-000020:mdna:12]
Impact of Macroeconomic Conditions: The stronger U.S. dollar has had a negative impact on sales denominated in currencies other than the U.S. dollar. In addition, weakening economic conditions and a significant drop in global commodity prices have negatively impacted sales in Latin America and Eastern Europe. The strengthening dollar has reduced the purchasing power of our customers, and the lower price of commodities has negatively impacted government budgets and funds available for the purchase of our products in these regions.

[0000068505-16-000020:mdna:13]
The impact of foreign exchange rate fluctuations on net earnings is partially mitigated by the following: (i) the majority of our revenues are derived from contracts within North America denominated in U.S. dollars, (ii) the cost of sales for the delivery of our Services offerings are predominately labor costs incurred within the same geographic region as the associated sales, resulting in minimal impact of foreign exchange rates on gross margin within the Services segment, and (iii) a significant portion of our operating expenses are denominated in foreign currencies as a result of our offshore research and development ("R&D") and selling, general, and administrative ("SG&A") footprint.

[0000068505-16-000020:mdna:14]
Cost Savings Initiatives: We are committed to employing disciplined financial policies and driving continuous efficiencies and improvements in our cost structure. We expect to reduce SG&A and R&D expenses during 2016 by approximately $120 million in comparison to 2015.

[0000068505-16-000020:mdna:15]
23

[0000068505-16-000020:mdna:16]
Growth of Our Services Portfolio: Our Services segment is expected to grow at a higher rate than our Products segment. Overall, the Services segment has a lower gross margin percentage than the Products segment, but we expect consolidated operating margins to continue to expand.

[0000068505-16-000020:mdna:17]
iDEN: We have experienced a downward trend in iDEN product and services sales over recent years due to decreased demand as a result of the dated nature of the technology. We expect the downward trend to continue as service contracts expire and new technology replaces iDEN equipment in the marketplace. This trend primarily relates to our Services segment as the majority of iDEN sales are hardware and software maintenance services. The expected decline in iDEN sales will impact both revenues and gross margins within the Services segment as iDEN services’ gross margins are generally higher than the remainder of our services portfolio.

[0000068505-16-000020:mdna:18]
Change in Presentation

[0000068505-16-000020:mdna:19]
During the first quarter of 2016, we restructured our regions operationally combining the Europe and Africa and Middle East regions into one region which is now reflected as Europe, Middle East, and Africa ("EMEA"). Accordingly, we now report net sales in the following four geographic regions: North America, Latin America, EMEA, and Asia Pacific ("AP"). We have updated all periods presented to reflect this change in presentation.

[0000068505-16-000020:mdna:20]
Geographic market sales measured by the locale of the end customer as a percent of total net sales are as follows:

[0000068505-16-000020:mdna:21]
|  | Three Months Ended |  | Year Ended December 31 |
|  | April 2, 2016 |  | April 4, 2015 |  | 2015 |  | 2014 |  | 2013 |
| North America | 66 | % |  | 63 | % |  | 65 | % |  | 61 | % |  | 63 | % |
| Latin America | 5 | % |  | 8 | % |  | 6 | % |  | 9 | % |  | 8 | % |
| EMEA | 19 | % |  | 18 | % |  | 17 | % |  | 19 | % |  | 17 | % |
| AP | 10 | % |  | 11 | % |  | 12 | % |  | 11 | % |  | 12 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-16-000020:mdna:22]
First Quarter Summary

[0000068505-16-000020:mdna:23]
| • | Net sales were $1.2 billion in the first quarter of 2016, a $30 million, or 2% decrease from the first quarter of 2015. Net sales in the first quarter of 2016 included the unfavorable impact of foreign currency fluctuations primarily within EMEA, AP, and Latin America, partially offset by growth in North America. |

[0000068505-16-000020:mdna:24]
| • | We generated operating earnings of $100 million, or 8% of net sales, in the first quarter of 2016, compared to $119 million, or 10% of net sales, in the first quarter of 2015. Profitability declined primarily as a result of: (i) lower gross margin in the Products segment and (ii) higher costs within Other charges associated with the acquisition of GDCL, including $13 million of transaction fees and increased intangible amortization expense. |

[0000068505-16-000020:mdna:25]
| • | We had earnings from continuing operations attributable to Motorola Solutions, Inc. of $17 million, or $0.10 per diluted common share, in the first quarter of 2016, compared to $87 million, or $0.40 per diluted common share, in the first quarter of 2015. |

[0000068505-16-000020:mdna:26]
| • | We generated net cash from operating activities of $13 million during the first quarter of 2016, compared to $156 million in the first quarter of 2015. Operating cash flows decreased primarily as a result of decreased earnings from continuing operations, higher working capital needs, higher incentive compensation, and increased payments of interest and income taxes. |

[0000068505-16-000020:mdna:27]
| • | We returned $135 million in capital to shareholders through dividends and share repurchases during the first quarter of 2016. |

[0000068505-16-000020:mdna:28]
A summary of our segment results is as follows:

[0000068505-16-000020:mdna:29]
| • | Products: Net sales were $702 million in the first quarter of 2016, a decrease of $56 million, or 7% compared to net sales of $758 million during the first quarter of 2015. On a geographic basis, net sales decreased in EMEA, Latin America, and AP, and increased in North America, compared to the year-ago quarter. |

[0000068505-16-000020:mdna:30]
| • | Services: Net sales were $491 million in the first quarter of 2016, an increase of $26 million, or 6% compared to net sales of $465 million in the first quarter of 2015. On a geographic basis, net sales increased in EMEA, North America, and AP and decreased in Latin America, compared to the year-ago quarter. |

[0000068505-16-000020:mdna:31]
[same as prior period, unchanged from 0000068505-15-000013:mdna:27]

[0000068505-16-000020:mdna:32]
|  | Three Months Ended |
| (Dollars in millions, except per share amounts) | April 2, 2016 |  | % ofSales** |  | April 4, 2015 |  | % ofSales** |
| Net sales from products | $ | 702 |  |  |  |  | $ | 758 |  |  |  |
| Net sales from services | 491 |  |  |  |  | 465 |  |  |  |
| Net sales | 1,193 |  |  |  |  | 1,223 |  |  |  |
| Costs of product sales | 366 |  |  | 52.1 | % |  | 359 |  |  | 47.4 | % |
| Costs of services sales | 325 |  |  | 66.2 | % |  | 316 |  |  | 68.0 | % |
| Costs of sales | 691 |  |  |  |  | 675 |  |  |  |
| Gross margin | 502 |  |  | 42.1 | % |  | 548 |  |  | 44.8 | % |
| Selling, general and administrative expenses | 234 |  |  | 19.6 | % |  | 256 |  |  | 20.9 | % |
| Research and development expenditures | 135 |  |  | 11.3 | % |  | 159 |  |  | 13.0 | % |
| Other charges | 33 |  |  | 2.8 | % |  | 14 |  |  | 1.1 | % |
| Operating earnings | 100 |  |  | 8.4 | % |  | 119 |  |  | 9.7 | % |
| Other income (expense): |  |  |  |  |  |  |  |
| Interest expense, net | (49 | ) |  | (4.1 | )% |  | (40 | ) |  | (3.3 | )% |
| Gain (loss) on sales of investments and businesses, net | (21 | ) |  | (1.8 | )% |  | 46 |  |  | 3.8 | % |
| Other | (8) |  |  | (0.7 | )% |  | 3 |  |  | 0.2 | % |
| Total other income (expense) | (78 | ) |  | (6.5 | )% |  | 9 |  |  | 0.7 | % |
| Earnings from continuing operations before income taxes | 22 |  |  | 1.8 | % |  | 128 |  |  | 10.5 | % |
| Income tax expense | 5 |  |  | 0.4 | % |  | 40 |  |  | 3.3 | % |
| Earnings from continuing operations | 17 |  |  | 1.4 | % |  | 88 |  |  | 7.2 | % |
| Less: Earnings attributable to noncontrolling interests | — |  |  | — | % |  | 1 |  |  | 0.1 | % |
| Earnings from continuing operations* | 17 |  |  | 1.4 | % |  | 87 |  |  | 7.1 | % |
| Loss from discontinued operations, net of tax | — |  |  | — | % |  | (13 | ) |  | (1.1 | )% |
| Net earnings* | $ | 17 |  |  | 1.4 | % |  | $ | 74 |  |  | 6.1 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.10 |  |  |  |  | $ | 0.40 |  |  |  |
| Discontinued operations | — |  |  |  |  | (0.06 | ) |  |  |
| Earnings per diluted common share* | $ | 0.10 |  |  |  |  | $ | 0.34 |  |  |  |

[0000068505-16-000020:mdna:33]
[same as prior period, unchanged from 0000068505-15-000013:mdna:29]

[0000068505-16-000020:mdna:34]
[same as prior period, unchanged from 0000068505-15-000013:mdna:30]

[0000068505-16-000020:mdna:35]
[same as prior period, unchanged from 0000068505-15-000013:mdna:15]

[0000068505-16-000020:mdna:36]
Results of Operations—Three months ended April 2, 2016 compared to three months ended April 4, 2015

[0000068505-16-000020:mdna:37]
[same as prior period, unchanged from 0000068505-15-000013:mdna:33]

[0000068505-16-000020:mdna:38]
Net sales were $1.2 billion in the first quarter of 2016, a $30 million, or 2% decrease from the first quarter of 2015. The decline in net sales is reflective of decreases in Latin America and AP, partially offset by growth in North America and EMEA. The decrease in Latin America was primarily the result of lower Products and Services sales due to macroeconomic pressures. The decrease in AP was due to lower Products sales, partially offset by growth in the Services segment. North America grew on Products and Services sales while EMEA grew on Services sales primarily due to the acquisition of GDCL, partially offset by lower Products sales.

[0000068505-16-000020:mdna:39]
[same as prior period, unchanged from 0000068505-15-000013:mdna:35]

[0000068505-16-000020:mdna:40]
Gross margin was $502 million, or 42.1% of net sales, in the first quarter of 2016, compared to $548 million, or 44.8% of net sales, in the first quarter of 2015. The decrease in gross margin percentage was driven by the Products segment while the gross margin percentage of the Services segment increased. The decrease in gross margin percentage in the Products segment was primarily driven by: (i) a decrease in volume, (ii) the unfavorable impact of foreign currency fluctuations, and (iii) lower devices sales outside of North America. The Services segment gross margin percentage improved with the completion of the Norway system integration and expansion of our Managed & Support services portfolio, primarily due to the acquisition of GDCL.

[0000068505-16-000020:mdna:41]
[same as prior period, unchanged from 0000068505-15-000013:mdna:37]

[0000068505-16-000020:mdna:42]
SG&A expenses decreased $22 million to $234 million, or 19.6% of net sales, in the first quarter of 2016, compared to $256 million, or 20.9% of net sales, in the first quarter of 2015. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions and (ii) the favorable impact of foreign exchange rates.

[0000068505-16-000020:mdna:43]
[same as prior period, unchanged from 0000068505-15-000013:mdna:63]

[0000068505-16-000020:mdna:44]
R&D expenditures decreased $24 million to $135 million, or 11.3% of net sales, in the first quarter of 2016, compared to $159 million, or 13.0% of net sales, in the first quarter of 2015. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions and the movement of employees to lower cost work sites, and (ii) the favorable impact of foreign exchange rates.

[0000068505-16-000020:mdna:45]
[same as prior period, unchanged from 0000068505-15-000013:mdna:41]

[0000068505-16-000020:mdna:46]
We recorded net charges of $33 million in Other charges in the first quarter of 2016, compared to net charges of $14 million in the first quarter of 2015. The net charges in the first quarter of 2016 included: (i) $13 million of transaction fees on the acquisition of GDCL, (ii) $13 million of charges relating to the amortization of intangibles, and (iii) $7 million of net reorganization of business charges, including a $3 million impairment of the corporate aircraft. The net Other charges in the first quarter of 2015 of $14 million included: (i) $12 million of net reorganization of business charges and (ii) $2 million of charges relating to the amortization of intangibles. The net reorganization of business charges are discussed in further detail in the “Reorganization of Business” section.

[0000068505-16-000020:mdna:47]
[same as prior period, unchanged from 0000068505-15-000013:mdna:43]

[0000068505-16-000020:mdna:48]
Net interest expense was $49 million in the first quarter of 2016 and $40 million in the first quarter of 2015. The increase in net interest expense in the first quarter of 2016 as compared to the first quarter of 2015 was a result of higher outstanding debt balances.

[0000068505-16-000020:mdna:49]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-16-000020:mdna:50]
Net losses on sales of investments and businesses were $21 million in the first quarter of 2016 compared to net gains on sales of investments and businesses of $46 million in the first quarter of 2015. The net losses in the first quarter of 2016 consisted of: (i) a $19 million loss on the sale of an investment in United Kingdom treasury securities, (ii) a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $5 million of gains on the sales of equity investments. The net gain in the first quarter of 2015 consisted of a gain on the sale of an equity investment.

[0000068505-16-000020:mdna:51]
[same as prior period, unchanged from 0000068505-15-000013:mdna:47]

[0000068505-16-000020:mdna:52]
Net Other expense was $8 million in the first quarter of 2016, compared to net Other income of $3 million in the first quarter of 2015. The net Other expense in the first quarter of 2016 was comprised of: (i) a $12 million loss on derivative instruments and (ii) a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of GDCL, partially offset by: (i) a $13 million foreign currency gain and (ii) a $1 million gain on equity method investments. The net Other income in the first quarter of 2015 was comprised of: (i) an $18 million foreign currency gain and (ii) $2 million of other non-operating gains, partially offset by a $17 million loss on derivative instruments.

[0000068505-16-000020:mdna:53]
[same as prior period, unchanged from 0000068505-15-000013:mdna:49]

[0000068505-16-000020:mdna:54]
We recorded $5 million of net tax expense in the first quarter of 2016, resulting in an effective tax rate of 23%, compared to $40 million of net tax expense, resulting in an effective tax rate of 31% in the first quarter of 2015. Our effective tax rate in 2016 was lower than the U.S. statutory tax rate of 35% primarily due to the recognition of excess tax benefits on share-based compensation in income tax expense as a result of the Company's adoption of ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." The rate was also positively impacted by the release of unrecognized tax benefit reserves, offset by increases in state valuation allowances and other adjustments to certain deferred tax assets. Our effective tax rate in the first quarter of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the U.S. domestic production tax deduction and rate differential for foreign affiliates.

[0000068505-16-000020:mdna:55]
[same as prior period, unchanged from 0000068505-15-000013:mdna:51]

[0000068505-16-000020:mdna:56]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $17 million, or $0.10 per diluted share, in the first quarter of 2016, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $87 million, or $0.40 per diluted share, in the first quarter of 2015.

[0000068505-16-000020:mdna:57]
The decrease in earnings from continuing operations in the first quarter of 2016, as compared to the first quarter of 2015, was primarily driven by: (i) a decrease in Gains on sales of investments and businesses of $67 million, (ii) an overall decline in Gross margin of $46 million, and (iii) a $19 million increase in Other charges, partially offset by: (i) a $24 million decrease in R&D expenses and (ii) a $22 million decrease in SG&A spend. The decrease in earnings from continuing operations per diluted share was driven by a decrease in earnings from continuing operations offset by lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-16-000020:mdna:58]
Loss from Discontinued Operations

[0000068505-16-000020:mdna:59]
In the first quarter of 2016, we reported no earnings from discontinued operations in the first quarter of 2016, compared to a loss from discontinued operations of $13 million, or $0.06 per diluted share, in the first quarter of 2015.

[0000068505-16-000020:mdna:60]
[same as prior period, unchanged from 0000068505-15-000013:mdna:81]

[0000068505-16-000020:mdna:61]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three months ended April 2, 2016 and April 4, 2015, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-16-000020:mdna:62]
[same as prior period, unchanged from 0000068505-15-000013:mdna:83]

[0000068505-16-000020:mdna:63]
For the first quarter of 2016, the segment’s net sales represented 59% of our consolidated net sales, compared to 62% of our consolidated net sales for the first quarter of 2015.

[0000068505-16-000020:mdna:64]
|  | Three Months Ended |  |  |
|  | April 2, 2016 |  | April 4, 2015 |  | % Change |
| Segment net sales | $ | 702 |  |  | $ | 758 |  |  | (7 | )% |
| Operating earnings | 51 |  |  | 64 |  |  | (20 | )% |

[0000068505-16-000020:mdna:65]
Three months ended April 2, 2016 compared to three months ended April 4, 2015

[0000068505-16-000020:mdna:66]
The segment’s net sales decreased $56 million, or 7%, to $702 million in the first quarter of 2016, as compared to the first quarter of 2015. The decrease in the segment's net sales was primarily driven by: (i) unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP, (ii) lower volumes, including decreased devices sales outside of North America and (iii) decreases in both devices and systems sales in Latin America primarily due to macroeconomic conditions, partially offset by growth of devices sales in North America. On a geographic basis, net sales decreased in EMEA, Latin America, and AP and increased in North America for the first quarter of 2016, compared to the first quarter of 2015.

[0000068505-16-000020:mdna:67]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 70% of the segment’s net sales in the first quarter of 2016, up from 64% of the segment's net sales in the first quarter of 2015.

[0000068505-16-000020:mdna:68]
The segment had operating earnings of $51 million in the first quarter of 2016, compared to $64 million in the first quarter of 2015. The decrease in operating earnings in the first quarter of 2016 compared to the first quarter of 2015, was primarily driven by: (i) lower gross margin as a result of lower devices sales, partially offset by: (i) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign exchange rates and (ii) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, and the favorable impact of foreign exchange rates.

[0000068505-16-000020:mdna:69]
[same as prior period, unchanged from 0000068505-15-000013:mdna:94]

[0000068505-16-000020:mdna:70]
For the first quarter of 2016, the segment’s net sales represented 41% of our consolidated net sales, compared to 38% of our consolidated net sales for the first quarter of 2015.

[0000068505-16-000020:mdna:71]
|  | Three Months Ended |  |  |
|  | April 2, 2016 |  | April 4, 2015 |  | % Change |
| Segment net sales | $ | 491 |  |  | $ | 465 |  |  | 6 | % |
| Operating earnings | 49 |  |  | 55 |  |  | (11 | )% |

[0000068505-16-000020:mdna:72]
Three months ended April 2, 2016 compared to three months ended April 4, 2015

[0000068505-16-000020:mdna:73]
The segment’s net sales increased $26 million, or 6%, to $491 million in the first quarter of 2016, as compared to net sales of $465 million in the first quarter of 2015. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from both the organic business as well as the Airwave acquisition. The acquisition of Airwave provided $61 million of net sales within EMEA during the quarter, while the organic Managed & Support services business grew in North America and AP. This sales growth was partially offset by: (i) a decrease in global Integration services sales, with significant decrease in EMEA related to the winding down of a large system implementation, (ii) declining iDEN services sales in Latin America, and (iii) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP. On a geographic basis, net sales for the first quarter of 2016 increased in EMEA, North America, and AP and decreased in Latin America, compared to the first quarter of 2015.

[0000068505-16-000020:mdna:74]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 59% of the segment’s net sales in the first quarter of 2016, compared to 61% of the segment’s net sales in the first quarter of 2015.

[0000068505-16-000020:mdna:75]
The segment had operating earnings of $49 million in the first quarter of 2016, compared to operating earnings of $55 million in the first quarter of 2015. The decrease in operating earnings in the first quarter of 2016 as compared to the first quarter of 2015 was driven by an increase in Other charges, including: (i) $13 million of acquisition related transaction fees and (ii) $12 million of intangible amortization expense associated with recent acquisitions.

[0000068505-16-000020:mdna:76]
[same as prior period, unchanged from 0000068505-15-000013:mdna:105]

[0000068505-16-000020:mdna:77]
During the first quarter of 2016, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first quarter of 2016, we recorded net reorganization of business charges of $23 million including charges of $7 million recorded in Other charges and $16 million in Cost of sales in our condensed consolidated statements of operations. Included in the $23 million were charges of: (i) $24 million for employee separation costs and (ii) $3 million for the impairment of the corporate aircraft, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-16-000020:mdna:78]
During the first quarter of 2015, we recorded net reorganization of business charges of $14 million including charges of $12 million recorded in Other charges and $2 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $14 million are charges of $10 million for employee separation costs and $4 million of exit costs.

[0000068505-16-000020:mdna:79]
[same as prior period, unchanged from 0000068505-15-000013:mdna:112]

[0000068505-16-000020:mdna:80]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Products | $ | 21 |  |  | $ | 10 |  |
| Services | 2 |  |  | 4 |  |
|  | $ | 23 |  |  | $ | 14 |  |

[0000068505-16-000020:mdna:81]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $23 million in the first quarter of 2016 and $28 million in the first quarter of 2015. The reorganization of business accruals at April 2, 2016 were $57 million, of which $50 million relate to employee separation costs that are expected to be paid within one year and $7 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-16-000020:mdna:82]
[same as prior period, unchanged from 0000068505-15-000013:mdna:115]

[0000068505-16-000020:mdna:83]
We decreased the aggregate of our cash and cash equivalent balances by $40 million from $2.0 billion as of December 31, 2015 to $1.9 billion as of April 2, 2016. The decrease is primarily due to $1.0 billion paid in the acquisition of GDCL, as well as $135 million of capital returned to shareholders through share repurchases and dividends paid, offset by $673 million of net proceeds raised by the issuance of the Term Loan (net of $2 million of issuance costs paid), $382 million of proceeds received from the sale of United Kingdom treasury securities used to partially fund the acquisition of GDCL, and $13 million of cash generated by operating activities.

[0000068505-16-000020:mdna:84]
[same as prior period, unchanged from 0000068505-15-000013:mdna:117]

[0000068505-16-000020:mdna:85]
[same as prior period, unchanged from 0000068505-15-000013:mdna:118]

[0000068505-16-000020:mdna:86]
At April 2, 2016, $1.4 billion of the $1.9 billion cash and cash equivalents balance was held in the U.S. and approximately $551 million was held by the Company or its subsidiaries in other countries, with approximately $187 million held in the United Kingdom. At both April 2, 2016 and December 31, 2015, restricted cash was $63 million.

[0000068505-16-000020:mdna:87]
Undistributed earnings that we intend to reinvest indefinitely, and for which no income taxes have been provided, aggregate to $1.4 billion at April 2, 2016. We currently have no plans to repatriate these permanently reinvested foreign earnings. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-16-000020:mdna:88]
[same as prior period, unchanged from 0000068505-15-000013:mdna:121]

[0000068505-16-000020:mdna:89]
Net cash provided by operating activities in the first quarter of 2016 was $13 million, as compared to $156 million in the first quarter of 2015. Operating cash flows in the first quarter of 2016, as compared to the first quarter of 2015, were negatively impacted by: (i) a decease in earnings from continuing operations, (ii) higher working capital needs, (iii) higher incentive compensation, and (iv) increased payments of interest and income taxes.

[0000068505-16-000020:mdna:90]
[same as prior period, unchanged from 0000068505-15-000013:mdna:124]

[0000068505-16-000020:mdna:91]
Net cash used by investing activities was $623 million in the first quarter of 2016, compared to $18 million in the first quarter of 2015. The $623 million cash used in the first quarter of 2016 included $1.1 billion cash used for acquisitions and investments, including $1.0 billion paid for the acquisition of GDCL, and $51 million in capital expenditures, partially offset by $481 million of proceeds from sales of investments and businesses. The cash usage of $18 million in the first quarter of 2015 consisted primarily of $74 million cash used for acquisitions and investments and $33 million in capital expenditures, partially offset by $88 million of proceeds from the sale of investments and businesses.

[0000068505-16-000020:mdna:92]
Acquisition and Investments:  We used net cash for acquisitions and investments of $1.1 billion during the first quarter of 2016 compared to $74 million in the first quarter of 2015. We paid cash of $1.0 billion during the first quarter of 2016 related to the acquisition of GDCL. The remainder of the cash was used for several debt and equity investments. The cash used during the first quarter of 2015 consisted of $49 million related to the acquisition of two public safety software solution providers and several debt and equity investments.

[0000068505-16-000020:mdna:93]
Sales of Investments and Businesses:  We had $481 million of proceeds related to the sales of investments and businesses in the first quarter of 2016 compared to $88 million in the first quarter of 2015. The proceeds in the first quarter of 2016 primarily consisted of: (i) $382 million from the sale of United Kingdom treasury securities used to finance the acquisition of GDCL, (ii) $53 million from the sales of various securities, and (iii) $46 million from the sale of our Penang, Malaysia facility and manufacturing operations. The proceeds in the first quarter of 2015 were comprised of: (i) $49 million reimbursement from Zebra Technologies for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale; (ii) $47 million from the sale of an equity investment, and (iii) $16 million net cash received from Zebra Technologies for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest.

[0000068505-16-000020:mdna:94]
Capital Expenditures:  Capital expenditures increased in the first quarter of 2016 to $51 million, compared to $33 million in the first quarter of 2015. The increase in capital expenditures was primarily related to information technology spend.

[0000068505-16-000020:mdna:95]
[same as prior period, unchanged from 0000068505-15-000013:mdna:130]

[0000068505-16-000020:mdna:96]
Net cash provided by financing activities was $577 million in the first quarter of 2016, compared to net cash used for financing activities of $687 million in the first quarter of 2015. Cash provided by financing activities in the first quarter of 2016 was primarily comprised of: (i) $673 million of net proceeds from the issuance of the Term Loan and (ii) $40 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan, partially offset by: (i) $71 million of cash used for the payment of dividends and (ii) $64 million used for purchases of our common stock under our share repurchase program. Net cash used for financing activities in the first quarter of 2015 was primarily comprised of: (i) $653 million used for purchases of our common stock under our share repurchase program and (ii)  $75 million of cash used for the payment of dividends, partially offset by $41 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-16-000020:mdna:97]
Long-Term Debt:  We had outstanding long-term debt of $5.0 billion and $4.3 billion, including the current portions of $4 million, at April 2, 2016 and December 31, 2015, respectively.

[0000068505-16-000020:mdna:98]
In connection with the completion of the acquisition of GDCL, we entered into a new term loan credit agreement (the “Term Loan Agreement”), under which we borrowed a Term Loan with an initial principal amount of $675 million. We received net proceeds of $673 million, net of $2 million of issuance costs. Interest on the Term Loan is variable and indexed to LIBOR. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed. Our borrowing capacity under the 2014 Motorola Solutions Credit Agreement may be partially limited during the second quarter of 2016 due to the additional indebtedness incurred in connection with the Term Loan. However, we believe we will continue to have sufficient liquidity to operate our business.

[0000068505-16-000020:mdna:99]
We have investment grade ratings on our senior unsecured long-term debt from the three largest U.S. national rating agencies. We continue to believe that we will be able to maintain sufficient access to the capital markets. Any future disruptions, uncertainty, or volatility in the capital markets or deterioration in our credit ratings may result in higher funding costs for us and adversely affect our ability to access funds.

[0000068505-16-000020:mdna:100]
Share Repurchase Program: During the three months ended April 2, 2016, the Company paid an aggregate of $64 million, including transaction costs, to repurchase approximately 0.9 million shares at an average price of $71.41 per share. As of April 2, 2016, the Company had used approximately $11.0 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.0 billion of authority available for future repurchases.

[0000068505-16-000020:mdna:101]
Payment of Dividends: During the first quarter of 2016, we paid $71 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $72 million in cash dividends to holders of our common stock.

[0000068505-16-000020:mdna:102]
[same as prior period, unchanged from 0000068505-15-000013:mdna:139]

[0000068505-16-000020:mdna:103]
As of April 2, 2016, we had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of April 2, 2016. We did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the first quarter of 2016.

[0000068505-16-000020:mdna:104]
[same as prior period, unchanged from 0000068505-15-000013:mdna:141]

[0000068505-16-000020:mdna:105]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $91 million at April 2, 2016, compared to $112 million at December 31, 2015.

[0000068505-16-000020:mdna:106]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $29 million at April 2, 2016, compared to $47 million at December 31, 2015.

[0000068505-16-000020:mdna:107]
[same as prior period, unchanged from 0000068505-15-000013:mdna:144]

[0000068505-16-000020:mdna:108]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended April 2, 2016 and April 4, 2015:

[0000068505-16-000020:mdna:109]
|  | Three Months Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Accounts receivable sales proceeds | $ | 2 |  |  | $ | 6 |  |
| Long-term receivables sales proceeds | 42 |  |  | 65 |  |
| Total proceeds from sales of accounts receivable | $ | 44 |  |  | $ | 71 |  |

[0000068505-16-000020:mdna:110]
At both April 2, 2016 and December 31, 2015, we had retained servicing obligations for $668 million of long-term receivables. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-16-000020:mdna:111]
Other Contingencies

[0000068505-16-000020:mdna:112]
[same as prior period, unchanged from 0000068505-15-000013:mdna:149]

[0000068505-16-000020:mdna:113]
Indemnification Provisions:  We are a party to a variety of agreements pursuant to which we are obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party's claims. In some instances, we may have recourse against third parties for certain payments made by us.

[0000068505-16-000020:mdna:114]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. We had no accruals for any such obligations at April 2, 2016.

[0000068505-16-000020:mdna:115]
Legal Matters:  We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on our consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-16-000020:mdna:116]
[same as prior period, unchanged from 0000068505-15-000013:mdna:153]

[0000068505-16-000020:mdna:117]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the our annual reporting period begins after December 15, 2017. In March 2016, the FASB issued ASU 2016-08, “"Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net)” which clarifies the implementation guidance on principal versus agent considerations and includes indicators to assist an entity in determining whether it controls a specified good or service before it is transferred to the customers. ASU 2014-09 allows for both retrospective and modified retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-16-000020:mdna:118]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us January 1, 2019 and interim periods within that reporting period.  The ASU requires a modified retrospective method upon adoption. We are in the process of assessing the impact of this ASU on our Consolidated Financial Statements.

[0000068505-16-000020:mdna:119]
In March 2016, the FASB issued ASU 2016-07, "Investments - Equity Method and Joint Ventures: Simplifying the Transition to the Equity Method of Accounting," which eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. ASU 2016-07 is effective for us January 1, 2017 and interim periods within that reporting period. The adoption of ASU 2016-07 is not expected to have a material effect on our condensed consolidated financial statements.
